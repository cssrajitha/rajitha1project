export function isFunctionalityEnabled(propName, locationCode, uswin) {
  if (sessionStorage.APP_PROPERTIES) {
    const cradleProps = JSON.parse(sessionStorage.APP_PROPERTIES);
    if (cradleProps) {
      const propValue = cradleProps[propName] && cradleProps[propName]?.toUpperCase();
      if (propValue && propValue === 'TRUE') {
        return true;
      }
      if (locationCode && propValue && propValue?.indexOf(locationCode?.toUpperCase()) >= 0) {
        return true;
      }
      if (uswin && propValue && propValue?.indexOf(uswin?.toUpperCase()) >= 0) {
        return true;
      }
      return false;
    }
    return false;
  }
  if (sessionStorage.getItem('assistedFlags')) {
    const assisedFlag = JSON.parse(sessionStorage.getItem('assistedFlags'));
    const propValue = assisedFlag[propName] && assisedFlag[propName]?.toUpperCase();
    if (propValue && propValue === 'TRUE') {
      return true;
    }
    return false;
  }
}
