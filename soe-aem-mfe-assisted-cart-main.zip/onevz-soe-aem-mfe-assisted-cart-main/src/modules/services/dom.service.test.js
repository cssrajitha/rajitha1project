const { isFunctionalityEnabled } = require('./dom.service');

describe('isFunctionalityEnabled', () => {
  beforeEach(() => {
    sessionStorage.clear();
  });

  it('should return true if propName is TRUE in APP_PROPERTIES', () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ TEST_PROP: 'TRUE' }));
    expect(isFunctionalityEnabled('TEST_PROP')).toBe(true);
  });

  it('should return true if propName contains locationCode in APP_PROPERTIES', () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ TEST_PROP: 'NYC' }));
    expect(isFunctionalityEnabled('TEST_PROP', 'nyc')).toBe(true);
  });

  it('should return true if propName contains uswin in APP_PROPERTIES', () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ TEST_PROP: 'US123' }));
    expect(isFunctionalityEnabled('TEST_PROP', null, 'us123')).toBe(true);
  });

  it('should return false if propName does not match any criteria in APP_PROPERTIES', () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ TEST_PROP: 'FALSE' }));
    expect(isFunctionalityEnabled('TEST_PROP')).toBe(false);
  });

  it('should return true if propName is TRUE in assistedFlags', () => {
    sessionStorage.setItem('assistedFlags', JSON.stringify({ TEST_PROP: 'TRUE' }));
    expect(isFunctionalityEnabled('TEST_PROP')).toBe(true);
  });
  it('should return false if propName is not TRUE in assistedFlags', () => {
    sessionStorage.setItem('assistedFlags', JSON.stringify({ TEST_PROP: 'FALSE' }));
    expect(isFunctionalityEnabled('TEST_PROP')).toBe(false);
  });
});
