import { injectAPI } from 'onevzsoemfeframework/APIService';
import { GetAppConfig } from 'onevzsoemfeframework/GetAppConfig';

const appConfig = GetAppConfig();
const { urls } = appConfig;
const getAccountInfoForAIQuote = '/quoteservice/getAccountInfoForAIQuote';
const compareQuotes = '/quoteservice/compareQuotes';
const captureQuoteFeedback = '/quoteservice/captureQuoteFeedback';
const updateVisionRemark = '/acctmgmtservice/updateVisionRemark';
const removeSelectedLinesFromCart = '/cartservice/cart/remove-lines';
const generateInspicioID = '/inspicioservice/inspicio/generateInspicioID';
const sendMessage = '/inspicioservice/inspicio/sendMessage';
const createapplication = '/accountlandingservice/isaac/createapplication';
const autopaySendMessage = '/messageservice/send-message';
const TAG_SEND_MESSAGE = 'tag_send_message';
const TAG_CREATE_APPLICATION = 'tag_create_application';
const TAG_CALL_SEND_MESSAGE = 'tag_autopay_send_message';
const {
  getMyOffers,
  getMultipleAddressQualification,
  landing,
  typeAhead,
  getSkuDetails,
  fetchPricingSnapshot,
  retrieveCart,
  getPromo,
} = urls;

// Query builder Types
export const MUTATION = 'mutation';
export const QUERY = 'query';

// HTTP Method
export const POST = 'POST';
// export const GET = 'GET';

// const fetchPricingSnapshot = '/addonsservice/fetchPricingSnapshot';
const ADD_ACCESSORY_TO_CART_URL = '/cartservice/cart/add-accessories'; // need to move to common repo
const PROCESS_ACCT_INQUIRY_TRAN_DETAILS = '/acctmgmtservice/processAcctInquiryTranDetails';
const RETRIEVE_AEM_INFO_MANAGER_DATA = '/inspicioservice/inspicio/retrieveAEMInfoManagerData';
// Tags
const TAG_FETCH_PRICING_SNAPSHOT = 'tag_fetch_pricing_snapshot';
export const TAG_MY_OFFERS = 'tag_my_offers';
export const TAG_MY_LANDING = 'tag_my_landing';
export const TAG_ADD_ACCESSORY = 'tag_add_accessory';
export const TAG_TYPE_AHEAD_LIST = 'tag_type_ahead_list';
export const TAG_SKU_DETAILS = 'tag_sku_details';
export const TAG_GET_ACCOUNT_INFO_FOR_AI_QUOTE = 'tag_getAccountInfoForAIQuote';
export const TAG_PROCESS_ACCT_INQUIRY_TRAN_DETAILS = 'tag_process_acct_inquiry_tran_details';
export const TAG_GET_MULTIPLE_ADDRESS_QUALIFICATION = 'tag_getMultipleAddressQualification';
export const TAG_COMPAREQUOTES = 'tag_compareQuote';
export const TAG_CAPTURE_QUOTE_FEEDBACK = 'tag_capture_quote_feedback';
export const TAG_GET_CART_DETAILS = 'tag_cart_details';
export const TAG_GET_PROMO_DETAILS = 'tag_get_promo';
export const TAG_REMOVE_SELECTED_LINES_FROM_CART = 'tag_remove_selected_lines_from_cart';
export const TAG_UPDATE_VISION_REMARK = 'tag_update_vision_remark';
export const TAG_APPLY_OFFERS = 'tag_apply_offers';
export const TAG_RETRIEVE_AEM_INFO_MANAGER_DATA = 'tag_retrieve_aem_info_manager_data';
const TAG_GENERATE_INSPICIO_ID = 'tag_generate_inspicio_id';
// Names
const API_FETCH_PRICING_SNAPSHOT = 'getFetchPricingSnapshot';
const API_GENERATE_INSPICIO_ID = 'generateInspicioID';
const API_SEND_MESSAGE = 'sendMessage';
const API_CREATE_APPLICATION = 'createapplication';
const API_CALL_SEND_MESSAGE = 'autopaySendMessage';
export const API_MY_OFFERS = 'getMyOffers';
export const API_MY_LANDING = 'getLanding';
export const API_ADD_ACCESSORY = 'addAccessory';
export const API_TYPE_AHEAD_LIST = 'getTypeAhead';
export const API_SKU_DETAILS_LIST = 'getSkuDetails';
export const API_REMOVE_SELECTED_LINES_FROM_CART = 'removeSelectedLinesFromCart';
export const API_GET_ACCOUNT_INFO_FOR_AI_QUOTE = 'getAccountInfoForAIQuote';
export const API_PROCESS_ACCT_INQUIRY_TRAN_DETAILS = 'processAcctInquiryTranDetails';
export const API_GET_MULTIPLE_ADDRESS_QUALIFICATION = 'getMultipleAddressQualification';
export const API_COMPARE_QUOTES = 'compareQuotes';
export const API_CAPTURE_QUOTE_FEEDBACK = 'captureQuoteFeedback';
export const API_GET_CART_DETAILS = 'getCartDetails';
export const API_GET_PROMO_DETAILS = 'getPromo';
export const API_UPDATE_VISION_REMARK = 'updateVisionRemark';
export const API_APPLY_OFFERS = 'applyOffers';
export const API_RETRIEVE_AEM_INFO_MANAGER_DATA = 'retrieveAEMInfoManagerData';

// hooks
export const { useGetFetchPricingSnapshotQuery } = injectAPI(
  API_FETCH_PRICING_SNAPSHOT,
  TAG_FETCH_PRICING_SNAPSHOT,
  fetchPricingSnapshot,
);
export const { useFetchPricingSnapshotMutation } = injectAPI(
  API_FETCH_PRICING_SNAPSHOT,
  TAG_FETCH_PRICING_SNAPSHOT,
  fetchPricingSnapshot,
  POST,
  MUTATION,
  [],
  0,
);
export const { useGetMyOffersQuery } = injectAPI(API_MY_OFFERS, TAG_MY_OFFERS, getMyOffers);
export const { useLazyGetLandingQuery } = injectAPI(API_MY_LANDING, TAG_MY_LANDING, landing);
export const { useLazyAddAccessoryQuery } = injectAPI(API_ADD_ACCESSORY, TAG_ADD_ACCESSORY, ADD_ACCESSORY_TO_CART_URL);
export const { useLazyGetTypeAheadQuery } = injectAPI(API_TYPE_AHEAD_LIST, TAG_TYPE_AHEAD_LIST, typeAhead);
export const { useLazyGetSkuDetailsQuery } = injectAPI(API_SKU_DETAILS_LIST, TAG_SKU_DETAILS, getSkuDetails);

export const { useLazyProcessAcctInquiryTranDetailsQuery } = injectAPI(
  API_PROCESS_ACCT_INQUIRY_TRAN_DETAILS,
  TAG_PROCESS_ACCT_INQUIRY_TRAN_DETAILS,
  PROCESS_ACCT_INQUIRY_TRAN_DETAILS,
);

export const { useLazyRemoveSelectedLinesFromCartQuery } = injectAPI(
  API_REMOVE_SELECTED_LINES_FROM_CART,
  TAG_REMOVE_SELECTED_LINES_FROM_CART,
  removeSelectedLinesFromCart,
);

export const { useGetAccountInfoForAIQuoteQuery } = injectAPI(
  API_GET_ACCOUNT_INFO_FOR_AI_QUOTE,
  TAG_GET_ACCOUNT_INFO_FOR_AI_QUOTE,
  getAccountInfoForAIQuote,
);

export const { useGetMultipleAddressQualificationQuery } = injectAPI(
  API_GET_MULTIPLE_ADDRESS_QUALIFICATION,
  TAG_GET_MULTIPLE_ADDRESS_QUALIFICATION,
  getMultipleAddressQualification,
);

export const { useLazyCompareQuotesQuery } = injectAPI(API_COMPARE_QUOTES, TAG_COMPAREQUOTES, compareQuotes);

export const { useLazyCaptureQuoteFeedbackQuery } = injectAPI(
  API_CAPTURE_QUOTE_FEEDBACK,
  TAG_CAPTURE_QUOTE_FEEDBACK,
  captureQuoteFeedback,
);

export const { useLazyGetFetchPricingSnapshotQuery } = injectAPI(
  API_FETCH_PRICING_SNAPSHOT,
  TAG_FETCH_PRICING_SNAPSHOT,
  fetchPricingSnapshot,
);

export const { useLazyGetCartDetailsQuery } = injectAPI(API_GET_CART_DETAILS, TAG_GET_CART_DETAILS, retrieveCart);

export const { useLazyGetPromoQuery } = injectAPI(API_GET_PROMO_DETAILS, TAG_GET_PROMO_DETAILS, getPromo);

export const { useLazyUpdateVisionRemarkQuery } = injectAPI(
  API_UPDATE_VISION_REMARK,
  TAG_UPDATE_VISION_REMARK,
  updateVisionRemark,
);

export const { useLazyRetrieveAEMInfoManagerDataQuery } = injectAPI(
  API_RETRIEVE_AEM_INFO_MANAGER_DATA,
  TAG_RETRIEVE_AEM_INFO_MANAGER_DATA,
  RETRIEVE_AEM_INFO_MANAGER_DATA,
);

export const { useLazyGenerateInspicioIDQuery } = injectAPI(
  API_GENERATE_INSPICIO_ID,
  TAG_GENERATE_INSPICIO_ID,
  generateInspicioID,
);

export const { useLazySendMessageQuery } = injectAPI(API_SEND_MESSAGE, TAG_SEND_MESSAGE, sendMessage, POST);

export const { useLazyCreateapplicationQuery } = injectAPI(
  API_CREATE_APPLICATION,
  TAG_CREATE_APPLICATION,
  createapplication,
  POST,
);

export const { useLazyAutopaySendMessageQuery } = injectAPI(
  API_CALL_SEND_MESSAGE,
  TAG_CALL_SEND_MESSAGE,
  autopaySendMessage,
  POST,
);
