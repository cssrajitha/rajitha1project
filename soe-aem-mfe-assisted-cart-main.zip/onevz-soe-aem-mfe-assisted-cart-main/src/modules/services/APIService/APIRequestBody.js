/* eslint-disable no-nested-ternary */
export const requestBodyRetriveCart = {
  meta: {
    client: 'CXP',
  },
  data: {
    cartId: '',
    retrieveCurrentFeatures: true,
  },
};

export const requestBodyCustomerProfile = {
  customerId: '',
  mtn: '',
  channelId: '',
  cartCreatorOrderLocationCode: '',
  cartCreatorSalesRepId: '',
  registerNumber: '',
  cartId: '',
  caseId: '',
  loggedInUser: '',
  intent: '',
  enableAssistedTagging: true,
  adobeSubkey: sessionStorage.getItem('adobe-sessionId') || '', // adobeSubkey is added solely for Tagging, pls do not remove it.
};

export const requestBodyFetchPricingShapshort = {
  cartId: '',
  caseId: '',
  quoteNSAEnabled: true,
  requestSource: 'LANDING',
  unifiedNbsFlag: false,
};

export const requestBodyLanding = {
  customerId: '',
  mtn: '',
  cartCreatorOrderLocationCode: '',
  cartCreatorSalesRepId: '',
  registerNumber: '',
  cartId: '',
  caseId: '',
  loggedInUser: '',
};

export const requestBodyProductList = {
  data: {
    correlationId: '',
    market: '',
    custType: '',
    siteId: '',
    masterAgentCode: '',
    locationCode: '',
    productType: 'device',
    intentType: 'NSE',
    zipCode: '',
    customerLoggedInOrNot: false,
    compatibleProductId: '',
    prepayCart: false,
    orderType: 'PS',
    filterSortData: {
      sortOption: '',
      paymentOption: '',
      filters: [
        {
          type: 'Category',
          values: ['Smartphones'],
        },
        {
          type: 'Brand',
          values: [''],
        },
        {
          type: 'OS',
          values: [''],
        },
        {},
      ],
    },
    paginationData: {
      offset: 0,
      recPerPage: 24,
    },
    enableGridwallPersonalization: false,
  },
};

export const requestBodyupdateRemark = {
  mdn: '',
  requestMapping: 'autoRemarksUpdate',
  billAccountType: 'C',
  location: '',
  contactName: '',
  remarkLevel: 'A',
  page: '1',
  accessLvl: '1',
  remarkText: '',
  customerId: '',
  billingSystem: 'VISION_NORTH',
  billAccountNumber: '00001',
  remarkType: '',
};



/* istanbul ignore next */
export const prepareCcdApiPayload = (lineDetails, spanishSelected) => {
  const planIds = [];
  lineDetails?.lineInfo.forEach((line) => {
    if (line?.serviceInfo?.newPricePlanId) {
      planIds.push({ id: line?.serviceInfo?.newPricePlanId, status: 'add' });
      if (line?.serviceInfo?.oldPricePlanId) {
        planIds.push({ id: line?.serviceInfo?.oldPricePlanId, status: 'remove' });
      }
    } else if (line?.serviceInfo?.pricePlanInfo?.pricePlanCode) {
      planIds.push({ id: line?.serviceInfo?.pricePlanInfo?.pricePlanCode, status: 'keep' });
    } else if (line?.serviceInfo?.oldPricePlanId) {
      planIds.push({ id: line?.serviceInfo?.oldPricePlanId, status: 'keep' });
    }
  });

  const sbdOffers =
    lineDetails?.lineInfo
      ?.flatMap((e) => e?.serviceInfo?.sbdOffer)
      ?.map((e) => e?.offerId)
      ?.filter((e) => e !== undefined) || [];
  const tradeInOffers =
    lineDetails?.tradeInDetail?.tradeInItems
      ?.flatMap((e) => e?.recycleDeviceOffer)
      ?.map((e) => e?.offerId)
      ?.filter((e) => e !== undefined) || [];
  const promoOfferIds = [...new Set([...sbdOffers, ...tradeInOffers])].map((id) => ({ id, status: 'A' })) || [];
  const featureIds = [
    ...new Set(
      lineDetails?.lineInfo
        ?.flatMap((x) => x?.serviceInfo?.selectedFeaturesList?.visFeature)
        ?.map((x) => ({
          id: x?.visFeatureCode,
          status: x?.addDeleteInd === 'A' ? 'add' : x?.addDeleteInd === 'Z' ? 'keep' : 'remove',
        })) || [],
    ),
  ];

  let channelType = 'direct_';
  let orderType = 'service_change_flow';
  if (sessionStorage.getItem('channel') === 'OMNI-INDIRECT') {
    channelType = 'indirect_';
  }
  lineDetails?.lineInfo?.forEach((item) => {
    if (
      item.lineActivityType &&
      (item.lineActivityType.includes('AAL') ||
        item.lineActivityType.includes('NSE') ||
        item.lineActivityType.includes('EUP') ||
        item.lineActivityType.includes('BYOD'))
    ) {
      orderType = 'purchase_flow';
    }
  });
  const channelFlow = `${channelType + orderType}`;

  const requestPayload = {
    content: {
      planIds: {
        idlist: planIds,
        category: 'plan',
      },
      featureIds: {
        idlist: featureIds,
        category: 'feature',
      },
      promoIds: { idlist: promoOfferIds, category: 'promo' },
    },
    channel: channelFlow,
    contenttype: 'html',
    langInd: !spanishSelected ? 'EN' : 'ES',
  };
  return requestPayload;
};
/* export const requestBodyInitiateClickToCall = {
    agentLocationId: '',
    agentLocationName: '',
    agentUserName: '',
    callRsn: '',
    cbr: '',
    ccANum: '',
  }; */
