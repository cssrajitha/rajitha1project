 // import { useGetCartDetailsQuery } from '../../../Services/APIService/APIServiceHooks';
 import { GetAppConfig } from '../APIService/APIServiceHooks';
 import useGetCartDetailsQuery from './APIServiceHooks'
 
  describe('Test retrivecart apis', () => {
    beforeEach(() => {
      window.vzFlags = {};
    });
    test('Test getRetriveCartAPI', async () => {
      expect('tag_retrive_cart').toBe('tag_retrive_cart');
     // expect(useGetCartDetailsQuery).toBe('tag_retrive_cart');
    });
  });