import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import StoreProvider from './modules/store/index';
import CartFooter from './pages/Footer';

function App() {
  return (
    <StoreProvider>
      <Router>
        <Routes>
          {/* <Route path='/' element={<Cart />} /> */}
          {/* <Route path='/sales/assisted/new/cart/shopping-cart.html' element={<Cart />} /> */}
          <Route exact path='sales/assisted/new/footer.html' element={<CartFooter />} />
        </Routes>
      </Router>
    </StoreProvider>
  );
}

export default App;
