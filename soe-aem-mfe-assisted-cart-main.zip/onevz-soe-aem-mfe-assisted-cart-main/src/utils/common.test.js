import { useSelector } from 'react-redux';
import { useCradleState } from './common';

// Mock the useSelector function
jest.mock('react-redux', () => ({
  useSelector: jest.fn(),
}));

describe('useCradleState', () => {
  afterEach(() => {
    jest.clearAllMocks(); // Clear mocks after each test
  });

  it('should return the correct cradle state when data exists', () => {
    // Mock the Redux state structure
    const mockState = {
      APIService: {
        queries: {
          'getCradleService({"body":{"properties":[{"name":"applicationId","value":"assisted"},{"name":"locationCode","value":"2777301"},{"name":"pageName","value":"SOEORDERSPRINT1"},{"name":"uswin","value":"mastral"},{"name":"platform","value":"desktop"},{"name":"locationSubType","value":""}]}, "spinner":false})':
            {
              data: {
                enableFullBlownMfeNbsPosFFlag: 'TRUE',
              },
            },
        },
      },
    };

    // Mock the return value of useSelector
    useSelector.mockImplementation((selector) => selector(mockState));

    // Call the hook
    const result = useCradleState();

    // Assert the result
    expect(result).toEqual(undefined);
  });
});
