import { GetAppConfig } from './GetAppConfig';
import expectedAppConfig from './appconfig.json';

describe('GetAppConfig', () => {
  it('should return the appConfig from appconfig.json', () => {
    const result = GetAppConfig();
    expect(result).toEqual(expectedAppConfig);
  });
});
