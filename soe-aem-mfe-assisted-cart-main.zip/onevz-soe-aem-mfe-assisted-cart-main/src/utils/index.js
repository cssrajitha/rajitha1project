import { GetAppConfig } from './GetAppConfig';

export { GetAppConfig };
