import { useSelector } from 'react-redux';

export const useCradleState = () =>
  useSelector(
    (state) =>
      state?.APIService?.queries[
        'getCradleService({"body":{"properties":[{"name":"applicationId","value":"assisted"},{"name":"locationCode","value":"2777301"},{"name":"pageName","value":"SOEORDERSPRINT1"},{"name":"uswin","value":"mastral"},{"name":"platform","value":"desktop"},{"name":"locationSubType","value":""}]},"spinner":false})'
      ],
  );
