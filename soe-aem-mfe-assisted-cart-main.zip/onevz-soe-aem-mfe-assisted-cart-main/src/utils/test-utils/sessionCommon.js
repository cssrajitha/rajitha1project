// import Cookies from 'universal-cookie';

export const SetStorageSession = (key, value) => {
  window.sessionStorage.setItem(key, value);
};
export const setSession = (sessionName, value) => {
  window.sessionStorage.setItem(sessionName, value);
};

export const getSession = (name) => {
  const value = window.sessionStorage.getItem(name);
  return value;
};

export const ClearStorageSession = () => {
  window.sessionStorage.clear();
};

// export const SetCookie = (cookieName, value) => {
//   document.cookie = `${cookieName}=${value};path=/`;
// };
// export const getCookie = (name) => {
//   const cookies = new Cookies();
//   return cookies.get(name) || '';
// };

// export const ClearCookie = (name) => {
//   document.cookie = `${name}=1; expires=1 Jan 1970 00:00:00 GMT;`;
// };
