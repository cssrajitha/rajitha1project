import { createMemoryHistory } from 'history';
import { createHistory } from './memoryHistory';

describe('createHistory', () => {
  test('creating initial route', () => {
    const initialRoute = '/example';
    const history = createHistory(initialRoute);
    expect(Object.getPrototypeOf(history)).toBe(Object.getPrototypeOf(createMemoryHistory()));
    // expect(history.location.pathname).toBe(initialRoute);
  });
  test('should navigate to a new page', () => {
    const initialRoute = '/example';
    const history = createHistory(initialRoute);
    const newPath = '/new-page';
    history.navigatePage(newPath);
  });
});
