import { render, screen } from './renderHelper';

it('should test render function', () => {
    render(<h1>Hello World</h1>);
    expect(screen.getByRole('heading')).toBeInTheDocument();
  });
  