import { getApiContext, getnetworktype } from './utils';
import { cleanup } from '@testing-library/react';
import { setUserAgentIPad } from './utils';
import { setupChannel } from './utils';
import { wait } from './utils';

describe('GetAppConfig', () => {
  it('should return the appConfig from appconfig.json', () => {
    const result = getApiContext();
    expect(result).toBeUndefined();
  });
  it('should return the appConfig from appconfig.json', () => {
    const result = getApiContext('OMNI-RETAIL-TAB');
    expect(result).toBe('https://sposstore-soe.vzwcorp.com');
  });
  it('should return the appConfig from appconfig.json', () => {
    const result = getApiContext('OMNI-TELESALES');
    expect(result).toBe('https://telestore-soe.vzwcorp.com');
  });
});


const TestUtilDevices = () => {
  describe('test util display', () => {
    beforeAll(() => {
      Object.defineProperty(global.navigator, 'userAgent', {
        get() {
          return 'iPad';
        },
        configurable: true,
      });
    });
    test('in util devices with pageName as ExpressHub', () => {
      // setUserAgentIPad('Android|iPhone|MY_VZW_APP|VZW_MFA_IOS');
      setUserAgentIPad();
      setupChannel('test');
    });
  });
};

const TestwaitDevices = () => {
  describe('test wait display', () => {
    test('in waiting session for milliseconds', async() => {
      await(wait(100));
    });
  });
};

const TestGetNetworkType = () => {
  describe('getnetworktype', () => {
  beforeEach(() => {
    sessionStorage.clear();
  });

  afterEach(() => {
    sessionStorage.clear();
  });

  // VHILite flow tests
  describe('VHILite flow', () => {
    it('should return "LTE" when fiveGHomeInternetSelectedFlow is "VHILite"', () => {
      sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'VHILite');

      const result = getnetworktype();

      expect(result).toBe('LTE');
    });

    it('should return "LTE" when fiveGHomeInternetSelectedFlow is "VHILite" regardless of other qualifications', () => {
      sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'VHILite');
      sessionStorage.setItem('wifiBackupCbandQualified', 'true');
      sessionStorage.setItem('Qualification_type', 'CBD');

      const result = getnetworktype();

      expect(result).toBe('LTE');
    });
  });

  // WiFi-Backup flow tests
  describe('WiFi-Backup flow', () => {
    it('should return "LTE" when WiFi-Backup flow with wifiBackupLteQualified true', () => {
      sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'WiFi-Backup');
      sessionStorage.setItem('wifiBackupLteQualified', 'true');

      const result = getnetworktype();

      expect(result).toBe('LTE');
    });

    it('should return "CBD" when WiFi-Backup flow with wifiBackupCbandQualified true', () => {
      sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'WiFi-Backup');
      sessionStorage.setItem('wifiBackupCbandQualified', 'true');

      const result = getnetworktype();

      expect(result).toBe('CBD');
    });

    it('should return "LTE" when WiFi-Backup flow with both qualifications (LTE has priority)', () => {
      sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'WiFi-Backup');
      sessionStorage.setItem('wifiBackupLteQualified', 'true');
      sessionStorage.setItem('wifiBackupCbandQualified', 'true');

      const result = getnetworktype();

      expect(result).toBe('LTE');
    });

    it('should return empty string when WiFi-Backup flow but no qualifications', () => {
      sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'WiFi-Backup');
      sessionStorage.setItem('wifiBackupLteQualified', 'false');
      sessionStorage.setItem('wifiBackupCbandQualified', 'false');

      const result = getnetworktype();

      expect(result).toBe('');
    });

    it('should return empty string when WiFi-Backup flow with qualifications not set to "true"', () => {
      sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'WiFi-Backup');
      sessionStorage.setItem('wifiBackupLteQualified', 'TRUE'); // uppercase
      sessionStorage.setItem('wifiBackupCbandQualified', 'yes'); // not "true"

      const result = getnetworktype();

      expect(result).toBe('');
    });
  });

  // 5G-Internet flow tests
  describe('5G-Internet flow', () => {
    it('should return "LTE" when 5G-Internet flow with Qualification_type LTE', () => {
      sessionStorage.setItem('fiveGHomeInternetSelectedFlow', '5G-Internet');
      sessionStorage.setItem('Qualification_type', 'LTE');

      const result = getnetworktype();

      expect(result).toBe('LTE');
    });

    it('should return "CBD" when 5G-Internet flow with Qualification_type CBD', () => {
      sessionStorage.setItem('fiveGHomeInternetSelectedFlow', '5G-Internet');
      sessionStorage.setItem('Qualification_type', 'CBD');

      const result = getnetworktype();

      expect(result).toBe('CBD');
    });

    it('should return "MMW" when 5G-Internet flow with Qualification_type MMW', () => {
      sessionStorage.setItem('fiveGHomeInternetSelectedFlow', '5G-Internet');
      sessionStorage.setItem('Qualification_type', 'MMW');

      const result = getnetworktype();

      expect(result).toBe('MMW');
    });

    it('should return empty string when 5G-Internet flow without Qualification_type', () => {
      sessionStorage.setItem('fiveGHomeInternetSelectedFlow', '5G-Internet');

      const result = getnetworktype();

      expect(result).toBe('');
    });

  // Edge cases and default behavior
  describe('Edge cases', () => {
    it('should return empty string when fiveGHomeInternetSelectedFlow is not set', () => {
      const result = getnetworktype();

      expect(result).toBe('');
    });

    it('should return empty string when fiveGHomeInternetSelectedFlow is empty string', () => {
      sessionStorage.setItem('fiveGHomeInternetSelectedFlow', '');

      const result = getnetworktype();

      expect(result).toBe('');
    });

    it('should return empty string when fiveGHomeInternetSelectedFlow is null', () => {
      sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'null');

      const result = getnetworktype();

      expect(result).toBe('');
    });

    it('should return empty string when fiveGHomeInternetSelectedFlow has unexpected value', () => {
      sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'UnknownFlow');

      const result = getnetworktype();

      expect(result).toBe('');
    });

    it('should be case-sensitive for flow values', () => {
      sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'vhilite'); // lowercase
      sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'wifi-backup'); // lowercase

      const result = getnetworktype();

      expect(result).toBe('');
    });
  });

  // Priority tests
  describe('Flow priority', () => {
    it('should prioritize VHILite flow over other flows', () => {
      sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'VHILite');
      sessionStorage.setItem('wifiBackupCbandQualified', 'true');
      sessionStorage.setItem('Qualification_type', 'MMW');

      const result = getnetworktype();

      expect(result).toBe('LTE'); // VHILite always returns LTE
    });

    it('should check WiFi-Backup before 5G-Internet when both could apply', () => {
      sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'WiFi-Backup');
      sessionStorage.setItem('wifiBackupCbandQualified', 'true');
      sessionStorage.setItem('Qualification_type', 'LTE');

      const result = getnetworktype();

      expect(result).toBe('CBD'); // WiFi-Backup CBD qualification takes precedence
    });
  });

    it('should handle undefined sessionStorage keys', () => {
      // Don't set anything in sessionStorage
      const result = getnetworktype();

      expect(result).toBe('');
    });
  });

  // Integration-like tests
  describe('Real-world scenarios', () => {
    it('should handle VHILite customer scenario', () => {
      sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'VHILite');

      const result = getnetworktype();

      expect(result).toBe('LTE');
    });

    it('should handle WiFi-Backup with LTE customer scenario', () => {
      sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'WiFi-Backup');
      sessionStorage.setItem('wifiBackupLteQualified', 'true');

      const result = getnetworktype();

      expect(result).toBe('LTE');
    });

    it('should handle WiFi-Backup with CBD customer scenario', () => {
      sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'WiFi-Backup');
      sessionStorage.setItem('wifiBackupCbandQualified', 'true');

      const result = getnetworktype();

      expect(result).toBe('CBD');
    });

    it('should handle 5G-Internet MMW customer scenario', () => {
      sessionStorage.setItem('fiveGHomeInternetSelectedFlow', '5G-Internet');
      sessionStorage.setItem('Qualification_type', 'MMW');

      const result = getnetworktype();

      expect(result).toBe('MMW');
    });

    it('should handle 5G-Internet CBD customer scenario', () => {
      sessionStorage.setItem('fiveGHomeInternetSelectedFlow', '5G-Internet');
      sessionStorage.setItem('Qualification_type', 'CBD');

      const result = getnetworktype();

      expect(result).toBe('CBD');
    });

    it('should handle 5G-Internet LTE customer scenario', () => {
      sessionStorage.setItem('fiveGHomeInternetSelectedFlow', '5G-Internet');
      sessionStorage.setItem('Qualification_type', 'LTE');

      const result = getnetworktype();

      expect(result).toBe('LTE');
    });

    it('should handle customer with no qualifications', () => {
      sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'WiFi-Backup');

      const result = getnetworktype();

      expect(result).toBe('');
    });
  });
});
}

TestwaitDevices();
TestUtilDevices();
TestGetNetworkType();
