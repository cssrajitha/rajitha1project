export const affirmEnableContent = {
  affrimHeaderLabel: 'Affirm',
  affrimContent: 'As low as 0% APR when you pay over time with Affirm',
  affrimSeeDetailsLabel: 'See details',
};
export const affirmAccConfig = {
  devPublicKey: 'JA9VX7XQIXIR9H2O',
  prodPublicKey: 'JA9VX7XQIXIR9H2O',
  devScript: 'https://cdn1.sandbox.affirm.com/js/v2/affirm.js',
  prodScript: 'https://cdn1.affirm.com/js/v2/affirm.js',
};
export const secondNumberPerkContent = {
  reviewOrderAlert: {
    message:
      'To proceed, you must first activate the Second Number line or remove the Second Number Perk for the (line(s)) - (MTN(s))',
  },
  categoryCode: 'BYO2NDNUM',
};
export const FooterMessageContent = {
  splitDepletionMessage:
    'Cannot combine multiple depletions in a single order, switch all lines to either Local / ISPU or Dfill.',
  splitDepletionMessageForSales:
    'Cannot combine multiple fulfillments in a single order, switch all lines to either ISPU or Dfill.',

};
