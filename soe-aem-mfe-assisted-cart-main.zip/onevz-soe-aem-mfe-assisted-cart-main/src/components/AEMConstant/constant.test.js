import { affirmEnableContent, affirmAccConfig } from './constant';

describe('Constant array', () => {
  const affirmEnableContentarray = Object.keys(affirmEnableContent);
  const affirmAccConfigarray = Object.keys(affirmAccConfig);
  test('check length of array', () => {
    expect(affirmEnableContentarray.length).toBe(3);
  });
  test('check length of array', () => {
    expect(affirmAccConfigarray.length).toBe(4);
  });
});
