/* eslint-disable no-unneeded-ternary */
import styled from 'styled-components';
import { Line } from '@vds/lines';
import { Body } from '@vds/typography';
import { TextLink, Button } from '@vds/buttons';
import { Checkbox } from '@vds/checkboxes';
import { Icon } from '@vds/icons';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { formatCurrency, getUIContextPath } from 'onevzsoemfecommon/Helpers';
import _ from 'lodash';
import moment from 'moment/moment';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { getQueryParamByName, isAsurion } from 'onevzsoemfeframework/DomService';
import { GetAppConfig } from 'onevzsoemfeframework/GetAppConfig';
import { affirmEnableContent, affirmAccConfig } from '../AEMConstant/constant';
import ShoppingBag from './ShoppingBag';
import RemindRepNotification from './ShoppingBag/RemindRepNotification';
import Affirm from './Affirm/Affirm';
import { useCradleState } from '../../utils/common';

const PaddingRight16 = styled.div`
  padding-right: 1rem;
`;
const PaddingTop16 = styled.div`
  padding-top: 1rem;
`;
const PaddingAll = styled.div`
  padding: 2rem;
`;
const StyledTextRight = styled.div`
  text-align: right;
`;
const FlexJustify = styled.div`
  display: flex;
  justify-content: space-between;
`;
const FlexBox = styled.div`
  display: flex;
`;
const PaddingTop24 = styled.div`
  padding-top: 1.5rem;
`;
const StyledPaddingBot32 = styled.div`
  padding-bottom: 2rem;
`;
const FooterContainer = styled.div`
  position: fixed;
  bottom: 0px;
  width: 100%;
  z-index: 1;
  max-width: 1133px;
  p,
  span,
  div {
    font-family: Verizon-NHG-eDS, Helvetica, Arial, Sans-serif !important;
  }
`;
const FooterWrapper = styled.div`
  padding: 1.25rem 2.5rem;
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  background-color: rgb(255, 255, 255);
  background-color: #ffffff;
  border-top: 1px solid rgb(0, 0, 0);
  box-sizing: border-box;
  cursor: pointer;
`;
const DueWrapper = styled.div`
  display: flex;
  width: 100%;
  align-items: center;
`;
const Margin = styled.div`
  margin: 1rem 0rem 1rem 0rem;
`;
const FinanceBottomBox = styled.div`
  border-top: 1px solid rgb(0, 0, 0);
  box-sizing: border-box;
  background: rgb(246, 246, 246);
  button.reviewOrder {
    margin-right: 20px;
  }
`;
const Wrapper = styled.div`
  width: 100%;
  height: 100%;
  position: fixed;
  z-index: 1;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  max-width: 1133px;
`;
const FlexGrid = styled.div`
  display: flex;
  gap: 2.5rem;
`;
const FlexRowGap = styled.div`
  display: flex;
  flex-direction: row;
  gap: 1rem;
`;
const FlexRowJustify = styled.div`
  display: flex;
  justify-content: ${({ spacing }) => (spacing ? 'space-between' : 'flex-end')};
`;
const FlexGrowOne = styled.div`
  flex-grow: 1;
`;
const FlexVerital = styled.div`
  display: flex;
  flex-direction: column;
`;
const ShoppingBagWrapper = styled.div`
  display: flex;
  gap: 1rem;
  padding-top: 0.5rem;
  align-items: flex-end;
`;
function ExpandFooter(props) {
  // const [remindRepAboutSB, setremindRepAboutSB] = useState(false);
  // const promoBundleFlow = false; // useSelector(getPromoBundleFlow())
  const appConfig = GetAppConfig();
  const { messages } = appConfig || {};
  console.log('affirm aem ', messages);
  const navigate = useNavigate();
  const { affirmChecked, setAffirmChecked } = props;
  // const [affirmChecked, setAffirmChecked] = useState(false); // useSelector(selectAffirmChecked())
  const affirmFinancingEnabled = true; // useSelector(selectAffirmFinancingEnabled())
  const [isAffirmLaunchEnabled] = getAssistedCradlePropertyV2(['isAffirmLaunchEnabled']);

  const isCustomerAffirmEligible = props.landing?.cartDetails?.orderDetails?.affirmFinancingOfferInfo?.offerAvailable;
  const [accessoryVvcChecked, setAccessoryVvcChecked] = useState(false);
  const isCustomerAfoEligible = props.landing?.cartDetails?.orderDetails?.accessoryFinancingOfferInfo?.customerEligible;
  const enableAfoForCustomer = false; // useSelector(enableAfoForCustomerfn())
  const afoVzccApplicationStatus =
    props.landing?.cartDetails?.orderDetails?.nbxInfo?.vzccApplicationStatus?.toString().toLowerCase() || '';

  const showIsaacLink = props?.landing?.directApply?.issacPromo?.proposition?.isDirectApply;
  const showIsaacRewardsLink = props?.landing?.directApply?.issacPromo?.proposition?.rewardsEnrolled;

  // modify landing reducer state - affirmCheck which is used in OrderReview page
  // defining action
  const affirmCheckAction = (payload) => ({
    type: 'AFFIRM_CHECKED',
    payload,
  });

  const enableAffirm = (e) => {
    setAffirmChecked(e.target.checked);
    window?.store?.dispatch(affirmCheckAction(e.target.checked));
  };

  const cradleState = useCradleState();
  const nbsFFlagState = cradleState?.data?.enablePartialNbsPosFFlag === 'TRUE';
  const channel = sessionStorage.getItem('channel');
  const appPropertiesFromSessionStorage = sessionStorage.getItem('APP_PROPERTIES');
  const nbsFFlagSessionStorage = appPropertiesFromSessionStorage
    ? JSON.parse(appPropertiesFromSessionStorage)?.enablePartialNbsPosFFlag === 'TRUE'
    : false;
  const enablePartialNbsPosFFlag = nbsFFlagState || nbsFFlagSessionStorage;
  const checkChannelRetail = channel?.indexOf('OMNI-RETAIL') > -1;

  const bagFeeCradleEnabled = props?.assistedFlag?.isBagFeeEnabled;
  const largeBagLocation = props?.assistedFlag?.disableLargeBagFee;
  // Due Monthly
  const grandTotalDueMonthlyAllSubAcc = props?.landing?.subAccounts?.map(
    (rec) => rec.totals?.grandTotalDueMonthly.estimatedTotal,
  );
  const grandTotalDueMonthly = grandTotalDueMonthlyAllSubAcc?.reduce((temp, sum) => temp + sum, 0);
  const grandTotals = props?.accountDetails?.grandTotals;
  let dueMonthly;
  const activeSubAccountId = sessionStorage.getItem('selectedSubAccountId');
  const subAccountInfo = props?.FetchPricingSnapShotResult?.data?.data?.subAccounts?.filter(
    (rec) => rec.subAccountId === activeSubAccountId,
  );
  if (props?.landing?.cartDetails?.orderDetails.subAccountInfo?.length > 0 && subAccountInfo?.length > 0) {
    dueMonthly = subAccountInfo?.length > 0 && subAccountInfo[0]?.totals?.grandTotalDueMonthly?.estimatedTotal;
  } else {
    dueMonthly = grandTotalDueMonthly || grandTotals?.grandTotalDueMonthly?.estimatedTotal;
  }

  const monthlyTotal = grandTotals?.monthlyTotal?.regularPrice;
  const addonsTotal = grandTotals?.addonsTotal?.regularPrice;
  const surCharges = grandTotals?.surcharges?.regularPrice;
  const taxes = grandTotals?.taxesAndFees?.regularPrice;
  const devicesTotal = grandTotals?.devicesTotal?.regularPrice;
  const plansTotal = grandTotals?.plansTotal?.regularPrice;

  // Estimated next bill
  const cartNBSNextBillTotals = props?.accountDetails?.cartNBSNextBillTotals;
  const nextBillGrandTotal = cartNBSNextBillTotals?.grandTotal || 0.0;
  const totalOneTimeCharge = cartNBSNextBillTotals?.totalOneTimeCharge || 0.0;
  const subTotalWithoutAddons = cartNBSNextBillTotals?.subTotalWithoutAddons || 0.0;
  const totalAddOnsSummary = cartNBSNextBillTotals?.totalAddOnsSummary || 0.0;
  const nextBillSurcharges = cartNBSNextBillTotals?.surcharges || 0.0;
  const taxesAndFees = cartNBSNextBillTotals?.taxesAndFees || 0.0;
  const nextBillDevicesTotal = cartNBSNextBillTotals?.devicesTotal || 0.0;
  const nextBillPlansTotal = cartNBSNextBillTotals?.plansTotal || 0.0;

  // Discounts requiring action
  const pceDetail = props?.landing?.subAccounts?.[0]?.shared?.pendingChargesAndDiscounts
    ? props?.landing?.subAccounts[0]?.shared?.pendingChargesAndDiscounts
    : '';
  const disPenDetail = pceDetail?.discountsPendingActionDetails ? pceDetail?.discountsPendingActionDetails : '';
  const apoPaperlessAmount = disPenDetail?.apoPaperlessAmount ? disPenDetail?.apoPaperlessAmount : '';
  const totalPendingDiscount = disPenDetail?.totalPendingDiscount ? disPenDetail?.totalPendingDiscount : '';
  const newMonthlyTotalWithPendingDiscounts = disPenDetail?.newMonthlyTotalWithPendingDiscounts
    ? disPenDetail?.newMonthlyTotalWithPendingDiscounts
    : '';

  // orderEffective
  const isOrderEffectiveDateEnabled =
    props?.landing?.accountDetails?.sharedAttributes?.flags?.isEffectiveDateEligible || false;
  const OrderEffAlignment = !!(apoPaperlessAmount || totalPendingDiscount || newMonthlyTotalWithPendingDiscounts);
  let orderEffectiveDateValue = '';
  if (props?.landing?.accountDetails?.sharedAttributes?.flags?.isEffectiveDateEligible) {
    const currentDate = moment(new Date()).format('MM/DD/YYYY');
    // if (promoBundleFlow) {
    //   if (currentDate === props?.landing?.cartDetails?.orderDetails?.effectiveDateDetails?.selectedDate) {
    //     orderEffectiveDateValue = 'Today';
    //   } else {
    //     orderEffectiveDateValue = props?.landing?.cartDetails?.orderDetails?.effectiveDateDetails?.selectedDate
    //       ? props?.landing?.cartDetails?.orderDetails?.effectiveDateDetails?.selectedDate
    //       : '';
    //   }
    // } else
    if (currentDate === props?.landing?.accountDetails?.sharedAttributes?.flags?.selectedEffectiveDate) {
      orderEffectiveDateValue = 'Today';
    } else {
      orderEffectiveDateValue = props?.landing?.accountDetails?.sharedAttributes?.flags?.selectedEffectiveDate
        ? props?.landing?.accountDetails?.sharedAttributes?.flags?.selectedEffectiveDate
        : '';
    }
  }

  let bagTax = false;
  let bagFeeSku;
  if (props?.landing?.cartDetails?.lineDetails) {
    bagTax = props?.landing?.cartDetails?.lineDetails?.bagTax;
    if (bagTax) {
      bagFeeSku = props?.landing?.cartDetails?.lineDetails?.bagFeeSku;
    }
  }
  // navigate to orderEffective page
  const goToOrderEffectiveDate = () => {
    navigate(`${getUIContextPath()}/ordereffectivedate.html`);
  };

  const enableaccessoryVvc = (e) => {
    // const payload = { path: 'home', accessoryVvcChecked: e.target.checked };
    // dispatch(landingActions.renderAccessoryVVCLanding(payload))
    setAccessoryVvcChecked(e.target.checked);
  };

  const accessoryVVC = () => (
    <div className='paddingAccessoryVVc' style={affirmChecked ? { pointerEvents: 'none', opacity: 0.7 } : {}}>
      <Checkbox
        data-track={`afo_VVCard:${accessoryVvcChecked ? 'unchecked' : 'checked'}`}
        type='checkbox'
        name='accessoryVVC'
        label={props?.vvcEnableContent?.headerLabel}
        selected={accessoryVvcChecked}
        onChange={(e) => enableaccessoryVvc(e)}
      />
      <div>
        {props?.vvcEnableContent?.vvcContent}
        <span
          className='seeDetailsLabelStyle'
          data-testid='accessoryVvc'
          role='presentation'
          onClick={() => props?.showAccessoryVvcModal && props?.showAccessoryVvcModal(false, 'BLUE-BANNER')}
        >
          {' '}
          {props?.vvcEnableContent?.seeDetailsLabel}
        </span>
      </div>
    </div>
  );
  const isD2D = () =>
    getQueryParamByName('isDoorToDoorFlow') === 'true' ||
    sessionStorage.getItem('channel')?.indexOf('OMNI-D2D') > -1 ||
    false;

  const montanaOfferEnableFFlag = /true/i.test(
    JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.montanaOfferEnableFFlag,
  );
  const fullFpsResponse = props?.FetchPricingSnapShotResult?.data?.data;
  const estimatedTotal = props?.landing?.subAccounts?.[0]?.totals?.grandTotalDueMonthly?.estimatedTotal ?? '';
  const checkEcpdDiscount = (response, isMontanaOfferEnabled) => {
    if (!isMontanaOfferEnabled || !response) {
      return false;
    }

    const { isAiBillUpload, ecpdType, ecpdDiscount } = response;

    const isRecognizedAsAiBill = isAiBillUpload?.toUpperCase() === 'Y';
    const hasValidEcpdType = !!ecpdType;
    const hasEcpdDiscountValue = !!ecpdDiscount;

    return isRecognizedAsAiBill && hasValidEcpdType && hasEcpdDiscountValue;
  };
  const isEcpdDiscount = checkEcpdDiscount(fullFpsResponse, montanaOfferEnableFFlag);
  const isAiBillUploadfn = () => montanaOfferEnableFFlag && fullFpsResponse?.isAiBillUpload?.toUpperCase() === 'Y' 
  const isAutoPayEnabledfn = () => montanaOfferEnableFFlag && fullFpsResponse?.isAutoPayEnabled 
 
  const isAiBillUpload = isAiBillUploadfn();
  const isAutoPayEnabled = isAutoPayEnabledfn();
  const colorReturn = () => isAutoPayEnabled ? 'green' : '';
   const colorReturnisAiBillUpload = () => isAiBillUpload ? 'green' : '';
   const getFormattedBillTotal = () => { 
    const amountToFormat = isAutoPayEnabled 
        ? estimatedTotal 
        : newMonthlyTotalWithPendingDiscounts;
    return amountToFormat;
};
const nextbillTotal = () => isAutoPayEnabled ? estimatedTotal : nextBillGrandTotal ;
  console.log('landing prop', props);
  return (
    <Wrapper>
      <FooterContainer>
        <FooterWrapper data-testid='expandFooter'>
          <FlexGrowOne>
            <FlexGrid>
              <FlexRowGap>
                <div>
                  <Body size='large'>
                    <b>{props?.itemsInCart}</b> Items
                  </Body>
                  <Body size='large'>
                    <b>{props?.tradeInCount}</b> Trade-in
                  </Body>
                </div>
              </FlexRowGap>
              <FlexRowGap>
                <FlexVerital>
                  <FlexBox>
                    <FlexRowGap>
                      <Body primitive='span' size='large' bold>
                        Due today
                      </Body>
                      <PaddingTop16 />
                      <div>
                        <Body primitive='span' size='large' bold>
                          {props?.dueToday?.includes('$') ? props?.dueToday : formatCurrency(props?.dueToday)}
                        </Body>
                      </div>
                    </FlexRowGap>
                  </FlexBox>

                  <FlexBox>
                    {bagTax && (
                      <ShoppingBagWrapper>
                        {sessionStorage.getItem('channel').includes('OMNI-RETAIL') &&
                          bagFeeCradleEnabled === 'TRUE' &&
                          largeBagLocation === 'FALSE' && (
                            <ShoppingBag
                              setBagQty={props?.setBagQty}
                              bagTax={bagTax}
                              bagFeeSku={bagFeeSku}
                              proceedtoNext={props?.shoppingBagNotRequiredAction}
                              setOnDefaultBagSelected={props?.setOnDefaultBagSelected}
                              remindRep={props.toggleRemindRepAboutSB}
                              turnOffExistingSBReminder={props.turnOffExistingSBReminder}
                              fromFlexLanding
                            />
                          )}
                        {sessionStorage.getItem('channel').includes('OMNI-RETAIL') &&
                          bagFeeCradleEnabled === 'TRUE' &&
                          largeBagLocation === 'FALSE' &&
                          props?.remindRepAboutSB && (
                            <RemindRepNotification onCloseButtonClick={props.toggleRemindRepAboutSB} />
                          )}
                      </ShoppingBagWrapper>
                    )}
                  </FlexBox>

                  {/* <FlexBox>
                    <ShoppingBagWrapper>
                      <ShoppingBag fromFlexLanding />
                      {remindRepAboutSB && (
                        <RemindRepNotification onCloseButtonClick={() => setremindRepAboutSB(!remindRepAboutSB)} />
                      )}
                    </ShoppingBagWrapper>
                  </FlexBox> */}
                </FlexVerital>
              </FlexRowGap>

              {props?.itemsInCart > 0 && (
                <FlexRowGap>
                  <div>
                    <Body primitive='span' size='large' bold>
                      {enablePartialNbsPosFFlag ? 'Est. ongoing monthly' : 'Est. new monthly'}
                    </Body>
                    <PaddingTop16 />
                    <Body size='medium'>{enablePartialNbsPosFFlag ? 'Plans' : 'Monthly charges and credits'}</Body>
                    <Body size='medium'>{enablePartialNbsPosFFlag ? 'Device' : ''}</Body>
                    <Body size='medium'>{enablePartialNbsPosFFlag ? 'Services and perks' : 'Add-ons'}</Body>
                    <Body size='medium'>Surcharges</Body>
                    <Body size='medium'>Taxes & govt. fee</Body>
                  </div>
                  <div>
                    <Body primitive='span' size='large' bold>
                      {formatCurrency(dueMonthly)}
                    </Body>
                    <PaddingTop16 />
                    <StyledTextRight>
                      {!enablePartialNbsPosFFlag && <Body size='medium'>{formatCurrency(monthlyTotal)}</Body>}
                      <Body size='medium'>{enablePartialNbsPosFFlag ? formatCurrency(plansTotal) : ''}</Body>
                      <Body size='medium'> {enablePartialNbsPosFFlag ? formatCurrency(devicesTotal) : ''}</Body>
                      <Body size='medium'>{formatCurrency(addonsTotal)}</Body>
                      <Body size='medium'>{formatCurrency(surCharges)}</Body>
                      <Body size='medium'>{formatCurrency(taxes)}</Body>
                    </StyledTextRight>
                  </div>
                </FlexRowGap>
              )}

              {/* <FlexRowGap>
                <div>
                  <Body primitive='span' size='large' bold>
                    Est. new monthly
                  </Body>
                  <PaddingTop16 />
                  <Body size='medium'>Monthly charges and credits</Body>
                  <Body size='medium'>Add-ons</Body>
                  <Body size='medium'>Surcharges</Body>
                  <Body size='medium'>Taxes & govt. fee</Body>
                </div>
                <div>
                  <Body primitive='span' size='large' bold>
                    ${10}
                  </Body>
                  <PaddingTop16 />
                  <StyledTextRight>
                    <Body size='medium'>${20}</Body>
                    <Body size='medium'>${30}</Body>
                    <Body size='medium'>${40}</Body>
                    <Body size='medium'>${50}</Body>
                  </StyledTextRight>
                </div>
              </FlexRowGap> */}

              {props.customerType !== 'N' &&
              !props?.isprepaycart &&
              nextBillGrandTotal &&
              Number(nextBillGrandTotal) > 0 &&
              props?.itemsInCart > 0 ? (
                <FlexRowGap>
                  <div>
                    <Body primitive='span' size='large' bold>
                      Est. next bill
                    </Body>
                    <PaddingTop16 />
                    <Body size='medium'>One-time charges and credits</Body>
                    <Body size='medium'>{enablePartialNbsPosFFlag ? 'Plans' : 'Monthly charges and credits'}</Body>
                    <Body size='medium'>{enablePartialNbsPosFFlag ? 'Device' : ''}</Body>
                    <Body size='medium'>{enablePartialNbsPosFFlag ? 'Services and perks' : 'Add-ons'}</Body>
                    <Body size='medium'>Surcharges</Body>
                    <Body size='medium'>Taxes & govt. fee</Body>
                  </div>
                  <div>
                    <Body primitive='span' size='large' bold>
                      {formatCurrency(nextbillTotal())}
                    </Body>
                    <PaddingTop16 />
                    <StyledTextRight>
                      <Body size='medium'>{formatCurrency(totalOneTimeCharge)}</Body>
                      <Body size='medium'>
                        {enablePartialNbsPosFFlag
                          ? formatCurrency(nextBillPlansTotal)
                          : formatCurrency(subTotalWithoutAddons)}
                      </Body>
                      <Body size='medium'>{enablePartialNbsPosFFlag ? formatCurrency(nextBillDevicesTotal) : ''}</Body>
                      <Body size='medium'>{formatCurrency(totalAddOnsSummary)}</Body>
                      <Body size='medium'>{formatCurrency(nextBillSurcharges)}</Body>
                      <Body size='medium'>{formatCurrency(taxesAndFees)}</Body>
                    </StyledTextRight>
                  </div>
                </FlexRowGap>
              ) : null}
              {/* <FlexRowGap>
                <div>
                  <Body primitive='span' size='large' bold>
                    Est. next bill
                  </Body>
                  <PaddingTop16 />
                  <Body size='medium'>One-time charges and credits</Body>
                  <Body size='medium'>Monthly charges and credits</Body>
                  <Body size='medium'>Add-ons</Body>
                  <Body size='medium'>Surcharges</Body>
                  <Body size='medium'>Taxes & govt. fee</Body>
                </div>
                <div>
                  <Body primitive='span' size='large' bold>
                    ${10}
                  </Body>
                  <PaddingTop16 />
                  <StyledTextRight>
                    <Body size='medium'>${20}</Body>
                    <Body size='medium'>${20}</Body>
                    <Body size='medium'>${20}</Body>
                    <Body size='medium'>${20}</Body>
                    <Body size='medium'>${20}</Body>
                  </StyledTextRight>
                </div>
              </FlexRowGap> */}
            </FlexGrid>
            <Margin>
              <Body size='small' color='#6F7171'>
                *Pending promotions not included
              </Body>
            </Margin>
            <Margin>
              <Line type='secondary' />
            </Margin>
            <FlexRowJustify spacing={OrderEffAlignment}>
              {!props?.isprepaycart &&
                !_.isEmpty(pceDetail) &&
                (apoPaperlessAmount || totalPendingDiscount || newMonthlyTotalWithPendingDiscounts) && (
                  <FlexJustify>
                    <PaddingRight16>
                      <Body primitive='span' size='large' bold>
                        Discounts requiring action
                      </Body>
                      <PaddingTop16 />
                      <Body size='medium'>APO/Paperless discount</Body>
                      {isEcpdDiscount && <Body size='medium'>ECPD discount ({fullFpsResponse?.ecpdType})</Body>}
                      {!isAiBillUpload && (
                        <div>
                          <Body primitive="span" size="medium" bold>
                            Total
                          </Body>
                        </div>
                      )}
                      <div>
                        <Body primitive='span' size='medium' bold>
                          {enablePartialNbsPosFFlag
                            ? 'Est. ongoing monthly if discounts are applied'
                            : 'Est. new monthly if discounts are applied'}
                        </Body>
                      </div>
                    </PaddingRight16>
                    <PaddingRight16>
                      <PaddingTop16 />
                      <StyledTextRight>
                        <PaddingTop24 />
                        <div>
                          <Body size='medium' color={colorReturn()}>{formatCurrency(apoPaperlessAmount)}</Body>
                        </div>
                        {isEcpdDiscount && (
                          <div>
                            <Body size='medium' color="green">-{formatCurrency(fullFpsResponse?.ecpdDiscount)}</Body>
                          </div>
                        )}
                        {!isAiBillUpload && (
                        <div>
                          <Body primitive='span' size='medium' bold>
                            {formatCurrency(totalPendingDiscount)}
                          </Body>
                        </div>
                        )}
                        <div>
                          <Body primitive='span' size='medium' color={colorReturnisAiBillUpload()} bold>
                            {formatCurrency(getFormattedBillTotal())}
                          </Body>
                        </div>
                      </StyledTextRight>
                    </PaddingRight16>
                  </FlexJustify>
                )}

              {/* <FlexJustify>
                <PaddingRight16>
                  <Body primitive='span' size='large' bold>
                    Discounts requiring action
                  </Body>
                  <PaddingTop16 />
                  <Body size='medium'>APO/Paperless discount</Body>
                  <div>
                    <Body primitive='span' size='medium' bold>
                      Total
                    </Body>
                  </div>
                  <div>
                    <Body primitive='span' size='medium' bold>
                      Est. new monthly if discounts are applied
                    </Body>
                  </div>
                </PaddingRight16>
                <PaddingRight16>
                  <PaddingTop16 />
                  <StyledTextRight>
                    <PaddingTop24 />
                    <div>
                      <Body size='medium'>${20}</Body>
                    </div>
                    <div>
                      <Body primitive='span' size='medium' bold>
                        ${20}
                      </Body>
                    </div>
                    <div>
                      <Body primitive='span' size='medium' bold>
                        ${20}
                      </Body>
                    </div>
                  </StyledTextRight>
                </PaddingRight16>
              </FlexJustify> */}

              {isOrderEffectiveDateEnabled && (
                <div>
                  <Body size='medium'>
                    Order effective date is set to <b>{orderEffectiveDateValue}</b>
                    <TextLink
                      type='standAlone'
                      size='small'
                      data-track='order-landing_Change'
                      onClick={() => goToOrderEffectiveDate()}
                    >
                      {' '}
                      Change
                    </TextLink>
                  </Body>
                </div>
              )}

              {/* <div>
                <Body size='medium'>
                  Order effective date is set to <b>orderEffectiveDateValue</b>
                  <TextLink
                    type='standAlone'
                    size='small'
                    data-track='order-landing_Change'
                    // onClick={() => goToOrderEffectiveDate()}
                  >
                    {' '}
                    Change
                  </TextLink>
                </Body>
              </div> */}
            </FlexRowJustify>
          </FlexGrowOne>
          <div>
            <DueWrapper onClick={props.hideFooter}>
              <Icon name='down-caret' size='XLarge' />
            </DueWrapper>
          </div>
        </FooterWrapper>
        <FinanceBottomBox>
          <PaddingAll>
            <StyledPaddingBot32>
              {!props.isprepaycart &&
                affirmFinancingEnabled &&
                checkChannelRetail &&
                isCustomerAffirmEligible &&
                isAffirmLaunchEnabled === 'TRUE' &&
                !isD2D() &&
                !isAsurion() && (
                  <div style={accessoryVvcChecked ? { pointerEvents: 'none', opacity: 0.7 } : {}}>
                    <Checkbox
                      name='default'
                      width='auto'
                      label={affirmEnableContent?.affrimHeaderLabel}
                      disabled={false}
                      error={false}
                      errorText='Please agree to the terms and conditions.'
                      selected={affirmChecked}
                      onChange={(e) => enableAffirm(e)}
                    />
                    {affirmEnableContent?.affrimContent} {'  '}
                    <Affirm
                      isLandingPage
                      affirmConfirmationButton={affirmEnableContent?.affrimSeeDetailsLabel}
                      affirmConfig={affirmAccConfig}
                    />
                  </div>
                )}
              {((isCustomerAfoEligible && enableAfoForCustomer && !showIsaacLink && showIsaacRewardsLink) ||
                (afoVzccApplicationStatus === 'application_approved' &&
                  isCustomerAfoEligible &&
                  enableAfoForCustomer)) &&
                accessoryVVC()}
            </StyledPaddingBot32>
            <FlexBox>
              {props?.customerInfo?.channel !== 'OMNI-CARE' && props?.isExpressCheckout && (
                <Button
                  className='reviewOrder'
                  size='large'
                  surface='light'
                  data-track='order-landing_Express checkout'
                  disabled={false}
                  primary
                  onClick={({ isexpressCheckoutPath = true }) =>
                    props?.onProceedToOrderClick(props?.pastDuevalue, props?.isExpressCheckout, isexpressCheckoutPath)
                  }
                >
                  Express checkout
                </Button>
              )}

              {/* <Button
                className='reviewOrder'
                size='large'
                surface='light'
                data-track='order-landing_Express checkout'
                disabled={false}
                primary
                // onClick={({ isexpressCheckoutPath = true }) => props?.showShoppingBagModalFn(false) && props?.getAcknowledge() && props?.getPauseResumeStandaloneCheck() && props?.onProceedToOrderClick(props?.pastDuevalue, props?.isExpressCheckout, isexpressCheckoutPath)}
              >
                Express checkout
              </Button> */}

              <Button
                type='primary'
                size='large'
                width='auto'
                surface='light'
                className='reviewOrder'
                disabled={
                  (props?.customerInfo?.channel?.includes('OMNI-INDIRECT') &&
                    props?.itemsInCart === 0 &&
                    props?.tradeInCount === 0) ||
                  props?.isExpressCheckoutDisabled ||
                  props?.isProceedToOrderDisabled ||
                  props?.landing?.enableLandingButtons ||
                  props?.landing?.fetchPricingOnLoad
                }
                data-testid='ReviewOrder'
                data-track='order-landing_Review order'
                onClick={({ isProceedToOrderPath = true }) =>
                  // props?.showShoppingBagModalFn(false) &&
                  // props?.getAcknowledge() &&
                  // props?.getPauseResumeStandaloneCheck() &&
                  props?.onProceedToOrderClick(isProceedToOrderPath)
                }
              >
                Review order
              </Button>
              {/* <Button
                type='primary'
                size='large'
                width='auto'
                surface='light'
                className='reviewOrder'
                // disabled={(props?.customerInfo?.channel?.includes("OMNI-INDIRECT") && props?.itemsInCart == 0 && props?.tradeInCount == 0) || props?.isExpressCheckoutDisabled|| props?.isProceedToOrderDisabled || (props?.landing?.enableLandingButtons) || props?.landing?.fetchPricingOnLoad}
                data-testid='ReviewOrder'
                data-track='order-landing_Review order'
                // onClick={ ({isProceedToOrderPath = true }) =>
                // props?.showShoppingBagModalFn(false) &&
                // props?.getAcknowledge() &&
                // props?.getPauseResumeStandaloneCheck() &&
                // props?.onProceedToOrderClick(props?.pastDuevalue,props?.isExpressCheckout,false,isProceedToOrderPath)
                // }
              >
                Review order
              </Button> */}

              {!props?.isRfexFlow && !props?.isprepaycart && !props?.isTysFlow && (
                <Button
                  size='large'
                  use='secondary'
                  width='auto'
                  Margin-left='20px'
                  data-track='order-landing_Apply-Offers'
                  disabled={props?.itemsInCart === 0}
                  onClick={() => props?.onapplyOffersClick()}
                >
                  Apply offers
                </Button>
              )}
              {/* <Button
                size='large'
                use='secondary'
                width='auto'
                Margin-left='20px'
                data-track='order-landing_Apply-Offers'
                // disabled={props?.itemsInCart == 0}
                // onClick={() => props?.onapplyOffersClick()}
              >
                Apply offers
              </Button> */}
            </FlexBox>
          </PaddingAll>
        </FinanceBottomBox>
      </FooterContainer>
    </Wrapper>
  );
}
export default ExpandFooter;
