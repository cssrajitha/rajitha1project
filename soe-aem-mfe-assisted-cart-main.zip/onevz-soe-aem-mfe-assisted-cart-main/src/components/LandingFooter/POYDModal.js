import React from 'react';
import { Modal, ModalBody, ModalFooter, ModalTitle } from '@vds/modals';
import { Button } from '@vds/buttons';
import styled from 'styled-components';

const ModalWrapper = styled.div`
  height: 16rem;
`;

const Footer = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: flex-start;
  gap: 1rem;
`;

export function PYODModal(props) {
  const { proceedClick, onGoBack, profileText } = props;
  return (
    <Modal
      id='pyod-confirmation-modal'
      surface='light'
      fullScreenDialog={false}
      disableOutsideClick
      disableAnimation={false}
      width='40rem'
      ariaLabel='PYOD Confirmation Modal'
      opened
      closeButton={<div />}
      onOpenedChange={() => {}}
    >
      <ModalWrapper>
        <ModalTitle data-testid='poyd-title'>Proceed without POYD Offer?</ModalTitle>
        <ModalBody>
          {`The customer's previous carrier bill has not been uploaded yet for ${profileText}. You can go back and upload the bill to receive the POYD offer benefits. Proceeding without uploading the bill will remove the offer from the order.`}
        </ModalBody>
        <ModalFooter>
          <Footer>
            <Button
              type='button'
              name='Proceed without offer'
              data-track='proceed-without-offer'
              data-testid='proceed-without-offer'
              use='primary'
              onClick={() => proceedClick()}
            >
              Proceed without offer
            </Button>
            <Button
              type='button'
              name='Go back'
              use='secondary'
              data-testid='go-back'
              data-track='go-back'
              onClick={() => onGoBack()}
            >
              Go back
            </Button>
          </Footer>
        </ModalFooter>
      </ModalWrapper>
    </Modal>
  );
}
