import React from 'react';
import { cleanup } from '@testing-library/react';
import { setupChannel, CHANNELS } from '../../../utils/test-utils/utils';
import { render, screen } from '../../../utils/test-utils/renderHelper';
import { affrimjson } from './__mocks__/affirmjson';
import Affirm from './Affirm';

const Test = (channel) => {
  setupChannel(channel);
  afterEach(cleanup);
  describe('AffirmComponent component unit testing', () => {
    beforeAll(() => {
      sessionStorage.setItem('isProd', 'true');
    });
    afterAll(() => {
      sessionStorage.setItem('isProd', '');
    });
    beforeEach(() => {
      const script = document.createElement('script');
      document.body.appendChild(script);
      render(<Affirm {...affrimjson} />);
    });
    test('mounting learn how text', () => {
      setTimeout(() => {
        const inputElement = screen.getByTestId('learn-how');
        expect(inputElement).toBeInTheDocument();
      }, 2000);
    });
    // test('should display Line details', () => {
    //   setTimeout(() => {
    //     expect(affirmContent.financeWith).toBe('FinancingWith');
    //     expect(affirmContent.learnHow).toBe('Learn How');
    //   }, 2000);
    // });
  });

  describe('AffirmComponent component unit testing', () => {
    beforeEach(() => {
      const script = document.createElement('script');
      document.body.appendChild(script);
      render(<Affirm isLandingPage withDynamicPricingTxt {...affrimjson} />);
    });
    test('mounting learn how text', () => {
      setTimeout(() => {
        const inputElement = screen.getByTestId('learn-how');
        expect(inputElement).toBeInTheDocument();
      }, 2000);
    });
  });
  describe('AffirmComponent component unit testing', () => {
    beforeEach(() => {
      const script = document.createElement('script');
      document.body.appendChild(script);
      render(<Affirm isLandingPage {...affrimjson} />);
    });
    test('mounting learn how text', () => {
      setTimeout(() => {
        const inputElement = screen.getByTestId('learn-how');
        expect(inputElement).toBeInTheDocument();
      }, 2000);
    });
  });
};

Test(CHANNELS.OMNI_TELESALES);
Test(CHANNELS.OMNI_RETAIL);
Test(CHANNELS.OMNI_D2D);
