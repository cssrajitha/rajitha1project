export const affrimjson = {
  affirmContent: {
    financeWith: 'FinancingWith',
    learnHow: 'Learn How',
  },
  affirmConfig: {
    devPublicKey: 'JA9VX7XQIXIR9H2O',
    prodPublicKey: 'JA9VX7XQIXIR9H2O',
    devScript: 'https://cdn1-sandbox.affirm.com/js/v2/affirm.js',
    prodScript: 'https://cdn1.affirm.com',
  },
  isCashOptionEnabledForXbox: true,
  firstMonthPrice: 24.99,
};
