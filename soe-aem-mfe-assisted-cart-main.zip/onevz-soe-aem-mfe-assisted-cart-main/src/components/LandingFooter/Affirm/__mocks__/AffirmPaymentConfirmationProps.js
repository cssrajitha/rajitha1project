export const AffirmPaymentConfirmationProps = {
  affirmConfirmationContent: {
    affirmConfirmationContentTitle: 'FinancingWith',
    payxbox: 'Learn How',
    withAffirm: 'FinancingWith',
    // affirmConfirmationButtonLabel: "Learn How"
  },
  affirmConfig: {
    devPublicKey: 'JA9VX7XQIXIR9H2O',
    prodPublicKey: 'JA9VX7XQIXIR9H2O',
    devScript: 'https://cdn1-sandbox.affirm.com/js/v2/affirm.js',
    prodScript: 'https://cdn1.affirm.com',
  },
  isAffirmPaymentSelected: true,
  isCashPaymentEligible: false,
};
