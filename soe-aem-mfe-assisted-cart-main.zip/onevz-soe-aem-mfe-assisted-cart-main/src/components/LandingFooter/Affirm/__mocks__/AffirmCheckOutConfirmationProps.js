export const AffirmCheckOutConfirmationProps = {
  isAffirmPaymentSucess: true,
  handleAffirmContinueButton: jest.fn(),
};
