import React, { useEffect } from 'react';
import { TextLink } from '@vds/buttons';
import styled from 'styled-components';
import './affirmnew.css';

const FinanceWrapper = styled.div`
  background-color: #f6f6f6;
  padding: 6px;
`;
const LearnhowWrapper = styled.span`
  padding: 0px;
  color: black;
  font-weight: bold;
`;
const FinanceMargin = styled.div`
  bottom: 16px;
  display: flex;
`;
const AffirmHeaderDiv = styled.div`
  display: flex;
`;
const MonthPriceDiv = styled.div`
  font-weight: bold;
  margin-right: 5px;
`;

function Affirm({
  originalPrice,
  affirmContent,
  isLandingPage,
  affirmConfirmationButton,
  affirmConfig,
  isCashOptionEnabledForXbox,
  firstMonthPrice,
  withDynamicPricingTxt,
}) {
  const isProd = sessionStorage.getItem('isProd');
  let public_api_key = '';
  let script = '';
  if (isProd === 'true') {
    public_api_key = affirmConfig?.prodPublicKey;
    script = affirmConfig?.prodScript;
  } else {
    public_api_key = affirmConfig?.devPublicKey;
    script = affirmConfig?.devScript;
  }
  useEffect(() => {
    /* eslint-disable */
    const affirm_config = {
      public_api_key: public_api_key, // Affirm public api key
      script: script,
    };
    (function (l, g, m, e, a, f, b) {
      let d;
      const c = l[m] || {};
      const h = document.createElement(f);
      const n = document.getElementsByTagName(f)[0];
      const k = function (a, b, c) {
        return function () {
          a[b]._.push([c, arguments]);
        };
      };
      c[e] = k(c, e, 'set');
      d = c[e];
      c[a] = {};
      c[a]._ = [];
      d._ = [];
      c[a][b] = k(c, a, b);
      a = 0;
      for (b = 'set add save post open empty reset on off trigger ready setProduct'.split(' '); a < b.length; a++)
        d[b[a]] = k(c, e, b[a]);
      a = 0;
      for (b = ['get', 'token', 'url', 'items']; a < b.length; a++) d[b[a]] = function () {};
      h.async = !0;
      h.src = g[f];
      n.parentNode.insertBefore(h, n);
      delete g[f];
      d(g);
      l[m] = c;
    })(window, affirm_config, 'affirm', 'checkout', 'ui', 'script', 'ready');
    /* eslint-disable */
    // affirmModal();
  }, []);

  return (
    <>
      {isLandingPage ? (
        withDynamicPricingTxt ? (
          <span class='dynamic-txt-with-custom-detail-link'>
            <p class='affirm-as-low-as' data-page-type='product' data-amount={originalPrice * 100}></p>
            <TextLink className='affirm-product-modal' data-amount={originalPrice * 100} data-page-type='product'>
              <LearnhowWrapper>{affirmConfirmationButton}</LearnhowWrapper>
            </TextLink>
          </span>
        ) : (
          <TextLink className='affirm-product-modal' data-amount={originalPrice * 100} data-page-type='product'>
            <LearnhowWrapper>{affirmConfirmationButton}</LearnhowWrapper>
          </TextLink>
        )
      ) : (
        <FinanceMargin data-testid='learn-how'>
          <FinanceWrapper>
            <AffirmHeaderDiv>
              {isCashOptionEnabledForXbox && <MonthPriceDiv>${firstMonthPrice}/mo</MonthPriceDiv>}
              {affirmContent.financeWith}
              <img
                src='https://ss7.vzw.com/is/image/VerizonWireless/affirm-2-color-hex-2022?scl=3'
                className='lozad'
                alt='affirm'
                style={{ height: '20px', width: '51px', marginLeft: '7px', marginRight: '12px' }}
              />
              <TextLink className='affirm-product-modal' data-amount={originalPrice * 100} data-page-type='product'>
                <LearnhowWrapper>{affirmContent.learnHow}</LearnhowWrapper>
              </TextLink>
            </AffirmHeaderDiv>
          </FinanceWrapper>
        </FinanceMargin>
      )}
    </>
  );
}

export default Affirm;
