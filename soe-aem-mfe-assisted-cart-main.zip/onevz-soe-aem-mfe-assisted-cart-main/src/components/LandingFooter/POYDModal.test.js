import React from 'react';
import { fireEvent, render, screen, waitFor } from '../../utils/test-utils/renderHelper';
import { CHANNELS, setupChannel } from '../../utils/test-utils/utils';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { PYODModal } from './POYDModal';

jest.mock('@vds/modals', () => ({
  ...jest.requireActual('@vds/modals'),
  // eslint-disable-next-line react/button-has-type, react/prop-types
  Modal: ({ children, ...props }) => (
    // eslint-disable-next-line react/prop-types
    <div {...props} data-testid={props.id}>
      {children}
    </div>
  ),
}));

const Test = (channel) => {
  setupChannel(channel);
  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });
  describe(`POYD modal - ${channel}`, () => {
    const props = {
      proceedClick: jest.fn(),
      onGoBack: jest.fn(),
      profileText: 'Some text',
    };
    render(<PYODModal {...props} />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
    it('should test POYD Proceed without offer click', async () => {
      const title = await waitFor(() => screen.findByTestId('modal-header'));
      expect(title).toBeInTheDocument();
      const proceedWithoutOfr = screen.getByTestId('proceed-without-offer');
      expect(proceedWithoutOfr).toBeInTheDocument();
      fireEvent.click(proceedWithoutOfr);
      const goback = screen.getByTestId('go-back');
      expect(goback).toBeInTheDocument();
      fireEvent.click(goback);
    });
  });
};

Test(CHANNELS.OMNI_RETAIL);
