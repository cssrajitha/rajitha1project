import React from 'react';
// import reactDom from 'react-dom';
import PropTypes from 'prop-types';
import { Notification } from '@vds/notifications';

function RemindRepNotification({ onCloseButtonClick }) {
  // const appMessageElement = document.getElementById('AppMessage');
  const warningContent = (
    <div>
      <Notification
        type='info'
        title='Please inform the customer that they will be charged for the shopping bag (s)'
        fullBleed={false}
        inline={false}
        disableFocus
        onCloseButtonClick={onCloseButtonClick}
        layout='vertical'
      />
    </div>
  );
  // if (appMessageElement) {
  //   return reactDom.createPortal(warningContent, appMessageElement);
  // }
  return warningContent;
}

RemindRepNotification.propTypes = {
  onCloseButtonClick: PropTypes.func.isRequired,
};

export default RemindRepNotification;
