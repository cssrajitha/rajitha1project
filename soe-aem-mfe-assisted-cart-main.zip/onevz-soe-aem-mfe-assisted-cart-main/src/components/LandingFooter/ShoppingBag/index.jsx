import React, { Fragment } from 'react';
import styled from 'styled-components';
import { Body } from '@vds/typography';
import './shoppingbag.css';

const FlexGrowOne = styled.div`
  flex-grow: 1 !important;
`;
const PaddingTop8 = styled.div`
  padding: 0.5rem 0 0 0;
`;

function ShoppingBag(props) {
  return (
    <div>
      {props.fromFlexLanding ? (
        <Fragment>
          <FlexGrowOne>
            <Body primitive='span' size='medium' bold>
              Shopping bag
            </Body>
            <PaddingTop8>
              {/* <DropdownSelect
                          label=""
                          errorText=""
                          error={false}
                          disabled={false}
                          readOnly={false}
                          inlineLabel={false}
                          width="76px"
                          onChange={this.onBagSelected}
                          className="bag-qty-selector"
                          placeholder="Select"
                          value={bagSelectedQty}>
                         {
                          bagQtyOptions.map((option, index) => (
                            <option key={index} value={option.value} >
                              {option.value}
                            </option>
                          ))}
                      </DropdownSelect> */}
            </PaddingTop8>
          </FlexGrowOne>
          <div>
            <Body size='medium'>${20}</Body>
          </div>
        </Fragment>
      ) : (
        <div data-testid='ShoppingBagDropdown'>
          <div className='bag-select-label'>Shopping Bag</div>
          {/* <Dropdown
                disabled={false}
                placeholder="Select"
                value={bagSelectedQty}
                options={bagQtyOptions}
                onChange={this.onBagSelected}
                style={{ width: "20%" }}
                autoWidth
                className="bag-qty-selector"
              /> */}
          <span className='u-floatRight'>${20}</span>
        </div>
      )}
    </div>
  );
}

export default ShoppingBag;
