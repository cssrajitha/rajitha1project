import React from 'react';
import RemindRepNotification from './RemindRepNotification';
import { render, screen, fireEvent } from '../../../utils/test-utils/renderHelper';
import { setupChannel, CHANNELS } from '../../../utils/test-utils/utils';

const runTest = (channel) => {
  setupChannel(channel);
  const onCloseButtonClick = jest.fn().mockName('onCloseButtonClick');
  describe(`<ShoppingBagModal component - ${channel}`, () => {
    beforeEach(() => {
      render(
        <div id='AppMessage'>
          <RemindRepNotification onCloseButtonClick={onCloseButtonClick} />
        </div>,
      );
    });
    test('should mount shopping bag modal', () => {
      expect(
        screen.getByText('Please inform the customer that they will be charged for the shopping bag (s)'),
      ).toBeInTheDocument();
    });
    test('should mount with button yes', () => {
      const yes = screen.getByRole('button', { name: 'Notification Close' });
      expect(yes).toBeInTheDocument();
      fireEvent.click(yes);
    });
  });
};

runTest(CHANNELS.OMNI_RETAIL);
