import React from 'react';
import { render, screen } from '../../../utils/test-utils/renderHelper';
import ShoppingBag from './index';

describe('ShoppingBag Component', () => {
  test('renders ShoppingBag component with proper content when fromFlexLanding is true', () => {
    const props = {
      fromFlexLanding: true,
    };

    render(<ShoppingBag {...props} />);

    // Check if the Shopping bag label is rendered
    const shoppingBagLabel = screen.getByText(/Shopping bag/i);
    expect(shoppingBagLabel).toBeInTheDocument();
  });
  test('renders ShoppingBag component with proper content when fromFlexLanding is false', () => {
    const props = {
      fromFlexLanding: false,
    };

    render(<ShoppingBag {...props} />);

    // Check if the Shopping Bag Dropdown is rendered
    const shoppingBagDropdown = screen.getByTestId('ShoppingBagDropdown');
    expect(shoppingBagDropdown).toBeInTheDocument();
  });

  // You can add more test cases for different scenarios or interactions
});
