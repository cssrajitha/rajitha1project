import React, { useEffect, useState } from 'react';
import { Modal, ModalBody } from '@vds/modals';
import styled from 'styled-components';
import { Button } from '@vds/buttons';
import { Accordion, AccordionItem, AccordionHeader, AccordionTitle, AccordionDetail } from '@vds/accordions';
import { Notification } from '@vds/notifications';
import { useLazyUpdateVisionRemarkQuery } from '../../modules/services/APIService/APIServiceHooks';

const TextLinkWrapper = styled.div`
  display: flex;
  justify-content: center;
  margin-top: 15px;
`;
const CustomHeading = styled.h2`
  font-size: 2rem;
  font-weight: 700;
  line-height: 2rem;
  font-family: 'BrandFont-Display', sans-serif !important;
  color: rgb(0, 0, 0);
  margin: 0px;
  text-decoration: none;
  letter-spacing: 0.5px;
`;
const CustomSubTitle = styled.h3`
  font-family: 'BrandFont-Display', sans-serif !important;
  letter-spacing: 0.5px;
  line-height: 21.25px;
  font-weight: 700;
  font-size: 14px;
`;
function CcdModal(props) {
  const {
    showCcdModal,
    CcdData,
    onProceedToOrderClickForExpreesCheckout,
    landingData,
    ccdRemarksForServiceChange,
    customerProfileDetails,
    closeCcdModal,
  } = props;
  const [modalData, setModalData] = useState([]);
  const [updateVisionRemak, updateVisionRemakResult] = useLazyUpdateVisionRemarkQuery();
  const consentMessage = 'I confirm I have read the CCDs to the customer';

  useEffect(() => {
    /* istanbul ignore else */
    if (updateVisionRemakResult?.isSuccess) {
      console.log(`updateVisionRemark API called`);
    }
  }, [updateVisionRemakResult]);

  const updateVisionRemark = (landingProps, customerProfile) => {
    console.log('updateVisionRemark', landingProps, customerProfile);
    const billingSysMap = {
      VN: 'VISION_NORTH',
      VW: 'VISION_WEST',
      VE: 'VISION_EAST',
      VS: 'VISION_SOUTH',
      V: 'VISION',
    };
    const { customer } = customerProfile;
    const repNameOrId = customer?.loggedInUser;
    const customerType = landingProps?.cartDetails?.orderDetails?.customerType || '';
    const billingSystemNSE = 'V';
    const custid = '';
    const billAccountNumber = '';
    const activeMtn = sessionStorage.getItem('activeMTN');
    const requestPayload = {
      mdn: activeMtn,
      requestMapping: 'autoRemarksUpdate',
      billAccountType: 'C',
      location: customer?.orderLocationCode,
      contactName: '',
      remarkLevel: 'A',
      page: '1',
      accessLvl: '1',
      remarkText: `REP ${repNameOrId} CONFIRMED CCDS WERE READ TO THE CUSTOMER - 1`,
      customerId: customerType !== 'N' ? landingProps?.flags?.fullAccountNumber?.split(/[-]/)[0] : custid,
      billingSystem:
        customerType !== 'N'
          ? billingSysMap[landingProps?.cartDetails?.orderDetails?.billingSystem]
          : billingSysMap[billingSystemNSE] || 'V',
      billAccountNumber:
        customerType !== 'N' ? landingProps?.flags?.fullAccountNumber?.split(/[-]/)[1] : billAccountNumber,
      remarkType: '',
    };
    /* istanbul ignore else */
    if (ccdRemarksForServiceChange === 'TRUE') {
      updateVisionRemak({ body: requestPayload });
    }
  };
  useEffect(() => {
    const contentArray = [];
    CcdData?.content?.forEach((value) => {
      contentArray.push(
        value.display === 'summary' ? (
          <ModalBody>
            <div
              dangerouslySetInnerHTML={{
                __html: value.content,
              }}
            />
          </ModalBody>
        ) : (
          <Accordion topLine bottomLine>
            <AccordionItem>
              <AccordionHeader triggerType='icon'>
                <AccordionTitle>{value.title}</AccordionTitle>
              </AccordionHeader>
              <AccordionDetail>
                <div className='Container' dangerouslySetInnerHTML={{ __html: value.content }} />
              </AccordionDetail>
            </AccordionItem>
          </Accordion>
        ),
      );
    });
    setModalData(contentArray);
  }, []);
  return (
    <div data-testid='CcdModal' id='CcdModal'>
      <Modal
        surface='light'
        hideCloseButton={false}
        fullScreenDialog={false}
        disableAnimation={false}
        disableOutsideClick={false}
        ariaLabel='Testing Modal'
        width='800px'
        opened={showCcdModal}
        onOpenedChange={(opened) => {
          if (!opened) closeCcdModal();
        }}
        id='CcdModal'
      >
        <div className='u-marginTop16'>
          <Notification
            type='error'
            id='ccdAlert'
            layout='vertical'
            title='CCDs must be read to the customer when View Together is not used.'
            hideCloseButton={false}
          />
          <CustomHeading primitive='h2' color='#000000' aria-hidden='false'>
            Here is what you need to know.
          </CustomHeading>
          <CustomSubTitle>
            You're almost done. An updated summary of your service will be available in My Verizon.
          </CustomSubTitle>
        </div>
        {modalData}
        <div>
          <TextLinkWrapper>
            <Button
              use='primary'
              size='small'
              onClick={() => {
                onProceedToOrderClickForExpreesCheckout();
                updateVisionRemark(landingData, customerProfileDetails);
              }}
              data-track={consentMessage}
              data-testid='CcdModalBtn'
            >
              {consentMessage}
            </Button>
          </TextLinkWrapper>
        </div>
      </Modal>
    </div>
  );
}
export default CcdModal;
