import React from 'react';
import Emitter from 'onevzsoemfeframework/Emitter';
import { useApplyOffersMutation } from 'onevzsoemfecommon/QuoteAPIService';
import { useLazyGetCustomerProfileQuery } from 'onevzsoemfecommon/APIService';
import { useAssignMTNMutation } from 'onevzsoemfecommon/AssignMtnAPIService';
import * as domService from '../../modules/services/dom.service';
import LandingFooter from './LandingFooter';
import { fireEvent, render, screen } from '../../utils/test-utils/renderHelper';
import { setupChannel, CHANNELS } from '../../utils/test-utils/utils';
import mockFetchPricingSnapshot from '../../mocks/fetchPricingSnapshot.json';
import mockRetrieveCart from '../../mocks/retrieveCart.json';
import updatedRetrieveCart from '../../mocks/retrieveCartWithOutFeature.json';
import CartApiCallHook from '../../pages/Cart/CartApiCallHook';
import { LANDING_STATE_DATA, APPLY_OFFERS_DATA } from '../../mocks/landingTestData';
import {
  useLazyGetPromoQuery,
  useLazyRetrieveAEMInfoManagerDataQuery,
  useLazyGenerateInspicioIDQuery,
  useLazySendMessageQuery,
} from '../../modules/services/APIService/APIServiceHooks';

jest.mock('../../pages/Cart/CartApiCallHook');

jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  useLazyGetPromoQuery: jest.fn(),
  useLazyRetrieveAEMInfoManagerDataQuery: jest.fn(),
  useLazyGenerateInspicioIDQuery: jest.fn(),
  useLazySendMessageQuery: jest.fn(),
}));

jest.mock('onevzsoemfecommon/QuoteAPIService', () => ({
  useApplyOffersMutation: jest.fn(),
}));
jest.mock('onevzsoemfecommon/AssignMtnAPIService', () => ({
  useAssignMTNMutation: jest.fn(),
}));

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    ...jest.requireActual('onevzsoemfeframework/AssistedCradleService'),
    default: jest.fn(() => ({})),
    getAssistedCradlePropertyV2: () => ['TRUE', 'TRUE', 'TRUE'],
  }),
  { virtual: true },
);

jest.mock('onevzsoemfecommon/APIService', () => ({
  useLazyGetCustomerProfileQuery: jest.fn(),
}));

const Test = (channel) => {
  setupChannel(channel);

  describe(`<NewSubAccount component express checkout - ${channel}`, () => {
    const props = {
      isConnectToPlan: true,
    };
    beforeEach(() => {
      sessionStorage.setItem('refundexchange', 'true');
      const retriveCart = { ...mockRetrieveCart };
      retriveCart.data.cart.cartHasConflicts = true;
      retriveCart.data.cart.conflictsAccepted = true;

      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        LandingResult: { data: { data: LANDING_STATE_DATA.landing } },
        CartDetailsResult: { data: retriveCart },
        FetchPricingSnapShotResult: { data: mockFetchPricingSnapshot },
        CustomerProfileResult: {
          data: {
            data: {
              customer: {
                channel: 'OMNI-TELESALES',
                billAccounts: [
                  {
                    mtns: [
                      {
                        mtn: '8189121022',
                        equipmentUpgradeEligibility: {
                          upgradeEligibilityDate: '09/15/2021',
                          upgradeEligible: true,
                          twoYearContract: {},
                        },
                        mobileInfoAttributes: {
                          smartFamilyParent: false,
                          accessRoles: {
                            owner: false,
                            manager: true,
                            member: true,
                          },
                        },
                        equipmentInfos: [
                          {
                            deviceInfo: {
                              modelName: 'Apple iPad 10.2 128GB in Space Gray',
                              deviceId: '353203106075529',
                              deviceIdType: 'IME',
                              deviceSku: 'MW6L2LL/A',
                            },
                            simInfo: {
                              modelName: 'GTO MULTI-FORM-FACTOR SIM',
                              simId: '89148000005523293587',
                              simSku: 'BULKSIM-TRI-A',
                            },
                          },
                        ],
                        lineSharingIndicator: '',
                        pricePlanInfo: {
                          planId: '47880',
                          planAttributes: {
                            sharePlan: false,
                          },
                        },
                        simFreezeInfo: {
                          simFreezeCode: 'N',
                          simUnfreezeTime: '15',
                          simUnfreezeTimeStamp: '',
                          isBlocked: 'Y',
                          simFreezeDetails: 'QQ',
                        },
                      },
                    ],
                    fiosEligibilityCategory: '',
                    accountAddress: {
                      zipCode: '67209',
                      zipCodePlus4: '1001',
                      fipsCode: '2017379000',
                      addressLine1: '218 S  CARDINGTON ST S',
                      addressLine2: '',
                      city: 'WICHITA',
                      state: 'KS',
                      scrubbedAddress: {
                        streetName: 'S CARDINGTON',
                        streetNumber: '218',
                        streetType: 'ST',
                        streetDirection: '',
                        apartmentNo: '',
                        pobox: '',
                        ruralDeliveryNo: '',
                        ruralRouteNo: '',
                        city: 'WICHITA',
                        state: 'KS',
                        zipCode: '67209',
                        zipCodePlus4: '4108',
                      },
                    },
                    accountAttributes: {
                      autopay: {
                        autoPayDiscount: '20.00',
                      },
                    },
                  },
                ],
              },
            },
          },
        },
      });

      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([jest.fn(), {}]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      jest.spyOn(domService, 'isFunctionalityEnabled').mockReturnValue(true);

      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    test('footer component with out sub account to display revieworder button', async () => {
      Emitter.emit('Conflicts_Accepted', true);
      const NewSubAccountTradeIn = await screen.getByTestId('ReviewOrder');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
    });
  });
  describe(`<NewSubAccount component express checkout - ${channel}`, () => {
    const props = {
      isConnectToPlan: true,
    };
    beforeEach(() => {
      sessionStorage.clear();
      const retriveCart = { ...updatedRetrieveCart };
      retriveCart.data.cart.cartHasConflicts = true;
      retriveCart.data.cart.conflictsAccepted = true;

      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        LandingResult: { data: { data: LANDING_STATE_DATA.landing } },
        CartDetailsResult: { data: retriveCart },
        FetchPricingSnapShotResult: { data: mockFetchPricingSnapshot },
        CustomerProfileResult: {
          data: {
            data: {
              customer: {
                channel: 'OMNI-TELESALES',
                billAccounts: [
                  {
                    mtns: [
                      {
                        mtn: '8189121022',
                        equipmentUpgradeEligibility: {
                          upgradeEligibilityDate: '09/15/2021',
                          upgradeEligible: true,
                          twoYearContract: {},
                        },
                        mobileInfoAttributes: {
                          smartFamilyParent: false,
                          accessRoles: {
                            owner: false,
                            manager: true,
                            member: true,
                          },
                        },
                        equipmentInfos: [
                          {
                            deviceInfo: {
                              modelName: 'Apple iPad 10.2 128GB in Space Gray',
                              deviceId: '353203106075529',
                              deviceIdType: 'IME',
                              deviceSku: 'MW6L2LL/A',
                            },
                            simInfo: {
                              modelName: 'GTO MULTI-FORM-FACTOR SIM',
                              simId: '89148000005523293587',
                              simSku: 'BULKSIM-TRI-A',
                            },
                          },
                        ],
                        lineSharingIndicator: '',
                        pricePlanInfo: {
                          planId: '47880',
                          planAttributes: {
                            sharePlan: false,
                          },
                        },
                        simFreezeInfo: {
                          simFreezeCode: 'N',
                          simUnfreezeTime: '15',
                          simUnfreezeTimeStamp: '',
                          isBlocked: 'Y',
                          simFreezeDetails: 'QQ',
                        },
                      },
                    ],
                    fiosEligibilityCategory: '',
                    accountAddress: {
                      zipCode: '67209',
                      zipCodePlus4: '1001',
                      fipsCode: '2017379000',
                      addressLine1: '218 S  CARDINGTON ST S',
                      addressLine2: '',
                      city: 'WICHITA',
                      state: 'KS',
                      scrubbedAddress: {
                        streetName: 'S CARDINGTON',
                        streetNumber: '218',
                        streetType: 'ST',
                        streetDirection: '',
                        apartmentNo: '',
                        pobox: '',
                        ruralDeliveryNo: '',
                        ruralRouteNo: '',
                        city: 'WICHITA',
                        state: 'KS',
                        zipCode: '67209',
                        zipCodePlus4: '4108',
                      },
                    },
                    accountAttributes: {
                      autopay: {
                        autoPayDiscount: '20.00',
                      },
                    },
                  },
                ],
              },
            },
          },
        },
      });

      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([jest.fn(() => ({ status: 'rejected' })), {}]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      jest.spyOn(domService, 'isFunctionalityEnabled').mockReturnValue(true);

      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    test('footer component with out sub account to display revieworder button', async () => {
      Emitter.emit('Conflicts_Accepted', true);
      const NewSubAccountTradeIn = await screen.getByTestId('ReviewOrder');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
    });
  });
};

Test(CHANNELS.OMNI_RETAIL);
Test(CHANNELS.OMNI_TELESALES);
