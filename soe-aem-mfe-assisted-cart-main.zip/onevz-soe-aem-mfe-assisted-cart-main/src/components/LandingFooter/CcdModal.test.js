import React from 'react';
import { fireEvent, render, screen, waitFor } from '../../utils/test-utils/renderHelper';
import { setupChannel, CHANNELS } from '../../utils/test-utils/utils';
import CcdModal from './CcdModal';
import { useLazyUpdateVisionRemarkQuery } from '../../modules/services/APIService/APIServiceHooks';

jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  useLazyUpdateVisionRemarkQuery: jest.fn(),
}));

jest.mock('@vds/modals', () => ({
  ...jest.requireActual('@vds/modals'),
  // eslint-disable-next-line react/button-has-type, react/prop-types
  Modal: ({ children, ...props }) => (
    // eslint-disable-next-line react/prop-types
    <div {...props} data-testid={props.id}>
      {children}
    </div>
  ),
}));

const Test = (channel) => {
  setupChannel(channel);

  describe('CcdModal Component', () => {
    beforeEach(() => {
      useLazyUpdateVisionRemarkQuery.mockReturnValue([jest.fn(), { isSuccess: true }]);
    });
    const mockProps = {
      showCcdModal: true,
      closeCcdModal: jest.fn(),
      CcdData: {
        content: [
          {
            display: 'summary',
            content: 'test',
            title: 'test',
          },
        ],
      },
      onProceedToOrderClickForExpreesCheckout: jest.fn(),
      ccdRemarksForServiceChange: 'TRUE',
      landingData: {
        cartDetails: {
          orderDetails: {
            customerType: 'P',
            billingSystem: 'test',
          },
        },
        flags: {
          fullAccountNumber: '123-456-789',
        },
      },
      customerProfileDetails: {
        customer: {
          orderLocationCode: 12354656,
        },
      },
    };

    test('renders the modal with correct content when opened', async () => {
      render(<CcdModal {...mockProps} />);

      setTimeout(async () => {
        const CcdModalBtn = await waitFor(() => expect(screen.findByTestId('CcdModalBtn').toBeInTheDocument()));
        await waitFor(() => fireEvent.click(CcdModalBtn));
      }, 1000);
    });
  });

  describe('CcdModal Component', () => {
    beforeEach(() => {
      useLazyUpdateVisionRemarkQuery.mockReturnValue([jest.fn(), { isSuccess: true }]);
    });
    const mockProps = {
      showCcdModal: true,
      closeCcdModal: jest.fn(),
      CcdData: {
        content: [
          {
            display: 'test',
            content: 'test',
            title: 'test',
          },
        ],
      },
      onProceedToOrderClickForExpreesCheckout: jest.fn(),
      ccdRemarksForServiceChange: 'TRUE',
      landingData: {
        cartDetails: {
          orderDetails: {
            customerType: 'P',
            billingSystem: 'test',
          },
        },
        flags: {
          fullAccountNumber: '123-456-789',
        },
      },
      customerProfileDetails: {
        customer: {
          orderLocationCode: 12354656,
        },
      },
    };

    test('renders the modal with correct content when opened', async () => {
      render(<CcdModal {...mockProps} />);
      await waitFor(() => screen.findByTestId('CcdModalBtn'));
      expect(screen.getByTestId('CcdModalBtn')).toBeInTheDocument();
    });
  });
  describe('CcdModal Component', () => {
    beforeEach(() => {
      useLazyUpdateVisionRemarkQuery.mockReturnValue([jest.fn(), { isSuccess: true }]);
    });
    const mockProps = {
      showCcdModal: true,
      closeCcdModal: jest.fn(),
      CcdData: {
        content: [
          {
            display: 'test',
            content: 'test',
            title: 'test',
          },
        ],
      },
      onProceedToOrderClickForExpreesCheckout: jest.fn(),
      ccdRemarksForServiceChange: 'TRUE',
      landingData: {
        cartDetails: {
          orderDetails: {
            customerType: 'P',
            billingSystem: 'test',
          },
        },
        flags: {
          fullAccountNumber: '123-456-789',
        },
      },
      customerProfileDetails: {
        customer: {
          orderLocationCode: 12354656,
        },
      },
    };

    test('renders the modal with correct content when opened', async () => {
      render(<CcdModal {...mockProps} />);
      setTimeout(async () => {
        const CcdModalBtn = await waitFor(() => expect(screen.findByTestId('CcdModalBtn').toBeInTheDocument()));
        const closeBtn = screen.getByTestId('modal-close-button');
        expect(closeBtn).toBeInTheDocument();
        fireEvent.click(closeBtn);
        await waitFor(() => fireEvent.click(CcdModalBtn));
      }, 1000);
    });
  });

  describe('CcdModal Component', () => {
    beforeEach(() => {
      useLazyUpdateVisionRemarkQuery.mockReturnValue([jest.fn(), { isSuccess: true }]);
    });
    const mockProps = {
      showCcdModal: true,
      closeCcdModal: jest.fn(),
      CcdData: {
        content: [
          {
            display: 'test',
            content: 'test',
            title: 'test',
          },
        ],
      },
      onProceedToOrderClickForExpreesCheckout: jest.fn(),
      ccdRemarksForServiceChange: 'TRUE',
      landingData: {
        cartDetails: {
          orderDetails: {
            customerType: 'N',
            billingSystem: 'test',
          },
        },
        flags: {
          fullAccountNumber: '123-456-789',
        },
      },
      customerProfileDetails: {
        customer: {
          orderLocationCode: 12354656,
        },
      },
    };

    test('renders the modal with correct content when opened', async () => {
      render(<CcdModal {...mockProps} />);

      setTimeout(async () => {
        const CcdModalBtn = screen.findByTestId('CcdModalBtn').toBeInTheDocument();
        await waitFor(() => fireEvent.click(CcdModalBtn));
      }, 1000);
      const modal = screen.getByRole('button', { name: 'I confirm I have read the CCDs to the customer' });
      fireEvent.click(modal);
    });
  });
};

Test(CHANNELS.OMNI_RETAIL);
