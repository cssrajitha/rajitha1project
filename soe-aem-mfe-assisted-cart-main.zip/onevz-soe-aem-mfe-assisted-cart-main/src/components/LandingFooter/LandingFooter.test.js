import React from 'react';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import Emitter from 'onevzsoemfeframework/Emitter';
import { useApplyOffersMutation } from 'onevzsoemfecommon/QuoteAPIService';
import { useLazyGetCustomerProfileQuery } from 'onevzsoemfecommon/APIService';
import { useAssignMTNMutation } from 'onevzsoemfecommon/AssignMtnAPIService';
import { waitFor, cleanup } from '@testing-library/react';
import * as domService from '../../modules/services/dom.service';
import LandingFooter from './LandingFooter';
import { fireEvent, render, screen } from '../../utils/test-utils/renderHelper';
import { setupChannel, CHANNELS } from '../../utils/test-utils/utils';
import mockFetchPricingSnapshot from '../../mocks/fetchPricingSnapshot.json';
import mockRetrieveCart from '../../mocks/retrieveCart.json';
import mockRetrieveCartAssignMTN from '../../mocks/retrieveCartAssignMtn.json';
import expressRetrieveCart from '../../mocks/expressCheckoutretrieveCart.json';
import CartApiCallHook from '../../pages/Cart/CartApiCallHook';
import { LANDING_STATE_DATA, APPLY_OFFERS_DATA, APPLY_OFFERS_ERROR } from '../../mocks/landingTestData';
import {
  useLazyGetPromoQuery,
  useLazyRetrieveAEMInfoManagerDataQuery,
  useLazyGenerateInspicioIDQuery,
  useLazySendMessageQuery,
  useLazyGetCartDetailsQuery,
} from '../../modules/services/APIService/APIServiceHooks';
import { cartDetailsPOYD, cartDetailsPOYD2, fetchPricingResultPOYD } from '../../mocks/PYOD';
import snPerkwithNoBYOD from '../../mocks/snPerkwithNoBYOD.json';
import snPerkwithBYOD from '../../mocks/snPerkwithBYOD.json';
import snPerkwithNoBYODNoNewLine from '../../mocks/snPerkwithNoBYODNoNewLine.json';
import snPerkwithNoBYODmutiMTN from '../../mocks/snPerkwithNoBYODmutiMTN.json';

jest.mock('../../pages/Cart/CartApiCallHook');

jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  useLazyGetPromoQuery: jest.fn(),
  useLazyRetrieveAEMInfoManagerDataQuery: jest.fn(),
  useLazyGenerateInspicioIDQuery: jest.fn(),
  useLazySendMessageQuery: jest.fn(),
  useLazyGetCartDetailsQuery: jest.fn(),
}));

jest.mock('onevzsoemfecommon/QuoteAPIService', () => ({
  useApplyOffersMutation: jest.fn(),
}));
jest.mock('onevzsoemfecommon/AssignMtnAPIService', () => ({
  useAssignMTNMutation: jest.fn(),
}));

jest.mock('onevzsoemfeframework/AssistedCradleService', () => ({
  getAssistedCradlePropertyV2: jest.fn(),
}));
jest.mock('onevzsoemfecommon/APIService', () => ({
  useLazyGetCustomerProfileQuery: jest.fn(),
}));

const Test = (channel) => {
  setupChannel(channel);

  beforeAll(() => {
    class ResizeObserver {
      constructor() {
        this.observe = () => jest.fn();
        this.unobserve = () => jest.fn();
        this.disconnect = () => jest.fn();
      }
    }
    window.ResizeObserver = ResizeObserver;
  });

  describe(`Order Review button click dfo without pending banner,without limit - ${channel}`, () => {
    document.body.innerHTML = '<div id="AppMessage" data-testid="AppMessage" />';
    const props = {
      isConnectToPlan: true,
    };
    const customerData = {
      status: 'fulfilled',
      fulfilledTimeStamp: 1726564778679,
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      data: {
        data: {
          featureFlags: {
            accountLevelVVCFFlag: true,
            intrestFreeAFOFFlag: false,
            specialFinanceAFOFFlag: false,
            vvcCardLimitMFEFFlag: true,
            vvcCardLimitTempFFlag: true,
          },
          vvcCreditLimitList: [
            {
              applicationId: 'UNA5U62DR4NA44DMM',
              crCardToken: '400898TIUUPC6603',
              availableCredit: 1,
            },
          ],
          customer: { billAccounts: [{ mtns: [{ mtn: '9989898988', marketingOption: { vzCCHolder: true } }] }] },
        },
        featureFlags: {
          accountLevelVVCFFlag: true,
          intrestFreeAFOFFlag: false,
          specialFinanceAFOFFlag: false,
          vvcCardLimitMFEFFlag: true,
          gclidMlpFFlag: true,
          vvcCardLimitTempFFlag: true,
        },
      },
    };
    beforeEach(() => {
      jest.resetAllMocks();
      sessionStorage.setItem('activeMTN', '9989898988');
      const mockFetchPricingSnapshot1 = { ...mockFetchPricingSnapshot };
      mockFetchPricingSnapshot1.data.data.subAccounts = [];
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        CartDetailsResult: { data: mockRetrieveCart },
        FetchPricingSnapShotResult: mockFetchPricingSnapshot1,
        CustomerProfileResult: { data: { featureFlags: { accountLevelVVCFFlag: true } } },
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), customerData]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'fulfilled', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          activeSubAccountId=''
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          landing={{ activeSubAccountId: 'New Sub Account 123' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    afterEach(() => {
      jest.resetAllMocks();
      cleanup();
    });
    test.skip('should open ExpandFooter', async () => {
      fireEvent.click(await screen.getByTestId('ReviewOrder'));
      console.log('html.........', document.body.innerHTML);
      await waitFor(() => {
        const header = screen.getByTestId('Notification-close-button');
        expect(header).toBeInTheDocument();
        fireEvent.click(header);
      });
    });
  });

  describe(`Order Review button click PseudoMTN Flow 1 - ${channel}`, () => {
    document.body.innerHTML = '<div id="AppMessage" data-testid="AppMessage" />';
    const props = {
      isConnectToPlan: true,
    };
    const customerData = {
      data: {
        data: {
          featureFlags: {
            accountLevelVVCFFlag: true,
            intrestFreeAFOFFlag: false,
            specialFinanceAFOFFlag: false,
            vvcCardLimitMFEFFlag: true,
            vvcCardLimitTempFFlag: true,
          },
          vvcCreditLimitList: [
            {
              applicationId: 'UNA5U62DR4NA44DMM',
              crCardToken: '400898TIUUPC6603',
            },
          ],
          customer: { billAccounts: [{ mtns: [{ mtn: '9989898988', marketingOption: { vzCCHolder: false } }] }] },
        },
        featureFlags: {
          accountLevelVVCFFlag: true,
          intrestFreeAFOFFlag: false,
          specialFinanceAFOFFlag: false,
          vvcCardLimitMFEFFlag: true,
          gclidMlpFFlag: true,
          vvcCardLimitTempFFlag: true,
        },
      },
    };
    beforeEach(() => {
       window.sessionStorage.setItem('APP_PROPERTIES', '{"fwaRetrieveCartFFlag":"TRUE"}');
      // sessionStorage.setItem('activeMTN', '9989898988');
      sessionStorage.setItem('channel', 'OMNI-INDIRECT');
      sessionStorage.setItem('fiveGHomeInternetSelectedFlow', '5G-Internet');
      sessionStorage.setItem('Qualification_type', 'CBD');
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        CartDetailsResult: { data: mockRetrieveCartAssignMTN },
        FetchPricingSnapShotResult: mockFetchPricingSnapshot,
        CustomerProfileResult: { data: { featureFlags: { accountLevelVVCFFlag: true } } },
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), customerData]);
      let successData = {
        isSuccess: true
      }
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'fulfilled', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          activeSubAccountId=''
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          landing={{ activeSubAccountId: 'New Sub Account 1' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });

    test('should open ExpandFooter', () => {
      const reviewOrder = screen.getByTestId('ReviewOrder');
      fireEvent.click(reviewOrder);
    });
  });

  describe(`Order Review button click PseudoMTN Flow 2 - ${channel}`, () => {
    document.body.innerHTML = '<div id="AppMessage" data-testid="AppMessage" />';
    const props = {
      isConnectToPlan: true,
    };
    const customerData = {
      data: {
        data: {
          featureFlags: {
            accountLevelVVCFFlag: true,
            intrestFreeAFOFFlag: false,
            specialFinanceAFOFFlag: false,
            vvcCardLimitMFEFFlag: true,
            vvcCardLimitTempFFlag: true,
          },
          vvcCreditLimitList: [
            {
              applicationId: 'UNA5U62DR4NA44DMM',
              crCardToken: '400898TIUUPC6603',
            },
          ],
          customer: { billAccounts: [{ mtns: [{ mtn: '9989898988', marketingOption: { vzCCHolder: false } }] }] },
        },
        featureFlags: {
          accountLevelVVCFFlag: true,
          intrestFreeAFOFFlag: false,
          specialFinanceAFOFFlag: false,
          vvcCardLimitMFEFFlag: true,
          gclidMlpFFlag: true,
          vvcCardLimitTempFFlag: true,
        },
      },
    };
    beforeEach(() => {
       window.sessionStorage.setItem('APP_PROPERTIES', '{"fwaRetrieveCartFFlag":"TRUE"}');
      // sessionStorage.setItem('activeMTN', '9989898988');
      // sessionStorage.setItem('channel', 'OMNI-INDIRECT');
      sessionStorage.setItem('fiveGHomeInternetSelectedFlow', '5G-Internet');
      sessionStorage.setItem('Qualification_type', 'CBD');
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        CartDetailsResult: { data: mockRetrieveCartAssignMTN },
        FetchPricingSnapShotResult: mockFetchPricingSnapshot,
        CustomerProfileResult: { data: { featureFlags: { accountLevelVVCFFlag: true } } },
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), customerData]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'fulfilled', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          activeSubAccountId=''
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          landing={{ activeSubAccountId: 'New Sub Account 1' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });

    test('should open ExpandFooter', () => {
      const reviewOrder = screen.getByTestId('ReviewOrder');
      fireEvent.click(reviewOrder);
    });
  });

  describe(`Order Review button click dfo without pending banner,without vvcCardLimitMFEFFlag - ${channel}`, () => {
    document.body.innerHTML = '<div id="AppMessage" data-testid="AppMessage" />';
    const props = {
      isConnectToPlan: true,
    };
    const customerData = {
      status: 'fulfilled',
      fulfilledTimeStamp: 1726564778679,
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      data: {
        data: {
          featureFlags: {
            accountLevelVVCFFlag: true,
            intrestFreeAFOFFlag: false,
            specialFinanceAFOFFlag: false,
            vvcCardLimitMFEFFlag: true,
            vvcCardLimitTempFFlag: true,
          },
          vvcCreditLimitList: [
            {
              applicationId: 'UNA5U62DR4NA44DMM',
              crCardToken: '400898TIUUPC6603',
              availableCredit: 1,
            },
          ],
          customer: { billAccounts: [{ mtns: [{ mtn: '9989898988', marketingOption: { vzCCHolder: true } }] }] },
        },
        featureFlags: {
          accountLevelVVCFFlag: true,
          intrestFreeAFOFFlag: false,
          specialFinanceAFOFFlag: false,
          vvcCardLimitTempFFlag: true,
        },
      },
    };
    beforeEach(() => {
      sessionStorage.setItem('activeMTN', '9989898988');
      const mockFetchPricingSnapshot1 = { ...mockFetchPricingSnapshot };
      mockFetchPricingSnapshot1.data.data.subAccounts = [];
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        CartDetailsResult: { data: mockRetrieveCart },
        FetchPricingSnapShotResult: mockFetchPricingSnapshot1,
        CustomerProfileResult: { data: { featureFlags: { accountLevelVVCFFlag: true } } },
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), customerData]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'fulfilled', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          activeSubAccountId=''
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          landing={{ activeSubAccountId: 'New Sub Account 123' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    test('footer component with out sub account to display revieworder button', async () => {
      const NewSubAccountTradeIn = await screen.getByTestId('ReviewOrder');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
    });

    test('should mount Footer component', async () => {
      const vaditeShop = await screen.getByTestId('dueToday');
      expect(vaditeShop).toBeInTheDocument();
      fireEvent.click(vaditeShop);
    });

    test('should open ExpandFooter', async () => {
      const vaditeShop = await screen.getByRole('img', { name: 'up-caret icon' });
      expect(vaditeShop).toBeInTheDocument();
      fireEvent.click(vaditeShop);
      const reviewOrder = await screen.getByRole('button', { name: 'Review order' });
      // expect(reviewOrder).toBeInTheDocument();
      fireEvent.click(reviewOrder);
    });

    test('Disable express checkout', async () => {
      Emitter.emit('Set_Express_Checkout_Disabled', true);
    });
  });
  describe(`Order Review button click dfo without pending banner,with limit - ${channel}`, () => {
    document.body.innerHTML = '<div id="AppMessage" data-testid="AppMessage" />';
    const props = {
      isConnectToPlan: true,
    };
    const customerData = {
      status: 'fulfilled',
      fulfilledTimeStamp: 1726564778679,
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      data: {
        data: {
          featureFlags: {
            accountLevelVVCFFlag: true,
            intrestFreeAFOFFlag: false,
            specialFinanceAFOFFlag: false,
            vvcCardLimitMFEFFlag: true,
            vvcCardLimitTempFFlag: true,
          },
          vvcCreditLimitList: [
            {
              applicationId: 'UNA5U62DR4NA44DMM',
              crCardToken: '400898TIUUPC6603',
              availableCredit: 5000,
            },
          ],
          customer: { billAccounts: [{ mtns: [{ mtn: '9989898988', marketingOption: { vzCCHolder: true } }] }] },
        },
        featureFlags: {
          accountLevelVVCFFlag: true,
          intrestFreeAFOFFlag: false,
          specialFinanceAFOFFlag: false,
          vvcCardLimitMFEFFlag: true,
          vvcCardLimitTempFFlag: true,
        },
      },
    };
    beforeEach(() => {
      sessionStorage.setItem('activeMTN', '9989898988');
      const mockFetchPricingSnapshot1 = { ...mockFetchPricingSnapshot };
      mockFetchPricingSnapshot1.data.data.subAccounts = [];
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        CartDetailsResult: { data: mockRetrieveCart },
        FetchPricingSnapShotResult: mockFetchPricingSnapshot1,
        CustomerProfileResult: { data: { featureFlags: { accountLevelVVCFFlag: true } } },
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), customerData]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'fulfilled', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          activeSubAccountId=''
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          landing={{ activeSubAccountId: 'New Sub Account 123' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    test('footer component with out sub account to display revieworder button', async () => {
      const NewSubAccountTradeIn = await screen.getByTestId('ReviewOrder');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
    });

    test('should mount Footer component', async () => {
      const vaditeShop = await screen.getByTestId('dueToday');
      expect(vaditeShop).toBeInTheDocument();
      fireEvent.click(vaditeShop);
    });

    test('should open ExpandFooter', async () => {
      const vaditeShop = await screen.getByRole('img', { name: 'up-caret icon' });
      expect(vaditeShop).toBeInTheDocument();
      fireEvent.click(vaditeShop);
      const reviewOrder = await screen.getByRole('button', { name: 'Review order' });
      // expect(reviewOrder).toBeInTheDocument();
      fireEvent.click(reviewOrder);
    });

    test('Disable express checkout', async () => {
      Emitter.emit('Set_Express_Checkout_Disabled', true);
    });
  });
  describe(`Order Review button click dfo without pending banner,with out available credit node - ${channel}`, () => {
    document.body.innerHTML = '<div id="AppMessage" data-testid="AppMessage" />';
    const props = {
      isConnectToPlan: true,
    };
    const customerData = {
      status: 'fulfilled',
      fulfilledTimeStamp: 1726564778679,
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      data: {
        data: {
          featureFlags: {
            accountLevelVVCFFlag: true,
            intrestFreeAFOFFlag: false,
            specialFinanceAFOFFlag: false,
            vvcCardLimitMFEFFlag: true,
            vvcCardLimitTempFFlag: true,
          },
          vvcCreditLimitList: [
            {
              applicationId: 'UNA5U62DR4NA44DMM',
              crCardToken: '400898TIUUPC6603',
            },
          ],
          customer: { billAccounts: [{ mtns: [{ mtn: '9989898988', marketingOption: { vzCCHolder: true } }] }] },
        },
        featureFlags: {
          accountLevelVVCFFlag: true,
          intrestFreeAFOFFlag: false,
          specialFinanceAFOFFlag: false,
          vvcCardLimitMFEFFlag: true,
          vvcCardLimitTempFFlag: true,
        },
      },
    };
    beforeEach(() => {
      sessionStorage.setItem('activeMTN', '9989898988');
      const mockFetchPricingSnapshot1 = { ...mockFetchPricingSnapshot };
      mockFetchPricingSnapshot1.data.data.subAccounts = [];
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        CartDetailsResult: { data: mockRetrieveCart },
        FetchPricingSnapShotResult: mockFetchPricingSnapshot1,
        CustomerProfileResult: { data: { featureFlags: { accountLevelVVCFFlag: true } } },
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), customerData]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'fulfilled', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          activeSubAccountId=''
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          landing={{ activeSubAccountId: 'New Sub Account 123' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    test('footer component with out sub account to display revieworder button', async () => {
      const NewSubAccountTradeIn = await screen.getByTestId('ReviewOrder');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
    });

    test('should mount Footer component', async () => {
      const vaditeShop = await screen.getByTestId('dueToday');
      expect(vaditeShop).toBeInTheDocument();
      fireEvent.click(vaditeShop);
    });

    test('should open ExpandFooter', async () => {
      const vaditeShop = await screen.getByRole('img', { name: 'up-caret icon' });
      expect(vaditeShop).toBeInTheDocument();
      fireEvent.click(vaditeShop);
      const reviewOrder = await screen.getByRole('button', { name: 'Review order' });
      // expect(reviewOrder).toBeInTheDocument();
      fireEvent.click(reviewOrder);
    });

    test('Disable express checkout', async () => {
      Emitter.emit('Set_Express_Checkout_Disabled', true);
    });
  });
  describe(`Order Review button click dfo without pending banner,with out available credit node - ${channel}`, () => {
    document.body.innerHTML = '<div id="AppMessage" data-testid="AppMessage" />';
    const props = {
      isConnectToPlan: true,
    };
    const customerData = {
      status: 'fulfilled',
      fulfilledTimeStamp: 1726564778679,
      isUninitialized: false,
      isLoading: false,
      isSuccess: true,
      isError: false,
      data: {
        data: {
          featureFlags: {
            accountLevelVVCFFlag: true,
            intrestFreeAFOFFlag: false,
            specialFinanceAFOFFlag: false,
            vvcCardLimitMFEFFlag: false,
            vvcCardLimitTempFFlag: true,
          },
          vvcCreditLimitList: [
            {
              applicationId: 'UNA5U62DR4NA44DMM',
              crCardToken: '400898TIUUPC6603',
            },
          ],
          customer: { billAccounts: [{ mtns: [{ mtn: '9989898988', marketingOption: { vzCCHolder: true } }] }] },
        },
        featureFlags: {
          accountLevelVVCFFlag: true,
          intrestFreeAFOFFlag: false,
          specialFinanceAFOFFlag: false,
          vvcCardLimitMFEFFlag: true,
          vvcCardLimitTempFFlag: true,
        },
      },
    };
    beforeEach(() => {
      sessionStorage.setItem('activeMTN', '9989898988');
      const mockFetchPricingSnapshot1 = { ...mockFetchPricingSnapshot };
      mockFetchPricingSnapshot1.data.data.subAccounts = [];
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        CartDetailsResult: { data: mockRetrieveCart },
        FetchPricingSnapShotResult: mockFetchPricingSnapshot1,
        CustomerProfileResult: { data: { featureFlags: { accountLevelVVCFFlag: true } } },
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), customerData]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'fulfilled', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          activeSubAccountId=''
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          landing={{ activeSubAccountId: 'New Sub Account 123' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    test('footer component with out sub account to display revieworder button', async () => {
      const NewSubAccountTradeIn = await screen.getByTestId('ReviewOrder');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
    });

    test('should mount Footer component', async () => {
      const vaditeShop = await screen.getByTestId('dueToday');
      expect(vaditeShop).toBeInTheDocument();
      fireEvent.click(vaditeShop);
    });

    test('should open ExpandFooter', async () => {
      const vaditeShop = await screen.getByRole('img', { name: 'up-caret icon' });
      expect(vaditeShop).toBeInTheDocument();
      fireEvent.click(vaditeShop);
      const reviewOrder = await screen.getByRole('button', { name: 'Review order' });
      // expect(reviewOrder).toBeInTheDocument();
      fireEvent.click(reviewOrder);
    });

    test('Disable express checkout', async () => {
      Emitter.emit('Set_Express_Checkout_Disabled', true);
    });
  });
  describe(`<Footer component - ${channel}`, () => {
    const props = {
      isConnectToPlan: true,
    };
    const cartData = {
      data: {
        cart: {
          lineDetails: {
            lineInfo: [
              {
                itemsInfo: [
                  { itemCount: 1, cartItems: {} },
                  { itemCount: 2, cartItems: { cartItem: [] } },
                  { itemCount: 0, cartItems: { cartItem: [{ cartItemType: 'SIM' }] } },
                  { itemCount: 0, cartItems: { cartItem: [{ prodCode1: 'LAB', prodCode2: 'SER', prodCode4: 'SUG' }] } },
                ],
              },
              {
                itemsInfo: [
                  { itemCount: 1, cartItems: {} },
                  { itemCount: 1, cartItems: { cartItem: [] } },
                  { itemCount: 0, cartItems: { cartItem: [{ cartItemType: 'SIM' }] } },
                ],
              },
              null,
            ],
          },
        },
      },
    };
    beforeEach(() => {
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        CartDetailsResult: { data: cartData },
        FetchPricingSnapShotResult: {},
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_ERROR]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'fulfilled', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount
          activeSubAccountId='New Sub Account 1'
          landing={{ activeSubAccountId: 'New Sub Account 1' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          showShoppingBagModalFn={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    test('footer component with applyOffers button', async () => {
      const NewSubAccountTradeIn = await screen.getByTestId('Apply-Offers');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
    });
  });

  describe(`<Footer component - ${channel}`, () => {
    const props = {
      isConnectToPlan: true,
    };
    beforeEach(() => {
      window.sessionStorage.setItem('APP_PROPERTIES', '{"billUsageTaggingFFlag":"TRUE"}');
      window.sessionStorage.setItem('selectedSubAccountId', 'New Sub Account 1');
      const retriveCart = { ...mockRetrieveCart };
      retriveCart.data.cart.orderDetails.subAccountInfo = [{ subAccountId: 'New Sub Account 1', totalDueToday: 1000 }];
      retriveCart.data.cart.orderDetails.totalDueToday = 1002;
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        LandingResult: { data: { data: LANDING_STATE_DATA.landing } },
        CartDetailsResult: { data: retriveCart },
        FetchPricingSnapShotResult: mockFetchPricingSnapshot,
        CustomerProfileResult: {
          data: {
            data: {
              customer: {
                channel: 'OMNI-TELESALES',
                billAccounts: [{ accountAttributes: { isCashOnlyExceptCO: true } }],
              },
            },
          },
        },
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_ERROR]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'fulfilled', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount
          activeSubAccountId='New Sub Account 1'
          landing={{ activeSubAccountId: 'New Sub Account 1' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    test('footer component with applyOffers button', async () => {
      const NewSubAccountTradeIn = await screen.getByTestId('Apply-Offers');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
    });
    test('footer component with review-order button and navigating to subaccounts screen', async () => {
      const NewSubAccountTradeIn = await screen.getByTestId('ReviewOrder-SubAccount');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
    });
    test('footer component with vzdl event value validation', async () => {
      const retrieveCartSubAccountInfo = sessionStorage.getItem('selectedSubAccountId');
      expect(retrieveCartSubAccountInfo).toBe('New Sub Account 1');
      expect(window.vzdl?.event?.value).toBe(`event308=${1000}`);
    });
  });

  describe(`<Footer component with express checkout- ${channel}`, () => {
    const props = {
      isConnectToPlan: true,
    };
    beforeEach(() => {
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        LandingResult: { data: { data: LANDING_STATE_DATA.landing } },
        CartDetailsResult: { data: expressRetrieveCart },
        FetchPricingSnapShotResult: mockFetchPricingSnapshot,
        retrieveAEMInfoManagerData: { data: { data: { aemInfoManagerData: { data: { aemInfo: { data: {} } } } } } },
        CustomerProfileResult: {
          data: {
            data: {
              customer: {
                channel: 'OMNI-TELESALES',
                billAccounts: [{ accountAttributes: { isCashOnlyExceptCO: true } }],
              },
            },
          },
        },
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_ERROR]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'fulfilled', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    test('footer component with review-order button and navigating to subaccounts screen', async () => {
      const ExpressCheckoutID = await screen.getByTestId('ExpressCheckoutId');
      expect(ExpressCheckoutID).toBeInTheDocument();
      fireEvent.click(ExpressCheckoutID);
    });
  });
  describe(`<Footer component with express checkout- ${channel}`, () => {
    const props = {
      isConnectToPlan: true,
    };
    beforeEach(() => {
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        LandingResult: { data: { data: LANDING_STATE_DATA.landing } },
        CartDetailsResult: { data: mockRetrieveCart },
        FetchPricingSnapShotResult: mockFetchPricingSnapshot,
        retrieveAEMInfoManagerData: { data: { data: { aemInfoManagerData: { data: { aemInfo: { data: {} } } } } } },
        CustomerProfileResult: {
          data: {
            data: {
              customer: {
                channel: 'OMNI-TELESALES',
                billAccounts: [{ accountAttributes: { isCashOnlyExceptCO: true } }],
              },
            },
          },
        },
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_ERROR]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'fulfilled', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount
          activeSubAccountId='New Sub Account 1'
          landing={{ activeSubAccountId: 'New Sub Account 1' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    test('footer component with review-order button and navigating to subaccounts screen', async () => {
      Emitter.emit('Conflicts_Accepted', true);
      const ExpressCheckoutID = await screen.getByTestId('ExpressCheckoutId');
      expect(ExpressCheckoutID).toBeInTheDocument();
      fireEvent.click(ExpressCheckoutID);
    });
  });

  describe(`<Footer component with express checkout- ${channel}`, () => {
    const props = {
      isConnectToPlan: true,
    };

    beforeAll(() => {
      Emitter.emit('Conflicts_Accepted', true);
    });
    beforeEach(() => {
      const retriveCart = { ...mockRetrieveCart };
      retriveCart.data.cart.cartHasConflicts = true;
      retriveCart.data.cart.conflictsAccepted = true;

      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        LandingResult: { data: { data: LANDING_STATE_DATA.landing } },
        CartDetailsResult: { data: retriveCart },
        FetchPricingSnapShotResult: mockFetchPricingSnapshot,
        retrieveAEMInfoManagerData: { data: { data: { aemInfoManagerData: { data: { aemInfo: { data: {} } } } } } },
        CustomerProfileResult: {
          data: {
            data: {
              customer: {
                channel: 'OMNI-TELESALES',
                billAccounts: [{ accountAttributes: { isCashOnlyExceptCO: true } }],
              },
            },
          },
        },
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_ERROR]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'fulfilled', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount
          activeSubAccountId='New Sub Account 1'
          landing={{ activeSubAccountId: 'New Sub Account 1' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    test('footer component with review-order button and navigating to subaccounts screen', async () => {
      const ExpressCheckoutID = await screen.getByTestId('ExpressCheckoutId');
      expect(ExpressCheckoutID).toBeInTheDocument();
      fireEvent.click(ExpressCheckoutID);
    });

    test('footer component with review-order button and navigating to subaccounts screen', async () => {
      Emitter.emit('Conflicts_Accepted', true);

      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount
          activeSubAccountId='New Sub Account 1'
          landing={{ activeSubAccountId: 'New Sub Account 1' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
      const ExpressCheckoutID = await screen.getAllByTestId('ExpressCheckoutId')[0];
      expect(ExpressCheckoutID).toBeInTheDocument();
      fireEvent.click(ExpressCheckoutID);

      Emitter.emit('Conflicts_Accepted', true);

      const ExpressCheckoutID1 = await screen.getAllByTestId('ExpressCheckoutId')[0];
      expect(ExpressCheckoutID1).toBeInTheDocument();
      fireEvent.click(ExpressCheckoutID);
    });
  });

  describe(`<NewSubAccount component - ${channel}`, () => {
    const props = {
      isConnectToPlan: true,
    };
    beforeEach(() => {
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        CartDetailsResult: { data: mockRetrieveCart },
        FetchPricingSnapShotResult: mockFetchPricingSnapshot,
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'fulfilled', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          activeSubAccountId=''
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          landing={{ activeSubAccountId: 'New Sub Account 1' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    test('footer component with out sub account to display revieworder button', async () => {
      const NewSubAccountTradeIn = await screen.getByTestId('ReviewOrder');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
    });

    test('should mount Footer component', async () => {
      const vaditeShop = await screen.getByTestId('dueToday');
      expect(vaditeShop).toBeInTheDocument();
      fireEvent.click(vaditeShop);
    });

    test('should open ExpandFooter', async () => {
      const vaditeShop = await screen.getByRole('img', { name: 'up-caret icon' });
      expect(vaditeShop).toBeInTheDocument();
      fireEvent.click(vaditeShop);
      const reviewOrder = await screen.getByRole('button', { name: 'Review order' });
      // expect(reviewOrder).toBeInTheDocument();
      fireEvent.click(reviewOrder);
    });

    test('Disable express checkout', async () => {
      Emitter.emit('Set_Express_Checkout_Disabled', true);
    });
  });

  describe(`<NewSubAccount component POYD Notification - ${channel}`, () => {
    const props = {
      isConnectToPlan: true,
      name: 'PYOD Prop',
    };
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({ isPYODEnabled: 'TRUE', payOffYourDeviceRebateFFlag: 'TRUE', floridaDiscountFFlag: 'TRUE' }),
      );
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        CartDetailsResult: { data: cartDetailsPOYD },
        FetchPricingSnapShotResult: fetchPricingResultPOYD,
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'fulfilled', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          activeSubAccountId=''
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          landing={{ activeSubAccountId: 'New Sub Account 1' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    test('footer component with out sub account to display revieworder button', async () => {
      const NewSubAccountTradeIn = await screen.getByTestId('ReviewOrder');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
      const proceedWithoutOfr = screen.getByTestId('proceed-without-offer');
      expect(proceedWithoutOfr).toBeInTheDocument();
      fireEvent.click(proceedWithoutOfr);
    });
  });

  describe(`<NewSubAccount component POYD Notification - ${channel}`, () => {
    const props = {
      isConnectToPlan: true,
      name: 'PYOD Prop',
    };
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({ isPYODEnabled: 'TRUE', payOffYourDeviceRebateFFlag: 'TRUE', floridaDiscountFFlag: 'TRUE' }),
      );
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        CartDetailsResult: { data: cartDetailsPOYD },
        FetchPricingSnapShotResult: fetchPricingResultPOYD,
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'fulfilled', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          activeSubAccountId=''
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          landing={{ activeSubAccountId: 'New Sub Account 1' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    test('footer component with out sub account to display revieworder button', async () => {
      const NewSubAccountTradeIn = await screen.getByTestId('ReviewOrder');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
      const goback = screen.getByTestId('go-back');
      expect(goback).toBeInTheDocument();
      fireEvent.click(goback);
    });
  });
  describe(`<NewSubAccount component POYD Notification - ${channel}`, () => {
    const props = {
      isConnectToPlan: true,
      name: 'PYOD Prop',
    };
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({ isPYODEnabled: 'TRUE', payOffYourDeviceRebateFFlag: 'TRUE', floridaDiscountFFlag: 'TRUE' }),
      );
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        CartDetailsResult: { data: cartDetailsPOYD2 },
        FetchPricingSnapShotResult: fetchPricingResultPOYD,
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'rejected', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          activeSubAccountId=''
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          landing={{ activeSubAccountId: 'New Sub Account 1' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    test('footer component with out sub account to display revieworder button', async () => {
      const NewSubAccountTradeIn = await screen.getByTestId('ReviewOrder');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
      const goback = screen.getByTestId('go-back');
      expect(goback).toBeInTheDocument();
      fireEvent.click(goback);
    });
  });

  describe(`<NewSubAccount component POYD Notification - ${channel}`, () => {
    const props = {
      isConnectToPlan: true,
    };

    beforeEach(() => {
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        LandingResult: { data: { data: LANDING_STATE_DATA.landing } },
        CartDetailsResult: { data: cartDetailsPOYD },
        FetchPricingSnapShotResult: fetchPricingResultPOYD,
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'fulfilled', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          activeSubAccountId='New Sub Account 1'
          landing={{ activeSubAccountId: 'New Sub Account 1' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });

    test('Initiate apply offers', async () => {
      const NewSubAccountTradeIn = await screen.getByTestId('Apply-Offers');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
      const proceedWithoutOfr = screen.getByTestId('proceed-without-offer');
      expect(proceedWithoutOfr).toBeInTheDocument();
      fireEvent.click(proceedWithoutOfr);
    });
  });

  describe(`<NewSubAccount component - ${channel}`, () => {
    const props = {
      isConnectToPlan: true,
    };

    beforeEach(() => {
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        LandingResult: { data: { data: LANDING_STATE_DATA.landing } },
        CartDetailsResult: { data: mockRetrieveCart },
        FetchPricingSnapShotResult: { data: mockFetchPricingSnapshot },
        CustomerProfileResult: {
          data: {
            data: {
              customer: {
                channel: 'OMNI-TELESALES',
                billAccounts: [{ accountAttributes: { isCashOnlyExceptCO: true } }],
              },
            },
          },
        },
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'fulfilled', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          activeSubAccountId='New Sub Account 1'
          landing={{ activeSubAccountId: 'New Sub Account 1' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });

    test('Initiate apply offers', async () => {
      const NewSubAccountTradeIn = await screen.getByTestId('Apply-Offers');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
    });

    test('Clicking ReviewOrder-SubAccount', async () => {
      const NewSubAccountTradeIn = await screen.getByTestId('ReviewOrder-SubAccount');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
    });
  });

  describe(`<NewSubAccount component - ${channel}`, () => {
    const props = {
      isConnectToPlan: true,
    };
    beforeEach(() => {
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        LandingResult: { data: { data: LANDING_STATE_DATA.landing } },
        CartDetailsResult: { data: mockRetrieveCart },
        FetchPricingSnapShotResult: { data: mockFetchPricingSnapshot },
        CustomerProfileResult: {
          data: {
            data: {
              customer: {
                channel: 'OMNI-TELESALES',
                billAccounts: [{ accountAttributes: { isCashOnlyExceptCO: true } }],
              },
            },
          },
        },
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'fulfilled', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      jest.spyOn(domService, 'isFunctionalityEnabled').mockReturnValue(true);

      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          activeSubAccountId='New Sub Account 1'
          landing={{ activeSubAccountId: 'New Sub Account 1' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    test('footer component with out sub account to display revieworder button', async () => {
      const NewSubAccountTradeIn = await screen.getByTestId('ReviewOrder');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
    });
  });

  describe(`<NewSubAccount component - ${channel}`, () => {
    const props = {
      isConnectToPlan: true,
    };
    beforeEach(() => {
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        LandingResult: { data: { data: LANDING_STATE_DATA.landing } },
        CartDetailsResult: { data: mockRetrieveCart, isSuccess: true },
        FetchPricingSnapShotResult: { data: mockFetchPricingSnapshot },
        CustomerProfileResult: {
          data: {
            data: {
              customer: {
                channel: 'OMNI-TELESALES',
                billAccounts: [{ accountAttributes: { isCashOnlyExceptCO: true } }],
              },
            },
          },
        },
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'fulfilled', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          activeSubAccountId='New Sub Account 1'
          landing={{ activeSubAccountId: 'New Sub Account 1' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });

    test('Initiate apply offers', async () => {
      const NewSubAccountTradeIn = await screen.getByTestId('Apply-Offers');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
    });
  });

  describe(`<NewSubAccount component - ${channel}`, () => {
    const props = {
      isConnectToPlan: true,
    };
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableReturnAnywhereAssisted: 'TRUE',
          assistedFlexV2APIFFlag: 'TRUE',
          floridaDiscountFFlag: 'TRUE',
        }),
      );
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        LandingResult: { data: { data: LANDING_STATE_DATA.landing } },
        CartDetailsResult: { data: mockRetrieveCart, isSuccess: true },
        FetchPricingSnapShotResult: { data: mockFetchPricingSnapshot },
        CustomerProfileResult: {
          data: {
            data: {
              customer: {
                channel: 'OMNI-TELESALES',
                billAccounts: [{ accountAttributes: { isCashOnlyExceptCO: true } }],
              },
            },
          },
        },
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'fulfilled', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE']);

      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          activeSubAccountId='New Sub Account 1'
          landing={{ activeSubAccountId: 'New Sub Account 1' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });

    test('Initiate apply offers', async () => {
      const NewSubAccountTradeIn = await screen.getByTestId('Apply-Offers');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
    });
  });

  describe.skip(`<NewSubAccount component - ${channel}`, () => {
    const props = {
      isConnectToPlan: true,
    };
    beforeEach(() => {
      sessionStorage.clear();
      const retriveCart = { ...mockRetrieveCart };
      retriveCart.data.cart.orderDetails.customerType = 'N';
      retriveCart.data.cart.lineDetails.spendingLimitAmountExceededBy = 10000000000000;

      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        LandingResult: { data: { data: LANDING_STATE_DATA.landing } },
        CartDetailsResult: { data: retriveCart, isSuccess: true },
        FetchPricingSnapShotResult: { data: mockFetchPricingSnapshot },
        CustomerProfileResult: {
          data: {
            data: {
              customer: {
                channel: 'OMNI-TELESALES',
                billAccounts: [
                  {
                    accountAttributes: {
                      isCashOnlyExceptCO: true,
                      isCashOnlyExceptCA: true,
                      isCashOnlyExceptCC: true,
                      establishedInLastThirtyDays: true,
                    },
                  },
                ],
              },
            },
          },
        },
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'fulfilled', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      sessionStorage.setItem('newPostToPreIndicator', 'false');
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          activeSubAccountId='New Sub Account 1'
          landing={{ activeSubAccountId: 'New Sub Account 1' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    afterEach(() => {
      jest.resetAllMocks();
      cleanup();
    });
    test('Initiate apply offers', async () => {
      const NewSubAccountTradeIn = await screen.getByTestId('Apply-Offers');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
    });
  });

  describe.skip(`<NewSubAccount component - ${channel}`, () => {
    const props = {
      isConnectToPlan: true,
    };
    beforeEach(() => {
      sessionStorage.clear();
      const retriveCart = { ...mockRetrieveCart };
      retriveCart.data.cart.orderDetails.customerType = 'N';
      retriveCart.data.cart.lineDetails.spendingLimitAmountExceededBy = 10000000000000;

      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        LandingResult: { data: { data: LANDING_STATE_DATA.landing } },
        CartDetailsResult: { data: retriveCart, isSuccess: true },
        FetchPricingSnapShotResult: { data: mockFetchPricingSnapshot },
        CustomerProfileResult: {
          data: {
            data: {
              customer: {
                channel: 'OMNI-TELESALES',
                billAccounts: [{ accountAttributes: { isCashOnly: true, establishedInLastThirtyDays: true } }],
              },
            },
          },
        },
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'fulfilled', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      sessionStorage.setItem('newPostToPreIndicator', 'false');
      render(
        <LandingFooter
          {...props}
          isRfexFlow
          isTysFlow={false}
          hasSubAccount
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          activeSubAccountId='New Sub Account 1'
          landing={{ activeSubAccountId: 'New Sub Account 1' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });

    test('footer component', async () => {
      const NewSubAccountTradeIn = await screen.getByText('Due today');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
    });
  });

  describe(`<NewSubAccount component - ${channel}`, () => {
    const props = {
      isConnectToPlan: true,
    };
    beforeEach(() => {
      const retriveCart = { ...mockRetrieveCart };
      retriveCart.data.cart.cartHasConflicts = true;
      retriveCart.data.cart.conflictsAccepted = true;

      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        LandingResult: { data: { data: LANDING_STATE_DATA.landing } },
        CartDetailsResult: { data: retriveCart },
        FetchPricingSnapShotResult: { data: mockFetchPricingSnapshot },
        CustomerProfileResult: {
          data: {
            data: {
              customer: {
                channel: 'OMNI-TELESALES',
                billAccounts: [{ accountAttributes: { isCashOnlyExceptCO: true } }],
              },
            },
          },
        },
      });

      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'fulfilled', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      jest.spyOn(domService, 'isFunctionalityEnabled').mockReturnValue(true);

      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          activeSubAccountId='New Sub Account 1'
          landing={{ activeSubAccountId: 'New Sub Account 1' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    test('footer component with out sub account to display revieworder button', async () => {
      const NewSubAccountTradeIn = await screen.getByTestId('ReviewOrder');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
    });
  });

  // new

  describe(`<NewSubAccount component express checkout - ${channel}`, () => {
    const props = {
      isConnectToPlan: true,
    };
    beforeEach(() => {
      const retriveCart = { ...mockRetrieveCart };
      retriveCart.data.cart.cartHasConflicts = true;
      retriveCart.data.cart.conflictsAccepted = true;

      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        LandingResult: { data: { data: LANDING_STATE_DATA.landing } },
        CartDetailsResult: { data: retriveCart },
        FetchPricingSnapShotResult: { data: mockFetchPricingSnapshot },
        CustomerProfileResult: {
          data: {
            data: {
              customer: {
                channel: 'OMNI-TELESALES',
                billAccounts: [
                  {
                    mtns: [
                      {
                        mtn: '8189121022',
                        equipmentUpgradeEligibility: {
                          upgradeEligibilityDate: '09/15/2021',
                          upgradeEligible: true,
                          twoYearContract: {},
                        },
                        mobileInfoAttributes: {
                          smartFamilyParent: false,
                          accessRoles: {
                            owner: false,
                            manager: true,
                            member: true,
                          },
                        },
                        equipmentInfos: [
                          {
                            deviceInfo: {
                              modelName: 'Apple iPad 10.2 128GB in Space Gray',
                              deviceId: '353203106075529',
                              deviceIdType: 'IME',
                              deviceSku: 'MW6L2LL/A',
                            },
                            simInfo: {
                              modelName: 'GTO MULTI-FORM-FACTOR SIM',
                              simId: '89148000005523293587',
                              simSku: 'BULKSIM-TRI-A',
                            },
                          },
                        ],
                        lineSharingIndicator: '',
                        pricePlanInfo: {
                          planId: '47880',
                          planAttributes: {
                            sharePlan: false,
                          },
                        },
                        simFreezeInfo: {
                          simFreezeCode: 'N',
                          simUnfreezeTime: '15',
                          simUnfreezeTimeStamp: '',
                          isBlocked: 'Y',
                          simFreezeDetails: 'QQ',
                        },
                      },
                    ],
                    fiosEligibilityCategory: '',
                    accountAddress: {
                      zipCode: '67209',
                      zipCodePlus4: '1001',
                      fipsCode: '2017379000',
                      addressLine1: '218 S  CARDINGTON ST S',
                      addressLine2: '',
                      city: 'WICHITA',
                      state: 'KS',
                      scrubbedAddress: {
                        streetName: 'S CARDINGTON',
                        streetNumber: '218',
                        streetType: 'ST',
                        streetDirection: '',
                        apartmentNo: '',
                        pobox: '',
                        ruralDeliveryNo: '',
                        ruralRouteNo: '',
                        city: 'WICHITA',
                        state: 'KS',
                        zipCode: '67209',
                        zipCodePlus4: '4108',
                      },
                    },
                    accountAttributes: {
                      autopay: {
                        autoPayDiscount: '20.00',
                      },
                    },
                  },
                ],
              },
            },
          },
        },
      });

      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'fulfilled', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      jest.spyOn(domService, 'isFunctionalityEnabled').mockReturnValue(true);

      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          activeSubAccountId='New Sub Account 1'
          landing={{ activeSubAccountId: 'New Sub Account 1' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    test('footer component with out sub account to display revieworder button', async () => {
      const NewSubAccountTradeIn = await screen.getByTestId('ReviewOrder');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
    });
  });

  describe(`<NewSubAccount component express checkout - ${channel}`, () => {
    const props = {
      isConnectToPlan: true,
    };
    beforeEach(() => {
      const retriveCart = { ...mockRetrieveCart };
      retriveCart.data.cart.cartHasConflicts = true;
      retriveCart.data.cart.conflictsAccepted = true;

      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        LandingResult: { data: { data: LANDING_STATE_DATA.landing } },
        CartDetailsResult: { data: retriveCart },
        FetchPricingSnapShotResult: { data: mockFetchPricingSnapshot },
        CustomerProfileResult: {
          data: {
            data: {
              customer: {
                channel: 'OMNI-TELESALES',
                billAccounts: [
                  {
                    mtns: [
                      {
                        mtn: '8189121022',
                        equipmentUpgradeEligibility: {
                          upgradeEligibilityDate: '09/15/2021',
                          upgradeEligible: true,
                          twoYearContract: {},
                        },
                        mobileInfoAttributes: {
                          smartFamilyParent: false,
                          accessRoles: {
                            owner: false,
                            manager: true,
                            member: true,
                          },
                        },
                        equipmentInfos: [
                          {
                            deviceInfo: {
                              modelName: 'Apple iPad 10.2 128GB in Space Gray',
                              deviceId: '353203106075529',
                              deviceIdType: 'IME',
                              deviceSku: 'MW6L2LL/A',
                            },
                            simInfo: {
                              modelName: 'GTO MULTI-FORM-FACTOR SIM',
                              simId: '89148000005523293587',
                              simSku: 'BULKSIM-TRI-A',
                            },
                          },
                        ],
                        lineSharingIndicator: '',
                        pricePlanInfo: {
                          planId: '47880',
                          planAttributes: {
                            sharePlan: false,
                          },
                        },
                        simFreezeInfo: {
                          simFreezeCode: 'N',
                          simUnfreezeTime: '15',
                          simUnfreezeTimeStamp: '',
                          isBlocked: 'Y',
                          simFreezeDetails: 'QQ',
                        },
                      },
                    ],
                    fiosEligibilityCategory: '',
                    accountAddress: {
                      zipCode: '67209',
                      zipCodePlus4: '1001',
                      fipsCode: '2017379000',
                      addressLine1: '218 S  CARDINGTON ST S',
                      addressLine2: '',
                      city: 'WICHITA',
                      state: 'KS',
                      scrubbedAddress: {
                        streetName: 'S CARDINGTON',
                        streetNumber: '218',
                        streetType: 'ST',
                        streetDirection: '',
                        apartmentNo: '',
                        pobox: '',
                        ruralDeliveryNo: '',
                        ruralRouteNo: '',
                        city: 'WICHITA',
                        state: 'KS',
                        zipCode: '67209',
                        zipCodePlus4: '4108',
                      },
                    },
                    accountAttributes: {
                      autopay: {
                        autoPayDiscount: '20.00',
                      },
                    },
                  },
                ],
              },
            },
          },
        },
      });

      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'fulfilled', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      jest.spyOn(domService, 'isFunctionalityEnabled').mockReturnValue(true);

      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    test('footer component with out sub account to display revieworder button', async () => {
      Emitter.emit('Conflicts_Accepted', true);
      const NewSubAccountTradeIn = await screen.getByTestId('ReviewOrder');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
    });
  });

  describe.skip(`<NewSubAccount component - ${channel}`, () => {
    const props = {
      isConnectToPlan: true,
    };
    beforeEach(() => {
      sessionStorage.clear();
      const retriveCart = { ...mockRetrieveCart };
      retriveCart.data.cart.orderDetails.customerType = 'N';
      retriveCart.data.cart.lineDetails.spendingLimitAmountExceededBy = 10000000000000;

      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        LandingResult: { data: { data: LANDING_STATE_DATA.landing } },
        CartDetailsResult: { data: retriveCart, isSuccess: true },
        FetchPricingSnapShotResult: { data: mockFetchPricingSnapshot },
        CustomerProfileResult: {
          data: {
            data: {
              customer: {
                channel: 'OMNI-TELESALES',
                billAccounts: [
                  {
                    accountAttributes: {
                      isCashOnlyExceptCO: true,
                      isCashOnlyExceptCA: true,
                      isCashOnlyExceptCC: true,
                      establishedInLastThirtyDays: true,
                    },
                  },
                ],
              },
            },
          },
        },
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'fulfilled', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      sessionStorage.setItem('newPostToPreIndicator', 'false');
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          activeSubAccountId='New Sub Account 1'
          landing={{
            activeSubAccountId: 'New Sub Account 1',
            assistedFlags: { isPYODEnabled: 'true' },
            lineDetails: {
              lineInfo: [
                {
                  payOffDeviceInfo: {
                    payOffYourDevice: {
                      documentList: {},
                    },
                  },
                },
              ],
            },
          }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });

    test('Initiate apply offers', async () => {
      const NewSubAccountTradeIn = await screen.getByTestId('Apply-Offers');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
    });
  });

  describe(`<Footer component without express checkout- ${channel}`, () => {
    const props = {
      isConnectToPlan: true,
    };
    beforeEach(() => {
      // window.sessionStorage.setItem(
      //   'APP_PROPERTIES',
      //   JSON.stringify({ isExpressCheckoutOffFFlag: 'TRUE' })
      // );
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        LandingResult: { data: { data: LANDING_STATE_DATA.landing } },
        CartDetailsResult: { data: expressRetrieveCart },
        FetchPricingSnapShotResult: mockFetchPricingSnapshot,
        retrieveAEMInfoManagerData: { data: { data: { aemInfoManagerData: { data: { aemInfo: { data: {} } } } } } },
        CustomerProfileResult: {
          data: {
            data: {
              customer: {
                channel: 'OMNI-TELESALES',
                billAccounts: [{ accountAttributes: { isCashOnlyExceptCO: true } }],
              },
            },
          },
        },
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'TRUE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_ERROR]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'fulfilled', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    test('footer component should not render Express checkout button', async () => {
      const ExpressCheckoutID = await screen.queryByTestId('ExpressCheckoutId');
      expect(ExpressCheckoutID).not.toBeInTheDocument();
    });
  });

  describe(`<Footer component without express checkout- ${channel}`, () => {
    const props = {
      isConnectToPlan: true,
    };
    const updatedFetch = JSON.parse(JSON.stringify(mockFetchPricingSnapshot));
    updatedFetch.data.data.subAccounts[1] = {
      subAccountId: 'New Sub Account 2',
      subAccountType: 'New',
      totals: {
        grandTotalDueMonthly: {
          estimatedTotal: 0,
          currentTotal: 0,
          todaysChanges: 0,
          estimatedTotalLabel: 'Estimated Monthly bill',
          currentTotalLabel: 'Current Monthly bill',
        },
        surcharges: {
          regularPrice: 0,
          discountedPrice: 0,
        },
        taxesAndFees: {
          regularPrice: 0,
          discountedPrice: 0,
        },
        addonsTotal: {
          regularPrice: 0,
          discountedPrice: 0,
        },
        monthlyTotal: {
          regularPrice: 0,
          discountedPrice: 0,
        },
        totalDueToday: {
          regularPrice: 0,
          discountedPrice: 0,
        },
        plansTotal: {
          regularPrice: 0,
          discountedPrice: 0,
        },
        devicesTotal: {
          regularPrice: 0,
          discountedPrice: 0,
        },
      },
      shared: {
        flags: {
          enableProceedToOrder: true,
          isEffectiveDateEligible: false,
          selectedEffectiveDate: null,
          serviceInEffectLaterMsg: null,
          isActionRequired: true,
        },
        addons: [],
        addonsDueMonthly: {
          regularPrice: 0,
          discountedPrice: 0,
          actualDiscount: 0,
          promos: [],
        },
        promosTotal: {
          regularPrice: 0,
          discountedPrice: 0,
          actualDiscount: 0,
          promos: [],
        },
        existingPlan: null,
        selectedPlan: null,
        totalDueMonthly: {
          regularPrice: 0,
          discountedPrice: 0,
          actualDiscount: 0,
          promos: [],
        },
        pendingChargesAndDiscounts: null,
      },
      lines: [
        {
          mtn: '8483040657',
          flags: {
            isNewLine: true,
            lineActivityType: 'AAL',
          },
          addons: [],
          addonsDueMonthly: {
            regularPrice: 0,
            discountedPrice: 0,
            actualDiscount: 0,
            promos: [],
          },
          promosTotal: {
            regularPrice: 0,
            discountedPrice: 0,
            actualDiscount: 0,
            promos: [],
          },
          balanceAmount: null,
          existingPlan: null,
          selectedPlan: null,
          dummyMtn: null,
          devicePayment: {
            label: 'Device payment',
            price: {
              regularPrice: 0,
              discountedPrice: 0,
              actualDiscount: 0,
              promos: [],
              discountedPriceLabel: 'Device payment',
            },
          },
          existingDevice: null,
          selectedDevice: null,
          accessories: [],
          totalDueMonthly: {
            regularPrice: 0,
            discountedPrice: 0,
            actualDiscount: 0,
            promos: [],
          },
          secondaryNumber: false,
          primaryNumber: false,
          pairedMtn: null,
          planPriceFromNBS: null,
          installmentContractDetail: null,
          showAddSecondNumberTile: false,
          lineLevelSavings: null,
          appliedOffers: null,
          productId: null,
          payOffYourDevice: false,
          simFreezeInfo: null,
        },
      ],
      tradeInDetail: {},
      cartItems: 0,
      tradeInItems: 0,
    };

    const updatedRetreiveCart = JSON.parse(JSON.stringify(expressRetrieveCart));
    updatedRetreiveCart.data.cart.orderDetails = {
      subAccountInfo: [
        {
          subAccountId: 'New Sub Account 2',
          subAccountDisplayName: 'New Sub Account 2',
          subAccountType: 'New',
          mtnInfo: [
            {
              mtn: '8483040657',
              isActionRequired: true,
            },
          ],
          totalDueMonthly: 0,
          totalDueToday: 0,
          totalTax: 0,
          subTotalDueToday: 0,
          subTotalDueMonthly: 0,
          estimatedNextMonthCharge: 0,
        },
      ],
    };

    beforeEach(() => {
      // window.sessionStorage.setItem(
      //   'APP_PROPERTIES',
      //   JSON.stringify({ isExpressCheckoutOffFFlag: 'TRUE' })
      // );
      window.sessionStorage.setItem('selectedSubAccountId', 'New Sub Account 2');
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        LandingResult: { data: { data: LANDING_STATE_DATA.landing } },
        CartDetailsResult: { data: updatedRetreiveCart },
        FetchPricingSnapShotResult: updatedFetch,
        retrieveAEMInfoManagerData: { data: { data: { aemInfoManagerData: { data: { aemInfo: { data: {} } } } } } },
        CustomerProfileResult: {
          data: {
            data: {
              customer: {
                channel: 'OMNI-TELESALES',
                billAccounts: [{ accountAttributes: { isCashOnlyExceptCO: true } }],
              },
            },
          },
        },
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'TRUE', 'TRUE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_ERROR]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: false }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'fulfilled', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    test('footer component should not render Express checkout button', async () => {
      const ExpressCheckoutID = await screen.queryByTestId('ExpressCheckoutId');
      expect(ExpressCheckoutID).not.toBeInTheDocument();
    });
  });

  describe(`<NewSubAccount component for SN - ${channel} secondNumberPerkDisplayFFlag true 1`, () => {
    const props = {
      isConnectToPlan: true,
      name: 'SN Prop',
    };
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          isPYODEnabled: 'FALSE',
          payOffYourDeviceRebateFFlag: 'TRUE',
          secondNumberPerkDisplayFFlag: 'TRUE',
          floridaDiscountFFlag: 'TRUE',
          fwaRetrieveCartFFlag: 'TRUE',
        }),
      );
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        CartDetailsResult: { data: snPerkwithNoBYOD },
        CustomerProfileResult: {
          data: {
            data: {
              customer: {
                channel: 'OMNI-TELESALES',
                billAccounts: [
                  {
                    accountAttributes: { isCashOnlyExceptCO: true },
                    mtns: [
                      {
                        secondaryNumber: true,
                        equipmentInfos: [
                          {
                            deviceInfo: {
                              pairedDeviceDetails: [
                                {
                                  pairedImeiMtn: '200',
                                },
                              ],
                            },
                          },
                        ],
                      },
                    ],
                  },
                ],
              },
            },
          },
        },
        // FetchPricingSnapShotResult: fetchPricingResultSN,
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE', 'TRUE', 'TRUE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'rejected', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          activeSubAccountId=''
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          landing={{ activeSubAccountId: 'New Sub Account 1' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    test('footer component with revieworder button', async () => {
      const NewSubAccountTradeIn = await screen.getByTestId('ReviewOrder');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
    });
  });
  describe(`<NewSubAccount component for SN - ${channel} secondNumberPerkDisplayFFlag true 2`, () => {
    const props = {
      isConnectToPlan: true,
      name: 'SN Prop',
    };
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          isPYODEnabled: 'FALSE',
          payOffYourDeviceRebateFFlag: 'TRUE',
          secondNumberPerkDisplayFFlag: 'TRUE',
          fwaRetrieveCartFFlag: 'TRUE',
        }),
      );
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        CartDetailsResult: { data: snPerkwithNoBYOD },
        CustomerProfileResult: {
          data: {
            data: {
              customer: {
                channel: 'OMNI-TELESALES',
                billAccounts: [
                  {
                    accountAttributes: { isCashOnlyExceptCO: true },
                    mtns: [
                      {
                        secondaryNumber: false,
                        equipmentInfos: [
                          {
                            deviceInfo: {
                              pairedDeviceDetails: [
                                {
                                  pairedImeiMtn: '200',
                                },
                              ],
                            },
                          },
                        ],
                      },
                    ],
                  },
                ],
              },
            },
          },
        },
        // FetchPricingSnapShotResult: fetchPricingResultSN,
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE', 'TRUE', 'TRUE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'rejected', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          activeSubAccountId=''
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          landing={{ activeSubAccountId: 'New Sub Account 1' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    test('footer component with revieworder button', async () => {
      const NewSubAccountTradeIn = await screen.getByTestId('ReviewOrder');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
    });
  });
  describe(`<NewSubAccount component for SN - ${channel} secondNumberPerkDisplayFFlag true 3`, () => {
    const props = {
      isConnectToPlan: true,
      name: 'SN Prop',
    };
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          isPYODEnabled: 'FALSE',
          payOffYourDeviceRebateFFlag: 'TRUE',
          secondNumberPerkDisplayFFlag: 'TRUE',
          fwaRetrieveCartFFlag: 'TRUE',
        }),
      );
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        CartDetailsResult: { data: snPerkwithNoBYOD },
        CustomerProfileResult: {
          data: {
            data: {
              customer: {
                channel: 'OMNI-TELESALES',
                billAccounts: [
                  {
                    accountAttributes: { isCashOnlyExceptCO: true },
                    mtns: [
                      {
                        secondaryNumber: true,
                        equipmentInfos: [
                          {
                            deviceInfo: {
                              pairedDeviceDetails: [
                                {
                                  pairedImeiMtn: '100',
                                },
                              ],
                            },
                          },
                        ],
                      },
                    ],
                  },
                ],
              },
            },
          },
        },
        // FetchPricingSnapShotResult: fetchPricingResultSN,
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE', 'TRUE', 'TRUE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'rejected', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          activeSubAccountId=''
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          landing={{ activeSubAccountId: 'New Sub Account 1' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    test('footer component with revieworder button', async () => {
      const NewSubAccountTradeIn = await screen.getByTestId('ReviewOrder');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
    });
  });

  describe(`<NewSubAccount component for SN - ${channel} secondNumberPerkDisplayFFlag true 4`, () => {
    const props = {
      isConnectToPlan: true,
      name: 'SN Prop',
    };
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          isPYODEnabled: 'FALSE',
          payOffYourDeviceRebateFFlag: 'TRUE',
          secondNumberPerkDisplayFFlag: 'TRUE',
          fwaRetrieveCartFFlag: 'TRUE',
        }),
      );
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        CartDetailsResult: { data: snPerkwithBYOD },
        // FetchPricingSnapShotResult: fetchPricingResultSN,
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE', 'TRUE', 'TRUE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'rejected', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          activeSubAccountId=''
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          landing={{ activeSubAccountId: 'New Sub Account 1' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    test('footer component with revieworder button', async () => {
      const NewSubAccountTradeIn = await screen.getByTestId('ReviewOrder');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
    });
  });
  describe(`<NewSubAccount component for SN - ${channel} secondNumberPerkDisplayFFlag true 5`, () => {
    const props = {
      isConnectToPlan: true,
      name: 'SN Prop',
    };
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          isPYODEnabled: 'FALSE',
          payOffYourDeviceRebateFFlag: 'TRUE',
          secondNumberPerkDisplayFFlag: 'TRUE',
          fwaRetrieveCartFFlag: 'TRUE'
        }),
      );
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        CartDetailsResult: { data: snPerkwithNoBYODNoNewLine },
        // FetchPricingSnapShotResult: fetchPricingResultSN,
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE', 'TRUE', 'TRUE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'rejected', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          activeSubAccountId=''
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          landing={{ activeSubAccountId: 'New Sub Account 1' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    test('footer component with revieworder button', async () => {
      const NewSubAccountTradeIn = await screen.getByTestId('ReviewOrder');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
    });
  });
  describe(`<NewSubAccount component for SN - ${channel} secondNumberPerkDisplayFFlag true 6`, () => {
    const props = {
      isConnectToPlan: true,
      name: 'SN Prop',
    };
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          isPYODEnabled: 'FALSE',
          payOffYourDeviceRebateFFlag: 'TRUE',
          secondNumberPerkDisplayFFlag: 'TRUE',
          fwaRetrieveCartFFlag: 'TRUE',
        }),
      );
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        CartDetailsResult: { data: snPerkwithNoBYODmutiMTN },
        // FetchPricingSnapShotResult: fetchPricingResultSN,
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE', 'TRUE', 'TRUE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'rejected', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          activeSubAccountId=''
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          landing={{ activeSubAccountId: 'New Sub Account 1' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    test('footer component with revieworder button', async () => {
      const NewSubAccountTradeIn = await screen.getByTestId('ReviewOrder');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
    });
  });

  describe(`<NewSubAccount component for SN - ${channel} secondNumberPerkDisplayFFlag true 6`, () => {
    const props = {
      isConnectToPlan: true,
      name: 'SN Prop',
    };
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          isPYODEnabled: 'FALSE',
          payOffYourDeviceRebateFFlag: 'TRUE',
          secondNumberPerkDisplayFFlag: 'TRUE',
          fwaRetrieveCartFFlag: 'TRUE',
        }),
      );
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        CartDetailsResult: { data: snPerkwithBYOD },
        // FetchPricingSnapShotResult: fetchPricingResultSN,
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE', 'TRUE', 'TRUE', 'TRUE', 'FALSE', 'TRUE', 'TRUE', 'TRUE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'rejected', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          activeSubAccountId=''
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          landing={{ activeSubAccountId: 'New Sub Account 1' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    test('footer component with revieworder button', async () => {
      const NewSubAccountTradeIn = await screen.getByTestId('ReviewOrder');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
    });
  });

  describe(`<NewSubAccount component for SN - ${channel} checkSnAddedWithSnPerkFFlag true 7`, () => {
    const props = {
      isConnectToPlan: true,
      name: 'SN Prop',
    };
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          isPYODEnabled: 'FALSE',
          payOffYourDeviceRebateFFlag: 'TRUE',
          secondNumberPerkDisplayFFlag: 'TRUE',
          checkSnAddedWithSnPerkFFlag: 'TRUE',
          expressCheckoutServiceBlockerFFlag: 'TRUE',
          fwaRetrieveCartFFlag: 'TRUE',
        }),
      );
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        CartDetailsResult: { data: snPerkwithNoBYODmutiMTN },
        FetchPricingSnapShotResult: mockFetchPricingSnapshot,
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['FALSE', 'TRUE', 'TRUE', 'TRUE', 'FALSE', 'TRUE', 'TRUE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'rejected', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          activeSubAccountId=''
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          landing={{ activeSubAccountId: 'New Sub Account 1' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    test('footer component with revieworder button', async () => {
      const NewSubAccountTradeIn = await screen.getByTestId('ExpressCheckoutId');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
    });
  });
  describe(`<NewSubAccount component for SN - ${channel} checkSnAddedWithSnPerkFFlag true 8`, () => {
    sessionStorage.setItem('channel', 'OMNI-INDIRECT');
    const props = {
      isConnectToPlan: true,
      name: 'SN Prop',
    };
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          isPYODEnabled: 'FALSE',
          payOffYourDeviceRebateFFlag: 'TRUE',
          secondNumberPerkDisplayFFlag: 'TRUE',
          checkSnAddedWithSnPerkFFlag: 'FALSE',
          bestBuyIntegrationFFlag: 'TRUE',
          bestBuyBlockEupAndAalComboFFlag: 'TRUE',
          expressCheckoutServiceBlockerFFlag: 'TRUE',
          fwaRetrieveCartFFlag: 'TRUE',
        }),
      );
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        CartDetailsResult: { data: snPerkwithNoBYODmutiMTN },
        FetchPricingSnapShotResult: mockFetchPricingSnapshot,
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['FALSE', 'TRUE', 'TRUE', 'TRUE', 'FALSE', 'TRUE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'rejected', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          activeSubAccountId=''
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          landing={{ activeSubAccountId: 'New Sub Account 1' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    test('footer component with revieworder button', async () => {
      const NewSubAccountTradeIn = await screen.getByTestId('ExpressCheckoutId');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
    });
  });
  describe(`<NewSubAccount component for SN - ${channel} checkSnAddedWithSnPerkFFlag true 8`, () => {
    sessionStorage.setItem('channel', 'OMNI-INDIRECT');
    const props = {
      isConnectToPlan: true,
      name: 'SN Prop',
    };
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          isPYODEnabled: 'FALSE',
          payOffYourDeviceRebateFFlag: 'TRUE',
          secondNumberPerkDisplayFFlag: 'TRUE',
          checkSnAddedWithSnPerkFFlag: 'FALSE',
          bestBuyIntegrationFFlag: 'TRUE',
          bestBuyBlockEupAndAalComboFFlag: 'TRUE',
          expressCheckoutServiceBlockerFFlag: 'FALSE',
          fwaRetrieveCartFFlag: 'TRUE',
        }),
      );
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        CartDetailsResult: { data: snPerkwithNoBYODmutiMTN },
        FetchPricingSnapShotResult: mockFetchPricingSnapshot,
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['FALSE', 'TRUE', 'TRUE', 'TRUE', 'FALSE', 'TRUE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([jest.fn(), APPLY_OFFERS_DATA]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([
        jest.fn(() => ({ status: 'rejected', data: { sendInspicioToken: 'testtoken' } })),
        jest.fn(),
      ]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);
      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          activeSubAccountId=''
          cartHasConflicts
          conflictsAccepted
          appPropertiesFromSessionStorage={{ isConflictsModalRemoved: 'TRUE' }}
          landing={{ activeSubAccountId: 'New Sub Account 1' }}
          tradeInData={{
            tradeInDueMonthlyTotal: '23.5',
            tradeInDueTodayTotal: '23.5',
          }}
          subAccountInfoFromCart={{
            subAccount: {
              subAccountId: 'New Sub Account 1',
            },
          }}
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );
    });
    test('footer component with revieworder button', async () => {
      const NewSubAccountTradeIn = await screen.getByTestId('ExpressCheckoutId');
      expect(NewSubAccountTradeIn).toBeInTheDocument();
      fireEvent.click(NewSubAccountTradeIn);
    });
  });

  describe(`Test auto-apply offers with applyOffersLandingFFlag - ${channel}`, () => {
    const props = {
      isConnectToPlan: true,
    };

    beforeEach(() => {
      sessionStorage.setItem('activeMTN', '9989898988');
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          applyOffersLandingFFlag: 'true',
          fwaRetrieveCartFFlag: 'TRUE',
        }),
      );
    });

    afterEach(() => {
      cleanup();
      sessionStorage.clear();
    });

    test('should call onapplyOffersClick when applyOffersLandingFFlag is true and items in cart', async () => {
      const mockApplyOffers = jest.fn();
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        CartDetailsResult: { data: mockRetrieveCart },
        FetchPricingSnapShotResult: mockFetchPricingSnapshot,
        CustomerProfileResult: { data: { featureFlags: {} } },
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['FALSE', 'TRUE', 'TRUE', 'TRUE', 'FALSE', 'FALSE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([mockApplyOffers, { isSuccess: true, data: { data: { errors: [] } } }]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: false }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([jest.fn(), {}]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);

      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          activeSubAccountId=''
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );

      await waitFor(() => {
        expect(mockApplyOffers).toHaveBeenCalled();
      });
    });

    test('should not call onapplyOffersClick when applyOffersLandingFFlag is false', async () => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          applyOffersLandingFFlag: 'false',
          fwaRetrieveCartFFlag: 'TRUE',
        }),
      );

      const mockApplyOffers = jest.fn();
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        CartDetailsResult: { data: mockRetrieveCart },
        FetchPricingSnapShotResult: mockFetchPricingSnapshot,
        CustomerProfileResult: { data: { featureFlags: {} } },
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['FALSE', 'TRUE', 'TRUE', 'TRUE', 'FALSE', 'FALSE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([mockApplyOffers, { isSuccess: false }]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: false }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([jest.fn(), {}]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);

      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          activeSubAccountId=''
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );

      await waitFor(() => {
        expect(mockApplyOffers).not.toHaveBeenCalled();
      });
    });

    test('should only call onapplyOffersClick once with memoized items', async () => {
      const mockApplyOffers = jest.fn();
      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        CartDetailsResult: { data: mockRetrieveCart },
        FetchPricingSnapShotResult: mockFetchPricingSnapshot,
        CustomerProfileResult: { data: { featureFlags: {} } },
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['FALSE', 'TRUE', 'TRUE', 'TRUE', 'FALSE', 'FALSE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([mockApplyOffers, { isSuccess: true, data: { data: { errors: [] } } }]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: false }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([jest.fn(), {}]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);

      const { rerender } = render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          activeSubAccountId=''
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );

      await waitFor(() => {
        expect(mockApplyOffers).toHaveBeenCalledTimes(1);
      });

      // Re-render with same data to verify it doesn't call again
      rerender(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          activeSubAccountId=''
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );

      await waitFor(() => {
        expect(mockApplyOffers).toHaveBeenCalledTimes(1); // Should still be 1, not called again
      });
    });

    test('should not call onapplyOffersClick when items in cart is 0', async () => {
      const mockApplyOffers = jest.fn();
      const emptyCartMock = JSON.parse(JSON.stringify(mockRetrieveCart));
      emptyCartMock.data.cart.lineDetails.lineInfo = [];

      CartApiCallHook.mockReturnValue({
        __esModule: true,
        ...jest.requireActual('../../pages/Cart/CartApiCallHook'),
        CartDetailsResult: { data: emptyCartMock },
        FetchPricingSnapShotResult: mockFetchPricingSnapshot,
        CustomerProfileResult: { data: { featureFlags: {} } },
      });
      useLazyGetPromoQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
      getAssistedCradlePropertyV2.mockReturnValue(['FALSE', 'TRUE', 'TRUE', 'TRUE', 'FALSE', 'FALSE', 'FALSE']);
      useApplyOffersMutation.mockReturnValue([mockApplyOffers, { isSuccess: false }]);
      useAssignMTNMutation.mockReturnValue([jest.fn(), { isSuccess: true }]);
      useLazyRetrieveAEMInfoManagerDataQuery.mockReturnValue([jest.fn(), {}]);
      useLazyGenerateInspicioIDQuery.mockReturnValue([jest.fn(), {}]);
      useLazySendMessageQuery.mockReturnValue([jest.fn(), {}]);

      render(
        <LandingFooter
          {...props}
          isRfexFlow={false}
          isTysFlow={false}
          hasSubAccount={false}
          activeSubAccountId=''
          showShoppingBagModalFn={jest.fn()}
          getAcknowledge={jest.fn()}
          getPauseResumeStandaloneCheck={jest.fn()}
          onProceedToOrderClick={jest.fn()}
          getTotalDueToday={jest.fn()}
        />,
      );

      await waitFor(() => {
        expect(mockApplyOffers).not.toHaveBeenCalled();
      });
    });
  });
};

Test(CHANNELS.OMNI_RETAIL);
Test(CHANNELS.OMNI_TELESALES);
