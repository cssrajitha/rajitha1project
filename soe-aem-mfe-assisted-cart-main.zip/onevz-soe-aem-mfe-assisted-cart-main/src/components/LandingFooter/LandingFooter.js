import React, { useState, useEffect, useMemo, useRef } from 'react';
import styled from 'styled-components';
import { Button } from '@vds/buttons';
import { Title, Body } from '@vds/typography';
import { Icon } from '@vds/icons';
import _ from 'lodash';
import { useDispatch } from 'react-redux';
import { isIpad } from 'onevzsoemfeframework/DomService';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { sendCustomEvent } from 'onevzsoemfeframework/Tagging';
import Emitter from 'onevzsoemfeframework/Emitter';
import { formatCurrency } from 'onevzsoemfecommon/Helpers';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import { useApplyOffersMutation } from 'onevzsoemfecommon/QuoteAPIService';
import { useLazyGetCustomerProfileQuery } from 'onevzsoemfecommon/APIService';
import { useAssignMTNMutation } from 'onevzsoemfecommon/AssignMtnAPIService';
import { Notification } from '@vds/notifications';
import reactDom from 'react-dom';
import ExpandFooter from './ExpandFooter';
import CartApiCallHook from '../../pages/Cart/CartApiCallHook';
import { isFunctionalityEnabled } from '../../modules/services/dom.service';
import {
  useLazyRetrieveAEMInfoManagerDataQuery,
  useLazyGenerateInspicioIDQuery,
  useLazySendMessageQuery,
} from '../../modules/services/APIService/APIServiceHooks';
import { prepareCcdApiPayload } from '../../modules/services/APIService/APIRequestBody';
import CcdModal from './CcdModal';
import { PYODModal } from './POYDModal';
import { secondNumberPerkContent } from '../AEMConstant/constant';
import { useCradleState } from '../../utils/common';
import { getnetworktype } from '../../utils/test-utils/utils';

const FooterWrapper = styled.div`
  padding: 1.25rem;
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  max-width: 1112px;
  background-color: rgb(255, 255, 255);
  z-index: 1;
  bottom: 0px;
  position: fixed;
  width: 100%;
  background-color: #ffffff;
  border-top: 1px solid rgb(0, 0, 0);
  box-sizing: border-box;
  align-items: center;
  p,
  span,
  div {
    font-family: Verizon-NHG-eDS, Helvetica, Arial, Sans-serif !important;
  }
  button.reviewOrder {
    margin-right: 20px;
  }
`;
const DueWrapper = styled.div`
  display: flex;
  width: 100%;
  align-items: center;
`;
const StyledPaddingRight8 = styled.div`
  padding-right: 0.5rem;
`;
const FlexBox = styled.div`
  display: flex;
`;

function LandingFooter(props) {
  const dispatch = useDispatch();

  const [expandFooter, setExpandFooter] = useState(false);
  const [shopLandingProps /* setShopLandingProps */] = useState(props);
  const [remindRepAboutSB, setremindRepAboutSB] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isPOYDModal, setIsPOYDModal] = useState(false);
  const [handleButtonClick, setHandleButtonClick] = useState('');
  const [isExpressCheckoutDisabled, setisExpressCheckoutDisabled] = useState(false);
  const [isConflictsAccepted, setConflictsAccepted] = useState(false);
  const [affirmChecked, setAffirmChecked] = useState(false);
  const [AssignMTN] = useAssignMTNMutation();

  console.log(isModalOpen, isPOYDModal);

  const { CustomerProfileResult, CartDetailsResult, FetchPricingSnapShotResult } = CartApiCallHook();

  const landingBillAccounts = CustomerProfileResult?.data?.data?.customer?.billAccounts[0] || {};
  const customerInfo = CustomerProfileResult?.data?.data?.customer || {};
  const cartDetails = CartDetailsResult?.data?.data?.cart || {};

  const fetchPricingSnapshotLinesInfo = FetchPricingSnapShotResult?.data?.data || {};
  // const accountDetails = customerInfo?.billAccounts[0] || {};// need to check. are we referring to correct account details?
  const [applyOffers, ApplyOffersResult] = useApplyOffersMutation();
  const [generateInspicioID] = useLazyGenerateInspicioIDQuery();
  const [retrieveAEMInfoManagerData] = useLazyRetrieveAEMInfoManagerDataQuery();
  const [sendMessage] = useLazySendMessageQuery();
  const [showCcdModal, setShowCcdModal] = useState(false);
  const [ccdData, setCcdData] = useState({});
  const billUsageTaggingFFlag = /true/i.test(
    JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.billUsageTaggingFFlag,
  );
  const assistedFlags = JSON.parse(
    sessionStorage.getItem('APP_PROPERTIES') ? sessionStorage.getItem('APP_PROPERTIES') : '{}',
  );
  const retrieveCartFFlag = assistedFlags?.fwaRetrieveCartFFlag === 'TRUE';
  // Cradle
  const [
    ccdForServiceChange,
    IS_VALID_USER,
    ccdRemarksForServiceChange,
    vtCreditCheckFFlag,
    isExpressCheckoutOffFFlag,
    secondNumberPerkDisplayFFlag,
    nseByodSuppressBannerFFlag,
  ] = getAssistedCradlePropertyV2([
    'ccdForServiceChange',
    'IS_VALID_USER',
    'ccdRemarksForServiceChange',
    'vtCreditCheckFFlag',
    'isExpressCheckoutOffFFlag',
    'secondNumberPerkDisplayFFlag',
    'nseByodSuppressBannerFFlag',
  ]);
  useEffect(() => {
    if (FetchPricingSnapShotResult?.data?.data) {
      Emitter.emit('Update_FetchPricing', FetchPricingSnapShotResult?.data?.data?.subAccounts || []);
    }
  }, [FetchPricingSnapShotResult]);

  useEffect(() => {
    Emitter.on('Conflicts_Accepted', (newValue) => {
      setConflictsAccepted(newValue);
    });
    return () => {
      Emitter.off('Conflicts_Accepted');
    };
  }, []);

  // const [grandTotalDueMonthly1, setMonthly] = useState(0);

  const accountDetails = {
    sharedAttributes: {
      ...(FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.shared || {}),
    },
    isOverThreshHold: landingBillAccounts?.accountAttributes?.isOverThreshHold,
    cartNBSNextBillTotals: FetchPricingSnapShotResult?.data?.data?.subAccounts
      ? FetchPricingSnapShotResult?.data?.data?.subAccounts[0]?.cartNBSNextBillTotals
      : {},
    paymentRestriction: {
      isCashOnly: landingBillAccounts?.accountAttributes?.isCashOnly,
      isCashOnlyExceptCC: landingBillAccounts?.accountAttributes?.isCashOnlyExceptCC,
      isCashOnlyExceptCO: landingBillAccounts?.accountAttributes?.isCashOnlyExceptCO,
      isCashOnlyExceptCA: landingBillAccounts?.accountAttributes?.isCashOnlyExceptCA,
    },
    grandTotals: FetchPricingSnapShotResult?.data?.data?.subAccounts
      ? FetchPricingSnapShotResult?.data?.data?.subAccounts[0]?.totals
      : {},
  };

  // const { appPropertiesFromSessionStorage = {} } = shopLandingProps;
  const landing = {
    ...fetchPricingSnapshotLinesInfo,
    lineDetails: cartDetails?.lineDetails,
    cartDetails,
    accountDetails,
  };

  const tradeIn = cartDetails?.lineDetails?.tradeInDetail?.tradeInItems;

  const { pastdueValue = 0 } = landing;

  const billAccounts = customerInfo?.billAccounts?.[0]?.accountAttributes || {};

  const pastDuevalue = landing?.pastdueValue;

  const MiniCart = cartDetails?.lineDetails?.lineInfo;
  const isPOYDEnabled = /true/i.test(assistedFlags?.isPYODEnabled);
  const isPayOffYourDeviceRebateFFlag = /true/i.test(assistedFlags?.payOffYourDeviceRebateFFlag);
  const idVerifyStatus = landing?.mitekIdVerifyStatus;

  console.log(landing);

  // const cartLineInfo = cartDetails?.lineDetails?.lineInfo || [];
  const fpsPayOffYourDeviceLines = landing?.subAccounts?.[0]?.lines?.filter((line) => line?.payOffYourDevice === true);
  const cartPayOffYourDeviceLines = landing?.lineDetails?.lineInfo?.filter((line) => {
    const filteredCartMtns = fpsPayOffYourDeviceLines?.some((fpsLine) => fpsLine?.mtn === line?.mobileNumber);
    return filteredCartMtns;
  });
  const isPayOff = cartPayOffYourDeviceLines?.filter(
    (x) => !x?.payOffDeviceInfo || x?.payOffDeviceInfo?.billUploaded === false,
  );

  // Subaccount flow
  const hasSubAccountFromCart = CartDetailsResult?.data?.data?.cart?.orderDetails?.subAccountInfo?.length > 0 || false;

  const isDFo =
    cartDetails?.orderDetails?.accessoryFinancingOfferInfo?.splitPaymentInfo &&
    cartDetails?.orderDetails?.accessoryFinancingOfferInfo?.splitPaymentInfo?.filter((data) => data.isDfo).length > 0;

  const [getCustomerDetail, customerDetails] = useLazyGetCustomerProfileQuery();
  const [isReviewOrderClick, setIsReviewOrderClick] = useState(false);
  const [warningContent, setWarningContent] = useState('');
  const [warnningBanner, setWarnningBanner] = useState(false);

  useEffect(() => {
    Emitter.on('Set_Express_Checkout_Disabled', (data) => {
      if (data) setisExpressCheckoutDisabled(true);
    });

    return () => {
      Emitter.off('Set_Express_Checkout_Disabled');
    };
  }, []);

  const proceedClick = () => {
    if (handleButtonClick === 'Apply') {
      onapplyOffersClick();
    } else if (handleButtonClick === 'Review') {
      handleReviewOrderClick({ isProceedToOrderPath: true });
    }
  };

  const onGoBack = () => {
    setIsPOYDModal(false);
    setHandleButtonClick('');
  };

  const formatMTN = (number, separator) => {
    const validSeparator = separator || '.';
    return number?.toString().replace(/(\d{3})(\d{3})(\d{4})/, `$1${validSeparator}$2${validSeparator}$3`);
  };

  const displayLineAndMTN = (lineinfo) => {
    const formattedText = lineinfo?.map(
      (line) =>
        `${
          line?.serviceInfo?.primaryUserInfo?.firstName
            ? `${line?.serviceInfo?.primaryUserInfo?.firstName
                ?.charAt(0)
                .toUpperCase()}${line?.serviceInfo?.primaryUserInfo?.firstName?.slice(1).toLowerCase()}`
            : ''
        } ${
          line?.serviceInfo?.primaryUserInfo?.lastName
            ? `${line?.serviceInfo?.primaryUserInfo?.lastName
                ?.charAt(0)
                .toUpperCase()}${line?.serviceInfo?.primaryUserInfo?.lastName?.slice(1).toLowerCase()}`
            : ''
        } | ${formatMTN(line?.mobileNumber)}`,
    );
    if (formattedText?.length === 1) {
      return formattedText[0];
    }
    // const allButLast = formattedText.slice(0, -1).join(', ');
    // const lastItem = formattedText[formattedText.length - 1];
    // const displayText = `${allButLast} and ${lastItem}`;
    // return displayText;
  };

  const getPlanCount = () => {
    let planCount = 0;
    let sharePlanCount = 0;
    let linePlanCount = 0;
    let featuresCount = 0;
    const serviceInfo = cartDetails?.lineDetails?.lineInfo?.reduce((outArr, lineInf) => {
      if (lineInf?.serviceInfo) {
        return [...outArr, lineInf.serviceInfo];
      }
      return outArr;
    }, []);
    // plan count includes line level and share plan
    const sharePlan = serviceInfo?.filter(
      (item) => item.isSharePlanAdded && item?.selectedALPShareList?.newAlpShareInfo,
      // return item.mtn !== "9999999999" && item.mea !=="NIG" && item;
    );
    sharePlanCount = sharePlan?.length || 0;
    const linePlan = serviceInfo?.filter(
      (item) => item.isSharePlanAdded === false && item.newPricePlanId && item.newPricePlanInfo,
    );
    linePlanCount = linePlan?.length || 0;
    // plan count end

    // feature count
    serviceInfo?.map((item) => {
      if (_.has(item, 'selectedFeaturesList')) {
        const feature = item.selectedFeaturesList.visFeature;

        const validFeature = feature.filter(
          (d) => d.addDeleteInd === 'A' && d.customerSelected === 'Y' && d.type === 'SFO' && d.source === 'USER',
        );

        const validSPOFeature = feature.filter(
          (d) => d.addDeleteInd === 'A' && d.customerSelected === 'Y' && d.type === 'SPO' && d.source === 'USER',
        );
        const validSPOFeatureLength = validSPOFeature?.length || 0;
        const validFeatureLength = validFeature?.length || 0;
        const count = validSPOFeatureLength + validFeatureLength;
        featuresCount += count;
      }
      return item;
    });
    // feature count end

    planCount = sharePlanCount + linePlanCount + featuresCount;
    return planCount;
  };

  const getCartUpgradeFee = () => {
    const itemsInfo = cartDetails?.lineDetails?.lineInfo?.reduce((outArr, lineInf) => {
      if (lineInf?.itemsInfo) {
        return [...outArr, lineInf.itemsInfo];
      }
      return outArr;
    }, []);
    let upgradeFeeCount = 0;

    itemsInfo?.forEach((itemInfo) => {
      itemInfo.forEach((info) => {
        upgradeFeeCount +=
          info?.cartItems?.cartItem?.filter((item) => item && item.cartItemType === 'UPGRADE_FEE')?.length || 0;
      });
    });
    return upgradeFeeCount;
  };

  const getItemsInfo = () =>
    MiniCart?.reduce(
      (outArr, lineInf) => (lineInf && lineInf?.itemsInfo ? outArr.concat(...lineInf.itemsInfo) : outArr),
      [],
    );

  const getCartItems = () => {
    const itemsInfo = getItemsInfo();
    return itemsInfo?.reduce((outArr, itemsInf) => {
      outArr.push(itemsInf);
      return outArr;
    }, []);
  };

  const getCartItemCount = (fromCartIcon = false) => {
    const cartItems = getCartItems();
    const cartItemCount = cartItems?.reduce((total, cartItem) => {
      let totalCount = total + (cartItem?.itemCount || 0);
      if (cartItem?.itemCount === 0) {
        if (
          cartItem &&
          cartItem?.cartItems &&
          cartItem?.cartItems?.cartItem &&
          cartItem?.cartItems?.cartItem.some(
            (item) =>
              item?.cartItemType === 'SIM' ||
              (item?.prodCode1 &&
                item?.prodCode1 === 'LAB' &&
                item?.prodCode2 &&
                item?.prodCode2 === 'SER' &&
                item?.prodCode4 &&
                item?.prodCode4 === 'SUG' &&
                fromCartIcon),
          )
        ) {
          totalCount += 1;
        }
      }
      //  else if (fromCartIcon) {
      //   if (cartItem && cartItem?.cartItems && cartItem?.cartItems?.cartItem &&
      //     cartItem?.cartItems?.cartItem.some(item =>
      //       (item.prodCode1 && item.prodCode1 === 'LAB' && item?.prodCode2 && item?.prodCode2 === 'SER' && item?.prodCode4 && item?.prodCode4 === 'SUG'))) {
      //     totalCount += 1;
      //   }
      // }
      return totalCount;
    }, 0);
    return cartItemCount;
  };

  const tradeInCount = tradeIn?.length || 0;
  const itemsInCart = (getCartItemCount() || 0) + getPlanCount() + getCartUpgradeFee();
  const customerType = cartDetails?.orderDetails?.customerType;

  const { isCashOnlyExceptCC = false, isCashOnlyExceptCO = false } = billAccounts;
  const { subTotalDueToday = '-' } = cartDetails?.orderPricing || {};
  const isExpressCheckout = landing?.flags?.isExpressCheckout && isExpressCheckoutOffFFlag !== 'TRUE'; // isExpressCheckoutOffFFlag is TRUE then turn off express checkout
  const isAccountLevelFeaturesAdded = cartDetails?.lineDetails?.acctMcsSubscription?.length > 0;
  const isOverThreshHold = accountDetails?.isOverThreshHold;
  const isCashOnlyAccount =
    customerInfo?.channel === 'OMNI-TELESALES' && (isCashOnlyExceptCC || isCashOnlyExceptCO) && subTotalDueToday > 0;
  const isActionRequiredTrueAccount =
    landing?.subAccounts?.length > 0 &&
    landing?.subAccounts?.filter((subAccount) => subAccount?.shared?.flags?.isActionRequired === true);
  const isprepaycart = cartDetails?.orderDetails?.isPrePayCart === 'Y';

  const grandTotalDueMonthlyAllSubAcc = landing?.subAccounts?.map(
    (rec) => rec.totals?.grandTotalDueMonthly.estimatedTotal,
  );
  const grandTotalDueMonthly = grandTotalDueMonthlyAllSubAcc?.reduce((temp, sum) => temp + sum, 0);

  const cartNBSNextBillTotals = accountDetails?.cartNBSNextBillTotals; // need to check
  const nextBillGrandTotal = cartNBSNextBillTotals?.grandTotal || 0.0;

  const activeSubAccountIdvalue = sessionStorage.getItem('selectedSubAccountId');
  const subAccountInfo = FetchPricingSnapShotResult?.data?.data?.subAccounts?.filter(
    (rec) => rec?.subAccountId === activeSubAccountIdvalue,
  );
  const retrieveCartSubAccountInfo = CartDetailsResult?.data?.data?.cart?.orderDetails?.subAccountInfo?.filter(
    (rec) => rec?.subAccountId === activeSubAccountIdvalue,
  );

  let dueMonthly;
  if (subAccountInfo?.length > 0) {
    dueMonthly = subAccountInfo?.[0]?.totals?.grandTotalDueMonthly?.estimatedTotal;
  } else {
    dueMonthly = grandTotalDueMonthly;
  }

  let dueToday;
  if (retrieveCartSubAccountInfo?.length > 0) {
    dueToday = retrieveCartSubAccountInfo?.[0]?.totalDueToday;
  } else {
    dueToday = cartDetails?.orderDetails?.totalDueToday;
  }

  const dueTodayFormatted = formatCurrency(dueToday);
  useEffect(() => {
    if (billUsageTaggingFFlag) {
      let vzdl = window?.vzdl || {};
      if (!vzdl?.event?.value) {
        vzdl = { ...vzdl, event: { value: '' } };
      }
      /* istanbul ignore else */
      if (vzdl) {
        vzdl.event.value = `event308=${dueToday}`;
      }
      sendCustomEvent('pageView', vzdl);
      window.vzdl = vzdl;
      console.log('vzdl event value for dueToday', { vzdl: window.vzdl });
    }
  }, [dueToday]);

  const hasCalledApplyOffers = useRef(false);
  const memoizedItemsInCart = useMemo(() => itemsInCart, [cartDetails]);
  const applyOffersLandingFFlag = /true/i.test(assistedFlags?.applyOffersLandingFFlag);
  useEffect(() => {
    if (applyOffersLandingFFlag && memoizedItemsInCart > 0 && !hasCalledApplyOffers.current) {
      hasCalledApplyOffers.current = true;
      onapplyOffersClick();
    }
  }, [memoizedItemsInCart]);

  let isStandAloneEdgeUpFlow = false;
  let downPaymentFlag = '';
  let minDownPaymentFlag = '';
  let minOneLineonDP = false;
  let totalDownPaymentAmount = 0.0;
  let minimumDownPaymentRequired = [];
  let minimumDownPaymentNotPaid = [];

  if (cartDetails?.lineDetails?.lineInfo?.[0]) {
    minimumDownPaymentRequired = cartDetails?.lineDetails?.lineInfo?.filter(
      (line) => line?.ispuDownPaymentAdjstRequired,
    );
  }
  const lineDet = cartDetails?.lineDetails?.lineInfo || [];
  // Express Checkout
  const isAddALineExists = cartDetails?.lineDetails?.numofLinesAAL > 0 || false;
  let simProtectionStatus = '';
  let simProtectionEnabledRemovedSubTitle = '';
  const lineDetailSimFreezeData = landingBillAccounts?.mtns?.filter((item) =>
    lineDet.map((mtns) => mtns.mobileNumber).includes(item.mtn),
  );
  if (lineDetailSimFreezeData) {
    const selectedlineDetailSimFreezeData = lineDetailSimFreezeData?.filter(
      (simFreezeData) => simFreezeData?.simFreezeInfo?.isBlocked === 'Y',
    );
    /* istanbul ignore else */
    if (selectedlineDetailSimFreezeData?.length > 0) {
      simProtectionStatus = selectedlineDetailSimFreezeData[0]?.simFreezeInfo;
      simProtectionEnabledRemovedSubTitle = `SIM Protection was recently removed from this line but the protection period has not yet expired. To upgrade or complete SIM change, please retry this transaction after ${simProtectionStatus?.simUnfreezeTimeStamp}.Please refresh this page if updates have already been made.`;
    }
  }
  const dpLines = lineDet.map((line) => {
    const lineArray = [];
    if (line?.itemsInfo?.length > 0) {
      line?.itemsInfo.forEach((item) => {
        item?.cartItems?.cartItem?.forEach((cartItem) => {
          const filterLine =
            cartItem?.cartItemType === 'DEVICE' && cartItem?.priceType === 'VERIZON_EDGE' ? line : null;
          if (filterLine !== undefined && filterLine !== null) lineArray?.push(filterLine);
          if (filterLine !== undefined && filterLine !== null) {
            minOneLineonDP = true;
          }
        });
      });
    }
    return lineArray;
  });
  if (dpLines !== undefined && dpLines && dpLines?.length > 0) {
    dpLines.forEach((dpLine) => {
      const downPaymentAmount =
        dpLine?.length > 0 && dpLine[0]?.installmentInfo && dpLine[0]?.installmentInfo.downPayment
          ? dpLine[0]?.installmentInfo?.downPayment
          : 0.0;
      totalDownPaymentAmount += parseFloat(downPaymentAmount);
      minimumDownPaymentNotPaid = cartDetails?.lineDetails?.lineInfo.filter(
        (line) => line?.ispuDownPaymentAdjstRequired && downPaymentAmount < line?.ispuDownPaymentAmount,
      );
    });
    const newCustomerWithoutCredit = cartDetails?.orderDetails?.quoteWithoutCredit;
    downPaymentFlag =
      !newCustomerWithoutCredit &&
      minOneLineonDP === true &&
      cartDetails?.lineDetails?.spendingLimitAmountExceededBy > totalDownPaymentAmount
        ? 'true'
        : 'false';

    minDownPaymentFlag = !!(
      minOneLineonDP === true &&
      cartDetails?.lineDetails &&
      customerType === 'N' &&
      minimumDownPaymentRequired?.length > 0 &&
      minimumDownPaymentNotPaid?.length > 0
    );
  }

  const getPaymentRestrictionKey = (accountDetailsParam) => {
    const paymentRestriction = (accountDetailsParam || {}).paymentRestriction || {};

    return (
      (paymentRestriction.isCashOnly && paymentRestriction.isCashOnlyExceptCO && 'isCashOnlyExceptCO') ||
      (paymentRestriction.isCashOnly && paymentRestriction.isCashOnlyExceptCA && 'isCashOnlyExceptCA') ||
      (paymentRestriction.isCashOnly && paymentRestriction.isCashOnlyExceptCC && 'isCashOnlyExceptCC') ||
      (paymentRestriction.isCashOnly && 'isCashOnly')
    );
  };
  /* Disabling ProceedToOrder Button In StandAloneEdegeUp Flow -- Start */

  /* Filtering edgeUp lines from cart response */
  const edgeUpLinesInCart = lineDet?.filter((line) => line?.edgeUpDetail);

  const filteredEdgeUpLinesInCart = [];

  edgeUpLinesInCart?.forEach((line) => {
    if (line?.itemsInfo?.length > 0) {
      line?.itemsInfo?.forEach((item) => {
        const itemInfo = item?.cartItems?.cartItem?.length > 0 ? item?.cartItems?.cartItem : [];
        const filteredItemsInfo =
          itemInfo?.length > 0 &&
          itemInfo.filter((cartItem) => cartItem?.itemCode === 'EDGERL' || cartItem?.itemCode === 'EDGEUPPMT');
        const filterLine = filteredItemsInfo?.length === 2 && item?.cartItems?.cartItem?.length === 2 ? line : null;
        if (filterLine !== undefined && filterLine !== null) {
          filteredEdgeUpLinesInCart.push(filterLine);
        }
      });
    }
  });

  /* Disabling proccedToOrder button when the numberOfLines cart matches the number of filteredEdgeUpLinesInCart */
  if (filteredEdgeUpLinesInCart?.length > 0 && filteredEdgeUpLinesInCart?.length === lineDet?.length) {
    isStandAloneEdgeUpFlow = true;
  }
  /* Disabling ProceedToOrder Button In StandAloneEdegeUp Flow -- End */
  const isRfexFlow =
    (sessionStorage.getItem('refundexchange') && sessionStorage.getItem('refundexchange') === 'true') || false;

  let isProceedToOrderDisabled = true;
  if (!isRfexFlow && (downPaymentFlag === 'true' || minDownPaymentFlag)) {
    isProceedToOrderDisabled = true;
  } else {
    if (
      (isAccountLevelFeaturesAdded ||
        itemsInCart > 0 ||
        tradeInCount ||
        cartDetails?.lineDetails?.lineInfo?.length > 0) &&
      (isOverThreshHold === null || isOverThreshHold === false || isOverThreshHold === undefined) &&
      !isCashOnlyAccount &&
      isStandAloneEdgeUpFlow === false
    ) {
      isProceedToOrderDisabled = false;
    }
    if (
      customerInfo?.channel === 'OMNI-TELESALES' &&
      cartDetails?.orderPricing?.dueToday > 0 &&
      getPaymentRestrictionKey(accountDetails) === 'isCashOnly'
    ) {
      isProceedToOrderDisabled = true;
    }
    if ((shopLandingProps?.hasSubAccount || hasSubAccountFromCart) && isActionRequiredTrueAccount?.length > 0) {
      isProceedToOrderDisabled = true;
    }
  }

  const handleExpand = () => {
    setExpandFooter(!expandFooter);
  };
  /* istanbul ignore next */
  const CcdAemInfoApi = async () => {
    const checkSnAddedWithSnPerkFFlag = /true/i.test(assistedFlags?.checkSnAddedWithSnPerkFFlag);
    if (checkSnAddedWithSnPerkFFlag && validateCartForAlerts()) {
      return;
    }
    if (IS_VALID_USER === 'TRUE' && !isAddALineExists) {
      console.log('called');
    }
    if (
      IS_VALID_USER === 'TRUE' &&
      !isAddALineExists &&
      (simProtectionStatus?.simFreezeCode === 'F' || simProtectionStatus?.simFreezeCode === 'N') &&
      simProtectionStatus?.isBlocked === 'Y'
    ) {
      // will display simfreeze banner in account repo
      Emitter.emit('Render_SimFreezer_banner', {
        simProtectionEnabledTitle: 'simProtectionEnabledTitle',
        simProtectionEnabledSubTitle:
          'SIM changes and upgrades are restricted. Customer must disable via My Verizon before processing.Please refresh this page if updates have already been made.',
        simProtectionStatus,
        simProtectionEnabledRemovedSubTitle,
        isSimfreezeModal: true,
      });
      return false;
    }
    const lineDetails = cartDetails?.lineDetails;
    const requestPayload = prepareCcdApiPayload(lineDetails, false);
    try {
      const res = await retrieveAEMInfoManagerData({ body: requestPayload });
      if (res?.data) {
        setShowCcdModal(true);
        setCcdData(res?.data);
      } else {
        setShowCcdModal(false);
      }
    } catch (error) {
      console.log(`error while fetching retrieveAEMInfoManagerData, ${error}`);
    }
  };

  const checkingSubAccountEligible = () => {
    const hasSubAccount = shopLandingProps?.hasSubAccount;
    const activeSubAccountId = shopLandingProps?.activeSubAccountId || '';
    let isSubActReviewOrderButtonDisplay = false;
    if (hasSubAccount && activeSubAccountId !== '') {
      isSubActReviewOrderButtonDisplay = true;
    }

    return isSubActReviewOrderButtonDisplay;
  };

  const reviewOrderSubAccount = () => {
    //   if (appPropertiesFromSessionStorage?.isConflictsModalRemoved === 'TRUE' && shopLandingProps?.cartHasConflicts) {
    //     if (shopLandingProps?.conflictsAccepted) {
    //       // dispatch(landingActions.setActiveSubAccount(''));
    //     } else {
    //       // shopLandingProps?.makeConflictsCall('ReviewOrder-SubAccount');
    //     }
    //   } else {
    //     // dispatch(landingActions.setActiveSubAccount(''));
    //   }
  };

  const reviewOrderClick = (isProceedToOrderPath) => {
    if (cartDetails?.cartHasConflicts) {
      if (isConflictsAccepted || cartDetails?.conflictsAccepted) {
        Emitter.emit('Invoke_on_proceed_to_order_click', {
          pastDuevalue,
          isExpressCheckout,
          isexpressCheckoutPath: false,
          isProceedToOrderPath,
          cartDetails,
          customerInfo,
        });
      } else {
        Emitter.emit('Render_Conflicts_Page', true);
      }
    } else {
      Emitter.emit('Invoke_on_proceed_to_order_click', {
        pastDuevalue,
        isExpressCheckout,
        isexpressCheckoutPath: false,
        isProceedToOrderPath,
        cartDetails,
        customerInfo,
      });
    }
  };

  function isDeviceOrUpgradeFn(lineInfo) {
    let isDeviceOrUpgrade = false;
    lineInfo.forEach((line) => {
      if (line?.itemsInfo?.length > 0) {
        line.itemsInfo.forEach((item) => {
          const itemInfo = item?.cartItems?.cartItem?.length > 0 ? item.cartItems.cartItem : [];
          if (itemInfo?.length > 0) {
            itemInfo.forEach((cartItem) => {
              if (cartItem?.cartItemType === 'DEVICE' || cartItem?.cartItemType === 'UPGRADE_FEE') {
                isDeviceOrUpgrade = true;
              }
            });
          }
        });
      }
    });

    return isDeviceOrUpgrade;
  }

  const sendLineDetails = async () => {
    const request = {
      clientName: customerInfo.channel,
      lov: true,
      offsetMin: '',
      delay: '',
    };
    const response = await generateInspicioID({ body: request, spinner: false });
    if (response?.status === 'fulfilled' && response?.data?.sendInspicioToken?.length > 0) {
      const params = {
        clientId: response?.data?.sendInspicioToken,
        cluster: 'S',
        event: 'selectedDevices',
        payload: {
          lineDetails: cartDetails?.lineDetails,
          cartId: fetchPricingSnapshotLinesInfo?.flags?.cartId,
        },
      };
      sendMessage({ body: params, spinner: false });
    }
  };
  const formatMtnWithDecimals = (mtn) => {
    let formattedMtn = mtn.toString();
    formattedMtn = `${formattedMtn.substring(0, 3)}.${formattedMtn.substring(3, 6)}.${formattedMtn.substring(6, 10)}`;
    return formattedMtn;
  };
  const getSnPerkLinesFromCart = () => {
    if (nseByodSuppressBannerFFlag === 'TRUE') {
      const BYODLineAcitivityTypes = ['BYOD', 'NSEBYOD'];
      return cartDetails?.lineDetails?.lineInfo?.filter(
        (line) =>
          !_.isEmpty(
            line?.serviceInfo?.selectedFeaturesList?.visFeature?.find(
              (feature) =>
                feature?.categoryCodes?.includes(secondNumberPerkContent?.categoryCode) &&
                feature?.addDeleteInd === 'A',
            ),
          ) && !BYODLineAcitivityTypes.includes(line?.lineActivityType),
      );
    }
    return cartDetails?.lineDetails?.lineInfo?.filter(
      (line) =>
        !_.isEmpty(
          line?.serviceInfo?.selectedFeaturesList?.visFeature?.find(
            (feature) =>
              feature?.categoryCodes?.includes(secondNumberPerkContent?.categoryCode) && feature?.addDeleteInd === 'A',
          ),
        ) && line?.lineActivityType !== 'BYOD',
    );
  };

  const getFirstNumberList = () => {
    const firstNumbers = [];

    cartDetails?.lineDetails?.lineInfo?.forEach((item) => {
      if (item?.secondNumber?.isSecondNumber) {
        firstNumbers.push(item?.secondNumber?.primaryMtn);
      }
    });

    customerInfo?.billAccounts?.[0]?.mtns?.forEach((item) => {
      if (item?.secondaryNumber) {
        const pairedImeiMtn = item?.equipmentInfos?.[0]?.deviceInfo?.pairedDeviceDetails?.[0]?.pairedImeiMtn;
        if (pairedImeiMtn && firstNumbers.indexOf(pairedImeiMtn) === -1) {
          firstNumbers.push(pairedImeiMtn);
        }
      }
    });

    return firstNumbers;
  };

  const validateCartForAlerts = () => {
    const snPerkLinesFromCart = getSnPerkLinesFromCart();
    if (snPerkLinesFromCart?.length > 0) {
      const firstNumbers = getFirstNumberList();
      const snPerkConstraintCart =
        snPerkLinesFromCart?.length > 0 &&
        snPerkLinesFromCart?.filter((item) => !firstNumbers?.includes(item?.mobileNumber))?.map((x) => x?.mobileNumber);
      const snPerkAlertMtns = [...new Set([...snPerkConstraintCart])];
      if (snPerkAlertMtns?.length > 0) {
        const snPerkAlertLinesFormatted = snPerkAlertMtns?.map((mtn) =>
          mtn?.toLowerCase()?.includes('newline') ? mtn : formatMtnWithDecimals(mtn),
        );
        let alertMessage = secondNumberPerkContent?.reviewOrderAlert?.message;
        if (snPerkAlertLinesFormatted?.length === 1) {
          alertMessage = alertMessage?.replace('(line(s))', 'line').replace('(MTN(s))', snPerkAlertLinesFormatted[0]);
        } else {
          alertMessage = alertMessage
            ?.replace('(line(s))', 'lines')
            .replace('(MTN(s))', snPerkAlertLinesFormatted.join(', '));
        }
        dispatch(appMessageActions.addAppMessage(alertMessage, 'error', true, true));
        return true;
      }
    }
  };

  const handleReviewOrderClick = ({ isProceedToOrderPath = true }) => {
    if (secondNumberPerkDisplayFFlag === 'TRUE' && validateCartForAlerts()) {
      return;
    }
    if (vtCreditCheckFFlag === 'TRUE') {
      sendLineDetails();
    }
    const customerBillAccounts = customerInfo?.billAccounts;
    const youngTenureIDScanEnabled = isFunctionalityEnabled('youngTenureIDScan', '', '');
    const isAddLineOrUpgrade = isDeviceOrUpgradeFn(
      cartDetails?.lineDetails?.lineInfo ? cartDetails.lineDetails.lineInfo : [],
    );
    const isAddALine = cartDetails?.lineDetails?.numofLinesAAL > 0;
    if (isPOYDEnabled && isPayOffYourDeviceRebateFFlag && handleButtonClick !== 'Review') {
      // const infoObj = cartDetails?.lineDetails?.lineInfo.find((x) => x.payOffDeviceInfo);
      // const isPayOff = infoObj?.payOffYourDevice;
      // const documentId = infoObj?.payOffDeviceInfo?.documentList;
      // const documentIdLength = documentId?.length === 0;
      if (isPOYDEnabled && isPayOff?.length > 0) {
        setHandleButtonClick('Review');
        setIsPOYDModal(true);
      } else {
        setIsPOYDModal(false);
        setHandleButtonClick('');
        if (
          billAccounts &&
          // billAccounts.length > 0 &&
          billAccounts?.establishedInLastThirtyDays &&
          youngTenureIDScanEnabled &&
          isIpad() &&
          idVerifyStatus !== 'Approved' &&
          (isAddLineOrUpgrade || isAddALine)
        ) {
          setIsModalOpen(idVerifyStatus === 'NotApproved');
        } else {
          reviewOrderClick(isProceedToOrderPath);
        }
      }
    } else {
      setIsPOYDModal(false);
      setHandleButtonClick('');

      if (
        customerBillAccounts &&
        customerBillAccounts?.length > 0 &&
        customerBillAccounts[0]?.establishedInLastThirtyDays &&
        youngTenureIDScanEnabled &&
        isIpad() &&
        idVerifyStatus !== 'Approved' &&
        (isAddLineOrUpgrade || isAddALine)
      ) {
        setIsModalOpen(idVerifyStatus === 'NotApproved');
      } else {
        reviewOrderClick(isProceedToOrderPath);
      }
    }
  };

  const initiateApplyOffersRequest = () => {
    const request = {
      clientId: customerInfo && customerInfo.channel ? customerInfo.channel : '',
      cartCreator: customerInfo && customerInfo.lookupMtn ? customerInfo.lookupMtn : '',
      caseId: fetchPricingSnapshotLinesInfo?.flags?.caseId,
      cartId: fetchPricingSnapshotLinesInfo?.flags?.cartId,
      intendType: '',
    };
    const assistedFlexV2APIFFlag = /true/i.test(assistedFlags.assistedFlexV2APIFFlag);
    applyOffers({ body: assistedFlexV2APIFFlag ? {} : request, spinner: true });
  };

  useEffect(() => {
    if (ApplyOffersResult?.isSuccess) {
      if (ApplyOffersResult?.data?.data?.errors?.length > 0) {
        const errorMessage = ApplyOffersResult?.data?.data?.errors?.[0]?.message;
        dispatch(appMessageActions.addAppMessage(errorMessage, 'error', true, true));
      }
    }
  }, [ApplyOffersResult]);

  const onapplyOffersClick = async () => {
    if (isPOYDEnabled && isPayOffYourDeviceRebateFFlag && handleButtonClick !== 'Apply') {
      // const infoObj = landing?.lineDetails?.lineInfo.find((x) => x.payOffDeviceInfo);
      // const isPayOff = infoObj?.payOffYourDevice;
      // const documentId = infoObj?.payOffDeviceInfo?.documentList;
      // const documentIdLength = documentId?.length === 0;
      if (isPOYDEnabled && isPayOff?.length > 0) {
        setHandleButtonClick('Apply');
        setIsPOYDModal(true);
      } else {
        setIsPOYDModal(false);
        setHandleButtonClick('');
        initiateApplyOffersRequest();
      }
    } else {
      setIsPOYDModal(false);
      setHandleButtonClick('');
      initiateApplyOffersRequest();
    }
  };

  const toggleRemindRepAboutSB = () => {
    setremindRepAboutSB(!remindRepAboutSB);
  };

  const turnOffExistingSBReminder = () => {
    setremindRepAboutSB(false);
  };

  const onProceedToOrderClick = ({ isProceedToOrderPath = true }) => {
    Emitter.emit('Invoke_on_proceed_to_order_click', {
      pastDuevalue,
      isExpressCheckout,
      isexpressCheckoutPath: false,
      isProceedToOrderPath,
    });
  };

  const onProceedToOrderClickForExpreesCheckout = () => {
    const checkSnAddedWithSnPerkFFlag = /true/i.test(assistedFlags?.checkSnAddedWithSnPerkFFlag);
    const expressCheckoutServiceBlockerFFlag = /true/i.test(assistedFlags?.expressCheckoutServiceBlockerFFlag);
    if (checkSnAddedWithSnPerkFFlag && validateCartForAlerts()) {
      return;
    }
    Emitter.emit('Invoke_on_proceed_to_order_click', {
      pastDuevalue,
      isExpressCheckout: true,
      isexpressCheckoutPath: true,
      isProceedToOrderPath: false,
      ...(expressCheckoutServiceBlockerFFlag && { cartDetails, customerInfo }),
    });
  };

  const closeCcdModal = () => {
    setShowCcdModal(false);
  };
  const cradleState = useCradleState();
  const nbsFFlagState = cradleState?.data?.enableFullBlownMfeNbsPosFFlag === 'TRUE';
  console.log(nbsFFlagState);
  const appPropertiesFromSessionStorage = sessionStorage.getItem('APP_PROPERTIES');
  const nbsFFlagSessionStorage = appPropertiesFromSessionStorage
    ? JSON.parse(appPropertiesFromSessionStorage)?.enableFullBlownMfeNbsPosFFlag === 'TRUE'
    : false;
  const enableFullBlownMfeNbsPosFFlag = nbsFFlagState || nbsFFlagSessionStorage;

  let displayText = 'Current monthly';
  if (enableFullBlownMfeNbsPosFFlag) {
    displayText = 'Est. ongoing monthly';
  } else if (itemsInCart !== 0) {
    displayText = 'Est. new monthly';
  }

  const isFloridaFFlagEnabled = isFunctionalityEnabled('floridaDiscountFFlag');
  const isOfferState =
    cartDetails?.lineDetails?.localStoreOfferState === 'OfferEligible' &&
    cartDetails?.lineDetails?.florida55PlusOfferState === 'OfferEligible';

  useEffect(() => {
    if (isReviewOrderClick && customerDetails?.data) {
      const customerDetailResults = customerDetails?.data?.data;
      const featureFlags = customerDetails?.data?.featureFlags;
      const activeMtn = sessionStorage.getItem('activeMTN');
      const activeMTNObj = customerDetailResults?.customer?.billAccounts?.[0]?.mtns?.find(
        (mtnObj) => mtnObj.mtn === activeMtn,
      );
      const isHavingLineLevelVVC = activeMTNObj?.marketingOption?.vzCCHolder;
      const isHavingAccountLevelVVC = customerDetailResults?.customer?.billAccounts?.[0]?.mtns?.some(
        (mtnObj) => mtnObj?.marketingOption?.vzCCHolder === true,
      );
      if (!isHavingLineLevelVVC && !isHavingAccountLevelVVC && featureFlags?.accountLevelVVCFFlag) {
        setWarnningBanner(true);
        setWarningContent({
          title: `Verizon Visa Card Approval Pending`,
          description: `Confirm if customer has applied for the Verizon Visa Card.  If the customer was not instantly approved then select another payment option in order to continue.`,
        });
      } else {
        setWarnningBanner(false);
        setWarningContent('');
        if (featureFlags?.vvcCardLimitMFEFFlag) {
          const dueAmount = parseFloat(dueTodayFormatted?.toString().replace(/[^0-9.-]+/g, ''));
          const maxVZCardValue = customerDetailResults?.vvcCreditLimitList?.reduce(
            (max, obj) => Math.max(max, obj.availableCredit || 0),
            0,
          );
          const vvcTokens = customerDetailResults?.vvcCreditLimitList?.map((item) => ({
            crCardToken: item.crCardToken,
            isEligible:
              item.availableCredit && item.availableCredit > 0 ? Number(item.availableCredit) > dueAmount : true,
            availableCredit: item.availableCredit,
          }));
          sessionStorage.setItem('vvcTokens', JSON.stringify(vvcTokens));
          if (dueAmount > maxVZCardValue && maxVZCardValue > 0) {
            setWarnningBanner(true);
            setWarningContent({
              title: `Cart Exceeds the Available Verizon Visa Card Credit Limit`,
              description: `The cart exceeds the credit limit of ${formatCurrency(maxVZCardValue)} by ${formatCurrency(
                dueAmount - maxVZCardValue,
              )}.Select another financing option or edit cart.`,
            });
          } else {
            handleReviewOrderClick({ isProceedToOrderPath: true });
          }
        } else {
          handleReviewOrderClick({ isProceedToOrderPath: true });
        }
      }
    }
    if (isReviewOrderClick && isFloridaFFlagEnabled && isOfferState && warnningBanner) {
      setWarnningBanner(false);
      setWarningContent('');
    }
  }, [customerDetails, isReviewOrderClick]);

const pseudoMTNCallHandler = () => {
  /* istanbul ignore else */
  if (retrieveCartFFlag) {
    const isIndirectChannel = sessionStorage.getItem("channel") === "OMNI-INDIRECT";
    const lineInfo = cartDetails?.lineDetails?.lineInfo;
    const nwBandwidth = getnetworktype();
    let fwaLineIndex = -1;
    let mtnForFWA = '';
    for (let i = 0; i < lineInfo?.length; i++) {
      const currentLine = lineInfo[i];
      /* istanbul ignore else */
      if (currentLine?.deviceTypeSelected === '5G Internet' && currentLine?.mobileNumber?.startsWith('newLine')) {
        fwaLineIndex = i;
        mtnForFWA = currentLine?.lineNumber;
        break;
      }
    }
    // this insures assign-mtn call is happenng only for 5G-Internet(FWA) and for OMNI-INDIRECT channel
    /* istanbul ignore else */
    if (fwaLineIndex === -1 || nwBandwidth === '' || !isIndirectChannel) {
      return;
    }

    const requestBodyNSEassignMTN = {
      cartInfo: {
        processStep: 'InterimPage',
        processingMTN: '',
      },
      data: {
        lines: [
          {
            mtn: mtnForFWA,
            npaNxx: '00000',
            userSelectedMTN: '',
            minNumber: '',
            device: { networkBandwidthType: nwBandwidth },
          },
        ],
      },
    };
    AssignMTN({ body: requestBodyNSEassignMTN });
    dispatch({ type: 'ASSIGN_MTN_TRIGGERED', payload: true });
  }
}


  const handleDFOReviewOrderClick = () => {
    pseudoMTNCallHandler();
    const bestBuyIntegrationFFlag = /true/i.test(
      JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.bestBuyIntegrationFFlag,
    );
    const bestBuyCradleCheck = /indirect/i.test(sessionStorage.getItem('channel')) && bestBuyIntegrationFFlag;
    if (bestBuyCradleCheck) {
      const isEUPlineHave = cartDetails?.lineDetails?.lineInfo?.some(
        (line) =>
          line?.lineActivityType === 'EUP' &&
          Array.isArray(line?.itemsInfo) &&
          line?.itemsInfo?.some(
            (item) =>
              Array.isArray(item?.cartItems?.cartItem) &&
              item?.cartItems?.cartItem?.some((data) => data?.cartItemType === 'DEVICE'),
          ),
      );
      const isAALlineHave = cartDetails?.lineDetails?.lineInfo?.some(
        (line) =>
          line?.lineActivityType === 'AAL' &&
          Array.isArray(line?.itemsInfo) &&
          line?.itemsInfo?.some(
            (item) =>
              Array.isArray(item?.cartItems?.cartItem) &&
              item?.cartItems?.cartItem?.some((data) => data?.cartItemType === 'DEVICE'),
          ),
      );
      console.log('EUP and AAL check**', isEUPlineHave, isAALlineHave);
      if (isEUPlineHave && isAALlineHave) {
        dispatch(
          appMessageActions.addAppMessage(
            'The upgrade and newline combo not supported in the Local Order flow',
            'error',
            true,
            true,
          ),
        );
        return;
      }
    }
    if (isDFo && CustomerProfileResult?.data?.featureFlags?.accountLevelVVCFFlag) {
      setIsReviewOrderClick(true);
      const request = {
        customerId: customerInfo?.accountNo,
        requestFlow: 'VVC_CREDIT_LIMIT_CHECK',
        vvcCreditLimitRequired: true,
      };
      getCustomerDetail({ body: request, spinner: true });
    } else if (isFloridaFFlagEnabled && isOfferState && !warnningBanner) {
      setWarnningBanner(true);
      setIsReviewOrderClick(true);
      setWarningContent({
        title: 'No offer has been selected or applied',
      });
    } else {
      handleReviewOrderClick({ isProceedToOrderPath: true });
    }
  };
  const showWarningBanner = () => {
    const appMessageElement = document.getElementById('AppMessage');
    const warningContentBanner = (
      <Notification
        type='warning'
        title={warningContent?.title}
        subtitle={warningContent?.description}
        surface='light'
        disableAnimation={false}
        fullBleed={false}
        hideCloseButton={false}
        inline={false}
        layout={null}
        onCloseButtonClick={() => {
          setWarnningBanner(false);
        }}
      />
    );

    return appMessageElement && reactDom.createPortal(warningContentBanner, appMessageElement);
  };
  return (
    <>
      {warnningBanner && showWarningBanner()}
      {isPOYDEnabled && isPayOffYourDeviceRebateFFlag && isPOYDModal && (
        <PYODModal
          proceedClick={() => proceedClick()}
          onGoBack={() => onGoBack()}
          profileText={isPayOff?.length > 0 && displayLineAndMTN(isPayOff)}
        />
      )}
      {!expandFooter ? (
        <div>
          <FooterWrapper data-testid='dueToday'>
            <div className='footerButtonFlex'>
              <FlexBox>
                {customerInfo?.channel !== 'OMNI-CARE' && isExpressCheckout && ccdForServiceChange === 'FALSE' && (
                  <Button
                    className='reviewOrder'
                    size='large'
                    surface='light'
                    data-track='order-landing_Express checkout'
                    data-testid='ExpressCheckoutId'
                    disabled={
                      shopLandingProps?.isExpressCheckoutDisabled ||
                      landing?.enableLandingButtons ||
                      isExpressCheckoutDisabled
                    }
                    use='primary'
                    onClick={() => {
                      onProceedToOrderClickForExpreesCheckout();
                    }}
                  >
                    Express checkout
                  </Button>
                )}
                {customerInfo?.channel !== 'OMNI-CARE' && ccdForServiceChange === 'TRUE' && isExpressCheckout && (
                  <Button
                    className='reviewOrder'
                    size='large'
                    surface='light'
                    data-track='order-landing_Express checkout'
                    data-testid='ExpressCheckoutId'
                    disabled={
                      isExpressCheckoutDisabled ||
                      shopLandingProps?.isExpressCheckoutDisabled ||
                      landing?.enableLandingButtons
                    }
                    use='primary'
                    onClick={() => CcdAemInfoApi()}
                  >
                    Express checkout
                  </Button>
                )}

                {checkingSubAccountEligible() ? (
                  <Button
                    type='primary'
                    size='large'
                    width='auto'
                    surface='light'
                    data-track='order-landing_Review order'
                    className='reviewOrder'
                    disabled={isExpressCheckoutDisabled || isProceedToOrderDisabled || landing?.enableLandingButtons}
                    data-testid='ReviewOrder-SubAccount'
                    onClick={reviewOrderSubAccount}
                  >
                    Review order
                  </Button>
                ) : (
                  <Button
                    type='primary'
                    size='large'
                    width='auto'
                    surface='light'
                    data-track='order-landing_Review order'
                    className='reviewOrder'
                    disabled={isExpressCheckoutDisabled || isProceedToOrderDisabled || landing?.enableLandingButtons}
                    data-testid='ReviewOrder'
                    onClick={handleDFOReviewOrderClick}
                  >
                    Review order
                  </Button>
                )}

                {!isRfexFlow && !isprepaycart && !shopLandingProps?.isTysFlow && (
                  <Button
                    size='large'
                    use='secondary'
                    width='auto'
                    Margin-left='20px'
                    data-track='order-landing_Apply-Offers'
                    disabled={itemsInCart === 0}
                    data-testid='Apply-Offers'
                    onClick={() => onapplyOffersClick()}
                  >
                    Apply offers
                  </Button>
                )}
              </FlexBox>
            </div>
            {!isRfexFlow && (
              <StyledPaddingRight8>
                <Body size='large'>
                  <b>{itemsInCart}</b> Items
                </Body>
                <Body size='large'>
                  <b>{tradeInCount}</b> Trade-in
                </Body>
              </StyledPaddingRight8>
            )}
            {/* <StyledPaddingRight8>
              <Body size='large'>
                <b>1</b> Items
              </Body>
              <Body size='large'>
                <b>2</b> Trade-in
              </Body>
            </StyledPaddingRight8> */}

            <StyledPaddingRight8>
              <Title size='small' bold>
                {dueTodayFormatted}
              </Title>
              <Body size='medium'>Due today</Body>
            </StyledPaddingRight8>

            {/* <StyledPaddingRight8>
              <Title size='small' bold>
                {10}
              </Title>
              <Body size='medium'>Due today</Body>
            </StyledPaddingRight8> */}

            <StyledPaddingRight8>
              <Title size='small' bold>
                {formatCurrency(dueMonthly)}
              </Title>

              <Body size='medium'>{displayText}</Body>
            </StyledPaddingRight8>
            {/* <StyledPaddingRight8>
              <Title size='small' bold>
                {207}
              </Title>

              <Body size='medium'>Current monthly</Body>
            </StyledPaddingRight8> */}

            {customerType !== 'N' && itemsInCart > 0 && nextBillGrandTotal && Number(nextBillGrandTotal) > 0 ? (
              <StyledPaddingRight8>
                <Title size='small' bold>
                  {formatCurrency(nextBillGrandTotal)}
                </Title>
                <Body size='medium'>Est. next bill</Body>
              </StyledPaddingRight8>
            ) : null}

            {/* <StyledPaddingRight8>
              <Title size='small' bold>
                300
              </Title>
              <Body size='medium'>Est. next bill</Body>
            </StyledPaddingRight8> */}

            <div>
              {(itemsInCart > 0 || isExpressCheckout) && (
                <DueWrapper onClick={handleExpand}>
                  <Icon name='up-caret' size='large' />
                </DueWrapper>
              )}
            </div>
            {showCcdModal && (
              <CcdModal
                showCcdModal={showCcdModal}
                CcdData={ccdData}
                closeCcdModal={closeCcdModal}
                onProceedToOrderClickForExpreesCheckout={onProceedToOrderClickForExpreesCheckout}
                landingData={landing}
                ccdRemarksForServiceChange={ccdRemarksForServiceChange}
                customerProfileDetails={CustomerProfileResult?.data?.data}
              />
            )}

            {/* <div>
              <DueWrapper data-testid='showFooter' onClick={handleExpand}>
                <Icon name='up-caret' size='large' />
              </DueWrapper>
            </div> */}
          </FooterWrapper>
        </div>
      ) : (
        <ExpandFooter
          {...shopLandingProps}
          landing={landing}
          dueToday={dueTodayFormatted}
          isprepaycart={isprepaycart}
          isTysFlow={shopLandingProps?.isTysFlow}
          accountDetails={accountDetails}
          itemsInCart={itemsInCart}
          tradeInCount={tradeInCount}
          hideFooter={handleExpand}
          onapplyOffersClick={onapplyOffersClick}
          getAcknowledge={shopLandingProps?.getAcknowledge}
          getPauseResumeStandaloneCheck={shopLandingProps?.getPauseResumeStandaloneCheck}
          showShoppingBagModalFn={shopLandingProps?.showShoppingBagModalFn}
          pastDuevalue={pastdueValue}
          isExpressCheckout={isExpressCheckout}
          onProceedToOrderClick={onProceedToOrderClick}
          shoppingBagNotRequiredAction={shopLandingProps?.shoppingBagNotRequiredAction}
          setBagQty={shopLandingProps?.setbagSelectedQty}
          setOnDefaultBagSelected={shopLandingProps?.setOnDefaultBagSelected}
          toggleRemindRepAboutSB={toggleRemindRepAboutSB}
          turnOffExistingSBReminder={turnOffExistingSBReminder}
          remindRepAboutSB={remindRepAboutSB}
          showShoppingBagModal={shopLandingProps?.showShoppingBagModal}
          defaultBagSelected={shopLandingProps?.defaultBagSelected}
          hideShoppingBagModal={shopLandingProps?.hideShoppingBagModal}
          showAccessoryVvcModal={shopLandingProps?.showAccessoryVvcModal}
          isProceedToOrderDisabled={isProceedToOrderDisabled}
          customerType={customerType}
          affirmChecked={affirmChecked}
          setAffirmChecked={setAffirmChecked}
          FetchPricingSnapShotResult={FetchPricingSnapShotResult}
        />
      )}
    </>
  );
}
export default LandingFooter;
