import React from 'react';
import moment from 'moment/moment';
import { GetAppConfig } from 'onevzsoemfeframework/GetAppConfig';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import { render, screen, fireEvent, waitFor } from '../../utils/test-utils/renderHelper';
import { setupChannel, CHANNELS } from '../../utils/test-utils/utils';
import ExpandFooter from './ExpandFooter';
import { LANDING_STATE_DATA } from '../../mocks/landingTestData';

jest.mock(
  'onevzsoemfeframework/AssistedCradleService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getAssistedCradlePropertyV2: jest.fn(),
  }),
  { virtual: true },
);
jest.mock(
  'onevzsoemfeframework/DomService',
  () => ({
    __esModule: true,
    default: jest.fn(() => ({})),
    getQueryParamByName: () => 'false',
    isAsurion: () => false,
  }),
  { virtual: true },
);
jest.mock(
  'onevzsoemfeframework/GetAppConfig',
  () => ({
    GetAppConfig: jest.fn(),
  }),
  { virtual: true },
);
jest.mock(
  './Affirm/Affirm',
  () =>
    function () {
      return <div>Affirm componenet</div>;
    },
);

const Test = (channel) => {
  setupChannel(channel);
  sessionStorage.setItem('channel', 'OMNI-RETAIL');
  describe(`<ExpandFooter component - ${channel}`, () => {
    document.body.innerHTML = '<div id="AppMessage" data-testid="AppMessage" />';
    const props = {
      affirmChecked: false,
      setAffirmChecked: () => {},
      remindRepAboutSB: true,
      assistedFlag: {
        isBagFeeEnabled: 'TRUE',
        disableLargeBagFee: 'FALSE',
      },
      landing: {
        accountDetails: {
          sharedAttributes: {
            flags: {
              isEffectiveDateEligible: true,
              selectedEffectiveDate: '09/15/2024',
            },
          },
        },
        cartDetails: {
          lineDetails: {
            bagTax: true,
            bagFeeSku: 'MHXH3AM/A',
            lineInfo: [
              {
                itemsInfo: [
                  {
                    depletionType: 'L',
                    attention: 'JACK JONES',
                    fipsCode: '1318578800',
                    itemCount: 1,
                    itemTabSeqNum: 0,
                    cartItems: {
                      cartItem: [
                        {
                          deviceDisplayName: 'IPHONE 14 128 BLUE',
                          cartItemType: 'DEVICE',
                          priceType: 'VERIZON_EDGE',
                        },
                      ],
                    },
                  },
                ],
              },
            ],
          },
          orderDetails: {
            subAccountInfo: [
              {
                subAccountId: 'New Sub Account 1',
              },
            ],
          },
        },
        subAccounts: [
          {
            shared: {
              pendingChargesAndDiscounts: {
                discountsPendingActionDetails: {
                  apoPaperlessAmount: '5652',
                  deviceTradeInDetails: [],
                  totalPendingDiscount: -20,
                  newMonthlyTotalWithPendingDiscounts: 0,
                },
              },
            },
          },
        ],
      },
      FetchPricingSnapShotResult: {
        data: {
          data: {
            subAccounts: [
              {
                subAccountId: 'New Sub Account 1',
                totals: {
                  grandTotalDueMonthly: {
                    estimatedTotal: 400.4,
                  },
                },
              },
            ],
            ecpdType: 'Military',
            isAutoPayEnabled: true,
            isAiBillUpload: 'Y',
            ecpdDiscount: '-16.0',
          },
        },
      },
    };

    beforeEach(() => {
      getAssistedCradlePropertyV2.mockReturnValue(['FALSE']);
      sessionStorage.setItem('selectedSubAccountId', 'New Sub Account 1');
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ montanaOfferEnableFFlag: 'true' }));
      GetAppConfig.mockReturnValue({
        messages: {
          landingContent: {
            affirmAccConfig: {
              prodScript: 'https://cdn1.affirm.com/js/v2/affirm.js',
              prodPublicKey: 'T4ASH81C8QOX9LYF',
              devPublicKey: 'WE2EY1ZRWLDP08RG',
              devScript: 'https://cdn1-sandbox.affirm.com/js/v2/affirm.js',
            },
            affirmEnableContent: {
              affrimHeaderLabel: 'Affirm',
              affrimContent: 'As low as 0% APR when you pay over time with Affirm',
              affrimSeeDetailsLabel: 'See details',
            },
          },
        },
      });
      render(<ExpandFooter {...props} />);
    });

    afterEach(() => {
      jest.clearAllMocks();
    });

    test('should mount Expand Footer component', async () => {
      const vaditeShop = await screen.getAllByTestId('expandFooter')[0];
      expect(vaditeShop).toBeInTheDocument();
      fireEvent.click(vaditeShop);
      expect(screen.getByText('Order effective date is set to')).toBeInTheDocument();
    });

    test('should onClick goToOrderEffectiveDate component', async () => {
      const vaditeShop = await screen.getByRole('link', { name: 'Text Link' });
      expect(vaditeShop).toBeInTheDocument();
      fireEvent.click(vaditeShop);
    });
    test('should return estimatedTotal when isAutoPayEnabled is true', async () => {
      getAssistedCradlePropertyV2.mockReturnValue(['FALSE']);
      sessionStorage.setItem('selectedSubAccountId', 'New Sub Account 1');
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ montanaOfferEnableFFlag: 'true',enablePartialNbsPosFFlag:'TRUE' }));
      const tempprops = {
        itemsInCart: 5,
        customerType: 'PE',
        isprepaycart: false,
        affirmChecked: false,
        setAffirmChecked: () => {},
        accountDetails: {
          cartNBSNextBillTotals: {
            grandTotal: 433.03,
            totalOneTimeCharge: 94.36,
            subTotalWithoutAddons: 237.26,
            totalAddOnsSummary: 60.0,
            taxesAndFees: 13.34,
            surcharges: 28.07,
            plansTotal: 187.0,
            devicesTotal: 50.26,
          },
        },
        remindRepAboutSB: true,
        assistedFlag: {
          isBagFeeEnabled: 'TRUE',
          disableLargeBagFee: 'FALSE',
        },
        landing: {
          accountDetails: {
            sharedAttributes: {
              flags: {
                isEffectiveDateEligible: true,
                selectedEffectiveDate: '09/15/2024',
              },
            },
          },
          cartDetails: {
            lineDetails: {
              bagTax: true,
              bagFeeSku: 'MHXH3AM/A',
              lineInfo: [
                {
                  itemsInfo: [
                    {
                      depletionType: 'L',
                      attention: 'JACK JONES',
                      fipsCode: '1318578800',
                      itemCount: 1,
                      itemTabSeqNum: 0,
                      cartItems: {
                        cartItem: [
                          {
                            deviceDisplayName: 'IPHONE 14 128 BLUE',
                            cartItemType: 'DEVICE',
                            priceType: 'VERIZON_EDGE',
                          },
                        ],
                      },
                    },
                  ],
                },
              ],
            },
            orderDetails: {
              subAccountInfo: [
                {
                  subAccountId: 'New Sub Account 1',
                },
              ],
            },
          },
          subAccounts: [
            {
              shared: {
                pendingChargesAndDiscounts: {
                  discountsPendingActionDetails: {
                    apoPaperlessAmount: '5652',
                    deviceTradeInDetails: [],
                    totalPendingDiscount: -20,
                    newMonthlyTotalWithPendingDiscounts: 0,
                  },
                },
              },
            },
          ],
          ecpdType: 'Military',
            isAutoPayEnabled: true,
            isAiBillUpload: 'Y',
            ecpdDiscount: '-16.0',
        },
        FetchPricingSnapShotResult: {
          data:{
            data:{
              ecpdType: 'Military',
              isAutoPayEnabled: true,
              isAiBillUpload: 'Y',
              ecpdDiscount: '-16.0',
            }
          }
        }
      };
       
      GetAppConfig.mockReturnValue({
        messages: {
          landingContent: {
            affirmAccConfig: {
              prodScript: 'https://cdn1.affirm.com/js/v2/affirm.js',
              prodPublicKey: 'T4ASH81C8QOX9LYF',
              devPublicKey: 'WE2EY1ZRWLDP08RG',
              devScript: 'https://cdn1-sandbox.affirm.com/js/v2/affirm.js',
            },
            affirmEnableContent: {
              affrimHeaderLabel: 'Affirm',
              affrimContent: 'As low as 0% APR when you pay over time with Affirm',
              affrimSeeDetailsLabel: 'See details',
            },
          },
        },
      });
      render(<ExpandFooter {...tempprops} />);
    });
  });

  describe(`<ExpandFooter component - ${channel}`, () => {
    document.body.innerHTML = '<div id="AppMessage" data-testid="AppMessage" />';
    const props = {
      affirmChecked: false,
      setAffirmChecked: () => {},
      remindRepAboutSB: true,
      assistedFlag: {
        isBagFeeEnabled: 'TRUE',
        disableLargeBagFee: 'FALSE',
      },
      landing: {
        accountDetails: {
          sharedAttributes: {
            flags: {
              isEffectiveDateEligible: true,
              selectedEffectiveDate: '09/15/2024',
            },
          },
        },
        cartDetails: {
          lineDetails: {
            bagTax: true,
            bagFeeSku: 'MHXH3AM/A',
            lineInfo: [
              {
                itemsInfo: [
                  {
                    depletionType: 'L',
                    attention: 'JACK JONES',
                    fipsCode: '1318578800',
                    itemCount: 1,
                    itemTabSeqNum: 0,
                    cartItems: {
                      cartItem: [
                        {
                          deviceDisplayName: 'IPHONE 14 128 BLUE',
                          cartItemType: 'DEVICE',
                          priceType: 'VERIZON_EDGE',
                        },
                      ],
                    },
                  },
                ],
              },
            ],
          },
          orderDetails: {
            subAccountInfo: [
              {
                subAccountId: 'New Sub Account 1',
              },
            ],
          },
        },
        subAccounts: [
          {
            shared: {
              pendingChargesAndDiscounts: {
                discountsPendingActionDetails: {
                  apoPaperlessAmount: '5652',
                  deviceTradeInDetails: [],
                  totalPendingDiscount: -20,
                  newMonthlyTotalWithPendingDiscounts: 0,
                },
              },
            },
          },
        ],
      },
      FetchPricingSnapShotResult: {
        data: {
          data: {
            subAccounts: [
              {
                subAccountId: 'New Sub Account 1',
                totals: {
                  grandTotalDueMonthly: {
                    estimatedTotal: 400.4,
                  },
                },
              },
            ],
          },
        },
      },
    };

    beforeEach(() => {
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE']);
      sessionStorage.setItem('selectedSubAccountId', 'New Sub Account 1');
      GetAppConfig.mockReturnValue({
        messages: {
          landingContent: {
            affirmAccConfig: {
              prodScript: 'https://cdn1.affirm.com/js/v2/affirm.js',
              prodPublicKey: 'T4ASH81C8QOX9LYF',
              devPublicKey: 'WE2EY1ZRWLDP08RG',
              devScript: 'https://cdn1-sandbox.affirm.com/js/v2/affirm.js',
            },
            affirmEnableContent: {
              affrimHeaderLabel: 'Affirm',
              affrimContent: 'As low as 0% APR when you pay over time with Affirm',
              affrimSeeDetailsLabel: 'See details',
            },
          },
        },
      });
      render(<ExpandFooter {...props} />);
    });

    afterEach(() => {
      jest.clearAllMocks();
    });

    test('should mount Expand Footer component', async () => {
      const vaditeShop = await screen.getAllByTestId('expandFooter')[0];
      expect(vaditeShop).toBeInTheDocument();
      fireEvent.click(vaditeShop);
      expect(screen.getByText('Order effective date is set to')).toBeInTheDocument();
    });

    test('should onClick goToOrderEffectiveDate component', async () => {
      const vaditeShop = await screen.getByRole('link', { name: 'Text Link' });
      expect(vaditeShop).toBeInTheDocument();
      fireEvent.click(vaditeShop);
    });
  });
  describe(`<Footer component - ${channel}`, () => {
    const props = {
      affirmChecked: false,
      setAffirmChecked: () => {},
      isExpressCheckout: true,
      showShoppingBagModalFn: jest.fn(),
      getAcknowledge: jest.fn(),
      onProceedToOrderClick: jest.fn(),
      onapplyOffersClick: jest.fn(),
      landing: {
        accountDetails: {
          sharedAttributes: {
            flags: {
              isEffectiveDateEligible: true,
              selectedEffectiveDate: moment(new Date()).format('MM/DD/YYYY'),
            },
          },
        },
        subAccounts: [
          {
            shared: {
              pendingChargesAndDiscounts: {
                discountsPendingActionDetails: {
                  apoPaperlessAmount: '5652',
                  deviceTradeInDetails: [],
                  totalPendingDiscount: -20,
                  newMonthlyTotalWithPendingDiscounts: 0,
                },
              },
            },
          },
        ],
        cartDetails: {
          orderDetails: {
            subAccountInfo: [
              {
                subAccountId: 'New Sub Account 1',
              },
            ],
          },
        },
      },
      accountDetails: {
        grandTotals: {
          grandTotalDueMonthly: {
            estimatedTotal: 400.4,
          },
        },
      },
    };

    LANDING_STATE_DATA.landing.cartDetails.lineDetails = { bagTax: 2 };

    beforeEach(() => {
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE']);
      sessionStorage.setItem('selectedSubAccountId', 'New Sub Account 1');
      window.sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ enablePartialNbsPosFFlag: 'TRUE' }));
      GetAppConfig.mockReturnValue({
        messages: {
          landingContent: {
            affirmAccConfig: {
              prodScript: 'https://cdn1.affirm.com/js/v2/affirm.js',
              prodPublicKey: 'T4ASH81C8QOX9LYF',
              devPublicKey: 'WE2EY1ZRWLDP08RG',
              devScript: 'https://cdn1-sandbox.affirm.com/js/v2/affirm.js',
            },
            affirmEnableContent: {
              affrimHeaderLabel: 'Affirm',
              affrimContent: 'As low as 0% APR when you pay over time with Affirm',
              affrimSeeDetailsLabel: 'See details',
            },
          },
        },
      });

      render(<ExpandFooter {...props} />);
    });

    afterEach(() => {
      jest.clearAllMocks();
    });

    test('should mount Expand Footer component', async () => {
      const vaditeShop = await screen.getAllByTestId('expandFooter')[0];
      expect(vaditeShop).toBeInTheDocument();
      fireEvent.click(vaditeShop);
    });
    test('should mount Expand Footer component', async () => {
      const vaditeShop = await screen.getByRole('button', { name: 'Express checkout' });
      expect(vaditeShop).toBeInTheDocument();
      fireEvent.click(vaditeShop);
    });
    test('should mount Expand Footer component', async () => {
      const vaditeShop = await screen.getByRole('button', { name: 'Apply offers' });
      expect(vaditeShop).toBeInTheDocument();
      fireEvent.click(vaditeShop);
    });
  });
  describe(`<ExpandFooter component - ${channel}`, () => {
    const getPauseResumeStandaloneCheck = jest.fn().mockName('getPauseResumeStandaloneCheck');
    const showShoppingBagModalFn = jest.fn().mockName('showShoppingBagModalFn');
    const getAcknowledge = jest.fn().mockName('getAcknowledge');
    const onProceedToOrderClick = jest.fn().mockName('onProceedToOrderClick');

    const props = {
      affirmChecked: false,
      setAffirmChecked: () => {},
      isExpressCheckout: true,
      showShoppingBagModalFn,
      getAcknowledge,
      getPauseResumeStandaloneCheck,
      onProceedToOrderClick,
      onapplyOffersClick: jest.fn(),
      landing: {
        accountDetails: {
          sharedAttributes: {
            flags: {
              isEffectiveDateEligible: true,
              selectedEffectiveDate: '09/14/2024',
            },
          },
        },
        subAccounts: [
          {
            shared: {
              pendingChargesAndDiscounts: {
                discountsPendingActionDetails: {
                  apoPaperlessAmount: '5652',
                  deviceTradeInDetails: [],
                  totalPendingDiscount: -20,
                  newMonthlyTotalWithPendingDiscounts: 0,
                },
              },
            },
          },
        ],
      },
    };

    LANDING_STATE_DATA.landing.cartDetails.lineDetails = { bagTax: 2 };

    beforeEach(() => {
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE']);
      GetAppConfig.mockReturnValue({
        messages: {
          landingContent: {
            affirmAccConfig: {
              prodScript: 'https://cdn1.affirm.com/js/v2/affirm.js',
              prodPublicKey: 'T4ASH81C8QOX9LYF',
              devPublicKey: 'WE2EY1ZRWLDP08RG',
              devScript: 'https://cdn1-sandbox.affirm.com/js/v2/affirm.js',
            },
            affirmEnableContent: {
              affrimHeaderLabel: 'Affirm',
              affrimContent: 'As low as 0% APR when you pay over time with Affirm',
              affrimSeeDetailsLabel: 'See details',
            },
          },
        },
      });

      showShoppingBagModalFn.mockImplementation(() => true);
      getAcknowledge.mockImplementation(() => true);
      getPauseResumeStandaloneCheck.mockImplementation(() => true);
      render(<ExpandFooter {...props} />);
    });

    afterEach(() => {
      jest.clearAllMocks();
    });

    test("should trigger onProceed on clicking 'Express Checkout'", async () => {
      const vaditeShop = await screen.findByRole('button', { name: 'Express checkout' });
      expect(vaditeShop).toBeInTheDocument();
      fireEvent.click(vaditeShop);

      await waitFor(() => expect(onProceedToOrderClick).toBeCalled());
    });
    test("should trigger onProceed on clicking 'Review order'", async () => {
      const vaditeShop = await screen.findByRole('button', { name: 'Review order' });
      expect(vaditeShop).toBeInTheDocument();
      fireEvent.click(vaditeShop);

      await waitFor(() => expect(onProceedToOrderClick).toBeCalled());
    });
  });
  describe(`<ExpandFooter component - ${channel}`, () => {
    const getPauseResumeStandaloneCheck = jest.fn().mockName('getPauseResumeStandaloneCheck');
    const showShoppingBagModalFn = jest.fn().mockName('showShoppingBagModalFn');
    const getAcknowledge = jest.fn().mockName('getAcknowledge');
    const onProceedToOrderClick = jest.fn().mockName('onProceedToOrderClick');

    const props = {
      affirmChecked: false,
      setAffirmChecked: () => {},
      isExpressCheckout: true,
      showShoppingBagModalFn,
      getAcknowledge,
      getPauseResumeStandaloneCheck,
      onProceedToOrderClick,
      onapplyOffersClick: jest.fn(),
      landing: {
        accountDetails: {
          sharedAttributes: {
            flags: {
              isEffectiveDateEligible: true,
              selectedEffectiveDate: '09/14/2024',
            },
          },
        },
        subAccounts: [
          {
            shared: {
              pendingChargesAndDiscounts: {
                discountsPendingActionDetails: {
                  apoPaperlessAmount: '5652',
                  deviceTradeInDetails: [],
                  totalPendingDiscount: -20,
                  newMonthlyTotalWithPendingDiscounts: 0,
                },
              },
            },
          },
        ],
      },
    };

    LANDING_STATE_DATA.landing.cartDetails.lineDetails = { bagTax: 2 };

    beforeEach(() => {
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE']);
      GetAppConfig.mockReturnValue({
        messages: {
          landingContent: {
            affirmAccConfig: {
              prodScript: 'https://cdn1.affirm.com/js/v2/affirm.js',
              prodPublicKey: 'T4ASH81C8QOX9LYF',
              devPublicKey: 'WE2EY1ZRWLDP08RG',
              devScript: 'https://cdn1-sandbox.affirm.com/js/v2/affirm.js',
            },
            affirmEnableContent: {
              affrimHeaderLabel: 'Affirm',
              affrimContent: 'As low as 0% APR when you pay over time with Affirm',
              affrimSeeDetailsLabel: 'See details',
            },
          },
        },
      });

      showShoppingBagModalFn.mockImplementation(() => true);
      getAcknowledge.mockImplementation(() => true);
      getPauseResumeStandaloneCheck.mockImplementation(() => true);
      render(<ExpandFooter {...props} />);
    });

    afterEach(() => {
      jest.clearAllMocks();
    });

    test("should trigger onProceed on clicking 'Express Checkout'", async () => {
      const vaditeShop = await screen.findByRole('button', { name: 'Express checkout' });
      expect(vaditeShop).toBeInTheDocument();
      fireEvent.click(vaditeShop);

      await waitFor(() => expect(onProceedToOrderClick).toBeCalled());
    });
    test("should trigger onProceed on clicking 'Review order'", async () => {
      const vaditeShop = await screen.findByRole('button', { name: 'Review order' });
      expect(vaditeShop).toBeInTheDocument();
      fireEvent.click(vaditeShop);

      await waitFor(() => expect(onProceedToOrderClick).toBeCalled());
    });
  });
  describe(`<ExpandFooter component - affirmcheck box ${channel}`, () => {
    const getPauseResumeStandaloneCheck = jest.fn().mockName('getPauseResumeStandaloneCheck');
    const showShoppingBagModalFn = jest.fn().mockName('showShoppingBagModalFn');
    const getAcknowledge = jest.fn().mockName('getAcknowledge');
    const onProceedToOrderClick = jest.fn().mockName('onProceedToOrderClick');

    const props = {
      affirmChecked: false,
      setAffirmChecked: () => {},
      isExpressCheckout: true,
      showShoppingBagModalFn,
      getAcknowledge,
      getPauseResumeStandaloneCheck,
      onProceedToOrderClick,
      onapplyOffersClick: jest.fn(),
      landing: {
        cartDetails: {
          cartHasOnlyAccessories: false,
          cartHasConflicts: false,
          conflictsAccepted: false,
          flow: 'NAO',
          cartHeader: {
            winBackAccountNumber: '',
            vendorId: 'NETACE',
            repRole: '',
            locationType: 'S',
            isVzPhEligible: true,
            sourceSystem: 'OMNI-RETAIL',

            cartCreatorSalesRepId: 'ENC',
            visionCustomerType: 'PE',
            maverickLocation: false,
            isCoreRep: false,
            isERTRep: false,
          },
          orderDetails: {
            subAccountInfo: [
              {
                subAccountId: 'New Sub Account 1',
              },
            ],
            totalUpgradeFee: 0,
            totalDeviceDollar: 0,
            totalRemainingDeviceDollar: 0,
            totalUsedDeviceDollar: 0,
            totalAccountLevelAccCost: 0,
            assistanceOptedByCustomer: false,
            locationState: 'IL',
            totalVerizonDollarUsed: '0.0',
            isShellAccountSelected: false,
            fullfillmentLocation: '1000050',
            estimatedNextMonthChargeOnProfile: 0,
            originalSubTotalDueMonthly: 0,
            totalDueMonthlyAfterDiscounts: 0,
            accessoryFinancingOfferInfo: {
              installmentTerm: '12',
              installmentInfo: {
                monthlyInstallment: 0,
                accessoryTotal: 1049.97,
              },
              offerEligibleAmount: 100,
              offerExpiryDate: '12/31/2025',
              offerDisQualifiedAfterRemoveAcc: false,
              offerAvailable: true,
              customerEligible: true,
              offerAccepted: false,
              disclosureAgreementSent: false,
            },
            refundNotifications: {
              notificationEmail: 'XOVZGS@VZW.COM',
              notificationPhoneNum: '3467642983',
              emailIds: ['XOVZGS@VZW.COM'],
              phoneNumbers: ['3467642983', '2818814560', '7132482720', '7132487561', '7132046738', '2812530682'],
            },
            totalTaxAdjustmentAmount: 0,
            totalActivationFees: 0,
            fiveGHomeOrder: false,
            totalRefundAmount: 0,
            totalExchangeAmount: 0,
            totalRefundTaxAmount: 0,
            totalExchangeTaxAmount: 0,
            digitalExchange: false,
            affirmFinancingOfferInfo: {
              offerAvailable: true,
              offerAccepted: false,
              offerRejected: false,
              totalAffirmAccessoryAmount: 1049.97,
              totalAffirmAccessoryTaxAmount: 0,
              totalDueTodayAffirmApproved: 0,
              totalDueTodayWithoutAccessories: 0,
              shippingAmount: 0,
              splitPaymentInfo: [
                {
                  orderNumber: '20324957',
                  nonAccessoryTotal: 0,
                  accessoryTotal: 1049.97,
                  vdPaymentAmount: 0,
                },
              ],
            },
            remainingAmountAfterAffirmApplied: 0,
            cashOptionEnabled: false,
            affirmCreditCheckFailed: false,
            orderType: 'IS',
            locationCode: '2777301',
            customerType: 'E',
            billingSystem: 'VE',
            totalTaxAmount: '0.0',

            totalDueToday: 1049.97,
            runningTotalDueToday: 1049.97,
            totalDueTodayFlag: false,
          },
          lineDetails: {
            lineInfo: [
              {
                isCommonPDP: false,
                isTradeInIntentSelected: false,
                multiLineSeqNumber: 1,
                lineActivityType: 'ACC',
                totalDueToday: 1049.97,
                totalDueTodayWithoutTax: 1049.97,
                totalDueTodayWithoutTaxWithoutDiscount: 1049.97,
                totalDueMonthly: 0,
                mobileNumber: '7132487561',
                showGlobalChoiceOffer: false,
                serviceInfo: {
                  serviceAddress: {
                    addressLine1: '8787 HAMMERLY BLVD APT 1422',
                    addressLine2: '',
                    zipCode: '77080',
                    zipCode4: '6611',
                    firstName: 'JAKE',
                    lastName: 'REYES',
                    city: 'HOUSTON',
                    state: 'TX',
                  },
                  comparePlan: false,
                  primaryUserInfo: {
                    firstName: 'JAKE',
                    lastName: 'REYES',
                    address: {
                      firmName: '',
                      apartmentNo: '1422',
                      type: 'BL',
                      streetNumber: '8787',
                      streetName: 'HAMMERLY',
                      addressLine2: '',
                      addressLine1: '8787 HAMMERLY BLVD APT 1422',
                      poBoxNo: '',
                      ruralRouteNo: '',
                      ruralDelNo: '',
                      city: 'HOUSTON',
                      state: 'TX',
                      zipCode: '77080',
                      zipCode4: '6611',
                      county: '',
                      countryCode: 'US',
                      fipsCode: '4820135000',
                      firstName: 'JAKE',
                      lastName: 'REYES',
                      emailId: 'XOVZGS@VZW.COM',
                      phoneNumber: '2482140542',
                      streetType: 'BL',
                      streetDirection: '',
                    },
                    isValidAddress: true,
                    bsnsName: '',
                    emailId: 'XOVZGS@VZW.COM',
                    midInitials: 'L',
                  },
                  mtn: '7132487561',
                  min: '7132487561',
                  oldPricePlanId: '17991',
                  currentDevice: {
                    oldLteVoraEquipInfo: {
                      iccid: '89148000009959123359',
                      lteVoraDeviceInfo: {
                        deviceId: '354029285051901',
                        deviceType: '5GE',
                        deviceSku: 'MTLY3LL/A',
                        capacity: '128 GB',
                        description: 'Apple iPhone 15 128 GB in Blue',
                        imageUrlMap: {
                          defaultImage:
                            'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-128gb-blue-prepaid-mtpm3ll-a-a',
                          largeImage:
                            'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-128gb-blue-prepaid-mtpm3ll-a-a?$device-lg$',
                          mediumImage:
                            'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-128gb-blue-prepaid-mtpm3ll-a-a?$device-med$',
                          miniImage:
                            'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-128gb-blue-prepaid-mtpm3ll-a-a?$device-mini$',
                          thumbImage:
                            'https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-128gb-blue-prepaid-mtpm3ll-a-a?$device-thumb$',
                        },
                        color: {
                          description: 'Blue',
                        },
                        manufacturer: 'Apple',
                      },
                    },
                  },
                  isSharePlanAdded: false,
                  mea: 'VHT',
                  isE911AddressValidated: false,
                  oldPlanFlag: 'L',
                  kidsPlanParentMtn: false,
                  mcsSubscription: [],
                  fiveGUpSell: false,
                  e911AddressSameAsServiceAddress: false,
                  unpairedGrantor: false,
                  totalAddedFeaturesPrice: '0.0',
                },
                itemsInfo: [
                  {
                    depletionType: 'F',
                    attention: 'JAKE REYES',
                    shipping: {
                      address: {
                        firmName: '',
                        apartmentNo: '1422',
                        type: 'R',
                        streetNumber: '8787',
                        streetName: 'HAMMERLY',
                        addressLine2: '',
                        addressLine1: '8787 HAMMERLY BLVD APT 1422',
                        poBoxNo: '',
                        ruralRouteNo: '',
                        ruralDelNo: '',
                        city: 'HOUSTON',
                        state: 'TX',
                        zipCode: '77080',
                        zipCode4: '6611',
                        county: '',
                        countryCode: '',
                        fipsCode: '4820135000',
                        firstName: 'JAKE',
                        lastName: 'REYES',
                        emailId: 'XOVZGS@VZW.COM',
                        phoneNumber: '2482140542',
                        streetType: 'BL',
                        streetDirection: '',
                      },
                      bsnsName: '',
                      cbrPhone: '2482140542',
                      firstName: 'JAKE',
                      lastName: 'REYES',
                      midInitials: 'L',
                      isUseUnVerifiedAddress: false,
                      isValidAddress: false,
                      email: 'XOVZGS@VZW.COM',
                      shipToCustomerAddress: false,
                    },
                    fipsCode: '4820135000',
                    itemCount: 3,
                    itemTabSeqNum: 0,
                    cartItems: {
                      cartItem: [
                        {
                          discountAmount: 0,
                          deviceDollarApplied: 0,
                          qrScanNeededForEsimActivation: false,
                          isPreconfigureDuringAddDevice: false,
                          deviceDisplayName: 'Ring AIR - Size 6 - Raw Titanium',
                          accessoryGiftCardAmount: 0,
                          tradeInAmountTowardsUserDPUsed: 0,
                          sorDeviceCategory: ' ',
                          vendingKioskItem: 'false',
                          tradeInAutoPull: false,
                          priceAdjustment: false,
                          priceAdjustmentQty: 0,
                          newPurchasedQty: 1,
                          canonicalUrl: 'products/ultrahuman-ring-air/',
                          selectedForRFEX: false,
                          selectedForPAD: false,
                          bogoItem: false,
                          refxItemSeqNum: 0,
                          restrictedAccySku: false,
                          maxAccyPurchaseLimit: false,
                          giftCard: false,
                          itemCode: 'UHRA-RT-06',
                          totalPriceWithDiscount: 1049.97,
                          sorId: 'UHRA-RT-06',
                          skuId: 'sku6014958',
                          cartItemType: 'ACCESSORY',
                          description: 'Ring AIR - Size 6 - Raw Titanium',
                          qty: 3,
                          bundleSeqNum: 0,
                          itemPrice: '349.99',
                          discountedPercentage: 0,
                          discountedPrice: 349.99,
                          buyOutTaxAmountUnbilled: 0,
                          buyOutAmountWithoutTax: 0,
                          imageUrlMap: {
                            defaultImage: 'https://ss7.vzw.com/is/image/VerizonWireless/UHRA-RT-06-iset',
                            largeImage: 'https://ss7.vzw.com/is/image/VerizonWireless/UHRA-RT-06-iset?$acc-lg$',
                            mediumImage: 'https://ss7.vzw.com/is/image/VerizonWireless/UHRA-RT-06-iset?$acc-med$',
                            miniImage: 'https://ss7.vzw.com/is/image/VerizonWireless/UHRA-RT-06-iset?$acc-mini$',
                            thumbImage: 'https://ss7.vzw.com/is/image/VerizonWireless/UHRA-RT-06-iset?$acc-thumb$',
                          },
                          prodCode1: 'ACC',
                          prodCode2: 'SMA',
                          prodCode3: 'OEM',
                          prodCode4: '000',
                          prodCode5: 'ADS',
                          btaEligible: 'true',
                          depletionType: 'F',
                          catalogPrice: 349.99,
                          instantCreditAmountUsed: 0,
                          instantCreditAmountUsedForTaxes: 0,
                          unitTaxBasedPrice: 349.99,
                          itemNrpPrice: 349.99,
                          discounts: [],
                          availableReasonCode: [],
                          inventory: {
                            isAvailable: true,
                            isBackorder: false,
                            isDeliverBy: false,
                            isPreOrder: false,
                            qtyAvailable: 2993,
                            isShipBy: false,
                          },
                          isCustomerProvidedSIM: false,
                          isNetworkExtender: false,
                          ispuEligible: false,
                          itemSeqNum: 1,
                          sddEligible: false,
                          smartIMEI: false,
                          year: 0,
                          sellerPrice: '0.0',
                          productId: 'acc20892834',
                          taxDetailsList: [],
                          quantityOnHand: 993,
                          iconicPhone: false,
                          ringBell: false,
                          isPreconfigureEnabled: false,
                          isHumDevice: false,
                          isSmartLocator: false,
                          isSecurityAlarm: false,
                          isMotoMod: false,
                          isConnectedCar: false,
                          accountLevelAccessory: false,
                          byodESimPhone: false,
                          scannedItem: false,
                          appleCareAccessoryFlag: false,
                          quantityAllowed: true,
                          isDfoSelected: false,
                        },
                      ],
                    },
                    depletionLocation: '',
                    isPromoSelected: false,
                    isTradeInSelected: false,
                    taxExemptionTypes: '',
                  },
                ],
                mtnDetails: {
                  lineNumber: '7132487561',
                  mobileNumber: '7132487561',
                },
                lineNumber: '7132487561',
                fiveGToFourGDownGrade: false,
                lineCreator: '2812530682',
                amRole: '',
                lineRefundTotal: 0,
                lineExchangeTotal: 1049.97,
                totalDueMonthlyBeforeCredit: 0,
                sugAllowed: false,
                totalDueAddOnMonthly: 0,
                totalPriceOfPlanAndPerks: '0.0',
                isCpe: false,
                isLTEHomeLine: false,
                isDevicePlanCompatible: false,
                portinMtnAssignment: false,
                impactedLine: false,
                preOrBackOrder: false,
                ispuItem: false,
                ispuItemBYOD: false,
                isModConnected: false,
                modDevice: false,
                byodCapable: false,
                isCarLine: false,
                buySimOnly: false,
                broadBandInd: false,
                ispuDownPaymentAdjstRequired: false,
                ispuDownPaymentAmount: 0,
                lineWithSkipMDN: false,
                protectionNotRequired: false,
              },
            ],
          },
        },
      },
    };

    LANDING_STATE_DATA.landing.cartDetails.lineDetails = { bagTax: 2 };

    beforeEach(() => {
      // affirm component
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE']);

      GetAppConfig.mockReturnValue({
        messages: {
          landingContent: {
            affirmAccConfig: {
              prodScript: 'https://cdn1.affirm.com/js/v2/affirm.js',
              prodPublicKey: 'T4ASH81C8QOX9LYF',
              devPublicKey: 'WE2EY1ZRWLDP08RG',
              devScript: 'https://cdn1-sandbox.affirm.com/js/v2/affirm.js',
            },
            affirmEnableContent: {
              affrimHeaderLabel: 'Affirm',
              affrimContent: 'As low as 0% APR when you pay over time with Affirm',
              affrimSeeDetailsLabel: 'See details',
            },
          },
        },
      });

      const script = document.createElement('script');
      document.body.appendChild(script);

      showShoppingBagModalFn.mockImplementation(() => true);
      getAcknowledge.mockImplementation(() => true);
      getPauseResumeStandaloneCheck.mockImplementation(() => true);
      render(<ExpandFooter {...props} />);
    });

    afterEach(() => {
      jest.clearAllMocks();
    });

    test('should trigger on checking affirm box', async () => {
      const affirmbox = screen.getByRole('checkbox', { name: 'Affirm' });
      expect(affirmbox).toBeInTheDocument();
      fireEvent.click(affirmbox);
    });
  });
  describe(`<ExpandFooter component OneUI - ${channel}`, () => {
    document.body.innerHTML = '<div id="AppMessage" data-testid="AppMessage" />';
    const props = {
      itemsInCart: 5,
      customerType: 'PE',
      isprepaycart: false,
      affirmChecked: false,
      setAffirmChecked: () => {},
      accountDetails: {
        cartNBSNextBillTotals: {
          grandTotal: 433.03,
          totalOneTimeCharge: 94.36,
          subTotalWithoutAddons: 237.26,
          totalAddOnsSummary: 60.0,
          taxesAndFees: 13.34,
          surcharges: 28.07,
          plansTotal: 187.0,
          devicesTotal: 50.26,
        },
      },
      remindRepAboutSB: true,
      assistedFlag: {
        isBagFeeEnabled: 'TRUE',
        disableLargeBagFee: 'FALSE',
      },
      landing: {
        accountDetails: {
          sharedAttributes: {
            flags: {
              isEffectiveDateEligible: true,
              selectedEffectiveDate: '09/15/2024',
            },
          },
        },
        cartDetails: {
          lineDetails: {
            bagTax: true,
            bagFeeSku: 'MHXH3AM/A',
            lineInfo: [
              {
                itemsInfo: [
                  {
                    depletionType: 'L',
                    attention: 'JACK JONES',
                    fipsCode: '1318578800',
                    itemCount: 1,
                    itemTabSeqNum: 0,
                    cartItems: {
                      cartItem: [
                        {
                          deviceDisplayName: 'IPHONE 14 128 BLUE',
                          cartItemType: 'DEVICE',
                          priceType: 'VERIZON_EDGE',
                        },
                      ],
                    },
                  },
                ],
              },
            ],
          },
          orderDetails: {
            subAccountInfo: [
              {
                subAccountId: 'New Sub Account 1',
              },
            ],
          },
        },
        subAccounts: [
          {
            shared: {
              pendingChargesAndDiscounts: {
                discountsPendingActionDetails: {
                  apoPaperlessAmount: '5652',
                  deviceTradeInDetails: [],
                  totalPendingDiscount: -20,
                  newMonthlyTotalWithPendingDiscounts: 0,
                },
              },
            },
          },
        ],
      },
    };

    beforeEach(() => {
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE']);
      window.sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ enablePartialNbsPosFFlag: 'TRUE' }));
      GetAppConfig.mockReturnValue({
        messages: {
          landingContent: {
            affirmAccConfig: {
              prodScript: 'https://cdn1.affirm.com/js/v2/affirm.js',
              prodPublicKey: 'T4ASH81C8QOX9LYF',
              devPublicKey: 'WE2EY1ZRWLDP08RG',
              devScript: 'https://cdn1-sandbox.affirm.com/js/v2/affirm.js',
            },
            affirmEnableContent: {
              affrimHeaderLabel: 'Affirm',
              affrimContent: 'As low as 0% APR when you pay over time with Affirm',
              affrimSeeDetailsLabel: 'See details',
            },
          },
        },
      });
      render(<ExpandFooter {...props} />);
    });

    afterEach(() => {
      jest.clearAllMocks();
    });

    test('should mount Expand Footer component', async () => {
      const vaditeShop = await screen.getAllByTestId('expandFooter')[0];
      expect(vaditeShop).toBeInTheDocument();
      fireEvent.click(vaditeShop);
      expect(screen.getByText('Order effective date is set to')).toBeInTheDocument();
    });

    test('should onClick goToOrderEffectiveDate component', async () => {
      const vaditeShop = await screen.getByRole('link', { name: 'Text Link' });
      expect(vaditeShop).toBeInTheDocument();
      fireEvent.click(vaditeShop);
    });
  });

  describe(`<ExpandFooter component - ${channel}`, () => {
    const getPauseResumeStandaloneCheck = jest.fn().mockName('getPauseResumeStandaloneCheck');
    const showShoppingBagModalFn = jest.fn().mockName('showShoppingBagModalFn');
    const getAcknowledge = jest.fn().mockName('getAcknowledge');
    const onProceedToOrderClick = jest.fn().mockName('onProceedToOrderClick');

    const props = {
      affirmChecked: false,
      setAffirmChecked: () => {},
      isExpressCheckout: false,
      showShoppingBagModalFn,
      getAcknowledge,
      getPauseResumeStandaloneCheck,
      onProceedToOrderClick,
      onapplyOffersClick: jest.fn(),
      landing: {
        accountDetails: {
          sharedAttributes: {
            flags: {
              isEffectiveDateEligible: true,
              selectedEffectiveDate: '09/14/2024',
            },
          },
        },
        subAccounts: [
          {
            shared: {
              pendingChargesAndDiscounts: {
                discountsPendingActionDetails: {
                  apoPaperlessAmount: '5652',
                  deviceTradeInDetails: [],
                  totalPendingDiscount: -20,
                  newMonthlyTotalWithPendingDiscounts: 0,
                },
              },
            },
          },
        ],
      },
    };

    LANDING_STATE_DATA.landing.cartDetails.lineDetails = { bagTax: 2 };

    beforeEach(() => {
      getAssistedCradlePropertyV2.mockReturnValue(['TRUE']);
      GetAppConfig.mockReturnValue({
        messages: {
          landingContent: {
            affirmAccConfig: {
              prodScript: 'https://cdn1.affirm.com/js/v2/affirm.js',
              prodPublicKey: 'T4ASH81C8QOX9LYF',
              devPublicKey: 'WE2EY1ZRWLDP08RG',
              devScript: 'https://cdn1-sandbox.affirm.com/js/v2/affirm.js',
            },
            affirmEnableContent: {
              affrimHeaderLabel: 'Affirm',
              affrimContent: 'As low as 0% APR when you pay over time with Affirm',
              affrimSeeDetailsLabel: 'See details',
            },
          },
        },
      });

      showShoppingBagModalFn.mockImplementation(() => true);
      getAcknowledge.mockImplementation(() => true);
      getPauseResumeStandaloneCheck.mockImplementation(() => true);
      render(<ExpandFooter {...props} />);
    });

    afterEach(() => {
      jest.clearAllMocks();
    });

    test("Should not display express checkout'", async () => {
      const expressCheckoutBtn = await screen.queryByRole('button', { name: 'Express checkout' });
      expect(expressCheckoutBtn).not.toBeInTheDocument();
    });
  });
};

Test(CHANNELS.OMNI_RETAIL);
