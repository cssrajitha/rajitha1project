import React from 'react';
import { render } from '@testing-library/react';
/* import { render ,screen } from '../../utils/test-utils/renderHelper'; */
import '@testing-library/jest-dom/extend-expect';
import DotLoader from './DotLoader';

test('render DotLoader Component', () => {
  const { container } = render(<DotLoader />);

  const containerElement = container.querySelector('.dot-loading');
  expect(containerElement).toBeInTheDocument();

  const dots = container.querySelectorAll('.icon-circle.dot');
  expect(dots).toHaveLength(3);

  expect(dots[0]).toHaveClass('one');
  expect(dots[1]).toHaveClass('two');
  expect(dots[2]).toHaveClass('three');
});
