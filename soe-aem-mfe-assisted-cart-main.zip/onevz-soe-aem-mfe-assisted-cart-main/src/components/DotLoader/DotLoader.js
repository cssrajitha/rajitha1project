import React from "react";
import "./DotLoader.css";

export default function DotLoader() {
  return (
    <div className="dot-loading">
      <span className="icon-circle dot one"/>
      <span className="icon-circle dot two"/>
      <span className="icon-circle dot three"/>
    </div>
  );
}
