import React from 'react';
import { Modal, ModalBody, ModalTitle } from '@vds/modals';
import styled from 'styled-components';
import PropTypes from 'prop-types';
import { GetAppConfig } from 'onevzsoemfeframework/GetAppConfig';

import { Button } from '@vds/buttons';

const GroupButtons = styled.div`
  margin-top: 20px;
  display: flex;
  width: 100%;
`;
export default function HomeInternetLiteModal(props) {
  const appConfig = GetAppConfig();

  return (
    <div id='home-internet-lite-modal' data-testid='home-internet-lite-modal'>
      <Modal
        className='home-internet-lite-modal'
        closeButtonId='close'
        opened={props?.showHomeInternetLiteModal}
        hideCloseButton={false}
        disableOutsideClick
        onOpenedChange={(opened) => {
          if (!opened) {
            props?.closeHomeInternetLiteModal();
          }
        }}
      >
        <ModalTitle primitive='h6'>{appConfig?.messages?.homeInternetLitePopup?.title}</ModalTitle>
        <ModalBody>
          {appConfig?.messages?.homeInternetLitePopup?.points?.map((point) => (
            <li key={point}>&#8226; {point}</li>
          ))}
          <GroupButtons>
            <Button
              size='large'
              surface='light'
              disabled={false}
              use='primary'
              data-testid='home-internet-lite-modal-continue'
              onClick={() => props?.onPlanSelectConfirmation()}
              style={{ flex: '1', marginLeft: '10px' }}
            >
              {appConfig?.messages?.homeInternetLitePopup?.buttons?.proceed}
            </Button>
            {/* <SpacingDiv /> */}
            <Button
              size='large'
              surface='light'
              disabled={false}
              use='secondary'
              data-testid='home-internet-lite-modal-cancel'
              onClick={() => props?.closeHomeInternetLiteModal()}
              style={{ flex: '1', marginLeft: '10px' }}
            >
              {appConfig?.messages?.homeInternetLitePopup?.buttons?.cancel}
            </Button>
          </GroupButtons>
        </ModalBody>
      </Modal>
    </div>
  );
}

HomeInternetLiteModal.propTypes = {
  showHomeInternetLiteModal: PropTypes.bool,
  closeHomeInternetLiteModal: PropTypes.func,
  onPlanSelectConfirmation: PropTypes.func,
};
