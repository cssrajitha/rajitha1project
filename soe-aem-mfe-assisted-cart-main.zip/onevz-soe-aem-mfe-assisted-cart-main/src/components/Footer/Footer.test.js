import React from 'react';
import Emitter from 'onevzsoemfeframework/Emitter';
import { GetAppConfig } from 'onevzsoemfeframework/GetAppConfig';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import { fireEvent, render, screen, waitFor, act } from '../../utils/test-utils/renderHelper';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { setupChannel, CHANNELS } from '../../utils/test-utils/utils';
import Footer from './Footer';
import FetchPricingSnapshot from '../../mocks/fetchPricingSnapshot.json';
import FetchPricingSnapshotVMP from '../../mocks/fetchPricingSnapshotVMP.json';
import FpsVvc from '../../mocks/fpsvvc.json';
import compareQuotes from './Mocks/compareQuotes.json';
import FPSWithZeroAppraisalToTrade from './Mocks/FPSWithZeroAppraisalToTrade.json';
import fpsNoSETUP from '../../mocks/fpsNoSETUP.json';
import aiquoteResponseTaggingJSON from './Mocks/aiquoteResponseTagging.json';
import aiQuoteResponseJSON from './Mocks/aiquoteResponse.json';
import fpsWithCartItemJSON from './Mocks/fpsWithCartItem.json';
import fpsWithNoCartItemJSON from './Mocks/fpsWithNoCartItems.json';
import fpsWithBICOfferJSON from '../../mocks/fpsWithBICOffer.json';
import fpsWithTradeOfferJSON from '../../mocks/fpsWithTradeOffer.json';
import { customerBio, deviceRecommendations } from '../../mocks/footerTestData';
import fpsNew from './Mocks/FPSNEW.json';
import removeLinesJSON from './Mocks/removeLines.json';

jest.mock('onevzsoemfeframework/GetAppConfig', () => ({
  GetAppConfig: jest.fn(() => ({
    urls: {
      fetchPricingSnapshot: '/test/fetchPricingSnapshot',
      getMyOffers: '/test/getMyOffers',
      getAccountInfoForAIQuote: '/test/getAccountInfoForAIQuote',
      getMultipleAddressQualification: '/test/getMultipleAddressQualification',
      landing: '/test/landing',
      typeAhead: '/test/typeAhead',
      getSkuDetails: '/test/getSkuDetails',
      eSimDetails: '/test/eSimDetails',
      retrieveCart: '/test/retrieveCart',
      edgeUpEarlyUpgrade: '/test/edgeUpEarlyUpgrade',
      getDropPromoDetails: '/test/getDropPromoDetails',
      dpEligibility: '/test/dpEligibility',
      getCustomerInfo: '/test/getCustomerInfo',
      getCustomerLinesInfo: '/test/getCustomerLinesInfo',
      getTradeinCases: '/test/getTradeinCases',
      offersAndPromotions: '/test/offersAndPromotions',
      getOffers: '/test/getOffers',
      getCustomerInsights: '/test/getCustomerInsights',
      validateCartAndCheckout: '/test/validateCartAndCheckout',
      updateAssistUserSession: '/test/updateAssistUserSession',
      getConflicts: '/test/getConflicts',
      getRetrieveCart: '/test/getRetrieveCart',
      getUpdateEffectiveDate: '/test/getUpdateEffectiveDate',
      updateConflictStatus: '/test/updateConflictStatus',
      getExistingFeatures: '/test/getExistingFeatures',
      deEnrollMNFDiscounts: '/test/deEnrollMNFDiscounts',
      fraudInterceptor: '/test/fraudInterceptor',
      getInventoryDetails: '/test/getInventoryDetails',
      checkInStoreAvailability: '/test/checkInStoreAvailability',
      readAssistedDL: '/test/readAssistedDL',
      removeOffers: '/test/removeOffers',
      validateAddress: '/test/validateAddress',
      updateCustomerProfile: '/test/updateCustomerProfile',
      editAddressRFEX: '/test/editAddressRFEX',
      initiateCLNR: '/test/initiateCLNR',
      addressTypehead: '/test/addressTypehead',
      getPromo: '/test/getPromo',
      getStoreInformation: '/test/getStoreInformation',
      applyOffers: '/test/applyOffers',
      generateJWT: '/test/generateJWT',
      retrievecreditappsbyssn: '/test/retrievecreditappsbyssn',
      submitcredit: '/test/submitcredit',
      getVvcLoan: '/test/getVvcLoan',
      readAgentsByEId: '/test/readAgentsByEId',
      getHouseHoldSavings: '/test/getHouseHoldSavings',
      removeCustomerCheckIn: '/test/removeCustomerCheckIn',
      createCase: '/test/createCase',
      addPlanAndPerks: '/test/addPlanAndPerks',
      fetchTilesData: '/test/fetchTilesData',
    },
    messages: {
      dqContent: {
        byodPlanIDs: ['63217', '70143', '70144', '71156', '71157'],
        byodPromo: ["21259", "21271"]
      },
      montanaContent: {},
    },
  })),
}));

jest.mock('@vds/modals', () => ({
  ...jest.requireActual('@vds/modals'),
  // eslint-disable-next-line react/button-has-type, react/prop-types
  Modal: ({ children, ...props }) => (
    // eslint-disable-next-line react/prop-types
    <div {...props} data-testid={props['data-testid'] || props.id}>
      {children}
    </div>
  ),
}));

// Mock the API hooks
let mockRetrieveAEMInfoManagerData = jest.fn();

jest.mock('../../modules/services/APIService/APIServiceHooks', () => ({
  ...jest.requireActual('../../modules/services/APIService/APIServiceHooks'),
  useLazyRetrieveAEMInfoManagerDataQuery: () => [mockRetrieveAEMInfoManagerData, {}],
}));

beforeEach(() => {
  sessionStorage.setItem(
    'APP_PROPERTIES',
    JSON.stringify({
      byodPlusPlanFFlag: 'TRUE',
      byodFiveDollarPlanPOSFFlag: 'TRUE',
      byodPlusEUPSupressFFlag: 'TRUE',
    }),
  );
  mockRetrieveAEMInfoManagerData = jest.fn();
});

const Test = (channel) => {
  
  setupChannel(channel);
  const setFPSProtectionData = jest.fn();
  const setTriggerProceedToQuote = jest.fn();
  describe('Footer', () => {
    const handlers = [
      rest.post(`*fetchPricingSnapshot`, (req, res, ctx) => {
        console.log('inside FPS mock');
        return res(ctx.status(200), ctx.json(fpsWithCartItemJSON));
      }),
      rest.post(`*processAcctInquiryTranDetails`, (req, res, ctx) => {
        console.log('inside mock');
        return res(
          ctx.status(200),
          ctx.json({
            data: {
              statusMessage: 'Success',
              uniqueKey: '1710886290738',
              pkSequence: null,
              errors: null,
              status: 1,
            },
          }),
        );
      }),
      rest.post(`*compareQuotes`, (req, res, ctx) => {
        console.log('inside FPS mock');
        return res(ctx.status(200), ctx.json(compareQuotes));
      }),
    ];
    const vzdlMock = window.vzdl;
    delete window.vzdl;
    window.vzdl = {
      ...vzdlMock,
      page: { detail: 'Footer', throttle: 'MFE' },
      event: { value: 'scAdd' },
      txn: { product: { current: [] }, nonRecurringPrice: 0 },
    };

    window.cartProducts = [
      {
        mtn: 'newLine1',
        current: [
          {
            name: 'iPhone 16 Pro Max',
            lineHash: '',
            sku: 'sku6016050',
            shared: 'N',
            id: 'MYW53LL/A',
            category: 'Device',
            discount: 0,
            qty: 1,
            merchCat: '',
            offer: '',
            recurringPrice: 33.33,
            nonRecurringPrice: 1199.99,
            shippingCharge: 0,
            shippingType: '',
            propId: '',
            path: '',
            group: '',
            action: '',
            line: 0,
            contractType: '',
          },
        ],
      },
      {
        mtn: '4107397731',
      },
    ];

    const createAiQuoteResCollection = [{ offerRecommendations: [{ rank: '1', isRtdOffer: 'Y' }] }];

    const server = setupServer(...handlers);
    beforeAll(() => server.listen());
    afterEach(() => server.resetHandlers());
    afterAll(() => server.close());
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'FALSE',
          personalShopperLineLevelFFlag: 'FALSE',
          enableShareQuoteinAIQuoteFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
          aiQuoteProspectOffersFFlag: 'TRUE',
          byodPlusPlanFFlag: 'TRUE',
          byodPlusEUPSupressFFlag: 'TRUE',
        }),
      );
      Object.defineProperty(global.navigator, 'userAgent', {
        get() {
          return 'iPad';
        },
        configurable: true,
      });
      render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          deviceTriageDone
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          triggerProceedToQuote
          aiquoteResponse={aiQuoteResponseJSON}
          createAiQuoteResCollection={createAiQuoteResCollection}
          FetchPricingSnapShotResult={fpsWithCartItemJSON}
          setFPSProtectionData={setFPSProtectionData}
          linesWithoutProtection={[{ mtn: 'newLine1' }]}
          isCollaborationStartedForRC
          showPriceDetails
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          mandatoryNumberShareLines={[{ mtn: 'newLine1' }]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });

    test('renders Footer content', async () => {
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const footercomponent = await screen.getByTestId('footercomponent');
      Emitter.emit('TRIGGER_AIQUOTE_FPS_CALL', true);
      fireEvent.click(footercomponent);
      Emitter.emit('FetchPricingSnaphotResult', FetchPricingSnapshot);
    });
    test('renders Footer content', async () => {
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('FETCH_CART_LINE_DETAILS');
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: true,
      });
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: false,
      });
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {});
      Emitter.emit('Closing_Device_Protection_Modal', {});
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });

    test('verify proceed to quote when trade has zero appraisal value', async () => {
      render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          deviceTriageDone
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          triggerProceedToQuote
          aiquoteResponse={aiQuoteResponseJSON}
          FetchPricingSnapShotResult={FPSWithZeroAppraisalToTrade}
          setFPSProtectionData={setFPSProtectionData}
          isCollaborationStartedForRC
          setTaggingPayload={jest.fn()}
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('FETCH_CART_LINE_DETAILS');
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: true,
      });
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: false,
      });
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {});
      Emitter.emit('Closing_Device_Protection_Modal', {});
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findAllByTestId('footercomponentButton');
      expect(proceedtoCart[0]).not.toBeDisabled();
      fireEvent.click(proceedtoCart[0]);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });

    test('renders Footer content', async () => {
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: true,
      });
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: false,
      });
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {});
      Emitter.emit('Closing_Device_Protection_Modal', {});
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });

    test('renders Footer content - Trade Offer', async () => {
      server.use(
        rest.post(`*fetchPricingSnapshot`, (req, res, ctx) => res(ctx.status(200), ctx.json(fpsWithTradeOfferJSON))),
      );
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {
        mtn: '8045735000',
      });
      Emitter.emit('Priority_upgrade_List', [{ isPriorityMtn: true, mtn: '384343422' }]);
      Emitter.emit('AI_QUOTE_PERK_RECOMMENDATIONS_FOR_FOOTER', {
        perks: [
          {
            spoId: '2641',
            spoDescription: 'Disney Bundle',
            recomOrder: '1',
            propositionId: 'Perk_1',
            propositionName: 'Perk',
            rank: '1',
          },
          {
            spoId: '2642',
            spoDescription: 'Disney Bundle',
            recomOrder: '1',
            propositionId: 'Perk_1',
            propositionName: 'Perk',
            rank: '2',
          },
        ],
        isUpdateQuote: false,
      });
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: true,
      });
      Emitter.emit('Closing_Device_Protection_Modal', {});
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });
  });
  describe('Footer', () => {
    const handlers = [
      rest.post(`*fetchPricingSnapshot`, (req, res, ctx) => {
        console.log('inside FPS mock');
        return res(ctx.status(200), ctx.json(FetchPricingSnapshot));
      }),
      rest.post(`*processAcctInquiryTranDetails`, (req, res, ctx) => {
        console.log('inside mock');
        return res(
          ctx.status(200),
          ctx.json({
            data: {
              statusMessage: 'Success',
              uniqueKey: '1710886290738',
              pkSequence: null,
              errors: null,
              status: 1,
            },
          }),
        );
      }),
      rest.post(`*compareQuotes`, (req, res, ctx) => {
        console.log('inside FPS mock');
        return res(ctx.status(200), ctx.json(compareQuotes));
      }),
    ];
    const vzdlMock = window.vzdl;
    delete window.vzdl;
    window.vzdl = {
      ...vzdlMock,
      page: { detail: 'Footer', throttle: 'MFE' },
      event: { value: 'scAdd' },
      txn: { product: { current: [] }, nonRecurringPrice: 0 },
    };

    window.cartProducts = [
      {
        mtn: 'newLine1',
        current: [
          {
            name: 'iPhone 16 Pro Max',
            lineHash: '',
            sku: 'sku6016050',
            shared: 'N',
            id: 'MYW53LL/A',
            category: 'Device',
            discount: 0,
            qty: 1,
            merchCat: '',
            offer: '',
            recurringPrice: 33.33,
            nonRecurringPrice: 1199.99,
            shippingCharge: 0,
            shippingType: '',
            propId: '',
            path: '',
            group: '',
            action: '',
            line: 0,
            contractType: '',
          },
        ],
      },
      {
        mtn: '4107397731',
      },
    ];

    const createAiQuoteResCollection = [{ offerRecommendations: [{ rank: '1', isRtdOffer: 'Y' }] }];

    const server = setupServer(...handlers);
    beforeAll(() => server.listen());
    afterEach(() => server.resetHandlers());
    afterAll(() => server.close());
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          enableShareQuoteinAIQuoteFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
          showQuoteInitModalFFlag: 'TRUE',
          aiQuoteD2DleadFFlag: 'TRUE',
        }),
      );
      Object.defineProperty(global.navigator, 'userAgent', {
        get() {
          return 'iPad';
        },
        configurable: true,
      });
      render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          deviceTriageDone
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          triggerProceedToQuote
          aiquoteResponse={aiQuoteResponseJSON}
          createAiQuoteResCollection={createAiQuoteResCollection}
          FetchPricingSnapShotResult={FetchPricingSnapshot}
          setFPSProtectionData={setFPSProtectionData}
          linesWithoutProtection={[{ mtn: 'newLine1' }]}
          isCollaborationStartedForRC
          showPriceDetails
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          mandatoryNumberShareLines={[{ mtn: 'newLine1' }]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });

    test('renders Footer content', async () => {
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const footercomponent = await screen.getByTestId('footercomponent');
      Emitter.emit('TRIGGER_AIQUOTE_FPS_CALL', true);
      fireEvent.click(footercomponent);
      Emitter.emit('FetchPricingSnaphotResult', FetchPricingSnapshot);
    });
    test('renders Footer content', async () => {
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const footercomponent = await screen.getByLabelText('Expand Footer');
      fireEvent.click(footercomponent);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      rest.post(`*compareQuotes`, (req, res, ctx) => {
        console.log('inside FPS mock');
        return res(ctx.status(200), ctx.json(compareQuotes));
      });
    });
    test('verifies unifiedNbsFlag uses FPS flag for existing customer on expand', async () => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({ enableFullBlownMfeNbsPosFFlag: 'FALSE', personalShopperLineLevelFFlag: 'FALSE' }),
      );
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const footercomponent = await screen.getByLabelText('Expand Footer');
      fireEvent.click(footercomponent);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });
    test('renders Footer content', async () => {
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('FETCH_CART_LINE_DETAILS');
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: true,
      });
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: false,
      });
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {});
      Emitter.emit('Closing_Device_Protection_Modal', {});
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });

    test('renders Footer content', async () => {
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('FETCH_CART_LINE_DETAILS');
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: true,
      });
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: false,
      });
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {});
      Emitter.emit('Closing_Device_Protection_Modal', {});
      Emitter.emit('SET_PAYLOAD_FOR_RC', { flowType: 'quote' });
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findByTestId('footercomponentShareQuoteButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });

    test('verify proceed to quote when trade has zero appraisal value', async () => {
      render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          deviceTriageDone
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          triggerProceedToQuote
          aiquoteResponse={aiQuoteResponseJSON}
          FetchPricingSnapShotResult={FPSWithZeroAppraisalToTrade}
          setFPSProtectionData={setFPSProtectionData}
          isCollaborationStartedForRC
          showPriceDetails
          setTaggingPayload={jest.fn()}
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('FETCH_CART_LINE_DETAILS');
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: true,
      });
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: false,
      });
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {});
      Emitter.emit('Closing_Device_Protection_Modal', {});
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findAllByTestId('footercomponentButton');
      expect(proceedtoCart[0]).not.toBeDisabled();
      fireEvent.click(proceedtoCart[0]);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });

    test('renders Footer content', async () => {
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: true,
      });
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: false,
      });
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {});
      Emitter.emit('Closing_Device_Protection_Modal', {});
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });

    test('renders Footer content - Trade Offer', async () => {
      server.use(
        rest.post(`*fetchPricingSnapshot`, (req, res, ctx) => res(ctx.status(200), ctx.json(fpsWithTradeOfferJSON))),
      );
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {
        mtn: '8045735000',
      });
      Emitter.emit('AI_QUOTE_PERK_RECOMMENDATIONS_FOR_FOOTER', {
        perks: [
          {
            spoId: '2641',
            spoDescription: 'Disney Bundle',
            recomOrder: '1',
            propositionId: 'Perk_1',
            propositionName: 'Perk',
            rank: '1',
          },
          {
            spoId: '2642',
            spoDescription: 'Disney Bundle',
            recomOrder: '1',
            propositionId: 'Perk_1',
            propositionName: 'Perk',
            rank: '2',
          },
        ],
        isUpdateQuote: false,
      });
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: true,
      });
      Emitter.emit('Closing_Device_Protection_Modal', {});
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });
    test('renders Footer content for breadcrumb flow', async () => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          enableShareQuoteinAIQuoteFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
          showQuoteInitModalFFlag: 'TRUE',
        }),
      );
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('FETCH_CART_LINE_DETAILS');
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: true,
      });
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: false,
      });
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', { isCaptureBreadcrumbFlow: 'true' });
      Emitter.emit('Closing_Device_Protection_Modal', {});
      Emitter.emit('SET_PAYLOAD_FOR_RC', { flowType: 'quote' });
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findByTestId('footercomponentShareQuoteButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });
  });

  describe('Footer component', () => {
    const handlers = [
      rest.post(`*fetchPricingSnapshot`, (req, res, ctx) => res(ctx.status(200), ctx.json(fpsNoSETUP))),
      rest.post(`*processAcctInquiryTranDetails`, (req, res, ctx) => {
        console.log('inside mock');
        return res(
          ctx.status(200),
          ctx.json({
            data: {
              statusMessage: 'Success',
              uniqueKey: '1710886290738',
              pkSequence: null,
              errors: null,
              status: 1,
            },
          }),
        );
      }),
    ];
    const vzdlMock = window.vzdl;
    delete window.vzdl;
    window.vzdl = {
      ...vzdlMock,
      page: { detail: 'Footer', throttle: 'MFE' },
      event: { value: 'scAdd' },
      txn: { product: { current: [] }, nonRecurringPrice: 0 },
    };
    const server = setupServer(...handlers);
    beforeAll(() => server.listen());
    afterEach(() => server.resetHandlers());
    afterAll(() => server.close());
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          enableShareQuoteinAIQuoteFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
        }),
      );
      render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          setIsManualTriage={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          aiquoteResponse={aiQuoteResponseJSON}
          setFPSProtectionData={setFPSProtectionData}
          linesWithoutProtection={[{ mtn: 'newLine1' }]}
          isCollaborationStartedForRC
          showPriceDetails
          setTaggingPayload={jest.fn()}
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          mandatoryNumberShareLines={[{ mtn: 'newLine1' }]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });

    test('renders Footer content without setup and go', async () => {
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('existingServices_customerBio', [{ title: 'plan reduction' }]);
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: true,
      });
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: false,
      });
      Emitter.emit('protection_services_data_services', { title: 'plan reduction', price: '3' });
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {});
      Emitter.emit('Closing_Device_Protection_Modal', {});
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCart).not.toBeDisabled();
    });
  });

  describe('Footer - ipad flow', () => {
    const handlers = [
      rest.post(`*fetchPricingSnapshot`, (req, res, ctx) => {
        console.log('inside FPS mock');
        return res(ctx.status(200), ctx.json(FetchPricingSnapshot));
      }),
      rest.post(`*processAcctInquiryTranDetails`, (req, res, ctx) => {
        console.log('inside mock');
        return res(
          ctx.status(200),
          ctx.json({
            data: {
              statusMessage: 'Success',
              uniqueKey: '1710886290738',
              pkSequence: null,
              errors: null,
              status: 1,
            },
          }),
        );
      }),
    ];
    const server = setupServer(...handlers);
    beforeAll(() => server.listen());
    afterEach(() => server.resetHandlers());
    afterAll(() => server.close());
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          enableShareQuoteinAIQuoteFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
        }),
      );
      render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          aiquoteResponse={aiQuoteResponseJSON}
          setFPSProtectionData={setFPSProtectionData}
          FetchPricingSnapShotResult={fpsNew}
          linesWithoutProtection={[{ mtn: 'newLine1' }]}
          isCollaborationStartedForRC
          showPriceDetails
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          mandatoryNumberShareLines={[{ mtn: 'newLine1' }]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });

    test('renders Footer content', async () => {
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const footercomponent = await screen.getByTestId('footercomponent');
      Emitter.emit('TRIGGER_AIQUOTE_FPS_CALL', true);
      fireEvent.click(footercomponent);
      Emitter.emit('FetchPricingSnaphotResult', FetchPricingSnapshot);
    });
    test('renders Footer to auto proceed to cart after manual triage', async () => {
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('TRIGGER_AIQUOTE_FPS_CALL', true);
      Emitter.emit('FetchPricingSnaphotResult', FetchPricingSnapshot);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const tradeDevicesInCart = [
        {
          tradeDeviceMDN: '2158726660',
          deviceId: '350393283167190',
        },
      ];
      render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          isManualTriageDone
          setIsManualTriage={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          FetchPricingSnapShotResult={fpsNew}
          setFPSProtectionData={setFPSProtectionData}
          aiquoteResponse={aiQuoteResponseJSON}
          tradeDevicesInCart={tradeDevicesInCart}
          tradeAddedOnLoad={tradeDevicesInCart}
          linesWithoutProtection={[{ mtn: 'newLine1' }]}
          isCollaborationStartedForRC
          showPriceDetails
          setTaggingPayload={jest.fn()}
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          mandatoryNumberShareLines={[{ mtn: 'newLine1' }]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });
    test('renders Footer content', async () => {
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const footercomponent = await screen.getByLabelText('Expand Footer');
      fireEvent.click(footercomponent);
    });
    test('renders Footer content', async () => {
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('FETCH_CART_LINE_DETAILS');
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: true,
      });
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: false,
      });
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {});
      Emitter.emit('Closing_Device_Protection_Modal', {});
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });
    test('renders Footer content', async () => {
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: true,
      });
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: false,
      });
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {});
      Emitter.emit('Closing_Device_Protection_Modal', {});
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });
  });

  describe('Footer', () => {
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          enableShareQuoteinAIQuoteFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
        }),
      );
      render(
        <Footer
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          setFPSProtectionData={setFPSProtectionData}
          FetchPricingSnapShotResult={fpsNew}
          linesWithoutProtection={[{ mtn: 'newLine1' }]}
          showPriceDetails
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          disableProceedToQuote={false}
          mandatoryNumberShareLines={[{ mtn: 'newLine1' }]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });

    test('renders Footer content', async () => {
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const footercomponent = screen.getByTestId('footercomponent');
      Emitter.emit('TRIGGER_AIQUOTE_FPS_CALL', true);
      fireEvent.click(footercomponent);
      Emitter.emit('FetchPricingSnaphotResult', FetchPricingSnapshot);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
    });
    test('renders Footer content', async () => {
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const footercomponent = screen.getByLabelText('Expand Footer');
      fireEvent.click(footercomponent);
    });
    test('renders Footer content', async () => {
      window.cartProducts = [
        {
          mtn: 'newLine1',
          current: [
            {
              name: 'iPhone 16 Pro Max',
              lineHash: '',
              sku: 'sku6016050',
              shared: 'N',
              id: 'MYW53LL/A',
              category: 'Device',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 33.33,
              nonRecurringPrice: 1199.99,
              shippingCharge: 0,
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              line: 0,
              contractType: '',
            },
            {
              name: 'Apple iPhone 13 256GB Red',
              lineHash: '',
              sku: '358265580971304',
              shared: 'N',
              id: 'MLAX3LL/A',
              category: 'Trade-Device',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 0,
              nonRecurringPrice: 195,
              shippingCharge: 0,
              orderType: 'TradeIn',
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              line: null,
              contractType: '',
              type: 'deviceProtection',
            },
            {
              name: 'Verizon Mobile Protect Multi-Device',
              line: 0,
              lineHash: '',
              sku: '2663',
              shared: 'Y',
              contractType: '',
              id: '2663',
              category: 'Feature',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 68,
              nonRecurringPrice: 0,
              shippingCharge: 0,
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              orderType: 'FEA',
              downPayment: '',
            },
          ],
        },
        {
          mtn: '4107397731',
        },
      ];
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = screen.getByRole('button', { name: 'Proceed with Quote' });
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
    });

    test('renders Footer content', async () => {
      window.cartProducts = [
        {
          mtn: 'newLine1',
          current: [
            {
              name: 'iPhone 16 Pro Max',
              lineHash: '',
              sku: 'sku6016050',
              shared: 'N',
              id: 'MYW53LL/A',
              category: 'Device',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 33.33,
              nonRecurringPrice: 1199.99,
              shippingCharge: 0,
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              line: 0,
              contractType: '',
            },
            {
              name: 'Apple iPhone 14 256GB Purple',
              lineHash: '',
              sku: '358265580971304',
              shared: 'N',
              id: 'MLAX3LL/A',
              category: 'Trade-Device',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 0,
              nonRecurringPrice: 195,
              shippingCharge: 0,
              orderType: 'TradeIn',
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              line: null,
              contractType: '',
              type: 'deviceProtection',
            },
            {
              name: 'Verizon Mobile Protect Multi-Device',
              line: 0,
              lineHash: '',
              sku: '2663',
              shared: 'Y',
              contractType: '',
              id: '2663',
              category: 'Feature',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 68,
              nonRecurringPrice: 0,
              shippingCharge: 0,
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              orderType: 'FEA',
              downPayment: '',
            },
          ],
        },
        {
          mtn: '4107397731',
        },
      ];
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = screen.getByRole('button', { name: 'Proceed with Quote' });
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
    });
  });

  describe('Footer with VHI Lite', () => {
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          vhiLiteAckModalFFlag: 'TRUE',
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          enableShareQuoteinAIQuoteFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
        }),
      );

      sessionStorage.setItem('fiveGHomeInternetSelectedFlow', 'VHILite');
      sessionStorage.setItem('vhiLiteQualified', 'true');
      render(
        <Footer
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          setFPSProtectionData={setFPSProtectionData}
          FetchPricingSnapShotResult={fpsNew}
          linesWithoutProtection={[{ mtn: 'newLine1' }]}
          showPriceDetails
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          disableProceedToQuote={false}
          mandatoryNumberShareLines={[{ mtn: 'newLine1' }]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });

    test('renders Footer content', async () => {
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => setTimeout(res, 1000));
      const footercomponent = screen.getByTestId('footercomponent');
      Emitter.emit('TRIGGER_AIQUOTE_FPS_CALL', true);
      fireEvent.click(footercomponent);
      Emitter.emit('FetchPricingSnaphotResult', FetchPricingSnapshot);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
    });
    test('renders Footer content', async () => {
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => setTimeout(res, 1000));
      const footercomponent = screen.getByLabelText('Expand Footer');
      fireEvent.click(footercomponent);
    });
    test('renders Footer content', async () => {
      window.cartProducts = [
        {
          mtn: 'newLine1',
          current: [
            {
              name: 'iPhone 16 Pro Max',
              lineHash: '',
              sku: 'sku6016050',
              shared: 'N',
              id: 'MYW53LL/A',
              category: 'Device',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 33.33,
              nonRecurringPrice: 1199.99,
              shippingCharge: 0,
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              line: 0,
              contractType: '',
            },
            {
              name: 'Apple iPhone 13 256GB Red',
              lineHash: '',
              sku: '358265580971304',
              shared: 'N',
              id: 'MLAX3LL/A',
              category: 'Trade-Device',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 0,
              nonRecurringPrice: 195,
              shippingCharge: 0,
              orderType: 'TradeIn',
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              line: null,
              contractType: '',
              type: 'deviceProtection',
            },
            {
              name: 'Verizon Mobile Protect Multi-Device',
              line: 0,
              lineHash: '',
              sku: '2663',
              shared: 'Y',
              contractType: '',
              id: '2663',
              category: 'Feature',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 68,
              nonRecurringPrice: 0,
              shippingCharge: 0,
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              orderType: 'FEA',
              downPayment: '',
            },
          ],
        },
        {
          mtn: '4107397731',
        },
      ];
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      await new Promise((res) => setTimeout(res, 1000));
      const proceedtoCart = screen.getByRole('button', { name: 'Proceed with Quote' });
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
    });

    test('renders Footer content', async () => {
      window.cartProducts = [
        {
          mtn: 'newLine1',
          current: [
            {
              name: 'iPhone 16 Pro Max',
              lineHash: '',
              sku: 'sku6016050',
              shared: 'N',
              id: 'MYW53LL/A',
              category: 'Device',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 33.33,
              nonRecurringPrice: 1199.99,
              shippingCharge: 0,
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              line: 0,
              contractType: '',
            },
            {
              name: 'Apple iPhone 14 256GB Purple',
              lineHash: '',
              sku: '358265580971304',
              shared: 'N',
              id: 'MLAX3LL/A',
              category: 'Trade-Device',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 0,
              nonRecurringPrice: 195,
              shippingCharge: 0,
              orderType: 'TradeIn',
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              line: null,
              contractType: '',
              type: 'deviceProtection',
            },
            {
              name: 'Verizon Mobile Protect Multi-Device',
              line: 0,
              lineHash: '',
              sku: '2663',
              shared: 'Y',
              contractType: '',
              id: '2663',
              category: 'Feature',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 68,
              nonRecurringPrice: 0,
              shippingCharge: 0,
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              orderType: 'FEA',
              downPayment: '',
            },
          ],
        },
        {
          mtn: '4107397731',
        },
      ];
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      await new Promise((res) => setTimeout(res, 1000));
      const proceedtoCart = screen.getByRole('button', { name: 'Proceed with Quote' });
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
      const continueButton = screen.getByTestId('home-internet-lite-modal-continue');
      fireEvent.click(continueButton);

      // await waitFor(() => {
      //   expect(screen.getByText('Proceed')).toBeInTheDocument();
      // });
    });

    test('renders Footer content cancel button', async () => {
      window.cartProducts = [
        {
          mtn: 'newLine1',
          current: [
            {
              name: 'iPhone 16 Pro Max',
              lineHash: '',
              sku: 'sku6016050',
              shared: 'N',
              id: 'MYW53LL/A',
              category: 'Device',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 33.33,
              nonRecurringPrice: 1199.99,
              shippingCharge: 0,
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              line: 0,
              contractType: '',
            },
            {
              name: 'Apple iPhone 14 256GB Purple',
              lineHash: '',
              sku: '358265580971304',
              shared: 'N',
              id: 'MLAX3LL/A',
              category: 'Trade-Device',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 0,
              nonRecurringPrice: 195,
              shippingCharge: 0,
              orderType: 'TradeIn',
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              line: null,
              contractType: '',
              type: 'deviceProtection',
            },
            {
              name: 'Verizon Mobile Protect Multi-Device',
              line: 0,
              lineHash: '',
              sku: '2663',
              shared: 'Y',
              contractType: '',
              id: '2663',
              category: 'Feature',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 68,
              nonRecurringPrice: 0,
              shippingCharge: 0,
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              orderType: 'FEA',
              downPayment: '',
            },
          ],
        },
        {
          mtn: '4107397731',
        },
      ];
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      await new Promise((res) => setTimeout(res, 1000));
      const proceedtoCart = screen.getByRole('button', { name: 'Proceed with Quote' });
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
      const cancelButton = screen.getByTestId('home-internet-lite-modal-cancel');
      fireEvent.click(cancelButton);
    });
  });

  describe('Footer for Verizon visa card', () => {
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          enableShareQuoteinAIQuoteFFlag: 'TRUE',
          isAiQuoteVVCEnabledFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
        }),
      );
      sessionStorage.setItem('customerType', 'N');
      sessionStorage.setItem('location', '0026301');
      render(
        <Footer
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          setFPSProtectionData={setFPSProtectionData}
          FetchPricingSnapShotResult={fpsNew}
          linesWithoutProtection={[{ mtn: 'newLine1' }]}
          showPriceDetails
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          disableProceedToQuote={false}
          mandatoryNumberShareLines={[{ mtn: 'newLine1' }]}
          callCreateApplication
          isAutopayEnabled
          autopayDiscount={50}
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });

    test('renders Footer content', async () => {
      window.cartProducts = [
        {
          mtn: 'newLine1',
          current: [
            {
              name: 'iPhone 16 Pro Max',
              lineHash: '',
              sku: 'sku6016050',
              shared: 'N',
              id: 'MYW53LL/A',
              category: 'Device',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 33.33,
              nonRecurringPrice: 1199.99,
              shippingCharge: 0,
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              line: 0,
              contractType: '',
            },
            {
              name: 'Apple iPhone 14 256GB Purple',
              lineHash: '',
              sku: '358265580971304',
              shared: 'N',
              id: 'MLAX3LL/A',
              category: 'Trade-Device',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 0,
              nonRecurringPrice: 195,
              shippingCharge: 0,
              orderType: 'TradeIn',
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              line: null,
              contractType: '',
              type: 'deviceProtection',
            },
            {
              name: 'Verizon Mobile Protect Multi-Device',
              line: 0,
              lineHash: '',
              sku: '2663',
              shared: 'Y',
              contractType: '',
              id: '2663',
              category: 'Feature',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 68,
              nonRecurringPrice: 0,
              shippingCharge: 0,
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              orderType: 'FEA',
              downPayment: '',
            },
          ],
        },
        {
          mtn: '4107397731',
        },
      ];
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = screen.getByRole('button', { name: 'Proceed with Quote' });
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
    });
  });

  describe('Footer for Verizon visa card', () => {
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          enableShareQuoteinAIQuoteFFlag: 'TRUE',
          isAiQuoteVVCEnabledFFlag: 'FALSE',
          montanaOfferEnableFFlag: 'TRUE',
        }),
      );
      sessionStorage.setItem('customerType', 'N');
      sessionStorage.setItem('location', '0026301');
      render(
        <Footer
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          setFPSProtectionData={setFPSProtectionData}
          FetchPricingSnapShotResult={fpsNew}
          linesWithoutProtection={[{ mtn: 'newLine1' }]}
          showPriceDetails
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          disableProceedToQuote={false}
          mandatoryNumberShareLines={[{ mtn: 'newLine1' }]}
          callCreateApplication
          isAutopayEnabled
          autopayDiscount={50}
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });

    test('renders Footer content', async () => {
      window.cartProducts = [
        {
          mtn: 'newLine1',
          current: [
            {
              name: 'iPhone 16 Pro Max',
              lineHash: '',
              sku: 'sku6016050',
              shared: 'N',
              id: 'MYW53LL/A',
              category: 'Device',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 33.33,
              nonRecurringPrice: 1199.99,
              shippingCharge: 0,
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              line: 0,
              contractType: '',
            },
            {
              name: 'Apple iPhone 14 256GB Purple',
              lineHash: '',
              sku: '358265580971304',
              shared: 'N',
              id: 'MLAX3LL/A',
              category: 'Trade-Device',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 0,
              nonRecurringPrice: 195,
              shippingCharge: 0,
              orderType: 'TradeIn',
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              line: null,
              contractType: '',
              type: 'deviceProtection',
            },
            {
              name: 'Verizon Mobile Protect Multi-Device',
              line: 0,
              lineHash: '',
              sku: '2663',
              shared: 'Y',
              contractType: '',
              id: '2663',
              category: 'Feature',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 68,
              nonRecurringPrice: 0,
              shippingCharge: 0,
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              orderType: 'FEA',
              downPayment: '',
            },
          ],
        },
        {
          mtn: '4107397731',
        },
      ];
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = screen.getByRole('button', { name: 'Proceed with Quote' });
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
    });
  });

  describe('Footer for Verizon visa card', () => {
    const newCustomerBio = { ...customerBio, isEnglishLanguage: true };
    beforeEach(() => {
      sessionStorage.removeItem('customerType');
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          enableShareQuoteinAIQuoteFFlag: 'TRUE',
          isAiQuoteVVCEnabledFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
        }),
      );
      window.history.pushState({}, 'AIQuote', `sposstore-soe-nssit3.vzwcorp.com?customerType=N`);
      sessionStorage.setItem('location', '0026301');
      render(
        <Footer
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          setFPSProtectionData={setFPSProtectionData}
          FetchPricingSnapShotResult={fpsNew}
          linesWithoutProtection={[{ mtn: 'newLine1' }]}
          showPriceDetails
          customerBio={newCustomerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          disableProceedToQuote={false}
          mandatoryNumberShareLines={[{ mtn: 'newLine1' }]}
          callCreateApplication
          isAutopayEnabled
          autopayDiscount={50}
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });

    test('renders Footer content', async () => {
      window.cartProducts = [
        {
          mtn: 'newLine1',
          current: [
            {
              name: 'iPhone 16 Pro Max',
              lineHash: '',
              sku: 'sku6016050',
              shared: 'N',
              id: 'MYW53LL/A',
              category: 'Device',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 33.33,
              nonRecurringPrice: 1199.99,
              shippingCharge: 0,
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              line: 0,
              contractType: '',
            },
            {
              name: 'Apple iPhone 14 256GB Purple',
              lineHash: '',
              sku: '358265580971304',
              shared: 'N',
              id: 'MLAX3LL/A',
              category: 'Trade-Device',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 0,
              nonRecurringPrice: 195,
              shippingCharge: 0,
              orderType: 'TradeIn',
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              line: null,
              contractType: '',
              type: 'deviceProtection',
            },
            {
              name: 'Verizon Mobile Protect Multi-Device',
              line: 0,
              lineHash: '',
              sku: '2663',
              shared: 'Y',
              contractType: '',
              id: '2663',
              category: 'Feature',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 68,
              nonRecurringPrice: 0,
              shippingCharge: 0,
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              orderType: 'FEA',
              downPayment: '',
            },
          ],
        },
        {
          mtn: '4107397731',
        },
      ];
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = screen.getByRole('button', { name: 'Proceed with Quote' });
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
    });
  });

  describe('Footer for Verizon visa card', () => {
    const newCustomerBio = { ...customerBio, isEnglishLanguage: true };
    beforeEach(() => {
      sessionStorage.removeItem('customerType');
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          enableShareQuoteinAIQuoteFFlag: 'TRUE',
          isAiQuoteVVCEnabledFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
        }),
      );
      window.history.pushState({}, 'AIQuote', `sposstore-soe-nssit3.vzwcorp.com?customerType=PE`);
      sessionStorage.setItem('location', '0026301');
      render(
        <Footer
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          setFPSProtectionData={setFPSProtectionData}
          FetchPricingSnapShotResult={fpsNew}
          linesWithoutProtection={[{ mtn: 'newLine1' }]}
          showPriceDetails
          customerBio={newCustomerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          disableProceedToQuote={false}
          mandatoryNumberShareLines={[{ mtn: 'newLine1' }]}
          callCreateApplication
          isAutopayEnabled
          autopayDiscount={50}
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });

    test('renders Footer content', async () => {
      window.cartProducts = [
        {
          mtn: 'newLine1',
          current: [
            {
              name: 'iPhone 16 Pro Max',
              lineHash: '',
              sku: 'sku6016050',
              shared: 'N',
              id: 'MYW53LL/A',
              category: 'Device',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 33.33,
              nonRecurringPrice: 1199.99,
              shippingCharge: 0,
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              line: 0,
              contractType: '',
            },
            {
              name: 'Apple iPhone 14 256GB Purple',
              lineHash: '',
              sku: '358265580971304',
              shared: 'N',
              id: 'MLAX3LL/A',
              category: 'Trade-Device',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 0,
              nonRecurringPrice: 195,
              shippingCharge: 0,
              orderType: 'TradeIn',
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              line: null,
              contractType: '',
              type: 'deviceProtection',
            },
            {
              name: 'Verizon Mobile Protect Multi-Device',
              line: 0,
              lineHash: '',
              sku: '2663',
              shared: 'Y',
              contractType: '',
              id: '2663',
              category: 'Feature',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 68,
              nonRecurringPrice: 0,
              shippingCharge: 0,
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              orderType: 'FEA',
              downPayment: '',
            },
          ],
        },
        {
          mtn: '4107397731',
        },
      ];
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = screen.getByRole('button', { name: 'Proceed with Quote' });
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
    });
  });

  describe('Footer - Prospect Montana and Personal Shopper Tab Switching', () => {
    const handlers = [
      rest.post(`*fetchPricingSnapshot`, (req, res, ctx) => res(ctx.status(200), ctx.json(fpsNew))),
      rest.post(`*processAcctInquiryTranDetails`, (req, res, ctx) =>
        res(
          ctx.status(200),
          ctx.json({
            data: {
              statusMessage: 'Success',
              uniqueKey: '1710886290738',
              pkSequence: null,
              errors: null,
              status: 1,
            },
          }),
        ),
      ),
    ];
    const server = setupServer(...handlers);
    beforeAll(() => server.listen());
    afterEach(() => {
      server.resetHandlers();
      delete window.mfe;
    });
    afterAll(() => server.close());

    test('should emit tab switching events when isProspectNewCustomerTab and isProspectMontana are true', async () => {
      const personalShopperTabCloseEvents = [];
      const acssSwitchTabEvents = [];

      const personalShopperListener = (data) => personalShopperTabCloseEvents.push(data);
      const acssListener = (data) => acssSwitchTabEvents.push(data);

      Emitter.on('PERSONAL_SHOPPER_TAB_CLOSE', personalShopperListener);
      Emitter.on('ACSS_SCM_SWITCH_TAB', acssListener);

      window.mfe = {
        isProspectNewCustomerTab: true,
        isProspectMontana: true,
        isProspectPersonalShopper: false,
      };

      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          enableShareQuoteinAIQuoteFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
        }),
      );

      render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          FetchPricingSnapShotResult={fpsNew}
          setFPSProtectionData={setFPSProtectionData}
          customerBio={customerBio}
          mtnListPriceEdit={[]}
          isInDirect={false}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );

      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await waitFor(() => {
        const proceedButton = screen.getByTestId('footercomponentButton');
        expect(proceedButton).toBeInTheDocument();
      });

      const proceedButton = screen.getByTestId('footercomponentButton');
      fireEvent.click(proceedButton);

      await waitFor(() => {
        expect(personalShopperTabCloseEvents.length).toBeGreaterThan(0);
        expect(acssSwitchTabEvents.length).toBeGreaterThan(0);
      });

      expect(personalShopperTabCloseEvents[personalShopperTabCloseEvents.length - 1]).toEqual({
        type: 'SWITCH_TAB',
        targetTab: 'PERSONAL_SHOPPER_TAB_CLOSE',
      });
      expect(acssSwitchTabEvents[acssSwitchTabEvents.length - 1]).toEqual({
        type: 'SWITCH_TAB',
        targetTab: 'INSIDE_SALES_ASSIGNED_MTN_TAB',
      });

      Emitter.off('PERSONAL_SHOPPER_TAB_CLOSE', personalShopperListener);
      Emitter.off('ACSS_SCM_SWITCH_TAB', acssListener);
    });

    test('should emit tab switching events when isProspectNewCustomerTab and isProspectPersonalShopper are true', async () => {
      const personalShopperTabCloseEvents = [];
      const acssSwitchTabEvents = [];

      const personalShopperListener = (data) => personalShopperTabCloseEvents.push(data);
      const acssListener = (data) => acssSwitchTabEvents.push(data);

      Emitter.on('PERSONAL_SHOPPER_TAB_CLOSE', personalShopperListener);
      Emitter.on('ACSS_SCM_SWITCH_TAB', acssListener);

      window.mfe = {
        isProspectNewCustomerTab: true,
        isProspectMontana: false,
        isProspectPersonalShopper: true,
      };

      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          enableShareQuoteinAIQuoteFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
        }),
      );

      render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          FetchPricingSnapShotResult={fpsNew}
          setFPSProtectionData={setFPSProtectionData}
          customerBio={customerBio}
          mtnListPriceEdit={[]}
          isInDirect={false}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );

      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await waitFor(() => {
        const proceedButton = screen.getByTestId('footercomponentButton');
        expect(proceedButton).toBeInTheDocument();
      });

      const proceedButton = screen.getByTestId('footercomponentButton');
      fireEvent.click(proceedButton);

      await waitFor(() => {
        expect(personalShopperTabCloseEvents.length).toBeGreaterThan(0);
        expect(acssSwitchTabEvents.length).toBeGreaterThan(0);
      });

      expect(personalShopperTabCloseEvents[personalShopperTabCloseEvents.length - 1]).toEqual({
        type: 'SWITCH_TAB',
        targetTab: 'PERSONAL_SHOPPER_TAB_CLOSE',
      });
      expect(acssSwitchTabEvents[acssSwitchTabEvents.length - 1]).toEqual({
        type: 'SWITCH_TAB',
        targetTab: 'INSIDE_SALES_ASSIGNED_MTN_TAB',
      });

      Emitter.off('PERSONAL_SHOPPER_TAB_CLOSE', personalShopperListener);
      Emitter.off('ACSS_SCM_SWITCH_TAB', acssListener);
    });

    test('should NOT emit tab switching events when isProspectNewCustomerTab is false', async () => {
      const personalShopperTabCloseEvents = [];
      const acssSwitchTabEvents = [];
      const setIsProceedToQuoteMock = jest.fn();

      const personalShopperListener = (data) => personalShopperTabCloseEvents.push(data);
      const acssListener = (data) => acssSwitchTabEvents.push(data);

      Emitter.on('PERSONAL_SHOPPER_TAB_CLOSE', personalShopperListener);
      Emitter.on('ACSS_SCM_SWITCH_TAB', acssListener);

      window.mfe = {
        isProspectNewCustomerTab: false,
        isProspectMontana: true,
        isProspectPersonalShopper: true,
      };

      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          enableShareQuoteinAIQuoteFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
        }),
      );

      render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={setIsProceedToQuoteMock}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          FetchPricingSnapShotResult={fpsNew}
          setFPSProtectionData={setFPSProtectionData}
          customerBio={customerBio}
          mtnListPriceEdit={[]}
          isInDirect={false}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );

      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await waitFor(() => {
        const proceedButton = screen.getByTestId('footercomponentButton');
        expect(proceedButton).toBeInTheDocument();
      });

      const proceedButton = screen.getByTestId('footercomponentButton');
      fireEvent.click(proceedButton);

      await waitFor(() => {
        expect(setIsProceedToQuoteMock).toHaveBeenCalledWith(true);
      });

      // Verify tab switching events were NOT emitted after click (initial event count remains)
      const initialEventCount = personalShopperTabCloseEvents.length;
      await new Promise((res) => {
        setTimeout(res, 500);
      });
      expect(personalShopperTabCloseEvents.length).toBe(initialEventCount);
      expect(acssSwitchTabEvents.length).toBe(0);

      Emitter.off('PERSONAL_SHOPPER_TAB_CLOSE', personalShopperListener);
      Emitter.off('ACSS_SCM_SWITCH_TAB', acssListener);
    });

    test('should NOT emit tab switching events when neither isProspectMontana nor isProspectPersonalShopper are true', async () => {
      const personalShopperTabCloseEvents = [];
      const acssSwitchTabEvents = [];
      const setIsProceedToQuoteMock = jest.fn();

      const personalShopperListener = (data) => personalShopperTabCloseEvents.push(data);
      const acssListener = (data) => acssSwitchTabEvents.push(data);

      Emitter.on('PERSONAL_SHOPPER_TAB_CLOSE', personalShopperListener);
      Emitter.on('ACSS_SCM_SWITCH_TAB', acssListener);

      window.mfe = {
        isProspectNewCustomerTab: true,
        isProspectMontana: false,
        isProspectPersonalShopper: false,
      };

      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          enableShareQuoteinAIQuoteFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
        }),
      );

      render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={setIsProceedToQuoteMock}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          FetchPricingSnapShotResult={fpsNew}
          setFPSProtectionData={setFPSProtectionData}
          customerBio={customerBio}
          mtnListPriceEdit={[]}
          isInDirect={false}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );

      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await waitFor(() => {
        const proceedButton = screen.getByTestId('footercomponentButton');
        expect(proceedButton).toBeInTheDocument();
      });

      const proceedButton = screen.getByTestId('footercomponentButton');
      fireEvent.click(proceedButton);

      await waitFor(() => {
        expect(setIsProceedToQuoteMock).toHaveBeenCalledWith(true);
      });

      // Verify tab switching events were NOT emitted
      await new Promise((res) => {
        setTimeout(res, 500);
      });
      expect(personalShopperTabCloseEvents.length).toBe(0);
      expect(acssSwitchTabEvents.length).toBe(0);

      Emitter.off('PERSONAL_SHOPPER_TAB_CLOSE', personalShopperListener);
      Emitter.off('ACSS_SCM_SWITCH_TAB', acssListener);
    });
  });

  describe('Footer for Verizon visa card', () => {
    const newCustomerBio = { ...customerBio, isEnglishLanguage: true };
    beforeEach(() => {
      sessionStorage.removeItem('customerType');
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          enableShareQuoteinAIQuoteFFlag: 'TRUE',
          isAiQuoteVVCEnabledFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
        }),
      );
      window.history.pushState({}, 'AIQuote', `sposstore-soe-nssit3.vzwcorp.com`);
      sessionStorage.setItem('location', '0026301');
      render(
        <Footer
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          setFPSProtectionData={setFPSProtectionData}
          FetchPricingSnapShotResult={fpsNew}
          linesWithoutProtection={[{ mtn: 'newLine1' }]}
          showPriceDetails
          customerBio={newCustomerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          disableProceedToQuote={false}
          mandatoryNumberShareLines={[{ mtn: 'newLine1' }]}
          callCreateApplication
          isAutopayEnabled
          autopayDiscount={50}
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });

    test('renders Footer content', async () => {
      window.cartProducts = [
        {
          mtn: 'newLine1',
          current: [
            {
              name: 'iPhone 16 Pro Max',
              lineHash: '',
              sku: 'sku6016050',
              shared: 'N',
              id: 'MYW53LL/A',
              category: 'Device',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 33.33,
              nonRecurringPrice: 1199.99,
              shippingCharge: 0,
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              line: 0,
              contractType: '',
            },
            {
              name: 'Apple iPhone 14 256GB Purple',
              lineHash: '',
              sku: '358265580971304',
              shared: 'N',
              id: 'MLAX3LL/A',
              category: 'Trade-Device',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 0,
              nonRecurringPrice: 195,
              shippingCharge: 0,
              orderType: 'TradeIn',
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              line: null,
              contractType: '',
              type: 'deviceProtection',
            },
            {
              name: 'Verizon Mobile Protect Multi-Device',
              line: 0,
              lineHash: '',
              sku: '2663',
              shared: 'Y',
              contractType: '',
              id: '2663',
              category: 'Feature',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 68,
              nonRecurringPrice: 0,
              shippingCharge: 0,
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              orderType: 'FEA',
              downPayment: '',
            },
          ],
        },
        {
          mtn: '4107397731',
        },
      ];
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = screen.getByRole('button', { name: 'Proceed with Quote' });
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
    });
  });

  describe('Ai Quote Footer', () => {
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          enableShareQuoteinAIQuoteFFlag: 'TRUE',
          fiosReferralOnRCFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
        }),
      );
      render(
        <Footer
          isAIQuote
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          setFPSProtectionData={setFPSProtectionData}
          FetchPricingSnapShotResult={fpsNew}
          linesWithoutProtection={[{ mtn: 'newLine1' }]}
          showPriceDetails
          customerBio={customerBio}
          isFiosEnabled
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          disableProceedToQuote
          mandatoryNumberShareLines={[{ mtn: 'newLine1' }]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });

    test('renders Footer content for Ai Quote with disabled proceed to quote', async () => {
      window.cartProducts = [
        {
          mtn: 'newLine1',
          current: [
            {
              name: 'iPhone 16 Pro Max',
              lineHash: '',
              sku: 'sku6016050',
              shared: 'N',
              id: 'MYW53LL/A',
              category: 'Device',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 33.33,
              nonRecurringPrice: 1199.99,
              shippingCharge: 0,
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              line: 0,
              contractType: '',
            },
            {
              name: 'Apple iPhone 14 256GB Purple',
              lineHash: '',
              sku: '358265580971304',
              shared: 'N',
              id: 'MLAX3LL/A',
              category: 'Trade-Device',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 0,
              nonRecurringPrice: 195,
              shippingCharge: 0,
              orderType: 'TradeIn',
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              line: null,
              contractType: '',
              type: 'deviceProtection',
            },
            {
              name: 'Verizon Mobile Protect Multi-Device',
              line: 0,
              lineHash: '',
              sku: '2663',
              shared: 'Y',
              contractType: '',
              id: '2663',
              category: 'Feature',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 68,
              nonRecurringPrice: 0,
              shippingCharge: 0,
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              orderType: 'FEA',
              downPayment: '',
            },
          ],
        },
        {
          mtn: '4107397731',
        },
      ];
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = screen.getByRole('button', { name: 'Proceed with Quote' });
      expect(proceedtoCart).toBeDisabled();
    });
  });

  describe('Footer component CSIS flow', () => {
    const handlers = [
      rest.post(`*fetchPricingSnapshot`, (req, res, ctx) => {
        console.log('inside FPS mock');
        return res(ctx.status(200), ctx.json(FetchPricingSnapshot));
      }),
      rest.post(`*processAcctInquiryTranDetails`, (req, res, ctx) => {
        console.log('inside mock');
        return res(
          ctx.status(200),
          ctx.json({
            data: {
              statusMessage: 'Success',
              uniqueKey: '1710886290738',
              pkSequence: null,
              errors: null,
              status: 1,
            },
          }),
        );
      }),
    ];
    const vzdlMock = window.vzdl;
    delete window.vzdl;
    window.vzdl = {
      ...vzdlMock,
      page: { detail: 'Footer', throttle: 'MFE' },
      event: { value: 'scAdd' },
      txn: { product: { current: [] }, nonRecurringPrice: 0 },
    };
    const server = setupServer(...handlers);
    const redirectToFlexOrdering = jest.fn().mockName('redirectToFlexOrdering');
    const CSISFlag = true;
    const linesWithQuoteInCart = [{}, {}, {}];
    const createAiQuoteResCollection = [
      {
        intentType: 'AAL',
        propositionName: 'Connected Devices',
        offerRecommendations: [{ rank: '1', isRtdOffer: 'Y' }],
      },
    ];
    beforeAll(() => server.listen());
    afterEach(() => server.resetHandlers());
    afterAll(() => server.close());
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          fiosReferralOnRCFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
        }),
      );
      render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          isInsideSalesorCustomerService={CSISFlag}
          redirectToFlexOrdering={redirectToFlexOrdering}
          setIsManualTriage={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          createAiQuoteResCollection={createAiQuoteResCollection}
          linesWithQuoteInCart={linesWithQuoteInCart}
          FetchPricingSnapShotResult={fpsNew}
          aiquoteResponse={aiQuoteResponseJSON}
          setFPSProtectionData={setFPSProtectionData}
          linesWithoutProtection={[]}
          isCollaborationStartedForRC
          showPriceDetails
          setTaggingPayload={jest.fn()}
          isFiosEnabled
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          mandatoryNumberShareLines={[]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });
    test('renders Footer content', async () => {
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('FETCH_CART_LINE_DETAILS');
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: true,
      });
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: false,
      });
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {});
      Emitter.emit('Closing_Device_Protection_Modal', {});
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });
  });
  describe('Footer component CSIS flow', () => {
    const handlers = [
      rest.post(`*fetchPricingSnapshot`, (req, res, ctx) => {
        console.log('inside FPS mock');
        return res(ctx.status(200), ctx.json(FetchPricingSnapshot));
      }),
      rest.post(`*processAcctInquiryTranDetails`, (req, res, ctx) => {
        console.log('inside mock');
        return res(
          ctx.status(200),
          ctx.json({
            data: {
              statusMessage: 'Success',
              uniqueKey: '1710886290738',
              pkSequence: null,
              errors: null,
              status: 1,
            },
          }),
        );
      }),
    ];
    const vzdlMock = window.vzdl;
    delete window.vzdl;
    window.vzdl = {
      ...vzdlMock,
      page: { detail: 'Footer', throttle: 'MFE' },
      event: { value: 'scAdd' },
      txn: { product: { current: [] }, nonRecurringPrice: 0 },
    };
    const server = setupServer(...handlers);
    const redirectToFlexOrdering = jest.fn().mockName('redirectToFlexOrdering');
    const CSISFlag = true;
    const linesWithQuoteInCart = [{}, {}, {}];
    const createAiQuoteResCollection = [
      {
        intentType: 'AAL',
        propositionName: 'Connected Devices',
        offerRecommendations: [{ rank: '1', isRtdOffer: 'Y' }],
      },
    ];
    beforeAll(() => server.listen());
    afterEach(() => server.resetHandlers());
    afterAll(() => server.close());
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          fiosReferralOnRCFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
        }),
      );
      render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          isInsideSalesorCustomerService={CSISFlag}
          redirectToFlexOrdering={redirectToFlexOrdering}
          setIsManualTriage={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          createAiQuoteResCollection={createAiQuoteResCollection}
          linesWithQuoteInCart={linesWithQuoteInCart}
          FetchPricingSnapShotResult={fpsWithCartItemJSON}
          aiquoteResponse={aiQuoteResponseJSON}
          setFPSProtectionData={setFPSProtectionData}
          linesWithoutProtection={[]}
          isCollaborationStartedForRC
          showPriceDetails
          isFiosEnabled
          setTaggingPayload={jest.fn()}
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          mandatoryNumberShareLines={[]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });
    test('renders Footer content', async () => {
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('FETCH_CART_LINE_DETAILS');
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: true,
      });
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: false,
      });
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {});
      Emitter.emit('Closing_Device_Protection_Modal', {});
      Emitter.emit('Priority_upgrade_List', [{ isPriorityMtn: true, mtn: '838432442234' }]);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });
  });
  describe('Footer component CSIS flow', () => {
    const handlers = [
      rest.post(`*fetchPricingSnapshot`, (req, res, ctx) => {
        console.log('inside FPS mock');
        return res(ctx.status(200), ctx.json(FetchPricingSnapshot));
      }),
      rest.post(`*processAcctInquiryTranDetails`, (req, res, ctx) => {
        console.log('inside mock');
        return res(
          ctx.status(200),
          ctx.json({
            data: {
              statusMessage: 'Success',
              uniqueKey: '1710886290738',
              pkSequence: null,
              errors: null,
              status: 1,
            },
          }),
        );
      }),
    ];
    const vzdlMock = window.vzdl;
    delete window.vzdl;
    window.vzdl = {
      ...vzdlMock,
      page: { detail: 'Footer', throttle: 'MFE' },
      event: { value: 'scAdd' },
      txn: { product: { current: [] }, nonRecurringPrice: 0 },
    };
    const server = setupServer(...handlers);
    const redirectToFlexOrdering = jest.fn().mockName('redirectToFlexOrdering');
    const CSISFlag = true;
    const linesWithQuoteInCart = [{}, {}, {}];
    const createAiQuoteResCollection = [
      {
        intentType: 'AAL',
        propositionName: 'Connected Devices',
        offerRecommendations: [{ rank: '1', isRtdOffer: 'Y' }],
      },
    ];
    beforeAll(() => server.listen());
    afterEach(() => server.resetHandlers());
    afterAll(() => server.close());
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          fiosReferralOnRCFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
        }),
      );
      render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          isInsideSalesorCustomerService={CSISFlag}
          redirectToFlexOrdering={redirectToFlexOrdering}
          setIsManualTriage={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          createAiQuoteResCollection={createAiQuoteResCollection}
          linesWithQuoteInCart={linesWithQuoteInCart}
          FetchPricingSnapShotResult={fpsWithNoCartItemJSON}
          aiquoteResponse={aiQuoteResponseJSON}
          setFPSProtectionData={setFPSProtectionData}
          linesWithoutProtection={[]}
          isCollaborationStartedForRC
          showPriceDetails
          isFiosEnabled
          setTaggingPayload={jest.fn()}
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          mandatoryNumberShareLines={[]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });
    test('renders Footer content', async () => {
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('FETCH_CART_LINE_DETAILS');
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: true,
      });
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: false,
      });
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {});
      Emitter.emit('Closing_Device_Protection_Modal', {});
      Emitter.emit('Priority_upgrade_List', [{ isPriorityMtn: true, mtn: '838432442234' }]);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });
  });

  describe('Footer component updateVision Remark', () => {
    const handlers = [
      rest.post(`*processAcctInquiryTranDetails`, (req, res, ctx) => {
        console.log('inside mock');
        return res(
          ctx.status(200),
          ctx.json({
            data: {
              statusMessage: 'Success',
              uniqueKey: '1710886290738',
              pkSequence: null,
              errors: null,
              status: 1,
            },
          }),
        );
      }),
      rest.post(`*updateVisionRemark`, (req, res, ctx) => {
        console.log('inside FPS mock');
        return res(
          ctx.status(200),
          ctx.json({
            data: {
              statusMessage: 'Success',
              uniqueKey: '1710886290738',
              pkSequence: null,
              errors: null,
              status: 1,
            },
          }),
        );
      }),
    ];
    const fpsOfferDetails = {
      data: {
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '3025455388',
                  appliedOffers: {
                    appliedOffersList: [
                      {
                        offerId: '554871',
                        description: 'UAT BIC PR00030603 250 00 OFF A71 VIA RECURRING BIC - APP ONLY -Restricted',
                        discountedRetailPrice: 949.99,
                        discAmt: 250.0,
                        offerSubType: 'Simple',
                        isStrategicOffer: true,
                        itemMonthlyDiscount: 6.94,
                        itemMonthlyDiscountedPrice: 26.38,
                        bicNoOfOccurences: '36',
                        itemMonthlyRetailPrice: 949.99,
                        promoType: 'BIC',
                        monthlySavingAmount: 6.94,
                      },
                    ],
                  },
                },
              ],
            },
          ],
        },
      },
    };

    const fpsWithNewLine = {
      status: 'fulfilled',
      data: {
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: 'newLine1',
                  flags: {
                    lineActivityType: 'AAL',
                    isNewLine: true,
                  },
                  addons: [
                    {
                      type: 'SFO',
                    },
                  ],
                },
              ],
            },
          ],
        },
      },
    };
    const fpsWithNewCustomer = {
      status: 'fulfilled',
      data: {
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: 'newLine1',
                  flags: {
                    lineActivityType: 'NSE',
                    isNewLine: true,
                  },
                  addons: [
                    {
                      type: 'SFO',
                    },
                  ],
                },
              ],
            },
          ],
        },
      },
    };

    const server = setupServer(...handlers);
    const redirectToFlexOrdering = jest.fn().mockName('redirectToFlexOrdering');
    beforeAll(() => server.listen());
    afterEach(() => server.resetHandlers());
    afterAll(() => server.close());
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          fiosReferralOnRCFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
        }),
      );
      render(
        <Footer
          isAIQuote
          billingSystem='VE'
          deviceRecom={deviceRecommendations}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          redirectToFlexOrdering={redirectToFlexOrdering}
          newLinesWithoutQuote={[]}
          setIsManualTriage={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          FetchPricingSnapShotResult={fpsOfferDetails}
          aiquoteResponse={aiQuoteResponseJSON}
          setFPSProtectionData={setFPSProtectionData}
          linesWithQuoteInCart={[{ mtn: 'newLine1' }]}
          linesWithoutProtection={[]}
          isCollaborationStartedForRC
          showPriceDetails
          isFiosEnabled
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          mandatoryNumberShareLines={[]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });
    test('renders Footer content for updateVISIONAPI', async () => {
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });

    test('test footer component with new line', async () => {
      render(
        <Footer
          isAIQuote
          billingSystem='VN'
          deviceRecom={deviceRecommendations}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          redirectToFlexOrdering={redirectToFlexOrdering}
          setIsManualTriage={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          FetchPricingSnapShotResult={fpsWithNewLine}
          aiquoteResponse={aiQuoteResponseJSON}
          inlineShowLoader
          setFPSProtectionData={setFPSProtectionData}
          linesWithQuoteInCart={[{ mtn: 'newLine1' }]}
          linesWithoutProtection={[]}
          isCollaborationStartedForRC
          showPriceDetails
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          mandatoryNumberShareLines={[]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findAllByTestId('footercomponentButton');
      expect(proceedtoCart[0]).not.toBeDisabled();
      fireEvent.click(proceedtoCart[0]);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });
    test('test footer component with new line', async () => {
      render(
        <Footer
          isAIQuote
          billingSystem='VN'
          deviceRecom={deviceRecommendations}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          redirectToFlexOrdering={redirectToFlexOrdering}
          setIsManualTriage={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          FetchPricingSnapShotResult={fpsWithNewCustomer}
          aiquoteResponse={aiQuoteResponseJSON}
          inlineShowLoader
          setFPSProtectionData={setFPSProtectionData}
          linesWithQuoteInCart={[{ mtn: 'newLine1' }]}
          linesWithoutProtection={[]}
          isCollaborationStartedForRC
          showPriceDetails
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          mandatoryNumberShareLines={[]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findAllByTestId('footercomponentButton');
      expect(proceedtoCart[0]).not.toBeDisabled();
      fireEvent.click(proceedtoCart[0]);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });

    test('renders Footer content', async () => {
      render(
        <Footer
          isAIQuote
          billingSystem='VN'
          deviceRecom={deviceRecommendations}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          redirectToFlexOrdering={redirectToFlexOrdering}
          setIsManualTriage={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          FetchPricingSnapShotResult={fpsOfferDetails}
          aiquoteResponse={aiQuoteResponseJSON}
          inlineShowLoader
          setFPSProtectionData={setFPSProtectionData}
          linesWithQuoteInCart={[
            { mtn: 'newLine1' },
            { deviceCategoryName: 'SmartWatch' },
            { lineActivityType: 'EUP' },
            { lineActivityType: 'AAL' },
          ]}
          linesWithoutProtection={[]}
          isCollaborationStartedForRC
          showPriceDetails
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          mandatoryNumberShareLines={[]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findAllByTestId('footercomponentButton');
      expect(proceedtoCart[1]).not.toBeDisabled();
      fireEvent.click(proceedtoCart[1]);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });
  });

  describe('Footer component updateVision Remark', () => {
    const handlers = [
      rest.post(`*processAcctInquiryTranDetails`, (req, res, ctx) => {
        console.log('inside mock');
        return res(
          ctx.status(200),
          ctx.json({
            data: {
              statusMessage: 'Success',
              uniqueKey: '1710886290738',
              pkSequence: null,
              errors: null,
              status: 1,
            },
          }),
        );
      }),
      rest.post(`*updateVisionRemark`, (req, res, ctx) => {
        console.log('inside FPS mock');
        return res(
          ctx.status(200),
          ctx.json({
            data: {
              statusMessage: 'Success',
              uniqueKey: '1710886290738',
              pkSequence: null,
              errors: null,
              status: 1,
            },
          }),
        );
      }),
    ];
    const fpsOfferDetails = {
      data: {
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '3025455388',
                  appliedOffers: {
                    appliedOffersList: [
                      {
                        offerId: '554871',
                        description: 'UAT BIC PR00030603 250 00 OFF A71 VIA RECURRING BIC - APP ONLY -Restricted',
                        discountedRetailPrice: 949.99,
                        discAmt: 250.0,
                        offerSubType: 'Simple',
                        isStrategicOffer: true,
                        itemMonthlyDiscount: 6.94,
                        itemMonthlyDiscountedPrice: 26.38,
                        bicNoOfOccurences: '36',
                        itemMonthlyRetailPrice: 949.99,
                        promoType: 'BIC',
                        monthlySavingAmount: 6.94,
                      },
                    ],
                  },
                },
              ],
            },
          ],
        },
      },
    };

    const fpsWithNewLine = {
      status: 'fulfilled',
      data: {
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: 'newLine1',
                  flags: {
                    lineActivityType: 'AAL',
                    isNewLine: true,
                  },
                  addons: [
                    {
                      type: 'SFO',
                    },
                  ],
                },
              ],
            },
          ],
        },
      },
    };
    const fpsWithNewCustomer = {
      status: 'fulfilled',
      data: {
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: 'newLine1',
                  flags: {
                    lineActivityType: 'NSEBYOD',
                    isNewLine: true,
                  },
                  addons: [
                    {
                      type: 'SFO',
                    },
                  ],
                },
              ],
            },
          ],
        },
      },
    };

    const server = setupServer(...handlers);
    const redirectToFlexOrdering = jest.fn().mockName('redirectToFlexOrdering');
    beforeAll(() => server.listen());
    afterEach(() => server.resetHandlers());
    afterAll(() => server.close());
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          fiosReferralOnRCFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
        }),
      );
      render(
        <Footer
          isAIQuote
          billingSystem='VE'
          deviceRecom={deviceRecommendations}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          redirectToFlexOrdering={redirectToFlexOrdering}
          newLinesWithoutQuote={[]}
          setIsManualTriage={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          FetchPricingSnapShotResult={fpsOfferDetails}
          aiquoteResponse={aiQuoteResponseJSON}
          setFPSProtectionData={setFPSProtectionData}
          linesWithQuoteInCart={[{ mtn: 'newLine1' }]}
          linesWithoutProtection={[]}
          isCollaborationStartedForRC
          showPriceDetails
          isFiosEnabled
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          mandatoryNumberShareLines={[]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });
    test('renders Footer content for updateVISIONAPI', async () => {
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });

    test('test footer component with new line', async () => {
      render(
        <Footer
          isAIQuote
          billingSystem='VN'
          deviceRecom={deviceRecommendations}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          redirectToFlexOrdering={redirectToFlexOrdering}
          setIsManualTriage={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          FetchPricingSnapShotResult={fpsWithNewLine}
          aiquoteResponse={aiQuoteResponseJSON}
          inlineShowLoader
          setFPSProtectionData={setFPSProtectionData}
          linesWithQuoteInCart={[{ mtn: 'newLine1' }]}
          linesWithoutProtection={[]}
          isCollaborationStartedForRC
          showPriceDetails
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          mandatoryNumberShareLines={[]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findAllByTestId('footercomponentButton');
      expect(proceedtoCart[0]).not.toBeDisabled();
      fireEvent.click(proceedtoCart[0]);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });
    test('test footer component with new line', async () => {
      render(
        <Footer
          isAIQuote
          billingSystem='VN'
          deviceRecom={deviceRecommendations}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          redirectToFlexOrdering={redirectToFlexOrdering}
          setIsManualTriage={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          FetchPricingSnapShotResult={fpsWithNewCustomer}
          aiquoteResponse={aiQuoteResponseJSON}
          inlineShowLoader
          setFPSProtectionData={setFPSProtectionData}
          linesWithQuoteInCart={[{ mtn: 'newLine1' }]}
          linesWithoutProtection={[]}
          isCollaborationStartedForRC
          showPriceDetails
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          mandatoryNumberShareLines={[]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findAllByTestId('footercomponentButton');
      expect(proceedtoCart[0]).not.toBeDisabled();
      fireEvent.click(proceedtoCart[0]);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });

    test('renders Footer content', async () => {
      render(
        <Footer
          isAIQuote
          billingSystem='VN'
          deviceRecom={deviceRecommendations}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          redirectToFlexOrdering={redirectToFlexOrdering}
          setIsManualTriage={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          FetchPricingSnapShotResult={fpsOfferDetails}
          aiquoteResponse={aiQuoteResponseJSON}
          inlineShowLoader
          setFPSProtectionData={setFPSProtectionData}
          linesWithQuoteInCart={[
            { mtn: 'newLine1' },
            { deviceCategoryName: 'SmartWatch' },
            { lineActivityType: 'EUP' },
            { lineActivityType: 'AAL' },
          ]}
          linesWithoutProtection={[]}
          isCollaborationStartedForRC
          showPriceDetails
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          mandatoryNumberShareLines={[]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findAllByTestId('footercomponentButton');
      expect(proceedtoCart[1]).not.toBeDisabled();
      fireEvent.click(proceedtoCart[1]);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });
  });

  describe('Footer component - testing remove line popUp', () => {
    const handlers = [
      rest.post(`*processAcctInquiryTranDetails`, (req, res, ctx) => {
        console.log('inside mock');
        return res(
          ctx.status(200),
          ctx.json({
            data: {
              statusMessage: 'Success',
              uniqueKey: '1710886290738',
              pkSequence: null,
              errors: null,
              status: 1,
            },
          }),
        );
      }),
      rest.post(`*remove-lines`, (req, res, ctx) => {
        console.log('inside removeLines mock');
        return res(ctx.status(200), ctx.json(removeLinesJSON));
      }),
    ];

    const server = setupServer(...handlers);
    const redirectToFlexOrdering = jest.fn().mockName('redirectToFlexOrdering');
    beforeAll(() => server.listen());
    afterEach(() => server.resetHandlers());
    afterAll(() => server.close());
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({ enableFullBlownMfeNbsPosFFlag: 'TRUE', montanaOfferEnableFFlag: 'TRUE' }),
      );
      Object.defineProperty(global.navigator, 'userAgent', {
        get() {
          return 'Desktop';
        },
        configurable: true,
      });
      const fetchCartDetailsResult1 = {
        data: {
          data: {
            cart: {
              lineDetails: {
                lineInfo: [
                  {
                    itemsInfo: [
                      {
                        cartItems: {
                          cartItem: undefined,
                        },
                      },
                    ],
                  },
                  {
                    itemsInfo: [
                      {
                        cartItems: {
                          cartItem: [{ cartItemType: 'DEVICE', inventory: { isBackorder: true } }],
                        },
                      },
                    ],
                  },
                ],
              },
            },
          },
        },
      };

      render(
        <Footer
          isAIQuote
          billingSystem='VE'
          deviceRecom={deviceRecommendations}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          redirectToFlexOrdering={redirectToFlexOrdering}
          setIsManualTriage={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setAssistedMtnFromAIQuote={jest.fn()}
          setMtnToBeSelectedWithoutGenratingQuote={jest.fn()}
          newLinesWithoutQuote={[{ mtn: 'newLine1' }, { mtn: 'newLine2' }]}
          aiquoteResponse={aiQuoteResponseJSON}
          setFPSProtectionData={setFPSProtectionData}
          linesWithQuoteInCart={[{ mtn: 'newLine1' }]}
          linesWithoutProtection={[]}
          isCollaborationStartedForRC
          isInsideSalesorCustomerService
          showPriceDetails
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          mandatoryNumberShareLines={[]}
          fetchCartDetailsResult={fetchCartDetailsResult1}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });
    test('renders removeLine popUp on click of proceedWithQuote', async () => {
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCartOne = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCartOne).not.toBeDisabled();
      fireEvent.click(proceedtoCartOne);
      await waitFor(() => screen.findByTestId('Cancel'));
      expect(screen.getByTestId('Cancel')).toBeInTheDocument();
      const proceedtoCartTwo = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCartTwo).not.toBeDisabled();
      fireEvent.click(proceedtoCartTwo);
      const proceedWithQuoteBtn = await screen.findByTestId('ProceedWithQuote');
      expect(proceedWithQuoteBtn).toBeInTheDocument();
      fireEvent.click(proceedWithQuoteBtn);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });

    test('should close removeLine modal and set MTN when Cancel button is clicked', async () => {
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => setTimeout(res, 1000));
      
      const proceedtoCartOne = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCartOne).not.toBeDisabled();
      fireEvent.click(proceedtoCartOne);

      // Modal should be displayed
      const cancelBtn = await screen.findByTestId('Cancel');
      expect(cancelBtn).toBeInTheDocument();

      // Click Cancel button
      fireEvent.click(cancelBtn);

      // Wait a bit for state to update
      await new Promise((res) => setTimeout(res, 100));
    });

    test('renders removeLine popUp on click of proceedWithQuote - removeLine API failure', async () => {
      server.use(rest.post(`*remove-lines`, (req, res, ctx) => res(ctx.status(500), ctx.json({}))));
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCartOne = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCartOne).not.toBeDisabled();
      fireEvent.click(proceedtoCartOne);
      setTimeout(async () => {
        await waitFor(() => expect(screen.findAllByTestId('ProceedWithQuote')));
      }, 2000);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const ProceedWithQuote = screen.getByRole('button', { name: 'Proceed with Quote' });
      fireEvent.click(ProceedWithQuote);
    });

    test('renders footer component on click of proceedWithQuote - AAL flow captureQuoteFeedback call request body ', async () => {
      delete window.vzdl;
      window.cartProducts = [
        {
          mtn: 'newLine1',
          current: [
            {
              name: 'iPhone 16 Pro Max',
              lineHash: '',
              sku: 'sku6016050',
              shared: 'N',
              id: 'MYW53LL/A',
              category: 'Device',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 33.33,
              nonRecurringPrice: 1199.99,
              shippingCharge: 0,
              shippingType: '',
              propId: 'SD_9424',
              path: '',
              group: '',
              action: '',
              line: 0,
              contractType: '',
            },
          ],
        },
        {
          mtn: '4107397731',
          current: [
            {
              name: 'iPhone 16 Pro Max',
              lineHash: 'e0ae74149b07e7c05fe8afbc19012b7d1ccc288496c31e09ad91d90dece950f1',
              sku: 'sku6016050',
              shared: 'N',
              id: 'MYW53LL/A',
              category: 'Device',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 13.05,
              nonRecurringPrice: 1199.99,
              shippingCharge: 0,
              shippingType: '',
              propId: 'SD_9424',
              path: '',
              group: '',
              action: '',
              line: null,
              contractType: '',
              type: 'deviceProtection',
            },
            {
              name: 'Apple iPhone 13 256GB Red',
              lineHash: 'e0ae74149b07e7c05fe8afbc19012b7d1ccc288496c31e09ad91d90dece950f1',
              sku: '358265580971304',
              shared: 'N',
              id: 'MLAX3LL/A',
              category: 'Trade-Device',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 0,
              nonRecurringPrice: 195,
              shippingCharge: 0,
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              line: null,
              contractType: '',
            },
            {
              name: 'Unlimited Plus',
              lineHash: 'e0ae74149b07e7c05fe8afbc19012b7d1ccc288496c31e09ad91d90dece950f1',
              sku: '',
              shared: 'N',
              id: '63217',
              category: 'Plan',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 80,
              nonRecurringPrice: 0,
              shippingCharge: 0,
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              line: null,
              contractType: '',
            },
            {
              name: 'Upgrade fee',
              lineHash: 'e0ae74149b07e7c05fe8afbc19012b7d1ccc288496c31e09ad91d90dece950f1',
              sku: '',
              shared: 'N',
              id: 'UPGRADEFEE',
              category: 'Features',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 0,
              nonRecurringPrice: 35,
              shippingCharge: 0,
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              line: null,
              contractType: '',
            },
            {
              name: 'Disney Bundle',
              lineHash: 'e0ae74149b07e7c05fe8afbc19012b7d1ccc288496c31e09ad91d90dece950f1',
              sku: '',
              shared: 'N',
              contractType: '',
              id: '2641',
              category: 'Features',
              discount: 0,
              qty: 1,
              group: '',
              merchCat: '',
              offer: '',
              recurringPrice: 0,
              nonRecurringPrice: 10,
              shippingCharge: 0,
              shippingType: '',
              propId: '',
              path: '',
              action: '',
              line: null,
            },
            {
              name: 'Netflix & Max (With Ads)',
              lineHash: 'e0ae74149b07e7c05fe8afbc19012b7d1ccc288496c31e09ad91d90dece950f1',
              sku: '',
              shared: 'N',
              contractType: '',
              id: '2839',
              category: 'Features',
              discount: 0,
              qty: 1,
              group: '',
              merchCat: '',
              offer: '',
              recurringPrice: 0,
              nonRecurringPrice: 10,
              shippingCharge: 0,
              shippingType: '',
              propId: '',
              path: '',
              action: '',
              line: null,
            },
          ],
        },
      ];
      render(
        <Footer
          isAIQuote
          activeMtnValue='newLine1'
          deviceRecom={deviceRecommendations}
          deviceTriageDone
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          triggerProceedToQuote
          aiquoteResponse={aiquoteResponseTaggingJSON}
          FetchPricingSnapShotResult={FetchPricingSnapshot}
          setFPSProtectionData={setFPSProtectionData}
          linesWithoutProtection={[{ mtn: 'newLine1' }]}
          isCollaborationStartedForRC
          showPriceDetails
          activeLinePriceTypeInCart='MONTH_TO_MONTH'
          setTaggingPayload={jest.fn()}
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          mandatoryNumberShareLines={[{ mtn: 'newLine1' }]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('FETCH_CART_LINE_DETAILS');
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: true,
      });
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: false,
      });
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {});
      Emitter.emit('Closing_Device_Protection_Modal', {});
      Emitter.emit('Priority_upgrade_List', [{ isPriorityMtn: true, mtn: '302383234' }]);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findAllByTestId('footercomponentButton');
      expect(proceedtoCart[1]).not.toBeDisabled();
      fireEvent.click(proceedtoCart[1]);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });

    test('renders footer component on click of proceedWithQuote - AAL flow captureQuoteFeedback call request body ', async () => {
      delete window.vzdl;
      window.cartProducts = [
        {
          mtn: 'newLine1',
          current: [
            {
              name: 'iPhone 16 Pro Max',
              lineHash: '',
              sku: 'sku6016050',
              shared: 'N',
              id: 'MYW53LL/A',
              category: 'Device',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 33.33,
              nonRecurringPrice: 1199.99,
              shippingCharge: 0,
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              line: 0,
              contractType: '',
            },
          ],
        },
      ];
      const activeLineInfoInCart = [
        {
          deviceTypeSelected: 'BYOD',
        },
      ];
      const acknowledgedBYODConfirmDevice = ['newLine2'];
      render(
        <Footer
          isAIQuote
          activeMtnValue='newLine1'
          deviceRecom={deviceRecommendations}
          deviceTriageDone
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          triggerProceedToQuote
          aiquoteResponse={aiquoteResponseTaggingJSON}
          FetchPricingSnapShotResult={FetchPricingSnapshot}
          setFPSProtectionData={setFPSProtectionData}
          linesWithoutProtection={[{ mtn: 'newLine1' }]}
          isCollaborationStartedForRC
          showPriceDetails
          activeLinePriceTypeInCart='MONTH_TO_MONTH'
          setTaggingPayload={jest.fn()}
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          acknowledgedBYODConfirmDevice={acknowledgedBYODConfirmDevice}
          activeLineInfoInCart={activeLineInfoInCart}
          mandatoryNumberShareLines={[{ mtn: 'newLine1' }]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('FETCH_CART_LINE_DETAILS');
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: true,
      });
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: false,
      });
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {});
      Emitter.emit('Closing_Device_Protection_Modal', {});
      Emitter.emit('Priority_upgrade_List', [{ isPriorityMtn: true, mtn: '302383234' }]);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findAllByTestId('footercomponentButton');
      expect(proceedtoCart[1]).toBeDisabled();
    });
    test('renders removeLine popUp on click of proceedWithQuote for prospect', async () => {
      window.history.pushState({}, 'AIQuote', `sposstore-soe-nssit3.vzwcorp.com?customerType=N`);
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCartOne = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCartOne).not.toBeDisabled();
      fireEvent.click(proceedtoCartOne);
      await waitFor(() => screen.findByTestId('Cancel'));
      expect(screen.getByTestId('Cancel')).toBeInTheDocument();
      const proceedtoCartTwo = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCartTwo).not.toBeDisabled();
      fireEvent.click(proceedtoCartTwo);
      const proceedWithQuoteBtn = await screen.findByTestId('ProceedWithQuote');
      expect(proceedWithQuoteBtn).toBeInTheDocument();
      fireEvent.click(proceedWithQuoteBtn);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });
  });

  describe('Footer component for Indirect cahnnel- testing remove line popUp', () => {
    const handlers = [
      rest.post(`*processAcctInquiryTranDetails`, (req, res, ctx) => {
        console.log('inside mock');
        return res(
          ctx.status(200),
          ctx.json({
            data: {
              statusMessage: 'Success',
              uniqueKey: '1710886290738',
              pkSequence: null,
              errors: null,
              status: 1,
            },
          }),
        );
      }),
      rest.post(`*remove-lines`, (req, res, ctx) => {
        console.log('inside removeLines mock');
        return res(ctx.status(200), ctx.json(removeLinesJSON));
      }),
    ];

    const server = setupServer(...handlers);
    const redirectToFlexOrdering = jest.fn().mockName('redirectToFlexOrdering');
    beforeAll(() => server.listen());
    afterEach(() => server.resetHandlers());
    afterAll(() => server.close());
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          fiosReferralOnRCFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
        }),
      );
      Object.defineProperty(global.navigator, 'userAgent', {
        get() {
          return 'Desktop';
        },
        configurable: true,
      });

      render(
        <Footer
          isAIQuote
          billingSystem='VE'
          deviceRecom={deviceRecommendations}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          redirectToFlexOrdering={redirectToFlexOrdering}
          setIsManualTriage={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setAssistedMtnFromAIQuote={jest.fn()}
          setMtnToBeSelectedWithoutGenratingQuote={jest.fn()}
          newLinesWithoutQuote={[{ mtn: 'newLine1' }, { mtn: 'newLine2' }]}
          aiquoteResponse={aiQuoteResponseJSON}
          setFPSProtectionData={setFPSProtectionData}
          linesWithQuoteInCart={[{ mtn: 'newLine1' }]}
          linesWithoutProtection={[]}
          isCollaborationStartedForRC
          isInsideSalesorCustomerService
          showPriceDetails={false}
          setShowDownPayment={jest.fn()}
          isFiosEnabled
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          mandatoryNumberShareLines={[]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });

    test('renders removeLine popUp on click of proceedWithQuote - removeLine API failure', async () => {
      server.use(rest.post(`*remove-lines`, (req, res, ctx) => res(ctx.status(500), ctx.json({}))));
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCartOne = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCartOne).not.toBeDisabled();
      fireEvent.click(proceedtoCartOne);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });
  });

  describe('Footer component for Indirect cahnnel- testing all line edited false', () => {
    const handlers = [
      rest.post(`*processAcctInquiryTranDetails`, (req, res, ctx) => {
        console.log('inside mock');
        return res(
          ctx.status(200),
          ctx.json({
            data: {
              statusMessage: 'Success',
              uniqueKey: '1710886290738',
              pkSequence: null,
              errors: null,
              status: 1,
            },
          }),
        );
      }),
      rest.post(`*remove-lines`, (req, res, ctx) => {
        console.log('inside removeLines mock');
        return res(ctx.status(200), ctx.json(removeLinesJSON));
      }),
    ];

    const server = setupServer(...handlers);
    const redirectToFlexOrdering = jest.fn().mockName('redirectToFlexOrdering');
    beforeAll(() => server.listen());
    afterEach(() => server.resetHandlers());
    afterAll(() => server.close());
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({ enableFullBlownMfeNbsPosFFlag: 'TRUE', montanaOfferEnableFFlag: 'TRUE' }),
      );
      Object.defineProperty(global.navigator, 'userAgent', {
        get() {
          return 'Desktop';
        },
        configurable: true,
      });

      render(
        <Footer
          isAIQuote
          billingSystem='VE'
          deviceRecom={deviceRecommendations}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          redirectToFlexOrdering={redirectToFlexOrdering}
          setIsManualTriage={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setAssistedMtnFromAIQuote={jest.fn()}
          setMtnToBeSelectedWithoutGenratingQuote={jest.fn()}
          newLinesWithoutQuote={[{ mtn: 'newLine1' }, { mtn: 'newLine2' }]}
          aiquoteResponse={aiQuoteResponseJSON}
          setFPSProtectionData={setFPSProtectionData}
          linesWithQuoteInCart={[{ mtn: '4107397731' }, { mtn: '4107397732' }]}
          linesWithoutProtection={[]}
          isCollaborationStartedForRC
          isInsideSalesorCustomerService
          showPriceDetails
          setShowDownPayment={jest.fn()}
          customerBio={customerBio}
          mtnListPriceEdit={[
            { mtn: '4107397731', priceEdited: false },
            { mtn: '4107397732', priceEdited: false },
          ]}
          isInDirect
          mandatoryNumberShareLines={[]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });

    test('renders removeLine popUp on click of proceedWithQuote - removeLine API failure', async () => {
      server.use(rest.post(`*remove-lines`, (req, res, ctx) => res(ctx.status(500), ctx.json({}))));
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCartOne = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCartOne).not.toBeDisabled();
      fireEvent.click(proceedtoCartOne);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });
  });

  describe('Footer component for Indirect cahnnel- all Line edited true', () => {
    const handlers = [
      rest.post(`*processAcctInquiryTranDetails`, (req, res, ctx) => {
        console.log('inside mock');
        return res(
          ctx.status(200),
          ctx.json({
            data: {
              statusMessage: 'Success',
              uniqueKey: '1710886290738',
              pkSequence: null,
              errors: null,
              status: 1,
            },
          }),
        );
      }),
      rest.post(`*remove-lines`, (req, res, ctx) => {
        console.log('inside removeLines mock');
        return res(ctx.status(200), ctx.json(removeLinesJSON));
      }),
    ];

    const server = setupServer(...handlers);
    const redirectToFlexOrdering = jest.fn().mockName('redirectToFlexOrdering');
    beforeAll(() => server.listen());
    afterEach(() => server.resetHandlers());
    afterAll(() => server.close());
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          personalShopperVVCModalFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
        }),
      );
      Object.defineProperty(global.navigator, 'userAgent', {
        get() {
          return 'Desktop';
        },
        configurable: true,
      });

      render(
        <Footer
          isAIQuote
          billingSystem='VE'
          deviceRecom={deviceRecommendations}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          redirectToFlexOrdering={redirectToFlexOrdering}
          setIsManualTriage={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setAssistedMtnFromAIQuote={jest.fn()}
          setMtnToBeSelectedWithoutGenratingQuote={jest.fn()}
          newLinesWithoutQuote={[{ mtn: 'newLine1' }, { mtn: 'newLine2' }]}
          aiquoteResponse={aiQuoteResponseJSON}
          setFPSProtectionData={setFPSProtectionData}
          linesWithQuoteInCart={[{ mtn: '4107397731' }]}
          linesWithoutProtection={[]}
          isCollaborationStartedForRC
          isInsideSalesorCustomerService
          showPriceDetails
          setShowDownPayment={jest.fn()}
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect
          mandatoryNumberShareLines={[]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });

    test('renders removeLine popUp on click of proceedWithQuote - removeLine API failure', async () => {
      server.use(rest.post(`*remove-lines`, (req, res, ctx) => res(ctx.status(500), ctx.json({}))));
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCartOne = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCartOne).not.toBeDisabled();
      fireEvent.click(proceedtoCartOne);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });
  });

  describe('Footer', () => {
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          enableShareQuoteinAIQuoteFFlag: 'TRUE',
          personalShopperVVCModalFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
        }),
      );
      render(
        <Footer
          activeMtnValue='2812530682'
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          setFPSProtectionData={setFPSProtectionData}
          FetchPricingSnapShotResult={fpsWithBICOfferJSON}
          linesWithoutProtection={[{ mtn: 'newLine1' }]}
          showPriceDetails
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          disableProceedToQuote={false}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });

    test('renders Footer content - BIC Offer', async () => {
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {
        mtn: '8045735000',
      });
      Emitter.emit('AI_QUOTE_PERK_RECOMMENDATIONS_FOR_FOOTER', {
        perks: [
          {
            spoId: '2641',
            spoDescription: 'Disney Bundle',
            recomOrder: '1',
            propositionId: 'Perk_1',
            propositionName: 'Perk',
            rank: '1',
          },
        ],
        isUpdateQuote: false,
      });
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: true,
      });
      Emitter.emit('Closing_Device_Protection_Modal', {});
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });
  });

  describe('Ai Quote Footer Prospect Flow', () => {
    beforeEach(() => {
      window.history.pushState({}, 'AIQuote', `sposstore-soe-nssit3.vzwcorp.com?customerType=N`);
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          enableShareQuoteinAIQuoteFFlag: 'TRUE',
          fiosReferralOnRCFFlag: 'TRUE',
          personalShopperVVCModalFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
        }),
      );
      render(
        <Footer
          isAIQuote
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          setFPSProtectionData={setFPSProtectionData}
          FetchPricingSnapShotResult={fpsNew}
          linesWithoutProtection={[{ mtn: 'newLine1' }]}
          showPriceDetails
          customerBio={customerBio}
          isFiosEnabled
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          disableProceedToQuote
          mandatoryNumberShareLines={[{ mtn: 'newLine1' }]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });

    test('renders Footer content for Ai Quote with disabled proceed to quote', async () => {
      window.cartProducts = [
        {
          mtn: 'newLine1',
          current: [
            {
              name: 'iPhone 16 Pro Max',
              lineHash: '',
              sku: 'sku6016050',
              shared: 'N',
              id: 'MYW53LL/A',
              category: 'Device',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 33.33,
              nonRecurringPrice: 1199.99,
              shippingCharge: 0,
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              line: 0,
              contractType: '',
            },
            {
              name: 'Apple iPhone 14 256GB Purple',
              lineHash: '',
              sku: '358265580971304',
              shared: 'N',
              id: 'MLAX3LL/A',
              category: 'Trade-Device',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 0,
              nonRecurringPrice: 195,
              shippingCharge: 0,
              orderType: 'TradeIn',
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              line: null,
              contractType: '',
              type: 'deviceProtection',
            },
            {
              name: 'Verizon Mobile Protect Multi-Device',
              line: 0,
              lineHash: '',
              sku: '2663',
              shared: 'Y',
              contractType: '',
              id: '2663',
              category: 'Feature',
              discount: 0,
              qty: 1,
              merchCat: '',
              offer: '',
              recurringPrice: 68,
              nonRecurringPrice: 0,
              shippingCharge: 0,
              shippingType: '',
              propId: '',
              path: '',
              group: '',
              action: '',
              orderType: 'FEA',
              downPayment: '',
            },
          ],
        },
        {
          mtn: '4107397731',
        },
      ];
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = screen.getByRole('button', { name: 'Proceed with Quote' });
      expect(proceedtoCart).toBeDisabled();
    });
  });

  describe('Footer for Verizon visa card details', () => {
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          enableShareQuoteinAIQuoteFFlag: 'TRUE',
          isAiQuoteVVCEnabledFFlag: 'TRUE',
          personalShopperVVCModalFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
        }),
      );
      sessionStorage.setItem('customerType', 'N');
      sessionStorage.setItem('location', '0026301');
      render(
        <Footer
          activeMtnValue='4107397731'
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          setFPSProtectionData={setFPSProtectionData}
          FetchPricingSnapShotResult={FpsVvc}
          linesWithoutProtection={[{ mtn: 'newLine1' }]}
          showPriceDetails
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          disableProceedToQuote={false}
          mandatoryNumberShareLines={[{ mtn: 'newLine1' }]}
          callCreateApplication
          isAutopayEnabled
          autopayDiscount={50}
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });

    test('renders Footer content for verizon visa card billing details', async () => {
      Emitter.emit('Assisted_MTN_Value', '4107397731');
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);

      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = screen.getByRole('button', { name: 'Proceed with Quote' });
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
    });
  });
  describe('Footer for Verizon visa card details when only dfo available', () => {
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          enableShareQuoteinAIQuoteFFlag: 'TRUE',
          isAiQuoteVVCEnabledFFlag: 'TRUE',
          personalShopperVVCModalFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
        }),
      );
      sessionStorage.setItem('customerType', 'N');
      sessionStorage.setItem('location', '0026301');
      render(
        <Footer
          activeMtnValue='4107397731'
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          setFPSProtectionData={setFPSProtectionData}
          FetchPricingSnapShotResult={FpsVvc}
          linesWithoutProtection={[{ mtn: 'newLine1' }]}
          showPriceDetails
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          disableProceedToQuote={false}
          mandatoryNumberShareLines={[{ mtn: 'newLine1' }]}
          callCreateApplication={false}
          isAutopayEnabled={false}
          autopayDiscount={50}
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });

    test('renders Footer content for verizon visa card billing details when only dfo available', async () => {
      Emitter.emit('Assisted_MTN_Value', '4107397731');
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);

      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = screen.getByRole('button', { name: 'Proceed with Quote' });
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
    });
  });
  describe('Footer for Multi depletion Type check', () => {
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          enableShareQuoteinAIQuoteFFlag: 'TRUE',
          isAiQuoteVVCEnabledFFlag: 'TRUE',
          personalShopperVVCModalFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
          showMultiDepletionInCartWarningFFlag: 'TRUE',
        }),
      );
      sessionStorage.setItem('customerType', 'N');
      sessionStorage.setItem('location', '0026301');
      render(
        <Footer
          activeMtnValue='4107397731'
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          setFPSProtectionData={setFPSProtectionData}
          FetchPricingSnapShotResult={FpsVvc}
          linesWithoutProtection={[{ mtn: 'newLine1' }]}
          showPriceDetails
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          disableProceedToQuote={false}
          mandatoryNumberShareLines={[{ mtn: 'newLine1' }]}
          callCreateApplication={false}
          isAutopayEnabled={false}
          autopayDiscount={50}
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
          linesWithQuoteInCart={[
            { mtn: '4107397731', depletionType: 'L' },
            { mtn: 'newLine1', depletionType: 'F' },
          ]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });

    test('renders multi depletion error message banner', async () => {
      Emitter.emit('Assisted_MTN_Value', '4107397731');
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);

      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = screen.getByRole('button', { name: 'Proceed with Quote' });
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
    });
  });

  describe('Footer for Multi depletion Type check for sales flow', () => {
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          enableShareQuoteinAIQuoteFFlag: 'TRUE',
          isAiQuoteVVCEnabledFFlag: 'TRUE',
          personalShopperVVCModalFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
          showMultiDepletionInCartWarningFFlag: 'TRUE',
        }),
      );
      sessionStorage.setItem('customerType', 'N');
      sessionStorage.setItem('location', '0026301');
      render(
        <Footer
          activeMtnValue='4107397731'
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          setFPSProtectionData={setFPSProtectionData}
          FetchPricingSnapShotResult={FpsVvc}
          linesWithoutProtection={[{ mtn: 'newLine1' }]}
          showPriceDetails
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          disableProceedToQuote={false}
          mandatoryNumberShareLines={[{ mtn: 'newLine1' }]}
          callCreateApplication={false}
          isAutopayEnabled={false}
          autopayDiscount={50}
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
          isInsideSalesorCustomerService
          linesWithQuoteInCart={[{ mtn: '4107397731', depletionType: 'L' }, { mtn: 'newLine1', depletionType: 'F' }]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });

    test('renders multi depletion error message banner', async () => {
      Emitter.emit('Assisted_MTN_Value', '4107397731');
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);

      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = screen.getByRole('button', { name: 'Proceed with Quote' });
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
    });
  });
  describe('Footer for Verizon visa card details when only vvc available', () => {
    const getOffersData = {
      issacPromo: {
        mtnActivatedForMoreThanADay: true,
        proposition: {
          rank: '1',
          soiEngagementId: '123456',
          syfOfferId: '1234567',
          propositionId: 'GC_01',
          spoName: 'MockName',
        },
        sessionId: '9087654321',
      },
    };
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          enableShareQuoteinAIQuoteFFlag: 'TRUE',
          isAiQuoteVVCEnabledFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
        }),
      );
      sessionStorage.setItem('customerType', 'N');
      sessionStorage.setItem('location', '0026301');
      render(
        <Footer
          activeMtnValue='4107397731'
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          setFPSProtectionData={setFPSProtectionData}
          FetchPricingSnapShotResult={FpsVvc}
          linesWithoutProtection={[{ mtn: 'newLine1' }]}
          showPriceDetails
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          disableProceedToQuote={false}
          mandatoryNumberShareLines={[{ mtn: 'newLine1' }]}
          getOffers={getOffersData}
          messageMtn='4107397731'
          callCreateApplication
          isAutopayEnabled={false}
          autopayDiscount={50}
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });

    test('renders Footer content for verizon visa card billing details when only vvc available', async () => {
      Emitter.emit('Assisted_MTN_Value', '4107397731');
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);

      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = screen.getByRole('button', { name: 'Proceed with Quote' });
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
    });
  });
  describe('Footer - getAdditionalDiscounts function', () => {
    const handlers = [
      rest.post(`*fetchPricingSnapshot`, (req, res, ctx) => res(ctx.status(200), ctx.json(FetchPricingSnapshot))),
    ];
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({
        enableFullBlownMfeNbsPosFFlag: 'TRUE',
        personalShopperLineLevelFFlag: 'TRUE',
        // showPastDuePreBackOrderModalFFlag: 'TRUE',
        montanaPriceBreakUpFixFFlag: 'TRUE',
      }),
    );
    const server = setupServer(...handlers);
    beforeAll(() => server.listen());
    afterEach(() => server.resetHandlers());
    afterAll(() => server.close());
    const fetchCartDetailsResult = {
      status: 'fulfilled',
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [
                {
                  serviceInfo: {
                    selectedFeaturesList: {
                      visFeature: [{ categoryCodes: ['SEGDISC', 'BTROFF1', 'BTRDISC'] }],
                    },
                  },
                },
                {
                  itemsInfo: [
                    {
                      cartItems: {
                        cartItem: [{ cartItemType: 'DEVICE', inventory: { isBackorder: true } }],
                      },
                    },
                  ],
                },
              ],
            },
          },
        },
      },
    };

    test('should return empty array when toggleStatus is false', async () => {
      render(
        <Footer
          isAIQuote
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setTriggerProceedToQuote={jest.fn()}
          setFPSProtectionData={jest.fn()}
          FetchPricingSnapShotResult={FetchPricingSnapshot}
          showPriceDetails
          isAutopayEnabled
          ecpdDiscountAmount={10}
          customerBio={customerBio}
          fetchCartDetailsResult={fetchCartDetailsResult}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );

      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 100);
      });

      // Test when toggleStatus is false (default state)
      const footerEl = await screen.getByTestId('footercomponent');
      expect(footerEl).toBeInTheDocument();

      // Expand footer to check discount section
      const expandBtn = await screen.getByLabelText('Expand Footer');
      fireEvent.click(expandBtn);

      // Additional discounts should not be visible when toggle is false
      expect(screen.queryByText('Additional available discounts**')).not.toBeInTheDocument();
    });

    test('should include APO/Paperless and ECPD discounts when toggleStatus is true and relevant props are provided', async () => {
      render(
        <Footer
          isAIQuote
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setTriggerProceedToQuote={jest.fn()}
          setFPSProtectionData={jest.fn()}
          FetchPricingSnapShotResult={{
            ...FetchPricingSnapshot,
            data: {
              ...FetchPricingSnapshot.data,
              data: {
                ...FetchPricingSnapshot.data.data,
                subAccounts: [
                  {
                    ...FetchPricingSnapshot.data.data.subAccounts[0],
                    shared: {
                      pendingChargesAndDiscounts: {
                        discountsPendingActionDetails: {
                          apoPaperlessAmount: 10,
                        },
                      },
                    },
                  },
                ],
                ecpdType: 'EMPLOYEE',
                ecpdDiscount: 15,
                isAutoPayEnabled: true,
                isAiBillUpload: 'Y',
              },
            },
          }}
          showPriceDetails
          isAutopayEnabled
          customerBio={customerBio}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );

      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 100);
      });

      // Expand footer to check discount section
      const expandBtn = await screen.getByLabelText('Expand Footer');
      fireEvent.click(expandBtn);

      // Toggle the additional savings to show them
      // const savingsButton = await screen.findByTestId('test-toggle');
      // fireEvent.click(savingsButton);

      // Now additional discounts should be visible
      await waitFor(() => {
        // expect(screen.getByText('Additional available discounts**')).toBeInTheDocument();
      });
    });

    test('should only include APO/Paperless discount when isAutopayEnabled is true and ECPD is not present', async () => {
      render(
        <Footer
          isAIQuote
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setTriggerProceedToQuote={jest.fn()}
          setFPSProtectionData={jest.fn()}
          FetchPricingSnapShotResult={{
            ...FetchPricingSnapshot,
            data: {
              ...FetchPricingSnapshot.data,
              data: {
                ...FetchPricingSnapshot.data.data,
                subAccounts: [
                  {
                    ...FetchPricingSnapshot.data.data.subAccounts[0],
                    shared: {
                      pendingChargesAndDiscounts: {
                        discountsPendingActionDetails: {
                          apoPaperlessAmount: 10,
                          totalAdditionalDiscount: 10,
                        },
                      },
                    },
                  },
                ],
                ecpdDiscount: 0,
                ecpdType: 'Military',
                isAutoPayEnabled: true,
                isAiBillUpload: 'Y',
              },
            },
          }}
          showPriceDetails
          isAutopayEnabled
          customerBio={customerBio}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );

      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 100);
      });

      // Expand footer to check discount section
      const expandBtn = await screen.getByLabelText('Expand Footer');
      fireEvent.click(expandBtn);

      // Toggle the additional savings to show them
      // const savingsButton = await screen.findByTestId('test-toggle');
      // fireEvent.click(savingsButton);

      // Now only APO/Paperless discount should be visible
      await waitFor(() => {
        // expect(screen.getByText('Additional available discounts**')).toBeInTheDocument();
      });
    });

    test('should only include ECPD discount when ecpdDiscountAmount exists and isAutopayEnabled is false', async () => {
      render(
        <Footer
          isAIQuote
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setTriggerProceedToQuote={jest.fn()}
          setFPSProtectionData={jest.fn()}
          FetchPricingSnapShotResult={{
            ...FetchPricingSnapshot,
            data: {
              ...FetchPricingSnapshot.data,
              data: {
                ...FetchPricingSnapshot.data.data,
                ecpdType: 'BUSINESS',
                ecpdDiscount: 20,
                isAutoPayEnabled: true,
                isAiBillUpload: 'Y',
              },
            },
          }}
          showPriceDetails
          isAutopayEnabled={false}
          customerBio={customerBio}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );

      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 100);
      });

      // Expand footer to check discount section
      const expandBtn = await screen.getByLabelText('Expand Footer');
      fireEvent.click(expandBtn);

      // Toggle the additional savings to show them
      // const savingsButton = await screen.findByTestId('test-toggle');
      // fireEvent.click(savingsButton);

      // Now only ECPD discount should be visible
      await waitFor(() => {
        // expect(screen.getByText('Additional available discounts**')).toBeInTheDocument();
        // expect(screen.getByText('ECPD discount(BUSINESS)')).toBeInTheDocument();
      });
    });

    test('should show estimated new monthly with additional discounts when toggleStatus is true', async () => {
      render(
        <Footer
          isAIQuote
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setTriggerProceedToQuote={jest.fn()}
          setFPSProtectionData={jest.fn()}
          FetchPricingSnapShotResult={{
            ...FetchPricingSnapshot,
            data: {
              ...FetchPricingSnapshot.data,
              data: {
                ...FetchPricingSnapshot.data.data,
                subAccounts: [
                  {
                    ...FetchPricingSnapshot.data.data.subAccounts[0],
                    savings: {
                      grandTotalSaving: {
                        grandTotalLineSavings: 55.85,
                        grandTotalAccountLevelSavings: 0,
                        totalPerkSavings: 41.97,
                        totalVerizonSavings: 569.73,
                        grandTotalSavingsWithDiscount: 100.85,
                      },
                    },
                    shared: {
                      pendingChargesAndDiscounts: {
                        discountsPendingActionDetails: {
                          // apoPaperlessAmount: 5
                          totalAdditionalDiscount: 15,
                        },
                      },
                    },
                    totals: {
                      ...FetchPricingSnapshot.data.data.subAccounts[0].totals,
                      grandTotalDueMonthly: {
                        ...FetchPricingSnapshot.data.data.subAccounts[0].totals.grandTotalDueMonthly,
                        estimatedTotal: '100.00',
                      },
                    },
                  },
                ],
                ecpdType: 'BUSINESS',
                ecpdDiscount: 10,
                isAutoPayEnabled: true,
                isAiBillUpload: 'Y',
              },
            },
          }}
          showPriceDetails
          isAutopayEnabled
          customerBio={customerBio}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );

      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 100);
      });

      // Expand footer to check discount section
      const expandBtn = await screen.getByLabelText('Expand Footer');
      fireEvent.click(expandBtn);

      // Toggle the additional savings to show them
      // const savingsButton = await screen.findByTestId('test-toggle');
      // fireEvent.click(savingsButton);

      // The estimated new monthly with additional discounts should be visible
      // await waitFor(() => {
      //   expect(screen.getByText('Est. new monthly if discounts are applied')).toBeInTheDocument();
      //   // With $15 of discounts on a $100 bill, should show $85.00
      //   expect(screen.getByText('$85.00')).toBeInTheDocument();
      // });
    });
  });
  describe('Footer - getAdditionalDiscounts function for non-Montana', () => {
    const handlers = [
      rest.post(`*fetchPricingSnapshot`, (req, res, ctx) => res(ctx.status(200), ctx.json(FetchPricingSnapshot))),
    ];
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({
        enableFullBlownMfeNbsPosFFlag: 'TRUE',
        personalShopperLineLevelFFlag: 'TRUE',
        aiQuoteProspectOffersFFlag: 'TRUE',
        montanaPriceBreakUpFixFFlag: 'TRUE',
      }),
    );
    const server = setupServer(...handlers);
    beforeAll(() => server.listen());
    afterEach(() => server.resetHandlers());
    afterAll(() => server.close());
    const fetchCartDetailsResult = {
      status: 'fulfilled',
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [
                {
                  serviceInfo: {
                    selectedFeaturesList: {
                      visFeature: [{ categoryCodes: ['SEGDISC', 'BTROFF1', 'BTRDISC'] }],
                    },
                  },
                },
                {
                  itemsInfo: [
                    {
                      cartItems: {
                        cartItem: [{ cartItemType: 'DEVICE', inventory: { isBackorder: true } }],
                      },
                    },
                  ],
                },
              ],
            },
          },
        },
      },
    };

    test('should display autopay when toggle is enabled', async () => {
      render(
        <Footer
          isAIQuote
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setTriggerProceedToQuote={jest.fn()}
          setFPSProtectionData={jest.fn()}
          FetchPricingSnapShotResult={FetchPricingSnapshot}
          showPriceDetails
          isAutopayEnabled
          isAiBillUpload='N'
          ecpdDiscountAmount={10}
          customerBio={customerBio}
          fetchCartDetailsResult={fetchCartDetailsResult}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );

      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 100);
      });

      // Test when toggleStatus is false (default state)
      const footerEl = await screen.getByTestId('footercomponent');
      expect(footerEl).toBeInTheDocument();

      // Expand footer to check discount section
      const expandBtn = await screen.getByLabelText('Expand Footer');
      fireEvent.click(expandBtn);

      // Additional discounts should not be visible when toggle is false
      expect(screen.queryByText('Additional available discounts**')).not.toBeInTheDocument();
    });

    
  });
  describe('Footer component - testing past due with preorbackorder popup', () => {
    const handlers = [
      rest.post(`*processAcctInquiryTranDetails`, (req, res, ctx) => {
        console.log('inside mock');
        return res(
          ctx.status(200),
          ctx.json({
            data: {
              statusMessage: 'Success',
              uniqueKey: '1710886290738',
              pkSequence: null,
              errors: null,
              status: 1,
            },
          }),
        );
      }),
      rest.post(`*remove-lines`, (req, res, ctx) => {
        console.log('inside removeLines mock');
        return res(ctx.status(200), ctx.json(removeLinesJSON));
      }),
    ];

    const server = setupServer(...handlers);
    const redirectToFlexOrdering = jest.fn().mockName('redirectToFlexOrdering');
    beforeAll(() => server.listen());
    afterEach(() => server.resetHandlers());
    afterAll(() => server.close());
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          // showPastDuePreBackOrderModalFFlag: 'TRUE',
          montanaPriceBreakUpFixFFlag: 'TRUE',
        }),
      );
      Object.defineProperty(global.navigator, 'userAgent', {
        get() {
          return 'Desktop';
        },
        configurable: true,
      });
      const fetchCartDetailsResult = {
        data: {
          data: {
            cart: {
              lineDetails: {
                lineInfo: [
                  {
                    itemsInfo: [
                      {
                        cartItems: {
                          cartItem: [
                            { cartItemType: 'DEVICE', inventory: { isPreOrder: false } },
                            { cartItemType: 'PASTDUE' },
                          ],
                        },
                      },
                    ],
                  },
                  {
                    itemsInfo: [
                      {
                        cartItems: {
                          cartItem: [{ cartItemType: 'DEVICE', inventory: { isBackorder: true } }],
                        },
                      },
                    ],
                  },
                ],
              },
            },
          },
        },
      };

      render(
        <Footer
          isAIQuote
          fetchCartDetailsResult={fetchCartDetailsResult}
          billingSystem='VE'
          deviceRecom={deviceRecommendations}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          redirectToFlexOrdering={redirectToFlexOrdering}
          setIsManualTriage={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setAssistedMtnFromAIQuote={jest.fn()}
          setMtnToBeSelectedWithoutGenratingQuote={jest.fn()}
          newLinesWithoutQuote={[{ mtn: 'newLine1' }, { mtn: 'newLine2' }]}
          aiquoteResponse={aiQuoteResponseJSON}
          setFPSProtectionData={setFPSProtectionData}
          linesWithQuoteInCart={[{ mtn: 'newLine1' }]}
          linesWithoutProtection={[]}
          isCollaborationStartedForRC
          isInsideSalesorCustomerService
          showPriceDetails
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          mandatoryNumberShareLines={[]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });

    test('renders pastdue with preorbackorder popup', async () => {
      window.history.pushState({}, 'AIQuote', `sposstore-soe-nssit3.vzwcorp.com?customerType=N`);
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCartOne = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCartOne).not.toBeDisabled();
      fireEvent.click(proceedtoCartOne);
      await waitFor(() => screen.findByTestId('Cancel'));
      expect(screen.getByTestId('Cancel')).toBeInTheDocument();
      const proceedtoCartTwo = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCartTwo).not.toBeDisabled();
      fireEvent.click(proceedtoCartTwo);
      const proceedWithQuoteBtn = await screen.findByTestId('ProceedWithQuote');
      expect(proceedWithQuoteBtn).toBeInTheDocument();
      fireEvent.click(proceedWithQuoteBtn);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const okBtn = await screen.findByTestId('OKBtn');
      expect(okBtn).toBeInTheDocument();
      fireEvent.click(okBtn);
    });
  });
  describe('Footer component - set selfsetup productId in session for PS ', () => {
    const handlers = [
      rest.post(`*processAcctInquiryTranDetails`, (req, res, ctx) => {
        console.log('inside mock');
        return res(
          ctx.status(200),
          ctx.json({
            data: {
              statusMessage: 'Success',
              uniqueKey: '1710886290738',
              pkSequence: null,
              errors: null,
              status: 1,
            },
          }),
        );
      }),
      rest.post(`*remove-lines`, (req, res, ctx) => {
        console.log('inside removeLines mock');
        return res(ctx.status(200), ctx.json(removeLinesJSON));
      }),
    ];

    const server = setupServer(...handlers);
    const redirectToFlexOrdering = jest.fn().mockName('redirectToFlexOrdering');
    beforeAll(() => server.listen());
    afterEach(() => server.resetHandlers());
    afterAll(() => server.close());
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          // showPastDuePreBackOrderModalFFlag: 'TRUE',
          montanaPriceBreakUpFixFFlag: 'TRUE',
        }),
      );
      Object.defineProperty(global.navigator, 'userAgent', {
        get() {
          return 'Desktop';
        },
        configurable: true,
      });
      const fetchCartDetailsResult = {
        data: {
          data: {
            cart: {
              lineDetails: {
                lineInfo: [
                  {
                    lineActivityType: 'NSE_5G',
                    itemsInfo: [
                      {
                        depletionType: 'L',
                        cartItems: {
                          cartItem: [
                            { cartItemType: 'DEVICE', inventory: { isPreOrder: false } },
                            { cartItemType: 'PASTDUE' },
                          ],
                        },
                      },
                    ],
                  },
                  {
                    itemsInfo: [
                      {
                        cartItems: {
                          cartItem: [{ cartItemType: 'DEVICE', inventory: { isBackorder: true } }],
                        },
                      },
                    ],
                  },
                ],
              },
            },
          },
        },
      };
      const mockQualifiedAddressVHI = {
        cbandBundle: [{ type: 's', id: '2000022' }],
      };
      render(
        <Footer
          isAIQuote
          fetchCartDetailsResult={fetchCartDetailsResult}
          billingSystem='VE'
          deviceRecom={deviceRecommendations}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          redirectToFlexOrdering={redirectToFlexOrdering}
          setIsManualTriage={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setAssistedMtnFromAIQuote={jest.fn()}
          setMtnToBeSelectedWithoutGenratingQuote={jest.fn()}
          newLinesWithoutQuote={[{ mtn: 'newLine1' }, { mtn: 'newLine2' }]}
          aiquoteResponse={aiQuoteResponseJSON}
          setFPSProtectionData={setFPSProtectionData}
          linesWithQuoteInCart={[{ mtn: 'newLine1' }]}
          linesWithoutProtection={[]}
          isCollaborationStartedForRC
          isInsideSalesorCustomerService
          showPriceDetails
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          mandatoryNumberShareLines={[]}
          qualifiedAddressVHI={mockQualifiedAddressVHI}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });

    test('renders pastdue with preorbackorder popup', async () => {
      window.history.pushState({}, 'AIQuote', `sposstore-soe-nssit3.vzwcorp.com?customerType=N`);
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCartOne = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCartOne).not.toBeDisabled();
      fireEvent.click(proceedtoCartOne);
      await waitFor(() => screen.findByTestId('Cancel'));
      expect(screen.getByTestId('Cancel')).toBeInTheDocument();
      const proceedtoCartTwo = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCartTwo).not.toBeDisabled();
      fireEvent.click(proceedtoCartTwo);
      const proceedWithQuoteBtn = await screen.findByTestId('ProceedWithQuote');
      expect(proceedWithQuoteBtn).toBeInTheDocument();
      fireEvent.click(proceedWithQuoteBtn);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });
  });
  describe('Footer component - set prof setup productId in session for PS ', () => {
    const handlers = [
      rest.post(`*processAcctInquiryTranDetails`, (req, res, ctx) => {
        console.log('inside mock');
        return res(
          ctx.status(200),
          ctx.json({
            data: {
              statusMessage: 'Success',
              uniqueKey: '1710886290738',
              pkSequence: null,
              errors: null,
              status: 1,
            },
          }),
        );
      }),
      rest.post(`*remove-lines`, (req, res, ctx) => {
        console.log('inside removeLines mock');
        return res(ctx.status(200), ctx.json(removeLinesJSON));
      }),
    ];

    const server = setupServer(...handlers);
    const redirectToFlexOrdering = jest.fn().mockName('redirectToFlexOrdering');
    beforeAll(() => server.listen());
    afterEach(() => server.resetHandlers());
    afterAll(() => server.close());
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          // showPastDuePreBackOrderModalFFlag: 'TRUE',
          montanaPriceBreakUpFixFFlag: 'TRUE',
        }),
      );
      Object.defineProperty(global.navigator, 'userAgent', {
        get() {
          return 'Desktop';
        },
        configurable: true,
      });
      const fetchCartDetailsResult = {
        data: {
          data: {
            cart: {
              lineDetails: {
                lineInfo: [
                  {
                    lineActivityType: 'NSE_5G',
                    itemsInfo: [
                      {
                        depletionType: 'O',
                        cartItems: {
                          cartItem: [
                            { cartItemType: 'DEVICE', inventory: { isPreOrder: false } },
                            { cartItemType: 'PASTDUE' },
                          ],
                        },
                      },
                    ],
                  },
                  {
                    itemsInfo: [
                      {
                        cartItems: {
                          cartItem: [{ cartItemType: 'DEVICE', inventory: { isBackorder: true } }],
                        },
                      },
                    ],
                  },
                ],
              },
            },
          },
        },
      };
      const mockQualifiedAddressVHI = {
        cbandBundle: [{ type: 's', id: '2000022' }],
      };
      render(
        <Footer
          isAIQuote
          fetchCartDetailsResult={fetchCartDetailsResult}
          billingSystem='VE'
          deviceRecom={deviceRecommendations}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          redirectToFlexOrdering={redirectToFlexOrdering}
          setIsManualTriage={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setAssistedMtnFromAIQuote={jest.fn()}
          setMtnToBeSelectedWithoutGenratingQuote={jest.fn()}
          newLinesWithoutQuote={[{ mtn: 'newLine1' }, { mtn: 'newLine2' }]}
          aiquoteResponse={aiQuoteResponseJSON}
          setFPSProtectionData={setFPSProtectionData}
          linesWithQuoteInCart={[{ mtn: 'newLine1' }]}
          linesWithoutProtection={[]}
          isCollaborationStartedForRC
          isInsideSalesorCustomerService
          showPriceDetails
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          mandatoryNumberShareLines={[]}
          qualifiedAddressVHI={mockQualifiedAddressVHI}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });

    test('renders pastdue with preorbackorder popup', async () => {
      window.history.pushState({}, 'AIQuote', `sposstore-soe-nssit3.vzwcorp.com?customerType=N`);
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCartOne = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCartOne).not.toBeDisabled();
      fireEvent.click(proceedtoCartOne);
      await waitFor(() => screen.findByTestId('Cancel'));
      expect(screen.getByTestId('Cancel')).toBeInTheDocument();
      const proceedtoCartTwo = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCartTwo).not.toBeDisabled();
      fireEvent.click(proceedtoCartTwo);
      const proceedWithQuoteBtn = await screen.findByTestId('ProceedWithQuote');
      expect(proceedWithQuoteBtn).toBeInTheDocument();
      fireEvent.click(proceedWithQuoteBtn);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });
  });

  describe('Footer - getAdditionalDiscounts function', () => {
    const handlers = [
      rest.post(`*fetchPricingSnapshot`, (req, res, ctx) => res(ctx.status(200), ctx.json(FetchPricingSnapshot))),
    ];
    const server = setupServer(...handlers);
    beforeAll(() => server.listen());
    afterEach(() => server.resetHandlers());
    afterAll(() => server.close());
    const fetchCartDetailsResult = {
      status: 'fulfilled',
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [
                {
                  serviceInfo: {
                    selectedFeaturesList: {
                      visFeature: [{ categoryCodes: ['SEGDISC'] }],
                    },
                  },
                },
                {
                  itemsInfo: [
                    {
                      cartItems: {
                        cartItem: [{ cartItemType: 'DEVICE', inventory: { isBackorder: true } }],
                      },
                    },
                  ],
                },
              ],
            },
          },
        },
      },
    };

    test('should return empty array when toggleStatus is false', async () => {
      render(
        <Footer
          isAIQuote
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setTriggerProceedToQuote={jest.fn()}
          setFPSProtectionData={jest.fn()}
          FetchPricingSnapShotResult={FetchPricingSnapshot}
          showPriceDetails
          isAutopayEnabled
          ecpdDiscountAmount={10}
          customerBio={customerBio}
          fetchCartDetailsResult={fetchCartDetailsResult}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );

      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 100);
      });

      // Test when toggleStatus is false (default state)
      const footerEl = await screen.getByTestId('footercomponent');
      expect(footerEl).toBeInTheDocument();

      // Expand footer to check discount section
      const expandBtn = await screen.getByLabelText('Expand Footer');
      fireEvent.click(expandBtn);

      // Additional discounts should not be visible when toggle is false
      expect(screen.queryByText('Additional available discounts**')).not.toBeInTheDocument();
    });
  });

  describe('Footer - getAdditionalDiscounts function', () => {
    const handlers = [
      rest.post(`*fetchPricingSnapshot`, (req, res, ctx) => res(ctx.status(200), ctx.json(FetchPricingSnapshot))),
    ];
    const server = setupServer(...handlers);
    beforeAll(() => server.listen());
    afterEach(() => server.resetHandlers());
    afterAll(() => server.close());
    const fetchCartDetailsResult = {
      status: 'fulfilled',
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [
                {
                  serviceInfo: {
                    selectedFeaturesList: {
                      visFeature: [{ categoryCodes: ['BTROFF1', 'BTRDISC'] }],
                    },
                  },
                },
                {
                  itemsInfo: [
                    {
                      cartItems: {
                        cartItem: [{ cartItemType: 'DEVICE', inventory: { isBackorder: true } }],
                      },
                    },
                  ],
                },
              ],
            },
          },
        },
      },
    };

    test('should return empty array when toggleStatus is false', async () => {
      render(
        <Footer
          isAIQuote
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setTriggerProceedToQuote={jest.fn()}
          setFPSProtectionData={jest.fn()}
          FetchPricingSnapShotResult={FetchPricingSnapshot}
          showPriceDetails
          isAutopayEnabled
          ecpdDiscountAmount={10}
          customerBio={customerBio}
          fetchCartDetailsResult={fetchCartDetailsResult}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );

      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 100);
      });

      // Test when toggleStatus is false (default state)
      const footerEl = await screen.getByTestId('footercomponent');
      expect(footerEl).toBeInTheDocument();

      // Expand footer to check discount section
      const expandBtn = await screen.getByLabelText('Expand Footer');
      fireEvent.click(expandBtn);

      // Additional discounts should not be visible when toggle is false
      expect(screen.queryByText('Additional available discounts**')).not.toBeInTheDocument();
    });
  });

  describe('Footer - getAdditionalDiscounts function', () => {
    const handlers = [
      rest.post(`*fetchPricingSnapshot`, (req, res, ctx) => res(ctx.status(200), ctx.json(FetchPricingSnapshot))),
    ];
    const server = setupServer(...handlers);
    beforeAll(() => server.listen());
    afterEach(() => server.resetHandlers());
    afterAll(() => server.close());
    const fetchCartDetailsResult = {
      status: 'fulfilled',
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [
                {
                  serviceInfo: {
                    selectedFeaturesList: {
                      visFeature: [{ categoryCodes: ['SEGDISC', 'BTROFF1', 'BTRDISC'] }],
                    },
                  },
                },
                {
                  itemsInfo: [
                    {
                      cartItems: {
                        cartItem: [{ cartItemType: 'DEVICE', inventory: { isBackorder: true } }],
                      },
                    },
                  ],
                },
              ],
            },
          },
        },
      },
    };

    test('should return empty array when toggleStatus is false', async () => {
      render(
        <Footer
          isAIQuote
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setTriggerProceedToQuote={jest.fn()}
          setFPSProtectionData={jest.fn()}
          FetchPricingSnapShotResult={FetchPricingSnapshot}
          showPriceDetails
          isAutopayEnabled
          ecpdDiscountAmount={10}
          customerBio={customerBio}
          fetchCartDetailsResult={fetchCartDetailsResult}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );

      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 100);
      });

      // Test when toggleStatus is false (default state)
      const footerEl = await screen.getByTestId('footercomponent');
      expect(footerEl).toBeInTheDocument();

      // Expand footer to check discount section
      const expandBtn = await screen.getByLabelText('Expand Footer');
      fireEvent.click(expandBtn);

      // Additional discounts should not be visible when toggle is false
      expect(screen.queryByText('Additional available discounts**')).not.toBeInTheDocument();
    });
  });

  describe('Footer - getAdditionalDiscounts function', () => {
    const handlers = [
      rest.post(`*fetchPricingSnapshot`, (req, res, ctx) => res(ctx.status(200), ctx.json(FetchPricingSnapshot))),
    ];
    const server = setupServer(...handlers);
    beforeAll(() => server.listen());
    afterEach(() => server.resetHandlers());
    afterAll(() => server.close());
    const fetchCartDetailsResult = {
      status: 'fulfilled',
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [
                {
                  serviceInfo: {
                    selectedFeaturesList: {
                      visFeature: [{ categoryCodes: [] }],
                    },
                  },
                },
                {
                  itemsInfo: [
                    {
                      cartItems: {
                        cartItem: [{ cartItemType: 'DEVICE', inventory: { isBackorder: true } }],
                      },
                    },
                  ],
                },
              ],
            },
          },
        },
      },
    };
    test('should return empty array when toggleStatus is false', async () => {
      render(
        <Footer
          isAIQuote
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          setTriggerProceedToQuote={jest.fn()}
          setFPSProtectionData={jest.fn()}
          FetchPricingSnapShotResult={FetchPricingSnapshot}
          showPriceDetails
          isAutopayEnabled
          ecpdDiscountAmount={10}
          customerBio={customerBio}
          fetchCartDetailsResult={fetchCartDetailsResult}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );

      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await new Promise((res) => {
        setTimeout(res, 100);
      });

      // Test when toggleStatus is false (default state)
      const footerEl = await screen.getByTestId('footercomponent');
      expect(footerEl).toBeInTheDocument();

      // Expand footer to check discount section
      const expandBtn = await screen.getByLabelText('Expand Footer');
      fireEvent.click(expandBtn);

      // Additional discounts should not be visible when toggle is false
      expect(screen.queryByText('Additional available discounts**')).not.toBeInTheDocument();
    });
  });
};

const TestFooter = (channel) => {
  setupChannel(channel);
  const setFPSProtectionData = jest.fn();
  const setTriggerProceedToQuote = jest.fn();
  describe('Footer component without cartProducts', () => {
    const handlers = [
      rest.post(`*fetchPricingSnapshot`, (req, res, ctx) => {
        console.log('inside FPS mock');
        return res(ctx.status(200), ctx.json(fpsWithCartItemJSON));
      }),
      rest.post(`*processAcctInquiryTranDetails`, (req, res, ctx) => {
        console.log('inside mock');
        return res(
          ctx.status(200),
          ctx.json({
            data: {
              statusMessage: 'Success',
              uniqueKey: '1710886290738',
              pkSequence: null,
              errors: null,
              status: 1,
            },
          }),
        );
      }),
      rest.post(`*compareQuotes`, (req, res, ctx) => {
        console.log('inside FPS mock');
        return res(ctx.status(200), ctx.json(compareQuotes));
      }),
    ];

    const executeLogic = () => {
      const addPersonalShopperTaggingFields = (vzdlObj) => {
        const personalShopperFlowTaggingFFlag =
          JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.personalShopperFlowTaggingFFlag?.toUpperCase() ===
          'TRUE';

        if (personalShopperFlowTaggingFFlag) {
          return {
            ...vzdlObj,
            flow: window?.vzdl?.page?.flow,
            subFlow: window?.vzdl?.page?.subFlow,
          };
        }
        return vzdlObj;
      };

      const vzdlForOrdering = {};
      const updatedVzdlForOrdering = addPersonalShopperTaggingFields(vzdlForOrdering);

      return updatedVzdlForOrdering;
    };

    delete window.cartProducts;
    const vzdlMock = window.vzdl;
    delete window.vzdl;
    window.vzdl = {
      ...vzdlMock,
      page: { detail: 'Footer', throttle: 'MFE', flow: 'AIQuote', subFlow: 'AAL' },
      event: { value: 'scAdd' },
      txn: { product: { current: [] }, nonRecurringPrice: 0 },
    };
    const server = setupServer(...handlers);
    beforeAll(() => server.listen());
    afterEach(() => server.resetHandlers());
    afterAll(() => server.close());
    beforeEach(() => {
      delete window.cartProducts;
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          personalShopperLineLevelFFlag: 'TRUE',
          enableShareQuoteinAIQuoteFFlag: 'TRUE',
          personalShopperVVCModalFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
          personalShopperFlowTaggingFFlag: 'TRUE',
        }),
      );
      Object.defineProperty(global.navigator, 'userAgent', {
        get() {
          return 'iPad';
        },
        configurable: true,
      });
      render(
        <Footer
          isAIQuote
          activeMtnValue='newLine1'
          deviceRecom={deviceRecommendations}
          deviceTriageDone
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          triggerProceedToQuote
          aiquoteResponse={aiquoteResponseTaggingJSON}
          FetchPricingSnapShotResult={FetchPricingSnapshot}
          setFPSProtectionData={setFPSProtectionData}
          linesWithoutProtection={[]}
          isCollaborationStartedForRC
          showPriceDetails
          activeLinePriceTypeInCart='MONTH_TO_MONTH'
          setTaggingPayload={jest.fn()}
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          mandatoryNumberShareLines={[]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });

    test('executeLogic should INCLUDE flow and subFlow when personalShopperFlowTaggingFFlag is TRUE', () => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          personalShopperFlowTaggingFFlag: 'TRUE',
        }),
      );
      if (!window.vzdl) window.vzdl = {};
      if (!window.vzdl.page) window.vzdl.page = {};
      window.vzdl.page.flow = 'AIQuote';
      window.vzdl.page.subFlow = 'AAL';

      const result = executeLogic();
      expect(result).toEqual({
        flow: 'AIQuote',
        subFlow: 'AAL',
      });
      expect(result).toHaveProperty('flow', 'AIQuote');
      expect(result).toHaveProperty('subFlow', 'AAL');
    });

    test('executeLogic should NOT include flow and subFlow when the flag is FALSE', () => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          personalShopperFlowTaggingFFlag: 'FALSE',
        }),
      );

      const result = executeLogic();

      expect(result).toEqual({});
      expect(result).not.toHaveProperty('flow');
      expect(result).not.toHaveProperty('subFlow');
    });

    test('executeLogic should NOT include flow and subFlow when the flag is undefined/missing', () => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          someOtherFlag: 'TRUE',
        }),
      );

      const result = executeLogic();

      expect(result).toEqual({});
      expect(result).not.toHaveProperty('flow');
      expect(result).not.toHaveProperty('subFlow');
    });

    test('executeLogic should NOT include flow and subFlow when APP_PROPERTIES is missing', () => {
      sessionStorage.removeItem('APP_PROPERTIES');

      const result = executeLogic();

      expect(result).toEqual({});
      expect(result).not.toHaveProperty('flow');
      expect(result).not.toHaveProperty('subFlow');
    });

    test('executeLogic should handle case-insensitive flag values', () => {
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ personalShopperFlowTaggingFFlag: 'true', byodPlusPlanFFlag: 'TRUE', byodPlusEUPSupressFFlag: 'TRUE' }));
      window.vzdl = { page: { flow: 'Test', subFlow: 'Test' } };

      let result = executeLogic();
      expect(result).toHaveProperty('flow', 'Test');
      expect(result).toHaveProperty('subFlow', 'Test');

      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ personalShopperFlowTaggingFFlag: 'True', byodPlusPlanFFlag: 'TRUE',byodPlusEUPSupressFFlag: 'TRUE' }));

      result = executeLogic();
      expect(result).toHaveProperty('flow', 'Test');
      expect(result).toHaveProperty('subFlow', 'Test');
    });

    test('executeLogic should handle null and empty flag values', () => {
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ personalShopperFlowTaggingFFlag: null, byodPlusPlanFFlag: 'TRUE', byodPlusEUPSupressFFlag: 'TRUE' }));

      let result = executeLogic();
      expect(result).toEqual({});

      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ personalShopperFlowTaggingFFlag: '' }));

      result = executeLogic();
      expect(result).toEqual({});
    });

    test('executeLogic should handle missing window.vzdl', () => {
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ personalShopperFlowTaggingFFlag: 'TRUE', byodPlusPlanFFlag: 'TRUE', byodPlusEUPSupressFFlag: 'TRUE' }));
      delete window.vzdl;

      const result = executeLogic();
      expect(result).toEqual({
        flow: undefined,
        subFlow: undefined,
      });
    });

    test('executeLogic should handle missing window.vzdl.page', () => {
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ personalShopperFlowTaggingFFlag: 'TRUE', byodPlusPlanFFlag: 'TRUE', byodPlusEUPSupressFFlag: 'TRUE' }));
      window.vzdl = {}; // Missing page property

      const result = executeLogic();
      expect(result).toEqual({
        flow: undefined,
        subFlow: undefined,
      });
    });

    test('executeLogic should handle partial window.vzdl.page properties', () => {
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ personalShopperFlowTaggingFFlag: 'TRUE', byodPlusPlanFFlag: 'TRUE', byodPlusEUPSupressFFlag: 'TRUE' }));

      // Test with only flow, missing subFlow
      window.vzdl = { page: { flow: 'TestFlow' } };
      let result = executeLogic();
      expect(result).toEqual({
        flow: 'TestFlow',
        subFlow: undefined,
      });

      // Test with only subFlow, missing flow
      window.vzdl = { page: { subFlow: 'TestSubFlow' } };
      result = executeLogic();
      expect(result).toEqual({
        flow: undefined,
        subFlow: 'TestSubFlow',
      });
    });

    test('executeLogic should handle string "true" value (case insensitive)', () => {
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ personalShopperFlowTaggingFFlag: 'TrUe', byodPlusPlanFFlag: 'TRUE', byodPlusEUPSupressFFlag: 'TRUE' }));
      window.vzdl = { page: { flow: 'Test', subFlow: 'Test' } };

      const result = executeLogic();
      expect(result).toHaveProperty('flow', 'Test');
      expect(result).toHaveProperty('subFlow', 'Test');
    });

    test('executeLogic should handle string "false" value', () => {
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ personalShopperFlowTaggingFFlag: 'false', byodPlusPlanFFlag: 'TRUE', byodPlusEUPSupressFFlag: 'TRUE' }));

      const result = executeLogic();
      expect(result).toEqual({});
    });

    test('executeLogic should handle undefined personalShopperFlowTaggingFFlag property', () => {
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ otherFlag: 'TRUE', byodPlusPlanFFlag: 'TRUE', byodPlusEUPSupressFFlag: 'TRUE' }));

      const result = executeLogic();
      expect(result).toEqual({});
    });

    test('executeLogic should handle empty window.vzdl.page object', () => {
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ personalShopperFlowTaggingFFlag: 'TRUE', byodPlusPlanFFlag: 'TRUE', byodPlusEUPSupressFFlag: 'TRUE' }));
      window.vzdl = { page: {} };

      const result = executeLogic();
      expect(result).toEqual({
        flow: undefined,
        subFlow: undefined,
      });
    });

    test('executeLogic should return a new object when flag is TRUE', () => {
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ personalShopperFlowTaggingFFlag: 'TRUE', byodPlusPlanFFlag: 'TRUE', byodPlusEUPSupressFFlag: 'TRUE' }));
      window.vzdl = { page: { flow: 'AIQuote', subFlow: 'AAL' } };

      const result = executeLogic();

      // Verify it returns a new object with spread properties
      expect(result).toEqual({
        flow: 'AIQuote',
        subFlow: 'AAL',
      });

      // Verify the function returns the result from addPersonalShopperTaggingFields
      expect(result).toHaveProperty('flow', 'AIQuote');
      expect(result).toHaveProperty('subFlow', 'AAL');
    });

    test('executeLogic should return original object when flag is FALSE', () => {
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ personalShopperFlowTaggingFFlag: 'FALSE', byodPlusPlanFFlag: 'TRUE', byodPlusEUPSupressFFlag: 'TRUE' }));

      const result = executeLogic();

      // Should return the original empty vzdlForOrdering object
      expect(result).toEqual({});
    });
    test('should include flow and subFlow when personalShopperFlowTaggingFFlag is TRUE and Footer component renders', async () => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          personalShopperFlowTaggingFFlag: 'TRUE',
          byodPlusPlanFFlag: 'TRUE',
          byodPlusEUPSupressFFlag: 'TRUE',
        }),
      );
      window.vzdl = { page: { flow: 'AIQuote', subFlow: 'AAL' } };

      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {});
      Emitter.emit('Closing_Device_Protection_Modal', {});

      await new Promise((res) => {
        setTimeout(res, 1000);
      });

      const proceedtoCart = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);

      await new Promise((res) => {
        setTimeout(res, 1000);
      });

      expect(window.vzdl.page.flow).toBe('AIQuote');
      expect(window.vzdl.page.subFlow).toBe('AAL');
    });

    test('should NOT include flow and subFlow when personalShopperFlowTaggingFFlag is FALSE', async () => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          personalShopperFlowTaggingFFlag: 'FALSE',
        }),
      );
      window.vzdl = { page: { flow: 'AIQuote', subFlow: 'AAL' } };

      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {});
      Emitter.emit('Closing_Device_Protection_Modal', {});

      await new Promise((res) => {
        setTimeout(res, 1000);
      });

      const proceedtoCart = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);

      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });

    test('should handle missing personalShopperFlowTaggingFFlag', async () => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          someOtherFlag: 'TRUE',
        }),
      );
      window.vzdl = { page: { flow: 'AIQuote', subFlow: 'AAL' } };

      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {});
      Emitter.emit('Closing_Device_Protection_Modal', {});

      await new Promise((res) => {
        setTimeout(res, 1000);
      });

      const proceedtoCart = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);

      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });

    test('should handle missing APP_PROPERTIES', async () => {
      sessionStorage.removeItem('APP_PROPERTIES');
      window.vzdl = { page: { flow: 'AIQuote', subFlow: 'AAL' } };

      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {});
      Emitter.emit('Closing_Device_Protection_Modal', {});

      await new Promise((res) => {
        setTimeout(res, 1000);
      });

      const proceedtoCart = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);

      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });

    test('should handle case-insensitive personalShopperFlowTaggingFFlag values', async () => {
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ personalShopperFlowTaggingFFlag: 'true', byodPlusPlanFFlag: 'TRUE', byodPlusEUPSupressFFlag: 'TRUE' }));
      window.vzdl = { page: { flow: 'TestFlow', subFlow: 'TestSubFlow' } };

      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {});
      Emitter.emit('Closing_Device_Protection_Modal', {});

      await new Promise((res) => {
        setTimeout(res, 1000);
      });

      const proceedtoCart = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);

      await new Promise((res) => {
        setTimeout(res, 1000);
      });

      expect(window.vzdl.page.flow).toBe('TestFlow');
      expect(window.vzdl.page.subFlow).toBe('TestSubFlow');
    });

    test('should handle null personalShopperFlowTaggingFFlag value', async () => {
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ personalShopperFlowTaggingFFlag: null, byodPlusEUPSupressFFlag: 'TRUE' }));
      window.vzdl = { page: { flow: 'AIQuote', subFlow: 'AAL' } };

      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {});
      Emitter.emit('Closing_Device_Protection_Modal', {});

      await new Promise((res) => {
        setTimeout(res, 1000);
      });

      const proceedtoCart = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);

      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });

    test('should handle empty personalShopperFlowTaggingFFlag value', async () => {
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ personalShopperFlowTaggingFFlag: '', byodPlusPlanFFlag: 'TRUE' }));
      window.vzdl = { page: { flow: 'AIQuote', subFlow: 'AAL' } };

      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {});
      Emitter.emit('Closing_Device_Protection_Modal', {});

      await new Promise((res) => {
        setTimeout(res, 1000);
      });

      const proceedtoCart = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);

      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });

    test('should handle missing window.vzdl', async () => {
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ personalShopperFlowTaggingFFlag: 'TRUE', byodPlusPlanFFlag: 'TRUE' }));
      delete window.vzdl;

      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {});
      Emitter.emit('Closing_Device_Protection_Modal', {});

      await new Promise((res) => {
        setTimeout(res, 1000);
      });

      const proceedtoCart = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);

      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });

    test('should handle missing window.vzdl.page', async () => {
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ personalShopperFlowTaggingFFlag: 'TRUE', byodPlusPlanFFlag: 'TRUE' }));
      window.vzdl = {};

      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {});
      Emitter.emit('Closing_Device_Protection_Modal', {});

      await new Promise((res) => {
        setTimeout(res, 1000);
      });

      const proceedtoCart = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);

      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });

    test('should handle partial window.vzdl.page properties', async () => {
      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ personalShopperFlowTaggingFFlag: 'TRUE', byodPlusPlanFFlag: 'TRUE' }));
      window.vzdl = { page: { flow: 'TestFlow' } };

      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {});
      Emitter.emit('Closing_Device_Protection_Modal', {});

      await new Promise((res) => {
        setTimeout(res, 1000);
      });

      const proceedtoCart = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);

      await new Promise((res) => {
        setTimeout(res, 1000);
      });

      expect(window.vzdl.page.flow).toBe('TestFlow');
      expect(window.vzdl.page.subFlow).toBeUndefined();
    });

    test('renders footer component on click of proceedWithQuote - AAL flow captureQuoteFeedback call request body ', async () => {
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('FETCH_CART_LINE_DETAILS');
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: true,
      });
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: false,
      });
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {});
      Emitter.emit('Closing_Device_Protection_Modal', {});
      Emitter.emit('Priority_upgrade_List', [{ isPriorityMtn: true, mtn: '302383234' }]);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });
  });
};

const TestVMPProtection = (channel) => {
  setupChannel(channel);
  const setFPSProtectionData = jest.fn();
  const setTriggerProceedToQuote = jest.fn();
  describe('Footer', () => {
    const handlers = [
      rest.post(`*fetchPricingSnapshot`, (req, res, ctx) => {
        console.log('inside FPS mock');
        return res(ctx.status(200), ctx.json(FetchPricingSnapshotVMP));
      }),
      rest.post(`*processAcctInquiryTranDetails`, (req, res, ctx) => {
        console.log('inside mock');
        return res(
          ctx.status(200),
          ctx.json({
            data: {
              statusMessage: 'Success',
              uniqueKey: '1710886290738',
              pkSequence: null,
              errors: null,
              status: 1,
            },
          }),
        );
      }),
      rest.post(`*compareQuotes`, (req, res, ctx) => {
        console.log('inside FPS mock');
        return res(ctx.status(200), ctx.json(compareQuotes));
      }),
    ];
    const vzdlMock = window.vzdl;
    delete window.vzdl;
    window.vzdl = {
      ...vzdlMock,
      page: { detail: 'Footer', throttle: 'MFE' },
      event: { value: 'scAdd' },
      txn: { product: { current: [] }, nonRecurringPrice: 0 },
    };

    window.cartProducts = [
      {
        mtn: 'newLine1',
        current: [
          {
            name: 'iPhone 16 Pro Max',
            lineHash: '',
            sku: 'sku6016050',
            shared: 'N',
            id: 'MYW53LL/A',
            category: 'Device',
            discount: 0,
            qty: 1,
            merchCat: '',
            offer: '',
            recurringPrice: 33.33,
            nonRecurringPrice: 1199.99,
            shippingCharge: 0,
            shippingType: '',
            propId: '',
            path: '',
            group: '',
            action: '',
            line: 0,
            contractType: '',
          },
        ],
      },
      {
        mtn: '4844470614',
      },
    ];

    const createAiQuoteResCollection = [{ offerRecommendations: [{ rank: '1', isRtdOffer: 'Y' }] }];
    const declinedProtectionAddedByReps = [{
      mtn: '123',
      isRepDeclinedProtection: true,
    }];
    
    const server = setupServer(...handlers);
    beforeAll(() => server.listen());
    afterEach(() => server.resetHandlers());
    afterAll(() => server.close());
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'FALSE',
          enableShareQuoteinAIQuoteFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
          aiQuoteVMPFFlag: 'TRUE',
        }),
      );
      Object.defineProperty(global.navigator, 'userAgent', {
        get() {
          return 'iPad';
        },
        configurable: true,
      });
      render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          deviceTriageDone
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          triggerProceedToQuote
          aiquoteResponse={aiQuoteResponseJSON}
          createAiQuoteResCollection={createAiQuoteResCollection}
          FetchPricingSnapShotResult={FetchPricingSnapshotVMP}
          setFPSProtectionData={setFPSProtectionData}
          linesWithoutProtection={[{ mtn: 'newLine1' }]}
          isCollaborationStartedForRC
          showPriceDetails
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4844470614', priceEdited: true }]}
          isInDirect={false}
          mandatoryNumberShareLines={[{ mtn: 'newLine1' }]}
          setShowVMPWarningModal={jest.fn()}
          proceedQuoteWithDeclineProtection={false}
          declinedProtectionAddedByReps={declinedProtectionAddedByReps}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
    });

    test('renders Footer content', async () => {
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('FETCH_CART_LINE_DETAILS');
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: true,
      });
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: false,
      });
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {});
      Emitter.emit('Closing_Device_Protection_Modal', {});
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });
  });
};

describe('BYOD+ Discount Modal Tests', () => {
  beforeEach(() => {
    GetAppConfig.mockReturnValue({
      messages: {
        dqContent: {
          byodPlanIDs: ['70143', '70144', '63217', '71156', '71157'],
          byodPromo: ["21259", "21271"]
        },
      },
    });
  });

  afterEach(() => {
    sessionStorage.clear();
    jest.clearAllMocks();
  });

  test.skip('should show BYOD discount modal when hasByodPlan is true and byodPlusPlanFFlag is true', async () => {
    const fpsMockWithByodPlan = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  selectedPlan: {
                    planDetails: {
                      planPromotions: {
                        promos: [
                        { id: '21271'}
                        ]
                      }
                    },
                    planId: '70143',
                    displayName: 'Unlimited BYOD',
                    price: {
                      discountedPrice: 0,
                    },
                  },
                  existingPlan: {
                    planId: '63217',
                    displayName: 'Unlimited Plus',
                    price: {
                      discountedPrice: 0,
                    },
                  },
                },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseJSON}
        FetchPricingSnapShotResult={fpsMockWithByodPlan}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => {
      setTimeout(res, 500);
    });

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      expect(screen.getByTestId('byod-discount-modal')).toBeInTheDocument();
    });
  });

  test('should not show BYOD discount modal when hasByodPlan is false', async () => {
    const fpsMockWithoutByodPlan = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7164753195',
                  selectedPlan: {
                    planId: '70143',
                    displayName: 'Unlimited BYOD',
                    price: {
                      discountedPrice: 0,
                    },
                     planDetails: {
                      planPromotions: {
                        promos: [
                        { id: '21271'}
                        ]
                      }
                    },
                  },
                  existingPlan: { planId: '18056', displayName: 'Number Share' },
                },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseJSON}
        FetchPricingSnapShotResult={fpsMockWithoutByodPlan}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => {
      setTimeout(res, 500);
    });

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      expect(screen.queryByTestId('byod-discount-modal')).not.toBeInTheDocument();
    });
  });

  test('should not show BYOD discount modal when byodPlusPlanFFlag is false', async () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ byodPlusPlanFFlag: 'FALSE', byodPlusEUPSupressFFlag: 'FALSE' }));

    const fpsMockWithByodPlan = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  selectedPlan: {
                    planId: '70143',
                    displayName: 'Unlimited BYOD',
                    price: {
                      discountedPrice: 0,
                    },
                     planDetails: {
                      planPromotions: {
                        promos: [
                        { id: '21271'}
                        ]
                      }
                    },
                  },
                  existingPlan: { planId: '63217', displayName: 'Unlimited Plus' },
                },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseJSON}
        FetchPricingSnapShotResult={fpsMockWithByodPlan}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => {
      setTimeout(res, 500);
    });

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      expect(screen.queryByTestId('byod-discount-modal')).not.toBeInTheDocument();
    });
  });

  test.skip('should test Yes and Cancel button clicks in BYOD discount modal', async () => {
    const setIsProceedToQuoteMock = jest.fn();
    const fpsMockWithByodPlan = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  selectedPlan: {
                    planId: '70143',
                    displayName: 'Unlimited BYOD',
                    price: {
                      discountedPrice: 0,
                    },
                  },
                  existingPlan: {
                    planId: '63217',
                    displayName: 'Unlimited Plus',
                    price: {
                      discountedPrice: 0,
                    },
                  },
                },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={setIsProceedToQuoteMock}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseJSON}
        FetchPricingSnapShotResult={fpsMockWithByodPlan}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => setTimeout(res, 500));

    // Open the BYOD discount modal
    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      expect(screen.getByTestId('byod-discount-modal')).toBeInTheDocument();
    });

    // Verify modal content
    expect(screen.getByText("By changing the plan, the customer's BYOD+ discount will be removed and cannot be readded.")).toBeInTheDocument();
    
    // Get button references
    const yesButton = screen.getByLabelText('confirm byod discount removal');
    
    expect(yesButton).toBeInTheDocument();
    
    // Test Cancel button
    fireEvent.click(cancelButton);
    await waitFor(() => {
      expect(screen.queryByTestId('byod-discount-modal')).not.toBeInTheDocument();
    });
    
    // Open modal again to test Yes button
    const proceedButtonAgain = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButtonAgain);
    
    await waitFor(() => {
      expect(screen.getByTestId('byod-discount-modal')).toBeInTheDocument();
    });
    
    // Test Yes button
    const yesButtonAgain = screen.getByLabelText('confirm byod discount removal');
    fireEvent.click(yesButtonAgain);
    
    await waitFor(() => {
      expect(screen.queryByTestId('byod-discount-modal')).not.toBeInTheDocument();
    });
    
    // Verify that the proceed flow was triggered
    await waitFor(() => {
      expect(setIsProceedToQuoteMock).toHaveBeenCalled();
    });
  });

  test('should close modal when OK button is clicked', async () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ byodPlusPlanFFlag: 'TRUE', byodPlusEUPSupressFFlag: 'TRUE', byodFiveDollarPlanPOSFFlag: 'TRUE' }));

    const fpsMockWithByodPlan = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  selectedPlan: { planId: '69185', displayName: 'Unlimited Ultimate' },
                  existingPlan: {
                    planId: '63217',
                    displayName: 'Unlimited Plus',
                    price: {
                      discountedPrice: 0,
                    },
                  },
                },
              ],
            },
          ],
        },
      },
    };

    const fetchCartDetailsResult = {
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [
                {
                  mobileNumber: '7165790580',
                  serviceInfo: {
                    otherPromotions: [
                      {
                        promos: [
                          {
                            id: '21259',
                          },
                        ],
                      },
                    ],
                  },
                },
              ],
            },
          },
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseJSON}
        FetchPricingSnapShotResult={fpsMockWithByodPlan}
        fetchCartDetailsResult={fetchCartDetailsResult}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => setTimeout(res, 500));

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      expect(screen.getByTestId('byod-discount-modal')).toBeInTheDocument();
    });
    
    const okButton = screen.getByRole('button', { name: /confirm byod discount removal/i });
    fireEvent.click(okButton);

    await waitFor(() => {
      expect(screen.queryByTestId('byod-discount-modal')).not.toBeInTheDocument();
    }, { timeout: 3000 });
    
    // Verify modal is closed
    expect(screen.queryByRole('button', { name: /confirm byod discount removal/i })).not.toBeInTheDocument();
  });

  test.skip('should extract existingPlanIds correctly from FetchPricingSnapShotResult', async () => {
    const fpsMockMultiplePlans = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7164753195',
                  selectedPlan: {
                    planId: '70143',
                    displayName: 'Unlimited BYOD',
                    price: {
                      discountedPrice: 0,
                    },
                  },
                  existingPlan: { planId: '18056', displayName: 'Number Share' },
                },
                {
                  mtn: '7165790580',
                  selectedPlan: { planId: '69185', displayName: 'Unlimited Ultimate' },
                  existingPlan: {
                    planId: '63217',
                    displayName: 'Unlimited Plus',
                    price: {
                      discountedPrice: 0,
                    },
                  },
                },
                {
                  mtn: '7163271624',
                  selectedPlan: { planId: '69185', displayName: 'Unlimited Ultimate' },
                  existingPlan: { planId: '69185', displayName: 'Unlimited Ultimate' },
                },
                {
                  mtn: 'newLine1',
                  selectedPlan: { planId: '63217', displayName: 'Unlimited Plus' },
                  existingPlan: null,
                },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseJSON}
        FetchPricingSnapShotResult={fpsMockMultiplePlans}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => setTimeout(res, 500));

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      expect(screen.getByTestId('byod-discount-modal')).toBeInTheDocument();
    });
  });

  test.skip('should show BYOD discount modal when existingPlan has discountedPrice === 0', async () => {
    const fpsMockWithDiscountedPriceZero = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  selectedPlan: {
                    planId: '70143',
                    displayName: 'Unlimited BYOD',
                    price: {
                      discountedPrice: 0,
                    },
                  },
                  existingPlan: {
                    planId: '63217',
                    displayName: 'Unlimited Plus',
                    price: {
                      discountedPrice: 0,
                    },
                  },
                },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseJSON}
        FetchPricingSnapShotResult={fpsMockWithDiscountedPriceZero}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => setTimeout(res, 500));

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      expect(screen.getByTestId('byod-discount-modal')).toBeInTheDocument();
    });
  });

  test('should NOT show BYOD discount modal when existingPlan has discountedPrice !== 0', async () => {
    const fpsMockWithDiscountedPriceNonZero = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  selectedPlan: { planId: '69185', displayName: 'Unlimited Ultimate' },
                  existingPlan: {
                    planId: '63217',
                    displayName: 'Unlimited Plus',
                    price: {
                      discountedPrice: 10.99,
                    },
                  },
                },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseJSON}
        FetchPricingSnapShotResult={fpsMockWithDiscountedPriceNonZero}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => setTimeout(res, 500));

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      expect(screen.queryByTestId('byod-discount-modal')).not.toBeInTheDocument();
    });
  });

  test('should NOT show BYOD discount modal when existingPlan has no price object', async () => {
    const fpsMockWithoutPrice = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  selectedPlan: { planId: '69185', displayName: 'Unlimited Ultimate' },
                  existingPlan: {
                    planId: '63217',
                    displayName: 'Unlimited Plus',
                  },
                },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseJSON}
        FetchPricingSnapShotResult={fpsMockWithoutPrice}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => setTimeout(res, 500));

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      expect(screen.queryByTestId('byod-discount-modal')).not.toBeInTheDocument();
    });
  });

  test('should NOT show BYOD discount modal when existingPlan has price but no discountedPrice property', async () => {
    const fpsMockWithPriceButNoDiscountedPrice = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  selectedPlan: { planId: '70143', displayName: 'Unlimited BYOD' },
                  existingPlan: {
                    planId: '63217',
                    displayName: 'Unlimited Plus',
                    price: {
                      basePrice: 50.00,
                    },
                  },
                },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseJSON}
        FetchPricingSnapShotResult={fpsMockWithPriceButNoDiscountedPrice}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => setTimeout(res, 500));

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      expect(screen.queryByTestId('byod-discount-modal')).not.toBeInTheDocument();
    });
  });
});

describe('BYOD+ Discount Modal - newByodPlanIds with DPP+EUP Tests', () => {
  beforeEach(() => {
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({
        byodPlusPlanFFlag: 'TRUE',
        byodFiveDollarPlanPOSFFlag: 'TRUE',
        newByodPlanDppEupFFlag: 'TRUE',
      }),
    );
    GetAppConfig.mockReturnValue({
      messages: {
        dqContent: {
          byodPlanIDs: ['70143', '70144', '63217', '71156', '71157'],
          byodPromo: ['21259', '21271'],
          newByodPlanIds: ['80001', '80002'],
        },
      },
    });
  });

  afterEach(() => {
    sessionStorage.clear();
    jest.clearAllMocks();
  });

  test('should show modal with DPP+EUP message when newByodPlanIds selected with DPP contractType and EUP intentType', async () => {
    const fpsMockWithNewByodPlan = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  dummyMtn: 'newLine1',
                  existingPlan: {
                    planId: '80001',
                    displayName: 'Current Unlimited BYOD',
                  },
                  selectedPlan: {
                    planId: '80001',
                    displayName: 'New Unlimited BYOD',
                    price: {
                      discountedPrice: 0,
                    },
                    planDetails: {
                      planPromotions: {
                        promos: [{ id: '21271' }],
                      },
                    },
                  },
                },
              ],
            },
          ],
        },
      },
    };

    const aiQuoteResponseWithDppEup = {
      data: {
        service: {
          ...aiQuoteResponseJSON.service,
          serviceBody: {
            ...aiQuoteResponseJSON.service.serviceBody,
            serviceRequest: {
              ...aiQuoteResponseJSON.service.serviceBody.serviceRequest,
              customerInfo: {
                ...aiQuoteResponseJSON.service.serviceBody.serviceRequest.customerInfo,
                lineInfo: [
                  {
                    mtn: '7165790580',
                    contractType: 'DPP',
                    intentType: 'EUP',
                  },
                ],
              },
            },
          },
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseWithDppEup}
        FetchPricingSnapShotResult={fpsMockWithNewByodPlan}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
        createAiQuoteResCollection={[
          {
            mtn: '7165790580',
            contractType: 'DPP',
            intentType: 'EUP',
          },
        ]}
        fetchCartDetailsResult={{
          data: {
            data: {
              cart: {
                lineDetails: {
                  lineInfo: [
                    {
                      mobileNumber: '7165790580',
                      serviceInfo: {
                        otherPromotions: [
                          {
                            promos: [
                              {
                                id: '21271',
                                discountActionCd: 'END',
                              },
                            ],
                          },
                        ],
                      },
                    },
                  ],
                },
              },
            },
          },
        }}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => {
      setTimeout(res, 500);
    });

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      expect(screen.getByTestId('byod-discount-modal')).toBeInTheDocument();
      expect(screen.getByText('Confirm Phone Upgrade')).toBeInTheDocument();
      expect(screen.getByText("By upgrading the device, the customer's BYOD+ discount will be removed and cannot be readded.")).toBeInTheDocument();
    });
  });

  test('should not show modal when discountActionCd is not END', async () => {
    const fpsMockWithNewByodPlan = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  dummyMtn: 'newLine1',
                  existingPlan: {
                    planId: '80001',
                    displayName: 'Current Unlimited BYOD',
                  },
                  selectedPlan: {
                    planId: '80001',
                    displayName: 'New Unlimited BYOD',
                    price: {
                      discountedPrice: 0,
                    },
                    planDetails: {
                      planPromotions: {
                        promos: [{ id: '21271' }],
                      },
                    },
                  },
                },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseJSON}
        FetchPricingSnapShotResult={fpsMockWithNewByodPlan}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
        createAiQuoteResCollection={[
          {
            mtn: '7165790580',
            contractType: 'DPP',
            intentType: 'EUP',
          },
        ]}
        fetchCartDetailsResult={{
          data: {
            data: {
              cart: {
                lineDetails: {
                  lineInfo: [
                    {
                      mobileNumber: '7165790580',
                      serviceInfo: {
                        otherPromotions: [
                          {
                            promos: [
                              {
                                id: '21271',
                                discountActionCd: 'ADD',
                              },
                            ],
                          },
                        ],
                      },
                    },
                  ],
                },
              },
            },
          },
        }}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => {
      setTimeout(res, 500);
    });

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      expect(screen.queryByTestId('byod-discount-modal')).not.toBeInTheDocument();
    });
  });

  test('should not show modal when newByodPlanDppEupFFlag is false', async () => {
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({
        byodPlusPlanFFlag: 'TRUE',
        byodFiveDollarPlanPOSFFlag: 'TRUE',
        newByodPlanDppEupFFlag: 'FALSE',
      }),
    );

    const fpsMockWithNewByodPlan = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  selectedPlan: {
                    planId: '80001',
                    displayName: 'New Unlimited BYOD',
                    price: {
                      discountedPrice: 0,
                    },
                    planDetails: {
                      planPromotions: {
                        promos: [{ id: '21271' }],
                      },
                    },
                  },
                },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseJSON}
        FetchPricingSnapShotResult={fpsMockWithNewByodPlan}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
        createAiQuoteResCollection={[
          {
            mtn: '7165790580',
            contractType: 'DPP',
            intentType: 'EUP',
          },
        ]}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => {
      setTimeout(res, 500);
    });

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      expect(screen.queryByTestId('byod-discount-modal')).not.toBeInTheDocument();
    });
  });

  test('should match line with dummyMtn when checking DPP+EUP from AI Quote', async () => {
    const fpsMockWithNewByodPlan = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: 'newLine1',
                  dummyMtn: 'newLine1',
                  existingPlan: {
                    planId: '80001',
                    displayName: 'Current Unlimited BYOD',
                  },
                  selectedPlan: {
                    planId: '80001',
                    displayName: 'New Unlimited BYOD',
                    price: {
                      discountedPrice: 0,
                    },
                    planDetails: {
                      planPromotions: {
                        promos: [{ id: '21271' }],
                      },
                    },
                  },
                },
              ],
            },
          ],
        },
      },
    };

    const aiQuoteResponseWithDppEupNewLine = {
      data: {
        service: {
          ...aiQuoteResponseJSON.service,
          serviceBody: {
            ...aiQuoteResponseJSON.service.serviceBody,
            serviceRequest: {
              ...aiQuoteResponseJSON.service.serviceBody.serviceRequest,
              customerInfo: {
                ...aiQuoteResponseJSON.service.serviceBody.serviceRequest.customerInfo,
                lineInfo: [
                  {
                    mtn: 'newLine1',
                    contractType: 'DPP',
                    intentType: 'EUP',
                  },
                ],
              },
            },
          },
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseWithDppEupNewLine}
        FetchPricingSnapShotResult={fpsMockWithNewByodPlan}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
        createAiQuoteResCollection={[
          {
            mtn: 'newLine1',
            contractType: 'DPP',
            intentType: 'EUP',
          },
        ]}
        fetchCartDetailsResult={{
          data: {
            data: {
              cart: {
                lineDetails: {
                  lineInfo: [
                    {
                      mobileNumber: 'newLine1',
                      serviceInfo: {
                        otherPromotions: [
                          {
                            promos: [
                              {
                                id: '21271',
                                discountActionCd: 'END',
                              },
                            ],
                          },
                        ],
                      },
                    },
                  ],
                },
              },
            },
          },
        }}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => {
      setTimeout(res, 500);
    });

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      expect(screen.getByTestId('byod-discount-modal')).toBeInTheDocument();
      expect(screen.getByText('Confirm Phone Upgrade')).toBeInTheDocument();
    });
  });

  test('should proceed with quote after clicking OK button in DPP+EUP modal', async () => {
    const fpsMockWithNewByodPlan = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  existingPlan: {
                    planId: '80001',
                    displayName: 'Current Unlimited BYOD',
                  },
                  selectedPlan: {
                    planId: '80001',
                    displayName: 'New Unlimited BYOD',
                    price: {
                      discountedPrice: 0,
                    },
                    planDetails: {
                      planPromotions: {
                        promos: [{ id: '21271' }],
                      },
                    },
                  },
                },
              ],
            },
          ],
        },
      },
    };

    const aiQuoteResponseWithDppEup7165790580 = {
      data: {
        service: {
          ...aiQuoteResponseJSON.service,
          serviceBody: {
            ...aiQuoteResponseJSON.service.serviceBody,
            serviceRequest: {
              ...aiQuoteResponseJSON.service.serviceBody.serviceRequest,
              customerInfo: {
                ...aiQuoteResponseJSON.service.serviceBody.serviceRequest.customerInfo,
                lineInfo: [
                  {
                    mtn: '7165790580',
                    contractType: 'DPP',
                    intentType: 'EUP',
                  },
                ],
              },
            },
          },
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseWithDppEup7165790580}
        FetchPricingSnapShotResult={fpsMockWithNewByodPlan}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
        createAiQuoteResCollection={[
          {
            mtn: '7165790580',
            contractType: 'DPP',
            intentType: 'EUP',
          },
        ]}
        fetchCartDetailsResult={{
          data: {
            data: {
              cart: {
                lineDetails: {
                  lineInfo: [
                    {
                      mobileNumber: '7165790580',
                      serviceInfo: {
                        otherPromotions: [
                          {
                            promos: [
                              {
                                id: '21271',
                                discountActionCd: 'END',
                              },
                            ],
                          },
                        ],
                      },
                    },
                  ],
                },
              },
            },
          },
        }}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => {
      setTimeout(res, 500);
    });

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      expect(screen.getByTestId('byod-discount-modal')).toBeInTheDocument();
    });

    const okButton = screen.getByRole('button', { name: /confirm byod discount removal/i });
    fireEvent.click(okButton);

    await waitFor(() => {
      expect(screen.queryByTestId('byod-discount-modal')).not.toBeInTheDocument();
    });
  });

  test('should set hasNewByodSelected to true when newByodPlanIds match regardless of DPP+EUP', async () => {
    const fpsMockWithNewByodPlan = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  existingPlan: {
                    planId: '80001',
                    displayName: 'Current Unlimited BYOD',
                  },
                  selectedPlan: {
                    planId: '80001',
                    displayName: 'New Unlimited BYOD',
                    price: {
                      discountedPrice: 0,
                    },
                    planDetails: {
                      planPromotions: {
                        promos: [{ id: '21271' }],
                      },
                    },
                  },
                },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseJSON}
        FetchPricingSnapShotResult={fpsMockWithNewByodPlan}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
        createAiQuoteResCollection={[
          {
            mtn: '7165790580',
            contractType: 'FR',
            intentType: 'EUP',
          },
        ]}
        fetchCartDetailsResult={{
          data: {
            data: {
              cart: {
                lineDetails: {
                  lineInfo: [
                    {
                      mobileNumber: '7165790580',
                      serviceInfo: {
                        otherPromotions: [
                          {
                            promos: [
                              {
                                id: '21271',
                                discountActionCd: 'END',
                              },
                            ],
                          },
                        ],
                      },
                    },
                  ],
                },
              },
            },
          },
        }}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => {
      setTimeout(res, 500);
    });

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      expect(screen.getByTestId('byod-discount-modal')).toBeInTheDocument();
      expect(screen.getByText('Confirm plan change')).toBeInTheDocument();
      expect(screen.getByText("By changing the plan, the customer's BYOD+ discount will be removed and cannot be readded.")).toBeInTheDocument();
    });
  });

  test('should not execute newByodPlanIds logic when flag is false', async () => {
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({
        byodPlusPlanFFlag: 'TRUE',
        byodFiveDollarPlanPOSFFlag: 'TRUE',
        newByodPlanDppEupFFlag: 'FALSE',
      }),
    );

    const fpsMockWithNewByodPlan = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  selectedPlan: {
                    planId: '80001',
                    displayName: 'New Unlimited BYOD',
                    price: {
                      discountedPrice: 0,
                    },
                    planDetails: {
                      planPromotions: {
                        promos: [{ id: '21271' }],
                      },
                    },
                  },
                },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseJSON}
        FetchPricingSnapShotResult={fpsMockWithNewByodPlan}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
        createAiQuoteResCollection={[
          {
            mtn: '7165790580',
            contractType: 'DPP',
            intentType: 'EUP',
          },
        ]}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => {
      setTimeout(res, 500);
    });

    // Verify variables remain false when flag is disabled
    const proceedButton = await screen.findByTestId('footercomponentButton');
    expect(proceedButton).toBeInTheDocument();
  });

  test('should handle case when aiQuoteLine is not found in createAiQuoteResCollection', async () => {
    const fpsMockWithNewByodPlan = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  dummyMtn: 'newLine1',
                  existingPlan: {
                    planId: '80001',
                    displayName: 'Current Unlimited BYOD',
                  },
                  selectedPlan: {
                    planId: '80001',
                    displayName: 'New Unlimited BYOD',
                    price: {
                      discountedPrice: 0,
                    },
                    planDetails: {
                      planPromotions: {
                        promos: [{ id: '21271' }],
                      },
                    },
                  },
                },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseJSON}
        FetchPricingSnapShotResult={fpsMockWithNewByodPlan}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
        createAiQuoteResCollection={[
          {
            mtn: 'differentMTN',
            contractType: 'DPP',
            intentType: 'EUP',
          },
        ]}
        fetchCartDetailsResult={{
          data: {
            data: {
              cart: {
                lineDetails: {
                  lineInfo: [
                    {
                      mobileNumber: '7165790580',
                      serviceInfo: {
                        otherPromotions: [
                          {
                            promos: [
                              {
                                id: '21271',
                                discountActionCd: 'END',
                              },
                            ],
                          },
                        ],
                      },
                    },
                  ],
                },
              },
            },
          },
        }}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => {
      setTimeout(res, 500);
    });

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    // Should not show DPP+EUP modal since aiQuoteLine is not found, but should show default modal
    await waitFor(() => {
      expect(screen.getByTestId('byod-discount-modal')).toBeInTheDocument();
      expect(screen.getByText('Confirm plan change')).toBeInTheDocument();
    });
  });

  test('should handle case when aiQuoteLine found but contractType is not DPP', async () => {
    const fpsMockWithNewByodPlan = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  existingPlan: {
                    planId: '80001',
                    displayName: 'Current Unlimited BYOD',
                  },
                  selectedPlan: {
                    planId: '80001',
                    displayName: 'New Unlimited BYOD',
                    price: {
                      discountedPrice: 0,
                    },
                    planDetails: {
                      planPromotions: {
                        promos: [{ id: '21271' }],
                      },
                    },
                  },
                },
              ],
            },
          ],
        },
      },
    };

    const aiQuoteResponseWithFR = {
      data: {
        service: {
          ...aiQuoteResponseJSON.service,
          serviceBody: {
            ...aiQuoteResponseJSON.service.serviceBody,
            serviceRequest: {
              ...aiQuoteResponseJSON.service.serviceBody.serviceRequest,
              customerInfo: {
                ...aiQuoteResponseJSON.service.serviceBody.serviceRequest.customerInfo,
                lineInfo: [
                  {
                    mtn: '7165790580',
                    contractType: 'FR',
                    intentType: 'EUP',
                  },
                ],
              },
            },
          },
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseWithFR}
        FetchPricingSnapShotResult={fpsMockWithNewByodPlan}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
        createAiQuoteResCollection={[
          {
            mtn: '7165790580',
            contractType: 'FR',
            intentType: 'EUP',
          },
        ]}
        fetchCartDetailsResult={{
          data: {
            data: {
              cart: {
                lineDetails: {
                  lineInfo: [
                    {
                      mobileNumber: '7165790580',
                      serviceInfo: {
                        otherPromotions: [
                          {
                            promos: [
                              {
                                id: '21271',
                                discountActionCd: 'END',
                              },
                            ],
                          },
                        ],
                      },
                    },
                  ],
                },
              },
            },
          },
        }}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => {
      setTimeout(res, 500);
    });

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    // Should show default modal when contractType is not DPP
    await waitFor(() => {
      expect(screen.getByTestId('byod-discount-modal')).toBeInTheDocument();
      expect(screen.getByText('Confirm plan change')).toBeInTheDocument();
    });
  });

  test('should set hasNewByodSelected true when existingPlan matches newByodPlanIds and promo has END action', async () => {
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({
        byodPlusPlanFFlag: 'TRUE',
        byodFiveDollarPlanPOSFFlag: 'TRUE',
        newByodPlanDppEupFFlag: 'TRUE',
      }),
    );

    const fpsMock = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          ...FetchPricingSnapshot.data.data,
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  existingPlan: {
                    planId: '71156',
                    displayName: 'New BYOD Plan',
                  },
                  selectedPlan: {
                    planId: '71156',
                    displayName: 'New BYOD Plan',
                  },
                },
              ],
            },
          ],
        },
      },
    };

    const fetchCartDetailsResult = {
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [
                {
                  mobileNumber: '7165790580',
                  serviceInfo: {
                    otherPromotions: [
                      {
                        promos: [
                          {
                            id: '21259',
                            discountActionCd: 'END',
                          },
                        ],
                      },
                    ],
                  },
                },
              ],
            },
          },
        },
      },
    };

    const aiquoteResponse = {
      data: {
        service: {
          serviceBody: {
            serviceRequest: {
              customerInfo: {
                lineInfo: [
                  {
                    mtn: '7165790580',
                    contractType: 'FR',
                    intentType: 'EUP',
                  },
                ],
              },
            },
          },
        },
      },
    };

    const { container } = render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={fpsMock}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        aiquoteResponse={aiquoteResponse}
        fetchCartDetailsResult={fetchCartDetailsResult}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    expect(container).toBeTruthy();
  });

  test('should set hasNewByodWithDppEup true when DPP+EUP conditions met and no plan change', async () => {
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({
        byodPlusPlanFFlag: 'TRUE',
        byodFiveDollarPlanPOSFFlag: 'TRUE',
        newByodPlanDppEupFFlag: 'TRUE',
      }),
    );

    const fpsMock = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          ...FetchPricingSnapshot.data.data,
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  existingPlan: {
                    planId: '71157',
                    displayName: 'New BYOD Plan',
                  },
                  selectedPlan: {
                    planId: '71157',
                    displayName: 'New BYOD Plan',
                  },
                },
              ],
            },
          ],
        },
      },
    };

    const fetchCartDetailsResult = {
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [
                {
                  mobileNumber: '7165790580',
                  serviceInfo: {
                    otherPromotions: [
                      {
                        promos: [
                          {
                            id: '21271',
                            discountActionCd: 'END',
                          },
                        ],
                      },
                    ],
                  },
                },
              ],
            },
          },
        },
      },
    };

    const aiquoteResponse = {
      data: {
        service: {
          serviceBody: {
            serviceRequest: {
              customerInfo: {
                lineInfo: [
                  {
                    mtn: '7165790580',
                    contractType: 'DPP',
                    intentType: 'EUP',
                  },
                ],
              },
            },
          },
        },
      },
    };

    const { container } = render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={fpsMock}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        aiquoteResponse={aiquoteResponse}
        fetchCartDetailsResult={fetchCartDetailsResult}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    expect(container).toBeTruthy();
  });

  test('should match aiQuoteLine using dummyMtn when mtn does not match', async () => {
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({
        byodPlusPlanFFlag: 'TRUE',
        byodFiveDollarPlanPOSFFlag: 'TRUE',
        newByodPlanDppEupFFlag: 'TRUE',
      }),
    );

    const fpsMock = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          ...FetchPricingSnapshot.data.data,
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  dummyMtn: 'newLine1',
                  existingPlan: {
                    planId: '71156',
                    displayName: 'New BYOD Plan',
                  },
                  selectedPlan: {
                    planId: '71156',
                    displayName: 'New BYOD Plan',
                  },
                },
              ],
            },
          ],
        },
      },
    };

    const fetchCartDetailsResult = {
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [
                {
                  mobileNumber: '7165790580',
                  serviceInfo: {
                    otherPromotions: [
                      {
                        promos: [
                          {
                            id: '21259',
                            discountActionCd: 'END',
                          },
                        ],
                      },
                    ],
                  },
                },
              ],
            },
          },
        },
      },
    };

    const aiquoteResponse = {
      data: {
        service: {
          serviceBody: {
            serviceRequest: {
              customerInfo: {
                lineInfo: [
                  {
                    mtn: 'newLine1',
                    contractType: 'DPP',
                    intentType: 'EUP',
                  },
                ],
              },
            },
          },
        },
      },
    };

    const { container } = render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={fpsMock}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        aiquoteResponse={aiquoteResponse}
        fetchCartDetailsResult={fetchCartDetailsResult}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    expect(container).toBeTruthy();
  });

  test('should not set hasNewByodWithDppEup when plan has changed', async () => {
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({
        byodPlusPlanFFlag: 'TRUE',
        byodFiveDollarPlanPOSFFlag: 'TRUE',
        newByodPlanDppEupFFlag: 'TRUE',
      }),
    );

    const fpsMock = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          ...FetchPricingSnapshot.data.data,
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  existingPlan: {
                    planId: '71156',
                    displayName: 'New BYOD Plan',
                  },
                  selectedPlan: {
                    planId: '70143',
                    displayName: 'Different Plan',
                  },
                },
              ],
            },
          ],
        },
      },
    };

    const fetchCartDetailsResult = {
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [
                {
                  mobileNumber: '7165790580',
                  serviceInfo: {
                    otherPromotions: [
                      {
                        promos: [
                          {
                            id: '21259',
                            discountActionCd: 'END',
                          },
                        ],
                      },
                    ],
                  },
                },
              ],
            },
          },
        },
      },
    };

    const aiquoteResponse = {
      data: {
        service: {
          serviceBody: {
            serviceRequest: {
              customerInfo: {
                lineInfo: [
                  {
                    mtn: '7165790580',
                    contractType: 'DPP',
                    intentType: 'EUP',
                  },
                ],
              },
            },
          },
        },
      },
    };

    const { container } = render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={fpsMock}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        aiquoteResponse={aiquoteResponse}
        fetchCartDetailsResult={fetchCartDetailsResult}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    expect(container).toBeTruthy();
  });

  test('should not set hasNewByodSelected when discountActionCd is not END', async () => {
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({
        byodPlusPlanFFlag: 'TRUE',
        byodFiveDollarPlanPOSFFlag: 'TRUE',
        newByodPlanDppEupFFlag: 'TRUE',
      }),
    );

    const fpsMock = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          ...FetchPricingSnapshot.data.data,
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  existingPlan: {
                    planId: '71156',
                    displayName: 'New BYOD Plan',
                  },
                  selectedPlan: {
                    planId: '71156',
                    displayName: 'New BYOD Plan',
                  },
                },
              ],
            },
          ],
        },
      },
    };

    const fetchCartDetailsResult = {
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [
                {
                  mobileNumber: '7165790580',
                  serviceInfo: {
                    otherPromotions: [
                      {
                        promos: [
                          {
                            id: '21259',
                            discountActionCd: 'ADD',
                          },
                        ],
                      },
                    ],
                  },
                },
              ],
            },
          },
        },
      },
    };

    const aiquoteResponse = {
      data: {
        service: {
          serviceBody: {
            serviceRequest: {
              customerInfo: {
                lineInfo: [
                  {
                    mtn: '7165790580',
                    contractType: 'DPP',
                    intentType: 'EUP',
                  },
                ],
              },
            },
          },
        },
      },
    };

    const { container } = render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={fpsMock}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        aiquoteResponse={aiquoteResponse}
        fetchCartDetailsResult={fetchCartDetailsResult}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    expect(container).toBeTruthy();
  });

  test('should handle case when aiQuoteLine found but intentType is not EUP', async () => {
    const fpsMockWithNewByodPlan = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  existingPlan: {
                    planId: '80001',
                    displayName: 'Current Unlimited BYOD',
                  },
                  selectedPlan: {
                    planId: '80001',
                    displayName: 'New Unlimited BYOD',
                    price: {
                      discountedPrice: 0,
                    },
                    planDetails: {
                      planPromotions: {
                        promos: [{ id: '21271' }],
                      },
                    },
                  },
                },
              ],
            },
          ],
        },
      },
    };

    const aiQuoteResponseWithAAL = {
      data: {
        service: {
          ...aiQuoteResponseJSON.service,
          serviceBody: {
            ...aiQuoteResponseJSON.service.serviceBody,
            serviceRequest: {
              ...aiQuoteResponseJSON.service.serviceBody.serviceRequest,
              customerInfo: {
                ...aiQuoteResponseJSON.service.serviceBody.serviceRequest.customerInfo,
                lineInfo: [
                  {
                    mtn: '7165790580',
                    contractType: 'DPP',
                    intentType: 'AAL',
                  },
                ],
              },
            },
          },
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseWithAAL}
        FetchPricingSnapShotResult={fpsMockWithNewByodPlan}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
        createAiQuoteResCollection={[
          {
            mtn: '7165790580',
            contractType: 'DPP',
            intentType: 'AAL',
          },
        ]}
        fetchCartDetailsResult={{
          data: {
            data: {
              cart: {
                lineDetails: {
                  lineInfo: [
                    {
                      mobileNumber: '7165790580',
                      serviceInfo: {
                        otherPromotions: [
                          {
                            promos: [
                              {
                                id: '21271',
                                discountActionCd: 'END',
                              },
                            ],
                          },
                        ],
                      },
                    },
                  ],
                },
              },
            },
          },
        }}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => {
      setTimeout(res, 500);
    });

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    // Should show default modal when intentType is not EUP
    await waitFor(() => {
      expect(screen.getByTestId('byod-discount-modal')).toBeInTheDocument();
      expect(screen.getByText('Confirm plan change')).toBeInTheDocument();
    });
  });

  test('should handle case when FetchPricingSnapShotResult has no lines', async () => {
    const fpsMockWithNoLines = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseJSON}
        FetchPricingSnapShotResult={fpsMockWithNoLines}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
        createAiQuoteResCollection={[]}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => {
      setTimeout(res, 500);
    });

    const proceedButton = await screen.findByTestId('footercomponentButton');
    expect(proceedButton).toBeInTheDocument();
  });

  test('should handle case when createAiQuoteResCollection is undefined', async () => {
    const fpsMockWithNewByodPlan = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  selectedPlan: {
                    planId: '80001',
                    displayName: 'New Unlimited BYOD',
                    price: {
                      discountedPrice: 0,
                    },
                    planDetails: {
                      planPromotions: {
                        promos: [{ id: '21271' }],
                      },
                    },
                  },
                },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseJSON}
        FetchPricingSnapShotResult={fpsMockWithNewByodPlan}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
        createAiQuoteResCollection={undefined}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => {
      setTimeout(res, 500);
    });

    const proceedButton = await screen.findByTestId('footercomponentButton');
    expect(proceedButton).toBeInTheDocument();
  });

  test('should handle multiple lines where only one matches newByodPlanIds with DPP+EUP', async () => {
    const fpsMockWithMultipleLines = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  selectedPlan: {
                    planId: '70143',
                    displayName: 'Regular Plan',
                    price: {
                      discountedPrice: 30,
                    },
                  },
                },
                {
                  mtn: '7165790581',
                  existingPlan: {
                    planId: '80001',
                    displayName: 'Current Unlimited BYOD',
                  },
                  selectedPlan: {
                    planId: '80001',
                    displayName: 'New Unlimited BYOD',
                    price: {
                      discountedPrice: 0,
                    },
                    planDetails: {
                      planPromotions: {
                        promos: [{ id: '21271' }],
                      },
                    },
                  },
                },
              ],
            },
          ],
        },
      },
    };

    const aiQuoteResponseMultiLines = {
      data: {
        service: {
          ...aiQuoteResponseJSON.service,
          serviceBody: {
            ...aiQuoteResponseJSON.service.serviceBody,
            serviceRequest: {
              ...aiQuoteResponseJSON.service.serviceBody.serviceRequest,
              customerInfo: {
                ...aiQuoteResponseJSON.service.serviceBody.serviceRequest.customerInfo,
                lineInfo: [
                  {
                    mtn: '7165790580',
                    contractType: 'FR',
                    intentType: 'AAL',
                  },
                  {
                    mtn: '7165790581',
                    contractType: 'DPP',
                    intentType: 'EUP',
                  },
                ],
              },
            },
          },
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseMultiLines}
        FetchPricingSnapShotResult={fpsMockWithMultipleLines}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
        createAiQuoteResCollection={[
          {
            mtn: '7165790580',
            contractType: 'FR',
            intentType: 'AAL',
          },
          {
            mtn: '7165790581',
            contractType: 'DPP',
            intentType: 'EUP',
          },
        ]}
        fetchCartDetailsResult={{
          data: {
            data: {
              cart: {
                lineDetails: {
                  lineInfo: [
                    {
                      mobileNumber: '7165790581',
                      serviceInfo: {
                        otherPromotions: [
                          {
                            promos: [
                              {
                                id: '21271',
                                discountActionCd: 'END',
                              },
                            ],
                          },
                        ],
                      },
                    },
                  ],
                },
              },
            },
          },
        }}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => {
      setTimeout(res, 500);
    });

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      expect(screen.getByTestId('byod-discount-modal')).toBeInTheDocument();
      expect(screen.getByText('Confirm Phone Upgrade')).toBeInTheDocument();
    });
  });

  test('should handle case when line has no planDetails', async () => {
    const fpsMockWithNoPlanDetails = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  existingPlan: {
                    planId: '80001',
                    displayName: 'Current Unlimited BYOD',
                  },
                  selectedPlan: {
                    planId: '80001',
                    displayName: 'New Unlimited BYOD',
                    price: {
                      discountedPrice: 0,
                    },
                  },
                  addons: [{ sorId: '21271' }],
                },
              ],
            },
          ],
        },
      },
    };

    const aiQuoteResponseNoPlanDetails = {
      data: {
        service: {
          ...aiQuoteResponseJSON.service,
          serviceBody: {
            ...aiQuoteResponseJSON.service.serviceBody,
            serviceRequest: {
              ...aiQuoteResponseJSON.service.serviceBody.serviceRequest,
              customerInfo: {
                ...aiQuoteResponseJSON.service.serviceBody.serviceRequest.customerInfo,
                lineInfo: [
                  {
                    mtn: '7165790580',
                    contractType: 'DPP',
                    intentType: 'EUP',
                  },
                ],
              },
            },
          },
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseNoPlanDetails}
        FetchPricingSnapShotResult={fpsMockWithNoPlanDetails}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
        createAiQuoteResCollection={[
          {
            mtn: '7165790580',
            contractType: 'DPP',
            intentType: 'EUP',
          },
        ]}
        fetchCartDetailsResult={{
          data: {
            data: {
              cart: {
                lineDetails: {
                  lineInfo: [
                    {
                      mobileNumber: '7165790580',
                      serviceInfo: {
                        otherPromotions: [
                          {
                            promos: [
                              {
                                id: '21271',
                                discountActionCd: 'END',
                              },
                            ],
                          },
                        ],
                      },
                    },
                  ],
                },
              },
            },
          },
        }}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => {
      setTimeout(res, 500);
    });

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      expect(screen.getByTestId('byod-discount-modal')).toBeInTheDocument();
      expect(screen.getByText('Confirm Phone Upgrade')).toBeInTheDocument();
    });
  });

  test('should handle case when both mtn and dummyMtn do not match', async () => {
    const fpsMockWithNewByodPlan = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  dummyMtn: 'newLine1',
                  selectedPlan: {
                    planId: '80001',
                    displayName: 'New Unlimited BYOD',
                    price: {
                      discountedPrice: 0,
                    },
                    planDetails: {
                      planPromotions: {
                        promos: [{ id: '21271' }],
                      },
                    },
                  },
                },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseJSON}
        FetchPricingSnapShotResult={fpsMockWithNewByodPlan}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
        createAiQuoteResCollection={[
          {
            mtn: '9999999999',
            contractType: 'DPP',
            intentType: 'EUP',
          },
        ]}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => {
      setTimeout(res, 500);
    });

    const proceedButton = await screen.findByTestId('footercomponentButton');
    expect(proceedButton).toBeInTheDocument();
  });

  test('should not show modal when promo ID is not in byodPromo list', async () => {
    const fpsMockWithNewByodPlan = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  existingPlan: {
                    planId: '80001',
                    displayName: 'Current Unlimited BYOD',
                  },
                  selectedPlan: {
                    planId: '80001',
                    displayName: 'New Unlimited BYOD',
                    price: {
                      discountedPrice: 0,
                    },
                  },
                },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseJSON}
        FetchPricingSnapShotResult={fpsMockWithNewByodPlan}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
        createAiQuoteResCollection={[
          {
            mtn: '7165790580',
            contractType: 'DPP',
            intentType: 'EUP',
          },
        ]}
        fetchCartDetailsResult={{
          data: {
            data: {
              cart: {
                lineDetails: {
                  lineInfo: [
                    {
                      mobileNumber: '7165790580',
                      serviceInfo: {
                        otherPromotions: [
                          {
                            promos: [
                              {
                                id: '99999',
                                discountActionCd: 'END',
                              },
                            ],
                          },
                        ],
                      },
                    },
                  ],
                },
              },
            },
          },
        }}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => {
      setTimeout(res, 500);
    });

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      expect(screen.queryByTestId('byod-discount-modal')).not.toBeInTheDocument();
    });
  });

  test('should not show modal when fetchCartDetailsResult is undefined', async () => {
    const fpsMockWithNewByodPlan = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  existingPlan: {
                    planId: '80001',
                    displayName: 'Current Unlimited BYOD',
                  },
                  selectedPlan: {
                    planId: '80001',
                    displayName: 'New Unlimited BYOD',
                    price: {
                      discountedPrice: 0,
                    },
                  },
                },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseJSON}
        FetchPricingSnapShotResult={fpsMockWithNewByodPlan}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
        createAiQuoteResCollection={[
          {
            mtn: '7165790580',
            contractType: 'DPP',
            intentType: 'EUP',
          },
        ]}
        fetchCartDetailsResult={undefined}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => {
      setTimeout(res, 500);
    });

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      expect(screen.queryByTestId('byod-discount-modal')).not.toBeInTheDocument();
    });
  });

  test('should not show modal when otherPromotions is empty array', async () => {
    const fpsMockWithNewByodPlan = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  existingPlan: {
                    planId: '80001',
                    displayName: 'Current Unlimited BYOD',
                  },
                  selectedPlan: {
                    planId: '80001',
                    displayName: 'New Unlimited BYOD',
                    price: {
                      discountedPrice: 0,
                    },
                  },
                },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseJSON}
        FetchPricingSnapShotResult={fpsMockWithNewByodPlan}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
        createAiQuoteResCollection={[
          {
            mtn: '7165790580',
            contractType: 'DPP',
            intentType: 'EUP',
          },
        ]}
        fetchCartDetailsResult={{
          data: {
            data: {
              cart: {
                lineDetails: {
                  lineInfo: [
                    {
                      mobileNumber: '7165790580',
                      serviceInfo: {
                        otherPromotions: [],
                      },
                    },
                  ],
                },
              },
            },
          },
        }}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => {
      setTimeout(res, 500);
    });

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      expect(screen.queryByTestId('byod-discount-modal')).not.toBeInTheDocument();
    });
  });

  test('should not show modal when promos array is empty', async () => {
    const fpsMockWithNewByodPlan = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  existingPlan: {
                    planId: '80001',
                    displayName: 'Current Unlimited BYOD',
                  },
                  selectedPlan: {
                    planId: '80001',
                    displayName: 'New Unlimited BYOD',
                    price: {
                      discountedPrice: 0,
                    },
                  },
                },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseJSON}
        FetchPricingSnapShotResult={fpsMockWithNewByodPlan}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
        createAiQuoteResCollection={[
          {
            mtn: '7165790580',
            contractType: 'DPP',
            intentType: 'EUP',
          },
        ]}
        fetchCartDetailsResult={{
          data: {
            data: {
              cart: {
                lineDetails: {
                  lineInfo: [
                    {
                      mobileNumber: '7165790580',
                      serviceInfo: {
                        otherPromotions: [
                          {
                            promos: [],
                          },
                        ],
                      },
                    },
                  ],
                },
              },
            },
          },
        }}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => {
      setTimeout(res, 500);
    });

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      expect(screen.queryByTestId('byod-discount-modal')).not.toBeInTheDocument();
    });
  });

  test('should not show modal when matchingCartLine is not found', async () => {
    const fpsMockWithNewByodPlan = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  existingPlan: {
                    planId: '80001',
                    displayName: 'Current Unlimited BYOD',
                  },
                  selectedPlan: {
                    planId: '80001',
                    displayName: 'New Unlimited BYOD',
                    price: {
                      discountedPrice: 0,
                    },
                  },
                },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseJSON}
        FetchPricingSnapShotResult={fpsMockWithNewByodPlan}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
        createAiQuoteResCollection={[
          {
            mtn: '7165790580',
            contractType: 'DPP',
            intentType: 'EUP',
          },
        ]}
        fetchCartDetailsResult={{
          data: {
            data: {
              cart: {
                lineDetails: {
                  lineInfo: [
                    {
                      mobileNumber: 'differentMTN',
                      serviceInfo: {
                        otherPromotions: [
                          {
                            promos: [
                              {
                                id: '21271',
                                discountActionCd: 'END',
                              },
                            ],
                          },
                        ],
                      },
                    },
                  ],
                },
              },
            },
          },
        }}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => {
      setTimeout(res, 500);
    });

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      expect(screen.queryByTestId('byod-discount-modal')).not.toBeInTheDocument();
    });
  });

  test('should handle multiple promos and find the one with END action code', async () => {
    const fpsMockWithNewByodPlan = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  existingPlan: {
                    planId: '80001',
                    displayName: 'Current Unlimited BYOD',
                  },
                  selectedPlan: {
                    planId: '80001',
                    displayName: 'New Unlimited BYOD',
                    price: {
                      discountedPrice: 0,
                    },
                  },
                },
              ],
            },
          ],
        },
      },
    };

    const aiQuoteResponseMultiPromos = {
      data: {
        service: {
          ...aiQuoteResponseJSON.service,
          serviceBody: {
            ...aiQuoteResponseJSON.service.serviceBody,
            serviceRequest: {
              ...aiQuoteResponseJSON.service.serviceBody.serviceRequest,
              customerInfo: {
                ...aiQuoteResponseJSON.service.serviceBody.serviceRequest.customerInfo,
                lineInfo: [
                  {
                    mtn: '7165790580',
                    contractType: 'DPP',
                    intentType: 'EUP',
                  },
                ],
              },
            },
          },
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseMultiPromos}
        FetchPricingSnapShotResult={fpsMockWithNewByodPlan}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
        createAiQuoteResCollection={[
          {
            mtn: '7165790580',
            contractType: 'DPP',
            intentType: 'EUP',
          },
        ]}
        fetchCartDetailsResult={{
          data: {
            data: {
              cart: {
                lineDetails: {
                  lineInfo: [
                    {
                      mobileNumber: '7165790580',
                      serviceInfo: {
                        otherPromotions: [
                          {
                            promos: [
                              {
                                id: '99999',
                                discountActionCd: 'ADD',
                              },
                              {
                                id: '21271',
                                discountActionCd: 'END',
                              },
                            ],
                          },
                        ],
                      },
                    },
                  ],
                },
              },
            },
          },
        }}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => {
      setTimeout(res, 500);
    });

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      expect(screen.getByTestId('byod-discount-modal')).toBeInTheDocument();
      expect(screen.getByText('Confirm Phone Upgrade')).toBeInTheDocument();
    });
  });
});

describe('BYOD+ Discount Modal - onOpenedChange Handler Tests', () => {
  let modalSpy;
  let capturedOnOpenedChange;

  beforeEach(() => {
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({
        byodPlusPlanFFlag: 'TRUE',
        byodPlusEUPSupressFFlag: 'TRUE',
      }),
    );
    GetAppConfig.mockReturnValue({
      messages: {
        dqContent: {
          byodPlanIDs: ['70143', '70144', '63217', '71156', '71157'],
          byodPromo: ["21259", "21271"]
        },
      },
    });

    // Mock Modal component to capture onOpenedChange prop
    modalSpy = jest.spyOn(require('@vds/modals'), 'Modal').mockImplementation(({ children, onOpenedChange, ...props }) => {
      capturedOnOpenedChange = onOpenedChange;
      return (
        <div {...props} data-testid={props['data-testid'] || props.id}>
          {children}
        </div>
      );
    });
  });

  afterEach(() => {
    if (modalSpy) {
      modalSpy.mockRestore();
    }
    jest.clearAllMocks();
    sessionStorage.clear();
  });

  test.skip('should close modal via onOpenedChange when modal is dismissed', async () => {
    const fpsMockWithByodPlan = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  selectedPlan: {
                    planId: '70143',
                    displayName: 'Unlimited BYOD',
                    price: {
                      discountedPrice: 0,
                    },
                  },
                  existingPlan: {
                    planId: '63217',
                    displayName: 'Unlimited Plus',
                    price: {
                      discountedPrice: 0,
                    },
                  },
                },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseJSON}
        FetchPricingSnapShotResult={fpsMockWithByodPlan}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => setTimeout(res, 500));

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      expect(screen.getByTestId('byod-discount-modal')).toBeInTheDocument();
    });

    // Simulate modal closing via onOpenedChange (ESC key, backdrop click, etc.)
    expect(capturedOnOpenedChange).toBeDefined();
    
    // Trigger the onOpenedChange callback with opened=false
    await act(async () => {
      capturedOnOpenedChange(false);
    });

    await waitFor(() => {
      expect(screen.queryByTestId('byod-discount-modal')).not.toBeInTheDocument();
    });
  });

  test.skip('should cover onOpenedChange when opened is true', async () => {
    const fpsMockWithByodPlan = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  selectedPlan: {
                    planId: '70143',
                    displayName: 'Unlimited BYOD',
                    price: {
                      discountedPrice: 0,
                    },
                  },
                },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        aiquoteResponse={aiQuoteResponseJSON}
        FetchPricingSnapShotResult={fpsMockWithByodPlan}
        setFPSProtectionData={jest.fn()}
        setTaggingPayload={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        newLinesWithoutQuote={[]}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => setTimeout(res, 500));

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      expect(screen.getByTestId('byod-discount-modal')).toBeInTheDocument();
    });

    // Test onOpenedChange with opened=true (should not close modal)
    expect(capturedOnOpenedChange).toBeDefined();
    
    await act(async () => {
      capturedOnOpenedChange(true);
    });

    // Modal should still be in document
    expect(screen.getByTestId('byod-discount-modal')).toBeInTheDocument();
  });
});

describe('Footer - getCartLines function', () => {
  test('should return cart lines with lineActivityType', async () => {
    const mockFPS = {
      data: {
        data: {
          subAccounts: [
            {
              lineInfo: [
                { mobileNumber: '7165790580', lineActivityType: 'AAL_5G' },
                { mobileNumber: '7164753195', lineActivityType: 'EUP' },
              ],
              lines: [
                { mtn: '7165790580', selectedPlan: { planId: '63217' } },
                { mtn: '7164753195', selectedPlan: { planId: '70143' } },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={mockFPS}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        aiquoteResponse={aiQuoteResponseJSON}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => setTimeout(res, 500));

    const footerComponent = await screen.findByTestId('footercomponent');
    expect(footerComponent).toBeInTheDocument();
  });

  test('should handle empty lineInfo gracefully', async () => {
    const mockFPS = {
      data: {
        data: {
          subAccounts: [
            {
              lineInfo: [],
              lines: [],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={mockFPS}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        aiquoteResponse={aiQuoteResponseJSON}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => setTimeout(res, 500));

    const footerComponent = await screen.findByTestId('footercomponent');
    expect(footerComponent).toBeInTheDocument();
  });

  test('should handle missing mtn in lines array', async () => {
    const mockFPS = {
      data: {
        data: {
          subAccounts: [
            {
              lineInfo: [
                { mobileNumber: '7165790580', lineActivityType: 'AAL_5G' },
              ],
              lines: [
                { mtn: '7164753195', selectedPlan: { planId: '70143' } },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={mockFPS}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        aiquoteResponse={aiQuoteResponseJSON}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => setTimeout(res, 500));

    const footerComponent = await screen.findByTestId('footercomponent');
    expect(footerComponent).toBeInTheDocument();
  });
});

describe('Footer - checkForEUPLinesWithDeclineProtection function', () => {
  const handlers = [
    rest.post(`*fetchPricingSnapshot`, (req, res, ctx) => res(ctx.status(200), ctx.json(FetchPricingSnapshot))),
  ];
  const server = setupServer(...handlers);
  beforeAll(() => server.listen());
  afterEach(() => server.resetHandlers());
  afterAll(() => server.close());

  test('should trigger VMP warning modal when EUP line has decline protection', async () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ aiQuoteVMPFFlag: 'TRUE' }));
    const setShowVMPWarningModalMock = jest.fn();
    
    const mockFPS = {
      data: {
        data: {
          subAccounts: [
            {
              lineInfo: [
                { mobileNumber: '7165790580', lineActivityType: 'EUP' },
              ],
              lines: [
                {
                  mtn: '7165790580',
                  lineActivityType: 'EUP',
                  addons: [
                    {
                      actionIndicator: 'Z',
                      skuName: 'Decline Device Protection',
                      protection: true,
                    },
                  ],
                },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={mockFPS}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        setShowVMPWarningModal={setShowVMPWarningModalMock}
        proceedQuoteWithDeclineProtection={false}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => setTimeout(res, 500));

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      expect(setShowVMPWarningModalMock).toHaveBeenCalledWith(true);
    });
  });

  test('should not trigger VMP warning when proceedQuoteWithDeclineProtection is true', async () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ aiQuoteVMPFFlag: 'TRUE' }));
    const setShowVMPWarningModalMock = jest.fn();
    
    const mockFPS = {
      data: {
        data: {
          subAccounts: [
            {
              lineInfo: [
                { mobileNumber: '7165790580', lineActivityType: 'EUP' },
              ],
              lines: [
                {
                  mtn: '7165790580',
                  lineActivityType: 'EUP',
                  addons: [
                    {
                      actionIndicator: 'Z',
                      skuName: 'DECLINE DEVICE PROTECTION',
                      protection: true,
                    },
                  ],
                },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={mockFPS}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        setShowVMPWarningModal={setShowVMPWarningModalMock}
        proceedQuoteWithDeclineProtection={true}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => setTimeout(res, 500));

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      expect(setShowVMPWarningModalMock).not.toHaveBeenCalled();
    });
  });

  test('should not trigger VMP warning when aiQuoteVMPFFlag is false', async () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ aiQuoteVMPFFlag: 'FALSE' }));
    const setShowVMPWarningModalMock = jest.fn();
    
    const mockFPS = {
      data: {
        data: {
          subAccounts: [
            {
              lineInfo: [
                { mobileNumber: '7165790580', lineActivityType: 'EUP' },
              ],
              lines: [
                {
                  mtn: '7165790580',
                  lineActivityType: 'EUP',
                  addons: [
                    {
                      actionIndicator: 'Z',
                      skuName: 'Decline Device Protection',
                      protection: true,
                    },
                  ],
                },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={mockFPS}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        setShowVMPWarningModal={setShowVMPWarningModalMock}
        proceedQuoteWithDeclineProtection={false}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => setTimeout(res, 500));

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      expect(setShowVMPWarningModalMock).not.toHaveBeenCalled();
    });
  });

  test('should not trigger VMP warning for non-EUP lines', async () => {
    sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({ aiQuoteVMPFFlag: 'TRUE' }));
    const setShowVMPWarningModalMock = jest.fn();
    
    const mockFPS = {
      data: {
        data: {
          subAccounts: [
            {
              lineInfo: [
                { mobileNumber: '7165790580', lineActivityType: 'AAL_5G' },
              ],
              lines: [
                {
                  mtn: '7165790580',
                  lineActivityType: 'AAL_5G',
                  addons: [
                    {
                      actionIndicator: 'Z',
                      skuName: 'Decline Device Protection',
                      protection: true,
                    },
                  ],
                },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={mockFPS}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        setShowVMPWarningModal={setShowVMPWarningModalMock}
        proceedQuoteWithDeclineProtection={false}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => setTimeout(res, 500));

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      expect(setShowVMPWarningModalMock).not.toHaveBeenCalled();
    });
  });
});

describe('Footer - setProductIdFromDepletion function', () => {
  test('should set productId when depletion type is O (owned)', async () => {
    const qualifiedAddressVHI = {
      cbandBundle: [
        { type: 'p', id: '2000021' },
        { type: 's', id: '2000022' },
      ],
    };

    const fetchCartDetailsResult = {
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [
                {
                  lineActivityType: 'AAL_5G',
                  itemsInfo: [
                    {
                      depletionType: 'O',
                      cartItems: {
                        cartItem: [{ cartItemType: 'DEVICE' }],
                      },
                    },
                  ],
                },
              ],
            },
          },
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={FetchPricingSnapshot}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        qualifiedAddressVHI={qualifiedAddressVHI}
        fetchCartDetailsResult={fetchCartDetailsResult}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => setTimeout(res, 500));

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      const storedProductId = sessionStorage.getItem('productIdFromPS');
      expect(storedProductId).toBe('2000021');
    });
  });

  test('should set productId when depletion type is not O (subsidized)', async () => {
    const qualifiedAddressVHI = {
      cbandBundle: [
        { type: 'p', id: '2000021' },
        { type: 's', id: '2000022' },
      ],
    };

    const fetchCartDetailsResult = {
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [
                {
                  lineActivityType: 'NSE_5G',
                  itemsInfo: [
                    {
                      depletionType: 'S',
                      cartItems: {
                        cartItem: [{ cartItemType: 'DEVICE' }],
                      },
                    },
                  ],
                },
              ],
            },
          },
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={FetchPricingSnapshot}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        qualifiedAddressVHI={qualifiedAddressVHI}
        fetchCartDetailsResult={fetchCartDetailsResult}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => setTimeout(res, 500));

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      const storedProductId = sessionStorage.getItem('productIdFromPS');
      expect(storedProductId).toBe('2000022');
    });
  });

  test('should not set productId when qualifiedAddressVHI is not provided', async () => {
    const fetchCartDetailsResult = {
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [
                {
                  lineActivityType: 'AAL_5G',
                  itemsInfo: [
                    {
                      depletionType: 'O',
                      cartItems: {
                        cartItem: [{ cartItemType: 'DEVICE' }],
                      },
                    },
                  ],
                },
              ],
            },
          },
        },
      },
    };

    sessionStorage.removeItem('productIdFromPS');

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={FetchPricingSnapshot}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        fetchCartDetailsResult={fetchCartDetailsResult}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await new Promise((res) => setTimeout(res, 500));

    const proceedButton = await screen.findByTestId('footercomponentButton');
    fireEvent.click(proceedButton);

    await waitFor(() => {
      const storedProductId = sessionStorage.getItem('productIdFromPS');
      expect(storedProductId).toBeNull();
    });
  });
});

describe('hasUpgradedIncompatibleByodDevice - Null Checks', () => {
  const byodPlanIDs = ['BYOD123', 'BYOD456'];
  
  beforeEach(() => {
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({
        byodPlusPlanFFlag: 'TRUE',
        byodPlusEUPSupressFFlag: 'TRUE',
      }),
    );
    GetAppConfig.mockReturnValue({
      messages: {
        dqContent: {
          byodPlanIDs: ['BYOD123', 'BYOD456'],
        },
      },
      urls: {
        fetchPricingSnapshot: '/test/fetchPricingSnapshot',
      },
    });
  });

  test('should handle null FetchPricingSnapShotResult', () => {
    const { container } = render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={null}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        fetchCartDetailsResult={{}}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    expect(container).toBeTruthy();
  });

  test('should handle undefined lines array', () => {
    const FetchPricingSnapShotResult = {
      data: {
        data: {
          subAccounts: [
            {
              lines: undefined,
            },
          ],
        },
      },
    };

    const { container } = render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={FetchPricingSnapShotResult}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        fetchCartDetailsResult={{}}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    expect(container).toBeTruthy();
  });

  test('should handle null line object in lines array', () => {
    const FetchPricingSnapShotResult = {
      data: {
        data: {
          subAccounts: [
            {
              lines: [
                {
                  mtn: '1234567890',
                  selectedPlan: null,
                  existingPlan: null,
                },
              ],
            },
          ],
        },
      },
    };

    const { container } = render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={FetchPricingSnapShotResult}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        fetchCartDetailsResult={{}}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    expect(container).toBeTruthy();
  });

  test('should handle line with null existingDevice', () => {
    const FetchPricingSnapShotResult = {
      data: {
        data: {
          subAccounts: [
            {
              lines: [
                {
                  existingDevice: null,
                  selectedDevice: { sorId: 'NEW123' },
                  existingPlan: { planId: 'BYOD123', price: { discountedPrice: 0 } },
                  mtn: '1234567890',
                },
              ],
            },
          ],
        },
      },
    };

    const { container } = render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={FetchPricingSnapShotResult}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        fetchCartDetailsResult={{}}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    expect(container).toBeTruthy();
  });

  test('should handle line with null selectedDevice', () => {
    const FetchPricingSnapShotResult = {
      data: {
        data: {
          subAccounts: [
            {
              lines: [
                {
                  existingDevice: { sorId: 'OLD123' },
                  selectedDevice: null,
                  existingPlan: { planId: 'BYOD123', price: { discountedPrice: 0 } },
                  mtn: '1234567890',
                },
              ],
            },
          ],
        },
      },
    };

    const { container } = render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={FetchPricingSnapShotResult}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        fetchCartDetailsResult={{}}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    expect(container).toBeTruthy();
  });

  test('should handle line with null existingPlan', () => {
    const FetchPricingSnapShotResult = {
      data: {
        data: {
          subAccounts: [
            {
              lines: [
                {
                  existingDevice: { sorId: 'OLD123' },
                  selectedDevice: { sorId: 'NEW123' },
                  existingPlan: null,
                  mtn: '1234567890',
                },
              ],
            },
          ],
        },
      },
    };

    const { container } = render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={FetchPricingSnapShotResult}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        fetchCartDetailsResult={{}}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    expect(container).toBeTruthy();
  });

  test('should handle null fetchCartDetailsResult', () => {
    const FetchPricingSnapShotResult = {
      data: {
        data: {
          subAccounts: [
            {
              lines: [
                {
                  existingDevice: { sorId: 'OLD123' },
                  selectedDevice: { sorId: 'NEW123' },
                  existingPlan: { planId: 'BYOD123', price: { discountedPrice: 0 } },
                  mtn: '1234567890',
                },
              ],
            },
          ],
        },
      },
    };

    const { container } = render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={FetchPricingSnapShotResult}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        fetchCartDetailsResult={null}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    expect(container).toBeTruthy();
  });

  test('should handle undefined lineInfo in fetchCartDetailsResult', () => {
    const FetchPricingSnapShotResult = {
      data: {
        data: {
          subAccounts: [
            {
              lines: [
                {
                  existingDevice: { sorId: 'OLD123' },
                  selectedDevice: { sorId: 'NEW123' },
                  existingPlan: { planId: 'BYOD123', price: { discountedPrice: 0 } },
                  mtn: '1234567890',
                },
              ],
            },
          ],
        },
      },
    };

    const fetchCartDetailsResult = {
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: undefined,
            },
          },
        },
      },
    };

    const { container } = render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={FetchPricingSnapShotResult}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        fetchCartDetailsResult={fetchCartDetailsResult}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    expect(container).toBeTruthy();
  });

  test('should handle null item in lineInfo find operation', () => {
    const FetchPricingSnapShotResult = {
      data: {
        data: {
          subAccounts: [
            {
              lines: [
                {
                  existingDevice: { sorId: 'OLD123' },
                  selectedDevice: { sorId: 'NEW123' },
                  existingPlan: { planId: 'BYOD123', price: { discountedPrice: 0 } },
                  mtn: '1234567890',
                },
              ],
            },
          ],
        },
      },
    };

    const fetchCartDetailsResult = {
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [null, undefined, { mobileNumber: '9999999999' }],
            },
          },
        },
      },
    };

    const { container } = render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={FetchPricingSnapShotResult}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        fetchCartDetailsResult={fetchCartDetailsResult}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    expect(container).toBeTruthy();
  });

  test('should handle valid BYOD device upgrade with Basic Phone', () => {
    const FetchPricingSnapShotResult = {
      data: {
        data: {
          subAccounts: [
            {
              lines: [
                {
                  existingDevice: { sorId: 'OLD123' },
                  selectedDevice: { sorId: 'NEW123' },
                  existingPlan: { planId: 'BYOD123', price: { discountedPrice: 0 } },
                  mtn: '1234567890',
                },
              ],
            },
          ],
        },
      },
    };

    const fetchCartDetailsResult = {
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [
                {
                  mobileNumber: '1234567890',
                  deviceCategoryName: 'Basic Phones',
                },
              ],
            },
          },
        },
      },
    };

    const { container } = render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={FetchPricingSnapShotResult}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        fetchCartDetailsResult={fetchCartDetailsResult}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    expect(container).toBeTruthy();
  });

  test('should handle valid BYOD device upgrade with Smartphone', () => {
    const FetchPricingSnapShotResult = {
      data: {
        data: {
          subAccounts: [
            {
              lines: [
                {
                  existingDevice: { sorId: 'OLD123' },
                  selectedDevice: { sorId: 'NEW123' },
                  existingPlan: { planId: 'BYOD123', price: { discountedPrice: 0 } },
                  mtn: '1234567890',
                },
              ],
            },
          ],
        },
      },
    };

    const fetchCartDetailsResult = {
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [
                {
                  mobileNumber: '1234567890',
                  deviceCategoryName: 'Smartphones',
                },
              ],
            },
          },
        },
      },
    };

    const { container } = render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={FetchPricingSnapShotResult}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        fetchCartDetailsResult={fetchCartDetailsResult}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    expect(container).toBeTruthy();
  });

  test('should handle device upgrade with non-Basic/Smartphone category', () => {
    const FetchPricingSnapShotResult = {
      data: {
        data: {
          subAccounts: [
            {
              lines: [
                {
                  existingDevice: { sorId: 'OLD123' },
                  selectedDevice: { sorId: 'NEW123' },
                  existingPlan: { planId: 'BYOD123', price: { discountedPrice: 0 } },
                  mtn: '1234567890',
                },
              ],
            },
          ],
        },
      },
    };

    const fetchCartDetailsResult = {
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [
                {
                  mobileNumber: '1234567890',
                  deviceCategoryName: 'Tablets',
                },
              ],
            },
          },
        },
      },
    };

    const { container } = render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={FetchPricingSnapShotResult}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        fetchCartDetailsResult={fetchCartDetailsResult}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    expect(container).toBeTruthy();
  });

  test('should handle missing deviceCategoryName in retrieveCartLine', () => {
    const FetchPricingSnapShotResult = {
      data: {
        data: {
          subAccounts: [
            {
              lines: [
                {
                  existingDevice: { sorId: 'OLD123' },
                  selectedDevice: { sorId: 'NEW123' },
                  existingPlan: { planId: 'BYOD123', price: { discountedPrice: 0 } },
                  mtn: '1234567890',
                },
              ],
            },
          ],
        },
      },
    };

    const fetchCartDetailsResult = {
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [
                {
                  mobileNumber: '1234567890',
                },
              ],
            },
          },
        },
      },
    };

    const { container } = render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={FetchPricingSnapShotResult}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        fetchCartDetailsResult={fetchCartDetailsResult}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    expect(container).toBeTruthy();
  });

  test('should handle no matching mobileNumber in lineInfo', () => {
    const FetchPricingSnapShotResult = {
      data: {
        data: {
          subAccounts: [
            {
              lines: [
                {
                  existingDevice: { sorId: 'OLD123' },
                  selectedDevice: { sorId: 'NEW123' },
                  existingPlan: { planId: 'BYOD123', price: { discountedPrice: 0 } },
                  mtn: '1234567890',
                },
              ],
            },
          ],
        },
      },
    };

    const fetchCartDetailsResult = {
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [
                {
                  mobileNumber: '9999999999',
                  deviceCategoryName: 'Smartphones',
                },
              ],
            },
          },
        },
      },
    };

    const { container } = render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={FetchPricingSnapShotResult}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        fetchCartDetailsResult={fetchCartDetailsResult}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    expect(container).toBeTruthy();
  });

  test('should handle same device sorIds (no device change)', () => {
    const FetchPricingSnapShotResult = {
      data: {
        data: {
          subAccounts: [
            {
              lines: [
                {
                  existingDevice: { sorId: 'SAME123' },
                  selectedDevice: { sorId: 'SAME123' },
                  existingPlan: { planId: 'BYOD123', price: { discountedPrice: 0 } },
                  mtn: '1234567890',
                },
              ],
            },
          ],
        },
      },
    };

    const fetchCartDetailsResult = {
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [
                {
                  mobileNumber: '1234567890',
                  deviceCategoryName: 'Smartphones',
                },
              ],
            },
          },
        },
      },
    };

    const { container } = render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={FetchPricingSnapShotResult}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        fetchCartDetailsResult={fetchCartDetailsResult}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    expect(container).toBeTruthy();
  });

  test('should handle non-zero discounted price', () => {
    const FetchPricingSnapShotResult = {
      data: {
        data: {
          subAccounts: [
            {
              lines: [
                {
                  existingDevice: { sorId: 'OLD123' },
                  selectedDevice: { sorId: 'NEW123' },
                  existingPlan: { planId: 'BYOD123', price: { discountedPrice: 10 } },
                  mtn: '1234567890',
                },
              ],
            },
          ],
        },
      },
    };

    const fetchCartDetailsResult = {
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [
                {
                  mobileNumber: '1234567890',
                  deviceCategoryName: 'Smartphones',
                },
              ],
            },
          },
        },
      },
    };

    const { container } = render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={FetchPricingSnapShotResult}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        fetchCartDetailsResult={fetchCartDetailsResult}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    expect(container).toBeTruthy();
  });
});

describe('hasUpgradedIncompatibleByodDevice - If Condition Coverage', () => {
    test('should handle byodFiveDollarPlanPOSFFlag true value', () => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          byodPlusPlanFFlag: 'TRUE',
          byodPlusEUPSupressFFlag: 'TRUE',
          byodFiveDollarPlanPOSFFlag: 'TRUE',
        })
      );
      GetAppConfig.mockReturnValue({
        messages: {
          dqContent: {
            byodPlanIDs: ['BYOD123'],
          },
        },
        urls: {
          fetchPricingSnapshot: '/test/fetchPricingSnapshot',
        },
      });
      const FetchPricingSnapShotResult = {
        data: {
          data: {
            subAccounts: [
              {
                lines: [
                  {
                    existingDevice: { sorId: 'OLD123' },
                    selectedDevice: { sorId: 'NEW456' },
                    existingPlan: { planId: 'BYOD123', price: { discountedPrice: 0 } },
                    mtn: '1234567890',
                  },
                ],
              },
            ],
          },
        },
      };
      const fetchCartDetailsResult = {
        data: {
          data: {
            cart: {
              lineDetails: {
                lineInfo: [
                  {
                    mobileNumber: '1234567890',
                    deviceCategoryName: 'Basic Phones',
                  },
                ],
              },
            },
          },
        },
      };
      const { container } = render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={jest.fn()}
          FetchPricingSnapShotResult={FetchPricingSnapShotResult}
          setFPSProtectionData={jest.fn()}
          customerBio={customerBio}
          isInDirect={false}
          fetchCartDetailsResult={fetchCartDetailsResult}
        />, {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );
      expect(container).toBeTruthy();
    });
  beforeEach(() => {
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({
        byodPlusPlanFFlag: 'TRUE',
        byodPlusEUPSupressFFlag: 'TRUE',
      }),
    );
    GetAppConfig.mockReturnValue({
      messages: {
        dqContent: {
          byodPlanIDs: ['BYOD123', 'BYOD456'],
        },
      },
      urls: {
        fetchPricingSnapshot: '/test/fetchPricingSnapshot',
      },
    });
  });

  test('should return true when hasDeviceChange and hasByodExistingPlan with Basic Phones', () => {
    const FetchPricingSnapShotResult = {
      data: {
        data: {
          subAccounts: [
            {
              lines: [
                {
                  existingDevice: { sorId: 'OLD123' },
                  selectedDevice: { sorId: 'NEW456' },
                  existingPlan: { planId: 'BYOD123', price: { discountedPrice: 0 } },
                  mtn: '1234567890',
                },
              ],
            },
          ],
        },
      },
    };

    const fetchCartDetailsResult = {
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [
                {
                  mobileNumber: '1234567890',
                  deviceCategoryName: 'Basic Phones',
                },
              ],
            },
          },
        },
      },
    };

    const { container } = render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={FetchPricingSnapShotResult}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        fetchCartDetailsResult={fetchCartDetailsResult}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    expect(container).toBeTruthy();
  });

  test('should return true when hasDeviceChange and hasByodExistingPlan with Smartphones', () => {
    const FetchPricingSnapShotResult = {
      data: {
        data: {
          subAccounts: [
            {
              lines: [
                {
                  existingDevice: { sorId: 'OLD123' },
                  selectedDevice: { sorId: 'NEW456' },
                  existingPlan: { planId: 'BYOD456', price: { discountedPrice: 0 } },
                  mtn: '9876543210',
                },
              ],
            },
          ],
        },
      },
    };

    const fetchCartDetailsResult = {
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [
                {
                  mobileNumber: '9876543210',
                  deviceCategoryName: 'Smartphones',
                },
              ],
            },
          },
        },
      },
    };

    const { container } = render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={FetchPricingSnapShotResult}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        fetchCartDetailsResult={fetchCartDetailsResult}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    expect(container).toBeTruthy();
  });

  test('should return false when hasDeviceChange and hasByodExistingPlan but device is Tablet', () => {
    const FetchPricingSnapShotResult = {
      data: {
        data: {
          subAccounts: [
            {
              lines: [
                {
                  existingDevice: { sorId: 'OLD123' },
                  selectedDevice: { sorId: 'NEW789' },
                  existingPlan: { planId: 'BYOD123', price: { discountedPrice: 0 } },
                  mtn: '5555555555',
                },
              ],
            },
          ],
        },
      },
    };

    const fetchCartDetailsResult = {
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [
                {
                  mobileNumber: '5555555555',
                  deviceCategoryName: 'Tablets',
                },
              ],
            },
          },
        },
      },
    };

    const { container } = render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={FetchPricingSnapShotResult}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        fetchCartDetailsResult={fetchCartDetailsResult}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    expect(container).toBeTruthy();
  });

  test('should return false when hasDeviceChange and hasByodExistingPlan but retrieveCartLine not found', () => {
    const FetchPricingSnapShotResult = {
      data: {
        data: {
          subAccounts: [
            {
              lines: [
                {
                  existingDevice: { sorId: 'OLD123' },
                  selectedDevice: { sorId: 'NEW999' },
                  existingPlan: { planId: 'BYOD123', price: { discountedPrice: 0 } },
                  mtn: '1111111111',
                },
              ],
            },
          ],
        },
      },
    };

    const fetchCartDetailsResult = {
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [
                {
                  mobileNumber: '2222222222',
                  deviceCategoryName: 'Smartphones',
                },
              ],
            },
          },
        },
      },
    };

    const { container } = render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={FetchPricingSnapShotResult}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        fetchCartDetailsResult={fetchCartDetailsResult}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    expect(container).toBeTruthy();
  });

  test('should return false when hasDeviceChange and hasByodExistingPlan but deviceCategoryName is undefined', () => {
    const FetchPricingSnapShotResult = {
      data: {
        data: {
          subAccounts: [
            {
              lines: [
                {
                  existingDevice: { sorId: 'OLD123' },
                  selectedDevice: { sorId: 'NEW888' },
                  existingPlan: { planId: 'BYOD456', price: { discountedPrice: 0 } },
                  mtn: '3333333333',
                },
              ],
            },
          ],
        },
      },
    };

    const fetchCartDetailsResult = {
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [
                {
                  mobileNumber: '3333333333',
                  // deviceCategoryName is intentionally missing
                },
              ],
            },
          },
        },
      },
    };

    const { container } = render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={FetchPricingSnapShotResult}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        fetchCartDetailsResult={fetchCartDetailsResult}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    expect(container).toBeTruthy();
  });

  test('should handle multiple lines with mixed conditions', () => {
    const FetchPricingSnapShotResult = {
      data: {
        data: {
          subAccounts: [
            {
              lines: [
                {
                  existingDevice: { sorId: 'OLD111' },
                  selectedDevice: { sorId: 'NEW111' },
                  existingPlan: { planId: 'BYOD123', price: { discountedPrice: 0 } },
                  mtn: '4444444444',
                },
                {
                  existingDevice: { sorId: 'OLD222' },
                  selectedDevice: { sorId: 'NEW222' },
                  existingPlan: { planId: 'BYOD456', price: { discountedPrice: 0 } },
                  mtn: '5555555555',
                },
              ],
            },
          ],
        },
      },
    };

    const fetchCartDetailsResult = {
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [
                {
                  mobileNumber: '4444444444',
                  deviceCategoryName: 'Basic Phones',
                },
                {
                  mobileNumber: '5555555555',
                  deviceCategoryName: 'Tablets',
                },
              ],
            },
          },
        },
      },
    };

    const { container } = render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={FetchPricingSnapShotResult}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        fetchCartDetailsResult={fetchCartDetailsResult}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );
    expect(container).toBeTruthy();
  });
});

describe('CCD Modal and BYOD Flow Integration Tests', () => {
  const byodPlanIDs = ['63217', '70143', '70144', '71156', '71157'];
  
  beforeEach(() => {
    GetAppConfig.mockReturnValue({
      messages: {
        dqContent: {
          byodPlanIDs,
          byodPromo: ["21259", "21271"]
        },
      },
    });
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({
        byodPlusPlanFFlag: 'TRUE',
        byodPlusEUPSupressFFlag: 'TRUE',
        byodFiveDollarPlanPOSFFlag: 'TRUE'
      }),
    );
    mockRetrieveAEMInfoManagerData.mockReset();
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  test('CcdAemInfoApi should be triggered when hasByodSelected is true - with data', async () => {
    mockRetrieveAEMInfoManagerData.mockResolvedValue({
      data: {
        content: [{ title: 'Test', content: '<p>Test</p>' }],
      },
    });

    const fpsMock = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          ...FetchPricingSnapshot.data.data,
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  selectedPlan: {
                    planId: '63217',
                    displayName: 'BYOD Plan',
                    price: {
                      discountedPrice: 0,
                    },
                    planDetails: {
                      planPromotions: {
                        promos: [{
                          id: '21259',
                        }]
                      }
                    }
                  },
                },
              ],
            },
          ],
        },
      },
    };
    const cartRespMock = {
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: [{
                mobileNumber: '7165790580',
                serviceInfo: {
                  otherPromotions: [{
                    promos: [{
                      id: '21259',
                    }]
                  }]
                }
              }]
            }
          }
        }
      }
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={fpsMock}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        aiquoteResponse={aiQuoteResponseJSON}
        fetchCartDetailsResult={cartRespMock}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await act(async () => {
      await new Promise((res) => setTimeout(res, 100));
    });

    const proceedButton = await screen.findByTestId('footercomponentButton');
    await act(async () => {
      fireEvent.click(proceedButton);
      await new Promise((res) => setTimeout(res, 100));
    });

    expect(mockRetrieveAEMInfoManagerData).toHaveBeenCalled();

    // Wait for CCD modal to appear and click the proceed button
    const ccdModalButton = await screen.findByTestId('CcdModalBtn');
    expect(ccdModalButton).toBeInTheDocument();
    
    await act(async () => {
      fireEvent.click(ccdModalButton);
      await new Promise((res) => setTimeout(res, 100));
    });
  });

  test('CcdAemInfoApi should be triggered when hasByodSelected is true - without data', async () => {
    mockRetrieveAEMInfoManagerData.mockResolvedValue({
      data: null,
    });

    const fpsMock = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          ...FetchPricingSnapshot.data.data,
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  selectedPlan: {
                    planId: '63217',
                    displayName: 'BYOD Plan',
                    price: {
                      discountedPrice: 0,
                    },
                    planDetails: {
                      planPromotions: {
                        promos: [{
                          id: '21259',
                        }]
                      }
                    }
                  },
                },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={fpsMock}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        aiquoteResponse={aiQuoteResponseJSON}
        fetchCartDetailsResult={{}}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await act(async () => {
      await new Promise((res) => setTimeout(res, 100));
    });

    const proceedButton = await screen.findByTestId('footercomponentButton');
    await act(async () => {
      fireEvent.click(proceedButton);
      await new Promise((res) => setTimeout(res, 100));
    });

    expect(mockRetrieveAEMInfoManagerData).toHaveBeenCalled();
  });

  test('closeCcdModal should close the CCD modal when close button is clicked', async () => {
    mockRetrieveAEMInfoManagerData.mockResolvedValue({
      data: {
        content: [{ title: 'Test', content: '<p>Test</p>' }],
      },
    });

    const fpsMock = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          ...FetchPricingSnapshot.data.data,
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  selectedPlan: {
                    planId: '63217',
                    displayName: 'BYOD Plan',
                    price: {
                      discountedPrice: 0,
                    },
                    planDetails: {
                      planPromotions: {
                        promos: [{
                          id: '21259',
                        }]
                      }
                    }
                  },
                },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={fpsMock}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        aiquoteResponse={aiQuoteResponseJSON}
        fetchCartDetailsResult={{}}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await act(async () => {
      await new Promise((res) => setTimeout(res, 100));
    });

    const proceedButton = await screen.findByTestId('footercomponentButton');
    await act(async () => {
      fireEvent.click(proceedButton);
      await new Promise((res) => setTimeout(res, 100));
    });
    expect(mockRetrieveAEMInfoManagerData).toHaveBeenCalled();
  });

  test('CcdAemInfoApi should handle error in catch block', async () => {
    const consoleLogSpy = jest.spyOn(console, 'log').mockImplementation();
    mockRetrieveAEMInfoManagerData.mockRejectedValue(new Error('API Error'));

    const fpsMock = {
      ...FetchPricingSnapshot,
      data: {
        ...FetchPricingSnapshot.data,
        data: {
          ...FetchPricingSnapshot.data.data,
          subAccounts: [
            {
              lines: [
                {
                  mtn: '7165790580',
                  selectedPlan: {
                    planId: '63217',
                    displayName: 'BYOD Plan',
                    price: {
                      discountedPrice: 0,
                    },
                    planDetails: {
                      planPromotions: {
                        promos: [{
                          id: '21259',
                        }]
                      }
                    }
                  },
                },
              ],
            },
          ],
        },
      },
    };

    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={jest.fn()}
        FetchPricingSnapShotResult={fpsMock}
        setFPSProtectionData={jest.fn()}
        customerBio={customerBio}
        isInDirect={false}
        aiquoteResponse={aiQuoteResponseJSON}
        fetchCartDetailsResult={{}}
      />,
      {
        reducers: rootReducer,
        sagas: rootSaga,
      },
    );

    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await act(async () => {
      await new Promise((res) => setTimeout(res, 100));
    });

    const proceedButton = await screen.findByTestId('footercomponentButton');
    await act(async () => {
      fireEvent.click(proceedButton);
      await new Promise((res) => setTimeout(res, 100));
    });

    await waitFor(() => {
      expect(consoleLogSpy).toHaveBeenCalledWith(
        expect.stringContaining('error while fetching retrieveAEMInfoManagerData')
      );
    });

    consoleLogSpy.mockRestore();
  });
});

describe('CCD Modal and BYOD Flow Integration Tests WHEN byodFiveDollarPlanPOSFFlag is FALSE', () => {
    test('should show CCD modal and NOT BYOD+ Discount modal when byodFiveDollarPlanPOSFFlag is FALSE and byodZeroDollarPlan applies', async () => {
      mockRetrieveAEMInfoManagerData.mockResolvedValue({
        data: {
          content: [{ title: 'Test', content: '<p>Test</p>' }],
        },
      });

      const fpsMock = {
        ...FetchPricingSnapshot,
        data: {
          ...FetchPricingSnapshot.data,
          data: {
            ...FetchPricingSnapshot.data.data,
            subAccounts: [
              {
                lines: [
                  {
                    mtn: '7165790580',
                    selectedPlan: {
                      planId: '63217',
                      displayName: 'BYOD Plan',
                      price: {
                        discountedPrice: 0,
                      },
                      planDetails: {
                        planPromotions: {
                          promos: [{ id: '21259' }],
                        },
                      },
                    },
                    existingPlan: {
                      planId: '63217',
                      displayName: 'BYOD Plan',
                      price: {
                        discountedPrice: 0,
                      },
                    },
                  },
                ],
              },
            ],
          },
        },
      };
      const cartRespMock = {
        data: {
          data: {
            cart: {
              lineDetails: {
                lineInfo: [{
                  mobileNumber: '7165790580',
                  serviceInfo: {
                    otherPromotions: [{}],
                  },
                }],
              },
            },
          },
        },
      };

      render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={jest.fn()}
          FetchPricingSnapShotResult={fpsMock}
          setFPSProtectionData={jest.fn()}
          customerBio={customerBio}
          isInDirect={false}
          aiquoteResponse={aiQuoteResponseJSON}
          fetchCartDetailsResult={cartRespMock}
        />, {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );

      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await act(async () => {
        await new Promise((res) => setTimeout(res, 100));
      });

      const proceedButton = await screen.findByTestId('footercomponentButton');
      await act(async () => {
        fireEvent.click(proceedButton);
        await new Promise((res) => setTimeout(res, 100));
      });

      expect(mockRetrieveAEMInfoManagerData).toHaveBeenCalled();
      expect(screen.queryByTestId('byod-discount-modal')).not.toBeInTheDocument();
      const ccdModalButton = await screen.findByTestId('CcdModalBtn');
      expect(ccdModalButton).toBeInTheDocument();
    });
  const byodPlanIDs = ['63217', '70143', '70144', '71156', '71157'];
  
  beforeEach(() => {
    GetAppConfig.mockReturnValue({
      messages: {
        dqContent: {
          byodPlanIDs,
          byodPromo: ["21259", "21271"]
        },
      },
    });
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({
        byodPlusPlanFFlag: 'TRUE',
        byodPlusEUPSupressFFlag: 'TRUE',
        byodFiveDollarPlanPOSFFlag: 'FALSE'
      }),
    );
    mockRetrieveAEMInfoManagerData.mockReset();
  });

  afterEach(() => {
    jest.clearAllMocks();
  });
});

// --- New Tests for checkByodPlanMatch and checkByodPromoFromRetrieveCart ---
describe('checkByodPlanMatch and checkByodPromoFromRetrieveCart Tests', () => {
  const byodPlanIDs = ['63217', '70143', '70144', '71156', '71157'];
  const byodPromo = ['21259', '21271'];

  beforeEach(() => {
    GetAppConfig.mockReturnValue({
      messages: {
        dqContent: {
          byodPlanIDs,
          byodPromo,
        },
      },
    });
  });

  afterEach(() => {
    jest.clearAllMocks();
    sessionStorage.clear();
  });

  describe('checkByodPlanMatch with byodFiveDollarPlanPOSFFlag TRUE', () => {
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          byodPlusPlanFFlag: 'TRUE',
          byodFiveDollarPlanPOSFFlag: 'TRUE',
        }),
      );
    });

    test('should return true when planId matches and promo exists in planPromotions', async () => {
      const fpsMock = {
        ...FetchPricingSnapshot,
        data: {
          ...FetchPricingSnapshot.data,
          data: {
            ...FetchPricingSnapshot.data.data,
            subAccounts: [
              {
                lines: [
                  {
                    mtn: '7165790580',
                    selectedPlan: {
                      planId: '63217',
                      displayName: 'BYOD Plan',
                      price: {
                        discountedPrice: 5.0,
                      },
                      planDetails: {
                        planPromotions: {
                          promos: [{ id: '21259' }],
                        },
                      },
                    },
                  },
                ],
              },
            ],
          },
        },
      };

      const { container } = render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={jest.fn()}
          FetchPricingSnapShotResult={fpsMock}
          setFPSProtectionData={jest.fn()}
          customerBio={customerBio}
          isInDirect={false}
          aiquoteResponse={aiQuoteResponseJSON}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );

      expect(container).toBeTruthy();
    });

    test('should return true when planId matches and promo exists in addons', async () => {
      const fpsMock = {
        ...FetchPricingSnapshot,
        data: {
          ...FetchPricingSnapshot.data,
          data: {
            ...FetchPricingSnapshot.data.data,
            subAccounts: [
              {
                lines: [
                  {
                    mtn: '7165790580',
                    selectedPlan: {
                      planId: '63217',
                      displayName: 'BYOD Plan',
                      price: {
                        discountedPrice: 5.0,
                      },
                    },
                    addons: [
                      {
                        sorId: '21271',
                        skuName: 'BYOD Promo',
                      },
                    ],
                  },
                ],
              },
            ],
          },
        },
      };

      const { container } = render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={jest.fn()}
          FetchPricingSnapShotResult={fpsMock}
          setFPSProtectionData={jest.fn()}
          customerBio={customerBio}
          isInDirect={false}
          aiquoteResponse={aiQuoteResponseJSON}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );

      expect(container).toBeTruthy();
    });

    test('should return false when planId matches but no promo exists', async () => {
      const fpsMock = {
        ...FetchPricingSnapshot,
        data: {
          ...FetchPricingSnapshot.data,
          data: {
            ...FetchPricingSnapshot.data.data,
            subAccounts: [
              {
                lines: [
                  {
                    mtn: '7165790580',
                    selectedPlan: {
                      planId: '63217',
                      displayName: 'BYOD Plan',
                      price: {
                        discountedPrice: 5.0,
                      },
                    },
                  },
                ],
              },
            ],
          },
        },
      };

      const { container } = render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={jest.fn()}
          FetchPricingSnapShotResult={fpsMock}
          setFPSProtectionData={jest.fn()}
          customerBio={customerBio}
          isInDirect={false}
          aiquoteResponse={aiQuoteResponseJSON}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );

      expect(container).toBeTruthy();
    });
  });

  describe('checkByodPlanMatch with byodFiveDollarPlanPOSFFlag FALSE', () => {
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          byodPlusPlanFFlag: 'TRUE',
          byodFiveDollarPlanPOSFFlag: 'FALSE',
        }),
      );
    });

    test('should return true when planId matches and discountedPrice is 0', async () => {
      const fpsMock = {
        ...FetchPricingSnapshot,
        data: {
          ...FetchPricingSnapshot.data,
          data: {
            ...FetchPricingSnapshot.data.data,
            subAccounts: [
              {
                lines: [
                  {
                    mtn: '7165790580',
                    selectedPlan: {
                      planId: '63217',
                      displayName: 'BYOD Plan',
                      price: {
                        discountedPrice: 0,
                      },
                    },
                  },
                ],
              },
            ],
          },
        },
      };

      const { container } = render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={jest.fn()}
          FetchPricingSnapShotResult={fpsMock}
          setFPSProtectionData={jest.fn()}
          customerBio={customerBio}
          isInDirect={false}
          aiquoteResponse={aiQuoteResponseJSON}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );

      expect(container).toBeTruthy();
    });

    test('should return false when planId matches but discountedPrice is not 0', async () => {
      const fpsMock = {
        ...FetchPricingSnapshot,
        data: {
          ...FetchPricingSnapshot.data,
          data: {
            ...FetchPricingSnapshot.data.data,
            subAccounts: [
              {
                lines: [
                  {
                    mtn: '7165790580',
                    selectedPlan: {
                      planId: '63217',
                      displayName: 'BYOD Plan',
                      price: {
                        discountedPrice: 5.0,
                      },
                    },
                  },
                ],
              },
            ],
          },
        },
      };

      const { container } = render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={jest.fn()}
          FetchPricingSnapShotResult={fpsMock}
          setFPSProtectionData={jest.fn()}
          customerBio={customerBio}
          isInDirect={false}
          aiquoteResponse={aiQuoteResponseJSON}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );

      expect(container).toBeTruthy();
    });
  });

  describe('checkByodPromoFromRetrieveCart function', () => {
    beforeEach(() => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          byodPlusPlanFFlag: 'TRUE',
          byodFiveDollarPlanPOSFFlag: 'TRUE',
        }),
      );
    });

    test('should return true when byod promo exists in retrieveCart response', async () => {
      const fpsMock = {
        ...FetchPricingSnapshot,
        data: {
          ...FetchPricingSnapshot.data,
          data: {
            ...FetchPricingSnapshot.data.data,
            subAccounts: [
              {
                lines: [
                  {
                    mtn: '7165790580',
                    existingPlan: {
                      planId: '63217',
                      displayName: 'BYOD Plan',
                      price: {
                        discountedPrice: 0,
                      },
                    },
                    selectedPlan: {
                      planId: '70143',
                      displayName: 'New Plan',
                    },
                  },
                ],
              },
            ],
          },
        },
      };

      const fetchCartDetailsResult = {
        data: {
          data: {
            cart: {
              lineDetails: {
                lineInfo: [
                  {
                    mobileNumber: '7165790580',
                    serviceInfo: {
                      otherPromotions: [
                        {
                          promos: [
                            {
                              id: '21259',
                            },
                          ],
                        },
                      ],
                    },
                  },
                ],
              },
            },
          },
        },
      };

      const { container } = render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={jest.fn()}
          FetchPricingSnapShotResult={fpsMock}
          setFPSProtectionData={jest.fn()}
          customerBio={customerBio}
          isInDirect={false}
          aiquoteResponse={aiQuoteResponseJSON}
          fetchCartDetailsResult={fetchCartDetailsResult}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );

      expect(container).toBeTruthy();
    });

    test('should return false when byod promo does not exist in retrieveCart response', async () => {
      const fpsMock = {
        ...FetchPricingSnapshot,
        data: {
          ...FetchPricingSnapshot.data,
          data: {
            ...FetchPricingSnapshot.data.data,
            subAccounts: [
              {
                lines: [
                  {
                    mtn: '7165790580',
                    existingPlan: {
                      planId: '63217',
                      displayName: 'BYOD Plan',
                      price: {
                        discountedPrice: 0,
                      },
                    },
                    selectedPlan: {
                      planId: '70143',
                      displayName: 'New Plan',
                    },
                  },
                ],
              },
            ],
          },
        },
      };

      const fetchCartDetailsResult = {
        data: {
          data: {
            cart: {
              lineDetails: {
                lineInfo: [
                  {
                    mobileNumber: '7165790580',
                    serviceInfo: {
                      otherPromotions: [
                        {
                          promos: [
                            {
                              id: 'someOtherPromo',
                            },
                          ],
                        },
                      ],
                    },
                  },
                ],
              },
            },
          },
        },
      };

      const { container } = render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={jest.fn()}
          FetchPricingSnapShotResult={fpsMock}
          setFPSProtectionData={jest.fn()}
          customerBio={customerBio}
          isInDirect={false}
          aiquoteResponse={aiQuoteResponseJSON}
          fetchCartDetailsResult={fetchCartDetailsResult}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );

      expect(container).toBeTruthy();
    });

    test('should return false when otherPromotions is not an array', async () => {
      const fpsMock = {
        ...FetchPricingSnapshot,
        data: {
          ...FetchPricingSnapshot.data,
          data: {
            ...FetchPricingSnapshot.data.data,
            subAccounts: [
              {
                lines: [
                  {
                    mtn: '7165790580',
                    existingPlan: {
                      planId: '63217',
                      displayName: 'BYOD Plan',
                      price: {
                        discountedPrice: 0,
                      },
                    },
                    selectedPlan: {
                      planId: '70143',
                      displayName: 'New Plan',
                    },
                  },
                ],
              },
            ],
          },
        },
      };

      const fetchCartDetailsResult = {
        data: {
          data: {
            cart: {
              lineDetails: {
                lineInfo: [
                  {
                    mobileNumber: '7165790580',
                    serviceInfo: {
                      otherPromotions: 'notAnArray',
                    },
                  },
                ],
              },
            },
          },
        },
      };

      const { container } = render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={jest.fn()}
          FetchPricingSnapShotResult={fpsMock}
          setFPSProtectionData={jest.fn()}
          customerBio={customerBio}
          isInDirect={false}
          aiquoteResponse={aiQuoteResponseJSON}
          fetchCartDetailsResult={fetchCartDetailsResult}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );

      expect(container).toBeTruthy();
    });

    test('should return false when matchingCartLine is not found', async () => {
      const fpsMock = {
        ...FetchPricingSnapshot,
        data: {
          ...FetchPricingSnapshot.data,
          data: {
            ...FetchPricingSnapshot.data.data,
            subAccounts: [
              {
                lines: [
                  {
                    mtn: '7165790580',
                    existingPlan: {
                      planId: '63217',
                      displayName: 'BYOD Plan',
                      price: {
                        discountedPrice: 0,
                      },
                    },
                    selectedPlan: {
                      planId: '70143',
                      displayName: 'New Plan',
                    },
                  },
                ],
              },
            ],
          },
        },
      };

      const fetchCartDetailsResult = {
        data: {
          data: {
            cart: {
              lineDetails: {
                lineInfo: [
                  {
                    mobileNumber: '9999999999',
                    serviceInfo: {
                      otherPromotions: [
                        {
                          promos: [
                            {
                              id: '21259',
                            },
                          ],
                        },
                      ],
                    },
                  },
                ],
              },
            },
          },
        },
      };

      const { container } = render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={jest.fn()}
          FetchPricingSnapShotResult={fpsMock}
          setFPSProtectionData={jest.fn()}
          customerBio={customerBio}
          isInDirect={false}
          aiquoteResponse={aiQuoteResponseJSON}
          fetchCartDetailsResult={fetchCartDetailsResult}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );

      expect(container).toBeTruthy();
    });
  });

  describe('hasByodPlan with checkByodPromoFromRetrieveCart integration', () => {
    test('should return true when byodFiveDollarPlanPOSFFlag is TRUE and promo exists in retrieveCart', async () => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          byodPlusPlanFFlag: 'TRUE',
          byodFiveDollarPlanPOSFFlag: 'TRUE',
        }),
      );

      const fpsMock = {
        ...FetchPricingSnapshot,
        data: {
          ...FetchPricingSnapshot.data,
          data: {
            ...FetchPricingSnapshot.data.data,
            subAccounts: [
              {
                lines: [
                  {
                    mtn: '7165790580',
                    existingPlan: {
                      planId: '63217',
                      displayName: 'BYOD Plan',
                      price: {
                        discountedPrice: 5.0,
                      },
                    },
                    selectedPlan: {
                      planId: '70143',
                      displayName: 'New Plan',
                    },
                  },
                ],
              },
            ],
          },
        },
      };

      const fetchCartDetailsResult = {
        data: {
          data: {
            cart: {
              lineDetails: {
                lineInfo: [
                  {
                    mobileNumber: '7165790580',
                    serviceInfo: {
                      otherPromotions: [
                        {
                          promos: [
                            {
                              id: '21259',
                            },
                          ],
                        },
                      ],
                    },
                  },
                ],
              },
            },
          },
        },
      };

      const { container } = render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={jest.fn()}
          FetchPricingSnapShotResult={fpsMock}
          setFPSProtectionData={jest.fn()}
          customerBio={customerBio}
          isInDirect={false}
          aiquoteResponse={aiQuoteResponseJSON}
          fetchCartDetailsResult={fetchCartDetailsResult}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );

      expect(container).toBeTruthy();
    });

    test('should return false when byodFiveDollarPlanPOSFFlag is TRUE but promo does not exist in retrieveCart', async () => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          byodPlusPlanFFlag: 'TRUE',
          byodFiveDollarPlanPOSFFlag: 'TRUE',
        }),
      );

      const fpsMock = {
        ...FetchPricingSnapshot,
        data: {
          ...FetchPricingSnapshot.data,
          data: {
            ...FetchPricingSnapshot.data.data,
            subAccounts: [
              {
                lines: [
                  {
                    mtn: '7165790580',
                    existingPlan: {
                      planId: '63217',
                      displayName: 'BYOD Plan',
                      price: {
                        discountedPrice: 5.0,
                      },
                    },
                    selectedPlan: {
                      planId: '70143',
                      displayName: 'New Plan',
                    },
                  },
                ],
              },
            ],
          },
        },
      };

      const fetchCartDetailsResult = {
        data: {
          data: {
            cart: {
              lineDetails: {
                lineInfo: [
                  {
                    mobileNumber: '7165790580',
                    serviceInfo: {
                      otherPromotions: [
                        {
                          promos: [],
                        },
                      ],
                    },
                  },
                ],
              },
            },
          },
        },
      };

      const { container } = render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={jest.fn()}
          FetchPricingSnapShotResult={fpsMock}
          setFPSProtectionData={jest.fn()}
          customerBio={customerBio}
          isInDirect={false}
          aiquoteResponse={aiQuoteResponseJSON}
          fetchCartDetailsResult={fetchCartDetailsResult}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );

      expect(container).toBeTruthy();
    });
  });

  describe('hasUpgradedIncompatibleByodDevice with checkByodPromoFromRetrieveCart integration', () => {
    test('should return true when byodFiveDollarPlanPOSFFlag is TRUE and promo exists in retrieveCart', async () => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          byodPlusPlanFFlag: 'TRUE',
          byodPlusEUPSupressFFlag: 'TRUE',
          byodFiveDollarPlanPOSFFlag: 'TRUE',
        }),
      );

      const fpsMock = {
        ...FetchPricingSnapshot,
        data: {
          ...FetchPricingSnapshot.data,
          data: {
            ...FetchPricingSnapshot.data.data,
            subAccounts: [
              {
                lines: [
                  {
                    mtn: '7165790580',
                    existingDevice: {
                      sorId: 'OLD123',
                    },
                    selectedDevice: {
                      sorId: 'NEW456',
                    },
                    existingPlan: {
                      planId: '63217',
                      displayName: 'BYOD Plan',
                      price: {
                        discountedPrice: 5.0,
                      },
                    },
                  },
                ],
              },
            ],
          },
        },
      };

      const fetchCartDetailsResult = {
        data: {
          data: {
            cart: {
              lineDetails: {
                lineInfo: [
                  {
                    mobileNumber: '7165790580',
                    serviceInfo: {
                      otherPromotions: [
                        {
                          promos: [
                            {
                              id: '21259',
                            },
                          ],
                        },
                      ],
                    },
                  },
                ],
              },
            },
          },
        },
      };

      const { container } = render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={jest.fn()}
          FetchPricingSnapShotResult={fpsMock}
          setFPSProtectionData={jest.fn()}
          customerBio={customerBio}
          isInDirect={false}
          aiquoteResponse={aiQuoteResponseJSON}
          fetchCartDetailsResult={fetchCartDetailsResult}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );

      expect(container).toBeTruthy();
    });

    test('should return false when byodFiveDollarPlanPOSFFlag is TRUE but promo does not exist', async () => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          byodPlusPlanFFlag: 'TRUE',
          byodPlusEUPSupressFFlag: 'TRUE',
          byodFiveDollarPlanPOSFFlag: 'TRUE',
        }),
      );

      const fpsMock = {
        ...FetchPricingSnapshot,
        data: {
          ...FetchPricingSnapshot.data,
          data: {
            ...FetchPricingSnapshot.data.data,
            subAccounts: [
              {
                lines: [
                  {
                    mtn: '7165790580',
                    existingDevice: {
                      sorId: 'OLD123',
                    },
                    selectedDevice: {
                      sorId: 'NEW456',
                    },
                    existingPlan: {
                      planId: '63217',
                      displayName: 'BYOD Plan',
                      price: {
                        discountedPrice: 5.0,
                      },
                    },
                  },
                ],
              },
            ],
          },
        },
      };

      const fetchCartDetailsResult = {
        data: {
          data: {
            cart: {
              lineDetails: {
                lineInfo: [
                  {
                    mobileNumber: '7165790580',
                    serviceInfo: {
                      otherPromotions: [
                        {
                          promos: [],
                        },
                      ],
                    },
                  },
                ],
              },
            },
          },
        },
      };

      const { container } = render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={jest.fn()}
          FetchPricingSnapShotResult={fpsMock}
          setFPSProtectionData={jest.fn()}
          customerBio={customerBio}
          isInDirect={false}
          aiquoteResponse={aiQuoteResponseJSON}
          fetchCartDetailsResult={fetchCartDetailsResult}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );

      expect(container).toBeTruthy();
    });

    test('should return true when byodFiveDollarPlanPOSFFlag is FALSE and discountedPrice is 0', async () => {
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          byodPlusPlanFFlag: 'TRUE',
          byodPlusEUPSupressFFlag: 'TRUE',
          byodFiveDollarPlanPOSFFlag: 'FALSE',
        }),
      );

      const fpsMock = {
        ...FetchPricingSnapshot,
        data: {
          ...FetchPricingSnapshot.data,
          data: {
            ...FetchPricingSnapshot.data.data,
            subAccounts: [
              {
                lines: [
                  {
                    mtn: '7165790580',
                    existingDevice: {
                      sorId: 'OLD123',
                    },
                    selectedDevice: {
                      sorId: 'NEW456',
                    },
                    existingPlan: {
                      planId: '63217',
                      displayName: 'BYOD Plan',
                      price: {
                        discountedPrice: 0,
                      },
                    },
                  },
                ],
              },
            ],
          },
        },
      };

      const { container } = render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={jest.fn()}
          FetchPricingSnapShotResult={fpsMock}
          setFPSProtectionData={jest.fn()}
          customerBio={customerBio}
          isInDirect={false}
          aiquoteResponse={aiQuoteResponseJSON}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        },
      );

      expect(container).toBeTruthy();
    });
  });
});

TestFooter(CHANNELS.OMNI_RETAIL);
Test(CHANNELS.OMNI_RETAIL);

Test(CHANNELS.OMNI_INDIRECT);
TestVMPProtection(CHANNELS.OMNI_RETAIL);

// --- CCD Modal Express Checkout Test ---
describe('Footer CcdModal express checkout', () => {
  const handlers = [
    rest.post(`*fetchPricingSnapshot`, (req, res, ctx) => res(ctx.status(200), ctx.json(fpsNew))),
    rest.post(`*processAcctInquiryTranDetails`, (req, res, ctx) =>
      res(
        ctx.status(200),
        ctx.json({
          data: {
            statusMessage: 'Success',
            uniqueKey: '1710886290738',
            pkSequence: null,
            errors: null,
            status: 1,
          },
        }),
      ),
    ),
  ];
});
