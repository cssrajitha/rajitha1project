import React, { useState } from 'react';
import _ from 'lodash';
import styled from 'styled-components';
import { Body } from '@vds/typography';
import { Line } from '@vds/lines';
import { ButtonGroup } from '@vds/buttons';
import { Icon } from '@vds/icons';
import { Tabs, Tab } from '@vds/tabs';
import { Tooltip } from '@vds/tooltips';
import { formatCurrency } from 'onevzsoemfecommon/Helpers/validation';
import { sendCustomEvent } from 'onevzsoemfeframework/Tagging';
import { isIpad } from 'onevzsoemfeframework/DomService';
// import { Toggle } from '@vds/toggles';

const PaddingTop16 = styled.div`
  padding-top: 0;
`;

export const PaddingAll = styled.div`
  padding: 1rem;
`;

const StyledPaddingTop32 = styled.div`
  padding: 0 0 0 0;
  display: ${(props) => (props?.isPlanChangeRecommender === 'TRUE' ? 'flex' : '')};
`;

const IconGroup = styled.div`
  width: 100%;
  height: 100%;
  background-color: transparent;
  border-radius: 50%;
  border: none;
  background-clip: padding-box;
  transition: all 0.1s ease-out 0s;
`;

const FooterContainer = styled.div`
  position: fixed;
  bottom: ${(props) => (props?.isProspectPersonalShopper ? '1.5rem' : '0')};
  width: 100%;
  z-index: 1;
  max-width: 1133px;
`;

const FooterWrapper = styled.div`
  align-items: baseline;
  justify-content: center;
  background-color: rgb(255, 255, 255);
  background-color: #ffffff;
  border-top: ${(props) => (props?.label ? '0px' : '1px solid rgb(0, 0, 0)')};
  box-sizing: border-box;
  cursor: pointer;
  padding: 1rem;

  div[role='tabpanel'] {
    overflow-y: ${(props) => (props.enableScroll ? 'auto' : 'none')};
    max-height: ${(props) => (props.isIpad ? '500px !important' : '325px')};
  }
`;

const WrapperContainer = styled.div`
  position: absolute;
  top: 1.75rem;
  right: 1.25rem;
  z-index: 99;
  display: flex;
  align-items: center;
  gap: 1rem;
`;

// const ToggleWrapper = styled.div`
//   display: flex;
//   align-items: center;
// `;

const CloseWrapper = styled.div`
  display: flex;
  align-items: center;
  cursor: pointer;
`;
const FinanceBottomBox = styled.div`
  border-top: 1px solid rgb(0, 0, 0);
  box-sizing: border-box;
  background: rgb(246, 246, 246);
`;
const Wrapper = styled.div`
  width: 100%;
  height: 100%;
  position: fixed;
  z-index: 1;
  bottom: 0;
  background-color: ${(props) => (props?.isProspectPersonalShopper ? '' : 'rgba(0, 0, 0, 0.5)')};
  max-width: 1133px;
`;

const GridContainer = styled.div`
  display: grid;
  grid-template-rows: 1fr;
  grid-template-columns: max-content max-content max-content max-content;
  grid-column-gap: 2.5rem;
  GridItem > :first-child {
    grid-column-gap: 1.5rem;
  }
`;
const GridItem = styled.div`
  p {
    margin: 0;
  }
`;
const ItemWrapper = styled.div`
  table {
    border: none !important;
  }
  td {
    padding-bottom: 0.5rem !important;
    border: none !important;
    padding: 0.5rem 0.5rem !important;
  }
  td:nth-child(even) {
    text-align: right;
  }
  td:nth-child(odd) {
    padding-right: 1rem;
  }
`;
const PromotionContainer = styled.div`
  display: flex;
  justify-content: flex-start;
  flex-direction: row;
  max-width: 1133px;
`;
const PaddingRight64 = styled.div`
  padding-right: 4rem;
`;
const PaddingRight80 = styled.div`
  padding-right: 5rem;
`;
const TabContent = styled.div`
  margin-top: 1rem;
`;
const LinePricingContainer = styled.div`
  flex-direction: column;
`;
const TotalSavingContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1.25rem;
`;
const SavingsBreakup = styled.div`
  padding: 0.5rem;
  background-color: #f6f6f6;
  border: 1px dashed #a7a7a7;
  border-radius: 0.25rem;
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
  width: 270px;
`;
const HeadingsContainer = styled.div`
  display: flex;
  gap: 2rem;
  p {
    width: 15%;
  }
`;
const RowContainer = styled.div`
  position: relative;
  display: flex;
  gap: 2rem;
  padding: 1.5rem 0;
  p {
    width: 15%;
  }
`;
const ExpandIconContainer = styled.div`
  margin-left: auto;
  position: absolute;
  right: 0px;
  padding-right: 0.5rem;
`;
export const FlexSpaceBetween = styled.div`
  display: flex;
  justify-content: space-between;
`;

export const TooltipContentWrapper = styled.div`
  top:${({isProspectPersonalShopper}) =>(isProspectPersonalShopper ? '12px' : '5px')};
  position: relative;
  left: ${({isProspectPersonalShopper}) =>(isProspectPersonalShopper ? '385px' : '360px')};
  width: 23px;
  > span {
    position: absolute;
    z-index: 1001;
  }
  > span:hover {
    position: fixed;
  }
`;

export const FlexRowGap = styled.div`
  display: flex;
  flex-direction: row;
  align-items: ${({ align }) => (align === undefined ? 'center' : align)};
  gap: ${({ gap }) => gap}px;
`;

export const FlexColumnGap = styled.div`
  display: flex;
  width: ${({ width }) => width}px;
  flex-direction: column;
  gap: ${({ gap }) => gap}px;
`;

// const AdditionalAvailableStaticDiv = styled.div`
//   display: flex;
//   justify-content: flex-start;
//   flex-direction: row;
//   max-width: 1133px;
//   padding-top: 1rem;
// `;

function ExpandFooter({
  hideFooter,
  expandFooterData,
  handleProceedToOrder,
  estnewmonthly,
  nextBillTotal,
  enableScroll,
  isPlanChangeRecommender = false,
  fetchPricingResponse = {},
  isNewCustomer = false,
  personalShopperFlow = false,
  // hideSavings,
  // toggleStatus = false,
  // shouldShowAdditionalToggle = false,
  additionalSavingsAmount = 0,
  isAiBillUploadFlow = false,
}) {
  const [openIndices, setOpenIndices] = useState([]);
  const assistedFlags = JSON.parse(
    sessionStorage.getItem('APP_PROPERTIES') ? sessionStorage.getItem('APP_PROPERTIES') : '{}',
  );
  const aiPlanFooterFFlag = assistedFlags?.aiPlanFooterFFlag?.toUpperCase() === 'TRUE' || false;
  const originalperkWorth =
    fetchPricingResponse?.data?.data?.subAccounts?.[0]?.savings?.savingsList?.reduce(
      (sum, item) => sum + (parseFloat(item.originalPrice) || 0),
      0,
    ) || 0;
  const grandTotalLineSavings =
    fetchPricingResponse?.data?.data?.subAccounts?.[0]?.savings?.grandTotalSavings?.grandTotalLineSavings ?? 0;
  const handleClick = (index) => {
    if (openIndices.includes(index)) {
      setOpenIndices(openIndices.filter((i) => i !== index));
    } else {
      setOpenIndices([...openIndices, index]);
    }
  };

  const montanaOfferEnableFFlag =
    JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.montanaOfferEnableFFlag?.toUpperCase() === 'TRUE';
  const aiQuoteProspectOffersFFlag =
    JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.aiQuoteProspectOffersFFlag?.toUpperCase() === 'TRUE';
  const hasAdditionalSavingDiscounts = ( montanaOfferEnableFFlag && personalShopperFlow && isAiBillUploadFlow) || (aiQuoteProspectOffersFFlag && !isAiBillUploadFlow);
  const getTabLabel = (key) => {
    const labels = [
      'Monthly estimate',
      'Line level pricing & savings',
      // 'Total Savings'
    ];

    // If personalShopperFlow is true, use all 3 labels, otherwise only first 2
    // const availableLabels =  enableTotalSavingsTab ? labels : labels.slice(0, 2);

    return labels[key];
  };

  // const filteredFooterData = enableTotalSavingsTab ? expandFooterData : expandFooterData.slice(0, 2);

  const handleOpenView = (key) => {
    const vzdl = window?.vzdl || {};
    /* istanbul ignore if */
    if (vzdl?.page) {
      if (key === 0) {
        vzdl.page.detail = 'Monthly Estimate';
        vzdl.event.value = `event270=${estnewmonthly || 0},event269=${nextBillTotal || 0}`;
      } else {
        vzdl.page.detail = 'lineLevelPricing&Savings';
        vzdl.event.value = '';
      }
    }
    sendCustomEvent('openView', window?.vzdl);
  };

  return (
    <Wrapper isProspectPersonalShopper={window?.mfe?.isProspectPersonalShopper}>
      <FooterContainer data-testid='expandFooter' isProspectPersonalShopper={window?.mfe?.isProspectPersonalShopper}>
        <WrapperContainer>
          {/* {montanaOfferEnableFFlag && shouldShowAdditionalToggle && (
          <ToggleWrapper>
            <Body size='small' style={{ marginRight: '0.5rem' }}>Show additional available discounts</Body>
            <Toggle on={toggleStatus} onChange={hideSavings}
             data-track={toggleStatus ? 'Show additional available discounts_disabled' : 'Show additional available discounts_enabled'}
            />
          </ToggleWrapper>
          )} */}
          <CloseWrapper onClick={hideFooter} data-track='Billing Details - Close'>
            <Icon name='down-caret' size='XLarge' />
          </CloseWrapper>
        </WrapperContainer>
        <FooterWrapper enableScroll={enableScroll} isIpad={isIpad()}>
          <TooltipContentWrapper isProspectPersonalShopper={window?.mfe?.isProspectPersonalShopper}>
            <Tooltip size='small' surface='light' title=''>
              Line level estimates do not include account level pricing or discounts
            </Tooltip>
          </TooltipContentWrapper>
          <Tabs orientation='horizontal' indicatorPosition='bottom' size='medium'>
            {expandFooterData &&
              expandFooterData.map((tabItem, key) => (
                <Tab key={_.uniqueId('tab-')} label={getTabLabel(key)} onClick={() => handleOpenView(key)}>
                  {Object.entries(tabItem).map(([label, value]) => (
                    <TabContent key={_.uniqueId('tabcontent-')}>
                      <GridContainer>
                        {key === 0 &&
                          value?.map((item) => (
                            <GridItem key={_.uniqueId('grid-item-')}>
                              <ItemWrapper>
                                <table border={0} cellPadding={0} cellSpacing={0}>
                                  <tbody>
                                    {item &&
                                      item.map((obj) => (
                                        <tr key={_.uniqueId('t1-')}>
                                          <td>
                                            <Body
                                              size={(obj?.bold && 'large') || 'medium'}
                                              bold={obj?.bold || false}
                                              style={label === 'discounts' && { marginBottom: '1rem' }}
                                              color={
                                                label === 'discounts' && obj.title?.match(/Total Savings for/g)
                                                  ? '#00AC3E'
                                                  : ''
                                              }
                                            >
                                              <strong>{obj?.count}</strong> {obj?.title}
                                            </Body>
                                          </td>
                                          <td>
                                            <Body
                                              size={(obj?.bold && 'large') || 'medium'}
                                              bold={obj?.amtBold || false}
                                              color={
                                                (label === 'discounts' || label === 'totals') &&
                                                obj?.title?.match(
                                                  /Savings|Additional available discounts|Paperless discount|ECPD discount|Est. new monthly if discounts/g,
                                                )
                                                  ? '#00AC3E'
                                                  : ''
                                              }
                                            >
                                              {obj?.amount}
                                              {obj?.displayMon ? '/mo' : ''}
                                            </Body>
                                            {obj?.type === 'TRADE' ||
                                              (obj?.type === 'BIC' && (
                                                <Body size='small' bold color='#000000'>
                                                  (36 monthly credits)
                                                </Body>
                                              ))}
                                          </td>
                                        </tr>
                                      ))}
                                  </tbody>
                                </table>
                              </ItemWrapper>
                            </GridItem>
                          ))}
                      </GridContainer>
                      {key === 1 && (
                        <LinePricingContainer>
                          <HeadingsContainer>
                            <Body size='large' bold>
                              Lines
                            </Body>
                            {!isNewCustomer && (
                              <Body size='large' bold>
                                Current monthly
                              </Body>
                            )}
                            <Body size='large' bold>
                              Est new monthly
                            </Body>
                            {!isNewCustomer && (
                              <Body size='large' bold>
                                Change
                              </Body>
                            )}
                            <Body size='large' bold color='#008331'>
                              Perk & Promo Savings
                            </Body>
                          </HeadingsContainer>
                          {key === 1 &&
                            value?.[0] &&
                            value?.map((lineData, index) => (
                              <React.Fragment key={_.uniqueId('lineData-')}>
                                <RowContainer>
                                  <Body size='large'>{lineData.mtn}</Body>
                                  {!isNewCustomer && <Body size='large'>{lineData.currentMonthly}</Body>}
                                  <Body size='large'>{lineData.estNewMonthly}</Body>
                                  {!isNewCustomer && (
                                    <Body size='large'>
                                      {formatCurrency(lineData.change)}
                                      <Icon
                                        name={lineData.change > 0 ? 'up-arrow' : 'down-arrow'}
                                        size='small'
                                        color={lineData.change > 0 ? '#b95319' : '#00AC3E'}
                                      />
                                    </Body>
                                  )}
                                  <TotalSavingContainer>
                                    <Body size='large' color='#008331'>
                                      {lineData.totalSavings}
                                    </Body>
                                    {openIndices.includes(index) && lineData?.savingsBreakup && (
                                      <SavingsBreakup>
                                        {lineData?.savingsBreakup?.map((eachSaving) => (
                                          <FlexSpaceBetween key={_.uniqueId(`saving-`)}>
                                            <Body size='medium' primitive='span'>
                                              {eachSaving.name}
                                            </Body>
                                            <Body size='medium' primitive='span' color='#008331'>
                                              {eachSaving.price}
                                            </Body>
                                          </FlexSpaceBetween>
                                        ))}
                                      </SavingsBreakup>
                                    )}
                                  </TotalSavingContainer>
                                  <ExpandIconContainer>
                                    <IconGroup
                                      data-testid='minusplusIcon'
                                      data-track={
                                        openIndices.includes(index) ? 'CollapsePromoSavings' : 'ExpandPromoSavings'
                                      }
                                      onClick={() => handleClick(index)}
                                    >
                                      <Icon name={openIndices.includes(index) ? 'minus' : 'plus'} size={24} />
                                    </IconGroup>
                                  </ExpandIconContainer>
                                </RowContainer>
                                {value.length - 1 !== index && <Line type='secondary' />}
                              </React.Fragment>
                            ))}
                        </LinePricingContainer>
                      )}
                      {/* <GridContainer>
                        {key === 2 && montanaOfferEnableFFlag && personalShopperFlow && value?.length > 0 && (
                          value?.map((item) => (
                            <GridItem key={_.uniqueId('total-savings-item-')}>
                              <ItemWrapper>
                                <table border={0} cellPadding={0} cellSpacing={0} style={{ width: '700px', minWidth: '700px' }}>
                                  <tbody>
                                    {(item && item?.length > 0) &&
                                      item.map((obj) => (
                                        <tr key={_.uniqueId('total-savings-')} style={{ backgroundColor: label === 'totalSavings' ? '#DFF8EF' : ''}}>
                                          <td>
                                            <Body
                                              size={(obj?.bold && 'large') || 'medium'}
                                              bold={obj?.bold || false}
                                              style={label === 'discounts' && { marginBottom: '1rem' }}
                                              color={
                                                label === 'discounts' && obj.title?.match(/Total Savings for/g)
                                                  ? '#00AC3E'
                                                  : ''
                                              }
                                            >
                                              {obj?.title}
                                            </Body>
                                          </td>
                                          {obj?.originalAmount ?
                                            <td aria-label="Original amount" style={{ textAlign: 'right' }}>
                                              <Body size={(obj?.bold && 'large') || 'medium'} bold={obj?.bold || false}>
                                                {obj?.originalAmount}
                                              </Body>
                                            </td>
                                            : <td aria-label="No original amount" style={{ textAlign: 'right', width: '200px', minWidth: '200px' }}>
                                              <Body size={(obj?.bold && 'large') || 'medium'} style={{ visibility: 'hidden' }}>
                                                &nbsp;
                                              </Body>
                                            </td>
                                          }
                                          <td style={{ textAlign: 'right' }}>
                                            <Body
                                              size={(obj?.bold && 'large') || 'medium'}
                                              bold={obj?.amtBold || false}
                                              color={obj?.amount !== 'What they save' ? '#00AC3E' : '#000000'}
                                            >
                                              {obj?.amount}
                                              {obj?.displayMon ? '/mo' : ''}
                                            </Body>
                                            {obj?.type === 'TRADE' ||
                                              (obj?.type === 'BIC' && (
                                                <Body size='small' bold color='#000000'>
                                                  (36 monthly credits)
                                                </Body>
                                              ))}
                                          </td>
                                        </tr>
                                      ))}
                                  </tbody>
                                </table>
                                <Line type='secondary' />
                              </ItemWrapper>
                            </GridItem>
                          ))
                        )}
                      </GridContainer> */}
                      {label === 'totals' && (
                        <PromotionContainer>
                          <PaddingRight64 />
                          <Body size='small' color='#6F7171'>
                            *Pending promotions not included
                          </Body>
                          {/* {montanaOfferEnableFFlag && shouldShowAdditionalToggle && toggleStatus && additionalSavingsAmount > 0 && ( */}
                          {hasAdditionalSavingDiscounts && additionalSavingsAmount > 0 && (
                            <>
                              <PaddingRight80 />
                              <Body size='small' color='#6F7171'>
                                *Additional available discounts require enrollment after purchase.
                              </Body>
                            </>
                          )}
                        </PromotionContainer>
                      )}
                      {/* {montanaOfferEnableFFlag && shouldShowAdditionalToggle && toggleStatus && additionalSavingsAmount > 0 && label === 'additionalSavings' && (
                        <AdditionalAvailableStaticDiv>
                          <Body size='small' color='#6F7171'>
                            *Additional available discounts require enrollment after purchase.
                          </Body>
                        </AdditionalAvailableStaticDiv>
                      )} */}
                    </TabContent>
                  ))}
                  <PaddingTop16 />
                </Tab>
              ))}
          </Tabs>
        </FooterWrapper>
        {!isPlanChangeRecommender ? (
          <FinanceBottomBox>
            <PaddingAll>
              <StyledPaddingTop32>
                <ButtonGroup
                  childWidth='100%'
                  rowQuantity={{ desktop: 2 }}
                  data={[
                    {
                      name: 'ProceedToCartButton',
                      children: 'Proceed with Quote',
                      size: 'large',
                      use: 'primary',
                      width: 'auto',
                      onClick: () => handleProceedToOrder(),
                      tabIndex: 0,
                    },
                  ]}
                  alignment='left'
                />
              </StyledPaddingTop32>
            </PaddingAll>
          </FinanceBottomBox>
        ) : (
          <FinanceBottomBox>
            <PaddingAll>
              <StyledPaddingTop32 isPlanChangeRecommender='TRUE'>
                <ButtonGroup
                  childWidth='100%'
                  rowQuantity={{ desktop: 2 }}
                  data={[
                    {
                      name: 'ProceedToCartButton',
                      children: 'Proceed With Quote',
                      size: 'large',
                      use: 'primary',
                      width: 'auto',
                      onClick: () => handleProceedToOrder(),
                      tabIndex: 0,
                    },
                  ]}
                  alignment='left'
                />
                <FlexRowGap align='right' gap={32}>
                  <FlexColumnGap width={120}>
                    <Body size='large' bold>
                      {formatCurrency(
                        fetchPricingResponse?.data?.data?.subAccounts?.[0]?.totals?.grandTotalDueMonthly?.currentTotal,
                      )}
                    </Body>
                    <Body size='medium'>Current monthly</Body>
                  </FlexColumnGap>
                  <FlexColumnGap>
                    <FlexRowGap gap={4}>
                      <Body size='large' bold primitive='span'>
                        {formatCurrency(
                          fetchPricingResponse?.data?.data?.subAccounts?.[0]?.totals?.grandTotalDueMonthly
                            ?.estimatedTotal,
                        )}
                      </Body>
                      {!isNewCustomer && (
                        <Body
                          size='large'
                          primitive='span'
                          color={
                            fetchPricingResponse?.data?.data?.subAccounts?.[0]?.totals?.grandTotalDueMonthly
                              ?.priceDiffStatus === 'I'
                              ? '#b95319'
                              : '#00AC3E'
                          }
                        >
                          {formatCurrency(
                            fetchPricingResponse?.data?.data?.subAccounts?.[0]?.totals?.grandTotalDueMonthly
                              ?.todaysChanges,
                          )}
                        </Body>
                      )}

                      {!isNewCustomer &&
                        fetchPricingResponse?.data?.data?.subAccounts?.[0]?.totals?.grandTotalDueMonthly
                          ?.priceDiffStatus === 'I' && <Icon name='up-arrow' size='small' color='#b95319' />}
                      {!isNewCustomer &&
                        fetchPricingResponse?.data?.data?.subAccounts?.[0]?.totals?.grandTotalDueMonthly
                          ?.priceDiffStatus === 'D' && <Icon name='down-arrow' size='small' color='#00AC3E' />}
                    </FlexRowGap>
                    <Body size='medium'>Est. new monthly</Body>
                  </FlexColumnGap>
                  {!aiPlanFooterFFlag ? (
                    <>
                      {fetchPricingResponse?.data?.data?.subAccounts?.[0]?.totals?.grandTotalDueMonthly
                        ?.priceDiffStatus === 'D' && (
                        <div>
                          <Body size='large' bold color='#008331'>
                            {formatCurrency(fetchPricingResponse?.data?.data?.subAccounts?.[0]?.savings?.totalSavings)}
                          </Body>
                          <Body size='medium' color='#008331'>
                            Total savings
                          </Body>
                        </div>
                      )}
                      {fetchPricingResponse?.data?.data?.subAccounts?.[0]?.totals?.grandTotalDueMonthly
                        ?.priceDiffStatus === 'I' && (
                        <FlexColumnGap width={140}>
                          <Body size='large' bold color='#008331'>
                            {formatCurrency(originalperkWorth)}
                          </Body>
                          <Body size='medium' color='#008331'>
                            Worth of perks inc.
                          </Body>
                        </FlexColumnGap>
                      )}
                    </>
                  ) : (
                    <div>
                      <Body size='large' bold color='#008331'>
                        {formatCurrency(grandTotalLineSavings)}
                      </Body>
                      <Body size='medium' color='#008331'>
                        Total Monthly Savings
                      </Body>
                    </div>
                  )}
                </FlexRowGap>
              </StyledPaddingTop32>
            </PaddingAll>
          </FinanceBottomBox>
        )}
      </FooterContainer>
    </Wrapper>
  );
}
export default ExpandFooter;
