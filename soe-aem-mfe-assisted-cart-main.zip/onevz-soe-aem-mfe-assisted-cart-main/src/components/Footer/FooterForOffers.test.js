import React from 'react';
import Emitter from 'onevzsoemfeframework/Emitter';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import { fireEvent, render, screen } from '../../utils/test-utils/renderHelper';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { setupChannel, CHANNELS } from '../../utils/test-utils/utils';
import Footer from './Footer';
import FetchPricingSnapshot from '../../mocks/fetchPricingSnapshot.json';
import compareQuotes from './Mocks/compareQuotes.json';
import aiquoteResponseTaggingJSON from './Mocks/aiquoteResponseTagging.json';
import fpsWithCartItemJSON from './Mocks/fpsWithCartItem.json';
import { customerBio, deviceRecommendations } from '../../mocks/footerTestData';
import FetchPricingSnapshotForOffers from '../../mocks/fetchPricingSnapshotForOffers.json';

jest.mock('onevzsoemfecommon/Helpers', () => ({
  getQueryParamByName: (param) => {
    if (param === 'customerType') return 'N';
    return null;
  },
  getUIContextPathBAU: jest.fn(() => {}),
}));
jest.mock('@vds/modals', () => ({
  ...jest.requireActual('@vds/modals'),
  // eslint-disable-next-line react/button-has-type, react/prop-types
  Modal: ({ children, ...props }) => (
    // eslint-disable-next-line react/prop-types
    <div {...props} data-testid={props.id}>
      {children}
    </div>
  ),
}));

const TestFooter = (channel) => {
  setupChannel(channel);
  const setFPSProtectionData = jest.fn();
  const setTriggerProceedToQuote = jest.fn();
  describe('Footer component without cartProducts', () => {
    const handlers = [
      rest.post(`*fetchPricingSnapshot`, (req, res, ctx) => {
        console.log('inside FPS mock');
        return res(ctx.status(200), ctx.json(fpsWithCartItemJSON));
      }),
      rest.post(`*processAcctInquiryTranDetails`, (req, res, ctx) => {
        console.log('inside mock');
        return res(
          ctx.status(200),
          ctx.json({
            data: {
              statusMessage: 'Success',
              uniqueKey: '1710886290738',
              pkSequence: null,
              errors: null,
              status: 1,
            },
          })
        );
      }),
      rest.post(`*compareQuotes`, (req, res, ctx) => {
        console.log('inside FPS mock');
        return res(ctx.status(200), ctx.json(compareQuotes));
      }),
    ];

    delete window.cartProducts;
    const vzdlMock = window.vzdl;
    delete window.vzdl;
    window.vzdl = {
      ...vzdlMock,
      page: { name: 'AI QUOTE', detail: 'Footer', throttle: 'MFE' },
      event: { value: 'scAdd' },
      txn: { product: { current: [] }, nonRecurringPrice: 0 },      
    };
    const server = setupServer(...handlers);
    beforeAll(() => server.listen());
    afterEach(() => server.resetHandlers());
    afterAll(() => server.close());
    beforeEach(() => {
      delete window.cartProducts;
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          enableShareQuoteinAIQuoteFFlag: 'TRUE',
          personalShopperVVCModalFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
          montanaOffersTaggingFFlag: 'TRUE',
        })
      );
      Object.defineProperty(global.navigator, 'userAgent', {
        get() {
          return 'iPad';
        },
        configurable: true,
      });
      render(
        <Footer
          isAIQuote
          activeMtnValue='newLine1'
          deviceRecom={deviceRecommendations}
          deviceTriageDone
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          triggerProceedToQuote
          aiquoteResponse={aiquoteResponseTaggingJSON}
          FetchPricingSnapShotResult={FetchPricingSnapshot}
          setFPSProtectionData={setFPSProtectionData}
          linesWithoutProtection={[]}
          isCollaborationStartedForRC
          showPriceDetails
          activeLinePriceTypeInCart='MONTH_TO_MONTH'
          setTaggingPayload={jest.fn()}
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          mandatoryNumberShareLines={[]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        }
      );
    });
    test('renders footer component on click of proceedWithQuote - AAL flow captureQuoteFeedback call request body ', async () => {
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('FETCH_CART_LINE_DETAILS');
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: true,
      });
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: false,
      });
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {});
      Emitter.emit('Closing_Device_Protection_Modal', {});
      Emitter.emit('Priority_upgrade_List', [{ isPriorityMtn: true, mtn: '302383234' }]);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });
  });

  describe('Footer - Add to cart for Montana with Offers', () => {
    const handlers = [
      rest.post(`*fetchPricingSnapshot`, (req, res, ctx) => {
        console.log('inside FPS mock');
        return res(ctx.status(200), ctx.json(fpsWithCartItemJSON));
      }),
      rest.post(`*processAcctInquiryTranDetails`, (req, res, ctx) => {
        console.log('inside mock');
        return res(
          ctx.status(200),
          ctx.json({
            data: {
              statusMessage: 'Success',
              uniqueKey: '1710886290738',
              pkSequence: null,
              errors: null,
              status: 1,
            },
          })
        );
      }),
      rest.post(`*compareQuotes`, (req, res, ctx) => {
        console.log('inside FPS mock');
        return res(ctx.status(200), ctx.json(compareQuotes));
      }),
    ];

    delete window.cartProducts;
    const vzdlMock = window.vzdl;
    delete window.vzdl;
    window.vzdl = {
      ...vzdlMock,
      page: { name: 'AI QUOTE' },
      event: { value: 'scAdd' },
      txn: { product: { current: [] }, nonRecurringPrice: 0 },      
    };
    const server = setupServer(...handlers);
    beforeAll(() => server.listen());
    afterEach(() => server.resetHandlers());
    afterAll(() => server.close());
    beforeEach(() => {
      delete window.cartProducts;
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          enableShareQuoteinAIQuoteFFlag: 'TRUE',
          personalShopperVVCModalFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
          montanaOffersTaggingFFlag: 'TRUE',
        })
      );
      Object.defineProperty(global.navigator, 'userAgent', {
        get() {
          return 'iPad';
        },
        configurable: true,
      });
      render(
        <Footer
          isAIQuote
          activeMtnValue='newLine1'
          deviceRecom={deviceRecommendations}
          deviceTriageDone
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          triggerProceedToQuote
          aiquoteResponse={aiquoteResponseTaggingJSON}
          FetchPricingSnapShotResult={FetchPricingSnapshotForOffers}
          setFPSProtectionData={setFPSProtectionData}
          linesWithoutProtection={[]}
          isCollaborationStartedForRC
          showPriceDetails
          activeLinePriceTypeInCart='MONTH_TO_MONTH'
          setTaggingPayload={jest.fn()}
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          mandatoryNumberShareLines={[]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        }
      );
    });
    test('renders footer component on click of proceedWithQuote - AAL flow captureQuoteFeedback call request body ', async () => {
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('FETCH_CART_LINE_DETAILS');
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: true,
      });
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: false,
      });
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {});
      Emitter.emit('Closing_Device_Protection_Modal', {});
      Emitter.emit('Priority_upgrade_List', [{ isPriorityMtn: true, mtn: '302383234' }]);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });
  });

  describe('Footer - Add to cart for target Offers', () => {
    const handlers = [
      rest.post(`*fetchPricingSnapshot`, (req, res, ctx) => {
        console.log('inside FPS mock');
        return res(ctx.status(200), ctx.json(fpsWithCartItemJSON));
      }),
      rest.post(`*processAcctInquiryTranDetails`, (req, res, ctx) => {
        console.log('inside mock');
        return res(
          ctx.status(200),
          ctx.json({
            data: {
              statusMessage: 'Success',
              uniqueKey: '1710886290738',
              pkSequence: null,
              errors: null,
              status: 1,
            },
          })
        );
      }),
      rest.post(`*compareQuotes`, (req, res, ctx) => {
        console.log('inside FPS mock');
        return res(ctx.status(200), ctx.json(compareQuotes));
      }),
    ];
    delete window.cartProducts;

    const server = setupServer(...handlers);
    beforeAll(() => server.listen());
    afterEach(() => server.resetHandlers());
    afterAll(() => server.close());
    beforeEach(() => {
      delete window.cartProducts;
      sessionStorage.setItem(
        'APP_PROPERTIES',
        JSON.stringify({
          enableFullBlownMfeNbsPosFFlag: 'TRUE',
          enableShareQuoteinAIQuoteFFlag: 'TRUE',
          personalShopperVVCModalFFlag: 'TRUE',
          montanaOfferEnableFFlag: 'TRUE',
          montanaOffersTaggingFFlag: 'TRUE',
          promotionOfferTaggingFFlag: 'TRUE',
        })
      );
      Object.defineProperty(global.navigator, 'userAgent', {
        get() {
          return 'iPad';
        },
        configurable: true,
      });
      render(
        <Footer
          isAIQuote
          activeMtnValue='newLine1'
          deviceRecom={deviceRecommendations}
          deviceTriageDone
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          triggerProceedToQuote
          aiquoteResponse={aiquoteResponseTaggingJSON}
          FetchPricingSnapShotResult={FetchPricingSnapshotForOffers}
          setFPSProtectionData={setFPSProtectionData}
          linesWithoutProtection={[]}
          isCollaborationStartedForRC
          showPriceDetails
          activeLinePriceTypeInCart='MONTH_TO_MONTH'
          setTaggingPayload={jest.fn()}
          customerBio={customerBio}
          mtnListPriceEdit={[{ mtn: '4107397731', priceEdited: true }]}
          isInDirect={false}
          mandatoryNumberShareLines={[]}
        />,
        {
          reducers: rootReducer,
          sagas: rootSaga,
        }
      );
    });
    test('renders footer component on click of proceedWithQuote with window.vzdl', async () => {
        const vzdlMock = window.vzdl;
    delete window.vzdl;
    // Set window.vzdl with target.offer to test line 794 when window.vzdl exists
    window.vzdl = {
      ...vzdlMock,
      target: {
        offer: 'Montana Offer Test',
      },
    };
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('FETCH_CART_LINE_DETAILS');
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: true,
      });
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: false,
      });
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {});
      Emitter.emit('Closing_Device_Protection_Modal', {});
      Emitter.emit('Priority_upgrade_List', [{ isPriorityMtn: true, mtn: '302383234' }]);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });
    test('renders footer component on click of proceedWithQuote when window.vzdl is undefined', async () => {
        const vzdlMock = window.vzdl;
    delete window.vzdl;
    // Set window.vzdl with target.offer to test line 794 when window.vzdl exists
    window.vzdl = undefined;
      Emitter.emit('AI_QUOTE_SUCCESS', true);
      Emitter.emit('Show_Edit_TradeIn', false);
      Emitter.emit('Assisted_MTN_Value', '2812530682');
      Emitter.emit('FETCH_CART_LINE_DETAILS');
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: true,
      });
      Emitter.emit('AI_QUOTE_PLAN_RECOMMENDATIONS', {
        plans: [
          {
            planId: '63217',
            recommendationOrder: '1',
          },
        ],
        isUpdateQuote: false,
      });
      Emitter.emit('UPDATE_TRAN_DETAILS_TO_FOOTER', {});
      Emitter.emit('Closing_Device_Protection_Modal', {});
      Emitter.emit('Priority_upgrade_List', [{ isPriorityMtn: true, mtn: '302383234' }]);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
      const proceedtoCart = await screen.findByTestId('footercomponentButton');
      expect(proceedtoCart).not.toBeDisabled();
      fireEvent.click(proceedtoCart);
      await new Promise((res) => {
        setTimeout(res, 1000);
      });
    });
  });

};

TestFooter(CHANNELS.OMNI_RETAIL);

