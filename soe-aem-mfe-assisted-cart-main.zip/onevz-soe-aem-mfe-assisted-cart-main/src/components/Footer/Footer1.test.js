import React from 'react';
import Emitter from 'onevzsoemfeframework/Emitter';
import { setupServer } from 'msw/node';
import { rest } from 'msw';
import { fireEvent, render, screen, waitFor } from '../../utils/test-utils/renderHelper';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import { setupChannel, CHANNELS } from '../../utils/test-utils/utils';
import Footer from './Footer';
import { customerBio, deviceRecommendations } from '../../mocks/footerTestData';
import fpsNew from './Mocks/FPSNEW.json';

jest.mock('@vds/modals', () => ({
  ...jest.requireActual('@vds/modals'),
  Modal: ({ children, ...props }) => (
    <div {...props} data-testid={props.id}>
      {children}
    </div>
  ),
}));

const Test = (channel) => {
  setupChannel(channel);
  const setFPSProtectionData = jest.fn();
  const setTriggerProceedToQuote = jest.fn();

  describe('Footer - Prospect Montana and Personal Shopper Tab Switching', () => {
    const handlers = [
      rest.post(`*fetchPricingSnapshot`, (req, res, ctx) => res(ctx.status(200), ctx.json(fpsNew))),
      rest.post(`*processAcctInquiryTranDetails`, (req, res, ctx) =>
        res(ctx.status(200), ctx.json({
          data: {
            statusMessage: 'Success',
            uniqueKey: '1710886290738',
            pkSequence: null,
            errors: null,
            status: 1,
          },
        })),
      ),
    ];

    const server = setupServer(...handlers);
    beforeAll(() => server.listen());
    afterEach(() => {
      server.resetHandlers();
      delete window.mfe;
      jest.clearAllMocks();
      jest.clearAllTimers();
      jest.useRealTimers();
      Emitter.removeAllListeners();
    });
    afterAll(() => server.close());

    test('should set PERSONAL_SHOPPER_SKIPPED and emit combo event when a combo item is in cart', async () => {
      jest.useFakeTimers();
      
      const personalShopperTabCloseEvents = [];
      const acssSwitchTabEvents = [];

      const personalShopperListener = (data) => personalShopperTabCloseEvents.push(data);
      const acssListener = (data) => acssSwitchTabEvents.push(data);
      Emitter.on('PERSONAL_SHOPPER_TAB_CLOSE', personalShopperListener);
      Emitter.on('ACSS_SCM_SWITCH_TAB', acssListener);
      
      const setItemSpy = jest.spyOn(Storage.prototype, 'setItem');

      window.mfe = {
        isProspectNewCustomerTab: true,
        isProspectMontana: false,
        isProspectPersonalShopper: true, 
      };

      const mockFetchCartDetailsResult_Combo = {
        data: {
          data: {
            cart: {
              lineDetails: {
                lineInfo: [
                  { deviceTypeSelected: 'Smartphone' },
                  { deviceTypeSelected: 'Home Internet' }
                ]
              }
            }
          }
        }
      };

      sessionStorage.setItem('APP_PROPERTIES', JSON.stringify({
        enableFullBlownMfeNbsPosFFlag: 'TRUE',
        enableShareQuoteinAIQuoteFFlag: 'TRUE',
        montanaOfferEnableFFlag: 'TRUE',
      }));

      render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          FetchPricingSnapShotResult={fpsNew}
          fetchCartDetailsResult={mockFetchCartDetailsResult_Combo}
          setFPSProtectionData={setFPSProtectionData}
          customerBio={customerBio}
          mtnListPriceEdit={[]}
          isInDirect={false}
        />,
        { reducers: rootReducer, sagas: rootSaga }
      );

      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await waitFor(() => {
        expect(screen.getByTestId('footercomponentButton')).toBeInTheDocument();
      });

      const proceedButton = screen.getByTestId('footercomponentButton');
      fireEvent.click(proceedButton);

      expect(setItemSpy).toHaveBeenCalledWith('PERSONAL_SHOPPER_SKIPPED', 'Y');
      jest.advanceTimersByTime(1000);

      await waitFor(() => {
        expect(personalShopperTabCloseEvents.length).toBeGreaterThan(0);
      });

      expect(personalShopperTabCloseEvents[personalShopperTabCloseEvents.length - 1]).toEqual({
        type: 'SWITCH_TAB',
        targetTab: 'PERSONAL_SHOPPER_TAB_CLOSE',
        targetSubTab: 'NumberSelection',
      });
      
      expect(acssSwitchTabEvents.length).toBe(0);

      Emitter.off('PERSONAL_SHOPPER_TAB_CLOSE', personalShopperListener);
      Emitter.off('ACSS_SCM_SWITCH_TAB', acssListener);
      setItemSpy.mockRestore();
      jest.useRealTimers();
    });

    // ADD THIS TEST TO COVER THE ?? false
    test('should handle undefined lineInfo and trigger ?? false fallback', async () => {
      window.mfe = {
        isProspectNewCustomerTab: true,
        isProspectPersonalShopper: true,
      };

      // This mock specifically targets the ?? false condition
      const mockFetchCartDetailsResult_Undefined = {
        data: {
          data: {
            cart: {
              lineDetails: {
                lineInfo: undefined // This will make cartDetailsLineInfo?.some?.() return undefined
              }
            }
          }
        }
      };

      const personalShopperTabCloseEvents = [];
      const acssSwitchTabEvents = [];
      
      const personalShopperListener = (data) => personalShopperTabCloseEvents.push(data);
      const acssListener = (data) => acssSwitchTabEvents.push(data);
      
      Emitter.on('PERSONAL_SHOPPER_TAB_CLOSE', personalShopperListener);
      Emitter.on('ACSS_SCM_SWITCH_TAB', acssListener);

      render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          FetchPricingSnapShotResult={fpsNew}
          fetchCartDetailsResult={mockFetchCartDetailsResult_Undefined}
          setFPSProtectionData={setFPSProtectionData}
          customerBio={customerBio}
          mtnListPriceEdit={[]}
          isInDirect={false}
        />,
        { reducers: rootReducer, sagas: rootSaga }
      );

      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await waitFor(() => {
        expect(screen.getByTestId('footercomponentButton')).toBeInTheDocument();
      });

      const proceedButton = screen.getByTestId('footercomponentButton');
      fireEvent.click(proceedButton);

      // When lineInfo is undefined, the ?? false should be triggered
      await waitFor(() => {
        expect(personalShopperTabCloseEvents.length).toBeGreaterThan(0);
      });

      Emitter.off('PERSONAL_SHOPPER_TAB_CLOSE', personalShopperListener);
      Emitter.off('ACSS_SCM_SWITCH_TAB', acssListener);
    });

    test('should handle completely missing cart data', async () => {
      window.mfe = {
        isProspectNewCustomerTab: true,
        isProspectPersonalShopper: true,
      };

      render(
        <Footer
          isAIQuote
          deviceRecom={deviceRecommendations}
          setIsManualTriage={jest.fn()}
          setIsProceedToQuote={jest.fn()}
          triggerFPSCallback={jest.fn()}
          triggerRetrieveCart={jest.fn()}
          setTriggerProceedToQuote={setTriggerProceedToQuote}
          FetchPricingSnapShotResult={fpsNew}
          fetchCartDetailsResult={undefined} // No cart data at all
          setFPSProtectionData={setFPSProtectionData}
          customerBio={customerBio}
          mtnListPriceEdit={[]}
          isInDirect={false}
        />,
        { reducers: rootReducer, sagas: rootSaga }
      );

      Emitter.emit('AI_QUOTE_SUCCESS', true);
      await waitFor(() => {
        expect(screen.getByTestId('footercomponentButton')).toBeInTheDocument();
      });

      const proceedButton = screen.getByTestId('footercomponentButton');
      fireEvent.click(proceedButton);

      expect(proceedButton).toBeInTheDocument();
    });
    // Add these test cases to your Footer1.test.js file

test('should trigger ?? false when cartDetailsLineInfo is null', async () => {
    window.mfe = {
      isProspectNewCustomerTab: true,
      isProspectPersonalShopper: true,
    };
  
    // This will make cartDetailsLineInfo null, causing some?.() to return undefined
    const mockFetchCartDetailsResult_Undefined = {
      data: {
        data: {
          cart: {
            lineDetails: {
              lineInfo: null // This will trigger ?? false
            }
          }
        }
      }
    };
  
    const personalShopperTabCloseEvents = [];
    const acssSwitchTabEvents = [];
    
    const personalShopperListener = (data) => personalShopperTabCloseEvents.push(data);
    const acssListener = (data) => acssSwitchTabEvents.push(data);
    
    Emitter.on('PERSONAL_SHOPPER_TAB_CLOSE', personalShopperListener);
    Emitter.on('ACSS_SCM_SWITCH_TAB', acssListener);
  
    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={setTriggerProceedToQuote}
        FetchPricingSnapShotResult={fpsNew}
        fetchCartDetailsResult={mockFetchCartDetailsResult_Undefined}
        setFPSProtectionData={setFPSProtectionData}
        customerBio={customerBio}
        mtnListPriceEdit={[]}
        isInDirect={false}
      />,
      { reducers: rootReducer, sagas: rootSaga }
    );
  
    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await waitFor(() => {
      expect(screen.getByTestId('footercomponentButton')).toBeInTheDocument();
    });
  
    const proceedButton = screen.getByTestId('footercomponentButton');
    fireEvent.click(proceedButton);
  
    // When lineInfo is null, some() returns undefined, triggering ?? false
    // This should make isCombo = false and go to else path
    await waitFor(() => {
      expect(personalShopperTabCloseEvents.length).toBeGreaterThan(0);
    });
  
    expect(personalShopperTabCloseEvents[personalShopperTabCloseEvents.length - 1]).toEqual({
      type: 'SWITCH_TAB',
      targetTab: 'PERSONAL_SHOPPER_TAB_CLOSE',
    });
  
    expect(acssSwitchTabEvents[acssSwitchTabEvents.length - 1]).toEqual({
      type: 'SWITCH_TAB',
      targetTab: 'INSIDE_SALES_ASSIGNED_MTN_TAB',
    });
  
    Emitter.off('PERSONAL_SHOPPER_TAB_CLOSE', personalShopperListener);
    Emitter.off('ACSS_SCM_SWITCH_TAB', acssListener);
  });
  
  test('should trigger ?? false when cart structure is broken', async () => {
    window.mfe = {
      isProspectNewCustomerTab: true,
      isProspectPersonalShopper: true,
    };
  
    // This breaks the optional chaining earlier, causing the entire expression to be undefined
    const mockFetchCartDetailsResult_Undefined = {
      data: {
      }
    };
  
    const personalShopperTabCloseEvents = [];
    const acssSwitchTabEvents = [];
    
    const personalShopperListener = (data) => personalShopperTabCloseEvents.push(data);
    const acssListener = (data) => acssSwitchTabEvents.push(data);
    
    Emitter.on('PERSONAL_SHOPPER_TAB_CLOSE', personalShopperListener);
    Emitter.on('ACSS_SCM_SWITCH_TAB', acssListener);
  
    render(
      <Footer
        isAIQuote
        deviceRecom={deviceRecommendations}
        setIsManualTriage={jest.fn()}
        setIsProceedToQuote={jest.fn()}
        triggerFPSCallback={jest.fn()}
        triggerRetrieveCart={jest.fn()}
        setTriggerProceedToQuote={setTriggerProceedToQuote}
        FetchPricingSnapShotResult={fpsNew}
        fetchCartDetailsResult={mockFetchCartDetailsResult_Undefined}
        setFPSProtectionData={setFPSProtectionData}
        customerBio={customerBio}
        mtnListPriceEdit={[]}
        isInDirect={false}
      />,
      { reducers: rootReducer, sagas: rootSaga }
    );
  
    Emitter.emit('AI_QUOTE_SUCCESS', true);
    await waitFor(() => {
      expect(screen.getByTestId('footercomponentButton')).toBeInTheDocument();
    });
  
    const proceedButton = screen.getByTestId('footercomponentButton');
    fireEvent.click(proceedButton);
  
    await waitFor(() => {
      expect(personalShopperTabCloseEvents.length).toBeGreaterThan(0);
    });
  
    Emitter.off('PERSONAL_SHOPPER_TAB_CLOSE', personalShopperListener);
    Emitter.off('ACSS_SCM_SWITCH_TAB', acssListener);
  });
  
      test('should show device protection banner when linesWithoutProtection greater than 0 and isProspectNewCustomerTab or isProspectPersonalShopper are true', async () => {
        const personalShopperTabCloseEvents = [];
        const acssSwitchTabEvents = [];
  
        const personalShopperListener = (data) => personalShopperTabCloseEvents.push(data);
        const acssListener = (data) => acssSwitchTabEvents.push(data);
  
        Emitter.on('PERSONAL_SHOPPER_TAB_CLOSE', personalShopperListener);
        Emitter.on('ACSS_SCM_SWITCH_TAB', acssListener);
        const setProtectionBannerMock = jest.fn();
        window.mfe = {
          isProspectNewCustomerTab: true,
          isProspectMontana: false,
          isProspectPersonalShopper: true,
        };
  
        sessionStorage.setItem(
          'APP_PROPERTIES',
          JSON.stringify({
            enableFullBlownMfeNbsPosFFlag: 'TRUE',
            enableShareQuoteinAIQuoteFFlag: 'TRUE',
            montanaOfferEnableFFlag: 'TRUE',
          }),
        );
  
        render(
          <Footer
            isAIQuote
            deviceRecom={deviceRecommendations}
            setIsManualTriage={jest.fn()}
            setIsProceedToQuote={jest.fn()}
            triggerFPSCallback={jest.fn()}
            triggerRetrieveCart={jest.fn()}
            setTriggerProceedToQuote={setTriggerProceedToQuote}
            FetchPricingSnapShotResult={fpsNew}
            setFPSProtectionData={setFPSProtectionData}
            customerBio={customerBio}
            mtnListPriceEdit={[]}
            isInDirect={false}
            linesWithoutProtection={[{mtn:"newLines1"}]}
            setProtectionBanner={setProtectionBannerMock}
          />,
          {
            reducers: rootReducer,
            sagas: rootSaga,
          },
        );
  
        Emitter.emit('AI_QUOTE_SUCCESS', true);
        await waitFor(() => {
          const proceedButton = screen.getByTestId('footercomponentButton');
          expect(proceedButton).toBeInTheDocument();
        });
  
        const proceedButton = screen.getByTestId('footercomponentButton');
        fireEvent.click(proceedButton);
  
        await waitFor(() => {
            expect(setProtectionBannerMock).toHaveBeenCalledWith(true);
        });
      });
  

  });
};

Test(CHANNELS.OMNI_RETAIL);
Test(CHANNELS.OMNI_INDIRECT);