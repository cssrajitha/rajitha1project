import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import TimeoutManager from 'onevzsoemfecommon/TimeoutManager';
import { getAssistedCradlePropertyV2 } from 'onevzsoemfeframework/AssistedCradleService';
import Emitter from 'onevzsoemfeframework/Emitter';
import { parseInt, cloneDeep } from 'lodash';
import pako from 'pako';
import { Body, Title } from '@vds/typography';
import { Modal, ModalFooter, ModalBody, ModalTitle } from '@vds/modals';
import { useDispatch } from 'react-redux';
import * as appMessageActions from 'onevzsoemfecommon/AppMessageActions';
import { TextLinkCaret, Button } from '@vds/buttons';
import { Icon } from '@vds/icons';
import isEmpty from 'lodash/isEmpty';
import { isIpad, executeShellFunction } from 'onevzsoemfeframework/DomService';
import { getQueryParamByName, getUIContextPathBAU } from 'onevzsoemfecommon/Helpers';
import { formatCurrency } from 'onevzsoemfecommon/Helpers/validation';
import { sendCustomEvent } from 'onevzsoemfeframework/Tagging';
import { GetAppConfig } from 'onevzsoemfeframework/GetAppConfig';
import {
  useLazyProcessAcctInquiryTranDetailsQuery,
  useLazyCompareQuotesQuery,
  useLazyCaptureQuoteFeedbackQuery,
  useLazyRemoveSelectedLinesFromCartQuery,
  useLazyUpdateVisionRemarkQuery,
  useLazyRetrieveAEMInfoManagerDataQuery,
} from '../../modules/services/APIService/APIServiceHooks';
import ExpandFooter from './ExpandFooter';
// import fpsNew from './Mocks/FPSNEW.json';
import DotLoader from '../DotLoader/DotLoader';
import { requestBodyupdateRemark } from '../../modules/services/APIService/APIRequestBody';
import { useCradleState } from '../../utils/common';
import HomeInternetLiteModal from './Modals/HomeInternetLiteModal';
import CcdModal from '../LandingFooter/CcdModal';
import { FooterMessageContent } from '../AEMConstant/constant';
import './Footer.css';
// import { setTimeout } from 'timers/promises';

const FooterWrapper = styled.div`
  padding: 0.6rem;
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  max-width: 1133px;
  background-color: rgb(255, 255, 255);
  z-index: 1;
  bottom: 0;
  position: relative;
  width: 100%;
  background-color: #ffffff;
  border-top: 1px solid rgb(0, 0, 0);
  box-sizing: border-box;
  align-items: center;
`;
const ButtonWrapper = styled.div`
  display: flex;
  gap: ${({ shareQuoteEnabled }) => (shareQuoteEnabled ? '0.25rem' : '0.75rem')};
`;
const PromotionWrapper = styled.div`
  display: flex;
  gap: ${({ shareQuoteEnabled, isDfoSelected }) => {
    if (isDfoSelected && shareQuoteEnabled) {
      return '1rem';
    }
    if (shareQuoteEnabled) {
      return '1.5rem';
    }
    return '2rem';
  }};
  padding-left: ${({ shareQuoteEnabled, isDfoSelected }) => {
    if (isDfoSelected && shareQuoteEnabled) {
      return '0.5rem';
    }
    return shareQuoteEnabled ? '0.75rem' : '1rem';
  }};
  p {line-height: ${({ isDfoSelected }) => (isDfoSelected ? '1rem' : '1.125rem')};
`;
const DueWrapper = styled.div`
  cursor: pointer;
`;

function Footer({
  isAIQuote,
  isEditTradeIn,
  deviceRecom,
  isInsideSalesorCustomerService,
  redirectToFlexOrdering,
  triggerProceedToQuote,
  linesWithQuoteInCart,
  newLinesWithoutQuote,
  setTriggerProceedToQuote,
  setIsManualTriage,
  isManualTriageDone,
  channelInCreateCase,
  triggerFPSCallback,
  FetchPricingSnapShotResult,
  setMtnToBeSelectedWithoutGenratingQuote,
  setAssistedMtnFromAIQuote,
  createAiQuoteResCollection,
  inlineShowLoader,
  activeMtnValue,
  tradeDevicesInCart,
  tradeAddedOnLoad,
  aiquoteResponse,
  setFPSProtectionData,
  triggerRetrieveCart,
  billingSystem,
  setIsProceedToQuote,
  setlinesWithoutProtection = () => {},
  linesWithoutProtection,
  setProtectionBanner = () => {},
  isCollaborationStartedForRC = false,
  isFiosEnabled = false,
  isRCCart = false,
  fiosOrderDetails = '',
  fiosReferralIndirectFFlag = false,
  showPriceDetails,
  setShowPriceDetails = () => {},
  activeLinePriceTypeInCart,
  setTaggingPayload = () => {},
  setShowDownPayment = () => {},
  customerBio,
  mtnListPriceEdit,
  isInDirect,
  disableProceedToQuote,
  acknowledgedBYODConfirmDevice,
  activeLineInfoInCart,
  mandatoryNumberShareLines,
  setShowNumberShareVerifyBanner = () => {},
  fetchCartDetailsResult,
  fpfCheckState,
  idCheckState,
  qualifiedAddressVHI,
  setShowVMPWarningModal,
  proceedQuoteWithDeclineProtection,
  declinedProtectionAddedByReps,
}) {
  const dispatch = useDispatch();
  const [deviceRecocommendations, setDeviceRecocommendations] = useState([]);
  const [perkRecommendations, setPerkRecommendations] = useState([]);
  const [processAcctInquiryTranDetails, processAcctInquiryTranDetailsResult] =
    useLazyProcessAcctInquiryTranDetailsQuery();
  const [tranDetailsFromQuote, setTranDetailsFromQuote] = useState({});
  const [showLoader, setShowLoader] = useState(true);
  const [planRecocommendations, setPlanRecocommendations] = useState([]);
  const [expandFooter, setExpandFooter] = useState(false);
  const [selectedMtn, setSelectedMtn] = useState('');
  const [aiQuoteSuccess, setAiQuoteSuccess] = useState(false);
  const [exisitngServicesFromCustomer, setExisitngServices] = useState({});
  const [compareQuotes, compareQuotesResult] = useLazyCompareQuotesQuery();
  const [compareQuoteData, setCompareQuoteData] = useState({});
  const [feedBackCall] = useLazyCaptureQuoteFeedbackQuery();
  const [displayRemoveLinesPopUp, setDisplayRemoveLinesPopUp] = useState(false);
  const [newLinesWithoutQuoteInCart, setNewLinesWithOutQuoteInCart] = useState([]);
  const [removeSelectedLinesFromCart, removeSelectedLinesFromCartResult] = useLazyRemoveSelectedLinesFromCartQuery();
  // const [toggleStatus, setToggleStatus] = useState(true);
  const [updateVisionRemak, updateVisionRemakresult] = useLazyUpdateVisionRemarkQuery();
  const cradleState = useCradleState();
  const nbsFFlagState = cradleState?.data?.enableFullBlownMfeNbsPosFFlag === 'TRUE';
  const appPropertiesFromSessionStorage = sessionStorage.getItem('APP_PROPERTIES');
  const nbsFFlagSessionStorage = appPropertiesFromSessionStorage
    ? JSON.parse(appPropertiesFromSessionStorage)?.enableFullBlownMfeNbsPosFFlag === 'TRUE'
    : false;
  const enableFullBlownMfeNbsPosFFlag = nbsFFlagState || nbsFFlagSessionStorage;
  const enableShareQuoteinAIQuoteFFlag = appPropertiesFromSessionStorage
    ? JSON.parse(appPropertiesFromSessionStorage)?.enableShareQuoteinAIQuoteFFlag?.toUpperCase() === 'TRUE'
    : false;
  const fiosReferralOnRCFFlag = appPropertiesFromSessionStorage
    ? JSON.parse(appPropertiesFromSessionStorage)?.fiosReferralOnRCFFlag?.toUpperCase() === 'TRUE'
    : false;
  const aiQuoteFeedbackFFlag = appPropertiesFromSessionStorage
    ? JSON.parse(appPropertiesFromSessionStorage)?.aiQuoteFeedbackFFlag?.toUpperCase() === 'TRUE'
    : false;
  const showMultiDepletionInCartWarningFFlag = appPropertiesFromSessionStorage
    ? JSON.parse(appPropertiesFromSessionStorage)?.showMultiDepletionInCartWarningFFlag?.toUpperCase() === 'TRUE'
    : false;
  // const showPastDuePreBackOrderModalFFlag = appPropertiesFromSessionStorage
  //   ? JSON.parse(appPropertiesFromSessionStorage)?.showPastDuePreBackOrderModalFFlag?.toUpperCase() === 'TRUE'
  //   : false;
  const vhiLiteAckModalFFlag = appPropertiesFromSessionStorage
    ? JSON.parse(appPropertiesFromSessionStorage)?.vhiLiteAckModalFFlag?.toUpperCase() === 'TRUE'
    : false;

  const shareQuoteDesktopRetailFFlag = /true/i.test(getAssistedCradlePropertyV2(['shareQuoteDesktopRetailFFlag'])?.[0]);
  const shareQuoteDesktopIndirectFFlag = /true/i.test(
    getAssistedCradlePropertyV2(['shareQuoteDesktopIndirectFFlag'])?.[0],
  );
  const isAIQuoteInitModalEnabledFFlag = /true/i.test(getAssistedCradlePropertyV2(['showQuoteInitModalFFlag'])?.[0]);
  const cleanUpEmitterFFlag = /true/i.test(getAssistedCradlePropertyV2(['cleanUpEmitterFFlag'])?.[0]);
  const isAiQuoteVVCEnabledFFlag = /true/i.test(getAssistedCradlePropertyV2(['isAiQuoteVVCEnabledFFlag'])?.[0]);
  const aiQuoteVMPFFlag = /true/i.test(getAssistedCradlePropertyV2(['aiQuoteVMPFFlag'])?.[0]);
  const timeoutManager = new TimeoutManager({ fileName: 'Footer.js', enableFF: cleanUpEmitterFFlag });
  const [isPriorityMtn, setIsPriorityMtn] = useState([]);
  const [payloadForRC, setPayloadForRC] = useState({});
  const [showModalPastbalPreBackOrder, setShowModalPastbalPreBackOrder] = useState(false);
  const [segmentAndCloserDiscountText, setSegmentAndCloserDiscountText] = useState('');
  const [showHomeInternetLiteModal, setShowHomeInternetLiteModal] = useState(false);
  const [showByodDiscountModal, setShowByodDiscountModal] = useState(false);
  const [byodModalMessageType, setByodModalMessageType] = useState('default'); // 'default' or 'dppEup'
  const [showCcdModal, setShowCcdModal] = useState(false);
  const [ccdData, setCcdData] = useState({});
  const [retrieveAEMInfoManagerData] = useLazyRetrieveAEMInfoManagerDataQuery();
  const isFRP = activeLinePriceTypeInCart === 'MONTH_TO_MONTH';

  const isNewCustomer = getQueryParamByName('customerType')?.toUpperCase() === 'N';
  const montanaOfferEnableFFlag =
    JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.montanaOfferEnableFFlag?.toUpperCase() === 'TRUE';
  const aiQuoteD2DleadFFlag =
    JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.aiQuoteD2DleadFFlag?.toUpperCase() === 'TRUE';
  const montanaPriceBreakUpFixFFlag =
    JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.montanaPriceBreakUpFixFFlag?.toUpperCase() === 'TRUE';
  const aiQuoteProspectOffersFFlag =
    JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.aiQuoteProspectOffersFFlag?.toUpperCase() === 'TRUE';
  const personalShopperLineLevelFFlag =
    JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.personalShopperLineLevelFFlag?.toUpperCase() === 'TRUE';
  const byodPlusPlanFFlag =
    JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.byodPlusPlanFFlag?.toUpperCase() === 'TRUE';
  const byodFiveDollarPlanPOSFFlag =
    JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.byodFiveDollarPlanPOSFFlag?.toUpperCase() === 'TRUE';
  const byodPlusEUPSupressFFlag =
    JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.byodPlusEUPSupressFFlag?.toUpperCase() === 'TRUE';
  const newByodPlanDppEupFFlag =
    JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.newByodPlanDppEupFFlag?.toUpperCase() === 'TRUE';
  const byodUpgradeDQFixFFlag =
    JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.byodUpgradeDQFixFFlag?.toUpperCase() === 'TRUE';
  const appConfig = GetAppConfig();
  const montanaContent = appConfig?.messages?.montanaContent;

  const isD2DFlowAndFFlag = () => {
    const isD2DFlow = getQueryParamByName('orderChannelId')?.toUpperCase().includes('OMNI-D2D');
    return aiQuoteD2DleadFFlag && isD2DFlow;
  };
  const isShareToRCCTAEligible = () => {
    const isIpadEligible = isIpad() && enableShareQuoteinAIQuoteFFlag;
    const isDesktopEligible = shareQuoteDesktopRetailFFlag || shareQuoteDesktopIndirectFFlag;
    const isFlowIneligible = !isD2DFlowAndFFlag();
    return (isIpadEligible || isDesktopEligible) && isFlowIneligible;
  };
  // const handleToggleSavings = () => {
  //   setToggleStatus(!toggleStatus);
  // };

  const { byodPlanIDs = [], byodPromo = [], newByodPlanIds = [] } = appConfig?.messages?.dqContent || {};
  let byodPlanIdInCart = '';
  
  // Helper function to check BYOD plan match
  const checkByodPlanMatch = (line, planIds) => {
    const planIdMatch = line?.selectedPlan?.planId && planIds.includes(line.selectedPlan.planId);
    const promoIdMatch = line?.selectedPlan?.planDetails?.planPromotions?.promos?.some(promo => byodPromo?.includes(promo?.id)) || line?.addons?.some(addon => byodPromo?.includes(addon?.sorId));
    
    if (byodFiveDollarPlanPOSFFlag) {
      return planIdMatch && promoIdMatch;
    }
    return planIdMatch && line?.selectedPlan?.price?.discountedPrice === 0;
  };

  const hasByodSelected = FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.lines?.some(
    (line) => {
      const isMatch = checkByodPlanMatch(line, byodPlanIDs);
      if (isMatch) {
        byodPlanIdInCart = line.selectedPlan.planId;
      }
      return isMatch;
    }
  ) || false;

  // Check for newByodPlanIds with DPP+EUP scenario
  let hasNewByodSelected = false;
  let hasNewByodWithDppEup = false;
  
  /* istanbul ignore next */
  if (newByodPlanDppEupFFlag) {
    // Get lineInfo from aiquoteResponse which contains contractType and intentType
    const aiQuoteLineInfo = aiquoteResponse?.data?.service?.serviceBody?.serviceRequest?.customerInfo?.lineInfo || [];
    const updatedAiQuoteLineContractType = aiquoteResponse?.originalArgs?.body?.contractType;
    const updatedAiQuoteLineIntentType = aiquoteResponse?.originalArgs?.body?.intentType;
    
    /* istanbul ignore next */
    FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.lines?.forEach((line) => {
      // Check if plan matches newByodPlanIds
      const planIdMatch = line?.existingPlan?.planId && newByodPlanIds.includes(line.existingPlan.planId);
      const hasChange = !!(line?.selectedPlan?.planId && line?.selectedPlan?.planId !== line?.existingPlan?.planId);
      /* istanbul ignore else */
      if (planIdMatch) {
        // Get promo info from retrieveCart response
        const matchingCartLine = fetchCartDetailsResult?.data?.data?.cart?.lineDetails?.lineInfo?.find(
          (cartLine) => cartLine?.mobileNumber === line?.mtn
        );

        // Check if promo exists in otherPromotions with discountActionCd = 'END'
        /* istanbul ignore next */
        const hasEndingByodPromo = matchingCartLine?.serviceInfo?.otherPromotions?.[0]?.promos?.some(
          (promo) => byodPromo.includes(promo?.id) && promo?.discountActionCd === 'END'
        );
        
        /* istanbul ignore next */
        if (hasEndingByodPromo) {
          hasNewByodSelected = true;
          
          // Check if this specific line with newByodPlanIds has DPP+EUP in AI Quote response
          /* istanbul ignore next */
          const aiQuoteLine = aiQuoteLineInfo?.find(
            (aiLine) => aiLine?.mtn === line?.mtn || aiLine?.mtn === line?.dummyMtn
          );
          
          /* istanbul ignore next */
          if (((aiQuoteLine?.contractType === 'DPP' && aiQuoteLine?.intentType === 'EUP') || (byodUpgradeDQFixFFlag && updatedAiQuoteLineContractType === 'DPP' && updatedAiQuoteLineIntentType === 'EUP')) && !hasChange) {
            hasNewByodWithDppEup = true;
          }
        }
      }
    });
  }

  function checkByodPromoFromRetrieveCart(mtn) {
    const matchingCartLine = fetchCartDetailsResult?.data?.data?.cart?.lineDetails?.lineInfo?.find(cartLine => cartLine?.mobileNumber === mtn);
    if (matchingCartLine && Array.isArray(matchingCartLine?.serviceInfo?.otherPromotions)) {
      const promosArr = matchingCartLine.serviceInfo.otherPromotions?.[0]?.promos || [];
      return promosArr?.some(promo => byodPromo.includes(promo?.id));
    }
    return false;
  }

  const hasByodPlan = FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.lines
    ?.some(line => {
      const hasChange = line?.selectedPlan?.planId && line?.selectedPlan?.planId !== line?.existingPlan?.planId;
      const hasByodExistingPlan = line?.existingPlan?.planId && byodPlanIDs?.includes(line?.existingPlan?.planId);
      const byodZeroDollarPlan = line?.existingPlan?.price?.discountedPrice === 0;
      const byodPromoPresent = checkByodPromoFromRetrieveCart(line?.mtn);
      return hasChange && hasByodExistingPlan && (byodFiveDollarPlanPOSFFlag ? byodPromoPresent : byodZeroDollarPlan);
    }) || false;

  const hasUpgradedIncompatibleByodDevice =
    FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.lines?.some((line) => {
      const hasDeviceChange =
        line?.existingDevice?.sorId &&
        line?.selectedDevice?.sorId &&
        line?.existingDevice?.sorId !== line?.selectedDevice?.sorId;
      const hasByodExistingPlan =
        line?.existingPlan?.planId &&
        byodPlanIDs?.includes(line?.existingPlan?.planId);
      const discountCondition = line?.existingPlan?.price?.discountedPrice === 0;
      const byodPromoPresent = checkByodPromoFromRetrieveCart(line?.mtn);
      return hasDeviceChange && hasByodExistingPlan && (byodFiveDollarPlanPOSFFlag ? byodPromoPresent : discountCondition);
    }) || false;

  const handleExpand = () => {
    /* istanbul ignore else */
    if (!expandFooter) {
      const itemsPresentInCart = !isEmpty(FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.lineInfo);
      const request = {
        fullAccNumber: FetchPricingSnapShotResult?.data?.data?.flags?.fullAccountNumber,
        unifiedNbsFlag: isNewCustomer
          ? false
          : enableFullBlownMfeNbsPosFFlag ||
            FetchPricingSnapShotResult?.data?.data?.flags?.enableFullBlownMfeNbsPosFFlag,
      };
      const cartIds = [];
      /* istanbul ignore else */
      if (FetchPricingSnapShotResult?.data?.data?.flags?.cartId !== '') {
        cartIds.push(FetchPricingSnapShotResult?.data?.data?.flags?.cartId);
      }
      for (const i in cartIds) {
        const cartCount = parseInt(i) + 1;
        request[`cart${cartCount}`] = cartIds[i];
      }
      /* istanbul ignore else */
      if (request?.cart1 && itemsPresentInCart) {
        compareQuotes({ body: request });
      }
      const vzdl = window?.vzdl || {};
      /* istanbul ignore else */
      if (vzdl?.page) {
        vzdl.page.name = 'AI Quote';
        vzdl.page.detail = 'Monthly Estimate';
      }
      /* istanbul ignore else */
      if (vzdl?.event) vzdl.event.value = `event270=${estnewmonthly || 0},event269=${nextBillTotal || 0}`;
      /* istanbul ignore else */
      if (window?.vzdl?.txn) {
        window.vzdl.txn.nonRecurringPrice = currentmonthly ?? 0;
      }
      window.vzdl = vzdl;

      sendCustomEvent('openView', window?.vzdl);
    }
    setExpandFooter(!expandFooter);
  };

  useEffect(() => {
    /* istanbul ignore else */
    if (isFRP) {
      setShowPriceDetails(true);
    }
  }, [isFRP]);

  // useEffect(() => {
  //   if (expandFooter) {
  //     setToggleStatus(true);
  //   }
  // }, [expandFooter]);

  useEffect(() => {
    if (['rejected', 'fulfilled'].includes(compareQuotesResult?.status)) {
      console.log('compareQuotesResult', compareQuotesResult);
      const array = [];
      const quoteExists = compareQuotesResult?.data?.compareQuoteResponse?.find(
        (item) => item?.quoteLable === 'Quote 1',
      );
      /* istanbul ignore else */
      if (quoteExists) {
        FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.savings?.lineLevelSavings?.forEach((item) => {
          const dummyMtnFromLines = personalShopperLineLevelFFlag
            ? FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.lines?.find(
                (line) => line?.mtn === item?.mtn
              )?.dummyMtn
            : null;
          FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.lineInfo?.map(
            (e) =>
              e?.mobileNumber === item?.mtn &&
              e?.lineActivityType !== 'FEA' &&
              array.push({
                selected: item?.mtn === activeMtnValue,
                mtn: item?.mtn,
                currentMonthly: formatCurrency(
                  compareQuotesResult?.data?.compareQuoteResponse
                    ?.find((quote) => quote?.quoteLable === 'Current')
                    ?.dueMonthly?.lineLevelChargesDetails?.filter((linesItem) => linesItem?.mtn === item?.mtn)?.[0]
                    ?.lineLevelChargesTotal || '0.00',
                ),
                estNewMonthly: formatCurrency(
                  compareQuotesResult?.data?.compareQuoteResponse
                    ?.find((quote) => quote?.quoteLable === 'Quote 1')
                    ?.dueMonthly?.lineLevelChargesDetails?.filter((linesItem) =>
                      personalShopperLineLevelFFlag
                        ? linesItem?.mtn === item?.mtn || linesItem?.mtn === dummyMtnFromLines
                        : linesItem?.mtn === item?.mtn
                    )?.[0]
                    ?.lineLevelChargesTotal || '0.00',
                ),
                change:
                  (compareQuotesResult?.data?.compareQuoteResponse
                    ?.find((quote) => quote?.quoteLable === 'Quote 1')
                    ?.dueMonthly?.lineLevelChargesDetails?.filter((linesItem) =>
                      personalShopperLineLevelFFlag
                        ? linesItem?.mtn === item?.mtn || linesItem?.mtn === dummyMtnFromLines
                        : linesItem?.mtn === item?.mtn
                    )?.[0]
                    ?.lineLevelChargesTotal || '0.00') -
                  (compareQuotesResult?.data?.compareQuoteResponse
                    ?.find((quote) => quote?.quoteLable === 'Current')
                    ?.dueMonthly?.lineLevelChargesDetails?.filter((linesItem) =>
                      personalShopperLineLevelFFlag
                        ? linesItem?.mtn === item?.mtn || linesItem?.mtn === dummyMtnFromLines
                        : linesItem?.mtn === item?.mtn
                    )?.[0]
                    ?.lineLevelChargesTotal || '0.00'),
                totalSavings: formatCurrency(item?.totalLineSavings || '0.00'),
                savingsBreakup: item?.savingsList?.map((list) => ({
                  name: list?.itemName,
                  price: `${formatCurrency(list?.monthlySavingAmount || '0.00')}`,
                })),
              }),
          );
        });
        setCompareQuoteData(array);
      }
    }
  }, [compareQuotesResult?.status]);

  console.log('selectedMtn', selectedMtn);
  const lineInfoObj = FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.lineInfo?.filter(
    (item) => item?.mobileNumber === activeMtnValue,
  )?.[0]?.itemsInfo;
  const cartItemsForLine = lineInfoObj?.[0]?.cartItems?.cartItem ?? [];
  const deviceItemInCartForLine =
    cartItemsForLine?.[0] && cartItemsForLine.filter((item) => item?.cartItemType === 'DEVICE')?.[0];

  const isDfoAvailable =
    (cartItemsForLine?.[0] &&
      cartItemsForLine.filter((item) => item?.priceType === 'MONTH_TO_MONTH' && item?.isDfoSelected)) ||
    [];

  const checkIsDfoSelected = () => isDfoAvailable && isDfoAvailable?.length > 0 && isAiQuoteVVCEnabledFFlag;
  const isDfoSelected = checkIsDfoSelected();
  const lineInfoInCart = fetchCartDetailsResult?.data?.data?.cart?.lineDetails?.lineInfo;
  const getDepletionTypeFromVHI = lineInfoInCart
    ?.filter((item) => ['AAL_5G', 'AAL_LTE', 'NSE_5G', 'NSE_LTE'].includes(item?.lineActivityType))
    ?.find((item) => item?.itemsInfo?.[0]?.depletionType)?.itemsInfo?.[0]?.depletionType;

  const preOrderInCart = lineInfoInCart
    ?.flatMap((item) => item?.itemsInfo?.[0]?.cartItems?.cartItem || [])
    ?.some((cartItem) => cartItem?.cartItemType === 'DEVICE' && cartItem?.inventory?.isPreOrder);

  const backOrderWithoutISPUIncart = lineInfoInCart
    ?.flatMap((item) => (!item?.ispuItem && item?.itemsInfo?.[0]?.cartItems?.cartItem) || [])
    ?.some((cartItem) => cartItem?.cartItemType === 'DEVICE' && cartItem?.inventory?.isBackorder);

  const pastDueInCartForLine = lineInfoInCart
    ?.flatMap((item) => item?.itemsInfo?.[0]?.cartItems?.cartItem || [])
    ?.some((cartItem) => cartItem?.cartItemType === 'PASTDUE');

  const getCartLines = () => {
    const cartLines = [];
    FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.lineInfo?.forEach((line) => {
      const eachLine = FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.lines.filter(
        (item) => item?.mtn === line?.mobileNumber,
      );
      if(eachLine?.[0]){
        cartLines.push({...eachLine?.[0], lineActivityType: line?.lineActivityType});
      }      
    });

    return cartLines;
  }

  const triggerTranDetails = () => {
    const filterLineDetailsFromFPS = FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.lines.filter(
      (item) => item.mtn === tranDetailsFromQuote?.mtn,
    )?.[0];
    // const filteredRealMtns =
    //   FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.lines?.filter(
    //     (item) => item?.mtn === tranDetailsFromQuote?.mtn,
    //   ) ?? [];
    // const offerListFromAIQuote =
    //   createAiQuoteResCollection?.[0]?.offerRecommendations?.filter((item) => item?.rank === '1') ?? [];
    // const existingPlan = filteredRealMtns?.[0]?.existingPlan?.displayName;
    // const existingDevice = filteredRealMtns?.[0]?.existingDevice?.displayName;
    // const existingSorId = filteredRealMtns?.[0]?.existingDevice?.sorId;
    // const perkListFilter = filteredRealMtns?.[0]?.addons?.filter(
    //   (item) => item?.isUserSelected && item?.isPerk && item?.actionIndicator === 'A',
    // );
    // const selectedPlan =
    //   FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.lines?.filter(
    //     (item) => item?.mtn === tranDetailsFromQuote?.mtn,
    //   ) ?? [];
    // const typeOfDevice = deviceRecocommendations?.devices?.filter((item) => item.rank === '1') ?? [];
    // const lineActivityType = createAiQuoteResCollection?.[0]?.intentType;
    // const accessoryList =
    //   FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.lineInfo?.[0]?.itemsInfo?.[0]?.cartItems?.cartItem?.filter(
    //     (item) => item.cartItemType === 'ACCESSORY',
    //   ) ?? [];
    // const addedDevice =
    //   FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.lineInfo?.[0]?.itemsInfo?.[0]?.cartItems?.cartItem?.filter(
    //     (item) => item.cartItemType === 'DEVICE',
    //   ) ?? [];

    // const recommendAccessory = createAiQuoteResCollection?.[0]?.accessoriesRecommendation?.accessories;
    const priorMtn = isPriorityMtn?.some((item) => item?.isPriorityMtn === true);
    console.log(priorMtn);
    // const selectedDeviceFromFPS = filterLineDetailsFromFPS?.selectedDevice?.sorId ?? 0;
    // const selectedPlanFromFPS = filterLineDetailsFromFPS?.selectedPlan?.planId ?? 0;
    // const tradeInDeviceFromFPS =
    // FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.tradeInDetail?.tradeInItems?.[0]?.recycleDeviceSku ?? 0;
    const perkRecomList = [];
    perkRecommendations?.perks
      ?.filter((item) => item.recomOrder === '1')
      ?.sort((a, b) => a.rank - b.rank)
      ?.slice(0, 2)
      ?.forEach((perk) => perkRecomList.push(perk?.spoId));
    // const perkRecomListFormatted = perkRecomList?.[0] ? perkRecomList.join(',') : 0;
    const selectedPerksInFPS = filterLineDetailsFromFPS?.addons?.filter((item) => item?.isPerk) ?? [];
    const selectedPerkSposInFPS = [];
    selectedPerksInFPS?.forEach((perk) => selectedPerkSposInFPS.push(perk?.sorId));
    // const selectedPerksInFPSFormatted = selectedPerkSposInFPS?.[0] ? selectedPerkSposInFPS.join(',') : 0;
    const quoteType = linesWithQuoteInCart?.length > 1 ? `ML${linesWithQuoteInCart?.length}` : 'SL';
    let isConnectedDevicePresent = 'N';
    let isAALPresent = 'N';
    if (createAiQuoteResCollection?.filter((line) => line?.intentType === 'AAL')?.[0]) {
      isAALPresent = 'Y';
    }
    if (
      createAiQuoteResCollection?.filter(
        (line) => line?.propositionName?.replace(/\s/g, '')?.toLowerCase() === 'connecteddevices',
      )?.[0]
    ) {
      isConnectedDevicePresent = 'Y';
    }
    const recommendedPlan = planRecocommendations?.plans?.[0]?.planDescription ?? '';
    console.log(recommendedPlan);
    const cartLines = [];
    FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.lineInfo?.forEach((line) => {
      const eachLine = FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.lines.filter(
        (item) => item?.mtn === line?.mobileNumber,
      );
      cartLines.push(eachLine);
    });

    const accountLevelProtection = FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.shared?.addons?.filter(
      (item) => item?.protection === true,
    );

    const auditArray = [`${tranDetailsFromQuote?.cartId ?? ''}`];
    cartLines?.forEach((objArray) => {
      const obj = objArray[0];

      const addedPerk1 =
        obj?.addons?.filter((item) => item?.isPerk && item?.actionIndicator === 'A' && item.isUserSelected)?.[0]
          ?.sorId ?? '';
      const addedPerk2 =
        obj?.addons?.filter((item) => item?.isPerk && item?.actionIndicator === 'A' && item.isUserSelected)?.[1]
          ?.sorId ?? '';
      const lineLevelProtection = obj?.addons?.filter((item) => item?.protection)?.[0] ?? '';

      auditArray.push(
        `${obj?.mtn ?? ''},${obj?.dummyMtn ?? ''},${obj?.flags?.lineActivityType ?? ''},${obj?.appliedOffers?.appliedOffersList?.[0]?.offerId ?? ''}, ${(obj?.appliedOffers?.appliedOffersList?.[0]?.offerType || obj?.appliedOffers?.appliedOffersList?.[0]?.offerSubType) ?? ''},${obj?.planPriceFromNBS?.planId ?? ''},${obj?.selectedDevice?.sorId ?? ''}, ${obj?.selectedDevice?.displayName ?? ''}, ${obj?.accessories?.[0]?.sorId ?? ''},${obj?.accessories?.[1]?.sorId ?? ''},${obj?.accessories?.[2]?.sorId ?? ''},${obj?.accessories?.[3]?.sorId ?? ''},${addedPerk1},${addedPerk2},${lineLevelProtection?.sorId || ''},${lineLevelProtection?.skuName || ''}, ${lineLevelProtection?.actionIndicator || ''},${accountLevelProtection?.[0]?.sorId || ''},${accountLevelProtection?.[0]?.skuName || ''},${accountLevelProtection?.[0]?.actionIndicator || ''}${'|'}`,
      );
    });
    const auditFinalData = auditArray.join();
    const estimatedTotal =
      FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.totals?.grandTotalDueMonthly?.estimatedTotal;
    const noOfLines = FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.lines?.length;
    const reqBody = {
      uniqueKey: Date.now(),
      locationCode: tranDetailsFromQuote?.locationCode,
      orderNum: '',
      orderType: '',
      tranType: 'AIQuote',
      channelId: channelInCreateCase,
      customerID: tranDetailsFromQuote?.customerID,
      mtn: tranDetailsFromQuote?.mtn,
      billAccountNumber: tranDetailsFromQuote?.billAccountNumber,
      repId: tranDetailsFromQuote?.loggedInUser,
      custType: tranDetailsFromQuote?.custType,
      orderStatus: '',
      orderZipCode: '',
      orderState: '',
      transactionInitChannel: channelInCreateCase,
      orderCompletionChannel: channelInCreateCase,
      orderPaymentMethod: '',
      orderPaymentAmount: '',
      orderEcpdId: '',
      platform: isIpad() ? 'Ipad' : 'Desktop',
      appVersion: 'POS',
      remark: `AIQuote transaction details - ${quoteType},${isConnectedDevicePresent},${isAALPresent}, ${estimatedTotal}, ${noOfLines}`,
      tranDetailSJSON: auditFinalData,
    };
    processAcctInquiryTranDetails({
      body: reqBody,
      showErrorBanner: false,
    });
  };

  const addPersonalShopperTaggingFields = (vzdlObj) => {
    const personalShopperFlowTaggingFFlag =
      JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.personalShopperFlowTaggingFFlag?.toUpperCase() === 'TRUE';

    if (personalShopperFlowTaggingFFlag) {
      return {
        ...vzdlObj,
        flow: window?.vzdl?.page?.flow,
        subFlow: window?.vzdl?.page?.subFlow,
      };
    }
    return vzdlObj;
  };
  const triggerRedirectionToOrdering = (processAcctInquiryTranDetailsResultValue) => {
    console.log('inside redirect to ordering', processAcctInquiryTranDetailsResultValue);
    console.log(
      'processAcctInquiryTranDetailsResultValue?.originalArgs?.body',
      processAcctInquiryTranDetailsResultValue?.originalArgs?.body,
    );

    const tagProducts = window?.cartProducts?.map(({ mtn, current }) => {
      const lineProducts = current?.reduce((items, { id, name, lineHash, category }) => {
        if (category === 'Trade-Device') {
          items.push({
            id,
            name,
            lineHash,
          });
        }
        return items;
      }, []);
      return { mtn, products: lineProducts };
    });
    // const extractedProductNodes = tagProducts?.map(({ id, name, lineHash, orderType }) => ({
    //   id,
    //   name,
    //   lineHash,
    //   orderType,
    // }));
    const vzdlForOrdering = {
      user: {
        account: window?.vzdl?.user?.account,
        id: window?.vzdl?.user?.id,
        authType: window?.vzdl?.user?.authType,
        authStatus: window?.vzdl?.user?.authStatus,
        customerRole: window?.vzdl?.user?.customerRole,
        customerType: window?.vzdl?.user?.customerType,
        numberOfLines: window?.vzdl?.user?.numberOfLines,
        tenure: window?.vzdl?.user?.tenure,
        zip: window?.vzdl?.user?.zip,
      },
      agentRole: window?.vzdl?.txn?.agentRole,
      autoPay: window?.vzdl?.txn?.autoPay,
      product: tagProducts,
    };

    const updatedVzdlForOrdering = addPersonalShopperTaggingFields(vzdlForOrdering);
    const compressedTagData = pako.deflate(JSON.stringify(updatedVzdlForOrdering), { to: 'string' }); // compressing data using pako
    const binaryString = String.fromCharCode.apply(null, compressedTagData); // converting the Uint8Array into binary string
    const encodedTagData = btoa(binaryString); // passing binarydata to btoa method

    const location = sessionStorage?.getItem('location') || localStorage?.getItem('locationCode');
    let urlRoute = `${window.location.protocol}//${window.location.host}${getUIContextPathBAU()}/landing.html?isRCCart=${isRCCart}&aiTagData=${encodeURIComponent(encodedTagData)}&locationCode=${location}&fpfCheck=${fpfCheckState}&idCheck=${idCheckState}&fiosOrderDetails=${fiosOrderDetails}&fiosReferralIndirectFFlag=${fiosReferralIndirectFFlag}`;
    if (fiosReferralOnRCFFlag && isFiosEnabled) {
      urlRoute = `${window.location.protocol}//${window.location.host}${getUIContextPathBAU()}/landing.html?isRCCart=${isRCCart}&fiosEnabled=${isFiosEnabled}&aiTagData=${encodeURIComponent(encodedTagData)}&locationCode=${location}&fpfCheck=${fpfCheckState}&idCheck=${idCheckState}&fiosOrderDetails=${fiosOrderDetails}&fiosReferralIndirectFFlag=${fiosReferralIndirectFFlag}`;
    }
    if (isNewCustomer) {
      urlRoute += window.location.search.replace('?', '&');
    }

    const aiQuoteCartData = JSON.stringify(processAcctInquiryTranDetailsResultValue?.originalArgs?.body ?? {});
    if (isIpad()) {
      const aiQuoteCartParam = {
        key: 'AI_QUOTE_CART',
        value: aiQuoteCartData,
      };
      const shellParams = {
        name: 'order',
        path: '',
        replace: 'true',
        params: `rawurl:${urlRoute}`,
      };
      const shellParamsForRC = { title: 'ORDER-REVIEW-STARTED', description: '' };
      const comboParams = {
        params: [
          { class: 'SharedMemory', functionName: 'setData', params: aiQuoteCartParam },
          { class: 'Shell', functionName: 'showScreen', params: shellParams },
        ],
      };
      if (isCollaborationStartedForRC) {
        comboParams?.params?.push({ class: 'Shell', functionName: 'sendSSEMessage', params: shellParamsForRC });
      }
      executeShellFunction('Shell', 'executeShellFunctions', 'none', comboParams);
    } else {
      console.log('in desktop ordering redirect');
      sessionStorage.setItem('AI_QUOTE_CART', aiQuoteCartData);
      try {
        if (isInsideSalesorCustomerService) {
          redirectToFlexOrdering();
        } else {
          const message = {
            iframe: 'order',
            path: '',
            replace: true,
            url: urlRoute,
          };
          const target = window.parent;
          target.postMessage(message, window.parent.location.origin);
        }
      } catch (e) {
        console.log(`Unable to redirect!${e}`);
      }
    }
  };

  const getRemarkText = () => {
    let remarkText = '';
    FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.lines?.forEach((line) => {
      line?.appliedOffers?.appliedOffersList?.forEach((i) => {
        /* istanbul ignore else */
        if (i?.description?.toUpperCase()?.includes('RESTRICTED')) {
          remarkText += ` MTN: ${line?.mtn} OfferId: ${i?.offerId} Offers Accepted: ${i?.description} `;
        }
      });
    });
    if (remarkText?.length > 0) {
      const remarkTS = `${new Date()} Personal Shopper flow : Complete. `;
      return remarkTS + remarkText;
    }
    return '';
  };

  useEffect(() => {
    if (newLinesWithoutQuoteInCart?.length === 0 && removeSelectedLinesFromCartResult?.fulfilledTimeStamp) {
      /* Redirect to flex after all new lines without quote are removed from cart */
      handleProceedToOrder();
    }
  }, [newLinesWithoutQuoteInCart?.length]);

  useEffect(() => {
    const linesArray = [];
    if (newLinesWithoutQuote?.length > 0) {
      newLinesWithoutQuote?.forEach((line) => {
        linesArray.push(line?.mtn);
        setNewLinesWithOutQuoteInCart(linesArray);
      });
    } else {
      setNewLinesWithOutQuoteInCart([]);
    }
  }, [newLinesWithoutQuote?.length]);

  useEffect(() => {
    if (['rejected', 'fulfilled'].includes(processAcctInquiryTranDetailsResult?.status)) {
      if (getRemarkText()?.length > 0) {
        const reqBody = {
          ...requestBodyupdateRemark,
          mdn: tranDetailsFromQuote?.mtn,
          location: tranDetailsFromQuote?.locationCode,
          contactName: tranDetailsFromQuote?.loggedInUser,
          remarkText: getRemarkText(),
          customerId: tranDetailsFromQuote?.customerID,
          billingSystem: billingSystem === 'VN' ? 'VISION_NORTH' : 'VISION_EAST',
          billAccountNumber: tranDetailsFromQuote?.billAccountNumber,
        };
        updateVisionRemak({ body: reqBody, customHeaders: { flowName: 'AIQuote' }, spinner: false });
      } else {
        timeoutManager.scheduleTimeout(() => {
          triggerRedirectionToOrdering(processAcctInquiryTranDetailsResult);
        }, 2000);
      }
    }
    return () => {
      timeoutManager.clearAllTimeouts();
    };
  }, [processAcctInquiryTranDetailsResult]);

  useEffect(() => {
    if (['rejected', 'fulfilled'].includes(updateVisionRemakresult?.status)) {
      timeoutManager.scheduleTimeout(() => {
        triggerRedirectionToOrdering(processAcctInquiryTranDetailsResult);
      }, 2000);
    }
    return () => {
      timeoutManager.clearAllTimeouts();
    };
  }, [updateVisionRemakresult?.status]);

  useEffect(() => {
    if (['fulfilled'].includes(removeSelectedLinesFromCartResult?.status)) {
      triggerRetrieveCart();
      setDisplayRemoveLinesPopUp(false);
      setNewLinesWithOutQuoteInCart([]);
    }
    if (['rejected'].includes(removeSelectedLinesFromCartResult?.status)) {
      dispatch(
        appMessageActions.addAppMessage(
          'Unable to remove the selected line(s) from cart, please try again.',
          'error',
          true,
          true,
        ),
      );
    }
  }, [removeSelectedLinesFromCartResult?.status]);

  const removeNewLinesWithoutQuote = (lines) => {
    const linesArray = [];
    lines?.forEach((line) => {
      const lineObj = {};
      lineObj.mtn = line;
      linesArray.push(lineObj);
    });
    const reqBody = {
      cartInfo: {
        processStep: 'ShoppingCart',
        intendType: isNewCustomer ? 'NSE' : 'AAL',
      },
      data: { lines: linesArray },
    };
    removeSelectedLinesFromCart({ body: reqBody, customHeaders: { flowName: 'AIQuote' }, showErrorBanner: false });
  };

  const setOffersAndNoOfLines = () => {
    const montanaOffersTaggingFFlag = /true/i.test(
      JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.montanaOffersTaggingFFlag,
    );
    /* istanbul ignore else */
    if (
      montanaOfferEnableFFlag &&
      montanaOffersTaggingFFlag &&
      window?.vzdl?.page?.name?.toUpperCase() === 'AI QUOTE' &&
      isNewCustomer
    ) {
      const numberOfLines =
        FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.savings?.lineLevelSavings?.filter(
          (lineSaving) => lineSaving?.savingsList?.length > 0,
        ).length || 0;
      const ecpdType = FetchPricingSnapShotResult?.data?.data?.ecpdType
        ? `ECPD_${FetchPricingSnapShotResult.data.data.ecpdType}`
        : '';
      const autoPayEnabled = FetchPricingSnapShotResult?.data?.data?.isAutoPayEnabled ? 'APO' : '';
      const betterDealSorIds =
        FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.shared?.addons
          ?.map((addon) => addon.sorId)
          ?.join('|') || '';
      const MoreOfferSPOIds =
        FetchPricingSnapShotResult?.data?.data?.subAccounts
          ?.flatMap((subAccount) =>
            subAccount?.lines?.flatMap((line) =>
              line?.appliedOffers?.appliedOffersList?.map((offer) => offer?.offerId),
            ),
          )
          ?.filter(Boolean)
          ?.join('|') || '';
      const combinedOfferIds = Array.from(
        new Set([ecpdType, autoPayEnabled, betterDealSorIds, MoreOfferSPOIds].filter(Boolean).join('|').split('|')),
      ).join('|');
      const vzdl = window?.vzdl;
      vzdl.user = vzdl?.user || {};
      vzdl.target = vzdl?.target || {};
      vzdl.user.numberOfLines = numberOfLines > 0 ? numberOfLines : 1;
      vzdl.target.offer = combinedOfferIds;
      window.vzdl = vzdl;
      const sessionStorageOfferIds = Array.from(
        new Set([ecpdType, autoPayEnabled, MoreOfferSPOIds].filter(Boolean).join('|').split('|')),
      ).join('|');
      sessionStorage.setItem('montanaOfferList', sessionStorageOfferIds);
    }
  };

  const promoFromPromotionTab = () => {
    const promotionOfferTaggingFFlag = /true/i.test(JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.promotionOfferTaggingFFlag);
     /* istanbul ignore else */
    if (promotionOfferTaggingFFlag) {
      sessionStorage.setItem('offerFromAIQuote', window?.vzdl?.target?.offer ?? '');
    }
  }
  const setProductIdFromDepletion = () => {
    /* istanbul ignore else */
    if (!getDepletionTypeFromVHI || !qualifiedAddressVHI?.cbandBundle?.length) {
      return;
    }
    const bundleType = getDepletionTypeFromVHI === 'O' ? 'p' : 's';
    const productId = qualifiedAddressVHI?.cbandBundle?.find((item) => item?.type === bundleType)?.id;
    /* istanbul ignore else */
    if (productId) {
      sessionStorage.setItem('productIdFromPS', productId);
      localStorage.setItem('productIdFromPS', productId);
    }
  };

  // showPastDuePreBackOrderModalFFlag removed as part of cleanup
  const hasPastDueWithPreOrBackOrder = () => pastDueInCartForLine && (preOrderInCart || backOrderWithoutISPUIncart);
  const checkDfoItemInCartForNonVZCCHolder = () => {
    const personalShopperVVCModalFFlag =
      /true/i.test(JSON.parse(sessionStorage.getItem('APP_PROPERTIES'))?.personalShopperVVCModalFFlag) ||
      customerBio?.featureFlags?.personalShopperVVCModalFFlag;
    if (customerBio?.isAccountVZCCHolder === false && isDfoAvailable.length > 0 && personalShopperVVCModalFFlag) {
      sessionStorage.setItem('isDFOItemInCartFromPSNCHFlow', true);
    }
  };

  const checkForPastDueWithPreOrBackOrder = () => {
    if (hasPastDueWithPreOrBackOrder()) {
      setShowModalPastbalPreBackOrder(true);
      return true;
    }
    return false;
  };

  const checkForEUPLinesWithDeclineProtection = () => {
    const cartLines = getCartLines();

    const checkDeclineProtection = (addon) => {
      const skuName = addon?.skuName?.toUpperCase();
      return skuName?.includes('DECLINE DEVICE PROTECTION');
    };

    const getRepDeclinedProtectionForLine = (mtn) => {
      const declinedProtection = declinedProtectionAddedByReps?.filter(item => item?.isRepDeclinedProtection && item?.mtn === mtn);
      return declinedProtection?.length > 0;
    }

    const linesWithExistingDeclineProtection = [];

    cartLines.forEach((line) => {
      if (line?.lineActivityType === 'EUP') {
        line.addons?.forEach((addon) => {
          if (
            (addon?.actionIndicator?.toUpperCase() === 'Z' ||
              (addon?.actionIndicator?.toUpperCase() === 'A' && !getRepDeclinedProtectionForLine(line?.mtn))) &&
            checkDeclineProtection(addon) &&
            addon?.protection
          ) {          
            linesWithExistingDeclineProtection.push(line);
          }
        });
      }
    });

    if (aiQuoteVMPFFlag && linesWithExistingDeclineProtection?.length > 0 && !proceedQuoteWithDeclineProtection) {
      setShowVMPWarningModal(true);
      return true;
    }
    return false;
  };

  const handleNewLinesWithoutQuote = () => {
    setDisplayRemoveLinesPopUp(true);
    const vzdl = window?.vzdl || {};
    /* istanbul ignore else */
    if (vzdl?.page) {
      vzdl.page.detail = 'newLine_InQuote';
    }
    sendCustomEvent('openView', window?.vzdl);
  };

  const checkNoTradeEligibility = () => {
    const isNoTradeEligible =
      FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.tradeInDetail?.tradeInItems?.some(
        (device) => device?.appliedPrice === '0.00',
      );

    if (isNoTradeEligible) {
      const NoTradeEligibleMsg = `The device you are trading has $0.00 value and is not recognized as eligible for a promotion. Do not submit this trade unless it should qualify for promotion based on an eligible purchase within the previous 30 days. $0 trade orders will also require Promo Correction Application to add an eligible trade promotion`;
      dispatch(appMessageActions.addAppMessage(NoTradeEligibleMsg));
      return true;
    }
    return false;
  };

  const sendFeedbackRequest = () => {
    const request = {
      service: cloneDeep(aiquoteResponse?.data?.service),
    };
    /* istanbul ignore else */
    if (request?.service?.serviceBody?.serviceRequest?.customerInfo?.lineInfo[0]?.mtn?.includes('newLine')) {
      const requestMtn = request.service.serviceBody.serviceRequest.customerInfo.lineInfo[0]?.mtn;
      const activeLine = FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.lines?.filter(
        (line) => line?.mtn === requestMtn,
      )?.[0];
      request.service.serviceBody.serviceRequest.customerInfo.lineInfo[0].mtn = activeLine?.dummyMtn ?? activeMtnValue;
    }
    /* istanbul ignore else */
    if (request?.service && !aiQuoteFeedbackFFlag) {
      feedBackCall({
        body: request,
        customHeaders: { flowName: 'AIQuote' },
        spinner: false,
        showErrorBanner: false,
      });
    }
  };

  const checkForManualTriageAndProtection = () => {
    setTriggerProceedToQuote(false);
    setIsManualTriage(false);
    const tradeMDNs = tradeDevicesInCart?.[0] && tradeDevicesInCart.map((device) => device?.tradeDeviceMDN);
    const manualTriageMDNs =
      (tradeMDNs?.[0] &&
        tradeAddedOnLoad?.[0] &&
        tradeAddedOnLoad?.filter((device) => tradeMDNs.includes(device?.tradeDeviceMDN))) ||
      [];

    if (linesWithoutProtection?.length > 0) {
      setProtectionBanner(true);
    }

    if (manualTriageMDNs?.[0]) {
      setIsManualTriage(true);
    }

    if (mandatoryNumberShareLines?.length > 0) {
      setShowNumberShareVerifyBanner(true);
    }

    return {
      shouldProceed:
        linesWithoutProtection?.length === 0 &&
        manualTriageMDNs?.length === 0 &&
        mandatoryNumberShareLines?.length === 0,
    };
  };

  const setupTaggingAndTriggerTranDetails = () => {
    const vzdl = window?.vzdl || {};
    /* istanbul ignore else */
    const hasConnectedDevices =
      linesWithQuoteInCart?.filter(
        (item) => item.deviceCategoryName === 'SmartWatch' || item.deviceCategoryName === 'Tablets',
      ).length > 0;
    const hasAAL = linesWithQuoteInCart?.filter((item) => item.lineActivityType?.includes('AAL'))?.length > 0;
    const hasEUP = linesWithQuoteInCart?.filter((item) => item.lineActivityType?.includes('EUP'))?.length > 0;
    if (vzdl?.event) vzdl.event.value = 'scAdd';
    /* istanbul ignore else */
    if (vzdl?.page) vzdl.page.throttle = 'MFE';
    /* the following existing code not covered previously */
    /* istanbul ignore next */
    if (vzdl?.txn && hasConnectedDevices && hasAAL && hasEUP) {
      vzdl.txn.orderType = 'EUP+AAL';
    }
    window.vzdl = vzdl;
    /* the following existing code not covered previously */
    /* istanbul ignore next */
    if (window?.vzdl?.txn?.product) {
      const allCartProducts =
        window?.cartProducts?.reduce((items, line) => [...items, ...(line?.current || [])], []) || [];
      const cartProducts = allCartProducts?.map((item) => {
        if (item.type === 'deviceProtection') {
          const { type, ...rest } = item;
          return rest;
        }
        return item;
      });

      let customerProtectionLines = [];
      const linesInCart = window.cartProducts?.map((item) => String(item.mtn));
      const multiProtectionExist = cartProducts.find((item) => item?.id === '2663');
      /* istanbul ignore else */
      if (multiProtectionExist) {
        customerProtectionLines = miniCartItems?.reduce((protectionItems, item) => {
          const lineItemFromCustBio = customerBio?.lineLevelInfo?.filter(
            (lineInfo) => lineInfo.mtn === item.mtn,
          )?.[0];
          if (!linesInCart?.includes(item.mtn)) {
            protectionItems.push({
              ...multiProtectionExist,
              lineHash: lineItemFromCustBio?.hashedMtn,
            });
          }
          return protectionItems;
        }, []);
      }
      window.vzdl.txn.product.current = [...customerProtectionLines, ...cartProducts];
    }
    setOffersAndNoOfLines();
    promoFromPromotionTab();
    sendCustomEvent('AddtoCart', window?.vzdl);
    triggerTranDetails();
  };

  const handleProceedToOrder = () => {
    checkDfoItemInCartForNonVZCCHolder();

    if (isAIQuote) {
      setProductIdFromDepletion();

      if (checkForPastDueWithPreOrBackOrder()) {
        return true;
      }

      if (checkForEUPLinesWithDeclineProtection()) {
        return true;
      }

      if (newLinesWithoutQuoteInCart?.length > 0) {
        handleNewLinesWithoutQuote();
      } else {
        if (checkNoTradeEligibility()) {
          return false;
        }

        sendFeedbackRequest();

        const { shouldProceed } = checkForManualTriageAndProtection();

        if (shouldProceed) {
          setupTaggingAndTriggerTranDetails();
        }
      }
    } else {
      triggerRedirectionToOrdering();
    }
  };
  const isACSSProspectNavigation = () => {
    if (linesWithoutProtection?.length > 0) {
      setProtectionBanner(true);
      setIsProceedToQuote(true);
    } else {
      let isCombo = false;
      const cartDetailsLineInfo = fetchCartDetailsResult?.data?.data?.cart?.lineDetails?.lineInfo ?? [];
      if (cartDetailsLineInfo.length) {
        isCombo = cartDetailsLineInfo.some((line) =>
          ['Other', 'Basic Phone', 'Home Internet', '5G Internet'].includes(line?.deviceTypeSelected),
        );
      }
      if (isCombo) {
        sessionStorage.setItem('PERSONAL_SHOPPER_SKIPPED', 'Y');
        setTimeout(() => {
          Emitter.emit('PERSONAL_SHOPPER_TAB_CLOSE', {
            type: 'SWITCH_TAB',
            targetTab: 'PERSONAL_SHOPPER_TAB_CLOSE',
            targetSubTab: 'NumberSelection',
          });
        }, 1000);
      } else {
        Emitter.emit('PERSONAL_SHOPPER_TAB_CLOSE', { type: 'SWITCH_TAB', targetTab: 'PERSONAL_SHOPPER_TAB_CLOSE' });
        Emitter.emit('ACSS_SCM_SWITCH_TAB', { type: 'SWITCH_TAB', targetTab: 'INSIDE_SALES_ASSIGNED_MTN_TAB' });
      }
    }
  };
  const handelProceedButtonClick = () => {
    const cartHasMultiDepletionItems = [...new Set(linesWithQuoteInCart?.map(line => line?.depletionType).filter(Boolean))].length > 1
    if (showMultiDepletionInCartWarningFFlag &&
      cartHasMultiDepletionItems
    ) {
      const warningMessage = isInsideSalesorCustomerService
        ? FooterMessageContent?.splitDepletionMessageForSales
        : FooterMessageContent?.splitDepletionMessage;

      dispatch(
        appMessageActions.addAppMessage(
          warningMessage,
          'error',
          true,
          true,
        ),
      );
    } else if (showPriceDetails === false && !isFRP) {
        setShowDownPayment(true);
    } else {
      if (isInDirect) {
        let missingMtn = '';
        linesWithQuoteInCart?.forEach((obj) => {
          const mtnPriceEdit = mtnListPriceEdit
            ?.filter(
              (lineObj) =>
                lineObj?.mtn === obj?.mtn &&
                obj?.deviceTypeSelected !== '5G Internet' &&
                obj?.deviceTypeSelected !== 'BYOD',
            )
            ?.map((item) => ({
              ...item,
              isFRP: obj?.priceType === 'MONTH_TO_MONTH',
            }));

          if (mtnPriceEdit?.length !== 0 && !mtnPriceEdit?.[0]?.priceEdited && !mtnPriceEdit?.[0]?.isFRP) {
            if (missingMtn === '') {
              missingMtn = mtnPriceEdit?.[0]?.mtn;
            } else {
              const tmpMtn = mtnPriceEdit?.[0]?.mtn;
              missingMtn += `, ${tmpMtn}`;
            }
          }
        });

        if (missingMtn !== '') {
          const NotProceedToQuoteErrorMsg = `Please update seller price for mtn - ${missingMtn}`;
          dispatch(appMessageActions.addAppMessage(NotProceedToQuoteErrorMsg));
          return false;
        }
      }
      if (
        window?.mfe?.isProspectNewCustomerTab &&
        (window?.mfe?.isProspectMontana || window?.mfe?.isProspectPersonalShopper)
      ) {
        isACSSProspectNavigation();
      } else {
        handleProceedToOrder();
        setIsProceedToQuote(true);
      }
    }
  };

    const CcdAemInfoApi = async () => {
      try {
        const requestBodyByodCcdAemInfo = {
          content: {
            planIds: {
              idlist: [
                {
                  id: byodPlanIdInCart,
                  status: 'add',
                },
              ],
              category: 'plan',
            },
          },
          channel: 'direct_purchase_flow',
          contenttype: 'html',
          langInd: 'EN',
        };
        const res = await retrieveAEMInfoManagerData({ body: requestBodyByodCcdAemInfo });
        if (res?.data) {
          setShowCcdModal(true);
          setCcdData(res?.data);
        } else {
          setShowCcdModal(false);
        }
      } catch (error) {
        console.log(`error while fetching retrieveAEMInfoManagerData, ${error}`);
      }
    };

  const handleProceedButtonWithVHICheck = () => {
    const isVHILiteFlow = sessionStorage.getItem('fiveGHomeInternetSelectedFlow') === 'VHILite';
    const isVHILiteQualified = sessionStorage.getItem('vhiLiteQualified') === 'true';
    /* istanbul ignore else */
    if (vhiLiteAckModalFFlag && isVHILiteQualified && isVHILiteFlow) {
      setShowHomeInternetLiteModal(true);
      return;
    }
    handelProceedButtonClick();
  };

  const closeHomeInternetLiteModal = () => {
    setShowHomeInternetLiteModal(false);
  };

  const closeCcdModal = () => {
    setShowCcdModal(false);
  };

  const handleHomeInternetLiteProceed = () => {
    setShowHomeInternetLiteModal(false);
    handelProceedButtonClick();
  };

  useEffect(() => {
    if (triggerProceedToQuote === true) {
      handleProceedToOrder();
    }
  }, [triggerProceedToQuote]);

  useEffect(() => {
    if (deviceRecom?.devices?.[0]?.sorId) {
      // && deviceRecom?.isUpdateQuote === false) {
      setDeviceRecocommendations(deviceRecom);
    }
  }, [deviceRecom?.devices?.[0]?.sorId]);

  useEffect(() => {
    const handleAiQuoteSuccess = (value) => {
      setAiQuoteSuccess(value);
    };
    const handleAssitedMtnValue = (lookupMtn) => {
      setSelectedMtn(lookupMtn);
    };
    const handleClosingDPModal = (dpFlagData) => {
      /* istanbul ignore else */
      if (dpFlagData) {
        setTaggingPayload({
          type: 'deviceProtection',
        });
        triggerFPSCallback();
        triggerRetrieveCart();
      }
    };
    const handleUpdateTranDetails = (value) => {
      setTranDetailsFromQuote(value);
    };
    const handleQuotePlanRecommendations = (value) => {
      if (value?.isUpdateQuote === false) {
        setPlanRecocommendations(value);
      }
    };
    const handlePerkRecommendations = (value) => {
      /* istanbul ignore else */
      if (value?.isUpdateQuote === false) {
        setPerkRecommendations(value);
      }
    };
    const handleExistingServices = (existingServices) => {
      /* istanbul ignore else */
      if (existingServices) {
        setExisitngServices(existingServices);
      }
    };
    const handlePriorityUpgrade = (value) => {
      setIsPriorityMtn(value);
    };
    const handlePayloadForRC = (value) => {
      setPayloadForRC(value);
    };
    Emitter.on('AI_QUOTE_SUCCESS', handleAiQuoteSuccess);
    Emitter.on('Assisted_MTN_Value', handleAssitedMtnValue);
    // Emitter.on('TRIGGER_AIQUOTE_FPS_CALL', (value) => {
    //   if (value) {
    //     triggerFPSapi();
    //   }
    // });
    Emitter.on('Closing_Device_Protection_Modal', handleClosingDPModal);
    Emitter.on('UPDATE_TRAN_DETAILS_TO_FOOTER', handleUpdateTranDetails);
    Emitter.on('AI_QUOTE_PLAN_RECOMMENDATIONS', handleQuotePlanRecommendations);
    Emitter.on('AI_QUOTE_PERK_RECOMMENDATIONS_FOR_FOOTER', handlePerkRecommendations);

    Emitter.on('protection_services_data_services', handleExistingServices);
    Emitter.on('Priority_upgrade_List', handlePriorityUpgrade);
    Emitter.on('SET_PAYLOAD_FOR_RC', handlePayloadForRC);
    return () => {
      Emitter.off('TRIGGER_AIQUOTE_FPS_CALL');
      Emitter.off('AI_QUOTE_SUCCESS', handleAiQuoteSuccess);
      Emitter.off('Assisted_MTN_Value', handleAssitedMtnValue);
      // Emitter.on('TRIGGER_AIQUOTE_FPS_CALL', (value) => {
      //   if (value) {
      //     triggerFPSapi();
      //   }
      // });
      Emitter.off('Closing_Device_Protection_Modal', handleClosingDPModal);
      Emitter.off('UPDATE_TRAN_DETAILS_TO_FOOTER', handleUpdateTranDetails);
      Emitter.off('AI_QUOTE_PLAN_RECOMMENDATIONS', handleQuotePlanRecommendations);
      Emitter.off('AI_QUOTE_PERK_RECOMMENDATIONS_FOR_FOOTER', handlePerkRecommendations);

      Emitter.off('protection_services_data_services', handleExistingServices);
      Emitter.off('Priority_upgrade_List', handlePriorityUpgrade);
      Emitter.off('SET_PAYLOAD_FOR_RC', handlePayloadForRC);
    };
  }, []);

  useEffect(() => {
    if (isManualTriageDone && tradeDevicesInCart?.length > 0) {
      handleProceedToOrder();
    }
  }, [isManualTriageDone]);

  const disableProceedToCart = () => {
    let disabled = true;
    const isActiveBYODLineConfirmedDevice =
      activeLineInfoInCart?.[0]?.deviceTypeSelected === 'BYOD' &&
      !acknowledgedBYODConfirmDevice?.includes(activeMtnValue);
    /* istanbul ignore else */
    if (
      (deviceRecocommendations?.devices?.[0]?.sorId || activeLineInfoInCart?.[0]?.deviceTypeSelected === 'BYOD') &&
      !isActiveBYODLineConfirmedDevice &&
      !disableProceedToQuote
    ) {
      disabled = false;
    }
    return disabled;
  };
  const disableShareQuote = () => {
    let disabled = true;
    if (Object?.keys(payloadForRC)?.length > 0) {
      disabled = false;
    }
    return disabled;
  };

  // const triggerFPSapi = () => {
  //   setShowLoader(true);
  //   fetchPricingSnapShot({
  //     body: {
  //       cartId: '',
  //       caseId: '',
  //       quoteNSAEnabled: true,
  //       pageId: 'CART',
  //       requestSource: 'AIQUOTE',
  //       flowType: 'AIQuote',
  //     },
  //     customHeaders: { flowName: 'AIQuote' },
  //     spinner: false,
  //   });
  // };

  useEffect(() => {
    if (['rejected', 'fulfilled'].includes(FetchPricingSnapShotResult?.status)) {
      setShowLoader(false);
      const tradeInSkuInFPS =
        FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.tradeInDetail?.tradeInItems?.[0]?.recycleDeviceSku ??
        '';
      Emitter.emit('TRADE_IN_SKU_IN_FPS', tradeInSkuInFPS);

      // for AAL device protection check
      const accLevelProtectionExists = FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.shared?.addons?.filter(
        (item) => (item?.actionIndicator === 'A' || item?.actionIndicator === 'Z') && item.protection,
      )?.[0]?.sorId;
      const linesFromFPS = FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.lines;
      const newLinesinCart = linesFromFPS?.filter(
        (line) =>
          line?.flags?.isNewLine &&
          (line?.flags?.lineActivityType === 'AAL' ||
            line?.flags?.lineActivityType === 'BYOD' ||
            line?.flags?.lineActivityType === 'NSEBYOD' ||
            line?.flags?.lineActivityType === 'NSE'),
      );
      /* istanbul ignore else */
      if (!accLevelProtectionExists && newLinesinCart?.length > 0) {
        const newLinesinCartwithOutProtection = newLinesinCart?.filter(
          (newLine) =>
            /* Apply protection logic only for those new lines with quote */
            linesWithQuoteInCart?.filter((line) => line?.mtn === newLine?.mtn)?.[0] &&
            newLine?.addons?.every((item) => !item.hasOwnProperty.call(item, 'protection')),
        );
        const lineswithNoProtection = newLinesinCartwithOutProtection?.map((newLine) => ({ mtn: newLine?.mtn }));
        setlinesWithoutProtection([...lineswithNoProtection]);
      } else {
        setlinesWithoutProtection([]);
      }
    }
    // if (FetchPricingSnapShotResult?.data?.data?.isAutoPayEnabled) {
    //   setToggleStatus(true);
    // }
  }, [FetchPricingSnapShotResult]);

  // discount text logic
  const updateCloserAndSegmentDiscountText = () => {
    let closerAndSegmentDiscountText = '';
    const lineInfoFromRC = fetchCartDetailsResult?.data?.data?.cart?.lineDetails?.lineInfo;
    const visFeatures = lineInfoFromRC?.flatMap((line) => line?.serviceInfo?.selectedFeaturesList?.visFeature || []);
    const isSEGDISC = visFeatures?.some(
      (feature) => feature?.categoryCodes?.includes('SEGDISC') && feature?.addDeleteInd !== 'D',
    );

    const categoryCodes = ['BTROFF1', 'BTRDISC', 'BTRSPOMARK'];
    const isBTROFF1 = visFeatures?.filter((feature) =>
      categoryCodes.some((code) => feature?.categoryCodes?.includes(code) && feature?.addDeleteInd !== 'D'),
    );

    if (isSEGDISC && isBTROFF1?.length > 0) {
      closerAndSegmentDiscountText = montanaContent?.closerAndSegmentDiscountText;
    } else if (isSEGDISC) {
      closerAndSegmentDiscountText = montanaContent?.segmentDiscountText;
    } else if (isBTROFF1?.length > 0) {
      closerAndSegmentDiscountText = montanaContent?.closerDiscountText;
    }
    setSegmentAndCloserDiscountText(closerAndSegmentDiscountText);
  };

  useEffect(() => {
    if (montanaPriceBreakUpFixFFlag && ['fulfilled'].includes(fetchCartDetailsResult?.status)) {
      updateCloserAndSegmentDiscountText();
    }
  }, [fetchCartDetailsResult]);

  const duetoday = FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.totals?.totalDueToday?.discountedPrice
    ? FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.totals?.totalDueToday?.regularPrice
    : '0.00';
  const currentmonthly =
    FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.totals?.grandTotalDueMonthly?.currentTotal || '0.00';
  // const estimatedTotalWithoutDisc = FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.totals?.grandTotalDueMonthly?.estimatedTotalWithoutDisc || '0.00';
  const estnewmonthly =
    (FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.lineInfo?.length > 0 &&
      FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.totals?.grandTotalDueMonthly?.estimatedTotal) ||
    '0.00';
  const todaysChanges =
    FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.totals?.grandTotalDueMonthly?.todaysChanges || '0.00';
  const priceDiffStatus =
    FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.totals?.grandTotalDueMonthly?.priceDiffStatus;

  const surcharges =
    FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.totals?.surcharges?.regularPrice || '0.00';
  // const savings = FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.savings?.totalSavings || '0.00';
  const miniCartItems =
    FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.miniCartItemDetail?.miniCartItemList || [];
  const cartItems =
    FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.miniCartItemDetail?.cartItemsWithoutTradeIn ?? 0;
  const tradeInItems = FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.miniCartItemDetail?.tradeInItems ?? 0;
  const taxesAndFees =
    FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.totals?.taxesAndFees?.regularPrice || '0.00';
  const addonsTotal =
    FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.totals?.addonsTotal?.regularPrice || '0.00';
  const totalOneTimeCharge =
    FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.cartNBSNextBillTotals?.totalOneTimeCharge || '0.00';
  const monthlyCharges = FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.totals?.monthlyTotal?.regularPrice;
  const subTotalWithoutAddons =
    FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.cartNBSNextBillTotals?.subTotalWithoutAddons;
  const nextBillTotal = FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.cartNBSNextBillTotals?.grandTotal;
  const nextBillAddOns =
    FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.cartNBSNextBillTotals?.totalAddOnsSummary;
  const nextBillSurCharges =
    FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.cartNBSNextBillTotals?.surcharges;
  const nextBillTaxesAndFees =
    FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.cartNBSNextBillTotals?.taxesAndFees;
  const filteredMtnObj = FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.lines?.filter(
    (item) => item?.mtn === activeMtnValue,
  )?.[0];
  let fpsSelectedDevice = { ...filteredMtnObj?.selectedDevice };

  FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.lineInfo?.[0]?.itemsInfo?.[0]?.cartItems?.cartItem?.forEach(
    (obj) => {
      if (obj?.cartItemType === 'DEVICE') {
        const description = obj?.description ? obj?.description : '';
        fpsSelectedDevice = { ...fpsSelectedDevice, description };
      }
    },
  );
  let fpsPlanDetails = [];
  fpsPlanDetails = {
    selectedPlan: {
      ...filteredMtnObj?.selectedPlan,
      displayName: filteredMtnObj?.planPriceFromNBS?.planSkuName ?? '',
      planPrice: filteredMtnObj?.planPriceFromNBS,
    },
    existingPlan: { ...filteredMtnObj?.existingPlan, planPrice: filteredMtnObj?.planPriceFromNBS },
  };
  const fpsSelectedPerks = filteredMtnObj?.addons?.filter((item) => item?.isPerk && item?.actionIndicator === 'A');
  const fpsSelectedAccessories = filteredMtnObj?.accessories;
  const fpsTradeInDetails = FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.tradeInDetail;
  const fpsBICOfferDetails = FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.bicOfferDetail ?? {};
  const savingDataItem = FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.savings?.lineLevelSavings?.filter(
    (line) => line?.mtn === activeMtnValue,
  )?.[0];
  const grandTotalLineSavings =
    FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.savings?.grandTotalSavings?.grandTotalLineSavings ?? 0;
  // const totalPerkSavings =
  //   FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.savings?.grandTotalSavings?.totalPerkSavings ?? 0;
  // const totalVerizonSavings =
  //   FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.savings?.grandTotalSavings?.totalVerizonSavings ?? 0;
  let offerTypeInSavingsList = '';
  if (savingDataItem?.savingsList?.filter((saving) => saving?.type?.toUpperCase() === 'TRADE')?.[0]) {
    offerTypeInSavingsList = 'TRADE';
  } else if (savingDataItem?.savingsList?.filter((saving) => saving?.type?.toUpperCase() === 'BIC')?.[0]) {
    offerTypeInSavingsList = 'BIC';
  }

  let fpsEssentialsDetails = {};

  const apoPaperlessAmount = Math.abs(
    FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.shared?.pendingChargesAndDiscounts
      ?.discountsPendingActionDetails?.apoPaperlessAmount || 0,
  ); // Example amount for APO/Paperless discount
  const ecpdType = FetchPricingSnapShotResult?.data?.data?.ecpdType || ''; // Example ECPD type
  const isAutopayEnabledMontana = FetchPricingSnapShotResult?.data?.data?.isAutoPayEnabled || false;
  const isAiBillUpload = FetchPricingSnapShotResult?.data?.data?.isAiBillUpload || 'N';
  const ecpdDiscountAmount = FetchPricingSnapShotResult?.data?.data?.ecpdDiscount || 0; // Example amount for ECPD discount
  const additionalSavingsAmount =
    FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.shared?.pendingChargesAndDiscounts
      ?.discountsPendingActionDetails?.totalAdditionalDiscount || 0;
  // const grandTotalSavingsWithDiscount =
  //   FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.savings?.grandTotalSavings
  //     ?.grandTotalSavingsWithDiscount || 0;

  // const isToggleEnabled = ecpdType !== '' || isAutopayEnabledMontana;
  const isAiBillUploadFlow = isAiBillUpload.toUpperCase() === 'Y';
  // const isAdditionalToggleFlagEnabled = () => {
  //   const res = montanaOfferEnableFFlag && isAiBillUploadFlow && isToggleEnabled;
  //   return res;
  // };
  // const showAdditionalToggle = isAdditionalToggleFlagEnabled();

  // const shouldShowAdditionalToggle = showAdditionalToggle;

  // const savingDataItem = fpsNew?.data?.data?.subAccounts?.[0]?.savings;
  // const fpsTradeInDetails = fpsNew?.data?.data?.subAccounts?.[0]?.tradeInDetail;
  const discounts = [];

  const noOfLines = FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.savings?.lineLevelSavings?.filter(
    (lineSaving) => lineSaving?.savingsList?.length > 0,
  ).length;
  const monthlyEstimates = FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.savings?.monthlyEstimates;
  // const savingsList = FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.savings?.savingsList || [];
  if (monthlyEstimates && noOfLines > 0) {
    const obj = { title: `Total Savings for ${noOfLines} line(s)`, bold: true };
    discounts.push(
      monthlyEstimates.map((item) => ({
        title: item.itemName,
        amount: formatCurrency(item.monthlySavingAmount),
        bold: item.type === 'MONTHLY_SAVINGS' || item.itemName === 'Total',
        amtBold: true,
        displayMon: item.type !== 'PROMO_SAVINGS',
      })),
    );
    discounts[0].unshift(obj);
  }

  // const getDiscountsData = (discountArray) => {
  //   if (montanaOfferEnableFFlag && isAiBillUploadFlow) {
  //     return [];
  //   }
  //   return discountArray;
  // };

  // discounts = getDiscountsData(discounts);

  // const perkSavingsData = [];
  // const verizonSavingsData = [];
  // const shouldShowPerkSavings = () => {
  //   const res = montanaOfferEnableFFlag && isAIQuote && isNewCustomer && Boolean(savingsList?.length);
  //   return res;
  // };

  // if (shouldShowPerkSavings()) {
  //   const obj = {
  //     title: 'Perk Savings',
  //     bold: true,
  //     amtBold: true,
  //     amount: `-${formatCurrency(totalPerkSavings)}`,
  //     displayMon: true,
  //   };
  //   perkSavingsData.push(
  //     savingsList
  //       .filter((item) => item.type?.toLowerCase() === 'perk')
  //       .map((item) => ({
  //         title: `${item?.itemName} for ${noOfLines} line(s)`,
  //         amount: formatCurrency(item?.monthlySavingAmount),
  //         bold: item?.type === 'MONTHLY_SAVINGS' || item?.itemName === 'Total',
  //         amtBold: false,
  //         displayMon: item?.type !== 'PROMO_SAVINGS',
  //         originalAmount: item?.originalPrice ? formatCurrency(item?.originalPrice) : null,
  //       })),
  //   );
  //   perkSavingsData[0].unshift({ title: '', originalAmount: 'What they pay', amount: 'What they save' });
  //   perkSavingsData[0].unshift(obj);
  //   const verizonSavingTitle = {
  //     title: 'Verizon Savings',
  //     bold: true,
  //     amtBold: true,
  //     amount: `-${formatCurrency(totalVerizonSavings)}`,
  //     displayMon: true,
  //   };
  //   verizonSavingsData.push(
  //     savingsList
  //       .filter((item) => item.type?.toLowerCase() !== 'perk')
  //       .map((item) => ({
  //         title: `${item?.itemName} for ${item?.mtn} (${item?.bicNoOfOccurences} months)`,
  //         amount: formatCurrency(item?.monthlySavingAmount),
  //         bold: item?.type === 'MONTHLY_SAVINGS' || item?.itemName === 'Total',
  //         amtBold: false,
  //         displayMon: false,
  //       })),
  //   );
  //   verizonSavingsData[0].unshift(verizonSavingTitle);
  // }
  // Helper to get DueToday and Pay with VVC
  /* istanbul ignore next */
  const getDueTodayEntries = () => {
    if (isDfoSelected) {
      return [{ DueToday: formatCurrency(0) }, { 'Pay with VVC': formatCurrency(duetoday) }];
    }
    return [{ DueToday: formatCurrency(duetoday) }];
  };

  // Helper to get Current monthly entry
  /* istanbul ignore next */
  const getCurrentMonthlyEntry = () => {
    const excludedTypes = ['NSE', 'NSE_5G', 'NSE_LTE'];
    const allNotNSE = FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.lines?.every(
      (line) => !excludedTypes.includes(line?.flags?.lineActivityType),
    );
    return allNotNSE ? { 'Current monthly': formatCurrency(currentmonthly) } : {};
  };

  // Helper to get Est. new monthly entry
  /* istanbul ignore next */
  const getEstNewMonthlyEntry = () => {
    const hasLineInfo = FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.lineInfo?.length > 0;
    return hasLineInfo ? { 'Est. new monthly': formatCurrency(estnewmonthly) } : {};
  };

  const footerpricinngs = [
    { Items: cartItems || 0 },
    { 'Trade-In': tradeInItems || 0 },
    ...getDueTodayEntries(),
    getCurrentMonthlyEntry(),
    getEstNewMonthlyEntry(),
    { 'Total Monthly Savings': formatCurrency(grandTotalLineSavings) },
  ].filter((entry) => Object.keys(entry).length > 0);
  const setUpnGoInfo = lineInfoObj?.[0]?.cartItems?.cartItem?.filter((item) => item?.itemCode === 'SETUPANDGO');
  const protectionChange =
    filteredMtnObj?.addons?.filter(
      (item) => (item?.actionIndicator === 'A' || item?.actionIndicator === 'Z') && item.protection,
    )?.[0] && true;
  const protectionChangedBack =
    filteredMtnObj?.addons?.filter((item) => item?.actionIndicator === 'A' && item.protection)?.[0] && true;
  const accProtection = FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.shared?.addons?.filter(
    (item) =>
      (item?.actionIndicator === 'A' || item?.actionIndicator === 'Z') &&
      item?.protection &&
      item?.eligibileMTNs?.includes(activeMtnValue),
  );
  console.log('----accProtection', accProtection);

  const activeLineFromFps = FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.lineInfo?.filter(
    (item) => item?.mobileNumber === activeMtnValue,
  )?.[0]?.itemsInfo;

  const depletionLocationInFPS = activeLineFromFps?.[0]?.depletionLocation ?? '';
  const depletionTypeInFPS = fpsSelectedDevice?.depletionType ?? '';
  let fullfillmentMethod = '';
  if (depletionLocationInFPS && depletionTypeInFPS === 'L') {
    fullfillmentMethod = 'ISPU';
  } else if (depletionTypeInFPS === 'F') {
    fullfillmentMethod = 'Ship This Device';
  } else {
    fullfillmentMethod = '';
  }

  // constructing fpsSelectedDevice object to emit to deviceWidget
  fpsSelectedDevice = {
    ...fpsSelectedDevice,
    colorDisplayName: fpsSelectedDevice?.color?.colorDisplayName,
    defaultImage: fpsSelectedDevice?.deviceUrl,
    skuDisplayName: fpsSelectedDevice?.displayName,
    remainingMonthPrice: fpsSelectedDevice?.price?.discountedPrice,
    fullRetailPrice: deviceItemInCartForLine?.itemPrice,
    fpsMTN: filteredMtnObj?.mtn ?? '',
    fullfillmentMethod,
    fpsTimeStamp: FetchPricingSnapShotResult?.fulfilledTimeStamp ?? '',
    accInFPS: !!fpsSelectedAccessories?.[0],
  };
  const dppPriceForSelectedLine = fpsTradeInDetails?.tradeInItems?.filter(
    (line) => line?.tradeDeviceMDN === activeMtnValue,
  )?.[0]?.recycleDeviceOffer?.dppCredit;
  const bicOfferDppPriceForSelectedLine = fpsBICOfferDetails?.tradeInItems?.filter(
    (item) => item.tradeDeviceMDN === activeMtnValue,
  )?.[0]?.recycleDeviceOffer?.dppCredit;

  if (offerTypeInSavingsList && offerTypeInSavingsList?.toUpperCase() === 'TRADE' && dppPriceForSelectedLine) {
    fpsSelectedDevice = {
      ...fpsSelectedDevice,
      price: {
        ...fpsSelectedDevice?.price,
        dppPrice: dppPriceForSelectedLine,
      },
    };
  } else if (
    offerTypeInSavingsList &&
    offerTypeInSavingsList?.toUpperCase() === 'BIC' &&
    bicOfferDppPriceForSelectedLine
  ) {
    fpsSelectedDevice = {
      ...fpsSelectedDevice,
      price: {
        ...fpsSelectedDevice?.price,
        dppPrice: bicOfferDppPriceForSelectedLine,
      },
    };
  }
  if (filteredMtnObj?.devicePayment?.price) {
    fpsSelectedDevice = {
      ...fpsSelectedDevice,
      price: {
        ...fpsSelectedDevice?.price,
        finalDppPrice: filteredMtnObj?.devicePayment?.price?.finalDppPrice,
        mandatoryDownPayment: filteredMtnObj?.devicePayment?.price?.mandatoryDownPayment,
      },
    };
    fpsEssentialsDetails = {
      ...fpsEssentialsDetails,
      mandatoryDownPayment: filteredMtnObj?.devicePayment?.price?.mandatoryDownPayment,
    };
  }
  if (filteredMtnObj?.planPriceFromNBS?.planId) {
    fpsSelectedDevice = {
      ...fpsSelectedDevice,
      planIdInCart: filteredMtnObj.planPriceFromNBS.planId,
    };
  }

  // const getTotalSavingsAmount = () => {
  //   if (toggleStatus && shouldShowAdditionalToggle) {
  //     return grandTotalSavingsWithDiscount;
  //   }
  //   return grandTotalLineSavings;
  // };

  // const totalSavingsData = montanaOfferEnableFFlag && [
  //   [
  //     {
  //       title: 'Total Savings',
  //       bold: true,
  //       amtBold: true,
  //       amount: `-${formatCurrency(getTotalSavingsAmount())}`,
  //       displayMon: true,
  //     },
  //   ],
  // ];

  const shouldShowAdditionalDiscountsFlow = () =>
    ((montanaOfferEnableFFlag && isAiBillUploadFlow && additionalSavingsAmount > 0) || (aiQuoteProspectOffersFFlag && !isAiBillUploadFlow && additionalSavingsAmount > 0));
  console.log('shouldShowAdditionalDiscountsFlow', shouldShowAdditionalDiscountsFlow());
  const getAdditionalDiscounts = () => {
    const additionalDiscounts = [];
    // if (toggleStatus) {
    if (apoPaperlessAmount && isAutopayEnabledMontana) {
      additionalDiscounts.push({
        title: 'APO/Paperless discount',
        amount: `-${formatCurrency(apoPaperlessAmount)}`,
        bold: false,
      });
    }
    if (ecpdDiscountAmount && ecpdType !== '') {
      additionalDiscounts.push({
        title: `ECPD discount(${ecpdType})`,
        amount: `-${formatCurrency(ecpdDiscountAmount)}`,
        bold: false,
      });
    }
    additionalDiscounts.unshift({
      title: 'Additional available discounts**',
      amount: `-${formatCurrency(additionalSavingsAmount)}`,
      bold: true,
      amtBold: true,
    });
    // }
    return additionalDiscounts;
  };

  // Get additional discounts when Montana offer flag is enabled and in AI Bill Upload flow
  const additionsDiscounts = shouldShowAdditionalDiscountsFlow() ? getAdditionalDiscounts() : [];

  // Calculate estimated monthly amount with additional discounts applied
  // when Montana offer flag is enabled and in AI Bill Upload flow
  const estNewMonthlyWithAdditionalDiscounts = shouldShowAdditionalDiscountsFlow()
    ? {
        title: 'Est. new monthly if discounts are applied',
        amount: formatCurrency(estnewmonthly),
        bold: true,
        amtBold: true,
      }
    : {};

  const getCloserAndSegmentDiscountText = () => {
    if (montanaPriceBreakUpFixFFlag) {
      return segmentAndCloserDiscountText;
    }
    return '';
  };
  const getExpandedDueTodayEntries = () => {
    if (isDfoSelected) {
      return [
        { title: 'Due today', amount: formatCurrency(0), bold: true },
        { title: 'Pay with VVC', amount: formatCurrency(duetoday), bold: true },
      ];
    }
    return [{ title: 'Due today', amount: formatCurrency(duetoday), bold: true }];
  };

  const setUpnGoInfoFPS = lineInfoObj?.[0]?.cartItems?.cartItem?.some((item) => item?.itemCode === 'SETUPANDGO');
  const expandFooterData = [
    {
      totals: [
        [
          { title: 'Items', count: cartItems || 0 },
          { title: 'Trade-In', count: tradeInItems || 0 },
        ],
        getExpandedDueTodayEntries(),
        [
          { title: 'Est. New Monthly', amount: formatCurrency(estnewmonthly), bold: true },
          {
            title: `Monthly Charges and Credits ${getCloserAndSegmentDiscountText()}`,
            amount: formatCurrency(monthlyCharges),
            bold: false,
          },
          { title: 'Add-Ons', amount: formatCurrency(addonsTotal), bold: false },
          { title: 'Surcharges', amount: formatCurrency(surcharges), bold: false },
          { title: 'Taxes & Govt.Fee', amount: formatCurrency(taxesAndFees), bold: false },
          ...additionsDiscounts,
          { ...estNewMonthlyWithAdditionalDiscounts },
        ],
        [
          { title: 'Est. Next Bill', amount: formatCurrency(nextBillTotal), bold: true },
          { title: 'One Time Charges and Credits', amount: formatCurrency(totalOneTimeCharge), bold: false },
          { title: 'Monthly Charges and Credits', amount: formatCurrency(subTotalWithoutAddons), bold: false },
          { title: 'Add-Ons', amount: formatCurrency(nextBillAddOns), bold: false },
          { title: 'Surcharges', amount: formatCurrency(nextBillSurCharges), bold: false },
          { title: 'Taxes & Govt.Fee', amount: formatCurrency(nextBillTaxesAndFees), bold: false },
        ],
      ],
      discounts,
    },
    {
      compareQuoteData,
    },
    // {
    //   totalSavings: totalSavingsData,
    //   perkSavings: totalPerkSavings > 0 ? perkSavingsData : [],
    //   verizonSavings: totalVerizonSavings > 0 ? verizonSavingsData : [],
    //   additionalSavings:
    //     montanaOfferEnableFFlag && toggleStatus && additionalSavingsAmount > 0 ? [additionsDiscounts] : [],
    // },
  ];

  Emitter.emit('setUpnGo_Info_FPS', setUpnGoInfo);
  Emitter.emit('AI_QUOTE_FPS_TRADEIN_DETAILS', fpsTradeInDetails);
  if (fpsSelectedDevice?.sorId !== undefined) {
    Emitter.emit('AI_QUOTE_FPS_DEVICE_DETAILS', fpsSelectedDevice);
  }
  if (!isEmpty(fpsEssentialsDetails)) {
    Emitter.emit('AI_QUOTE_FPS_ESSENTIALS_DETAILS', fpsEssentialsDetails);
  }
  Emitter.emit('AI_QUOTE_FPS_PLAN_DETAILS', fpsPlanDetails);
  Emitter.emit('AI_QUOTE_FPS_PERKS_DETAILS', fpsSelectedPerks);
  Emitter.emit('Inline_Loader_Show', showLoader);

  if (FetchPricingSnapShotResult?.data?.data?.subAccounts?.[0]?.lineInfo?.length > 0) {
    Emitter.emit('AI_QUOTE_FPS_DATA_FOR_TAGGING', FetchPricingSnapShotResult?.data?.data?.subAccounts);
  }

  const offersApplied = filteredMtnObj?.appliedOffers?.appliedOffersList?.[0];

  useEffect(() => {
    if (['rejected', 'fulfilled'].includes(FetchPricingSnapShotResult?.status)) {
      Emitter.emit('OFFERS_ADDED_IN_CART', offersApplied);
    }
  }, [FetchPricingSnapShotResult]);

  useEffect(() => {
    if (protectionChange || accProtection?.length > 0 || protectionChangedBack) {
      const updatedProtectionData = [];
      const protectionServices = [];
      filteredMtnObj?.addons
        ?.filter((item) => (item?.actionIndicator === 'A' || item?.actionIndicator === 'Z') && item.protection)
        .map((obj) =>
          protectionServices.push({
            name: obj?.skuName,
            price: `$${obj?.price?.discountedPrice}`,
            productId: obj?.sorId,
            isChange: true,
            showLink: true,
          }),
        );

      accProtection
        ?.filter((item) => item?.actionIndicator === 'A' || (item?.actionIndicator === 'Z' && item?.protection))
        .map((obj) =>
          protectionServices?.push({
            name: obj?.skuName,
            price: `$${obj?.price?.discountedPrice}`,
            productId: obj?.sorId,
            isChange: false,
            showLink: true,
          }),
        );
      const existingServices = [];
      filteredMtnObj?.addons
        ?.filter(
          (item) => item?.actionIndicator === 'Z' && item.type === 'SFO' && item?.price?.discountedPrice > '0.00',
        )
        .map((obj) =>
          existingServices.push({ name: obj?.skuName, price: `$${obj?.price?.discountedPrice}`, showLink: false }),
        );
      updatedProtectionData.push({
        protectionServices,
        recommendation: setUpnGoInfoFPS
          ? [{ name: 'Setup & Go', price: '$29.99', isAdd: true, showLink: false, sorId: 'SETUPANDGO' }]
          : [{ name: 'Setup & Go', price: '$29.99', isAdd: true, showLink: true, sorId: 'SETUPANDGO' }],
        existingServices: exisitngServicesFromCustomer,
      });
      setFPSProtectionData(updatedProtectionData);
    }
  }, [protectionChange, accProtection?.length, protectionChangedBack, setUpnGoInfoFPS]);

  const getPriceDifference = () =>
    !isNewCustomer && priceDiffStatus === 'I' ? (
      <>
        <Icon name='up-arrow' size='small' color='#b95319' />
        <Body size='large' primitive='span' color='#b95319'>
          {formatCurrency(todaysChanges)}
        </Body>
      </>
    ) : (
      !isNewCustomer &&
      priceDiffStatus === 'D' && (
        <>
          <Icon name='down-arrow' size='small' color='#00AC3E' />
          <Body size='large' primitive='span' color='#00AC3E'>
            {formatCurrency(todaysChanges * -1)}
          </Body>
        </>
      )
    );

  const handleConnectPlanBuilder = () => {
    const breadCrumbVal = isAIQuoteInitModalEnabledFFlag && tranDetailsFromQuote?.isCaptureBreadcrumbFlow === 'true';
    const currentPayloadForRC = breadCrumbVal
      ? { ...payloadForRC, isCaptureBreadcrumbFlow: tranDetailsFromQuote?.isCaptureBreadcrumbFlow }
      : payloadForRC;
    /* istanbul ignore else */
    if (isIpad() && executeShellFunction) {
      executeShellFunction('Shell', 'connectToPlanBuilder', 'window.proceedToQuoteFromRC', currentPayloadForRC);
    } else {
      Emitter.emit('RETAIL_COMPANION_MODAL', true);
    }
  };

  console.log('isEditTradeIn in cart footer', isEditTradeIn);
  const isProspect = window?.mfe?.isProspectPersonalShopper;
  const classMap = {
    true: 'footercomponent',
    false: '',
  };

  const footerClass = classMap[isProspect];
  return (
    <div style={{ display: isEditTradeIn && 'none' }}>
      {aiQuoteSuccess && !expandFooter && (
        <div data-testid='footercomponent' className={footerClass}>
          <FooterWrapper>
            <div>
              <ButtonWrapper shareQuoteEnabled={enableShareQuoteinAIQuoteFFlag}>
                <Button
                  size='large'
                  surface='light'
                  data-testid='footercomponentButton'
                  data-track={
                    isInDirect && showPriceDetails === false && !isFRP ? 'update_SellerPrice' : 'Proceed with Quote'
                  }
                  disabled={isAIQuote ? disableProceedToCart() : false}
                  use='primary'
                  onClick={async () => {
                    /* istanbul ignore else */
                    if (byodPlusPlanFFlag && hasByodSelected) {
                      CcdAemInfoApi();
                    } else if (newByodPlanDppEupFFlag && hasNewByodWithDppEup) {
                      // Show modal with new message for newByodPlanIds with DPP+EUP
                      setByodModalMessageType('dppEup');
                      setShowByodDiscountModal(true);
                    } else if (
                      (byodPlusPlanFFlag && (hasByodPlan || (newByodPlanDppEupFFlag && hasNewByodSelected))) ||
                      (byodPlusEUPSupressFFlag && hasUpgradedIncompatibleByodDevice)
                    ) {
                      // Show modal with default message for other scenarios
                      setByodModalMessageType('default');
                      setShowByodDiscountModal(true);
                    } else {
                      handleProceedButtonWithVHICheck();
                    }
                  }}
                >
                  {isInDirect && showPriceDetails === false && !isFRP ? 'Update seller price' : 'Proceed with Quote'}
                </Button>
                {isShareToRCCTAEligible() && (
                  <Button
                    size='large'
                    surface='light'
                    data-testid='footercomponentShareQuoteButton'
                    data-track='shareQuote'
                    disabled={isAIQuote && enableShareQuoteinAIQuoteFFlag ? disableShareQuote() : true}
                    use='secondary'
                    onClick={() => {
                      handleConnectPlanBuilder();
                    }}
                  >
                    Share to RC
                  </Button>
                )}
              </ButtonWrapper>
            </div>
            {(showPriceDetails || isFRP) && (
              <PromotionWrapper shareQuoteEnabled={enableShareQuoteinAIQuoteFFlag} isDfoSelected={isDfoSelected}>
                {footerpricinngs.map((e) =>
                  Object.entries(e).map(([label, value]) => (
                    <div>
                      {inlineShowLoader ? (
                        <DotLoader />
                      ) : (
                        <Title size='small' bold color={`${label === 'Total Monthly Savings' ? '#008331' : null}`}>
                          {label === 'Total Monthly Savings' ? (
                            <TextLinkCaret
                              surface='light'
                              disabled={false}
                              iconPosition=''
                              style={{
                                color: '#008331',
                                cursor: 'pointer',
                              }}
                              onClick={handleExpand}
                            >
                              {value}
                            </TextLinkCaret>
                          ) : (
                            value
                          )}
                          {label === 'Est. new monthly' && getPriceDifference()}
                        </Title>
                      )}
                      <Body size='medium' color={`${label === 'Total Monthly Savings' ? '#008331' : null}`}>
                        {label}
                      </Body>
                    </div>
                  ))
                )}
                <DueWrapper
                  onClick={handleExpand}
                  tabIndex={0}
                  aria-label='Expand Footer'
                  data-track='Billing Details - Open'
                >
                  {cartItems > 0 && <Icon name='up-caret' size='large' data-testid='up-caret icon' />}
                </DueWrapper>
              </PromotionWrapper>
            )}
          </FooterWrapper>
        </div>
      )}
      {expandFooter && expandFooterData && (
        <ExpandFooter
          handleProceedToOrder={handleProceedToOrder}
          hideFooter={handleExpand}
          expandFooterData={expandFooterData}
          estnewmonthly={estnewmonthly}
          nextBillTotal={nextBillTotal}
          enableScroll
          isNewCustomer={isNewCustomer}
          personalShopperFlow={isAIQuote}
          // hideSavings={handleToggleSavings}
          // toggleStatus={toggleStatus}
          // shouldShowAdditionalToggle={shouldShowAdditionalToggle}
          additionalSavingsAmount={additionalSavingsAmount}
          isAiBillUploadFlow={isAiBillUploadFlow}
        />
      )}
      <Modal
        surface='light'
        fullScreenDialog={false}
        opened={displayRemoveLinesPopUp}
        disableAnimation={false}
        closeButton={<div />}
        disableOutsideClick
        ariaLabel='RemoveNewLinesInCartWithoutQuote'
      >
        <ModalTitle primitive='h6'>New lines in Quote</ModalTitle>
        <ModalBody>{`You have not viewed the quote for ${newLinesWithoutQuoteInCart?.join(
          ', '
        )}. If you proceed, new line(s) that have not been viewed will be removed from the cart.`}</ModalBody>
        <ModalFooter
          buttonData={{
            primary: {
              children: 'Proceed With Quote',
              'data-testid': 'ProceedWithQuote',
              'data-track': 'newLine_InQuote_proceedWithQuote',
              onClick: () => {
                removeNewLinesWithoutQuote(newLinesWithoutQuoteInCart);
              },
            },
            close: {
              children: 'Cancel',
              'data-testid': 'Cancel',
              'data-track': 'newLine_InQuote_cancel',
              onClick: () => {
                setDisplayRemoveLinesPopUp(false);
                setAssistedMtnFromAIQuote(newLinesWithoutQuoteInCart?.[0]);
                setMtnToBeSelectedWithoutGenratingQuote(newLinesWithoutQuoteInCart?.[0]);
              },
            },
          }}
        />
      </Modal>

      <Modal
        surface='light'
        fullScreenDialog={false}
        opened={showModalPastbalPreBackOrder}
        disableAnimation={false}
        closeButton={<div />}
        disableOutsideClick
        ariaLabel='ModalPastbalPreBackOrder'
      >
        <ModalTitle>Devices that are on preOrder/backorder are not allowed Past Due transaction</ModalTitle>
        <ModalBody>
          <p className='u-marginTopMedium'>
            Past Due amount must be paid before sales order, or select in-stock device to proceed.
          </p>
          <p className='u-marginTopMedium'>
            <b>Note:</b> Back orders with ISPU can still proceed with past due.
          </p>
        </ModalBody>
        <ModalFooter>
          <Button
            size='large'
            use='secondary'
            surface='light'
            data-testid='OKBtn'
            onClick={() => setShowModalPastbalPreBackOrder(false)}
          >
            OK
          </Button>
        </ModalFooter>
      </Modal>
      <HomeInternetLiteModal
        showHomeInternetLiteModal={showHomeInternetLiteModal}
        closeHomeInternetLiteModal={closeHomeInternetLiteModal}
        onPlanSelectConfirmation={handleHomeInternetLiteProceed}
      />
      {byodPlusPlanFFlag && showCcdModal && (
        <CcdModal
          showCcdModal={showCcdModal}
          CcdData={ccdData}
          closeCcdModal={closeCcdModal}
          
          onProceedToOrderClickForExpreesCheckout={() => {
            closeCcdModal();
            handleProceedButtonWithVHICheck();
          }}
          landingData={{
            cartDetails: fetchCartDetailsResult?.data?.data?.cart,
            flags: FetchPricingSnapShotResult?.data?.data?.flags,
          }}
          ccdRemarksForServiceChange='TRUE'
          customerProfileDetails={customerBio}
        />
      )}
      {/* istanbul ignore next */}
      {showByodDiscountModal && (
        <Modal
          opened={showByodDiscountModal}
          surface='light'
          fullScreenDialog={false}
          onOpenedChange={(opened) => {
            if (!opened) setShowByodDiscountModal(false);
          }}
          data-testid='byod-discount-modal'
        >
          <ModalTitle style={{ 'font-size': '1rem' }}>
            {byodModalMessageType === 'dppEup' ? 'Confirm Phone Upgrade' : 'Confirm plan change'}
          </ModalTitle>
          <ModalBody>
            <Body size='large'>
              {byodModalMessageType === 'dppEup' 
                ? 'By upgrading the device, the customer\'s BYOD+ discount will be removed and cannot be readded.'
                : 'By changing the plan, the customer\'s BYOD+ discount will be removed and cannot be readded.'}
            </Body>
          </ModalBody>
          <ModalFooter
            buttonData={{
              primary: {
                children: 'OK',
                'aria-label': 'confirm byod discount removal',
                onClick: () => {
                  setShowByodDiscountModal(false);
                  handleProceedButtonWithVHICheck();
                },
              }
            }}
          />
        </Modal>
      )}
    </div>
  );
}
export default Footer;
