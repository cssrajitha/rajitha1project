import React from 'react';
// import { render, screen, fireEvent } from '@testing-library/react';
import { isIpad } from 'onevzsoemfeframework/DomService';
import { fireEvent, render, screen } from '../../utils/test-utils/renderHelper';
// import '@testing-library/jest-dom';
import ExpandFooter from './ExpandFooter'; // Assuming the component file is named 'ExpandFooter.js';
import mockData from './Mocks/FPS.json';
import expandFooterData from './Mocks/expandFooterData.json';
import priceMockData from './Mocks/fpsWithCartItem.json';
import priceMockData1 from './Mocks/fpsWithNoCartItems.json';

const mockHideFooter = jest.fn();
const handleProceedToOrder = jest.fn();
jest.mock('onevzsoemfeframework/DomService', () => ({
  isIpad: jest.fn(),
}));

describe('ExpandFooter Component', () => {
  test('renders the component with initial state', () => {
    isIpad.mockReturnValue(true);
    render(
      <ExpandFooter
        hideFooter={mockHideFooter}
        expandFooterData={mockData}
        handleProceedToOrder={handleProceedToOrder}
        enableScroll
      />,
    );

    // Verify the presence of key elements
    expect(screen.getByTestId('expandFooter')).toBeInTheDocument();
    expect(screen.getByText('Items')).toBeInTheDocument();
    expect(screen.getByText('Due today')).toBeInTheDocument();
    fireEvent.click(screen.getByText('Proceed with Quote'));
    // expect(screen.getByText('Est. new monthly')).toBeInTheDocument();
    // Add more assertions as needed based on your component structure
  });
  // test('toggles RemindRepNotification when ShoppingBag is clicked', () => {
  //   render(<ExpandFooter />);

  //   const shoppingBag = screen.getByRole('button', { name: 'Shopping Bag' });
  //   fireEvent.click(shoppingBag);

  //   // Assuming RemindRepNotification is toggled by clicking the ShoppingBag
  //   expect(screen.getByTestId('remindRepNotification')).toBeInTheDocument();

  //   fireEvent.click(shoppingBag); // Click again to hide RemindRepNotification

  //   expect(screen.queryByTestId('remindRepNotification')).not.toBeInTheDocument();
  // });

  // Add more test cases based on the component's functionality
});

describe('ExpandFooter Component test', () => {
  test('renders the component with initial state', async () => {
    render(
      <ExpandFooter
        hideFooter={mockHideFooter}
        expandFooterData={expandFooterData}
        handleProceedToOrder={handleProceedToOrder}
        enableScroll={false}
      />,
    );
    expect(screen.getByTestId('expandFooter')).toBeInTheDocument();
    expect(screen.getByText('Items')).toBeInTheDocument();
    expect(screen.getByText('Due today')).toBeInTheDocument();

    expect(screen.getByText('Line level pricing & savings')).toBeInTheDocument();
    fireEvent.click(screen.getByText('Line level pricing & savings'));
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    const icon = screen.getAllByTestId('minusplusIcon');
    fireEvent.click(icon[0]);
    fireEvent.click(screen.getByText('Proceed with Quote'));
  });
});

describe('ExpandFooter Component test for AI Plan recommender', () => {
  const isPlanChangeRecommender = true;
  test('renders the component with initial state', async () => {
    render(
      <ExpandFooter
        hideFooter={mockHideFooter}
        expandFooterData={expandFooterData}
        handleProceedToOrder={handleProceedToOrder}
        enableScroll={false}
        fetchPricingResponse={priceMockData}
        isPlanChangeRecommender={isPlanChangeRecommender}
      />,
    );
    expect(screen.getByTestId('expandFooter')).toBeInTheDocument();
    expect(screen.getByText('Items')).toBeInTheDocument();
    expect(screen.getByText('Due today')).toBeInTheDocument();

    expect(screen.getByText('Line level pricing & savings')).toBeInTheDocument();
    fireEvent.click(screen.getByText('Line level pricing & savings'));
    await new Promise((res) => {
      setTimeout(res, 2000);
    });
    const icon = screen.getAllByTestId('minusplusIcon');
    fireEvent.click(icon[0]);
    // fireEvent.click(screen.getByText('Proceed with Quote'));
  });
  test('renders the component with initial state', async () => {
    render(
      <ExpandFooter
        hideFooter={mockHideFooter}
        expandFooterData={expandFooterData}
        handleProceedToOrder={handleProceedToOrder}
        enableScroll={false}
        fetchPricingResponse={priceMockData1}
        isPlanChangeRecommender={isPlanChangeRecommender}
      />,
    );
    expect(screen.getByTestId('expandFooter')).toBeInTheDocument();
    expect(screen.getByText('Items')).toBeInTheDocument();
    expect(screen.getByText('Due today')).toBeInTheDocument();
  });
});

describe('ExpandFooter Component with montanaOfferEnableFFlag', () => {
  beforeEach(() => {
    jest.resetAllMocks();
  });

  test('should not show additional available discounts toggle when montanaOfferEnableFFlag is false', () => {
    // Mock sessionStorage to return montanaOfferEnableFFlag as FALSE
    const originalGetItem = Storage.prototype.getItem;
    Storage.prototype.getItem = jest.fn((key) => {
      if (key === 'APP_PROPERTIES') {
        return JSON.stringify({ montanaOfferEnableFFlag: 'FALSE' });
      }
      return originalGetItem.call(window.sessionStorage, key);
    });

    render(
      <ExpandFooter
        hideFooter={mockHideFooter}
        expandFooterData={mockData}
        handleProceedToOrder={handleProceedToOrder}
        enableScroll
        personalShopperFlow
      />,
    );

    // Toggle for additional discounts should not be present
    expect(screen.queryByText('Show additional available discounts')).not.toBeInTheDocument();

    // Restore original implementation
    Storage.prototype.getItem = originalGetItem;
  });

  // test('should show additional available discounts toggle when montanaOfferEnableFFlag is true', () => {
  //   // Mock sessionStorage to return montanaOfferEnableFFlag as TRUE
  //   const originalGetItem = Storage.prototype.getItem;
  //   Storage.prototype.getItem = jest.fn((key) => {
  //     if (key === 'APP_PROPERTIES') {
  //       return JSON.stringify({ montanaOfferEnableFFlag: 'TRUE' });
  //     }
  //     return originalGetItem.call(window.sessionStorage, key);
  //   });

  //   render(
  //     <ExpandFooter
  //       hideFooter={mockHideFooter}
  //       expandFooterData={mockData}
  //       handleProceedToOrder={handleProceedToOrder}
  //       enableScroll
  //       personalShopperFlow={true}
  //       shouldShowAdditionalToggle={true}
  //       additionalSavingsAmount={20} // Set a non-zero additional savings amount
  //       isAiBillUpload='Y'
  //     />,
  //   );

  //   // Toggle for additional discounts should be present
  //   // expect(screen.getByText('Show additional available discounts')).toBeInTheDocument();

  //   // Restore original implementation
  //   Storage.prototype.getItem = originalGetItem;
  // });

  test('should show additional discount information when toggle is activated and montanaOfferEnableFFlag is true', () => {
    // Mock sessionStorage to return montanaOfferEnableFFlag as TRUE
    const originalGetItem = Storage.prototype.getItem;
    Storage.prototype.getItem = jest.fn((key) => {
      if (key === 'APP_PROPERTIES') {
        return JSON.stringify({ montanaOfferEnableFFlag: 'TRUE' });
      }
      return originalGetItem.call(window.sessionStorage, key);
    });

    // Create a mock function for hideSavings toggle handler
    const mockHideSavings = jest.fn();

    render(
      <ExpandFooter
        hideFooter={mockHideFooter}
        expandFooterData={mockData}
        handleProceedToOrder={handleProceedToOrder}
        enableScroll
        personalShopperFlow
        hideSavings={mockHideSavings}
        toggleStatus // Set toggle status to true
        shouldShowAdditionalToggle
        additionalSavingsAmount={20} // Set a non-zero additional savings amount
        isAiBillUploadFlow
      />,
    );

    // Verify the toggle is present
    // const toggleText = screen.getByText('Show additional available discounts');
    // expect(toggleText).toBeInTheDocument();

    // Additional text that appears when toggle is on should be visible
    // Note: This part might need adjustment based on the actual component behavior
    // when the toggle is activated
    expect(screen.getByText(/Proceed with Quote/)).toBeInTheDocument();
    fireEvent.click(screen.getByText(/Proceed with Quote/));
    // Restore original implementation
    Storage.prototype.getItem = originalGetItem;
  });
});
describe('ExpandFooter Component with aiQuoteProspectOffersFFlag', () => {
  beforeEach(() => {
    jest.resetAllMocks();
  });

  test('should show additional discount information when toggle is activated and aiQuoteProspectOffersFFlag is true', () => {
    // Mock sessionStorage to return aiQuoteProspectOffersFFlag as TRUE
    const originalGetItem = Storage.prototype.getItem;
    Storage.prototype.getItem = jest.fn((key) => {
      if (key === 'APP_PROPERTIES') {
        return JSON.stringify({ aiQuoteProspectOffersFFlag: 'TRUE' });
      }
      return originalGetItem.call(window.sessionStorage, key);
    });

    // Create a mock function for hideSavings toggle handler
    const mockHideSavings = jest.fn();

    render(
      <ExpandFooter
        hideFooter={mockHideFooter}
        expandFooterData={mockData}
        handleProceedToOrder={handleProceedToOrder}
        enableScroll
        personalShopperFlow
        hideSavings={mockHideSavings}
        toggleStatus // Set toggle status to true
        shouldShowAdditionalToggle
        additionalSavingsAmount={20} // Set a non-zero additional savings amount
      />,
    );

    // Verify the toggle is present
    // const toggleText = screen.getByText('Show additional available discounts');
    // expect(toggleText).toBeInTheDocument();

    // Additional text that appears when toggle is on should be visible
    // Note: This part might need adjustment based on the actual component behavior
    // when the toggle is activated
    expect(screen.getByText(/Proceed with Quote/)).toBeInTheDocument();
    fireEvent.click(screen.getByText(/Proceed with Quote/));
    // Restore original implementation
    Storage.prototype.getItem = originalGetItem;
  });
});
describe('ExpandFooter styling based on isProspectPersonalShopper', () => {
  // Store the original window.mfe to restore it after tests
  const originalMfe = window.mfe;

  afterEach(() => {
    // Restore the original window.mfe after each test
    window.mfe = originalMfe;
    jest.clearAllMocks();
  });

  test('should apply prospect styles when window.mfe.isProspectPersonalShopper is true', () => {
    // 1. Setup the mock condition
    window.mfe = { isProspectPersonalShopper: true };

    // 2. Render the component
    render(
      <ExpandFooter
        hideFooter={mockHideFooter}
        expandFooterData={mockData}
        handleProceedToOrder={handleProceedToOrder}
        enableScroll
      />,
    );

    // 3. Find the components and assert their styles
    const footerContainer = screen.getByTestId('expandFooter');
    const wrapper = footerContainer.parentElement; // This gets the 'Wrapper' styled-component

    // Check FooterContainer style
    expect(footerContainer).toHaveStyle('bottom: 1.5rem');

    // Check Wrapper style. The style is an empty string,
    // so we'll assert it doesn't have the default value.
    expect(wrapper).not.toHaveStyle('background-color: rgba(0, 0, 0, 0.5)');
  });

  test('should apply default styles when window.mfe.isProspectPersonalShopper is false', () => {
    // 1. Setup the mock condition
    window.mfe = { isProspectPersonalShopper: false };

    // 2. Render the component
    render(
      <ExpandFooter
        hideFooter={mockHideFooter}
        expandFooterData={mockData}
        handleProceedToOrder={handleProceedToOrder}
        enableScroll
      />,
    );

    // 3. Find the components and assert their styles
    const footerContainer = screen.getByTestId('expandFooter');
    const wrapper = footerContainer.parentElement;

    // Check FooterContainer style
    expect(footerContainer).toHaveStyle('bottom: 0');

    // Check Wrapper style
    expect(wrapper).toHaveStyle('background-color: rgba(0, 0, 0, 0.5)');
  });

  test('should apply default styles when window.mfe is undefined', () => {
    // 1. Setup the mock condition
    delete window.mfe;

    // 2. Render the component
    render(
      <ExpandFooter
        hideFooter={mockHideFooter}
        expandFooterData={mockData}
        handleProceedToOrder={handleProceedToOrder}
        enableScroll
      />,
    );

    // 3. Find the components and assert their styles
    const footerContainer = screen.getByTestId('expandFooter');
    const wrapper = footerContainer.parentElement;

    // Check FooterContainer style
    expect(footerContainer).toHaveStyle('bottom: 0');

    // Check Wrapper style
    expect(wrapper).toHaveStyle('background-color: rgba(0, 0, 0, 0.5)');
  });
});
