import { render } from '@testing-library/react';
import rootReducer from './modules/store/reducer';
import { rootSaga } from './modules/store/saga';
import App from './App';

test('renders AddALine page', () => {
  render(<App />, {
    reducers: rootReducer,
    sagas: rootSaga,
  });
});
