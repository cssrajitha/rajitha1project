import { renderHook } from '@testing-library/react';
import { useGetCartDetailsQuery, useGetCustomerProfileQuery } from 'onevzsoemfecommon/APIService';
import {
  useGetFetchPricingSnapshotQuery,
  useGetMyOffersQuery,
} from '../../modules/services/APIService/APIServiceHooks';
import ShoplandingApiCallHook from './CartApiCallHook';
import * as domService from '../../modules/services/dom.service';

jest.mock('onevzsoemfecommon/APIService');
jest.mock('../../modules/services/APIService/APIServiceHooks');

test('should call useGetCustomerProfileQuery with the correct arguments', () => {
  renderHook(() => ShoplandingApiCallHook());

  expect(useGetCustomerProfileQuery).toHaveBeenCalled();
});

test('should call useGetCustomerProfileQuery with the correct arguments', () => {
  window.sessionStorage.setItem(
    'customerInfoParam',
    JSON.stringify({
      isUpdateCustomerAccount: false,
      customerInfo: {
        address: {
          streetNumber: '222',
          streetName: '222 222 POPLAR ST E',
          direction: '',
          streetType: '',
          aptSuite: '',
          city: 'FLASHER',
          state: 'ND',
          zipCode: '58535',
          zipCode4: '9711',
        },
        email: 'ZIRXSGVI@VZW.COM',
        skipMissedProfileEmailValidation: false,
        customerCbrInfo: {
          cbrNos: '7088173813',
        },
        customerName: {
          firstName: 'JACK',
          middleInitial: '',
          lastName: 'BELTRAN',
          suffix: '',
        },
      },
    }),
  );
  renderHook(() => ShoplandingApiCallHook());

  expect(useGetCustomerProfileQuery).toHaveBeenCalled();
});

describe(`test with Assisted Cradleflag on`, () => {
  beforeEach(() => {
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({ islocalStoreOfferEnabled: 'TRUE', localStoreOfferCompatbilePlans: '1234,4321' }),
    );
    jest
      .spyOn(domService, 'isFunctionalityEnabled')
      .mockImplementation(
        (value) => (value === 'floridaDiscountFFlag' || value === 'florida55AssistedDefectFFlag') && true,
      );
  });
  test('should call useGetCartDetailsQuery with the correct arguments', () => {
    renderHook(() => ShoplandingApiCallHook());

    expect(useGetCartDetailsQuery).toHaveBeenCalled();
  });
});

describe(`test with Assisted Cradleflag on`, () => {
  beforeEach(() => {
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({
        islocalStoreOfferEnabled: 'TRUE',
        refetchCustomerInfoFFlag: 'TRUE',
        localStoreOfferCompatbilePlans: '1234,4321',
      }),
    );
    jest
      .spyOn(domService, 'isFunctionalityEnabled')
      .mockImplementation((value) => value === 'floridaDiscountFFlag' && true);
  });
  test('should call useGetCartDetailsQuery with the correct arguments', () => {
    renderHook(() => ShoplandingApiCallHook());

    expect(useGetCartDetailsQuery).toHaveBeenCalled();
  });
});

describe(`test with Assisted Cradleflag on`, () => {
  beforeEach(() => {
    sessionStorage.setItem(
      'APP_PROPERTIES',
      JSON.stringify({
        islocalStoreOfferEnabled: 'FALSE',
        refetchCustomerInfoFFlag: 'TRUE',
        duplicateSessionIdFFlag: 'TRUE',
        localStoreOfferCompatbilePlans: '1234,4321',
      }),
    );
    jest.spyOn(domService, 'isFunctionalityEnabled').mockReturnValue(false);
  });
  test('should call useGetCartDetailsQuery with the correct arguments', () => {
    renderHook(() => ShoplandingApiCallHook());

    expect(useGetCartDetailsQuery).toHaveBeenCalled();
  });
});

test('should call useGetFetchPricingSnapshotQuery with the correct arguments', () => {
  renderHook(() => ShoplandingApiCallHook());

  expect(useGetFetchPricingSnapshotQuery).toHaveBeenCalled();
});

test('should call useGetMyOffersQuery with the correct arguments', () => {
  renderHook(() => ShoplandingApiCallHook());

  expect(useGetMyOffersQuery).toHaveBeenCalled();
});
