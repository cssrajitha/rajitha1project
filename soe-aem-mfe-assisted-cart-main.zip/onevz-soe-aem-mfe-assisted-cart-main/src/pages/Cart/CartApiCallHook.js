import { useGetCartDetailsQuery, useGetCustomerProfileQuery } from 'onevzsoemfecommon/APIService';

import {
  requestBodyRetriveCart,
  requestBodyCustomerProfile,
  requestBodyFetchPricingShapshort,
} from '../../modules/services/APIService/APIRequestBody';
import {
  useGetFetchPricingSnapshotQuery,
  useGetMyOffersQuery,
} from '../../modules/services/APIService/APIServiceHooks';
import { isFunctionalityEnabled } from '../../modules/services/dom.service';

const ShoplandingApiCallHook = () => {
  const assistedFlags = JSON.parse(
    sessionStorage.getItem('APP_PROPERTIES') ? sessionStorage.getItem('APP_PROPERTIES') : '{}',
  );
  const islocalStoreOfferEnabled = assistedFlags?.islocalStoreOfferEnabled
    ? assistedFlags?.islocalStoreOfferEnabled
    : '';
  const localStoreOfferCompatbilePlans = assistedFlags?.localStoreOfferCompatbilePlans
    ? assistedFlags?.localStoreOfferCompatbilePlans
    : '';
  const refetchCustomerInfoFFlag = /true/i.test(assistedFlags?.refetchCustomerInfoFFlag);

  const duplicateSessionIdFFlag = /true/i.test(assistedFlags?.duplicateSessionIdFFlag);

  const isOneUINbs = assistedFlags?.enableFullBlownMfeNbsPosFFlag ? assistedFlags?.enableFullBlownMfeNbsPosFFlag : '';

  const CustomerProfileResult = useGetCustomerProfileQuery(
    { body: requestBodyCustomerProfile, spinner: true },
    { refetchOnMountOrArgChange: false },
  );

  const requestBodyOfRetrieveCartForLocalStoreOffer = {
    meta: {
      client: 'CXP',
    },
    data: {
      cartId: '',
      retrieveCurrentFeatures: true,
      isLocalStoreOfferEnabled: true,
      eligiblePlanIdsForLocalStoreOffer: localStoreOfferCompatbilePlans,
      adobeSubkey: sessionStorage.getItem('adobe-sessionId') || '', // adobeSubkey is added solely for Tagging, pls do not remove it.
    },
  };
  const requestBodyRetriveCartNew = { ...requestBodyRetriveCart };

  if (duplicateSessionIdFFlag) {
    requestBodyRetriveCartNew.data.adobeSubkey = sessionStorage.getItem('adobe-sessionId') || ''; // adobeSubkey is added solely for Tagging, pls do not remove it.
  }

  const retrieveRequest = /true/i.test(islocalStoreOfferEnabled)
    ? requestBodyOfRetrieveCartForLocalStoreOffer
    : requestBodyRetriveCartNew;

  const isfloridaDiscountFFlag = isFunctionalityEnabled('floridaDiscountFFlag');
  const florida55AssistedDefectFFlag = isFunctionalityEnabled('florida55AssistedDefectFFlag');
  let floridarequest;

  if (isfloridaDiscountFFlag && florida55AssistedDefectFFlag) {
    floridarequest = { ...retrieveRequest };
    floridarequest.data = { ...floridarequest.data, isFloridaDiscountEnabled: true };
  } else if (isfloridaDiscountFFlag) {
    retrieveRequest.data.isFloridaDiscountEnabled = true;
  }

  const CartDetailsResult = useGetCartDetailsQuery(
    { body: isfloridaDiscountFFlag && florida55AssistedDefectFFlag ? floridarequest : retrieveRequest },
    {
      refetchOnMountOrArgChange: 10,
      skip: !CustomerProfileResult?.isSuccess,
    },
  );

  const requestBodyX = {
    ...requestBodyFetchPricingShapshort,
    unifiedNbsFlag: refetchCustomerInfoFFlag ? /true/i.test(isOneUINbs) : isOneUINbs,
  };

  const FetchPricingSnapShotResult = useGetFetchPricingSnapshotQuery(
    { body: requestBodyX, spinner: false },
    { refetchOnMountOrArgChange: 10, skip: !CustomerProfileResult?.isSuccess },
  );
  const MyOffers = useGetMyOffersQuery({ body: {} });

  return {
    CustomerProfileResult,
    CartDetailsResult,
    FetchPricingSnapShotResult,
    MyOffers,
  };
};

export default ShoplandingApiCallHook;
