import React from 'react';
import { render } from '../../utils/test-utils/renderHelper';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import Footer from './index';

describe(`Footer component`, () => {
  test('Footer should mount', async () => {
    render(<Footer />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
});
