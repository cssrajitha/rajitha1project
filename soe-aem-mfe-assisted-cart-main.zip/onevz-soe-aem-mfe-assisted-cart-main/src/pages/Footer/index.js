import React from 'react';
import PropTypes from 'prop-types';
import Footer from '../../components/Footer/Footer';

function CartFooter({
  isAIQuote,
  isEditTradeIn,
  deviceRecom,
  isInsideSalesorCustomerService,
  redirectToFlexOrdering,
  triggerProceedToQuote,
  setTriggerProceedToQuote,
  setIsManualTriage,
  isManualTriageDone,
  deviceTriageDone,
  channelInCreateCase,
  linesWithQuoteInCart,
  createAiQuoteResCollection,
  setMtnToBeSelectedWithoutGenratingQuote,
  setAssistedMtn,
  triggerFPSCallback,
  newLinesWithoutQuote,
  FetchPricingSnapShotResult,
  inlineShowLoader,
  activeMtnValue,
  tradeDevicesInCart,
  tradeAddedOnLoad,
  aiquoteResponse,
  setFPSProtectionData,
  triggerRetrieveCart,
  billingSystem,
  setIsProceedToQuote,
  setlinesWithoutProtection,
  linesWithoutProtection,
  setProtectionBanner,
  isCollaborationStartedForRC,
  isFiosEnabled,
  isRCCart,
  fiosOrderDetails,
  fiosReferralIndirectFFlag,
  showPriceDetails,
  setShowPriceDetails,
  setTaggingPayload,
  setShowDownPayment,
  activeLinePriceTypeInCart,
  customerBio,
  mtnListPriceEdit,
  isInDirect,
  disableProceedToQuote,
  acknowledgedBYODConfirmDevice,
  activeLineInfoInCart,
  mandatoryNumberShareLines,
  callCreateApplication,
  setShowNumberShareVerifyBanner,
  isAutopayEnabled,
  autopayDiscount,
  totalMonthlySavings,
  fetchCartDetailsResult,
  fpfCheckState,
  idCheckState,
  qualifiedAddressVHI,
  setShowVMPWarningModal,
  proceedQuoteWithDeclineProtection,
  declinedProtectionAddedByReps,
}) {
  return (
    <Footer
      proceedQuoteWithDeclineProtection={proceedQuoteWithDeclineProtection}
      setShowVMPWarningModal={setShowVMPWarningModal}
      isAIQuote={isAIQuote}
      isEditTradeIn={isEditTradeIn}
      deviceRecom={deviceRecom}
      setIsProceedToQuote={setIsProceedToQuote}
      linesWithQuoteInCart={linesWithQuoteInCart}
      tradeDevicesInCart={tradeDevicesInCart}
      tradeAddedOnLoad={tradeAddedOnLoad}
      isInsideSalesorCustomerService={isInsideSalesorCustomerService}
      redirectToFlexOrdering={redirectToFlexOrdering}
      setTriggerProceedToQuote={setTriggerProceedToQuote}
      triggerProceedToQuote={triggerProceedToQuote}
      setMtnToBeSelectedWithoutGenratingQuote={setMtnToBeSelectedWithoutGenratingQuote}
      setAssistedMtnFromAIQuote={setAssistedMtn}
      setIsManualTriage={setIsManualTriage}
      newLinesWithoutQuote={newLinesWithoutQuote}
      createAiQuoteResCollection={createAiQuoteResCollection}
      isManualTriageDone={isManualTriageDone}
      deviceTriageDone={deviceTriageDone}
      channelInCreateCase={channelInCreateCase}
      triggerFPSCallback={triggerFPSCallback}
      FetchPricingSnapShotResult={FetchPricingSnapShotResult}
      inlineShowLoader={inlineShowLoader}
      activeMtnValue={activeMtnValue}
      aiquoteResponse={aiquoteResponse}
      setFPSProtectionData={setFPSProtectionData}
      triggerRetrieveCart={triggerRetrieveCart}
      billingSystem={billingSystem}
      setlinesWithoutProtection={setlinesWithoutProtection}
      linesWithoutProtection={linesWithoutProtection}
      setProtectionBanner={setProtectionBanner}
      isCollaborationStartedForRC={isCollaborationStartedForRC}
      isFiosEnabled={isFiosEnabled}
      isRCCart={isRCCart}
      fiosOrderDetails={fiosOrderDetails}
      fiosReferralIndirectFFlag={fiosReferralIndirectFFlag}
      showPriceDetails={showPriceDetails}
      setShowPriceDetails={setShowPriceDetails}
      setTaggingPayload={setTaggingPayload}
      setShowDownPayment={setShowDownPayment}
      activeLinePriceTypeInCart={activeLinePriceTypeInCart}
      customerBio={customerBio}
      mtnListPriceEdit={mtnListPriceEdit}
      isInDirect={isInDirect}
      disableProceedToQuote={disableProceedToQuote}
      acknowledgedBYODConfirmDevice={acknowledgedBYODConfirmDevice}
      activeLineInfoInCart={activeLineInfoInCart}
      mandatoryNumberShareLines={mandatoryNumberShareLines}
      callCreateApplication={callCreateApplication}
      setShowNumberShareVerifyBanner={setShowNumberShareVerifyBanner}
      isAutopayEnabled={isAutopayEnabled}
      autopayDiscount={autopayDiscount}
      totalMonthlySavings={totalMonthlySavings}
      fetchCartDetailsResult={fetchCartDetailsResult}
      fpfCheckState={fpfCheckState}
      idCheckState={idCheckState}
      qualifiedAddressVHI={qualifiedAddressVHI}
      declinedProtectionAddedByReps={declinedProtectionAddedByReps}
    />
  );
}

export default CartFooter;
CartFooter.propTypes = {
  FetchPricingSnapShotResult: PropTypes.object,
  triggerFPSCallback: PropTypes.func,
  setIsProceedToQuote: PropTypes.func,
  inlineShowLoader: PropTypes.bool,
  triggerProceedToQuote: PropTypes.bool,
  setTriggerProceedToQuote: PropTypes.func,
  aiquoteResponse: PropTypes.object,
  setlinesWithoutProtection: PropTypes.func,
  linesWithoutProtection: PropTypes.bool,
  setProtectionBanner: PropTypes.func,
  setTaggingPayload: PropTypes.func,
  setShowDownPayment: PropTypes.func,
  customerBio: PropTypes.object,
  mtnListPriceEdit: PropTypes.object,
  isInDirect: PropTypes.bool,
  disableProceedToQuote: PropTypes.bool,
  mandatoryNumberShareLines: PropTypes.object,
  callCreateApplication: PropTypes.bool,
  setShowNumberShareVerifyBanner: PropTypes.func,
  isAutopayEnabled: PropTypes.bool,
  autopayDiscount: PropTypes.number,
  totalMonthlySavings: PropTypes.number,
  fetchCartDetailsResult: PropTypes.object,
  fpfCheckState: PropTypes.bool,
  idCheckState: PropTypes.bool,
  qualifiedAddressVHI:PropTypes.object,
  setShowVMPWarningModal: PropTypes.func,
  proceedQuoteWithDeclineProtection: PropTypes.bool,
  fiosOrderDetails: PropTypes.string,
  fiosReferralIndirectFFlag: PropTypes.string,
  declinedProtectionAddedByReps: PropTypes.array,
};
