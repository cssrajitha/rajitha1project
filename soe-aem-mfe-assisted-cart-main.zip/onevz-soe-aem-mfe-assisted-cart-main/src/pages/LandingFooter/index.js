import React from 'react';
import Footer from '../../components/LandingFooter/LandingFooter';

function LandingFooter() {
  return <Footer />;
}

export default LandingFooter;
