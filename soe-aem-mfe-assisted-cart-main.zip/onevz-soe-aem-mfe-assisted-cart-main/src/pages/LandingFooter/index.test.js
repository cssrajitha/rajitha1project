import React from 'react';
import {
  useLazyGetCustomerProfileQuery,
  useGetCustomerProfileQuery,
  useGetCartDetailsQuery,
} from 'onevzsoemfecommon/APIService';
import { render } from '../../utils/test-utils/renderHelper';
import rootReducer from '../../modules/store/reducer';
import { rootSaga } from '../../modules/store/saga';
import Footer from './index';

jest.mock('onevzsoemfecommon/APIService', () => ({
  useLazyGetCustomerProfileQuery: jest.fn(),
  useGetCustomerProfileQuery: jest.fn(),
  useGetCartDetailsQuery: jest.fn(),
}));

describe(`Footer component`, () => {
  beforeEach(() => {
    useLazyGetCustomerProfileQuery.mockReturnValue([jest.fn(), []]);
    useGetCustomerProfileQuery.mockReturnValue([jest.fn(), {}]);
    useGetCartDetailsQuery.mockReturnValue([jest.fn(), {}]);
  });
  test('Footer should mount', async () => {
    render(<Footer />, {
      reducers: rootReducer,
      sagas: rootSaga,
    });
  });
});
