/* eslint-disable no-param-reassign */
const { whenDev, whenProd } = require('@craco/craco');
// eslint-disable-next-line import/no-extraneous-dependencies
const cracoCommon = require('@onevz-soe-mfe-base/craco-config');
const path = require('path');
const { DedupePlugin } = require('@tinkoff/webpack-dedupe-plugin');
const { dependencies } = require('./package.json');

const branch = 'main';
const appPrefix = 'mfe-cart';
const timestamp = Date.now();
// MFE name must be unique
const mfeName = 'onevzsoemfeassistedcart';
const SERVER_PORT = 4004;
const buildParam = process.env.BUILD_PARAM || '';
const pathPrefix = buildParam === 'VBG' ? '/vbg' : '';

const remotes = {
  onevzsoemfeframework: `onevzsoemfeframework@${pathPrefix}/etc/clientlibs/vcg/common/onevzsoemfeframework/100/remoteEntry.js`,
  onevzsoemfecommon: `onevzsoemfecommon@${pathPrefix}/etc/clientlibs/vcg/common/onevzsoemfecommon/100/remoteEntry.js`,
};
// const remotes = {
//   onevzsoemfeframework: 'onevzsoemfeframework@/etc/clientlibs/vcg/common/onevzsoemfeframework/100/remoteEntry.js',
//   onevzsoemfecommon: 'onevzsoemfecommon@/etc/clientlibs/vcg/common/onevzsoemfecommon/100/remoteEntry.js',
// };
const localRemotes = {
  onevzsoemfeframework: 'onevzsoemfeframework@http://localhost:3001/remoteEntry.js',
  onevzsoemfecommon: 'onevzsoemfecommon@http://localhost:4002/remoteEntry.js',
};

const appCracoConfig = {
  mode: whenDev(() => 'development', 'production'),
  devServer: whenDev(() => ({
    host: '::',
    historyApiFallback: {
      disableDotRule: true,
    },
    port: SERVER_PORT,
    static: {
      directory: path.join(__dirname, 'dist'),
    },
    headers: {
      'Access-Control-Allow-Origin': '*',
    },
    liveReload: true,
    proxy: {
      '/api': {
        target: 'https://soe-hivv-nssit1.ebiz.verizon.com/',
        pathRewrite: { '^/api': '' },
        changeOrigin: true,
        secure: false,
      },
      '/generate/jwt': {
        target: 'https://onevzssosoe-east-gz-dit1.ebiz.verizon.com/',
        changeOrigin: true,
        secure: false,
      },
    },
  })),
  // devtool: "source-map", // Enable source maps
};

const commonConfig = cracoCommon.createCracoConfig({
  appCracoConfig,
  debug: false,
  moduleFederationOptions: {
    dependencies,
    debug: false,
    options: {
      name: mfeName,
      filename: 'remoteEntry.js',
      exposes: {
        './CartFooter': './src/pages/Footer',
        './LandingFooter': './src/pages/LandingFooter',
        './ExpandFooter': './src/components/Footer/ExpandFooter',
      },
      remotes: whenDev(() => localRemotes, remotes),
    },
  },
  moduleFederationTestPluginOptions: {
    branch,
    additionalBundlerConfig: {
      noExternal: [
        /@vds\/badges/,
        /@vds\/checkboxes/,
        /@vds\/icons/,
        /@vds\/lines/,
        /@vds\/modals/,
        /@vds\/selects/,
        /@vds\/tiles/,
        /@vds\/toggles/,
        /@vds\/tooltips/,
        /immer/,
      ],
    },
    // localRemotes
  },
  overrideWebpackConfigure: (webpackConfig) => {
    webpackConfig.plugins.push(
      new DedupePlugin({
        strategy: 'equality',
      }),
    );

    webpackConfig.output.filename = whenProd(() => `[name].[contenthash]${timestamp}.js`);
    webpackConfig.output.publicPath = whenProd(
      () => `${pathPrefix}/etc/clientlibs/vcg/assisted/soe-assisted-mfe/${mfeName}/100/`, // PROD publicPath
      'http://localhost:4004/', // DEV publicPath
    );

    if (webpackConfig?.optimization?.splitChunks?.cacheGroups) {
      webpackConfig.optimization.splitChunks.cacheGroups = {
        ...webpackConfig.optimization.splitChunks.cacheGroups,
        vendors: {
          chunks: 'async',
          test: /[\\/]node_modules[\\/](@vds[\\/]date-pickers|@vds[\\/]radio-swatches|react|lodash)[\\/]/,
          name: `${appPrefix}-vendors`,
          enforce: true,
          minChunks: 1,
          reuseExistingChunk: true,
        },
        // 'vendors-fallback': {
        //   chunks: 'async',
        //   test: /[\\/]node_modules[\\/](@vds[\\/]modals|react-clientside-effect|@vds[\\/]tooltips|focus-lock|react-focus-lock|react-side-effect|shallowequal|@uie|enquire\.js|@vds[\\/]type-lockups|@vds[\\/]typography|webfontloader|@vds-core|performance-now|@vds-tokens|add-px-to-style|raf|dom-css|to-camel-case|to-no-case|to-space-case|prefix-style|@vds[\\/]utilities|cuid)[\\/]/,
        //   name: `${appPrefix}-vendors-fallback`,
        //   enforce: true,
        //   minChunks: 1,
        //   reuseExistingChunk: true,
        // },
      };
    }

    return webpackConfig;
  },
  splitChunkOptions: {
    appPrefix,
  },
});

module.exports = commonConfig;
