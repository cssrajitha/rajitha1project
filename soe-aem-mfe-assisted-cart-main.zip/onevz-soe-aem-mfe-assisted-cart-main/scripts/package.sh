#!/bin/sh
REL_VERSION=$(echo ${GIT_BRANCH} | cut -d '/' -f2 | tr -d ' ')
REPO="onevz-soe-aem-mfe-assisted-cart"
PROP_PATH_NAME="com.verizon.vcg.soe.mfe-assisted.aem.ui.apps.cart"
CONTEXT_PATH="onevzsoemfeassistedcart"
VBGPATH=$1
MOCKS_ZIP_NAME='@mf-tests.zip'
DEPLOY_VERSION=100
ZIP_FOLDER=${PROP_PATH_NAME}-${REL_VERSION}.${BUILD_NUMBER}
VERSION_NUMBER=${REL_VERSION}.${BUILD_NUMBER}
VBG_PREFIX=""
if [ "${VBGPATH}" = "vbg" ] || [ "${VBGPATH}" = "VBG" ]; then
    VBG_PREFIX="vbg/"
    ZIP_FOLDER=${PROP_PATH_NAME}-${REL_VERSION}.${BUILD_NUMBER}.${VBGPATH}
fi

# Set the base path pattern and artifact path based on VBG_PREFIX
BASE_PATH="/etc/clientlibs/vcg/assisted/soe-assisted-mfe"
ARTIFACT_PATH="HIVV_SOE"
if [ -n "${VBG_PREFIX}" ]; then
    BASE_PATH="/${VBG_PREFIX}etc/clientlibs/vcg/assisted/soe-assisted-mfe"
    ARTIFACT_PATH="k6vv-aem-generic-np"
fi

if [ ${REPO} = "onevz-soe-aem-mfe-framework" ] || [ ${REPO} = "onevz-soe-aem-mfe-common" ] || [ ${REPO} = "onevz-soe-aem-mfe-assisted-plans" ];then
    TEMPLATE_NAME=onevz-soe-aem-mfe-common-manifest
else
    TEMPLATE_NAME=onevz-soe-aem-mfe-assisted-manifest
fi
CUR_DIR=$(pwd) && echo "Current working dir = ${CUR_DIR}"
ls -altrh
mkdir -p ${CUR_DIR}/${ZIP_FOLDER}
mkdir -p ${CUR_DIR}/build_template
curl -ks --config ${CUR_DIR}/configCL.txt https://oneartifactoryci.verizon.com/artifactory/${ARTIFACT_PATH}/${TEMPLATE_NAME}/MFE/${TEMPLATE_NAME}.zip -o  ${TEMPLATE_NAME}-${REL_VERSION}.zip
unzip -q ${TEMPLATE_NAME}-${REL_VERSION}.zip -d ${CUR_DIR}/build_template
if [ -d "${CUR_DIR}/build_template/jcr_root/apps" ]; then 
    rm -Rf ${CUR_DIR}/build_template/jcr_root/apps
fi
echo "updating filter.xml file"
sed -i "s#${BASE_PATH}#${BASE_PATH}/${CONTEXT_PATH}/${DEPLOY_VERSION}#g" ${CUR_DIR}/build_template/META-INF/vault/filter.xml
#sed -i 's#/etc/clientlibs/vcg/assisted/soe-assisted-mfe#/etc/clientlibs/vcg/assisted/soe-assisted-mfe/'${CONTEXT_PATH}'/'${DEPLOY_VERSION}'#g' ${CUR_DIR}/build_template/META-INF/vault/filter.xml
grep -v "/apps/vcg/components/soe-assisted/page/react-page-mfe" ${CUR_DIR}/build_template/META-INF/vault/filter.xml > temp.txt
mv temp.txt ${CUR_DIR}/build_template/META-INF/vault/filter.xml
sed -i 's#/version.config.js##g' ${CUR_DIR}/build_template/META-INF/vault/filter.xml
echo "Printing filter.xml file"
cat ${CUR_DIR}/build_template/META-INF/vault/filter.xml
cp -R ${CUR_DIR}/build_template/** ${CUR_DIR}/${ZIP_FOLDER}
echo "update properties.xml file"
if [ ${REPO} = "onevz-soe-aem-mfe-framework" ] || [ ${REPO} = "onevz-soe-aem-mfe-common" ] || [ ${REPO} = "onevz-soe-aem-mfe-assisted-plans" ]; then	
    mkdir -p ${CUR_DIR}/${ZIP_FOLDER}/jcr_root/etc/clientlibs/vcg/common/${CONTEXT_PATH}/${DEPLOY_VERSION}                    
else
    mkdir -p ${CUR_DIR}/${ZIP_FOLDER}/jcr_root/etc/clientlibs/vcg/assisted/soe-assisted-mfe/${CONTEXT_PATH}/${DEPLOY_VERSION}
fi
curl -ks --config ${CUR_DIR}/configCL.txt https://oneartifactoryci.verizon.com/artifactory/${ARTIFACT_PATH}/properties.xml_AEM_COMMON -o properties.xml_AEM_COMMON
cp  properties.xml_AEM_COMMON ${CUR_DIR}/${ZIP_FOLDER}/META-INF/vault/properties.xml
sed -i "s/VERSION_NUMBER/${VERSION_NUMBER}/g" ${CUR_DIR}/${ZIP_FOLDER}/META-INF/vault/properties.xml
sed -i "s/PROP_NAME/${PROP_PATH_NAME}/g" ${CUR_DIR}/${ZIP_FOLDER}/META-INF/vault/properties.xml
echo "Printing properties.xml file"
cat ${CUR_DIR}/${ZIP_FOLDER}/META-INF/vault/properties.xml
if [ ${REPO} = "onevz-soe-aem-mfe-framework" ] || [ ${REPO} = "onevz-soe-aem-mfe-common" ] || [ ${REPO} = "onevz-soe-aem-mfe-assisted-plans" ];then
    cp -R ${CUR_DIR}/build/** ${CUR_DIR}/${ZIP_FOLDER}/jcr_root/etc/clientlibs/vcg/common/${CONTEXT_PATH}/${DEPLOY_VERSION}
else
    cp -R $CUR_DIR/build/** ${CUR_DIR}/${ZIP_FOLDER}/jcr_root/etc/clientlibs/vcg/assisted/soe-assisted-mfe/${CONTEXT_PATH}/${DEPLOY_VERSION}
fi
echo "data under workspace"
ls -altrh ${CUR_DIR}
echo "data under build directory"
ls -altrh ${CUR_DIR}/build
echo "data under artifact folder ${CUR_DIR}/${ZIP_FOLDER}"
ls -altrh ${CUR_DIR}/${ZIP_FOLDER}
echo "Archiving the artifact => ${ZIP_FOLDER}.zip"
cd ${CUR_DIR}/${ZIP_FOLDER}
zip -r -qq ${CUR_DIR}/${ZIP_FOLDER}.zip jcr_root META-INF 
echo "Artifact created successfully => ${ZIP_FOLDER}.zip"
echo "uploading test.zip"
ls -l ${CUR_DIR}/dist
curl -ks --config ${CUR_DIR}/configCL.txt -X PUT "https://oneartifactoryci.verizon.com/artifactory/${ARTIFACT_PATH}/${CONTEXT_PATH}/ICON/${GIT_BRANCH}/${MOCKS_ZIP_NAME}" -T ${CUR_DIR}/dist/@mf-tests.zip
echo "uploading success"
