#!/bin/sh

# Update your local exact path of http server local to drop the built files
DEPLOY_LOCATION=/Users/<profilename>/Documents/httpserver/etc/clientlibs/vcg/assisted/soe-assisted-mfe/onevzsoemfeassistedcart/100/
rm -rfv "$DEPLOY_LOCATION"*
cp -r ./build/* $DEPLOY_LOCATION
