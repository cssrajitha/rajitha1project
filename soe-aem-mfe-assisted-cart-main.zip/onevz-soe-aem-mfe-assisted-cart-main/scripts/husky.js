const husky = require('@onevz-soe-mfe-tools/husky');

husky.addHooks({
  mode: {
    // coverage: 'SKIP',
    // contentLeak: MODES.SKIP,
    // commitMsg: MODES.SKIP,
    // fortify: MODES.SKIP,
    // linter: MODES.SKIP,
  },
  coverageOptions: {
    qualityGate: 80,
    collectCoverageFromNegationArray: [
      '!src/index.js',
      '!src/polyfills/index.js',
      '!src/*/*/Loadable.{js,jsx}',
      '!src/**/*/imports.{js,jsx}',
      '!src/**/*/Async*.{js,jsx}',
      '!src/assets/json/**/*',
      '!src/*mock*/**/*.[jt]s?(x)',
      '!src/**/*/*mock*.js',
      '!src/**/*mock*/**/*.[jt]s?(x)',
      '!src/**/*/*TestData*',
      '!src/**/*/*MockData*',
      '!src/bootstrap.js',
      '!src/index.js',
      '!src/reportWebVitals.js'
    ],
  },
});
