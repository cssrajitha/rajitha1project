#!/bin/sh

Color_Off='\033[0m' 
BRed="\033[1;31m"   
BGreen="\033[1;32m" 
BBlue="\033[1;34m"        # Blue
ex="$(date) -"

PASS_WITH_COLOR="${BGreen}PASS${Color_Off}"
FAIL_WITH_COLOR="${BRed}FAIL${Color_Off}"

# ######### Check coverage status #########
coverageValue="FAIL"
covFilename=hooks/COVERAGE_STATUS.txt
if [ -f $covFilename ] ; then
  	while read line; do
		if [[ "$line" == "PASS"* ]]; then
		#echo "PASS"
		coverageValue="PASS"
		fi
	done < $covFilename
	coverageValueWithCol="$FAIL_WITH_COLOR (Please refer logs in hooks/coverage.log)"
	if [[ "$coverageValue" == "PASS" ]]; then
		coverageValueWithCol="$PASS_WITH_COLOR"
	fi
	printf "\n$ex Code Coverage status         : $coverageValueWithCol \n"
fi


# ######### Check sca status #########
scaValue="FAIL"
scaFilename=hooks/SCA_STATUS.txt
if [ -f $scaFilename ] ; then
	while read line; do
		if [[ "$line" == "PASS"* ]]; then
		#echo "PASS"
		scaValue="PASS"
		fi
	done < $scaFilename
	scaValueWithCol="$FAIL_WITH_COLOR (Please refer logs in hooks/security.log)"
	if [[ "$scaValue" == "PASS" ]]; then
		scaValueWithCol="$PASS_WITH_COLOR"
	fi
	printf "$ex SCA Fortify status           : $scaValueWithCol \n"
fi


# ######### Check file size status #########
fileSizeValue="FAIL"
sizeFilename=hooks/FILESIZE_STATUS.txt
if [ -f $sizeFilename ] ; then
	while read line; do
		if [[ "$line" == "PASS"* ]]; then
		#echo "PASS"
		fileSizeValue="PASS"
		fi
	done < $sizeFilename
	fileSizeValueWithCol="$FAIL_WITH_COLOR (Please refer logs in hooks/sizeRestriction.log)"
	if [[ "$fileSizeValue" == "PASS" ]]; then
		fileSizeValueWithCol="$PASS_WITH_COLOR"
	fi
	printf "$ex File no of line count status : $fileSizeValueWithCol \n"
fi


# ######### Check the documentation status #########
docValue="FAIL"
docFilename=hooks/DOC_STATUS.txt
if [ -f $docFilename ] ; then
	while read line; do
		if [[ "$line" == "PASS"* ]]; then
		#echo "PASS"
		docValue="PASS"
		fi
	done < $docFilename
	docValueWithCol="$FAIL_WITH_COLOR (Please refer logs in hooks/documentation.log)"
	if [[ "$docValue" == "PASS" ]]; then
		docValueWithCol="$PASS_WITH_COLOR"
	fi
	printf "$ex Checked Documentation status : $docValueWithCol \n"
fi


# ######### Check the duplication status #########
# duplicationValue="FAIL"
# duplicationFilename=hooks/DUPL_STATUS.txt
# if [ -f $duplicationFilename ] ; then
# 	while read line; do
# 		if [[ "$line" == "PASS"* ]]; then
# 		#echo "PASS"
# 		duplicationValue="PASS"
# 		fi
# 	done < $duplicationFilename
# 	duplicationValueWithCol="$FAIL_WITH_COLOR"
# 	if [[ "$duplicationValue" == "PASS" ]]; then
# 		duplicationValueWithCol="$PASS_WITH_COLOR"
# 	fi
# 	printf "$ex Duplication checked status   : $duplicationValueWithCol"
# fi


# ######### Check the Content Leakage status #########
contentLeakageValue="FAIL"
contentLeakageFilename=hooks/LEAKAGE_STATUS.txt
if [ -f $contentLeakageFilename ] ; then
	while read line; do
		if [[ "$line" == "PASS"* ]]; then
		#echo "PASS"
		contentLeakageValue="PASS"
		fi
	done < $contentLeakageFilename
	contentLeakageValueWithCol="$FAIL_WITH_COLOR (Please refer logs in hooks/DLP.log)"
	if [[ "$contentLeakageValue" == "PASS" ]]; then
		contentLeakageValueWithCol="$PASS_WITH_COLOR"
	fi
	printf "$ex Content Leakage Status       : $contentLeakageValueWithCol \n"
fi


# ######### Check status for All #########
# if [[ $coverageValue == "PASS" ]] && [[ $scaValue == "PASS" ]] && [[ $fileSizeValue == "PASS" ]] && [[ $docValue == "PASS" ]] && [[ $duplicationValue == "PASS" ]] && [[ $contentLeakageValue == "PASS" ]]; then
if [[ $coverageValue == "PASS" ]] && [[ $scaValue == "PASS" ]] && [[ $fileSizeValue == "PASS" ]] && [[ $docValue == "PASS" ]] && [[ $contentLeakageValue == "PASS" ]]; then
smsg="${BGreen}Please visit the Dev360 portal for the Delivery Excellence Score for your recent commits -${Color_Off}"
slink="http://10.119.10.216:7006/ui/dev360/"
printf "$smsg \e]8;;$slink\a${BBlue}$slink\e]8;;\a ${Color_Off} \n"
printf "${BGreen}$(date) ### All pre-commit hooks are passed successful! ${Color_Off}\n"
if [[ -d "temp" ]]; then
  rm -rf hooks/COVERAGE_STATUS.txt
  rm -rf hooks/SCA_STATUS.txt
  rm -rf hooks/FILESIZE_STATUS.txt
  rm -rf hooks/DOC_STATUS.txt
  rm -rf hooks/DUPL_STATUS.txt
  rm -rf hooks/LEAKAGE_STATUS.txt
  if [ -f skip_files.txt ] ; then
	rm -rf skip_files.txt
  fi 
fi
else
	if [[ "$coverageValue" == "FAIL" ]] ||  [[ $scaValue == "FAIL" ]] || [[ "$fileSizeValue" == "FAIL" ]] || [[ "$docValue" == "FAIL" ]] || [[ "$contentLeakageValue" == "FAIL" ]]; then
	# if [[ "$coverageValue" == "FAIL" ]] ||  [[ $scaValue == "FAIL" ]] || [[ "$fileSizeValue" == "FAIL" ]] || [[ "$docValue" == "FAIL" ]] || [[ "$duplicationValue" == "FAIL" ]] || [[ "$contentLeakageValue" == "FAIL" ]]; then
		printf "${BRed}$ex Commit Failed! ${Color_Off}\n"		
		echo "$ex Commit Failed! \n" >> hooks/pre-commit.log
	fi 

	if [ -f hooks/COVERAGE_STATUS.txt ] ; then
		rm -rf hooks/COVERAGE_STATUS.txt
	fi	
	if [ -f hooks/SCA_STATUS.txt ] ; then
		rm -rf hooks/SCA_STATUS.txt
	fi	
	if [ -f hooks/FILESIZE_STATUS.txt ] ; then
		 rm -rf hooks/FILESIZE_STATUS.txt
	fi	
	if [ -f hooks/DOC_STATUS.txt ] ; then
		  rm -rf hooks/DOC_STATUS.txt
	fi	
	if [ -f hooks/DUPL_STATUS.txt ] ; then
		  rm -rf hooks/DUPL_STATUS.txt
	fi	
	if [ -f hooks/LEAKAGE_STATUS.txt ] ; then
		 rm -rf hooks/LEAKAGE_STATUS.txt
	fi	
  	if [ -f skip_files.txt ] ; then
		 rm -rf skip_files.txt
	fi  
 
exit 1
fi
