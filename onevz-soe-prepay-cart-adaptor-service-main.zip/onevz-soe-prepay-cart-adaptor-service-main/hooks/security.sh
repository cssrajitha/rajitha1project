#!/bin/sh

Color_Off='\033[0m' 
BRed="\033[1;31m"         # Red
BGreen="\033[1;32m"       # Green
BYellow="\033[1;33m"      # Yellow
BBlue="\033[1;34m"        # Blue


if [[ -d "temp" ]]; then
  rm -rf temp
fi
mkdir temp
# unzip Utils/Utils.jar -d temp > /dev/null
chmod 777 temp

# Checking message pattern for local
#FILE_CONTENT="$(eval cat .git/COMMIT_EDITMSG)";
#export REGEX='^((build|chore|ci|docs|feat|fix|perf|refactor|revert|style|test)(\(\w+\))?(!)?(: (.*\s*)*))|(Merge (.*\s*)*)|(Initial commit$)|(NSAT-98 version update$)|(Update .gitlab-ci.yml version$)'
#export ERROR_MSG="Commit failed. Commit message format must match \"${REGEX}\""
#if [[ $FILE_CONTENT =~ $REGEX ]]; then
#echo "Valid message pattern -  $FILE_CONTENT \n"  >> hooks/pre-commit.log
#echo "====Valid message pattern===  $FILE_CONTENT \n"
#else
#echo "Invalid message pattern -  $FILE_CONTENT \n" >> hooks/pre-commit.log
#echo "====Invalid message pattern====  $FILE_CONTENT \n"	
#echo "$ERROR_MSG\n" >> hooks/pre-commit.log
#echo "FAIL" >> hooks/SCA_STATUS.txt
#exit 1
#fi

# Checking fortify issues
if [[ "$OSTYPE" == "darwin"* ]]; then
hooks/analyzer/analyzer.sh > hooks/pre-commit.log
else
hooks/analyzer/analyzer.bat > hooks/pre-commit.log
fi

#sca testing from temp location on Utils

if [ -f temp/SCA_STATUS.txt ] ; then
	scaFilename=temp/SCA_STATUS.txt
	while read line; do
	if [[ "$line" == "PASS"* ]]; then
		echo "PASS" >> hooks/SCA_STATUS.txt
		exit 1
	fi
	done < $scaFilename
else
	printf "${BRed} Please enable SCA fortify for new file to check the bugs/errors.${Color_Off}\n"
	echo -e "$ex Please enable SCA fortify for new file to check the bugs/errors  \n"
	echo "FAIL" >> hooks/SCA_STATUS.txt
	exit 1
fi