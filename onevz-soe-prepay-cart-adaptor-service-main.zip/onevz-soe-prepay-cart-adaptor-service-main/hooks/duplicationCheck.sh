#!/bin/bash
Color_Off='\033[0m' 
BRed="\033[1;31m"         # Red
BGreen="\033[1;32m"       # Green
BYellow="\033[1;33m"      # Yellow
BBlue="\033[1;34m"        # Blue
 # if [ -s pom.xml ]; then
     # echo "Running mvn test"
     # mvn clean test	
     # if [ $? -ne 0 ]; then
         # echo "There are failed Unit test cases in the test suite. 100% unit test success is required for commit."
        # exit 1
	# else 
		# echo "All unit test cases successfully executed. Creating jacoco report"
		# mvn jacoco:report		
    # fi
# fi

calc() { awk "BEGIN{print $*}"; }
duplicateThreshold=10
ex="$(date) ### Exception"

skipfilesText="./src/main/java/onevz/soe/*"
rm -rf skip_files.txt
skipFiles="skip_files.txt"
echo "$skipfilesText" | tee -a $skipFiles

#Duplicate code check
pathToExclude=$(printf "! -path %s " $(<skip_files.txt))
#printf "${BGreen}Duplicate percent check for the repo... \n${Color_Off}"
echo -e "Duplicate percent check for the repo... \n"
#mvnOutput=(mvn  jxr:jxr pmd:aggregate-cpd)
mvn jxr:jxr pmd:aggregate-cpd --log-file hooks/cpd_output.log
DUPLICATE_INPUT=./target/cpd.csv

if [ -f ./target/cpd.csv ] ; then
	echo -e "$(date) Checking duplication.......... \n"
else
	echo "FAIL" >> hooks/DUPL_STATUS.txt 
	printf "${BRed} $ex Please run the command <mvn  jxr:jxr pmd:aggregate-cpd> to generate cpd.csv, then try to commit your stagged file. ${Color_Off}\n"
	printf "${BRed} $ex Commit Failed! Please check the logs on hooks/cpd_output.log.${Color_Off}\n"
	echo -e "$ex Please check the logs on hooks/cpd_output.log. \n" 
	echo -e "$ex Run the command <mvn  jxr:jxr pmd:aggregate-cpd> to generate cpd.csv, then try to run pre-commit hook. \n"
	exit 1
fi

iCounter=0
totalLines=0
#output=$(find ./src/main/java -name '*.java' -print0 $(printf "! -path %s " $(<skip_files.txt)) |xargs -0 wc -l|grep total|awk '{ sum+= $1; } END { print sum;}')
output=$(find ./src/main/java -mindepth 1 -name "*.java" $pathToExclude -print0 |xargs -0 wc -l|grep total|awk '{ sum+= $1; } END { print sum;}')
totalLines=$(sed -n '$p' <<< "$output" )

#printf "${BGreen}Total lines of code is $totalLines \n${Color_Off}"
echo -e "Total lines of code is $totalLines \n"
OLDIFS=$IFS
IFS=,
[ ! -f $DUPLICATE_INPUT ] && { echo "$DUPLICATE_INPUT file not found"; exit 99; }
while read lines  occurences ;
do	
	if [ $lines != 'lines' ]; then
		iCounter=$(($iCounter+$lines))
	fi
done < $DUPLICATE_INPUT
IFS=$OLDIFS

duplicatePercent=$((100*$iCounter/$totalLines))

[ -z "$duplicatePercent" ] && duplicatePercent=0

if [ -f hooks/cpd_output.log ] ; then
    rm hooks/cpd_output.log
fi

echo -e "Duplicate lines of code for the repo is: $iCounter. \n" 
if [[ "$duplicatePercent" -lt "$duplicateThreshold" ]]; then
	#printf "${BGreen}Duplication check is successful for the repo and current duplication is: $duplicatePercent%  \n${Color_Off}"
	echo -e "Duplication check is successful for the repo and current duplication is: $duplicatePercent%  \n"
	#echo "$FILE_CONTENT updated post commit [PASS][SCA] " > $MSG_FILE
	#printf "${BGreen}All pre-commit hooks are successful. Commit successful!${Color_Off}"
	echo "PASS" >> hooks/DUPL_STATUS.txt
	exit 1	 
else
	printf "${BRed}Duplicate percent is greater than $duplicateThreshold% and current duplication is $duplicatePercent%.${Color_Off}\e]8;;file:///$(git rev-parse --show-toplevel)/target/site/cpd.html\e\\ ${BBlue}Please click and check this link\e]8;;\e\\\ ${Color_Off}${BRed}to fix duplicates. Commit failed.${Color_Off}\n"
	rootlocation="file:///$(git rev-parse --show-toplevel)/target/site/cpd.html"
	echo -e "$ex - Duplicate percent is greater than $duplicateThreshold% and current duplication is $duplicatePercent%. \n" 
	echo -e "$ex - $rootlocation \n"
	echo -e "$ex - please check the above link in browser to fix duplicates. \n"
	echo "FAIL" >> hooks/DUPL_STATUS.txt 
    exit 1	
fi