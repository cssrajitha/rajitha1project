package onevz.soe.prepay.adaptor.cart.helper;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.requests.SwitchSimCXPRequest;
import onevz.soe.cart.responses.SwitchSimCXPResponse;
import onevz.soe.channels.SOEChannels;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.prepay.adaptor.cart.config.PrepayCartAdaptorServiceTestConfig;
import onevz.soe.prepay.adaptor.cart.model.cart.vo.VZWPrepayEditCartRequest;
import onevz.soe.prepay.adaptor.cart.model.cart.vo.VZWPrepayEditCartResponse;
import onevz.soe.prepay.adaptor.cart.util.FileReaderUtil;
import onevz.soe.prepay.payment.request.common.PaymentsSessionData;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.session.constants.SessionConstants;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import onevz.soe.wsclient.prepay.webclient.model.PrepaidAdaptorWebClientRequest;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.net.URI;
import java.util.Arrays;
import java.util.HashMap;
import java.util.UUID;

import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.*;
import static onevz.soe.prepay.payment.constants.PaymentConstants.SAFE_TECH_SESSION_ID_KEY;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {PrepayCartAdaptorServiceTestConfig.class})
@WebFluxTest(PrepayAdaptorCartSwitchSimHelper.class)
public class PrepayAdaptorCartSwitchSimHelperTest {

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    private PrepayAdaptorCartSwitchSimHelper switchSimHelper;

    @MockBean
    private PrepayAdaptorWebClient prepayAdaptorWebClient;

    @MockBean
    SOELoginSessionBean sessionBean;

    @Autowired
    private PrepayCartRedisHelper prepayCartRedisHelper;

    private final String mockDataLocation = "src/test/resources/data/";
    private PaymentsSessionData sessionData = null;

    @Before
    public void setup() {
        mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        when(sessionBean.setSessionData(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(sessionBean.getSessionData(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new HashMap<>()));
        try {
            String sessionDataStr = FileReaderUtil.readFromFile("data/redisPrepaidODRequestData.json");
            sessionData = mapper.readValue(sessionDataStr, PaymentsSessionData.class);
            final String token = UUID.randomUUID().toString();
            sessionData.setCartId(token);
            sessionData.setChannelId(SOEChannels.VZW_DOTCOM.getChannelName());
            sessionData.setCaseId(token);

        } catch (Exception e) {
            e.printStackTrace();
        }

        when(sessionBean.getSessionData(Arrays.asList(SessionConstants.MTN_KEY, SessionConstants.ACCOUNT_NUMBER_KEY,SAFE_TECH_SESSION_ID_KEY))).thenReturn(Mono.just(new HashMap<>()));
        when(sessionBean.getSessionData(Mockito.any(), Mockito.any())).thenReturn(Mono.just(sessionData));
    }


    @Test
    public void switchSimTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/switchSimCXPRequest.json");
        String responseODString = FileReaderUtil.readFromFile("data/switchSimODResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/redisPrepaidODRequestDataForSwitchSim.json");
        SwitchSimCXPRequest switchSimCXPRequest = mapper.readValue(requestString, SwitchSimCXPRequest.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/cart/switchSim");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(responseODString, HttpStatus.OK)));
        Mono<ResponseEntity<SwitchSimCXPResponse>> controllerResp = switchSimHelper.switchSim(httpRequest, switchSimCXPRequest);
        StepVerifier.create(controllerResp).assertNext(Assert::assertNotNull).verifyComplete();
    }

    @Test
    public void switchSimRedisErrorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/switchSimCXPRequest.json");
        String responseODString = FileReaderUtil.readFromFile("data/switchSimODResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/redisPrepaidODRequestDataForSwitchSim.json");
        SwitchSimCXPRequest switchSimCXPRequest = mapper.readValue(requestString, SwitchSimCXPRequest.class);
        //VZWPrepayEditCartResponse switchSimODResponse = mapper.readValue(responseODString, VZWPrepayEditCartResponse.class);
        //PrepaidODRequestData prepaidODRequestData = mapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/cart/switchSim");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.empty());
        Mono<ResponseEntity<SwitchSimCXPResponse>> controllerResp = switchSimHelper.switchSim(httpRequest, switchSimCXPRequest);
        StepVerifier.create(controllerResp).assertNext(Assert::assertNotNull).verifyComplete();
    }

    @Test
    public void switchSimRedisParsingErrorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/switchSimCXPRequest.json");
        String responseODString = FileReaderUtil.readFromFile("data/switchSimODResponse.json");
        String prepaidODRequestDataString = "{\"ecommSessionId\": {}}";
        SwitchSimCXPRequest switchSimCXPRequest = mapper.readValue(requestString, SwitchSimCXPRequest.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/cart/switchSim");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        Mono<ResponseEntity<SwitchSimCXPResponse>> controllerResp = switchSimHelper.switchSim(httpRequest, switchSimCXPRequest);
        StepVerifier.create(controllerResp).assertNext(Assert::assertNotNull).verifyComplete();
    }

    @Test
    public void switchSimServiceErrorStatusTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/switchSimCXPRequest.json");
        String responseODErrString = FileReaderUtil.readFromFile("data/switchSimODErrResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/redisPrepaidODRequestDataForSwitchSim.json");
        SwitchSimCXPRequest switchSimCXPRequest = mapper.readValue(requestString, SwitchSimCXPRequest.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/cart/switchSim");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(responseODErrString, HttpStatus.INTERNAL_SERVER_ERROR)));
        Mono<ResponseEntity<SwitchSimCXPResponse>> controllerResp = switchSimHelper.switchSim(httpRequest, switchSimCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> resp.getStatusCode().equals(HttpStatus.INTERNAL_SERVER_ERROR)).verifyComplete();
    }

    @Test
    public void switchSimServiceErrorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/switchSimCXPRequest.json");
        String responseODString = FileReaderUtil.readFromFile("data/switchSimODResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/redisPrepaidODRequestDataForSwitchSim.json");
        SwitchSimCXPRequest switchSimCXPRequest = mapper.readValue(requestString, SwitchSimCXPRequest.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/cart/switchSim");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>("", HttpStatus.OK)));
        Mono<ResponseEntity<SwitchSimCXPResponse>> controllerResp = switchSimHelper.switchSim(httpRequest, switchSimCXPRequest);
        StepVerifier.create(controllerResp).assertNext(Assert::assertNotNull).verifyComplete();
    }

    @Test
    public void switchSimInvalidMtnErrorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/switchSimCXPRequest.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/redisPrepaidODRequestDataForSwitchSim.json");
        SwitchSimCXPRequest switchSimCXPRequest = mapper.readValue(requestString, SwitchSimCXPRequest.class);
        switchSimCXPRequest.getData().setMtn(null);
        URI url = URI.create("http://localhost/prepaid-adaptor/cart/switchSim");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>("", HttpStatus.OK)));
        Mono<ResponseEntity<SwitchSimCXPResponse>> controllerResp = switchSimHelper.switchSim(httpRequest, switchSimCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> resp.getStatusCode().equals(HttpStatus.INTERNAL_SERVER_ERROR)).verifyComplete();
    }

    @Test
    public void switchSimForEsimOnlyDeviceErrorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/switchSimCXPRequest.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/redisPrepaidODRequestDataForSwitchSim.json");
        prepaidODRequestDataString = prepaidODRequestDataString.replace("\"esimOnly\": false", "\"esimOnly\": true");
        SwitchSimCXPRequest switchSimCXPRequest = mapper.readValue(requestString, SwitchSimCXPRequest.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/cart/switchSim");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>("", HttpStatus.OK)));
        Mono<ResponseEntity<SwitchSimCXPResponse>> controllerResp = switchSimHelper.switchSim(httpRequest, switchSimCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> resp.getStatusCode().equals(HttpStatus.INTERNAL_SERVER_ERROR)).verifyComplete();
    }

    @Test
    public void switchSimPsimTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/switchSimCXPRequest.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/redisPrepaidODRequestDataForSwitchSim.json");
        SwitchSimCXPRequest switchSimCXPRequest = mapper.readValue(requestString, SwitchSimCXPRequest.class);
        switchSimCXPRequest.getData().setSimType(SWITCHSIM_OD_SIMTYPE_PSIM);
        URI url = URI.create("http://localhost/prepaid-adaptor/cart/switchSim");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>("", HttpStatus.OK)));
        Mono<ResponseEntity<SwitchSimCXPResponse>> controllerResp = switchSimHelper.switchSim(httpRequest, switchSimCXPRequest);
        StepVerifier.create(controllerResp).assertNext(Assert::assertNotNull).verifyComplete();
    }

    @Test
    public void switchSimEsimTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/switchSimCXPRequest.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/redisPrepaidODRequestDataForSwitchSim.json");
        prepaidODRequestDataString = prepaidODRequestDataString.replace("\"capacity\": \"\"", "\"eSimId\": \"1234\"");
        SwitchSimCXPRequest switchSimCXPRequest = mapper.readValue(requestString, SwitchSimCXPRequest.class);
        switchSimCXPRequest.getData().setSimType(SWITCHSIM_OD_SIMTYPE_ESIM);
        switchSimCXPRequest.getData().setESimId("1234");
        URI url = URI.create("http://localhost/prepaid-adaptor/cart/switchSim");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>("", HttpStatus.OK)));
        Mono<ResponseEntity<SwitchSimCXPResponse>> controllerResp = switchSimHelper.switchSim(httpRequest, switchSimCXPRequest);
        StepVerifier.create(controllerResp).assertNext(Assert::assertNotNull).verifyComplete();
    }

    @Test
    public void switchSimTest_1() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/switchSimCXPRequest.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/redisPrepaidODRequestDataForSwitchSim.json");
        prepaidODRequestDataString = prepaidODRequestDataString.replace("\"capacity\": \"\"", "\"eSimId\": \"1234\"");
        SwitchSimCXPRequest switchSimCXPRequest = mapper.readValue(requestString, SwitchSimCXPRequest.class);
        switchSimCXPRequest.getData().setSimType("swutchSim");
        switchSimCXPRequest.getData().setESimId("1234");
        URI url = URI.create("http://localhost/prepaid-adaptor/cart/switchSim");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>("", HttpStatus.OK)));
        Mono<ResponseEntity<SwitchSimCXPResponse>> controllerResp = switchSimHelper.switchSim(httpRequest, switchSimCXPRequest);
        StepVerifier.create(controllerResp).assertNext(Assert::assertNotNull).verifyComplete();
    }

    @Test
    public void switchSimEsimForsmartIMEIFlowErrorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/switchSimCXPRequest.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/redisPrepaidODRequestDataForSwitchSim.json");
        SwitchSimCXPRequest switchSimCXPRequest = mapper.readValue(requestString, SwitchSimCXPRequest.class);
        switchSimCXPRequest.getData().setSimType(SWITCHSIM_OD_SIMTYPE_ESIM);
        switchSimCXPRequest.getData().setSmartImeiDevice(true);
        switchSimCXPRequest.getData().setESimId("1234");
        URI url = URI.create("http://localhost/prepaid-adaptor/cart/switchSim");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>("", HttpStatus.OK)));
        Mono<ResponseEntity<SwitchSimCXPResponse>> controllerResp = switchSimHelper.switchSim(httpRequest, switchSimCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> resp.getStatusCode().equals(HttpStatus.INTERNAL_SERVER_ERROR)).verifyComplete();
    }

    @Test
    public void switchSimEsimNotMatchWithRedisEsimIdErrorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/switchSimCXPRequest.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/redisPrepaidODRequestDataForSwitchSim.json");
        SwitchSimCXPRequest switchSimCXPRequest = mapper.readValue(requestString, SwitchSimCXPRequest.class);
        switchSimCXPRequest.getData().setSimType(SWITCHSIM_OD_SIMTYPE_ESIM);
        switchSimCXPRequest.getData().setESimId("1234");
        URI url = URI.create("http://localhost/prepaid-adaptor/cart/switchSim");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>("", HttpStatus.OK)));
        Mono<ResponseEntity<SwitchSimCXPResponse>> controllerResp = switchSimHelper.switchSim(httpRequest, switchSimCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> resp.getStatusCode().equals(HttpStatus.INTERNAL_SERVER_ERROR)).verifyComplete();
    }

    @Test
    public void switchSimWithEmptySimIdErrorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/switchSimCXPRequest.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/redisPrepaidODRequestDataForSwitchSim.json");
        PrepaidODRequestData redisData = mapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        redisData.getLines().forEach(data -> data.setSimId("1234"));
        prepaidODRequestDataString = mapper.writeValueAsString(redisData);
        SwitchSimCXPRequest switchSimCXPRequest = mapper.readValue(requestString, SwitchSimCXPRequest.class);
        switchSimCXPRequest.getData().setSimType(SWITCHSIM_OD_SIMTYPE_VZSIM);
        switchSimCXPRequest.getData().setSimId(null);
        URI url = URI.create("http://localhost/prepaid-adaptor/cart/switchSim");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>("", HttpStatus.OK)));
        Mono<ResponseEntity<SwitchSimCXPResponse>> controllerResp = switchSimHelper.switchSim(httpRequest, switchSimCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> resp.getStatusCode().equals(HttpStatus.INTERNAL_SERVER_ERROR)).verifyComplete();
    }

    @Test
    public void switchSimWithESimIdErrorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/switchSimCXPRequest.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/redisPrepaidODRequestDataForSwitchSim.json");
        PrepaidODRequestData redisData = mapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        redisData.getLines().forEach(data -> data.setSimId("1234"));
        prepaidODRequestDataString = mapper.writeValueAsString(redisData);
        SwitchSimCXPRequest switchSimCXPRequest = mapper.readValue(requestString, SwitchSimCXPRequest.class);
        switchSimCXPRequest.getData().setSimType(SWITCHSIM_OD_SIMTYPE_ESIM);
        switchSimCXPRequest.getData().setESimId("1234");
        URI url = URI.create("http://localhost/prepaid-adaptor/cart/switchSim");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>("", HttpStatus.OK)));
        Mono<ResponseEntity<SwitchSimCXPResponse>> controllerResp = switchSimHelper.switchSim(httpRequest, switchSimCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> resp.getStatusCode().equals(HttpStatus.INTERNAL_SERVER_ERROR)).verifyComplete();
    }

    @Test
    public void switchSimWithESimIdAndSmartImeiErrorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/switchSimCXPRequest.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/redisPrepaidODRequestDataForSwitchSim.json");
        PrepaidODRequestData redisData = mapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        redisData.getLines().forEach(data -> {
            data.setESimId("1234");
            data.setSimId("1234");
        });
        prepaidODRequestDataString = mapper.writeValueAsString(redisData);
        SwitchSimCXPRequest switchSimCXPRequest = mapper.readValue(requestString, SwitchSimCXPRequest.class);
        switchSimCXPRequest.getData().setSimType(SWITCHSIM_OD_SIMTYPE_ESIM);
        switchSimCXPRequest.getData().setESimId("1234");
        switchSimCXPRequest.getData().setSmartImeiDevice(true);
        URI url = URI.create("http://localhost/prepaid-adaptor/cart/switchSim");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>("", HttpStatus.OK)));
        Mono<ResponseEntity<SwitchSimCXPResponse>> controllerResp = switchSimHelper.switchSim(httpRequest, switchSimCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> resp.getStatusCode().equals(HttpStatus.INTERNAL_SERVER_ERROR)).verifyComplete();
    }

    @Test
    public void switchSimWithESimIdTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/switchSimCXPRequest.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/redisPrepaidODRequestDataForSwitchSim.json");
        PrepaidODRequestData redisData = mapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        redisData.getLines().forEach(data -> {
            data.setESimId("1234");
            data.setSimId("1234");
        });
        prepaidODRequestDataString = mapper.writeValueAsString(redisData);
        SwitchSimCXPRequest switchSimCXPRequest = mapper.readValue(requestString, SwitchSimCXPRequest.class);
        switchSimCXPRequest.getData().setSimType(SWITCHSIM_OD_SIMTYPE_ESIM);
        switchSimCXPRequest.getData().setESimId("1234");
        URI url = URI.create("http://localhost/prepaid-adaptor/cart/switchSim");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>("", HttpStatus.OK)));
        Mono<ResponseEntity<SwitchSimCXPResponse>> controllerResp = switchSimHelper.switchSim(httpRequest, switchSimCXPRequest);
        StepVerifier.create(controllerResp).assertNext(Assert::assertNotNull).verifyComplete();
    }

    @Test
    public void switchSimWithSimIdErrorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/switchSimCXPRequest.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/redisPrepaidODRequestDataForSwitchSim.json");
        PrepaidODRequestData redisData = mapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        redisData.getLines().forEach(data -> data.setSimId("1234"));
        prepaidODRequestDataString = mapper.writeValueAsString(redisData);
        SwitchSimCXPRequest switchSimCXPRequest = mapper.readValue(requestString, SwitchSimCXPRequest.class);
        switchSimCXPRequest.getData().setSimType(SWITCHSIM_OD_SIMTYPE_ESIM);
        switchSimCXPRequest.getData().setSimId("1234");
        URI url = URI.create("http://localhost/prepaid-adaptor/cart/switchSim");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>("", HttpStatus.OK)));
        Mono<ResponseEntity<SwitchSimCXPResponse>> controllerResp = switchSimHelper.switchSim(httpRequest, switchSimCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> resp.getStatusCode().equals(HttpStatus.INTERNAL_SERVER_ERROR)).verifyComplete();
    }

    @Test
    public void switchSimWithEsimIdErrorTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/switchSimCXPRequest.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/redisPrepaidODRequestDataForSwitchSim.json");
        PrepaidODRequestData redisData = mapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        redisData.getLines().forEach(data -> data.setESimId("1234"));
        prepaidODRequestDataString = mapper.writeValueAsString(redisData);
        SwitchSimCXPRequest switchSimCXPRequest = mapper.readValue(requestString, SwitchSimCXPRequest.class);
        switchSimCXPRequest.getData().setSimType(SWITCHSIM_OD_SIMTYPE_ESIM);
        switchSimCXPRequest.getData().setESimId("1234");
        URI url = URI.create("http://localhost/prepaid-adaptor/cart/switchSim");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>("", HttpStatus.OK)));
        Mono<ResponseEntity<SwitchSimCXPResponse>> controllerResp = switchSimHelper.switchSim(httpRequest, switchSimCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> resp.getStatusCode().equals(HttpStatus.INTERNAL_SERVER_ERROR)).verifyComplete();
    }

    @Test
    public void switchSimSuccessTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/switchSimCXPRequest.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/redisPrepaidODRequestDataForSwitchSim.json");
        PrepaidODRequestData redisData = mapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        redisData.getLines().forEach(data -> {
            data.setESimId("1234");
            data.setSimId("1234");
        });
        prepaidODRequestDataString = mapper.writeValueAsString(redisData);
        SwitchSimCXPRequest switchSimCXPRequest = mapper.readValue(requestString, SwitchSimCXPRequest.class);
        switchSimCXPRequest.getData().setSimType(SWITCHSIM_OD_SIMTYPE_ESIM);
        switchSimCXPRequest.getData().setESimId("1234");
        URI url = URI.create("http://localhost/prepaid-adaptor/cart/switchSim");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>("{ \"status\" : \"OK\"}", HttpStatus.OK)));
        Mono<ResponseEntity<SwitchSimCXPResponse>> controllerResp = switchSimHelper.switchSim(httpRequest, switchSimCXPRequest);
        StepVerifier.create(controllerResp).assertNext(Assert::assertNotNull).verifyComplete();
    }

    @Test
    public void switchSimErrorWhileCallingPrepaidLegacyServiceRequestTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/switchSimCXPRequest.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/redisPrepaidODRequestDataForSwitchSim.json");
        PrepaidODRequestData redisData = mapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        redisData.getLines().forEach(data -> {
            data.setESimId("1234");
            data.setSimId("1234");
        });
        prepaidODRequestDataString = mapper.writeValueAsString(redisData);
        SwitchSimCXPRequest switchSimCXPRequest = mapper.readValue(requestString, SwitchSimCXPRequest.class);
        switchSimCXPRequest.getData().setSimType(SWITCHSIM_OD_SIMTYPE_ESIM);
        switchSimCXPRequest.getData().setESimId("1234");
        URI url = URI.create("http://localhost/prepaid-adaptor/cart/switchSim");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>("{\"status\" : \"\", \"payload\" : {\"pageData\" : { \"sessionId\" : \"xyz-123\"}}}", HttpStatus.NOT_FOUND)));
        Mono<ResponseEntity<SwitchSimCXPResponse>> controllerResp = switchSimHelper.switchSim(httpRequest, switchSimCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> resp.getStatusCode().equals(HttpStatus.NOT_FOUND)).verifyComplete();
    }

    @Test
    public void switchSimErrorWhileCallingPrepaidLegacyServiceRequestTest_statusnotok() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/switchSimCXPRequest.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/redisPrepaidODRequestDataForSwitchSim.json");
        PrepaidODRequestData redisData = mapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        redisData.getLines().forEach(data -> {
            data.setESimId("1234");
            data.setSimId("1234");
        });
        prepaidODRequestDataString = mapper.writeValueAsString(redisData);
        SwitchSimCXPRequest switchSimCXPRequest = mapper.readValue(requestString, SwitchSimCXPRequest.class);
        switchSimCXPRequest.getData().setSimType(SWITCHSIM_OD_SIMTYPE_ESIM);
        switchSimCXPRequest.getData().setESimId("1234");
        URI url = URI.create("http://localhost/prepaid-adaptor/cart/switchSim");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>("{\"status\" : \"NOTOK\", \"payload\" : {\"pageData\" : { \"sessionId\" : \"xyz-123\"}}}", HttpStatus.OK)));
        Mono<ResponseEntity<SwitchSimCXPResponse>> controllerResp = switchSimHelper.switchSim(httpRequest, switchSimCXPRequest);
        StepVerifier.create(controllerResp).assertNext(resp-> resp.getStatusCode().equals(HttpStatus.NOT_FOUND)).verifyComplete();
    }

    @Test
    public void getPrepaidLegacyServiceRequestForSwitchSimTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/switchSimCXPRequest.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/redisPrepaidODRequestDataForSwitchSim.json");
        SwitchSimCXPRequest switchSimCXPRequest = mapper.readValue(requestString, SwitchSimCXPRequest.class);
        PrepaidODRequestData  prepaidODRequestData = mapper.readValue(prepaidODRequestDataString, PrepaidODRequestData.class);
        String flow = "NSEBYOD";
        PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest  = ReflectionTestUtils.invokeMethod(switchSimHelper, "getPrepaidLegacyServiceRequestForSwitchSim", switchSimCXPRequest, prepaidODRequestData, new VZWPrepayEditCartRequest(),flow);
        Assert.assertNotNull(prepaidAdaptorWebClientRequest);
    }

    @Test
    public void buildSwitchSimResponseTest() throws IOException {
        String responseODString = FileReaderUtil.readFromFile("data/switchSimODResponse.json");
        VZWPrepayEditCartResponse vzwPrepayEditCartResponse = mapper.readValue(responseODString, VZWPrepayEditCartResponse.class);
        SwitchSimCXPResponse switchSimCXPResponse  = ReflectionTestUtils.invokeMethod(switchSimHelper, "buildSwitchSimResponse", vzwPrepayEditCartResponse);
        Assert.assertNotNull(switchSimCXPResponse);
    }

    @Test
    public void buildSwitchSimErrorResponseTest() throws IOException {
        String responseODString = FileReaderUtil.readFromFile("data/switchSimODErrResponse.json");
        VZWPrepayEditCartResponse vzwPrepayEditCartResponse = mapper.readValue(responseODString, VZWPrepayEditCartResponse.class);
        SwitchSimCXPResponse switchSimCXPResponse  = ReflectionTestUtils.invokeMethod(switchSimHelper, "buildSwitchSimErrorResponse", vzwPrepayEditCartResponse);
        Assert.assertNotNull(switchSimCXPResponse);
    }

    @Test
    public void switchSimESimToVZSIMTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/switchSimCXPRequestVzSim.json");
        String responseODString = FileReaderUtil.readFromFile("data/switchSimODResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/redisPrepaidODRequestDataForSwitchSimFromESim.json");
        SwitchSimCXPRequest switchSimCXPRequest = mapper.readValue(requestString, SwitchSimCXPRequest.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/cart/switchSim");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(responseODString, HttpStatus.OK)));
        Mono<ResponseEntity<SwitchSimCXPResponse>> controllerResp = switchSimHelper.switchSim(httpRequest, switchSimCXPRequest);
        StepVerifier.create(controllerResp).assertNext(Assert::assertNotNull).verifyComplete();
    }

    @Test
    public void switchSimESimToVZSIMTest_1() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/switchSimCXPRequestVzSim.json");
        String responseODString = FileReaderUtil.readFromFile("data/switchSimODResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/redisPrepaidODRequestDataForSwitchSimFromESim.json");
        SwitchSimCXPRequest switchSimCXPRequest = mapper.readValue(requestString, SwitchSimCXPRequest.class);
        switchSimCXPRequest.getData().setSimId("simId");
        URI url = URI.create("http://localhost/prepaid-adaptor/cart/switchSim");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(responseODString, HttpStatus.OK)));
        Mono<ResponseEntity<SwitchSimCXPResponse>> controllerResp = switchSimHelper.switchSim(httpRequest, switchSimCXPRequest);
        StepVerifier.create(controllerResp).assertNext(Assert::assertNotNull).verifyComplete();
    }

    @Test
    public void switchSimESimToPSIMTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/switchSimCXPRequestPSim.json");
        String responseODString = FileReaderUtil.readFromFile("data/switchSimODResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/redisPrepaidODRequestDataForSwitchSimFromESim.json");
        SwitchSimCXPRequest switchSimCXPRequest = mapper.readValue(requestString, SwitchSimCXPRequest.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/cart/switchSim");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(responseODString, HttpStatus.OK)));
        Mono<ResponseEntity<SwitchSimCXPResponse>> controllerResp = switchSimHelper.switchSim(httpRequest, switchSimCXPRequest);
        StepVerifier.create(controllerResp).assertNext(Assert::assertNotNull).verifyComplete();
    }


    @Test
    public void switchSimESimToPSIMSIMIDTest() throws IOException {
        String requestString = FileReaderUtil.readFromFile("data/switchSimCXPRequest.json");
        String responseODString = FileReaderUtil.readFromFile("data/switchSimODResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/redisPrepaidODRequestDataForSwitchSimFromESim.json");
        SwitchSimCXPRequest switchSimCXPRequest = mapper.readValue(requestString, SwitchSimCXPRequest.class);
        URI url = URI.create("http://localhost/prepaid-adaptor/cart/switchSim");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(responseODString, HttpStatus.OK)));
        Mono<ResponseEntity<SwitchSimCXPResponse>> controllerResp = switchSimHelper.switchSim(httpRequest, switchSimCXPRequest);
        StepVerifier.create(controllerResp).assertNext(Assert::assertNotNull).verifyComplete();
    }


}
