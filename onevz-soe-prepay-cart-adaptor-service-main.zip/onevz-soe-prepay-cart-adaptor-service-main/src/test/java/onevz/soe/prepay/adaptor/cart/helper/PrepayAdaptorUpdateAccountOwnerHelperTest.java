package onevz.soe.prepay.adaptor.cart.helper;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import net.jcip.annotations.NotThreadSafe;
import onevz.soe.cart.requests.AccountOwnerPEGARequest;
import onevz.soe.cart.responses.AccountOwnerPEGAResponse;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.common.model.PrepaidODRequestDataAccessorySkuIds;
import onevz.soe.common.model.PrepaidODRequestDataLines;
import onevz.soe.od.model.VZWPrepayAccountOwnerRequest;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_DATA;
import static org.mockito.Mockito.when;

@WebFluxTest
@RunWith(SpringJUnit4ClassRunner.class)
@NotThreadSafe
public class PrepayAdaptorUpdateAccountOwnerHelperTest {

    @Autowired
    PrepayAdaptorUpdateAccountOwnerHelper helper;

    @Autowired
    ObjectMapper mapper;

    @MockBean
    PrepayCartRedisHelper prepayCartRedisHelper;

    @MockBean
    PrepayAdaptorWebClient prepayAdaptorWebClient;

    private PrepaidODRequestData getRedisData(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setMtn("newLine1");
        line.setFlow("NSE");
        line.setCheckoutFlag(true);
        lines.add(line);

        List<String> featureSkuIds = new ArrayList<>();
        featureSkuIds.add("sku3920521");
        featureSkuIds.add("feature13");
        //adding AccessoryskuId
        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        line.setAccessorySkuIds(accessorySkuIds);
        line.setFeatureSkuIds(featureSkuIds);

        redisData.setLines(lines);

        return redisData;
    }

    private PrepaidODRequestData getRedisData2(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setMtn("newLine1");
        line.setFlow("NSEBYOD");
        line.setCheckoutFlag(true);
        lines.add(line);

        List<String> featureSkuIds = new ArrayList<>();
        featureSkuIds.add("sku3920521");
        featureSkuIds.add("feature13");
        //adding AccessoryskuId
        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        line.setAccessorySkuIds(accessorySkuIds);
        line.setFeatureSkuIds(featureSkuIds);

        redisData.setLines(lines);

        return redisData;
    }
    private PrepaidODRequestData getRedisData3(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setMtn("newLine1");
        line.setFlow("ESO");
        line.setCheckoutFlag(true);
        lines.add(line);

        List<String> featureSkuIds = new ArrayList<>();
        featureSkuIds.add("sku3920521");
        featureSkuIds.add("feature13");
        //adding AccessoryskuId
        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        line.setAccessorySkuIds(accessorySkuIds);
        line.setFeatureSkuIds(featureSkuIds);

        redisData.setLines(lines);

        return redisData;
    }

    private PrepaidODRequestData getRedisData4(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setMtn("newLine1");
        line.setFlow("NSP");
        line.setCheckoutFlag(true);
        lines.add(line);

        List<String> featureSkuIds = new ArrayList<>();
        featureSkuIds.add("sku3920521");
        featureSkuIds.add("feature13");
        //adding AccessoryskuId
        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        line.setAccessorySkuIds(accessorySkuIds);
        line.setFeatureSkuIds(featureSkuIds);

        redisData.setLines(lines);

        return redisData;
    }
    private PrepaidODRequestData getRedisData5(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setMtn("newLine1");
        line.setFlow("PASO");
        line.setCheckoutFlag(true);
        lines.add(line);

        List<String> featureSkuIds = new ArrayList<>();
        featureSkuIds.add("sku3920521");
        featureSkuIds.add("feature13");
        //adding AccessoryskuId
        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        line.setAccessorySkuIds(accessorySkuIds);
        line.setFeatureSkuIds(featureSkuIds);

        redisData.setLines(lines);

        return redisData;
    }
    String requestString = "{\n" +
            "  \"serviceHeader\": {\n" +
            "    \"clientId\": \"VZW-DOTCOM\",\n" +
            "    \"statusMsg\": \"PEGA generated message\",\n" +
            "    \"serviceName\": \"SalesOrderPurchase\",\n" +
            "    \"userId\": \"\",\n" +
            "    \"statusCode\": \"0\",\n" +
            "    \"sessionId\": \"\",\n" +
            "    \"correlationId\": \"soe-cart-2022.01.25.18.58.21-916.8608036659715\"\n" +
            "  },\n" +
            "  \"serviceBody\": {\n" +
            "    \"serviceRequest\": {\n" +
            "      \"context\": {\n" +
            "        \"caseId\": \"SOP-817289281-E01\",\n" +
            "        \"contextInfo\": {\n" +
            "          \"callReason\": \"SalesOrderPurchase\",\n" +
            "          \"processStep\": \"PlanSelection\",\n" +
            "          \"processAction\": \"addPlan\",\n" +
            "          \"intent\": \"Inline-CPC\"\n" +
            "        },\n" +
            "        \"customerInfo\": {\n" +
            "          \"throttleName\": \"|AccessoryInterestialProspect|\",\n" +
            "          \"bucketAllocator\": \"BAU\",\n" +
            "          \"customerType\": \"N\",\n" +
            "          \"accountNumber\": \"\",\n" +
            "          \"cartCreator\": \"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\n" +
            "          \"processingMTN\": \"newLine1\",\n" +
            "          \"registerNumber\": 0,\n" +
            "          \"mtnFlow\": \"P\",\n" +
            "          \"globalId\": \"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"\n" +
            "        },\n" +
            "        \"cartInfo\": {\n" +
            "          \"retrieveFeatureLossReferenceData\": \"Y\",\n" +
            "          \"parentMtn\": \"\",\n" +
            "          \"cartItemCount\": 0,\n" +
            "          \"cartId\": \"b83940f5-0276-407f-947f-c2a2fa819afe\",\n" +
            "          \"itemType\": \"PLAN\",\n" +
            "          \"intendType\": \"NSE\",\n" +
            "          \"action\": \"UPDATE\",\n" +
            "          \"lines\": [\n" +
            "            {\n" +
            "              \"plan\": {\n" +
            "                \"id\": \"50427\",\n" +
            "                \"isRecommendedPlan\": false\n" +
            "              },\n" +
            "              \"mtn\": \"newLine1\",\n" +
            "              \"editSim\": false,\n" +
            "              \"lineWithSkipMDN\": false,\n" +
            "              \"inWithVerizonOpted\": false,\n" +
            "              \"protectionNotRequired\": false\n" +
            "            }\n" +
            "          ],\n" +
            "          \"effectiveDate\": \"\",\n" +
            "          \"checkAutoPayDiscountEligible\": \"N\",\n" +
            "          \"discountPromoTotal\": 0,\n" +
            "          \"registerNumber\": 0,\n" +
            "          \"protectionNotRequired\": false\n" +
            "        }\n" +
            "      }\n" +
            "    }\n" +
            "  }\n" +
            "}";
    @Test
    public void updateAccountOwnerTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        String mockRedisData = mapper.writeValueAsString(getRedisData());

        AccountOwnerPEGARequest request = mapper.readValue(requestString, AccountOwnerPEGARequest.class);
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].setAccountOwner("Y");
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));

        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        URI url = URI.create("http://localhost/testurl");
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AccountOwnerPEGAResponse>> responseMono = helper.updateAccountOwner(serverHttpRequest, request) ;
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void updateAccountOwnerRedisExceptionTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        String mockRedisData = "value";

        AccountOwnerPEGARequest request = mapper.readValue(requestString, AccountOwnerPEGARequest.class);
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].setAccountOwner("Y");
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));

        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        URI url = URI.create("http://localhost/testurl");
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AccountOwnerPEGAResponse>> responseMono = helper.updateAccountOwner(serverHttpRequest, request) ;
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void updateAccountOwnerWebclientExceptionTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        String mockRedisData = mapper.writeValueAsString(getRedisData()); ;

        AccountOwnerPEGARequest request = mapper.readValue(requestString, AccountOwnerPEGARequest.class);
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].setAccountOwner("Y");
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));

        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        URI url = URI.create("http://localhost/testurl");
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenThrow(new RuntimeException());

        Mono<ResponseEntity<AccountOwnerPEGAResponse>> responseMono = helper.updateAccountOwner(serverHttpRequest, request) ;
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void updateAccountOwnerTest_emptyRedisData() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        AccountOwnerPEGARequest request = mapper.readValue(requestString, AccountOwnerPEGARequest.class);
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(""));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        URI url = URI.create("http://localhost/testurl");
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AccountOwnerPEGAResponse>> responseMono = helper.updateAccountOwner(serverHttpRequest, request) ;
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void updatePrepayODDataInRedisTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        AccountOwnerPEGARequest request = mapper.readValue(requestString, AccountOwnerPEGARequest.class);

        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        JsonNode responseNode = mapper.readValue(responseString, JsonNode.class);
        JsonNode payloadNode = responseNode.get("payload");
        Mono<ResponseEntity<AccountOwnerPEGAResponse>> responseMono = ReflectionTestUtils.invokeMethod(helper,"updatePrepayODDataInRedis",request,getRedisData(), payloadNode);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void callBusErrorResponseTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        AccountOwnerPEGAResponse response = mapper.readValue(responseString,AccountOwnerPEGAResponse.class);
        Mono<ResponseEntity<AccountOwnerPEGAResponse>> responseMono = ReflectionTestUtils.invokeMethod(helper,"callBusErrorResponse",response);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void callSystemErrorResponseTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        AccountOwnerPEGAResponse response = mapper.readValue(responseString,AccountOwnerPEGAResponse.class);
        Mono<ResponseEntity<AccountOwnerPEGAResponse>> responseMono = ReflectionTestUtils.invokeMethod(helper,"callSystemErrorResponse",response);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));
    }

    @Test
    public void getAccountOwnerPEGAResponseTest() throws IOException {

        AccountOwnerPEGARequest request = mapper.readValue(requestString, AccountOwnerPEGARequest.class);

        AccountOwnerPEGAResponse response = ReflectionTestUtils.invokeMethod(helper,"getAccountOwnerPEGAResponse",true,request, getRedisData());
        Assert.assertNotNull(response);
    }

    @Test
    public void getAccountOwnerPEGAResponseTest_emptyRedisData() throws IOException {

        AccountOwnerPEGARequest request = mapper.readValue(requestString, AccountOwnerPEGARequest.class);

        AccountOwnerPEGAResponse response = ReflectionTestUtils.invokeMethod(helper,"getAccountOwnerPEGAResponse",true,request, new PrepaidODRequestData());
        Assert.assertNotNull(response);
    }

    @Test
    public void getVZWPrepayAccountOwnerRequestTest() throws IOException {

        AccountOwnerPEGARequest request = mapper.readValue(requestString, AccountOwnerPEGARequest.class);

        VZWPrepayAccountOwnerRequest request1 = ReflectionTestUtils.invokeMethod(helper,"getVZWPrepayAccountOwnerRequest",request, getRedisData());
        Assert.assertNotNull(request1);
    }

    @Test
    public void updateAccountOwnerTest2() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        String mockRedisData = mapper.writeValueAsString(getRedisData2());

        AccountOwnerPEGARequest request = mapper.readValue(requestString, AccountOwnerPEGARequest.class);
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));

        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        URI url = URI.create("http://localhost/testurl");
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AccountOwnerPEGAResponse>> responseMono = helper.updateAccountOwner(serverHttpRequest, request) ;
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void updateAccountOwnerTest3() throws IOException {

        String responseString = "{\"status\":\"ok\",\"payload\":{\"cqContent\":{\"label\":{\"OD_PREPAID_CART_HOLIDAY_RETURN_POLICY_HEADER_TEXT\":\"PurchasewithconfidencewithourHolidayReturnPolicy\",\"OD_PREPAID_CART_HOLIDAY_RETURN_POLICY_SUBHEADING_TEXT\":\"Arestockingfeeof$50appliestoanyreturnorexchangeofawirelessdevice(excludingHawaii).\",\"OD_PREPAID_CART_HOLIDAY_RETURN_POLICY_SUBHEADING_TOOLTIP_TEXT\":\"DevicesandaccessoriespurchasedbetweenNovember24,2022throughDecember15,2022maybereturnedorexchangedonorbeforeJanuary14,2023.DevicesandaccessoriespurchasedonorafterDecember16,2022maybereturnedorexchangedwithin30daysofpurchase.Thereturnandexchangeperiodbeginsuponthedateofpurchaseorthedateofdeliveryofyournewdevice.Arestockingfeeof$50appliestoanyreturnorexchangeofawirelessdevice(excludingHawaii).Ifyoupurchasedyourdeviceandaccessoriesfromanon-Verizonoperatedretaillocation(authorizedretailer),youshouldreviewthatlocation'sreturnpolicyregardingtheiracceptanceofdeviceandaccessoryreturns.\",\"OD_PREPAID_CART_ADD_A_NEW_DEVICE_BTN\":\"Addaline?\",\"OD_PREPAID_CART_ADD_A_BYOD_DEVICE_BTN\":\"Bringyourowndevice?\",\"OD_PREPAID_CONFIRMATION_DIALOG_HEADING\":\"Areyousureyouwanttoremovethis$itemName$?\",\"OD_PREPAID_REMOVE_CTA\":\"Yes,remove\",\"OD_PREPAID_SMARTPHONE_UNLIMITED_PLUS\":\"Smartphoneplan<br/>UnlimitedPlus\",\"OD_PREPAID_CART_CC_MAIN_HEADING\":\"Justconfirmthedetailsandyou'regoodtogo.\",\"OD_PREPAID_CART_BONUS_DATA_PROMO\":\"Additional$bonusData$dataeverymonth.\",\"OD_PREPAID_CART_MAIN_HEADING\":\"Here'swhatyou'veselected,justdoublecheckeverything'sgoodtogo.\",\"OD_PREPAID_CART_DUE_MONTHLY_LABEL\":\"Monthlypayment\",\"OD_PREPAID_CART_DUE_TODAY_LABEL\":\"Duetoday\",\"OD_PREPAID_CART_CHECKOUT_BTN_LABEL\":\"Checkout\",\"OD_PREPAID_CART_SUMMARY_LABEL\":\"Summary\",\"OD_PREPAID_CART_PLAN_LABEL\":\"Plan\",\"OD_PREPAID_CART_DEVICE_LABEL\":\"Phones\",\"OD_PREPAID_CART_SAVINGS_LABEL\":\"Savings\",\"OD_PREPAID_CART_TOTAL_HEADING\":\"Total\",\"OD_PREPAID_CART_CLEAR_CART_LINK\":\"Clearcart\",\"OD_PREPAID_CART_SAVE_CART_LINK\":\"savecart\",\"OD_PREPAID_CART_BANNER_HEADING_TEXT\":\"You'realmostthere.\",\"OD_PREPAID_CART_BANNER_SUB_HEADING_TEXT\":\"Checkoutandstartsavingwithloyaltydiscounts\",\"OD_PREPAID_CART_BANNER_LINK_TEXT\":\"Learnmore\",\"OD_PREPAID_LOYALTY_PROGRAM_HEADING_TEXT\":\"Plandiscountdetails\",\"OD_PREPAID_LOYALTY_PROGRAM_SUBHEADING_TEXT\":\"Requirements;`AutoPaydiscount\",\"OD_PREPAID_LOYALTY_PROGRAM_SUBHEADING_CONTENT\":\"$5/moloyaltydiscountappliesafter3monthsofservice;additional$5/moappliesafter9monthsofservice,foratotalof$10/moonplans$40orhigher.Discountappliesaslongasyourlineisnotdisconnected.;`AutoPaydiscountof$5/moavailableafter1stmonthforalltheplans.Creditordebitcardrequired.\",\"OD_PREPAID_PLAN_MOBILEHOTSPOT_HEADING\":\"Purchase;`Details;`Manage;`Cancellation;`Disclaimer\",\"OD_PREPAID_PLAN_MOBILEHOTSPOT_CONTENT\":\"YoucanaddMobileHotspotandwillbecharged$5eachmonthonyourrenewaldate.;`MobileHotspotletsyoushare10GBofhigh-speeddatawithotherdevicessotheycanaccesstheInternet.YourdevicesconnectoverWi-Fiforunlimitedaccessat600Kbpsspeedsonoursecurenetwork.;`MobileHotspotcomespreinstalledoncompatibledevices.Dependingonyourdevice,itmaybeinyourAppmenuorSettings.;`IfyoudecidetoremoveMobileHotspot,you'llnolongerbeabletoconnectotherdevices.;`MobileHotspotandtetheringavailableontheUnlimitedPlanfor$5/mo.Includes10GBofhigh-speeddata,thenspeedsupto600Kbpstheremainderofthemonth.Yourdataexperienceandfunctionalityofsomedataapplicationssuchasstreamingvideooraudiomaybeimpacted.\",\"OD_PREPAID_SMARTPHONE_PLAN_LABEL\":\"Smartphoneplan\",\"OD_PREPAID_CART_EDIT_PLAN_LINK\":\"Changeplan\",\"OD_PREPAID_CART_ADD_INTL_FEATURE_LABEL\":\"AddInternationalcalling\",\"OD_PREPAID_CART_LINE_DISCOUNT_LABEL\":\"linediscount\",\"OD_PREPAID_CART_EDIT_FEATURE_LINK\":\"Edit\",\"OD_PREPAID_CART_REMOVE_FEATURE_LINK\":\"Remove\",\"OD_PREPAID_CART_EDIT_DEVICE_LINK\":\"Edit\",\"OD_PREPAID_CART_REM_DEVICE_LINK\":\"Removeline\",\"OD_PREPAID_CART_OWNER_LABEL\":\"Currentaccountowner\",\"OD_PREPAID_CART_CHANGE_OWNER_LINK\":\"Edit\",\"OD_PREPAID_CART_DISCOUNTS_LABEL\":\"Discounts\",\"OD_PREPAID_CART_ORDER_SAVINGS_LABEL\":\"Ordersavings\",\"OD_PREPAID_CART_TAX_DISCLAIMER\":\"*Monthlytaxes,andgovernmentfeeswillbeaddedtoyourbill.\",\"OD_PREPAID_CART_ZIP_HEADING\":\"BasedonyourZIPcode\",\"OD_PREPAID_CART_CHANGE_ZIP_LABEL\":\"EnteryourZIPcode:\",\"OD_PREPAID_CART_APPLY_BTN_LABEL\":\"Apply\",\"OD_PREPAID_CART_RETURN_POLICY_HEADING\":\"Needtoreturnorexchangeapurchase?Noproblem.\",\"OD_PREPAID_CART_ADD_A_LINE_BTN\":\"Addaline?\",\"OD_PREPAID_CART_YES_BTN\":\"Yes\",\"OD_PREPAID_CART_CANCEL_BTN\":\"Cancel\",\"OD_PREPAID_CART_REM_DEVICE_HEADING\":\"Areyousureyouwanttoremovethisdevice?\",\"OD_PREPAID_SAVE_CART_HEADING\":\"Youcansavethiscartforupto30days.\",\"OD_PREPAID_CART_EMPTY_CART_HEADING\":\"Areyousureyouwanttostartagain?\",\"OD_PREPAID_CART_REM_DEVICE_SUB_HEADING\":\"Youwillloseyourdeviceconfigurationandanyoffersassociatedwiththisdevice.\",\"OD_PREPAID_CART_EMPTY_CART_SUB_HEADING\":\"Ifyouclearplansanddevicesfromyourcart,you'llhavetostartfromthebeginningagain.Doyouwanttodothis?\",\"OD_PREPAID_CART_ENTER_EMAIL_TITLE\":\"Enteryouremailandwe'llsendyouacopyofyourcart.\",\"OD_PREPAID_CART_SAVE_CART_BTN_LABEL\":\"Saveandcontinue\",\"OD_PREPAID_CART_DONT_SAVE_CART_BTN_LABEL\":\"Continuewithoutsaving\",\"OD_PREPAID_PLAN_CC_INTRIAL_UNLIMITED_PLAN_HEADING\":\"ConnectedCarWi-Fi{planSize}UnlimitedMonthlySubscription.\",\"OD_PREPAID_CART_CC_ONE_LINE_ITEM\":\"Justaheadsupthatyoucanonlyactivateonedeviceatatimeonthisaccount.Continuetocheckout,orcallusat1-800-255-3987ifyouhaveanyquestions.\",\"OD_PREPAID_UNLIMITED_75GB_PLAN_TEXT\":\"Includes5GUltraWideband\",\"OD_PREPAID_PLAN_MOBILEHOTSPOT_SL_HEADING\":\"Purchase;`Details;`Manage;`Disclaimer\",\"OD_PREPAID_PLAN_MOBILEHOTSPOT_SL_CONTENT\":\"YoucanaddMobileHotspotandwillbecharged$5eachmonthonyourrenewaldate.;`MobileHotspotletsyousharedatawithotherdevicessotheycanaccesstheinternet.IfyoudecidetoremoveMobileHotspot,you'llnolongerbeabletoconnectotherdevices.;`MobileHotspotcomespreinstalledoncompatibledevices.Dependingonthedevice,itmaybeintheAppmenuorSettings.;`MobileHotspotandtetheringavailableontheUnlimitedPlanfor$5/mo.Includes10GBof5GNationwide/4GLTEdata,thenspeedsupto600KbpstheremainderOfthemonth.YourdataexperienceandfunctionalityOfsomedataapplicationssuchasstreamingvideooraudiomaybeimpacted.\",\"OD_PREPAID_PLAN_MOBILEHOTSPOT_ML_HEADING\":\"Purchase;`Details;`Manage;`Disclaimer\",\"OD_PREPAID_PLAN_MOBILEHOTSPOT_ML_CONTENT\":\"YoucanaddMobileHotspottothislineandwillbecharged$5eachmonthOnyourrenewaldate.;`MobileHotspotletsthislinesharedatawithotherdevicessotheycanaccesstheinternet.IfyoudecidetoremoveMobileHotspotfromthisline,they'llnolongerbeabletoconnectotherdevices.;`MobileHotspotcomespreinstalledoncompatibledevices.Dependingonthedevice,itmaybeintheAppmenuorSettings.;`MobileHotspotandtetheringavailableontheUnlimitedPlanfor$5/mo.Includes10GBof5GNationwide/4GLTEdata,thenspeedsupto600Kbpstheremainderofthemonth.Yourdataexperienceandfunctionalityofsomedataapplicationssuchasstreamingvideooraudiomaybeimpacted.\",\"OD_PREPAID_UNLIMITED_75GB_PLAN_TOOLTIP_TEXT\":\"<b>5GUltraWidebandavailableonlyinpartsofselectcities.</b><br></br>5GUltraWidebandaccessrequiresa5G-capabledeviceinsidethe5GUltraWidebandCoverageArea.Downloadsover5GUltraWideband.Dependingonlocation,uploadsover5GUltraWidebandor4GLTE.\",\"OD_PREPAID_MOBILE_HOTSPOT_POPUP_HEADNG\":\"MobileHotspotDetails\",\"OD_PREPAID_SECURE_CHECKOUT_CTA\":\"Beginsecurecheckout\",\"OD_PREPAID_CART_MULTILINE_DISCOUNTS_LABEL\":\"Multilinediscount\",\"OD_PREPAID_VIEW_RETURN_POLICY_TEXT\":\"Viewreturnpolicy\",\"OD_PREPAID_CHECKOUT_MULTILINE_CONTENT\":\"You’resaving$20/mowithmultilinediscount.\",\"OD_PREPAID_PLAN_MULTILINE_DISCOUNT_TOOLTIP\":\"Save$20/mowhenyouaddanyVerizonPrepaidUnlimitedphoneplantoyourMultilineaccount.Firstlineontheaccountcanbeeitheronaphoneordataplan.EachadditionalUnlimitedphonelinereceivesa$20/modiscount.EligibilityforAutoPayorLoyaltydiscountsalsoavailable.\",\"OD_PREPAID_CHECKOUT_MULTILINE_DATA_PLAN_CONTENT\":\"You’resaving$30/mowithmultilinediscount.\",\"OD_PREPAID_PLAN_MULTILINE_DISCOUNT_DATA_PLAN_TOOLTIP\":\"ForanactiveVerizonPrepaidaccount,receivea$30/modiscountoneachlineyouaddwithadataplan.Firstlineontheaccountcanbeeitheraphoneordataplan.Additionaltaxesandfeesmayapply.DatalinesdonotqualifyforAutoPayorLoyaltydiscounts.\",\"OD_PREPAID_CHECKOUT_AUTOPAY_REDEEMED_TOOLTIP\":\"AutoPaydiscountof$10/moonplans$45&higherafterthe1stmonth.$5/modiscountonthe$35Talk&Textplanafterthe1stmonth.CreditorDebitcardrequired.Additionalloyaltydiscountsdonotapply.\",\"OD_PREPAID_CHECKOUT_AUTOPAY_REDEEMED_LABEL\":\"AutoPaydiscountof${autoPaySaving}/moavailableafter1stmonth.\",\"OD_PREPAID_UNLIMITED_DISNEY_PLUS_OFFER_TEXT\":\"Includes6monthsofDisney+\",\"OD_PREPAID_UNLIMITED_DISNEY_PLUS_OFFER_TOOLTIP_TEXT\":\"Disney+onusfor6months;thenauto-renewsatthen-currentmonthlyprice(currently$7.99+taxpermonth)afterpromoperiodendsunlessyoucancel.MustactivateanUnlimited$65or$75planbetween7.27.22and1.31.23andremainontheplantoretainoffer.Mustredeemby3.2.23.NewandeligiblereturningDisney+subscribersonly.Mustbe18+.Additionaltermsapply.OneofferpereligibleVerizonaccount.©2022Disneyanditsrelatedentities.\",\"OD_PREPAID_CHECKOUT_CONFIRMATION_UNLIMITED_DISNEY_PLUS_OFFER_TEXT\":\"<br/><br/>You'llalsoreceiveacodeviatextwithin24hourstoactivateDisney+.\",\"OD_PREPAID_LOYALTY_PROGRAM_HEADING_PRICING_TEXT\":\"SavemorewithVerizondiscounts.\",\"OD_PREPAID_LOYALTY_PROGRAM_HEADING_PRICING_SUBTEXT\":\"Saveupto$10permonthwithAutoPay.Orsavewithloyaltydiscountsovertime.\",\"OD_PREPAID_LOYALTY_PROGRAM_SUBHEADING_PRICING_TEXT\":\"AutoPaydiscounts;`Loyaltydiscount\",\"OD_PREPAID_LOYALTY_PROGRAM_SUBHEADING_PRICING_CONTENT\":\"$10/moAutoPaydiscountonplans$45&higherafterthefirstmonth.$5/modiscountonthe$35Talk&Textplanafterthe1stmonth.CreditorDebitcardrequired.Additionalloyaltydiscountsdonotapply.;`$5/moloyaltydiscountappliesafter3monthsofservice;additional$5/moappliesafter9monthsofservice,foratotalof$10/moonplans$45orhigher.Discountappliesaslongasyourlineisnotdisconnected.AdditionalAutoPaydiscountsdonotapply.\",\"OD_PREPAID_LOYALTY_PROGRAM_MAXIMUM_DISCOUNT\":\"Upto$10/modiscount\",\"OD_PREPAID_UNLIMITED_DISNEY_PLUS_OFFER_PRICING_TOOLTIP_TEXT\":\"Disney+onusfor6months;thenauto-renewsatthen-currentmonthlyprice(currently$7.99+taxpermonth)afterpromoperiodendsunlessyoucancel.MustactivateanUnlimited$60or$70planbetween7.27.22and1.31.23andremainontheplantoretainoffer.Mustredeemby3.2.23.NewandeligiblereturningDisney+subscribersonly.Mustbe18+.Additionaltermsapply.OneofferpereligibleVerizonaccount.©2022Disneyanditsrelatedentities.\",\"OD_PREPAID_CHECKOUT_TERMS_AND_CONDITIONS\":\"TermsandConditions\",\"offerDetailsContent\":{\"OD_PREPAID_BANNER_HEADING_TEXT\":\"You'realmostthere.\",\"OD_PREPAID_BANNER_SUB_HEADING_TEXT\":\"Checkoutandstartsavingwithourbestplans.\",\"OD_PREPAID_VARIANT_BANNER_HEADING\":\"Continuetocheckout.\",\"OD_PREPAID_CART_OFFER_BANNER_HEADING_TEXT\":\"You'realmostthere.\",\"OD_PREPAID_CART_OFFER_BANNER_SUB_HEADING_TEXT\":\"Completeyournewactivation,andyou'reonestepclosertoafreemonthonus.\",\"OD_PREPAID_CART_OFFER_BANNER_LINK_TEXT\":\"LearnMore\",\"OD_PREPAID_OFFER_DETAILS_POPUP_HEADING_TEXT\":\"Offerdetails\",\"OD_PREPAID_OFFER_DETAILS_POPUP_CONTENT\":\"CreditappliedtoAccountOwnerfor3rdmonthrenewal;creditequaltothemonthlyplancostattimeofrenewal.Requiresanewlineand2monthsofservice.Upto$75savingsbasedonactivationofeligibleprepaidplanandnon-Autopaycustomer.Offernotavailableinallsaleschannels.Limitedtimeoffer.\",\"OD_PREPAID_JETPACK_TABLET_BANNER_SUB_HEADING_TEXT\":\"You'reonestepclosertocompletingyournewactivation.\",\"OD_PREPAID_OFFER_DETAILS_POPUP_CTA_TEXT\":\"Done\"}},\"html\":{\"OD_PREPAID_CART_VARIANT_RETURN_POLICY_SUMMARY\":\"<h3>Purchasewithconfidencewithour30-dayreturnandexchangeperiod.</h3><pclass='noTopMargin'>Arestockingfeeof$50appliestoanyreturnorexchangeofawirelessdevice(excludingHawaii).</p>\",\"OD_PREPAID_SMARTPHONE_UNLIMITED_PLUS\":\"Smartphoneplan<br/>UnlimitedPlus\",\"OD_PREPAID_CART_MAX_LIMIT_REACHED_HTML\":\"Sorry!Yourcartonlyholds$max_device_limit$devices.Weappreciateyourbusinessandhopethatyou'lladdthisitemafteryoucheckout.Questions?Call1-800-256-4644\",\"OD_PREPAID_CART_DEVICE_MISMATCH_HTML\":\"Oops.Unfortunately,thedeviceyou'retryingtoaddisn'teligibleforthePrepaidFamilyPlan.\",\"OD_PREPAID_TAX_PROMO_BANNER_HTML\":\"<style>.promo_heading{font-size:20px;}.tooltip-container.sm-screen{bottom:45px}@media(min-width:768px){.promo_heading{font-size:32px;}.mixed-cart-promo{position:relative;background:url(https://ss7.vzw.com/is/image/VerizonWireless/checkout-prepaid-bonus-data-d-010219?&scl=2)no-repeat;background-position:center;height:190px;background-size:100%;padding:20px;}.mixed-cart-promo.message{font-size:20px;width:291px;}}@mediaonlyscreenand(max-width:767px){.mixed-cart-promo{background:url(https://ss7.vzw.com/is/image/VerizonWireless/checkout-prepaid-bonus-data-d-010219?&scl=3)no-repeat;height:110px;padding:15px;position:relative;background-size:100%;}}@mediaonlyscreenand(max-width:620px){.promo_heading{font-size:16px;}.mixed-cart-promo{background:url(https://ss7.vzw.com/is/image/VerizonWireless/checkout-prepaid-bonus-data-m-010219?&scl=2)no-repeat;background-size:100%;height:136px;}.mixed-cart-promo.message{font-size:14px;width:215px;}.mixed-cart-promo.promoCTA{position:relative;bottom:0;margin-top:12px;font-size:16px;}}@mediaonlyscreenand(max-width:550px){.mixed-cart-promo.message{font-size:12px;width:190px;}.mixed-cart-promo{background:url(https://ss7.vzw.com/is/image/VerizonWireless/checkout-prepaid-bonus-data-m-010219?&scl=1)no-repeat;padding:15px;background-size:480px;position:relative;height:136px;background-position:right0;}}</style><divclass='mixed-cart-promo'><divclass='promo_headingbold'>Get15GB<brclass='lg-screen'/>for$45/mo.</div><divclass='clear6'></div><divclass='boldlg-screen'>WhenyouenrollinAutoPay.<br/>Limitedtimeonly</div><divclass='sm-screen'>WhenyouenrollinAutoPay.<br/>Limitedtimeonly</div><divclass='clear20'></div><divclass='tooltip-containerlg-screen'style='position:absolute;bottom:30px'><ahref='javascript:void(0)'class='linkfontSize_3tooltip-btn'aria-label='Seedetailstooltipcollapsed'id='label_modal_1'>Seedetails</a><spanclass='tooltip-contentis-hidden'><buttonclass='tooltip-close'aria-label='Closeinformationtooltip'>×</button>Promotional7GBon$50planuntil4/30/19.Availabletonewcustomers,andexistingcustomersthatupgradetoorreactiveonthe8GB$50plan.BonusDataaddedeachmonthaslongasyouprepiadaccountremainsactive.Youraccountmusthavesufficientfundstoremainactive.Autopaydiscountappliesafter1stmonth.Creditordebitcardonlyreq'd.1stmonthfees;$40,$50,$70dependingonplan.</span></div><divclass='tooltip-containersm-screen'style='position:absolute;bottom:45px'><ahref='javascript:void(0)'class='linkfontSize_3tooltip-btn'aria-label='Seedetailstooltipcollapsed'id='label_modal_1'>Seedetails</a><spanclass='tooltip-contentis-hidden'><buttonclass='tooltip-close'aria-label='Closeinformationtooltip'>×</button>Promotional7GBon$50planuntil4/30/19.Availabletonewcustomers,andexistingcustomersthatupgradetoorreactiveonthe8GB$50plan.BonusDataaddedeachmonthaslongasyouprepiadaccountremainsactive.Youraccountmusthavesufficientfundstoremainactive.Autopaydiscountappliesafter1stmonth.Creditordebitcardonlyreq'd.1stmonthfees;$40,$50,$70dependingonplan.</span></div></div>\",\"OD_PREPAID_PROMO_BANNER_HTML\":\"<style>.mixed-cart-promo{position:relative;background:url(https://ss7.vzw.com/is/image/VerizonWireless/data-device-tablet-jetpack-final-d-09252020?&scl=2)no-repeat!important;background-position:center;background-size:cover!important;height:275px;padding:28px;}.mixed-cart-promo.message{font-size:15px;width:291px;}.message-font{font-size:40px}.mixed-cart-promo.promoCTA{position:absolute;bottom:20px;font-size:18px;}@mediaonlyscreenand(max-width:860px){.mixed-cart-promo{background:url(https://ss7.vzw.com/is/image/VerizonWireless/data-device-tablet-jetpack-final-d-09252020?&scl=2)no-repeat!important;background-position:center;background-size:cover!important;height:275px;}.mixed-cart-promo.message{font-size:16px;}}@mediaonlyscreenand(max-width:620px){.mixed-cart-promo{background:url(https://ss7.vzw.com/is/image/VerizonWireless/data-device-tablet-jetpack-final-d-09252020?&scl=2)no-repeat!important;background-position:center;background-size:cover!important;height:100px;padding:12px;}.mixed-cart-promo.message{font-size:14px;width:215px;}.mixed-cart-promo.promoCTA{position:relative;bottom:0;margin-top:12px;font-size:16px;}}@mediaonlyscreenand(max-width:550px){.mixed-cart-promo.promoCTA{font-size:14px;margin-top:10px;}.mixed-cart-promo.message{font-size:15px;width:230px;}.mixed-cart-promo{background:url(https://ss7.vzw.com/is/image/VerizonWireless/data-device-tablet-jetpack-final-d-09252020?&scl=2)no-repeat!important;background-position:center;background-size:cover!important;height:240px;width:450px}}</style><divclass='mixed-cart-promo'><divclass='messagebold'><spanclass='message-font'>Getdouble</span></br><spanclass='message-font'>thedata.</span><br>Get16GBforjust<br>$45/mowhenyou<br>enrollinAutoPay.</div><divclass='tooltip-container'><ahref='javascript:void(0)'class='linkfontSize_3tooltip-btn'aria-label='Seedetailstooltipcollapsed'id='label_modal_1'>Seedetails</a><spanclass='tooltip-contentis-hidden'><buttonclass='tooltip-close'aria-label='Closeinformationtooltip'>×</button>Availabletonewactivationsonly.Bonusdataaddedeachmonthaslongasyouraccountremainsactive.Onceactivated,customerscanmovebetweeneligibleplansanytimeandkeepthebonusdata.Yourbonusdataallowancewillnotappearinyourshoppingcartbutwillbeseeninyouraccountafteractivation.<br><br>Autopaydiscountof$5/moappliesafter1stmonthonplans$40orhigher.CreditorDebitcardonlyreq'd.</span></div></div></div>\",\"OD_PREPAID_CART_EUP_BANNER\":\"Wow,thatwasfast.Yournewdeviceisreadytogoonyourexistingplan.Justplaceyourorderandyou'reallset.\",\"OD_PREPAID_CART_ACTIVATION_FEE_HTML\":\"Onetimeactivationfee<br>(waivedonlineonly)\",\"OD_PREPAID_CART_RETURN_POLICY_SUMMARY_HTML\":\"<h3>Purchasewithconfidencewithour30-dayreturnandexchangeperiod.</h3><pclass='noTopMargin'>Arestockingfeeof$50appliestoanyreturnorexchangeofawirelessdevice(excludingHawaii).</p><adata-track='Viewreturnpolicy'href='https://www.verizonwireless.com/support/return-policy/'target='_blank'class='link'>Viewreturnpolicy</a>\",\"OD_PREPAID_CART_HOLIDAY_RETURN_POLICY_LINK_TEXT\":\"<adata-track='Viewreturnpolicy'href='https://www.verizonwireless.com/support/return-policy/'target='_blank'class='link'>HolidayReturnPolicy</a>\",\"OD_PREPAID_CART_TAXES_HEADING_HTML\":\"Taxesand<br/>governmentfees\"},\"error\":{\"OD_PREPAID_CART_CC_MAX_LIMIT_ERROR\":\"Wewereunabletoaddyouritemstothecartbecauseyoucanonlyactivateonedeviceatatimeonthisaccount.Continuetocheckout,orcallusat1-800-255-3987ifyouhaveanyquestions.\",\"OD_PREPAID_CART_CC_ADDING_NONCC_ITEM_ERROR\":\"OD_PREPAID_CART_CC_ADDING_NONCC_ITEM_ERROR\"}},\"pageData\":{\"status\":200,\"orderId\":\"S5d3deecdc200c1b1b453baef29f5e5ef{s4}\",\"orderTotal\":110.0,\"orderTax\":0.0,\"orderDiscount\":0.0,\"monthlySavings\":20.0,\"orderZipcode\":\"30004\",\"dueMonthly\":110.0,\"dueToday\":110.0,\"flow\":\"NSP\",\"totalActivationfee\":0.0,\"sessionId\":\"POS-D-1dbfb7cf-240f-49e4-bd25-711487331e89{s4}\",\"deviceList\":[{\"quantity\":1,\"skuId\":\"sku4120159\",\"productId\":\"dev10920021\",\"seoName\":\"apple-iphone-xr-prepaid\",\"sorId\":\"MH563LL/A\",\"listPrice\":0.0,\"itemAmount\":0.0,\"rawTotalAmount\":0.0,\"deviceTax\":0.0,\"skuDisplayName\":\"iPhoneXRPrepaid\",\"activationFee\":0.0,\"color\":\"Black\",\"capacity\":\"64GB\",\"brandName\":\"Apple\",\"imageUrl\":\"https://ss7.vzw.com/is/image/VerizonWireless/iPhoneXr_Black_PureAngles?$device-lg$\",\"miniImageUrl\":\"https://ss7.vzw.com/is/image/VerizonWireless/iPhoneXr_Black_PureAngles?$device-mini$\",\"planItemId\":\"S5d3deecdc200c1b1b453baef29f5e5ef{s4}_plan_397867880\",\"accountMember\":false,\"accountOwner\":true,\"portInDevice\":false,\"daccCode\":\"P1189\",\"simDisplayName\":\"GTO4G5GInterimDFILLSIM\",\"purchasePath\":\"NSP\",\"itemType\":\"smartphone\",\"totalDueMonthly\":60.0,\"totalDueToday\":60.0,\"trialStatus\":null,\"deviceSorType\":\"4GE\",\"fiftyPercentPromoApplied\":false,\"lineSecurityPin\":null,\"securityQuestion\":null,\"securityAnswer\":null,\"deviceFirstName\":null,\"deviceLastName\":null,\"simId\":null,\"esimCompatible\":false,\"esimOnlyDevice\":false,\"smartImeiDevice\":false,\"imei\":null,\"imei2\":null,\"requestedEsimImei\":null,\"itemDiscount\":0.0,\"autoPaymentEligible\":false,\"eSIMEnabledDevice\":false,\"fullRetailListPrice\":0.0,\"taxDetails\":{},\"existingDevice\":null,\"npaNxxCode\":\"470-626-XXXX\",\"id\":\"S5d3deecdc200c1b1b453baef29f5e5ef{s4}_device_269631950\",\"inlinePromo\":false},{\"quantity\":1,\"skuId\":\"sku4120159\",\"productId\":\"dev10920021\",\"seoName\":\"apple-iphone-xr-prepaid\",\"sorId\":\"MH563LL/A\",\"listPrice\":0.0,\"itemAmount\":0.0,\"rawTotalAmount\":0.0,\"deviceTax\":0.0,\"skuDisplayName\":\"iPhoneXRPrepaid\",\"activationFee\":0.0,\"color\":\"Black\",\"capacity\":\"64GB\",\"brandName\":\"Apple\",\"imageUrl\":\"https://ss7.vzw.com/is/image/VerizonWireless/iPhoneXr_Black_PureAngles?$device-lg$\",\"miniImageUrl\":\"https://ss7.vzw.com/is/image/VerizonWireless/iPhoneXr_Black_PureAngles?$device-mini$\",\"planItemId\":\"S5d3deecdc200c1b1b453baef29f5e5ef{s4}_plan_611852131\",\"accountMember\":true,\"accountOwner\":false,\"portInDevice\":false,\"daccCode\":\"P1189\",\"simDisplayName\":\"GTO4G5GInterimDFILLSIM\",\"purchasePath\":\"NSP\",\"itemType\":\"smartphone\",\"totalDueMonthly\":50.0,\"totalDueToday\":50.0,\"trialStatus\":null,\"deviceSorType\":\"4GE\",\"fiftyPercentPromoApplied\":false,\"lineSecurityPin\":null,\"securityQuestion\":null,\"securityAnswer\":null,\"deviceFirstName\":null,\"deviceLastName\":null,\"simId\":null,\"esimCompatible\":false,\"esimOnlyDevice\":false,\"smartImeiDevice\":false,\"imei\":null,\"imei2\":null,\"requestedEsimImei\":null,\"itemDiscount\":0.0,\"autoPaymentEligible\":false,\"eSIMEnabledDevice\":false,\"fullRetailListPrice\":0.0,\"taxDetails\":{},\"existingDevice\":null,\"npaNxxCode\":\"470-626-XXXX\",\"id\":\"S5d3deecdc200c1b1b453baef29f5e5ef{s4}_device_030385081\",\"inlinePromo\":false}],\"accessoryList\":null,\"planList\":[{\"id\":\"S5d3deecdc200c1b1b453baef29f5e5ef{s4}_plan_611852131\",\"skuId\":\"sku5720003\",\"productId\":\"plan2680002\",\"sorId\":\"28399\",\"dueMonthly\":50.0,\"dueToday\":50.0,\"skuDisplayName\":null,\"itemTax\":0.0,\"discount\":20.0,\"planSize\":\"Unlimited\",\"description\":\"UnlimitedPlusPlan\",\"featureLineItemId\":null,\"title\":\"UnlimitedPlusPlan\",\"fourthLinePromoDiscount\":0.0,\"autoPaySaving\":10.0,\"promotions\":{},\"bonusData\":null,\"eligibleForDoubleData\":true,\"totalDueMonthly\":70.0,\"totalDueToday\":70.0,\"planDueMonthly\":50.0,\"actualPlanPrice\":70.0,\"planDescription\":\"UnlimitedPlusplan\",\"disneyPlusPromo\":false,\"accountOwner\":false,\"loyalityDiscountsEnabled\":true,\"mobileHotspotEnabled\":false,\"autoPayToolTip\":{\"toolTipMessage\":\"EnrollinAutoPayandsaveupto$10/mopereligibleline.\",\"toolTipOverlayMessage\":\"AutoPaydiscountof$10/moonplans$45&higherafterthe1stmonth.$5/modiscountonthe$35Talk&Textplanafterthe1stmonth.CreditorDebitcardrequired.Additionalloyaltydiscountsdonotapply.\"},\"taxDetails\":null,\"discountApplied\":true},{\"id\":\"S5d3deecdc200c1b1b453baef29f5e5ef{s4}_plan_397867880\",\"skuId\":\"sku5720005\",\"productId\":\"plan2680002\",\"sorId\":\"28397\",\"dueMonthly\":60.0,\"dueToday\":60.0,\"skuDisplayName\":null,\"itemTax\":0.0,\"discount\":20.0,\"planSize\":\"Unlimited\",\"description\":\"$60SmartphonePlan\",\"featureLineItemId\":null,\"title\":\"UnlimitedPlan\",\"fourthLinePromoDiscount\":0.0,\"autoPaySaving\":10.0,\"promotions\":{},\"bonusData\":null,\"eligibleForDoubleData\":true,\"totalDueMonthly\":80.0,\"totalDueToday\":80.0,\"planDueMonthly\":60.0,\"actualPlanPrice\":60.0,\"planDescription\":\"Unlimitedplan\",\"disneyPlusPromo\":false,\"accountOwner\":true,\"loyalityDiscountsEnabled\":true,\"mobileHotspotEnabled\":true,\"autoPayToolTip\":{\"toolTipMessage\":\"EnrollinAutoPayandsaveupto$10/mopereligibleline.\",\"toolTipOverlayMessage\":\"AutoPaydiscountof$10/moonplans$45&higherafterthe1stmonth.$5/modiscountonthe$35Talk&Textplanafterthe1stmonth.CreditorDebitcardrequired.Additionalloyaltydiscountsdonotapply.\"},\"taxDetails\":null,\"discountApplied\":false}],\"featureList\":[],\"taxDetailList\":[],\"accountInfo\":{\"mdnNumber\":null,\"accountOwner\":false,\"firstName\":null,\"middleName\":null,\"zipcode\":null,\"fullName\":null,\"address\":null,\"lastName\":null},\"todaySavings\":20.0,\"linesCount\":0,\"cartCount\":2,\"accountOwnerUpdate\":false,\"itemType\":\"smartphone\",\"maxDeviceLimit\":10,\"accountDeviceLimit\":10,\"promotions\":[],\"promoAdded\":false,\"digitalPaymentOptions\":{\"applepayEnabled\":\"true\",\"applePayMerchantId\":\"merchant.com.vzw.test\",\"paypalEnabled\":\"true\"},\"taxPromoEnabled\":false,\"deviceFingerPrintEnabled\":true,\"planDueMonthly\":110.0,\"maxCartLimit\":9,\"trialStatus\":null,\"is5G_EWB_Device\":false,\"nseNsoFlag\":true,\"accumulateInlineDiscount\":0.0,\"inlinePromotionMessage\":null,\"holidayPolicyEnable\":false,\"autopaySavings\":0.0,\"autoPayAccount\":false,\"enableFamilyPricing\":true,\"autopaySavingEligible\":true,\"enabledPriceRefresh\":true,\"planSavings\":20.0,\"shippingDetails\":{},\"nextDueDate\":null,\"dueNextCycle\":110.0,\"offerDataToBeShowed\":true,\"mot\":false}},\"prepayThrottleList\":\"|\"}";

        String mockRedisData = mapper.writeValueAsString(getRedisData3());

        AccountOwnerPEGARequest request = mapper.readValue(requestString, AccountOwnerPEGARequest.class);
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));

        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        URI url = URI.create("http://localhost/testurl");
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AccountOwnerPEGAResponse>> responseMono = helper.updateAccountOwner(serverHttpRequest, request) ;
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void updateAccountOwnerTest_emptyResponse() throws IOException {

        String mockRedisData = mapper.writeValueAsString(getRedisData4());

        AccountOwnerPEGARequest request = mapper.readValue(requestString, AccountOwnerPEGARequest.class);
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));

        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        URI url = URI.create("http://localhost/testurl");
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(""));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AccountOwnerPEGAResponse>> responseMono = helper.updateAccountOwner(serverHttpRequest, request) ;
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void updateAccountOwnerTest5() throws IOException {

        String responseString = "{\"status\":\"ok\",\"payload\":{\"cqContent\":{\"label\":{\"OD_PREPAID_CART_HOLIDAY_RETURN_POLICY_HEADER_TEXT\":\"PurchasewithconfidencewithourHolidayReturnPolicy\",\"OD_PREPAID_CART_HOLIDAY_RETURN_POLICY_SUBHEADING_TEXT\":\"Arestockingfeeof$50appliestoanyreturnorexchangeofawirelessdevice(excludingHawaii).\",\"OD_PREPAID_CART_HOLIDAY_RETURN_POLICY_SUBHEADING_TOOLTIP_TEXT\":\"DevicesandaccessoriespurchasedbetweenNovember24,2022throughDecember15,2022maybereturnedorexchangedonorbeforeJanuary14,2023.DevicesandaccessoriespurchasedonorafterDecember16,2022maybereturnedorexchangedwithin30daysofpurchase.Thereturnandexchangeperiodbeginsuponthedateofpurchaseorthedateofdeliveryofyournewdevice.Arestockingfeeof$50appliestoanyreturnorexchangeofawirelessdevice(excludingHawaii).Ifyoupurchasedyourdeviceandaccessoriesfromanon-Verizonoperatedretaillocation(authorizedretailer),youshouldreviewthatlocation'sreturnpolicyregardingtheiracceptanceofdeviceandaccessoryreturns.\",\"OD_PREPAID_CART_ADD_A_NEW_DEVICE_BTN\":\"Addaline?\",\"OD_PREPAID_CART_ADD_A_BYOD_DEVICE_BTN\":\"Bringyourowndevice?\",\"OD_PREPAID_CONFIRMATION_DIALOG_HEADING\":\"Areyousureyouwanttoremovethis$itemName$?\",\"OD_PREPAID_REMOVE_CTA\":\"Yes,remove\",\"OD_PREPAID_SMARTPHONE_UNLIMITED_PLUS\":\"Smartphoneplan<br/>UnlimitedPlus\",\"OD_PREPAID_CART_CC_MAIN_HEADING\":\"Justconfirmthedetailsandyou'regoodtogo.\",\"OD_PREPAID_CART_BONUS_DATA_PROMO\":\"Additional$bonusData$dataeverymonth.\",\"OD_PREPAID_CART_MAIN_HEADING\":\"Here'swhatyou'veselected,justdoublecheckeverything'sgoodtogo.\",\"OD_PREPAID_CART_DUE_MONTHLY_LABEL\":\"Monthlypayment\",\"OD_PREPAID_CART_DUE_TODAY_LABEL\":\"Duetoday\",\"OD_PREPAID_CART_CHECKOUT_BTN_LABEL\":\"Checkout\",\"OD_PREPAID_CART_SUMMARY_LABEL\":\"Summary\",\"OD_PREPAID_CART_PLAN_LABEL\":\"Plan\",\"OD_PREPAID_CART_DEVICE_LABEL\":\"Phones\",\"OD_PREPAID_CART_SAVINGS_LABEL\":\"Savings\",\"OD_PREPAID_CART_TOTAL_HEADING\":\"Total\",\"OD_PREPAID_CART_CLEAR_CART_LINK\":\"Clearcart\",\"OD_PREPAID_CART_SAVE_CART_LINK\":\"savecart\",\"OD_PREPAID_CART_BANNER_HEADING_TEXT\":\"You'realmostthere.\",\"OD_PREPAID_CART_BANNER_SUB_HEADING_TEXT\":\"Checkoutandstartsavingwithloyaltydiscounts\",\"OD_PREPAID_CART_BANNER_LINK_TEXT\":\"Learnmore\",\"OD_PREPAID_LOYALTY_PROGRAM_HEADING_TEXT\":\"Plandiscountdetails\",\"OD_PREPAID_LOYALTY_PROGRAM_SUBHEADING_TEXT\":\"Requirements;`AutoPaydiscount\",\"OD_PREPAID_LOYALTY_PROGRAM_SUBHEADING_CONTENT\":\"$5/moloyaltydiscountappliesafter3monthsofservice;additional$5/moappliesafter9monthsofservice,foratotalof$10/moonplans$40orhigher.Discountappliesaslongasyourlineisnotdisconnected.;`AutoPaydiscountof$5/moavailableafter1stmonthforalltheplans.Creditordebitcardrequired.\",\"OD_PREPAID_PLAN_MOBILEHOTSPOT_HEADING\":\"Purchase;`Details;`Manage;`Cancellation;`Disclaimer\",\"OD_PREPAID_PLAN_MOBILEHOTSPOT_CONTENT\":\"YoucanaddMobileHotspotandwillbecharged$5eachmonthonyourrenewaldate.;`MobileHotspotletsyoushare10GBofhigh-speeddatawithotherdevicessotheycanaccesstheInternet.YourdevicesconnectoverWi-Fiforunlimitedaccessat600Kbpsspeedsonoursecurenetwork.;`MobileHotspotcomespreinstalledoncompatibledevices.Dependingonyourdevice,itmaybeinyourAppmenuorSettings.;`IfyoudecidetoremoveMobileHotspot,you'llnolongerbeabletoconnectotherdevices.;`MobileHotspotandtetheringavailableontheUnlimitedPlanfor$5/mo.Includes10GBofhigh-speeddata,thenspeedsupto600Kbpstheremainderofthemonth.Yourdataexperienceandfunctionalityofsomedataapplicationssuchasstreamingvideooraudiomaybeimpacted.\",\"OD_PREPAID_SMARTPHONE_PLAN_LABEL\":\"Smartphoneplan\",\"OD_PREPAID_CART_EDIT_PLAN_LINK\":\"Changeplan\",\"OD_PREPAID_CART_ADD_INTL_FEATURE_LABEL\":\"AddInternationalcalling\",\"OD_PREPAID_CART_LINE_DISCOUNT_LABEL\":\"linediscount\",\"OD_PREPAID_CART_EDIT_FEATURE_LINK\":\"Edit\",\"OD_PREPAID_CART_REMOVE_FEATURE_LINK\":\"Remove\",\"OD_PREPAID_CART_EDIT_DEVICE_LINK\":\"Edit\",\"OD_PREPAID_CART_REM_DEVICE_LINK\":\"Removeline\",\"OD_PREPAID_CART_OWNER_LABEL\":\"Currentaccountowner\",\"OD_PREPAID_CART_CHANGE_OWNER_LINK\":\"Edit\",\"OD_PREPAID_CART_DISCOUNTS_LABEL\":\"Discounts\",\"OD_PREPAID_CART_ORDER_SAVINGS_LABEL\":\"Ordersavings\",\"OD_PREPAID_CART_TAX_DISCLAIMER\":\"*Monthlytaxes,andgovernmentfeeswillbeaddedtoyourbill.\",\"OD_PREPAID_CART_ZIP_HEADING\":\"BasedonyourZIPcode\",\"OD_PREPAID_CART_CHANGE_ZIP_LABEL\":\"EnteryourZIPcode:\",\"OD_PREPAID_CART_APPLY_BTN_LABEL\":\"Apply\",\"OD_PREPAID_CART_RETURN_POLICY_HEADING\":\"Needtoreturnorexchangeapurchase?Noproblem.\",\"OD_PREPAID_CART_ADD_A_LINE_BTN\":\"Addaline?\",\"OD_PREPAID_CART_YES_BTN\":\"Yes\",\"OD_PREPAID_CART_CANCEL_BTN\":\"Cancel\",\"OD_PREPAID_CART_REM_DEVICE_HEADING\":\"Areyousureyouwanttoremovethisdevice?\",\"OD_PREPAID_SAVE_CART_HEADING\":\"Youcansavethiscartforupto30days.\",\"OD_PREPAID_CART_EMPTY_CART_HEADING\":\"Areyousureyouwanttostartagain?\",\"OD_PREPAID_CART_REM_DEVICE_SUB_HEADING\":\"Youwillloseyourdeviceconfigurationandanyoffersassociatedwiththisdevice.\",\"OD_PREPAID_CART_EMPTY_CART_SUB_HEADING\":\"Ifyouclearplansanddevicesfromyourcart,you'llhavetostartfromthebeginningagain.Doyouwanttodothis?\",\"OD_PREPAID_CART_ENTER_EMAIL_TITLE\":\"Enteryouremailandwe'llsendyouacopyofyourcart.\",\"OD_PREPAID_CART_SAVE_CART_BTN_LABEL\":\"Saveandcontinue\",\"OD_PREPAID_CART_DONT_SAVE_CART_BTN_LABEL\":\"Continuewithoutsaving\",\"OD_PREPAID_PLAN_CC_INTRIAL_UNLIMITED_PLAN_HEADING\":\"ConnectedCarWi-Fi{planSize}UnlimitedMonthlySubscription.\",\"OD_PREPAID_CART_CC_ONE_LINE_ITEM\":\"Justaheadsupthatyoucanonlyactivateonedeviceatatimeonthisaccount.Continuetocheckout,orcallusat1-800-255-3987ifyouhaveanyquestions.\",\"OD_PREPAID_UNLIMITED_75GB_PLAN_TEXT\":\"Includes5GUltraWideband\",\"OD_PREPAID_PLAN_MOBILEHOTSPOT_SL_HEADING\":\"Purchase;`Details;`Manage;`Disclaimer\",\"OD_PREPAID_PLAN_MOBILEHOTSPOT_SL_CONTENT\":\"YoucanaddMobileHotspotandwillbecharged$5eachmonthonyourrenewaldate.;`MobileHotspotletsyousharedatawithotherdevicessotheycanaccesstheinternet.IfyoudecidetoremoveMobileHotspot,you'llnolongerbeabletoconnectotherdevices.;`MobileHotspotcomespreinstalledoncompatibledevices.Dependingonthedevice,itmaybeintheAppmenuorSettings.;`MobileHotspotandtetheringavailableontheUnlimitedPlanfor$5/mo.Includes10GBof5GNationwide/4GLTEdata,thenspeedsupto600KbpstheremainderOfthemonth.YourdataexperienceandfunctionalityOfsomedataapplicationssuchasstreamingvideooraudiomaybeimpacted.\",\"OD_PREPAID_PLAN_MOBILEHOTSPOT_ML_HEADING\":\"Purchase;`Details;`Manage;`Disclaimer\",\"OD_PREPAID_PLAN_MOBILEHOTSPOT_ML_CONTENT\":\"YoucanaddMobileHotspottothislineandwillbecharged$5eachmonthOnyourrenewaldate.;`MobileHotspotletsthislinesharedatawithotherdevicessotheycanaccesstheinternet.IfyoudecidetoremoveMobileHotspotfromthisline,they'llnolongerbeabletoconnectotherdevices.;`MobileHotspotcomespreinstalledoncompatibledevices.Dependingonthedevice,itmaybeintheAppmenuorSettings.;`MobileHotspotandtetheringavailableontheUnlimitedPlanfor$5/mo.Includes10GBof5GNationwide/4GLTEdata,thenspeedsupto600Kbpstheremainderofthemonth.Yourdataexperienceandfunctionalityofsomedataapplicationssuchasstreamingvideooraudiomaybeimpacted.\",\"OD_PREPAID_UNLIMITED_75GB_PLAN_TOOLTIP_TEXT\":\"<b>5GUltraWidebandavailableonlyinpartsofselectcities.</b><br></br>5GUltraWidebandaccessrequiresa5G-capabledeviceinsidethe5GUltraWidebandCoverageArea.Downloadsover5GUltraWideband.Dependingonlocation,uploadsover5GUltraWidebandor4GLTE.\",\"OD_PREPAID_MOBILE_HOTSPOT_POPUP_HEADNG\":\"MobileHotspotDetails\",\"OD_PREPAID_SECURE_CHECKOUT_CTA\":\"Beginsecurecheckout\",\"OD_PREPAID_CART_MULTILINE_DISCOUNTS_LABEL\":\"Multilinediscount\",\"OD_PREPAID_VIEW_RETURN_POLICY_TEXT\":\"Viewreturnpolicy\",\"OD_PREPAID_CHECKOUT_MULTILINE_CONTENT\":\"You’resaving$20/mowithmultilinediscount.\",\"OD_PREPAID_PLAN_MULTILINE_DISCOUNT_TOOLTIP\":\"Save$20/mowhenyouaddanyVerizonPrepaidUnlimitedphoneplantoyourMultilineaccount.Firstlineontheaccountcanbeeitheronaphoneordataplan.EachadditionalUnlimitedphonelinereceivesa$20/modiscount.EligibilityforAutoPayorLoyaltydiscountsalsoavailable.\",\"OD_PREPAID_CHECKOUT_MULTILINE_DATA_PLAN_CONTENT\":\"You’resaving$30/mowithmultilinediscount.\",\"OD_PREPAID_PLAN_MULTILINE_DISCOUNT_DATA_PLAN_TOOLTIP\":\"ForanactiveVerizonPrepaidaccount,receivea$30/modiscountoneachlineyouaddwithadataplan.Firstlineontheaccountcanbeeitheraphoneordataplan.Additionaltaxesandfeesmayapply.DatalinesdonotqualifyforAutoPayorLoyaltydiscounts.\",\"OD_PREPAID_CHECKOUT_AUTOPAY_REDEEMED_TOOLTIP\":\"AutoPaydiscountof$10/moonplans$45&higherafterthe1stmonth.$5/modiscountonthe$35Talk&Textplanafterthe1stmonth.CreditorDebitcardrequired.Additionalloyaltydiscountsdonotapply.\",\"OD_PREPAID_CHECKOUT_AUTOPAY_REDEEMED_LABEL\":\"AutoPaydiscountof${autoPaySaving}/moavailableafter1stmonth.\",\"OD_PREPAID_UNLIMITED_DISNEY_PLUS_OFFER_TEXT\":\"Includes6monthsofDisney+\",\"OD_PREPAID_UNLIMITED_DISNEY_PLUS_OFFER_TOOLTIP_TEXT\":\"Disney+onusfor6months;thenauto-renewsatthen-currentmonthlyprice(currently$7.99+taxpermonth)afterpromoperiodendsunlessyoucancel.MustactivateanUnlimited$65or$75planbetween7.27.22and1.31.23andremainontheplantoretainoffer.Mustredeemby3.2.23.NewandeligiblereturningDisney+subscribersonly.Mustbe18+.Additionaltermsapply.OneofferpereligibleVerizonaccount.©2022Disneyanditsrelatedentities.\",\"OD_PREPAID_CHECKOUT_CONFIRMATION_UNLIMITED_DISNEY_PLUS_OFFER_TEXT\":\"<br/><br/>You'llalsoreceiveacodeviatextwithin24hourstoactivateDisney+.\",\"OD_PREPAID_LOYALTY_PROGRAM_HEADING_PRICING_TEXT\":\"SavemorewithVerizondiscounts.\",\"OD_PREPAID_LOYALTY_PROGRAM_HEADING_PRICING_SUBTEXT\":\"Saveupto$10permonthwithAutoPay.Orsavewithloyaltydiscountsovertime.\",\"OD_PREPAID_LOYALTY_PROGRAM_SUBHEADING_PRICING_TEXT\":\"AutoPaydiscounts;`Loyaltydiscount\",\"OD_PREPAID_LOYALTY_PROGRAM_SUBHEADING_PRICING_CONTENT\":\"$10/moAutoPaydiscountonplans$45&higherafterthefirstmonth.$5/modiscountonthe$35Talk&Textplanafterthe1stmonth.CreditorDebitcardrequired.Additionalloyaltydiscountsdonotapply.;`$5/moloyaltydiscountappliesafter3monthsofservice;additional$5/moappliesafter9monthsofservice,foratotalof$10/moonplans$45orhigher.Discountappliesaslongasyourlineisnotdisconnected.AdditionalAutoPaydiscountsdonotapply.\",\"OD_PREPAID_LOYALTY_PROGRAM_MAXIMUM_DISCOUNT\":\"Upto$10/modiscount\",\"OD_PREPAID_UNLIMITED_DISNEY_PLUS_OFFER_PRICING_TOOLTIP_TEXT\":\"Disney+onusfor6months;thenauto-renewsatthen-currentmonthlyprice(currently$7.99+taxpermonth)afterpromoperiodendsunlessyoucancel.MustactivateanUnlimited$60or$70planbetween7.27.22and1.31.23andremainontheplantoretainoffer.Mustredeemby3.2.23.NewandeligiblereturningDisney+subscribersonly.Mustbe18+.Additionaltermsapply.OneofferpereligibleVerizonaccount.©2022Disneyanditsrelatedentities.\",\"OD_PREPAID_CHECKOUT_TERMS_AND_CONDITIONS\":\"TermsandConditions\",\"offerDetailsContent\":{\"OD_PREPAID_BANNER_HEADING_TEXT\":\"You'realmostthere.\",\"OD_PREPAID_BANNER_SUB_HEADING_TEXT\":\"Checkoutandstartsavingwithourbestplans.\",\"OD_PREPAID_VARIANT_BANNER_HEADING\":\"Continuetocheckout.\",\"OD_PREPAID_CART_OFFER_BANNER_HEADING_TEXT\":\"You'realmostthere.\",\"OD_PREPAID_CART_OFFER_BANNER_SUB_HEADING_TEXT\":\"Completeyournewactivation,andyou'reonestepclosertoafreemonthonus.\",\"OD_PREPAID_CART_OFFER_BANNER_LINK_TEXT\":\"LearnMore\",\"OD_PREPAID_OFFER_DETAILS_POPUP_HEADING_TEXT\":\"Offerdetails\",\"OD_PREPAID_OFFER_DETAILS_POPUP_CONTENT\":\"CreditappliedtoAccountOwnerfor3rdmonthrenewal;creditequaltothemonthlyplancostattimeofrenewal.Requiresanewlineand2monthsofservice.Upto$75savingsbasedonactivationofeligibleprepaidplanandnon-Autopaycustomer.Offernotavailableinallsaleschannels.Limitedtimeoffer.\",\"OD_PREPAID_JETPACK_TABLET_BANNER_SUB_HEADING_TEXT\":\"You'reonestepclosertocompletingyournewactivation.\",\"OD_PREPAID_OFFER_DETAILS_POPUP_CTA_TEXT\":\"Done\"}},\"html\":{\"OD_PREPAID_CART_VARIANT_RETURN_POLICY_SUMMARY\":\"<h3>Purchasewithconfidencewithour30-dayreturnandexchangeperiod.</h3><pclass='noTopMargin'>Arestockingfeeof$50appliestoanyreturnorexchangeofawirelessdevice(excludingHawaii).</p>\",\"OD_PREPAID_SMARTPHONE_UNLIMITED_PLUS\":\"Smartphoneplan<br/>UnlimitedPlus\",\"OD_PREPAID_CART_MAX_LIMIT_REACHED_HTML\":\"Sorry!Yourcartonlyholds$max_device_limit$devices.Weappreciateyourbusinessandhopethatyou'lladdthisitemafteryoucheckout.Questions?Call1-800-256-4644\",\"OD_PREPAID_CART_DEVICE_MISMATCH_HTML\":\"Oops.Unfortunately,thedeviceyou'retryingtoaddisn'teligibleforthePrepaidFamilyPlan.\",\"OD_PREPAID_TAX_PROMO_BANNER_HTML\":\"<style>.promo_heading{font-size:20px;}.tooltip-container.sm-screen{bottom:45px}@media(min-width:768px){.promo_heading{font-size:32px;}.mixed-cart-promo{position:relative;background:url(https://ss7.vzw.com/is/image/VerizonWireless/checkout-prepaid-bonus-data-d-010219?&scl=2)no-repeat;background-position:center;height:190px;background-size:100%;padding:20px;}.mixed-cart-promo.message{font-size:20px;width:291px;}}@mediaonlyscreenand(max-width:767px){.mixed-cart-promo{background:url(https://ss7.vzw.com/is/image/VerizonWireless/checkout-prepaid-bonus-data-d-010219?&scl=3)no-repeat;height:110px;padding:15px;position:relative;background-size:100%;}}@mediaonlyscreenand(max-width:620px){.promo_heading{font-size:16px;}.mixed-cart-promo{background:url(https://ss7.vzw.com/is/image/VerizonWireless/checkout-prepaid-bonus-data-m-010219?&scl=2)no-repeat;background-size:100%;height:136px;}.mixed-cart-promo.message{font-size:14px;width:215px;}.mixed-cart-promo.promoCTA{position:relative;bottom:0;margin-top:12px;font-size:16px;}}@mediaonlyscreenand(max-width:550px){.mixed-cart-promo.message{font-size:12px;width:190px;}.mixed-cart-promo{background:url(https://ss7.vzw.com/is/image/VerizonWireless/checkout-prepaid-bonus-data-m-010219?&scl=1)no-repeat;padding:15px;background-size:480px;position:relative;height:136px;background-position:right0;}}</style><divclass='mixed-cart-promo'><divclass='promo_headingbold'>Get15GB<brclass='lg-screen'/>for$45/mo.</div><divclass='clear6'></div><divclass='boldlg-screen'>WhenyouenrollinAutoPay.<br/>Limitedtimeonly</div><divclass='sm-screen'>WhenyouenrollinAutoPay.<br/>Limitedtimeonly</div><divclass='clear20'></div><divclass='tooltip-containerlg-screen'style='position:absolute;bottom:30px'><ahref='javascript:void(0)'class='linkfontSize_3tooltip-btn'aria-label='Seedetailstooltipcollapsed'id='label_modal_1'>Seedetails</a><spanclass='tooltip-contentis-hidden'><buttonclass='tooltip-close'aria-label='Closeinformationtooltip'>×</button>Promotional7GBon$50planuntil4/30/19.Availabletonewcustomers,andexistingcustomersthatupgradetoorreactiveonthe8GB$50plan.BonusDataaddedeachmonthaslongasyouprepiadaccountremainsactive.Youraccountmusthavesufficientfundstoremainactive.Autopaydiscountappliesafter1stmonth.Creditordebitcardonlyreq'd.1stmonthfees;$40,$50,$70dependingonplan.</span></div><divclass='tooltip-containersm-screen'style='position:absolute;bottom:45px'><ahref='javascript:void(0)'class='linkfontSize_3tooltip-btn'aria-label='Seedetailstooltipcollapsed'id='label_modal_1'>Seedetails</a><spanclass='tooltip-contentis-hidden'><buttonclass='tooltip-close'aria-label='Closeinformationtooltip'>×</button>Promotional7GBon$50planuntil4/30/19.Availabletonewcustomers,andexistingcustomersthatupgradetoorreactiveonthe8GB$50plan.BonusDataaddedeachmonthaslongasyouprepiadaccountremainsactive.Youraccountmusthavesufficientfundstoremainactive.Autopaydiscountappliesafter1stmonth.Creditordebitcardonlyreq'd.1stmonthfees;$40,$50,$70dependingonplan.</span></div></div>\",\"OD_PREPAID_PROMO_BANNER_HTML\":\"<style>.mixed-cart-promo{position:relative;background:url(https://ss7.vzw.com/is/image/VerizonWireless/data-device-tablet-jetpack-final-d-09252020?&scl=2)no-repeat!important;background-position:center;background-size:cover!important;height:275px;padding:28px;}.mixed-cart-promo.message{font-size:15px;width:291px;}.message-font{font-size:40px}.mixed-cart-promo.promoCTA{position:absolute;bottom:20px;font-size:18px;}@mediaonlyscreenand(max-width:860px){.mixed-cart-promo{background:url(https://ss7.vzw.com/is/image/VerizonWireless/data-device-tablet-jetpack-final-d-09252020?&scl=2)no-repeat!important;background-position:center;background-size:cover!important;height:275px;}.mixed-cart-promo.message{font-size:16px;}}@mediaonlyscreenand(max-width:620px){.mixed-cart-promo{background:url(https://ss7.vzw.com/is/image/VerizonWireless/data-device-tablet-jetpack-final-d-09252020?&scl=2)no-repeat!important;background-position:center;background-size:cover!important;height:100px;padding:12px;}.mixed-cart-promo.message{font-size:14px;width:215px;}.mixed-cart-promo.promoCTA{position:relative;bottom:0;margin-top:12px;font-size:16px;}}@mediaonlyscreenand(max-width:550px){.mixed-cart-promo.promoCTA{font-size:14px;margin-top:10px;}.mixed-cart-promo.message{font-size:15px;width:230px;}.mixed-cart-promo{background:url(https://ss7.vzw.com/is/image/VerizonWireless/data-device-tablet-jetpack-final-d-09252020?&scl=2)no-repeat!important;background-position:center;background-size:cover!important;height:240px;width:450px}}</style><divclass='mixed-cart-promo'><divclass='messagebold'><spanclass='message-font'>Getdouble</span></br><spanclass='message-font'>thedata.</span><br>Get16GBforjust<br>$45/mowhenyou<br>enrollinAutoPay.</div><divclass='tooltip-container'><ahref='javascript:void(0)'class='linkfontSize_3tooltip-btn'aria-label='Seedetailstooltipcollapsed'id='label_modal_1'>Seedetails</a><spanclass='tooltip-contentis-hidden'><buttonclass='tooltip-close'aria-label='Closeinformationtooltip'>×</button>Availabletonewactivationsonly.Bonusdataaddedeachmonthaslongasyouraccountremainsactive.Onceactivated,customerscanmovebetweeneligibleplansanytimeandkeepthebonusdata.Yourbonusdataallowancewillnotappearinyourshoppingcartbutwillbeseeninyouraccountafteractivation.<br><br>Autopaydiscountof$5/moappliesafter1stmonthonplans$40orhigher.CreditorDebitcardonlyreq'd.</span></div></div></div>\",\"OD_PREPAID_CART_EUP_BANNER\":\"Wow,thatwasfast.Yournewdeviceisreadytogoonyourexistingplan.Justplaceyourorderandyou'reallset.\",\"OD_PREPAID_CART_ACTIVATION_FEE_HTML\":\"Onetimeactivationfee<br>(waivedonlineonly)\",\"OD_PREPAID_CART_RETURN_POLICY_SUMMARY_HTML\":\"<h3>Purchasewithconfidencewithour30-dayreturnandexchangeperiod.</h3><pclass='noTopMargin'>Arestockingfeeof$50appliestoanyreturnorexchangeofawirelessdevice(excludingHawaii).</p><adata-track='Viewreturnpolicy'href='https://www.verizonwireless.com/support/return-policy/'target='_blank'class='link'>Viewreturnpolicy</a>\",\"OD_PREPAID_CART_HOLIDAY_RETURN_POLICY_LINK_TEXT\":\"<adata-track='Viewreturnpolicy'href='https://www.verizonwireless.com/support/return-policy/'target='_blank'class='link'>HolidayReturnPolicy</a>\",\"OD_PREPAID_CART_TAXES_HEADING_HTML\":\"Taxesand<br/>governmentfees\"},\"error\":{\"OD_PREPAID_CART_CC_MAX_LIMIT_ERROR\":\"Wewereunabletoaddyouritemstothecartbecauseyoucanonlyactivateonedeviceatatimeonthisaccount.Continuetocheckout,orcallusat1-800-255-3987ifyouhaveanyquestions.\",\"OD_PREPAID_CART_CC_ADDING_NONCC_ITEM_ERROR\":\"OD_PREPAID_CART_CC_ADDING_NONCC_ITEM_ERROR\"}},\"pageData\":{\"status\":200,\"orderId\":\"S5d3deecdc200c1b1b453baef29f5e5ef{s4}\",\"orderTotal\":110.0,\"orderTax\":0.0,\"orderDiscount\":0.0,\"monthlySavings\":20.0,\"orderZipcode\":\"30004\",\"dueMonthly\":110.0,\"dueToday\":110.0,\"flow\":\"NSP\",\"totalActivationfee\":0.0,\"sessionId\":\"POS-D-1dbfb7cf-240f-49e4-bd25-711487331e89{s4}\",\"deviceList\":[{\"quantity\":1,\"skuId\":\"sku4120159\",\"productId\":\"dev10920021\",\"seoName\":\"apple-iphone-xr-prepaid\",\"sorId\":\"MH563LL/A\",\"listPrice\":0.0,\"itemAmount\":0.0,\"rawTotalAmount\":0.0,\"deviceTax\":0.0,\"skuDisplayName\":\"iPhoneXRPrepaid\",\"activationFee\":0.0,\"color\":\"Black\",\"capacity\":\"64GB\",\"brandName\":\"Apple\",\"imageUrl\":\"https://ss7.vzw.com/is/image/VerizonWireless/iPhoneXr_Black_PureAngles?$device-lg$\",\"miniImageUrl\":\"https://ss7.vzw.com/is/image/VerizonWireless/iPhoneXr_Black_PureAngles?$device-mini$\",\"planItemId\":\"S5d3deecdc200c1b1b453baef29f5e5ef{s4}_plan_397867880\",\"accountMember\":false,\"accountOwner\":true,\"portInDevice\":false,\"daccCode\":\"P1189\",\"simDisplayName\":\"GTO4G5GInterimDFILLSIM\",\"purchasePath\":\"NSP\",\"itemType\":\"smartphone\",\"totalDueMonthly\":60.0,\"totalDueToday\":60.0,\"trialStatus\":null,\"deviceSorType\":\"4GE\",\"fiftyPercentPromoApplied\":false,\"lineSecurityPin\":null,\"securityQuestion\":null,\"securityAnswer\":null,\"deviceFirstName\":null,\"deviceLastName\":null,\"simId\":null,\"esimCompatible\":false,\"esimOnlyDevice\":false,\"smartImeiDevice\":false,\"imei\":null,\"imei2\":null,\"requestedEsimImei\":null,\"itemDiscount\":0.0,\"autoPaymentEligible\":false,\"eSIMEnabledDevice\":false,\"fullRetailListPrice\":0.0,\"taxDetails\":{},\"existingDevice\":null,\"npaNxxCode\":\"470-626-XXXX\",\"id\":\"S5d3deecdc200c1b1b453baef29f5e5ef{s4}_device_269631950\",\"inlinePromo\":false},{\"quantity\":1,\"skuId\":\"sku4120159\",\"productId\":\"dev10920021\",\"seoName\":\"apple-iphone-xr-prepaid\",\"sorId\":\"MH563LL/A\",\"listPrice\":0.0,\"itemAmount\":0.0,\"rawTotalAmount\":0.0,\"deviceTax\":0.0,\"skuDisplayName\":\"iPhoneXRPrepaid\",\"activationFee\":0.0,\"color\":\"Black\",\"capacity\":\"64GB\",\"brandName\":\"Apple\",\"imageUrl\":\"https://ss7.vzw.com/is/image/VerizonWireless/iPhoneXr_Black_PureAngles?$device-lg$\",\"miniImageUrl\":\"https://ss7.vzw.com/is/image/VerizonWireless/iPhoneXr_Black_PureAngles?$device-mini$\",\"planItemId\":\"S5d3deecdc200c1b1b453baef29f5e5ef{s4}_plan_611852131\",\"accountMember\":true,\"accountOwner\":false,\"portInDevice\":false,\"daccCode\":\"P1189\",\"simDisplayName\":\"GTO4G5GInterimDFILLSIM\",\"purchasePath\":\"NSP\",\"itemType\":\"smartphone\",\"totalDueMonthly\":50.0,\"totalDueToday\":50.0,\"trialStatus\":null,\"deviceSorType\":\"4GE\",\"fiftyPercentPromoApplied\":false,\"lineSecurityPin\":null,\"securityQuestion\":null,\"securityAnswer\":null,\"deviceFirstName\":null,\"deviceLastName\":null,\"simId\":null,\"esimCompatible\":false,\"esimOnlyDevice\":false,\"smartImeiDevice\":false,\"imei\":null,\"imei2\":null,\"requestedEsimImei\":null,\"itemDiscount\":0.0,\"autoPaymentEligible\":false,\"eSIMEnabledDevice\":false,\"fullRetailListPrice\":0.0,\"taxDetails\":{},\"existingDevice\":null,\"npaNxxCode\":\"470-626-XXXX\",\"id\":\"S5d3deecdc200c1b1b453baef29f5e5ef{s4}_device_030385081\",\"inlinePromo\":false}],\"accessoryList\":null,\"planList\":[{\"id\":\"S5d3deecdc200c1b1b453baef29f5e5ef{s4}_plan_611852131\",\"skuId\":\"sku5720003\",\"productId\":\"plan2680002\",\"sorId\":\"28399\",\"dueMonthly\":50.0,\"dueToday\":50.0,\"skuDisplayName\":null,\"itemTax\":0.0,\"discount\":20.0,\"planSize\":\"Unlimited\",\"description\":\"UnlimitedPlusPlan\",\"featureLineItemId\":null,\"title\":\"UnlimitedPlusPlan\",\"fourthLinePromoDiscount\":0.0,\"autoPaySaving\":10.0,\"promotions\":{},\"bonusData\":null,\"eligibleForDoubleData\":true,\"totalDueMonthly\":70.0,\"totalDueToday\":70.0,\"planDueMonthly\":50.0,\"actualPlanPrice\":70.0,\"planDescription\":\"UnlimitedPlusplan\",\"disneyPlusPromo\":false,\"accountOwner\":false,\"loyalityDiscountsEnabled\":true,\"mobileHotspotEnabled\":false,\"autoPayToolTip\":{\"toolTipMessage\":\"EnrollinAutoPayandsaveupto$10/mopereligibleline.\",\"toolTipOverlayMessage\":\"AutoPaydiscountof$10/moonplans$45&higherafterthe1stmonth.$5/modiscountonthe$35Talk&Textplanafterthe1stmonth.CreditorDebitcardrequired.Additionalloyaltydiscountsdonotapply.\"},\"taxDetails\":null,\"discountApplied\":true},{\"id\":\"S5d3deecdc200c1b1b453baef29f5e5ef{s4}_plan_397867880\",\"skuId\":\"sku5720005\",\"productId\":\"plan2680002\",\"sorId\":\"28397\",\"dueMonthly\":60.0,\"dueToday\":60.0,\"skuDisplayName\":null,\"itemTax\":0.0,\"discount\":20.0,\"planSize\":\"Unlimited\",\"description\":\"$60SmartphonePlan\",\"featureLineItemId\":null,\"title\":\"UnlimitedPlan\",\"fourthLinePromoDiscount\":0.0,\"autoPaySaving\":10.0,\"promotions\":{},\"bonusData\":null,\"eligibleForDoubleData\":true,\"totalDueMonthly\":80.0,\"totalDueToday\":80.0,\"planDueMonthly\":60.0,\"actualPlanPrice\":60.0,\"planDescription\":\"Unlimitedplan\",\"disneyPlusPromo\":false,\"accountOwner\":true,\"loyalityDiscountsEnabled\":true,\"mobileHotspotEnabled\":true,\"autoPayToolTip\":{\"toolTipMessage\":\"EnrollinAutoPayandsaveupto$10/mopereligibleline.\",\"toolTipOverlayMessage\":\"AutoPaydiscountof$10/moonplans$45&higherafterthe1stmonth.$5/modiscountonthe$35Talk&Textplanafterthe1stmonth.CreditorDebitcardrequired.Additionalloyaltydiscountsdonotapply.\"},\"taxDetails\":null,\"discountApplied\":false}],\"featureList\":[],\"taxDetailList\":[],\"accountInfo\":{\"mdnNumber\":null,\"accountOwner\":false,\"firstName\":null,\"middleName\":null,\"zipcode\":null,\"fullName\":null,\"address\":null,\"lastName\":null},\"todaySavings\":20.0,\"linesCount\":0,\"cartCount\":2,\"accountOwnerUpdate\":true,\"itemType\":\"smartphone\",\"maxDeviceLimit\":10,\"accountDeviceLimit\":10,\"promotions\":[],\"promoAdded\":false,\"digitalPaymentOptions\":{\"applepayEnabled\":\"true\",\"applePayMerchantId\":\"merchant.com.vzw.test\",\"paypalEnabled\":\"true\"},\"taxPromoEnabled\":false,\"deviceFingerPrintEnabled\":true,\"planDueMonthly\":110.0,\"maxCartLimit\":9,\"trialStatus\":null,\"is5G_EWB_Device\":false,\"nseNsoFlag\":true,\"accumulateInlineDiscount\":0.0,\"inlinePromotionMessage\":null,\"holidayPolicyEnable\":false,\"autopaySavings\":0.0,\"autoPayAccount\":false,\"enableFamilyPricing\":true,\"autopaySavingEligible\":true,\"enabledPriceRefresh\":true,\"planSavings\":20.0,\"shippingDetails\":{},\"nextDueDate\":null,\"dueNextCycle\":110.0,\"offerDataToBeShowed\":true,\"mot\":false}},\"prepayThrottleList\":\"|\"}";
        String mockRedisData = mapper.writeValueAsString(getRedisData5());

        AccountOwnerPEGARequest request = mapper.readValue(requestString, AccountOwnerPEGARequest.class);
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));

        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        URI url = URI.create("http://localhost/testurl");
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AccountOwnerPEGAResponse>> responseMono = helper.updateAccountOwner(serverHttpRequest, request) ;
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void updateAccountOwnerTest_500Response() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        String mockRedisData = mapper.writeValueAsString(getRedisData2());

        AccountOwnerPEGARequest request = mapper.readValue(requestString, AccountOwnerPEGARequest.class);
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));

        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        URI url = URI.create("http://localhost/testurl");
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AccountOwnerPEGAResponse>> responseMono = helper.updateAccountOwner(serverHttpRequest, request) ;
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

}
