package onevz.soe.prepay.adaptor.cart.config;

import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;

import onevz.soe.datastore.annotations.EnableDatastoreClients;

@Configuration
@ComponentScan(basePackages = { "onevz.spring.config", "onevzw.soe.core.config", "onevz.soe.session","onevz.aem.errorhandling","onevz.cxp.feature",
        "onevz.soe.spring.web.filter", "onevz.soe.cradle.client", "onevz.soe.wsclient.prepay.api.impl", "onevz.soe.wsclient.prepay.webclient", "onevz.soe.prepay.adaptor.cart"})

@EnableDatastoreClients(value = {"onevz.soe.cradle", "onevz.soe.core.exception.datastore.client","onevz.soe.security", "onevz.soe.session","onevz.soe.cart.datastore.client","onevz.aem.errorhandling",})
public class PrepayCartAdaptorServiceTestConfig {

	@Bean
    public MessageSource messageSource() {
        ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
 
        messageSource.setBasename("i18n/messages");
        messageSource.setUseCodeAsDefaultMessage(true);
 
        return messageSource;
    }
}
