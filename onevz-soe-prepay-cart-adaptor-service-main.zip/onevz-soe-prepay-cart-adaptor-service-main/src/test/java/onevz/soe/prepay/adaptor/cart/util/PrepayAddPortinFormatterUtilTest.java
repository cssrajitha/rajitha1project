package onevz.soe.prepay.adaptor.cart.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.assignmtn.reponse.pega.PortinPEGAResponse;
import onevz.soe.assignmtn.request.pega.PortinPEGARequest;
import onevz.soe.cart.model.common.PortLine;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.common.model.PrepaidODRequestDataAccessorySkuIds;
import onevz.soe.common.model.PrepaidODRequestDataLines;
import onevz.soe.prepay.adaptor.cart.model.play.*;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
public class PrepayAddPortinFormatterUtilTest {

    ObjectMapper mapper = new ObjectMapper();

    private PrepaidODRequestData getRedisData(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setMtn("0123456789");
        lines.add(line);

        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        line.setAccessorySkuIds(accessorySkuIds);
        redisData.setLines(lines);

        return redisData;
    }

    String requestString = "{\n" +
            "  \"serviceHeader\": {\n" +
            "    \"clientId\": \"VZW-DOTCOM\",\n" +
            "    \"statusMsg\": \"PEGA generated message\",\n" +
            "    \"serviceName\": \"SalesOrderPurchase\",\n" +
            "    \"userId\": \"\",\n" +
            "    \"statusCode\": \"0\",\n" +
            "    \"sessionId\": \"\",\n" +
            "    \"correlationId\": \"soe-cart-2022.01.25.18.58.21-916.8608036659715\"\n" +
            "  },\n" +
            "  \"serviceBody\": {\n" +
            "    \"serviceRequest\": {\n" +
            "      \"context\": {\n" +
            "        \"caseId\": \"SOP-817289281-E01\",\n" +
            "        \"contextInfo\": {\n" +
            "          \"callReason\": \"SalesOrderPurchase\",\n" +
            "          \"processStep\": \"PlanSelection\",\n" +
            "          \"processAction\": \"addPlan\",\n" +
            "          \"intent\": \"Inline-CPC\"\n" +
            "        },\n" +
            "        \"customerInfo\": {\n" +
            "          \"throttleName\": \"|AccessoryInterestialProspect|\",\n" +
            "          \"bucketAllocator\": \"BAU\",\n" +
            "          \"customerType\": \"N\",\n" +
            "          \"accountNumber\": \"\",\n" +
            "          \"cartCreator\": \"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\n" +
            "          \"processingMTN\": \"newLine1\",\n" +
            "          \"registerNumber\": 0,\n" +
            "          \"mtnFlow\": \"P\",\n" +
            "          \"globalId\": \"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"\n" +
            "        },\n" +
            "        \"cartInfo\": {\n" +
            "          \"retrieveFeatureLossReferenceData\": \"Y\",\n" +
            "          \"parentMtn\": \"\",\n" +
            "          \"cartItemCount\": 0,\n" +
            "          \"cartId\": \"b83940f5-0276-407f-947f-c2a2fa819afe\",\n" +
            "          \"itemType\": \"PLAN\",\n" +
            "          \"intendType\": \"NSE\",\n" +
            "          \"action\": \"UPDATE\",\n" +
            "          \"lines\": [\n" +
            "            {\n" +
            "              \"plan\": {\n" +
            "                \"id\": \"50427\",\n" +
            "                \"isRecommendedPlan\": false\n" +
            "              },\n" +
            "              \"mtn\": \"newLine1\",\n" +
            "              \"editSim\": false,\n" +
            "              \"lineWithSkipMDN\": false,\n" +
            "              \"inWithVerizonOpted\": false,\n" +
            "              \"protectionNotRequired\": false\n" +
            "            }\n" +
            "          ],\n" +
            "          \"effectiveDate\": \"\",\n" +
            "          \"checkAutoPayDiscountEligible\": \"N\",\n" +
            "          \"discountPromoTotal\": 0,\n" +
            "          \"registerNumber\": 0,\n" +
            "          \"protectionNotRequired\": false\n" +
            "        }\n" +
            "      }\n" +
            "    }\n" +
            "  }\n" +
            "}";

    @Test
    public void getVZWPrepayAddPortinRequestTest() throws IOException {

        PortinPEGARequest portinPegaRequest = mapper.readValue(requestString, PortinPEGARequest.class);

        portinPegaRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().setPortLines(new PortLine[1]);
        portinPegaRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0] = new PortLine();
        portinPegaRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0].setMtn("newLine1");

        VZWPrepayAddPortinResponse vzwPrepayAddPortinResponse= new VZWPrepayAddPortinResponse();

        VZWPrepayAddPortinRequest response = PrepayAddPortinFormatterUtil.getVZWPrepayAddPortinRequest(portinPegaRequest,getRedisData());
        Assert.assertNotNull(response);
        //ReflectionTestUtils.invokeMethod(prepayAddPortinFormatterUtil, "getResponsePegaPortInContext",portinPegaRequest, vzwPrepayAddPortinResponse, getRedisData());
    }

    @Test
    public void getPortinPEGAResponseTest() throws IOException {

        PortinPEGARequest portinPegaRequest = mapper.readValue(requestString, PortinPEGARequest.class);

        portinPegaRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().setPortLines(new PortLine[1]);
        portinPegaRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0] = new PortLine();

        portinPegaRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0].setMtn("newLine1");

        //PortinPEGARequest portinPegaRequest,VZWPrepayAddPortinResponse vzwPrepayAddPortinResponse, PrepaidODRequestData redisData){
        VZWPrepayAddPortinResponse vzwPrepayAddPortinResponse= new VZWPrepayAddPortinResponse();
        vzwPrepayAddPortinResponse.setPayload(new VZWAddPortinPayload());
        vzwPrepayAddPortinResponse.getPayload().setPageData(new VZWAddPortinPageData());
        List<TransferNumberDetail> transferNumberDetails = new ArrayList<>();
        TransferNumberDetail transferNumberDetail1 = new TransferNumberDetail();
        transferNumberDetails.add(transferNumberDetail1);
        vzwPrepayAddPortinResponse.getPayload().getPageData().setTransferNumberDetails(transferNumberDetails);

        PortinPEGAResponse response = PrepayAddPortinFormatterUtil.getPortinPEGAResponse(portinPegaRequest, vzwPrepayAddPortinResponse, getRedisData(), "false");
        Assert.assertNotNull(response);
        //ReflectionTestUtils.invokeMethod(prepayAddPortinFormatterUtil, "getResponsePegaPortInContext",portinPegaRequest, vzwPrepayAddPortinResponse, getRedisData());
    }

    @Test
    public void getPortinPEGAResponseTest_LoggedInUser() throws IOException {

        PortinPEGARequest portinPegaRequest = mapper.readValue(requestString, PortinPEGARequest.class);

        portinPegaRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().setPortLines(new PortLine[1]);
        portinPegaRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0] = new PortLine();

        portinPegaRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0].setMtn("newLine1");

        VZWPrepayAddPortinResponse vzwPrepayAddPortinResponse= new VZWPrepayAddPortinResponse();
         vzwPrepayAddPortinResponse.setPayload(new VZWAddPortinPayload());
        vzwPrepayAddPortinResponse.getPayload().setPageData(new VZWAddPortinPageData());
        List<TransferNumberDetail> transferNumberDetails = new ArrayList<>();
        TransferNumberDetail transferNumberDetail1 = new TransferNumberDetail();
        transferNumberDetails.add(transferNumberDetail1);
        vzwPrepayAddPortinResponse.getPayload().getPageData().setTransferNumberDetails(transferNumberDetails);
        PrepaidODRequestData redis=getRedisData();
        redis.setLoggedIn(true);
        PortinPEGAResponse response = PrepayAddPortinFormatterUtil.getPortinPEGAResponse(portinPegaRequest, vzwPrepayAddPortinResponse,redis, "false");
        Assert.assertNotNull(response);
    }

    @Test
    public void getPortinPEGAResponseTest_withNoAssigned() throws IOException {

        PortinPEGARequest portinPegaRequest = mapper.readValue(requestString, PortinPEGARequest.class);

        portinPegaRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().setPortLines(new PortLine[1]);
        portinPegaRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0] = new PortLine();

        portinPegaRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0].setMtn("newLine1");

        //PortinPEGARequest portinPegaRequest,VZWPrepayAddPortinResponse vzwPrepayAddPortinResponse, PrepaidODRequestData redisData){
        VZWPrepayAddPortinResponse vzwPrepayAddPortinResponse= new VZWPrepayAddPortinResponse();
        vzwPrepayAddPortinResponse.setPayload(new VZWAddPortinPayload());
        vzwPrepayAddPortinResponse.getPayload().setPageData(new VZWAddPortinPageData());
        List<TransferNumberDetail> transferNumberDetails = new ArrayList<>();
        TransferNumberDetail transferNumberDetail1 = new TransferNumberDetail();
        transferNumberDetails.add(transferNumberDetail1);
        vzwPrepayAddPortinResponse.getPayload().getPageData().setTransferNumberDetails(transferNumberDetails);

        PrepaidODRequestData redisData=getRedisData();
        redisData.setNumberAssignedToAllLines(true);
        List<PrepaidODRequestDataLines> lines=redisData.getLines();
        PrepaidODRequestDataLines lineData=lines.get(0);
        lineData.setSimId("simId");


        PortinPEGAResponse response = PrepayAddPortinFormatterUtil.getPortinPEGAResponse(portinPegaRequest, vzwPrepayAddPortinResponse, redisData, "false");
        Assert.assertNotNull(response);
        //ReflectionTestUtils.invokeMethod(prepayAddPortinFormatterUtil, "getResponsePegaPortInContext",portinPegaRequest, vzwPrepayAddPortinResponse, getRedisData());
    }

    @Test
    public void getPortinPEGAResponseTest_withNoAssignedNoSku() throws IOException {

        PortinPEGARequest portinPegaRequest = mapper.readValue(requestString, PortinPEGARequest.class);

        portinPegaRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().setPortLines(new PortLine[1]);
        portinPegaRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0] = new PortLine();

        portinPegaRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0].setMtn("newLine1");

        //PortinPEGARequest portinPegaRequest,VZWPrepayAddPortinResponse vzwPrepayAddPortinResponse, PrepaidODRequestData redisData){
        VZWPrepayAddPortinResponse vzwPrepayAddPortinResponse= new VZWPrepayAddPortinResponse();
        vzwPrepayAddPortinResponse.setPayload(new VZWAddPortinPayload());
        vzwPrepayAddPortinResponse.getPayload().setPageData(new VZWAddPortinPageData());
        List<TransferNumberDetail> transferNumberDetails = new ArrayList<>();
        TransferNumberDetail transferNumberDetail1 = new TransferNumberDetail();
        transferNumberDetails.add(transferNumberDetail1);
        vzwPrepayAddPortinResponse.getPayload().getPageData().setTransferNumberDetails(transferNumberDetails);

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setNumberAssignedToAllLines(true);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        redisData.setLines(lines);
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setMtn("0123456789");
        lines.add(line);


        PortinPEGAResponse response = PrepayAddPortinFormatterUtil.getPortinPEGAResponse(portinPegaRequest, vzwPrepayAddPortinResponse, redisData, "false");
        Assert.assertNotNull(response);
        //ReflectionTestUtils.invokeMethod(prepayAddPortinFormatterUtil, "getResponsePegaPortInContext",portinPegaRequest, vzwPrepayAddPortinResponse, getRedisData());
    }

    @Test
    public void getPortinPEGAResponseTest_SmartWatch() throws IOException {
        String redisData="{\"ecommSessionId\":\"eyJhbGciOiJIUzI1NiJ9.eyJkYXRhIjp7ImNvcnJlbGF0aW9uSWQiOiJQT1MtRC0xOGRhMzc1ZC05MWQ3LTQ2NTItOGZiMy1iMWM1MTNmYTI1N2F7YXMyfSIsIlNFU1NJT05fSUQiOiJQT1MtRC0xOGRhMzc1ZC05MWQ3LTQ2NTItOGZiMy1iMWM1MTNmYTI1N2F7YXMyfSIsInBsYXlTZXNzaW9uIjoiUE9TLUQtMThkYTM3NWQtOTFkNy00NjUyLThmYjMtYjFjNTEzZmEyNTdhe2FzMn0ifSwibmJmIjoxNzA1NDA1MzY1LCJpYXQiOjE3MDU0MDUzNjV9.vgOqaqaGoHI-2ZLAxfC3mSWvpojhxBTUv6kFUKVkFlQ\",\"curr_line\":2,\"lines\":[{\"mtn\":\"newLine1\",\"deviceId\":\"dev14240058\",\"deviceSkuId\":\"sku4120641\",\"deviceSorId\":\"MGFC3LL/A\",\"completedProcessSteps\":[\"BYODLandingPage\"],\"checkoutFlag\":true,\"imageUrl\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-12-red-10132020?\",\"displayName\":\"iPhone12\",\"capacity\":\"128GB\",\"color\":\"(PRODUCT)RED\",\"manufacturer\":\"Apple\",\"description\":\"iPhone12\",\"numAssigned\":false,\"securityPinAssigned\":false,\"accountOwner\":false,\"flow\":\"NSEBYOD\",\"imei\":\"353253188163701\",\"stageCheckpointFlag\":true,\"uniqueDeviceId\":\"dev14240058_49978084\",\"smartPhone\":true,\"smartWatch\":false,\"basicPhone\":false,\"dataDevice\":false,\"connectedCar\":false,\"planUpdated\":false,\"osType\":\"IOS\",\"numberShareEligibile\":false,\"standaloneEligibile\":false,\"transferNumberEligible\":false,\"esimEnabledDevice\":false,\"esimOnly\":false,\"esimCompatibleDevice\":false},{\"mtn\":\"newLine2\",\"deviceId\":\"dev14080075\",\"deviceSkuId\":\"sku5240438\",\"deviceSorId\":\"MYYR2LL/A\",\"planSorId\":\"28445\",\"completedProcessSteps\":[\"BYODLandingPage\"],\"checkoutFlag\":true,\"imageUrl\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_SE_Nike_LTE_40mm_Silver_Aluminum_Pure_Platinum_Black_Nike_Sport_Band_1?\",\"displayName\":\"WatchSESilverAluminumCasewithPurePlatinumNikeSportBand40MM\",\"capacity\":\"\",\"color\":\"Silver\",\"manufacturer\":\"Apple\",\"description\":\"WatchSESilverAluminumCasewithPurePlatinumNikeSportBand40MM\",\"numAssigned\":false,\"securityPinAssigned\":false,\"accountOwner\":false,\"flow\":\"NSEBYOD\",\"imei\":\"352933119570873\",\"stageCheckpointFlag\":true,\"uniqueDeviceId\":\"dev14080075_31498425\",\"smartPhone\":false,\"smartWatch\":true,\"basicPhone\":false,\"dataDevice\":false,\"connectedCar\":false,\"planUpdated\":false,\"numbershareEligibleOS\":\"IOS\",\"numberShareEligibile\":true,\"standaloneEligibile\":true,\"transferNumberEligible\":true,\"esimEnabledDevice\":false,\"esimOnly\":true,\"esimCompatibleDevice\":false}],\"numberAssignedToAllLines\":false,\"totalNumAssignedLines\":0,\"accountPinAssignedtoAllLines\":false,\"zipCode\":\"93612\",\"autoPay\":false,\"accountOwner\":\"newLine1\",\"refillCardNumbers\":{},\"loggedIn\":false,\"orderConfirmation\":false,\"pcsrfToken\":\"8d89301e29157ce31ccc1598857c08ae3564a52f-1705405364983-ee4ecd2412c3309a8de3e5d6\"}";
        PrepaidODRequestData prepayODRequest = new PrepaidODRequestData();
        prepayODRequest=mapper.readValue(redisData,PrepaidODRequestData.class);

        PortinPEGARequest portinPegaRequest = mapper.readValue(requestString, PortinPEGARequest.class);

        portinPegaRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().setPortLines(new PortLine[1]);
        portinPegaRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0] = new PortLine();

        portinPegaRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0].setMtn("newLine1");

        VZWPrepayAddPortinResponse vzwPrepayAddPortinResponse= new VZWPrepayAddPortinResponse();
        vzwPrepayAddPortinResponse.setPayload(new VZWAddPortinPayload());
        vzwPrepayAddPortinResponse.getPayload().setPageData(new VZWAddPortinPageData());
        List<TransferNumberDetail> transferNumberDetails = new ArrayList<>();
        TransferNumberDetail transferNumberDetail1 = new TransferNumberDetail();
        transferNumberDetails.add(transferNumberDetail1);
        vzwPrepayAddPortinResponse.getPayload().getPageData().setTransferNumberDetails(transferNumberDetails);

        PortinPEGAResponse response = PrepayAddPortinFormatterUtil.getPortinPEGAResponse(portinPegaRequest, vzwPrepayAddPortinResponse, prepayODRequest, "false");
        Assert.assertNotNull(response);
        //ReflectionTestUtils.invokeMethod(prepayAddPortinFormatterUtil, "getResponsePegaPortInContext",portinPegaRequest, vzwPrepayAddPortinResponse, getRedisData());
    }
}
