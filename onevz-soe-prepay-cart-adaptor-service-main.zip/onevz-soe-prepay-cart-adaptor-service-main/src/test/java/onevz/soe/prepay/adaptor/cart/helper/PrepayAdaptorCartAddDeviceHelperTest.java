package onevz.soe.prepay.adaptor.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import net.jcip.annotations.NotThreadSafe;
import onevz.soe.cart.model.addDevice.AddDeviceContext;
import onevz.soe.cart.model.common.CartServiceContextInfo;
import onevz.soe.cart.model.common.CartServiceCustomerInfo;
import onevz.soe.cart.model.common.ProcessMTNList;
import onevz.soe.cart.requests.AddDevicePEGARequest;
import onevz.soe.cart.responses.AddDevicePEGAResponse;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.common.model.PrepaidODRequestDataAccessorySkuIds;
import onevz.soe.common.model.PrepaidODRequestDataLines;
import onevz.soe.prepay.adaptor.cart.model.bpm.*;
import onevz.soe.prepay.adaptor.cart.model.cart.removelines.RemoveLineItemsRequest;
import onevz.soe.prepay.adaptor.cart.model.play.PrepaidODAddAccessoriesOutput;
import onevz.soe.prepay.adaptor.cart.model.play.PrepaidODAddAccessoriesResponse;
import onevz.soe.prepay.adaptor.cart.model.play.PrepaidODAddDeviceRequest;
import onevz.soe.prepay.adaptor.cart.model.play.VZWPrepayAddOrUpdateCartResponse;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import onevz.soe.wsclient.prepay.webclient.model.PrepaidAdaptorWebClientRequest;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.MultiValueMap;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.CHANNEL_ID;
import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_DATA;
import static org.mockito.Mockito.when;

@WebFluxTest
@RunWith(SpringJUnit4ClassRunner.class)
@NotThreadSafe
public class PrepayAdaptorCartAddDeviceHelperTest {

    @Autowired
    PrepayAdaptorCartAddDeviceHelper helper;

    @MockBean
    PrepayCartRedisHelper prepayCartRedisHelper;

    @MockBean
    ServerHttpRequest httpRequest;

    @MockBean
    PrepayAdaptorWebClient prepayAdaptorWebClient;

    @Autowired
    ObjectMapper mapper;


    private PrepaidODRequestData getRedisData(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(2);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        line.setMtn("newLine1");
        line.setCheckoutFlag(false);
        line.setSelectedMtn("425-635-XXXX");
        PrepaidODRequestDataAccessorySkuIds skuIds= new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("123456789");
        List<PrepaidODRequestDataAccessorySkuIds> skuIdsList= new ArrayList<PrepaidODRequestDataAccessorySkuIds>();
        skuIdsList.add(skuIds);
        line.setAccessorySkuIds(skuIdsList);
        PrepaidODRequestDataLines line2 = new PrepaidODRequestDataLines();
        line2.setMtn("newLine2");
        line2.setAccessorySkuIds(skuIdsList);
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        lines.add(line);
        lines.add(line2);
        redisData.setLines(lines);

        return redisData;
    }

    private PrepaidODRequestData getRedisData2(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ934543543543543534543545");
        redisData.setOrderConfirmation(false);
        redisData.setCurr_line(2);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        line.setMtn("newLine1");
        line.setFlow("NSE");
        line.setCheckoutFlag(false);
        line.setSelectedMtn("425-635-XXXX");
        PrepaidODRequestDataAccessorySkuIds skuIds= new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("123456789");
        List<PrepaidODRequestDataAccessorySkuIds> skuIdsList= new ArrayList<PrepaidODRequestDataAccessorySkuIds>();
        skuIdsList.add(skuIds);
        line.setAccessorySkuIds(skuIdsList);
        PrepaidODRequestDataLines line2 = new PrepaidODRequestDataLines();
        line2.setMtn("newLine2");
        line2.setFlow("NSEBYOD");
        line2.setAccessorySkuIds(skuIdsList);
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        lines.add(line);
        lines.add(line2);
        redisData.setLines(lines);

        return redisData;
    }

    private PrepaidODRequestData getRedisData3(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setOrderConfirmation(false);
        redisData.setCurr_line(2);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        line.setMtn("newLine1");
        line.setFlow("NSE");
        line.setSelectedMtn("425-635-XXXX");
        PrepaidODRequestDataAccessorySkuIds skuIds= new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("123456789");
        List<PrepaidODRequestDataAccessorySkuIds> skuIdsList= new ArrayList<PrepaidODRequestDataAccessorySkuIds>();
        skuIdsList.add(skuIds);
        line.setAccessorySkuIds(skuIdsList);
        PrepaidODRequestDataLines line2 = new PrepaidODRequestDataLines();
        line2.setMtn("newLine2");
        line2.setFlow("NSE");
        line.setPlanSkuId("689989898989");
        line2.setAccessorySkuIds(skuIdsList);
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        lines.add(line);
        lines.add(line2);
        redisData.setLines(lines);

        return redisData;
    }

    private PrepaidODRequestData getRedisData4(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setOrderConfirmation(false);
        redisData.setCurr_line(2);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        line.setDataDevice(true);
        line.setUniqueDeviceId("8989808800980");
        line.setCheckoutFlag(false);
        line.setFlow("ESO");
        line.setSelectedMtn("425-635-XXXX");
        PrepaidODRequestDataAccessorySkuIds skuIds= new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("123456789");
        List<PrepaidODRequestDataAccessorySkuIds> skuIdsList= new ArrayList<PrepaidODRequestDataAccessorySkuIds>();
        skuIdsList.add(skuIds);
        line.setAccessorySkuIds(skuIdsList);
        PrepaidODRequestDataLines line2 = new PrepaidODRequestDataLines();

        line2.setFlow("ESO");
        line2.setCheckoutFlag(false);
        line2.setAccessorySkuIds(skuIdsList);
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        lines.add(line);
        lines.add(line2);
        redisData.setLines(lines);

        return redisData;
    }

    private PrepaidODRequestData getRedisData5(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9ertretertrtretretreteterter");
        redisData.setOrderConfirmation(true);
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        line.setMtn("newLine1");
        line.setFlow("NSE");
        line.setSelectedMtn("425-635-XXXX");
        PrepaidODRequestDataAccessorySkuIds skuIds= new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("123456789");
        List<PrepaidODRequestDataAccessorySkuIds> skuIdsList= new ArrayList<PrepaidODRequestDataAccessorySkuIds>();
        skuIdsList.add(skuIds);
        line.setAccessorySkuIds(skuIdsList);
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        lines.add(line);
        redisData.setLines(lines);

        return redisData;
    }

    private PrepaidODRequestData getRedisData6(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9ertretertrtretretreteterter");
        redisData.setOrderConfirmation(true);
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        line.setMtn("newLine1");
        line.setSelectedMtn("425-635-XXXX");
        line.setFlow("NSE");
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        lines.add(line);
        redisData.setLines(lines);

        return redisData;
    }
    private PrepaidODRequestData getRedisData7(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(2);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        line.setMtn("line1");
        line.setCheckoutFlag(false);
        PrepaidODRequestDataAccessorySkuIds skuIds= new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("123456789");
        line.setSelectedMtn("425-635-XXXX");
        List<PrepaidODRequestDataAccessorySkuIds> skuIdsList= new ArrayList<PrepaidODRequestDataAccessorySkuIds>();
        skuIdsList.add(skuIds);
        line.setAccessorySkuIds(skuIdsList);
        PrepaidODRequestDataLines line2 = new PrepaidODRequestDataLines();
        line2.setMtn(null);
        line2.setAccessorySkuIds(skuIdsList);
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        lines.add(line);
        lines.add(line2);
        redisData.setLines(lines);

        return redisData;
    }

    @Test
    public void addDeviceHelperTest() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDevicePEGARequest request = mapper.readValue(requestString, AddDevicePEGARequest.class);
        AddDevicePEGAResponse response = mapper.readValue(responseString, AddDevicePEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddDevicePEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<AddDevicePEGAResponse>> responseMono = helper.addDevice(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addDeviceHelperRedisExceptionTest() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        String mockRedisData = "Value";
        AddDevicePEGARequest request = mapper.readValue(requestString, AddDevicePEGARequest.class);
        AddDevicePEGAResponse response = mapper.readValue(responseString, AddDevicePEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddDevicePEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<AddDevicePEGAResponse>> responseMono = helper.addDevice(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addDeviceHelperTest_maxDeviceLimit() throws IOException {
        ReflectionTestUtils.setField(helper,"maxDevicesAllowedPromoHub",1);
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData();
        redisData.getLines().get(0).setCheckoutFlag(true);
        redisData.getLines().get(1).setCheckoutFlag(true);
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDevicePEGARequest request = mapper.readValue(requestString, AddDevicePEGARequest.class);
        AddDevicePEGAResponse response = mapper.readValue(responseString, AddDevicePEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddDevicePEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<AddDevicePEGAResponse>> responseMono = helper.addDevice(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }


    @Test
    public void addDeviceHelperTest_linesNoData() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData();
        redisData.setLines(null);
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDevicePEGARequest request = mapper.readValue(requestString, AddDevicePEGARequest.class);
        AddDevicePEGAResponse response = mapper.readValue(responseString, AddDevicePEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddDevicePEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<AddDevicePEGAResponse>> responseMono = helper.addDevice(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addDeviceHelperTest5() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData5();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDevicePEGARequest request = mapper.readValue(requestString, AddDevicePEGARequest.class);
        AddDevicePEGAResponse response = mapper.readValue(responseString, AddDevicePEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddDevicePEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<AddDevicePEGAResponse>> responseMono = helper.addDevice(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }


    @Test
    public void addDeviceToPrepayODTest() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData();

        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        AddDeviceToPrepayODBpmResponse response = mapper.readValue(responseString, AddDeviceToPrepayODBpmResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(requestString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayOD(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addDeviceToPrepayTest_noRedisData() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        AddDevicePEGARequest request = mapper.readValue(requestString, AddDevicePEGARequest.class);
        URI url = URI.create("http://localhost/testurl");
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(""));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<AddDevicePEGAResponse>> responseMono = helper.addDevice(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));
    }


    @Test
    public void addDeviceToPrepayODTest_noRedisData() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        URI url = URI.create("http://localhost/testurl");
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(""));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayOD(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));
    }

    @Test
    public void addDeviceToPrepayODTest_nullRedisLines() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        URI url = URI.create("http://localhost/testurl");
        PrepaidODRequestData redisData = getRedisData2();
        redisData.setLines(null);
        String mockRedisData = mapper.writeValueAsString(redisData);
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayOD(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));
    }

    @Test
    public void addDeviceToPrepayODTest_noLinesRedisData() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";
        PrepaidODRequestData redisData = getRedisData2();
        redisData.setLines(Collections.emptyList());
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        AddDeviceToPrepayODBpmResponse response = mapper.readValue(responseString, AddDeviceToPrepayODBpmResponse.class);
        URI url = URI.create("http://localhost/testurl");
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayOD(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addDeviceToPrepayODTest_linestoProcessNull() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";
        PrepaidODRequestData redisData = getRedisData2();
        List<PrepaidODRequestDataLines> lines= redisData.getLines();
        lines.get(0).setCheckoutFlag(true);
        lines.get(1).setCheckoutFlag(true);
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        AddDeviceToPrepayODBpmResponse response = mapper.readValue(responseString, AddDeviceToPrepayODBpmResponse.class);
        URI url = URI.create("http://localhost/testurl");
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayOD(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addDeviceToPrepayODTest_StatusCodeNot200() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData2();
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        AddDeviceToPrepayODBpmResponse response = mapper.readValue(responseString, AddDeviceToPrepayODBpmResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(requestString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayOD(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addDeviceToPrepayODTest2() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData2();

        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        AddDeviceToPrepayODBpmResponse response = mapper.readValue(responseString, AddDeviceToPrepayODBpmResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(requestString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayOD(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addDeviceToPrepayODTest3() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData3();

        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        AddDeviceToPrepayODBpmResponse response = mapper.readValue(responseString, AddDeviceToPrepayODBpmResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(requestString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayOD(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addDeviceToPrepayODTest4() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData4();

        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        AddDeviceToPrepayODBpmResponse response = mapper.readValue(responseString, AddDeviceToPrepayODBpmResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(requestString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayOD(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addDeviceToPrepayODErrorTest() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";
        PrepaidODRequestData redisData = getRedisData4();
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        AddDeviceToPrepayODBpmResponse response = mapper.readValue(responseString, AddDeviceToPrepayODBpmResponse.class);
        URI url = URI.create("http://localhost/testurl");
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        requestString = requestString.replace("}", "");
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(requestString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayOD(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d.getBody().getErrors()));
    }

    @Test
    public void addDeviceToPrepayODTestWithoutLines() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData();
        redisData.getLines().get(0).getAccessorySkuIds().clear();

        MultiValueMap<String,String> headers = new HttpHeaders();
        headers.put("p-csrf-token", Arrays.asList("pcsrfToken"));
        headers.put("ECOMM_SESSION", Arrays.asList("eCommSession"));

        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        AddDeviceToPrepayODBpmResponse response = mapper.readValue(responseString, AddDeviceToPrepayODBpmResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(requestString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayOD(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addDeviceToPrepayODTestWithoutLines_withData() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData();
        //redisData.getLines().get(0).getAccessorySkuIds().clear();

        MultiValueMap<String, String> headers = new HttpHeaders();
        headers.put("p-csrf-token", Arrays.asList("pcsrfToken"));
        headers.put("ECOMM_SESSION", Arrays.asList("eCommSession"));

        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        AddDeviceToPrepayODBpmResponse response = mapper.readValue(responseString, AddDeviceToPrepayODBpmResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(requestString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayOD(httpHeader, request);
        responseMono.subscribe(value -> {
                },
                error -> {
                },
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addDeviceToPrepayODTestWithoutLines_200() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"200\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"200\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        String vzwPrepayAddOrUpdateCartResponse="{\"orderId\":\"Success\",\"status\":\"200\"}";
        PrepaidODRequestData redisData = getRedisData();
        //redisData.getLines().get(0).getAccessorySkuIds().clear();

        MultiValueMap<String, String> headers = new HttpHeaders();
        headers.put("p-csrf-token", Arrays.asList("pcsrfToken"));
        headers.put("ECOMM_SESSION", Arrays.asList("eCommSession"));

        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        AddDeviceToPrepayODBpmResponse response = mapper.readValue(responseString, AddDeviceToPrepayODBpmResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();


        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.ACCEPTED).body(vzwPrepayAddOrUpdateCartResponse));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayOD(httpHeader, request);
        responseMono.subscribe(value -> {
                },
                error -> {
                },
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addDeviceToPrepayODTestWithoutLinesException_200() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"200\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"200\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        String vzwPrepayAddOrUpdateCartResponse="{\"orderId\":\"Success\",\"status\":\"200\"}";
        PrepaidODRequestData redisData = getRedisData();
        //redisData.getLines().get(0).getAccessorySkuIds().clear();

        MultiValueMap<String, String> headers = new HttpHeaders();
        headers.put("p-csrf-token", Arrays.asList("pcsrfToken"));
        headers.put("ECOMM_SESSION", Arrays.asList("eCommSession"));

        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        AddDeviceToPrepayODBpmResponse response = mapper.readValue(responseString, AddDeviceToPrepayODBpmResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();


        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.ACCEPTED).body(vzwPrepayAddOrUpdateCartResponse));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body("value")));

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayOD(httpHeader, request);
        responseMono.subscribe(value -> {
                },
                error -> {
                },
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addDeviceToPrepayODTestWithoutLines_accessorySkuNull() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"200\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"200\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        String vzwPrepayAddOrUpdateCartResponse="{\"orderId\":\"Success\",\"status\":\"200\"}";
        PrepaidODRequestData redisData = getRedisData();
        redisData.getLines().get(0).setAccessorySkuIds(null);
        redisData.getLines().get(1).setAccessorySkuIds(null);

        MultiValueMap<String, String> headers = new HttpHeaders();
        headers.put("p-csrf-token", Arrays.asList("pcsrfToken"));
        headers.put("ECOMM_SESSION", Arrays.asList("eCommSession"));

        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        AddDeviceToPrepayODBpmResponse response = mapper.readValue(responseString, AddDeviceToPrepayODBpmResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();


        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.ACCEPTED).body(vzwPrepayAddOrUpdateCartResponse));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayOD(httpHeader, request);
        responseMono.subscribe(value -> {
                },
                error -> {
                },
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addDeviceToPrepayODTestWithoutLines_500() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"200\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"200\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        String vzwPrepayAddOrUpdateCartResponse="{\"orderId\":\"Success\",\"status\":\"200\"}";
        PrepaidODRequestData redisData = getRedisData();
        //redisData.getLines().get(0).getAccessorySkuIds().clear();

        MultiValueMap<String, String> headers = new HttpHeaders();
        headers.put("p-csrf-token", Arrays.asList("pcsrfToken"));
        headers.put("ECOMM_SESSION", Arrays.asList("eCommSession"));

        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        AddDeviceToPrepayODBpmResponse response = mapper.readValue(responseString, AddDeviceToPrepayODBpmResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();


        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.ACCEPTED).body(vzwPrepayAddOrUpdateCartResponse));

        Mono<ResponseEntity<String>> webClientResponse1 = Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(vzwPrepayAddOrUpdateCartResponse));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse,webClientResponse1);

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayOD(httpHeader, request);
        responseMono.subscribe(value -> {
                },
                error -> {
                },
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addDeviceToPrepayODMultiLineTest() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData();

        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        AddDeviceToPrepayODBpmResponse response = mapper.readValue(responseString, AddDeviceToPrepayODBpmResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MultiValueMap<String,String> headers = new HttpHeaders();
        headers.put("p-csrf-token", Arrays.asList("pcsrfToken"));
        headers.put("ECOMM_SESSION", Arrays.asList("eCommSession"));
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(requestString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayODMultiLine(serverHttpRequest, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void addDeviceToPrepayODMultiLineRedisNullTest() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = null;

        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        AddDeviceToPrepayODBpmResponse response = mapper.readValue(responseString, AddDeviceToPrepayODBpmResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MultiValueMap<String,String> headers = new HttpHeaders();
        headers.put("p-csrf-token", Arrays.asList("pcsrfToken"));
        headers.put("ECOMM_SESSION", Arrays.asList("eCommSession"));
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(requestString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayODMultiLine(serverHttpRequest, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addDeviceToPrepayODMultiLineTest_Dataa1() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"404\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData5();
        PrepaidODRequestDataLines dataLines=getRedisData5().getLines().get(0);
        dataLines.setCheckoutFlag(false);
        redisData.setAccountOwner("newLine1");


        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        AddDeviceToPrepayODBpmResponse response = mapper.readValue(responseString, AddDeviceToPrepayODBpmResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        MultiValueMap<String,String> headers = new HttpHeaders();
        headers.put("p-csrf-token", Arrays.asList("pcsrfToken"));
        headers.put("ECOMM_SESSION", Arrays.asList("eCommSession"));
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(requestString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayODMultiLine(serverHttpRequest, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addDeviceToPrepayODMultiLineTest_Dataa() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData5();
        PrepaidODRequestDataLines dataLines=getRedisData5().getLines().get(0);
        dataLines.setCheckoutFlag(false);
        redisData.setAccountOwner("newLine1");


        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        AddDeviceToPrepayODBpmResponse response = mapper.readValue(responseString, AddDeviceToPrepayODBpmResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        MultiValueMap<String,String> headers = new HttpHeaders();
        headers.put("p-csrf-token", Arrays.asList("pcsrfToken"));
        headers.put("ECOMM_SESSION", Arrays.asList("eCommSession"));
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(requestString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayODMultiLine(serverHttpRequest, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }


    @Test
    public void addDeviceToPrepayODMultiLineTest_Data() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData();
        redisData.setAccountOwner("newLine1");

        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        AddDeviceToPrepayODBpmResponse response = mapper.readValue(responseString, AddDeviceToPrepayODBpmResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        MultiValueMap<String,String> headers = new HttpHeaders();
        headers.put("p-csrf-token", Arrays.asList("pcsrfToken"));
        headers.put("ECOMM_SESSION", Arrays.asList("eCommSession"));
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(requestString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayODMultiLine(serverHttpRequest, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addDeviceToPrepayODMultiLineErrorTest() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";
        PrepaidODRequestData redisData = getRedisData();
        redisData.setAccountOwner("newLine5");
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        URI url = URI.create("http://localhost/testurl");
        mockRedisData = mockRedisData.replace("}", "");
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        MultiValueMap<String,String> headers = new HttpHeaders();
        headers.put("p-csrf-token", Arrays.asList("pcsrfToken"));
        headers.put("ECOMM_SESSION", Arrays.asList("eCommSession"));
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(requestString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayODMultiLine(serverHttpRequest, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d.getBody().getErrors()));
    }

    @Test
    public void addDeviceToPrepayODMultiLineErrorTest2() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";
        PrepaidODRequestData redisData = getRedisData();
        redisData.setAccountOwner("newLine5");
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        URI url = URI.create("http://localhost/testurl");
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        MultiValueMap<String,String> headers = new HttpHeaders();
        headers.put("p-csrf-token", Arrays.asList("pcsrfToken"));
        headers.put("ECOMM_SESSION", Arrays.asList("eCommSession"));
        requestString = requestString.replace("}", "");
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(requestString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayODMultiLine(serverHttpRequest, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d.getBody().getErrors()));
    }

    @Test
    public void removeLineFromRedisTest() throws JsonProcessingException {
        PrepaidODRequestData redisData=getRedisData();
        redisData.setAccountOwner("newLine1");
        String mockRedisData = mapper.writeValueAsString(redisData);
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = ReflectionTestUtils.invokeMethod(helper,"removeLineFromRedis",redisData,getRedisData().getLines().get(0),null);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void removeLineFromRedisTest_odReqDataNull() throws JsonProcessingException {
        PrepaidODRequestData redisData=getRedisData();
        redisData.setAccountOwner("newLine1");
        String mockRedisData = mapper.writeValueAsString(redisData);
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = ReflectionTestUtils.invokeMethod(helper,"removeLineFromRedis",null,getRedisData().getLines().get(0),null);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addDeviceToPrepayODMultiLineTest_RedisEmptyData() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        URI url = URI.create("http://localhost/testurl");
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(""));
        MultiValueMap<String,String> headers = new HttpHeaders();
        headers.put("p-csrf-token", Arrays.asList("pcsrfToken"));
        headers.put("ECOMM_SESSION", Arrays.asList("eCommSession"));
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayODMultiLine(serverHttpRequest, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addDeviceToPrepayODMultiLineTest_noLines() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData2();
        redisData.setLines(Collections.emptyList());
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        AddDeviceToPrepayODBpmResponse response = mapper.readValue(responseString, AddDeviceToPrepayODBpmResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MultiValueMap<String,String> headers = new HttpHeaders();
        headers.put("p-csrf-token", Arrays.asList("pcsrfToken"));
        headers.put("ECOMM_SESSION", Arrays.asList("eCommSession"));
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(requestString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayODMultiLine(serverHttpRequest, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addDeviceToPrepayODMultiLineTest_checkoutFlagTrue() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData2();
        List<PrepaidODRequestDataLines> list=redisData.getLines();
        list.get(0).setCheckoutFlag(true);
        list.get(1).setCheckoutFlag(true);
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        AddDeviceToPrepayODBpmResponse response = mapper.readValue(responseString, AddDeviceToPrepayODBpmResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MultiValueMap<String,String> headers = new HttpHeaders();
        headers.put("p-csrf-token", Arrays.asList("pcsrfToken"));
        headers.put("ECOMM_SESSION", Arrays.asList("eCommSession"));
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(requestString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayODMultiLine(serverHttpRequest, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }


    @Test
    public void addDeviceToPrepayODMultiLineTest3() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData2();

        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        AddDeviceToPrepayODBpmResponse response = mapper.readValue(responseString, AddDeviceToPrepayODBpmResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MultiValueMap<String,String> headers = new HttpHeaders();
        headers.put("p-csrf-token", Arrays.asList("pcsrfToken"));
        headers.put("ECOMM_SESSION", Arrays.asList("eCommSession"));
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(requestString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayODMultiLine(serverHttpRequest, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addDeviceToPrepayODMultiLineTesttry() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";
        String vzwPrepayAddOrUpdateCartResponse="{\"orderId\":\"Success\",\"status\":\"200\",\"devCommerceId\":\"newLine1\"}";

        PrepaidODRequestData redisData = getRedisData2();
        redisData.getLines().get(0).getAccessorySkuIds().get(0).setSorId("123");
        redisData.getLines().get(1).getAccessorySkuIds().get(0).setSorId("123");

        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        AddDeviceToPrepayODBpmResponse response = mapper.readValue(responseString, AddDeviceToPrepayODBpmResponse.class);
        URI url = URI.create("http://localhost/testurl");
        PrepaidODAddAccessoriesResponse prepaidODAddAccessoriesResponse = new PrepaidODAddAccessoriesResponse();

        //prepaidODAddAccessoriesResponse.setErrorMap(new HashMap<String, String>());
        PrepaidODAddAccessoriesOutput prepaidODAddAccessoriesOutput = new PrepaidODAddAccessoriesOutput();
        List<PrepaidODAddAccessoriesOutput> prepaidODAddAccessoriesOutputArrayList = new ArrayList<>();
        prepaidODAddAccessoriesOutputArrayList.add(prepaidODAddAccessoriesOutput);
        prepaidODAddAccessoriesResponse.setOutput(prepaidODAddAccessoriesOutputArrayList);

        prepaidODAddAccessoriesOutput.setAccCommerceId("accCommerceId");
        prepaidODAddAccessoriesOutput.setSorId("123");
        String response1=mapper.writeValueAsString(prepaidODAddAccessoriesResponse);

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.anyString(), Mockito.any())).thenReturn(Mono.just(true));

        MultiValueMap<String,String> headers = new HttpHeaders();
        headers.put("p-csrf-token", Arrays.asList("pcsrfToken"));
        headers.put("ECOMM_SESSION", Arrays.asList("eCommSession"));
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(vzwPrepayAddOrUpdateCartResponse));
        Mono<ResponseEntity<String>> webClientResponse1 = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response1));

        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse).thenReturn(webClientResponse1);

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayODMultiLine(serverHttpRequest, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addDeviceToPrepayODMultiLineTesttry2() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine2\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";
        String vzwPrepayAddOrUpdateCartResponse="{\"orderId\":\"Success\",\"status\":\"200\",\"devCommerceId\":\"newLine1\"}";

        PrepaidODRequestData redisData = getRedisData2();
        redisData.getLines().get(0).getAccessorySkuIds().get(0).setSorId("123");
        redisData.getLines().get(1).getAccessorySkuIds().get(0).setSorId("123");

        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        AddDeviceToPrepayODBpmResponse response = mapper.readValue(responseString, AddDeviceToPrepayODBpmResponse.class);
        URI url = URI.create("http://localhost/testurl");
        PrepaidODAddAccessoriesResponse prepaidODAddAccessoriesResponse = new PrepaidODAddAccessoriesResponse();

        //prepaidODAddAccessoriesResponse.setErrorMap(new HashMap<String, String>());
        PrepaidODAddAccessoriesOutput prepaidODAddAccessoriesOutput = new PrepaidODAddAccessoriesOutput();
        List<PrepaidODAddAccessoriesOutput> prepaidODAddAccessoriesOutputArrayList = new ArrayList<>();
        prepaidODAddAccessoriesOutputArrayList.add(prepaidODAddAccessoriesOutput);
        prepaidODAddAccessoriesResponse.setOutput(prepaidODAddAccessoriesOutputArrayList);

        prepaidODAddAccessoriesOutput.setAccCommerceId("accCommerceId");
        prepaidODAddAccessoriesOutput.setSorId("123");
        String response1=mapper.writeValueAsString(prepaidODAddAccessoriesResponse);

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.anyString(), Mockito.any())).thenReturn(Mono.just(true));

        MultiValueMap<String,String> headers = new HttpHeaders();
        headers.put("p-csrf-token", Arrays.asList("pcsrfToken"));
        headers.put("ECOMM_SESSION", Arrays.asList("eCommSession"));
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(vzwPrepayAddOrUpdateCartResponse));
        Mono<ResponseEntity<String>> webClientResponse1 = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response1));

        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse).thenReturn(webClientResponse1);

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayODMultiLine(serverHttpRequest, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addDeviceToPrepayODMultiLineTest4() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData3();

        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        AddDeviceToPrepayODBpmResponse response = mapper.readValue(responseString, AddDeviceToPrepayODBpmResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MultiValueMap<String,String> headers = new HttpHeaders();
        headers.put("p-csrf-token", Arrays.asList("pcsrfToken"));
        headers.put("ECOMM_SESSION", Arrays.asList("eCommSession"));
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(requestString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayODMultiLine(serverHttpRequest, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addDeviceToPrepayODMultiLineTest5() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData4();

        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        AddDeviceToPrepayODBpmResponse response = mapper.readValue(responseString, AddDeviceToPrepayODBpmResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MultiValueMap<String,String> headers = new HttpHeaders();
        headers.put("p-csrf-token", Arrays.asList("pcsrfToken"));
        headers.put("ECOMM_SESSION", Arrays.asList("eCommSession"));
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(requestString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayODMultiLine(serverHttpRequest, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addDeviceToPrepayODMultiLineTest2() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData7();

        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddDeviceToPrepayODBpmRequest request = mapper.readValue(requestString, AddDeviceToPrepayODBpmRequest.class);
        AddDeviceToPrepayODBpmResponse response = mapper.readValue(responseString, AddDeviceToPrepayODBpmResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MultiValueMap<String,String> headers = new HttpHeaders();
        headers.put("p-csrf-token", Arrays.asList("pcsrfToken"));
        headers.put("ECOMM_SESSION", Arrays.asList("eCommSession"));
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(requestString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = helper.addDeviceToPrepayODMultiLine(serverHttpRequest, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void getCustomerInfoTest() throws IOException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {

        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";
        AddDevicePEGARequest request = mapper.readValue(requestString, AddDevicePEGARequest.class);

        PrepaidODRequestData prepaidODRequestData = null;
        Method method = PrepayAdaptorCartAddDeviceHelper.class.getDeclaredMethod("getCustomerinfo",AddDevicePEGARequest.class);
        method.setAccessible(true);

        CartServiceCustomerInfo cscInfo = (CartServiceCustomerInfo)method.invoke(helper,request);
        Assert.assertNotNull(cscInfo);
    }

    //getAddDevicePEGAResponse

    @Test
    public void getAddDevicePEGAResponseTest() throws IOException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {

        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";
        AddDevicePEGARequest request = mapper.readValue(requestString, AddDevicePEGARequest.class);

        PrepaidODRequestData prepaidODRequestData = new PrepaidODRequestData();
        Method method = PrepayAdaptorCartAddDeviceHelper.class.getDeclaredMethod("getAddDevicePEGAResponse",AddDevicePEGARequest.class,PrepaidODRequestData.class);
        method.setAccessible(true);

        AddDevicePEGAResponse response = (AddDevicePEGAResponse)method.invoke(helper,request,prepaidODRequestData);
        Assert.assertNotNull(response);
    }

    @Test
    public void getLineDataTest() throws IOException{
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false,\"device\":{\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\"}}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";
        AddDevicePEGARequest request = mapper.readValue(requestString, AddDevicePEGARequest.class);
        PrepaidODRequestDataLines lines = ReflectionTestUtils.invokeMethod(helper,"getLineData","newLine1", request);
        Assert.assertNotNull(lines);
    }
    @Test
    public void getLineDataTest2() throws IOException{
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false,\"device\":{\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\",\"category\":\"Smartphones\",\"operatingSystem\":\"android\"}}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";
        AddDevicePEGARequest request = mapper.readValue(requestString, AddDevicePEGARequest.class);
        PrepaidODRequestDataLines lines = ReflectionTestUtils.invokeMethod(helper,"getLineData","newLine1", request);
        Assert.assertNotNull(lines);
    }

    @Test
    public void getLineDataTest3() throws IOException{
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false,\"device\":{\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\",\"category\":\"Basic Phones\",\"operatingSystem\":\"android\"}}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";
        AddDevicePEGARequest request = mapper.readValue(requestString, AddDevicePEGARequest.class);
        PrepaidODRequestDataLines lines = ReflectionTestUtils.invokeMethod(helper,"getLineData","newLine1", request);
        Assert.assertNotNull(lines);
    }

    @Test
    public void getLineDataTest4() throws IOException{
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false,\"device\":{\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\",\"category\":\"SmartWatch\",\"operatingSystem\":\"android\"}}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";
        AddDevicePEGARequest request = mapper.readValue(requestString, AddDevicePEGARequest.class);
        PrepaidODRequestDataLines lines = ReflectionTestUtils.invokeMethod(helper,"getLineData","newLine1", request);
        Assert.assertNotNull(lines);
    }

    @Test
    public void getLineDataTest5() throws IOException{
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false,\"device\":{\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\",\"category\":\"Tablets\",\"operatingSystem\":\"android\"}}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";
        AddDevicePEGARequest request = mapper.readValue(requestString, AddDevicePEGARequest.class);
        PrepaidODRequestDataLines lines = ReflectionTestUtils.invokeMethod(helper,"getLineData","newLine1", request);
        Assert.assertNotNull(lines);
    }

    @Test
    public void getLineDataTest6() throws IOException{
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false,\"device\":{\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\",\"category\":\"Jetpack\",\"operatingSystem\":\"android\"}}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";
        AddDevicePEGARequest request = mapper.readValue(requestString, AddDevicePEGARequest.class);
        PrepaidODRequestDataLines lines = ReflectionTestUtils.invokeMethod(helper,"getLineData","newLine1", request);
        Assert.assertNotNull(lines);
    }

    @Test
    public void getPrepaidRemoveLineLegacyServiceRequestTest(){

        RemoveLineItemsRequest removeLineItemsRequest = new RemoveLineItemsRequest();
        PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = ReflectionTestUtils.invokeMethod(helper,"getPrepaidRemoveLineLegacyServiceRequest",removeLineItemsRequest, getRedisData());
        Assert.assertNotNull(prepaidAdaptorWebClientRequest);
    }

    @Test
    public void getMockResponseTest(){
        String path = "/file";
        Object obj = new Object();
        Object object = ReflectionTestUtils.invokeMethod(helper,"getMockResponse",path, obj);
        Assert.assertNull(object);
    }

    @Test
    public void getMockResponseSuccessTest() {
        Object obj = ReflectionTestUtils.invokeMethod(helper, "getMockResponse", "classpath:data/mockresponses/Cart/AddPlanPEGAResponse.json", Object.class);
        Assert.assertNotNull(obj);
    }

    @Test
    public void getHeaderValueNullTest(){
        String url = "/url";
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        String str = ReflectionTestUtils.invokeMethod(helper,"getHeaderValue",httpRequest, "header");
        Assert.assertNull(str);
    }

    @Test
    public void getHeaderValueTest() {
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, "/url").header(CHANNEL_ID, "VZW", "VZ-DOTCOM").build();
        String actual = ReflectionTestUtils.invokeMethod(helper,"getHeaderValue",httpRequest, CHANNEL_ID);
        Assert.assertEquals("VZW", actual);
    }

    @Test
    public void getHeaderValueEmptyTest() {
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, "/url").header(CHANNEL_ID, "", "VZ-DOTCOM").build();
        String actual = ReflectionTestUtils.invokeMethod(helper,"getHeaderValue",httpRequest, CHANNEL_ID);
        Assert.assertNull(actual);
    }

    @Test
    public void errorResponseTest(){

        Mono<ResponseEntity<AddDevicePEGAResponse>> addDeviceToPrepayOD = ReflectionTestUtils.invokeMethod(helper,"errorResponse","name","id","message","category");
        Assert.assertNotNull(addDeviceToPrepayOD);
    }

    @Test
    public void prepareAddDevicePrepayODBpmResponseWithInternalErrorTest(){

        AddDeviceToPrepayODBpmResponse addDeviceToPrepayODBpm = ReflectionTestUtils.invokeMethod(helper,"prepareAddDevicePrepayODBpmResponseWithInternalError","2345","Device out of stock","Business Error","BUSINESS_ERR");
        Assert.assertNotNull(addDeviceToPrepayODBpm);
    }

    @Test
    public void prepayAddDevicePrepayODBpmResponseTest(){

        AddDeviceToPrepayODAddDeviceResponse addDeviceToPrepayODAddDeviceResponse = new AddDeviceToPrepayODAddDeviceResponse();
        AddDeviceToPrepayODAddAccessoriesResponse addDeviceToPrepayODAddAccessoriesResponse = new AddDeviceToPrepayODAddAccessoriesResponse();
        AddDeviceToPrepayODBpmResponse addDeviceToPrepayODBpm = ReflectionTestUtils.invokeMethod(helper,"prepayAddDevicePrepayODBpmResponse",addDeviceToPrepayODAddDeviceResponse,addDeviceToPrepayODAddAccessoriesResponse);
        Assert.assertNotNull(addDeviceToPrepayODBpm);
    }


    @Test
    public void getLineDeviceAndAccessoryMonoTest(){
        // String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"200\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String vzwPrepayAddOrUpdateCartResponse="{\"orderId\":\"Success\",\"status\":\"200\"}";
        PrepaidODRequestDataLines line = getRedisData().getLines().get(0);
        AddDeviceToPrepayODBpmRequest addDeviceToPrepayODBpmRequest = new AddDeviceToPrepayODBpmRequest();
        addDeviceToPrepayODBpmRequest.setServiceBody(new AddDeviceToPrepayODServiceBody());
        addDeviceToPrepayODBpmRequest.getServiceBody().setServiceRequest(new AddDeviceToPrepayODServiceRequest());
        addDeviceToPrepayODBpmRequest.getServiceBody().getServiceRequest().setContext(new AddDeviceToPrepayODContext());
        //addDeviceToPrepayODBpmRequest.getServiceBody().getServiceRequest().getContext().setFlow();
        URI url = URI.create("http://localhost/testurl");
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(vzwPrepayAddOrUpdateCartResponse));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.anyString(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = ReflectionTestUtils.invokeMethod(helper,"getLineDeviceAndAccessoryMono",line,addDeviceToPrepayODBpmRequest,getRedisData(),serverHttpRequest);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));
    }

    @Test
    public void getLineDeviceAndAccessoryMonoTest2(){
        // String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"200\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        String vzwPrepayAddOrUpdateCartResponse="{\"orderId\":\"Success\",\"status\":\"200\"}";
        PrepaidODRequestDataLines line = getRedisData6().getLines().get(0);
        AddDeviceToPrepayODBpmRequest addDeviceToPrepayODBpmRequest = new AddDeviceToPrepayODBpmRequest();
        addDeviceToPrepayODBpmRequest.setServiceBody(new AddDeviceToPrepayODServiceBody());
        addDeviceToPrepayODBpmRequest.getServiceBody().setServiceRequest(new AddDeviceToPrepayODServiceRequest());
        addDeviceToPrepayODBpmRequest.getServiceBody().getServiceRequest().setContext(new AddDeviceToPrepayODContext());
        //addDeviceToPrepayODBpmRequest.getServiceBody().getServiceRequest().getContext().setFlow();
        URI url = URI.create("http://localhost/testurl");
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(vzwPrepayAddOrUpdateCartResponse));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.anyString(), Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = ReflectionTestUtils.invokeMethod(helper,"getLineDeviceAndAccessoryMono",line,addDeviceToPrepayODBpmRequest,getRedisData6(),serverHttpRequest);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));
    }

    @Test
    public void getLineDeviceAndAccessoryMonoTest_status500(){
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";

        PrepaidODRequestDataLines line = getRedisData().getLines().get(0);
        AddDeviceToPrepayODBpmRequest addDeviceToPrepayODBpmRequest = new AddDeviceToPrepayODBpmRequest();
        addDeviceToPrepayODBpmRequest.setServiceBody(new AddDeviceToPrepayODServiceBody());
        addDeviceToPrepayODBpmRequest.getServiceBody().setServiceRequest(new AddDeviceToPrepayODServiceRequest());
        addDeviceToPrepayODBpmRequest.getServiceBody().getServiceRequest().setContext(new AddDeviceToPrepayODContext());
        URI url = URI.create("http://localhost/testurl");
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(requestString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.anyString(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = ReflectionTestUtils.invokeMethod(helper,"getLineDeviceAndAccessoryMono",line,addDeviceToPrepayODBpmRequest,getRedisData(),serverHttpRequest);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));
    }

    @Test
    public void getPrepayodAddDeviceRequestTest()
    {
        AddDeviceToPrepayODBpmRequest addDeviceToPrepayODBpmRequest = new AddDeviceToPrepayODBpmRequest();
        addDeviceToPrepayODBpmRequest.setServiceBody(new AddDeviceToPrepayODServiceBody());
        addDeviceToPrepayODBpmRequest.getServiceBody().setServiceRequest(new AddDeviceToPrepayODServiceRequest());
        addDeviceToPrepayODBpmRequest.getServiceBody().getServiceRequest().setContext(new AddDeviceToPrepayODContext());
        PrepaidODRequestDataLines requestDataLines=new PrepaidODRequestDataLines();
        requestDataLines.setLineItemId("abcd");
        requestDataLines.setDeviceId("45678");
        requestDataLines.setDeviceSkuId("787879");
        requestDataLines.setSmartPhone(true);
        List<String> featureSkuIds= new ArrayList<String>();
        featureSkuIds.add("xxx");
        requestDataLines.setFeatureSkuIds(featureSkuIds);
        PrepaidODAddDeviceRequest prepaidODRequest = ReflectionTestUtils.invokeMethod(helper,"getPrepayODAddDeviceRequest",requestDataLines, addDeviceToPrepayODBpmRequest);
        Assert.assertNotNull(prepaidODRequest);
    }

    @Test
    public void getPrepayodAddDeviceRequestTest_Smartwatch()
    {
        AddDeviceToPrepayODBpmRequest addDeviceToPrepayODBpmRequest = new AddDeviceToPrepayODBpmRequest();
        addDeviceToPrepayODBpmRequest.setServiceBody(new AddDeviceToPrepayODServiceBody());
        addDeviceToPrepayODBpmRequest.getServiceBody().setServiceRequest(new AddDeviceToPrepayODServiceRequest());
        addDeviceToPrepayODBpmRequest.getServiceBody().getServiceRequest().setContext(new AddDeviceToPrepayODContext());
        PrepaidODRequestDataLines requestDataLines=new PrepaidODRequestDataLines();
        requestDataLines.setLineItemId("abcd");
        requestDataLines.setDeviceId("45678");
        requestDataLines.setDeviceSkuId("787879");
        requestDataLines.setSmartWatch(true);
        List<String> featureSkuIds= new ArrayList<String>();
        featureSkuIds.add("xxx");
        requestDataLines.setFeatureSkuIds(featureSkuIds);
        PrepaidODAddDeviceRequest prepaidODRequest = ReflectionTestUtils.invokeMethod(helper,"getPrepayODAddDeviceRequest",requestDataLines, addDeviceToPrepayODBpmRequest);
        Assert.assertNotNull(prepaidODRequest);
    }

    @Test
    public void getPrepayodAddDeviceRequestTest_SmartwatchWithPlan()
    {
        AddDeviceToPrepayODBpmRequest addDeviceToPrepayODBpmRequest = new AddDeviceToPrepayODBpmRequest();
        addDeviceToPrepayODBpmRequest.setServiceBody(new AddDeviceToPrepayODServiceBody());
        addDeviceToPrepayODBpmRequest.getServiceBody().setServiceRequest(new AddDeviceToPrepayODServiceRequest());
        addDeviceToPrepayODBpmRequest.getServiceBody().getServiceRequest().setContext(new AddDeviceToPrepayODContext());
        PrepaidODRequestDataLines requestDataLines=new PrepaidODRequestDataLines();
        requestDataLines.setLineItemId("abcd");
        requestDataLines.setDeviceId("45678");
        requestDataLines.setDeviceSkuId("787879");
        requestDataLines.setPlanSkuId("sku70778");
        requestDataLines.setSmartWatch(true);
        List<String> featureSkuIds= new ArrayList<String>();
        featureSkuIds.add("xxx");
        requestDataLines.setFeatureSkuIds(featureSkuIds);
        PrepaidODAddDeviceRequest prepaidODRequest = ReflectionTestUtils.invokeMethod(helper,"getPrepayODAddDeviceRequest",requestDataLines, addDeviceToPrepayODBpmRequest);
        Assert.assertNotNull(prepaidODRequest);
    }


    @Test
    public void getPrepayodAddDeviceRequestTestNSP()
    {
        AddDeviceToPrepayODBpmRequest addDeviceToPrepayODBpmRequest = new AddDeviceToPrepayODBpmRequest();
        addDeviceToPrepayODBpmRequest.setServiceBody(new AddDeviceToPrepayODServiceBody());
        addDeviceToPrepayODBpmRequest.getServiceBody().setServiceRequest(new AddDeviceToPrepayODServiceRequest());
        addDeviceToPrepayODBpmRequest.getServiceBody().getServiceRequest().setContext(new AddDeviceToPrepayODContext());
        PrepaidODRequestDataLines requestDataLines=new PrepaidODRequestDataLines();
        requestDataLines.setLineItemId("abcd");
        requestDataLines.setDeviceId("45678");
        requestDataLines.setDeviceSkuId("787879");
        requestDataLines.setPlanSkuId("6476535");
        requestDataLines.setDataDevice(true);
        requestDataLines.setFlow("NSP");
        List<String> featureSkuIds= new ArrayList<String>();
        featureSkuIds.add("xxx");
        requestDataLines.setFeatureSkuIds(featureSkuIds);
        PrepaidODAddDeviceRequest prepaidODRequest = ReflectionTestUtils.invokeMethod(helper,"getPrepayODAddDeviceRequest",requestDataLines, addDeviceToPrepayODBpmRequest);
        Assert.assertNotNull(prepaidODRequest);
    }

    @Test
    public void getPrepayodAddDeviceRequestTestNSE()
    {
        AddDeviceToPrepayODBpmRequest addDeviceToPrepayODBpmRequest = new AddDeviceToPrepayODBpmRequest();
        addDeviceToPrepayODBpmRequest.setServiceBody(new AddDeviceToPrepayODServiceBody());
        addDeviceToPrepayODBpmRequest.getServiceBody().setServiceRequest(new AddDeviceToPrepayODServiceRequest());
        addDeviceToPrepayODBpmRequest.getServiceBody().getServiceRequest().setContext(new AddDeviceToPrepayODContext());
        PrepaidODRequestDataLines requestDataLines=new PrepaidODRequestDataLines();
        requestDataLines.setLineItemId("abcd");
        requestDataLines.setDeviceId("45678");
        requestDataLines.setBasicPhone(true);
        requestDataLines.setPlanSkuId("6476535");
        requestDataLines.setDeviceSkuId("787879");
        requestDataLines.setFlow("NSE");
        List<String> featureSkuIds= new ArrayList<String>();
        featureSkuIds.add("xxx");
        requestDataLines.setFeatureSkuIds(featureSkuIds);
        PrepaidODAddDeviceRequest prepaidODRequest = ReflectionTestUtils.invokeMethod(helper,"getPrepayODAddDeviceRequest",requestDataLines, addDeviceToPrepayODBpmRequest);
        Assert.assertNotNull(prepaidODRequest);
    }

    @Test
    public void getPrepayodAddDeviceRequestTestNSEBYOD()
    {
        AddDeviceToPrepayODBpmRequest addDeviceToPrepayODBpmRequest = new AddDeviceToPrepayODBpmRequest();
        addDeviceToPrepayODBpmRequest.setServiceBody(new AddDeviceToPrepayODServiceBody());
        addDeviceToPrepayODBpmRequest.getServiceBody().setServiceRequest(new AddDeviceToPrepayODServiceRequest());
        addDeviceToPrepayODBpmRequest.getServiceBody().getServiceRequest().setContext(new AddDeviceToPrepayODContext());
        PrepaidODRequestDataLines requestDataLines=new PrepaidODRequestDataLines();
        requestDataLines.setLineItemId("abcd");
        requestDataLines.setDeviceId("45678");
        requestDataLines.setDeviceSkuId("787879");
        requestDataLines.setPlanSkuId("6476535");
        requestDataLines.setFlow("NSEBYOD");
        List<String> featureSkuIds= new ArrayList<String>();
        featureSkuIds.add("xxx");
        requestDataLines.setFeatureSkuIds(featureSkuIds);
        PrepaidODAddDeviceRequest prepaidODRequest = ReflectionTestUtils.invokeMethod(helper,"getPrepayODAddDeviceRequest",requestDataLines, addDeviceToPrepayODBpmRequest);
        Assert.assertNotNull(prepaidODRequest);
    }


    @Test
    public void getPrepayodAddDeviceRequestPASOTest()
    {
        AddDeviceToPrepayODBpmRequest addDeviceToPrepayODBpmRequest = new AddDeviceToPrepayODBpmRequest();
        addDeviceToPrepayODBpmRequest.setServiceBody(new AddDeviceToPrepayODServiceBody());
        addDeviceToPrepayODBpmRequest.getServiceBody().setServiceRequest(new AddDeviceToPrepayODServiceRequest());
        addDeviceToPrepayODBpmRequest.getServiceBody().getServiceRequest().setContext(new AddDeviceToPrepayODContext());
        PrepaidODRequestDataLines requestDataLines=new PrepaidODRequestDataLines();
        requestDataLines.setLineItemId("abcd");
        requestDataLines.setDeviceId("45678");
        requestDataLines.setDeviceSkuId("787879");
        List<String> featureSkuIds= new ArrayList<String>();
        featureSkuIds.add("xxx");
        requestDataLines.setFeatureSkuIds(featureSkuIds);
        requestDataLines.setFlow("ESO");
        PrepaidODAddDeviceRequest prepaidODRequest = ReflectionTestUtils.invokeMethod(helper,"getPrepayODAddDeviceRequest",requestDataLines, addDeviceToPrepayODBpmRequest);
        Assert.assertNotNull(prepaidODRequest);



    }
    @Test
    public void getCOntextInfoTest() throws JsonProcessingException {
        String requestString="{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"}";
        CartServiceContextInfo contextInfo= mapper.readValue(requestString,CartServiceContextInfo.class);
        CartServiceContextInfo contextInfo2 = ReflectionTestUtils.invokeMethod(helper,"getContextInfo",contextInfo,true);
        Assert.assertNotNull(contextInfo2);
    }
    @Test
    public void getCOntextInfoTest2() throws JsonProcessingException {
        String requestString="{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"}";
        CartServiceContextInfo contextInfo= mapper.readValue(requestString,CartServiceContextInfo.class);
        CartServiceContextInfo contextInfo2 = ReflectionTestUtils.invokeMethod(helper,"getContextInfo",contextInfo,false);
        Assert.assertNotNull(contextInfo2);
    }
    @Test
    public void getProcessMtnListTest() throws JsonProcessingException {
        String requestString="{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"}";
        CartServiceContextInfo contextInfo= mapper.readValue(requestString,CartServiceContextInfo.class);
        PrepaidODRequestData requestData= getRedisData();
        ProcessMTNList[] listData=ReflectionTestUtils.invokeMethod(helper,"getProcessMTNList",contextInfo,requestData);
        Assert.assertNotNull(listData);
    }
    @Test
    public void getResponseContextTest() throws JsonProcessingException {
        String requestString = "{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"processMTNList\":[{\"processMTNList\":{\"mtn\":\"mtn\",\"completedprocessSteps\":[\"ONECLICKCHECKOUT\"]}}]}";
        AddDeviceContext context=mapper.readValue(requestString,AddDeviceContext.class);
        PrepaidODRequestData requestData=getRedisData();
        AddDeviceContext context2=ReflectionTestUtils.invokeMethod(helper,"getResponseContext",context,requestData);
        Assert.assertNotNull(context2);
    }

    @Test
    public void prepayAddDevicePrepayODBpmResponseTestNegative() {
        AddDeviceToPrepayODBpmResponse odBPMResponse=ReflectionTestUtils.invokeMethod(helper,"prepayAddDevicePrepayODBpmResponse",null,null);
        Assert.assertNotNull(odBPMResponse);
    }
    @Test
    public void prepareAddDevicePrepayODBpmErrorResponseTest() {
        AddDeviceToPrepayODBpmResponse odBpmResponse2=ReflectionTestUtils.invokeMethod(helper,"prepareAddDevicePrepayODBpmErrorResponse");
        Assert.assertNotNull(odBpmResponse2);
    }
    @Test
    public void prepareErrorToAddDevicePrepayODResponseTest() {
        AddDeviceToPrepayODAddDeviceResponse response=ReflectionTestUtils.invokeMethod(helper,"prepareErrorToAddDevicePrepayODResponse");
        Assert.assertNotNull(response);
    }

    @Test
    public void prepareAddDevicePrepayODBpmResponseWithErrorTest() throws JsonProcessingException {
        String requestString="{\n" +
                "\t\"orderUpdated\": false,\n" +
                "\t\"success\": false,\n" +
                "\t\"errors\": {\n" +
                "\t\t\"status\": 400,\n" +
                "\t\t\"ecommApiErrorList\": [\n" +
                "\t\t\t{\n" +
                "\t\t\t\t\"statusCode\": \"01\",\n" +
                "\t\t\t\t\"message\": \"Internal Server Error\",\n" +
                "\t\t\t\t\"developerMessage\": \"Internal Server Error\"\n" +
                "\t\t\t}\n" +
                "\t\t]\n" +
                "\t},\n" +
                "\t\"status\": 400,\n" +
                "\t\"totalLines\": 0,\n" +
                "\t\"cartCount\": 0,\n" +
                "\t\"is5gTo4gTransition\": false\n" +
                "}";
        VZWPrepayAddOrUpdateCartResponse addDevicePrepayODResponse= mapper.readValue(requestString,VZWPrepayAddOrUpdateCartResponse.class);
        AddDeviceToPrepayODBpmResponse odBPMResponse=ReflectionTestUtils.invokeMethod(helper,"prepareAddDevicePrepayODBpmResponseWithError",addDevicePrepayODResponse);
        Assert.assertNotNull(odBPMResponse);
    }
    @Test
    public void prepareAddDevicePrepayODBpmResponseWithError2Test() throws JsonProcessingException {
        String requestString="{\n" +
                "\t\"orderUpdated\": false,\n" +
                "\t\"success\": false,\n" +
                "\t\"errors\": {\n" +
                "\t\t\"status\": 400,\n" +
                "\t\t\"ecommApiErrorList\": [\n" +
                "\t\t\t{\n" +
                "\t\t\t\t\"statusCode\": \"01\",\n" +
                "\t\t\t\t\"message\": \"Internal Server Error\",\n" +
                "\t\t\t\t\"developerMessage\": \"Internal Server Error\"\n" +
                "\t\t\t}\n" +
                "\t\t]\n" +
                "\t},\n" +
                "\t\"status\": 400,\n" +
                "\t\"totalLines\": 0,\n" +
                "\t\"cartCount\": 0,\n" +
                "\t\"is5gTo4gTransition\": false\n" +
                "}";
        VZWPrepayAddOrUpdateCartResponse addDevicePrepayODResponse= mapper.readValue(requestString,VZWPrepayAddOrUpdateCartResponse.class);
        AddDeviceToPrepayODBpmResponse odBPMResponse=ReflectionTestUtils.invokeMethod(helper,"prepareAddDevicePrepayODBpmResponseWithError2",addDevicePrepayODResponse);
        Assert.assertNotNull(odBPMResponse);
    }
    @Test
    public void prepareAddDevicePrepayODBpmResponseWithErrorTest3() throws JsonProcessingException {
        String requestString="{\n" +
                "\t\"orderUpdated\": false,\n" +
                "\t\"success\": false,\n" +
                "\t\"errors\": {\n" +
                "\t\t\"status\": 400,\n" +
                "\t\t\"ecommApiErrorList\": [\n" +
                "\t\t\t{\n" +
                "\t\t\t\t\"statusCode\": \"01\",\n" +
                "\t\t\t\t\"message\": \"Internal Server Error\",\n" +
                "\t\t\t\t\"developerMessage\": \"Internal Server Error\"\n" +
                "\t\t\t}\n" +
                "\t\t]\n" +
                "\t},\n" +
                "\t\"status\": 400,\n" +
                "\t\"totalLines\": 0,\n" +
                "\t\"cartCount\": 0,\n" +
                "\t\"is5gTo4gTransition\": false\n" +
                "}";
        VZWPrepayAddOrUpdateCartResponse addDevicePrepayODResponse= mapper.readValue(requestString,VZWPrepayAddOrUpdateCartResponse.class);
        addDevicePrepayODResponse.getErrors().setEcommApiErrorList(null);
        AddDeviceToPrepayODBpmResponse odBPMResponse=ReflectionTestUtils.invokeMethod(helper,"prepareAddDevicePrepayODBpmResponseWithError", addDevicePrepayODResponse);
        Assert.assertNotNull(odBPMResponse);
    }
    @Test
    public void addDevicePrepayResponseTest5() throws JsonProcessingException {
        PrepaidODRequestData redisData=getRedisData();
        ReflectionTestUtils.setField(helper, "prepaidAccountOwnerSelectionFlag", false);
        AddDeviceToPrepayODAddDeviceResponse addDeviceToPrepayODAddDeviceResponse = new AddDeviceToPrepayODAddDeviceResponse();
        List<AddDeviceToPrepayODBpmResponse> addDeviceList= new ArrayList<AddDeviceToPrepayODBpmResponse>();
        List<AddDeviceToPrepayODAddAccessoriesOutput> addAccessoriesOutputs= new ArrayList<AddDeviceToPrepayODAddAccessoriesOutput>();
        AddDeviceToPrepayODAddAccessoriesOutput accessoriesOutput=new AddDeviceToPrepayODAddAccessoriesOutput();
        accessoriesOutput.setItemAdded(true);
        accessoriesOutput.setAccCommerceId("12345678");
        accessoriesOutput.setItemAdded(true);
        addAccessoriesOutputs.add(accessoriesOutput);
        AddDeviceToPrepayODBpmResponse response= new AddDeviceToPrepayODBpmResponse();

        AddDeviceToPrepayODServiceBody finalServiceBody= new AddDeviceToPrepayODServiceBody();
        String requestString = "{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"processMTNList\":[{\"processMTNList\":{\"mtn\":\"mtn\",\"completedprocessSteps\":[\"ONECLICKCHECKOUT\"]}}]}";
        AddDeviceContext context=mapper.readValue(requestString,AddDeviceContext.class);
        String requestString2="{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"}";
        CartServiceContextInfo contextInfo= mapper.readValue(requestString,CartServiceContextInfo.class);
        AddDeviceToPrepayODServiceResponse finalServiceResponse= new AddDeviceToPrepayODServiceResponse();
        AddDeviceToPrepayODAddAccessoriesResponse accessoriesResponse= new AddDeviceToPrepayODAddAccessoriesResponse();
        boolean isSuccess=true;
        ReflectionTestUtils.invokeMethod(helper,"populateAddDevicePrepayResponse",redisData,addDeviceList,addAccessoriesOutputs,response,finalServiceBody,context,contextInfo,finalServiceResponse,accessoriesResponse,isSuccess);
        Assert.assertNotNull(contextInfo);

    }
    @Test
    public void addDevicePrepayResponseTest3() throws JsonProcessingException {
        PrepaidODRequestData redisData=getRedisData();
        ReflectionTestUtils.setField(helper, "prepaidAccountOwnerSelectionFlag", true);
        AddDeviceToPrepayODAddDeviceResponse addDeviceToPrepayODAddDeviceResponse = new AddDeviceToPrepayODAddDeviceResponse();
        List<AddDeviceToPrepayODBpmResponse> addDeviceList= new ArrayList<AddDeviceToPrepayODBpmResponse>();
        List<AddDeviceToPrepayODAddAccessoriesOutput> addAccessoriesOutputs= new ArrayList<AddDeviceToPrepayODAddAccessoriesOutput>();
        AddDeviceToPrepayODAddAccessoriesOutput accessoriesOutput=new AddDeviceToPrepayODAddAccessoriesOutput();
        accessoriesOutput.setItemAdded(true);
        accessoriesOutput.setAccCommerceId("12345678");
        accessoriesOutput.setItemAdded(true);
        addAccessoriesOutputs.add(accessoriesOutput);
        AddDeviceToPrepayODBpmResponse response= new AddDeviceToPrepayODBpmResponse();

        AddDeviceToPrepayODServiceBody finalServiceBody= new AddDeviceToPrepayODServiceBody();
        String requestString = "{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"processMTNList\":[{\"processMTNList\":{\"mtn\":\"mtn\",\"completedprocessSteps\":[\"ONECLICKCHECKOUT\"]}}]}";
        AddDeviceContext context=mapper.readValue(requestString,AddDeviceContext.class);
        String requestString2="{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"}";
        CartServiceContextInfo contextInfo= mapper.readValue(requestString,CartServiceContextInfo.class);
        AddDeviceToPrepayODServiceResponse finalServiceResponse= new AddDeviceToPrepayODServiceResponse();
        AddDeviceToPrepayODAddAccessoriesResponse accessoriesResponse= new AddDeviceToPrepayODAddAccessoriesResponse();
        boolean isSuccess=true;
        ReflectionTestUtils.invokeMethod(helper,"populateAddDevicePrepayResponse",redisData,addDeviceList,addAccessoriesOutputs,response,finalServiceBody,context,contextInfo,finalServiceResponse,accessoriesResponse,isSuccess);
        Assert.assertNotNull(contextInfo);
    }
    public void addDevicePrepayResponseTest6() throws JsonProcessingException {
        PrepaidODRequestData redisData=getRedisData5();
        ReflectionTestUtils.setField(helper, "prepaidAccountOwnerSelectionFlag", false);
        AddDeviceToPrepayODAddDeviceResponse addDeviceToPrepayODAddDeviceResponse = new AddDeviceToPrepayODAddDeviceResponse();
        List<AddDeviceToPrepayODBpmResponse> addDeviceList= new ArrayList<AddDeviceToPrepayODBpmResponse>();
        List<AddDeviceToPrepayODAddAccessoriesOutput> addAccessoriesOutputs= new ArrayList<AddDeviceToPrepayODAddAccessoriesOutput>();
        AddDeviceToPrepayODAddAccessoriesOutput accessoriesOutput=new AddDeviceToPrepayODAddAccessoriesOutput();
        accessoriesOutput.setItemAdded(true);
        accessoriesOutput.setAccCommerceId("12345678");
        accessoriesOutput.setItemAdded(true);
        addAccessoriesOutputs.add(accessoriesOutput);
        AddDeviceToPrepayODBpmResponse response= new AddDeviceToPrepayODBpmResponse();

        AddDeviceToPrepayODServiceBody finalServiceBody= new AddDeviceToPrepayODServiceBody();
        String requestString = "{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"processMTNList\":[{\"processMTNList\":{\"mtn\":\"mtn\",\"completedprocessSteps\":[\"ONECLICKCHECKOUT\"]}}]}";
        AddDeviceContext context=mapper.readValue(requestString,AddDeviceContext.class);
        String requestString2="{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"}";
        CartServiceContextInfo contextInfo= mapper.readValue(requestString,CartServiceContextInfo.class);
        AddDeviceToPrepayODServiceResponse finalServiceResponse= new AddDeviceToPrepayODServiceResponse();
        AddDeviceToPrepayODAddAccessoriesResponse accessoriesResponse= new AddDeviceToPrepayODAddAccessoriesResponse();
        boolean isSuccess=true;
        ReflectionTestUtils.invokeMethod(helper,"populateAddDevicePrepayResponse",redisData,addDeviceList,addAccessoriesOutputs,response,finalServiceBody,context,contextInfo,finalServiceResponse,accessoriesResponse,isSuccess);
        Assert.assertNotNull(contextInfo);
    }


    @Test
    public void addDevicePrepayResponseTest2() throws JsonProcessingException {
        PrepaidODRequestData redisData=getRedisData5();
        redisData.setLoggedIn(true);
        AddDeviceToPrepayODAddDeviceResponse addDeviceToPrepayODAddDeviceResponse = new AddDeviceToPrepayODAddDeviceResponse();
        List<AddDeviceToPrepayODBpmResponse> addDeviceList= new ArrayList<AddDeviceToPrepayODBpmResponse>();
        List<AddDeviceToPrepayODAddAccessoriesOutput> addAccessoriesOutputs= new ArrayList<AddDeviceToPrepayODAddAccessoriesOutput>();
        AddDeviceToPrepayODBpmResponse response= new AddDeviceToPrepayODBpmResponse();
        AddDeviceToPrepayODServiceBody finalServiceBody= new AddDeviceToPrepayODServiceBody();
        String requestString = "{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"processMTNList\":[{\"processMTNList\":{\"mtn\":\"mtn\",\"completedprocessSteps\":[\"ONECLICKCHECKOUT\"]}}]}";
        AddDeviceContext context=mapper.readValue(requestString,AddDeviceContext.class);
        String requestString2="{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"}";
        CartServiceContextInfo contextInfo= mapper.readValue(requestString,CartServiceContextInfo.class);
        AddDeviceToPrepayODServiceResponse finalServiceResponse= new AddDeviceToPrepayODServiceResponse();
        AddDeviceToPrepayODAddAccessoriesResponse accessoriesResponse= new AddDeviceToPrepayODAddAccessoriesResponse();
        boolean isSuccess=true;
        ReflectionTestUtils.invokeMethod(helper,"populateAddDevicePrepayResponse",redisData,addDeviceList,addAccessoriesOutputs,response,finalServiceBody,context,contextInfo,finalServiceResponse,accessoriesResponse,isSuccess);
        Assert.assertNotNull(contextInfo);
    }

    @Test
    public void addDevicePrepayResponseTest4() throws JsonProcessingException {
        PrepaidODRequestData redisData=getRedisData5();
        AddDeviceToPrepayODAddDeviceResponse addDeviceToPrepayODAddDeviceResponse = new AddDeviceToPrepayODAddDeviceResponse();
        List<AddDeviceToPrepayODBpmResponse> addDeviceList= new ArrayList<AddDeviceToPrepayODBpmResponse>();
        List<AddDeviceToPrepayODAddAccessoriesOutput> addAccessoriesOutputs= new ArrayList<AddDeviceToPrepayODAddAccessoriesOutput>();
        AddDeviceToPrepayODBpmResponse response= new AddDeviceToPrepayODBpmResponse();
        AddDeviceToPrepayODServiceBody finalServiceBody= new AddDeviceToPrepayODServiceBody();

        String requestString = "{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"processMTNList\":[{\"processMTNList\":{\"mtn\":\"mtn\",\"completedprocessSteps\":[\"ONECLICKCHECKOUT\"]}}]}";
        AddDeviceContext context=mapper.readValue(requestString,AddDeviceContext.class);
        String requestString2="{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"}";
        CartServiceContextInfo contextInfo= mapper.readValue(requestString,CartServiceContextInfo.class);
        AddDeviceToPrepayODServiceResponse finalServiceResponse= new AddDeviceToPrepayODServiceResponse();
        AddDeviceToPrepayODAddAccessoriesResponse accessoriesResponse= new AddDeviceToPrepayODAddAccessoriesResponse();
        boolean isSuccess=true;
        ReflectionTestUtils.invokeMethod(helper,"populateAddDevicePrepayResponse",redisData,addDeviceList,addAccessoriesOutputs,response,finalServiceBody,context,contextInfo,finalServiceResponse,accessoriesResponse,isSuccess);
        Assert.assertNotNull(contextInfo);
    }


    @Test
    public void addDevicePrepayResponseTest7() throws JsonProcessingException {
        PrepaidODRequestData redisData=getRedisData5();
        ReflectionTestUtils.setField(helper, "prepaidAccountOwnerSelectionFlag", true);
        AddDeviceToPrepayODAddDeviceResponse addDeviceToPrepayODAddDeviceResponse = new AddDeviceToPrepayODAddDeviceResponse();
        List<AddDeviceToPrepayODBpmResponse> addDeviceList= new ArrayList<AddDeviceToPrepayODBpmResponse>();
        List<AddDeviceToPrepayODAddAccessoriesOutput> addAccessoriesOutputs= new ArrayList<AddDeviceToPrepayODAddAccessoriesOutput>();
        AddDeviceToPrepayODBpmResponse response= new AddDeviceToPrepayODBpmResponse();
        AddDeviceToPrepayODServiceBody finalServiceBody= new AddDeviceToPrepayODServiceBody();

        String requestString = "{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"processMTNList\":[{\"processMTNList\":{\"mtn\":\"mtn\",\"completedprocessSteps\":[\"ONECLICKCHECKOUT\"]}}]}";
        AddDeviceContext context=mapper.readValue(requestString,AddDeviceContext.class);
        String requestString2="{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"}";
        CartServiceContextInfo contextInfo= mapper.readValue(requestString,CartServiceContextInfo.class);
        AddDeviceToPrepayODServiceResponse finalServiceResponse= new AddDeviceToPrepayODServiceResponse();
        AddDeviceToPrepayODAddAccessoriesResponse accessoriesResponse= new AddDeviceToPrepayODAddAccessoriesResponse();
        boolean isSuccess=false;
        ReflectionTestUtils.invokeMethod(helper,"populateAddDevicePrepayResponse",redisData,addDeviceList,addAccessoriesOutputs,response,finalServiceBody,context,contextInfo,finalServiceResponse,accessoriesResponse,isSuccess);
        Assert.assertNotNull(contextInfo);
    }

    @Test
    public void processAccessoriesTest() throws JsonProcessingException {
        String vzwPrepayAddOrUpdateCartResponse="{\"orderId\":\"Success\",\"status\":\"200\"}";
        VZWPrepayAddOrUpdateCartResponse addDevicePrepayODResponse= mapper.readValue(vzwPrepayAddOrUpdateCartResponse,VZWPrepayAddOrUpdateCartResponse.class);
        PrepaidODRequestDataLines line = getRedisData().getLines().get(0);
        PrepaidODRequestDataAccessorySkuIds prepaidODRequestDataAccessorySkuIds=new PrepaidODRequestDataAccessorySkuIds();
        prepaidODRequestDataAccessorySkuIds.setSorId("sorId");
        prepaidODRequestDataAccessorySkuIds.setAccessoryCommerceId("data");
        line.getAccessorySkuIds().set(0,prepaidODRequestDataAccessorySkuIds);
        PrepaidODRequestData redisData=new PrepaidODRequestData();
        List<PrepaidODRequestDataLines> list=new ArrayList<>();
        list.add(line);
        redisData.setLines(list);
        PrepaidODAddAccessoriesResponse prepaidODAddAccessoriesResponse = new PrepaidODAddAccessoriesResponse();
        PrepaidODAddAccessoriesOutput prepaidODAddAccessoriesOutput = new PrepaidODAddAccessoriesOutput();
        List<PrepaidODAddAccessoriesOutput> prepaidODAddAccessoriesOutputArrayList = new ArrayList<>();
        prepaidODAddAccessoriesOutput.setSorId("sorId");
        prepaidODAddAccessoriesOutput.setOrderId("orderId");
        prepaidODAddAccessoriesOutputArrayList.add(prepaidODAddAccessoriesOutput);
        prepaidODAddAccessoriesResponse.setOutput(prepaidODAddAccessoriesOutputArrayList);
        String webClientResponseString = mapper.writeValueAsString(prepaidODAddAccessoriesResponse);
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(webClientResponseString));

        URI url = URI.create("http://localhost/testurl");
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.anyString(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = ReflectionTestUtils.invokeMethod(helper,"processAccessories",line,redisData,serverHttpRequest,addDevicePrepayODResponse,"data");
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));
    }

    @Test
    public void processAccessoriesErrorTest() throws JsonProcessingException {
        String vzwPrepayAddOrUpdateCartResponse="{\"orderId\":\"Success\",\"status\":\"200\"}";
        VZWPrepayAddOrUpdateCartResponse addDevicePrepayODResponse= mapper.readValue(vzwPrepayAddOrUpdateCartResponse,VZWPrepayAddOrUpdateCartResponse.class);
        PrepaidODRequestDataLines line = getRedisData().getLines().get(0);
        PrepaidODRequestDataAccessorySkuIds prepaidODRequestDataAccessorySkuIds=new PrepaidODRequestDataAccessorySkuIds();
        prepaidODRequestDataAccessorySkuIds.setSorId("sorId");
        prepaidODRequestDataAccessorySkuIds.setAccessoryCommerceId("data");
        line.getAccessorySkuIds().set(0,prepaidODRequestDataAccessorySkuIds);
        PrepaidODRequestData redisData=new PrepaidODRequestData();
        List<PrepaidODRequestDataLines> list=new ArrayList<>();
        list.add(line);
        redisData.setLines(list);
        PrepaidODAddAccessoriesResponse prepaidODAddAccessoriesResponse = new PrepaidODAddAccessoriesResponse();
        PrepaidODAddAccessoriesOutput prepaidODAddAccessoriesOutput = new PrepaidODAddAccessoriesOutput();
        List<PrepaidODAddAccessoriesOutput> prepaidODAddAccessoriesOutputArrayList = new ArrayList<>();
        prepaidODAddAccessoriesOutput.setSorId("sorId");
        prepaidODAddAccessoriesOutput.setOrderId("orderId");
        prepaidODAddAccessoriesOutputArrayList.add(prepaidODAddAccessoriesOutput);
        prepaidODAddAccessoriesResponse.setOutput(prepaidODAddAccessoriesOutputArrayList);
        String webClientResponseString = mapper.writeValueAsString(prepaidODAddAccessoriesResponse);
        webClientResponseString = webClientResponseString.replace("}", "");
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(webClientResponseString));

        URI url = URI.create("http://localhost/testurl");
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.anyString(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = ReflectionTestUtils.invokeMethod(helper,"processAccessories",line,redisData,serverHttpRequest,addDevicePrepayODResponse,"data");
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d.getBody().getErrors()));
    }

    @Test
    public void processAccessoriesTest_Not200Status() throws JsonProcessingException {
        String vzwPrepayAddOrUpdateCartResponse="{\"orderId\":\"Success\",\"status\":\"500\"}";
        VZWPrepayAddOrUpdateCartResponse addDevicePrepayODResponse= mapper.readValue(vzwPrepayAddOrUpdateCartResponse,VZWPrepayAddOrUpdateCartResponse.class);
        PrepaidODRequestDataLines line = getRedisData().getLines().get(0);
        PrepaidODAddAccessoriesResponse prepaidODAddAccessoriesResponse = new PrepaidODAddAccessoriesResponse();
        PrepaidODAddAccessoriesOutput prepaidODAddAccessoriesOutput = new PrepaidODAddAccessoriesOutput();
        List<PrepaidODAddAccessoriesOutput> prepaidODAddAccessoriesOutputArrayList = new ArrayList<>();
        prepaidODAddAccessoriesOutput.setSorId("sorId");
        prepaidODAddAccessoriesOutput.setOrderId("orderId");
        prepaidODAddAccessoriesOutputArrayList.add(prepaidODAddAccessoriesOutput);
        prepaidODAddAccessoriesResponse.setOutput(prepaidODAddAccessoriesOutputArrayList);
        String webClientResponseString = mapper.writeValueAsString(prepaidODAddAccessoriesResponse);
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(webClientResponseString));

        URI url = URI.create("http://localhost/testurl");
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.anyString(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> responseMono = ReflectionTestUtils.invokeMethod(helper,"processAccessories",line,getRedisData(),serverHttpRequest,addDevicePrepayODResponse,"data");
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));
    }



}
