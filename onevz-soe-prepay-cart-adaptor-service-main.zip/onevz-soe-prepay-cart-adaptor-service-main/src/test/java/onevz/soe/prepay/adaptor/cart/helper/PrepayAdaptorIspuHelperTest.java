package onevz.soe.prepay.adaptor.cart.helper;

import com.fasterxml.jackson.databind.ObjectMapper;
import net.jcip.annotations.NotThreadSafe;
import onevz.soe.prepay.adaptor.cart.model.cxp.request.RetreiveNpanXXRequestModel;
import onevz.soe.prepay.adaptor.cart.model.cxp.response.RetrieveNpaNxxResponse;
import onevz.soe.prepay.adaptor.cart.model.cxp.shipping.RetrieveZipcodeMktDetailsRequest;
import onevz.soe.prepay.adaptor.cart.model.cxp.shipping.RetrieveZipcodeMktDetailsResponse;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.net.URI;

import static org.mockito.Mockito.when;

@WebFluxTest
@RunWith(SpringJUnit4ClassRunner.class)
@NotThreadSafe
public class PrepayAdaptorIspuHelperTest {

    @Autowired
    PrepayAdaptorIspuHelper helper;

    @MockBean
    PrepayCartRedisHelper redisHelper;

    @MockBean
    PrepayAdaptorWebClient prepayAdaptorWebClient;

    @Autowired
    ObjectMapper mapper;


    @Test
    public void retrieveZipcodeMktDetailsTest() throws IOException {
        String requestString = "{\"data\":{\"zipCode\":\"75033\"}}";
        String responseString = "{\n" +
                "    \"marketDetails\": {\n" +
                "        \"city\": \"Phoenix\",\n" +
                "        \"state\": \"AZ\",\n" +
                "        \"zipCode\": \"85054\",\n" +
                "        \"majorMarket\": \"0010\",\n" +
                "        \"region\": \"GA\",\n" +
                "        \"marketId\": \"412\",\n" +
                "        \"marketName\": \"AZ/NM/TX\",\n" +
                "        \"areaCode\": \"West\",\n" +
                "        \"shippingTimeZone\": \"PST\",\n" +
                "        \"b2eNetAceLocation\": \"X473801\",\n" +
                "        \"regionCode\": \"Southwest\"\n" +
                "    }\n" +
                "}";

        RetrieveZipcodeMktDetailsRequest request = mapper.readValue(requestString, RetrieveZipcodeMktDetailsRequest.class);
        RetrieveZipcodeMktDetailsResponse response = mapper.readValue(responseString, RetrieveZipcodeMktDetailsResponse.class);
        URI url = URI.create("http://localhost/test");
        Mono<ResponseEntity<String>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body("test"));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(requestString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<RetrieveZipcodeMktDetailsResponse>> actual = helper.retrieveZipcodeMktDetails(httpHeader, request);
        StepVerifier.create(actual).assertNext(Assert::assertNotNull).expectComplete().verify();


    }
}
