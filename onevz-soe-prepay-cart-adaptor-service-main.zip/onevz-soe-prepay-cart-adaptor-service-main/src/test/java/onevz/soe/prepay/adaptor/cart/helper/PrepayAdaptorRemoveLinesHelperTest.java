package onevz.soe.prepay.adaptor.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import net.jcip.annotations.NotThreadSafe;
import onevz.soe.cart.model.addAccessory.AccessoryAction;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.removeLines.RemoveLinesContext;
import onevz.soe.cart.model.removeLines.RemoveLinesServiceBody;
import onevz.soe.cart.model.removeLines.RemoveLinesServiceRequest;
import onevz.soe.cart.requests.RemoveLinesPEGARequest;
import onevz.soe.cart.responses.RemoveLinesPEGAResponse;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.common.model.PrepaidODRequestDataLines;
import onevz.soe.prepay.adaptor.cart.model.play.RemoveLinesPrepayResponse;
import onevz.soe.wsclient.bpm.model.request.ContextInfo;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URI;
import java.util.*;

import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_DATA;
import static org.mockito.Mockito.when;

@WebFluxTest
@RunWith(SpringJUnit4ClassRunner.class)
@NotThreadSafe
public class PrepayAdaptorRemoveLinesHelperTest {

    @Autowired
    PrepayAdaptorRemoveLinesHelper helper;

    @MockBean
    PrepayCartRedisHelper prepayCartRedisHelper;

    @MockBean
    PrepayAdaptorWebClient prepayAdaptorWebClient;


    @Autowired
    ObjectMapper mapper;
    String requestString = "{\n" +
            "  \"serviceHeader\": {\n" +
            "    \"clientId\": \"VZW-DOTCOM\",\n" +
            "    \"statusMsg\": \"PEGA generated message\",\n" +
            "    \"serviceName\": \"SalesOrderPurchase\",\n" +
            "    \"userId\": \"\",\n" +
            "    \"statusCode\": \"0\",\n" +
            "    \"sessionId\": \"\",\n" +
            "    \"correlationId\": \"soe-cart-2022.01.25.18.58.21-916.8608036659715\"\n" +
            "  },\n" +
            "  \"serviceBody\": {\n" +
            "    \"serviceRequest\": {\n" +
            "      \"context\": {\n" +
            "        \"caseId\": \"SOP-817289281-E01\",\n" +
            "        \"contextInfo\": {\n" +
            "          \"callReason\": \"SalesOrderPurchase\",\n" +
            "          \"processStep\": \"PlanSelection\",\n" +
            "          \"processAction\": \"addPlan\",\n" +
            "          \"intent\": \"Inline-CPC\"\n" +
            "        },\n" +
            "        \"customerInfo\": {\n" +
            "          \"throttleName\": \"|AccessoryInterestialProspect|\",\n" +
            "          \"bucketAllocator\": \"BAU\",\n" +
            "          \"customerType\": \"N\",\n" +
            "          \"accountNumber\": \"\",\n" +
            "          \"cartCreator\": \"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\n" +
            "          \"processingMTN\": \"newLine1\",\n" +
            "          \"registerNumber\": 0,\n" +
            "          \"mtnFlow\": \"P\",\n" +
            "          \"globalId\": \"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"\n" +
            "        },\n" +
            "        \"cartInfo\": {\n" +
            "          \"retrieveFeatureLossReferenceData\": \"Y\",\n" +
            "          \"parentMtn\": \"\",\n" +
            "          \"cartItemCount\": 0,\n" +
            "          \"cartId\": \"b83940f5-0276-407f-947f-c2a2fa819afe\",\n" +
            "          \"itemType\": \"PLAN\",\n" +
            "          \"intendType\": \"NSE\",\n" +
            "          \"action\": \"UPDATE\",\n" +
            "          \"lines\": [\n" +
            "            {\n" +
            "              \"plan\": {\n" +
            "                \"id\": \"50427\",\n" +
            "                \"isRecommendedPlan\": false\n" +
            "              },\n" +
            "              \"mtn\": \"newLine1\",\n" +
            "              \"editSim\": false,\n" +
            "              \"lineWithSkipMDN\": false,\n" +
            "              \"inWithVerizonOpted\": false,\n" +
            "              \"protectionNotRequired\": false\n" +
            "            }\n" +
            "          ],\n" +
            "          \"effectiveDate\": \"\",\n" +
            "          \"checkAutoPayDiscountEligible\": \"N\",\n" +
            "          \"discountPromoTotal\": 0,\n" +
            "          \"registerNumber\": 0,\n" +
            "          \"protectionNotRequired\": false\n" +
            "        }\n" +
            "      }\n" +
            "    }\n" +
            "  }\n" +
            "}";

    private PrepaidODRequestData getRedisData() throws JsonProcessingException {


        String redisDataString="{\"ecommSessionId\":\"1kjhlkliueijrlwkjelrjwl88lijeljrlkwjel\",\"curr_line\":1,\"lines\":[{\"mtn\":\"newLine1\",\"lineItemId\":\"newLine1\",\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\",\"completedProcessSteps\":[\"GridWallPDP\"]}],\"pcsrfToken\":\"3iqjhlwekjqlwjelqkwjelqhwekuhwqijlwk\"})";
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData = mapper.readValue(redisDataString,PrepaidODRequestData.class);

        return redisData;
    }

    @Test
    public void removeLinesTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2024.01.31.05.38.49-704.1830760158193\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"skipImei1Call\":false,\"accountNumber\":\"HIDDENVALUE\",\"cartCreator\":\"POE-D-105d8bd7-6300-4658-8f6f-244f6f98e8c3\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"D\",\"globalId\":\"POE-D-105d8bd7-6300-4658-8f6f-244f6f98e8c3\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false,\"lineItemIdToChangePLan\":\"newLine2\"},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"GridWallPDP\",\"removeLines\"]}]}}},\"cartCount\":\"0\"}";
        String responseString1 =  "{\"status\":\"ok\",\"payload\":{\"pageData\":{\"status\":200,\"orderId\":\"S96d0678a2fbf1fffe4fd5a171f335039{s4}\",\"orderTotal\":10,\"orderTax\":0,\"orderDiscount\":0,\"monthlySavings\":0,\"orderZipcode\":\"30004\",\"dueMonthly\":10,\"dueToday\":10,\"flow\":\"NSP\",\"totalActivationfee\":0,\"sessionId\":\"POS-D-9efcc936-798f-4844-8b70-9e525a06e248{s4}\",\"deviceList\":[{\"quantity\":1,\"skuId\":\"sku5600158\",\"productId\":\"dev21411044\",\"seoName\":null,\"sorId\":\"MNUV3LL/A\",\"listPrice\":0,\"itemAmount\":0,\"rawTotalAmount\":0,\"deviceTax\":0,\"skuDisplayName\":\"WatchSeries8\",\"activationFee\":0,\"color\":\"Midnight(Aluminum)\",\"capacity\":null,\"brandName\":\"Apple\",\"imageUrl\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-watch-series-8-cellular-41mm-midnight-aluminum-midnight-sport-band-34fr-screen-usen-mnuv3ll-a?$device-lg$\",\"miniImageUrl\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-watch-series-8-cellular-41mm-midnight-aluminum-midnight-sport-band-34fr-screen-usen-mnuv3ll-a?$device-mini$\",\"planItemId\":\"S96d0678a2fbf1fffe4fd5a171f335039{s4}_plan_477170940\",\"accountMember\":false,\"accountOwner\":true,\"portInDevice\":false,\"daccCode\":\"P1869\",\"simDisplayName\":null,\"purchasePath\":\"NAP\",\"itemType\":\"smartwatch\",\"totalDueMonthly\":10,\"totalDueToday\":10,\"trialStatus\":null,\"deviceSorType\":\"4GE\",\"fiftyPercentPromoApplied\":false,\"lineSecurityPin\":null,\"securityQuestion\":null,\"securityAnswer\":null,\"deviceFirstName\":null,\"deviceLastName\":null,\"simId\":null,\"esimCompatible\":false,\"esimOnlyDevice\":false,\"smartImeiDevice\":false,\"imei\":null,\"imei2\":null,\"requestedEsimImei\":null,\"futureDiscount\":0,\"futureDiscountMonths\":0,\"numberShareMdn\":null,\"replaceMdn\":null,\"replaceNumberShareMdn\":null,\"numberShareLineItemId\":null,\"operatingSystem\":\"AppleiOS\",\"numberShareEligibleOS\":[\"AppleiOS\"],\"itemDiscount\":0,\"autoPaymentEligible\":false,\"eSIMEnabledDevice\":true,\"fullRetailListPrice\":0,\"taxDetails\":{},\"existingDevice\":null,\"npaNxxCode\":null,\"id\":\"S96d0678a2fbf1fffe4fd5a171f335039{s4}_device_269792350\",\"inlinePromo\":false,\"nspaired\":false}],\"accessoryList\":null,\"planList\":[{\"id\":\"S96d0678a2fbf1fffe4fd5a171f335039{s4}_plan_477170940\",\"skuId\":\"sku6007705\",\"productId\":\"plan2560001\",\"sorId\":\"28445\",\"dueMonthly\":10,\"dueToday\":10,\"skuDisplayName\":null,\"itemTax\":0,\"discount\":0,\"planSize\":\"15GB\",\"description\":\"$10-2023-WATCH-NUMBERSHARE-PLAN\",\"featureLineItemId\":null,\"title\":\"Unlimited\",\"fourthLinePromoDiscount\":0,\"autoPaySaving\":5,\"promotions\":{},\"bonusData\":null,\"eligibleForDoubleData\":true,\"totalDueMonthly\":10,\"totalDueToday\":10,\"planDueMonthly\":10,\"actualPlanPrice\":10,\"planDescription\":\"15GBplan\",\"disneyPlusPromo\":false,\"accountOwner\":true,\"loyalityDiscountsEnabled\":true,\"mobileHotspotEnabled\":false,\"autoPayToolTip\":null,\"taxDetails\":{\"GAPrepaid911Fee\":1.5},\"discountApplied\":false}],\"featureList\":[],\"taxDetailList\":[{\"taxPrice\":1.5,\"taxDetailsToDisplay\":\"GAPrepaid911Fee\"}],\"accountInfo\":{\"mdnNumber\":null,\"accountOwner\":false,\"firstName\":null,\"middleName\":null,\"zipcode\":null,\"fullName\":null,\"address\":null,\"lastName\":null},\"todaySavings\":0,\"linesCount\":0,\"cartCount\":1,\"accountOwnerUpdate\":true,\"itemType\":\"smartwatch\",\"maxDeviceLimit\":10,\"accountDeviceLimit\":10,\"promotions\":[],\"promoAdded\":false,\"digitalPaymentOptions\":{\"applepayEnabled\":\"true\",\"applePayMerchantId\":\"merchant.com.vzw.test\",\"paypalEnabled\":\"true\"},\"taxPromoEnabled\":false,\"deviceFingerPrintEnabled\":true,\"planDueMonthly\":10,\"maxCartLimit\":9,\"trialStatus\":null,\"is5G_EWB_Device\":false,\"nseNsoFlag\":true,\"accumulateInlineDiscount\":0,\"inlinePromotionMessage\":null,\"holidayPolicyEnable\":false,\"autopaySavings\":0,\"autoPayAccount\":false,\"enableFamilyPricing\":true,\"lineItemIdToChangePLan\":\"S96d0678a2fbf1fffe4fd5a171f335039{s4}_device_269792350\",\"autopaySavingEligible\":true,\"enabledPriceRefresh\":true,\"planSavings\":0,\"shippingDetails\":{},\"nextDueDate\":null,\"dueNextCycle\":10,\"offerDataToBeShowed\":true,\"mot\":false}},\"prepayThrottleList\":\"|\"}";
        RemoveLinesPEGARequest request = mapper.readValue(requestString, RemoveLinesPEGARequest.class);
        RemoveLinesPEGAResponse response = mapper.readValue(responseString, RemoveLinesPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<RemoveLinesPEGAResponse>> justResponse =
                Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        RemoveLinesPrepayResponse response1 = mapper.readValue(responseString, RemoveLinesPrepayResponse.class);
        URI url1 = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<RemoveLinesPrepayResponse>> justResponse1 = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response1));

        PrepaidODRequestData redisData = getRedisData();
        Map<String,String> map=new HashMap<>();
        map.put("237592","483030");
        redisData.setRefillCardNumbers(map);
        redisData.getLines().get(0).setCheckoutFlag(true);
        redisData.getLines().get(0).setLineItemId("S96d0678a2fbf1fffe4fd5a171f335039{s4}_device_269792350");

        String mockRedisData = mapper.writeValueAsString(redisData);

        AccessoryAction accessoryAction = new AccessoryAction();

        Line[] requestLines = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();


        Accessory[] accessories = new Accessory[1];
        accessoryAction.setAdd(accessories);
        accessoryAction.setRemove(accessories);
        Arrays.stream(requestLines).findFirst().get().setAccessories(accessoryAction);

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString1));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<RemoveLinesPEGAResponse>> responseMono =
                helper.removeLines(httpHeader, request);
        responseMono.subscribe(value -> {
                },
                error -> {
                },
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void removeLinesErrorRespTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2024.01.31.05.38.49-704.1830760158193\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"skipImei1Call\":false,\"accountNumber\":\"HIDDENVALUE\",\"cartCreator\":\"POE-D-105d8bd7-6300-4658-8f6f-244f6f98e8c3\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"D\",\"globalId\":\"POE-D-105d8bd7-6300-4658-8f6f-244f6f98e8c3\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false,\"lineItemIdToChangePLan\":\"newLine2\"},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"GridWallPDP\",\"removeLines\"]}]}}},\"cartCount\":\"0\"}";
        String responseString1 =  "{\"status\":\"error\",\"payload\":{\"pageData\":{\"status\":200,\"orderId\":\"S96d0678a2fbf1fffe4fd5a171f335039{s4}\",\"orderTotal\":10,\"orderTax\":0,\"orderDiscount\":0,\"monthlySavings\":0,\"orderZipcode\":\"30004\",\"dueMonthly\":10,\"dueToday\":10,\"flow\":\"NSP\",\"totalActivationfee\":0,\"sessionId\":\"POS-D-9efcc936-798f-4844-8b70-9e525a06e248{s4}\",\"deviceList\":[{\"quantity\":1,\"skuId\":\"sku5600158\",\"productId\":\"dev21411044\",\"seoName\":null,\"sorId\":\"MNUV3LL/A\",\"listPrice\":0,\"itemAmount\":0,\"rawTotalAmount\":0,\"deviceTax\":0,\"skuDisplayName\":\"WatchSeries8\",\"activationFee\":0,\"color\":\"Midnight(Aluminum)\",\"capacity\":null,\"brandName\":\"Apple\",\"imageUrl\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-watch-series-8-cellular-41mm-midnight-aluminum-midnight-sport-band-34fr-screen-usen-mnuv3ll-a?$device-lg$\",\"miniImageUrl\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-watch-series-8-cellular-41mm-midnight-aluminum-midnight-sport-band-34fr-screen-usen-mnuv3ll-a?$device-mini$\",\"planItemId\":\"S96d0678a2fbf1fffe4fd5a171f335039{s4}_plan_477170940\",\"accountMember\":false,\"accountOwner\":true,\"portInDevice\":false,\"daccCode\":\"P1869\",\"simDisplayName\":null,\"purchasePath\":\"NAP\",\"itemType\":\"smartwatch\",\"totalDueMonthly\":10,\"totalDueToday\":10,\"trialStatus\":null,\"deviceSorType\":\"4GE\",\"fiftyPercentPromoApplied\":false,\"lineSecurityPin\":null,\"securityQuestion\":null,\"securityAnswer\":null,\"deviceFirstName\":null,\"deviceLastName\":null,\"simId\":null,\"esimCompatible\":false,\"esimOnlyDevice\":false,\"smartImeiDevice\":false,\"imei\":null,\"imei2\":null,\"requestedEsimImei\":null,\"futureDiscount\":0,\"futureDiscountMonths\":0,\"numberShareMdn\":null,\"replaceMdn\":null,\"replaceNumberShareMdn\":null,\"numberShareLineItemId\":null,\"operatingSystem\":\"AppleiOS\",\"numberShareEligibleOS\":[\"AppleiOS\"],\"itemDiscount\":0,\"autoPaymentEligible\":false,\"eSIMEnabledDevice\":true,\"fullRetailListPrice\":0,\"taxDetails\":{},\"existingDevice\":null,\"npaNxxCode\":null,\"id\":\"S96d0678a2fbf1fffe4fd5a171f335039{s4}_device_269792350\",\"inlinePromo\":false,\"nspaired\":false}],\"accessoryList\":null,\"planList\":[{\"id\":\"S96d0678a2fbf1fffe4fd5a171f335039{s4}_plan_477170940\",\"skuId\":\"sku6007705\",\"productId\":\"plan2560001\",\"sorId\":\"28445\",\"dueMonthly\":10,\"dueToday\":10,\"skuDisplayName\":null,\"itemTax\":0,\"discount\":0,\"planSize\":\"15GB\",\"description\":\"$10-2023-WATCH-NUMBERSHARE-PLAN\",\"featureLineItemId\":null,\"title\":\"Unlimited\",\"fourthLinePromoDiscount\":0,\"autoPaySaving\":5,\"promotions\":{},\"bonusData\":null,\"eligibleForDoubleData\":true,\"totalDueMonthly\":10,\"totalDueToday\":10,\"planDueMonthly\":10,\"actualPlanPrice\":10,\"planDescription\":\"15GBplan\",\"disneyPlusPromo\":false,\"accountOwner\":true,\"loyalityDiscountsEnabled\":true,\"mobileHotspotEnabled\":false,\"autoPayToolTip\":null,\"taxDetails\":{\"GAPrepaid911Fee\":1.5},\"discountApplied\":false}],\"featureList\":[],\"taxDetailList\":[{\"taxPrice\":1.5,\"taxDetailsToDisplay\":\"GAPrepaid911Fee\"}],\"accountInfo\":{\"mdnNumber\":null,\"accountOwner\":false,\"firstName\":null,\"middleName\":null,\"zipcode\":null,\"fullName\":null,\"address\":null,\"lastName\":null},\"todaySavings\":0,\"linesCount\":0,\"cartCount\":1,\"accountOwnerUpdate\":true,\"itemType\":\"smartwatch\",\"maxDeviceLimit\":10,\"accountDeviceLimit\":10,\"promotions\":[],\"promoAdded\":false,\"digitalPaymentOptions\":{\"applepayEnabled\":\"true\",\"applePayMerchantId\":\"merchant.com.vzw.test\",\"paypalEnabled\":\"true\"},\"taxPromoEnabled\":false,\"deviceFingerPrintEnabled\":true,\"planDueMonthly\":10,\"maxCartLimit\":9,\"trialStatus\":null,\"is5G_EWB_Device\":false,\"nseNsoFlag\":true,\"accumulateInlineDiscount\":0,\"inlinePromotionMessage\":null,\"holidayPolicyEnable\":false,\"autopaySavings\":0,\"autoPayAccount\":false,\"enableFamilyPricing\":true,\"lineItemIdToChangePLan\":\"S96d0678a2fbf1fffe4fd5a171f335039{s4}_device_269792350\",\"autopaySavingEligible\":true,\"enabledPriceRefresh\":true,\"planSavings\":0,\"shippingDetails\":{},\"nextDueDate\":null,\"dueNextCycle\":10,\"offerDataToBeShowed\":true,\"mot\":false}},\"prepayThrottleList\":\"|\"}";
        RemoveLinesPEGARequest request = mapper.readValue(requestString, RemoveLinesPEGARequest.class);
        RemoveLinesPEGAResponse response = mapper.readValue(responseString, RemoveLinesPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<RemoveLinesPEGAResponse>> justResponse =
                Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        RemoveLinesPrepayResponse response1 = mapper.readValue(responseString, RemoveLinesPrepayResponse.class);
        URI url1 = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<RemoveLinesPrepayResponse>> justResponse1 = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response1));

        PrepaidODRequestData redisData = getRedisData();
        Map<String,String> map=new HashMap<>();
        map.put("237592","483030");
        redisData.setRefillCardNumbers(map);
        redisData.getLines().get(0).setCheckoutFlag(false);
        redisData.getLines().get(0).setLineItemId("S96d0678a2fbf1fffe4fd5a171f335039{s4}_device_269792350");

        String mockRedisData = mapper.writeValueAsString(redisData);

        AccessoryAction accessoryAction = new AccessoryAction();

        Line[] requestLines = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();


        Accessory[] accessories = new Accessory[1];
        accessoryAction.setAdd(accessories);
        accessoryAction.setRemove(accessories);
        Arrays.stream(requestLines).findFirst().get().setAccessories(accessoryAction);

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString1));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<RemoveLinesPEGAResponse>> responseMono =
                helper.removeLines(httpHeader, request);
        responseMono.subscribe(value -> {
                },
                error -> {
                },
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void removeLinesErrorRespCheckoutTrueTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2024.01.31.05.38.49-704.1830760158193\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"skipImei1Call\":false,\"accountNumber\":\"HIDDENVALUE\",\"cartCreator\":\"POE-D-105d8bd7-6300-4658-8f6f-244f6f98e8c3\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"D\",\"globalId\":\"POE-D-105d8bd7-6300-4658-8f6f-244f6f98e8c3\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false,\"lineItemIdToChangePLan\":\"newLine2\"},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"GridWallPDP\",\"removeLines\"]}]}}},\"cartCount\":\"0\"}";
        String responseString1 =  "{\"status\":\"error\",\"payload\":{\"pageData\":{\"status\":200,\"orderId\":\"S96d0678a2fbf1fffe4fd5a171f335039{s4}\",\"orderTotal\":10,\"orderTax\":0,\"orderDiscount\":0,\"monthlySavings\":0,\"orderZipcode\":\"30004\",\"dueMonthly\":10,\"dueToday\":10,\"flow\":\"NSP\",\"totalActivationfee\":0,\"sessionId\":\"POS-D-9efcc936-798f-4844-8b70-9e525a06e248{s4}\",\"deviceList\":[{\"quantity\":1,\"skuId\":\"sku5600158\",\"productId\":\"dev21411044\",\"seoName\":null,\"sorId\":\"MNUV3LL/A\",\"listPrice\":0,\"itemAmount\":0,\"rawTotalAmount\":0,\"deviceTax\":0,\"skuDisplayName\":\"WatchSeries8\",\"activationFee\":0,\"color\":\"Midnight(Aluminum)\",\"capacity\":null,\"brandName\":\"Apple\",\"imageUrl\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-watch-series-8-cellular-41mm-midnight-aluminum-midnight-sport-band-34fr-screen-usen-mnuv3ll-a?$device-lg$\",\"miniImageUrl\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-watch-series-8-cellular-41mm-midnight-aluminum-midnight-sport-band-34fr-screen-usen-mnuv3ll-a?$device-mini$\",\"planItemId\":\"S96d0678a2fbf1fffe4fd5a171f335039{s4}_plan_477170940\",\"accountMember\":false,\"accountOwner\":true,\"portInDevice\":false,\"daccCode\":\"P1869\",\"simDisplayName\":null,\"purchasePath\":\"NAP\",\"itemType\":\"smartwatch\",\"totalDueMonthly\":10,\"totalDueToday\":10,\"trialStatus\":null,\"deviceSorType\":\"4GE\",\"fiftyPercentPromoApplied\":false,\"lineSecurityPin\":null,\"securityQuestion\":null,\"securityAnswer\":null,\"deviceFirstName\":null,\"deviceLastName\":null,\"simId\":null,\"esimCompatible\":false,\"esimOnlyDevice\":false,\"smartImeiDevice\":false,\"imei\":null,\"imei2\":null,\"requestedEsimImei\":null,\"futureDiscount\":0,\"futureDiscountMonths\":0,\"numberShareMdn\":null,\"replaceMdn\":null,\"replaceNumberShareMdn\":null,\"numberShareLineItemId\":null,\"operatingSystem\":\"AppleiOS\",\"numberShareEligibleOS\":[\"AppleiOS\"],\"itemDiscount\":0,\"autoPaymentEligible\":false,\"eSIMEnabledDevice\":true,\"fullRetailListPrice\":0,\"taxDetails\":{},\"existingDevice\":null,\"npaNxxCode\":null,\"id\":\"S96d0678a2fbf1fffe4fd5a171f335039{s4}_device_269792350\",\"inlinePromo\":false,\"nspaired\":false}],\"accessoryList\":null,\"planList\":[{\"id\":\"S96d0678a2fbf1fffe4fd5a171f335039{s4}_plan_477170940\",\"skuId\":\"sku6007705\",\"productId\":\"plan2560001\",\"sorId\":\"28445\",\"dueMonthly\":10,\"dueToday\":10,\"skuDisplayName\":null,\"itemTax\":0,\"discount\":0,\"planSize\":\"15GB\",\"description\":\"$10-2023-WATCH-NUMBERSHARE-PLAN\",\"featureLineItemId\":null,\"title\":\"Unlimited\",\"fourthLinePromoDiscount\":0,\"autoPaySaving\":5,\"promotions\":{},\"bonusData\":null,\"eligibleForDoubleData\":true,\"totalDueMonthly\":10,\"totalDueToday\":10,\"planDueMonthly\":10,\"actualPlanPrice\":10,\"planDescription\":\"15GBplan\",\"disneyPlusPromo\":false,\"accountOwner\":true,\"loyalityDiscountsEnabled\":true,\"mobileHotspotEnabled\":false,\"autoPayToolTip\":null,\"taxDetails\":{\"GAPrepaid911Fee\":1.5},\"discountApplied\":false}],\"featureList\":[],\"taxDetailList\":[{\"taxPrice\":1.5,\"taxDetailsToDisplay\":\"GAPrepaid911Fee\"}],\"accountInfo\":{\"mdnNumber\":null,\"accountOwner\":false,\"firstName\":null,\"middleName\":null,\"zipcode\":null,\"fullName\":null,\"address\":null,\"lastName\":null},\"todaySavings\":0,\"linesCount\":0,\"cartCount\":1,\"accountOwnerUpdate\":true,\"itemType\":\"smartwatch\",\"maxDeviceLimit\":10,\"accountDeviceLimit\":10,\"promotions\":[],\"promoAdded\":false,\"digitalPaymentOptions\":{\"applepayEnabled\":\"true\",\"applePayMerchantId\":\"merchant.com.vzw.test\",\"paypalEnabled\":\"true\"},\"taxPromoEnabled\":false,\"deviceFingerPrintEnabled\":true,\"planDueMonthly\":10,\"maxCartLimit\":9,\"trialStatus\":null,\"is5G_EWB_Device\":false,\"nseNsoFlag\":true,\"accumulateInlineDiscount\":0,\"inlinePromotionMessage\":null,\"holidayPolicyEnable\":false,\"autopaySavings\":0,\"autoPayAccount\":false,\"enableFamilyPricing\":true,\"lineItemIdToChangePLan\":\"S96d0678a2fbf1fffe4fd5a171f335039{s4}_device_269792350\",\"autopaySavingEligible\":true,\"enabledPriceRefresh\":true,\"planSavings\":0,\"shippingDetails\":{},\"nextDueDate\":null,\"dueNextCycle\":10,\"offerDataToBeShowed\":true,\"mot\":false}},\"prepayThrottleList\":\"|\"}";
        RemoveLinesPEGARequest request = mapper.readValue(requestString, RemoveLinesPEGARequest.class);
        RemoveLinesPEGAResponse response = mapper.readValue(responseString, RemoveLinesPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<RemoveLinesPEGAResponse>> justResponse =
                Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        RemoveLinesPrepayResponse response1 = mapper.readValue(responseString, RemoveLinesPrepayResponse.class);
        URI url1 = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<RemoveLinesPrepayResponse>> justResponse1 = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response1));

        PrepaidODRequestData redisData = getRedisData();
        Map<String,String> map=new HashMap<>();
        map.put("237592","483030");
        redisData.setRefillCardNumbers(map);
        redisData.getLines().get(0).setCheckoutFlag(true);
        redisData.getLines().get(0).setLineItemId("S96d0678a2fbf1fffe4fd5a171f335039{s4}_device_269792350");

        String mockRedisData = mapper.writeValueAsString(redisData);

        AccessoryAction accessoryAction = new AccessoryAction();

        Line[] requestLines = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();


        Accessory[] accessories = new Accessory[1];
        accessoryAction.setAdd(accessories);
        accessoryAction.setRemove(accessories);
        Arrays.stream(requestLines).findFirst().get().setAccessories(accessoryAction);

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString1));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<RemoveLinesPEGAResponse>> responseMono =
                helper.removeLines(httpHeader, request);
        responseMono.subscribe(value -> {
                },
                error -> {
                },
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void removeLinesEmptyLinesTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2024.01.31.05.38.49-704.1830760158193\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"skipImei1Call\":false,\"accountNumber\":\"HIDDENVALUE\",\"cartCreator\":\"POE-D-105d8bd7-6300-4658-8f6f-244f6f98e8c3\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"D\",\"globalId\":\"POE-D-105d8bd7-6300-4658-8f6f-244f6f98e8c3\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false,\"lineItemIdToChangePLan\":\"newLine2\"},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"GridWallPDP\",\"removeLines\"]}]}}},\"cartCount\":\"0\"}";

        RemoveLinesPEGARequest request = mapper.readValue(requestString, RemoveLinesPEGARequest.class);
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().setLines(null);
        RemoveLinesPEGAResponse response = mapper.readValue(responseString, RemoveLinesPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<RemoveLinesPEGAResponse>> justResponse =
                Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));


        PrepaidODRequestData redisData = getRedisData();
        String mockRedisData = mapper.writeValueAsString(redisData);

        AccessoryAction accessoryAction = new AccessoryAction();

        RemoveLinesPrepayResponse prepayResponse=new RemoveLinesPrepayResponse();
        prepayResponse.setStatus("error");
        String responseData=mapper.writeValueAsString(prepayResponse);


        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseData));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<RemoveLinesPEGAResponse>> responseMono =
                helper.removeLines(httpHeader, request);
        responseMono.subscribe(value -> {
                },
                error -> {
                },
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void removeLinesNoRedisDataTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2024.01.31.05.38.49-704.1830760158193\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"skipImei1Call\":false,\"accountNumber\":\"HIDDENVALUE\",\"cartCreator\":\"POE-D-105d8bd7-6300-4658-8f6f-244f6f98e8c3\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"D\",\"globalId\":\"POE-D-105d8bd7-6300-4658-8f6f-244f6f98e8c3\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false,\"lineItemIdToChangePLan\":\"newLine2\"},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"GridWallPDP\",\"removeLines\"]}]}}},\"cartCount\":\"0\"}";

        RemoveLinesPEGARequest request = mapper.readValue(requestString, RemoveLinesPEGARequest.class);
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().setLines(null);
        RemoveLinesPEGAResponse response = mapper.readValue(responseString, RemoveLinesPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<RemoveLinesPEGAResponse>> justResponse =
                Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));


        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.empty());
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<RemoveLinesPEGAResponse>> responseMono =
                helper.removeLines(httpHeader, request);
        responseMono.subscribe(value -> {
                },
                error -> {
                },
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }


    @Test
    public void removeLinesTest2() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2024.01.31.05.38.49-704.1830760158193\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"skipImei1Call\":false,\"accountNumber\":\"HIDDENVALUE\",\"cartCreator\":\"POE-D-105d8bd7-6300-4658-8f6f-244f6f98e8c3\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"D\",\"globalId\":\"POE-D-105d8bd7-6300-4658-8f6f-244f6f98e8c3\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false,\"lineItemIdToChangePLan\":\"newLine2\"},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"GridWallPDP\",\"removeLines\"]}]}}},\"cartCount\":\"0\"}";

        RemoveLinesPEGARequest request = mapper.readValue(requestString, RemoveLinesPEGARequest.class);
        RemoveLinesPEGAResponse response = mapper.readValue(responseString, RemoveLinesPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<RemoveLinesPEGAResponse>> justResponse =
                Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().setIntendType(null);


        PrepaidODRequestData redisData = getRedisData();
        PrepaidODRequestDataLines line= new PrepaidODRequestDataLines();
        line.setMtn("newLine2");
        line.setLineItemId("Test678");
        List<PrepaidODRequestDataLines> lines= redisData.getLines();
        lines.add(line);
        redisData.setLines(lines);
        String mockRedisData = mapper.writeValueAsString(redisData);

        AccessoryAction accessoryAction = new AccessoryAction();

        Line[] requestLines = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();


        Accessory[] accessories = new Accessory[1];
        accessoryAction.setAdd(accessories);
        accessoryAction.setRemove(accessories);
        Arrays.stream(requestLines).findFirst().get().setAccessories(accessoryAction);

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, redisData)).thenReturn(Mono.just(true));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<RemoveLinesPEGAResponse>> responseMono =
                helper.removeLines(httpHeader, request);
        responseMono.subscribe(value -> {
                },
                error -> {
                },
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void removeLinesTest3() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2024.01.31.05.38.49-704.1830760158193\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"skipImei1Call\":false,\"accountNumber\":\"HIDDENVALUE\",\"cartCreator\":\"POE-D-105d8bd7-6300-4658-8f6f-244f6f98e8c3\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"D\",\"globalId\":\"POE-D-105d8bd7-6300-4658-8f6f-244f6f98e8c3\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false,\"lineItemIdToChangePLan\":\"newLine2\"},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"GridWallPDP\",\"removeLines\"]}]}}},\"cartCount\":\"0\"}";

        RemoveLinesPEGARequest request = mapper.readValue(requestString, RemoveLinesPEGARequest.class);
        RemoveLinesPEGAResponse response = mapper.readValue(responseString, RemoveLinesPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<RemoveLinesPEGAResponse>> justResponse =
                Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().setIntendType(null);


        PrepaidODRequestData redisData = getRedisData();
        String mockRedisData = mapper.writeValueAsString(redisData);

        AccessoryAction accessoryAction = new AccessoryAction();

        Line[] requestLines = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();


        Accessory[] accessories = new Accessory[1];
        accessoryAction.setAdd(accessories);
        accessoryAction.setRemove(accessories);
        Arrays.stream(requestLines).findFirst().get().setAccessories(accessoryAction);

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, redisData)).thenReturn(Mono.just(true));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<RemoveLinesPEGAResponse>> responseMono =
                helper.removeLines(httpHeader, request);
        responseMono.subscribe(value -> {
                },
                error -> {
                },
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }


    @Test
    public void removeLinesTest_1() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2024.01.31.05.38.49-704.1830760158193\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"skipImei1Call\":false,\"accountNumber\":\"HIDDENVALUE\",\"cartCreator\":\"POE-D-105d8bd7-6300-4658-8f6f-244f6f98e8c3\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"D\",\"globalId\":\"POE-D-105d8bd7-6300-4658-8f6f-244f6f98e8c3\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false,\"lineItemIdToChangePLan\":\"newLine2\"},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"GridWallPDP\",\"removeLines\"]}]}}},\"cartCount\":\"0\"}";

        RemoveLinesPEGARequest request = mapper.readValue(requestString, RemoveLinesPEGARequest.class);
        URI url = URI.create("http://localhost/testurl");

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just("value"));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<RemoveLinesPEGAResponse>> responseMono =
                helper.removeLines(httpHeader, request);
        responseMono.subscribe(value -> {
                },
                error -> {
                },
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }



    @Test
    public void removeLinesWithEmptyLinesTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2024.01.31.05.38.49-704.1830760158193\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"skipImei1Call\":false,\"accountNumber\":\"HIDDENVALUE\",\"cartCreator\":\"POE-D-105d8bd7-6300-4658-8f6f-244f6f98e8c3\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"D\",\"globalId\":\"POE-D-105d8bd7-6300-4658-8f6f-244f6f98e8c3\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false,\"lineItemIdToChangePLan\":\"newLine2\"},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"GridWallPDP\",\"removeLines\"]}]}}},\"cartCount\":\"0\"}";

        RemoveLinesPEGARequest request = mapper.readValue(requestString, RemoveLinesPEGARequest.class);
        RemoveLinesPEGAResponse response = mapper.readValue(responseString, RemoveLinesPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<RemoveLinesPEGAResponse>> justResponse =
                Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));


        PrepaidODRequestData redisData = getRedisData();
        redisData.setLines(null);
        String mockRedisData = mapper.writeValueAsString(redisData);

        AccessoryAction accessoryAction = new AccessoryAction();

        Line[] requestLines = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
        Accessory[] accessories = new Accessory[1];
        accessoryAction.setAdd(accessories);
        accessoryAction.setRemove(accessories);
        Arrays.stream(requestLines).findFirst().get().setAccessories(accessoryAction);

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, redisData)).thenReturn(Mono.just(true));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<RemoveLinesPEGAResponse>> responseMono =
                helper.removeLines(httpHeader, request);
        responseMono.subscribe(value -> {
                },
                error -> {
                },
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void removeLinesCheckoutFlaggFalseTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2024.01.31.05.38.49-704.1830760158193\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"skipImei1Call\":false,\"accountNumber\":\"HIDDENVALUE\",\"cartCreator\":\"POE-D-105d8bd7-6300-4658-8f6f-244f6f98e8c3\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"D\",\"globalId\":\"POE-D-105d8bd7-6300-4658-8f6f-244f6f98e8c3\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false,\"lineItemIdToChangePLan\":\"newLine2\"},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"GridWallPDP\",\"removeLines\"]}]}}},\"cartCount\":\"0\"}";

        RemoveLinesPEGARequest request = mapper.readValue(requestString, RemoveLinesPEGARequest.class);
        RemoveLinesPEGAResponse response = mapper.readValue(responseString, RemoveLinesPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<RemoveLinesPEGAResponse>> justResponse =
                Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));


        PrepaidODRequestData redisData = getRedisData();
        List<PrepaidODRequestDataLines> redisDataLines=new ArrayList<PrepaidODRequestDataLines>();
        PrepaidODRequestDataLines line2=new PrepaidODRequestDataLines();
        line2.setMtn("newLine2");
        PrepaidODRequestDataLines line3=new PrepaidODRequestDataLines();
        line3.setMtn("newLine3");


        redisDataLines.addAll(redisData.getLines());
        redisDataLines.add(line2);
        redisDataLines.add(line3);
        redisData.setLines(redisDataLines);
        redisData.setAccountOwner("newLine1");
        for(PrepaidODRequestDataLines redisDataLine:redisDataLines)
        {
            redisDataLine.setCheckoutFlag(false);
        }

        String mockRedisData = mapper.writeValueAsString(redisData);

        AccessoryAction accessoryAction = new AccessoryAction();

        Line[] requestLines = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();


        Accessory[] accessories = new Accessory[1];
        accessoryAction.setAdd(accessories);
        accessoryAction.setRemove(accessories);
        Arrays.stream(requestLines).findFirst().get().setAccessories(accessoryAction);

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(""));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<RemoveLinesPEGAResponse>> responseMono =
                helper.removeLines(httpHeader, request);
        responseMono.subscribe(value -> {
                },
                error -> {
                },
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void removeLinesCheckoutFlaggTrueTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2024.01.31.05.38.49-704.1830760158193\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"skipImei1Call\":false,\"accountNumber\":\"HIDDENVALUE\",\"cartCreator\":\"POE-D-105d8bd7-6300-4658-8f6f-244f6f98e8c3\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"D\",\"globalId\":\"POE-D-105d8bd7-6300-4658-8f6f-244f6f98e8c3\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false,\"lineItemIdToChangePLan\":\"newLine2\"},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"GridWallPDP\",\"removeLines\"]}]}}},\"cartCount\":\"0\"}";

        RemoveLinesPEGARequest request = mapper.readValue(requestString, RemoveLinesPEGARequest.class);
        RemoveLinesPEGAResponse response = mapper.readValue(responseString, RemoveLinesPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<RemoveLinesPEGAResponse>> justResponse =
                Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));


        PrepaidODRequestData redisData = getRedisData();
        List<PrepaidODRequestDataLines> redisDataLines=new ArrayList<PrepaidODRequestDataLines>();
        PrepaidODRequestDataLines line2=new PrepaidODRequestDataLines();
        line2.setMtn("newLine2");
        PrepaidODRequestDataLines line3=new PrepaidODRequestDataLines();
        line3.setMtn("newLine3");

        redisDataLines.addAll(redisData.getLines());
        redisDataLines.add(line2);
        redisDataLines.add(line3);
        redisData.setLines(redisDataLines);
        redisData.setAccountOwner("newLine2");
        for(PrepaidODRequestDataLines redisDataLine:redisDataLines)
        {
            redisDataLine.setCheckoutFlag(true);
        }

        String mockRedisData = mapper.writeValueAsString(redisData);

        AccessoryAction accessoryAction = new AccessoryAction();

        Line[] requestLines = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();


        Accessory[] accessories = new Accessory[1];
        accessoryAction.setAdd(accessories);
        accessoryAction.setRemove(accessories);
        Arrays.stream(requestLines).findFirst().get().setAccessories(accessoryAction);

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, redisData)).thenReturn(Mono.just(true));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(""));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<RemoveLinesPEGAResponse>> responseMono =
                helper.removeLines(httpHeader, request);
        responseMono.subscribe(value -> {
                },
                error -> {
                },
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void removeLinesLIneItemIdNullTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        RemoveLinesPEGARequest request = mapper.readValue(requestString, RemoveLinesPEGARequest.class);
        RemoveLinesPEGAResponse response = mapper.readValue(responseString, RemoveLinesPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<RemoveLinesPEGAResponse>> justResponse =
                Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));


        PrepaidODRequestData redisData = getRedisData();
        List<PrepaidODRequestDataLines> redisDataLines=new ArrayList<PrepaidODRequestDataLines>();

        redisDataLines.addAll(redisData.getLines());
        for(PrepaidODRequestDataLines redisDataLine:redisDataLines)
        {
            redisDataLine.setLineItemId(null);
            redisDataLine.setCheckoutFlag(true);
        }

        String mockRedisData = mapper.writeValueAsString(redisData);

        AccessoryAction accessoryAction = new AccessoryAction();

        Line[] requestLines = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();


        Accessory[] accessories = new Accessory[1];
        accessoryAction.setAdd(accessories);
        accessoryAction.setRemove(accessories);
        Arrays.stream(requestLines).findFirst().get().setAccessories(accessoryAction);

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, redisData)).thenReturn(Mono.just(true));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<RemoveLinesPEGAResponse>> responseMono =
                helper.removeLines(httpHeader, request);
        responseMono.subscribe(value -> {
                },
                error -> {
                },
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void testConvertToPEGAResponse() throws Exception {
        RemoveLinesPEGARequest request = new RemoveLinesPEGARequest();
        RemoveLinesServiceBody body = new RemoveLinesServiceBody();
        RemoveLinesServiceRequest br = new RemoveLinesServiceRequest();
        RemoveLinesContext ctx = new RemoveLinesContext();
        CartServiceCartInfo ff = new CartServiceCartInfo();
        ctx.setCartInfo(ff);
        ContextInfo b = new ContextInfo();
        //  b.set
        ctx.setContextInfo(b);
        CartServiceCustomerInfo cin = new CartServiceCustomerInfo();
        cin.setMtn("newLine1");
        cin.setProcessingMTN("newLine1");
        ctx.setCustomerInfo(cin);
        br.setContext(ctx);
        body.setServiceRequest(br);
        request.setServiceBody(body);
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        request.setServiceHeader(serviceHeader);
        //etServiceBody().getServiceRequest().getContext().getCustomerInfo().getProcessingMTN()
        PrepaidODRequestData redisData = new PrepaidODRequestData();

        RemoveLinesPEGAResponse pegaResponse = helper.convertToPEGAResponse(request, true, redisData);

        Assert.assertNotNull(pegaResponse);

    }

    @Test
    public void testConvertToPEGAResponse_nullRedisData() {
        RemoveLinesPEGARequest request = new RemoveLinesPEGARequest();
        RemoveLinesServiceBody body = new RemoveLinesServiceBody();
        RemoveLinesServiceRequest br = new RemoveLinesServiceRequest();
        RemoveLinesContext ctx = new RemoveLinesContext();
        CartServiceCartInfo ff = new CartServiceCartInfo();
        ctx.setCartInfo(ff);
        ContextInfo b = new ContextInfo();
        ctx.setContextInfo(b);
        CartServiceCustomerInfo cin = new CartServiceCustomerInfo();
        cin.setMtn("newLine1");
        cin.setProcessingMTN("newLine1");
        ctx.setCustomerInfo(cin);
        br.setContext(ctx);
        body.setServiceRequest(br);
        request.setServiceBody(body);
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        request.setServiceHeader(serviceHeader);
        RemoveLinesPEGAResponse pegaResponse = helper.convertToPEGAResponse(request, true, null);

        Assert.assertNotNull(pegaResponse);

    }

    @Test
    public void testConvertToPEGAResponse_1()  {
        RemoveLinesPEGARequest request = new RemoveLinesPEGARequest();
        RemoveLinesServiceBody body = new RemoveLinesServiceBody();
        RemoveLinesServiceRequest br = new RemoveLinesServiceRequest();
        RemoveLinesContext ctx = new RemoveLinesContext();
        CartServiceCartInfo ff = new CartServiceCartInfo();
        Line Lineobj=new Line();
        Lineobj.setNpaNxx("123");
        Line[] linesArr=new Line[1];
        linesArr[0]=Lineobj;
        ff.setLines(linesArr);
        ctx.setCartInfo(ff);
        ContextInfo b = new ContextInfo();
        ctx.setContextInfo(b);
        CartServiceCustomerInfo cin = new CartServiceCustomerInfo();
        cin.setMtn("newLine1");
        cin.setProcessingMTN("newLine1");
        ctx.setCustomerInfo(cin);
        br.setContext(ctx);
        body.setServiceRequest(br);
        request.setServiceBody(body);
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        request.setServiceHeader(serviceHeader);
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setFlow("NSE");
        line.setCheckoutFlag(true);
        line.setCompletedProcessSteps(completedProcessSteps);
        lines.add(line);
        PrepaidODRequestDataLines line2 = new PrepaidODRequestDataLines();
        line.setFlow("NSE");
        lines.add(line2);
        PrepaidODRequestDataLines line3 = new PrepaidODRequestDataLines();
        line.setFlow("NSE");
        lines.add(line3);
        redisData.setLines(lines);

        RemoveLinesPEGAResponse pegaResponse = helper.convertToPEGAResponse(request, true, redisData);

        Assert.assertNotNull(pegaResponse);

    }

    @Test
    public void testConvertToPEGAResponse_checkoutFlagFalse(){
        RemoveLinesPEGARequest request = new RemoveLinesPEGARequest();
        RemoveLinesServiceBody body = new RemoveLinesServiceBody();
        RemoveLinesServiceRequest br = new RemoveLinesServiceRequest();
        RemoveLinesContext ctx = new RemoveLinesContext();
        CartServiceCartInfo ff = new CartServiceCartInfo();
        Line Lineobj=new Line();
        Lineobj.setNpaNxx("123");
        Line[] linesArr=new Line[1];
        linesArr[0]=Lineobj;
        ff.setLines(linesArr);
        ctx.setCartInfo(ff);
        ContextInfo b = new ContextInfo();
        ctx.setContextInfo(b);
        CartServiceCustomerInfo cin = new CartServiceCustomerInfo();
        cin.setMtn("newLine1");
        cin.setProcessingMTN("newLine1");
        ctx.setCustomerInfo(cin);
        br.setContext(ctx);
        body.setServiceRequest(br);
        request.setServiceBody(body);
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        request.setServiceHeader(serviceHeader);

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setFlow("NSE");
        line.setCheckoutFlag(true);
        line.setCompletedProcessSteps(completedProcessSteps);
        lines.add(line);
        PrepaidODRequestDataLines line2 = new PrepaidODRequestDataLines();
        line2.setFlow("NSE");
        line2.setCheckoutFlag(true);
        lines.add(line2);
        PrepaidODRequestDataLines line3 = new PrepaidODRequestDataLines();
        line3.setFlow("NSE");
        line3.setCheckoutFlag(true);
        lines.add(line3);
        redisData.setLines(lines);

        RemoveLinesPEGAResponse pegaResponse = helper.convertToPEGAResponse(request, true, redisData);

        Assert.assertNotNull(pegaResponse);

    }

    @Test
    public void testConvertToPEGAResponseIsOrderUpdateFalse() throws Exception {
        RemoveLinesPEGARequest request = new RemoveLinesPEGARequest();
        RemoveLinesServiceBody body = new RemoveLinesServiceBody();
        RemoveLinesServiceRequest br = new RemoveLinesServiceRequest();
        RemoveLinesContext ctx = new RemoveLinesContext();
        CartServiceCartInfo ff = new CartServiceCartInfo();
        ctx.setCartInfo(ff);
        ContextInfo b = new ContextInfo();
        //  b.set
        ctx.setContextInfo(b);
        CartServiceCustomerInfo cin = new CartServiceCustomerInfo();
        cin.setMtn("newLine1");
        cin.setProcessingMTN("newLine1");
        ctx.setCustomerInfo(cin);
        br.setContext(ctx);
        body.setServiceRequest(br);
        request.setServiceBody(body);
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        request.setServiceHeader(serviceHeader);
        //etServiceBody().getServiceRequest().getContext().getCustomerInfo().getProcessingMTN()
        PrepaidODRequestData redisData = new PrepaidODRequestData();

        RemoveLinesPEGAResponse pegaResponse = helper.convertToPEGAResponse(request, false, redisData);

        Assert.assertNotNull(pegaResponse);

    }
    @Test
    public void testGetCustomerinfo() throws Exception {
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        RemoveLinesPEGARequest request = mapper.readValue(requestString, RemoveLinesPEGARequest.class);
        RemoveLinesPEGAResponse response = mapper.readValue(responseString, RemoveLinesPEGAResponse.class);

        RemoveLinesServiceRequest serviceRequest = request.getServiceBody().getServiceRequest();
        CartServiceServiceHeader serviceHeader = request.getServiceHeader();// request.setServiceHeader(serviceHeader);
        RemoveLinesServiceBody serviceBody = request.getServiceBody();
        RemoveLinesContext context = request.getServiceBody().getServiceRequest().getContext();

        CartServiceCustomerInfo customerInfo = request.getServiceBody().getServiceRequest().getContext().getCustomerInfo();
        context.setCustomerInfo(customerInfo);
        ProcessMTNList[] ptnList = new ProcessMTNList[2];
        ProcessMTNList ptn1 = new ProcessMTNList();
        ProcessMTNList ptn2 = new ProcessMTNList();
        ptnList[0] = ptn1;
        ptnList[1] = ptn2;
        context.setProcessMTNList(ptnList);
        context.setContextInfo(context.getContextInfo());
        context.setCartInfo(context.getCartInfo());
        PrepaidODRequestData redisData = new PrepaidODRequestData();


        Method method = PrepayAdaptorRemoveLinesHelper.class
                .getDeclaredMethod("getCustomerinfo",
                        RemoveLinesPEGARequest.class, PrepaidODRequestData.class);
        method.setAccessible(true);
        Object justResponse = method.invoke(helper, request, redisData);
        Assert.assertNotNull(response);
    }

    @Test
    public void testGetCustomerinfoNonEmptyRedisData() throws Exception {
        //RemoveLinesPEGARequest request = new RemoveLinesPEGARequest();

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        RemoveLinesPEGARequest request = mapper.readValue(requestString, RemoveLinesPEGARequest.class);
        RemoveLinesPEGAResponse response = mapper.readValue(responseString, RemoveLinesPEGAResponse.class);

        RemoveLinesServiceRequest serviceRequest = request.getServiceBody().getServiceRequest();
        CartServiceServiceHeader serviceHeader = request.getServiceHeader();// request.setServiceHeader(serviceHeader);
        RemoveLinesServiceBody serviceBody = request.getServiceBody();
        RemoveLinesContext context = request.getServiceBody().getServiceRequest().getContext();

        CartServiceCustomerInfo customerInfo = request.getServiceBody().getServiceRequest().getContext().getCustomerInfo();
        context.setCustomerInfo(customerInfo);
        ProcessMTNList[] ptnList = new ProcessMTNList[2];
        ProcessMTNList ptn1 = new ProcessMTNList();
        ProcessMTNList ptn2 = new ProcessMTNList();
        ptnList[0] = ptn1;
        ptnList[1] = ptn2;
        context.setProcessMTNList(ptnList);
        context.setContextInfo(context.getContextInfo());
        context.setCartInfo(context.getCartInfo());
        PrepaidODRequestData redisData = getRedisData();


        Method method = PrepayAdaptorRemoveLinesHelper.class
                .getDeclaredMethod("getCustomerinfo",
                        RemoveLinesPEGARequest.class, PrepaidODRequestData.class);
        method.setAccessible(true);
        Object justResponse = method.invoke(helper, request, redisData);
        Assert.assertNotNull(response);
    }


}
