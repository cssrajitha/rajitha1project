package onevz.soe.prepay.adaptor.cart.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.model.updateBarcode.UpdateBarcodeBarcodeId;
import onevz.soe.cart.requests.UpdateBarCodePEGARequest;
import onevz.soe.cart.responses.UpdateBarCodePEGAResponse;
import onevz.soe.cart.ui.common.CartInfo;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.common.UpdateBarCodeData;
import onevz.soe.cart.ui.requests.UpdateBarcodeUIRequest;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.common.model.PrepaidODRequestDataAccessorySkuIds;
import onevz.soe.common.model.PrepaidODRequestDataLines;
import onevz.soe.prepay.adaptor.cart.model.cart.vo.UpdateBarcodePrepayOdRequest;
import onevz.soe.prepay.adaptor.cart.model.cart.vo.UpdateBarcodePrepayOdResponse;
import org.junit.Assert;
import org.junit.Test;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class PrepayUpdateBarcodeFormatterUtilTest {

    ObjectMapper mapper = new ObjectMapper();

    private PrepaidODRequestData getRedisData(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        lines.add(line);

        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        line.setAccessorySkuIds(accessorySkuIds);
        redisData.setLines(lines);

        return redisData;
    }

    String requestString = "{\n" +
            "  \"serviceHeader\": {\n" +
            "    \"clientId\": \"VZW-DOTCOM\",\n" +
            "    \"statusMsg\": \"PEGA generated message\",\n" +
            "    \"serviceName\": \"SalesOrderPurchase\",\n" +
            "    \"userId\": \"\",\n" +
            "    \"statusCode\": \"0\",\n" +
            "    \"sessionId\": \"\",\n" +
            "    \"correlationId\": \"soe-cart-2022.01.25.18.58.21-916.8608036659715\"\n" +
            "  },\n" +
            "  \"serviceBody\": {\n" +
            "    \"serviceRequest\": {\n" +
            "      \"context\": {\n" +
            "        \"caseId\": \"SOP-817289281-E01\",\n" +
            "        \"contextInfo\": {\n" +
            "          \"callReason\": \"SalesOrderPurchase\",\n" +
            "          \"processStep\": \"PlanSelection\",\n" +
            "          \"processAction\": \"addPlan\",\n" +
            "          \"intent\": \"Inline-CPC\"\n" +
            "        },\n" +
            "        \"customerInfo\": {\n" +
            "          \"throttleName\": \"|AccessoryInterestialProspect|\",\n" +
            "          \"bucketAllocator\": \"BAU\",\n" +
            "          \"customerType\": \"N\",\n" +
            "          \"accountNumber\": \"\",\n" +
            "          \"cartCreator\": \"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\n" +
            "          \"processingMTN\": \"newLine1\",\n" +
            "          \"registerNumber\": 0,\n" +
            "          \"mtnFlow\": \"P\",\n" +
            "          \"globalId\": \"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"\n" +
            "        },\n" +
            "        \"cartInfo\": {\n" +
            "          \"retrieveFeatureLossReferenceData\": \"Y\",\n" +
            "          \"parentMtn\": \"\",\n" +
            "          \"cartItemCount\": 0,\n" +
            "          \"cartId\": \"b83940f5-0276-407f-947f-c2a2fa819afe\",\n" +
            "          \"itemType\": \"PLAN\",\n" +
            "          \"intendType\": \"NSE\",\n" +
            "          \"action\": \"UPDATE\",\n" +
            "          \"lines\": [\n" +
            "            {\n" +
            "              \"plan\": {\n" +
            "                \"id\": \"50427\",\n" +
            "                \"isRecommendedPlan\": false\n" +
            "              },\n" +
            "              \"mtn\": \"newLine1\",\n" +
            "              \"editSim\": false,\n" +
            "              \"lineWithSkipMDN\": false,\n" +
            "              \"inWithVerizonOpted\": false,\n" +
            "              \"protectionNotRequired\": false\n" +
            "            }\n" +
            "          ],\n" +
            "          \"effectiveDate\": \"\",\n" +
            "          \"checkAutoPayDiscountEligible\": \"N\",\n" +
            "          \"discountPromoTotal\": 0,\n" +
            "          \"registerNumber\": 0,\n" +
            "          \"protectionNotRequired\": false\n" +
            "        }\n" +
            "      }\n" +
            "    }\n" +
            "  }\n" +
            "}";

    @Test
    public void formatUpdateBarcodeRequestTest() throws IOException {

        UpdateBarCodePEGARequest updateBarCodePEGARequest = this.mapper.readValue(this.requestString,UpdateBarCodePEGARequest.class);

        UpdateBarcodePrepayOdRequest response = PrepayUpdateBarcodeFormatterUtil.formatUpdateBarcodeRequest(updateBarCodePEGARequest);
        Assert.assertNotNull(response);
    }


    @Test
    public void formatUpdateBarcodeRequestTest1() throws JsonProcessingException {

        UpdateBarCodePEGARequest updateBarCodePEGARequest = this.mapper.readValue(this.requestString,UpdateBarCodePEGARequest.class);


        CartInfo cartInfo = new CartInfo();
        cartInfo.setAccountNumber("account number");
        cartInfo.setCartId("cartId");
        cartInfo.setProcessAction("processAction");
        cartInfo.setCartCreator("creator");
        cartInfo.setProcessingMTN("mtn");
        cartInfo.setIntendType("NSEACC");
        cartInfo.setExpressCheckout(true);

        List<UpdateBarcodeBarcodeId> updateBarcodeBarcodeIdList = new ArrayList<>();
        UpdateBarcodeBarcodeId updateBarcodeBarcodeId = new UpdateBarcodeBarcodeId();
        updateBarcodeBarcodeId.setBarCodeId("1234");
        updateBarcodeBarcodeIdList.add(updateBarcodeBarcodeId);
        cartInfo.setBarCodeIds(updateBarcodeBarcodeIdList);
        updateBarCodePEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().setBarCodeIds(updateBarcodeBarcodeIdList);

        UpdateBarcodePrepayOdRequest response = PrepayUpdateBarcodeFormatterUtil.formatUpdateBarcodeRequest(updateBarCodePEGARequest);
        Assert.assertNotNull(response);
    }


    @Test
    public void formatUpdateBarcodeResponseTest() throws IOException {
        UpdateBarcodePrepayOdResponse updateBarcodePrepayOdResponse = new UpdateBarcodePrepayOdResponse();
        updateBarcodePrepayOdResponse.setStatusCode("00");
        updateBarcodePrepayOdResponse.setStatusMessage("SUCCESS");
        UpdateBarCodePEGAResponse response = PrepayUpdateBarcodeFormatterUtil.formatUpdateBarcodeResponse(updateBarcodePrepayOdResponse);
        Assert.assertNotNull(response);
    }
    @Test
    public void formatUpdateBarcodeResponseTest1() throws IOException {
        UpdateBarcodePrepayOdResponse updateBarcodePrepayOdResponse = new UpdateBarcodePrepayOdResponse();
        updateBarcodePrepayOdResponse.setStatusCode("01");
        updateBarcodePrepayOdResponse.setStatusMessage("FAILED");
        UpdateBarCodePEGAResponse response = PrepayUpdateBarcodeFormatterUtil.formatUpdateBarcodeResponse(updateBarcodePrepayOdResponse);
        Assert.assertNotNull(response);
    }
}
