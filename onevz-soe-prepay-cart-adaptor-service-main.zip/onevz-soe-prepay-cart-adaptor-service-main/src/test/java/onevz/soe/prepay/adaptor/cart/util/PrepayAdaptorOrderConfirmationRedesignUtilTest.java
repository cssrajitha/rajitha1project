package onevz.soe.prepay.adaptor.cart.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.activation.cxp.response.OrderConfirmationCXPResponse;
import onevz.soe.orderprocess.model.checkoutdetails.*;
import onevz.soe.orderprocess.response.cxp.CheckoutDetailsCXPResponse;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
public class PrepayAdaptorOrderConfirmationRedesignUtilTest {

    ObjectMapper mapper = new ObjectMapper();

    @Test
    public void formatOrderConfirmationCXPResponseTest() throws JsonProcessingException {

        String checkoutResponse=FileReaderUtil.readFromFile("data/Get_Checkout_Details_CXPResponse.json");
        CheckoutDetailsCXPResponse response= this.mapper.readValue(checkoutResponse,CheckoutDetailsCXPResponse.class);
        response.getData().getCart().getLineDetails().setNumOfAccessoryAndDeviceItemsInCart(2);
        String orderDetailsString = "{\"managerApprovalRequired\":false,\"orderNumber\":98185975024,\"chargeSummary\":[{\"amount\":0,\"chargeType\":\"One time activation fee\"}],\"splitShipmentIndicator\":false,\"runningTotalDueToday\":1823.88,\"customerType\":\"N\",\"totalDueMonthly\":140,\"assistanceOptedByCustomer\":false,\"subTotalDueMonthly\":140,\"totalDueMonthlyAfterDiscounts\":140,\"nextMonthBillTotal\":0,\"totalNonBTACharges\":0,\"subTotalDueTodayWithoutUpgradeFee\":1699.98,\"totalDueTodayFlag\":false,\"orderList\":[{\"orderNumber\":98185975024,\"digitalOrderId\":\"98185975024\",\"orderActivityType\":\"NSE\"}],\"readOnly\":false,\"spocs\":{\"notificationOptions\":{\"primaryEmailId\":\"mayuresh.barde@verizon.com\"}},\"isSingleModConnectedDevice\":false,\"billingState\":\"GA\",\"attachmentCompleted\":false,\"subTotalDueToday\":1699.98,\"totalBTAEligibleAmount\":1823.88,\"cartTotalDiscounts\":{\"totalDiscount\":\"30.0\",\"totalDevicesDiscount\":0,\"totalAccessoriesDiscount\":0,\"autoPayTotalAmount\":140,\"totalAutoPayDiscount\":0,\"totalMultiLineDiscount\":30,\"smartphoneTotalMLDiscount\":0},\"orderChannelId\":\"VZW-DOTCOM\",\"totalTaxAmount\":123.9,\"totalDueToday\":1823.88,\"autoPaySavings\":0,\"autoPayEnabled\":false}";
        OrderDetails orderDetails= this.mapper.readValue(orderDetailsString,OrderDetails.class);
        response.getData().getCart().setOrderDetails(orderDetails);
        response.getData().getCart().getOrderDetails().getCartTotalDiscounts().setSmartphoneTotalMLDiscount(20D);
        response.getData().getCart().getLineDetails().getLineInfo().forEach(cartLineInfo->
                cartLineInfo.getServiceInfo().getPlanDetails().setPlanMLPrice("20"));
        response.getData().getCart().getLineDetails().getLineInfo().get(0).getNumberShareDeviceInfo().setLineNo("657-897-XXXX");
        response.getData().getCart().getLineDetails().getLineInfo().get(0).getNumberShareDeviceInfo().setName("iphone 12");
        List<CartPaymentInfo> list=new ArrayList<>();
        CartPaymentInfo cartPaymentInfo=new CartPaymentInfo();
        RefillCardPayment refillCardPayment = new RefillCardPayment();
        PaypalPaymentAuthenticateDetails paypalAuthDetails = new PaypalPaymentAuthenticateDetails();
        paypalAuthDetails.setPayal_currencyCode("USD");
        paypalAuthDetails.setPaypal_orderId("123");
        paypalAuthDetails.setPaypal_processorUserEmail("test@test.com");
        paypalAuthDetails.setPaypal_processorBillingCity("Dallas");
        PaypalPaymentDetails paypalPaymentDetails = new PaypalPaymentDetails();
        paypalPaymentDetails.setPaypalPaymentAuthenticateDetails(paypalAuthDetails);
        List<AppliedRC> appliedRCList = new ArrayList<>();
        AppliedRC appliedRC = new AppliedRC();
        appliedRC.setRefillCardNumber("XXXXXXX3418");
        appliedRC.setBalance(0.0);
        appliedRC.setAmountApplied(35.0);
        appliedRC.setPaymentGrpId("S8b9eb24867ad80081d2f970b1871719a{s3}_pin_517725890");
        appliedRCList.add(appliedRC);
        refillCardPayment.setAppliedRCList(appliedRCList);
        refillCardPayment.setAmountCreditFromRC(0.0);
        refillCardPayment.setRemainingDueFromRC(25.0);
        CreditCardPayment cardPayment=new CreditCardPayment();
        cardPayment.setCardType("credit");
        cartPaymentInfo.setPaymentType("CR");
        cartPaymentInfo.setPaymRegisterNum("2403");
        cartPaymentInfo.setPaymentSequence(23);
        cartPaymentInfo.setPaymentAmount(2);
        cartPaymentInfo.setCreditCardDetails(cardPayment);
        cartPaymentInfo.setPaypalPaymentDetails(paypalPaymentDetails);
        cartPaymentInfo.setRefillCardPaymentDetails(refillCardPayment);
        list.add(cartPaymentInfo);
        response.getData().getCart().getLineDetails().setPayments(list);
        List<TaxDetailInfo> taxDetailInfos=new ArrayList<>();
        TaxDetailInfo taxDetailInfo=new TaxDetailInfo();
        taxDetailInfo.setTaxAmount("23400");
        taxDetailInfos.add(taxDetailInfo);
        Address serviceInfo=new Address();
        serviceInfo.setAddress1("address1");
        DiscountSummary summary=new DiscountSummary();
        NbxInfo nbxInfo=new NbxInfo();
        nbxInfo.setDirectApply("directApply");
        summary.setAutoPayTotalAmount(22.0);
        response.getData().getCart().getOrderDetails().setCartTotalDiscounts(summary);
        response.getData().getCart().getOrderDetails().setNbxInfo(nbxInfo);
        response.getData().getCart().getLineDetails().getLineInfo().get(0).getItemsInfo().get(0).getCartItems().getCartItem().get(0).setTaxDetailsList(taxDetailInfos);
        response.getData().getCart().getLineDetails().getLineInfo().get(0).getServiceInfo().setServiceAddress(serviceInfo);
        OrderConfirmationCXPResponse orderConfirmationCXPResponse=PrepayAdaptorOrderConfirmationRedesignUtil.formatOrderConfirmationCXPResponse(response);
        Assert.assertNotNull(orderConfirmationCXPResponse);

    }
    @Test
    public void formatOrderConfirmationCXPResponseTest2() throws JsonProcessingException {

        String checkoutResponse=FileReaderUtil.readFromFile("data/Get_Checkout_Details_CXPResponse.json");
        CheckoutDetailsCXPResponse response= this.mapper.readValue(checkoutResponse,CheckoutDetailsCXPResponse.class);
        response.getData().getCart().getLineDetails().setNumOfAccessoryAndDeviceItemsInCart(2);
        List<CartPaymentInfo> list=new ArrayList<>();
        CartPaymentInfo cartPaymentInfo=new CartPaymentInfo();
        RefillCardPayment refillCardPayment = new RefillCardPayment();
        List<AppliedRC> appliedRCList = new ArrayList<>();
        AppliedRC appliedRC = new AppliedRC();
        appliedRC.setRefillCardNumber("XXXXXXX3418");
        appliedRC.setBalance(0.0);
        appliedRC.setAmountApplied(35.0);
        appliedRC.setPaymentGrpId("S8b9eb24867ad80081d2f970b1871719a{s3}_pin_517725890");
        appliedRCList.add(appliedRC);
        refillCardPayment.setAppliedRCList(appliedRCList);
        refillCardPayment.setAmountCreditFromRC(0.0);
        refillCardPayment.setRemainingDueFromRC(25.0);
        CreditCardPayment cardPayment=new CreditCardPayment();
        cardPayment.setCardType("credit");
        cartPaymentInfo.setPaymentType("CR");
        cartPaymentInfo.setPaymRegisterNum("2403");
        cartPaymentInfo.setPaymentSequence(23);
        cartPaymentInfo.setPaymentAmount(2);
        cartPaymentInfo.setCreditCardDetails(cardPayment);
        cartPaymentInfo.setRefillCardPaymentDetails(refillCardPayment);
        list.add(cartPaymentInfo);
        response.getData().getCart().getLineDetails().setPayments(list);
        response.getData().getCart().getLineDetails().getLineInfo().get(0).setMtnDetails(null);
        response.getData().getCart().getLineDetails().getLineInfo().get(0).setNumberShareDeviceInfo(null);
        response.getData().getCart().getLineDetails().getLineInfo().get(0).setOneTimeCharges(null);
        response.getData().getCart().getOrderDetails().setOrderList(null);
        response.getData().getCart().getOrderDetails().getSpocs().setNotificationOptions(null);
        response.getData().setEnableFamilyPricing(true);
        response.getData().getCart().setHolidayReturnPolicyEnabled(true);
        response.getData().getCart().setEnableIphoneSEPromo(true);
        List<TaxDetailInfo> taxDetailInfos=new ArrayList<>();
        TaxDetailInfo taxDetailInfo=new TaxDetailInfo();
        taxDetailInfo.setTaxAmount("23400");
        taxDetailInfos.add(taxDetailInfo);
        Address serviceInfo=new Address();
        serviceInfo.setAddress1("address1");
        response.getData().getCart().getOrderDetails().setCartTotalDiscounts(null);
        response.getData().getCart().getLineDetails().getLineInfo().get(0).getItemsInfo().get(0).getCartItems().getCartItem().get(0).setTaxDetailsList(taxDetailInfos);
        response.getData().getCart().getLineDetails().getLineInfo().get(0).getServiceInfo().setServiceAddress(serviceInfo);
        OrderConfirmationCXPResponse orderConfirmationCXPResponse=PrepayAdaptorOrderConfirmationRedesignUtil.formatOrderConfirmationCXPResponse(response);
        Assert.assertNotNull(orderConfirmationCXPResponse);

    }
    @Test
    public void formatOrderConfirmationCXPResponseTest3() throws JsonProcessingException {

        String checkoutResponse=FileReaderUtil.readFromFile("data/Get_Checkout_Details_CXPResponse_2.json");
        CheckoutDetailsCXPResponse response= this.mapper.readValue(checkoutResponse,CheckoutDetailsCXPResponse.class);
        List<CartPaymentInfo> list=new ArrayList<>();
        CartPaymentInfo cartPaymentInfo=new CartPaymentInfo();
        RefillCardPayment refillCardPayment = new RefillCardPayment();
        PaypalPaymentAuthenticateDetails paypalAuthDetails = new PaypalPaymentAuthenticateDetails();
        paypalAuthDetails.setPayal_currencyCode("USD");
        paypalAuthDetails.setPaypal_orderId("123");
        paypalAuthDetails.setPaypal_processorUserEmail("test@test.com");
        paypalAuthDetails.setPaypal_processorBillingCity("Dallas");
        PaypalPaymentDetails paypalPaymentDetails = new PaypalPaymentDetails();
        paypalPaymentDetails.setPaypalPaymentAuthenticateDetails(paypalAuthDetails);
        List<AppliedRC> appliedRCList = new ArrayList<>();
        AppliedRC appliedRC = new AppliedRC();
        appliedRC.setRefillCardNumber("XXXXXXX3418");
        appliedRC.setBalance(0.0);
        appliedRC.setAmountApplied(35.0);
        appliedRC.setPaymentGrpId("S8b9eb24867ad80081d2f970b1871719a{s3}_pin_517725890");
        appliedRCList.add(appliedRC);
        refillCardPayment.setAppliedRCList(appliedRCList);
        refillCardPayment.setAmountCreditFromRC(0.0);
        refillCardPayment.setRemainingDueFromRC(25.0);
        CreditCardPayment cardPayment=new CreditCardPayment();
        cardPayment.setCardType("credit");
        cartPaymentInfo.setPaymentType("CR");
        cartPaymentInfo.setPaymRegisterNum("2403");
        cartPaymentInfo.setPaymentSequence(23);
        cartPaymentInfo.setPaymentAmount(2);
        cartPaymentInfo.setCreditCardDetails(cardPayment);
        cartPaymentInfo.setPaypalPaymentDetails(paypalPaymentDetails);
        cartPaymentInfo.setRefillCardPaymentDetails(refillCardPayment);
        list.add(cartPaymentInfo);
        List<TaxDetailInfo> taxDetailInfos=new ArrayList<>();
        TaxDetailInfo taxDetailInfo=new TaxDetailInfo();
        taxDetailInfo.setTaxAmount("23400");
        taxDetailInfos.add(taxDetailInfo);
        Address serviceInfo=new Address();
        serviceInfo.setAddress1("address1");
        DiscountSummary summary=new DiscountSummary();
        summary.setAutoPayTotalAmount(22.0);
        OrderConfirmationCXPResponse orderConfirmationCXPResponse=PrepayAdaptorOrderConfirmationRedesignUtil.formatOrderConfirmationCXPResponse(response);
        Assert.assertNotNull(orderConfirmationCXPResponse);

    }
    @Test
    public void formatOrderConfirmationCXPResponseTest4() throws JsonProcessingException {


        CheckoutDetailsCXPResponse response=null;
        List<CartPaymentInfo> list=new ArrayList<>();
        CartPaymentInfo cartPaymentInfo=new CartPaymentInfo();
        RefillCardPayment refillCardPayment = new RefillCardPayment();
        PaypalPaymentAuthenticateDetails paypalAuthDetails = new PaypalPaymentAuthenticateDetails();
        paypalAuthDetails.setPayal_currencyCode("USD");
        paypalAuthDetails.setPaypal_orderId("123");
        paypalAuthDetails.setPaypal_processorUserEmail("test@test.com");
        paypalAuthDetails.setPaypal_processorBillingCity("Dallas");
        PaypalPaymentDetails paypalPaymentDetails = new PaypalPaymentDetails();
        paypalPaymentDetails.setPaypalPaymentAuthenticateDetails(paypalAuthDetails);
        List<AppliedRC> appliedRCList = new ArrayList<>();
        AppliedRC appliedRC = new AppliedRC();
        appliedRC.setRefillCardNumber("XXXXXXX3418");
        appliedRC.setBalance(0.0);
        appliedRC.setAmountApplied(35.0);
        appliedRC.setPaymentGrpId("S8b9eb24867ad80081d2f970b1871719a{s3}_pin_517725890");
        appliedRCList.add(appliedRC);
        refillCardPayment.setAppliedRCList(appliedRCList);
        refillCardPayment.setAmountCreditFromRC(0.0);
        refillCardPayment.setRemainingDueFromRC(25.0);
        CreditCardPayment cardPayment=new CreditCardPayment();
        cardPayment.setCardType("credit");
        cartPaymentInfo.setPaymentType("CR");
        cartPaymentInfo.setPaymRegisterNum("2403");
        cartPaymentInfo.setPaymentSequence(23);
        cartPaymentInfo.setPaymentAmount(2);
        cartPaymentInfo.setCreditCardDetails(cardPayment);
        cartPaymentInfo.setPaypalPaymentDetails(paypalPaymentDetails);
        cartPaymentInfo.setRefillCardPaymentDetails(refillCardPayment);
        list.add(cartPaymentInfo);
        List<TaxDetailInfo> taxDetailInfos=new ArrayList<>();
        TaxDetailInfo taxDetailInfo=new TaxDetailInfo();
        taxDetailInfo.setTaxAmount("23400");
        taxDetailInfos.add(taxDetailInfo);
        Address serviceInfo=new Address();
        serviceInfo.setAddress1("address1");
        DiscountSummary summary=new DiscountSummary();
        summary.setAutoPayTotalAmount(22.0);
        OrderConfirmationCXPResponse orderConfirmationCXPResponse=PrepayAdaptorOrderConfirmationRedesignUtil.formatOrderConfirmationCXPResponse(response);
        Assert.assertNotNull(orderConfirmationCXPResponse);

    }
    @Test
    public void formatOrderConfirmationCXPResponseTest5() throws JsonProcessingException {

        String checkoutResponse=FileReaderUtil.readFromFile("data/Get_Checkout_Details_CXPResponse_2.json");
        CheckoutDetailsCXPResponse response= this.mapper.readValue(checkoutResponse,CheckoutDetailsCXPResponse.class);
        response.setData(null);
        List<CartPaymentInfo> list=new ArrayList<>();
        CartPaymentInfo cartPaymentInfo=new CartPaymentInfo();
        RefillCardPayment refillCardPayment = new RefillCardPayment();
        PaypalPaymentAuthenticateDetails paypalAuthDetails = new PaypalPaymentAuthenticateDetails();
        paypalAuthDetails.setPayal_currencyCode("USD");
        paypalAuthDetails.setPaypal_orderId("123");
        paypalAuthDetails.setPaypal_processorUserEmail("test@test.com");
        paypalAuthDetails.setPaypal_processorBillingCity("Dallas");
        PaypalPaymentDetails paypalPaymentDetails = new PaypalPaymentDetails();
        paypalPaymentDetails.setPaypalPaymentAuthenticateDetails(paypalAuthDetails);
        List<AppliedRC> appliedRCList = new ArrayList<>();
        AppliedRC appliedRC = new AppliedRC();
        appliedRC.setRefillCardNumber("XXXXXXX3418");
        appliedRC.setBalance(0.0);
        appliedRC.setAmountApplied(35.0);
        appliedRC.setPaymentGrpId("S8b9eb24867ad80081d2f970b1871719a{s3}_pin_517725890");
        appliedRCList.add(appliedRC);
        refillCardPayment.setAppliedRCList(appliedRCList);
        refillCardPayment.setAmountCreditFromRC(0.0);
        refillCardPayment.setRemainingDueFromRC(25.0);
        CreditCardPayment cardPayment=new CreditCardPayment();
        cardPayment.setCardType("credit");
        cartPaymentInfo.setPaymentType("CR");
        cartPaymentInfo.setPaymRegisterNum("2403");
        cartPaymentInfo.setPaymentSequence(23);
        cartPaymentInfo.setPaymentAmount(2);
        cartPaymentInfo.setCreditCardDetails(cardPayment);
        cartPaymentInfo.setPaypalPaymentDetails(paypalPaymentDetails);
        cartPaymentInfo.setRefillCardPaymentDetails(refillCardPayment);
        list.add(cartPaymentInfo);
        List<TaxDetailInfo> taxDetailInfos=new ArrayList<>();
        TaxDetailInfo taxDetailInfo=new TaxDetailInfo();
        taxDetailInfo.setTaxAmount("23400");
        taxDetailInfos.add(taxDetailInfo);
        Address serviceInfo=new Address();
        serviceInfo.setAddress1("address1");
        DiscountSummary summary=new DiscountSummary();
        summary.setAutoPayTotalAmount(22.0);
        OrderConfirmationCXPResponse orderConfirmationCXPResponse=PrepayAdaptorOrderConfirmationRedesignUtil.formatOrderConfirmationCXPResponse(response);
        Assert.assertNotNull(orderConfirmationCXPResponse);

    }

    @Test
    public void formatOrderConfirmationCXPResponseTest7() throws JsonProcessingException {

        String checkoutResponse=FileReaderUtil.readFromFile("data/Get_Checkout_Details_CXPResponse.json");
        CheckoutDetailsCXPResponse response= this.mapper.readValue(checkoutResponse,CheckoutDetailsCXPResponse.class);
        response.getData().getCart().getLineDetails().setNumOfAccessoryAndDeviceItemsInCart(2);
        response.getData().getCart().setOrderDetails(null);
        List<CartPaymentInfo> list=new ArrayList<>();
        CartPaymentInfo cartPaymentInfo=new CartPaymentInfo();
        RefillCardPayment refillCardPayment = new RefillCardPayment();
        PaypalPaymentDetails paypalPaymentDetails = new PaypalPaymentDetails();
        paypalPaymentDetails.setPaypalPaymentAuthenticateDetails(null);
        List<AppliedRC> appliedRCList = new ArrayList<>();
        AppliedRC appliedRC = new AppliedRC();
        appliedRC.setRefillCardNumber("XXXXXXX3418");
        appliedRC.setBalance(0.0);
        appliedRC.setAmountApplied(35.0);
        appliedRC.setPaymentGrpId("S8b9eb24867ad80081d2f970b1871719a{s3}_pin_517725890");
        appliedRCList.add(appliedRC);
        refillCardPayment.setAppliedRCList(appliedRCList);
        refillCardPayment.setAmountCreditFromRC(0.0);
        refillCardPayment.setRemainingDueFromRC(25.0);
        CreditCardPayment cardPayment=new CreditCardPayment();
        cardPayment.setCardType("credit");
        cartPaymentInfo.setPaymentType("CR");
        cartPaymentInfo.setPaymRegisterNum("2403");
        cartPaymentInfo.setPaymentSequence(23);
        cartPaymentInfo.setPaymentAmount(2);
        cartPaymentInfo.setCreditCardDetails(cardPayment);
        cartPaymentInfo.setPaypalPaymentDetails(paypalPaymentDetails);
        cartPaymentInfo.setRefillCardPaymentDetails(refillCardPayment);
        list.add(cartPaymentInfo);
        response.getData().getCart().getLineDetails().setPayments(list);
        Address serviceInfo=new Address();
        serviceInfo.setAddress1("address1");
        response.getData().getCart().getLineDetails().getLineInfo().get(0).getItemsInfo().get(0).getCartItems().getCartItem().get(0).setTaxDetailsList(null);
        response.getData().getCart().getLineDetails().getLineInfo().get(0).getServiceInfo().setServiceAddress(serviceInfo);
        response.getData().getCart().getLineDetails().getLineInfo().get(0).getServiceInfo().setPlanDetails(null);
        OrderConfirmationCXPResponse orderConfirmationCXPResponse=PrepayAdaptorOrderConfirmationRedesignUtil.formatOrderConfirmationCXPResponse(response);
        Assert.assertNotNull(orderConfirmationCXPResponse);

    }

    @Test
    public void formatOrderConfirmationCXPResponseTest8() throws JsonProcessingException {

        String checkoutResponse=FileReaderUtil.readFromFile("data/Get_Checkout_Details_CXPResponse.json");
        CheckoutDetailsCXPResponse response= this.mapper.readValue(checkoutResponse,CheckoutDetailsCXPResponse.class);
        //response.getData().getCart().setLineDetails(null);
        response.getData().getCart().setCartHeader(null);
        List<CartPaymentInfo> list=new ArrayList<>();
        CartPaymentInfo cartPaymentInfo=new CartPaymentInfo();
        RefillCardPayment refillCardPayment = new RefillCardPayment();
        PaypalPaymentDetails paypalPaymentDetails = new PaypalPaymentDetails();
        paypalPaymentDetails.setPaypalPaymentAuthenticateDetails(null);
        List<AppliedRC> appliedRCList = new ArrayList<>();
        AppliedRC appliedRC = new AppliedRC();
        appliedRC.setRefillCardNumber("XXXXXXX3418");
        appliedRC.setBalance(0.0);
        appliedRC.setAmountApplied(35.0);
        appliedRC.setPaymentGrpId("S8b9eb24867ad80081d2f970b1871719a{s3}_pin_517725890");
        appliedRCList.add(appliedRC);
        refillCardPayment.setAppliedRCList(appliedRCList);
        refillCardPayment.setAmountCreditFromRC(0.0);
        refillCardPayment.setRemainingDueFromRC(25.0);
        CreditCardPayment cardPayment=new CreditCardPayment();
        cardPayment.setCardType("credit");
        cartPaymentInfo.setPaymentType("CR");
        cartPaymentInfo.setPaymRegisterNum("2403");
        cartPaymentInfo.setPaymentSequence(23);
        cartPaymentInfo.setPaymentAmount(2);
        cartPaymentInfo.setCreditCardDetails(cardPayment);
        cartPaymentInfo.setPaypalPaymentDetails(paypalPaymentDetails);
        cartPaymentInfo.setRefillCardPaymentDetails(refillCardPayment);
        list.add(cartPaymentInfo);
        response.getData().getCart().getLineDetails().setPayments(list);
        response.getData().getCart().getLineDetails().setNumOfAccessoryAndDeviceItemsInCart(2);
        Address serviceInfo=new Address();
        response.getData().getCart().getLineDetails().getLineInfo().get(0).getItemsInfo().get(0).getCartItems().getCartItem().get(0).setTaxDetailsList(null);
        response.getData().getCart().getLineDetails().getLineInfo().get(0).getServiceInfo().setServiceAddress(null);
        response.getData().getCart().getLineDetails().getLineInfo().get(0).getServiceInfo().setPlanDetails(null);
        response.getData().getCart().getLineDetails().getLineInfo().get(0).getItemsInfo().get(0).getCartItems().getCartItem().get(0).setDiscounts(null);
        response.getData().getCart().getLineDetails().getLineInfo().get(0).getServiceInfo().setSelectedFeaturesList(null);
        OrderConfirmationCXPResponse orderConfirmationCXPResponse=PrepayAdaptorOrderConfirmationRedesignUtil.formatOrderConfirmationCXPResponse(response);
        Assert.assertNotNull(orderConfirmationCXPResponse);

    }
}
