package onevz.soe.prepay.adaptor.cart.helper;

import com.fasterxml.jackson.databind.ObjectMapper;
import net.jcip.annotations.NotThreadSafe;
import onevz.soe.cart.model.common.Feature;
import onevz.soe.cart.model.common.FeatureAction;
import onevz.soe.cart.model.common.Line;
import onevz.soe.cart.requests.AddFeaturesPEGARequest;
import onevz.soe.cart.responses.AddFeaturesPEGAResponse;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.common.model.PrepaidODRequestDataAccessorySkuIds;
import onevz.soe.common.model.PrepaidODRequestDataLines;
import onevz.soe.prepay.adaptor.cart.util.FileReaderUtil;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_DATA;
import static org.mockito.Mockito.when;

@WebFluxTest
@RunWith(SpringJUnit4ClassRunner.class)
@NotThreadSafe
public class PrepayAdaptorAddFeaturesHelperTest {

    @Autowired
    PrepayAdaptorCartAddFeaturesHelper helper;

    @MockBean
    PrepayCartRedisHelper prepayCartRedisHelper;

    @MockBean
    PrepayAdaptorWebClient prepayAdaptorWebClient;

    @Autowired
    ObjectMapper mapper;

    protected PrepaidODRequestData redisData = null;
    protected AddFeaturesPEGARequest request = null;
    protected MockServerHttpRequest httpHeader = null;
    protected URI url = null;
    protected String requestString = null;
    protected String responseString = null;
    protected String mockRedisData = null;

    @Before
    public void setUp() throws IOException {

        this.responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";
        this.requestString = FileReaderUtil.readFromFile("request/addFeaturesPEGARequest.json");
        this.request = this.mapper.readValue(this.requestString, AddFeaturesPEGARequest.class);

        this.url = URI.create("http://localhost/testurl");
        this.httpHeader = MockServerHttpRequest.method(HttpMethod.POST, this.url).build();

    }

    private PrepaidODRequestData getRedisData(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setMtn("newLine1");
        line.setCheckoutFlag(true);
        lines.add(line);

        List<String> featureSkuIds = new ArrayList<>();
        featureSkuIds.add("sku3920521");
        featureSkuIds.add("feature13");
        //adding AccessoryskuId
        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        line.setAccessorySkuIds(accessorySkuIds);
        line.setFeatureSkuIds(featureSkuIds);

        redisData.setLines(lines);

        return redisData;
    }

    private PrepaidODRequestData getRedisData2(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setMtn("newLine1");
        line.setCheckoutFlag(true);
        lines.add(line);

        PrepaidODRequestDataLines line1 = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps1 = new ArrayList<>();
        completedProcessSteps1.add("Demo2");
        line1.setCompletedProcessSteps(completedProcessSteps);
        line1.setMtn("newLine2");
        line1.setPlanSorId("28365");
        line1.setCheckoutFlag(false);
        lines.add(line1);

        List<String> featureSkuIds = new ArrayList<>();
        featureSkuIds.add("feature13");
        //adding AccessoryskuId
        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        line.setAccessorySkuIds(accessorySkuIds);
        line.setFeatureSkuIds(featureSkuIds);

        redisData.setLines(lines);

        return redisData;
    }

    private PrepaidODRequestData getRedisData3(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setMtn("newLine1");
        line.setCheckoutFlag(true);
        lines.add(line);

        PrepaidODRequestDataLines line1 = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps1 = new ArrayList<>();
        completedProcessSteps1.add("Demo2");
        line1.setCompletedProcessSteps(completedProcessSteps);
        line1.setMtn("newLine2");
        line1.setPlanSorId("28365");
        line1.setCheckoutFlag(true);
        lines.add(line1);

        List<String> featureSkuIds = new ArrayList<>();
        featureSkuIds.add("feature13");
        //adding AccessoryskuId
        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        line.setAccessorySkuIds(accessorySkuIds);
        line.setFeatureSkuIds(featureSkuIds);

        redisData.setLines(lines);

        return redisData;
    }

    @Test
    public void addFeatureTest() throws IOException {
        this.redisData = getRedisData();
        this.mockRedisData = this.mapper.writeValueAsString(this.redisData);

        Line[] requestLines = this.request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
        Line requestLinesFirstLine = requestLines[0];
        FeatureAction featureAction = new FeatureAction();
        List<Feature> featureList = new ArrayList<>();
        Feature feature1 = new Feature();
        Feature feature2 = new Feature();
        feature1.setSkuId("sku3920521");
        featureList.add(feature1);
        featureList.add(feature2);
        featureAction.setRemove(featureList);
        requestLinesFirstLine.setFeatures(featureAction);

        when(this.prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(this.mockRedisData));
        when(this.prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(this.responseString));
        when(this.prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddFeaturesPEGAResponse>> responseMono = this.helper.addFeature(this.httpHeader, this.request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void addFeatureFeatureSKusNullTest() throws IOException {
        this.redisData = getRedisData();
        this.redisData.getLines().get(0).setFeatureSkuIds(new ArrayList<String>());
        this.mockRedisData = this.mapper.writeValueAsString(this.redisData);

        Line[] requestLines = this.request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
        Line requestLinesFirstLine = requestLines[0];
        FeatureAction featureAction = new FeatureAction();
        List<Feature> featureList = new ArrayList<>();
        Feature feature1 = new Feature();
        Feature feature2 = new Feature();
        feature1.setSkuId("sku3920521");
        featureList.add(feature1);
        featureList.add(feature2);
        featureAction.setAdd(featureList);
        requestLinesFirstLine.setFeatures(featureAction);

        when(this.prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(this.mockRedisData));
        when(this.prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(this.responseString));
        when(this.prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddFeaturesPEGAResponse>> responseMono = this.helper.addFeature(this.httpHeader, this.request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addFeatureFeatureSKusmobileHostspotTest() throws IOException {
        this.redisData = getRedisData();
        this.mockRedisData = this.mapper.writeValueAsString(this.redisData);

        Line[] requestLines = this.request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
        Line requestLinesFirstLine = requestLines[0];
        FeatureAction featureAction = new FeatureAction();
        List<Feature> featureList = new ArrayList<>();
        Feature feature1 = new Feature();
        Feature feature2 = new Feature();
        feature1.setSkuId("sku3920521");
        featureList.add(feature1);
        featureList.add(feature2);
        featureAction.setAdd(featureList);
        requestLinesFirstLine.setFeatures(featureAction);

        when(this.prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(this.mockRedisData));
        when(this.prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(this.responseString));
        when(this.prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddFeaturesPEGAResponse>> responseMono = this.helper.addFeature(this.httpHeader, this.request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addFeatureoneFeatureSkuTest() throws IOException {
        this.redisData = getRedisData2();
        this.mockRedisData = this.mapper.writeValueAsString(this.redisData);

        Line[] requestLines = this.request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
        Line requestLinesFirstLine = requestLines[0];
        FeatureAction featureAction = new FeatureAction();
        List<Feature> featureList = new ArrayList<>();
        Feature feature1 = new Feature();
        Feature feature2 = new Feature();
        feature1.setSkuId("sku3920521");
        featureList.add(feature1);
        featureList.add(feature2);
        featureAction.setAdd(featureList);
        requestLinesFirstLine.setFeatures(featureAction);

        when(this.prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(this.mockRedisData));
        when(this.prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(this.responseString));
        when(this.prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddFeaturesPEGAResponse>> responseMono = this.helper.addFeature(this.httpHeader, this.request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void addFeatureRedisMtn2Test() throws IOException {
        this.redisData = getRedisData();
        this.redisData.getLines().get(0).setMtn("newLine2");
        this.mockRedisData = this.mapper.writeValueAsString(this.redisData);

        Line[] requestLines = this.request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
        Line requestLinesFirstLine = requestLines[0];
        FeatureAction featureAction = new FeatureAction();
        List<Feature> featureList = new ArrayList<>();
        Feature feature1 = new Feature();
        Feature feature2 = new Feature();
        feature1.setSkuId("sku3920521");
        featureList.add(feature1);
        featureList.add(feature2);
        featureAction.setRemove(featureList);
        requestLinesFirstLine.setFeatures(featureAction);

        when(this.prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(this.mockRedisData));
        when(this.prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(this.responseString));
        when(this.prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddFeaturesPEGAResponse>> responseMono = this.helper.addFeature(this.httpHeader, this.request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addFeature2Test() throws IOException {
        this.redisData = getRedisData();
        this.mockRedisData = this.mapper.writeValueAsString(this.redisData);

        Line[] requestLines =  this.request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
        Line requestLinesFirstLine = requestLines[0];
        FeatureAction featureAction = new FeatureAction();
        List<Feature> featureList = new ArrayList<>();
        Feature feature1 = new Feature();
        Feature feature2 = new Feature();
        featureList.add(feature1);
        featureList.add(feature2);
        featureAction.setAdd(featureList);
        requestLinesFirstLine.setFeatures(featureAction);

        when(this.prepayCartRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(this.mockRedisData));
        when(this.prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(this.responseString));
        when(this.prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddFeaturesPEGAResponse>> responseMono = this.helper.addFeature(this.httpHeader, this.request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addFeatureRedisDataNullTest() throws IOException {
        this.redisData = getRedisData();
        this.mockRedisData = this.mapper.writeValueAsString(this.redisData);

        Line[] requestLines =  this.request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
        Line requestLinesFirstLine = requestLines[0];
        FeatureAction featureAction = new FeatureAction();
        List<Feature> featureList = new ArrayList<>();
        Feature feature1 = new Feature();
        Feature feature2 = new Feature();
        featureList.add(feature1);
        featureList.add(feature2);
        featureAction.setAdd(featureList);
        requestLinesFirstLine.setFeatures(featureAction);

        when(this.prepayCartRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.empty());
        when(this.prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(this.responseString));
        when(this.prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddFeaturesPEGAResponse>> responseMono = this.helper.addFeature(this.httpHeader, this.request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void addFeatureRemoveTest() throws IOException {
        this.redisData = getRedisData();
        this.mockRedisData = this.mapper.writeValueAsString(this.redisData);

        Line[] requestLines = this.request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
        Line requestLinesFirstLine = requestLines[0];
        FeatureAction featureAction = new FeatureAction();
        List<Feature> featureList = new ArrayList<>();
        Feature feature1 = new Feature();
        Feature feature2 = new Feature();
        featureList.add(feature1);
        featureList.add(feature2);
        featureAction.setRemove(featureList);
        requestLinesFirstLine.setFeatures(featureAction);

        when(this.prepayCartRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(this.mockRedisData));
        when(this.prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(this.responseString));
        when(this.prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddFeaturesPEGAResponse>> responseMono = this.helper.addFeature(this.httpHeader, this.request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addFeatureRemoveTest2() throws IOException {
        this.redisData = getRedisData2();
        this.mockRedisData = this.mapper.writeValueAsString(this.redisData);

        Line[] requestLines =  this.request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
        Line requestLinesFirstLine = requestLines[0];
        FeatureAction featureAction = new FeatureAction();
        List<Feature> featureList = new ArrayList<>();
        Feature feature1 = new Feature();
        feature1.setSkuId("feature13");
        Feature feature2 = new Feature();
        featureList.add(feature1);
        featureList.add(feature2);
        featureAction.setRemove(featureList);
        requestLinesFirstLine.setFeatures(featureAction);

        when(this.prepayCartRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(this.mockRedisData));
        when(this.prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(this.responseString));
        when(this.prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddFeaturesPEGAResponse>> responseMono = this.helper.addFeature(this.httpHeader, this.request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addFeatureFeatureListNullTest() throws IOException {
        this.redisData = getRedisData();
        this.mockRedisData = this.mapper.writeValueAsString(this.redisData);

        Line[] requestLines =  this.request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
        Line requestLinesFirstLine = requestLines[0];
        FeatureAction featureAction = new FeatureAction();
        requestLinesFirstLine.setFeatures(featureAction);

        when(this.prepayCartRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(this.mockRedisData));
        when(this.prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(this.responseString));
        when(this.prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddFeaturesPEGAResponse>> responseMono = this.helper.addFeature(this.httpHeader, this.request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addFeatureTestEmptyLines() throws IOException {
        this.redisData = getRedisData();
        this.mockRedisData = this.mapper.writeValueAsString(this.redisData);

        this.request.getServiceBody().getServiceRequest().getContext().getCartInfo().setLines(null);

        when(this.prepayCartRedisHelper.getDataFromRedisAsString(Mockito.any())).thenReturn(Mono.just(this.mockRedisData));
        when(this.prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(this.responseString));
        when(this.prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddFeaturesPEGAResponse>> responseMono = this.helper.addFeature(this.httpHeader, this.request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addFeatureRedisCheckoutFlagFalseTest() throws IOException {
        this.redisData = getRedisData();
        this.redisData.getLines().get(0).setCheckoutFlag(false);
        this.mockRedisData = this.mapper.writeValueAsString(this.redisData);

        Line[] requestLines =  this.request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
        Line requestLinesFirstLine = requestLines[0];
        FeatureAction featureAction = new FeatureAction();
        List<Feature> featureList = new ArrayList<>();
        Feature feature1 = new Feature();
        Feature feature2 = new Feature();
        feature1.setSkuId("sku3920521");
        featureList.add(feature1);
        featureList.add(feature2);
        featureAction.setRemove(featureList);
        requestLinesFirstLine.setFeatures(featureAction);

        when(this.prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(this.mockRedisData));
        when(this.prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(this.responseString));
        when(this.prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddFeaturesPEGAResponse>> responseMono = this.helper.addFeature(this.httpHeader, this.request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addFeaturesPEGAResponseInternalServerErrorTest() throws IOException {

        AddFeaturesPEGAResponse response = ReflectionTestUtils.invokeMethod(this.helper,"addFeaturesPEGAResponseInternalServerError");
        Assert.assertNotNull(response);
    }

    @Test
    public void addFeaturesPEGAResponseInvalidRequestErrorTest() throws IOException {

        AddFeaturesPEGAResponse response = ReflectionTestUtils.invokeMethod(this.helper,"addFeaturesPEGAResponseInvalidRequestError");
        Assert.assertNotNull(response);
    }

    @Test
    public void addFeatureEditCartResponseEntityErrorTest() throws IOException {
        this.redisData = getRedisData();
        this.redisData.getLines().get(0).setCheckoutFlag(true);
        this.mockRedisData = this.mapper.writeValueAsString(this.redisData);

        Line[] requestLines = this.request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
        Line requestLinesFirstLine = requestLines[0];
        FeatureAction featureAction = new FeatureAction();
        List<Feature> featureList = new ArrayList<>();
        Feature feature1 = new Feature();
        Feature feature2 = new Feature();
        feature1.setSkuId("sku3920521");
        featureList.add(feature1);
        featureList.add(feature2);
        featureAction.setAdd(featureList);
        requestLinesFirstLine.setFeatures(featureAction);

        when(this.prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(this.mockRedisData));
        when(this.prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<String>> webClientResponse =
                Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(this.responseString));
        when(this.prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddFeaturesPEGAResponse>> responseMono = this.helper.addFeature(this.httpHeader, this.request);
        StepVerifier.create(responseMono).assertNext(Assert::assertNotNull).expectComplete().verify();

    }

    @Test
    public void addFeatureJsonParsingExceptionTest() throws IOException {
        this.redisData = getRedisData();
        this.mockRedisData = this.mapper.writeValueAsString(this.redisData.toString());

        Line[] requestLines = this.request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
        Line requestLinesFirstLine = requestLines[0];
        FeatureAction featureAction = new FeatureAction();
        List<Feature> featureList = new ArrayList<>();
        Feature feature1 = new Feature();
        Feature feature2 = new Feature();
        feature1.setSkuId("sku3920521");
        featureList.add(feature1);
        featureList.add(feature2);
        featureAction.setAdd(featureList);
        requestLinesFirstLine.setFeatures(featureAction);

        when(this.prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(this.mockRedisData));
        when(this.prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<String>> webClientResponse =
                Mono.just(ResponseEntity.status(HttpStatus.OK).body(this.responseString));
        when(this.prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddFeaturesPEGAResponse>> responseMono = this.helper.addFeature(this.httpHeader, this.request);
        StepVerifier.create(responseMono).assertNext(Assert::assertNotNull).expectComplete().verify();

    }

    @Test
    public void addFeatureWithNullLinesFromRedisTest() throws IOException {
        this.redisData = getRedisData();
        this.redisData.setLines(null);
        this.mockRedisData = this.mapper.writeValueAsString(this.redisData);

        Line[] requestLines = this.request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
        Line requestLinesFirstLine = requestLines[0];
        FeatureAction featureAction = new FeatureAction();
        List<Feature> featureList = new ArrayList<>();
        Feature feature1 = new Feature();
        Feature feature2 = new Feature();
        feature1.setSkuId("sku3920521");
        featureList.add(feature1);
        featureList.add(feature2);
        featureAction.setAdd(featureList);
        requestLinesFirstLine.setFeatures(featureAction);

        when(this.prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(this.mockRedisData));
        when(this.prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<String>> webClientResponse =
                Mono.just(ResponseEntity.status(HttpStatus.OK).body(this.responseString));
        when(this.prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddFeaturesPEGAResponse>> responseMono = this.helper.addFeature(this.httpHeader, this.request);
        StepVerifier.create(responseMono).assertNext(Assert::assertNotNull).expectComplete().verify();

    }

    @Test
    public void addFeatureWithInValidResponseStringTest() throws IOException {
        String responseString = "{\"inValidResponseString\"}";
        this.redisData = getRedisData();
        this.mockRedisData = this.mapper.writeValueAsString(this.redisData);

        Line[] requestLines = this.request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
        Line requestLinesFirstLine = requestLines[0];
        FeatureAction featureAction = new FeatureAction();
        List<Feature> featureList = new ArrayList<>();
        Feature feature1 = new Feature();
        Feature feature2 = new Feature();
        featureList.add(feature1);
        featureList.add(feature2);
        featureAction.setAdd(featureList);
        requestLinesFirstLine.setFeatures(featureAction);

        when(this.prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(this.mockRedisData));
        when(this.prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<String>> webClientResponse =
                Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(responseString));
        when(this.prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddFeaturesPEGAResponse>> responseMono = this.helper.addFeature(this.httpHeader, this.request);
        StepVerifier.create(responseMono).assertNext(Assert::assertNotNull).expectComplete().verify();

    }

    @Test
    public void addFeatureResponseContextTest() throws IOException {
        this.redisData = getRedisData2();
        this.mockRedisData = this.mapper.writeValueAsString(this.redisData);

        Line[] requestLines = this.request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
        Line requestLinesFirstLine = requestLines[0];
        FeatureAction featureAction = new FeatureAction();
        List<Feature> featureList = new ArrayList<>();
        Feature feature1 = new Feature();
        Feature feature2 = new Feature();
        feature1.setSkuId("sku3920521");
        featureList.add(feature1);
        featureList.add(feature2);
        featureAction.setAdd(featureList);
        requestLinesFirstLine.setFeatures(featureAction);

        when(this.prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(this.mockRedisData));
        when(this.prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<String>> webClientResponse =
                Mono.just(ResponseEntity.status(HttpStatus.OK).body(this.responseString));
        when(this.prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddFeaturesPEGAResponse>> responseMono = this.helper.addFeature(this.httpHeader, this.request);
        StepVerifier.create(responseMono).assertNext(Assert::assertNotNull).expectComplete().verify();

    }

    @Test
    public void addFeaturesPEGARequestWithoutServiceHeaderTest() throws IOException {
        this.redisData = getRedisData();
        this.mockRedisData = this.mapper.writeValueAsString(this.redisData);

        this.request.setServiceHeader(null);
        Line[] requestLines = this.request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
        Line requestLinesFirstLine = requestLines[0];
        FeatureAction featureAction = new FeatureAction();
        List<Feature> featureList = new ArrayList<>();
        Feature feature1 = new Feature();
        Feature feature2 = new Feature();
        feature1.setSkuId("sku3920521");
        featureList.add(feature1);
        featureList.add(feature2);
        featureAction.setAdd(featureList);
        requestLinesFirstLine.setFeatures(featureAction);

        when(this.prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(this.mockRedisData));
        when(this.prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<String>> webClientResponse =
                Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(this.responseString));
        when(this.prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddFeaturesPEGAResponse>> responseMono = this.helper.addFeature(this.httpHeader, this.request);
        StepVerifier.create(responseMono).assertNext(Assert::assertNotNull).expectComplete().verify();

    }

    @Test
    public void addFeaturesPEGARequestWithNullCartInfoTest() throws IOException {
        this.redisData = getRedisData2();
        this.mockRedisData = this.mapper.writeValueAsString(this.redisData);

        this.request.getServiceBody().getServiceRequest().getContext().setCartInfo(null);

        when(this.prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(this.mockRedisData));
        when(this.prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<String>> webClientResponse =
                Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(this.responseString));
        when(this.prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddFeaturesPEGAResponse>> responseMono = this.helper.addFeature(this.httpHeader, this.request);
        StepVerifier.create(responseMono).assertNext(Assert::assertNotNull).expectComplete().verify();

    }

    @Test
    public void addFeaturesPEGARequestWithoutContextInfoTest() throws IOException {
        this.redisData = getRedisData2();
        this.mockRedisData = this.mapper.writeValueAsString(this.redisData);

        this.request.getServiceBody().getServiceRequest().getContext().setContextInfo(null);
        Line[] requestLines = this.request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
        Line requestLinesFirstLine = requestLines[0];
        FeatureAction featureAction = new FeatureAction();
        List<Feature> featureList = new ArrayList<>();
        Feature feature1 = new Feature();
        Feature feature2 = new Feature();
        feature1.setSkuId("sku3920521");
        featureList.add(feature1);
        featureList.add(feature2);
        featureAction.setAdd(featureList);
        requestLinesFirstLine.setFeatures(featureAction);

        when(this.prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(this.mockRedisData));
        when(this.prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<String>> webClientResponse =
                Mono.just(ResponseEntity.status(HttpStatus.OK).body(this.responseString));
        when(this.prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddFeaturesPEGAResponse>> responseMono = this.helper.addFeature(this.httpHeader, this.request);
        StepVerifier.create(responseMono).assertNext(Assert::assertNotNull).expectComplete().verify();

    }

    @Test
    public void addFeaturesPEGARequestWithoutCustomerInfoTest() throws IOException {
        this.redisData = getRedisData2();
        this.mockRedisData = this.mapper.writeValueAsString(this.redisData);

        this.request.getServiceBody().getServiceRequest().getContext().setCustomerInfo(null);
        Line[] requestLines = this.request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
        Line requestLinesFirstLine = requestLines[0];
        FeatureAction featureAction = new FeatureAction();
        List<Feature> featureList = new ArrayList<>();
        Feature feature1 = new Feature();
        Feature feature2 = new Feature();
        feature1.setSkuId("sku3920521");
        featureList.add(feature1);
        featureList.add(feature2);
        featureAction.setAdd(featureList);
        requestLinesFirstLine.setFeatures(featureAction);

        when(this.prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(this.mockRedisData));
        when(this.prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(false));

        Mono<ResponseEntity<String>> webClientResponse =
                Mono.just(ResponseEntity.status(HttpStatus.OK).body(this.responseString));
        when(this.prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddFeaturesPEGAResponse>> responseMono = this.helper.addFeature(this.httpHeader, this.request);
        StepVerifier.create(responseMono).assertNext(Assert::assertNotNull).expectComplete().verify();

    }

    @Test
    public void addFeaturesPEGARequestStatusMsgFailureTest() throws IOException {
        this.redisData = getRedisData3();
        this.mockRedisData = this.mapper.writeValueAsString(this.redisData);

        this.request.getServiceHeader().setStatusMsg("FAILURE");
        this.request.getServiceHeader().setStatusCode("01");
        Line[] requestLines = this.request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
        Line requestLinesFirstLine = requestLines[0];
        FeatureAction featureAction = new FeatureAction();
        List<Feature> featureList = new ArrayList<>();
        Feature feature1 = new Feature();
        Feature feature2 = new Feature();
        feature1.setSkuId("sku3920521");
        featureList.add(feature1);
        featureList.add(feature2);
        featureAction.setAdd(featureList);
        requestLinesFirstLine.setFeatures(featureAction);

        when(this.prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(this.mockRedisData));
        when(this.prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(false));

        Mono<ResponseEntity<String>> webClientResponse =
                Mono.just(ResponseEntity.status(HttpStatus.OK).body(this.responseString));
        when(this.prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddFeaturesPEGAResponse>> responseMono = this.helper.addFeature(this.httpHeader, this.request);
        StepVerifier.create(responseMono).assertNext(Assert::assertNotNull).expectComplete().verify();

    }

    @Test
    public void addFeatureWithFalseUpdateLineTest() throws IOException {
        this.redisData = getRedisData2();
        this.mockRedisData = this.mapper.writeValueAsString(this.redisData);

        Line[] requestLines = this.request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
        Line requestLinesFirstLine = requestLines[0];
        FeatureAction featureAction = new FeatureAction();
        List<Feature> featureList = new ArrayList<>();
        Feature feature1 = new Feature();
        Feature feature2 = new Feature();
        feature1.setSkuId("sku3920521");
        featureList.add(feature1);
        featureList.add(feature2);
        featureAction.setAdd(featureList);
        requestLinesFirstLine.setFeatures(featureAction);

        when(this.prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(this.mockRedisData));
        when(this.prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<String>> webClientResponse =
                Mono.just(ResponseEntity.status(HttpStatus.OK).body(this.responseString));
        when(this.prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        AddFeaturesPEGAResponse addFeaturesPEGAResponse =
                ReflectionTestUtils.invokeMethod(this.helper,"getAddFeaturePEGAResponse",false, this.redisData, this.request);
        Assert.assertNotNull(addFeaturesPEGAResponse);

    }



    @Test
    public void addFeaturesPEGARequestWithoutServiceBodyTest() throws IOException {
        this.redisData = getRedisData2();
        this.mockRedisData = this.mapper.writeValueAsString(this.redisData);

        this.request.setServiceBody(null);

        when(this.prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(this.mockRedisData));
        when(this.prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(false));

        Mono<ResponseEntity<String>> webClientResponse =
                Mono.just(ResponseEntity.status(HttpStatus.OK).body(this.responseString));
        when(this.prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddFeaturesPEGAResponse>> responseMono = this.helper.addFeature(this.httpHeader, this.request);
        StepVerifier.create(responseMono).assertNext(Assert::assertNotNull).expectComplete().verify();

    }

}
