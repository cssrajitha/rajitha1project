package onevz.soe.prepay.adaptor.cart.helper;

import com.fasterxml.jackson.databind.ObjectMapper;
import net.jcip.annotations.NotThreadSafe;
import onevz.soe.cart.model.addAccessory.AccessoryAction;
import onevz.soe.cart.model.common.Accessory;
import onevz.soe.cart.model.common.Line;
import onevz.soe.cart.requests.AddAccessoryPEGARequest;
import onevz.soe.cart.responses.AddAccessoriesPEGAResponse;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.common.model.PrepaidODRequestDataAccessorySkuIds;
import onevz.soe.common.model.PrepaidODRequestDataLines;
import onevz.soe.prepay.adaptor.cart.model.play.PrepaidODAddAccessoriesOutput;
import onevz.soe.prepay.adaptor.cart.model.play.PrepaidODAddAccessoriesResponse;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import onevz.soe.wsclient.prepay.webclient.model.PrepaidAdaptorWebClientRequest;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_DATA;
import static org.mockito.Mockito.when;

@WebFluxTest
@RunWith(SpringJUnit4ClassRunner.class)
@NotThreadSafe
public class PrepayAdaptorCartAddAccessoryHelperTest {

    @Autowired
    PrepayAdaptorCartAddAccessoryHelper helper;

    @MockBean
    PrepayCartRedisHelper prepayCartRedisHelper;

    @MockBean
    PrepayAdaptorWebClient prepayAdaptorWebClient;

    @Autowired
    ObjectMapper mapper;

    private PrepaidODRequestData getRedisData(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setMtn("newLine1");
        line.setCheckoutFlag(true);
        lines.add(line);

        //adding skuId
        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        line.setAccessorySkuIds(accessorySkuIds);
        line.getAccessorySkuIds().stream().findFirst().get().setSorId("random");

        redisData.setLines(lines);

        return redisData;
    }
    
    private PrepaidODRequestData getRedisData2(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setMtn("newLine1");
        line.setFlow("NSE");
        line.setCheckoutFlag(true);
        lines.add(line);

        //adding skuId
        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        line.setAccessorySkuIds(accessorySkuIds);
        line.getAccessorySkuIds().stream().findFirst().get().setSorId("random");

        redisData.setLines(lines);

        return redisData;
    }
    
    private PrepaidODRequestData getRedisData3(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setMtn("newLine1");
        line.setFlow("NSEBYOD");
        line.setCheckoutFlag(true);
        lines.add(line);

        //adding skuId
        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        line.setAccessorySkuIds(accessorySkuIds);
        line.getAccessorySkuIds().stream().findFirst().get().setSorId("random");

        redisData.setLines(lines);

        return redisData;
    }
    
    private PrepaidODRequestData getRedisData4(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setMtn("newLine1");
        line.setFlow("ESO");
        line.setCheckoutFlag(true);
        lines.add(line);

        //adding skuId
        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        line.setAccessorySkuIds(accessorySkuIds);
        line.getAccessorySkuIds().stream().findFirst().get().setSorId("random");

        redisData.setLines(lines);

        return redisData;
    }

    String requestString = "{\n" +
            "  \"serviceHeader\": {\n" +
            "    \"clientId\": \"VZW-DOTCOM\",\n" +
            "    \"statusMsg\": \"PEGA generated message\",\n" +
            "    \"serviceName\": \"SalesOrderPurchase\",\n" +
            "    \"userId\": \"\",\n" +
            "    \"statusCode\": \"0\",\n" +
            "    \"sessionId\": \"\",\n" +
            "    \"correlationId\": \"soe-cart-2022.01.25.18.58.21-916.8608036659715\"\n" +
            "  },\n" +
            "  \"serviceBody\": {\n" +
            "    \"serviceRequest\": {\n" +
            "      \"context\": {\n" +
            "        \"caseId\": \"SOP-817289281-E01\",\n" +
            "        \"contextInfo\": {\n" +
            "          \"callReason\": \"SalesOrderPurchase\",\n" +
            "          \"processStep\": \"PlanSelection\",\n" +
            "          \"processAction\": \"addPlan\",\n" +
            "          \"intent\": \"Inline-CPC\"\n" +
            "        },\n" +
            "        \"customerInfo\": {\n" +
            "          \"throttleName\": \"|AccessoryInterestialProspect|\",\n" +
            "          \"bucketAllocator\": \"BAU\",\n" +
            "          \"customerType\": \"N\",\n" +
            "          \"accountNumber\": \"\",\n" +
            "          \"cartCreator\": \"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\n" +
            "          \"processingMTN\": \"newLine1\",\n" +
            "          \"registerNumber\": 0,\n" +
            "          \"mtnFlow\": \"P\",\n" +
            "          \"globalId\": \"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"\n" +
            "        },\n" +
            "        \"cartInfo\": {\n" +
            "          \"retrieveFeatureLossReferenceData\": \"Y\",\n" +
            "          \"parentMtn\": \"\",\n" +
            "          \"cartItemCount\": 0,\n" +
            "          \"cartId\": \"b83940f5-0276-407f-947f-c2a2fa819afe\",\n" +
            "          \"itemType\": \"PLAN\",\n" +
            "          \"intendType\": \"NSE\",\n" +
            "          \"action\": \"UPDATE\",\n" +
            "          \"lines\": [\n" +
            "            {\n" +
            "              \"plan\": {\n" +
            "                \"id\": \"50427\",\n" +
            "                \"isRecommendedPlan\": false\n" +
            "              },\n" +
            "              \"mtn\": \"newLine1\",\n" +
            "              \"editSim\": false,\n" +
            "              \"lineWithSkipMDN\": false,\n" +
            "              \"inWithVerizonOpted\": false,\n" +
            "              \"protectionNotRequired\": false\n" +
            "            }\n" +
            "          ],\n" +
            "          \"effectiveDate\": \"\",\n" +
            "          \"checkAutoPayDiscountEligible\": \"N\",\n" +
            "          \"discountPromoTotal\": 0,\n" +
            "          \"registerNumber\": 0,\n" +
            "          \"protectionNotRequired\": false\n" +
            "        }\n" +
            "      }\n" +
            "    }\n" +
            "  }\n" +
            "}";

    @Test
    public void addAccessoryAddTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        AddAccessoryPEGARequest request = mapper.readValue(requestString, AddAccessoryPEGARequest.class);
//        Line[] lines=request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
//        AccessoryAction accessoryAction=new AccessoryAction();
//        Accessory[] add=new Accessory[0];
//        add[0].setDisplayName("charger");
//        accessoryAction.setAdd(add);
//        lines[0].setAccessories(accessoryAction);
        AddAccessoriesPEGAResponse response = mapper.readValue(responseString, AddAccessoriesPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddAccessoriesPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        PrepaidODRequestData redisData = getRedisData();
        String mockRedisData = mapper.writeValueAsString(redisData);

        //adding skuId
        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        accessorySkuIds.get(0).setQty("1");
        line.setAccessorySkuIds(accessorySkuIds);
        line.getAccessorySkuIds().stream().findFirst().get().setSorId("random");
        AccessoryAction accessoryAction = new AccessoryAction();
        Line[] requestLines = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();

        Accessory[] accessories = new Accessory[1];
        accessories[0] = new Accessory();
        accessories[0].setAccessoryBundle(true);
        accessories[0].setAccessorySkuID("accessorySkuId");
        accessories[0].setQty("1");
        accessories[0].setProductId("acc16240104");
        accessories[0].setDisplayName("charger");
        accessoryAction.setAdd(accessories);
        Arrays.stream(requestLines).findFirst().get().setAccessories(accessoryAction);
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, redisData)).thenReturn(Mono.just(true));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddAccessoriesPEGAResponse>> responseMono = helper.addAccessory(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));
    }

    @Test
    public void addAccessoryRedisExceptionAddTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        AddAccessoryPEGARequest request = mapper.readValue(requestString, AddAccessoryPEGARequest.class);
        URI url = URI.create("http://localhost/testurl");
        String mockRedisData = "Value";
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddAccessoriesPEGAResponse>> responseMono = helper.addAccessory(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));
    }



    @Test
    public void addAccessoryAddTest_500Error() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        AddAccessoryPEGARequest request = mapper.readValue(requestString, AddAccessoryPEGARequest.class);
        AddAccessoriesPEGAResponse response = mapper.readValue(responseString, AddAccessoriesPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddAccessoriesPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        PrepaidODRequestData redisData = getRedisData();
        String mockRedisData = mapper.writeValueAsString(redisData);

        //adding skuId
        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        accessorySkuIds.get(0).setQty("1");
        line.setAccessorySkuIds(accessorySkuIds);
        line.getAccessorySkuIds().stream().findFirst().get().setSorId("random");
        AccessoryAction accessoryAction = new AccessoryAction();
        Line[] requestLines = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();

        Accessory[] accessories = new Accessory[1];
        accessories[0] = new Accessory();
        accessories[0].setAccessoryBundle(true);
        accessories[0].setAccessorySkuID("accessorySkuId");
        accessories[0].setQty("1");
        accessories[0].setProductId("acc16240104");
        accessoryAction.setAdd(accessories);
        Arrays.stream(requestLines).findFirst().get().setAccessories(accessoryAction);
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, redisData)).thenReturn(Mono.just(true));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddAccessoriesPEGAResponse>> responseMono = helper.addAccessory(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));
    }

    @Test
    public void addAccessoryAddRedisDataNullTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        AddAccessoryPEGARequest request = mapper.readValue(requestString, AddAccessoryPEGARequest.class);
        AddAccessoriesPEGAResponse response = mapper.readValue(responseString, AddAccessoriesPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddAccessoriesPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        String mockRedisData = mapper.writeValueAsString(redisData);

        //adding skuId
        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        accessorySkuIds.get(0).setQty("1");
        line.setAccessorySkuIds(accessorySkuIds);
        line.getAccessorySkuIds().stream().findFirst().get().setSorId("random");
        AccessoryAction accessoryAction = new AccessoryAction();
        Line[] requestLines = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();

        Accessory[] accessories = new Accessory[1];
        accessories[0] = new Accessory();
        accessories[0].setAccessoryBundle(true);
        accessories[0].setAccessorySkuID("accessorySkuId");
        accessories[0].setQty("1");
        accessories[0].setProductId("acc16240104");
        accessoryAction.setAdd(accessories);
        Arrays.stream(requestLines).findFirst().get().setAccessories(accessoryAction);
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(""));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, redisData)).thenReturn(Mono.just(true));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddAccessoriesPEGAResponse>> responseMono = helper.addAccessory(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));
    }

    @Test
    public void addAccessoryRemoveTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        AddAccessoryPEGARequest request = mapper.readValue(requestString, AddAccessoryPEGARequest.class);
        AddAccessoriesPEGAResponse response = mapper.readValue(responseString, AddAccessoriesPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddAccessoriesPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        PrepaidODRequestData redisData = getRedisData();
        String mockRedisData = mapper.writeValueAsString(redisData);

        AccessoryAction accessoryAction = new AccessoryAction();

        Line[] requestLines = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();

        Accessory[] accessories = new Accessory[1];
        accessories[0] = new Accessory();
        accessories[0].setAccessoryBundle(true);
        accessories[0].setDisplayName("charger");
        accessoryAction.setRemove(accessories);
        Arrays.stream(requestLines).findFirst().get().setAccessories(accessoryAction);

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, redisData)).thenReturn(Mono.just(true));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddAccessoriesPEGAResponse>> responseMono = helper.addAccessory(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));
    }


    @Test
    public void addAccessoryRemoveTest_1() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        AddAccessoryPEGARequest request = mapper.readValue(requestString, AddAccessoryPEGARequest.class);
        AddAccessoriesPEGAResponse response = mapper.readValue(responseString, AddAccessoriesPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddAccessoriesPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        PrepaidODRequestData redisData = getRedisData();
        redisData.getLines().get(0).getAccessorySkuIds().get(0).setSorId("sorId");
        String mockRedisData = mapper.writeValueAsString(redisData);

        AccessoryAction accessoryAction = new AccessoryAction();

        Line[] requestLines = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();

        Accessory[] accessories = new Accessory[1];
        accessories[0] = new Accessory();
        accessories[0].setAccessoryBundle(true);
        accessories[0].setQty("1");
        accessories[0].setId("sorId");
        accessoryAction.setRemove(accessories);


        Arrays.stream(requestLines).findFirst().get().setAccessories(accessoryAction);

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, redisData)).thenReturn(Mono.just(true));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddAccessoriesPEGAResponse>> responseMono = helper.addAccessory(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));
    }


    @Test
    public void addAccessoryRemoveTest_2() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        AddAccessoryPEGARequest request = mapper.readValue(requestString, AddAccessoryPEGARequest.class);
        AddAccessoriesPEGAResponse response = mapper.readValue(responseString, AddAccessoriesPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddAccessoriesPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        PrepaidODRequestData redisData = getRedisData();
        redisData.getLines().get(0).getAccessorySkuIds().get(0).setSorId("sorId");
        String mockRedisData = mapper.writeValueAsString(redisData);

        AccessoryAction accessoryAction = new AccessoryAction();

        Line[] requestLines = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();

        Accessory[] accessories = new Accessory[1];
        accessories[0] = new Accessory();
        accessories[0].setAccessoryBundle(true);
        accessories[0].setQty("1");
        accessories[0].setId("sorId");
        accessories[0].setProductId("123");
        accessoryAction.setRemove(accessories);


        Arrays.stream(requestLines).findFirst().get().setAccessories(accessoryAction);

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, redisData)).thenReturn(Mono.just(true));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddAccessoriesPEGAResponse>> responseMono = helper.addAccessory(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));
    }
    @Test
    public void addAccessoryCheckoutFlagFalseWithRemoveTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        AddAccessoryPEGARequest request = mapper.readValue(requestString, AddAccessoryPEGARequest.class);
        AddAccessoriesPEGAResponse response = mapper.readValue(responseString, AddAccessoriesPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddAccessoriesPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        PrepaidODRequestData redisData = getRedisData();
        redisData.getLines().get(0).setCheckoutFlag(false);

        String mockRedisData = mapper.writeValueAsString(redisData);

        AccessoryAction accessoryAction = new AccessoryAction();

        Line[] requestLines = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();

        Accessory[] accessories = new Accessory[1];
        accessories[0] = new Accessory();
        accessories[0].setAccessoryBundle(true);
        accessoryAction.setRemove(accessories);
        Arrays.stream(requestLines).findFirst().get().setAccessories(accessoryAction);

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, redisData)).thenReturn(Mono.just(true));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddAccessoriesPEGAResponse>> responseMono = helper.addAccessory(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));
    }



    @Test
    public void addAccessoryCheckoutFlagFalseWithAddTest() throws IOException {
        ReflectionTestUtils.setField(helper,"prepayMaxAccessoriesPerLine",1);

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        AddAccessoryPEGARequest request = mapper.readValue(requestString, AddAccessoryPEGARequest.class);
        AddAccessoriesPEGAResponse response = mapper.readValue(responseString, AddAccessoriesPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddAccessoriesPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        PrepaidODRequestData redisData = getRedisData();
        redisData.getLines().get(0).setCheckoutFlag(false);
        redisData.getLines().get(0).getAccessorySkuIds().stream().findFirst().get().setQty("1");

        String mockRedisData = mapper.writeValueAsString(redisData);

        AccessoryAction accessoryAction = new AccessoryAction();

        Line[] requestLines = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();


        Accessory[] accessories = new Accessory[1];
        accessories[0] = new Accessory();
        accessories[0].setAccessoryBundle(true);
        accessories[0].setQty("1");
        accessoryAction.setAdd(accessories);
        Arrays.stream(requestLines).findFirst().get().setAccessories(accessoryAction);

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, redisData)).thenReturn(Mono.just(true));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddAccessoriesPEGAResponse>> responseMono = helper.addAccessory(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));
    }

    @Test
    public void addAccessoryCheckoutFlagFalseWithAddTest_1() throws IOException {


        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        AddAccessoryPEGARequest request = mapper.readValue(requestString, AddAccessoryPEGARequest.class);
        AddAccessoriesPEGAResponse response = mapper.readValue(responseString, AddAccessoriesPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddAccessoriesPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        PrepaidODRequestData redisData = getRedisData();
        redisData.getLines().get(0).setCheckoutFlag(false);
        redisData.getLines().get(0).getAccessorySkuIds().stream().findFirst().get().setQty("1");

        String mockRedisData = mapper.writeValueAsString(redisData);

        AccessoryAction accessoryAction = new AccessoryAction();

        Line[] requestLines = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();


        Accessory[] accessories = new Accessory[1];
        accessories[0] = new Accessory();
        accessories[0].setAccessoryBundle(true);
        accessories[0].setQty("1");
        accessoryAction.setAdd(accessories);
        Arrays.stream(requestLines).findFirst().get().setAccessories(accessoryAction);

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, redisData)).thenReturn(Mono.just(true));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddAccessoriesPEGAResponse>> responseMono = helper.addAccessory(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));
    }

    @Test
    public void addAccessoryCheckoutFlagFalseWithAddAccessoryTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        AddAccessoryPEGARequest request = mapper.readValue(requestString, AddAccessoryPEGARequest.class);
        AddAccessoriesPEGAResponse response = mapper.readValue(responseString, AddAccessoriesPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddAccessoriesPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        PrepaidODRequestData redisData = getRedisData();
        redisData.getLines().get(0).setCheckoutFlag(false);
        redisData.getLines().get(0).getAccessorySkuIds().stream().findFirst().get().setQty("10");

        String mockRedisData = mapper.writeValueAsString(redisData);

        AccessoryAction accessoryAction = new AccessoryAction();

        Line[] requestLines = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();


        Accessory[] accessories = new Accessory[1];
        accessories[0] = new Accessory();
        accessories[0].setAccessoryBundle(true);
        accessories[0].setQty("1");
        accessoryAction.setAdd(accessories);
        Arrays.stream(requestLines).findFirst().get().setAccessories(accessoryAction);

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, redisData)).thenReturn(Mono.just(true));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddAccessoriesPEGAResponse>> responseMono = helper.addAccessory(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));
    }

    //callODAddAccessories
    @Test
    public void callODAddAccessoriesTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        AddAccessoryPEGARequest request = mapper.readValue(requestString, AddAccessoryPEGARequest.class);
        AddAccessoriesPEGAResponse response = mapper.readValue(responseString, AddAccessoriesPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddAccessoriesPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        PrepaidODRequestData redisData = getRedisData();
        String mockRedisData = mapper.writeValueAsString(redisData);

        AccessoryAction accessoryAction = new AccessoryAction();

        Line[] requestLines = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
        Accessory accessory = new Accessory();
        accessory.setId("random");
        Accessory[] accessories = {accessory};
        accessoryAction.setAdd(accessories);
        accessoryAction.setRemove(accessories);
        Arrays.stream(requestLines).findFirst().get().setAccessories(accessoryAction);
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, redisData)).thenReturn(Mono.just(true));
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        PrepaidODAddAccessoriesResponse prepaidODAddAccessoriesResponse = new PrepaidODAddAccessoriesResponse();

        //prepaidODAddAccessoriesResponse.setErrorMap(new HashMap<String, String>());
        PrepaidODAddAccessoriesOutput prepaidODAddAccessoriesOutput = new PrepaidODAddAccessoriesOutput();
        List<PrepaidODAddAccessoriesOutput> prepaidODAddAccessoriesOutputArrayList = new ArrayList<>();
        prepaidODAddAccessoriesOutputArrayList.add(prepaidODAddAccessoriesOutput);
        prepaidODAddAccessoriesResponse.setOutput(prepaidODAddAccessoriesOutputArrayList);

        prepaidODAddAccessoriesOutput.setAccCommerceId("accCommerceId");

        String webClientResponseString = mapper.writeValueAsString(prepaidODAddAccessoriesResponse);
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(webClientResponseString));

        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any(PrepaidAdaptorWebClientRequest.class))).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddAccessoriesPEGAResponse>> responseMono = helper.callODAddAccessories(serverHttpRequest, redisData.getLines().get(0) , redisData, new PrepaidAdaptorWebClientRequest() , request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));
    }

    @Test
    public void callODAddAccessoriesTest2() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        AddAccessoryPEGARequest request = mapper.readValue(requestString, AddAccessoryPEGARequest.class);
        AddAccessoriesPEGAResponse response = mapper.readValue(responseString, AddAccessoriesPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddAccessoriesPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        PrepaidODRequestData redisData = getRedisData2();
        redisData.getLines().get(0).setCheckoutFlag(false);
        String mockRedisData = mapper.writeValueAsString(redisData);

        AccessoryAction accessoryAction = new AccessoryAction();

        Line[] requestLines = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
        Accessory accessory = new Accessory();
        accessory.setId("random");
        Accessory[] accessories = {accessory};
       // accessoryAction.setAdd(accessories);
        accessoryAction.setRemove(accessories);
        Arrays.stream(requestLines).findFirst().get().setAccessories(accessoryAction);
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, redisData)).thenReturn(Mono.just(true));
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        PrepaidODAddAccessoriesResponse prepaidODAddAccessoriesResponse = new PrepaidODAddAccessoriesResponse();

        //prepaidODAddAccessoriesResponse.setErrorMap(new HashMap<String, String>());
        PrepaidODAddAccessoriesOutput prepaidODAddAccessoriesOutput = new PrepaidODAddAccessoriesOutput();
        List<PrepaidODAddAccessoriesOutput> prepaidODAddAccessoriesOutputArrayList = new ArrayList<>();
        prepaidODAddAccessoriesOutputArrayList.add(prepaidODAddAccessoriesOutput);
        prepaidODAddAccessoriesResponse.setOutput(prepaidODAddAccessoriesOutputArrayList);

        prepaidODAddAccessoriesOutput.setAccCommerceId("accCommerceId");

        String webClientResponseString = mapper.writeValueAsString(prepaidODAddAccessoriesResponse);
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(webClientResponseString));

        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any(PrepaidAdaptorWebClientRequest.class))).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddAccessoriesPEGAResponse>> responseMono = helper.callODAddAccessories(serverHttpRequest, redisData.getLines().get(0) , redisData, new PrepaidAdaptorWebClientRequest() , request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));
    }
    
    @Test
    public void callODAddAccessoriesTest3() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        AddAccessoryPEGARequest request = mapper.readValue(requestString, AddAccessoryPEGARequest.class);
        AddAccessoriesPEGAResponse response = mapper.readValue(responseString, AddAccessoriesPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddAccessoriesPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        PrepaidODRequestData redisData = getRedisData3();
        String mockRedisData = mapper.writeValueAsString(redisData);

        AccessoryAction accessoryAction = new AccessoryAction();

        Line[] requestLines = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
        Accessory accessory = new Accessory();
        accessory.setId("random");
        Accessory[] accessories = {accessory};
        accessoryAction.setAdd(accessories);
        accessoryAction.setRemove(accessories);
        Arrays.stream(requestLines).findFirst().get().setAccessories(accessoryAction);
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, redisData)).thenReturn(Mono.just(true));
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        PrepaidODAddAccessoriesResponse prepaidODAddAccessoriesResponse = new PrepaidODAddAccessoriesResponse();

        //prepaidODAddAccessoriesResponse.setErrorMap(new HashMap<String, String>());
        PrepaidODAddAccessoriesOutput prepaidODAddAccessoriesOutput = new PrepaidODAddAccessoriesOutput();
        List<PrepaidODAddAccessoriesOutput> prepaidODAddAccessoriesOutputArrayList = new ArrayList<>();
        prepaidODAddAccessoriesOutputArrayList.add(prepaidODAddAccessoriesOutput);
        prepaidODAddAccessoriesResponse.setOutput(prepaidODAddAccessoriesOutputArrayList);

        prepaidODAddAccessoriesOutput.setAccCommerceId("accCommerceId");

        String webClientResponseString = mapper.writeValueAsString(prepaidODAddAccessoriesResponse);
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(webClientResponseString));

        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any(PrepaidAdaptorWebClientRequest.class))).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddAccessoriesPEGAResponse>> responseMono = helper.callODAddAccessories(serverHttpRequest, redisData.getLines().get(0) , redisData, new PrepaidAdaptorWebClientRequest() , request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));
    }
    
    @Test
    public void callODAddAccessoriesTest4() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        AddAccessoryPEGARequest request = mapper.readValue(requestString, AddAccessoryPEGARequest.class);
        AddAccessoriesPEGAResponse response = mapper.readValue(responseString, AddAccessoriesPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddAccessoriesPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        PrepaidODRequestData redisData = getRedisData4();
        redisData.getLines().get(0).setAccessorySkuIds(Collections.EMPTY_LIST);
        String mockRedisData = mapper.writeValueAsString(redisData);

        AccessoryAction accessoryAction = new AccessoryAction();

        Line[] requestLines = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
        Accessory accessory = new Accessory();
        accessory.setId("random");
        Accessory[] accessories = {accessory};
        accessoryAction.setAdd(accessories);
        accessoryAction.setRemove(accessories);
        Arrays.stream(requestLines).findFirst().get().setAccessories(accessoryAction);
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, redisData)).thenReturn(Mono.just(true));
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        PrepaidODAddAccessoriesResponse prepaidODAddAccessoriesResponse = new PrepaidODAddAccessoriesResponse();

        //prepaidODAddAccessoriesResponse.setErrorMap(new HashMap<String, String>());
        PrepaidODAddAccessoriesOutput prepaidODAddAccessoriesOutput = new PrepaidODAddAccessoriesOutput();
        List<PrepaidODAddAccessoriesOutput> prepaidODAddAccessoriesOutputArrayList = new ArrayList<>();
        prepaidODAddAccessoriesOutputArrayList.add(prepaidODAddAccessoriesOutput);
        prepaidODAddAccessoriesResponse.setOutput(prepaidODAddAccessoriesOutputArrayList);

        prepaidODAddAccessoriesOutput.setAccCommerceId("accCommerceId");

        String webClientResponseString = mapper.writeValueAsString(prepaidODAddAccessoriesResponse);
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(webClientResponseString));

        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any(PrepaidAdaptorWebClientRequest.class))).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddAccessoriesPEGAResponse>> responseMono = helper.callODAddAccessories(serverHttpRequest, redisData.getLines().get(0) , redisData, new PrepaidAdaptorWebClientRequest() , request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));
    }

    @Test
    public void callODAddAccessoriesExceptionTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        AddAccessoryPEGARequest request = mapper.readValue(requestString, AddAccessoryPEGARequest.class);
        AddAccessoriesPEGAResponse response = mapper.readValue(responseString, AddAccessoriesPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddAccessoriesPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        PrepaidODRequestData redisData = getRedisData4();
        redisData.getLines().get(0).setAccessorySkuIds(Collections.EMPTY_LIST);
        String mockRedisData = mapper.writeValueAsString(redisData);

        AccessoryAction accessoryAction = new AccessoryAction();

        Line[] requestLines = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
        Accessory accessory = new Accessory();
        accessory.setId("random");
        Accessory[] accessories = {accessory};
        accessoryAction.setAdd(accessories);
        accessoryAction.setRemove(accessories);
        Arrays.stream(requestLines).findFirst().get().setAccessories(accessoryAction);
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, redisData)).thenReturn(Mono.just(true));
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        PrepaidODAddAccessoriesResponse prepaidODAddAccessoriesResponse = new PrepaidODAddAccessoriesResponse();

        PrepaidODAddAccessoriesOutput prepaidODAddAccessoriesOutput = new PrepaidODAddAccessoriesOutput();
        List<PrepaidODAddAccessoriesOutput> prepaidODAddAccessoriesOutputArrayList = new ArrayList<>();
        prepaidODAddAccessoriesOutputArrayList.add(prepaidODAddAccessoriesOutput);
        prepaidODAddAccessoriesResponse.setOutput(prepaidODAddAccessoriesOutputArrayList);

        prepaidODAddAccessoriesOutput.setAccCommerceId("accCommerceId");

                Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body("value"));

        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any(PrepaidAdaptorWebClientRequest.class))).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddAccessoriesPEGAResponse>> responseMono = helper.callODAddAccessories(serverHttpRequest, redisData.getLines().get(0) , redisData, new PrepaidAdaptorWebClientRequest() , request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));
    }
    
    @Test
    public void updateLineInfoTest() throws IOException {

        AddAccessoryPEGARequest request = mapper.readValue(requestString, AddAccessoryPEGARequest.class);

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setMtn("newLine1");
        line.setCheckoutFlag(true);
        lines.add(line);

        //adding skuId
        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("skuId1");
        skuIds.setSorId("random");
        accessorySkuIds.add(skuIds);
        line.setAccessorySkuIds(accessorySkuIds);
        line.getAccessorySkuIds().stream().findFirst().get().setSorId("random");

        Accessory accessory = new Accessory();
        accessory.setId("random");
        accessory.setQty("1");
        accessory.setAccessorySkuID("accessorySkuId");
        accessory.setDisplayName("displayName");
        accessory.setImgUrl("imgUrl");
        accessory.setColor("color");
        accessory.setPrice("price");
        accessory.setManufacturer("manufacturer");
        accessory.setDescription("description");
        Accessory[] accessories = {accessory};
        AccessoryAction accessoryAction = new AccessoryAction();

        accessoryAction.setAdd(accessories);
        accessoryAction.setRemove(accessories);
        Line[] requestLines = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();

        Arrays.stream(requestLines).findFirst().get().setAccessories(accessoryAction);

        ReflectionTestUtils.invokeMethod(helper,"updateLineInfo",requestLines, lines);
        Assert.assertNotNull(requestLines);
    }

}
