package onevz.soe.prepay.adaptor.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import net.jcip.annotations.NotThreadSafe;
import onevz.soe.assignmtn.reponse.pega.PortinPEGAResponse;
import onevz.soe.assignmtn.request.pega.PortinPEGARequest;
import onevz.soe.cart.model.common.PortLine;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.common.model.PrepaidODRequestDataAccessorySkuIds;
import onevz.soe.common.model.PrepaidODRequestDataLines;
import onevz.soe.prepay.adaptor.cart.model.play.TransferNumberDetail;
import onevz.soe.prepay.adaptor.cart.model.play.VZWAddPortinPageData;
import onevz.soe.prepay.adaptor.cart.model.play.VZWAddPortinPayload;
import onevz.soe.prepay.adaptor.cart.model.play.VZWPrepayAddPortinResponse;
import onevz.soe.prepay.adaptor.cart.util.FileReaderUtil;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import onevz.soe.wsclient.prepay.webclient.model.PrepaidAdaptorWebClientRequest;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_DATA;
import static org.mockito.Mockito.when;

@WebFluxTest
@RunWith(SpringJUnit4ClassRunner.class)
@NotThreadSafe
public class PrepayAdaptorAddPortinHelperTest {

    @Autowired
    PrepayAdaptorAddPortinHelper helper;

    @MockBean
    PrepayCartRedisHelper prepayCartRedisHelper;

    @MockBean
    PrepayAdaptorWebClient prepayAdaptorWebClient;

    @Autowired
    ObjectMapper mapper;

    private PrepaidODRequestData getRedisData() throws JsonProcessingException {
        String redisDataString="{\"ecommSessionId\":\"1kjhlkliueijrlwkjelrjwl88lijeljrlkwjel\",\"curr_line\":1,\"lines\":[{\"mtn\":\"newLine1\",\"flow\":\"NSE\",\"lineItemId\":\"newLine1\",\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\",\"numAssigned\":false,\"completedProcessSteps\":[\"GridWallPDP\"]}],\"pcsrfToken\":\"3iqjhlwekjqlwjelqkwjelqhwekuhwqijlwk\"})";
    
        PrepaidODRequestData redisData = new PrepaidODRequestData();
       
        redisData = this.mapper.readValue(redisDataString,PrepaidODRequestData.class);
      
        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        return redisData;
    }

    private PrepaidODRequestData getRedisData6() throws JsonProcessingException {
        String redisDataString="{\"ecommSessionId\":\"1kjhlkliueijrlwkjelrjwl88lijeljrlkwjel\",\"curr_line\":1,\"lines\":[{\"mtn\":\"newLine1\",\"flow\":\"NSEBYOD\",\"lineItemId\":\"newLine1\",\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\",\"numAssigned\":false,\"completedProcessSteps\":[\"GridWallPDP\"]}],\"pcsrfToken\":\"3iqjhlwekjqlwjelqkwjelqhwekuhwqijlwk\"})";

        PrepaidODRequestData redisData = new PrepaidODRequestData();

        redisData = this.mapper.readValue(redisDataString,PrepaidODRequestData.class);

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        return redisData;
    }

    private PrepaidODRequestData getRedisData3() throws JsonProcessingException {
        String redisDataString="{\"ecommSessionId\":\"1kjhlkliueijrlwkjelrjwl88lijeljrlkwjel\",\"curr_line\":1,\"lines\":[{\"mtn\":\"newLine1\",\"flow\":\"ESO\",\"lineItemId\":\"newLine1\",\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\",\"numAssigned\":false,\"completedProcessSteps\":[\"GridWallPDP\"]}],\"pcsrfToken\":\"3iqjhlwekjqlwjelqkwjelqhwekuhwqijlwk\"})";

        PrepaidODRequestData redisData = new PrepaidODRequestData();

        redisData = this.mapper.readValue(redisDataString,PrepaidODRequestData.class);

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        return redisData;
    }

    private PrepaidODRequestData getRedisData4() throws JsonProcessingException {
        String redisDataString="{\"ecommSessionId\":\"1kjhlkliueijrlwkjelrjwl88lijeljrlkwjel\",\"curr_line\":1,\"lines\":[{\"mtn\":\"newLine1\",\"flow\":\"NSP\",\"lineItemId\":\"newLine1\",\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\",\"numAssigned\":false,\"completedProcessSteps\":[\"GridWallPDP\"]}],\"pcsrfToken\":\"3iqjhlwekjqlwjelqkwjelqhwekuhwqijlwk\"})";

        PrepaidODRequestData redisData = new PrepaidODRequestData();

        redisData = this.mapper.readValue(redisDataString,PrepaidODRequestData.class);

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        return redisData;
    }
    private PrepaidODRequestData getRedisData5() throws JsonProcessingException {
        String redisDataString="{\"ecommSessionId\":\"1kjhlkliueijrlwkjelrjwl88lijeljrlkwjel\",\"curr_line\":1,\"lines\":[{\"mtn\":\"newLine1\",\"flow\":\"PASO\",\"lineItemId\":\"newLine1\",\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\",\"numAssigned\":false,\"completedProcessSteps\":[\"GridWallPDP\"]}],\"pcsrfToken\":\"3iqjhlwekjqlwjelqkwjelqhwekuhwqijlwk\"})";

        PrepaidODRequestData redisData = new PrepaidODRequestData();

        redisData = this.mapper.readValue(redisDataString,PrepaidODRequestData.class);

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        return redisData;
    }
    
    private PrepaidODRequestData getRedisData2() throws JsonProcessingException {
        String redisDataString2="{\"ecommSessionId\":\"1kjhlkliueijrlwkjelrjwl88lijeljrlkwjel\",\"curr_line\":1,\"lines\":[{\"mtn\":\"newLine1\",\"lineItemId\":\"newLine1\",\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\",\"numAssigned\":true,\"completedProcessSteps\":[\"GridWallPDP\"]}],\"pcsrfToken\":\"3iqjhlwekjqlwjelqkwjelqhwekuhwqijlwk\"})";
        PrepaidODRequestData redisData2 = new PrepaidODRequestData();
        redisData2 = this.mapper.readValue(redisDataString2,PrepaidODRequestData.class);
        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();
        return redisData2;
    }
    

    String requestString = "{\n" +
            "  \"serviceHeader\": {\n" +
            "    \"clientId\": \"VZW-DOTCOM\",\n" +
            "    \"statusMsg\": \"PEGA generated message\",\n" +
            "    \"serviceName\": \"SalesOrderPurchase\",\n" +
            "    \"userId\": \"\",\n" +
            "    \"statusCode\": \"0\",\n" +
            "    \"sessionId\": \"\",\n" +
            "    \"correlationId\": \"soe-cart-2022.01.25.18.58.21-916.8608036659715\"\n" +
            "  },\n" +
            "  \"serviceBody\": {\n" +
            "    \"serviceRequest\": {\n" +
            "      \"context\": {\n" +
            "        \"caseId\": \"SOP-817289281-E01\",\n" +
            "        \"contextInfo\": {\n" +
            "          \"callReason\": \"SalesOrderPurchase\",\n" +
            "          \"processStep\": \"PlanSelection\",\n" +
            "          \"processAction\": \"addPlan\",\n" +
            "          \"intent\": \"Inline-CPC\"\n" +
            "        },\n" +
            "        \"customerInfo\": {\n" +
            "          \"throttleName\": \"|AccessoryInterestialProspect|\",\n" +
            "          \"bucketAllocator\": \"BAU\",\n" +
            "          \"customerType\": \"N\",\n" +
            "          \"accountNumber\": \"\",\n" +
            "          \"cartCreator\": \"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\n" +
            "          \"processingMTN\": \"newLine1\",\n" +
            "          \"registerNumber\": 0,\n" +
            "          \"mtnFlow\": \"P\",\n" +
            "          \"globalId\": \"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"\n" +
            "        },\n" +
            "        \"cartInfo\": {\n" +
            "          \"retrieveFeatureLossReferenceData\": \"Y\",\n" +
            "          \"parentMtn\": \"\",\n" +
            "          \"cartItemCount\": 0,\n" +
            "          \"cartId\": \"b83940f5-0276-407f-947f-c2a2fa819afe\",\n" +
            "          \"itemType\": \"PLAN\",\n" +
            "          \"intendType\": \"NSE\",\n" +
            "          \"action\": \"UPDATE\",\n" +
            "          \"lines\": [\n" +
            "            {\n" +
            "              \"plan\": {\n" +
            "                \"id\": \"50427\",\n" +
            "                \"isRecommendedPlan\": false\n" +
            "              },\n" +
            "              \"mtn\": \"newLine1\",\n" +
            "              \"editSim\": false,\n" +
            "              \"lineWithSkipMDN\": false,\n" +
            "              \"inWithVerizonOpted\": false,\n" +
            "              \"protectionNotRequired\": false\n" +
            "            }\n" +
            "          ],\n" +
            "          \"effectiveDate\": \"\",\n" +
            "          \"checkAutoPayDiscountEligible\": \"N\",\n" +
            "          \"discountPromoTotal\": 0,\n" +
            "          \"registerNumber\": 0,\n" +
            "          \"protectionNotRequired\": false\n" +
            "        }\n" +
            "      }\n" +
            "    }\n" +
            "  }\n" +
            "}";
    
    String requestString2 = "{\n" +
            "  \"serviceHeader\": {\n" +
            "    \"clientId\": \"VZW-DOTCOM\",\n" +
            "    \"statusMsg\": \"PEGA generated message\",\n" +
            "    \"serviceName\": \"SalesOrderPurchase\",\n" +
            "    \"userId\": \"\",\n" +
            "    \"statusCode\": \"0\",\n" +
            "    \"sessionId\": \"\",\n" +
            "    \"correlationId\": \"soe-cart-2022.01.25.18.58.21-916.8608036659715\"\n" +
            "  },\n" +
            "  \"serviceBody\": {\n" +
            "    \"serviceRequest\": {\n" +
            "      \"context\": {\n" +
            "        \"caseId\": \"SOP-817289281-E01\",\n" +
            "        \"contextInfo\": {\n" +
            "          \"callReason\": \"SalesOrderPurchase\",\n" +
            "          \"processStep\": \"PlanSelection\",\n" +
            "          \"processAction\": \"addPlan\",\n" +
            "          \"intent\": \"Inline-CPC\"\n" +
            "        },\n" +
            "        \"customerInfo\": {\n" +
            "          \"throttleName\": \"|AccessoryInterestialProspect|\",\n" +
            "          \"bucketAllocator\": \"BAU\",\n" +
            "          \"customerType\": \"N\",\n" +
            "          \"accountNumber\": \"\",\n" +
            "          \"cartCreator\": \"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\n" +
            "          \"processingMTN\": \"newLine1\",\n" +
            "          \"registerNumber\": 0,\n" +
            "          \"mtnFlow\": \"P\",\n" +
            "          \"globalId\": \"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"\n" +
            "        },\n" +
            "        \"cartInfo\": {\n" +
            "          \"retrieveFeatureLossReferenceData\": \"Y\",\n" +
            "          \"parentMtn\": \"\",\n" +
            "          \"cartItemCount\": 0,\n" +
            "          \"cartId\": \"b83940f5-0276-407f-947f-c2a2fa819afe\",\n" +
            "          \"itemType\": \"PLAN\",\n" +
            "          \"intendType\": \"NSEBYOD\",\n" +
            "          \"action\": \"UPDATE\",\n" +
            "          \"lines\": [\n" +
            "            {\n" +
            "              \"plan\": {\n" +
            "                \"id\": \"50427\",\n" +
            "                \"isRecommendedPlan\": false\n" +
            "              },\n" +
            "              \"mtn\": \"newLine1\",\n" +
            "              \"editSim\": false,\n" +
            "              \"lineWithSkipMDN\": false,\n" +
            "              \"inWithVerizonOpted\": false,\n" +
            "              \"protectionNotRequired\": false\n" +
            "            }\n" +
            "          ],\n" +
            "          \"effectiveDate\": \"\",\n" +
            "          \"checkAutoPayDiscountEligible\": \"N\",\n" +
            "          \"discountPromoTotal\": 0,\n" +
            "          \"registerNumber\": 0,\n" +
            "          \"protectionNotRequired\": false\n" +
            "        }\n" +
            "      }\n" +
            "    }\n" +
            "  }\n" +
            "}";

    String requestString3 = "{\n" +
            "  \"serviceHeader\": {\n" +
            "    \"clientId\": \"VZW-DOTCOM\",\n" +
            "    \"statusMsg\": \"PEGA generated message\",\n" +
            "    \"serviceName\": \"SalesOrderPurchase\",\n" +
            "    \"userId\": \"\",\n" +
            "    \"statusCode\": \"0\",\n" +
            "    \"sessionId\": \"\",\n" +
            "    \"correlationId\": \"soe-cart-2022.01.25.18.58.21-916.8608036659715\"\n" +
            "  },\n" +
            "  \"serviceBody\": {\n" +
            "    \"serviceRequest\": {\n" +
            "      \"context\": {\n" +
            "        \"caseId\": \"SOP-817289281-E01\",\n" +
            "        \"contextInfo\": {\n" +
            "          \"callReason\": \"SalesOrderPurchase\",\n" +
            "          \"processStep\": \"PlanSelection\",\n" +
            "          \"processAction\": \"addPlan\",\n" +
            "          \"intent\": \"Inline-CPC\"\n" +
            "        },\n" +
            "        \"customerInfo\": {\n" +
            "          \"throttleName\": \"|AccessoryInterestialProspect|\",\n" +
            "          \"bucketAllocator\": \"BAU\",\n" +
            "          \"customerType\": \"N\",\n" +
            "          \"accountNumber\": \"\",\n" +
            "          \"cartCreator\": \"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\n" +
            "          \"processingMTN\": \"newLine1\",\n" +
            "          \"registerNumber\": 0,\n" +
            "          \"mtnFlow\": \"P\",\n" +
            "          \"globalId\": \"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"\n" +
            "        },\n" +
            "        \"cartInfo\": {\n" +
            "          \"retrieveFeatureLossReferenceData\": \"Y\",\n" +
            "          \"parentMtn\": \"\",\n" +
            "          \"cartItemCount\": 0,\n" +
            "          \"cartId\": \"b83940f5-0276-407f-947f-c2a2fa819afe\",\n" +
            "          \"itemType\": \"PLAN\",\n" +
            "          \"intendType\": \"NSP\",\n" +
            "          \"action\": \"UPDATE\",\n" +
            "          \"lines\": [\n" +
            "            {\n" +
            "              \"plan\": {\n" +
            "                \"id\": \"50427\",\n" +
            "                \"isRecommendedPlan\": false\n" +
            "              },\n" +
            "              \"mtn\": \"newLine1\",\n" +
            "              \"editSim\": false,\n" +
            "              \"lineWithSkipMDN\": false,\n" +
            "              \"inWithVerizonOpted\": false,\n" +
            "              \"protectionNotRequired\": false\n" +
            "            }\n" +
            "          ],\n" +
            "          \"effectiveDate\": \"\",\n" +
            "          \"checkAutoPayDiscountEligible\": \"N\",\n" +
            "          \"discountPromoTotal\": 0,\n" +
            "          \"registerNumber\": 0,\n" +
            "          \"protectionNotRequired\": false\n" +
            "        }\n" +
            "      }\n" +
            "    }\n" +
            "  }\n" +
            "}";
    
    String requestString4 = "{\n" +
            "  \"serviceHeader\": {\n" +
            "    \"clientId\": \"VZW-DOTCOM\",\n" +
            "    \"statusMsg\": \"PEGA generated message\",\n" +
            "    \"serviceName\": \"SalesOrderPurchase\",\n" +
            "    \"userId\": \"\",\n" +
            "    \"statusCode\": \"0\",\n" +
            "    \"sessionId\": \"\",\n" +
            "    \"correlationId\": \"soe-cart-2022.01.25.18.58.21-916.8608036659715\"\n" +
            "  },\n" +
            "  \"serviceBody\": {\n" +
            "    \"serviceRequest\": {\n" +
            "      \"context\": {\n" +
            "        \"caseId\": \"SOP-817289281-E01\",\n" +
            "        \"contextInfo\": {\n" +
            "          \"callReason\": \"SalesOrderPurchase\",\n" +
            "          \"processStep\": \"PlanSelection\",\n" +
            "          \"processAction\": \"addPlan\",\n" +
            "          \"intent\": \"Inline-CPC\"\n" +
            "        },\n" +
            "        \"customerInfo\": {\n" +
            "          \"throttleName\": \"|AccessoryInterestialProspect|\",\n" +
            "          \"bucketAllocator\": \"BAU\",\n" +
            "          \"customerType\": \"N\",\n" +
            "          \"accountNumber\": \"\",\n" +
            "          \"cartCreator\": \"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\n" +
            "          \"processingMTN\": \"newLine1\",\n" +
            "          \"registerNumber\": 0,\n" +
            "          \"mtnFlow\": \"P\",\n" +
            "          \"globalId\": \"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"\n" +
            "        },\n" +
            "        \"cartInfo\": {\n" +
            "          \"retrieveFeatureLossReferenceData\": \"Y\",\n" +
            "          \"parentMtn\": \"\",\n" +
            "          \"cartItemCount\": 0,\n" +
            "          \"cartId\": \"b83940f5-0276-407f-947f-c2a2fa819afe\",\n" +
            "          \"itemType\": \"PLAN\",\n" +
            "          \"intendType\": \"ESO\",\n" +
            "          \"action\": \"UPDATE\",\n" +
            "          \"lines\": [\n" +
            "            {\n" +
            "              \"plan\": {\n" +
            "                \"id\": \"50427\",\n" +
            "                \"isRecommendedPlan\": false\n" +
            "              },\n" +
            "              \"mtn\": \"newLine1\",\n" +
            "              \"editSim\": false,\n" +
            "              \"lineWithSkipMDN\": false,\n" +
            "              \"inWithVerizonOpted\": false,\n" +
            "              \"protectionNotRequired\": false\n" +
            "            }\n" +
            "          ],\n" +
            "          \"effectiveDate\": \"\",\n" +
            "          \"checkAutoPayDiscountEligible\": \"N\",\n" +
            "          \"discountPromoTotal\": 0,\n" +
            "          \"registerNumber\": 0,\n" +
            "          \"protectionNotRequired\": false\n" +
            "        }\n" +
            "      }\n" +
            "    }\n" +
            "  }\n" +
            "}";


    @Test
    public void addPortinExceptionTest() throws IOException {

        VZWPrepayAddPortinResponse vzwPrepayAddPortinResponse= new VZWPrepayAddPortinResponse();
        vzwPrepayAddPortinResponse.setPayload(new VZWAddPortinPayload());
        vzwPrepayAddPortinResponse.getPayload().setPageData(new VZWAddPortinPageData());
        List<TransferNumberDetail> transferNumberDetails = new ArrayList<>();
        TransferNumberDetail transferNumberDetail1 = new TransferNumberDetail();
        transferNumberDetails.add(transferNumberDetail1);
        vzwPrepayAddPortinResponse.getPayload().getPageData().setTransferNumberDetails(transferNumberDetails);
        String responseString=mapper.writeValueAsString(vzwPrepayAddPortinResponse);
        PrepaidODRequestData redisData = getRedisData();

        String mockRedisData = mapper.writeValueAsString(redisData);
        PortinPEGARequest request = mapper.readValue(requestString, PortinPEGARequest.class);
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().setPortLines(new PortLine[1]);
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0] = new PortLine();

        request.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0].setMtn("newLine1");

        URI url = URI.create("http://localhost/testurl");

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(),Mockito.any())).thenThrow(new RuntimeException());
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<PortinPEGAResponse>> responseMono = helper.addPortin(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void addPortinTest() throws IOException {

        VZWPrepayAddPortinResponse vzwPrepayAddPortinResponse= new VZWPrepayAddPortinResponse();
        vzwPrepayAddPortinResponse.setPayload(new VZWAddPortinPayload());
        vzwPrepayAddPortinResponse.getPayload().setPageData(new VZWAddPortinPageData());
        List<TransferNumberDetail> transferNumberDetails = new ArrayList<>();
        TransferNumberDetail transferNumberDetail1 = new TransferNumberDetail();
        transferNumberDetails.add(transferNumberDetail1);
        vzwPrepayAddPortinResponse.getPayload().getPageData().setTransferNumberDetails(transferNumberDetails);
        String responseString=mapper.writeValueAsString(vzwPrepayAddPortinResponse);
        PrepaidODRequestData redisData = getRedisData();

        String mockRedisData = mapper.writeValueAsString(redisData);
        PortinPEGARequest request = mapper.readValue(requestString, PortinPEGARequest.class);
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().setPortLines(new PortLine[1]);
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0] = new PortLine();

        request.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0].setMtn("newLine1");

        URI url = URI.create("http://localhost/testurl");

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<PortinPEGAResponse>> responseMono = helper.addPortin(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addPortinEmptyRedisData() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"2\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PortinPEGARequest request = mapper.readValue(requestString, PortinPEGARequest.class);

        PortinPEGAResponse response = mapper.readValue(responseString, PortinPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(""));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<PortinPEGAResponse>> responseMono = helper.addPortin(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                 () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addPortinTest2() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"2\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData2();
        redisData.getLines().get(0).setNumAssigned(false);
        PrepaidODRequestDataLines lines=new PrepaidODRequestDataLines();
        lines.setMtn("newLine2");
        lines.setNumAssigned(false);
        redisData.getLines().add(lines);
        String mockRedisData = mapper.writeValueAsString(redisData);
        PortinPEGARequest request = mapper.readValue(requestString2, PortinPEGARequest.class);
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().setPortLines(new PortLine[1]);
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0] = new PortLine();

        request.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0].setMtn("newLine1");

        PortinPEGAResponse response = mapper.readValue(responseString, PortinPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<PortinPEGAResponse>> responseMono = helper.addPortin(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    
    @Test
    public void addPortinTest3() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"2\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData2();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        PortinPEGARequest request = mapper.readValue(requestString3, PortinPEGARequest.class);
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().setPortLines(new PortLine[1]);
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0] = new PortLine();

        request.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0].setMtn("newLine1");

        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        PortinPEGAResponse response = mapper.readValue(responseString, PortinPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<PortinPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<PortinPEGAResponse>> responseMono = helper.addPortin(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    
    @Test
    public void addPortinTest4() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"2\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData4();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        PortinPEGARequest request = mapper.readValue(requestString4, PortinPEGARequest.class);
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().setPortLines(new PortLine[1]);
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0] = new PortLine();

        request.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0].setMtn("newLine1");

        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        PortinPEGAResponse response = mapper.readValue(responseString, PortinPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<PortinPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<PortinPEGAResponse>> responseMono = helper.addPortin(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addPortinTest5() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"2\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData5();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        PortinPEGARequest request = mapper.readValue(requestString4, PortinPEGARequest.class);
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().setPortLines(new PortLine[1]);
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0] = new PortLine();

        request.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0].setMtn("newLine1");

        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        PortinPEGAResponse response = mapper.readValue(responseString, PortinPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<PortinPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<PortinPEGAResponse>> responseMono = helper.addPortin(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void addPortinTest6() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"2\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData6();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        PortinPEGARequest request = mapper.readValue(requestString4, PortinPEGARequest.class);
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().setPortLines(new PortLine[1]);
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0] = new PortLine();

        request.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0].setMtn("newLine1");

        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        PortinPEGAResponse response = mapper.readValue(responseString, PortinPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<PortinPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<PortinPEGAResponse>> responseMono = helper.addPortin(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void addPortinNot200ResponseCodeTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"5\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        PortinPEGARequest request = mapper.readValue(requestString, PortinPEGARequest.class);
        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().setPortLines(new PortLine[1]);
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0] = new PortLine();

        request.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0].setMtn("newLine1");

        PortinPEGAResponse response = mapper.readValue(responseString, PortinPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<PortinPEGAResponse>> responseMono = helper.addPortin(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void addPortinNot200ResponseCodeErrorsNOtNullTest() throws IOException {

        String responseString = FileReaderUtil.readFromFile("response/addPortInErrorResponse.json");
        PrepaidODRequestData redisData = getRedisData();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        PortinPEGARequest request = mapper.readValue(requestString, PortinPEGARequest.class);
        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().setPortLines(new PortLine[1]);
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0] = new PortLine();

        request.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0].setMtn("newLine1");

        PortinPEGAResponse response = mapper.readValue(responseString, PortinPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<PortinPEGAResponse>> responseMono = helper.addPortin(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addPortinNot200ResponseCodeErrorsNOtNullExceptionTest() throws IOException {

        String responseString = "Value";
        PrepaidODRequestData redisData = getRedisData();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        PortinPEGARequest request = mapper.readValue(requestString, PortinPEGARequest.class);
        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().setPortLines(new PortLine[1]);
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0] = new PortLine();

        request.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0].setMtn("newLine1");

       // PortinPEGAResponse response = mapper.readValue(responseString, PortinPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<PortinPEGAResponse>> responseMono = helper.addPortin(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addPortinNot200ResponseCodeErrorsRedisExceptionTest() throws IOException {
        String mockRedisData = "value";
        PortinPEGARequest request = mapper.readValue(requestString, PortinPEGARequest.class);


        URI url = URI.create("http://localhost/testurl");

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<PortinPEGAResponse>> responseMono = helper.addPortin(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void addPortin200ResponseCodeErrorsNOtNullTest() throws IOException {

        String responseString = FileReaderUtil.readFromFile("response/addPortInErrorResponse200.json");
        PrepaidODRequestData redisData = getRedisData();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        PortinPEGARequest request = mapper.readValue(requestString, PortinPEGARequest.class);
        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().setPortLines(new PortLine[1]);
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0] = new PortLine();

        request.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0].setMtn("newLine1");

        PortinPEGAResponse response = mapper.readValue(responseString, PortinPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<PortinPEGAResponse>> responseMono = helper.addPortin(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void addPotINEmptyResponseTest() throws IOException {

        String responseString = "";
        PrepaidODRequestData redisData = getRedisData();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        PortinPEGARequest request = mapper.readValue(requestString, PortinPEGARequest.class);
        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().setPortLines(new PortLine[1]);
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0] = new PortLine();

        request.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0].setMtn("newLine1");

      //  PortinPEGAResponse response = mapper.readValue(responseString, PortinPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<PortinPEGAResponse>> responseMono = helper.addPortin(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void addPortINEmptyPlayResponseTest() throws IOException {

        String responseString = "";
        PrepaidODRequestData redisData = getRedisData();
        String mockRedisData = mapper.writeValueAsString(redisData);
        PortinPEGARequest request = mapper.readValue(requestString, PortinPEGARequest.class);
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().setPortLines(new PortLine[1]);
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0] = new PortLine();

        request.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0].setMtn("newLine1");

        URI url = URI.create("http://localhost/testurl");

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<PortinPEGAResponse>> responseMono = helper.addPortin(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }


    public PrepaidAdaptorWebClientRequest getPrepaidLegacyServiceRequest(PrepaidODRequestData redisData) {
        PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
        Map<String, String> headers = new HashMap<>();
        //headers.put("p-csrf-token", redisData.getPCsrfToken());
        String prepayODCookie = "ECOMM_SESSION=" + redisData.getEcommSessionId() + ";" + "p_csrftkn=" + redisData.getPCsrfToken();
        headers.put("Cookie", prepayODCookie);

        prepaidAdaptorWebClientRequest.setRequestBody("{}");
        prepaidAdaptorWebClientRequest.setRequestType(HttpMethod.GET.toString());
        prepaidAdaptorWebClientRequest.setHeader(headers);
        return prepaidAdaptorWebClientRequest;
    }
}
