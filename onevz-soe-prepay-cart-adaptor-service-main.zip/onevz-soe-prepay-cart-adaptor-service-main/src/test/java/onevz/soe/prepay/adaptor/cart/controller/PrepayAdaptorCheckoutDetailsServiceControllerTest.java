package onevz.soe.prepay.adaptor.cart.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import junit.framework.Assert;
import onevz.soe.activation.cxp.response.OrderConfirmationCXPResponse;
import onevz.soe.orderprocess.request.CheckoutDetailsCXPRequest;
import onevz.soe.orderprocess.response.cxp.CheckoutDetailsCXPResponse;
import onevz.soe.prepay.adaptor.cart.config.PrepayCartAdaptorServiceTestConfig;
import onevz.soe.prepay.adaptor.cart.helper.PrepayAdaptorNSECheckoutDetailsHelper;
import onevz.soe.prepay.adaptor.cart.util.FileReaderUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.net.URI;

import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {PrepayCartAdaptorServiceTestConfig.class})
@WebFluxTest(PrepayAdaptorCheckoutDetailsServiceController.class)
public class PrepayAdaptorCheckoutDetailsServiceControllerTest {

    @MockBean
    private PrepayAdaptorNSECheckoutDetailsHelper prepayAdaptorNSECheckoutDetailsHelper;

    @Autowired
    private PrepayAdaptorCheckoutDetailsServiceController checkoutController;

    @Autowired
    private ObjectMapper mapper;

    @Test
    public void getCheckoutDetailsTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";
        CheckoutDetailsCXPRequest request = mapper.readValue(requestString, CheckoutDetailsCXPRequest.class);
        CheckoutDetailsCXPResponse response = mapper.readValue(responseString, CheckoutDetailsCXPResponse.class);
        URI url = URI.create("http://localhost:15112/prepaid-adaptor/assignmtn/retreive-npanxx");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<CheckoutDetailsCXPResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
        when(prepayAdaptorNSECheckoutDetailsHelper.getCheckoutDetails(Mockito.any(), Mockito.any())).thenReturn(justResponse);
        Mono<ResponseEntity<CheckoutDetailsCXPResponse>> actual = checkoutController.getCheckoutDetails(httpHeader, request);
        StepVerifier.create(actual).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void getCheckoutDetailsErrorTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";
        CheckoutDetailsCXPRequest request = mapper.readValue(requestString, CheckoutDetailsCXPRequest.class);
        CheckoutDetailsCXPResponse response = mapper.readValue(responseString, CheckoutDetailsCXPResponse.class);
        URI url = URI.create("http://localhost:15112/prepaid-adaptor/assignmtn/retreive-npanxx");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<CheckoutDetailsCXPResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
        when(prepayAdaptorNSECheckoutDetailsHelper.getCheckoutDetails(Mockito.any(), Mockito.any())).thenReturn(justResponse);
        Mono<ResponseEntity<CheckoutDetailsCXPResponse>> actual = checkoutController.getCheckoutDetails(httpHeader, request);
        StepVerifier.create(Mono.just("Exception").map(element -> {throw new RuntimeException();})).expectError().verify();
    }

    @Test
    public void getOrderConfirmationRedesignPage() throws IOException {
        String responseString = FileReaderUtil.readFromFile("response/getCheckoutDetailsAdaptorResponse.json");
        CheckoutDetailsCXPResponse response = mapper.readValue(responseString, CheckoutDetailsCXPResponse.class);
        URI url = URI.create("http://localhost:15112/prepaid-adaptor/cart/getOrderConfirmationRedesignPage");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<CheckoutDetailsCXPResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
        when(prepayAdaptorNSECheckoutDetailsHelper.getCheckoutDetails(Mockito.any(), Mockito.any())).thenReturn(justResponse);
        Mono<OrderConfirmationCXPResponse> actual = checkoutController.getOrderConfirmationRedesignPage(httpHeader);
        StepVerifier.create(actual).assertNext(Assert::assertNotNull).expectComplete().verify();
    }
}
