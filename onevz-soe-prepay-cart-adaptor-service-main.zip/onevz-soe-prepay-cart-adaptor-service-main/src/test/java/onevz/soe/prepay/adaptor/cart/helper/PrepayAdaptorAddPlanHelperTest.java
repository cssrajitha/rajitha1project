package onevz.soe.prepay.adaptor.cart.helper;


import com.fasterxml.jackson.databind.ObjectMapper;
import net.jcip.annotations.NotThreadSafe;
import onevz.soe.cart.model.common.Line;
import onevz.soe.cart.requests.AddPlanPEGARequest;
import onevz.soe.cart.responses.AddPlanPEGAResponse;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.common.model.PrepaidODRequestDataAccessorySkuIds;
import onevz.soe.common.model.PrepaidODRequestDataLines;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_DATA;
import static org.mockito.Mockito.when;

@WebFluxTest
@RunWith(SpringJUnit4ClassRunner.class)
@NotThreadSafe
public class PrepayAdaptorAddPlanHelperTest {

    @Autowired
    PrepayAdaptorCartAddPlanHelper helper;

    @MockBean
    PrepayCartRedisHelper prepayCartRedisHelper;

    @MockBean
    PrepayAdaptorWebClient prepayAdaptorWebClient;

    @Autowired
    ObjectMapper mapper;

    private PrepaidODRequestData getRedisData(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setMtn("newLine1");
        line.setCheckoutFlag(true);
        lines.add(line);

        List<String> featureSkuIds = new ArrayList<>();
        featureSkuIds.add("sku3920521");
        featureSkuIds.add("feature13");
        //adding AccessoryskuId
        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        line.setAccessorySkuIds(accessorySkuIds);
        line.setFeatureSkuIds(featureSkuIds);

        redisData.setLines(lines);

        return redisData;
    }

    private PrepaidODRequestData getRedisData2(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setMtn("newLine1");
        line.setCheckoutFlag(true);
        line.setFlow("NSE");
        lines.add(line);

        List<String> featureSkuIds = new ArrayList<>();
        featureSkuIds.add("sku3920521");
        featureSkuIds.add("feature13");
        //adding AccessoryskuId
        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        line.setAccessorySkuIds(accessorySkuIds);
        line.setFeatureSkuIds(featureSkuIds);

        redisData.setLines(lines);

        return redisData;
    }

    private PrepaidODRequestData getRedisData3(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setMtn("newLine1");
        line.setCheckoutFlag(true);
        line.setFlow("NSEBYOD");
        lines.add(line);

        List<String> featureSkuIds = new ArrayList<>();
        featureSkuIds.add("sku3920521");
        featureSkuIds.add("feature13");
        //adding AccessoryskuId
        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        line.setAccessorySkuIds(accessorySkuIds);
        line.setFeatureSkuIds(featureSkuIds);

        redisData.setLines(lines);

        return redisData;
    }

    private PrepaidODRequestData getRedisData4(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setMtn("newLine1");
        line.setCheckoutFlag(true);
        line.setFlow("ESO");
        lines.add(line);

        List<String> featureSkuIds = new ArrayList<>();
        featureSkuIds.add("sku3920521");
        featureSkuIds.add("feature13");
        //adding AccessoryskuId
        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        line.setAccessorySkuIds(accessorySkuIds);
        line.setFeatureSkuIds(featureSkuIds);

        redisData.setLines(lines);

        return redisData;
    }

    private PrepaidODRequestData getRedisData5(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setMtn("newLine1");
        line.setCheckoutFlag(true);
        line.setFlow("NSP");
        lines.add(line);

        List<String> featureSkuIds = new ArrayList<>();
        featureSkuIds.add("sku3920521");
        featureSkuIds.add("feature13");
        //adding AccessoryskuId
        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        line.setAccessorySkuIds(accessorySkuIds);
        line.setFeatureSkuIds(featureSkuIds);

        redisData.setLines(lines);

        return redisData;
    }

    String requestString = "{\n" +
            "  \"serviceHeader\": {\n" +
            "    \"clientId\": \"VZW-DOTCOM\",\n" +
            "    \"statusMsg\": \"PEGA generated message\",\n" +
            "    \"serviceName\": \"SalesOrderPurchase\",\n" +
            "    \"userId\": \"\",\n" +
            "    \"statusCode\": \"0\",\n" +
            "    \"sessionId\": \"\",\n" +
            "    \"correlationId\": \"soe-cart-2022.01.25.18.58.21-916.8608036659715\"\n" +
            "  },\n" +
            "  \"serviceBody\": {\n" +
            "    \"serviceRequest\": {\n" +
            "      \"context\": {\n" +
            "        \"caseId\": \"SOP-817289281-E01\",\n" +
            "        \"contextInfo\": {\n" +
            "          \"callReason\": \"SalesOrderPurchase\",\n" +
            "          \"processStep\": \"PlanSelection\",\n" +
            "          \"processAction\": \"addPlan\",\n" +
            "          \"intent\": \"Inline-CPC\"\n" +
            "        },\n" +
            "        \"customerInfo\": {\n" +
            "          \"throttleName\": \"|AccessoryInterestialProspect|\",\n" +
            "          \"bucketAllocator\": \"BAU\",\n" +
            "          \"customerType\": \"N\",\n" +
            "          \"accountNumber\": \"\",\n" +
            "          \"cartCreator\": \"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\n" +
            "          \"processingMTN\": \"newLine1\",\n" +
            "          \"registerNumber\": 0,\n" +
            "          \"mtnFlow\": \"P\",\n" +
            "          \"globalId\": \"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"\n" +
            "        },\n" +
            "        \"cartInfo\": {\n" +
            "          \"retrieveFeatureLossReferenceData\": \"Y\",\n" +
            "          \"parentMtn\": \"\",\n" +
            "          \"cartItemCount\": 0,\n" +
            "          \"cartId\": \"b83940f5-0276-407f-947f-c2a2fa819afe\",\n" +
            "          \"itemType\": \"PLAN\",\n" +
            "          \"intendType\": \"NSE\",\n" +
            "          \"action\": \"UPDATE\",\n" +
            "          \"lines\": [\n" +
            "            {\n" +
            "              \"plan\": {\n" +
            "                \"id\": \"50427\",\n" +
            "                \"isRecommendedPlan\": false\n" +
            "              },\n" +
            "              \"mtn\": \"newLine1\",\n" +
            "              \"editSim\": false,\n" +
            "              \"lineWithSkipMDN\": false,\n" +
            "              \"inWithVerizonOpted\": false,\n" +
            "              \"protectionNotRequired\": false\n" +
            "            }\n" +
            "          ],\n" +
            "          \"effectiveDate\": \"\",\n" +
            "          \"checkAutoPayDiscountEligible\": \"N\",\n" +
            "          \"discountPromoTotal\": 0,\n" +
            "          \"registerNumber\": 0,\n" +
            "          \"protectionNotRequired\": false\n" +
            "        }\n" +
            "      }\n" +
            "    }\n" +
            "  }\n" +
            "}";

    String requestString2 = "{\n" +
            "  \"serviceHeader\": {\n" +
            "    \"clientId\": \"VZW-DOTCOM\",\n" +
            "    \"statusMsg\": \"PEGA generated message\",\n" +
            "    \"serviceName\": \"SalesOrderPurchase\",\n" +
            "    \"userId\": \"\",\n" +
            "    \"statusCode\": \"0\",\n" +
            "    \"sessionId\": \"\",\n" +
            "    \"correlationId\": \"soe-cart-2022.01.25.18.58.21-916.8608036659715\"\n" +
            "  },\n" +
            "  \"serviceBody\": {\n" +
            "    \"serviceRequest\": {\n" +
            "      \"context\": {\n" +
            "        \"caseId\": \"SOP-817289281-E01\",\n" +
            "        \"contextInfo\": {\n" +
            "          \"callReason\": \"SalesOrderPurchase\",\n" +
            "          \"processStep\": \"PlanSelection\",\n" +
            "          \"processAction\": \"addPlan\",\n" +
            "          \"intent\": \"Inline-CPC\"\n" +
            "        },\n" +
            "        \"customerInfo\": {\n" +
            "          \"throttleName\": \"|AccessoryInterestialProspect|\",\n" +
            "          \"bucketAllocator\": \"BAU\",\n" +
            "          \"customerType\": \"N\",\n" +
            "          \"accountNumber\": \"\",\n" +
            "          \"cartCreator\": \"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\n" +
            "          \"processingMTN\": \"newLine1\",\n" +
            "          \"registerNumber\": 0,\n" +
            "          \"mtnFlow\": \"P\",\n" +
            "          \"globalId\": \"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"\n" +
            "        },\n" +
            "        \"cartInfo\": {\n" +
            "          \"retrieveFeatureLossReferenceData\": \"Y\",\n" +
            "          \"parentMtn\": \"\",\n" +
            "          \"cartItemCount\": 0,\n" +
            "          \"cartId\": \"b83940f5-0276-407f-947f-c2a2fa819afe\",\n" +
            "          \"itemType\": \"PLAN\",\n" +
            "          \"intendType\": \"NSE\",\n" +
            "          \"action\": \"UPDATE\",\n" +
            "          \"lines\": [\n" +
            "            {\n" +
            "              \"plan\": {\n" +
            "                \"id\": \"50427\",\n" +
            "                \"isRecommendedPlan\": false\n" +
            "              },\n" +
            "              \"mtn\": \"newLine1\",\n" +
            "              \"editSim\": false,\n" +
            "              \"lineWithSkipMDN\": false,\n" +
            "              \"inWithVerizonOpted\": false,\n" +
            "              \"protectionNotRequired\": false\n" +
            "            },{\n" +
            "              \"plan\": {\n" +
            "                \"id\": \"50427\",\n" +
            "                \"isRecommendedPlan\": false\n" +
            "              },\n" +
            "              \"mtn\": \"newLine2\",\n" +
            "              \"editSim\": false,\n" +
            "              \"lineWithSkipMDN\": false,\n" +
            "              \"inWithVerizonOpted\": false,\n" +
            "              \"protectionNotRequired\": false\n" +
            "            }\n" +
            "          ],\n" +
            "          \"effectiveDate\": \"\",\n" +
            "          \"checkAutoPayDiscountEligible\": \"N\",\n" +
            "          \"discountPromoTotal\": 0,\n" +
            "          \"registerNumber\": 0,\n" +
            "          \"protectionNotRequired\": false\n" +
            "        }\n" +
            "      }\n" +
            "    }\n" +
            "  }\n" +
            "}";


    @Test
    public void AddPlanCheckoutFlagTrueTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData();
        redisData.getLines().get(0).setCheckoutFlag(true);
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddPlanPEGARequest request = mapper.readValue(requestString, AddPlanPEGARequest.class);
        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        AddPlanPEGAResponse response = mapper.readValue(responseString, AddPlanPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddPlanPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddPlanPEGAResponse>> responseMono = helper.addPlan(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void AddPlanCheckoutFlagTrueResponse500Test() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"01\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData();
        redisData.getLines().get(0).setCheckoutFlag(true);
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddPlanPEGARequest request = mapper.readValue(requestString, AddPlanPEGARequest.class);
        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        AddPlanPEGAResponse response = mapper.readValue(responseString, AddPlanPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddPlanPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddPlanPEGAResponse>> responseMono = helper.addPlan(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void AddPlanCheckoutFlagTrueMtn2Test() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData();
        redisData.getLines().get(0).setCheckoutFlag(true);
        redisData.getLines().get(0).setMtn("newLine2");
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddPlanPEGARequest request = mapper.readValue(requestString, AddPlanPEGARequest.class);
        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        AddPlanPEGAResponse response = mapper.readValue(responseString, AddPlanPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddPlanPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddPlanPEGAResponse>> responseMono = helper.addPlan(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void AddPlanRedisLInesNullTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData();
        redisData.setLines(new ArrayList<PrepaidODRequestDataLines>());
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddPlanPEGARequest request = mapper.readValue(requestString, AddPlanPEGARequest.class);
        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        AddPlanPEGAResponse response = mapper.readValue(responseString, AddPlanPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddPlanPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddPlanPEGAResponse>> responseMono = helper.addPlan(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void AddPlanCheckoutFlagTruePLanNullTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData();
        redisData.getLines().get(0).setCheckoutFlag(true);

        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddPlanPEGARequest request = mapper.readValue(requestString, AddPlanPEGARequest.class);
        //Address address = new Address();
        List<Line> lines= Arrays.asList(request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines());
        lines.get(0).setPlan(null);
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        AddPlanPEGAResponse response = mapper.readValue(responseString, AddPlanPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddPlanPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddPlanPEGAResponse>> responseMono = helper.addPlan(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void AddPlanCheckoutFlagTrueMtnNullTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData();
        redisData.getLines().get(0).setCheckoutFlag(true);

        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddPlanPEGARequest request = mapper.readValue(requestString, AddPlanPEGARequest.class);
        //Address address = new Address();
        List<Line> lines= Arrays.asList(request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines());
        lines.get(0).setMtn(null);
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        AddPlanPEGAResponse response = mapper.readValue(responseString, AddPlanPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddPlanPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddPlanPEGAResponse>> responseMono = helper.addPlan(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void AddPlanRedisDataNullTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData();
        redisData.getLines().get(0).setCheckoutFlag(true);

        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddPlanPEGARequest request = mapper.readValue(requestString, AddPlanPEGARequest.class);
        //Address address = new Address();

        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        AddPlanPEGAResponse response = mapper.readValue(responseString, AddPlanPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddPlanPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.empty());
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddPlanPEGAResponse>> responseMono = helper.addPlan(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void AddPlanRedisDataExceptionTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        String mockRedisData = "value";
        AddPlanPEGARequest request = mapper.readValue(requestString, AddPlanPEGARequest.class);

        URI url = URI.create("http://localhost/testurl");

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddPlanPEGAResponse>> responseMono = helper.addPlan(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void requestLinesNullTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData();
        redisData.getLines().get(0).setCheckoutFlag(true);
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddPlanPEGARequest request = mapper.readValue(requestString, AddPlanPEGARequest.class);
        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
       Line[] lines= new Line[10];
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().setLines(lines);
        AddPlanPEGAResponse response = mapper.readValue(responseString, AddPlanPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddPlanPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddPlanPEGAResponse>> responseMono = helper.addPlan(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void AddPlanCheckoutFlagTrueTest_1() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData();
        redisData.getLines().get(0).setCheckoutFlag(true);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        PrepaidODRequestDataLines line1 = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setMtn("newLine1");
        line.setCheckoutFlag(true);
        line1.setMtn("newLine1");
        line1.setCheckoutFlag(true);
        lines.add(line);
        lines.add(line1);
        redisData.setLines(lines);
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddPlanPEGARequest request = mapper.readValue(requestString, AddPlanPEGARequest.class);
        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        AddPlanPEGAResponse response = mapper.readValue(responseString, AddPlanPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddPlanPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddPlanPEGAResponse>> responseMono = helper.addPlan(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void AddPlanCheckoutFlagTrueTest2() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData2();
        PrepaidODRequestDataLines lines=new PrepaidODRequestDataLines();
        lines.setSmartPhone(true);
        lines.setMtn("newLine2");
        lines.setPlanSorId("234");
        redisData.getLines().get(0).setCheckoutFlag(true);
        redisData.getLines().add(lines);
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddPlanPEGARequest request = mapper.readValue(requestString, AddPlanPEGARequest.class);
        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        AddPlanPEGAResponse response = mapper.readValue(responseString, AddPlanPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddPlanPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddPlanPEGAResponse>> responseMono = helper.addPlan(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void AddPlanCheckoutFlagTrueTest3() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData3();
        redisData.getLines().get(0).setCheckoutFlag(true);
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddPlanPEGARequest request = mapper.readValue(requestString, AddPlanPEGARequest.class);
        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        AddPlanPEGAResponse response = mapper.readValue(responseString, AddPlanPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddPlanPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddPlanPEGAResponse>> responseMono = helper.addPlan(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void AddPlanCheckoutFlagTrueTest4() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData4();
        redisData.getLines().get(0).setCheckoutFlag(true);
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddPlanPEGARequest request = mapper.readValue(requestString, AddPlanPEGARequest.class);
        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        AddPlanPEGAResponse response = mapper.readValue(responseString, AddPlanPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddPlanPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddPlanPEGAResponse>> responseMono = helper.addPlan(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void AddPlanCheckoutFlagTrueTest5() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData5();
        redisData.getLines().get(0).setCheckoutFlag(true);
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddPlanPEGARequest request = mapper.readValue(requestString, AddPlanPEGARequest.class);
        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        AddPlanPEGAResponse response = mapper.readValue(responseString, AddPlanPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddPlanPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
        ReflectionTestUtils.setField(helper,"accountOwner","false");
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddPlanPEGAResponse>> responseMono = helper.addPlan(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void AddPlanCheckoutFlagTrueTest6() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData5();
        redisData.getLines().get(0).setCheckoutFlag(true);
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        PrepaidODRequestDataLines line1 = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setMtn("newLine1");
        line.setCheckoutFlag(true);
        line1.setMtn("newLine2");
        line1.setCheckoutFlag(true);
        lines.add(line);
        lines.add(line1);
        redisData.setLines(lines);
        redisData.setLoggedIn(false);
        AddPlanPEGARequest request = mapper.readValue(requestString, AddPlanPEGARequest.class);
        Line[] requestLinesList= {};
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().setLines(requestLinesList);
        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        AddPlanPEGAResponse response = mapper.readValue(responseString, AddPlanPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        ReflectionTestUtils.setField(helper,"enablePricePlanRefresh","false");
        Mono<ResponseEntity<AddPlanPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddPlanPEGAResponse>> responseMono = helper.addPlan(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void AddPlanCheckoutFlagTrueTest7() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData5();
        redisData.getLines().get(0).setCheckoutFlag(true);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        PrepaidODRequestDataLines line1 = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setMtn("newLine1");
        line.setCheckoutFlag(true);
        line1.setMtn("newLine2");
        line1.setCheckoutFlag(true);
        lines.add(line);
        lines.add(line1);
        redisData.setLines(lines);
        redisData.setLoggedIn(false);
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddPlanPEGARequest request = mapper.readValue(requestString2, AddPlanPEGARequest.class);

        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        AddPlanPEGAResponse response = mapper.readValue(responseString, AddPlanPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        ReflectionTestUtils.setField(helper,"enablePricePlanRefresh","false");
        Mono<ResponseEntity<AddPlanPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddPlanPEGAResponse>> responseMono = helper.addPlan(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }


    @Test
    public void AddPlanCheckoutFlagFalseTest() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData();
        redisData.getLines().get(0).setCheckoutFlag(false);
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddPlanPEGARequest request = mapper.readValue(requestString, AddPlanPEGARequest.class);
        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        AddPlanPEGAResponse response = mapper.readValue(responseString, AddPlanPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddPlanPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddPlanPEGAResponse>> responseMono = helper.addPlan(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void AddPlanCheckoutFlagFalseTest2() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData();
        redisData.getLines().get(0).setCheckoutFlag(false);
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddPlanPEGARequest request = mapper.readValue(requestString, AddPlanPEGARequest.class);
        Line[] requestLinesList= {};
        request.getServiceBody().getServiceRequest().getContext().getCartInfo().setLines(requestLinesList);
        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        AddPlanPEGAResponse response = mapper.readValue(responseString, AddPlanPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddPlanPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddPlanPEGAResponse>> responseMono = helper.addPlan(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void AddPlanCheckoutFlagFalseTest3() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData();
        redisData.getLines().get(0).setCheckoutFlag(false);
        List<PrepaidODRequestDataLines> lines= redisData.getLines();
        PrepaidODRequestDataLines line1 = new PrepaidODRequestDataLines();
        line1.setMtn("newLine2");
        line1.setCheckoutFlag(false);
        line1.setPlanSorId("28365");
        lines.add(line1);
        redisData.setLines(lines);
        redisData.getLines().get(1).setFeatureSkuIds(null);
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        AddPlanPEGARequest request = mapper.readValue(requestString, AddPlanPEGARequest.class);
        ReflectionTestUtils.setField(helper,"enablePricePlanRefresh","false");
        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        AddPlanPEGAResponse response = mapper.readValue(responseString, AddPlanPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddPlanPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddPlanPEGAResponse>> responseMono = helper.addPlan(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void AddPlanCheckoutFlagFalseTestSetPLanNull() throws IOException {

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        PrepaidODRequestData redisData = getRedisData();
        redisData.getLines().get(0).setCheckoutFlag(false);
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);

        AddPlanPEGARequest request = mapper.readValue(requestString, AddPlanPEGARequest.class);
        Arrays.stream(request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()).findFirst().get().setPlan(null);
        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        AddPlanPEGAResponse response = mapper.readValue(responseString, AddPlanPEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<AddPlanPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<AddPlanPEGAResponse>> responseMono = helper.addPlan(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));
    }


}
