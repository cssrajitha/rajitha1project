package onevz.soe.prepay.adaptor.cart.helper;

import com.fasterxml.jackson.databind.ObjectMapper;
import net.jcip.annotations.NotThreadSafe;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.common.model.PrepaidODRequestDataAccessorySkuIds;
import onevz.soe.common.model.PrepaidODRequestDataLines;
import onevz.soe.prepay.adaptor.cart.model.cxp.request.RetreiveNpanXXRequestModel;
import onevz.soe.prepay.adaptor.cart.model.cxp.response.PageData;
import onevz.soe.prepay.adaptor.cart.model.cxp.response.PayLoad;
import onevz.soe.prepay.adaptor.cart.model.cxp.response.ResponseZipCodes;
import onevz.soe.prepay.adaptor.cart.model.cxp.response.RetrieveNpaNxxResponse;
import onevz.soe.prepay.adaptor.cart.model.play.Errors;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import onevz.soe.wsclient.prepay.webclient.model.PrepaidAdaptorWebClientRequest;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_DATA;
import static org.mockito.Mockito.when;

@WebFluxTest
@RunWith(SpringJUnit4ClassRunner.class)
@NotThreadSafe
public class PrepayAdaptorAssignMTNHelperTest {

    @Autowired
    PrepayAdaptorAssignMTNHelper helper;

    @MockBean
    PrepayCartRedisHelper redisHelper;

    @MockBean
    PrepayAdaptorWebClient prepayAdaptorWebClient;

    @Autowired
    ObjectMapper mapper;

    String requestString = "{\n" +
            "  \"serviceHeader\": {\n" +
            "    \"clientId\": \"VZW-DOTCOM\",\n" +
            "    \"statusMsg\": \"PEGA generated message\",\n" +
            "    \"serviceName\": \"SalesOrderPurchase\",\n" +
            "    \"userId\": \"\",\n" +
            "    \"statusCode\": \"0\",\n" +
            "    \"sessionId\": \"\",\n" +
            "    \"correlationId\": \"soe-cart-2022.01.25.18.58.21-916.8608036659715\"\n" +
            "  },\n" +
            "  \"serviceBody\": {\n" +
            "    \"serviceRequest\": {\n" +
            "      \"context\": {\n" +
            "        \"caseId\": \"SOP-817289281-E01\",\n" +
            "        \"contextInfo\": {\n" +
            "          \"callReason\": \"SalesOrderPurchase\",\n" +
            "          \"processStep\": \"PlanSelection\",\n" +
            "          \"processAction\": \"addPlan\",\n" +
            "          \"intent\": \"Inline-CPC\"\n" +
            "        },\n" +
            "        \"customerInfo\": {\n" +
            "          \"throttleName\": \"|AccessoryInterestialProspect|\",\n" +
            "          \"bucketAllocator\": \"BAU\",\n" +
            "          \"customerType\": \"N\",\n" +
            "          \"accountNumber\": \"\",\n" +
            "          \"cartCreator\": \"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\n" +
            "          \"processingMTN\": \"newLine1\",\n" +
            "          \"registerNumber\": 0,\n" +
            "          \"mtnFlow\": \"P\",\n" +
            "          \"globalId\": \"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"\n" +
            "        },\n" +
            "        \"cartInfo\": {\n" +
            "          \"retrieveFeatureLossReferenceData\": \"Y\",\n" +
            "          \"parentMtn\": \"\",\n" +
            "          \"cartItemCount\": 0,\n" +
            "          \"cartId\": \"b83940f5-0276-407f-947f-c2a2fa819afe\",\n" +
            "          \"itemType\": \"PLAN\",\n" +
            "          \"intendType\": \"NSE\",\n" +
            "          \"action\": \"UPDATE\",\n" +
            "          \"lines\": [\n" +
            "            {\n" +
            "              \"plan\": {\n" +
            "                \"id\": \"50427\",\n" +
            "                \"isRecommendedPlan\": false\n" +
            "              },\n" +
            "              \"mtn\": \"newLine1\",\n" +
            "              \"editSim\": false,\n" +
            "              \"lineWithSkipMDN\": false,\n" +
            "              \"inWithVerizonOpted\": false,\n" +
            "              \"protectionNotRequired\": false\n" +
            "            }\n" +
            "          ],\n" +
            "          \"effectiveDate\": \"\",\n" +
            "          \"checkAutoPayDiscountEligible\": \"N\",\n" +
            "          \"discountPromoTotal\": 0,\n" +
            "          \"registerNumber\": 0,\n" +
            "          \"protectionNotRequired\": false\n" +
            "        }\n" +
            "      }\n" +
            "    }\n" +
            "  }\n" +
            "}";

    private PrepaidODRequestData getRedisData(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setFlow("NSE");
        lines.add(line);

        //adding skuId
        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        line.setAccessorySkuIds(accessorySkuIds);

        redisData.setLines(lines);

        return redisData;
    }
    private PrepaidODRequestData getRedisData2(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setFlow("NSEBYOD");
        lines.add(line);

        //adding skuId
        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        line.setAccessorySkuIds(accessorySkuIds);

        redisData.setLines(lines);

        return redisData;
    }
    private PrepaidODRequestData getRedisData3(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setFlow("ESO");
        lines.add(line);

        //adding skuId
        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        line.setAccessorySkuIds(accessorySkuIds);

        redisData.setLines(lines);

        return redisData;
    }
    private PrepaidODRequestData getRedisData4(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setFlow("NSP");
        lines.add(line);

        //adding skuId
        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        line.setAccessorySkuIds(accessorySkuIds);

        redisData.setLines(lines);

        return redisData;
    }
    private PrepaidODRequestData getRedisData5(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setFlow("PASO");
        lines.add(line);

        //adding skuId
        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        line.setAccessorySkuIds(accessorySkuIds);

        redisData.setLines(lines);

        return redisData;
    }

    @Test
    public void retrieveNPANXXErrorTest() throws IOException{

        String responseString = "{\"status\":0,\"statusCode\":\"01\",\"errors\":{\"status\":400,\"ecommApiErrorList\":[{\"statusCode\":\"01\",\"message\":\"Nonumberavailableforthiszipcode71944pleasetrydifferentzipcode\",\"developerMessage\":\"Nonumberavailableforthiszipcode71944pleasetrydifferentzipcode\",\"moreInfo\":null,\"homeSafetyInfo\":null}]}}";
        PrepaidODRequestData redisData = getRedisData();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        RetreiveNpanXXRequestModel request = mapper.readValue(requestString, RetreiveNpanXXRequestModel.class);
        RetrieveNpaNxxResponse response = mapper.readValue(responseString, RetrieveNpaNxxResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<RetrieveNpaNxxResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(redisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<RetrieveNpaNxxResponse>> responseMono = helper.retrieveNPANXX(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void retrieveNPANXXErrorTest2() throws IOException{

        String responseString = "{\"status\":0,\"statusCode\":\"01\"}";
        PrepaidODRequestData redisData = getRedisData();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        RetreiveNpanXXRequestModel request = mapper.readValue(requestString, RetreiveNpanXXRequestModel.class);
        RetrieveNpaNxxResponse response = mapper.readValue(responseString, RetrieveNpaNxxResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<RetrieveNpaNxxResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(redisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<RetrieveNpaNxxResponse>> responseMono = helper.retrieveNPANXX(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void retrieveNPANXXEmptyRedisData() throws IOException{


        RetreiveNpanXXRequestModel request = mapper.readValue(requestString, RetreiveNpanXXRequestModel.class);
        URI url = URI.create("http://localhost/testurl");

        when(redisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(""));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<RetrieveNpaNxxResponse>> responseMono = helper.retrieveNPANXX(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void retrieveNPANXXErrorTestNonNullPayload() throws IOException{

        String responseString = "{\"status\":0,\"statusCode\":\"01\",\"payload\":\"\",\"errors\":{\"status\":400,\"ecommApiErrorList\":[{\"statusCode\":\"01\",\"message\":\"Nonumberavailableforthiszipcode71944pleasetrydifferentzipcode\",\"developerMessage\":\"Nonumberavailableforthiszipcode71944pleasetrydifferentzipcode\",\"moreInfo\":null,\"homeSafetyInfo\":null}]}}";
        PrepaidODRequestData redisData = getRedisData();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        RetreiveNpanXXRequestModel request = mapper.readValue(requestString, RetreiveNpanXXRequestModel.class);
        RetrieveNpaNxxResponse response = mapper.readValue(responseString, RetrieveNpaNxxResponse.class);
        ResponseZipCodes responseZipCodes=new ResponseZipCodes();
        PayLoad payLoad = new PayLoad();
        PageData pageData=new PageData();
        responseZipCodes.setPayload(payLoad);
        responseZipCodes.getPayload().setPageData(pageData);

        String[] mtns = {"random1", "random2"};

        responseZipCodes.getPayload().getPageData().setMtns(mtns);
        responseZipCodes.setStatusCode("01");
        Errors errors= new Errors();
        errors.setStatus(400);
        responseZipCodes.setErrors(errors);
        String responseZipCodesString=mapper.writeValueAsString(responseZipCodes);

        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<RetrieveNpaNxxResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(redisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseZipCodesString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<RetrieveNpaNxxResponse>> responseMono = helper.retrieveNPANXX(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void retrieveNPANXXTest() throws IOException{

        ResponseZipCodes responseZipCodes= new ResponseZipCodes();
        responseZipCodes.setStatus(200);
        PayLoad payLoad = new PayLoad();
        PageData pageData=new PageData();
        responseZipCodes.setPayload(payLoad);
        responseZipCodes.getPayload().setPageData(pageData);

        String[] mtns = {"random1", "random2"};

        responseZipCodes.getPayload().getPageData().setMtns(mtns);


        String responseZipCodesString = mapper.writeValueAsString(responseZipCodes);
        PrepaidODRequestData redisData = getRedisData();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        RetreiveNpanXXRequestModel request = mapper.readValue(requestString, RetreiveNpanXXRequestModel.class);
        //RetrieveNpaNxxResponse response = mapper.readValue(responseString, RetrieveNpaNxxResponse.class);
        URI url = URI.create("http://localhost/testurl");
        //Mono<ResponseEntity<RetrieveNpaNxxResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(redisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseZipCodesString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<RetrieveNpaNxxResponse>> responseMono = helper.retrieveNPANXX(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }


    public PrepaidAdaptorWebClientRequest getPrepaidLegacyServiceRequest(PrepaidODRequestData redisData) {
        PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
        Map<String, String> headers = new HashMap<>();
        //headers.put("p-csrf-token", redisData.getPCsrfToken());
        String prepayODCookie = "ECOMM_SESSION=" + redisData.getEcommSessionId() + ";" + "p_csrftkn=" + redisData.getPCsrfToken();
        headers.put("Cookie", prepayODCookie);

        prepaidAdaptorWebClientRequest.setRequestBody("{}");
        prepaidAdaptorWebClientRequest.setRequestType(HttpMethod.GET.toString());
        prepaidAdaptorWebClientRequest.setHeader(headers);
        return prepaidAdaptorWebClientRequest;
    }
    @Test
    public void retrieveNPANXXTest2() throws IOException{

        ResponseZipCodes responseZipCodes= new ResponseZipCodes();
        responseZipCodes.setStatus(200);
        PayLoad payLoad = new PayLoad();
        PageData pageData=new PageData();
        responseZipCodes.setPayload(payLoad);
        responseZipCodes.getPayload().setPageData(pageData);

        String[] mtns = {"random1", "random2"};

        responseZipCodes.getPayload().getPageData().setMtns(mtns);


        String responseZipCodesString = mapper.writeValueAsString(responseZipCodes);
        PrepaidODRequestData redisData = getRedisData2();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        RetreiveNpanXXRequestModel request = mapper.readValue(requestString, RetreiveNpanXXRequestModel.class);
        //RetrieveNpaNxxResponse response = mapper.readValue(responseString, RetrieveNpaNxxResponse.class);
        URI url = URI.create("http://localhost/testurl");
        //Mono<ResponseEntity<RetrieveNpaNxxResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(redisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseZipCodesString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<RetrieveNpaNxxResponse>> responseMono = helper.retrieveNPANXX(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void retrieveNPANXXTest3() throws IOException{

        ResponseZipCodes responseZipCodes= new ResponseZipCodes();
        responseZipCodes.setStatus(200);
        PayLoad payLoad = new PayLoad();
        PageData pageData=new PageData();
        responseZipCodes.setPayload(payLoad);
        responseZipCodes.getPayload().setPageData(pageData);

        String[] mtns = {"random1", "random2"};

        responseZipCodes.getPayload().getPageData().setMtns(mtns);


        String responseZipCodesString = mapper.writeValueAsString(responseZipCodes);
        PrepaidODRequestData redisData = getRedisData3();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        RetreiveNpanXXRequestModel request = mapper.readValue(requestString, RetreiveNpanXXRequestModel.class);
        //RetrieveNpaNxxResponse response = mapper.readValue(responseString, RetrieveNpaNxxResponse.class);
        URI url = URI.create("http://localhost/testurl");
        //Mono<ResponseEntity<RetrieveNpaNxxResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(redisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseZipCodesString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<RetrieveNpaNxxResponse>> responseMono = helper.retrieveNPANXX(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void retrieveNPANXXTest4() throws IOException{

        ResponseZipCodes responseZipCodes= new ResponseZipCodes();
        responseZipCodes.setStatus(200);
        PayLoad payLoad = new PayLoad();
        PageData pageData=new PageData();
        responseZipCodes.setPayload(payLoad);
        responseZipCodes.getPayload().setPageData(pageData);

        String[] mtns = {"random1", "random2"};

        responseZipCodes.getPayload().getPageData().setMtns(mtns);


        String responseZipCodesString = mapper.writeValueAsString(responseZipCodes);
        PrepaidODRequestData redisData = getRedisData4();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        RetreiveNpanXXRequestModel request = mapper.readValue(requestString, RetreiveNpanXXRequestModel.class);
        //RetrieveNpaNxxResponse response = mapper.readValue(responseString, RetrieveNpaNxxResponse.class);
        URI url = URI.create("http://localhost/testurl");
        //Mono<ResponseEntity<RetrieveNpaNxxResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(redisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseZipCodesString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<RetrieveNpaNxxResponse>> responseMono = helper.retrieveNPANXX(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void retrieveNPANXXTest5() throws IOException{

        ResponseZipCodes responseZipCodes= new ResponseZipCodes();
        responseZipCodes.setStatus(200);
        PayLoad payLoad = new PayLoad();
        PageData pageData=new PageData();
        responseZipCodes.setPayload(payLoad);
        responseZipCodes.getPayload().setPageData(pageData);

        String[] mtns = {"235-7279", "2692840-2048"};

        responseZipCodes.getPayload().getPageData().setMtns(mtns);


        String responseZipCodesString = mapper.writeValueAsString(responseZipCodes);
        PrepaidODRequestData redisData = getRedisData5();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        RetreiveNpanXXRequestModel request = mapper.readValue(requestString, RetreiveNpanXXRequestModel.class);
        //RetrieveNpaNxxResponse response = mapper.readValue(responseString, RetrieveNpaNxxResponse.class);
        URI url = URI.create("http://localhost/testurl");
        //Mono<ResponseEntity<RetrieveNpaNxxResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(redisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseZipCodesString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<RetrieveNpaNxxResponse>> responseMono = helper.retrieveNPANXX(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
}
