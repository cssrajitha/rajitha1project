package onevz.soe.prepay.adaptor.cart.util;

import onevz.soe.common.model.PrepaidODRequestData;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.http.HttpHeaders;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

@RunWith(SpringJUnit4ClassRunner.class)
public class PrepayAdaptorCartUtilTest {

    @Test
    public void getPrepayODServiceCommonHeadersNSETest() {
        PrepaidODRequestData prepaidODRequestData = this.getSampleData();
        Map<String,String> headers = PrepayAdaptorCartUtil.getPrepayODServiceCommonHeaders(prepaidODRequestData);
        Assert.assertTrue(headers.get(HttpHeaders.COOKIE).endsWith(PREPAY_OD_REQUEST_FLOW + "=" + NSE + ";"));
    }

    @Test
    public void getPrepayODServiceCommonHeadersEUPTest() {
        PrepaidODRequestData prepaidODRequestData = this.getSampleData();
        Map<String,String> headers = PrepayAdaptorCartUtil.getPrepayODServiceCommonHeaders(prepaidODRequestData,EUP);
        Assert.assertTrue(headers.get(HttpHeaders.COOKIE).endsWith(PREPAY_OD_REQUEST_FLOW + "=" + PUP + ";"));
    }

    @Test
    public void getPrepayODServiceCommonHeadersAALTest() {
        PrepaidODRequestData prepaidODRequestData = this.getSampleData();
        Map<String,String> headers = PrepayAdaptorCartUtil.getPrepayODServiceCommonHeaders(prepaidODRequestData,AAL);
        Assert.assertTrue(headers.get(HttpHeaders.COOKIE).endsWith(PREPAY_OD_REQUEST_FLOW + "=" + PAL + ";"));
    }

    @Test
    public void getPrepayODServiceCommonHeadersBYODTest() {
        PrepaidODRequestData prepaidODRequestData = this.getSampleData();
        Map<String,String> headers = PrepayAdaptorCartUtil.getPrepayODServiceCommonHeaders(prepaidODRequestData, NSE_BYOD);
        Assert.assertTrue(headers.get(HttpHeaders.COOKIE).endsWith(PREPAY_OD_REQUEST_FLOW + "=" + NSP + ";"));
    }
    
    @Test
    public void getPrepayODServiceCommonHeadersBYODNSPTest() {
        PrepaidODRequestData prepaidODRequestData = this.getSampleData();
        Map<String,String> headers = PrepayAdaptorCartUtil.getPrepayODServiceCommonHeaders(prepaidODRequestData, NSP);
        Assert.assertTrue(headers.get(HttpHeaders.COOKIE).endsWith(PREPAY_OD_REQUEST_FLOW + "=" + NSP + ";"));
    }

    @Test
    public void getPrepayODServiceCommonHeadersPASOTest() {
        PrepaidODRequestData prepaidODRequestData = this.getSampleData();
        Map<String,String> headers = PrepayAdaptorCartUtil.getPrepayODServiceCommonHeaders(prepaidODRequestData, PASO);
        Assert.assertTrue(headers.get(HttpHeaders.COOKIE).endsWith(PREPAY_OD_REQUEST_FLOW + "=" + PASO + ";"));
    }
    
    @Test
    public void getPrepayODServiceCommonHeadersNULLTest() {
        PrepaidODRequestData prepaidODRequestData = this.getSampleData();
        Map<String,String> headers = PrepayAdaptorCartUtil.getPrepayODServiceCommonHeaders(prepaidODRequestData, ESO);
        Assert.assertTrue(headers.get(HttpHeaders.COOKIE).endsWith(PREPAY_OD_REQUEST_FLOW + "=" + PASO + ";"));
    }

    private PrepaidODRequestData getSampleData() {
        PrepaidODRequestData prepaidODRequestData = new PrepaidODRequestData();
        prepaidODRequestData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9.xxxxxxxx.Oa460tJGqs3hHDkSdHWKZHxbO_Q2k9q_11G7KEb1XIs");
        prepaidODRequestData.setPCsrfToken("8ee07e882a7a5583683d05e1580bf4552d97b3ca-123456789-bec3c805b5d825b518edd01e");
        return prepaidODRequestData;
    }

    @Test
    public void getChannelTypeTest() {
        assertEquals(DIGITAL_CHANNEL, PrepayAdaptorCartUtil.getChannelType(VZW_DOTCOM));
    }

    @Test
    public void getChannelTypeEmptyTest() {
        assertEquals("", PrepayAdaptorCartUtil.getChannelType("XYZ_ABC"));
    }

    @Test
    public void getChannelTest() {
        assertEquals(DIGITAL_CHANNEL, PrepayAdaptorCartUtil.getChannel(VZW_DOTCOM));
    }

    @Test
    public void getChannelNullTest() {
        assertNull(PrepayAdaptorCartUtil.getChannel("XYZ_ABC"));
    }

    @Test
    public void removeSpecialCharactersTest() {
        assertEquals("XYZabcPQR", PrepayAdaptorCartUtil.removeSpecialCharacters("XYZ-abc:PQR", OMNI_CARE));
    }

    @Test
    public void isDigitalTest() {
        Assert.assertTrue(PrepayAdaptorCartUtil.isDigital(VZW_DOTCOM));
    }

    @Test
    public void isDigitalChannelTest() {
        Assert.assertTrue(PrepayAdaptorCartUtil.isDigitalChannel(VZW_DOTCOM));
    }

    @Test
    public void responseToJsonEntityConverterTest() {
        Assert.assertNotNull(PrepayAdaptorCartUtil.responseToJsonEntityConverter().get(0));
    }

    @Test
    public void isCollectionEmptyTest() {
        Assert.assertTrue(PrepayAdaptorCartUtil.isCollectionEmpty(new ArrayList<>()));
    }

    @Test
    public void isCollectionEmptyWithNullTest() {
        List list = new ArrayList();
        list.add(null);
        Assert.assertTrue(PrepayAdaptorCartUtil.isCollectionEmpty(list));
    }

    @Test
    public void isCollectionNotEmptyTest() {
        Assert.assertFalse(PrepayAdaptorCartUtil.isCollectionNotEmpty(new ArrayList<>()));
    }

    @Test
    public void buildErrorResponseTest() {
        Assert.assertNotNull(PrepayAdaptorCartUtil.buildErrorResponse("name", "id", "message", "category").get(0));
    }

    @Test
    public void getODFlowNameNullTest() {
        String flowName =null;
        assertNull(flowName);
        String actual = PrepayAdaptorCartUtil.getODFlowName(flowName);
        assertEquals(null, flowName);
    }

}