package onevz.soe.prepay.adaptor.cart.helper;

import com.fasterxml.jackson.databind.ObjectMapper;
import net.jcip.annotations.NotThreadSafe;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.common.model.PrepaidODRequestDataAccessorySkuIds;
import onevz.soe.common.model.PrepaidODRequestDataLines;
import onevz.soe.orderprocess.model.checkoutdetails.*;
import onevz.soe.orderprocess.request.CheckoutDetailsCXPRequest;
import onevz.soe.orderprocess.response.cxp.CheckoutDetailsCXPResponse;
import onevz.soe.orderprocess.response.cxp.CheckoutDetailsResponseData;
import onevz.soe.prepay.adaptor.cart.model.cart.vo.*;
import onevz.soe.prepay.adaptor.cart.model.play.VZWPrepayOrderVO;
import onevz.soe.prepay.adaptor.cart.model.play.shippingoptions.AvailableDeliveryWindows;
import onevz.soe.prepay.adaptor.cart.model.play.shippingoptions.ShippingOption;
import onevz.soe.prepay.adaptor.cart.model.play.shippingoptions.VZWPrepayShippingResponseVO;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebFluxTest
@RunWith(SpringJUnit4ClassRunner.class)
@NotThreadSafe
public class PrepayAdaptorCheckOutDetailsODToCXPRespConverterTest {

    @Autowired
    PrepayAdaptorCheckOutDetailsODToCXPRespConverter converter;

    @Autowired
    ObjectMapper mapper;

    private PrepaidODRequestData getPrepaidODRequestData(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();

        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setMtn("newLine1");
        line.setCheckoutFlag(true);
        line.setESimId("423442475431232");
        line.setLineItemId("random01");
        lines.add(line);

        List<String> featureSkuIds = new ArrayList<>();
        featureSkuIds.add("sku3920521");
        featureSkuIds.add("feature13");
        //adding AccessoryskuId
        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        line.setAccessorySkuIds(accessorySkuIds);
        line.setFeatureSkuIds(featureSkuIds);

        redisData.setLines(lines);

        return redisData;
    }
    private PrepaidODRequestData getPrepaidODRequestData2(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setLoggedIn(true);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();

        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setMtn("newLine1");
        line.setCheckoutFlag(true);
        line.setESimId("423442475431232");
        line.setLineItemId("S007194d00ba2177707ac8cf9fcbd4bd7{as4}_device_961754431");
        lines.add(line);

        List<String> featureSkuIds = new ArrayList<>();
        featureSkuIds.add("sku3920521");
        featureSkuIds.add("feature13");
        //adding AccessoryskuId
        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        line.setAccessorySkuIds(accessorySkuIds);
        line.setFeatureSkuIds(featureSkuIds);

        redisData.setLines(lines);

        return redisData;
    }

    @Test
    public void translateCheckoutDetailsTest() throws IOException{

        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        CheckoutDetailsCXPRequest request = mapper.readValue(requestString, CheckoutDetailsCXPRequest.class);
        CheckoutDetailsCXPResponse response = mapper.readValue(responseString, CheckoutDetailsCXPResponse.class);
        //   PrepayAdaptorCheckOutDetailsODToCXPRespConverter converter = new PrepayAdaptorCheckOutDetailsODToCXPRespConverter();

        URI url = URI.create("http://localhost/test");
        Mono<ResponseEntity<String>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body("test"));
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        PrepayAccessoryVO prepayAccessoryVO = new PrepayAccessoryVO();
        prepayAccessoryVO.setDeviceCommerceItemId("random01");

        List<PrepayAccessoryVO> prepayAccessoryVOList = new ArrayList<>();

        //promotions
        VZWPrepayPromotion prepayPromotion = new VZWPrepayPromotion();
        List<VZWPrepayPromotion> prepayPromotionList = new ArrayList<>();
        prepayPromotionList.add(prepayPromotion);

        //AccountInfo
        AccountInfoVO accountInfoVO = new AccountInfoVO();

        //tax details
        ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();

        TaxDetailInfo taxDetailInfo = new TaxDetailInfo();
        //taxDetailInfo.setTaxDescription(key);
        //taxDetailInfo.setTaxAmount(String.valueOf(value));
        taxDetailInfoList.add(taxDetailInfo);
        HashMap<String, Double> taxDetails = new HashMap<>();
        taxDetails.putIfAbsent("random1", 22.1);



        //Address
        AddressVO addressVO = new AddressVO();
        addressVO.setAddressLine1("harrongton drive Ohio");
        addressVO.setEmailAddress("test@gmail.com");
        addressVO.setAltPhoneNumber("8989898989898989");
        accountInfoVO.setAddress(addressVO);
        List<PrepayDeviceVO> prepayDeviceVOList = new ArrayList<>();
        PrepayDeviceVO prepayDeviceVO = new PrepayDeviceVO();
        prepayDeviceVO.setId("random01");
        prepayDeviceVO.setPurchasePath("NAP");
        prepayDeviceVO.setImei2("imei2");
        prepayDeviceVOList.add(0,prepayDeviceVO);

        prepayDeviceVO.setTaxDetails(taxDetails);

        VZWPrepayOrderVO pageData = new VZWPrepayOrderVO();
        pageData.setSessionId("123");
        pageData.setPaymentMethod("VISA Y");
        pageData.setDeviceList(prepayDeviceVOList);
        pageData.setAccessoryList(prepayAccessoryVOList);
        pageData.setAccountInfo(accountInfoVO);
        pageData.setPromotions(prepayPromotionList);
        pageData.setDevicePromotionId("test");
        PrepayAccessoryVO prepayAccessoryVO1 = new PrepayAccessoryVO();
        prepayAccessoryVO1.setDeviceCommerceItemId("deviceId1");
        TaxDetail taxDetail= new TaxDetail();
        taxDetail.setTaxAmount(5000.00);
        List<TaxDetail> taxDetails2= new ArrayList<TaxDetail>();
        taxDetails2.add(taxDetail);
        prepayAccessoryVO1.setTaxDetails(taxDetails2);
        PrepayAccessoryVO prepayAccessoryVO2 = new PrepayAccessoryVO();
        List<PrepayAccessoryVO> prepayAccessoryVOS = new ArrayList<>();
//        prepayAccessoryVOS.add(prepayAccessoryVO1);
//        prepayAccessoryVOS.add(prepayAccessoryVO2);
        pageData.setAccessoryList(prepayAccessoryVOS);

        pageData.getDeviceList().get(0).setPlanItemId("randomPlanItem");
        pageData.getDeviceList().get(0).setId("deviceId1");
        pageData.getDeviceList().get(0).setNumberShareLineItemId("S007194d00ba2177707ac8cf9fcbd4bd7{as4}_device_961754431");
        List<PrepayPlanVO> planList = new ArrayList<>();
        PrepayPlanVO planVO1 = new PrepayPlanVO();
        PrepayPlanVO planVO2 = new PrepayPlanVO();
        planVO1.setId("randomPlanItem");
        planVO1.setFeatureLineItemId("featureLineItemId");
        planVO1.setSorId("28401");
        planVO1.setSkuDisplayName("Sample Plan Sku");
        planVO1.setPlanSize("15GB");
        planVO1.setActualPlanPrice(50.00);
        planVO1.setDueMonthly(40.00);
        planVO1.setDiscount(10.00);
        planVO1.setAutoPaySaving(10.00);
        planVO1.setPlanBundleDiscount(5.00);
        planVO1.setBundleDiscountApplied(true);

        planList.add(planVO1);
        planList.add(planVO2);
        pageData.setPlanList(planList);
        pageData.setOrderNumber("95461423448");
        PrepayFeatureVO prepayFeatureVO = new PrepayFeatureVO();
        prepayFeatureVO.setSorId("sorId");
        prepayFeatureVO.setSkuId("skuId");
        prepayFeatureVO.setDisplayName("displayName");
        prepayFeatureVO.setDueMonthly(3.02);
        List<PrepayFeatureVO> prepayFeatureVOS = new ArrayList<>();
        prepayFeatureVOS.add(prepayFeatureVO);
        pageData.setFeatureList(prepayFeatureVOS);
        pageData.setAutoPayEnabled(false);
       /* List<PrepaidODRequestDataLines> numberShareId = new ArrayList<>();
        numberShareId.get(0).setSelectedMtn("559-807-XXXX");
        numberShareId.get(0).setDisplayName("iPhone 12");
        NumberShareDeviceInfo numberShareDeviceInfo = new NumberShareDeviceInfo();
        numberShareDeviceInfo.setLineNo(numberShareId.get(0).getSelectedMtn());
        numberShareDeviceInfo.setName(numberShareId.get(0).getDisplayName());
        CartLineInfo lineInfoItem = new CartLineInfo();
        lineInfoItem.setNumberShareDeviceInfo(numberShareDeviceInfo);*/
        CheckoutDetailsCXPResponse res = converter.translateCheckoutDetails(pageData, getPrepaidODRequestData(), httpRequest, request);
        Assert.assertEquals(pageData.getSessionId(), res.getData().getCart().getCartHeader().getSessionId());
        Assert.assertNotNull(res.getData().getCart().getCartHeader().getSourceSystem());

    }
    @Test
    public void translateCheckoutDetailsTest2() throws IOException{

        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        CheckoutDetailsCXPRequest request = mapper.readValue(requestString, CheckoutDetailsCXPRequest.class);
        CheckoutDetailsCXPResponse response = mapper.readValue(responseString, CheckoutDetailsCXPResponse.class);
        //   PrepayAdaptorCheckOutDetailsODToCXPRespConverter converter = new PrepayAdaptorCheckOutDetailsODToCXPRespConverter();

        URI url = URI.create("http://localhost/test");
        Mono<ResponseEntity<String>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body("test"));
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        PrepayAccessoryVO prepayAccessoryVO = new PrepayAccessoryVO();
        prepayAccessoryVO.setDeviceCommerceItemId("random01");

        List<PrepayAccessoryVO> prepayAccessoryVOList = new ArrayList<>();

        //promotions
        VZWPrepayPromotion prepayPromotion = new VZWPrepayPromotion();
        List<VZWPrepayPromotion> prepayPromotionList = new ArrayList<>();
        prepayPromotionList.add(prepayPromotion);

        //AccountInfo
        AccountInfoVO accountInfoVO = new AccountInfoVO();

        //tax details
        ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();

        TaxDetailInfo taxDetailInfo = new TaxDetailInfo();
        //taxDetailInfo.setTaxDescription(key);
        //taxDetailInfo.setTaxAmount(String.valueOf(value));
        taxDetailInfoList.add(taxDetailInfo);
        HashMap<String, Double> taxDetails = new HashMap<>();
        taxDetails.putIfAbsent("random1", 22.1);

        //Address
        AddressVO addressVO = new AddressVO();
        addressVO.setAddressLine1("harrongton drive Ohio");
        accountInfoVO.setAddress(addressVO);
        List<PrepayDeviceVO> prepayDeviceVOList = new ArrayList<>();
        PrepayDeviceVO prepayDeviceVO = new PrepayDeviceVO();
        prepayDeviceVO.setId("random01");
        prepayDeviceVO.setPurchasePath("NAP");
        prepayDeviceVO.setItemType("Smartwatch");
        prepayDeviceVO.setDeviceSorType("5GE");
        prepayDeviceVO.setBrandName("Apple");
        prepayDeviceVO.setNumberShareLineItemId("S007194d00ba2177707ac8cf9fcbd4bd7{as4}_device_961754431");
     //   prepayDeviceVO.setImei2("imei2");
        prepayDeviceVOList.add(0,prepayDeviceVO);

        prepayDeviceVO.setTaxDetails(taxDetails);

        VZWPrepayOrderVO pageData = new VZWPrepayOrderVO();
        pageData.setSessionId("123");
        pageData.setDeviceList(prepayDeviceVOList);
        pageData.setAccessoryList(prepayAccessoryVOList);
        pageData.setAccountInfo(accountInfoVO);
        pageData.setOrderZipcode("75038");
        pageData.setPromotions(prepayPromotionList);
        PrepayAccessoryVO prepayAccessoryVO1 = new PrepayAccessoryVO();
        prepayAccessoryVO1.setDeviceCommerceItemId("deviceId1");
        PrepayAccessoryVO prepayAccessoryVO2 = new PrepayAccessoryVO();
        List<PrepayAccessoryVO> prepayAccessoryVOS = new ArrayList<>();
//        prepayAccessoryVOS.add(prepayAccessoryVO1);
//        prepayAccessoryVOS.add(prepayAccessoryVO2);
        pageData.setAccessoryList(prepayAccessoryVOS);

        pageData.getDeviceList().get(0).setPlanItemId("randomPlanItem");
        pageData.getDeviceList().get(0).setId("deviceId1");
        pageData.setEnableFamilyPricing(true);
        List<PrepayPlanVO> planList = new ArrayList<>();
        PrepayPlanVO planVO1 = new PrepayPlanVO();
        PrepayPlanVO planVO2 = new PrepayPlanVO();
        PrepayPlanVO planVO3 = new PrepayPlanVO();
        planVO1.setId("randomPlanItem");
        planVO1.setFeatureLineItemId("featureLineItemId");
        planVO1.setSorId("28401");
        planVO1.setSkuDisplayName("Sample Plan Sku");
        planVO1.setPlanSize("Unlimited");
        planVO1.setDescription("$75 Smartphone Plan");
        planVO2.setBundleDiscountApplied(false);
        planVO2.setDescription("Unlimited");
        planVO3.setBundleDiscountApplied(false);
        planVO3.setDescription("ABCDEF");
        planVO1.setActualPlanPrice(70.00);
        planVO1.setAutoPaySaving(10.00);
        planVO1.setDiscount(20.00);
        planVO1.setBundleDiscountApplied(true);
        planList.add(planVO1);
        planList.add(planVO2);
        planList.add(planVO3);
        pageData.setPlanList(planList);
        PrepayFeatureVO prepayFeatureVO = new PrepayFeatureVO();
        prepayFeatureVO.setSorId("sorId");
        prepayFeatureVO.setSkuId("skuId");
        prepayFeatureVO.setDisplayName("displayName");
        prepayFeatureVO.setDueMonthly(3.02);
        List<PrepayFeatureVO> prepayFeatureVOS = new ArrayList<>();
        prepayFeatureVOS.add(prepayFeatureVO);
        pageData.setFeatureList(prepayFeatureVOS);
        pageData.setAutoPayEnabled(true);
        CheckoutDetailsCXPResponse res = converter.translateCheckoutDetails(pageData, getPrepaidODRequestData2(), httpRequest, request);
        Assert.assertEquals(pageData.getSessionId(), res.getData().getCart().getCartHeader().getSessionId());
        Assert.assertNotNull(res.getData().getCart().getCartHeader().getSourceSystem());

    }
    @Test
    public void translateCheckoutDetailsTest3() throws IOException{

        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        CheckoutDetailsCXPRequest request = mapper.readValue(requestString, CheckoutDetailsCXPRequest.class);
        CheckoutDetailsCXPResponse response = mapper.readValue(responseString, CheckoutDetailsCXPResponse.class);
        //   PrepayAdaptorCheckOutDetailsODToCXPRespConverter converter = new PrepayAdaptorCheckOutDetailsODToCXPRespConverter();

        URI url = URI.create("http://localhost/test");
        Mono<ResponseEntity<String>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body("test"));
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        PrepayAccessoryVO prepayAccessoryVO = new PrepayAccessoryVO();
        prepayAccessoryVO.setDeviceCommerceItemId("random01");

        List<PrepayAccessoryVO> prepayAccessoryVOList = new ArrayList<>();

        //promotions
        VZWPrepayPromotion prepayPromotion = new VZWPrepayPromotion();
        List<VZWPrepayPromotion> prepayPromotionList = new ArrayList<>();
        prepayPromotionList.add(prepayPromotion);

        //AccountInfo
        AccountInfoVO accountInfoVO = new AccountInfoVO();

        //tax details
        ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();

        TaxDetailInfo taxDetailInfo = new TaxDetailInfo();
        //taxDetailInfo.setTaxDescription(key);
        //taxDetailInfo.setTaxAmount(String.valueOf(value));
        taxDetailInfoList.add(taxDetailInfo);
        HashMap<String, Double> taxDetails = new HashMap<>();
        taxDetails.putIfAbsent("random1", 22.1);

        //Address
        AddressVO addressVO = new AddressVO();
        addressVO.setAddressLine1("harrongton drive Ohio");
        accountInfoVO.setAddress(addressVO);
        List<PrepayDeviceVO> prepayDeviceVOList = new ArrayList<>();
        PrepayDeviceVO prepayDeviceVO = new PrepayDeviceVO();
        prepayDeviceVO.setId("random01");
        prepayDeviceVO.setPurchasePath("NSE");
        prepayDeviceVO.setItemType("SMARTPHONE");
        prepayDeviceVO.setDeviceSorType("5GE");
        prepayDeviceVO.setBrandName("Apple");
        prepayDeviceVO.setImei2("imei2");
        prepayDeviceVOList.add(0,prepayDeviceVO);

        prepayDeviceVO.setTaxDetails(taxDetails);

        VZWPrepayOrderVO pageData = new VZWPrepayOrderVO();
        pageData.setSessionId("123");
        pageData.setPaymentMethod("X Y");
        pageData.setDeviceList(prepayDeviceVOList);
        pageData.setAccessoryList(prepayAccessoryVOList);
        pageData.setAccountInfo(accountInfoVO);
        pageData.setOrderNumber("95461423448");
        pageData.setPromotions(prepayPromotionList);
        PrepayAccessoryVO prepayAccessoryVO1 = new PrepayAccessoryVO();
        prepayAccessoryVO1.setDeviceCommerceItemId("deviceId1");
        PrepayAccessoryVO prepayAccessoryVO2 = new PrepayAccessoryVO();
        List<PrepayAccessoryVO> prepayAccessoryVOS = new ArrayList<>();
//        prepayAccessoryVOS.add(prepayAccessoryVO1);
//        prepayAccessoryVOS.add(prepayAccessoryVO2);
        pageData.setAccessoryList(prepayAccessoryVOS);

        pageData.getDeviceList().get(0).setPlanItemId("randomPlanItem");
        pageData.getDeviceList().get(0).setNumberShareLineItemId("S007194d00ba2177707ac8cf9fcbd4bd7{as4}_device_961754431");
        List<PrepayPlanVO> planList = new ArrayList<>();
        PrepayPlanVO planVO1 = new PrepayPlanVO();
        PrepayPlanVO planVO2 = new PrepayPlanVO();
        planVO1.setId("randomPlanItem");
        planVO1.setFeatureLineItemId("featureLineItemId");
        planVO1.setSorId("28401");
        planVO1.setSkuDisplayName("Sample Plan Sku");
        planVO1.setPlanSize("Unlimited Plus");
        planVO1.setDescription("Tablet");
        planVO1.setActualPlanPrice(50.00);
        planVO1.setDisneyPlusPromo(true);
        planVO1.setDueMonthly(40.00);
        planVO1.setDiscount(10.00);
        planVO1.setAutoPaySaving(10.00);
        planList.add(planVO1);
        planList.add(planVO2);
        pageData.setPlanList(planList);
        PrepayFeatureVO prepayFeatureVO = new PrepayFeatureVO();
        prepayFeatureVO.setId("featureLineItemId");
        prepayFeatureVO.setSorId("sorId");
        prepayFeatureVO.setSkuId("skuId");
        prepayFeatureVO.setDisplayName("displayName");
        prepayFeatureVO.setDueMonthly(3.02);
        List<PrepayFeatureVO> prepayFeatureVOS = new ArrayList<>();
        prepayFeatureVOS.add(prepayFeatureVO);
        pageData.setFeatureList(prepayFeatureVOS);
        pageData.setAutoPayEnabled(false);
        CheckoutDetailsCXPResponse res = converter.translateCheckoutDetails(pageData, getPrepaidODRequestData(), httpRequest, request);
        Assert.assertEquals(pageData.getSessionId(), res.getData().getCart().getCartHeader().getSessionId());
        Assert.assertNotNull(res.getData().getCart().getCartHeader().getSourceSystem());

    }
    @Test
    public void translateCheckoutDetailsTest4() throws IOException{

        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        CheckoutDetailsCXPRequest request = mapper.readValue(requestString, CheckoutDetailsCXPRequest.class);
        CheckoutDetailsCXPResponse response = mapper.readValue(responseString, CheckoutDetailsCXPResponse.class);
        //   PrepayAdaptorCheckOutDetailsODToCXPRespConverter converter = new PrepayAdaptorCheckOutDetailsODToCXPRespConverter();

        URI url = URI.create("http://localhost/test");
        Mono<ResponseEntity<String>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body("test"));
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        PrepayAccessoryVO prepayAccessoryVO = new PrepayAccessoryVO();
        prepayAccessoryVO.setDeviceCommerceItemId("random01");

        List<PrepayAccessoryVO> prepayAccessoryVOList = new ArrayList<>();

        //promotions
        VZWPrepayPromotion prepayPromotion = new VZWPrepayPromotion();
        List<VZWPrepayPromotion> prepayPromotionList = new ArrayList<>();
        prepayPromotionList.add(prepayPromotion);

        //AccountInfo
        AccountInfoVO accountInfoVO = new AccountInfoVO();

        //tax details
        ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();

        TaxDetailInfo taxDetailInfo = new TaxDetailInfo();
        //taxDetailInfo.setTaxDescription(key);
        //taxDetailInfo.setTaxAmount(String.valueOf(value));
        taxDetailInfoList.add(taxDetailInfo);
        HashMap<String, Double> taxDetails = new HashMap<>();
        taxDetails.putIfAbsent("random1", 22.1);

        //Address
        AddressVO addressVO = new AddressVO();
        addressVO.setAddressLine1("harrongton drive Ohio");
        accountInfoVO.setAddress(addressVO);

        VZWPrepayOrderVO pageData = new VZWPrepayOrderVO();
        pageData.setSessionId("123");
        pageData.setPaymentMethod("RC");
        List<String> refillCards= new ArrayList<String>();
        refillCards.add("12345688975");
        pageData.setRefillCards(refillCards);
        VZWPrepayPaymentVO vzwPrepayPaymentVO = new VZWPrepayPaymentVO();
        List<VZWPrepayRefillCardPaymentVO>  paymentGrpIdList = new ArrayList<>();
        VZWPrepayRefillCardPaymentVO vzwPrepayRefillCardPaymentVO = new VZWPrepayRefillCardPaymentVO();
        vzwPrepayRefillCardPaymentVO.setPaymentGrpId("paymentgrpIDxxxxxx");
        vzwPrepayRefillCardPaymentVO.setAmounApplied(50);
        vzwPrepayRefillCardPaymentVO.setBalance(15);
        vzwPrepayRefillCardPaymentVO.setPincard("23242343");
        paymentGrpIdList.add(vzwPrepayRefillCardPaymentVO);
        vzwPrepayPaymentVO.setRemainingDue(0);
        pageData.setAmountCredit(15);
        vzwPrepayPaymentVO.setPaymentGrpIdList(paymentGrpIdList);
        pageData.setRefillCardDetails(vzwPrepayPaymentVO);
        pageData.setAccessoryList(prepayAccessoryVOList);
        pageData.setAccountInfo(accountInfoVO);
        pageData.setPromotions(prepayPromotionList);
        PrepayAccessoryVO prepayAccessoryVO1 = new PrepayAccessoryVO();
        prepayAccessoryVO1.setDeviceCommerceItemId("deviceId1");
        PrepayAccessoryVO prepayAccessoryVO2 = new PrepayAccessoryVO();
        List<PrepayAccessoryVO> prepayAccessoryVOS = new ArrayList<>();
//        prepayAccessoryVOS.add(prepayAccessoryVO1);
//        prepayAccessoryVOS.add(prepayAccessoryVO2);
        pageData.setAccessoryList(prepayAccessoryVOS);
        List<PrepayPlanVO> planList = new ArrayList<>();
        PrepayPlanVO planVO1 = new PrepayPlanVO();
        PrepayPlanVO planVO2 = new PrepayPlanVO();
        planVO1.setId("randomPlanItem");
        planVO1.setFeatureLineItemId("featureLineItemId");
        planVO1.setSorId("28401");
        planVO1.setSkuDisplayName("Sample Plan Sku");
        planVO1.setPlanSize("15GB");
        planVO1.setDescription("Unlimited Plus");
        planVO1.setActualPlanPrice(50.00);
     //   planVO1.setDueMonthly(40.00);
        planVO1.setDiscount(10.00);
        planVO1.setBundleDiscountApplied(false);
        planVO1.setAutoPaySaving(10.00);
        planList.add(planVO1);
        planList.add(planVO2);
        pageData.setPlanList(planList);
        pageData.setEnableFamilyPricing(true);
        pageData.setHolidayPolicyEnable(true);
        pageData.setEnableIphoneSEPromo(true);
        PrepayFeatureVO prepayFeatureVO = new PrepayFeatureVO();
        prepayFeatureVO.setSorId("sorId");
        prepayFeatureVO.setSkuId("skuId");
      //  pageData.setOrderNumber("95461423448");
        prepayFeatureVO.setDisplayName("displayName");
        prepayFeatureVO.setDueMonthly(3.02);
        List<PrepayFeatureVO> prepayFeatureVOS = new ArrayList<>();
        prepayFeatureVOS.add(prepayFeatureVO);
        pageData.setFeatureList(prepayFeatureVOS);
        pageData.setAutoPayEnabled(false);
        CheckoutDetailsCXPResponse res = converter.translateCheckoutDetails(pageData, getPrepaidODRequestData(), httpRequest, request);
        Assert.assertEquals(pageData.getSessionId(), res.getData().getCart().getCartHeader().getSessionId());
        Assert.assertNotNull(res.getData().getCart().getCartHeader().getSourceSystem());

    }
    @Test
    public void translateCheckoutDetailsTest5() throws IOException{

        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        CheckoutDetailsCXPRequest request = mapper.readValue(requestString, CheckoutDetailsCXPRequest.class);
        CheckoutDetailsCXPResponse response = mapper.readValue(responseString, CheckoutDetailsCXPResponse.class);
        //   PrepayAdaptorCheckOutDetailsODToCXPRespConverter converter = new PrepayAdaptorCheckOutDetailsODToCXPRespConverter();

        URI url = URI.create("http://localhost/test");
        Mono<ResponseEntity<String>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body("test"));
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        PrepayAccessoryVO prepayAccessoryVO = new PrepayAccessoryVO();
        prepayAccessoryVO.setDeviceCommerceItemId("random01");

        List<PrepayAccessoryVO> prepayAccessoryVOList = new ArrayList<>();

        //promotions
        VZWPrepayPromotion prepayPromotion = new VZWPrepayPromotion();
        List<VZWPrepayPromotion> prepayPromotionList = new ArrayList<>();
        prepayPromotionList.add(prepayPromotion);

        //AccountInfo
        AccountInfoVO accountInfoVO = new AccountInfoVO();

        //tax details
        ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();

        TaxDetailInfo taxDetailInfo = new TaxDetailInfo();
        //taxDetailInfo.setTaxDescription(key);
        //taxDetailInfo.setTaxAmount(String.valueOf(value));
        taxDetailInfoList.add(taxDetailInfo);
        HashMap<String, Double> taxDetails = new HashMap<>();
        taxDetails.putIfAbsent("random1", 22.1);


        accountInfoVO.setAddress(null);

        VZWPrepayOrderVO pageData = new VZWPrepayOrderVO();
        pageData.setSessionId("123");
        pageData.setPaymentMethod("RC");
        List<String> refillCards= new ArrayList<String>();
        refillCards.add("12345688975");
        pageData.setRefillCards(refillCards);
        VZWPrepayPaymentVO vzwPrepayPaymentVO = new VZWPrepayPaymentVO();
        List<VZWPrepayRefillCardPaymentVO>  paymentGrpIdList = new ArrayList<>();
        VZWPrepayRefillCardPaymentVO vzwPrepayRefillCardPaymentVO = new VZWPrepayRefillCardPaymentVO();
        vzwPrepayRefillCardPaymentVO.setPaymentGrpId("paymentgrpIDxxxxxx");
        vzwPrepayRefillCardPaymentVO.setAmounApplied(50);
        vzwPrepayRefillCardPaymentVO.setBalance(15);
        vzwPrepayRefillCardPaymentVO.setPincard("23242343");
        paymentGrpIdList.add(vzwPrepayRefillCardPaymentVO);
        vzwPrepayPaymentVO.setRemainingDue(0);
        pageData.setAmountCredit(15);
        vzwPrepayPaymentVO.setPaymentGrpIdList(paymentGrpIdList);
        pageData.setRefillCardDetails(vzwPrepayPaymentVO);
        pageData.setAccessoryList(prepayAccessoryVOList);
        pageData.setAccountInfo(accountInfoVO);
        pageData.setPromotions(prepayPromotionList);
        PrepayAccessoryVO prepayAccessoryVO1 = new PrepayAccessoryVO();
        prepayAccessoryVO1.setDeviceCommerceItemId("deviceId1");
        PrepayAccessoryVO prepayAccessoryVO2 = new PrepayAccessoryVO();
        List<PrepayAccessoryVO> prepayAccessoryVOS = new ArrayList<>();
//        prepayAccessoryVOS.add(prepayAccessoryVO1);
//        prepayAccessoryVOS.add(prepayAccessoryVO2);
        pageData.setAccessoryList(prepayAccessoryVOS);
        List<PrepayPlanVO> planList = new ArrayList<>();
        PrepayPlanVO planVO1 = new PrepayPlanVO();
        PrepayPlanVO planVO2 = new PrepayPlanVO();
        planVO1.setId("randomPlanItem");
        planVO1.setFeatureLineItemId("featureLineItemId");
        planVO1.setSorId("28401");
        planVO1.setSkuDisplayName("Sample Plan Sku");
        planVO1.setPlanSize("15GB");
        planVO1.setDescription("Smartphone Unlimited Plus");
        planVO1.setActualPlanPrice(50.00);
        //   planVO1.setDueMonthly(40.00);
        planVO1.setDiscount(10.00);
        planVO1.setBundleDiscountApplied(false);
        planVO1.setAutoPaySaving(10.00);
        planList.add(planVO1);
        planList.add(planVO2);
        pageData.setPlanList(planList);
        pageData.setEnableFamilyPricing(true);
        pageData.setHolidayPolicyEnable(true);
        pageData.setEnableIphoneSEPromo(true);
        PrepayFeatureVO prepayFeatureVO = new PrepayFeatureVO();
        prepayFeatureVO.setSorId("sorId");
        prepayFeatureVO.setSkuId("skuId");
        //  pageData.setOrderNumber("95461423448");
        prepayFeatureVO.setDisplayName("displayName");
        prepayFeatureVO.setDueMonthly(3.02);
        List<PrepayFeatureVO> prepayFeatureVOS = new ArrayList<>();
        prepayFeatureVOS.add(prepayFeatureVO);
        pageData.setFeatureList(prepayFeatureVOS);
        pageData.setAutoPayEnabled(false);
        CheckoutDetailsCXPResponse res = converter.translateCheckoutDetails(pageData, getPrepaidODRequestData(), httpRequest, request);
        Assert.assertEquals(pageData.getSessionId(), res.getData().getCart().getCartHeader().getSessionId());
        Assert.assertNotNull(res.getData().getCart().getCartHeader().getSourceSystem());

    }
    @Test
    public void translateCheckoutDetailsOrderZipCodeTest() throws IOException{

        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        CheckoutDetailsCXPRequest request = mapper.readValue(requestString, CheckoutDetailsCXPRequest.class);
        CheckoutDetailsCXPResponse response = mapper.readValue(responseString, CheckoutDetailsCXPResponse.class);
        //   PrepayAdaptorCheckOutDetailsODToCXPRespConverter converter = new PrepayAdaptorCheckOutDetailsODToCXPRespConverter();

        URI url = URI.create("http://localhost/test");
        Mono<ResponseEntity<String>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body("test"));
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        PrepayAccessoryVO prepayAccessoryVO = new PrepayAccessoryVO();
        prepayAccessoryVO.setDeviceCommerceItemId("random01");

        List<PrepayAccessoryVO> prepayAccessoryVOList = new ArrayList<>();

        //promotions
        VZWPrepayPromotion prepayPromotion = new VZWPrepayPromotion();
        List<VZWPrepayPromotion> prepayPromotionList = new ArrayList<>();
        prepayPromotionList.add(prepayPromotion);

        //AccountInfo
        AccountInfoVO accountInfoVO = new AccountInfoVO();

        //tax details
        ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();

        TaxDetailInfo taxDetailInfo = new TaxDetailInfo();
        //taxDetailInfo.setTaxDescription(key);
        //taxDetailInfo.setTaxAmount(String.valueOf(value));
        taxDetailInfoList.add(taxDetailInfo);
        HashMap<String, Double> taxDetails = new HashMap<>();
        taxDetails.putIfAbsent("random1", 22.1);

       /* NumberShareDeviceInfo numberShareDeviceInfo = new NumberShareDeviceInfo();
        List<PrepaidODRequestDataLines> numberShareId = new ArrayList<>();
        PrepaidODRequestDataLines prepaidODRequestDataLines = new PrepaidODRequestDataLines();
        prepaidODRequestDataLines.setSelectedMtn("425-526-XXXX");
        prepaidODRequestDataLines.setDisplayName("iphone 12");
        numberShareId.add(prepaidODRequestDataLines);
        numberShareDeviceInfo.setLineNo(numberShareId.get(0).getSelectedMtn());
        numberShareDeviceInfo.setName(numberShareId.get(0).getDisplayName());

        CartLineInfo lineInfoItem = new CartLineInfo();
        lineInfoItem.setNumberShareDeviceInfo(numberShareDeviceInfo);
        ArrayList<CartLineInfo> cartLineInfoList = new ArrayList<>();
        cartLineInfoList.add(lineInfoItem);*/



        //Address
        AddressVO addressVO = new AddressVO();
        addressVO.setAddressLine1("harrongton drive Ohio");
        accountInfoVO.setAddress(addressVO);
        List<PrepayDeviceVO> prepayDeviceVOList = new ArrayList<>();
        PrepayDeviceVO prepayDeviceVO = new PrepayDeviceVO();
        prepayDeviceVO.setId("random01");
        prepayDeviceVO.setPurchasePath("NAP");
        prepayDeviceVO.setItemType("smartphone");
        prepayDeviceVO.setDeviceSorType("5GE");
        prepayDeviceVO.setBrandName("Apple");
        prepayDeviceVO.setNumberShareLineItemId("S007194d00ba2177707ac8cf9fcbd4bd7{as4}_device_961754431");
        //   prepayDeviceVO.setImei2("imei2");
        prepayDeviceVOList.add(0,prepayDeviceVO);

        prepayDeviceVO.setTaxDetails(taxDetails);

        VZWPrepayOrderVO pageData = new VZWPrepayOrderVO();
        pageData.setSessionId("123");
        pageData.setDeviceList(prepayDeviceVOList);
        pageData.setAccessoryList(prepayAccessoryVOList);
        pageData.setAccountInfo(accountInfoVO);
        pageData.setPromotions(prepayPromotionList);
        pageData.setOrderZipcode("75038");
        PrepayAccessoryVO prepayAccessoryVO1 = new PrepayAccessoryVO();
        prepayAccessoryVO1.setDeviceCommerceItemId("deviceId1");
        PrepayAccessoryVO prepayAccessoryVO2 = new PrepayAccessoryVO();
        List<PrepayAccessoryVO> prepayAccessoryVOS = new ArrayList<>();
//        prepayAccessoryVOS.add(prepayAccessoryVO1);
//        prepayAccessoryVOS.add(prepayAccessoryVO2);
        pageData.setAccessoryList(prepayAccessoryVOS);

        pageData.getDeviceList().get(0).setPlanItemId("randomPlanItem");
        pageData.getDeviceList().get(0).setId("deviceId1");
        List<PrepayPlanVO> planList = new ArrayList<>();
        PrepayPlanVO planVO1 = new PrepayPlanVO();
        PrepayPlanVO planVO2 = new PrepayPlanVO();
        planVO1.setId("randomPlanItem");
        planVO1.setFeatureLineItemId("featureLineItemId");
        planVO1.setSorId("28401");
        planVO1.setSkuDisplayName("Sample Plan Sku");
        planVO1.setPlanSize("Unlimited");
        planVO1.setDescription("$75 Smartphone Plan");
        planVO1.setActualPlanPrice(70.00);
        planVO1.setAutoPaySaving(10.00);
        planVO1.setDiscount(20.00);
        planList.add(planVO1);
        planList.add(planVO2);
        pageData.setPlanList(planList);
        PrepayFeatureVO prepayFeatureVO = new PrepayFeatureVO();
        prepayFeatureVO.setSorId("sorId");
        prepayFeatureVO.setSkuId("skuId");
        prepayFeatureVO.setDisplayName("displayName");
        prepayFeatureVO.setDueMonthly(3.02);
        List<PrepayFeatureVO> prepayFeatureVOS = new ArrayList<>();
        prepayFeatureVOS.add(prepayFeatureVO);
        pageData.setFeatureList(prepayFeatureVOS);
        pageData.setAutoPayEnabled(true);
        CheckoutDetailsCXPResponse res = converter.translateCheckoutDetails(pageData, getPrepaidODRequestData2(), httpRequest, request);
        Assert.assertEquals(pageData.getSessionId(), res.getData().getCart().getCartHeader().getSessionId());
        Assert.assertNotNull(res.getData().getCart().getCartHeader().getSourceSystem());

    }
    @Test
    public void translateCheckoutDetailsPaypalTest() throws IOException{

        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        CheckoutDetailsCXPRequest request = mapper.readValue(requestString, CheckoutDetailsCXPRequest.class);
        CheckoutDetailsCXPResponse response = mapper.readValue(responseString, CheckoutDetailsCXPResponse.class);

        URI url = URI.create("http://localhost/test");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        PrepayAccessoryVO prepayAccessoryVO = new PrepayAccessoryVO();
        prepayAccessoryVO.setDeviceCommerceItemId("random01");

        List<PrepayAccessoryVO> prepayAccessoryVOList = new ArrayList<>();

        //promotions
        VZWPrepayPromotion prepayPromotion = new VZWPrepayPromotion();
        List<VZWPrepayPromotion> prepayPromotionList = new ArrayList<>();
        prepayPromotionList.add(prepayPromotion);

        //AccountInfo
        AccountInfoVO accountInfoVO = new AccountInfoVO();
        accountInfoVO.setFirstName("Test");
        accountInfoVO.setLastName("user");
        accountInfoVO.setFullName("Test user");
        accountInfoVO.setZipcode("43229");

        //tax details
        ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();

        TaxDetailInfo taxDetailInfo = new TaxDetailInfo();
        //taxDetailInfo.setTaxDescription(key);
        //taxDetailInfo.setTaxAmount(String.valueOf(value));
        taxDetailInfoList.add(taxDetailInfo);
        HashMap<String, Double> taxDetails = new HashMap<>();
        taxDetails.putIfAbsent("random1", 22.1);

        //Address
        AddressVO addressVO = new AddressVO();
        addressVO.setAddressLine1("harrongton drive Ohio");
        addressVO.setEmailAddress("test@test.com");
        addressVO.setAltPhoneNumber("123457896");
        addressVO.setAddressLine2("apt 212");
        addressVO.setCity("Columbus");
        addressVO.setState("OH");
        addressVO.setZip("43229");

        accountInfoVO.setAddress(addressVO);
        List<PrepayDeviceVO> prepayDeviceVOList = new ArrayList<>();
        PrepayDeviceVO prepayDeviceVO = new PrepayDeviceVO();
        prepayDeviceVO.setId("random01");
        prepayDeviceVO.setItemType("DEVICE");
        prepayDeviceVO.setCapacity("128 GB");
        prepayDeviceVO.setFullRetailListPrice(123.00);
        prepayDeviceVO.setRawTotalAmount(123.00);
        prepayDeviceVO.setPurchasePath("NSP");
        prepayDeviceVO.setNumberShareLineItemId("S007194d00ba2177707ac8cf9fcbd4bd7{as4}_device_961754431");
        prepayDeviceVOList.add(0,prepayDeviceVO);

        prepayDeviceVO.setTaxDetails(taxDetails);

        VZWPrepayOrderVO pageData = new VZWPrepayOrderVO();
        pageData.setFlow("NSE");
        pageData.setSessionId("123");
        pageData.setPaymentMethod("paypal");
        pageData.setPaypalInfo("verizonbuyertest@test.com");
        pageData.setShippingMethod("Next Day by 8pm");
        pageData.setOrderNumber("93601083317");
        pageData.setDeviceList(prepayDeviceVOList);
        pageData.setAccessoryList(prepayAccessoryVOList);
       // pageData.setAccountInfo(accountInfoVO);
        pageData.setPromotions(prepayPromotionList);
        PrepayAccessoryVO prepayAccessoryVO1 = new PrepayAccessoryVO();
        prepayAccessoryVO1.setDeviceCommerceItemId("deviceId1");
        prepayAccessoryVO1.setSorId("123");
        prepayAccessoryVO1.setItemType("ACCESSORY");
        prepayAccessoryVO1.setFullRetailListPrice(15.00);
        prepayAccessoryVO1.setRawTotalAmount(13.00);


        PrepayAccessoryVO prepayAccessoryVO2 = new PrepayAccessoryVO();
        List<PrepayAccessoryVO> prepayAccessoryVOS = new ArrayList<>();
        pageData.setAccessoryList(prepayAccessoryVOS);

        pageData.getDeviceList().get(0).setPlanItemId("randomPlanItem");
        pageData.getDeviceList().get(0).setId("deviceId1");
        List<PrepayPlanVO> planList = new ArrayList<>();
        PrepayPlanVO planVO1 = new PrepayPlanVO();
        PrepayPlanVO planVO2 = new PrepayPlanVO();
        planVO1.setId("randomPlanItem");
        planVO1.setSorId("28399");
        planVO1.setPlanSize("Unlimited Plus");
        planVO1.setFeatureLineItemId("featureLineItemId");
        planList.add(planVO1);
        planList.add(planVO2);
        pageData.setPlanList(planList);
        PrepayFeatureVO prepayFeatureVO = new PrepayFeatureVO();
        prepayFeatureVO.setSorId("123");
        prepayFeatureVO.setSkuId("sku_123");
        prepayFeatureVO.setDisplayName("displayName");
        prepayFeatureVO.setDueToday(0.00);
        prepayFeatureVO.setId("123");
        prepayFeatureVO.setDescription("12345");
        prepayFeatureVO.setDescription("Sample Description");
        prepayFeatureVO.setDueMonthly(3.02);
        List<PrepayFeatureVO> prepayFeatureVOS = new ArrayList<>();
        prepayFeatureVOS.add(prepayFeatureVO);
        pageData.setFeatureList(prepayFeatureVOS);
        pageData.setBillingAddress(accountInfoVO);
        request.getData().setCartId("1234");
        CheckoutDetailsCXPResponse res = converter.translateCheckoutDetails(pageData, getPrepaidODRequestData(), httpRequest, request);
        Assert.assertEquals(pageData.getSessionId(), res.getData().getCart().getCartHeader().getSessionId());
        Assert.assertNotNull(res.getData().getCart().getLineDetails().getPayments().get(0).getPaypalPaymentDetails());

    }
    @Test
    public void translateCheckoutDetailsApplePayTest() throws IOException{

        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        CheckoutDetailsCXPRequest request = mapper.readValue(requestString, CheckoutDetailsCXPRequest.class);
        CheckoutDetailsCXPResponse response = mapper.readValue(responseString, CheckoutDetailsCXPResponse.class);

        URI url = URI.create("http://localhost/test");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        PrepayAccessoryVO prepayAccessoryVO = new PrepayAccessoryVO();
        prepayAccessoryVO.setDeviceCommerceItemId("random01");

        List<PrepayAccessoryVO> prepayAccessoryVOList = new ArrayList<>();

        //promotions
        VZWPrepayPromotion prepayPromotion = new VZWPrepayPromotion();
        List<VZWPrepayPromotion> prepayPromotionList = new ArrayList<>();
        prepayPromotionList.add(prepayPromotion);

        //AccountInfo
        AccountInfoVO accountInfoVO = new AccountInfoVO();
        accountInfoVO.setFirstName("Test");
        accountInfoVO.setLastName("user");

        //tax details
        ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();

        TaxDetailInfo taxDetailInfo = new TaxDetailInfo();
        //taxDetailInfo.setTaxDescription(key);
        //taxDetailInfo.setTaxAmount(String.valueOf(value));
        taxDetailInfoList.add(taxDetailInfo);
        HashMap<String, Double> taxDetails = new HashMap<>();
        taxDetails.putIfAbsent("random1", 22.1);

        //Address
        AddressVO addressVO = new AddressVO();
        addressVO.setAddressLine1("harrongton drive Ohio");
        addressVO.setEmailAddress("test@test.com");
        addressVO.setAltPhoneNumber("123457896");

        accountInfoVO.setAddress(addressVO);
        List<PrepayDeviceVO> prepayDeviceVOList = new ArrayList<>();
        PrepayDeviceVO prepayDeviceVO = new PrepayDeviceVO();
        prepayDeviceVO.setId("random01");
        prepayDeviceVO.setItemType("DEVICE");
        prepayDeviceVO.setCapacity("128 GB");
        prepayDeviceVO.setFullRetailListPrice(123.00);
        prepayDeviceVO.setRawTotalAmount(123.00);
        prepayDeviceVO.setPurchasePath("NSP");
        prepayDeviceVO.setNumberShareLineItemId("S007194d00ba2177707ac8cf9fcbd4bd7{as4}_device_961754431");
        prepayDeviceVOList.add(0,prepayDeviceVO);

        prepayDeviceVO.setTaxDetails(taxDetails);

        VZWPrepayOrderVO pageData = new VZWPrepayOrderVO();
        pageData.setFlow("NSE");
        pageData.setSessionId("123");
        pageData.setPaymentMethod("applepay");
        pageData.setShippingMethod("Next Day by 8pm");
        pageData.setOrderNumber("93601083317");
        pageData.setDeviceList(prepayDeviceVOList);
        pageData.setAccessoryList(prepayAccessoryVOList);
        pageData.setAccountInfo(accountInfoVO);
        pageData.setPromotions(prepayPromotionList);
        PrepayAccessoryVO prepayAccessoryVO1 = new PrepayAccessoryVO();
        prepayAccessoryVO1.setDeviceCommerceItemId("deviceId1");
        prepayAccessoryVO1.setSorId("123");
        prepayAccessoryVO1.setItemType("ACCESSORY");
        prepayAccessoryVO1.setFullRetailListPrice(15.00);
        prepayAccessoryVO1.setRawTotalAmount(13.00);


        PrepayAccessoryVO prepayAccessoryVO2 = new PrepayAccessoryVO();
        List<PrepayAccessoryVO> prepayAccessoryVOS = new ArrayList<>();
        pageData.setAccessoryList(prepayAccessoryVOS);

        pageData.getDeviceList().get(0).setPlanItemId("randomPlanItem");
        pageData.getDeviceList().get(0).setId("deviceId1");
        List<PrepayPlanVO> planList = new ArrayList<>();
        PrepayPlanVO planVO1 = new PrepayPlanVO();
        PrepayPlanVO planVO2 = new PrepayPlanVO();
        planVO1.setId("randomPlanItem");
        planVO1.setSorId("28399");
        planVO1.setPlanSize("Unlimited Plus");
        planVO1.setFeatureLineItemId("featureLineItemId");
        planList.add(planVO1);
        planList.add(planVO2);
        pageData.setPlanList(planList);
        PrepayFeatureVO prepayFeatureVO = new PrepayFeatureVO();
        prepayFeatureVO.setSorId("123");
        prepayFeatureVO.setSkuId("sku_123");
        prepayFeatureVO.setDisplayName("displayName");
        prepayFeatureVO.setDueToday(0.00);
        prepayFeatureVO.setId("123");
        prepayFeatureVO.setDescription("12345");
        prepayFeatureVO.setDescription("Sample Description");
        prepayFeatureVO.setDueMonthly(3.02);
        List<PrepayFeatureVO> prepayFeatureVOS = new ArrayList<>();
        prepayFeatureVOS.add(prepayFeatureVO);
        pageData.setFeatureList(prepayFeatureVOS);
        pageData.setBillingAddress(accountInfoVO);
        CheckoutDetailsCXPResponse res = converter.translateCheckoutDetails(pageData, getPrepaidODRequestData(), httpRequest, request);
        Assert.assertEquals(pageData.getSessionId(), res.getData().getCart().getCartHeader().getSessionId());
        Assert.assertNotNull(res.getData().getCart().getLineDetails().getPayments());

    }
    @Test
    public void translateCheckoutDetailsAALTest() throws IOException{

        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        CheckoutDetailsCXPRequest request = mapper.readValue(requestString, CheckoutDetailsCXPRequest.class);
        CheckoutDetailsCXPResponse response = mapper.readValue(responseString, CheckoutDetailsCXPResponse.class);

        URI url = URI.create("http://localhost/test");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        PrepayAccessoryVO prepayAccessoryVO = new PrepayAccessoryVO();
        prepayAccessoryVO.setDeviceCommerceItemId("deviceId1");
        prepayAccessoryVO.setSorId("s01830");
        prepayAccessoryVO.setSkuId("sku37402");

        List<PrepayAccessoryVO> prepayAccessoryVOList = new ArrayList<>();
        prepayAccessoryVOList.add(prepayAccessoryVO);

        //promotions
        VZWPrepayPromotion prepayPromotion = new VZWPrepayPromotion();
        List<VZWPrepayPromotion> prepayPromotionList = new ArrayList<>();
        prepayPromotionList.add(prepayPromotion);

        //AccountInfo
        AccountInfoVO accountInfoVO = new AccountInfoVO();
        accountInfoVO.setFirstName("Test");
        accountInfoVO.setLastName("user");

        //tax details
        ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();

        TaxDetailInfo taxDetailInfo = new TaxDetailInfo();
        //taxDetailInfo.setTaxDescription(key);
        //taxDetailInfo.setTaxAmount(String.valueOf(value));
        taxDetailInfoList.add(taxDetailInfo);
        HashMap<String, Double> taxDetails = new HashMap<>();
        taxDetails.putIfAbsent("random1", 22.1);

        //Address
        AddressVO addressVO = new AddressVO();
        addressVO.setAddressLine1("harrongton drive Ohio");
        addressVO.setEmailAddress("test@test.com");
        addressVO.setAltPhoneNumber("123457896");

        accountInfoVO.setAddress(addressVO);
        List<PrepayDeviceVO> prepayDeviceVOList = new ArrayList<>();
        PrepayDeviceVO prepayDeviceVO = new PrepayDeviceVO();
        prepayDeviceVO.setId("random01");
        prepayDeviceVO.setItemType("DEVICE");
        prepayDeviceVO.setCapacity("128 GB");
        prepayDeviceVO.setFullRetailListPrice(123.00);
        prepayDeviceVO.setRawTotalAmount(123.00);
        prepayDeviceVO.setPurchasePath("NSP");
        prepayDeviceVO.setNumberShareLineItemId("S007194d00ba2177707ac8cf9fcbd4bd7{as4}_device_961754431");
        prepayDeviceVOList.add(0,prepayDeviceVO);

        prepayDeviceVO.setTaxDetails(taxDetails);

        VZWPrepayOrderVO pageData = new VZWPrepayOrderVO();
        pageData.setFlow("AAL");
        pageData.setSessionId("123");
        pageData.setPaymentMethod("paypal");
        pageData.setPaypalInfo("verizonbuyertest@test.com");
        pageData.setShippingMethod("Next Day by 8pm");
        pageData.setOrderNumber("93601083317");
        pageData.setDeviceList(prepayDeviceVOList);
        pageData.setAccessoryList(prepayAccessoryVOList);
        pageData.setAccountInfo(accountInfoVO);
        pageData.setPromotions(prepayPromotionList);
        PrepayAccessoryVO prepayAccessoryVO1 = new PrepayAccessoryVO();
        prepayAccessoryVO1.setDeviceCommerceItemId("deviceId1");
        prepayAccessoryVO1.setSorId("123");
        prepayAccessoryVO1.setItemType("ACCESSORY");
        prepayAccessoryVO1.setFullRetailListPrice(15.00);
        prepayAccessoryVO1.setRawTotalAmount(13.00);

        pageData.getDeviceList().get(0).setPlanItemId("randomPlanItem");
        pageData.getDeviceList().get(0).setId("deviceId1");
        List<PrepayPlanVO> planList = new ArrayList<>();
        PrepayPlanVO planVO1 = new PrepayPlanVO();
        PrepayPlanVO planVO2 = new PrepayPlanVO();
        planVO1.setId("randomPlanItem");
        planVO1.setSorId("28399");
        planVO1.setPlanSize("Unlimited Plus");
        planVO1.setFeatureLineItemId("featureLineItemId");
        planList.add(planVO1);
        planList.add(planVO2);
        pageData.setPlanList(planList);
        PrepayFeatureVO prepayFeatureVO = new PrepayFeatureVO();
        prepayFeatureVO.setSorId("123");
        prepayFeatureVO.setSkuId("sku_123");
        prepayFeatureVO.setDisplayName("displayName");
        prepayFeatureVO.setDueToday(0.00);
        prepayFeatureVO.setId("123");
        prepayFeatureVO.setDescription("12345");
        prepayFeatureVO.setDescription("Sample Description");
        prepayFeatureVO.setDueMonthly(3.02);
        List<PrepayFeatureVO> prepayFeatureVOS = new ArrayList<>();
        prepayFeatureVOS.add(prepayFeatureVO);
        pageData.setFeatureList(prepayFeatureVOS);
        pageData.setBillingAddress(accountInfoVO);
        PrepaidODRequestData redisData=getPrepaidODRequestData();
        redisData.getLines().get(0).setCheckoutFlag(false);
        CheckoutDetailsCXPResponse res = converter.translateCheckoutDetails(pageData, redisData, httpRequest, request);
        Assert.assertEquals(pageData.getSessionId(), res.getData().getCart().getCartHeader().getSessionId());
        Assert.assertNotNull(res.getData().getCart().getLineDetails().getPayments().get(0).getPaypalPaymentDetails());

    }
    @Test
    public void translateCheckoutDetailsAALBillingNullTest() throws IOException{

        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        CheckoutDetailsCXPRequest request = mapper.readValue(requestString, CheckoutDetailsCXPRequest.class);

        URI url = URI.create("http://localhost/test");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        PrepayAccessoryVO prepayAccessoryVO = new PrepayAccessoryVO();
        prepayAccessoryVO.setDeviceCommerceItemId("random01");

        List<PrepayAccessoryVO> prepayAccessoryVOList = new ArrayList<>();

        //promotions
        VZWPrepayPromotion prepayPromotion = new VZWPrepayPromotion();
        List<VZWPrepayPromotion> prepayPromotionList = new ArrayList<>();
        prepayPromotionList.add(prepayPromotion);

        //AccountInfo
        AccountInfoVO accountInfoVO = new AccountInfoVO();
        accountInfoVO.setFirstName("Test");
        accountInfoVO.setLastName("user");

        //tax details
        ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();

        TaxDetailInfo taxDetailInfo = new TaxDetailInfo();
        taxDetailInfoList.add(taxDetailInfo);
        HashMap<String, Double> taxDetails = new HashMap<>();
        taxDetails.putIfAbsent("random1", 22.1);

        //Address
        AddressVO addressVO = new AddressVO();
        addressVO.setAddressLine1("harrongton drive Ohio");
        addressVO.setEmailAddress("test@test.com");
        addressVO.setAltPhoneNumber("123457896");

        accountInfoVO.setAddress(addressVO);
        List<PrepayDeviceVO> prepayDeviceVOList = new ArrayList<>();
        PrepayDeviceVO prepayDeviceVO = new PrepayDeviceVO();
        prepayDeviceVO.setId("random01");
        prepayDeviceVO.setItemType("DEVICE");
        prepayDeviceVO.setCapacity("128 GB");
        prepayDeviceVO.setFullRetailListPrice(123.00);
        prepayDeviceVO.setRawTotalAmount(123.00);
        prepayDeviceVO.setPurchasePath("NSP");
        prepayDeviceVOList.add(0,prepayDeviceVO);

        prepayDeviceVO.setTaxDetails(taxDetails);

        VZWPrepayOrderVO pageData = new VZWPrepayOrderVO();
        pageData.setFlow("AAL");
        pageData.setSessionId("123");
        pageData.setPaymentMethod("paypal");
        pageData.setPaypalInfo("verizonbuyertest@test.com");
        pageData.setShippingMethod("Next Day by 8pm");
        pageData.setOrderNumber("93601083317");
        pageData.setDeviceList(prepayDeviceVOList);
        pageData.setAccessoryList(prepayAccessoryVOList);
        pageData.setAccountInfo(accountInfoVO);
        pageData.setPromotions(prepayPromotionList);
        PrepayAccessoryVO prepayAccessoryVO1 = new PrepayAccessoryVO();
        prepayAccessoryVO1.setDeviceCommerceItemId("deviceId1");
        prepayAccessoryVO1.setSorId("123");
        prepayAccessoryVO1.setItemType("ACCESSORY");
        prepayAccessoryVO1.setFullRetailListPrice(15.00);
        prepayAccessoryVO1.setRawTotalAmount(13.00);


        PrepayAccessoryVO prepayAccessoryVO2 = new PrepayAccessoryVO();
        List<PrepayAccessoryVO> prepayAccessoryVOS = new ArrayList<>();
        pageData.setAccessoryList(prepayAccessoryVOS);

        pageData.getDeviceList().get(0).setPlanItemId("randomPlanItem");
        pageData.getDeviceList().get(0).setId("deviceId1");
        pageData.getDeviceList().get(0).setNumberShareLineItemId("S007194d00ba2177707ac8cf9fcbd4bd7{as4}_device_961754431");
        List<PrepayPlanVO> planList = new ArrayList<>();
        PrepayPlanVO planVO1 = new PrepayPlanVO();
        PrepayPlanVO planVO2 = new PrepayPlanVO();
        planVO1.setId("randomPlanItem");
        planVO1.setSorId("28399");
        planVO1.setPlanSize("Unlimited Plus");
        planVO1.setFeatureLineItemId("featureLineItemId");
        planList.add(planVO1);
        planList.add(planVO2);
        pageData.setPlanList(planList);
        PrepayFeatureVO prepayFeatureVO = new PrepayFeatureVO();
        prepayFeatureVO.setSorId("123");
        prepayFeatureVO.setSkuId("sku_123");
        prepayFeatureVO.setDisplayName("displayName");
        prepayFeatureVO.setDueToday(0.00);
        prepayFeatureVO.setId("123");
        prepayFeatureVO.setDescription("Smartphone");
        prepayFeatureVO.setDueMonthly(3.02);
        List<PrepayFeatureVO> prepayFeatureVOS = new ArrayList<>();
        prepayFeatureVOS.add(prepayFeatureVO);
        pageData.setFeatureList(prepayFeatureVOS);
        pageData.setBillingAddress(null);
        pageData.setEnableFamilyPricing(true);
        pageData.setHolidayPolicyEnable(true);
        pageData.setEnableIphoneSEPromo(true);
        CheckoutDetailsCXPResponse res = converter.translateCheckoutDetails(pageData, getPrepaidODRequestData(), httpRequest, request);
        Assert.assertEquals(pageData.getSessionId(), res.getData().getCart().getCartHeader().getSessionId());
        Assert.assertNotNull(res.getData().getCart().getLineDetails().getPayments().get(0).getPaypalPaymentDetails());

    }
    @Test
    public void translateCheckoutDetailsEUPTest() throws IOException{

        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        CheckoutDetailsCXPRequest request = mapper.readValue(requestString, CheckoutDetailsCXPRequest.class);
        CheckoutDetailsCXPResponse response = mapper.readValue(responseString, CheckoutDetailsCXPResponse.class);

        URI url = URI.create("http://localhost/test");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        PrepayAccessoryVO prepayAccessoryVO = new PrepayAccessoryVO();
        prepayAccessoryVO.setDeviceCommerceItemId("random01");

        List<PrepayAccessoryVO> prepayAccessoryVOList = new ArrayList<>();

        //promotions
        VZWPrepayPromotion prepayPromotion = new VZWPrepayPromotion();
        List<VZWPrepayPromotion> prepayPromotionList = new ArrayList<>();
        prepayPromotionList.add(prepayPromotion);

        //AccountInfo
        AccountInfoVO accountInfoVO = new AccountInfoVO();
        accountInfoVO.setFirstName("Test");
        accountInfoVO.setLastName("user");

        //tax details
        ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();

        TaxDetailInfo taxDetailInfo = new TaxDetailInfo();
        //taxDetailInfo.setTaxDescription(key);
        //taxDetailInfo.setTaxAmount(String.valueOf(value));
        taxDetailInfoList.add(taxDetailInfo);
        HashMap<String, Double> taxDetails = new HashMap<>();
        taxDetails.putIfAbsent("random1", 22.1);

        //Address
        AddressVO addressVO = new AddressVO();
        addressVO.setAddressLine1("harrongton drive Ohio");
        addressVO.setEmailAddress("test@test.com");
        addressVO.setAltPhoneNumber("123457896");

        accountInfoVO.setAddress(addressVO);
        List<PrepayDeviceVO> prepayDeviceVOList = new ArrayList<>();
        PrepayDeviceVO prepayDeviceVO = new PrepayDeviceVO();
        prepayDeviceVO.setId("random01");
        prepayDeviceVO.setItemType("DEVICE");
        prepayDeviceVO.setCapacity("128 GB");
        prepayDeviceVO.setFullRetailListPrice(123.00);
        prepayDeviceVO.setRawTotalAmount(123.00);
        prepayDeviceVO.setPurchasePath("NSP");
        prepayDeviceVOList.add(0,prepayDeviceVO);

        prepayDeviceVO.setTaxDetails(taxDetails);

        VZWPrepayOrderVO pageData = new VZWPrepayOrderVO();
        pageData.setFlow("EUP");
        pageData.setSessionId("123");
        pageData.setPaymentMethod("paypal");
        pageData.setPaypalInfo("verizonbuyertest@test.com");
        pageData.setShippingMethod("Next Day by 8pm");
        pageData.setOrderNumber("93601083317");
        pageData.setDeviceList(prepayDeviceVOList);
        pageData.setAccessoryList(prepayAccessoryVOList);
        pageData.setAccountInfo(accountInfoVO);
        pageData.setPromotions(prepayPromotionList);
        PrepayAccessoryVO prepayAccessoryVO1 = new PrepayAccessoryVO();
        prepayAccessoryVO1.setDeviceCommerceItemId("deviceId1");
        prepayAccessoryVO1.setSorId("123");
        prepayAccessoryVO1.setItemType("ACCESSORY");
        prepayAccessoryVO1.setFullRetailListPrice(15.00);
        prepayAccessoryVO1.setRawTotalAmount(13.00);


        PrepayAccessoryVO prepayAccessoryVO2 = new PrepayAccessoryVO();
        List<PrepayAccessoryVO> prepayAccessoryVOS = new ArrayList<>();
        pageData.setAccessoryList(prepayAccessoryVOS);

        pageData.getDeviceList().get(0).setPlanItemId("randomPlanItem");
        pageData.getDeviceList().get(0).setId("deviceId1");
        pageData.getDeviceList().get(0).setNumberShareLineItemId("S007194d00ba2177707ac8cf9fcbd4bd7{as4}_device_961754431");
        List<PrepayPlanVO> planList = new ArrayList<>();
        PrepayPlanVO planVO1 = new PrepayPlanVO();
        PrepayPlanVO planVO2 = new PrepayPlanVO();
        planVO1.setId("randomPlanItem");
        planVO1.setSorId("28399");
        planVO1.setPlanSize("Unlimited Plus");
        planVO1.setFeatureLineItemId("featureLineItemId");
        planVO1.setDiscount(10.00);
        planVO1.setActualPlanPrice(50.00);
        planList.add(planVO1);
        planList.add(planVO2);
        pageData.setPlanList(planList);
        PrepayFeatureVO prepayFeatureVO = new PrepayFeatureVO();
        prepayFeatureVO.setSorId("123");
        prepayFeatureVO.setSkuId("sku_123");
        prepayFeatureVO.setDisplayName("displayName");
        prepayFeatureVO.setDueToday(0.00);
        prepayFeatureVO.setId("123");
        prepayFeatureVO.setDescription("12345");
        prepayFeatureVO.setDescription("Smartphone");
        prepayFeatureVO.setDueMonthly(3.02);
        List<PrepayFeatureVO> prepayFeatureVOS = new ArrayList<>();
        prepayFeatureVOS.add(prepayFeatureVO);
        pageData.setFeatureList(prepayFeatureVOS);
        pageData.setBillingAddress(accountInfoVO);
        pageData.setEnableFamilyPricing(true);
        CheckoutDetailsCXPResponse res = converter.translateCheckoutDetails(pageData, getPrepaidODRequestData(), httpRequest, request);
        Assert.assertEquals(pageData.getSessionId(), res.getData().getCart().getCartHeader().getSessionId());
        Assert.assertNotNull(res.getData().getCart().getLineDetails().getPayments().get(0).getPaypalPaymentDetails());

    }
    @Test
    public void translateCheckoutDetailsEUPTest2() throws IOException{

        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        CheckoutDetailsCXPRequest request = mapper.readValue(requestString, CheckoutDetailsCXPRequest.class);
        CheckoutDetailsCXPResponse response = mapper.readValue(responseString, CheckoutDetailsCXPResponse.class);

        URI url = URI.create("http://localhost/test");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        PrepayAccessoryVO prepayAccessoryVO = new PrepayAccessoryVO();
        prepayAccessoryVO.setDeviceCommerceItemId("random01");

        List<PrepayAccessoryVO> prepayAccessoryVOList = new ArrayList<>();

        //promotions
        VZWPrepayPromotion prepayPromotion = new VZWPrepayPromotion();
        List<VZWPrepayPromotion> prepayPromotionList = new ArrayList<>();
        prepayPromotionList.add(prepayPromotion);

        //AccountInfo
        AccountInfoVO accountInfoVO = new AccountInfoVO();
        accountInfoVO.setFirstName("Test");
        accountInfoVO.setLastName("user");

        //tax details
        ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();

        TaxDetailInfo taxDetailInfo = new TaxDetailInfo();
        //taxDetailInfo.setTaxDescription(key);
        //taxDetailInfo.setTaxAmount(String.valueOf(value));
        taxDetailInfoList.add(taxDetailInfo);
        HashMap<String, Double> taxDetails = new HashMap<>();
        taxDetails.putIfAbsent("random1", 22.1);

        //Address
        AddressVO addressVO = new AddressVO();
        addressVO.setAddressLine1("harrongton drive Ohio");
        addressVO.setEmailAddress("test@test.com");
        addressVO.setAltPhoneNumber("123457896");

        accountInfoVO.setAddress(addressVO);
        List<PrepayDeviceVO> prepayDeviceVOList = new ArrayList<>();
        PrepayDeviceVO prepayDeviceVO = new PrepayDeviceVO();
        prepayDeviceVO.setId("random01");
        prepayDeviceVO.setItemType("DEVICE");
        prepayDeviceVO.setCapacity("128 GB");
        prepayDeviceVO.setFullRetailListPrice(123.00);
        prepayDeviceVO.setRawTotalAmount(123.00);
        prepayDeviceVO.setPurchasePath("NSP");
        prepayDeviceVO.setAccountOwner(true);
        prepayDeviceVOList.add(0,prepayDeviceVO);

        prepayDeviceVO.setTaxDetails(taxDetails);

        VZWPrepayOrderVO pageData = new VZWPrepayOrderVO();
        pageData.setFlow("EUP");
        pageData.setSessionId("123");
        pageData.setPaymentMethod("paypal");
        pageData.setPaypalInfo("verizonbuyertest@test.com");
        pageData.setShippingMethod("Next Day by 8pm");
        pageData.setOrderNumber("93601083317");
        pageData.setDeviceList(prepayDeviceVOList);
        pageData.setAccessoryList(prepayAccessoryVOList);
        pageData.setAccountInfo(accountInfoVO);
        pageData.setPromotions(prepayPromotionList);
        PrepayAccessoryVO prepayAccessoryVO1 = new PrepayAccessoryVO();
        prepayAccessoryVO1.setDeviceCommerceItemId("deviceId1");
        prepayAccessoryVO1.setSorId("123");
        prepayAccessoryVO1.setItemType("ACCESSORY");
        prepayAccessoryVO1.setFullRetailListPrice(15.00);
        prepayAccessoryVO1.setRawTotalAmount(13.00);


        PrepayAccessoryVO prepayAccessoryVO2 = new PrepayAccessoryVO();
        List<PrepayAccessoryVO> prepayAccessoryVOS = new ArrayList<>();
        pageData.setAccessoryList(prepayAccessoryVOS);

        pageData.getDeviceList().get(0).setPlanItemId("randomPlanItem");
        pageData.getDeviceList().get(0).setId("deviceId1");
        pageData.getDeviceList().get(0).setNumberShareLineItemId("S007194d00ba2177707ac8cf9fcbd4bd7{as4}_device_961754431");
        List<PrepayPlanVO> planList = new ArrayList<>();
        PrepayPlanVO planVO1 = new PrepayPlanVO();
        PrepayPlanVO planVO2 = new PrepayPlanVO();
        planVO1.setId("randomPlanItem");
        planVO1.setSorId("28399");
        planVO1.setPlanSize("Unlimited Plus");
        planVO1.setFeatureLineItemId("featureLineItemId");
        planVO1.setActualPlanPrice(50.00);
        planList.add(planVO1);
        planList.add(planVO2);
        pageData.setPlanList(planList);
        PrepayFeatureVO prepayFeatureVO = new PrepayFeatureVO();
        prepayFeatureVO.setSorId("123");
        prepayFeatureVO.setSkuId("sku_123");
        prepayFeatureVO.setDisplayName("displayName");
        prepayFeatureVO.setDueToday(0.00);
        prepayFeatureVO.setId("123");
        prepayFeatureVO.setDescription("12345");
        prepayFeatureVO.setDescription("Smartphone");
        prepayFeatureVO.setDueMonthly(3.02);
        List<PrepayFeatureVO> prepayFeatureVOS = new ArrayList<>();
        prepayFeatureVOS.add(prepayFeatureVO);
        pageData.setFeatureList(prepayFeatureVOS);
        pageData.setBillingAddress(accountInfoVO);
        pageData.setEnableFamilyPricing(true);
        pageData.setHolidayPolicyEnable(true);
        pageData.setEnableIphoneSEPromo(true);
        CheckoutDetailsCXPResponse res = converter.translateCheckoutDetails(pageData, getPrepaidODRequestData(), httpRequest, request);
        Assert.assertEquals(pageData.getSessionId(), res.getData().getCart().getCartHeader().getSessionId());
        Assert.assertNotNull(res.getData().getCart().getLineDetails().getPayments().get(0).getPaypalPaymentDetails());

    }
    @Test
    public void translateCheckoutDetailsFlowCheckLoggedin_NSPFlow() throws IOException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        CheckoutDetailsCXPRequest request = mapper.readValue(requestString, CheckoutDetailsCXPRequest.class);
        CheckoutDetailsCXPResponse response = mapper.readValue(responseString, CheckoutDetailsCXPResponse.class);

        URI url = URI.create("http://localhost/test");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        PrepayAccessoryVO prepayAccessoryVO = new PrepayAccessoryVO();
        prepayAccessoryVO.setDeviceCommerceItemId("random01");

        List<PrepayAccessoryVO> prepayAccessoryVOList = new ArrayList<>();

        //promotions
        VZWPrepayPromotion prepayPromotion = new VZWPrepayPromotion();
        List<VZWPrepayPromotion> prepayPromotionList = new ArrayList<>();
        prepayPromotionList.add(prepayPromotion);

        //AccountInfo
        AccountInfoVO accountInfoVO = new AccountInfoVO();
        accountInfoVO.setFirstName("Test");
        accountInfoVO.setLastName("user");

        //tax details
        ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();

        TaxDetailInfo taxDetailInfo = new TaxDetailInfo();
        //taxDetailInfo.setTaxDescription(key);
        //taxDetailInfo.setTaxAmount(String.valueOf(value));
        taxDetailInfoList.add(taxDetailInfo);
        HashMap<String, Double> taxDetails = new HashMap<>();
        taxDetails.putIfAbsent("random1", 22.1);

        //Address
        AddressVO addressVO = new AddressVO();
        addressVO.setAddressLine1("harrongton drive Ohio");
        addressVO.setEmailAddress("test@test.com");
        addressVO.setAltPhoneNumber("123457896");

        accountInfoVO.setAddress(addressVO);
        List<PrepayDeviceVO> prepayDeviceVOList = new ArrayList<>();
        PrepayDeviceVO prepayDeviceVO = new PrepayDeviceVO();
        prepayDeviceVO.setId("random01");
        prepayDeviceVO.setItemType("DEVICE");
        prepayDeviceVO.setFutureDiscount(24.0);
        prepayDeviceVO.setFutureDiscountMonths(3);
        prepayDeviceVO.setCapacity("128 GB");
        prepayDeviceVO.setFullRetailListPrice(123.00);
        prepayDeviceVO.setRawTotalAmount(123.00);
        prepayDeviceVO.setImei("imei");
        prepayDeviceVO.setRequestedEsimImei("359272531292045");
        prepayDeviceVO.setSmartImeiDevice(false);
        prepayDeviceVO.setESIMEnabledDevice(false);
        prepayDeviceVO.setEsimOnlyDevice(false);
        prepayDeviceVO.setEsimCompatible(false);
        prepayDeviceVOList.add(0,prepayDeviceVO);

        prepayDeviceVO.setTaxDetails(taxDetails);

        VZWPrepayOrderVO pageData = new VZWPrepayOrderVO();
        pageData.setFlow("NAP");
        pageData.setSessionId("123");
        pageData.setPaymentMethod("VISA");
        pageData.setPaypalInfo("verizonbuyertest@test.com");
        pageData.setShippingMethod("Next Day by 8pm");
        pageData.setOrderNumber("93601083317");
        pageData.setDeviceList(prepayDeviceVOList);
        pageData.setAccessoryList(prepayAccessoryVOList);
        pageData.setAccountInfo(accountInfoVO);
        pageData.setPromotions(prepayPromotionList);
        PrepayAccessoryVO prepayAccessoryVO1 = new PrepayAccessoryVO();
        prepayAccessoryVO1.setDeviceCommerceItemId("deviceId1");
        prepayAccessoryVO1.setSorId("123");
        prepayAccessoryVO1.setItemType("ACCESSORY");
        prepayAccessoryVO1.setFullRetailListPrice(15.00);
        prepayAccessoryVO1.setRawTotalAmount(13.00);


        PrepayAccessoryVO prepayAccessoryVO2 = new PrepayAccessoryVO();
        List<PrepayAccessoryVO> prepayAccessoryVOS = new ArrayList<>();
        pageData.setAccessoryList(prepayAccessoryVOS);


        pageData.getDeviceList().get(0).setPlanItemId("randomPlanItem");
        pageData.getDeviceList().get(0).setPurchasePath("NSP");
        pageData.getDeviceList().get(0).setId("deviceId1");
        pageData.getDeviceList().get(0).setNumberShareLineItemId("S007194d00ba2177707ac8cf9fcbd4bd7{as4}_device_961754431");
        List<PrepayPlanVO> planList = new ArrayList<>();
        PrepayPlanVO planVO1 = new PrepayPlanVO();
        PrepayPlanVO planVO2 = new PrepayPlanVO();
        planVO1.setId("randomPlanItem");
        planVO1.setFeatureLineItemId("featureLineItemId");
        planList.add(planVO1);
        planList.add(planVO2);
        pageData.setPlanList(planList);
        PrepayFeatureVO prepayFeatureVO = new PrepayFeatureVO();
        prepayFeatureVO.setSorId("123");
        prepayFeatureVO.setSkuId("sku_123");
        prepayFeatureVO.setDisplayName("displayName");
        prepayFeatureVO.setDueToday(0.00);
        prepayFeatureVO.setId("123");
        prepayFeatureVO.setDescription("12345");
        prepayFeatureVO.setDescription("Sample Description");
        prepayFeatureVO.setDueMonthly(3.02);
        List<PrepayFeatureVO> prepayFeatureVOS = new ArrayList<>();
        prepayFeatureVOS.add(prepayFeatureVO);
        pageData.setFeatureList(prepayFeatureVOS);
        pageData.setBillingAddress(accountInfoVO);
        PrepaidODRequestData redisData=getPrepaidODRequestData();
        redisData.setLoggedIn(true);

        CheckoutDetailsCXPResponse res = converter.translateCheckoutDetails(pageData, redisData, httpRequest, request);
        Assert.assertEquals(pageData.getSessionId(), res.getData().getCart().getCartHeader().getSessionId());
        Assert.assertNotNull(res.getData().getCart().getLineDetails().getPayments().get(0).getCreditCardDetails());
    }

    @Test
    public void translateCheckoutDetailsFlowCheckLoggedin_PALFlow() throws IOException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        CheckoutDetailsCXPRequest request = mapper.readValue(requestString, CheckoutDetailsCXPRequest.class);
        CheckoutDetailsCXPResponse response = mapper.readValue(responseString, CheckoutDetailsCXPResponse.class);

        URI url = URI.create("http://localhost/test");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        PrepayAccessoryVO prepayAccessoryVO = new PrepayAccessoryVO();
        prepayAccessoryVO.setDeviceCommerceItemId("random01");

        List<PrepayAccessoryVO> prepayAccessoryVOList = new ArrayList<>();

        //promotions
        VZWPrepayPromotion prepayPromotion = new VZWPrepayPromotion();
        List<VZWPrepayPromotion> prepayPromotionList = new ArrayList<>();
        prepayPromotionList.add(prepayPromotion);

        //AccountInfo
        AccountInfoVO accountInfoVO = new AccountInfoVO();
        accountInfoVO.setFirstName("Test");
        accountInfoVO.setLastName("user");

        //tax details
        ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();

        TaxDetailInfo taxDetailInfo = new TaxDetailInfo();
        //taxDetailInfo.setTaxDescription(key);
        //taxDetailInfo.setTaxAmount(String.valueOf(value));
        taxDetailInfoList.add(taxDetailInfo);
        HashMap<String, Double> taxDetails = new HashMap<>();
        taxDetails.putIfAbsent("random1", 22.1);

        //Address
        AddressVO addressVO = new AddressVO();
        addressVO.setAddressLine1("harrongton drive Ohio");
        addressVO.setEmailAddress("test@test.com");
        addressVO.setAltPhoneNumber("123457896");

        accountInfoVO.setAddress(addressVO);
        List<PrepayDeviceVO> prepayDeviceVOList = new ArrayList<>();
        PrepayDeviceVO prepayDeviceVO = new PrepayDeviceVO();
        prepayDeviceVO.setId("random01");
        prepayDeviceVO.setItemType("DEVICE");
        prepayDeviceVO.setFutureDiscount(24.0);
        prepayDeviceVO.setFutureDiscountMonths(3);
        prepayDeviceVO.setCapacity("128 GB");
        prepayDeviceVO.setFullRetailListPrice(123.00);
        prepayDeviceVO.setRawTotalAmount(123.00);
        prepayDeviceVO.setImei("imei");
        prepayDeviceVO.setRequestedEsimImei("359272531292045");
        prepayDeviceVO.setSmartImeiDevice(false);
        prepayDeviceVO.setESIMEnabledDevice(false);
        prepayDeviceVO.setEsimOnlyDevice(false);
        prepayDeviceVO.setEsimCompatible(false);
        prepayDeviceVOList.add(0,prepayDeviceVO);

        prepayDeviceVO.setTaxDetails(taxDetails);

        VZWPrepayOrderVO pageData = new VZWPrepayOrderVO();
        pageData.setFlow("NAP");
        pageData.setSessionId("123");
        pageData.setPaymentMethod("VISA");
        pageData.setPaypalInfo("verizonbuyertest@test.com");
        pageData.setShippingMethod("Next Day by 8pm");
        pageData.setOrderNumber("93601083317");
        pageData.setDeviceList(prepayDeviceVOList);
        pageData.setAccessoryList(prepayAccessoryVOList);
        pageData.setAccountInfo(accountInfoVO);
        pageData.setPromotions(prepayPromotionList);
        PrepayAccessoryVO prepayAccessoryVO1 = new PrepayAccessoryVO();
        prepayAccessoryVO1.setDeviceCommerceItemId("deviceId1");
        prepayAccessoryVO1.setSorId("123");
        prepayAccessoryVO1.setItemType("ACCESSORY");
        prepayAccessoryVO1.setFullRetailListPrice(15.00);
        prepayAccessoryVO1.setRawTotalAmount(13.00);


        PrepayAccessoryVO prepayAccessoryVO2 = new PrepayAccessoryVO();
        List<PrepayAccessoryVO> prepayAccessoryVOS = new ArrayList<>();
        pageData.setAccessoryList(prepayAccessoryVOS);


        pageData.getDeviceList().get(0).setPlanItemId("randomPlanItem");
        pageData.setFlow("PAL");
        pageData.getDeviceList().get(0).setId("deviceId1");
        pageData.getDeviceList().get(0).setNumberShareLineItemId("S007194d00ba2177707ac8cf9fcbd4bd7{as4}_device_961754431");
        List<PrepayPlanVO> planList = new ArrayList<>();
        PrepayPlanVO planVO1 = new PrepayPlanVO();
        PrepayPlanVO planVO2 = new PrepayPlanVO();
        planVO1.setId("randomPlanItem");
        planVO1.setFeatureLineItemId("featureLineItemId");
        planList.add(planVO1);
        planList.add(planVO2);
        pageData.setPlanList(planList);
        PrepayFeatureVO prepayFeatureVO = new PrepayFeatureVO();
        prepayFeatureVO.setSorId("123");
        prepayFeatureVO.setSkuId("sku_123");
        prepayFeatureVO.setDisplayName("displayName");
        prepayFeatureVO.setDueToday(0.00);
        prepayFeatureVO.setId("123");
        prepayFeatureVO.setDescription("12345");
        prepayFeatureVO.setDescription("Sample Description");
        prepayFeatureVO.setDueMonthly(3.02);
        List<PrepayFeatureVO> prepayFeatureVOS = new ArrayList<>();
        prepayFeatureVOS.add(prepayFeatureVO);
        pageData.setFeatureList(prepayFeatureVOS);
        pageData.setBillingAddress(accountInfoVO);
        PrepaidODRequestData redisData=getPrepaidODRequestData();
        redisData.setLoggedIn(true);

        CheckoutDetailsCXPResponse res = converter.translateCheckoutDetails(pageData, redisData, httpRequest, request);
        Assert.assertEquals(pageData.getSessionId(), res.getData().getCart().getCartHeader().getSessionId());
        Assert.assertNotNull(res.getData().getCart().getLineDetails().getPayments().get(0).getCreditCardDetails());
    }

    @Test
    public void translateCheckoutDetailsFlowCheckLoggedin_PUPFlow() throws IOException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        CheckoutDetailsCXPRequest request = mapper.readValue(requestString, CheckoutDetailsCXPRequest.class);
        CheckoutDetailsCXPResponse response = mapper.readValue(responseString, CheckoutDetailsCXPResponse.class);

        URI url = URI.create("http://localhost/test");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        PrepayAccessoryVO prepayAccessoryVO = new PrepayAccessoryVO();
        prepayAccessoryVO.setDeviceCommerceItemId("random01");

        List<PrepayAccessoryVO> prepayAccessoryVOList = new ArrayList<>();

        //promotions
        VZWPrepayPromotion prepayPromotion = new VZWPrepayPromotion();
        List<VZWPrepayPromotion> prepayPromotionList = new ArrayList<>();
        prepayPromotionList.add(prepayPromotion);

        //AccountInfo
        AccountInfoVO accountInfoVO = new AccountInfoVO();
        accountInfoVO.setFirstName("Test");
        accountInfoVO.setLastName("user");

        //tax details
        ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();

        TaxDetailInfo taxDetailInfo = new TaxDetailInfo();
        //taxDetailInfo.setTaxDescription(key);
        //taxDetailInfo.setTaxAmount(String.valueOf(value));
        taxDetailInfoList.add(taxDetailInfo);
        HashMap<String, Double> taxDetails = new HashMap<>();
        taxDetails.putIfAbsent("random1", 22.1);

        //Address
        AddressVO addressVO = new AddressVO();
        addressVO.setAddressLine1("harrongton drive Ohio");
        addressVO.setEmailAddress("test@test.com");
        addressVO.setAltPhoneNumber("123457896");

        accountInfoVO.setAddress(addressVO);
        List<PrepayDeviceVO> prepayDeviceVOList = new ArrayList<>();
        PrepayDeviceVO prepayDeviceVO = new PrepayDeviceVO();
        prepayDeviceVO.setId("random01");
        prepayDeviceVO.setItemType("DEVICE");
        prepayDeviceVO.setFutureDiscount(24.0);
        prepayDeviceVO.setFutureDiscountMonths(3);
        prepayDeviceVO.setCapacity("128 GB");
        prepayDeviceVO.setFullRetailListPrice(123.00);
        prepayDeviceVO.setRawTotalAmount(123.00);
        prepayDeviceVO.setImei("imei");
        prepayDeviceVO.setRequestedEsimImei("359272531292045");
        prepayDeviceVO.setSmartImeiDevice(false);
        prepayDeviceVO.setESIMEnabledDevice(false);
        prepayDeviceVO.setEsimOnlyDevice(false);
        prepayDeviceVO.setEsimCompatible(false);
        prepayDeviceVOList.add(0,prepayDeviceVO);

        prepayDeviceVO.setTaxDetails(taxDetails);

        VZWPrepayOrderVO pageData = new VZWPrepayOrderVO();
        pageData.setFlow("NAP");
        pageData.setSessionId("123");
        pageData.setPaymentMethod("VISA");
        pageData.setPaypalInfo("verizonbuyertest@test.com");
        pageData.setShippingMethod("Next Day by 8pm");
        pageData.setOrderNumber("93601083317");
        pageData.setDeviceList(prepayDeviceVOList);
        pageData.setAccessoryList(prepayAccessoryVOList);
        pageData.setAccountInfo(accountInfoVO);
        pageData.setPromotions(prepayPromotionList);
        PrepayAccessoryVO prepayAccessoryVO1 = new PrepayAccessoryVO();
        prepayAccessoryVO1.setDeviceCommerceItemId("deviceId1");
        prepayAccessoryVO1.setSorId("123");
        prepayAccessoryVO1.setItemType("ACCESSORY");
        prepayAccessoryVO1.setFullRetailListPrice(15.00);
        prepayAccessoryVO1.setRawTotalAmount(13.00);


        PrepayAccessoryVO prepayAccessoryVO2 = new PrepayAccessoryVO();
        List<PrepayAccessoryVO> prepayAccessoryVOS = new ArrayList<>();
        pageData.setAccessoryList(prepayAccessoryVOS);


        pageData.getDeviceList().get(0).setPlanItemId("randomPlanItem");
        pageData.setFlow("PUP");
        pageData.getDeviceList().get(0).setId("deviceId1");
        pageData.getDeviceList().get(0).setNumberShareLineItemId("S007194d00ba2177707ac8cf9fcbd4bd7{as4}_device_961754431");
        List<PrepayPlanVO> planList = new ArrayList<>();
        PrepayPlanVO planVO1 = new PrepayPlanVO();
        PrepayPlanVO planVO2 = new PrepayPlanVO();
        planVO1.setId("randomPlanItem");
        planVO1.setFeatureLineItemId("featureLineItemId");
        planList.add(planVO1);
        planList.add(planVO2);
        pageData.setPlanList(planList);
        PrepayFeatureVO prepayFeatureVO = new PrepayFeatureVO();
        prepayFeatureVO.setSorId("123");
        prepayFeatureVO.setSkuId("sku_123");
        prepayFeatureVO.setDisplayName("displayName");
        prepayFeatureVO.setDueToday(0.00);
        prepayFeatureVO.setId("123");
        prepayFeatureVO.setDescription("12345");
        prepayFeatureVO.setDescription("Sample Description");
        prepayFeatureVO.setDueMonthly(3.02);
        List<PrepayFeatureVO> prepayFeatureVOS = new ArrayList<>();
        prepayFeatureVOS.add(prepayFeatureVO);
        pageData.setFeatureList(prepayFeatureVOS);
        pageData.setBillingAddress(accountInfoVO);
        PrepaidODRequestData redisData=getPrepaidODRequestData();
        redisData.setLoggedIn(true);

        CheckoutDetailsCXPResponse res = converter.translateCheckoutDetails(pageData, redisData, httpRequest, request);
        Assert.assertEquals(pageData.getSessionId(), res.getData().getCart().getCartHeader().getSessionId());
        Assert.assertNotNull(res.getData().getCart().getLineDetails().getPayments().get(0).getCreditCardDetails());
    }

    @Test
    public void translateCheckoutDetailsCardPaymentTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        CheckoutDetailsCXPRequest request = mapper.readValue(requestString, CheckoutDetailsCXPRequest.class);
        CheckoutDetailsCXPResponse response = mapper.readValue(responseString, CheckoutDetailsCXPResponse.class);

        URI url = URI.create("http://localhost/test");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        PrepayAccessoryVO prepayAccessoryVO = new PrepayAccessoryVO();
        prepayAccessoryVO.setDeviceCommerceItemId("random01");

        List<PrepayAccessoryVO> prepayAccessoryVOList = new ArrayList<>();

        //promotions
        VZWPrepayPromotion prepayPromotion = new VZWPrepayPromotion();
        List<VZWPrepayPromotion> prepayPromotionList = new ArrayList<>();
        prepayPromotionList.add(prepayPromotion);

        //AccountInfo
        AccountInfoVO accountInfoVO = new AccountInfoVO();
        accountInfoVO.setFirstName("Test");
        accountInfoVO.setLastName("user");

        //tax details
        ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();

        TaxDetailInfo taxDetailInfo = new TaxDetailInfo();
        //taxDetailInfo.setTaxDescription(key);
        //taxDetailInfo.setTaxAmount(String.valueOf(value));
        taxDetailInfoList.add(taxDetailInfo);
        HashMap<String, Double> taxDetails = new HashMap<>();
        taxDetails.putIfAbsent("random1", 22.1);

        //Address
        AddressVO addressVO = new AddressVO();
        addressVO.setAddressLine1("harrongton drive Ohio");
        addressVO.setEmailAddress("test@test.com");
        addressVO.setAltPhoneNumber("123457896");

        accountInfoVO.setAddress(addressVO);
        List<PrepayDeviceVO> prepayDeviceVOList = new ArrayList<>();
        PrepayDeviceVO prepayDeviceVO = new PrepayDeviceVO();
        prepayDeviceVO.setId("random01");
        prepayDeviceVO.setItemType("DEVICE");
        prepayDeviceVO.setFutureDiscount(24.0);
        prepayDeviceVO.setFutureDiscountMonths(3);
        prepayDeviceVO.setCapacity("128 GB");
        prepayDeviceVO.setFullRetailListPrice(123.00);
        prepayDeviceVO.setRawTotalAmount(123.00);
        prepayDeviceVO.setImei("imei");
        prepayDeviceVO.setRequestedEsimImei("359272531292045");
        prepayDeviceVO.setSmartImeiDevice(false);
        prepayDeviceVO.setESIMEnabledDevice(false);
        prepayDeviceVO.setEsimOnlyDevice(false);
        prepayDeviceVO.setEsimCompatible(false);
        prepayDeviceVOList.add(0,prepayDeviceVO);

        prepayDeviceVO.setTaxDetails(taxDetails);

        VZWPrepayOrderVO pageData = new VZWPrepayOrderVO();
        pageData.setFlow("NAP");
        pageData.setSessionId("123");
        pageData.setPaymentMethod("VISA");
        pageData.setPaypalInfo("verizonbuyertest@test.com");
        pageData.setShippingMethod("Next Day by 8pm");
        pageData.setOrderNumber("93601083317");
        pageData.setDeviceList(prepayDeviceVOList);
        pageData.setAccessoryList(prepayAccessoryVOList);
        pageData.setAccountInfo(accountInfoVO);
        pageData.setPromotions(prepayPromotionList);
        PrepayAccessoryVO prepayAccessoryVO1 = new PrepayAccessoryVO();
        prepayAccessoryVO1.setDeviceCommerceItemId("deviceId1");
        prepayAccessoryVO1.setSorId("123");
        prepayAccessoryVO1.setItemType("ACCESSORY");
        prepayAccessoryVO1.setFullRetailListPrice(15.00);
        prepayAccessoryVO1.setRawTotalAmount(13.00);


        PrepayAccessoryVO prepayAccessoryVO2 = new PrepayAccessoryVO();
        List<PrepayAccessoryVO> prepayAccessoryVOS = new ArrayList<>();
        pageData.setAccessoryList(prepayAccessoryVOS);

        pageData.getDeviceList().get(0).setPlanItemId("randomPlanItem");
        pageData.getDeviceList().get(0).setId("deviceId1");
        pageData.getDeviceList().get(0).setNumberShareLineItemId("S007194d00ba2177707ac8cf9fcbd4bd7{as4}_device_961754431");
        List<PrepayPlanVO> planList = new ArrayList<>();
        PrepayPlanVO planVO1 = new PrepayPlanVO();
        PrepayPlanVO planVO2 = new PrepayPlanVO();
        planVO1.setId("randomPlanItem");
        planVO1.setFeatureLineItemId("featureLineItemId");
        planList.add(planVO1);
        planList.add(planVO2);
        pageData.setPlanList(planList);
        PrepayFeatureVO prepayFeatureVO = new PrepayFeatureVO();
        prepayFeatureVO.setSorId("123");
        prepayFeatureVO.setSkuId("sku_123");
        prepayFeatureVO.setDisplayName("displayName");
        prepayFeatureVO.setDueToday(0.00);
        prepayFeatureVO.setId("123");
        prepayFeatureVO.setDescription("12345");
        prepayFeatureVO.setDescription("Sample Description");
        prepayFeatureVO.setDueMonthly(3.02);
        List<PrepayFeatureVO> prepayFeatureVOS = new ArrayList<>();
        prepayFeatureVOS.add(prepayFeatureVO);
        pageData.setFeatureList(prepayFeatureVOS);
        pageData.setBillingAddress(accountInfoVO);

        CheckoutDetailsCXPResponse res = converter.translateCheckoutDetails(pageData, getPrepaidODRequestData(), httpRequest, request);
        Assert.assertEquals(pageData.getSessionId(), res.getData().getCart().getCartHeader().getSessionId());
        Assert.assertNotNull(res.getData().getCart().getLineDetails().getPayments().get(0).getCreditCardDetails());
    }

    @Test
    public void translateCheckoutDetailsCardPaymentTest_PAL() throws IOException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        CheckoutDetailsCXPRequest request = mapper.readValue(requestString, CheckoutDetailsCXPRequest.class);
        CheckoutDetailsCXPResponse response = mapper.readValue(responseString, CheckoutDetailsCXPResponse.class);

        URI url = URI.create("http://localhost/test");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        PrepayAccessoryVO prepayAccessoryVO = new PrepayAccessoryVO();
        prepayAccessoryVO.setDeviceCommerceItemId("random01");

        List<PrepayAccessoryVO> prepayAccessoryVOList = new ArrayList<>();

        //promotions
        VZWPrepayPromotion prepayPromotion = new VZWPrepayPromotion();
        List<VZWPrepayPromotion> prepayPromotionList = new ArrayList<>();
        prepayPromotionList.add(prepayPromotion);

        //AccountInfo
        AccountInfoVO accountInfoVO = new AccountInfoVO();
        accountInfoVO.setFirstName("Test");
        accountInfoVO.setLastName("user");

        //tax details
        ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();

        TaxDetailInfo taxDetailInfo = new TaxDetailInfo();
        //taxDetailInfo.setTaxDescription(key);
        //taxDetailInfo.setTaxAmount(String.valueOf(value));
        taxDetailInfoList.add(taxDetailInfo);
        HashMap<String, Double> taxDetails = new HashMap<>();
        taxDetails.putIfAbsent("random1", 22.1);

        //Address
        AddressVO addressVO = new AddressVO();
        addressVO.setAddressLine1("harrongton drive Ohio");
        addressVO.setEmailAddress("test@test.com");
        addressVO.setAltPhoneNumber("123457896");

        accountInfoVO.setAddress(addressVO);
        List<PrepayDeviceVO> prepayDeviceVOList = new ArrayList<>();
        PrepayDeviceVO prepayDeviceVO = new PrepayDeviceVO();
        prepayDeviceVO.setId("random01");
        prepayDeviceVO.setItemType("DEVICE");
        prepayDeviceVO.setCapacity("128 GB");
        prepayDeviceVO.setFullRetailListPrice(123.00);
        prepayDeviceVO.setRawTotalAmount(123.00);
        prepayDeviceVO.setImei("imei");
        prepayDeviceVO.setRequestedEsimImei("359272531292045");
        prepayDeviceVO.setSmartImeiDevice(false);
        prepayDeviceVO.setESIMEnabledDevice(false);
        prepayDeviceVO.setEsimOnlyDevice(false);
        prepayDeviceVO.setEsimCompatible(false);
        prepayDeviceVOList.add(0,prepayDeviceVO);

        prepayDeviceVO.setTaxDetails(taxDetails);

        VZWPrepayOrderVO pageData = new VZWPrepayOrderVO();
        pageData.setFlow("PAL");
        pageData.setSessionId("123");
        pageData.setPaymentMethod("VISA");
        pageData.setPaypalInfo("verizonbuyertest@test.com");
        pageData.setShippingMethod("Next Day by 8pm");
        pageData.setOrderNumber("93601083317");
        pageData.setDeviceList(prepayDeviceVOList);
        pageData.setAccessoryList(prepayAccessoryVOList);
        pageData.setAccountInfo(accountInfoVO);
        pageData.setPromotions(prepayPromotionList);
        PrepayAccessoryVO prepayAccessoryVO1 = new PrepayAccessoryVO();
        prepayAccessoryVO1.setDeviceCommerceItemId("deviceId1");
        prepayAccessoryVO1.setSorId("123");
        prepayAccessoryVO1.setItemType("ACCESSORY");
        prepayAccessoryVO1.setFullRetailListPrice(15.00);
        prepayAccessoryVO1.setRawTotalAmount(13.00);


        PrepayAccessoryVO prepayAccessoryVO2 = new PrepayAccessoryVO();
        List<PrepayAccessoryVO> prepayAccessoryVOS = new ArrayList<>();
        pageData.setAccessoryList(prepayAccessoryVOS);

        pageData.getDeviceList().get(0).setPlanItemId("randomPlanItem");
        pageData.getDeviceList().get(0).setId("deviceId1");
        pageData.getDeviceList().get(0).setNumberShareLineItemId("S007194d00ba2177707ac8cf9fcbd4bd7{as4}_device_961754431");
        List<PrepayPlanVO> planList = new ArrayList<>();
        PrepayPlanVO planVO1 = new PrepayPlanVO();
        PrepayPlanVO planVO2 = new PrepayPlanVO();
        planVO1.setId("randomPlanItem");
        planVO1.setFeatureLineItemId("featureLineItemId");
        planList.add(planVO1);
        planList.add(planVO2);
        pageData.setPlanList(planList);
        PrepayFeatureVO prepayFeatureVO = new PrepayFeatureVO();
        prepayFeatureVO.setSorId("123");
        prepayFeatureVO.setSkuId("sku_123");
        prepayFeatureVO.setDisplayName("displayName");
        prepayFeatureVO.setDueToday(0.00);
        prepayFeatureVO.setId("123");
        prepayFeatureVO.setDescription("12345");
        prepayFeatureVO.setDescription("Sample Description");
        prepayFeatureVO.setDueMonthly(3.02);
        List<PrepayFeatureVO> prepayFeatureVOS = new ArrayList<>();
        prepayFeatureVOS.add(prepayFeatureVO);
        pageData.setFeatureList(prepayFeatureVOS);
        pageData.setBillingAddress(accountInfoVO);

        CheckoutDetailsCXPResponse res = converter.translateCheckoutDetails(pageData, getPrepaidODRequestData(), httpRequest, request);
        Assert.assertEquals(pageData.getSessionId(), res.getData().getCart().getCartHeader().getSessionId());
        Assert.assertNotNull(res.getData().getCart().getLineDetails().getPayments().get(0).getCreditCardDetails());
    }

    @Test
    public void translateCheckoutDetailsCardPaymentTest_NSP() throws IOException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        CheckoutDetailsCXPRequest request = mapper.readValue(requestString, CheckoutDetailsCXPRequest.class);
        CheckoutDetailsCXPResponse response = mapper.readValue(responseString, CheckoutDetailsCXPResponse.class);

        URI url = URI.create("http://localhost/test");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        PrepayAccessoryVO prepayAccessoryVO = new PrepayAccessoryVO();
        prepayAccessoryVO.setDeviceCommerceItemId("random01");

        List<PrepayAccessoryVO> prepayAccessoryVOList = new ArrayList<>();

        //promotions
        VZWPrepayPromotion prepayPromotion = new VZWPrepayPromotion();
        List<VZWPrepayPromotion> prepayPromotionList = new ArrayList<>();
        prepayPromotionList.add(prepayPromotion);

        //AccountInfo
        AccountInfoVO accountInfoVO = new AccountInfoVO();
        accountInfoVO.setFirstName("Test");
        accountInfoVO.setLastName("user");

        //tax details
        ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();

        TaxDetailInfo taxDetailInfo = new TaxDetailInfo();
        //taxDetailInfo.setTaxDescription(key);
        //taxDetailInfo.setTaxAmount(String.valueOf(value));
        taxDetailInfoList.add(taxDetailInfo);
        HashMap<String, Double> taxDetails = new HashMap<>();
        taxDetails.putIfAbsent("random1", 22.1);

        //Address
        AddressVO addressVO = new AddressVO();
        addressVO.setAddressLine1("harrongton drive Ohio");
        addressVO.setEmailAddress("test@test.com");
        addressVO.setAltPhoneNumber("123457896");

        accountInfoVO.setAddress(addressVO);
        List<PrepayDeviceVO> prepayDeviceVOList = new ArrayList<>();
        PrepayDeviceVO prepayDeviceVO = new PrepayDeviceVO();
        prepayDeviceVO.setId("random01");
        prepayDeviceVO.setItemType("DEVICE");
        prepayDeviceVO.setCapacity("128 GB");
        prepayDeviceVO.setFullRetailListPrice(123.00);
        prepayDeviceVO.setRawTotalAmount(123.00);
        prepayDeviceVO.setImei("imei");
        prepayDeviceVO.setRequestedEsimImei("359272531292045");
        prepayDeviceVO.setSmartImeiDevice(false);
        prepayDeviceVO.setESIMEnabledDevice(false);
        prepayDeviceVO.setEsimOnlyDevice(false);
        prepayDeviceVO.setEsimCompatible(false);
        prepayDeviceVO.setNumberShareLineItemId("S007194d00ba2177707ac8cf9fcbd4bd7{as4}_device_961754431");
        prepayDeviceVOList.add(0,prepayDeviceVO);

        prepayDeviceVO.setTaxDetails(taxDetails);

        VZWPrepayOrderVO pageData = new VZWPrepayOrderVO();
        pageData.setFlow("NSP");
        pageData.setSessionId("123");
        pageData.setPaymentMethod("VISA");
        pageData.setPaypalInfo("verizonbuyertest@test.com");
        pageData.setShippingMethod("Next Day by 8pm");
        pageData.setOrderNumber("93601083317");
        pageData.setDeviceList(prepayDeviceVOList);
        pageData.setAccessoryList(prepayAccessoryVOList);
        pageData.setAccountInfo(accountInfoVO);
        pageData.setPromotions(prepayPromotionList);
        PrepayAccessoryVO prepayAccessoryVO1 = new PrepayAccessoryVO();
        prepayAccessoryVO1.setDeviceCommerceItemId("deviceId1");
        prepayAccessoryVO1.setSorId("123");
        prepayAccessoryVO1.setItemType("ACCESSORY");
        prepayAccessoryVO1.setFullRetailListPrice(15.00);
        prepayAccessoryVO1.setRawTotalAmount(13.00);


        PrepayAccessoryVO prepayAccessoryVO2 = new PrepayAccessoryVO();
        List<PrepayAccessoryVO> prepayAccessoryVOS = new ArrayList<>();
        pageData.setAccessoryList(prepayAccessoryVOS);

        pageData.getDeviceList().get(0).setPlanItemId("randomPlanItem");
        pageData.setEnableFamilyPricing(true);
        pageData.getDeviceList().get(0).setId("deviceId1");
        List<PrepayPlanVO> planList = new ArrayList<>();
        PrepayPlanVO planVO1 = new PrepayPlanVO();
        PrepayPlanVO planVO2 = new PrepayPlanVO();
        planVO1.setId("randomPlanItem");
        planVO1.setBundleDiscountApplied(true);
        planVO1.setFeatureLineItemId("featureLineItemId");
        planList.add(planVO1);
        planList.add(planVO2);
        pageData.setPlanList(planList);
        PrepayFeatureVO prepayFeatureVO = new PrepayFeatureVO();
        prepayFeatureVO.setSorId("123");
        prepayFeatureVO.setSkuId("sku_123");
        prepayFeatureVO.setDisplayName("displayName");
        prepayFeatureVO.setDueToday(0.00);
        prepayFeatureVO.setId("123");
        prepayFeatureVO.setDescription("12345");
        prepayFeatureVO.setDescription("Sample Description");
        prepayFeatureVO.setDueMonthly(3.02);
        List<PrepayFeatureVO> prepayFeatureVOS = new ArrayList<>();
        prepayFeatureVOS.add(prepayFeatureVO);
        pageData.setFeatureList(prepayFeatureVOS);
        pageData.setBillingAddress(accountInfoVO);

        CheckoutDetailsCXPResponse res = converter.translateCheckoutDetails(pageData, getPrepaidODRequestData(), httpRequest, request);
        Assert.assertEquals(pageData.getSessionId(), res.getData().getCart().getCartHeader().getSessionId());
        Assert.assertNotNull(res.getData().getCart().getLineDetails().getPayments().get(0).getCreditCardDetails());
    }

    @Test
    public void translateCheckoutDetailsCardPaymentTest_PUPFlow() throws IOException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        CheckoutDetailsCXPRequest request = mapper.readValue(requestString, CheckoutDetailsCXPRequest.class);
        CheckoutDetailsCXPResponse response = mapper.readValue(responseString, CheckoutDetailsCXPResponse.class);

        URI url = URI.create("http://localhost/test");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        PrepayAccessoryVO prepayAccessoryVO = new PrepayAccessoryVO();
        prepayAccessoryVO.setDeviceCommerceItemId("random01");

        List<PrepayAccessoryVO> prepayAccessoryVOList = new ArrayList<>();

        //promotions
        VZWPrepayPromotion prepayPromotion = new VZWPrepayPromotion();
        List<VZWPrepayPromotion> prepayPromotionList = new ArrayList<>();
        prepayPromotionList.add(prepayPromotion);

        //AccountInfo
        AccountInfoVO accountInfoVO = new AccountInfoVO();
        accountInfoVO.setFirstName("Test");
        accountInfoVO.setLastName("user");

        //tax details
        ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();

        TaxDetailInfo taxDetailInfo = new TaxDetailInfo();
        //taxDetailInfo.setTaxDescription(key);
        //taxDetailInfo.setTaxAmount(String.valueOf(value));
        taxDetailInfoList.add(taxDetailInfo);
        HashMap<String, Double> taxDetails = new HashMap<>();
        taxDetails.putIfAbsent("random1", 22.1);

        //Address
        AddressVO addressVO = new AddressVO();
        addressVO.setAddressLine1("harrongton drive Ohio");
        addressVO.setEmailAddress("test@test.com");
        addressVO.setAltPhoneNumber("123457896");

        accountInfoVO.setAddress(addressVO);
        List<PrepayDeviceVO> prepayDeviceVOList = new ArrayList<>();
        PrepayDeviceVO prepayDeviceVO = new PrepayDeviceVO();
        prepayDeviceVO.setId("random01");
        prepayDeviceVO.setItemType("DEVICE");
        prepayDeviceVO.setCapacity("128 GB");
        prepayDeviceVO.setFullRetailListPrice(123.00);
        prepayDeviceVO.setRawTotalAmount(123.00);
        prepayDeviceVO.setImei("imei");
        prepayDeviceVO.setRequestedEsimImei("359272531292045");
        prepayDeviceVO.setSmartImeiDevice(false);
        prepayDeviceVO.setESIMEnabledDevice(false);
        prepayDeviceVO.setEsimOnlyDevice(false);
        prepayDeviceVO.setEsimCompatible(false);
        prepayDeviceVOList.add(0,prepayDeviceVO);

        prepayDeviceVO.setTaxDetails(taxDetails);

        VZWPrepayOrderVO pageData = new VZWPrepayOrderVO();
        pageData.setFlow("PUP");
        pageData.setSessionId("123");
        pageData.setPaymentMethod("VISA");
        pageData.setPaypalInfo("verizonbuyertest@test.com");
        pageData.setShippingMethod("Next Day by 8pm");
        pageData.setOrderNumber("93601083317");
        pageData.setDeviceList(prepayDeviceVOList);
        pageData.setAccessoryList(prepayAccessoryVOList);
        pageData.setAccountInfo(accountInfoVO);
        pageData.setPromotions(prepayPromotionList);
        PrepayAccessoryVO prepayAccessoryVO1 = new PrepayAccessoryVO();
        prepayAccessoryVO1.setDeviceCommerceItemId("deviceId1");
        prepayAccessoryVO1.setSorId("123");
        prepayAccessoryVO1.setItemType("ACCESSORY");
        prepayAccessoryVO1.setFullRetailListPrice(15.00);
        prepayAccessoryVO1.setRawTotalAmount(13.00);


        PrepayAccessoryVO prepayAccessoryVO2 = new PrepayAccessoryVO();
        List<PrepayAccessoryVO> prepayAccessoryVOS = new ArrayList<>();
        pageData.setAccessoryList(prepayAccessoryVOS);

        pageData.getDeviceList().get(0).setPlanItemId("randomPlanItem");
        pageData.getDeviceList().get(0).setId("deviceId1");
        pageData.getDeviceList().get(0).setNumberShareLineItemId("S007194d00ba2177707ac8cf9fcbd4bd7{as4}_device_961754431");
        List<PrepayPlanVO> planList = new ArrayList<>();
        PrepayPlanVO planVO1 = new PrepayPlanVO();
        PrepayPlanVO planVO2 = new PrepayPlanVO();
        planVO1.setId("randomPlanItem");
        planVO1.setFeatureLineItemId("featureLineItemId");
        planList.add(planVO1);
        planList.add(planVO2);
        pageData.setPlanList(planList);
        PrepayFeatureVO prepayFeatureVO = new PrepayFeatureVO();
        prepayFeatureVO.setSorId("123");
        prepayFeatureVO.setSkuId("sku_123");
        prepayFeatureVO.setDisplayName("displayName");
        prepayFeatureVO.setDueToday(0.00);
        prepayFeatureVO.setId("123");
        prepayFeatureVO.setDescription("12345");
        prepayFeatureVO.setDescription("Sample Description");
        prepayFeatureVO.setDueMonthly(3.02);
        List<PrepayFeatureVO> prepayFeatureVOS = new ArrayList<>();
        prepayFeatureVOS.add(prepayFeatureVO);
        pageData.setFeatureList(prepayFeatureVOS);
        pageData.setBillingAddress(accountInfoVO);

        CheckoutDetailsCXPResponse res = converter.translateCheckoutDetails(pageData, getPrepaidODRequestData(), httpRequest, request);
        Assert.assertEquals(pageData.getSessionId(), res.getData().getCart().getCartHeader().getSessionId());
        Assert.assertNotNull(res.getData().getCart().getLineDetails().getPayments().get(0).getCreditCardDetails());
    }
    @Test
    public void translateCheckoutDetailsItemTypeSimTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        CheckoutDetailsCXPRequest request = mapper.readValue(requestString, CheckoutDetailsCXPRequest.class);
        CheckoutDetailsCXPResponse response = mapper.readValue(responseString, CheckoutDetailsCXPResponse.class);

        URI url = URI.create("http://localhost/test");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        PrepayAccessoryVO prepayAccessoryVO = new PrepayAccessoryVO();
        prepayAccessoryVO.setDeviceCommerceItemId("random01");

        List<PrepayAccessoryVO> prepayAccessoryVOList = new ArrayList<>();

        //promotions
        VZWPrepayPromotion prepayPromotion = new VZWPrepayPromotion();
        List<VZWPrepayPromotion> prepayPromotionList = new ArrayList<>();
        prepayPromotionList.add(prepayPromotion);

        //AccountInfo
        AccountInfoVO accountInfoVO = new AccountInfoVO();
        accountInfoVO.setFirstName("Test");
        accountInfoVO.setLastName("user");

        //tax details
        ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();

        TaxDetailInfo taxDetailInfo = new TaxDetailInfo();
        //taxDetailInfo.setTaxDescription(key);
        //taxDetailInfo.setTaxAmount(String.valueOf(value));
        taxDetailInfoList.add(taxDetailInfo);
        HashMap<String, Double> taxDetails = new HashMap<>();
        taxDetails.putIfAbsent("random1", 22.1);

        //Address
        AddressVO addressVO = new AddressVO();
        addressVO.setAddressLine1("harrongton drive Ohio");
        addressVO.setEmailAddress("test@test.com");
        addressVO.setAltPhoneNumber("123457896");

        accountInfoVO.setAddress(addressVO);
        List<PrepayDeviceVO> prepayDeviceVOList = new ArrayList<>();
        PrepayDeviceVO prepayDeviceVO = new PrepayDeviceVO();
        prepayDeviceVO.setId("random01");
        prepayDeviceVO.setItemType("SIM");
        prepayDeviceVO.setCapacity("128 GB");
        prepayDeviceVO.setFullRetailListPrice(123.00);
        prepayDeviceVO.setRawTotalAmount(123.00);
        prepayDeviceVO.setImei("imei");
        prepayDeviceVO.setRequestedEsimImei("359272531292045");
        prepayDeviceVO.setSmartImeiDevice(false);
        prepayDeviceVO.setESIMEnabledDevice(false);
        prepayDeviceVO.setEsimOnlyDevice(false);
        prepayDeviceVO.setEsimCompatible(false);
        prepayDeviceVOList.add(0,prepayDeviceVO);

        prepayDeviceVO.setTaxDetails(taxDetails);

        VZWPrepayOrderVO pageData = new VZWPrepayOrderVO();
        pageData.setFlow("PASO");
        pageData.setSessionId("123");
        pageData.setPaymentMethod("VISA");
        pageData.setPaypalInfo("verizonbuyertest@test.com");
        pageData.setShippingMethod("Next Day by 8pm");
        pageData.setOrderNumber("93601083317");
        pageData.setDeviceList(prepayDeviceVOList);
        pageData.setAccessoryList(prepayAccessoryVOList);
        pageData.setAccountInfo(accountInfoVO);
        pageData.setPromotions(prepayPromotionList);
        PrepayAccessoryVO prepayAccessoryVO1 = new PrepayAccessoryVO();
        prepayAccessoryVO1.setDeviceCommerceItemId("deviceId1");
        prepayAccessoryVO1.setSorId("123");
        prepayAccessoryVO1.setItemType("ACCESSORY");
        prepayAccessoryVO1.setFullRetailListPrice(15.00);
        prepayAccessoryVO1.setRawTotalAmount(13.00);


        PrepayAccessoryVO prepayAccessoryVO2 = new PrepayAccessoryVO();
        List<PrepayAccessoryVO> prepayAccessoryVOS = new ArrayList<>();
        pageData.setAccessoryList(prepayAccessoryVOS);

        pageData.getDeviceList().get(0).setPlanItemId("randomPlanItem");
        pageData.getDeviceList().get(0).setId("deviceId1");
        pageData.getDeviceList().get(0).setNumberShareLineItemId("S007194d00ba2177707ac8cf9fcbd4bd7{as4}_device_961754431");
        List<PrepayPlanVO> planList = new ArrayList<>();
        PrepayPlanVO planVO1 = new PrepayPlanVO();
        PrepayPlanVO planVO2 = new PrepayPlanVO();
        planVO1.setId("randomPlanItem");
        planVO1.setFeatureLineItemId("featureLineItemId");
        planList.add(planVO1);
        planList.add(planVO2);
        pageData.setPlanList(planList);
        PrepayFeatureVO prepayFeatureVO = new PrepayFeatureVO();
        prepayFeatureVO.setSorId("123");
        prepayFeatureVO.setSkuId("sku_123");
        prepayFeatureVO.setDisplayName("displayName");
        prepayFeatureVO.setDueToday(0.00);
        prepayFeatureVO.setId("123");
        prepayFeatureVO.setDescription("12345");
        prepayFeatureVO.setDescription("Sample Description");
        prepayFeatureVO.setDueMonthly(3.02);
        List<PrepayFeatureVO> prepayFeatureVOS = new ArrayList<>();
        prepayFeatureVOS.add(prepayFeatureVO);
        pageData.setFeatureList(prepayFeatureVOS);
        pageData.setBillingAddress(accountInfoVO);

        CheckoutDetailsCXPResponse res = converter.translateCheckoutDetails(pageData, getPrepaidODRequestData(), httpRequest, request);
        Assert.assertEquals(pageData.getSessionId(), res.getData().getCart().getCartHeader().getSessionId());
        Assert.assertNotNull(res.getData().getCart().getLineDetails().getPayments().get(0).getCreditCardDetails());
    }
    @Test
    public void translateCheckoutDetailsSavedCCPaymentTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        CheckoutDetailsCXPRequest request = mapper.readValue(requestString, CheckoutDetailsCXPRequest.class);
        CheckoutDetailsCXPResponse response = mapper.readValue(responseString, CheckoutDetailsCXPResponse.class);

        URI url = URI.create("http://localhost/test");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        PrepayAccessoryVO prepayAccessoryVO = new PrepayAccessoryVO();
        prepayAccessoryVO.setDeviceCommerceItemId("random01");

        List<PrepayAccessoryVO> prepayAccessoryVOList = new ArrayList<>();

        //promotions
        VZWPrepayPromotion prepayPromotion = new VZWPrepayPromotion();
        List<VZWPrepayPromotion> prepayPromotionList = new ArrayList<>();
        prepayPromotionList.add(prepayPromotion);

        //AccountInfo
        AccountInfoVO accountInfoVO = new AccountInfoVO();
        accountInfoVO.setFirstName("Test");
        accountInfoVO.setLastName("user");

        //tax details
        ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();

        TaxDetailInfo taxDetailInfo = new TaxDetailInfo();
        //taxDetailInfo.setTaxDescription(key);
        //taxDetailInfo.setTaxAmount(String.valueOf(value));
        taxDetailInfoList.add(taxDetailInfo);
        HashMap<String, Double> taxDetails = new HashMap<>();
        taxDetails.putIfAbsent("random1", 22.1);

        //Address
        AddressVO addressVO = new AddressVO();
        addressVO.setAddressLine1("harrongton drive Ohio");
        addressVO.setEmailAddress("test@test.com");
        addressVO.setAltPhoneNumber("123457896");


        accountInfoVO.setAddress(addressVO);
        List<PrepayDeviceVO> prepayDeviceVOList = new ArrayList<>();
        PrepayDeviceVO prepayDeviceVO = new PrepayDeviceVO();
        prepayDeviceVO.setId("random01");
        prepayDeviceVO.setItemType("DEVICE");
        prepayDeviceVO.setCapacity("128 GB");
        prepayDeviceVO.setFullRetailListPrice(123.00);
        prepayDeviceVO.setRawTotalAmount(123.00);
        prepayDeviceVO.setImei("imei");
        prepayDeviceVO.setRequestedEsimImei("359272531292045");
        prepayDeviceVO.setSmartImeiDevice(false);
        prepayDeviceVO.setESIMEnabledDevice(false);
        prepayDeviceVO.setEsimOnlyDevice(false);
        prepayDeviceVO.setEsimCompatible(false);
        prepayDeviceVO.setNpaNxxCode("test4-XXXX");
        prepayDeviceVOList.add(0,prepayDeviceVO);

        prepayDeviceVO.setTaxDetails(taxDetails);

        VZWPrepayOrderVO pageData = new VZWPrepayOrderVO();
        pageData.setFlow("NSE");
        pageData.setSessionId("123");
        pageData.setPaymentMethod("VISA");
        pageData.setPaypalInfo("verizonbuyertest@test.com");
        pageData.setShippingMethod("Next Day by 8pm");
        pageData.setOrderNumber("93601083317");
        pageData.setDeviceList(prepayDeviceVOList);
        pageData.setAccessoryList(prepayAccessoryVOList);
        pageData.setAccountInfo(accountInfoVO);
        pageData.setPromotions(prepayPromotionList);
        VZWPrepaySavedCreditCardDetailsVO vZWPrepaySavedCreditCardDetailsVO = new VZWPrepaySavedCreditCardDetailsVO();
        vZWPrepaySavedCreditCardDetailsVO.setCreditCardNumber("4111111111111111");
        pageData.setCustomerSavedCreditCard(vZWPrepaySavedCreditCardDetailsVO);
        PrepayAccessoryVO prepayAccessoryVO1 = new PrepayAccessoryVO();
        prepayAccessoryVO1.setDeviceCommerceItemId("deviceId1");
        prepayAccessoryVO1.setSorId("123");
        prepayAccessoryVO1.setItemType("ACCESSORY");
        prepayAccessoryVO1.setFullRetailListPrice(15.00);
        prepayAccessoryVO1.setRawTotalAmount(13.00);

        PrepayAccessoryVO prepayAccessoryVO2 = new PrepayAccessoryVO();
        List<PrepayAccessoryVO> prepayAccessoryVOS = new ArrayList<>();
        pageData.setAccessoryList(prepayAccessoryVOS);

        pageData.getDeviceList().get(0).setPlanItemId("randomPlanItem");
        pageData.getDeviceList().get(0).setId("deviceId1");
        pageData.getDeviceList().get(0).setNumberShareLineItemId("S007194d00ba2177707ac8cf9fcbd4bd7{as4}_device_961754431");
        List<PrepayPlanVO> planList = new ArrayList<>();
        PrepayPlanVO planVO1 = new PrepayPlanVO();
        PrepayPlanVO planVO2 = new PrepayPlanVO();
        planVO1.setId("randomPlanItem");
        planVO1.setFeatureLineItemId("featureLineItemId");
        planList.add(planVO1);
        planList.add(planVO2);
        pageData.setPlanList(planList);
        PrepayFeatureVO prepayFeatureVO = new PrepayFeatureVO();
        prepayFeatureVO.setSorId("123");
        prepayFeatureVO.setSkuId("sku_123");
        prepayFeatureVO.setDisplayName("displayName");
        prepayFeatureVO.setDueToday(0.00);
        prepayFeatureVO.setId("123");
        prepayFeatureVO.setDescription("12345");
        prepayFeatureVO.setDescription("Sample Description");
        prepayFeatureVO.setDueMonthly(3.02);
        List<PrepayFeatureVO> prepayFeatureVOS = new ArrayList<>();
        prepayFeatureVOS.add(prepayFeatureVO);
        pageData.setFeatureList(prepayFeatureVOS);
        pageData.setBillingAddress(accountInfoVO);

        CheckoutDetailsCXPResponse res = converter.translateCheckoutDetails(pageData, getPrepaidODRequestData(), httpRequest, request);
        Assert.assertEquals(pageData.getSessionId(), res.getData().getCart().getCartHeader().getSessionId());
        Assert.assertNotNull(res.getData().getCart().getLineDetails().getPayments().get(0).getCreditCardDetails());
    }
    @Test
    public void translateCheckoutDetailsSavedCCPaymentTest2() throws IOException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        CheckoutDetailsCXPRequest request = mapper.readValue(requestString, CheckoutDetailsCXPRequest.class);
        CheckoutDetailsCXPResponse response = mapper.readValue(responseString, CheckoutDetailsCXPResponse.class);

        URI url = URI.create("http://localhost/test");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        PrepayAccessoryVO prepayAccessoryVO = new PrepayAccessoryVO();
        prepayAccessoryVO.setDeviceCommerceItemId("random01");

        List<PrepayAccessoryVO> prepayAccessoryVOList = new ArrayList<>();

        //promotions
        VZWPrepayPromotion prepayPromotion = new VZWPrepayPromotion();
        List<VZWPrepayPromotion> prepayPromotionList = new ArrayList<>();
        prepayPromotionList.add(prepayPromotion);

        //AccountInfo
        AccountInfoVO accountInfoVO = new AccountInfoVO();


        //tax details
        ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();

        TaxDetailInfo taxDetailInfo = new TaxDetailInfo();
        //taxDetailInfo.setTaxDescription(key);
        //taxDetailInfo.setTaxAmount(String.valueOf(value));
        taxDetailInfoList.add(taxDetailInfo);
        HashMap<String, Double> taxDetails = new HashMap<>();
        taxDetails.putIfAbsent("random1", 22.1);

        //Address
        AddressVO addressVO = new AddressVO();
        addressVO.setAddressLine1("harrongton drive Ohio");
        addressVO.setEmailAddress("test@test.com");
        addressVO.setAltPhoneNumber("123457896");


        accountInfoVO.setAddress(addressVO);
        List<PrepayDeviceVO> prepayDeviceVOList = new ArrayList<>();
        PrepayDeviceVO prepayDeviceVO = new PrepayDeviceVO();
        prepayDeviceVO.setId("random01");
        prepayDeviceVO.setItemType("DEVICE");
        prepayDeviceVO.setNumberShareLineItemId("S007194d00ba2177707ac8cf9fcbd4bd7{as4}_device_961754431");
        prepayDeviceVO.setCapacity("128 GB");
        prepayDeviceVO.setFullRetailListPrice(123.00);
        prepayDeviceVO.setRawTotalAmount(123.00);
        prepayDeviceVO.setImei("imei");
        prepayDeviceVO.setRequestedEsimImei("359272531292045");
        prepayDeviceVO.setSmartImeiDevice(false);
        prepayDeviceVO.setESIMEnabledDevice(false);
        prepayDeviceVO.setEsimOnlyDevice(false);
        prepayDeviceVO.setEsimCompatible(false);
        prepayDeviceVO.setNpaNxxCode("test4-XXXX");
        prepayDeviceVOList.add(0,prepayDeviceVO);

        prepayDeviceVO.setTaxDetails(taxDetails);

        VZWPrepayOrderVO pageData = new VZWPrepayOrderVO();
        pageData.setFlow("NSE");
        pageData.setSessionId("123");
        pageData.setPaymentMethod("VISA");
        pageData.setPaypalInfo("verizonbuyertest@test.com");
        pageData.setShippingMethod("Next Day by 8pm");
        pageData.setOrderNumber("93601083317");
        pageData.setDeviceList(prepayDeviceVOList);
        pageData.setAccessoryList(prepayAccessoryVOList);
        pageData.setAccountInfo(accountInfoVO);
        pageData.setPromotions(prepayPromotionList);
        VZWPrepaySavedCreditCardDetailsVO vZWPrepaySavedCreditCardDetailsVO = new VZWPrepaySavedCreditCardDetailsVO();
        vZWPrepaySavedCreditCardDetailsVO.setCreditCardNumber("4111111111111111");
        pageData.setCustomerSavedCreditCard(vZWPrepaySavedCreditCardDetailsVO);
        PrepayAccessoryVO prepayAccessoryVO1 = new PrepayAccessoryVO();
        prepayAccessoryVO1.setDeviceCommerceItemId("deviceId1");
        prepayAccessoryVO1.setSorId("123");
        prepayAccessoryVO1.setItemType("ACCESSORY");
        prepayAccessoryVO1.setFullRetailListPrice(15.00);
        prepayAccessoryVO1.setRawTotalAmount(13.00);

        PrepayAccessoryVO prepayAccessoryVO2 = new PrepayAccessoryVO();
        List<PrepayAccessoryVO> prepayAccessoryVOS = new ArrayList<>();
        pageData.setAccessoryList(prepayAccessoryVOS);

        pageData.getDeviceList().get(0).setPlanItemId("randomPlanItem");
        pageData.getDeviceList().get(0).setId("deviceId1");
        List<PrepayPlanVO> planList = new ArrayList<>();
        PrepayPlanVO planVO1 = new PrepayPlanVO();
        PrepayPlanVO planVO2 = new PrepayPlanVO();
        planVO1.setId("randomPlanItem");
        planVO1.setFeatureLineItemId("featureLineItemId");
        planList.add(planVO1);
        planList.add(planVO2);
        pageData.setPlanList(planList);
        PrepayFeatureVO prepayFeatureVO = new PrepayFeatureVO();
        prepayFeatureVO.setSorId("123");
        prepayFeatureVO.setSkuId("sku_123");
        prepayFeatureVO.setDisplayName("displayName");
        prepayFeatureVO.setDueToday(0.00);
        prepayFeatureVO.setId("123");
        prepayFeatureVO.setDescription("12345");
        prepayFeatureVO.setDescription("Sample Description");
        prepayFeatureVO.setDueMonthly(3.02);
        List<PrepayFeatureVO> prepayFeatureVOS = new ArrayList<>();
        prepayFeatureVOS.add(prepayFeatureVO);
        pageData.setFeatureList(prepayFeatureVOS);
        pageData.setBillingAddress(accountInfoVO);

        CheckoutDetailsCXPResponse res = converter.translateCheckoutDetails(pageData, getPrepaidODRequestData(), httpRequest, request);
        Assert.assertEquals(pageData.getSessionId(), res.getData().getCart().getCartHeader().getSessionId());
        Assert.assertNotNull(res.getData().getCart().getLineDetails().getPayments().get(0).getCreditCardDetails());
    }

    @Test
    public void updateShippingDetailsTest() throws IOException{

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        CheckoutDetailsCXPResponse response = mapper.readValue(responseString, CheckoutDetailsCXPResponse.class);

        response.setData(new CheckoutDetailsResponseData());
        response.getData().setCart(new Cart());
        response.getData().getCart().setLineDetails(new LineDetails());
        ArrayList<CartLineInfo> cartLineInfoList = new ArrayList<>();
        CartLineInfo cartLineInfo1 = new CartLineInfo();
        CartLineInfo cartLineInfo2 = new CartLineInfo();
        cartLineInfoList.add(cartLineInfo1);
        cartLineInfoList.add(cartLineInfo2);
        response.getData().getCart().getLineDetails().setLineInfo(cartLineInfoList);
        VZWPrepayShippingResponseVO shippingResponse = new VZWPrepayShippingResponseVO();
        ShippingOption shippingOption1 = new ShippingOption();
        ShippingOption shippingOption2 = new ShippingOption();
        List<ShippingOption> shippingOptionList = new ArrayList<>();
        shippingOptionList.add(shippingOption1);
        shippingOptionList.add(shippingOption2);
        shippingResponse.setShippingOption(shippingOptionList);

        shippingOption1.setDepletionLocationCode("depletionCode");
        shippingOption1.setShippingDescription("shippingDescription");
        shippingOption1.setShippingCost(22.01);
        shippingOption1.setEstimatedDeliveryDate("estimatedDelivaeryDate");
        shippingOption1.setName("name");
        shippingOption1.setShippingOptionId("shippingOptionId");
        shippingOption1.setShortDescription("shortDescription");
        shippingOption1.setSignatureRequired("signatureRequired");
        shippingOption1.setActive(true);
        shippingOption1.setShippingOptionId("shippingOptionId");
        shippingOption1.isOvernightShipping();
        shippingOption1.isTwoDayShipping();
        List<AvailableDeliveryWindows> availableDeliveryWindows = new ArrayList<>();
        AvailableDeliveryWindows availableDeliveryWindows1 = new AvailableDeliveryWindows();
        availableDeliveryWindows.add(availableDeliveryWindows1);
        shippingOption1.setSddAvailableWindows(availableDeliveryWindows);

        CheckoutDetailsCXPResponse methodResponse = converter.updateShippingDetails(response,shippingResponse, false);
        Assert.assertNotNull(methodResponse);
    }

    @Test
    public void updateShippingDetailsByodTest() throws IOException{

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        CheckoutDetailsCXPResponse response = mapper.readValue(responseString, CheckoutDetailsCXPResponse.class);

        response.setData(new CheckoutDetailsResponseData());
        response.getData().setCart(new Cart());
        response.getData().getCart().setLineDetails(new LineDetails());
        ArrayList<CartLineInfo> cartLineInfoList = new ArrayList<>();
        CartLineInfo cartLineInfo1 = new CartLineInfo();
        CartLineInfo cartLineInfo2 = new CartLineInfo();
        List<ItemsInfo> list=new ArrayList<>();
        ItemsInfo itemsInfo=new ItemsInfo();
        Shipping shipping=new Shipping();
        shipping.setShippingOptionId("shippingOptionId");
        shipping.setShippingCode("shippingOptionId");
        itemsInfo.setShipping(shipping);
        list.add(itemsInfo);
        ServiceInfo serviceInfo=new ServiceInfo();
        PrimaryUserInfo primaryUserInfo=new PrimaryUserInfo();
        Address address=new Address();
        address.setAddress1("address1");
        primaryUserInfo.setAddress(address);
        serviceInfo.setPrimaryUserInfo(primaryUserInfo);
        cartLineInfo1.setServiceInfo(serviceInfo);
        cartLineInfo1.setItemsInfo((ArrayList<ItemsInfo>) list);
        cartLineInfoList.add(cartLineInfo1);
        cartLineInfoList.add(cartLineInfo2);
        response.getData().getCart().getLineDetails().setLineInfo(cartLineInfoList);
        VZWPrepayShippingResponseVO shippingResponse = new VZWPrepayShippingResponseVO();
        ShippingOption shippingOptionOne = new ShippingOption();
        ShippingOption shippingOptionTwo = new ShippingOption();
        List<ShippingOption> shippingOptionsList = new ArrayList<>();
        shippingOptionsList.add(shippingOptionOne);
        shippingOptionsList.add(shippingOptionTwo);
        shippingResponse.setShippingOption(shippingOptionsList);

        shippingOptionOne.setDepletionLocationCode("depletionCode");
        shippingOptionOne.setShippingDescription("shippingDescription");
        shippingOptionOne.setShippingCost(22.01);
        shippingOptionOne.setEstimatedDeliveryDate("estimatedDelivaeryDate");
        shippingOptionOne.setName("name");
        shippingOptionOne.setShippingOptionId("shippingOptionId");
        shippingOptionOne.setShortDescription("shortDescription");
        shippingOptionOne.setSignatureRequired("signatureRequired");
        shippingOptionOne.setActive(true);
        shippingOptionOne.setShippingOptionId("shippingOptionId");
        shippingOptionOne.isOvernightShipping();
        shippingOptionOne.isTwoDayShipping();
        List<AvailableDeliveryWindows> availableDeliveryWindows = new ArrayList<>();
        AvailableDeliveryWindows availableDeliveryWindows1 = new AvailableDeliveryWindows();
        availableDeliveryWindows.add(availableDeliveryWindows1);
        shippingOptionOne.setSddAvailableWindows(availableDeliveryWindows);

        CheckoutDetailsCXPResponse methodResponse = converter.updateShippingDetails(response,shippingResponse, true);
        Assert.assertNotNull(methodResponse);
    }

    @Test
    public void getCartItemForDeviceTest() {
        PrepayDeviceVO prepayLineVO = new PrepayDeviceVO();
        prepayLineVO.setId("random01");
        prepayLineVO.setSorId("123");
        prepayLineVO.setItemType("DEVICE");
        prepayLineVO.setSkuId("sku123");
        prepayLineVO.setProductId("1234");
        prepayLineVO.setAccountMember(false);
        prepayLineVO.setAccountOwner(true);
        prepayLineVO.setListPrice(75.00);
        prepayLineVO.setFullRetailListPrice(150.00);
        prepayLineVO.setRawTotalAmount(150.00);
        prepayLineVO.setCapacity("128GB");
        prepayLineVO.setImei("imei");
        prepayLineVO.setRequestedEsimImei("359272531292045");
        prepayLineVO.setEsimCompatible(true);
        prepayLineVO.setEsimOnlyDevice(true);
        prepayLineVO.setSmartImeiDevice(true);
        prepayLineVO.setESIMEnabledDevice(true);
        prepayLineVO.setMiniImageUrl("https://ss7.verizon.com/samsung-galaxy-a2");
        VZWPrepayOrderVO vzwPrepayOrderVO = new VZWPrepayOrderVO();
        vzwPrepayOrderVO.setOrderDiscount(0.00);
        TaxDetailInfo taxInfo = new TaxDetailInfo();
        taxInfo.setTaxDescription("State tax");
        taxInfo.setTaxAmount("14.00");
        ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();
        taxDetailInfoList.add(taxInfo);
        OrderDetails orderDetailsVO = new OrderDetails();
        DiscountSummary discSummary = new DiscountSummary();
        discSummary.setTotalDiscount("10.0");
        orderDetailsVO.setCartTotalDiscounts(discSummary);
        PrepaidODRequestData prepayODData = getPrepaidODRequestData();
        CartItem cartItem = ReflectionTestUtils.invokeMethod(converter, "getCartItemForDevice", vzwPrepayOrderVO,prepayLineVO, "0123456789",orderDetailsVO,prepayODData);
        Assert.assertNotNull(cartItem);
    }
    @Test
    public void getCartItemForDeviceTest2() {
        PrepayDeviceVO prepayLineVO = new PrepayDeviceVO();
        prepayLineVO.setId("random01");
        prepayLineVO.setSorId("123");
        prepayLineVO.setItemType("DEVICE");
        prepayLineVO.setSkuId("sku123");
        prepayLineVO.setProductId("1234");
        prepayLineVO.setAccountMember(false);
        prepayLineVO.setAccountOwner(true);
        prepayLineVO.setListPrice(75.00);
        prepayLineVO.setFullRetailListPrice(150.00);
        prepayLineVO.setRawTotalAmount(150.00);
        prepayLineVO.setCapacity("128GB");
        prepayLineVO.setImei("imei");
        prepayLineVO.setRequestedEsimImei("359272531292045");
        prepayLineVO.setMiniImageUrl("https://ss7.verizon.com/samsung-galaxy-a2");
        VZWPrepayOrderVO vzwPrepayOrderVO = new VZWPrepayOrderVO();
        vzwPrepayOrderVO.setOrderDiscount(0.00);
        TaxDetailInfo taxInfo = new TaxDetailInfo();
        taxInfo.setTaxDescription("State tax");
        taxInfo.setTaxAmount("14.00");
        ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();
        taxDetailInfoList.add(taxInfo);
        OrderDetails orderDetailsVO = new OrderDetails();
        DiscountSummary discSummary = new DiscountSummary();
      //  discSummary.setTotalDiscount("10.0");
        orderDetailsVO.setCartTotalDiscounts(discSummary);
        PrepaidODRequestData prepayODData = getPrepaidODRequestData();
        CartItem cartItem = ReflectionTestUtils.invokeMethod(converter, "getCartItemForDevice", vzwPrepayOrderVO,prepayLineVO, "0123456789",orderDetailsVO,prepayODData);
        Assert.assertNotNull(cartItem);
    }

    @Test
    public void getCartItemForDeviceTest_withoutEsim() {
        PrepayDeviceVO prepayLineVO = new PrepayDeviceVO();
        prepayLineVO.setId("random01");
        prepayLineVO.setSorId("123");
        prepayLineVO.setItemType("DEVICE");
        prepayLineVO.setSkuId("sku123");
        prepayLineVO.setProductId("1234");
        prepayLineVO.setAccountMember(false);
        prepayLineVO.setAccountOwner(true);
        prepayLineVO.setListPrice(75.00);
        prepayLineVO.setFullRetailListPrice(150.00);
        prepayLineVO.setRawTotalAmount(150.00);
        prepayLineVO.setCapacity("128GB");
        prepayLineVO.setMiniImageUrl("https://ss7.verizon.com/samsung-galaxy-a2");
        VZWPrepayOrderVO vzwPrepayOrderVO = new VZWPrepayOrderVO();
        vzwPrepayOrderVO.setOrderDiscount(0.00);
        TaxDetailInfo taxInfo = new TaxDetailInfo();
        taxInfo.setTaxDescription("State tax");
        taxInfo.setTaxAmount("14.00");
        ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();
        taxDetailInfoList.add(taxInfo);
        OrderDetails orderDetailsVO = new OrderDetails();
        DiscountSummary discSummary = new DiscountSummary();
        discSummary.setTotalDiscount("10.0");
        orderDetailsVO.setCartTotalDiscounts(discSummary);
        CartItem cartItem = ReflectionTestUtils.invokeMethod(converter, "getCartItemForDevice", vzwPrepayOrderVO,prepayLineVO, "0123456789",orderDetailsVO,getPrepaidODRequestData());
        Assert.assertNotNull(cartItem);
    }

    @Test
    public void getCartItemForAccessoryTest() {
        PrepayAccessoryVO prepayAccessoryVO = new PrepayAccessoryVO();
        prepayAccessoryVO.setDeviceCommerceItemId("random01");
        VZWPrepayOrderVO vzwPrepayOrderVO = new VZWPrepayOrderVO();
        OrderDetails orderDetailsVO = new OrderDetails();
        DiscountSummary discSummary = new DiscountSummary();

        prepayAccessoryVO.setSorId("123");
        prepayAccessoryVO.setItemType("DEVICE");
        prepayAccessoryVO.setSkuId("sku123");
        prepayAccessoryVO.setProductId("1234");
        prepayAccessoryVO.setListPrice(75.00);
        prepayAccessoryVO.setFullRetailListPrice(150.00);
        prepayAccessoryVO.setRawTotalAmount(150.00);
        prepayAccessoryVO.setCapacity("128GB");
        prepayAccessoryVO.setMiniImageUrl("https://ss7.verizon.com/samsung-galaxy-a2-cover");

        vzwPrepayOrderVO.setOrderDiscount(0.00);
        TaxDetailInfo taxInfo = new TaxDetailInfo();
        taxInfo.setTaxDescription("State tax");
        taxInfo.setTaxAmount("14.00");
        ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();
        taxDetailInfoList.add(taxInfo);
        discSummary.setTotalDiscount("10.0");
        orderDetailsVO.setCartTotalDiscounts(discSummary);
        CartItem cartItem = ReflectionTestUtils.invokeMethod(converter, "getCartItemForAccessory", vzwPrepayOrderVO,prepayAccessoryVO, "0123456789",orderDetailsVO);
        Assert.assertNotNull(cartItem);
    }

    @Test
    public void getCartItemForAccessoryItemTypeInlineAccessoriesTest() {
        PrepayAccessoryVO prepayAccessoryVO = new PrepayAccessoryVO();
        prepayAccessoryVO.setDeviceCommerceItemId("random01");
        VZWPrepayOrderVO vzwPrepayOrderVO = new VZWPrepayOrderVO();
        OrderDetails orderDetailsVO = new OrderDetails();
        DiscountSummary discSummary = new DiscountSummary();

        prepayAccessoryVO.setSorId("123");
        prepayAccessoryVO.setItemType("INLINE_ACCESSORIES");
        List<TaxDetail> list=new ArrayList<>();
        TaxDetail taxDetail=new TaxDetail();
        taxDetail.setItemType("itemType");
        taxDetail.setTaxAmount(20.0);
        taxDetail.setTaxDescription("data");
        taxDetail.setTaxType("taxType");
        taxDetail.setTaxLineItemId("lineItemId");
        list.add(taxDetail);
        prepayAccessoryVO.setTaxDetails(list);
        prepayAccessoryVO.setSkuId("sku123");
        prepayAccessoryVO.setProductId("1234");
        prepayAccessoryVO.setListPrice(75.00);
        prepayAccessoryVO.setFullRetailListPrice(150.00);
        prepayAccessoryVO.setRawTotalAmount(150.00);
        prepayAccessoryVO.setCapacity("128GB");
        prepayAccessoryVO.setMiniImageUrl("https://ss7.verizon.com/samsung-galaxy-a2-cover");

        vzwPrepayOrderVO.setOrderDiscount(0.00);
        TaxDetailInfo taxInfo = new TaxDetailInfo();
        taxInfo.setTaxDescription("State tax");
        taxInfo.setTaxAmount("14.00");
        ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();
        taxDetailInfoList.add(taxInfo);
        discSummary.setTotalDiscount("10.0");
        orderDetailsVO.setCartTotalDiscounts(discSummary);
        CartItem cartItem = ReflectionTestUtils.invokeMethod(converter, "getCartItemForAccessory", vzwPrepayOrderVO,prepayAccessoryVO, "0123456789",orderDetailsVO);
        Assert.assertNotNull(cartItem);
    }

    @Test
    public void getCartItemForAccessoryRedisTest() {
        PrepaidODRequestDataAccessorySkuIds prepayODAccessoryVO = new PrepaidODRequestDataAccessorySkuIds();
        prepayODAccessoryVO.setAccessoryCommerceId("S7c07a5a1b135fd113d747068756503a9{s1}_accessory_59249822");
        prepayODAccessoryVO.setColor("Phantom Black");
        prepayODAccessoryVO.setDescription("Galaxy Buds Pro");
        prepayODAccessoryVO.setDiscountedPrice("199.99");
        prepayODAccessoryVO.setDisplayName("Galaxy Buds Pro");
        prepayODAccessoryVO.setImgUrl("https://ss7.vzw.com/is/image/VerizonWireless/samsung-buds-project-attic-galaxy-buds-pro-tbc-black-sm-r190nzkvxar-iset");
        prepayODAccessoryVO.setManufacturer("Samsung");
        prepayODAccessoryVO.setPrice("199.99");
        prepayODAccessoryVO.setSkuId("sku4200101");
        prepayODAccessoryVO.setSorId("SM-R190NZKVXAR");

        CartItem cartItem = ReflectionTestUtils.invokeMethod(converter, "getCartItemForAccessoryRedis", prepayODAccessoryVO, "newLine1");
        Assert.assertNotNull(cartItem);
    }

    @Test
    public void getCartItemForAccessoryRedisTest2() {
        PrepaidODRequestDataAccessorySkuIds prepayODAccessoryVO = new PrepaidODRequestDataAccessorySkuIds();
        prepayODAccessoryVO.setAccessoryCommerceId("S7c07a5a1b135fd113d747068756503a9{s1}_accessory_59249822");
        prepayODAccessoryVO.setColor("Phantom Black");
        prepayODAccessoryVO.setDescription("Galaxy Buds Pro");
        prepayODAccessoryVO.setDiscountedPrice("199.99");
        prepayODAccessoryVO.setDisplayName("Galaxy Buds Pro");
        prepayODAccessoryVO.setImgUrl("https://ss7.vzw.com/is/image/VerizonWireless/samsung-buds-project-attic-galaxy-buds-pro-tbc-black-sm-r190nzkvxar-iset");
        prepayODAccessoryVO.setManufacturer("Samsung");
        prepayODAccessoryVO.setPrice(null);
        prepayODAccessoryVO.setSkuId("sku4200101");
        prepayODAccessoryVO.setSorId("SM-R190NZKVXAR");

        CartItem cartItem = ReflectionTestUtils.invokeMethod(converter, "getCartItemForAccessoryRedis", prepayODAccessoryVO, "newLine1");
        Assert.assertNotNull(cartItem);
    }

    @Test
    public void getRefillCartPaymentInfoTest(){
        VZWPrepayOrderVO pageData = new VZWPrepayOrderVO();
        VZWPrepayPaymentVO vzwPrepayPaymentVO = new VZWPrepayPaymentVO();
        List<VZWPrepayRefillCardPaymentVO>  paymentGrpIdList = new ArrayList<>();
        VZWPrepayRefillCardPaymentVO vzwPrepayRefillCardPaymentVO = new VZWPrepayRefillCardPaymentVO();
        vzwPrepayRefillCardPaymentVO.setPaymentGrpId("paymentgrpIDxxxxxx");
        vzwPrepayRefillCardPaymentVO.setAmounApplied(50);
        vzwPrepayRefillCardPaymentVO.setBalance(15);
        vzwPrepayRefillCardPaymentVO.setPincard("23242343");
        paymentGrpIdList.add(vzwPrepayRefillCardPaymentVO);
        vzwPrepayPaymentVO.setRemainingDue(0);
        pageData.setAmountCredit(15);
        vzwPrepayPaymentVO.setPaymentGrpIdList(paymentGrpIdList);
        pageData.setRefillCardDetails(vzwPrepayPaymentVO);
        CartPaymentInfo cartPaymentInfo = ReflectionTestUtils.invokeMethod(converter, "getRefillCartPaymentInfo", pageData);
        Assert.assertNotNull(cartPaymentInfo);
    }
    @Test
    public void setPaymentOptionstest2() {
        PrepayAccessoryVO prepayAccessoryVO = new PrepayAccessoryVO();
        prepayAccessoryVO.setDeviceCommerceItemId("random01");
        List<PrepayAccessoryVO> prepayAccessoryVOList = new ArrayList<>();
        //promotions
        VZWPrepayPromotion prepayPromotion = new VZWPrepayPromotion();
        List<VZWPrepayPromotion> prepayPromotionList = new ArrayList<>();
        prepayPromotionList.add(prepayPromotion);
        //AccountInfo
        AccountInfoVO accountInfoVO = new AccountInfoVO();
        //tax details
        ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();
        TaxDetailInfo taxDetailInfo = new TaxDetailInfo();
        //taxDetailInfo.setTaxDescription(key);
        //taxDetailInfo.setTaxAmount(String.valueOf(value));
        taxDetailInfoList.add(taxDetailInfo);
        HashMap<String, Double> taxDetails = new HashMap<>();
        taxDetails.putIfAbsent("random1", 22.1);
        //Address
        AddressVO addressVO = new AddressVO();
        addressVO.setAddressLine1("harrongton drive Ohio");
        accountInfoVO.setAddress(addressVO);
        List<PrepayDeviceVO> prepayDeviceVOList = new ArrayList<>();
        Map<String,Object> map=new HashMap<>();
        map.put("transactionId","0a5d1ee69dee50a7cda471a0bd353ac5d5d74a4");
        map.put("emailAddress","conceptr@gmail.com");
        map.put("paymentDataType","3DSecure");
        map.put("transactionAmount","21.7");
        PrepayDeviceVO prepayDeviceVO = new PrepayDeviceVO();
        prepayDeviceVO.setId("random01");
        prepayDeviceVO.setPurchasePath("NAP");
        prepayDeviceVOList.add(0,prepayDeviceVO);
        prepayDeviceVO.setTaxDetails(taxDetails);
        VZWPrepayOrderVO pageData = new VZWPrepayOrderVO();
        pageData.setFlow("NSP");
        pageData.setSessionId("123");
        pageData.setPaymentMethod("X Y");
        pageData.setDeviceList(prepayDeviceVOList);
        pageData.setAccessoryList(prepayAccessoryVOList);
        pageData.setAccountInfo(accountInfoVO);
        pageData.setPromotions(prepayPromotionList);
        PrepayAccessoryVO prepayAccessoryVO1 = new PrepayAccessoryVO();
        prepayAccessoryVO1.setDeviceCommerceItemId("deviceId1");
        List<PrepayAccessoryVO> prepayAccessoryVOS = new ArrayList<>();
        pageData.setAccessoryList(prepayAccessoryVOS);
        pageData.getDeviceList().get(0).setPlanItemId("randomPlanItem");
        pageData.getDeviceList().get(0).setId("deviceId1");
        List<PrepayPlanVO> planList = new ArrayList<>();
        PrepayPlanVO planVO1 = new PrepayPlanVO();
        PrepayPlanVO planVO2 = new PrepayPlanVO();
        planVO1.setId("randomPlanItem");
        planVO1.setFeatureLineItemId("featureLineItemId");
        planVO1.setSorId("28401");
        planVO1.setSkuDisplayName("Sample Plan Sku");
        planVO1.setPlanSize("15GB");
        planVO1.setActualPlanPrice(50.00);
        planVO1.setDueMonthly(40.00);
        planVO1.setDiscount(10.00);
        planVO1.setAutoPaySaving(10.00);
        planList.add(planVO1);
        planList.add(planVO2);
        pageData.setPlanList(planList);
        PrepayFeatureVO prepayFeatureVO = new PrepayFeatureVO();
        prepayFeatureVO.setSorId("sorId");
        prepayFeatureVO.setSkuId("skuId");
        prepayFeatureVO.setDisplayName("displayName");
        prepayFeatureVO.setDueMonthly(3.02);
        List<PrepayFeatureVO> prepayFeatureVOS = new ArrayList<>();
        prepayFeatureVOS.add(prepayFeatureVO);
        pageData.setFeatureList(prepayFeatureVOS);
        Map<String, Object> digitalPaymentOptions = new HashMap<>();
        digitalPaymentOptions.put("paypalEnabled", true);
        digitalPaymentOptions.put("applepayEnabled", true);
        digitalPaymentOptions.put("prepaySOEApplepayEnabled",null);
        pageData.setDigitalPaymentOptions(digitalPaymentOptions);
        Payment payment = new Payment();
        payment.setOrderTotal((int)pageData.getOrderTotal());
        ReflectionTestUtils.invokeMethod(converter, "setPaymentOptions", payment, pageData);
        Assert.assertNotNull(payment.getPaymentOptions());
    }
    @Test
    public void setPaymentOptions() {
        PrepayAccessoryVO prepayAccessoryVO = new PrepayAccessoryVO();
        prepayAccessoryVO.setDeviceCommerceItemId("random01");
        List<PrepayAccessoryVO> prepayAccessoryVOList = new ArrayList<>();
        //promotions
        VZWPrepayPromotion prepayPromotion = new VZWPrepayPromotion();
        List<VZWPrepayPromotion> prepayPromotionList = new ArrayList<>();
        prepayPromotionList.add(prepayPromotion);
        //AccountInfo
        AccountInfoVO accountInfoVO = new AccountInfoVO();
        //tax details
        ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();
        TaxDetailInfo taxDetailInfo = new TaxDetailInfo();
        //taxDetailInfo.setTaxDescription(key);
        //taxDetailInfo.setTaxAmount(String.valueOf(value));
        taxDetailInfoList.add(taxDetailInfo);
        HashMap<String, Double> taxDetails = new HashMap<>();
        taxDetails.putIfAbsent("random1", 22.1);
        //Address
        AddressVO addressVO = new AddressVO();
        addressVO.setAddressLine1("harrongton drive Ohio");
        accountInfoVO.setAddress(addressVO);
        List<PrepayDeviceVO> prepayDeviceVOList = new ArrayList<>();
        Map<String,Object> map=new HashMap<>();
        map.put("transactionId","0a5d1ee69dee50a7cda471a0bd353ac5d5d74a4");
        map.put("emailAddress","conceptr@gmail.com");
        map.put("paymentDataType","3DSecure");
        map.put("transactionAmount","21.7");
        PrepayDeviceVO prepayDeviceVO = new PrepayDeviceVO();
        prepayDeviceVO.setId("random01");
        prepayDeviceVO.setPurchasePath("NAP");
        prepayDeviceVOList.add(0,prepayDeviceVO);
        prepayDeviceVO.setTaxDetails(taxDetails);
        VZWPrepayOrderVO pageData = new VZWPrepayOrderVO();
        pageData.setFlow("NSP");
        pageData.setSessionId("123");
        pageData.setPaymentMethod("X Y");
        pageData.setDeviceList(prepayDeviceVOList);
        pageData.setAccessoryList(prepayAccessoryVOList);
        pageData.setAccountInfo(accountInfoVO);
        pageData.setPromotions(prepayPromotionList);
        pageData.setApplePayInfo(map);
        PrepayAccessoryVO prepayAccessoryVO1 = new PrepayAccessoryVO();
        prepayAccessoryVO1.setDeviceCommerceItemId("deviceId1");
        List<PrepayAccessoryVO> prepayAccessoryVOS = new ArrayList<>();
        pageData.setAccessoryList(prepayAccessoryVOS);
        pageData.getDeviceList().get(0).setPlanItemId("randomPlanItem");
        pageData.getDeviceList().get(0).setId("deviceId1");
        List<PrepayPlanVO> planList = new ArrayList<>();
        PrepayPlanVO planVO1 = new PrepayPlanVO();
        PrepayPlanVO planVO2 = new PrepayPlanVO();
        planVO1.setId("randomPlanItem");
        planVO1.setFeatureLineItemId("featureLineItemId");
        planVO1.setSorId("28401");
        planVO1.setSkuDisplayName("Sample Plan Sku");
        planVO1.setPlanSize("15GB");
        planVO1.setActualPlanPrice(50.00);
        planVO1.setBundleDiscountApplied(true);
        planVO1.setDueMonthly(40.00);
        planVO1.setDiscount(10.00);
        planVO1.setAutoPaySaving(10.00);
        planVO2.setBundleDiscountApplied(false);
        planList.add(planVO1);
        planList.add(planVO2);
        pageData.setPlanList(planList);
        PrepayFeatureVO prepayFeatureVO = new PrepayFeatureVO();
        prepayFeatureVO.setSorId("sorId");
        prepayFeatureVO.setSkuId("skuId");
        prepayFeatureVO.setDisplayName("displayName");
        prepayFeatureVO.setDueMonthly(3.02);
        List<PrepayFeatureVO> prepayFeatureVOS = new ArrayList<>();
        prepayFeatureVOS.add(prepayFeatureVO);
        pageData.setFeatureList(prepayFeatureVOS);
        Map<String, Object> digitalPaymentOptions = new HashMap<>();
        digitalPaymentOptions.put("paypalEnabled", true);
        digitalPaymentOptions.put("applepayEnabled", true);
        digitalPaymentOptions.put("prepaySOEApplepayEnabled",true);
        pageData.setDigitalPaymentOptions(digitalPaymentOptions);
        Payment payment = new Payment();
        payment.setOrderTotal((int)pageData.getOrderTotal());
        ReflectionTestUtils.invokeMethod(converter, "setPaymentOptions", payment, pageData);
        Assert.assertNotNull(payment.getPaymentOptions());
    }


    @Test
    public void translateCheckoutDetailsAALBillingNullTest_descriptionNull() throws IOException{

        ReflectionTestUtils.setField(this.converter,"enablePricePlanRefresh","false");


        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

        CheckoutDetailsCXPRequest request = mapper.readValue(requestString, CheckoutDetailsCXPRequest.class);

        URI url = URI.create("http://localhost/test");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-DOTCOM","digital_ig_session","POE-4729402").build();

        PrepayAccessoryVO prepayAccessoryVO = new PrepayAccessoryVO();
        prepayAccessoryVO.setDeviceCommerceItemId("random01");

        List<PrepayAccessoryVO> prepayAccessoryVOList = new ArrayList<>();

        //promotions
        VZWPrepayPromotion prepayPromotion = new VZWPrepayPromotion();
        List<VZWPrepayPromotion> prepayPromotionList = new ArrayList<>();
        prepayPromotionList.add(prepayPromotion);

        //AccountInfo
        AccountInfoVO accountInfoVO = new AccountInfoVO();
        accountInfoVO.setFirstName("Test");
        accountInfoVO.setLastName("user");

        //tax details
        ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();

        TaxDetailInfo taxDetailInfo = new TaxDetailInfo();
        taxDetailInfoList.add(taxDetailInfo);
        HashMap<String, Double> taxDetails = new HashMap<>();
        taxDetails.putIfAbsent("random1", 22.1);

        //Address
        AddressVO addressVO = new AddressVO();
        addressVO.setAddressLine1("harrongton drive Ohio");
        addressVO.setEmailAddress("test@test.com");
        addressVO.setAltPhoneNumber("123457896");

        accountInfoVO.setAddress(addressVO);
        List<PrepayDeviceVO> prepayDeviceVOList = new ArrayList<>();
        PrepayDeviceVO prepayDeviceVO = new PrepayDeviceVO();
       // prepayDeviceVO.setId("random01");
        prepayDeviceVO.setItemType("DEVICE");
        prepayDeviceVO.setCapacity("128 GB");
        prepayDeviceVO.setFullRetailListPrice(123.00);
        prepayDeviceVO.setRawTotalAmount(123.00);
        prepayDeviceVO.setPurchasePath("NSP");
        prepayDeviceVO.setAccountOwner(true);
        prepayDeviceVO.setNumberShareLineItemId("S007194d00ba2177707ac8cf9fcbd4bd7{as4}_device_961754431");
        prepayDeviceVOList.add(0,prepayDeviceVO);

        prepayDeviceVO.setTaxDetails(taxDetails);

        VZWPrepayOrderVO pageData = new VZWPrepayOrderVO();
        pageData.setFlow("AAL");
        pageData.setSessionId("123");
        pageData.setPaymentMethod("paypal");
        pageData.setPaypalInfo("verizonbuyertest@test.com");
        pageData.setShippingMethod("Next Day by 8pm");
        pageData.setOrderNumber("93601083317");
        pageData.setDeviceList(prepayDeviceVOList);
        pageData.setAccessoryList(prepayAccessoryVOList);
        pageData.setAccountInfo(accountInfoVO);
        pageData.setPromotions(prepayPromotionList);
        pageData.setOrderDiscount(2.00);
        PrepayAccessoryVO prepayAccessoryVO1 = new PrepayAccessoryVO();
        prepayAccessoryVO1.setDeviceCommerceItemId("deviceId1");
        prepayAccessoryVO1.setSorId("123");
        prepayAccessoryVO1.setItemType("ACCESSORY");
        prepayAccessoryVO1.setFullRetailListPrice(15.00);
        prepayAccessoryVO1.setRawTotalAmount(13.00);


        PrepayAccessoryVO prepayAccessoryVO2 = new PrepayAccessoryVO();
        List<PrepayAccessoryVO> prepayAccessoryVOS = new ArrayList<>();
        pageData.setAccessoryList(prepayAccessoryVOS);

        pageData.getDeviceList().get(0).setPlanItemId("randomPlanItem");
       // pageData.getDeviceList().get(0).setId("deviceId1");
        pageData.getDeviceList().get(0).setNumberShareLineItemId("S007194d00ba2177707ac8cf9fcbd4bd7{as4}_device_961754431");
        List<PrepayPlanVO> planList = new ArrayList<>();
        PrepayPlanVO planVO1 = new PrepayPlanVO();
        PrepayPlanVO planVO2 = new PrepayPlanVO();
        planVO1.setId("randomPlanItem");
        planVO1.setSorId("28445");
        planVO1.setPlanSize("Unlimited Plus");
        planVO1.setActualPlanPrice(50.00);
        planVO1.setDiscount(40.00);
        planVO1.setAutoPaySaving(20.00);
        planVO1.setFeatureLineItemId("featureLineItemId");
        planList.add(planVO1);
        planList.add(planVO2);
        pageData.setPlanList(planList);
        PrepayFeatureVO prepayFeatureVO = new PrepayFeatureVO();
        prepayFeatureVO.setSorId("123");
        prepayFeatureVO.setSkuId("sku_123");
        prepayFeatureVO.setDisplayName("displayName");
        prepayFeatureVO.setDueToday(0.00);
        prepayFeatureVO.setId("123");
        prepayFeatureVO.setDueMonthly(3.02);


        List<PrepayFeatureVO> prepayFeatureVOS = new ArrayList<>();
        prepayFeatureVOS.add(prepayFeatureVO);
        pageData.setFeatureList(prepayFeatureVOS);
        pageData.setBillingAddress(null);
        CheckoutDetailsCXPResponse res = converter.translateCheckoutDetails(pageData, getPrepaidODRequestData(), httpRequest, request);
        Assert.assertEquals(pageData.getSessionId(), res.getData().getCart().getCartHeader().getSessionId());
        Assert.assertNotNull(res.getData().getCart().getLineDetails().getPayments().get(0).getPaypalPaymentDetails());

    }

    @Test
    public void getSessionIdTest()
    {
        URI url = URI.create("http://localhost/test");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("digital_ig_session","POE-39394U29").build();
              String sessionId = converter.getSessionId(httpRequest);
        Assert.assertNotNull(httpRequest);
    }
    @Test
    public void getSessionIdTest2()
    {
        URI url = URI.create("http://localhost/test");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        String sessionId = converter.getSessionId(httpRequest);
        Assert.assertNotNull(httpRequest);
    }

    @Test
    public void translateCheckoutDetails_smartwatch() throws IOException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";
        String redisData="{\"ecommSessionId\":\"eyJhbGciOiJIUzI1NiJ9.eyJkYXRhIjp7ImNvcnJlbGF0aW9uSWQiOiJQT1MtRC0xOGRhMzc1ZC05MWQ3LTQ2NTItOGZiMy1iMWM1MTNmYTI1N2F7YXMyfSIsIlNFU1NJT05fSUQiOiJQT1MtRC0xOGRhMzc1ZC05MWQ3LTQ2NTItOGZiMy1iMWM1MTNmYTI1N2F7YXMyfSIsInBsYXlTZXNzaW9uIjoiUE9TLUQtMThkYTM3NWQtOTFkNy00NjUyLThmYjMtYjFjNTEzZmEyNTdhe2FzMn0ifSwibmJmIjoxNzA1NDA1MzY1LCJpYXQiOjE3MDU0MDUzNjV9.vgOqaqaGoHI-2ZLAxfC3mSWvpojhxBTUv6kFUKVkFlQ\",\"curr_line\":2,\"lines\":[{\"mtn\":\"newLine2\",\"deviceId\":\"dev14240058\",\"deviceSkuId\":\"sku4120641\",\"lineItemId\":\"S007194d00ba2177707ac8cf9fcbd4bd7{as4}_device_961754431\",\"deviceSorId\":\"MGFC3LL/A\",\"completedProcessSteps\":[\"BYODLandingPage\"],\"checkoutFlag\":true,\"imageUrl\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-12-red-10132020?\",\"displayName\":\"iPhone12\",\"capacity\":\"128GB\",\"color\":\"(PRODUCT)RED\",\"manufacturer\":\"Apple\",\"description\":\"iPhone12\",\"numAssigned\":false,\"securityPinAssigned\":false,\"accountOwner\":false,\"flow\":\"NSEBYOD\",\"imei\":\"353253188163701\",\"stageCheckpointFlag\":true,\"uniqueDeviceId\":\"dev14240058_49978084\",\"smartPhone\":true,\"smartWatch\":false,\"basicPhone\":false,\"dataDevice\":false,\"connectedCar\":false,\"planUpdated\":false,\"osType\":\"IOS\",\"numberShareEligibile\":false,\"standaloneEligibile\":false,\"transferNumberEligible\":false,\"esimEnabledDevice\":false,\"esimOnly\":false,\"esimCompatibleDevice\":false},{\"mtn\":\"newLine1\",\"deviceId\":\"dev14080075\",\"deviceSkuId\":\"sku5240438\",\"deviceSorId\":\"MYYR2LL/A\",\"planSorId\":\"28443\",\"completedProcessSteps\":[\"BYODLandingPage\"],\"checkoutFlag\":true,\"imageUrl\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_SE_Nike_LTE_40mm_Silver_Aluminum_Pure_Platinum_Black_Nike_Sport_Band_1?\",\"displayName\":\"WatchSESilverAluminumCasewithPurePlatinumNikeSportBand40MM\",\"capacity\":\"\",\"color\":\"Silver\",\"manufacturer\":\"Apple\",\"description\":\"WatchSESilverAluminumCasewithPurePlatinumNikeSportBand40MM\",\"numAssigned\":false,\"securityPinAssigned\":false,\"accountOwner\":false,\"flow\":\"NSEBYOD\",\"imei\":\"352933119570873\",\"stageCheckpointFlag\":true,\"uniqueDeviceId\":\"dev14080075_31498425\",\"smartPhone\":false,\"smartWatch\":true,\"basicPhone\":false,\"dataDevice\":false,\"connectedCar\":false,\"planUpdated\":false,\"numbershareEligibleOS\":\"IOS\",\"numberShareEligibile\":true,\"standaloneEligibile\":true,\"transferNumberEligible\":true,\"esimEnabledDevice\":false,\"esimOnly\":true,\"esimCompatibleDevice\":false}],\"numberAssignedToAllLines\":false,\"totalNumAssignedLines\":0,\"accountPinAssignedtoAllLines\":false,\"zipCode\":\"93612\",\"autoPay\":false,\"accountOwner\":\"newLine1\",\"refillCardNumbers\":{},\"loggedIn\":false,\"orderConfirmation\":false,\"pcsrfToken\":\"8d89301e29157ce31ccc1598857c08ae3564a52f-1705405364983-ee4ecd2412c3309a8de3e5d6\"}";

        CheckoutDetailsCXPRequest request = mapper.readValue(requestString, CheckoutDetailsCXPRequest.class);
        CheckoutDetailsCXPResponse response = mapper.readValue(responseString, CheckoutDetailsCXPResponse.class);
        PrepaidODRequestData redisDataa=mapper.readValue(redisData,PrepaidODRequestData.class);

        URI url = URI.create("http://localhost/test");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        PrepayAccessoryVO prepayAccessoryVO = new PrepayAccessoryVO();
        prepayAccessoryVO.setDeviceCommerceItemId("random01");

        List<PrepayAccessoryVO> prepayAccessoryVOList = new ArrayList<>();

        //promotions
        VZWPrepayPromotion prepayPromotion = new VZWPrepayPromotion();
        List<VZWPrepayPromotion> prepayPromotionList = new ArrayList<>();
        prepayPromotionList.add(prepayPromotion);

        //AccountInfo
        AccountInfoVO accountInfoVO = new AccountInfoVO();
        accountInfoVO.setFirstName("Test");
        accountInfoVO.setLastName("user");

        //tax details
        ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();

        TaxDetailInfo taxDetailInfo = new TaxDetailInfo();
        //taxDetailInfo.setTaxDescription(key);
        //taxDetailInfo.setTaxAmount(String.valueOf(value));
        taxDetailInfoList.add(taxDetailInfo);
        HashMap<String, Double> taxDetails = new HashMap<>();
        taxDetails.putIfAbsent("random1", 22.1);

        //Address
        AddressVO addressVO = new AddressVO();
        addressVO.setAddressLine1("harrongton drive Ohio");
        addressVO.setEmailAddress("test@test.com");
        addressVO.setAltPhoneNumber("123457896");

        accountInfoVO.setAddress(addressVO);
        List<PrepayDeviceVO> prepayDeviceVOList = new ArrayList<>();
        PrepayDeviceVO prepayDeviceVO = new PrepayDeviceVO();
        prepayDeviceVO.setId("random01");
        prepayDeviceVO.setItemType("DEVICE");
        prepayDeviceVO.setCapacity("128 GB");
        prepayDeviceVO.setFullRetailListPrice(123.00);
        prepayDeviceVO.setRawTotalAmount(123.00);
        prepayDeviceVO.setImei("imei");
        prepayDeviceVO.setRequestedEsimImei("359272531292045");
        prepayDeviceVO.setSmartImeiDevice(false);
        prepayDeviceVO.setESIMEnabledDevice(false);
        prepayDeviceVO.setEsimOnlyDevice(false);
        prepayDeviceVO.setEsimCompatible(false);
        prepayDeviceVOList.add(0,prepayDeviceVO);

        prepayDeviceVO.setTaxDetails(taxDetails);

        VZWPrepayOrderVO pageData = new VZWPrepayOrderVO();
        pageData.setFlow("PUP");
        pageData.setSessionId("123");
        pageData.setPaymentMethod("VISA");
        pageData.setPaypalInfo("verizonbuyertest@test.com");
        pageData.setShippingMethod("Next Day by 8pm");
        pageData.setOrderNumber("93601083317");
        pageData.setDeviceList(prepayDeviceVOList);
        pageData.setAccessoryList(prepayAccessoryVOList);
        pageData.setAccountInfo(accountInfoVO);
        pageData.setPromotions(prepayPromotionList);
        PrepayAccessoryVO prepayAccessoryVO1 = new PrepayAccessoryVO();
        prepayAccessoryVO1.setDeviceCommerceItemId("deviceId1");
        prepayAccessoryVO1.setSorId("123");
        prepayAccessoryVO1.setItemType("ACCESSORY");
        prepayAccessoryVO1.setFullRetailListPrice(15.00);
        prepayAccessoryVO1.setRawTotalAmount(13.00);


        PrepayAccessoryVO prepayAccessoryVO2 = new PrepayAccessoryVO();
        List<PrepayAccessoryVO> prepayAccessoryVOS = new ArrayList<>();
        pageData.setAccessoryList(prepayAccessoryVOS);

        pageData.getDeviceList().get(0).setPlanItemId("randomPlanItem");
        pageData.getDeviceList().get(0).setId("deviceId1");
        pageData.getDeviceList().get(0).setNumberShareLineItemId("S007194d00ba2177707ac8cf9fcbd4bd7{as4}_device_961754431");
        List<PrepayPlanVO> planList = new ArrayList<>();
        PrepayPlanVO planVO1 = new PrepayPlanVO();
        PrepayPlanVO planVO2 = new PrepayPlanVO();
        planVO1.setId("randomPlanItem");
        planVO1.setSorId("28443");
        planVO1.setFeatureLineItemId("featureLineItemId");
        planList.add(planVO1);
        planList.add(planVO2);
        pageData.setPlanList(planList);
        PrepayFeatureVO prepayFeatureVO = new PrepayFeatureVO();
        prepayFeatureVO.setSorId("123");
        prepayFeatureVO.setSkuId("sku_123");
        prepayFeatureVO.setDisplayName("displayName");
        prepayFeatureVO.setDueToday(0.00);
        prepayFeatureVO.setId("123");
        prepayFeatureVO.setDescription("12345");
        prepayFeatureVO.setDescription("Sample Description");
        prepayFeatureVO.setDueMonthly(3.02);
        List<PrepayFeatureVO> prepayFeatureVOS = new ArrayList<>();
        prepayFeatureVOS.add(prepayFeatureVO);
        pageData.setFeatureList(prepayFeatureVOS);
        pageData.setBillingAddress(accountInfoVO);

        CheckoutDetailsCXPResponse res = converter.translateCheckoutDetails(pageData, redisDataa, httpRequest, request);
        Assert.assertEquals(pageData.getSessionId(), res.getData().getCart().getCartHeader().getSessionId());
        Assert.assertNotNull(res.getData().getCart().getLineDetails().getPayments().get(0).getCreditCardDetails());
    }


}
