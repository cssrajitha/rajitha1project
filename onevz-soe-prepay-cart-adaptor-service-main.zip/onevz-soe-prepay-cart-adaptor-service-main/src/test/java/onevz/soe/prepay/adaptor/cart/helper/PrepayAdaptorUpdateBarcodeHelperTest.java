package onevz.soe.prepay.adaptor.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import net.jcip.annotations.NotThreadSafe;
import onevz.soe.cart.model.common.Address;
import onevz.soe.cart.requests.UpdateBarCodePEGARequest;
import onevz.soe.cart.responses.UpdateBarCodePEGAResponse;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.common.model.PrepaidODRequestDataAccessorySkuIds;
import onevz.soe.common.model.PrepaidODRequestDataLines;
import onevz.soe.prepay.adaptor.cart.util.FileReaderUtil;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_DATA;
import static org.mockito.Mockito.when;

@WebFluxTest
@RunWith(SpringJUnit4ClassRunner.class)
@NotThreadSafe
public class PrepayAdaptorUpdateBarcodeHelperTest {

    @Autowired
    PrepayAdaptorUpdateBarcodeHelper helper;

    @MockBean
    PrepayCartRedisHelper prepayCartRedisHelper;

    @MockBean
    PrepayAdaptorWebClient prepayAdaptorWebClient;

    @Autowired
    ObjectMapper mapper;

    String requestString;
    String responseString;
    String redisDataString;
    PrepaidODRequestData redisData;
    protected ResponseEntity<String> restResponseFailed =  null;

    private PrepaidODRequestData getRedisData() throws JsonProcessingException {

        this.redisDataString="{\"ecommSessionId\":\"1kjhlkliueijrlwkjelrjwl88lijeljrlkwjel\",\"curr_line\":1,\"lines\":[{\"mtn\":\"newLine1\",\"lineItemId\":\"newLine1\",\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\",\"completedProcessSteps\":[\"GridWallPDP\"]}],\"pcsrfToken\":\"3iqjhlwekjqlwjelqkwjelqhwekuhwqijlwk\"})";
        this.redisData = this.mapper.readValue(this.redisDataString,PrepaidODRequestData.class);

        return redisData;
    }
    private PrepaidODRequestData getRedisData2() throws JsonProcessingException {

        this.redisDataString="{\"ecommSessionId\":\"1kjhlkliueijrlwkjelrjwl88lijeljrlkwjel\",\"curr_line\":1,\"lines\":[{\"mtn\":\"newLine1\",\"flow\":\"NSE\",\"lineItemId\":\"newLine1\",\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\",\"completedProcessSteps\":[\"GridWallPDP\"]}],\"pcsrfToken\":\"3iqjhlwekjqlwjelqkwjelqhwekuhwqijlwk\"})";
        this.redisData = this.mapper.readValue(this.redisDataString,PrepaidODRequestData.class);

        return redisData;
    }
    private PrepaidODRequestData getRedisData3() throws JsonProcessingException {

        this.redisDataString="{\"ecommSessionId\":\"1kjhlkliueijrlwkjelrjwl88lijeljrlkwjel\",\"curr_line\":1,\"lines\":[{\"mtn\":\"newLine1\",\"flow\":\"NSEBYOD\",\"lineItemId\":\"newLine1\",\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\",\"completedProcessSteps\":[\"GridWallPDP\"]}],\"pcsrfToken\":\"3iqjhlwekjqlwjelqkwjelqhwekuhwqijlwk\"})";
        this.redisData = this.mapper.readValue(this.redisDataString,PrepaidODRequestData.class);

        return redisData;
    }
    private PrepaidODRequestData getRedisData4() throws JsonProcessingException {

        this.redisDataString="{\"ecommSessionId\":\"1kjhlkliueijrlwkjelrjwl88lijeljrlkwjel\",\"curr_line\":1,\"lines\":[{\"mtn\":\"newLine1\",\"flow\":\"ESO\",\"lineItemId\":\"newLine1\",\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\",\"completedProcessSteps\":[\"GridWallPDP\"]}],\"pcsrfToken\":\"3iqjhlwekjqlwjelqkwjelqhwekuhwqijlwk\"})";
        this.redisData = this.mapper.readValue(this.redisDataString,PrepaidODRequestData.class);

        return redisData;
    }
    private PrepaidODRequestData getRedisData5() throws JsonProcessingException {

        this.redisDataString="{\"ecommSessionId\":\"1kjhlkliueijrlwkjelrjwl88lijeljrlkwjel\",\"curr_line\":1,\"lines\":[{\"mtn\":\"newLine1\",\"flow\":\"NSP\",\"lineItemId\":\"newLine1\",\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\",\"completedProcessSteps\":[\"GridWallPDP\"]}],\"pcsrfToken\":\"3iqjhlwekjqlwjelqkwjelqhwekuhwqijlwk\"})";
        this.redisData = this.mapper.readValue(this.redisDataString,PrepaidODRequestData.class);

        return redisData;
    }
    private PrepaidODRequestData getRedisData6() throws JsonProcessingException {

        this.redisDataString="{\"ecommSessionId\":\"1kjhlkliueijrlwkjelrjwl88lijeljrlkwjel\",\"curr_line\":1,\"lines\":[{\"mtn\":\"newLine1\",\"flow\":\"PASO\",\"lineItemId\":\"newLine1\",\"deviceId\":\"dev16720145\",\"deviceSkuId\":\"sku4750108\",\"deviceSorId\":\"MLA73LL/A\",\"completedProcessSteps\":[\"GridWallPDP\"]}],\"pcsrfToken\":\"3iqjhlwekjqlwjelqkwjelqhwekuhwqijlwk\"})";
        this.redisData = this.mapper.readValue(this.redisDataString,PrepaidODRequestData.class);

        return redisData;
    }

    @Before
    public void setup(){
        this.requestString = "{\n" +
                "  \"serviceHeader\": {\n" +
                "    \"clientId\": \"VZW-DOTCOM\",\n" +
                "    \"statusMsg\": \"PEGA generated message\",\n" +
                "    \"serviceName\": \"SalesOrderPurchase\",\n" +
                "    \"userId\": \"\",\n" +
                "    \"statusCode\": \"0\",\n" +
                "    \"sessionId\": \"\",\n" +
                "    \"correlationId\": \"soe-cart-2022.01.25.18.58.21-916.8608036659715\"\n" +
                "  },\n" +
                "  \"serviceBody\": {\n" +
                "    \"serviceRequest\": {\n" +
                "      \"context\": {\n" +
                "        \"caseId\": \"SOP-817289281-E01\",\n" +
                "        \"contextInfo\": {\n" +
                "          \"callReason\": \"SalesOrderPurchase\",\n" +
                "          \"processStep\": \"PlanSelection\",\n" +
                "          \"processAction\": \"addPlan\",\n" +
                "          \"intent\": \"Inline-CPC\"\n" +
                "        },\n" +
                "        \"customerInfo\": {\n" +
                "          \"throttleName\": \"|AccessoryInterestialProspect|\",\n" +
                "          \"bucketAllocator\": \"BAU\",\n" +
                "          \"customerType\": \"N\",\n" +
                "          \"accountNumber\": \"\",\n" +
                "          \"cartCreator\": \"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\n" +
                "          \"processingMTN\": \"newLine1\",\n" +
                "          \"registerNumber\": 0,\n" +
                "          \"mtnFlow\": \"P\",\n" +
                "          \"globalId\": \"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"\n" +
                "        },\n" +
                "        \"cartInfo\": {\n" +
                "          \"retrieveFeatureLossReferenceData\": \"Y\",\n" +
                "          \"parentMtn\": \"\",\n" +
                "          \"cartItemCount\": 0,\n" +
                "          \"cartId\": \"b83940f5-0276-407f-947f-c2a2fa819afe\",\n" +
                "          \"itemType\": \"PLAN\",\n" +
                "          \"intendType\": \"NSE\",\n" +
                "          \"action\": \"UPDATE\",\n" +
                "          \"lines\": [\n" +
                "            {\n" +
                "              \"plan\": {\n" +
                "                \"id\": \"50427\",\n" +
                "                \"isRecommendedPlan\": false\n" +
                "              },\n" +
                "              \"mtn\": \"newLine1\",\n" +
                "              \"editSim\": false,\n" +
                "              \"lineWithSkipMDN\": false,\n" +
                "              \"inWithVerizonOpted\": false,\n" +
                "              \"protectionNotRequired\": false\n" +
                "            }\n" +
                "          ],\n" +
                "          \"effectiveDate\": \"\",\n" +
                "          \"checkAutoPayDiscountEligible\": \"N\",\n" +
                "          \"discountPromoTotal\": 0,\n" +
                "          \"registerNumber\": 0,\n" +
                "          \"protectionNotRequired\": false\n" +
                "        }\n" +
                "      }\n" +
                "    }\n" +
                "  }\n" +
                "}";

       this.responseString = "{\n" +
               "  \"status\": 200,\n" +
               "  \"statusCode\":\"00\"\n" +
               "}";

        this.restResponseFailed= new ResponseEntity(this.responseString, HttpStatus.SERVICE_UNAVAILABLE);

    }

    @Test
    public void updateBarcodeTest() throws IOException {


        PrepaidODRequestData redisData = getRedisData();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        UpdateBarCodePEGARequest request = mapper.readValue(requestString, UpdateBarCodePEGARequest.class);
        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        UpdateBarCodePEGAResponse response = mapper.readValue(responseString, UpdateBarCodePEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<UpdateBarCodePEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<UpdateBarCodePEGAResponse>> responseMono = helper.updateBarcode(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void updateBarcodeTestEmptyRedis() throws IOException {

        UpdateBarCodePEGARequest request = mapper.readValue(requestString, UpdateBarCodePEGARequest.class);
        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        UpdateBarCodePEGAResponse response = mapper.readValue(responseString, UpdateBarCodePEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<UpdateBarCodePEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(""));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<UpdateBarCodePEGAResponse>> responseMono = helper.updateBarcode(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void updateBarcodeTestFail() throws IOException {


        PrepaidODRequestData redisData = getRedisData();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        UpdateBarCodePEGARequest request = mapper.readValue(requestString, UpdateBarCodePEGARequest.class);
        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        UpdateBarCodePEGAResponse response = mapper.readValue(responseString, UpdateBarCodePEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<UpdateBarCodePEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(restResponseFailed);
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<UpdateBarCodePEGAResponse>> responseMono = helper.updateBarcode(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void updateBarcodeTest2() throws IOException {


        PrepaidODRequestData redisData = getRedisData2();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        UpdateBarCodePEGARequest request = mapper.readValue(requestString, UpdateBarCodePEGARequest.class);
        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        UpdateBarCodePEGAResponse response = mapper.readValue(responseString, UpdateBarCodePEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<UpdateBarCodePEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<UpdateBarCodePEGAResponse>> responseMono = helper.updateBarcode(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void updateBarcodeTest3() throws IOException {


        PrepaidODRequestData redisData = getRedisData3();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        UpdateBarCodePEGARequest request = mapper.readValue(requestString, UpdateBarCodePEGARequest.class);
        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        UpdateBarCodePEGAResponse response = mapper.readValue(responseString, UpdateBarCodePEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<UpdateBarCodePEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<UpdateBarCodePEGAResponse>> responseMono = helper.updateBarcode(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void updateBarcodeTest4() throws IOException {


        PrepaidODRequestData redisData = getRedisData4();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        UpdateBarCodePEGARequest request = mapper.readValue(requestString, UpdateBarCodePEGARequest.class);
        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        UpdateBarCodePEGAResponse response = mapper.readValue(responseString, UpdateBarCodePEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<UpdateBarCodePEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<UpdateBarCodePEGAResponse>> responseMono = helper.updateBarcode(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void updateBarcodeTest5() throws IOException {


        PrepaidODRequestData redisData = getRedisData5();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        UpdateBarCodePEGARequest request = mapper.readValue(requestString, UpdateBarCodePEGARequest.class);
        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        UpdateBarCodePEGAResponse response = mapper.readValue(responseString, UpdateBarCodePEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<UpdateBarCodePEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(""));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<UpdateBarCodePEGAResponse>> responseMono = helper.updateBarcode(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void updateBarcodeTest6() throws IOException {


        PrepaidODRequestData redisData = getRedisData6();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        UpdateBarCodePEGARequest request = mapper.readValue(requestString, UpdateBarCodePEGARequest.class);
        //Address address = new Address();
        //request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).setAddress(address);
        UpdateBarCodePEGAResponse response = mapper.readValue(responseString, UpdateBarCodePEGAResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<UpdateBarCodePEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<UpdateBarCodePEGAResponse>> responseMono = helper.updateBarcode(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void updateBarcodeNullRedisTest() throws IOException {
        PrepaidODRequestData redisData = getRedisData();
        String mockRedisData = mapper.writeValueAsString(redisData);
        UpdateBarCodePEGARequest request = mapper.readValue(requestString, UpdateBarCodePEGARequest.class);
        URI url = URI.create("http://localhost/testurl");
        mockRedisData = mockRedisData.replace("}", "");
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<UpdateBarCodePEGAResponse>> responseMono = helper.updateBarcode(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));
    }

    @Test
    public void updateBarcodeEmptyRedisLinesTest() throws IOException {
        PrepaidODRequestData redisData = getRedisData();
        redisData.setLines(null);
        String mockRedisData = mapper.writeValueAsString(redisData);
        UpdateBarCodePEGARequest request = mapper.readValue(requestString, UpdateBarCodePEGARequest.class);
        URI url = URI.create("http://localhost/testurl");
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<UpdateBarCodePEGAResponse>> responseMono = helper.updateBarcode(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));
    }

    @Test
    public void updateBarcodeErrorRespTest() throws IOException {
        PrepaidODRequestData redisData = getRedisData();
        String mockRedisData = mapper.writeValueAsString(redisData);
        UpdateBarCodePEGARequest request = mapper.readValue(requestString, UpdateBarCodePEGARequest.class);
        URI url = URI.create("http://localhost/testurl");
        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        String tempResp = responseString.replace("}", "");
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(tempResp));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        Mono<ResponseEntity<UpdateBarCodePEGAResponse>> responseMono = helper.updateBarcode(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));
    }

}
