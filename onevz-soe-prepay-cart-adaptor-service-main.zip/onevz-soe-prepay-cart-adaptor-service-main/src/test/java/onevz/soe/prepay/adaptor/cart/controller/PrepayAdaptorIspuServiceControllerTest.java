package onevz.soe.prepay.adaptor.cart.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import junit.framework.Assert;
import onevz.soe.prepay.adaptor.cart.helper.PrepayAdaptorIspuHelper;
import onevz.soe.prepay.adaptor.cart.model.cxp.shipping.RetrieveZipcodeMktDetailsRequest;
import onevz.soe.prepay.adaptor.cart.model.cxp.shipping.RetrieveZipcodeMktDetailsResponse;
import onevz.soe.prepay.adaptor.cart.config.PrepayCartAdaptorServiceTestConfig;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.bind.WebDataBinder;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.net.URI;

import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {PrepayCartAdaptorServiceTestConfig.class})
@WebFluxTest(PrepayAdaptorIspuServiceController.class)
public class PrepayAdaptorIspuServiceControllerTest {

    @MockBean
    private PrepayAdaptorIspuHelper prepayAdaptorIspuHelper;

    @Autowired
    private PrepayAdaptorIspuServiceController cartUpdateController;


    @Autowired
    private ObjectMapper mapper;

    @Test
    public void retrieveZipcodeMktDetailsTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";
        RetrieveZipcodeMktDetailsRequest request = mapper.readValue(requestString, RetrieveZipcodeMktDetailsRequest.class);
        RetrieveZipcodeMktDetailsResponse response = mapper.readValue(responseString, RetrieveZipcodeMktDetailsResponse.class);
        URI url = URI.create("http://localhost:15112/prepaid-adaptor/ispu/retrieveZipcodeMktDetails");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<RetrieveZipcodeMktDetailsResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
        when(prepayAdaptorIspuHelper.retrieveZipcodeMktDetails(Mockito.any(), Mockito.any())).thenReturn(justResponse);
        Mono<ResponseEntity<RetrieveZipcodeMktDetailsResponse>> actual = cartUpdateController.retrieveZipcodeMktDetails(httpHeader, null, request);
        StepVerifier.create(actual).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void retrieveZipcodeMktDetailsErrorTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";
        RetrieveZipcodeMktDetailsRequest request = mapper.readValue(requestString, RetrieveZipcodeMktDetailsRequest.class);
        RetrieveZipcodeMktDetailsResponse response = mapper.readValue(responseString, RetrieveZipcodeMktDetailsResponse.class);
        URI url = URI.create("http://localhost:15112/prepaid-adaptor/ispu/retrieveZipcodeMktDetails");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<RetrieveZipcodeMktDetailsResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
        when(prepayAdaptorIspuHelper.retrieveZipcodeMktDetails(Mockito.any(), Mockito.any())).thenReturn(justResponse);
        Mono<ResponseEntity<RetrieveZipcodeMktDetailsResponse>> actual = cartUpdateController.retrieveZipcodeMktDetails(httpHeader, null, request);
        StepVerifier.create(Mono.just("Exception").map(element -> {throw new RuntimeException();})).expectError().verify();
    }

    @Test
    public void initBinderByNameTest() throws NoSuchMethodException {
        org.junit.Assert.assertNotNull(cartUpdateController.getClass().getMethod("initBinderByName", WebDataBinder.class).getName());
        cartUpdateController.initBinderByName(new WebDataBinder(null));
    }
}

