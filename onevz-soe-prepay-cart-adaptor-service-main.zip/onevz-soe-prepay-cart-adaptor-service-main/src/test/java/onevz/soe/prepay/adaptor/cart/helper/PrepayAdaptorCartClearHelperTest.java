package onevz.soe.prepay.adaptor.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import net.jcip.annotations.NotThreadSafe;
import onevz.soe.cart.model.clearCart.ClearCartContext;
import onevz.soe.cart.model.clearCart.ClearCartServiceBody;
import onevz.soe.cart.model.clearCart.ClearCartServiceRequest;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.requests.ClearCartPEGARequest;
import onevz.soe.cart.responses.ClearCartPEGAResponse;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.common.model.PrepaidODRequestDataLines;
import onevz.soe.prepay.adaptor.cart.model.play.clearcart.VZWPrepayAPIClearCartPayload;
import onevz.soe.prepay.adaptor.cart.model.play.clearcart.VZWPrepayAPIClearCartResponse;
import onevz.soe.prepay.adaptor.cart.model.play.clearcart.VZWPrepayAddOrUpdateCartResponse;
import onevz.soe.wsclient.bpm.model.request.ContextInfo;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import onevz.soe.wsclient.prepay.webclient.model.PrepaidAdaptorWebClientRequest;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_DATA;
import static org.mockito.Mockito.when;

@WebFluxTest
@RunWith(SpringJUnit4ClassRunner.class)
@NotThreadSafe
public class PrepayAdaptorCartClearHelperTest {

    @Autowired
    PrepayAdaptorCartClearHelper helper;

    @MockBean
    PrepayCartRedisHelper redisHelper;

    @Autowired
    ObjectMapper mapper;

    @MockBean
    PrepayAdaptorWebClient prepayAdaptorWebClient;

    @Test
    public void clearCartTest() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";
        ClearCartPEGARequest request = this.mapper.readValue(requestString, ClearCartPEGARequest.class);
        ClearCartPEGAResponse response = this.mapper.readValue(responseString, ClearCartPEGAResponse.class);
        URI url = URI.create("http://localhost/clearCart");

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        line.setMtn("demo");
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setCheckoutFlag(true);
        lines.add(line);
        redisData.setLines(lines);

        VZWPrepayAPIClearCartResponse prepayODResponse=new VZWPrepayAPIClearCartResponse();
        VZWPrepayAPIClearCartPayload payload = new VZWPrepayAPIClearCartPayload();
        VZWPrepayAddOrUpdateCartResponse pageData = new VZWPrepayAddOrUpdateCartResponse();
        pageData.setOrderUpdated(true);
        payload.setPageData(pageData);
        prepayODResponse.setPayload(payload);

        String responseStringData= this.mapper.writeValueAsString(prepayODResponse);
        String mockRedisData = this.mapper.writeValueAsString(redisData);
        when(this.redisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(this.redisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest mockServerHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseStringData));
        when(this.prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<ClearCartPEGAResponse>> actual = this.helper.clearCart(mockServerHttpRequest, request);
        actual.subscribe(value -> {
                },
                error -> {
                },
                () -> System.out.println("Done")
        );
        StepVerifier.create(actual).assertNext(Assert::assertNotNull);
    }

    @Test
    public void clearCartWebclientExceptionTest() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";
        ClearCartPEGARequest request = this.mapper.readValue(requestString, ClearCartPEGARequest.class);
        ClearCartPEGAResponse response = this.mapper.readValue(responseString, ClearCartPEGAResponse.class);
        URI url = URI.create("http://localhost/clearCart");

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        line.setMtn("demo");
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setCheckoutFlag(true);
        lines.add(line);
        redisData.setLines(lines);


        String responseStringData= "Value";
        String mockRedisData = this.mapper.writeValueAsString(redisData);
        when(this.redisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(this.redisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest mockServerHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseStringData));
        when(this.prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<ClearCartPEGAResponse>> actual = this.helper.clearCart(mockServerHttpRequest, request);
        actual.subscribe(value -> {
                },
                error -> {
                },
                () -> System.out.println("Done")
        );
        StepVerifier.create(actual).assertNext(Assert::assertNotNull);
    }

    @Test
    public void clearCart_CheckoutFlagFalse_Test() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";
        ClearCartPEGARequest request = this.mapper.readValue(requestString, ClearCartPEGARequest.class);
        ClearCartPEGAResponse response = this.mapper.readValue(responseString, ClearCartPEGAResponse.class);
        URI url = URI.create("http://localhost/clearCart");

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        line.setMtn("demo");
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setCheckoutFlag(false);
        lines.add(line);
        redisData.setLines(lines);

        String mockRedisData = this.mapper.writeValueAsString(redisData);
        when(this.redisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(this.redisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest mockServerHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(mockRedisData));
        when(this.prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<ClearCartPEGAResponse>> actual = this.helper.clearCart(mockServerHttpRequest, request);
        actual.subscribe(value -> {
                },
                error -> {
                },
                () -> System.out.println("Done")
        );
        StepVerifier.create(actual).assertNext(Assert::assertNotNull);
    }

    @Test
    public void clearCart_redisDataNull_Test() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";
        ClearCartPEGARequest request = this.mapper.readValue(requestString, ClearCartPEGARequest.class);
        URI url = URI.create("http://localhost/clearCart");

        PrepaidODRequestData redisData = null;

        String mockRedisData = this.mapper.writeValueAsString(redisData);
        when(this.redisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(this.redisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.empty());
        MockServerHttpRequest mockServerHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(mockRedisData));
        when(this.prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<ClearCartPEGAResponse>> actual = this.helper.clearCart(mockServerHttpRequest, request);
        actual.subscribe(value -> {
                },
                error -> {
                },
                () -> System.out.println("Done")
        );
        StepVerifier.create(actual).assertNext(Assert::assertNotNull);
    }

    @Test
    public void clearCart_redisDataException_Test() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";
        ClearCartPEGARequest request = this.mapper.readValue(requestString, ClearCartPEGARequest.class);
        URI url = URI.create("http://localhost/clearCart");

        String mockRedisData = "value";
        when(this.redisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(this.redisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest mockServerHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(mockRedisData));
        when(this.prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<ClearCartPEGAResponse>> actual = this.helper.clearCart(mockServerHttpRequest, request);
        actual.subscribe(value -> {
                },
                error -> {
                },
                () -> System.out.println("Done")
        );
        StepVerifier.create(actual).assertNext(Assert::assertNotNull);
    }

    @Test
    public void clearCartWithoutLinesTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";
        // ClearCartPEGARequest request = mapper.readValue(requestString, ClearCartPEGARequest.class);
        ClearCartPEGAResponse response = this.mapper.readValue(responseString, ClearCartPEGAResponse.class);
        URI url = URI.create("http://localhost/clearCart");
        Mono<ResponseEntity<ClearCartPEGAResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));
        ClearCartPEGARequest request= new ClearCartPEGARequest();
        ClearCartServiceBody body = new ClearCartServiceBody();
        ClearCartServiceRequest sr = new ClearCartServiceRequest();
        ClearCartContext clearCartContext = new ClearCartContext();
        clearCartContext.setContextInfo(new ContextInfo());
        clearCartContext.setCustomerInfo(new CartServiceCustomerInfo());

        sr.setContext(clearCartContext);
        body.setServiceRequest(sr);

        request.setServiceBody(body);

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        line.setMtn("demo");
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        lines.add(line);
        //redisData.setLines(lines);

        String mockRedisData = this.mapper.writeValueAsString(redisData);
        when(this.redisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(mockRedisData));
        when(this.prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<ClearCartPEGAResponse>> actual = this.helper.clearCart(httpHeader, request);
        actual.subscribe(value -> {
                },
                error -> {
                },
                () -> System.out.println("Done")
        );
        StepVerifier.create(actual).assertNext(Assert::assertNotNull);
    }

    @Test
    public void convertToPEGAResponseTest() throws IOException {

        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";
        ClearCartPEGARequest request= new ClearCartPEGARequest();
        ClearCartServiceBody body = new ClearCartServiceBody();
        ClearCartServiceRequest sr = new ClearCartServiceRequest();
        ClearCartContext clearCartContext = new ClearCartContext();
        clearCartContext.setContextInfo(new ContextInfo());
        sr.setContext(clearCartContext);

        clearCartContext.setCustomerInfo(new CartServiceCustomerInfo());
        body.setServiceRequest(sr);

        request.setServiceBody(body);
        ClearCartPEGAResponse response = this.mapper.readValue(responseString, ClearCartPEGAResponse.class);
        VZWPrepayAPIClearCartResponse prepayODResponse=new VZWPrepayAPIClearCartResponse();
        VZWPrepayAPIClearCartPayload payload = new VZWPrepayAPIClearCartPayload();
        VZWPrepayAddOrUpdateCartResponse pageData = new VZWPrepayAddOrUpdateCartResponse();
        pageData.setOrderUpdated(true);
        payload.setPageData(pageData);
        prepayODResponse.setPayload(payload);

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        request.setServiceHeader(header);
        ClearCartPEGAResponse actual = this.helper.convertToPEGAResponse(request, prepayODResponse, redisData);
        Assert.assertNull( actual.getExceptions());
    }
    @Test
    public void convertToPEGAResponseOrderUpdatedFalseTest() throws IOException {

        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";

        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";
        ClearCartPEGARequest request= new ClearCartPEGARequest();
        ClearCartServiceBody body = new ClearCartServiceBody();
        ClearCartServiceRequest sr = new ClearCartServiceRequest();
        ClearCartContext clearCartContext = new ClearCartContext();
        clearCartContext.setContextInfo(new ContextInfo());
        sr.setContext(clearCartContext);

        clearCartContext.setCustomerInfo(new CartServiceCustomerInfo());
        body.setServiceRequest(sr);

        request.setServiceBody(body);
        ClearCartPEGAResponse response = this.mapper.readValue(responseString, ClearCartPEGAResponse.class);
        VZWPrepayAPIClearCartResponse prepayODResponse=new VZWPrepayAPIClearCartResponse();
        VZWPrepayAPIClearCartPayload payload = new VZWPrepayAPIClearCartPayload();
        VZWPrepayAddOrUpdateCartResponse pageData = new VZWPrepayAddOrUpdateCartResponse();
        pageData.setOrderUpdated(false);
        payload.setPageData(pageData);
        prepayODResponse.setPayload(payload);

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        request.setServiceHeader(header);
        ClearCartPEGAResponse actual = this.helper.convertToPEGAResponse(request, prepayODResponse, redisData);
        Assert.assertNull( actual.getExceptions());
    }

    @Test
    public void getProcessMTNListTest() throws IOException {
        ClearCartPEGARequest request= getCartPEGARequest();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        line.setMtn("demo");
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        lines.add(line);
        redisData.setLines(lines);
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()

        ProcessMTNList[] actual = this.helper.getProcessMTNList(request, redisData);
        Assert.assertTrue(actual.length>0);
    }

    @Test
    public void getProcessMTNListTest_2() throws IOException {
        ClearCartPEGARequest request= getCartPEGARequest();
        ClearCartServiceBody serviceBody=new ClearCartServiceBody();
        ClearCartServiceRequest serviceRequest=new ClearCartServiceRequest();
        ClearCartContext clearCartContext=new ClearCartContext();
        clearCartContext.setCaseId("1234");
        serviceRequest.setContext(clearCartContext);
        serviceBody.setServiceRequest(serviceRequest);
        request.setServiceBody(serviceBody);

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        line.setMtn("demo");
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        lines.add(line);
        redisData.setLines(lines);
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()

        ProcessMTNList[] actual = this.helper.getProcessMTNList(request, redisData);
        Assert.assertNull(actual);
    }
    @Test
    public void getPrepaidLegacyServiceRequestTest() throws IOException {
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        String flow = "NSE";
        PrepaidAdaptorWebClientRequest actual = this.helper.getPrepaidLegacyServiceRequest(redisData,flow);
        Assert.assertNotNull(actual.getHeader().get("Cookie"));
    }

    @Test
    public void getCustomerinfoTest() throws IOException {
        ClearCartPEGARequest request = getCartPEGARequest();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        CartServiceCustomerInfo actual = this.helper.getCustomerinfo(request);
        Assert.assertNotNull(actual);
    }

    private ClearCartPEGARequest getCartPEGARequest() {
        ClearCartPEGARequest request = new ClearCartPEGARequest();
        ClearCartServiceBody serviceBody = new ClearCartServiceBody();
        ClearCartServiceRequest serviceRequest = new ClearCartServiceRequest();
        ClearCartContext context = new ClearCartContext();
        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setAccountNumber("1");
        customerInfo.setCustomerType("c");
        customerInfo.setCartCreator("1");
        customerInfo.setProcessingMTN("demo");
        customerInfo.setRegisterNumber(1);
        customerInfo.setMtnFlow("demo");
        customerInfo.setGlobalId("demo");
        context.setCustomerInfo(customerInfo);
        ContextInfo info = new ContextInfo();
        info.setCallReason("Demo CallReason");
        context.setContextInfo(info);
        serviceRequest.setContext(context);
        serviceBody.setServiceRequest(serviceRequest);
        request.setServiceBody(serviceBody);

        return request;
    }

    @Test
    public void getContextInfoTest() throws IOException {
        ClearCartPEGARequest request = getCartPEGARequest();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        CartServiceContextInfo actual = this.helper.getContextInfo(request);
        Assert.assertEquals( "PromoHub",actual.getProcessStep());
    }

    @Test
    public void handleClearCartTest() throws JsonProcessingException {
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");

        String mockRedisData = this.mapper.writeValueAsString(redisData);
        PrepaidAdaptorWebClientRequest request=new PrepaidAdaptorWebClientRequest();
       ClearCartPEGARequest pegaRequest= getCartPEGARequest();
        CartServiceServiceHeader header= new CartServiceServiceHeader();
        pegaRequest.setServiceHeader(header);
        URI url = URI.create("http://localhost/handleClearCart");
        MockServerHttpRequest mockServerHttpRequest=MockServerHttpRequest.method(HttpMethod.POST, url).build();
       // String clearCartResponseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";
        VZWPrepayAPIClearCartResponse prepayODResponse=new VZWPrepayAPIClearCartResponse();
        VZWPrepayAPIClearCartPayload payload = new VZWPrepayAPIClearCartPayload();
        VZWPrepayAddOrUpdateCartResponse pageData = new VZWPrepayAddOrUpdateCartResponse();
        pageData.setOrderUpdated(true);
        payload.setPageData(pageData);
        prepayODResponse.setPayload(payload);
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"200\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";
        ClearCartPEGAResponse clearCartPEGAResponse = this.mapper.readValue(responseString,ClearCartPEGAResponse.class);
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseString));
        when(this.prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
       // doReturn(clearCartPEGAResponse).when(helper.convertToPEGAResponse(pegaRequest, prepayODResponse,Mockito.any()));
      //  when(helper.convertToPEGAResponse(pegaRequest, prepayODResponse,redisData)).thenReturn(clearCartPEGAResponse);
        Mono<ResponseEntity<ClearCartPEGAResponse>> handleClearCartresponse = ReflectionTestUtils.invokeMethod(this.helper,"handleClearCart",mockServerHttpRequest,request,pegaRequest,redisData);
        Assert.assertNotNull(handleClearCartresponse);
    }
    @Test
    public void handleClearCartTest2() throws JsonProcessingException {
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        String mockRedisData = this.mapper.writeValueAsString(redisData);
        PrepaidAdaptorWebClientRequest request=new PrepaidAdaptorWebClientRequest();
        ClearCartPEGARequest pegaRequest= getCartPEGARequest();
        CartServiceServiceHeader header= new CartServiceServiceHeader();
        pegaRequest.setServiceHeader(header);
        URI url = URI.create("http://localhost/handleClearCart");
        MockServerHttpRequest mockServerHttpRequest=MockServerHttpRequest.method(HttpMethod.POST, url).build();
        // String clearCartResponseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";
        VZWPrepayAPIClearCartResponse prepayODResponse=new VZWPrepayAPIClearCartResponse();
        VZWPrepayAPIClearCartPayload payload = new VZWPrepayAPIClearCartPayload();
        VZWPrepayAddOrUpdateCartResponse pageData = new VZWPrepayAddOrUpdateCartResponse();
        pageData.setOrderUpdated(true);
        payload.setPageData(pageData);
        prepayODResponse.setPayload(payload);
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"01\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";
        ClearCartPEGAResponse clearCartPEGAResponse = this.mapper.readValue(responseString,ClearCartPEGAResponse.class);
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseString));
        when(this.prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        // doReturn(clearCartPEGAResponse).when(helper.convertToPEGAResponse(pegaRequest, prepayODResponse,Mockito.any()));
        //  when(helper.convertToPEGAResponse(pegaRequest, prepayODResponse,redisData)).thenReturn(clearCartPEGAResponse);
        Mono<ResponseEntity<ClearCartPEGAResponse>> handleClearCartresponse = ReflectionTestUtils.invokeMethod(this.helper,"handleClearCart",mockServerHttpRequest,request,pegaRequest,redisData);
        Assert.assertNotNull(handleClearCartresponse);
    }
    @Test
    public void setCompletedProcessStep()
    {
        String mtn="mtn";
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        String[] processStepResponse = ReflectionTestUtils.invokeMethod(this.helper,"setCompletedProcessStep",mtn,redisData);
        Assert.assertNotNull(processStepResponse);


    }
    @Test
    public void getCartInfo()
    {
        ClearCartPEGARequest clearCartPEGARequest= new ClearCartPEGARequest();
        ClearCartServiceBody body = new ClearCartServiceBody();
        ClearCartServiceRequest sr = new ClearCartServiceRequest();
        ClearCartContext clearCartContext = new ClearCartContext();
        CartServiceCartInfo cartInfo= new CartServiceCartInfo();
        cartInfo.setCartId("1234567");
        clearCartContext.setContextInfo(new ContextInfo());
        sr.setContext(clearCartContext);
        clearCartContext.setCartInfo(cartInfo);
        clearCartContext.setCustomerInfo(new CartServiceCustomerInfo());
        body.setServiceRequest(sr);
        clearCartPEGARequest.setServiceBody(body);
        CartServiceCartInfo actual = this.helper.getCartInfo(clearCartPEGARequest);
        Assert.assertNotNull(actual);
    }
    @Test
    public void getResponseContext()
    {
        ClearCartPEGARequest clearCartPEGARequest= getCartPEGARequest();
        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
     ClearCartContext cartContext=   ReflectionTestUtils.invokeMethod(this.helper,"getResponseContext",clearCartPEGARequest,redisData);
     Assert.assertNotNull(cartContext);

    }
    @Test
    public void clearCartTest2() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";
        ClearCartPEGARequest request = this.mapper.readValue(requestString, ClearCartPEGARequest.class);
        ClearCartPEGAResponse response = this.mapper.readValue(responseString, ClearCartPEGAResponse.class);
        URI url = URI.create("http://localhost/clearCart");

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        line.setMtn("demo");
        line.setFlow("NSE");
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setCheckoutFlag(true);
        lines.add(line);
        redisData.setLines(lines);

        String mockRedisData = this.mapper.writeValueAsString(redisData);
        when(this.redisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(this.redisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest mockServerHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(mockRedisData));
        when(this.prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<ClearCartPEGAResponse>> actual = this.helper.clearCart(mockServerHttpRequest, request);
        actual.subscribe(value -> {
                },
                error -> {
                },
                () -> System.out.println("Done")
        );
        StepVerifier.create(actual).assertNext(Assert::assertNotNull);
    }
    @Test
    public void clearCartTest3() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";
        ClearCartPEGARequest request = this.mapper.readValue(requestString, ClearCartPEGARequest.class);
        ClearCartPEGAResponse response = this.mapper.readValue(responseString, ClearCartPEGAResponse.class);
        URI url = URI.create("http://localhost/clearCart");

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        line.setMtn("demo");
        line.setFlow("NSEBYOD");
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setCheckoutFlag(true);
        lines.add(line);
        redisData.setLines(lines);

        String mockRedisData = this.mapper.writeValueAsString(redisData);
        when(this.redisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(this.redisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest mockServerHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(mockRedisData));
        when(this.prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<ClearCartPEGAResponse>> actual = this.helper.clearCart(mockServerHttpRequest, request);
        actual.subscribe(value -> {
                },
                error -> {
                },
                () -> System.out.println("Done")
        );
        StepVerifier.create(actual).assertNext(Assert::assertNotNull);
    }
    @Test
    public void clearCartTest4() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";
        ClearCartPEGARequest request = this.mapper.readValue(requestString, ClearCartPEGARequest.class);
        ClearCartPEGAResponse response = this.mapper.readValue(responseString, ClearCartPEGAResponse.class);
        URI url = URI.create("http://localhost/clearCart");

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        line.setMtn("demo");
        line.setFlow("ESO");
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setCheckoutFlag(true);
        lines.add(line);
        redisData.setLines(lines);

        String mockRedisData = this.mapper.writeValueAsString(redisData);
        when(this.redisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(this.redisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest mockServerHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(mockRedisData));
        when(this.prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<ClearCartPEGAResponse>> actual = this.helper.clearCart(mockServerHttpRequest, request);
        actual.subscribe(value -> {
                },
                error -> {
                },
                () -> System.out.println("Done")
        );
        StepVerifier.create(actual).assertNext(Assert::assertNotNull);
    }
    @Test
    public void clearCartTest5() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";
        ClearCartPEGARequest request = this.mapper.readValue(requestString, ClearCartPEGARequest.class);
        ClearCartPEGAResponse response = this.mapper.readValue(responseString, ClearCartPEGAResponse.class);
        URI url = URI.create("http://localhost/clearCart");

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        line.setMtn("demo");
        line.setFlow("NSP");
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setCheckoutFlag(true);
        lines.add(line);
        redisData.setLines(lines);

        String mockRedisData = this.mapper.writeValueAsString(redisData);
        when(this.redisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(this.redisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest mockServerHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(mockRedisData));
        when(this.prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<ClearCartPEGAResponse>> actual = this.helper.clearCart(mockServerHttpRequest, request);
        actual.subscribe(value -> {
                },
                error -> {
                },
                () -> System.out.println("Done")
        );
        StepVerifier.create(actual).assertNext(Assert::assertNotNull);
    }
    @Test
    public void clearCartTest6() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";
        ClearCartPEGARequest request = this.mapper.readValue(requestString, ClearCartPEGARequest.class);
        ClearCartPEGAResponse response = this.mapper.readValue(responseString, ClearCartPEGAResponse.class);
        URI url = URI.create("http://localhost/clearCart");

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        line.setMtn("demo");
        line.setFlow("PASO");
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setCheckoutFlag(true);
        lines.add(line);
        redisData.setLines(lines);

        String mockRedisData = this.mapper.writeValueAsString(redisData);
        when(this.redisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(this.redisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest mockServerHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(mockRedisData));
        when(this.prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<ClearCartPEGAResponse>> actual = this.helper.clearCart(mockServerHttpRequest, request);
        actual.subscribe(value -> {
                },
                error -> {
                },
                () -> System.out.println("Done")
        );
        StepVerifier.create(actual).assertNext(Assert::assertNotNull);
    }

    @Test
    public void clearCartTest_500Response() throws IOException {
        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";
        ClearCartPEGARequest request = this.mapper.readValue(requestString, ClearCartPEGARequest.class);
        ClearCartPEGAResponse response = this.mapper.readValue(responseString, ClearCartPEGAResponse.class);
        URI url = URI.create("http://localhost/clearCart");

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        line.setMtn("demo");
        line.setFlow("PASO");
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setCheckoutFlag(true);
        lines.add(line);
        redisData.setLines(lines);

        String mockRedisData = this.mapper.writeValueAsString(redisData);
        when(this.redisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(this.redisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest mockServerHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(mockRedisData));
        when(this.prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);

        Mono<ResponseEntity<ClearCartPEGAResponse>> actual = this.helper.clearCart(mockServerHttpRequest, request);
        actual.subscribe(value -> {
                },
                error -> {
                },
                () -> System.out.println("Done")
        );
        StepVerifier.create(actual).assertNext(Assert::assertNotNull);
    }


    @Test
    public void getProcessMTNListNullTest() throws IOException {
        ClearCartPEGARequest request = getCartPEGARequest();
        ProcessMTNList[] ptnList = new ProcessMTNList[2];
        ProcessMTNList ptn1 = new ProcessMTNList();
        ProcessMTNList ptn2 = new ProcessMTNList();
        ptnList[0] = null;
        ptnList[1] = null;
        request.getServiceBody().getServiceRequest().getContext().setProcessMTNList(ptnList);

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        ProcessMTNList[] actual = this.helper.getProcessMTNList(request, redisData);
        Assert.assertTrue(actual.length > 0);
    }
}


