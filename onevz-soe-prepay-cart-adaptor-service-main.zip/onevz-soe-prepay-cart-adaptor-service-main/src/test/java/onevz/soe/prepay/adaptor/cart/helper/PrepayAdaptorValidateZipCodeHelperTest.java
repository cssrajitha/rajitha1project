package onevz.soe.prepay.adaptor.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.requests.AddZipcodeCXPRequest;
import onevz.soe.cart.responses.AddZipcodeCXPResponse;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.od.model.VZWValidateZipCodeResponseVO;
import onevz.soe.prepay.adaptor.cart.config.PrepayCartAdaptorServiceTestConfig;
import onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants;
import onevz.soe.prepay.adaptor.cart.util.FileReaderUtil;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.net.URI;

import static org.mockito.Mockito.when;

@WebFluxTest(PrepayAdaptorValidateZipCodeHelper.class)
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {PrepayCartAdaptorServiceTestConfig.class})
public class PrepayAdaptorValidateZipCodeHelperTest {

    @Autowired
    private PrepayAdaptorValidateZipCodeHelper validateZipCodeHelper;

    @MockBean
    PrepayCartRedisHelper prepayCartRedisHelper;

    @MockBean
    PrepayAdaptorWebClient prepayAdaptorWebClient;

    @Autowired
    ObjectMapper mapper;

    @Test
    public void validateZipCodeTest() throws JsonProcessingException {
        String addZipCodeCXPReq = FileReaderUtil.readFromFile("data/validateZipCodeCXPRequest.json");
        String responseStr = FileReaderUtil.readFromFile("data/validateZipCodeODResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/redisPrepaidODRequestData.json");
        AddZipcodeCXPRequest addZipcodeCXPRequest = mapper.readValue(addZipCodeCXPReq, AddZipcodeCXPRequest.class);
        VZWValidateZipCodeResponseVO vzwValidateZipCodeResponseVO = mapper.readValue(responseStr, VZWValidateZipCodeResponseVO.class);
        URI url = URI.create("http://localhost/prepaycartadaptor/validateZipCode");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.GET, url).build();
        when(prepayCartRedisHelper.getDataFromRedisAsString(PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(responseStr, HttpStatus.OK)));
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<AddZipcodeCXPResponse>> response = validateZipCodeHelper.validateZipCode(httpRequest, addZipcodeCXPRequest);
        StepVerifier.create(response).assertNext(resp-> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void validateZipCodeErrorTest() throws JsonProcessingException {
        String addZipCodeCXPReq = FileReaderUtil.readFromFile("data/validateZipCodeCXPRequest.json");
        String responseStr = FileReaderUtil.readFromFile("data/validateZipCodeErrODResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/redisPrepaidODRequestData.json");
        AddZipcodeCXPRequest addZipcodeCXPRequest = mapper.readValue(addZipCodeCXPReq, AddZipcodeCXPRequest.class);
        addZipcodeCXPRequest.getData().setIntendType("NSE");
        VZWValidateZipCodeResponseVO vzwValidateZipCodeResponseVO = mapper.readValue(responseStr, VZWValidateZipCodeResponseVO.class);
        URI url = URI.create("http://localhost/prepaycartadaptor/validateZipCode");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.GET, url).build();
        when(prepayCartRedisHelper.getDataFromRedisAsString(PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(responseStr, HttpStatus.OK)));
        Mono<ResponseEntity<AddZipcodeCXPResponse>> response = validateZipCodeHelper.validateZipCode(httpRequest, addZipcodeCXPRequest);
        StepVerifier.create(response).assertNext(resp->Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void validateZipCodeRedisExceptionTest() throws JsonProcessingException {
        String addZipCodeCXPReq = FileReaderUtil.readFromFile("data/validateZipCodeCXPRequest.json");
        String responseStr = FileReaderUtil.readFromFile("data/validateZipCodeErrODResponse.json");
        AddZipcodeCXPRequest addZipcodeCXPRequest = mapper.readValue(addZipCodeCXPReq, AddZipcodeCXPRequest.class);
        addZipcodeCXPRequest.getData().setIntendType("NSE");
        VZWValidateZipCodeResponseVO vzwValidateZipCodeResponseVO = mapper.readValue(responseStr, VZWValidateZipCodeResponseVO.class);
        URI url = URI.create("http://localhost/prepaycartadaptor/validateZipCode");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.GET, url).build();
        when(prepayCartRedisHelper.getDataFromRedisAsString(PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just("value"));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(responseStr, HttpStatus.OK)));
        Mono<ResponseEntity<AddZipcodeCXPResponse>> response = validateZipCodeHelper.validateZipCode(httpRequest, addZipcodeCXPRequest);
        StepVerifier.create(response).assertNext(resp->Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void validateZipCodeErrorStatusTest() throws JsonProcessingException {
        String addZipCodeCXPReq = FileReaderUtil.readFromFile("data/validateZipCodeCXPRequest.json");
        String responseStr = FileReaderUtil.readFromFile("data/validateZipCodeODResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/redisPrepaidODRequestData.json");
        AddZipcodeCXPRequest addZipcodeCXPRequest = mapper.readValue(addZipCodeCXPReq, AddZipcodeCXPRequest.class);
        VZWValidateZipCodeResponseVO vzwValidateZipCodeResponseVO = mapper.readValue(responseStr, VZWValidateZipCodeResponseVO.class);
        URI url = URI.create("http://localhost/prepaycartadaptor/validateZipCode");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.GET, url).build();
        when(prepayCartRedisHelper.getDataFromRedisAsString(PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(responseStr, HttpStatus.INTERNAL_SERVER_ERROR)));
        Mono<ResponseEntity<AddZipcodeCXPResponse>> response = validateZipCodeHelper.validateZipCode(httpRequest, addZipcodeCXPRequest);
        StepVerifier.create(response).assertNext(resp->Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void validateZipCodeExceptionTest() throws JsonProcessingException {
        String addZipCodeCXPReq = FileReaderUtil.readFromFile("data/validateZipCodeCXPRequest.json");
        String responseStr = FileReaderUtil.readFromFile("data/validateZipCodeODResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/redisPrepaidODRequestData.json");
        AddZipcodeCXPRequest addZipcodeCXPRequest = mapper.readValue(addZipCodeCXPReq, AddZipcodeCXPRequest.class);
        addZipcodeCXPRequest.setData(null);
        VZWValidateZipCodeResponseVO vzwValidateZipCodeResponseVO = mapper.readValue(responseStr, VZWValidateZipCodeResponseVO.class);
        URI url = URI.create("http://localhost/prepaycartadaptor/validateZipCode");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.GET, url).build();
        when(prepayCartRedisHelper.getDataFromRedisAsString(PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(prepaidODRequestDataString));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>("", HttpStatus.OK)));
        Mono<ResponseEntity<AddZipcodeCXPResponse>> response = validateZipCodeHelper.validateZipCode(httpRequest, addZipcodeCXPRequest);
        StepVerifier.create(response).assertNext(resp->Assert.assertNotNull(resp)).verifyComplete();
    }
   @Test
    public void updateZipCodeDataInRedis() throws JsonProcessingException {
        String addZipCodeCXPReq = FileReaderUtil.readFromFile("data/validateZipCodeCXPRequest.json");
        String responseStr = FileReaderUtil.readFromFile("data/validateZipCodeODResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/redisPrepaidODRequestData.json");
        PrepaidODRequestData redisData=mapper.readValue(prepaidODRequestDataString,PrepaidODRequestData.class);
        AddZipcodeCXPRequest addZipcodeCXPRequest = mapper.readValue(addZipCodeCXPReq, AddZipcodeCXPRequest.class);
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        Mono<?> response= ReflectionTestUtils.invokeMethod(validateZipCodeHelper,"updateZipCodeDataInRedis",addZipcodeCXPRequest,redisData,new AddZipcodeCXPResponse());
      Assert.assertNotNull(response);
    }

    @Test
    public void validateZipCodeEmptyRedisTest() throws JsonProcessingException {
        String addZipCodeCXPReq = FileReaderUtil.readFromFile("data/validateZipCodeCXPRequest.json");
        String responseStr = FileReaderUtil.readFromFile("data/validateZipCodeODResponse.json");
        String prepaidODRequestDataString = FileReaderUtil.readFromFile("data/redisPrepaidODRequestData.json");
        AddZipcodeCXPRequest addZipcodeCXPRequest = mapper.readValue(addZipCodeCXPReq, AddZipcodeCXPRequest.class);
        VZWValidateZipCodeResponseVO vzwValidateZipCodeResponseVO = mapper.readValue(responseStr, VZWValidateZipCodeResponseVO.class);
        URI url = URI.create("http://localhost/prepaycartadaptor/validateZipCode");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.GET, url).build();
        when(prepayCartRedisHelper.getDataFromRedisAsString(PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(""));
        when(prepayAdaptorWebClient.getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ResponseEntity<>(responseStr, HttpStatus.INTERNAL_SERVER_ERROR)));
        Mono<ResponseEntity<AddZipcodeCXPResponse>> response = validateZipCodeHelper.validateZipCode(httpRequest, addZipcodeCXPRequest);
        StepVerifier.create(response).assertNext(resp->Assert.assertNotNull(resp)).verifyComplete();
    }



}
