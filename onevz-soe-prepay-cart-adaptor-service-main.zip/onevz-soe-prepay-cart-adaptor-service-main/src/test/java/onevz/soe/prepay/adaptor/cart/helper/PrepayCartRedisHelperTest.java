package onevz.soe.prepay.adaptor.cart.helper;

import com.fasterxml.jackson.databind.ObjectMapper;
import net.jcip.annotations.NotThreadSafe;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.session.bean.SOELoginSessionBean;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import static org.mockito.Mockito.when;


@WebFluxTest
@RunWith(SpringJUnit4ClassRunner.class)
@NotThreadSafe
public class PrepayCartRedisHelperTest {

    @Autowired
    private ObjectMapper mapper;

    @MockBean
    SOELoginSessionBean sessionBean;

    private static Logger logger = LoggerFactory.getLogger(PrepayAdaptorNSECheckoutDetailsHelper.class);


    @Autowired
    private PrepayCartRedisHelper prepayCartRedisHelper;

    @Test
    public void upsertDataIntoRedisAsStrTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
        String str="prepay_odRequestData";
        Object request = this.mapper.readValue(requestString, Object.class);
        Mono<Boolean> responseMono = Mono.just(true);
        when(this.sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
        Mono<Boolean> actual = this.prepayCartRedisHelper.upsertDataIntoRedisAsStr(str,request);
        StepVerifier.create(actual).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void upsertDataIntoRedisTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
        String str="prepay_odRequestData";
        Object request = this.mapper.readValue(requestString, Object.class);
        Mono<Boolean> responseMono = Mono.just(true);
        when(this.sessionBean.setSessionData(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        Mono<Boolean> actual = this.prepayCartRedisHelper.upsertDataIntoRedis(str,request);
        StepVerifier.create(actual).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void getDataFromRedisAsStringTest() throws IOException {
        String str="prepay_odRequestData";
        Mono<String> responseMono = Mono.just(str);
        when(this.sessionBean.getSessionData(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        try {
            Mono<String> actual = this.prepayCartRedisHelper.getDataFromRedisAsString(str);
            logger.info("Successfully retrieved data from Redis: {}", actual);
            StepVerifier.create(actual).assertNext(Assert::assertNotNull).expectComplete();
        }
        catch (Exception e) {
            logger.error("PrepayCartRedisHelperTest.getDataFromRedisAsStringTest + #{}", e);
        }
        //StepVerifier.create(actual).expectError().verify();
    }

    @Test
    public void removeDataFromRedisTest() {
        String str="prepay_odRequestData";
        Mono<Boolean> responseMono = Mono.just(true);
        when(this.sessionBean.deleteSessionData(Mockito.any())).thenReturn(Mono.just(1L));
        try {
            Mono<Long> actual = this.prepayCartRedisHelper.removeDataFromRedis(str);
            StepVerifier.create(actual).assertNext(Assert::assertNotNull).expectComplete().verify();
        }
        catch (Exception e) {
            logger.error("PrepayCartRedisHelperTest.removeDataFromRedisTest + #{}", e);
        }
    }

}
