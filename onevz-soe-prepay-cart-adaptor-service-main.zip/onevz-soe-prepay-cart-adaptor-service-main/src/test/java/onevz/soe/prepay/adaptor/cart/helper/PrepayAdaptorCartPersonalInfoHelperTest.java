package onevz.soe.prepay.adaptor.cart.helper;

import com.fasterxml.jackson.databind.ObjectMapper;
import net.jcip.annotations.NotThreadSafe;
import onevz.soe.cart.model.common.CartServiceServiceHeader;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.common.model.PrepaidODRequestDataAccessorySkuIds;
import onevz.soe.common.model.PrepaidODRequestDataLines;
import onevz.soe.od.model.EcommApiErrorList;
import onevz.soe.od.model.Errors;
import onevz.soe.orderprocess.model.checkoutdetails.TaxDetailInfo;
import onevz.soe.orderprocess.request.CheckoutDetailsCXPRequest;
import onevz.soe.orderprocess.response.cxp.CheckoutDetailsCXPResponse;
import onevz.soe.prepay.adaptor.cart.model.cart.vo.*;
import onevz.soe.prepay.adaptor.cart.model.play.VZWPrepayOrderVO;
import onevz.soe.prepay.adaptor.cart.model.updateContactInfo.ContactInfoRequest;
import onevz.soe.prepay.adaptor.cart.model.updateContactInfo.ContactInfoResponse;
import onevz.soe.prepay.adaptor.cart.model.updateContactInfo.play.ContactInfoPrepayODResponse;
import onevz.soe.prepay.adaptor.cart.model.updateContactInfo.play.PageData;
import onevz.soe.prepay.adaptor.cart.model.updateContactInfo.play.Payload;
import onevz.soe.prepay.adaptor.cart.util.FileReaderUtil;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_DATA;
import static org.mockito.Mockito.when;

@WebFluxTest
@RunWith(SpringJUnit4ClassRunner.class)
@NotThreadSafe
public class PrepayAdaptorCartPersonalInfoHelperTest {

    @Autowired
    PrepayAdaptorCartPersonalInfoHelper helper;

    @MockBean
    PrepayCartRedisHelper prepayCartRedisHelper;

    @MockBean
    PrepayAdaptorWebClient prepayBusinessCartWebclient;

    @Autowired
    ObjectMapper mapper;

    private PrepaidODRequestData getRedisData(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setFlow("NSE");

        lines.add(line);

        //adding skuId
        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        line.setAccessorySkuIds(accessorySkuIds);

        redisData.setLines(lines);

        return redisData;
    }

    private PrepaidODRequestData getRedisData2(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setFlow("NSEBYOD");
        lines.add(line);

        //adding skuId
        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        line.setAccessorySkuIds(accessorySkuIds);

        redisData.setLines(lines);

        return redisData;
    }

    private PrepaidODRequestData getRedisData3(){

        List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

        PrepaidODRequestData redisData = new PrepaidODRequestData();
        redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
        redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
        redisData.setCurr_line(1);
        List<PrepaidODRequestDataLines> lines = new ArrayList<>();
        PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();
        final List<String> completedProcessSteps = new ArrayList<>();
        completedProcessSteps.add("Demo");
        line.setCompletedProcessSteps(completedProcessSteps);
        line.setFlow("ESO");
        lines.add(line);

        //adding skuId
        PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
        skuIds.setSkuId("skuId1");
        accessorySkuIds.add(skuIds);
        line.setAccessorySkuIds(accessorySkuIds);

        redisData.setLines(lines);

        return redisData;
    }

    @Test
    public void updatePersonalInfoTest() throws IOException{
        String requestString = "{\n" +
                "  \"serviceHeader\": {\n" +
                "    \"clientId\": \"VZW-DOTCOM\",\n" +
                "    \"statusMsg\": \"PEGA generated message\",\n" +
                "    \"serviceName\": \"SalesOrderPurchase\",\n" +
                "    \"userId\": \"\",\n" +
                "    \"statusCode\": \"0\",\n" +
                "    \"sessionId\": \"\",\n" +
                "    \"correlationId\": \"soe-cart-2022.01.25.18.58.21-916.8608036659715\"\n" +
                "  },\n" +
                "  \"serviceBody\": {\n" +
                "    \"serviceRequest\": {\n" +
                "      \"context\": {\n" +
                "        \"caseId\": \"SOP-817289281-E01\",\n" +
                "        \"contextInfo\": {\n" +
                "          \"callReason\": \"SalesOrderPurchase\",\n" +
                "          \"processStep\": \"PlanSelection\",\n" +
                "          \"processAction\": \"addPlan\",\n" +
                "          \"intent\": \"Inline-CPC\"\n" +
                "        },\n" +
                "        \"customerInfo\": {\n" +
                "          \"throttleName\": \"|AccessoryInterestialProspect|\",\n" +
                "          \"bucketAllocator\": \"BAU\",\n" +
                "          \"customerType\": \"N\",\n" +
                "          \"accountNumber\": \"\",\n" +
                "          \"cartCreator\": \"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\n" +
                "          \"processingMTN\": \"newLine1\",\n" +
                "          \"registerNumber\": 0,\n" +
                "          \"mtnFlow\": \"P\",\n" +
                "          \"globalId\": \"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"\n" +
                "        },\n" +
                "        \"cartInfo\": {\n" +
                "          \"retrieveFeatureLossReferenceData\": \"Y\",\n" +
                "          \"parentMtn\": \"\",\n" +
                "          \"cartItemCount\": 0,\n" +
                "          \"cartId\": \"b83940f5-0276-407f-947f-c2a2fa819afe\",\n" +
                "          \"itemType\": \"PLAN\",\n" +
                "          \"intendType\": \"NSE\",\n" +
                "          \"action\": \"UPDATE\",\n" +
                "          \"lines\": [\n" +
                "            {\n" +
                "              \"plan\": {\n" +
                "                \"id\": \"50427\",\n" +
                "                \"isRecommendedPlan\": false\n" +
                "              },\n" +
                "              \"address\": {\n" +
                "                \"addressLine2\": \"addr2\",\n" +
                "                \"phoneNumber\": \"8796910432\"\n" +
                "              },\n" +
                "              \"mtn\": \"newLine1\",\n" +
                "               \"firstName\": \"Test\",\n" +
                "               \"lastName\": \"Tester\",\n" +
                "               \"contactNumber\": \"8796910432\",\n" +
                "              \"editSim\": false,\n" +
                "              \"lineWithSkipMDN\": false,\n" +
                "              \"inWithVerizonOpted\": false,\n" +
                "              \"protectionNotRequired\": false\n" +
                "            }\n" +
                "          ],\n" +
                "          \"effectiveDate\": \"\",\n" +
                "          \"checkAutoPayDiscountEligible\": \"N\",\n" +
                "          \"discountPromoTotal\": 0,\n" +
                "          \"registerNumber\": 0,\n" +
                "          \"protectionNotRequired\": false\n" +
                "        }\n" +
                "      }\n" +
                "    }\n" +
                "  }\n" +
                "}";

        String responseString = FileReaderUtil.readFromFile("response/updateContactInfoPrepayOdResponse.json");

        PrepaidODRequestData redisData = getRedisData();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        ContactInfoRequest request = mapper.readValue(requestString, ContactInfoRequest.class);
        ContactInfoResponse response = mapper.readValue(responseString, ContactInfoResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<ContactInfoResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayBusinessCartWebclient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<ContactInfoResponse>> responseMono = helper.updatePersonalInfo(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void convertToPEGAResponseTest() throws IOException {

        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";
        ContactInfoRequest request = mapper.readValue(requestString, ContactInfoRequest.class);

        request.getServiceHeader().setUserId("randomId");
        request.getServiceHeader().setSessionId("randomSessionId");
        ContactInfoPrepayODResponse prepayODResponse=new ContactInfoPrepayODResponse();
        Payload payload = new Payload();
        PageData pageData = new PageData();
       // pageData.setOrderUpdated(true);

        payload.setPageData(pageData);
        prepayODResponse.setPayload(payload);
        prepayODResponse.setStatus(200);
        prepayODResponse.setStatusCode("success");

        PrepaidODRequestData redisData = getRedisData();
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        request.setServiceHeader(header);
        ContactInfoResponse actual = helper.convertToPEGAResponse(request, prepayODResponse, redisData);
        Assert.assertNull( actual.getErrors());
    }

    @Test
    public void convertToPEGAResponseTest_Watch() throws IOException {

        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";
        ContactInfoRequest request = mapper.readValue(requestString, ContactInfoRequest.class);

        request.getServiceHeader().setUserId("randomId");
        request.getServiceHeader().setSessionId("randomSessionId");
        ContactInfoPrepayODResponse prepayODResponse=new ContactInfoPrepayODResponse();
        Payload payload = new Payload();
        PageData pageData = new PageData();
        // pageData.setOrderUpdated(true);

        payload.setPageData(pageData);
        prepayODResponse.setPayload(payload);
        prepayODResponse.setStatus(200);
        prepayODResponse.setStatusCode("success");

        String redisDataa="{\"ecommSessionId\":\"eyJhbGciOiJIUzI1NiJ9.eyJkYXRhIjp7ImNvcnJlbGF0aW9uSWQiOiJQT1MtRC0xOGRhMzc1ZC05MWQ3LTQ2NTItOGZiMy1iMWM1MTNmYTI1N2F7YXMyfSIsIlNFU1NJT05fSUQiOiJQT1MtRC0xOGRhMzc1ZC05MWQ3LTQ2NTItOGZiMy1iMWM1MTNmYTI1N2F7YXMyfSIsInBsYXlTZXNzaW9uIjoiUE9TLUQtMThkYTM3NWQtOTFkNy00NjUyLThmYjMtYjFjNTEzZmEyNTdhe2FzMn0ifSwibmJmIjoxNzA1NDA1MzY1LCJpYXQiOjE3MDU0MDUzNjV9.vgOqaqaGoHI-2ZLAxfC3mSWvpojhxBTUv6kFUKVkFlQ\",\"curr_line\":2,\"lines\":[{\"mtn\":\"newLine2\",\"deviceId\":\"dev14240058\",\"deviceSkuId\":\"sku4120641\",\"deviceSorId\":\"MGFC3LL/A\",\"completedProcessSteps\":[\"BYODLandingPage\"],\"checkoutFlag\":true,\"imageUrl\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-12-red-10132020?\",\"displayName\":\"iPhone12\",\"capacity\":\"128GB\",\"color\":\"(PRODUCT)RED\",\"manufacturer\":\"Apple\",\"description\":\"iPhone12\",\"numAssigned\":false,\"securityPinAssigned\":false,\"accountOwner\":false,\"flow\":\"NSEBYOD\",\"imei\":\"353253188163701\",\"stageCheckpointFlag\":true,\"uniqueDeviceId\":\"dev14240058_49978084\",\"smartPhone\":true,\"smartWatch\":false,\"basicPhone\":false,\"dataDevice\":false,\"connectedCar\":false,\"planUpdated\":false,\"osType\":\"IOS\",\"numberShareEligibile\":false,\"standaloneEligibile\":false,\"transferNumberEligible\":false,\"esimEnabledDevice\":false,\"esimOnly\":false,\"esimCompatibleDevice\":false},{\"mtn\":\"newLine1\",\"deviceId\":\"dev14080075\",\"deviceSkuId\":\"sku5240438\",\"deviceSorId\":\"MYYR2LL/A\",\"planSorId\":\"28445\",\"completedProcessSteps\":[\"BYODLandingPage\"],\"checkoutFlag\":true,\"imageUrl\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_SE_Nike_LTE_40mm_Silver_Aluminum_Pure_Platinum_Black_Nike_Sport_Band_1?\",\"displayName\":\"WatchSESilverAluminumCasewithPurePlatinumNikeSportBand40MM\",\"capacity\":\"\",\"color\":\"Silver\",\"manufacturer\":\"Apple\",\"description\":\"WatchSESilverAluminumCasewithPurePlatinumNikeSportBand40MM\",\"numAssigned\":false,\"securityPinAssigned\":false,\"accountOwner\":false,\"flow\":\"NSEBYOD\",\"imei\":\"352933119570873\",\"stageCheckpointFlag\":true,\"uniqueDeviceId\":\"dev14080075_31498425\",\"smartPhone\":false,\"smartWatch\":true,\"trackIsNumberShareBanner\":true,\"basicPhone\":false,\"dataDevice\":false,\"connectedCar\":false,\"planUpdated\":false,\"numbershareEligibleOS\":\"IOS\",\"numberShareEligibile\":true,\"standaloneEligibile\":true,\"transferNumberEligible\":true,\"esimEnabledDevice\":false,\"esimOnly\":true,\"esimCompatibleDevice\":false}],\"numberAssignedToAllLines\":false,\"totalNumAssignedLines\":0,\"accountPinAssignedtoAllLines\":false,\"zipCode\":\"93612\",\"autoPay\":false,\"accountOwner\":\"newLine1\",\"refillCardNumbers\":{},\"loggedIn\":false,\"orderConfirmation\":false,\"pcsrfToken\":\"8d89301e29157ce31ccc1598857c08ae3564a52f-1705405364983-ee4ecd2412c3309a8de3e5d6\"}";
        PrepaidODRequestData redisData = mapper.readValue(redisDataa,PrepaidODRequestData.class);
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        request.setServiceHeader(header);
        ContactInfoResponse actual = helper.convertToPEGAResponse(request, prepayODResponse, redisData);
        Assert.assertNull( actual.getErrors());
    }



    @Test
    public void convertToPEGAResponseTest_withFailureStatus() throws IOException {

        String requestString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.01.25.18.58.21-916.8608036659715\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-817289281-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"addPlan\",\"intent\":\"Inline-CPC\"},\"customerInfo\":{\"throttleName\":\"|AccessoryInterestialProspect|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"P\",\"globalId\":\"POE-D-ebc4f7ec-2c76-47fc-b3e2-a3461db44043\"},\"cartInfo\":{\"retrieveFeatureLossReferenceData\":\"Y\",\"parentMtn\":\"\",\"cartItemCount\":0,\"cartId\":\"b83940f5-0276-407f-947f-c2a2fa819afe\",\"itemType\":\"PLAN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"lines\":[{\"plan\":{\"id\":\"50427\",\"isRecommendedPlan\":false},\"mtn\":\"newLine1\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"effectiveDate\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}";
        ContactInfoRequest request = mapper.readValue(requestString, ContactInfoRequest.class);

        request.getServiceHeader().setUserId("randomId");
        request.getServiceHeader().setSessionId("randomSessionId");
        ContactInfoPrepayODResponse prepayODResponse=new ContactInfoPrepayODResponse();
        Payload payload = new Payload();
        PageData pageData = new PageData();
        // pageData.setOrderUpdated(true);

        payload.setPageData(pageData);
        prepayODResponse.setPayload(payload);
        prepayODResponse.setStatus(500);
        prepayODResponse.setStatusCode("Internal Server Error");

        PrepaidODRequestData redisData = getRedisData();
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        request.setServiceHeader(header);
        ContactInfoResponse actual = helper.convertToPEGAResponse(request, prepayODResponse, redisData);
        Assert.assertNull( actual.getErrors());
    }

    @WebFluxTest
    @RunWith(SpringJUnit4ClassRunner.class)
    @NotThreadSafe
    public static class PrepayAdaptorCheckOutDetailsODToCXPRespConverterTest {

        @Autowired
        PrepayAdaptorCheckOutDetailsODToCXPRespConverter converter;

        @Autowired
        ObjectMapper mapper;

        private PrepaidODRequestData getPrepaidODRequestData(){

            List<PrepaidODRequestDataAccessorySkuIds> accessorySkuIds = new ArrayList<>();

            PrepaidODRequestData redisData = new PrepaidODRequestData();
            redisData.setPCsrfToken("d1843481a6b4f5a68c2f12a0f3b2a0d40b9dfd92-1647236978452-0b3a15d8c00db237fe0e222b");
            redisData.setEcommSessionId("eyJhbGciOiJIUzI1NiJ9");
            List<PrepaidODRequestDataLines> lines = new ArrayList<>();
            PrepaidODRequestDataLines line = new PrepaidODRequestDataLines();

            final List<String> completedProcessSteps = new ArrayList<>();
            completedProcessSteps.add("Demo");
            line.setCompletedProcessSteps(completedProcessSteps);
            line.setMtn("newLine1");
            line.setCheckoutFlag(true);
            lines.add(line);

            List<String> featureSkuIds = new ArrayList<>();
            featureSkuIds.add("sku3920521");
            featureSkuIds.add("feature13");
            //adding AccessoryskuId
            PrepaidODRequestDataAccessorySkuIds skuIds = new PrepaidODRequestDataAccessorySkuIds();
            skuIds.setSkuId("skuId1");
            accessorySkuIds.add(skuIds);
            line.setAccessorySkuIds(accessorySkuIds);
            line.setFeatureSkuIds(featureSkuIds);

            redisData.setLines(lines);

            return redisData;
        }

        @Test
        public void translateCheckoutDetailsTest() throws IOException{

            String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"27513\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"SMG996UZVV\",\"deviceId\":\"dev15400037\",\"deviceSkuId\":\"sku4420079\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":30,\"productId\":\"dev15400037\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}]}}";
            String responseString = "{\"serviceHeader\":{\"statusMsg\":\"Success\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.03.07.15.29.12-751.6034236849862\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ONECLICKCHECKOUT\",\"processAction\":\"\",\"intent\":\"NSE\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-6b9a6987-d02b-4aa1-b81e-c4992735263q\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false}}}},\"cartCount\":\"0\"}";

            CheckoutDetailsCXPRequest request = mapper.readValue(requestString, CheckoutDetailsCXPRequest.class);
            CheckoutDetailsCXPResponse response = mapper.readValue(responseString, CheckoutDetailsCXPResponse.class);
         //   PrepayAdaptorCheckOutDetailsODToCXPRespConverter converter = new PrepayAdaptorCheckOutDetailsODToCXPRespConverter();

            URI url = URI.create("http://localhost/test");
            Mono<ResponseEntity<String>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body("test"));
            MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();

            PrepayAccessoryVO prepayAccessoryVO = new PrepayAccessoryVO();
            prepayAccessoryVO.setDeviceCommerceItemId("random01");
            List<PrepayAccessoryVO> prepayAccessoryVOList = new ArrayList<>();

            //promotions
            VZWPrepayPromotion prepayPromotion = new VZWPrepayPromotion();
            List<VZWPrepayPromotion> prepayPromotionList = new ArrayList<>();
            prepayPromotionList.add(prepayPromotion);

            //AccountInfo
            AccountInfoVO accountInfoVO = new AccountInfoVO();

            //tax details
            ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();

            TaxDetailInfo taxDetailInfo = new TaxDetailInfo();
            //taxDetailInfo.setTaxDescription(key);
            //taxDetailInfo.setTaxAmount(String.valueOf(value));
            taxDetailInfoList.add(taxDetailInfo);
            HashMap<String, Double> taxDetails = new HashMap<>();
            taxDetails.putIfAbsent("random1", 22.1);

            //Address
            AddressVO addressVO = new AddressVO();
            addressVO.setAddressLine1("harrongton drive Ohio");
            accountInfoVO.setAddress(addressVO);
            List<PrepayDeviceVO> prepayDeviceVOList = new ArrayList<>();
            PrepayDeviceVO prepayDeviceVO = new PrepayDeviceVO();
            prepayDeviceVO.setId("random01");
            prepayDeviceVOList.add(0,prepayDeviceVO);

            prepayDeviceVO.setTaxDetails(taxDetails);


            VZWPrepayOrderVO pageData = new VZWPrepayOrderVO();
            pageData.setSessionId("123");
            pageData.setPaymentMethod("X Y");
            pageData.setDeviceList(prepayDeviceVOList);
            pageData.setAccessoryList(prepayAccessoryVOList);
            pageData.setAccountInfo(accountInfoVO);
            pageData.setPromotions(prepayPromotionList);

            pageData.getDeviceList().get(0).setPlanItemId("randomPlanItem");
            List<PrepayPlanVO> planList = new ArrayList<>();
            PrepayPlanVO planVO1 = new PrepayPlanVO();
            PrepayPlanVO planVO2 = new PrepayPlanVO();
            planVO1.setId("randomPlanItem");
            planVO1.setActualPlanPrice(22.01);
            planList.add(planVO1);
            planList.add(planVO2);
            pageData.setPlanList(planList);


            CheckoutDetailsCXPResponse res = converter.translateCheckoutDetails(pageData, getPrepaidODRequestData(), httpRequest, request);
            Assert.assertEquals(pageData.getSessionId(), res.getData().getCart().getCartHeader().getSessionId());
            Assert.assertNotNull(res.getData().getCart().getCartHeader().getSourceSystem());

        }
    }

    @Test
    public void updatePersonalInfoTest_1() throws IOException{
        String requestString = FileReaderUtil.readFromFile("request/updateContactInfoUiRequest1.json");
        String responseString = FileReaderUtil.readFromFile("response/updateContactInfoODResponse1.json");

        PrepaidODRequestData redisData = getRedisData();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        ContactInfoRequest request = mapper.readValue(requestString, ContactInfoRequest.class);
        ContactInfoResponse response = mapper.readValue(responseString, ContactInfoResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<ContactInfoResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(""));
        when(prepayBusinessCartWebclient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<ContactInfoResponse>> responseMono = helper.updatePersonalInfo(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void updatePersonalInfoTest2() throws IOException{
    	String requestString = FileReaderUtil.readFromFile("request/updateContactInfoUiRequest1.json");
        String responseString = FileReaderUtil.readFromFile("response/updateContactInfoODResponse1.json");

        PrepaidODRequestData redisData = getRedisData();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        ContactInfoRequest request = mapper.readValue(requestString, ContactInfoRequest.class);
        ContactInfoResponse response = mapper.readValue(responseString, ContactInfoResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<ContactInfoResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayBusinessCartWebclient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<ContactInfoResponse>> responseMono = helper.updatePersonalInfo(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void updatePersonalInfoTest_InternalServerError() throws IOException{
        String requestString = FileReaderUtil.readFromFile("request/updateContactInfoUiRequest1.json");
        String responseString = FileReaderUtil.readFromFile("response/updateContactInfoODResponse1.json");

        PrepaidODRequestData redisData = getRedisData2();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        ContactInfoRequest request = mapper.readValue(requestString, ContactInfoRequest.class);
        ContactInfoResponse response = mapper.readValue(responseString, ContactInfoResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<ContactInfoResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(responseString));
        when(prepayBusinessCartWebclient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<ContactInfoResponse>> responseMono = helper.updatePersonalInfo(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void updatePersonalInfoTest_Exception() throws IOException{
        String requestString = FileReaderUtil.readFromFile("request/updateContactInfoUiRequest1.json");
        String responseString = FileReaderUtil.readFromFile("response/updateContactInfoODResponse1.json");

        PrepaidODRequestData redisData = getRedisData();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        ContactInfoRequest request = mapper.readValue(requestString, ContactInfoRequest.class);
        ContactInfoResponse response = mapper.readValue(responseString, ContactInfoResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<ContactInfoResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body("value"));
        when(prepayBusinessCartWebclient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<ContactInfoResponse>> responseMono = helper.updatePersonalInfo(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }


    @Test
    public void updatePersonalInfoTest5() throws IOException{
        String requestString = FileReaderUtil.readFromFile("request/updateContactInfoUiRequest1.json");
        String responseString = FileReaderUtil.readFromFile("response/updateContactInfoODResponse1.json");

        PrepaidODRequestData redisData = getRedisData();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = "";
        ContactInfoRequest request = mapper.readValue(requestString, ContactInfoRequest.class);
        ContactInfoResponse response = mapper.readValue(responseString, ContactInfoResponse.class);
        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<ContactInfoResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(responseString));
        when(prepayBusinessCartWebclient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<ContactInfoResponse>> responseMono = helper.updatePersonalInfo(httpHeader, request);
        responseMono.subscribe(value -> {},
                error -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
    @Test
    public void updatePersonalInfoTest_withErrorResp() throws IOException{
        String requestString = FileReaderUtil.readFromFile("request/updateContactInfoUiRequest1.json");
        String responseString = FileReaderUtil.readFromFile("response/updateContactInfoODResponse1.json");

        PrepaidODRequestData redisData = getRedisData3();
        //redisData.getLines().stream().findFirst().get().getCompletedProcessSteps()
        String mockRedisData = mapper.writeValueAsString(redisData);
        ContactInfoRequest request = mapper.readValue(requestString, ContactInfoRequest.class);
        ContactInfoResponse response = mapper.readValue(responseString, ContactInfoResponse.class);

        ContactInfoPrepayODResponse contactInfoPrepayODResponse=new ContactInfoPrepayODResponse();
        List<EcommApiErrorList> list=new ArrayList<>();
        EcommApiErrorList errorList=new EcommApiErrorList();
        errorList.setDeveloperMessage("errorMessage");
        Errors errors = new Errors();
        errors.setStatus("500");
        list.add(errorList);
        errors.setEcommApiErrorList(list);
        contactInfoPrepayODResponse.setErrors(errors);
        contactInfoPrepayODResponse.setStatus(00);


        URI url = URI.create("http://localhost/testurl");
        Mono<ResponseEntity<ContactInfoResponse>> justResponse = Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just(mockRedisData));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(200).body(mapper.writeValueAsString(contactInfoPrepayODResponse)));
        when(prepayBusinessCartWebclient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<ContactInfoResponse>> responseMono = helper.updatePersonalInfo(httpHeader, request);
        responseMono.subscribe(value -> {},
                errorResp -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }

    @Test
    public void updatePersonalInfoTest_withErrorResp1() throws IOException{
        String requestString = FileReaderUtil.readFromFile("request/updateContactInfoUiRequest1.json");
        ContactInfoRequest request = mapper.readValue(requestString, ContactInfoRequest.class);

        ContactInfoPrepayODResponse contactInfoPrepayODResponse=new ContactInfoPrepayODResponse();
        List<EcommApiErrorList> list=new ArrayList<>();
        EcommApiErrorList errorList=new EcommApiErrorList();
        errorList.setDeveloperMessage("errorMessage");
        Errors errors = new Errors();
        errors.setStatus("500");
        list.add(errorList);
        errors.setEcommApiErrorList(list);
        contactInfoPrepayODResponse.setErrors(errors);
        contactInfoPrepayODResponse.setStatus(00);


        URI url = URI.create("http://localhost/testurl");

        when(prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)).thenReturn(Mono.just("value"));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();

        Mono<ResponseEntity<String>> webClientResponse = Mono.just(ResponseEntity.status(200).body(mapper.writeValueAsString(contactInfoPrepayODResponse)));
        when(prepayBusinessCartWebclient
                .getPrepayServiceResponse(Mockito.any(), Mockito.any())).thenReturn(webClientResponse);
        when(prepayCartRedisHelper.upsertDataIntoRedisAsStr(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));

        Mono<ResponseEntity<ContactInfoResponse>> responseMono = helper.updatePersonalInfo(httpHeader, request);
        responseMono.subscribe(value -> {},
                errorResp -> {},
                () -> System.out.println("Done")
        );
        StepVerifier.create(responseMono).assertNext(d -> Assert.assertNotNull(d));

    }
}
