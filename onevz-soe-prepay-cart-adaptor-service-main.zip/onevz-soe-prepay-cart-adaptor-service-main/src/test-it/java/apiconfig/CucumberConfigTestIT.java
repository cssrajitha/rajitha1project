package apiconfig;

import com.apiautomation.stepdefinitions.APIStepDefinitions;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CucumberConfigTestIT {

    @Bean
    public APIStepDefinitions apiStepDefinitions()
    {
        return new APIStepDefinitions();
    }

}
