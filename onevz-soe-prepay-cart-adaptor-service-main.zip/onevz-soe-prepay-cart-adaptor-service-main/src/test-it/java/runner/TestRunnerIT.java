package runner;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;
import com.apiautomation.utility.BaseRunner;
import com.apiautomation.utility.TestResultSummary;

@RunWith(Cucumber.class)

@CucumberOptions(features = "src/test-it/resources/features/", glue = { "stepdefinition" }, monochrome = true, plugin = {
        "pretty",
       "html:" + TestResultSummary.cucumberTestResultPath + ".html",
        "json:" + TestResultSummary.cucumberTestResultPath + ".json",
        "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:" }, dryRun = false, stepNotifications = true,
        tags = "")

public class TestRunnerIT extends BaseRunner{


}

