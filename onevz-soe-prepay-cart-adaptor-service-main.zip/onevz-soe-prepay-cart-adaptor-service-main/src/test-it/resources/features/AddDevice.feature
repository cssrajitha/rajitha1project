@addDevice
Feature: AddDevice SOE Services
  Description: Test scenarios of AddDevice SOE API services

  Background: 
    Given request builder creation for "<APIName>"
    When "SSOJWT" API is called with "SSOJWTPayload" to extract token value

  @addDeviceSuccessScenario
  Scenario Outline: AddDevice Positive Test Scenario
    And add required headers along with token header to "<APIName>" request
    And "<APIPayload>" is added to request for "<APIName>"
    When request is sent using "<HTTP_Method>" method to "<APIName>"
    Then validate response status code should be <expectedStatusCode> for "<APIName>"
    And validate "<APIName>" response for "<JSONPath>" with "<expectedValue>"

    Examples: 
      | expectedStatusCode | APIName   | HTTP_Method | APIPayload | JSONPath                                          | expectedValue         |
      |                200 | addDevice | POST        | addDevice  | serviceHeader.statusMsg,serviceHeader.serviceName | SUCCESS,SalesOrderPurchase |

  @addDeviceNegativeScenario
  Scenario Outline: AddDevice '<HTTP_Method>' '<Scenario_Name>' Negative Test Scenario
    And add required headers along with token header to "<APIName>" request without "<Header>"
    When request is sent using "<HTTP_Method>" method to "<APIName>"
    Then validate response status code should be <expectedStatusCode> for "<APIName>"
    And validate response with "<errorStatusMessage>"

    @addDeviceInvalidHttpMethod
    Examples: 
      | Scenario_Name       | expectedStatusCode | APIPayload | HTTP_Method | APIName   | errorStatusMessage |
      | Invalid Http Method |                405 | addDevice  | GET         | addDevice |                    |
