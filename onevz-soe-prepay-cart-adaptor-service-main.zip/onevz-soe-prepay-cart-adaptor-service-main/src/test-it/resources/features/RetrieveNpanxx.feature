@soeErrorCase @prepayCartAdaptorService @retrieveNpanxx
Feature: retrieveNpanxx SOE Services
  Description: Test scenarios of retrieveNpanxx SOE API services

  Background: 
    Given request builder creation for "<APIName>"
    When "SSOJWT" API is called with "SSOJWTPayload" to extract token value

  @retrieveNpanxxSuccessScenario
  Scenario Outline: retrieveNpanxx Positive Test Scenario
    And add required headers along with token header to "<APIName>" request
    And "<APIPayload>" is added to request for "<APIName>"
    When request is sent using "<HTTP_Method>" method to "<APIName>"
    Then validate response status code should be <expectedStatusCode> for "<APIName>"

    Examples: 
      | expectedStatusCode | APIName | HTTP_Method | APIPayload |
      |                200 | retrieveNpanxx  | GET        | emptyJSON      |

  @retrieveNpanxxNegativeScenario
  Scenario Outline: retrieveNpanxx '<HTTP_Method>' '<Scenario_Name>' Negative Test Scenario
    And add required headers along with token header to "<APIName>" request without "<Header>"
    When request is sent using "<HTTP_Method>" method to "<APIName>"
    Then validate response status code should be <expectedStatusCode> for "<APIName>"
    And validate response with "<errorStatusMessage>"

    @retrieveNpanxxInvalidHttpMethod
    Examples: 
      | Scenario_Name       | expectedStatusCode | APIPayload | HTTP_Method | APIName | errorStatusMessage |
      | Invalid Http Method |                405 | retrieveNpanxx      | POST         | retrieveNpanxx   |                    |

    @retrieveNpanxxCookieHeaderMissing
    Examples: 
      | Scenario_Name         | expectedStatusCode | APIPayload | Header | HTTP_Method | APIName | errorStatusMessage  |
      | Cookie Header Missing |                401 | retrieveNpanxx      | Cookie | POST        | retrieveNpanxx   | Invalid Session.Please redirect to logout page |
