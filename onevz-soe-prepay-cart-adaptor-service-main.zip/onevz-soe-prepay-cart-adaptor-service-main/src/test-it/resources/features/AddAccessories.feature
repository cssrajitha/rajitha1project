@addAccessories
Feature: addAccessories SOE Services
  Description: Test scenarios of addAccessories SOE API services

  Background:
    Given request builder creation for "<APIName>"
    When "SSOJWT" API is called with "SSOJWTPayload" to extract token value

  @addAccessoriesSuccessScenario
  Scenario Outline: addAccessories Positive Test Scenario
    And add required headers along with token header to "<APIName>" request
    And "<APIPayload>" is added to request for "<APIName>"
    When request is sent using "<HTTP_Method>" method to "<APIName>"
    Then validate response status code should be <expectedStatusCode> for "<APIName>"

    Examples:
      | expectedStatusCode | APIName                  | HTTP_Method | APIPayload               |
      | 200                | addAccessoriesPrepayCart | POST        | addAccessoriesPrepayCart |

  @addAccessoriesNegativeScenario
  Scenario Outline: addAccessories '<HTTP_Method>' '<Scenario_Name>' Negative Test Scenario
    And add required headers along with token header to "<APIName>" request without "<Header>"
    When request is sent using "<HTTP_Method>" method to "<APIName>"
    Then validate response status code should be <expectedStatusCode> for "<APIName>"
    And validate response with "<errorStatusMessage>"

    @addAccessoriesInvalidHttpMethod
    Examples:
      | Scenario_Name       | expectedStatusCode | APIPayload               | HTTP_Method | APIName                  | errorStatusMessage |
      | Invalid Http Method | 405                | addAccessoriesPrepayCart | GET         | addAccessoriesPrepayCart |                    |

