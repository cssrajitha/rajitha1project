package onevz.soe.prepay.adaptor.cart.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.prepay.adaptor.cart.exceptions.JsonValidator;
import onevz.soe.prepay.adaptor.cart.helper.*;
import onevz.soe.prepay.adaptor.cart.model.cxp.shipping.RetrieveZipcodeMktDetailsRequest;
import onevz.soe.prepay.adaptor.cart.model.cxp.shipping.RetrieveZipcodeMktDetailsResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import jakarta.validation.Valid;

/**
 * Cart Controller class.
 */
//NSADT-53978 removing CrossOrigin annotation in every service.
//@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping(value = "prepaid-adaptor")
public class PrepayAdaptorIspuServiceController {

	private static final Logger logger = LoggerFactory.getLogger(PrepayAdaptorIspuServiceController.class);

	@Autowired
	private PrepayAdaptorIspuHelper prepayAdaptorIspuHelper;

	@Autowired
	private ObjectMapper mapper;

	@Autowired
	JsonValidator validator;

	@Autowired
	private Environment env;

	/**
	 * 
	 * @param binder
	 */
	@InitBinder("*")
	public void initBinderByName(WebDataBinder binder) {
		binder.setDisallowedFields(new String[] { "genericHeader" });
	}

	/**
	 *
	 * @param httpRequest
	 * @param httpResponse
	 * @param retrieveZipcodeMktDetailsRequest
	 * @return ResponseEntity
	 *
	 */
	@PostMapping({"/ispu/retrieveZipcodeMktDetails"})
	public Mono<ResponseEntity<RetrieveZipcodeMktDetailsResponse>> retrieveZipcodeMktDetails(ServerHttpRequest httpRequest,
																							 ServerHttpResponse httpResponse, @Valid @RequestBody RetrieveZipcodeMktDetailsRequest retrieveZipcodeMktDetailsRequest) {
		System.setProperty("endPoint", "retrieveZipcodeMktDetails");
		logger.debug("retrieveZipcodeMktDetails Request: {}", retrieveZipcodeMktDetailsRequest);
		
		return prepayAdaptorIspuHelper.retrieveZipcodeMktDetails(httpRequest, retrieveZipcodeMktDetailsRequest);
	}


}
