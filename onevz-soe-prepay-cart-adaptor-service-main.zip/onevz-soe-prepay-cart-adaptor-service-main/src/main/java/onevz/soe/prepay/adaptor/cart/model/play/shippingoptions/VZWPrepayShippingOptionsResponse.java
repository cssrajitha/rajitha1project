package onevz.soe.prepay.adaptor.cart.model.play.shippingoptions;

import lombok.Data;

@Data
public class VZWPrepayShippingOptionsResponse {
    private String status;
    private VZWPrepayShippingOptionsResponsePayload payload;
}
