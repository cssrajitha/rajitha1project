package onevz.soe.prepay.adaptor.cart.model.cart.removelines;

import java.util.List;

import org.springframework.stereotype.Component;

import lombok.Data;
import onevz.soe.cart.model.common.Line;
import onevz.soe.common.model.PrepaidODRequestDataLines;

@Data
@Component
public class RemoveLinesDeriveModels {
	Line[] requestLines; 
	List<PrepaidODRequestDataLines> redisLines;
	List<PrepaidODRequestDataLines> updatedRedisDataLines;
	String linesToRemove;
	boolean errorResponse;
	String responseCode;

}
