/**
 * 
 */
package onevz.soe.prepay.adaptor.cart.model.vo;

import java.util.Objects;

/**
 *
 */
public class Paypal extends PaymentGroup {


	private static final long serialVersionUID = 1L;
	Long centinelOrderId;
	String transactionId;
	String emailAddress;
	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}
	/**
	 * @param emailAddress the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	/**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}
	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	/**
	 * @return the centinelOrderId
	 */
	public Long getCentinelOrderId() {
		return centinelOrderId;
	}
	/**
	 * @param centinelOrderId the centinelOrderId to set
	 */
	public void setCentinelOrderId(Long centinelOrderId) {
		this.centinelOrderId = centinelOrderId;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		if (!super.equals(o)) return false;
		Paypal paypal = (Paypal) o;
		return Objects.equals(centinelOrderId, paypal.centinelOrderId) && Objects.equals(transactionId, paypal.transactionId) && Objects.equals(emailAddress, paypal.emailAddress);
	}

	@Override
	public int hashCode() {
		return Objects.hash(super.hashCode(), centinelOrderId, transactionId, emailAddress);
	}
}

