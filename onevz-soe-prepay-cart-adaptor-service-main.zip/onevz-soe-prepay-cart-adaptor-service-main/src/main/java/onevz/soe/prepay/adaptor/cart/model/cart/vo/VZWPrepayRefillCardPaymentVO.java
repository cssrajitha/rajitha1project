package onevz.soe.prepay.adaptor.cart.model.cart.vo;

import java.io.Serializable;

public class VZWPrepayRefillCardPaymentVO implements Serializable {

    private static final long serialVersionUID = 1L;

    private double balance;

    private String paymentGrpId;

    private double amounApplied;

    private String pincard;

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String getPaymentGrpId() {
        return paymentGrpId;
    }

    public void setPaymentGrpId(String paymentGrpId) {
        this.paymentGrpId = paymentGrpId;
    }

    public double getAmounApplied() {
        return amounApplied;
    }

    public void setAmounApplied(double amounApplied) {
        this.amounApplied = amounApplied;
    }

    public String getPincard() {
        return pincard;
    }

    public void setPincard(String pincard) {
        this.pincard = pincard;
    }
}

