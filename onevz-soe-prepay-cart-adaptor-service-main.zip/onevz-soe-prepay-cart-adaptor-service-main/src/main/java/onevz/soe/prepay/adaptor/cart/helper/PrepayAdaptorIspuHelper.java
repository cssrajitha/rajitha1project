package onevz.soe.prepay.adaptor.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.prepay.adaptor.cart.model.cxp.shipping.RetrieveZipcodeMktDetailsRequest;
import onevz.soe.prepay.adaptor.cart.model.cxp.shipping.RetrieveZipcodeMktDetailsResponse;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import onevz.soe.wsclient.prepay.webclient.model.PrepaidAdaptorWebClientRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
public class PrepayAdaptorIspuHelper {

	@Autowired
	private ObjectMapper mapper;

	@Autowired
	private PrepayAdaptorWebClient prepayAdaptorCartWebClient;

	@Value("${ispuPrepaidLegacyServiceUrl}")
	private String ispuPrepaidLegacyServiceUrl;

	private static final Logger logger = LoggerFactory.getLogger(PrepayAdaptorIspuHelper.class);

	/**
	 * @param httpRequest
	 * @param retrieveZipcodeMktDetailsRequest
	 * @return retrieveZipcodeMktDetailsResponse
	 */
	public Mono<ResponseEntity<RetrieveZipcodeMktDetailsResponse>> retrieveZipcodeMktDetails(ServerHttpRequest httpRequest, RetrieveZipcodeMktDetailsRequest retrieveZipcodeMktDetailsRequest) {
		PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = getPrepaidLegacyServiceRequest(retrieveZipcodeMktDetailsRequest);

		return prepayAdaptorCartWebClient.getPrepayServiceResponse(httpRequest, prepaidAdaptorWebClientRequest)
				.doOnError(error->logger.error("Failed to get response, check exception for details.", error))
				.flatMap(responseEntity -> {
					RetrieveZipcodeMktDetailsResponse retrieveZipcodeMktDetailsResponse = new RetrieveZipcodeMktDetailsResponse();
					if (!responseEntity.getStatusCode().is2xxSuccessful()) {
						logger.error("Error while calling endpoint: {} with status code: {}", prepaidAdaptorWebClientRequest.getUrl(), responseEntity.getStatusCode());
					} else {
						try {
							retrieveZipcodeMktDetailsResponse = mapper.readValue(responseEntity.getBody(), RetrieveZipcodeMktDetailsResponse.class);
						} catch (JsonProcessingException e) {
							logger.error("Retrieve Zipcode Mkt details Json Processing error: {}",e.getMessage());
						}

					}
					return Mono.just(ResponseEntity.status(responseEntity.getStatusCode()).body(retrieveZipcodeMktDetailsResponse));
				});
	}

	private PrepaidAdaptorWebClientRequest getPrepaidLegacyServiceRequest(RetrieveZipcodeMktDetailsRequest retrieveZipcodeMktDetailsRequest) {
		//TODO:: Use MapStruct to do mapping

		PrepaidAdaptorWebClientRequest prepaidLegacyServiceRequest = new PrepaidAdaptorWebClientRequest();
		prepaidLegacyServiceRequest.setUrl(ispuPrepaidLegacyServiceUrl);
		prepaidLegacyServiceRequest.setRequestBody(retrieveZipcodeMktDetailsRequest);
		prepaidLegacyServiceRequest.setRequestType(HttpMethod.POST.toString());
		return prepaidLegacyServiceRequest;
	}

}
