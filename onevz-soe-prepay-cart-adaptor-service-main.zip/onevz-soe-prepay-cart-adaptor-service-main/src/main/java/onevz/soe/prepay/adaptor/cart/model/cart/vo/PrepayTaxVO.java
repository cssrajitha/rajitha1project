package onevz.soe.prepay.adaptor.cart.model.cart.vo;

import java.io.Serializable;

public class PrepayTaxVO implements Serializable {
    private static final long serialVersionUID = 1L;

    private double taxPrice;

    private String taxDetailsToDisplay;

    public double getTaxPrice() {
        return taxPrice;
    }

    public void setTaxPrice(double taxPrice) {
        this.taxPrice = taxPrice;
    }

    public String getTaxDetailsToDisplay() {
        return taxDetailsToDisplay;
    }

    public void setTaxDetailsToDisplay(String taxDetailsToDisplay) {
        this.taxDetailsToDisplay = taxDetailsToDisplay;
    }
}
