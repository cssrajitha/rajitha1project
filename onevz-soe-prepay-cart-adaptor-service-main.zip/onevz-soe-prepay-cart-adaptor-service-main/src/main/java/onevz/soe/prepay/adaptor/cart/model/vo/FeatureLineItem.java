package onevz.soe.prepay.adaptor.cart.model.vo;

import java.util.Date;

/**
 *
 */
public class FeatureLineItem extends OrderLineItem{

    
	private static final long serialVersionUID = 1L;
	private String deviceLineItemId;
    private Double featureCharge;
    private String featureType;
    private Date lastModifiedDate;
    private Double featureChargeWithAutoPay;
    private String planLineItemId;
    private boolean sddEnable;

	public boolean isSddEnable() {
		return sddEnable;
	}

	public void setSddEnable(boolean sddEnable) {
		this.sddEnable = sddEnable;
	}

	public String getPlanLineItemId() {
		return planLineItemId;
	}

	public void setPlanLineItemId(String planLineItemId) {
		this.planLineItemId = planLineItemId;
	}

	public Double getFeatureChargeWithAutoPay() {
		return featureChargeWithAutoPay;
	}

	public void setFeatureChargeWithAutoPay(Double featureChargeWithAutoPay) {
		this.featureChargeWithAutoPay = featureChargeWithAutoPay;
	}

	public String getDeviceLineItemId() {
        return deviceLineItemId;
    }

    public void setDeviceLineItemId(String deviceLineItemId) {
        this.deviceLineItemId = deviceLineItemId;
    }

	
	public Double getFeatureCharge() {
		if(featureCharge != null){
			return featureCharge;
		}else{
			return 0.0D;
		}
	}

	public void setFeatureCharge(Double featureCharge) {
		this.featureCharge = featureCharge;
	}

	
	public String getFeatureType() {
		return featureType;
	}

	public void setFeatureType(String featureType) {
		this.featureType = featureType;
	}
	
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DeviceLineItemId:" + getDeviceLineItemId()).append('\n')
				.append("FeatureType:" + getFeatureType());
		return builder.toString();
	}

	@Override
	public boolean equals(Object featureLineItem){
		if (!(featureLineItem instanceof FeatureLineItem)) {
			return false;
		}
		return this.getId() == null ? false : this.getId().equalsIgnoreCase(((FeatureLineItem)featureLineItem).getId());
	}
	
	@Override
	public int hashCode() {
		return this.getId().hashCode();
	}

	public boolean autoAddedFeature;

	public boolean isAutoAddedFeature() {
		return autoAddedFeature;
	}

	public void setAutoAddedFeature(boolean autoAddedFeature) {
		this.autoAddedFeature = autoAddedFeature;
	}
}
