package onevz.soe.prepay.adaptor.cart.model.play.common.vo;

public class VZWResponseCartVO<T> {

    private int status;

    private String statusCode;

    private T payload;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public T getPayload() {
        return payload;
    }

    public void setPayload(T payload) {
        this.payload = payload;
    }

    private ErrorVO errors;

    public ErrorVO getErrors() {
        return errors;
    }

    public void setErrors(ErrorVO errors) {
        this.errors = errors;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }
}