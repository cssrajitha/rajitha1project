package onevz.soe.prepay.adaptor.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.model.addPlan.AddPlanContext;
import onevz.soe.cart.model.addPlan.AddPlanServiceBody;
import onevz.soe.cart.model.addPlan.AddPlanServiceRequest;
import onevz.soe.cart.model.addPlan.AddPlanServiceResponse;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.requests.AddPlanPEGARequest;
import onevz.soe.cart.responses.AddPlanPEGAResponse;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.common.model.PrepaidODRequestDataLines;
import onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants;
import onevz.soe.prepay.adaptor.cart.model.cart.vo.VZWPrepayEditCartRequest;
import onevz.soe.prepay.adaptor.cart.util.PrepayAdaptorCartUtil;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.bpm.model.response.AvailablePaths;
import onevz.soe.wsclient.bpm.model.response.Error;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import onevz.soe.wsclient.prepay.webclient.model.PrepaidAdaptorWebClientRequest;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.*;
import java.util.stream.Collectors;

import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.*;

@Service
public class PrepayAdaptorCartAddPlanHelper {

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    private PrepayAdaptorWebClient prepayBusinessCartWebclient;

    @Autowired
    PrepayCartRedisHelper prepayCartRedisHelper;

    @Autowired
    SOELoginSessionBean sessionBean;

    @Value("${playPrepaidEditCart}")
    private String playPrepaidEditCart;
    
    @Value("${accountOwner}")
    private String accountOwner;
    
    @Value("${enablePricePlanRefresh}")
    private String enablePricePlanRefresh;

    private static final Logger logger = LoggerFactory.getLogger(PrepayAdaptorCartAddPlanHelper.class);

    /**
     * @param httpRequest
     * @param addPlanPEGARequest
     * @return AddPlanPEGAResponse
     */
    public Mono<ResponseEntity<AddPlanPEGAResponse>> addPlan(ServerHttpRequest httpRequest, AddPlanPEGARequest addPlanPEGARequest) {

        //Request Validation
        if(Optional.ofNullable(addPlanPEGARequest).map(AddPlanPEGARequest::getServiceBody).map(AddPlanServiceBody::getServiceRequest).map(AddPlanServiceRequest::getContext)
                .map(AddPlanContext::getCartInfo).map(CartServiceCartInfo::getLines).map(CollectionUtils::size).orElse(0).equals(0)){
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(addPlanPEGAResponseInvalidRequestError()));
        }

        List<Line> requestLinesList = Arrays.asList(Optional.ofNullable(addPlanPEGARequest).orElse(new AddPlanPEGARequest()).getServiceBody().getServiceRequest().getContext().getCartInfo().getLines());

        String mtnFromRequestTm = null;
        Plan planRequestTm = null;
        String planActionTypeTm = null;
        boolean applyPlanToFirstTwoLinesTm = false;
        if(PrepayAdaptorCartUtil.isCollectionNotEmpty(requestLinesList)) {
            mtnFromRequestTm = requestLinesList.get(0).getMtn();
            planRequestTm = requestLinesList.get(0).getPlan();
            if(null == requestLinesList.get(0).getPlan()){
                planActionTypeTm = PlanActionTypeEnum.ADD.toString();
            }else{
                planActionTypeTm = PlanActionTypeEnum.UPDATE.toString();
            }
            if(2==requestLinesList.size()){  //ApplyAll only applicable to first two lines
                applyPlanToFirstTwoLinesTm = true;
                planActionTypeTm = PlanActionTypeEnum.ADD.toString();
            }
        }
        if(null == planRequestTm || StringUtilities.isEmptyOrNull(mtnFromRequestTm)) {
            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(addPlanPEGAResponseInternalServerError()));
        }
        final String mtnFromRequest = mtnFromRequestTm;
        final Plan planRequest = planRequestTm;
        final boolean applyPlanToFirstTwoLines = applyPlanToFirstTwoLinesTm;
        return prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)
                .doOnError(err -> logger.error("Failed to read redis data and return error {}", err))
                .defaultIfEmpty("")
                .flatMap(response -> {
                    logger.info("PrepaidODRequestData From Redis:: {} ", response);
                    PrepaidODRequestData prepaidODRequestData = null;
                    List<PrepaidODRequestDataLines> linesFromRedis = null;

                    if( StringUtilities.isEmptyOrNull(response)){
                        logger.error("Failed to get data from redis {}",response);
                        return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(addPlanPEGAResponseInternalServerError()));
                    }

                    try {
                        prepaidODRequestData = mapper.readValue(response, PrepaidODRequestData.class);
                        linesFromRedis = prepaidODRequestData.getLines();
                    } catch (JsonProcessingException e) {
                        logger.error("Error while parsing redis Data for Add/Edit plan:", e);
                        return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(addPlanPEGAResponseInternalServerError()));
                    }
                    //Check if it is addPlan or updatePlanRequest
                    if(PrepayAdaptorCartUtil.isCollectionNotEmpty(linesFromRedis)){
                        List<PrepaidODRequestDataLines> redisLinesToModify = linesFromRedis.stream().filter(lineFromRedis-> mtnFromRequest.equalsIgnoreCase(lineFromRedis.getMtn())).collect(Collectors.toList());
                        if(PrepayAdaptorCartUtil.isCollectionEmpty(redisLinesToModify)){
                            return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(addPlanPEGAResponseInternalServerError()));
                        }

                        //check the plan, if it is empty then make addPlan call
                        PrepaidODRequestDataLines redisLineToModify = redisLinesToModify.get(0);
                        String existingPlanSkuId = StringUtilities.isEmptyOrNull(redisLineToModify.getPlanSkuId()) ? "" : new String(redisLineToModify.getPlanSkuId());
                        String existingPlanSorId = StringUtilities.isEmptyOrNull(redisLineToModify.getPlanSorId()) ? "" : new String(redisLineToModify.getPlanSorId());
                        List<String> existingFeatureSkuIdList = PrepayAdaptorCartUtil.isCollectionEmpty(redisLineToModify.getFeatureSkuIds()) ? new ArrayList<String>() : new ArrayList<>(redisLineToModify.getFeatureSkuIds());

                        redisLineToModify.setPlanSkuId(planRequest.getSkuId());
                        redisLineToModify.setPlanSorId(planRequest.getId());
                        redisLineToModify.setFeatureSkuIds(null);

                        if(applyPlanToFirstTwoLines){
                            final List<PrepaidODRequestDataLines> linesFromRedisFinal =linesFromRedis;
                            requestLinesList.stream().forEach(requestLine->
                                linesFromRedisFinal.stream().filter(redisLine->requestLine.getMtn().equalsIgnoreCase(redisLine.getMtn())).forEach(redisLine -> {
                                    redisLine.setPlanSkuId(planRequest.getSkuId());
                                    redisLine.setPlanSorId(planRequest.getId());
                                    redisLine.setFeatureSkuIds(null);
                                }));
                        }

                        PrepaidODRequestData finalPrepaidODRequestData = prepaidODRequestData;
                        //check checkout flag is false
                        if(redisLineToModify.isCheckoutFlag()){
                            //make Editcart Prepay OD call
                            PrepaidAdaptorWebClientRequest prepaidLegacyServiceRequest = getEditCartPrepaidLegacyServiceRequest(redisLineToModify, finalPrepaidODRequestData);
                            return prepayBusinessCartWebclient.getPrepayServiceResponse(httpRequest, prepaidLegacyServiceRequest)
                                    .doOnError(error -> logger.error("Failed to get response for add/update plan, check exception for details.", error))
                                    .flatMap(editCartResponseEntity -> {
                                        logger.info("Successful response from api: {}", prepaidLegacyServiceRequest.getUrl());
                                        if (!editCartResponseEntity.getStatusCode().is2xxSuccessful()) {
                                            logger.error("Error while calling prepaidODEditCart Service for update/add service, status code: {}", editCartResponseEntity.getStatusCode());
                                            redisLineToModify.setPlanSkuId(existingPlanSkuId);
                                            redisLineToModify.setPlanSorId(existingPlanSorId);
                                            redisLineToModify.setFeatureSkuIds(existingFeatureSkuIdList);
                                            return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(addPlanPEGAResponseInternalServerError()));
                                        }
                                        logger.info("prepaidODEditCart Service is successful ");
                                        redisLineToModify.setPlanUpdated(true);
                                        return prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, finalPrepaidODRequestData)
                                                .doOnError(err -> logger.error("Failed and return error {}", err))
                                                .flatMap(upsertResp -> {
                                                    logger.info("PrepaidODRequestData From Redis:: {} ", upsertResp);
                                                    return Mono.just(ResponseEntity.status(HttpStatus.OK).body(getAddPlanPEGAResponse(true, finalPrepaidODRequestData, addPlanPEGARequest)));
                                                });
                                    });
                        } else {
                            //just update the redis
                            return prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, finalPrepaidODRequestData)
                                    .doOnError(err -> logger.error("Failed to udpate redis and return error {}", err))
                                    .flatMap(upsertResp -> {
                                        logger.info("PrepaidODRequestData From Redis:: {} ", upsertResp);
                                        return Mono.just(ResponseEntity.status(HttpStatus.OK).body(getAddPlanPEGAResponse(true, finalPrepaidODRequestData, addPlanPEGARequest)));
                                    });
                        }
                    } else {
                        return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(addPlanPEGAResponseInternalServerError()));
                    }
                });
    }

    private AddPlanPEGAResponse addPlanPEGAResponseInternalServerError(){
        AddPlanPEGAResponse addPlanPEGAResponseError = new AddPlanPEGAResponse();
        List<Error> errors = new ArrayList<>();
        Error error = new Error();
        error.setErrorCode(PrepayAdaptorCartConstants.INVALID_REQUEST_ERROR_CODE);
        error.setMessage(PrepayAdaptorCartConstants.INVALID_REQUEST_ERROR);
        errors.add(error);
        addPlanPEGAResponseError.setErrors(errors);
        return addPlanPEGAResponseError;
    }

    private AddPlanPEGAResponse addPlanPEGAResponseInvalidRequestError(){
        AddPlanPEGAResponse addPlanPEGAResponseError = new AddPlanPEGAResponse();
        List<Error> errors = new ArrayList<>();
        Error error = new Error();
        error.setErrorCode(INVALID_REQUEST_ERROR);
        error.setMessage(INVALID_REQUEST_ERROR_CODE);
        errors.add(error);
        addPlanPEGAResponseError.setErrors(errors);
        return addPlanPEGAResponseError;
    }

    private PrepaidAdaptorWebClientRequest getEditCartPrepaidLegacyServiceRequest(PrepaidODRequestDataLines redisLineToModify, PrepaidODRequestData prepaidODRequestData) {
        VZWPrepayEditCartRequest prepayEditCartRequest = new VZWPrepayEditCartRequest();
        prepayEditCartRequest.setDeviceSkuId(redisLineToModify.getDeviceSkuId());
        prepayEditCartRequest.setEditFlowName(PrepayAdaptorCartConstants.PREPAY_OD_EDITCART_FLOW_DEVICE);
        prepayEditCartRequest.setLineItemId(redisLineToModify.getLineItemId());
        prepayEditCartRequest.setPlanSkuId(redisLineToModify.getPlanSkuId());
        prepayEditCartRequest.setProductId(redisLineToModify.getDeviceId());
        prepayEditCartRequest.setFeatureSkuId("");
        prepayEditCartRequest.setQuantity(1);
        
		String flow = StringUtilities.isNotEmptyOrNull(redisLineToModify.getFlow())?redisLineToModify.getFlow():NSE;
		String flowName = PrepayAdaptorCartUtil.getODFlowName(flow);
        prepayEditCartRequest.setFlow(flowName);
        PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
        prepaidAdaptorWebClientRequest.setUrl(playPrepaidEditCart);
        prepaidAdaptorWebClientRequest.setHeader(PrepayAdaptorCartUtil.getPrepayODServiceCommonHeaders(prepaidODRequestData,redisLineToModify.getFlow()));
        prepaidAdaptorWebClientRequest.setRequestBody(prepayEditCartRequest);
        prepaidAdaptorWebClientRequest.setRequestType(HttpMethod.POST.toString());
        return prepaidAdaptorWebClientRequest;
    }

    private AddPlanPEGAResponse getAddPlanPEGAResponse(boolean updateLine, PrepaidODRequestData prepaidODRequestData,
                                                              AddPlanPEGARequest addPlanPEGARequest) {
        AddPlanPEGAResponse addPlanPEGAResponse = new AddPlanPEGAResponse();
        if(updateLine){
            addPlanPEGARequest.getServiceHeader().setStatusMsg(PrepayAdaptorCartConstants.SUCCESS_MSG);
            addPlanPEGARequest.getServiceHeader().setStatusCode(PrepayAdaptorCartConstants.RESPONSE_SUCCESS_CODE);
        }else{
            addPlanPEGARequest.getServiceHeader().setStatusMsg(PrepayAdaptorCartConstants.FAILURE_MSG);
            addPlanPEGARequest.getServiceHeader().setStatusCode(PrepayAdaptorCartConstants.RESPONSE_FAILURE_CODE);
        }
        addPlanPEGAResponse.setServiceHeader(addPlanPEGARequest.getServiceHeader());
        addPlanPEGAResponse.setServiceBody(getServiceBody(updateLine,addPlanPEGARequest,prepaidODRequestData));
        return addPlanPEGAResponse;
    }

    private AddPlanServiceBody getServiceBody(boolean updateLine,AddPlanPEGARequest addPlanPEGARequest,
                                              PrepaidODRequestData prepaidODRequestData) {
        AddPlanServiceBody addPlanServiceBody = new AddPlanServiceBody();
        addPlanServiceBody.setServiceResponse(getServiceResponse(updateLine,addPlanPEGARequest,prepaidODRequestData));
        return addPlanServiceBody;
    }

    private AddPlanServiceResponse getServiceResponse(boolean updateLine,AddPlanPEGARequest addPlanPEGARequest,
                                                      PrepaidODRequestData prepaidODRequestData) {
        AddPlanServiceResponse addPlanServiceResponse = new AddPlanServiceResponse();
        addPlanServiceResponse.setContext(getResponseContext(updateLine,addPlanPEGARequest,prepaidODRequestData));
        return addPlanServiceResponse;
    }

    private AddPlanContext getResponseContext(boolean updateLine,AddPlanPEGARequest addPlanPEGARequest,
                                              PrepaidODRequestData prepaidODRequestData) {
        AddPlanContext addPlanContext = new AddPlanContext();
        try
        {
            CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
            CartServiceContextInfo serviceContextInfo = new CartServiceContextInfo();
            boolean isHotSpot=false;
            String requestMtn = PrepayAdaptorCartConstants.DEFAULT_NSE_LINE;
            Line[] lines = null;
            
            if(Objects.nonNull(addPlanPEGARequest) && Objects.nonNull(addPlanPEGARequest.getServiceBody()) 
            		&& Objects.nonNull(addPlanPEGARequest.getServiceBody().getServiceRequest()) 
            		&& Objects.nonNull(addPlanPEGARequest.getServiceBody().getServiceRequest().getContext()) 
            		&& Objects.nonNull(addPlanPEGARequest.getServiceBody().getServiceRequest().getContext().getContextInfo())) {
            	
            
	            serviceContextInfo.setCallReason(addPlanPEGARequest.getServiceBody().getServiceRequest().getContext().getContextInfo().getCallReason());
	            serviceContextInfo.setIntent(addPlanPEGARequest.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
            }
            
            if(Objects.nonNull(addPlanPEGARequest) && Objects.nonNull(addPlanPEGARequest.getServiceBody()) 
            		&& Objects.nonNull(addPlanPEGARequest.getServiceBody().getServiceRequest()) 
            		&& Objects.nonNull(addPlanPEGARequest.getServiceBody().getServiceRequest().getContext()) 
            		&& Objects.nonNull(addPlanPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo())) {
	            customerInfo.setCustomerType(addPlanPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCustomerType());
	            customerInfo.setAccountNumber(addPlanPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getAccountNumber());
	            customerInfo.setCartCreator(addPlanPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCartCreator());
	            customerInfo.setRegisterNumber(addPlanPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getRegisterNumber());
	            customerInfo.setMtnFlow(addPlanPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getMtnFlow());
	            customerInfo.setGlobalId(addPlanPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getGlobalId());
            }
       
            if(Objects.nonNull(addPlanPEGARequest) && Objects.nonNull(addPlanPEGARequest.getServiceBody()) 
            		&& Objects.nonNull(addPlanPEGARequest.getServiceBody().getServiceRequest()) 
            		&& Objects.nonNull(addPlanPEGARequest.getServiceBody().getServiceRequest().getContext()) 
            		&& Objects.nonNull(addPlanPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo()) 
            		&& Objects.nonNull(addPlanPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines())) {
            	requestMtn = addPlanPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getMtn();
            	lines=addPlanPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
            	isHotSpot = Arrays.stream(lines).filter(line->line.getPlan().getId().equalsIgnoreCase(PrepayAdaptorCartConstants.HOTSPOT_PLAN_ID)).collect(Collectors.toList()).size()>0?true:false;
            }
            AvailablePaths availablePath = new AvailablePaths();
            List<AvailablePaths> availablePaths = new ArrayList<>();
            ProcessMTNList listData = new ProcessMTNList();
            
            if(updateLine){
            	//check getLines is not null
            	List<PrepaidODRequestDataLines> remainingLines = new ArrayList<>();
            	List<PrepaidODRequestDataLines> hotspotLines = new ArrayList<>();
            	
            	if(Objects.nonNull(prepaidODRequestData.getLines())) {
            		remainingLines = prepaidODRequestData.getLines().stream().filter(line -> StringUtilities.isEmptyOrNull(line.getPlanSorId())).collect(Collectors.toList());
            		
            		if("true".equalsIgnoreCase(enablePricePlanRefresh)) {
            			logger.info("Price Plan Refresh is enabled");
                	} else {
                		hotspotLines = prepaidODRequestData.getLines().stream().filter(line -> PrepayAdaptorCartConstants.HOTSPOT_PLAN_ID.equalsIgnoreCase(line.getPlanSorId()) && CollectionUtilities.isEmptyOrNull(line.getFeatureSkuIds())).collect(Collectors.toList());
                	}
            	}
            	if(CollectionUtilities.isNotEmptyOrNull(remainingLines) && !remainingLines.isEmpty()) {
            		serviceContextInfo.setProcessStep(PrepayAdaptorCartConstants.NEW_PLANS_PROCESS_STEP);
            		availablePath.setPath(PrepayAdaptorCartConstants.NEW_PLANS_PROCESS_STEP);
            		customerInfo.setProcessingMTN(remainingLines.get(0).getMtn());
            		listData.setMtn(remainingLines.get(0).getMtn());
            		
            	} else if(CollectionUtilities.isNotEmptyOrNull(hotspotLines) && !hotspotLines.isEmpty()) {
            		
            		serviceContextInfo.setProcessStep(PrepayAdaptorCartConstants.HOTSPOT_PLAN_PROCESS_STEP);
            		availablePath.setPath(PrepayAdaptorCartConstants.HOTSPOT_PLAN_PROCESS_STEP);
            		customerInfo.setProcessingMTN(hotspotLines.get(0).getMtn());
            		listData.setMtn(hotspotLines.get(0).getMtn());
            	} else {
            		boolean checkoutFlag = false;
        			if(Objects.nonNull(addPlanPEGARequest) && Objects.nonNull(addPlanPEGARequest.getServiceBody())
        					&& Objects.nonNull(addPlanPEGARequest.getServiceBody().getServiceRequest()) 
        					&& Objects.nonNull(addPlanPEGARequest.getServiceBody().getServiceRequest().getContext())
        					&& Objects.nonNull(addPlanPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo())
        					&& Objects.nonNull(addPlanPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines())
        					&& Objects.nonNull(prepaidODRequestData) && Objects.nonNull(prepaidODRequestData.getLines())) {
        					
        						List<PrepaidODRequestDataLines> dataLines = prepaidODRequestData.getLines().stream().filter(line->line.getMtn().equalsIgnoreCase(addPlanPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getMtn())).collect(Collectors.toList());
        						checkoutFlag = dataLines.get(0).isCheckoutFlag();			
        				}
            		if(checkoutFlag) {
                		if("true".equalsIgnoreCase(accountOwner) && Objects.nonNull(prepaidODRequestData) && !prepaidODRequestData.isLoggedIn()) {
    	            		if(Objects.nonNull(prepaidODRequestData) && CollectionUtilities.isNotEmptyOrNull(prepaidODRequestData.getLines()) && prepaidODRequestData.getLines().size() > 1 && (prepaidODRequestData.getLines().stream().filter(lineData->lineData.isSmartWatch()).count()==0)) {
    	            			serviceContextInfo.setProcessStep(PrepayAdaptorCartConstants.ACCOUNT_OWNER_PROCESS_STEP);
    	                		availablePath.setPath(PrepayAdaptorCartConstants.ACCOUNT_OWNER_PROCESS_STEP);
    	            		} else {
    		            		serviceContextInfo.setProcessStep(PrepayAdaptorCartConstants.CHECKOUT_PLAN_PROCESS_STEP);
    		            		availablePath.setPath(PrepayAdaptorCartConstants.CHECKOUT_PLAN_PROCESS_STEP);
    	            		}
                		} else {
    	            		serviceContextInfo.setProcessStep(PrepayAdaptorCartConstants.CHECKOUT_PLAN_PROCESS_STEP);
    	            		availablePath.setPath(PrepayAdaptorCartConstants.CHECKOUT_PLAN_PROCESS_STEP);
                		}
            		} else {
            			serviceContextInfo.setProcessStep(PrepayAdaptorCartConstants.ADD_DEVICE_PREPAY_PROCESS_STEP);
	            		availablePath.setPath(PrepayAdaptorCartConstants.ADD_DEVICE_PREPAY_PROCESS_STEP);
            		}
        
            		customerInfo.setProcessingMTN(prepaidODRequestData.getLines().get(0).getMtn());
            		listData.setMtn(prepaidODRequestData.getLines().get(0).getMtn());
            	}                        
            }else{
            	customerInfo.setProcessingMTN(requestMtn);
            	listData.setMtn(requestMtn);
            	serviceContextInfo.setProcessStep(PrepayAdaptorCartConstants.NEW_PLANS_PROCESS_STEP);
            	availablePath.setPath(PrepayAdaptorCartConstants.NEW_PLANS_PROCESS_STEP);
            }
            List<PrepaidODRequestDataLines> lineToProcess = prepaidODRequestData.getLines().stream().filter(line->line.getMtn().equalsIgnoreCase(addPlanPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getMtn())).collect(Collectors.toList());
            List<String> completedSteps = lineToProcess.get(0).getCompletedProcessSteps();
            completedSteps.add(PrepayAdaptorCartConstants.NEW_PLANS_PROCESS_STEP);
            listData.setCompletedprocessSteps(completedSteps.toArray(new String[completedSteps.size()]));
            serviceContextInfo.setProcessAction("");
            availablePaths.add(availablePath);
            serviceContextInfo.setAvailablePaths(availablePaths);
            List<ProcessMTNList> mtnList = new ArrayList<>();
            mtnList.add(listData);
            addPlanContext.setProcessMTNList(mtnList);
            addPlanContext.setContextInfo(serviceContextInfo);
            addPlanContext.setCustomerInfo(customerInfo);
            addPlanContext.setCartInfo(getCartInfo(addPlanPEGARequest));
        } catch(Exception ex) {
            logger.error("Exception in building response{0}", ex);
        }
        return addPlanContext;

    }

    private CartServiceCartInfo getCartInfo(AddPlanPEGARequest addPlanPEGARequest) {
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(addPlanPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getCartId());
        return cartInfo;
    }

}
