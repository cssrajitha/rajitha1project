package onevz.soe.prepay.adaptor.cart.model.bpm;

import lombok.Data;

import java.util.HashMap;

@Data
public class AddDeviceToPrepayODAddDeviceResponse {
    private String orderId;
    private boolean orderUpdated;
    private boolean success;
    private HashMap<String,String> errorMap ;
    private String baseError;
    private String status;
    private int totalLines;
    private int cartCount;
    private boolean is5gTo4gTransition;
    private String devCommerceId;
    private String nextCyclePay;
}
