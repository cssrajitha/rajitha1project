package onevz.soe.prepay.adaptor.cart.model.cxp.common;

/**
 * Holds information about warnings from CXP services.
 */
public interface CXPWarning {
}
