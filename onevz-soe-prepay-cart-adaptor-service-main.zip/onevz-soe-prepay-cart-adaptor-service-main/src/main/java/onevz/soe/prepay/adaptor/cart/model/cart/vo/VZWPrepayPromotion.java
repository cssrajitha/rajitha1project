package onevz.soe.prepay.adaptor.cart.model.cart.vo;

import java.io.Serializable;

public class VZWPrepayPromotion implements Serializable {
    private static final long serialVersionUID = 1L;
    private String barCode;
    private Double promoAmount;
    private String sorId;
    private String skuId;
    private String promoMsg;

    public String getBarCode() {
        return barCode;
    }

    public void setBarCode(String barCode) {
        this.barCode = barCode;
    }

    public Double getPromoAmount() {
        return promoAmount;
    }

    public void setPromoAmount(Double promoAmount) {
        this.promoAmount = promoAmount;
    }

    public String getSorId() {
        return sorId;
    }

    public void setSorId(String sorId) {
        this.sorId = sorId;
    }

    public String getSkuId() {
        return skuId;
    }

    public void setSkuId(String skuId) {
        this.skuId = skuId;
    }

    public String getPromoMsg() {
        return promoMsg;
    }

    public void setPromoMsg(String promoMsg) {
        this.promoMsg = promoMsg;
    }
}
