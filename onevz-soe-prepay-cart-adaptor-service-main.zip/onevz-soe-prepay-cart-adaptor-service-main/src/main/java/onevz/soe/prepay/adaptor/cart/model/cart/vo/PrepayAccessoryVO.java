package onevz.soe.prepay.adaptor.cart.model.cart.vo;

import java.io.Serializable;

import java.util.List;

import lombok.Data;
@Data
public class PrepayAccessoryVO implements Serializable {

    private static final long serialVersionUID = 1L;

    private String id ;
    private int quantity;
    private String skuId;
    private String productId;
    private String seoName ;
    private String sorId;
    private double listPrice;
    private double itemAmount;
    private double rawTotalAmount;
    private double deviceTax;
    private double discountedPrice;
    private String skuDisplayName;
    private String color;
    private String capacity;
    private String brandName;
    private String miniImageUrl;
    private String thumbImageUrl;
    private String mediumImageUrl;
    private String largeImageUrl;
    private String purchasePath;
    private String itemType;
    private double totalDueToday;
    private String accessorySorType;
    private String deviceCommerceItemId;
    private String accessoryCategory;
    private boolean isInlinePromo;
    private double fullRetailListPrice;
    private List<TaxDetail> taxDetails;

}
