package onevz.soe.prepay.adaptor.cart.model.cxp.shipping;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * class RetrieveZipcodeMktDetailsResponseData having zipcode store market details.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RetrieveZipcodeMktDetailsResponseData {
	
		
	@JsonProperty(value = "marketDetails")
	private List<MarketDetails> marketDetails;
}
