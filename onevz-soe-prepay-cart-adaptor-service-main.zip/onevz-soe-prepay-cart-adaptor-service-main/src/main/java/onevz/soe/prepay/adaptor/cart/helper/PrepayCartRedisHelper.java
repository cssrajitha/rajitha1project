package onevz.soe.prepay.adaptor.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.session.bean.SOELoginSessionBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service
public class PrepayCartRedisHelper {

	@Autowired
	SOELoginSessionBean sessionBean;

	@Autowired
	private ObjectMapper mapper;

	private static final Logger logger = LoggerFactory.getLogger(PrepayCartRedisHelper.class);

	/**
	 * @param key
	 * @param data
	 * @return boolean
	 */
	public Mono<Boolean> upsertDataIntoRedis(String key, Object data) {
		return sessionBean.setSessionData(key, data).doOnError(onError ->
			logger.error(" Unable to add/update data into Redis {}", onError)
		).doOnSuccess(onSuccess ->
			logger.info("Successfully updated data to Redis: {}", onSuccess)
		).flatMap(response -> {
			logger.info("data upserted to redis response : {}",response);
			return Mono.just(response);
		});
	}

	/**
	 * @param key
	 * @param data
	 * @return boolean
	 */
	public Mono<Boolean> upsertDataIntoRedisAsStr(String key, Object data) {

		Map<String,String> reqMap=new HashMap<>();
		reqMap.put(key, convertObjectToString(data));
		return sessionBean.setSessionData(reqMap).doOnError(onError ->
			logger.error(" Unable to add/update data into Redis {}", onError)
		).doOnSuccess(onSuccess ->
			logger.info("Successfully updated data to Redis: {}", onSuccess)
		).flatMap(response -> {
			logger.info("data upserted to redis response : {}",response);
			return Mono.just(response);
		});
	}


	/**
	 *
	 * @return getDataFromRedisAsString
	 */
	public Mono<String> getDataFromRedisAsString(String key) {
		return sessionBean.getSessionData(key, String.class)
				.doOnError(onError ->
					logger.error(" Unable to get data from Redis {}", onError)
				).doOnSuccess(onSuccess ->
					logger.info("Successfully retrieved data from Redis: {}", onSuccess)
				).flatMap(response -> {
					return Mono.just(response);
				});
	}
	
	private String convertObjectToString(Object obj){
		String requestString="";
		try {
			requestString = mapper.writeValueAsString(obj);
		} catch (JsonProcessingException err) {
			logger.error("Unable to convert object to String {}", err);
		}
		return requestString;
	}
	
	/**
	 * @param key
	 * @return Long
	 */
	public Mono<Long> removeDataFromRedis(String key) {
		List<String> keys = new ArrayList<String>();
		keys.add(key);
		return sessionBean.deleteSessionData(keys).doOnError(onError ->
			logger.error(" Unable to add/update data into Redis {}", onError)
		).doOnSuccess(onSuccess ->
			logger.info("Successfully updated data to Redis: {}", onSuccess)
		).flatMap(response -> {
			logger.info("data upserted to redis response : {}",response);
			return Mono.just(response);
		});
	}

}
