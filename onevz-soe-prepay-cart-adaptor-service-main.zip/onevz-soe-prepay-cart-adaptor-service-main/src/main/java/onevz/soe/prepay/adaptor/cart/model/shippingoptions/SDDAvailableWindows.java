package onevz.soe.prepay.adaptor.cart.model.shippingoptions;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.Data;

/**
 * class SDDAvailableWindows contains same day delivery data information.
 *
 */
@Data
@JsonInclude(Include.NON_NULL)
public class SDDAvailableWindows {
    private String endTime;
    private String endsAt;
    private String formattedWindow;
    private String id;
    private String startTime;
    private String startsAt;
    private String timeZone;
    private String windowDescription;
    private boolean selected;
    private String formattedStartTime;
    private String formattedEndTime;

}
