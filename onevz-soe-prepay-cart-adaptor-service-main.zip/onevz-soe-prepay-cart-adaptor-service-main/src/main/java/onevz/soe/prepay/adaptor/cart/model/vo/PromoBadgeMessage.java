package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;

public class PromoBadgeMessage implements Serializable{

	private static final long serialVersionUID = 1L;
	private String badgeText;
	private String badgeToolTip;
	private String badgeToolTipUrl;
	private String badgeImage;
	private String placement;
	private double discountAmount;
	private String sedOfferId;
	private String offerType;
	private double offerAmount;
	private String barCodeId;

	public double getDiscountAmount() {
		return discountAmount;
	}

	public void setDiscountAmount(double discountAmount) {
		this.discountAmount = discountAmount;
	}

	public String getBadgeText() {
		return badgeText;
	}
	public void setBadgeText(String badgeText) {
		this.badgeText = badgeText;
	}
	public String getBadgeToolTip() {
		return badgeToolTip;
	}
	public void setBadgeToolTip(String badgeToolTip) {
		this.badgeToolTip = badgeToolTip;
	}
	public String getBadgeImage() {
		return badgeImage;
	}
	public void setBadgeImage(String badgeImage) {
		this.badgeImage = badgeImage;
	}
	public String getPlacement() {
		return placement;
	}
	public void setPlacement(String placement) {
		this.placement = placement;
	}

	public String getSedOfferId() {
		return sedOfferId;
	}

	public void setSedOfferId(String sedOfferId) {
		this.sedOfferId = sedOfferId;
	}

	public String getOfferType() {
		return offerType;
	}

	public String getBadgeToolTipUrl() {
		return badgeToolTipUrl;
	}

	public void setBadgeToolTipUrl(String badgeToolTipUrl) {
		this.badgeToolTipUrl = badgeToolTipUrl;
	}

	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}

	public double getOfferAmount() {
		return offerAmount;
	}

	public void setOfferAmount(double offerAmount) {
		this.offerAmount = offerAmount;
	}

	public String getBarCodeId() {
		return barCodeId;
	}

	public void setBarCodeId(String barCodeId) {
		this.barCodeId = barCodeId;
	}
}
