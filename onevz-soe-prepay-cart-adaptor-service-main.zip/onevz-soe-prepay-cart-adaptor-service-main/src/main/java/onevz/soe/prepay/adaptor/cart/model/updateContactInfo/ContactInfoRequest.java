package onevz.soe.prepay.adaptor.cart.model.updateContactInfo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import onevz.soe.prepay.orderprocess.model.common.CheckoutServiceHeader;
import onevz.soe.wsclient.bpm.model.request.BPMServiceRequest;


@lombok.Data
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
@EqualsAndHashCode(callSuper = true)
public class ContactInfoRequest extends BPMServiceRequest {
    private CheckoutServiceHeader serviceHeader;
    private COntactInfoServiceBody serviceBody;
}
