package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;

public class PricePlanPackageType implements Serializable {

    private static final long serialVersionUID = 1L;
    private String PPPID;
    private String PPPDesc;
    private double PurchasePrice;
    private double DiscountPrice;
    private String PPPType;
    private String UnitType;
    private String Units;
  	private String VendorPriceID;

    public DeviceList getDeviceList() {
        return deviceList;
    }

    public void setDeviceList(DeviceList deviceList) {
        this.deviceList = deviceList;
    }

    private DeviceList deviceList;
    public String getPPPID() {
        return PPPID;
    }

    public void setPPPID(String PPPID) {
        this.PPPID = PPPID;
    }

    public String getPPPDesc() {
        return PPPDesc;
    }

    public void setPPPDesc(String PPPDesc) {
        this.PPPDesc = PPPDesc;
    }

    public double getPurchasePrice() {
        return PurchasePrice;
    }

    public void setPurchasePrice(double purchasePrice) {
        PurchasePrice = purchasePrice;
    }

    public double getDiscountPrice() {
        return DiscountPrice;
    }

    public void setDiscountPrice(double discountPrice) {
        DiscountPrice = discountPrice;
    }

    public String getPPPType() {
        return PPPType;
    }

    public void setPPPType(String PPPType) {
        this.PPPType = PPPType;
    }

    public String getUnitType() {
        return UnitType;
    }

    public void setUnitType(String unitType) {
        UnitType = unitType;
    }

    public String getUnits() {
        return Units;
    }

    public void setUnits(String units) {
        Units = units;
    }

    public String getVendorPriceID() {
        return VendorPriceID;
    }

    public void setVendorPriceID(String vendorPriceID) {
        VendorPriceID = vendorPriceID;
    }
}
