/**
 * 
 */
package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;
import java.util.Date;

/**
 *
 *
 */
public class NumberPortabilityVO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3582496629506131000L;
	private String id;
	private String mobileNumber;
	private String accountNumber;
	private String accountPIN;
	private String accountHolderName;
	private String billingAddress1;
	private String billingAddress2;
	private String city;
	private String state;
	private String zipCode;
	private String transferredFromMtn;
	private boolean isEdgeContract;
	private String contactPhoneNumber;
	private String createDate;
	private Date lastModifiedDate;
	private int version;
	private ValidateMDNResponseVO validateMDNResponseVO;

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountPIN() {
		return accountPIN;
	}

	public void setAccountPIN(String accountPIN) {
		this.accountPIN = accountPIN;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public String getBillingAddress1() {
		return billingAddress1;
	}

	public void setBillingAddress1(String billingAddress1) {
		this.billingAddress1 = billingAddress1;
	}

	public String getBillingAddress2() {
		return billingAddress2;
	}

	public void setBillingAddress2(String billingAddress2) {
		this.billingAddress2 = billingAddress2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getTransferredFromMtn() {
		return transferredFromMtn;
	}

	public void setTransferredFromMtn(String transferredFromMtn) {
		this.transferredFromMtn = transferredFromMtn;
	}

	public boolean isEdgeContract() {
		return isEdgeContract;
	}

	public void setEdgeContract(boolean isEdgeContract) {
		this.isEdgeContract = isEdgeContract;
	}

	public String getContactPhoneNumber() {
		return contactPhoneNumber;
	}

	public void setContactPhoneNumber(String contactPhoneNumber) {
		this.contactPhoneNumber = contactPhoneNumber;
	}

	public void setValidateMDNResponseVO(ValidateMDNResponseVO validateMDNResponseVO) {
		this.validateMDNResponseVO = validateMDNResponseVO;
	}

	public ValidateMDNResponseVO getValidateMDNResponseVO() {
		return validateMDNResponseVO;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "NumberPortabilityVO [id=" + id + ", mobileNumber=" + mobileNumber + ", accountNumber=" + accountNumber
				+ ", accountPIN=" + accountPIN + ", accountHolderName=" + accountHolderName + ", billingAddress1="
				+ billingAddress1 + ", billingAddress2=" + billingAddress2 + ", city=" + city + ", state=" + state
				+ ", zipCode=" + zipCode + ", transferredFromMtn=" + transferredFromMtn + ", isEdgeContract="
				+ isEdgeContract + ", contactPhoneNumber=" + contactPhoneNumber + ", createDate=" + createDate
				+ ", lastModifiedDate=" + lastModifiedDate + ", version=" + version + ", validateMDNResponseVO="
				+ validateMDNResponseVO + "]";
	}

}
