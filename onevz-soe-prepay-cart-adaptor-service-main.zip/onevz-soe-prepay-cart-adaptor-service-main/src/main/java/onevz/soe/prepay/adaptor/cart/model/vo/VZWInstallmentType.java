package onevz.soe.prepay.adaptor.cart.model.vo;

/**
 * Created by gumapa on 6/23/2017.
 */
public enum VZWInstallmentType {


    /**
     * E - Edge
     *
     */
    E,

    /**
     * D - DIP
     *
     */
    D;

    public String value() {
        return name();
    }

    public static VZWInstallmentType fromValue(String v) {
        return valueOf(v);
    }

}
