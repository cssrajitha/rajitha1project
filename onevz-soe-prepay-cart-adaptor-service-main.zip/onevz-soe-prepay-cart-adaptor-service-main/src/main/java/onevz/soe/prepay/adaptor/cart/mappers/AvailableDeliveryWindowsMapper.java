package onevz.soe.prepay.adaptor.cart.mappers;

import onevz.soe.prepay.adaptor.cart.model.play.shippingoptions.AvailableDeliveryWindows;
import onevz.soe.prepay.adaptor.cart.model.shippingoptions.SDDAvailableWindows;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface AvailableDeliveryWindowsMapper {

    SDDAvailableWindows playAvailableDeliveryWindowsToSOESDDAvailableWindows(AvailableDeliveryWindows source);

    @InheritInverseConfiguration(name = "playAvailableDeliveryWindowsToSOESDDAvailableWindows")
    AvailableDeliveryWindows soeSDDAvailableWindowsToAvailableDeliveryWindows(SDDAvailableWindows source);

}
