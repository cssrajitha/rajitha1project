package onevz.soe.prepay.adaptor.cart.model.vo;

import java.util.Date;
import java.util.List;


public class AccessoryLineItem extends OrderLineItem{

   
	private static final long serialVersionUID = 1L;
	private String deviceLineItemId;
	private String imageUrl;
	private String bogoType;
	private String recycleStateInd;
	public List<PromoBadgeMessage> getPromoBadgeMessages() {
		return promoBadgeMessages;
	}

	public void setPromoBadgeMessages(List<PromoBadgeMessage> promoBadgeMessages) {
		this.promoBadgeMessages = promoBadgeMessages;
	}

	private List<PromoBadgeMessage> promoBadgeMessages;

	private boolean appleCare;
	
	private double recycleCreditAllocatedAmount;
	
	public String getDeviceLineItemId() {
        return deviceLineItemId;
    }

    public void setDeviceLineItemId(String deviceLineItemId) {
        this.deviceLineItemId = deviceLineItemId;
    }

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public String getBogoType() {
		return bogoType;
	}

	public void setBogoType(String bogoType) {
		this.bogoType = bogoType;
	}

	public String getRecycleStateInd() {
		return recycleStateInd;
	}

	public void setRecycleStateInd(String recycleStateInd) {
		this.recycleStateInd = recycleStateInd;
	}

	public double getRecycleCreditAllocatedAmount() {
		return recycleCreditAllocatedAmount;
	}

	public void setRecycleCreditAllocatedAmount(double recycleCreditAllocatedAmount) {
		this.recycleCreditAllocatedAmount = recycleCreditAllocatedAmount;
	}

	public boolean isAppleCare() {
		return appleCare;
	}

	public void setAppleCare(boolean appleCare) {
		this.appleCare = appleCare;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		return builder.toString();
	}
	public boolean equalsAccessoryLineItem(AccessoryLineItem accessoryLineItem) {
		return accessoryLineItem == null ? false : this.getId().equalsIgnoreCase(accessoryLineItem.getId());
	}
	private boolean sameDayDelivery;

	public boolean isSameDayDelivery() {
		return sameDayDelivery;
	}

	public void setSameDayDelivery(boolean sameDayDelivery) {
		this.sameDayDelivery = sameDayDelivery;
	}

	private String color;
	private String size;
	private String capacity;
	private Date lastModifiedDate;
	private String deviceManufacturerName;
	private String accessoryType;
	private boolean ispuEligibleFlag;
	private List<AccBundleBreackdownDetailsVO> bundleSkuLineItems;
	private String bundleDesciption;
	private List<VZWSbdOffer> vzwSbdOfferlist;
	private List<VZWPromotion> promotions;
	private String purchasePath;
	private Date expectedShippingDate;
	private String shipCommitInd;
	private Double ecpdItemAmount;
	private Double ecpdItemDiscount;
	private boolean standaloneaccessory;
	private boolean batteryAccessory;
	private String accSeoUrl;
	private boolean batteryRestrictionEligibility;
	private boolean isGiftCardAccessory;
	private String giftCardInfoId;
	private boolean smartLocator;
	private boolean customBundle;
	private String  customBundleId;

	/**
	 * Added for Agent COMM
	 */
	private Double listPrice;
	private double salePrice;
	private double salePriceDiscount;
	private boolean showFiveGAccessory;
	private List<String> categoryIdList;

	public boolean isShowFiveGAccessory() {
		return showFiveGAccessory;
	}

	public void setShowFiveGAccessory(boolean showFiveGAccessory) {
		this.showFiveGAccessory = showFiveGAccessory;
	}

	public double getSalePriceDiscount() {
		return salePriceDiscount;
	}

	public void setSalePriceDiscount(double salePriceDiscount) {
		this.salePriceDiscount = salePriceDiscount;
	}


	public double getSalePrice() {
		return salePrice;
	}

	public void setSalePrice(double salePrice) {
		this.salePrice = salePrice;
	}

	public Double getListPrice() {
		if(listPrice != null){
			return listPrice;
		}else{
			return 0.0D;
		}
	}
	public void setListPrice(Double listPrice) {
		this.listPrice = listPrice;
	}

	public List<AccBundleBreackdownDetailsVO> getBundleSkuLineItems() {
		return bundleSkuLineItems;
	}

	public void setBundleSkuLineItems(List<AccBundleBreackdownDetailsVO> bundleSkuLineItems) {
		this.bundleSkuLineItems = bundleSkuLineItems;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getCapacity() {
		return capacity;
	}

	public void setCapacity(String capacity) {
		this.capacity = capacity;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getDeviceManufacturerName() {
		return deviceManufacturerName;
	}

	public void setDeviceManufacturerName(String deviceManufacturerName) {
		this.deviceManufacturerName = deviceManufacturerName;
	}

	public String getAccessoryType() {
		return accessoryType;
	}

	public void setAccessoryType(String accessoryType) {
		this.accessoryType = accessoryType;
	}

	@Override
	public boolean isIspuEligibleFlag() {
		return ispuEligibleFlag;
	}

	@Override
	public void setIspuEligibleFlag(boolean ispuEligibleFlag) {
		this.ispuEligibleFlag = ispuEligibleFlag;
	}

	public String getBundleDesciption() {
		return bundleDesciption;
	}

	public void setBundleDesciption(String bundleDesciption) {
		this.bundleDesciption = bundleDesciption;
	}

	public List<VZWSbdOffer> getVzwSbdOfferlist() {
		return vzwSbdOfferlist;
	}

	public void setVzwSbdOfferlist(List<VZWSbdOffer> vzwSbdOfferlist) {
		this.vzwSbdOfferlist = vzwSbdOfferlist;
	}

	public List<VZWPromotion> getPromotions() {
		return promotions;
	}

	public void setPromotions(List<VZWPromotion> promotions) {
		this.promotions = promotions;
	}

	public String getPurchasePath() {
		return purchasePath;
	}

	public void setPurchasePath(String purchasePath) {
		this.purchasePath = purchasePath;
	}

	public Date getExpectedShippingDate() {
		return expectedShippingDate;
	}

	public void setExpectedShippingDate(Date expectedShippingDate) {
		this.expectedShippingDate = expectedShippingDate;
	}

	public String getShipCommitInd() {
		return shipCommitInd;
	}

	public void setShipCommitInd(String shipCommitInd) {
		this.shipCommitInd = shipCommitInd;
	}

	public Double getEcpdItemAmount() {
		return ecpdItemAmount;
	}

	public void setEcpdItemAmount(Double ecpdItemAmount) {
		this.ecpdItemAmount = ecpdItemAmount;
	}

	public Double getEcpdItemDiscount() {
		return ecpdItemDiscount;
	}

	public void setEcpdItemDiscount(Double ecpdItemDiscount) {
		this.ecpdItemDiscount = ecpdItemDiscount;
	}

	public boolean isStandaloneaccessory() {
		return standaloneaccessory;
	}

	public void setStandaloneaccessory(boolean standaloneaccessory) {
		this.standaloneaccessory = standaloneaccessory;
	}

	public boolean isBatteryAccessory() {
		return batteryAccessory;
	}

	public void setBatteryAccessory(boolean batteryAccessory) {
		this.batteryAccessory = batteryAccessory;
	}

	public String getAccSeoUrl() {
		return accSeoUrl;
	}

	public void setAccSeoUrl(String accSeoUrl) {
		this.accSeoUrl = accSeoUrl;
	}

	public boolean isBatteryRestrictionEligibility() {
		return batteryRestrictionEligibility;
	}

	public void setBatteryRestrictionEligibility(boolean batteryRestrictionEligibility) {
		this.batteryRestrictionEligibility = batteryRestrictionEligibility;
	}

	public boolean isGiftCardAccessory() {
		return isGiftCardAccessory;
	}

	public void setGiftCardAccessory(boolean giftCardAccessory) {
		isGiftCardAccessory = giftCardAccessory;
	}

	public String getGiftCardInfoId() {
		return giftCardInfoId;
	}

	public void setGiftCardInfoId(String giftCardInfoId) {
		this.giftCardInfoId = giftCardInfoId;
	}

	public boolean isSmartLocator() {
		return smartLocator;
	}

	public void setSmartLocator(boolean smartLocator) {
		this.smartLocator = smartLocator;
	}
	public boolean isCustomBundle() {
		return customBundle;
	}

	public void setCustomBundle(boolean customBundle) {
		this.customBundle = customBundle;
	}

	public String getCustomBundleId() {
		return customBundleId;
	}

	public void setCustomBundleId(String customBundleId) {
		this.customBundleId = customBundleId;
	}


	public List<String> getCategoryIdList() {
		return categoryIdList;
	}

	public void setCategoryIdList(List<String> categoryIdList) {
		this.categoryIdList = categoryIdList;
	}
	private String sorAccessoryType;

	public String getSorAccessoryType() {
		return sorAccessoryType;
	}

	public void setSorAccessoryType(String sorAccessoryType) {
		this.sorAccessoryType = sorAccessoryType;

	}
}
