package onevz.soe.prepay.adaptor.cart.model.cart;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Error {
    private String OD_PREPAID_CART_CC_MAX_LIMIT_ERROR;

    private String OD_PREPAID_CART_CC_ADDING_NONCC_ITEM_ERROR;
}