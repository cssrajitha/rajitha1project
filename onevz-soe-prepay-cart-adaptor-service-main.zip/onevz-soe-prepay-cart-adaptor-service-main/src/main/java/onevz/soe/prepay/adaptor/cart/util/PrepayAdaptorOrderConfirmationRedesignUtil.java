package onevz.soe.prepay.adaptor.cart.util;

import onevz.soe.activation.cxp.response.OrderConfirmationCXPResponse;
import onevz.soe.activation.digital.cxp.model.*;
import onevz.soe.cart.model.retrieveCart.ImageUrlMap;
import onevz.soe.cart.model.retrieveCart.NbxInfo;
import onevz.soe.cart.model.retrieveCart.NumbershareInfo;
import onevz.soe.cart.model.retrieveCart.SubAccountInfo;
import onevz.soe.orderprocess.model.checkoutdetails.CartLineInfo;
import onevz.soe.orderprocess.model.checkoutdetails.ItemsInfo;
import onevz.soe.orderprocess.model.checkoutdetails.ServiceInfo;
import onevz.soe.orderprocess.response.cxp.CheckoutDetailsCXPResponse;
import org.springframework.beans.BeanUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class PrepayAdaptorOrderConfirmationRedesignUtil {

    private PrepayAdaptorOrderConfirmationRedesignUtil() {

    }

    public static OrderConfirmationCXPResponse formatOrderConfirmationCXPResponse(CheckoutDetailsCXPResponse checkoutDetailsCXPResponse) {
        OrderConfirmationCXPResponse orderConfirmationCXPResponse = new OrderConfirmationCXPResponse();
        CartHeader cartHeader = new CartHeader();
        CartOrderDetails cXPLineDetailsVO = new CartOrderDetails();
        CartOrderHeader cXPOrderDetails = new CartOrderHeader();
        NbxInfo nbxInfo = new NbxInfo();
        SubAccountInfo subAccountInfo = new SubAccountInfo();
        ConfirmationPageInfo confirmationPageInfo = new ConfirmationPageInfo();

        if (Objects.nonNull(checkoutDetailsCXPResponse) && Objects.nonNull(checkoutDetailsCXPResponse.getData())
                && Objects.nonNull(checkoutDetailsCXPResponse.getData().getCart())) {
            if (Objects.nonNull(checkoutDetailsCXPResponse.getData().getCart().getCartHeader())) {
                cartHeader.setSourceSystem(checkoutDetailsCXPResponse.getData().getCart().getCartHeader().getSourceSystem());
                cartHeader.setEmailAddress(checkoutDetailsCXPResponse.getData().getCart().getCartHeader().getEmailAddress());
                cartHeader.setCartCreatorChannelId(checkoutDetailsCXPResponse.getData().getCart().getCartHeader().getCartCreatorChannelId());
            }
            if (Objects.nonNull(checkoutDetailsCXPResponse.getData().getCart().getLineDetails())) {
                cXPLineDetailsVO.setNumOfLines(checkoutDetailsCXPResponse.getData().getCart().getLineDetails().getNumOfLines());
                cXPLineDetailsVO.setNumOfAccessoryAndDeviceItemsInCart(checkoutDetailsCXPResponse.getData().getCart().getLineDetails().getNumOfAccessoryAndDeviceItemsInCart());
                cXPLineDetailsVO.setIsAutoPayEnrolled(checkoutDetailsCXPResponse.getData().getCart().getLineDetails().getIsAutoPayEnrolled());
                if (Objects.nonNull(checkoutDetailsCXPResponse.getData().getCart().getLineDetails().getPayments())) {
                    List<CartPaymentInfo> paymentsVOList = new ArrayList<>();
                    checkoutDetailsCXPResponse.getData().getCart().getLineDetails().getPayments().forEach(paymentData -> {
                        CartPaymentInfo paymentsVO = new CartPaymentInfo();
                        paymentsVO.setPaymentSequence(paymentData.getPaymentSequence());
                        paymentsVO.setPaymentType(PaymentType.valueOf(paymentData.getPaymentType()));
                        paymentsVO.setPaymentAmount(paymentData.getPaymentAmount());
                        paymentsVO.setPaymRegisterNum(paymentData.getPaymRegisterNum());

                        if (Objects.nonNull(paymentData.getCreditCardDetails())) {
                            CreditCardPayment creditCardDetails = getCreditCardPaymentDetails(paymentData);
                            paymentsVO.setCreditCardDetails(creditCardDetails);
                        }

                        if (Objects.nonNull(paymentData.getPaypalPaymentDetails())) {
                            PaypalPaymentDetails paypalPaymentDetails = new PaypalPaymentDetails();
                            PaypalPaymentAuthenticateDetails paypalPaymentAuthenticateDetails = getPaypalPaymentAuthenticateDetails(paymentData);
                            paypalPaymentDetails.setPaypalPaymentAuthenticateDetails(paypalPaymentAuthenticateDetails);
                            paymentsVO.setPaypalPaymentDetails(paypalPaymentDetails);
                        }

                        if(Objects.nonNull(paymentData.getRefillCardPaymentDetails())){
                            paymentsVO.setRefillCardPaymentDetails(paymentData.getRefillCardPaymentDetails());
                        }
                        paymentsVOList.add(paymentsVO);
                    });
                    cXPLineDetailsVO.setPayments(paymentsVOList);
                }

                if (Objects.nonNull(checkoutDetailsCXPResponse.getData().getCart().getLineDetails().getLineInfo())) {
                    List<CartLine> lineInfoList = new ArrayList<>();
                    checkoutDetailsCXPResponse.getData().getCart().getLineDetails().getLineInfo().forEach(cartLineInfo -> {
                        CartLine lineInfo = new CartLine();
                        lineInfo.setMultiLineSeqNumber(cartLineInfo.getMultiLineSeqNumber());
                        lineInfo.setLineActivityType(PosLineActivity.valueOf(cartLineInfo.getLineActivityType()));
                        lineInfo.setPortinMtnAssignment(cartLineInfo.isPortinMtnAssignment());
                        lineInfo.setMobileNumber(cartLineInfo.getMobileNumber());
                        lineInfo.setIspuItem(cartLineInfo.isIspuItem());
                        lineInfo.setIspuItemBYOD(cartLineInfo.isIspuItemBYOD());
                        lineInfo.setIspuRepAssisted(cartLineInfo.isIspuRepAssisted());
                        lineInfo.setIsCpe(cartLineInfo.isCpe());
                        lineInfo.setTotalDueToday((float) cartLineInfo.getTotalDueToday());
                        lineInfo.setTotalDueTodayWithoutTax((float) cartLineInfo.getTotalDueTodayWithoutTax());
                        lineInfo.setTotalDueMonthly((float) cartLineInfo.getTotalDueMonthly());
                        lineInfo.setImpactedLine(cartLineInfo.isImpactedLine());
                        lineInfo.setPreOrBackOrder(cartLineInfo.isPreOrBackOrder());
                        lineInfo.setAccountOwner(cartLineInfo.getAccountOwner());
                        lineInfo.setModDevice(cartLineInfo.isModDevice());


                        if (Objects.nonNull(cartLineInfo.getServiceInfo())) {
                            lineInfo.setServiceInfo(getServiceInfo(cartLineInfo.getServiceInfo(),checkoutDetailsCXPResponse.getData().isEnableFamilyPricing()));
                        }

                        if (Objects.nonNull(cartLineInfo.getItemsInfo())) {
                            lineInfo.setItemsInfo(getItemsInfo(cartLineInfo.getItemsInfo()));
                        }
                        MtnDetails mtnDetails = getMtnDetails(cartLineInfo);
                        lineInfo.setMtnDetails(mtnDetails);

                        NumberShareDeviceInfo numberShareDeviceInfo = getNumberShareDeviceInfo(cartLineInfo);
                        lineInfo.setNumberShareDeviceInfo(numberShareDeviceInfo);

                        List<Charge> oneTimeCharges = getOneTimeCharges(cartLineInfo);
                        lineInfo.setOneTimeCharges(oneTimeCharges);
                        lineInfoList.add(lineInfo);
                    });
                    cXPLineDetailsVO.setLineInfo(lineInfoList);
                }

                cXPLineDetailsVO.setNumofLinesAAL(checkoutDetailsCXPResponse.getData().getCart().getLineDetails().getNumofLinesAAL()!=null?checkoutDetailsCXPResponse.getData().getCart().getLineDetails().getNumofLinesAAL():0);
                cXPLineDetailsVO.setNumofLinesEUP(checkoutDetailsCXPResponse.getData().getCart().getLineDetails().getNumofLinesEUP()!=null?checkoutDetailsCXPResponse.getData().getCart().getLineDetails().getNumofLinesEUP():0);
            }

            if (Objects.nonNull(checkoutDetailsCXPResponse.getData().getCart().getOrderDetails())) {
                cXPOrderDetails.setTotalTaxAmount(checkoutDetailsCXPResponse.getData().getCart().getOrderDetails().getTotalTaxAmount().toString());
                cXPOrderDetails.setLocationCode(checkoutDetailsCXPResponse.getData().getCart().getOrderDetails().getLocationCode());
                cXPOrderDetails.setTotalDueToday(checkoutDetailsCXPResponse.getData().getCart().getOrderDetails().getTotalDueToday().floatValue());
                cXPOrderDetails.setTotalDueMonthly(checkoutDetailsCXPResponse.getData().getCart().getOrderDetails().getTotalDueMonthly().floatValue());
                subAccountInfo.setTotalDueMonthly(checkoutDetailsCXPResponse.getData().getCart().getOrderDetails().getTotalDueMonthly());
                subAccountInfo.setTotalDueToday(checkoutDetailsCXPResponse.getData().getCart().getOrderDetails().getTotalDueToday());
                cXPOrderDetails.setOrderChannelId(checkoutDetailsCXPResponse.getData().getCart().getOrderDetails().getOrderChannelId());
                List<OrderDetails> orderList = getOrderList(checkoutDetailsCXPResponse);
                cXPOrderDetails.setOrderList(orderList);
                SpocsType spocsType = getSpocsType(checkoutDetailsCXPResponse);
                cXPOrderDetails.setSpocs(spocsType);
                cXPOrderDetails.setCustomerType(CartCustomerType.valueOf(checkoutDetailsCXPResponse.getData().getCart().getOrderDetails().getCustomerType()));
                cXPOrderDetails.setSubTotalDueToday((float) checkoutDetailsCXPResponse.getData().getCart().getOrderDetails().getSubTotalDueToday());
                cXPOrderDetails.setSplitShipmentIndicator(checkoutDetailsCXPResponse.getData().getCart().getOrderDetails().isSplitShipmentIndicator());
                cXPOrderDetails.setAssistanceOptedByCustomer(checkoutDetailsCXPResponse.getData().getCart().getOrderDetails().isAssistanceOptedByCustomer());
                cXPOrderDetails.setAssistanceOptedByCustomer(checkoutDetailsCXPResponse.getData().getCart().getOrderDetails().isAssistanceOptedByCustomer());
                DiscountSummary discountSummary = getDiscountSummary(checkoutDetailsCXPResponse);
                cXPOrderDetails.setCartTotalDiscounts(discountSummary);
                cXPOrderDetails.setTotalDueMonthlyAfterDiscounts(checkoutDetailsCXPResponse.getData().getCart().getOrderDetails().getTotalDueMonthlyAfterDiscounts());
            }

            if (Objects.nonNull(checkoutDetailsCXPResponse.getData().getCart().getOrderDetails()) && Objects.nonNull(checkoutDetailsCXPResponse.getData().getCart().getOrderDetails().getNbxInfo())) {
                nbxInfo.setSessionId(checkoutDetailsCXPResponse.getData().getCart().getOrderDetails().getNbxInfo().getSessionId());
            }

            if (checkoutDetailsCXPResponse.getData().getCart().isHolidayReturnPolicyEnabled()) {
             confirmationPageInfo.setHolidayReturnPolicyEnabled(checkoutDetailsCXPResponse.getData().getCart().isHolidayReturnPolicyEnabled());
            }
            else{
                confirmationPageInfo.setHolidayReturnPolicyEnabled(false);
            }

            if (checkoutDetailsCXPResponse.getData().getCart().isEnableIphoneSEPromo()) {
                confirmationPageInfo.setEnableIphoneSEPromo(checkoutDetailsCXPResponse.getData().getCart().isEnableIphoneSEPromo());
            }
            else{
                confirmationPageInfo.setEnableIphoneSEPromo(false);
            }

            confirmationPageInfo.setDevicePromotionId(checkoutDetailsCXPResponse.getData().getCart().getDevicePromotionId());

        }
        OrderConfirmationCXPData dataVO = new OrderConfirmationCXPData();

        Cart cart = new Cart();
        cart.setCartHeader(cartHeader);
        cart.setLineDetails(cXPLineDetailsVO);
        cart.setOrderDetails(cXPOrderDetails);
        confirmationPageInfo.setCartDetails(cart);
        dataVO.setGetConfirmationPage(confirmationPageInfo);
        orderConfirmationCXPResponse.setData(dataVO);
        return orderConfirmationCXPResponse;
    }

    private static PaypalPaymentAuthenticateDetails getPaypalPaymentAuthenticateDetails(onevz.soe.orderprocess.model.checkoutdetails.CartPaymentInfo paymentData) {
        PaypalPaymentAuthenticateDetails paypalPaymentAuthenticateDetails = new PaypalPaymentAuthenticateDetails();
        
        if(Objects.nonNull(paymentData.getPaypalPaymentDetails().getPaypalPaymentAuthenticateDetails())) {
            onevz.soe.orderprocess.model.checkoutdetails.PaypalPaymentAuthenticateDetails checkoutPaypalPaymentAuthenticationDetails = paymentData.getPaypalPaymentDetails().getPaypalPaymentAuthenticateDetails();
            BeanUtils.copyProperties(checkoutPaypalPaymentAuthenticationDetails,paypalPaymentAuthenticateDetails);
        }
        return paypalPaymentAuthenticateDetails;
    }

    private static CreditCardPayment getCreditCardPaymentDetails(onevz.soe.orderprocess.model.checkoutdetails.CartPaymentInfo paymentData) {
        CreditCardPayment creditCardDetails = new CreditCardPayment();
        creditCardDetails.setCardNumber(paymentData.getCreditCardDetails().getCardNumber());
        creditCardDetails.setCardAddressZip(paymentData.getCreditCardDetails().getCardAddressZip());
        creditCardDetails.setPreAuthCheck(paymentData.getCreditCardDetails().isPreAuthCheck());
        creditCardDetails.setVerizonIssuedCard(paymentData.getCreditCardDetails().isVerizonIssuedCard());
        creditCardDetails.setCardType(paymentData.getCreditCardDetails().getCardType());
        return creditCardDetails;
    }

    private static MtnDetails getMtnDetails(CartLineInfo cartLineInfo) {
        MtnDetails mtnDetails = new MtnDetails();
        if (Objects.nonNull(cartLineInfo.getMtnDetails())) {
            mtnDetails.setLineNumber(cartLineInfo.getMtnDetails().getLineNumber());
            mtnDetails.setNpaNXX(cartLineInfo.getMtnDetails().getNpaNXX());
            mtnDetails.setPortInDevice(cartLineInfo.getMtnDetails().isPortInDevice());
        }
        return mtnDetails;
    }

    private static NumberShareDeviceInfo getNumberShareDeviceInfo(CartLineInfo cartLineInfo) {
        NumberShareDeviceInfo numberShareDeviceInfo = new NumberShareDeviceInfo();
        if (Objects.nonNull(cartLineInfo.getNumberShareDeviceInfo())) {
            numberShareDeviceInfo.setName(cartLineInfo.getNumberShareDeviceInfo().getName());
            numberShareDeviceInfo.setLineNo(cartLineInfo.getNumberShareDeviceInfo().getLineNo());
        }
        return numberShareDeviceInfo;
    }

    private static List<Charge> getOneTimeCharges(CartLineInfo cartLineInfo) {
        List<Charge> oneTimeCharges = new ArrayList<>();
        if (Objects.nonNull(cartLineInfo.getOneTimeCharges())) {
            cartLineInfo.getOneTimeCharges().forEach(charges -> {
                Charge oneTimeCharge = new Charge();
                oneTimeCharge.setChargeType(charges.getChargeType());
                oneTimeCharge.setAmount((float) charges.getAmount());
                oneTimeCharge.setFinalPrice(oneTimeCharge.getFinalPrice());
                oneTimeCharges.add(oneTimeCharge);
            });
        }
        return oneTimeCharges;
    }

    private static List<OrderDetails> getOrderList(CheckoutDetailsCXPResponse checkoutDetailsCXPResponse) {
        List<OrderDetails> orderList = new ArrayList<>();
        if (Objects.nonNull(checkoutDetailsCXPResponse.getData().getCart().getOrderDetails().getOrderList())) {
            checkoutDetailsCXPResponse.getData().getCart().getOrderDetails().getOrderList().forEach(orderDetails -> {
                OrderDetails order = new OrderDetails();
                order.setOrderNumber(String.valueOf(orderDetails.getOrderNumber()));
                order.setOrderActivityType(PosLineActivity.valueOf(orderDetails.getOrderActivityType()));
                orderList.add(order);
            });
        }
        return orderList;
    }

    private static SpocsType getSpocsType(CheckoutDetailsCXPResponse checkoutDetailsCXPResponse) {
        SpocsType spocsType = new SpocsType();
        if (Objects.nonNull(checkoutDetailsCXPResponse.getData().getCart().getOrderDetails().getSpocs().getNotificationOptions())) {
            NotificationOptions notificationOptions = new NotificationOptions();
            notificationOptions.setPrimaryEmailId(checkoutDetailsCXPResponse.getData().getCart().getOrderDetails().getSpocs().getNotificationOptions().getPrimaryEmailId());
            notificationOptions.setContactPhoneNumber(checkoutDetailsCXPResponse.getData().getCart().getOrderDetails().getSpocs().getNotificationOptions().getContactPhoneNumber());
            spocsType.setNotificationOptions(notificationOptions);
        }
        return spocsType;
    }

    private static DiscountSummary getDiscountSummary(CheckoutDetailsCXPResponse checkoutDetailsCXPResponse) {
        DiscountSummary discountSummary = new DiscountSummary();
        if (Objects.nonNull(checkoutDetailsCXPResponse.getData().getCart().getOrderDetails().getCartTotalDiscounts())) {
            discountSummary.setTotalDiscount(checkoutDetailsCXPResponse.getData().getCart().getOrderDetails().getCartTotalDiscounts().getTotalDiscount());
            discountSummary.setTotalAccessoriesDiscount(checkoutDetailsCXPResponse.getData().getCart().getOrderDetails().getCartTotalDiscounts().getTotalAccessoriesDiscount());
            discountSummary.setTotalMultiLineDiscount(checkoutDetailsCXPResponse.getData().getCart().getOrderDetails().getCartTotalDiscounts().getTotalMultiLineDiscount());
            discountSummary.setSmartphoneTotalMLDiscount(checkoutDetailsCXPResponse.getData().getCart().getOrderDetails().getCartTotalDiscounts().getSmartphoneTotalMLDiscount()); //PREGRO-6434_Family_Pricing
            discountSummary.setTotalAutoPayDiscount(checkoutDetailsCXPResponse.getData().getCart().getOrderDetails().getCartTotalDiscounts().getTotalAutoPayDiscount());
            discountSummary.setAutoPayTotalAmount(checkoutDetailsCXPResponse.getData().getCart().getOrderDetails().getCartTotalDiscounts().getAutoPayTotalAmount());
            discountSummary.setTotalDevicesDiscount(checkoutDetailsCXPResponse.getData().getCart().getOrderDetails().getCartTotalDiscounts().getTotalDevicesDiscount());
            discountSummary.setTotalFutureDiscount(checkoutDetailsCXPResponse.getData().getCart().getOrderDetails().getCartTotalDiscounts().getTotalFutureDiscount());
            discountSummary.setFutureDiscountMonths(checkoutDetailsCXPResponse.getData().getCart().getOrderDetails().getCartTotalDiscounts().getFutureDiscountMonths());
            discountSummary.setTotalBundleDiscount(checkoutDetailsCXPResponse.getData().getCart().getOrderDetails().getCartTotalDiscounts().getTotalBundleDiscount());

        }
        return discountSummary;
    }

    private static List<CartItemInfo> getItemsInfo(ArrayList<ItemsInfo> itemsInfo) {
        List<CartItemInfo> itemInfoList = new ArrayList<>();
        itemsInfo.forEach(items -> {
            CartItemInfo cxpItemInfo = new CartItemInfo();
            CartShippingType cxpShippingVO = getShippingVO(items);
            cxpItemInfo.setShipping(cxpShippingVO);
            CartItemList cxpCartItemsVO = getCartItemList(items);
            cxpItemInfo.setCartItems(cxpCartItemsVO);

            itemInfoList.add(cxpItemInfo);
        });
        return itemInfoList;
    }

    private static CartShippingType getShippingVO(ItemsInfo items) {
        CartShippingType cxpShippingVO = new CartShippingType();
        if (Objects.nonNull(items.getShipping())) {
            cxpShippingVO.setShippingDescription(items.getShipping().getShippingDescription());
            cxpShippingVO.setShippingCost(String.valueOf(items.getShipping().getShippingCost()));
            cxpShippingVO.setDeliveryDate(items.getShipping().getEstDeliveryDate());
            cxpShippingVO.setIsValidAddress(items.getShipping().isValidAddress());
            cxpShippingVO.setIsUseUnVerifiedAddress(items.getShipping().isUseUnVerifiedAddress());
            cxpShippingVO.setLastName(items.getShipping().getLastName());
            cxpShippingVO.setShippingCode(items.getShipping().getShippingCode());
            cxpShippingVO.setFirstName(items.getShipping().getFirstName());
            cxpShippingVO.setCbrPhone(items.getShipping().getCbrPhone());
            AddressType address = getShippingAddress(items);
            cxpShippingVO.setAddress(address);
        }
        return cxpShippingVO;
    }

    private static AddressType getShippingAddress(ItemsInfo items) {
        AddressType address = new AddressType();
        if (Objects.nonNull(items.getShipping().getAddress())) {
            address.setLastName(items.getShipping().getAddress().getLastName());
            address.setFirstName(items.getShipping().getAddress().getFirstName());
            address.setStreetNumber(items.getShipping().getAddress().getStreetNumber());
            address.setStreetName(items.getShipping().getAddress().getStreetName());
            address.setAddressLine2(items.getShipping().getAddress().getAddressLine2());
            address.setAddressLine1(items.getShipping().getAddress().getAddressLine1());
            address.setCity(items.getShipping().getAddress().getCity());
            address.setState(items.getShipping().getAddress().getState());
            address.setZipCode(items.getShipping().getAddress().getZipCode());
            address.setEmailId(items.getShipping().getAddress().getEmailId());
            address.setPhoneNumber(items.getShipping().getAddress().getPhoneNumber());
        }
        return address;
    }

    private static CartItemList getCartItemList(ItemsInfo items) {
        CartItemList cxpCartItemsVO = new CartItemList();
        if (Objects.nonNull(items.getCartItems().getCartItem())) {
            List<CartItem> cxpCartItems = new ArrayList<>();
            items.getCartItems().getCartItem().forEach(cartItems -> {
                CartItem cxpCartItem = new CartItem();
                cxpCartItem.setItemCode(cartItems.getItemCode());
                cxpCartItem.setTotalPriceWithDiscount(cartItems.getTotalPriceWithDiscount());
                cxpCartItem.setSorId(cartItems.getSorId());
                cxpCartItem.setCartItemType(CartItemType.valueOf(cartItems.getCartItemType()));
                cxpCartItem.setDescription(cartItems.getDescription());
                cxpCartItem.setMobileNumber(cartItems.getMobileNumber());
                cxpCartItem.setQty(cartItems.getQty());
                cxpCartItem.setSimId(cartItems.getSimId());
                cxpCartItem.setESIM(cartItems.getEsimId());
                cxpCartItem.setEsimId(cartItems.getEsimId());
                cxpCartItem.setRequestedEsimImei(cartItems.getRequestedEsimImei());
                cxpCartItem.setSmartIMEI(cartItems.isSmartIMEI());
                cxpCartItem.setItemPrice(cartItems.getItemPrice());
                cxpCartItem.setDiscountedPrice(Float.parseFloat(null != cartItems.getDiscountedPrice() ? cartItems.getDiscountedPrice() : "0.0"));
                cxpCartItem.setBuyOutTaxAmountUnbilled(cartItems.getBuyOutTaxAmountUnbilled());
                cxpCartItem.setBuyOutAmountWithoutTax(cartItems.getBuyOutAmountWithoutTax());
                cxpCartItem.setTaxAmount(cartItems.getTaxAmount().floatValue());
                cxpCartItem.setBundleSeqNum(cartItems.getBundleSeqNum());
                cxpCartItem.setItemSeqNum((short) cartItems.getItemSeqNum());
                cxpCartItem.setCatalogPrice(cartItems.getCatalogPrice().floatValue());
                cxpCartItem.setItemCost(cartItems.getItemCost().floatValue());
                cxpCartItem.setItemNrpPrice(cartItems.getItemNrpPrice().floatValue());
                cxpCartItem.setSavingUpto( (cartItems.getItemNrpPrice().floatValue() - cartItems.getItemCost().floatValue() + ( (float)cartItems.getFutureDiscount() * (float)cartItems.getFutureDiscountMonths())));
                cxpCartItem.setYear(cartItems.getYear());
                cxpCartItem.setCapacity(cartItems.getCapacity());
                cxpCartItem.setIsCustomerProvidedSIM(cartItems.isIsCustomerProvidedSIM());
                cxpCartItem.setIsNetworkExtender(cartItems.isNetworkExtender());
                cxpCartItem.setDeviceDueMonthly(Float.parseFloat(null != cartItems.getDeviceDueMonthly() ? cartItems.getDeviceDueMonthly() : "0.0"));
                cxpCartItem.setDeviceDueToday(Float.parseFloat(null != cartItems.getDeviceDueToday() ? cartItems.getDeviceDueToday() : "0.0"));
                cxpCartItem.setManufacturer(cartItems.getManufacturer());
                cxpCartItem.setSorDeviceCategory(cartItems.getSorDeviceCategory());
                cxpCartItem.setSkuId(cartItems.getSkuId());
                cxpCartItem.setProductId(cartItems.getProductId());
                cxpCartItem.setQrScanNeededForEsimActivation(cartItems.isQrScanNeededForEsimActivation());
                cxpCartItem.setAppleCareAccessoryFlag(cartItems.isAppleCareAccessoryFlag());
                cxpCartItem.setIsCustomerProvidedSIM(cartItems.isIsCustomerProvidedSIM());
                cxpCartItem.setESimFlow(cartItems.isESimFlow());
                cxpCartItem.setFutureDiscount(cartItems.getFutureDiscount());
                cxpCartItem.setFutureDiscountMonths(cartItems.getFutureDiscountMonths());
                ImageUrlMap imageUrlMap = getImageUrlMap(cartItems);
                cxpCartItem.setImageUrlMap(imageUrlMap);
                ColorInfo itemColorVO = getColorInfo(cartItems);
                cxpCartItem.setColor(itemColorVO);
                if (Objects.nonNull(cartItems.getTaxDetailsList())) {
                    List<TaxDetailInfo> taxDetailsLists = getTaxDetailInfoList(cartItems);
                    cxpCartItem.setTaxDetailsList(taxDetailsLists);
                }
                cxpCartItems.add(cxpCartItem);
            });
            cxpCartItemsVO.setCartItem(cxpCartItems);
        }
        return cxpCartItemsVO;
    }

    private static ImageUrlMap getImageUrlMap(onevz.soe.orderprocess.model.checkoutdetails.CartItem cartItems) {
        ImageUrlMap imageUrlMap = new ImageUrlMap();
        if (Objects.nonNull(cartItems.getImageUrlMap())) {
            imageUrlMap.setDefaultImage(cartItems.getImageUrlMap().getDefaultImage());
            imageUrlMap.setLargeImage(cartItems.getImageUrlMap().getLargeImage());
            imageUrlMap.setMediumImage(cartItems.getImageUrlMap().getMediumImage());
            imageUrlMap.setMiniImage(cartItems.getImageUrlMap().getMiniImage());
            imageUrlMap.setThumbImage(cartItems.getImageUrlMap().getThumbImage());
        }
        return imageUrlMap;
    }

    private static ColorInfo getColorInfo(onevz.soe.orderprocess.model.checkoutdetails.CartItem cartItems) {
        ColorInfo itemColorVO = new ColorInfo();
        if (Objects.nonNull(cartItems.getColor())) {
            itemColorVO.setColorDisplayName(cartItems.getColor().getColorDisplayName());
        }
        return itemColorVO;
    }

    private static List<TaxDetailInfo> getTaxDetailInfoList(onevz.soe.orderprocess.model.checkoutdetails.CartItem cartItems) {
        List<TaxDetailInfo> taxDetailsLists = new ArrayList<>();
        cartItems.getTaxDetailsList().forEach(taxDetails -> {
            TaxDetailInfo taxDetail = new TaxDetailInfo();
            taxDetail.setTaxSequenceNum(taxDetails.getTaxSequenceNum());
            taxDetail.setTaxAmount(taxDetails.getTaxAmount());
            taxDetail.setTaxDescription(taxDetails.getTaxDescription());
            taxDetail.setMldSequenceNum(taxDetails.getMldSequenceNum());
            taxDetailsLists.add(taxDetail);
        });
        return taxDetailsLists;
    }

    private static CartServiceInfo getServiceInfo(ServiceInfo serviceInfo, boolean enableFamilyPricing) {
        CartServiceInfo cxpOrderConfirmationServiceInfo = new CartServiceInfo();
        cxpOrderConfirmationServiceInfo.setMtn(serviceInfo.getMtn());
        cxpOrderConfirmationServiceInfo.setIsSharePlanAdded(serviceInfo.isSharePlanAdded());
        PosCartPrimaryUserInfoType primaryUserInfo = getPrimaryUserInfo(serviceInfo);
        cxpOrderConfirmationServiceInfo.setPrimaryUserInfo(primaryUserInfo);
        CartFeatureList selectedFeaturesList = getFeatureList(serviceInfo);
        cxpOrderConfirmationServiceInfo.setSelectedFeaturesList(selectedFeaturesList);
        PosCartPricePlanInfoType pricePlanInfo = getPricePlanInfo(serviceInfo);
        cxpOrderConfirmationServiceInfo.setNewPricePlanInfo(pricePlanInfo);
        PlanDetails planDetails = getPlanDetails(serviceInfo,enableFamilyPricing);
        cxpOrderConfirmationServiceInfo.setPlanDetails(planDetails);
        AddressType serviceAddress = getServiceAddress(serviceInfo);
        cxpOrderConfirmationServiceInfo.setServiceAddress(serviceAddress);
        return cxpOrderConfirmationServiceInfo;
    }

    private static PosCartPrimaryUserInfoType getPrimaryUserInfo(ServiceInfo serviceInfo) {
        PosCartPrimaryUserInfoType primaryUserInfo = new PosCartPrimaryUserInfoType();
        if (Objects.nonNull(serviceInfo.getPrimaryUserInfo())) {
            primaryUserInfo.setFirstName(serviceInfo.getPrimaryUserInfo().getFirstName());
            primaryUserInfo.setLastName(serviceInfo.getPrimaryUserInfo().getLastName());
            primaryUserInfo.setEmailId(serviceInfo.getPrimaryUserInfo().getEmailId());
            AddressType address = getPrimaryUserAddress(serviceInfo);
            primaryUserInfo.setAddress(address);
        }
        return primaryUserInfo;
    }

    private static AddressType getPrimaryUserAddress(ServiceInfo serviceInfo) {
        AddressType address = new AddressType();
        if (Objects.nonNull(serviceInfo.getPrimaryUserInfo().getAddress())) {
            address.setStreetNumber(serviceInfo.getPrimaryUserInfo().getAddress().getStreetNumber());
            address.setStreetName(serviceInfo.getPrimaryUserInfo().getAddress().getStreetName());
            address.setAddressLine1(serviceInfo.getPrimaryUserInfo().getAddress().getAddressLine1());
            address.setAddressLine2(serviceInfo.getPrimaryUserInfo().getAddress().getAddressLine2());
            address.setCity(serviceInfo.getPrimaryUserInfo().getAddress().getCity());
            address.setState(serviceInfo.getPrimaryUserInfo().getAddress().getState());
            address.setZipCode(serviceInfo.getPrimaryUserInfo().getAddress().getZipCode());
            address.setEmailId(serviceInfo.getPrimaryUserInfo().getAddress().getEmailId());
            address.setPhoneNumber(serviceInfo.getPrimaryUserInfo().getAddress().getPhoneNumber());
            address.setFirstName(serviceInfo.getPrimaryUserInfo().getAddress().getFirstName());
            address.setLastName(serviceInfo.getPrimaryUserInfo().getAddress().getLastName());
        }
        return address;
    }

    private static CartFeatureList getFeatureList(ServiceInfo serviceInfo) {
        CartFeatureList selectedFeaturesList = new CartFeatureList();
        if (Objects.nonNull(serviceInfo.getSelectedFeaturesList())) {
            selectedFeaturesList.setFeaturesCount(serviceInfo.getSelectedFeaturesList().getFeaturesCount());
        }
        return selectedFeaturesList;
    }

    private static PosCartPricePlanInfoType getPricePlanInfo(ServiceInfo serviceInfo) {
        PosCartPricePlanInfoType pricePlanInfo = new PosCartPricePlanInfoType();
        if (Objects.nonNull(serviceInfo.getNewPricePlanInfo())) {
            pricePlanInfo.setPricePlanCode(serviceInfo.getNewPricePlanInfo().getPricePlanCode());
            pricePlanInfo.setPricePlanDesc(serviceInfo.getNewPricePlanInfo().getPricePlanDesc());
            pricePlanInfo.setPlanPrice(Float.parseFloat(null != serviceInfo.getNewPricePlanInfo().getPlanPrice() ? serviceInfo.getNewPricePlanInfo().getPlanPrice() : "0.0"));
            pricePlanInfo.setActualPlanPrice(serviceInfo.getNewPricePlanInfo().getActualPlanPrice());
            pricePlanInfo.setDataAllowance(serviceInfo.getNewPricePlanInfo().getDataAllowance());
            pricePlanInfo.setDisneyPlusPromo(serviceInfo.getNewPricePlanInfo().isDisneyPlusPromo());
            pricePlanInfo.setPlanDescription(serviceInfo.getNewPricePlanInfo().getPlanDescription());
            pricePlanInfo.setPromo300(serviceInfo.getNewPricePlanInfo().isPromo300());
            pricePlanInfo.setPlanBundleDiscount(serviceInfo.getNewPricePlanInfo().getPlanBundleDiscount());
            pricePlanInfo.setBundleDiscountEligible(serviceInfo.getNewPricePlanInfo().isBundleDiscountEligible());
        }
        return pricePlanInfo;
    }

    private static AddressType getServiceAddress(ServiceInfo serviceInfo) {
        AddressType serviceAddress = new AddressType();
        if (Objects.nonNull(serviceInfo.getServiceAddress())) {
            serviceAddress.setAddressLine1(serviceInfo.getServiceAddress().getAddressLine1());
            serviceAddress.setAddressLine2(serviceInfo.getServiceAddress().getAddressLine2());
            serviceAddress.setFirstName(serviceInfo.getServiceAddress().getFirstName());
            serviceAddress.setLastName(serviceInfo.getServiceAddress().getLastName());
            serviceAddress.setCity(serviceInfo.getServiceAddress().getCity());
            serviceAddress.setState(serviceInfo.getServiceAddress().getState());
            serviceAddress.setZipCode(serviceInfo.getServiceAddress().getZipCode());
        }
        return serviceAddress;
    }

    private static PlanDetails getPlanDetails(ServiceInfo serviceInfo, boolean enableFamilyPricing) {
        PlanDetails planDetails = new PlanDetails();
        if (Objects.nonNull(serviceInfo.getPlanDetails())) {
            planDetails.setPlanPrice(Float.valueOf(serviceInfo.getPlanDetails().getPlanPrice()));
            planDetails.setDiscountedPrice(serviceInfo.getPlanDetails().getDiscountedPrice());
            planDetails.setActualPlanPrice(serviceInfo.getPlanDetails().getActualPlanPrice());
            //Family_Pricing_Start
            if(enableFamilyPricing){
                planDetails.setDiscount(Double.valueOf(serviceInfo.getPlanDetails().getDiscount()));
                planDetails.setAutoPaySaving(serviceInfo.getPlanDetails().getAutoPaySaving());
                planDetails.setPlanMLDiscount(Double.valueOf(serviceInfo.getPlanDetails().getPlanMLDiscount()));
                planDetails.setPlanDiscountedPrice(Float.valueOf(serviceInfo.getPlanDetails().getPlanDiscountedPrice()));
                planDetails.setPlanMLPrice(serviceInfo.getPlanDetails().getPlanMLPrice());
            }
            //Family_Pricing_End //PREGRO-6434_Family_Pricing
            planDetails.setDisneyPlusPromo(serviceInfo.getPlanDetails().isDisneyPlusPromo());
            planDetails.setPlanBundleDiscount(serviceInfo.getPlanDetails().getPlanBundleDiscount());
            planDetails.setBundleDiscountEligible(serviceInfo.getPlanDetails().isBundleDiscountEligible());

        }
        return planDetails;
    }

}
