package onevz.soe.prepay.adaptor.cart.model.cxp.common;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Holds meta information of CXP/Pega
 * request and response.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MetaTag {

	private String user;
	private String client;
	private String timestamp;
	private String correlationId;
	private String clientCorrelationId;
	private String cxpCorrelationId;
	private List<CXPError> errors;
	private List<CXPWarning> warnings;

}
