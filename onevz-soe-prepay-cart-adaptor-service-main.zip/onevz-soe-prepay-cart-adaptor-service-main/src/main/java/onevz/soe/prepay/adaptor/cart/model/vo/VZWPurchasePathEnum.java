package onevz.soe.prepay.adaptor.cart.model.vo;

public enum VZWPurchasePathEnum {

	GG, AAL, EUP, NSE, CPC, SO, NSO, CPCONLY, DC, NPP, NSP, BBPORTAL, BUYSIM
}
