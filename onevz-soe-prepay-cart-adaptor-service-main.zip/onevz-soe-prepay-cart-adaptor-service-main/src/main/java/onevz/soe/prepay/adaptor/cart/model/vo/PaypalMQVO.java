package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;
import java.util.Date;

public class PaypalMQVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	Long centinelOrderId;
	String transactionId;
	String emailAddress;
	private String billingAddressValidated = "N";
	private int version;
	private Date lastModifiedDate;
	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}
	/**
	 * @param emailAddress the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	/**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}
	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	/**
	 * @return the centinelOrderId
	 */
	public Long getCentinelOrderId() {
		return centinelOrderId;
	}
	/**
	 * @param centinelOrderId the centinelOrderId to set
	 */
	public void setCentinelOrderId(Long centinelOrderId) {
		this.centinelOrderId = centinelOrderId;
	}
	public String getBillingAddressValidated() {
		return billingAddressValidated;
	}
	public void setBillingAddressValidated(String billingAddressValidated) {
		this.billingAddressValidated = billingAddressValidated;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	
}
