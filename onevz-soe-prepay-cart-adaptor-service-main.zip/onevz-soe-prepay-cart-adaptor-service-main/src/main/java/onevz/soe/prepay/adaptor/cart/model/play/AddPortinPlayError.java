package onevz.soe.prepay.adaptor.cart.model.play;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import onevz.soe.prepay.adaptor.cart.model.play.common.error.EcommApiError;

import java.util.List;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AddPortinPlayError {
    private Integer status;
    private List<EcommApiError> ecommApiErrorList;
}
