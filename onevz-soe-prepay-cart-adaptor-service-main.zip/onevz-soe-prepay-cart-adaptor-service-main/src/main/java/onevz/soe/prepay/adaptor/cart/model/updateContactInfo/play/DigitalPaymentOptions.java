package onevz.soe.prepay.adaptor.cart.model.updateContactInfo.play;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class DigitalPaymentOptions {
    private String applepayEnabled;

    private String applePayMerchantId;

    private String paypalEnabled;
}

