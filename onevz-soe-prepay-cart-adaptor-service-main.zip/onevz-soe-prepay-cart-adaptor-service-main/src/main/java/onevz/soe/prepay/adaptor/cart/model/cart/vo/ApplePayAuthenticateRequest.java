package onevz.soe.prepay.adaptor.cart.model.cart.vo;


public class ApplePayAuthenticateRequest {

	private String subService;
	private AccountInformation accountInformation;
	private ApplePayBillingInfo billingContact;
	private ApplePayBillingInfo shippingContact;
	private String orderId;
	private String flow;
	private boolean fromCart;
	private String playSessionId;

	public String getSubService() {
		return subService;
	}
	public void setSubService(String subService) {
		this.subService = subService;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}


	public AccountInformation getAccountInformation() {
		return accountInformation;
	}

	public void setAccountInformation(AccountInformation accountInformation) {
		this.accountInformation = accountInformation;
	}

	public ApplePayBillingInfo getBillingContact() {
		return billingContact;
	}

	public void setBillingContact(ApplePayBillingInfo billingContact) {
		this.billingContact = billingContact;
	}

	public String getFlow() {
		return flow;
	}

	public void setFlow(String flow) {
		this.flow = flow;
	}

	public ApplePayBillingInfo getShippingContact() {
		return shippingContact;
	}

	public void setShippingContact(ApplePayBillingInfo shippingContact) {
		this.shippingContact = shippingContact;
	}

	public boolean isFromCart() {
		return fromCart;
	}

	public void setFromCart(boolean fromCart) {
		this.fromCart = fromCart;
	}

	public String getPlaySessionId() {
		return playSessionId;
	}

	public void setPlaySessionId(String playSessionId) {
		this.playSessionId = playSessionId;
	}
}
