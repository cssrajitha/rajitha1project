package onevz.soe.prepay.adaptor.cart.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.assignmtn.reponse.pega.PortinPEGAResponse;
import onevz.soe.assignmtn.request.pega.PortinPEGARequest;
import onevz.soe.cart.requests.*;
import onevz.soe.cart.responses.*;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants;
import onevz.soe.prepay.adaptor.cart.exceptions.JsonValidator;
import onevz.soe.prepay.adaptor.cart.helper.*;
import onevz.soe.prepay.adaptor.cart.model.bpm.AddDeviceToPrepayODBpmRequest;
import onevz.soe.prepay.adaptor.cart.model.bpm.AddDeviceToPrepayODBpmResponse;
import onevz.soe.prepay.adaptor.cart.model.updateContactInfo.ContactInfoRequest;
import onevz.soe.prepay.adaptor.cart.model.updateContactInfo.ContactInfoResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import jakarta.validation.Valid;

import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.CHANNEL_ID;
import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_DATA;


/**
 * Cart Controller class.
 */
//NSADT-53978 removing CrossOrigin annotation in every service.
//@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping(value = "prepaid-adaptor")
public class PrepayAdaptorCartUpdateOperationsController {

	private static final Logger logger = LoggerFactory.getLogger(PrepayAdaptorCartUpdateOperationsController.class);


	@Autowired
	private ObjectMapper mapper;

	@Autowired
	JsonValidator validator;

	@Autowired
	private PrepayAdaptorCartAddPlanHelper planHelper;

	@Autowired
	private PrepayAdaptorCartAddDeviceHelper deviceHelper;

	@Autowired
	private PrepayAdaptorCartClearHelper clearCartHelper;

	@Autowired
	private	PrepayAdaptorCartAddFeaturesHelper addFeaturesHelper;

	@Autowired
	private PrepayAdaptorCartAddAccessoryHelper accessoryHelper;

	@Autowired
	private PrepayAdaptorAddPortinHelper addPortinHelper;

	@Autowired
	private PrepayAdaptorCartPersonalInfoHelper personalInfoHelper;

	@Autowired
	private PrepayAdaptorUpdateBarcodeHelper updateBarcodeHelper;
	
	@Autowired
	private PrepayAdaptorRemoveLinesHelper removeLinesHelper;
	
	@Autowired
	private PrepayAdaptorUpdateAccountOwnerHelper updateAccountOwnerHelper;

	@Autowired
	private PrepayAdaptorValidateZipCodeHelper validateZipCodeHelper;

	@Autowired
	private PrepayAdaptorCartSwitchSimHelper switchSimHelper;

	@Autowired
	PrepayCartRedisHelper prepayCartRedisHelper;

	/**
	 *
	 * @param binder
	 */
	@InitBinder("*")
	public void initBinderByName(WebDataBinder binder) {
		binder.setDisallowedFields(new String[] { "genericHeader" });
	}

	/**
	 *
	 * @param httpRequest
	 * @param httpResponse
	 * @param updatePersonalInfoRequest
	 * @return ResponseEntity
	 *
	 */
	@PostMapping({"/cart/personal-info"})
	public Mono<ResponseEntity<ContactInfoResponse>>  updatePersonalInfo(ServerHttpRequest httpRequest,
																		 ServerHttpResponse httpResponse,
																		 @Valid @RequestBody ContactInfoRequest updatePersonalInfoRequest) {
		System.setProperty(PrepayAdaptorCartConstants.ENDPOINT, "contact-info");
		logger.debug("personal-info Request: {}", updatePersonalInfoRequest);
		return personalInfoHelper.updatePersonalInfo(httpRequest, updatePersonalInfoRequest);
	}


	/**
	 *
	 * @param httpRequest
	 * @param httpResponse
	 * @param addPlanPEGARequest
	 * @return ResponseEntity
	 *
	 */
	@PostMapping({"/cart/add-plan"})
	public Mono<ResponseEntity<AddPlanPEGAResponse>> addPlan(ServerHttpRequest httpRequest,
															 ServerHttpResponse httpResponse,
															 @Valid @RequestBody AddPlanPEGARequest addPlanPEGARequest) {
		System.setProperty(PrepayAdaptorCartConstants.ENDPOINT, "add-plan");
		logger.debug("add-plan Request: {}", addPlanPEGARequest);

		return planHelper.addPlan(httpRequest, addPlanPEGARequest);
	}

	/**
	 *
	 * @param httpRequest
	 * @param httpResponse
	 * @param addDevicePEGARequest
	 * @return ResponseEntity
	 *
	 */
	@PostMapping({"/cart/add-device"})
	public Mono<ResponseEntity<AddDevicePEGAResponse>> addDevice(ServerHttpRequest httpRequest,
																 ServerHttpResponse httpResponse, @Valid @RequestBody AddDevicePEGARequest addDevicePEGARequest) {
		System.setProperty(PrepayAdaptorCartConstants.ENDPOINT, "add-device");
		logger.debug("add-device Request: {}", addDevicePEGARequest);

		return deviceHelper.addDevice(httpRequest, addDevicePEGARequest);
	}

	/**
	 *
	 * @param httpRequest
	 * @param httpResponse
	 * @param addDevicePrepayRequest
	 * @return ResponseEntity
	 *
	 */
	@PostMapping({"/cart/add-device-prepay"})
	public Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> addDeviceToPrepayOD(ServerHttpRequest httpRequest,
																					ServerHttpResponse httpResponse, @Valid @RequestBody AddDeviceToPrepayODBpmRequest addDevicePrepayRequest) {
		System.setProperty(PrepayAdaptorCartConstants.ENDPOINT, "add-device-prepay");
		logger.debug("add-device Request: {}", addDevicePrepayRequest);
		return deviceHelper.addDeviceToPrepayODMultiLine(httpRequest, addDevicePrepayRequest);
	}

	/**
	 *
	 * @param httpRequest
	 * @param httpResponse
	 * @param addAccessoryPEGARequest
	 * @return ResponseEntity
	 *
	 */
	@PostMapping({"/cart/add-accessories"})
	public Mono<ResponseEntity<AddAccessoriesPEGAResponse>> addAccessory(ServerHttpRequest httpRequest,
																		 ServerHttpResponse httpResponse, @Valid @RequestBody AddAccessoryPEGARequest addAccessoryPEGARequest) {
		System.setProperty(PrepayAdaptorCartConstants.ENDPOINT, "add-accessories");
		logger.debug("add-accessories Request: {}", addAccessoryPEGARequest);
		String channelId = httpRequest.getHeaders().containsKey(CHANNEL_ID)
				? httpRequest.getHeaders().getFirst(CHANNEL_ID)
				: "";
		logger.info("Adapter channel Id: {} ", channelId);
		return accessoryHelper.addAccessory(httpRequest, addAccessoryPEGARequest);

	}


	/**
	 *
	 * @param httpRequest
	 * @param httpResponse
	 * @param clearCartPEGARequest
	 * @return ResponseEntity
	 *
	 */
	@PostMapping({"/cart/clear"})
	public Mono<ResponseEntity<ClearCartPEGAResponse>> clearCart(ServerHttpRequest httpRequest,
																 ServerHttpResponse httpResponse, @Valid @RequestBody ClearCartPEGARequest clearCartPEGARequest) {
		System.setProperty(PrepayAdaptorCartConstants.ENDPOINT, "clearCart");
		logger.debug("clearCart Request: {}", clearCartPEGARequest);
		String channelId = httpRequest.getHeaders().containsKey(CHANNEL_ID)
				? httpRequest.getHeaders().getFirst(CHANNEL_ID)
				: "";
		logger.info("Adapter channel id: {} ", channelId);
		return clearCartHelper.clearCart(httpRequest, clearCartPEGARequest);
	}
	
	
    /**
     * @param httpRequest
     * @param httpResponse
     * @param request
     * @return ResponseEntity
     */
    @PostMapping({"/cart/removeLines"})
    public Mono<ResponseEntity<RemoveLinesPEGAResponse>> removeLines(ServerHttpRequest httpRequest,
                ServerHttpResponse httpResponse, @Valid @RequestBody RemoveLinesPEGARequest request) {
        System.setProperty(PrepayAdaptorCartConstants.ENDPOINT, "removeLines");
        logger.debug("removeLines Request: {}", request);
        String channelId = httpRequest.getHeaders().containsKey(CHANNEL_ID)
                ? httpRequest.getHeaders().getFirst(CHANNEL_ID)
                : "";
        logger.info("Adapter channel id: {} ", channelId);
        return removeLinesHelper.removeLines(httpRequest, request);
    }

	/**
	 *
	 * @param httpRequest
	 * @param httpResponse
	 * @param addFeaturesPEGARequest
	 * @return ResponseEntity
	 *
	 */
	@PostMapping({"/cart/add-features"})
	public Mono<ResponseEntity<AddFeaturesPEGAResponse>> addFeatures(ServerHttpRequest httpRequest,
																	 ServerHttpResponse httpResponse, @Valid @RequestBody AddFeaturesPEGARequest addFeaturesPEGARequest) {
		System.setProperty(PrepayAdaptorCartConstants.ENDPOINT, "add-features");
		logger.debug("add-features Request is: {} \n Response: {}",addFeaturesPEGARequest, addFeaturesPEGARequest);

		return addFeaturesHelper.addFeature(httpRequest, addFeaturesPEGARequest);
	}

	/**
	 *
	 * @param httpRequest
	 * @param httpResponse
	 * @param bpmServiceRequest
	 * @return ResponseEntity
	 *
	 */
	@PostMapping({"/cart/add-portin"})
		public Mono<ResponseEntity<PortinPEGAResponse>> addPortin(ServerHttpRequest httpRequest,
																		  ServerHttpResponse httpResponse, @Valid @RequestBody PortinPEGARequest bpmServiceRequest) {
		System.setProperty(PrepayAdaptorCartConstants.ENDPOINT, "add-portin");
		logger.debug("add-portin Request: {}", bpmServiceRequest);
		String channelId = httpRequest.getHeaders().containsKey(CHANNEL_ID)
				? httpRequest.getHeaders().getFirst(CHANNEL_ID)
				: "";
		logger.info("Adapter channel id: {} ", channelId);
		return addPortinHelper.addPortin(httpRequest, bpmServiceRequest);

	}
	
	/**
	 * Update Account Owner to update account Owner in case of multi-line scenario.
	 * @param httpRequest
	 * @param httpResponse
	 * @param accountOwnerRequest
	 * @return AccountOwnerPEGAResponse
	 *
	 */
	@PostMapping({"/cart/update-account-owner"})
		public Mono<ResponseEntity<AccountOwnerPEGAResponse>> updateAccountOwner(ServerHttpRequest httpRequest,
																		  ServerHttpResponse httpResponse, @Valid @RequestBody AccountOwnerPEGARequest accountOwnerRequest) {
		System.setProperty(PrepayAdaptorCartConstants.ENDPOINT, "update-account-owner");
		logger.debug("update-account-owner Request: {}", accountOwnerRequest);
		String channelId = httpRequest.getHeaders().containsKey(CHANNEL_ID)
				? httpRequest.getHeaders().getFirst(CHANNEL_ID)
				: "";
		logger.info("Adapter channel id: {} ", channelId);
		return updateAccountOwnerHelper.updateAccountOwner(httpRequest, accountOwnerRequest);

	}

	/**
	 * Update contact info details like email and phone number.
	 * @param httpRequest
	 * @param httpResponse
	 * @param request
	 * @return
	 */
	@PostMapping("/cart/updateBarcode")
	public Mono<UpdateBarCodePEGAResponse> updateBarcode(ServerHttpRequest httpRequest,
														 ServerHttpResponse httpResponse, @RequestBody UpdateBarCodePEGARequest request){
		logger.info("Start Adapter updateBarcode");
		logger.debug("updateBarcode Request: {}", request);
		Mono<ResponseEntity<UpdateBarCodePEGAResponse>> responseEntity = updateBarcodeHelper.updateBarcode(httpRequest, request);
		return responseEntity.flatMap(dataResponse-> {
			UpdateBarCodePEGAResponse response = new UpdateBarCodePEGAResponse();
			ObjectMapper mapper = new ObjectMapper();
			response = dataResponse.getBody();
			String responseString = "";
			try {
				responseString = mapper.writeValueAsString(response);
			} catch (JsonProcessingException e){
				logger.error("JSON Processing Error in update Barcode: {0}", e);
			}
			logger.info("updateBarcode response :  {}", responseString);
			return Mono.just(response);
		});
	}

	/**
	 * Update SimCard in Cart.
	 * @param httpRequest
	 * @param httpResponse
	 * @param 
	 * @return
	 */
	@PostMapping("/cart/switchSim")
	public Mono<ResponseEntity<SwitchSimCXPResponse>> switchSim(ServerHttpRequest httpRequest, ServerHttpResponse httpResponse,
														@RequestBody SwitchSimCXPRequest switchSimCXPRequest){
		System.setProperty(PrepayAdaptorCartConstants.ENDPOINT, "switchSim");
		logger.debug("switchSim Request: {}", switchSimCXPRequest);
		return switchSimHelper.switchSim(httpRequest, switchSimCXPRequest);

	}


	/**
	 *
	 * @param httpHeader
	 * @param httpResponse
	 * @return redisResponse
	 */
	@GetMapping("/paypaidODRequestData")
	public Mono<ResponseEntity<PrepaidODRequestData>> getPrepaidODRequestData(ServerHttpRequest httpHeader, ServerHttpResponse httpResponse) {
		System.setProperty(PrepayAdaptorCartConstants.ENDPOINT, "getPrepaidODRequestData");
		return prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)
				.doOnError(onError ->
					logger.error(" Unable to get data from Redis for PrepaidODRequestData {0}", onError))
				.defaultIfEmpty("")
				.flatMap(response -> {
					PrepaidODRequestData prepaidODRequestData = null;
					try {
						prepaidODRequestData = mapper.readValue(response, PrepaidODRequestData.class);
					} catch (JsonProcessingException e) {
						logger.error(" Unable to process redis response{0} ", e);
					}
					return Mono.just(ResponseEntity.ok(prepaidODRequestData));
				});
	}

	@PostMapping({"/cart/validateZipCode"})
	public Mono<ResponseEntity<AddZipcodeCXPResponse>> validateZipCode(ServerHttpRequest httpRequest, ServerHttpResponse httpResponse,
																	   @Valid @RequestBody AddZipcodeCXPRequest addZipcodeCXPRequest){
		System.setProperty(PrepayAdaptorCartConstants.ENDPOINT, "validateZipCode");
		logger.debug("validateZipCode and request {}", addZipcodeCXPRequest);
		return validateZipCodeHelper.validateZipCode(httpRequest, addZipcodeCXPRequest);

	}

}
