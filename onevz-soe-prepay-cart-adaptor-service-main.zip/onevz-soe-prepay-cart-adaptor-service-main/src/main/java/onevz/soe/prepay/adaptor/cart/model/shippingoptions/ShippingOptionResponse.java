package onevz.soe.prepay.adaptor.cart.model.shippingoptions;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import onevz.soe.prepay.adaptor.cart.model.cxp.common.MetaTag;
import onevz.soe.prepay.adaptor.cart.model.common.Errors;

import java.util.List;

/** 
 * class for ShippingOptionResponse contains meta and
 * shipping option data of CXP.
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ShippingOptionResponse {
    private MetaTag meta;
    private ShippingOptionResponseData data;
    private List<Errors> errors;
}
