/**
 * 
 */
package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;
import java.util.Date;

/**
 *
 */
public class ValidateMDNResponseVO implements Serializable {
	private static final long serialVersionUID = 1L;

	private int version;
	private String id;
	private String portEligibilityInd;
	private String rateCenter;
	private String lrnPostPaid;
	private String lrnPrePaid;
	private String sid;
	private String spidOcn;
	private String numberGroup;
	private String numberLOC;
	private String billingSystem;
	private String productType;
	private String etniValidationDate;
	private String wirelessInd;
	private String omin;
	private String state;
	private String formerCompanyCode;
	private Date authorizationDate;
	private String portInd;
	private String errorDesc;
	private String invItemCode;
	private String regionId;
	private String licenseAreaInd;

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public String getId() {
		return id;
	}

	public void setId(String pID) {
		this.id = pID;
	}

	public String getPortEligibilityInd() {
		return portEligibilityInd;
	}

	public void setPortEligibilityInd(String portEligibilityInd) {
		this.portEligibilityInd = portEligibilityInd;
	}

	public String getRateCenter() {
		return rateCenter;
	}

	public void setRateCenter(String rateCenter) {
		this.rateCenter = rateCenter;
	}

	public String getLrnPostPaid() {
		return lrnPostPaid;
	}

	public void setLrnPostPaid(String lrnPostPaid) {
		this.lrnPostPaid = lrnPostPaid;
	}

	public String getLrnPrePaid() {
		return lrnPrePaid;
	}

	public void setLrnPrePaid(String lrnPrePaid) {
		this.lrnPrePaid = lrnPrePaid;
	}

	public String getSid() {
		return sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public String getSpidOcn() {
		return spidOcn;
	}

	public void setSpidOcn(String spidOcn) {
		this.spidOcn = spidOcn;
	}

	public String getNumberGroup() {
		return numberGroup;
	}

	public void setNumberGroup(String numberGroup) {
		this.numberGroup = numberGroup;
	}

	public String getNumberLOC() {
		return numberLOC;
	}

	public void setNumberLOC(String numberLOC) {
		this.numberLOC = numberLOC;
	}

	public String getBillingSystem() {
		return billingSystem;
	}

	public void setBillingSystem(String billingSystem) {
		this.billingSystem = billingSystem;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getEtniValidationDate() {
		return etniValidationDate;
	}

	public void setEtniValidationDate(String etniValidationDate) {
		this.etniValidationDate = etniValidationDate;
	}

	public String getWirelessInd() {
		return wirelessInd;
	}

	public void setWirelessInd(String wirelessInd) {
		this.wirelessInd = wirelessInd;
	}

	public String getOmin() {
		return omin;
	}

	public void setOmin(String omin) {
		this.omin = omin;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getFormerCompanyCode() {
		return formerCompanyCode;
	}

	public void setFormerCompanyCode(String formerCompanyCode) {
		this.formerCompanyCode = formerCompanyCode;
	}

	public Date getAuthorizationDate() {
		return authorizationDate;
	}

	public void setAuthorizationDate(Date authorizationDate) {
		this.authorizationDate = authorizationDate;
	}

	public String getPortInd() {
		return portInd;
	}

	public void setPortInd(String portInd) {
		this.portInd = portInd;
	}

	public String getErrorDesc() {
		return errorDesc;
	}

	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}

	public String getInvItemCode() {
		return invItemCode;
	}

	public void setInvItemCode(String invItemCode) {
		this.invItemCode = invItemCode;
	}

	public String getRegionId() {
		return regionId;
	}

	public void setRegionId(String regionId) {
		this.regionId = regionId;
	}

	public String getLicenseAreaInd() {
		return licenseAreaInd;
	}

	public void setLicenseAreaInd(String licenseAreaInd) {
		this.licenseAreaInd = licenseAreaInd;
	}

	@Override
	public String toString() {
		return "ValidateMDNResponseVO [version=" + version + ", id=" + id + ", portEligibilityInd="
				+ portEligibilityInd + ", rateCenter=" + rateCenter + ", lrnPostPaid=" + lrnPostPaid + ", lrnPrePaid="
				+ lrnPrePaid + ", sid=" + sid + ", spidOcn=" + spidOcn + ", numberGroup=" + numberGroup
				+ ", numberLOC=" + numberLOC + ", billingSystem=" + billingSystem + ", productType=" + productType
				+ ", etniValidationDate=" + etniValidationDate + ", wirelessInd=" + wirelessInd + ", omin=" + omin
				+ ", state=" + state + ", formerCompanyCode=" + formerCompanyCode + ", authorizationDate="
				+ authorizationDate + ", portInd=" + portInd + ", errorDesc=" + errorDesc + ", invItemCode="
				+ invItemCode + ", regionId=" + regionId + ", licenseAreaInd=" + licenseAreaInd + "]";
	}

}
