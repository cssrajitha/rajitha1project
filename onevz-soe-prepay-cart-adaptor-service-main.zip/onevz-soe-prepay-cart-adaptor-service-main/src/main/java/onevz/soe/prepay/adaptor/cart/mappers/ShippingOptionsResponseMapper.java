package onevz.soe.prepay.adaptor.cart.mappers;

import onevz.soe.prepay.adaptor.cart.model.play.shippingoptions.ShippingOptionsResponse;
import onevz.soe.prepay.adaptor.cart.model.shippingoptions.ShippingOptionResponseData;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface ShippingOptionsResponseMapper {

    ShippingOptionResponseData playShippingOptionsResponseToSOEShippingOptionResponseData(ShippingOptionsResponse source);

    @InheritInverseConfiguration(name = "playShippingOptionsResponseToSOEShippingOptionResponseData")
    ShippingOptionsResponse soeSDDAvailableWindowsToAvailableDeliveryWindows(ShippingOptionResponseData source);

}
