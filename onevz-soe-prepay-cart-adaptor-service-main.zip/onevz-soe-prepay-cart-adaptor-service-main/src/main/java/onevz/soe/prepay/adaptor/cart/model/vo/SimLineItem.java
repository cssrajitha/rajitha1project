package onevz.soe.prepay.adaptor.cart.model.vo;

import java.util.Date;

public class SimLineItem extends OrderLineItem{

	private static final long serialVersionUID = 1L;
	private String simId;
	private boolean newSim = true;
	private String category;
	private String saccCode;
	private Date lastModifiedDate;
	private String deviceLineItemId;
	private boolean cpe;
	private String iccid;
	private String displayName;
	
	public SimLineItem() {		
	}

	@Override
	public String getDisplayName() {
		return displayName;
	}

	@Override
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public SimLineItem(String id) {
		this.setId(id);
	}
	
	public String getSimId() {
		return simId;
	}

	public void setSimId(String simId) {
		this.simId = simId;
	}

	public boolean isNewSim() {
		return newSim;
	}

	public void setNewSim(boolean newSim) {
		this.newSim = newSim;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getSaccCode() {
		return saccCode;
	}

	public void setSaccCode(String saccCode) {
		this.saccCode = saccCode;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getDeviceLineItemId() {
		return deviceLineItemId;
	}

	public void setDeviceLineItemId(String deviceLineItemId) {
		this.deviceLineItemId = deviceLineItemId;
	}	
	
	public boolean isCpe() {
		return cpe;
	}

	public void setCpe(boolean cpe) {
		this.cpe = cpe;
	}

	public String getIccid() {
		return iccid;
	}

	public void setIccid(String iccid) {
		this.iccid = iccid;
	}
}
