package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;

public class Reason implements Serializable {
    private String code;
    private String desc;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
