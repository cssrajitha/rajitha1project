package onevz.soe.prepay.adaptor.cart.helper;

import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_DATA;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.hc.core5.http.ContentType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import onevz.soe.cart.model.accountOwner.AccountOwnerContext;
import onevz.soe.cart.model.accountOwner.AccountOwnerServiceBody;
import onevz.soe.cart.model.accountOwner.AccountOwnerServiceResponse;
import onevz.soe.cart.model.common.CartServiceCartInfo;
import onevz.soe.cart.model.common.CartServiceContextInfo;
import onevz.soe.cart.model.common.CartServiceCustomerInfo;
import onevz.soe.cart.model.common.CartServiceServiceHeader;
import onevz.soe.cart.model.common.ProcessMTNList;
import onevz.soe.cart.requests.AccountOwnerPEGARequest;
import onevz.soe.cart.responses.AccountOwnerPEGAResponse;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.common.model.PrepaidODRequestDataLines;
import onevz.soe.od.model.VZWPrepayAccountOwnerRequest;
import onevz.soe.prepay.adaptor.cart.util.PrepayAdaptorCartUtil;
import onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.bpm.model.response.AvailablePaths;
import onevz.soe.wsclient.bpm.model.response.Error;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import onevz.soe.wsclient.prepay.webclient.model.PrepaidAdaptorWebClientRequest;
import reactor.core.publisher.Mono;

@Service
public class PrepayAdaptorUpdateAccountOwnerHelper {
	
	 @Autowired
	    private ObjectMapper mapper;

	    @Autowired
	    SOELoginSessionBean sessionBean;

	    @Autowired
	    PrepayCartRedisHelper prepayCartRedisHelper;
	    
	    @Autowired
	    private PrepayAdaptorWebClient prepayAdaptorWebClient;
	    
	    @Value("${playPrepaidEditCart}")
	    private String playPrepaidEditCart;
	    
	    private static final Logger logger = LoggerFactory.getLogger(PrepayAdaptorUpdateAccountOwnerHelper.class);

	    public Mono<ResponseEntity<AccountOwnerPEGAResponse>> updateAccountOwner(ServerHttpRequest httpRequest, AccountOwnerPEGARequest request) {
	        
	        return prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)
	                .doOnError(onError -> logger.error("Unable to get data from Redis in UpdateAccountOwner Service: {}", onError.getMessage()))
	                .doOnSuccess(onSuccess -> logger.info("Successfully retrieved data from Redis in UpdateAccountOwner Service: {}", onSuccess))
	                .flatMap(redisResponse->{
	                    logger.info("UpdateAccountOwner Service redisData : {}", redisResponse);
	                    
	                    if(StringUtilities.isEmptyOrNull(redisResponse)) {
	                        AccountOwnerPEGAResponse accountOwnerPEGAResponse = new AccountOwnerPEGAResponse();
	                        return Mono.just(ResponseEntity.status(HttpStatus.OK).body(accountOwnerPEGAResponse));
	                    } else {
	                        PrepaidODRequestData redisData = null;

	                        try {
	                            redisData = mapper.readValue(redisResponse, PrepaidODRequestData.class);
	                        } catch (JsonProcessingException e) {
	                        	PrepayAdaptorCartUtil.buildErrorResponse(PrepayAdaptorCartConstants.ACCOUNT_OWNER_ERROR_NAME, 
	                        											 PrepayAdaptorCartConstants.ACCOUNT_OWNER_ERROR_ID, 
	                        											 PrepayAdaptorCartConstants.ACCOUNT_OWNER_ERROR_MSG, 
	                        											 PrepayAdaptorCartConstants.ACCOUNT_OWNER_SYSTEM_ERROR_CATEGORY);
	                        
	                        	logger.error("UpdateAccount Owner: JSON Processing exception while mapping redisData to PrepaidODRequest Data object: {}",e.getMessage());
	                        }
	                        VZWPrepayAccountOwnerRequest vzwPrepayAccountQwnerRequest = getVZWPrepayAccountOwnerRequest(request, redisData);
	                        PrepaidAdaptorWebClientRequest prepaidLegacyServiceRequest = getPrepaidLegacyServiceRequest(vzwPrepayAccountQwnerRequest, redisData);
	                        logger.info("Update AccountOwner OD Request URL: {}, Request body: {}, Request headers: {}",
	                        		prepaidLegacyServiceRequest.getUrl(),prepaidLegacyServiceRequest.getRequestBody(),prepaidLegacyServiceRequest.getHeader());
	                        try {
	                        return updateAccountOwnerODCall(httpRequest, prepaidLegacyServiceRequest, request, redisData);
	                        } catch(Exception ex) {
	                        	AccountOwnerPEGAResponse errorPEGAResponse = new AccountOwnerPEGAResponse();
	                        	logger.error("UpdateAccount Owner: Exception while invoking editCart OD call: {}",ex.getMessage());
	                        	return callSystemErrorResponse(errorPEGAResponse);
	                        }
	                    }
	          });
	    }
	    
	    private Mono<ResponseEntity<AccountOwnerPEGAResponse>> updateAccountOwnerODCall(
				ServerHttpRequest httpRequest, PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest,
				AccountOwnerPEGARequest request, PrepaidODRequestData redisData) {
	    	
	      	return prepayAdaptorWebClient.getPrepayServiceResponse(httpRequest, prepaidAdaptorWebClientRequest)
	                .doOnError(error -> logger.error("Failed to get response", error))
	                .flatMap(responseEntity-> {
	                	AccountOwnerPEGAResponse accountOwnerPEGAResponse = new AccountOwnerPEGAResponse();
	                    logger.info("Update Account Owner OD call Response body: {} \n Response Code: {} \n",responseEntity.getBody(),responseEntity.getStatusCode());
	             
	                    try {
	                    	
	                        if (!responseEntity.getStatusCode().is2xxSuccessful()) {
	                            logger.error("Error while calling endpoint: {} with status code: {}",
	                                    prepaidAdaptorWebClientRequest.getUrl(), responseEntity.getStatusCode());
	                            return callSystemErrorResponse(accountOwnerPEGAResponse);
	 
	                        } else {
	                        	
	                            String responseString = responseEntity.getBody();
	                            
	                            if(!StringUtilities.isEmptyOrNull(responseString)) {
	                            	JsonNode responseNode = mapper.readValue(responseString, JsonNode.class);
	                            	JsonNode errorNode = responseNode.get("error");
	                            	JsonNode payloadNode = responseNode.get("payload");
	                            	JsonNode pageDataNode = payloadNode.get("pageData");
	                            	
	                            	if(Objects.nonNull(errorNode) && Objects.isNull(payloadNode)) {
	                            		return callBusErrorResponse(accountOwnerPEGAResponse);
	                            	} else {
	                            		
	                            		if(Objects.nonNull(Objects.nonNull(request) && Objects.nonNull(request.getServiceBody()) && Objects.nonNull(request.getServiceBody().getServiceRequest()) 
	                        					&& Objects.nonNull(request.getServiceBody().getServiceRequest().getContext()) 
	                        					&& Objects.nonNull(request.getServiceBody().getServiceRequest().getContext().getCartInfo()))) {
		                            		List<PrepaidODRequestDataLines> dataLines = redisData.getLines();
									        List<PrepaidODRequestDataLines> linesToProcess = redisData.getLines().stream().filter(line-> line.getMtn().equalsIgnoreCase(request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getMtn())).collect(Collectors.toList());
								            PrepaidODRequestDataLines lineToProcess = linesToProcess.get(0);
								            lineToProcess.setAccountOwner(true);
								            (lineToProcess.getCompletedProcessSteps()).add(PrepayAdaptorCartConstants.ACCOUNT_OWNER_EDIT_FLOW_NAME);
								            dataLines.set(dataLines.indexOf(lineToProcess), lineToProcess);
			                                redisData.setLines(dataLines);
			                                redisData.setAccountOwner(lineToProcess.getMtn());
	                            		}
	                                    return updatePrepayODDataInRedis(request, redisData, pageDataNode);						        
	                            		
	                            		
	                            	}
	                            } else {
	                        	logger.error("update Account Owner OD response is empty");
	                        	return callSystemErrorResponse(accountOwnerPEGAResponse);
	                            }
	                        }

	                    } catch (JsonMappingException e) {
	                        logger.info("Json Mapping Error: {}", e.getMessage());
	                        return callSystemErrorResponse(accountOwnerPEGAResponse);
	                    } catch (JsonProcessingException e) {
	                        logger.info("JsonProcessing Error: {}", e.getMessage());
	                        return callSystemErrorResponse(accountOwnerPEGAResponse);
	                    }
	                });
		}

		private Mono<? extends ResponseEntity<AccountOwnerPEGAResponse>> updatePrepayODDataInRedis(
				AccountOwnerPEGARequest request, PrepaidODRequestData redisData, JsonNode pageDataNode) {
			return prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, redisData)
				  .doOnError(err -> logger.error("Failed to update the PrepaidODRequestData to Redis", err))
				  .flatMap(upsertResp -> 
				  {
					  logger.info("Successfully inserted updated Redis Data: {}",upsertResp);
					if(pageDataNode.get("accountOwnerUpdate").booleanValue()) {
			    		logger.info("AccountOwner Updated successfully");
			    		return Mono.just(ResponseEntity.status(HttpStatus.OK).body(getAccountOwnerPEGAResponse(true,request,redisData)));
					} else {
					  logger.info("Failed to update AccountOwner");
					return Mono.just(ResponseEntity.status(HttpStatus.OK).body(getAccountOwnerPEGAResponse(false,request,redisData)));	  
					}	  
				  });
		}

		private Mono<? extends ResponseEntity<AccountOwnerPEGAResponse>> callBusErrorResponse(
				AccountOwnerPEGAResponse accountOwnerPEGAResponse) {
			List<Error> errors = PrepayAdaptorCartUtil.buildErrorResponse(PrepayAdaptorCartConstants.ACCOUNT_OWNER_ERROR_NAME, 
				 PrepayAdaptorCartConstants.ACCOUNT_OWNER_ERROR_ID, 
				 PrepayAdaptorCartConstants.ACCOUNT_OWNER_ERROR_MSG, 
				 PrepayAdaptorCartConstants.ACCOUNT_OWNER_BUS_ERROR_CATEGORY);
                    	accountOwnerPEGAResponse.setErrors(errors);
                     return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(accountOwnerPEGAResponse));
		}

		private Mono<? extends ResponseEntity<AccountOwnerPEGAResponse>> callSystemErrorResponse(
				AccountOwnerPEGAResponse accountOwnerPEGAResponse) {
			List<Error> errors = PrepayAdaptorCartUtil.buildErrorResponse(PrepayAdaptorCartConstants.ACCOUNT_OWNER_ERROR_NAME, 
					 PrepayAdaptorCartConstants.ACCOUNT_OWNER_ERROR_ID, 
					 PrepayAdaptorCartConstants.ACCOUNT_OWNER_ERROR_MSG, 
					 PrepayAdaptorCartConstants.ACCOUNT_OWNER_SYSTEM_ERROR_CATEGORY);
			accountOwnerPEGAResponse.setErrors(errors);
			return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(accountOwnerPEGAResponse));
		}

		private AccountOwnerPEGAResponse getAccountOwnerPEGAResponse(boolean accountOwnerUpdated, AccountOwnerPEGARequest request,
				PrepaidODRequestData redisData) {
			
			AccountOwnerPEGAResponse accountOwnerPEGAResponse = new AccountOwnerPEGAResponse();
			AccountOwnerServiceBody serviceBody = new AccountOwnerServiceBody();
			AccountOwnerServiceResponse serviceResponse = new AccountOwnerServiceResponse();
			AccountOwnerContext context = new AccountOwnerContext();
			List<ProcessMTNList> processMTNList = new ArrayList<>();
			ProcessMTNList processMTN = new ProcessMTNList();
			CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
			CartServiceCartInfo cartInfo = new CartServiceCartInfo();
			
						
			CartServiceServiceHeader header = buildUpdateAccountOwnerServiceHeader(accountOwnerUpdated, request);
			
			//Build Customer Info && ProcessMtnList
			if(Objects.nonNull(request) && Objects.nonNull(request.getServiceBody()) && Objects.nonNull(request.getServiceBody().getServiceRequest()) 
					&& Objects.nonNull(request.getServiceBody().getServiceRequest().getContext()) 
					&& Objects.nonNull(request.getServiceBody().getServiceRequest().getContext().getCustomerInfo())) {
				customerInfo.setRegisterNumber(request.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getRegisterNumber());
				customerInfo.setCartCreator(request.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCartCreator());
				customerInfo.setGlobalId(request.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getGlobalId());
				customerInfo.setCustomerType(request.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCustomerType());
				customerInfo.setMtn(request.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getMtn());
			}
			if(Objects.nonNull(redisData) && Objects.nonNull(redisData.getLines()) && !redisData.getLines().isEmpty()) {
				customerInfo.setProcessingMTN(redisData.getLines().get(0).getMtn());
				processMTN.setMtn(redisData.getLines().get(0).getMtn());
				
				
			} else {
				if(Objects.nonNull(request) && Objects.nonNull(request.getServiceBody()) && Objects.nonNull(request.getServiceBody().getServiceRequest()) 
						&& Objects.nonNull(request.getServiceBody().getServiceRequest().getContext()) 
						&& Objects.nonNull(request.getServiceBody().getServiceRequest().getContext().getCustomerInfo())) {
					customerInfo.setProcessingMTN(request.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getProcessingMTN());
					processMTN.setMtn(request.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getProcessingMTN());
				}
			}
				
			//Build Context Info
			CartServiceContextInfo contextInfo = buildUpdateAccountOwnerContextInfo(request);
			//Build Cart Info
			if(Objects.nonNull(request) && Objects.nonNull(request.getServiceBody()) && Objects.nonNull(request.getServiceBody().getServiceRequest()) 
					&& Objects.nonNull(request.getServiceBody().getServiceRequest().getContext()) 
					&& Objects.nonNull(request.getServiceBody().getServiceRequest().getContext().getCartInfo())) {
				cartInfo.setAction(PrepayAdaptorCartConstants.ACCOUNT_OWNER_EDIT_FLOW_NAME);
				cartInfo.setIntendType(request.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
				cartInfo.setMtn(request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getMtn());
				
				if(Objects.nonNull(redisData) && Objects.nonNull(redisData.getLines())) {
					cartInfo.setCartItemCount(redisData.getLines().size());
					List<List<String>> completedStepsList = redisData.getLines().stream().filter(dataLines -> dataLines.getMtn().equalsIgnoreCase(request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getMtn())).map(PrepaidODRequestDataLines::getCompletedProcessSteps).collect(Collectors.toList());
					String[] completedSteps = completedStepsList.get(0).toArray(new String[completedStepsList.get(0).size()]);
					logger.info("Completed Process Steps in Update Account Owner: {}",Arrays.toString(completedSteps));
					processMTN.setCompletedprocessSteps(completedSteps);
				}							
			}
			processMTNList.add(processMTN);
			// Build Service Body
			context.setCustomerInfo(customerInfo);
			context.setContextInfo(contextInfo);
			context.setCartInfo(cartInfo);
			context.setProcessMTNList(null);
			serviceResponse.setContext(context);
			serviceBody.setServiceResponse(serviceResponse);
			accountOwnerPEGAResponse.setServiceBody(serviceBody);
			accountOwnerPEGAResponse.setServiceHeader(header);
			logger.info("Final response from update Account Owner: {}",accountOwnerPEGAResponse);
			return accountOwnerPEGAResponse;
		}

		private CartServiceContextInfo buildUpdateAccountOwnerContextInfo(AccountOwnerPEGARequest request) {
			CartServiceContextInfo contextInfo = new CartServiceContextInfo();
			if(Objects.nonNull(request) && Objects.nonNull(request.getServiceBody()) && Objects.nonNull(request.getServiceBody().getServiceRequest()) 
					&& Objects.nonNull(request.getServiceBody().getServiceRequest().getContext()) 
					&& Objects.nonNull(request.getServiceBody().getServiceRequest().getContext().getContextInfo())) {
				contextInfo.setCallReason(request.getServiceBody().getServiceRequest().getContext().getContextInfo().getCallReason());
				contextInfo.setIntent(request.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
			}
			List<AvailablePaths> availablePaths = new ArrayList<>();
			AvailablePaths availablePath = new AvailablePaths();
			availablePath.setPath(PrepayAdaptorCartConstants.CHECKOUT_PLAN_PROCESS_STEP);
			availablePaths.add(availablePath);
			contextInfo.setAvailablePaths(availablePaths);
			contextInfo.setProcessStep(PrepayAdaptorCartConstants.CHECKOUT_PLAN_PROCESS_STEP);
			contextInfo.setProcessAction("");
			return contextInfo;
		}

		private CartServiceServiceHeader buildUpdateAccountOwnerServiceHeader(boolean accountOwnerUpdated, AccountOwnerPEGARequest request) {
			CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
			//Build Service Header
			if(Objects.nonNull(request) && Objects.nonNull(request.getServiceHeader())) {
				serviceHeader.setClientId(request.getServiceHeader().getClientId());
				serviceHeader.setCorrelationId(request.getServiceHeader().getCorrelationId());
				serviceHeader.setServiceName(request.getServiceHeader().getServiceName());
				serviceHeader.setSessionId(request.getServiceHeader().getSessionId());
				serviceHeader.setUserId(request.getServiceHeader().getUserId());
			}
			if(accountOwnerUpdated) {
				serviceHeader.setStatusCode(PrepayAdaptorCartConstants.RESPONSE_SUCCESS_CODE);
				serviceHeader.setStatusMsg(PrepayAdaptorCartConstants.SUCCESS_MSG);
			} else {
				serviceHeader.setStatusCode(PrepayAdaptorCartConstants.RESPONSE_FAILURE_CODE);
				serviceHeader.setStatusMsg(PrepayAdaptorCartConstants.FAILURE_MSG);
			}
			return serviceHeader;
		}

		private VZWPrepayAccountOwnerRequest getVZWPrepayAccountOwnerRequest(AccountOwnerPEGARequest request,PrepaidODRequestData redisData) {
			
			VZWPrepayAccountOwnerRequest accountOwnerODRequest = new VZWPrepayAccountOwnerRequest();
						
			if((Objects.nonNull(request))&&(Objects.nonNull(request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()))) {
						String mtn = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getMtn();
						//String lineItemId = redisData.getLines().stream().filter(dataLines -> dataLines.getMtn().equalsIgnoreCase(mtn)).map(lineToProcess -> lineToProcess.getLineItemId()).toString();
						String lineItemId = redisData.getLines().stream().filter(dataLines -> dataLines.getMtn().equalsIgnoreCase(mtn)).collect(Collectors.toList()).get(0).getLineItemId();
						logger.info("Line Item ID for the new Account Owner: {} for mtn: {}",lineItemId, mtn);
						
						if( "Y".equalsIgnoreCase(request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getAccountOwner())) {
							accountOwnerODRequest.setLineItemId(lineItemId);
							accountOwnerODRequest.setEditFlowName(PrepayAdaptorCartConstants.ACCOUNT_OWNER_EDIT_FLOW_NAME);
						}

			}
			return accountOwnerODRequest;
		}

		private PrepaidAdaptorWebClientRequest getPrepaidLegacyServiceRequest(VZWPrepayAccountOwnerRequest request, PrepaidODRequestData redisData) {
	        PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
	        Map<String,String> headers = new HashMap<>();
	        String flow="";
	        String flowName = Objects.nonNull(redisData) && CollectionUtilities.isNotEmptyOrNull(redisData.getLines())?redisData.getLines().get(redisData.getCurr_line()-1).getFlow():PrepayAdaptorCartConstants.NSE;

			flow = PrepayAdaptorCartUtil.getODFlowName(flowName);
			if(Objects.nonNull(redisData)) {
	        headers.put(PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_P_CSRF_TOKEN, redisData.getPCsrfToken());
	        String prepayODCookie = PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_ECOMM_SESSION + "=" + redisData.getEcommSessionId() + ";"
										+ PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_FLOW + "=" + flow + ";"
										+ PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_P_CSRFTKN + "=" + redisData.getPCsrfToken();
	        headers.put("Cookie", prepayODCookie);
			}
	        headers.put("Content-Type", String.valueOf(ContentType.APPLICATION_JSON));
	        prepaidAdaptorWebClientRequest.setUrl(playPrepaidEditCart);
	        prepaidAdaptorWebClientRequest.setRequestBody(request);
	        prepaidAdaptorWebClientRequest.setRequestType("POST");
	        prepaidAdaptorWebClientRequest.setHeader(headers);
	        return prepaidAdaptorWebClientRequest;
	    }


}
