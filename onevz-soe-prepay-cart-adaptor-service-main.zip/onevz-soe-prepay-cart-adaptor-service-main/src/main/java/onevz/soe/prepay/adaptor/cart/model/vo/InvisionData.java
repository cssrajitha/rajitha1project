package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;
import java.util.List;

public class InvisionData implements Serializable {
    private List<String> actionScore;
    private String trackingNumber;
    private String otpStatus;
    private String creditAppNumber;
    private String phoneNumber;
    private int retryCount;
     private int validationRetryCount;

    public int getRetryCount() {
        return retryCount;
    }

    public void setRetryCount(int retryCount) {
        this.retryCount = retryCount;
    }

    public int getValidationRetryCount() {
        return validationRetryCount;
    }

    public void setValidationRetryCount(int validationRetryCount) {
        this.validationRetryCount = validationRetryCount;
    }

    public String getCreditAppNumber() {
        return creditAppNumber;
    }

    public void setCreditAppNumber(String creditAppNumber) {
        this.creditAppNumber = creditAppNumber;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getOtpStatus() {
        return otpStatus;
    }

    public void setOtpStatus(String otpStatus) {
        this.otpStatus = otpStatus;
    }

    public String getTrackingNumber() {

        return trackingNumber;
    }

    public void setTrackingNumber(String trackingNumber) {
        this.trackingNumber = trackingNumber;
    }

    public List<String> getActionScore() {
        return actionScore;
    }

    public void setActionScore(List<String> actionScore) {
        this.actionScore = actionScore;
    }

}
