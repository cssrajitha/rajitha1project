package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;

public class InstallationWindow implements Serializable {

	private String id;

	private String orderId;

	private String selectedDate;

	private String startTime;

	private String endTime;

	private String selectedReminderMode;

	private String phoneNumber;

	private String serviceProviderAccount;

	private String serviceProviderName;

	private String availableDay;

	private String availableType;

  	private String requestControllerId;
  	private String eventCorrelationId;
  	private String specialInstructions;

  	private String emailAddress;

    public String getSpecialInstructions() {
        return specialInstructions;
    }

    public void setSpecialInstructions(String specialInstructions) {
        this.specialInstructions = specialInstructions;
    }

    public String getEventCorrelationId() {
		return eventCorrelationId;
	}

	public void setEventCorrelationId(String eventCorrelationId) {
		this.eventCorrelationId = eventCorrelationId;
	}

	public String getRequestControllerId() {
		return requestControllerId;
	}

	public void setRequestControllerId(String requestControllerId) {
		this.requestControllerId = requestControllerId;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getSelectedDate() {
		return selectedDate;
	}

	public void setSelectedDate(String selectedDate) {
		this.selectedDate = selectedDate;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getSelectedReminderMode() {
		return selectedReminderMode;
	}

	public void setSelectedReminderMode(String selectedReminderMode) {
		this.selectedReminderMode = selectedReminderMode;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getServiceProviderAccount() {
		return serviceProviderAccount;
	}

	public void setServiceProviderAccount(String serviceProviderAccount) {
		this.serviceProviderAccount = serviceProviderAccount;
	}

	public String getServiceProviderName() {
		return serviceProviderName;
	}

	public void setServiceProviderName(String serviceProviderName) {
		this.serviceProviderName = serviceProviderName;
	}

	public String getAvailableDay() {
		return availableDay;
	}

	public void setAvailableDay(String availableDay) {
		this.availableDay = availableDay;
	}

	public String getAvailableType() {
		return availableType;
	}

	public void setAvailableType(String availableType) {
		this.availableType = availableType;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
}
