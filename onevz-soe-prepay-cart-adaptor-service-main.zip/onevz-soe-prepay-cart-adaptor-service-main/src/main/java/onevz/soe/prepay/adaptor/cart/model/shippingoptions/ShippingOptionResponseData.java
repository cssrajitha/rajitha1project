package onevz.soe.prepay.adaptor.cart.model.shippingoptions;

import lombok.Data;

import java.util.List;

/**
 * class ShippingOptionResponseData having the shipping options details.
 *
 */
@Data
public class ShippingOptionResponseData {
	private String cartId;
    private List<Lines> lines;
}
