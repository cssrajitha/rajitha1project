package onevz.soe.prepay.adaptor.cart.model.cart.vo;

/**
 * Created by w638278 on 1/17/2018.
 */
public class ProcessApplePaymentServiceBody {

    ProcessApplePaymentDecryptToken decryptTokenRes;

    public ProcessApplePaymentDecryptToken getDecryptTokenRes() {
        return decryptTokenRes;
    }

    public void setDecryptTokenRes(ProcessApplePaymentDecryptToken decryptTokenRes) {
        this.decryptTokenRes = decryptTokenRes;
    }
}
