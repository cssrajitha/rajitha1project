package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;


public class TradeInQuestionVO implements Serializable{
	private String id;
	private int version;
	private static final long serialVersionUID = 1L;
	private String activationLockCheck;
	private String hoverText;
	private String positiveResponse;
	/*  Question text */
	private String question;
	private String answer;
	private String questionId;
	private String questionPosition;
	private String reasonText;
	private String tradeInDeviceId;

	public String getTradeInDeviceId() {
		return tradeInDeviceId;
	}

	public void setTradeInDeviceId(String tradeInDeviceId) {
		this.tradeInDeviceId = tradeInDeviceId;
	}

	public TradeInQuestionVO(String activationLockCheck, String hoverText,
			String positiveResponse, String question, String questionId,
			String questionPosition, String reasonText) {
		super();
		this.activationLockCheck = activationLockCheck;
		this.hoverText = hoverText;
		this.positiveResponse = positiveResponse;
		this.question = question;
		this.questionId = questionId;
		this.questionPosition = questionPosition;
		this.reasonText = reasonText;
	}

	public TradeInQuestionVO() {	}

	public String getActivationLockCheck() {
		return activationLockCheck;
	}

	public void setActivationLockCheck(String activationLockCheck) {
		this.activationLockCheck = activationLockCheck;
	}

	public String getHovertext() {
		return hoverText;
	}

	public void setHovertext(String hoverText) {
		this.hoverText = hoverText;
	}

	public String getPositiveResponse() {
		return positiveResponse;
	}

	public void setPositiveResponse(String positiveResponse) {
		this.positiveResponse = positiveResponse;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getQuestionId() {
		return questionId;
	}

	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}

	public String getQuestionPosition() {
		return questionPosition;
	}

	public void setQuestionPosition(String questionPosition) {
		this.questionPosition = questionPosition;
	}

	public String getReasonText() {
		return reasonText;
	}

	public void setReasonText(String reasonText) {
		this.reasonText = reasonText;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public int getVersion() {
		return version;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setVersion(int version) {
		this.version = version;
	}

}
