package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;

public class ScreenResolution implements Serializable {

    private String availableWidth;
    private String availableHeight;
    private String actualWidth;
    private String actualHeight;
    private String pixelDensity;


    public ScreenResolution() {
    }

    public ScreenResolution(String availableWidth, String availableHeight, String actualWidth, String actualHeight, String pixelDensity) {
        this.availableWidth = availableWidth;
        this.availableHeight = availableHeight;
        this.actualWidth = actualWidth;
        this.actualHeight = actualHeight;
        this.pixelDensity = pixelDensity;
    }

    public void setAvailableWidth(String availableWidth) {
        this.availableWidth = availableWidth;
    }

    public void setAvailableHeight(String availableHeight) {
        this.availableHeight = availableHeight;
    }

    public void setActualWidth(String actualWidth) { this.actualWidth = actualWidth; }

    public void setActualHeight(String actualHeight) {
        this.actualHeight = actualHeight;
    }

    public void setPixelDensity(String pixelDensity) {
        this.pixelDensity = pixelDensity;
    }



    public String getAvailableWidth() {
        return availableWidth;
    }

    public String getAvailableHeight() {
        return availableHeight;
    }

    public String getActualWidth() {
        return actualWidth;
    }

    public String getActualHeight() {
        return actualHeight;
    }

    public String getPixelDensity() {
        return pixelDensity;
    }


}
