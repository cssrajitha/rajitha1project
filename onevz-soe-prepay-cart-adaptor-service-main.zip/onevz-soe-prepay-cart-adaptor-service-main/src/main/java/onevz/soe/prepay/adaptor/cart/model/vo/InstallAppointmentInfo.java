package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;

public class InstallAppointmentInfo implements Serializable {

    private static final long serialVersionUID = 1L;
    private String homePhone;
    private String workPhone;
    private String mobilePhone;
    private String primaryPhoneType;
    private String preferredContactType;
    private String emailAddress;
    private String companyName;
    private String firstName;
    private String lastName;
    private String directions;
    private String specialInstructions;
    private InstallApptSelectedDateInfo installApptSelectedDate;

    public String getHomePhone() {
        return homePhone;
    }

    public void setHomePhone(String homePhone) {
        this.homePhone = homePhone;
    }

    public String getWorkPhone() {
        return workPhone;
    }

    public void setWorkPhone(String workPhone) {
        this.workPhone = workPhone;
    }

    public String getMobilePhone() {
        return mobilePhone;
    }

    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    public String getPrimaryPhoneType() {
        return primaryPhoneType;
    }

    public void setPrimaryPhoneType(String primaryPhoneType) {
        this.primaryPhoneType = primaryPhoneType;
    }

    public String getPreferredContactType() {
        return preferredContactType;
    }

    public void setPreferredContactType(String preferredContactType) {
        this.preferredContactType = preferredContactType;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getDirections() {
        return directions;
    }

    public void setDirections(String directions) {
        this.directions = directions;
    }

    public String getSpecialInstructions() {
        return specialInstructions;
    }

    public void setSpecialInstructions(String specialInstructions) {
        this.specialInstructions = specialInstructions;
    }

    public InstallApptSelectedDateInfo getInstallApptSelectedDate() {
        return installApptSelectedDate;
    }

    public void setInstallApptSelectedDate(InstallApptSelectedDateInfo installApptSelectedDate) {
        this.installApptSelectedDate = installApptSelectedDate;
    }
}
