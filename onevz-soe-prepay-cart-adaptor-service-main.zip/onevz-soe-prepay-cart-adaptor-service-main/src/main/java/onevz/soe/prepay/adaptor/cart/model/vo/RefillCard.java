package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;

public class RefillCard extends PaymentGroup implements Serializable {

    private static final long serialVersionUID = 1L;

    private String mtn;
    private String pin;
    private String vendorCode;
    private Double pinCardTotalBalance;
    private String pinCardNumber;

    public String getMtn() {
        return mtn;
    }

    public void setMtn(String mtn) {
        this.mtn = mtn;
    }

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public String getVendorCode() {
        return vendorCode;
    }

    public void setVendorCode(String vendorCode) {
        this.vendorCode = vendorCode;
    }

    public Double getPinCardTotalBalance() {
        return pinCardTotalBalance;
    }

    public void setPinCardTotalBalance(Double pinCardTotalBalance) {
        this.pinCardTotalBalance = pinCardTotalBalance;
    }

    public String getPinCardNumber() {
        return pinCardNumber;
    }

    public void setPinCardNumber(String pinCardNumber) {
        this.pinCardNumber = pinCardNumber;
    }
}
