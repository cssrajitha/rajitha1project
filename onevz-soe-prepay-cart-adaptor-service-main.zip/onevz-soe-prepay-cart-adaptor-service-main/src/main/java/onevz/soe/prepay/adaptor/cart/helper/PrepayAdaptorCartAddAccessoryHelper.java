package onevz.soe.prepay.adaptor.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.model.addAccessory.AddAccContext;
import onevz.soe.cart.model.addAccessory.AddAccServiceBody;
import onevz.soe.cart.model.addAccessory.AddAccServiceResponse;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.requests.AddAccessoryPEGARequest;
import onevz.soe.cart.responses.AddAccessoriesPEGAResponse;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.common.model.PrepaidODRequestDataAccessorySkuIds;
import onevz.soe.common.model.PrepaidODRequestDataLines;
import onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants;
import onevz.soe.prepay.adaptor.cart.model.play.PrepaidODAccessory;
import onevz.soe.prepay.adaptor.cart.model.play.PrepaidODAddAccessoriesOutput;
import onevz.soe.prepay.adaptor.cart.model.play.PrepaidODAddAccessoriesRequest;
import onevz.soe.prepay.adaptor.cart.model.play.PrepaidODAddAccessoriesResponse;
import onevz.soe.prepay.adaptor.cart.util.PrepayAdaptorCartUtil;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.bpm.model.response.AvailablePaths;
import onevz.soe.wsclient.bpm.model.response.Error;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import onevz.soe.wsclient.prepay.webclient.model.PrepaidAdaptorWebClientRequest;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;

import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.*;


@Service
public class PrepayAdaptorCartAddAccessoryHelper {

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    private PrepayAdaptorWebClient prepayBusinessCartWebclient;

    @Value("${addAccessoryPrepaidLegacyServiceUrl}")
    private String addAccessoryPrepaidLegacyServiceUrl;

    @Value("${prepayMaxAccessoriesPerLine}")
    private int prepayMaxAccessoriesPerLine;

    @Autowired
    PrepayCartRedisHelper prepayCartRedisHelper;

    private static final Logger logger = LoggerFactory.getLogger(PrepayAdaptorCartAddAccessoryHelper.class);

    /**
     * @param httpRequest
     * @param addAccessoryPEGARequest
     * @return AddAccessoriesPEGAResponse
     */
    public Mono<ResponseEntity<AddAccessoriesPEGAResponse>> addAccessory(ServerHttpRequest httpRequest, AddAccessoryPEGARequest addAccessoryPEGARequest) {
        logger.debug(" addAccessory adaptor Request: {}", addAccessoryPEGARequest);
        return prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)
                .doOnError(err -> logger.error(REDIS_DATA_NOT_FOUND_ERROR_CODE, err)).defaultIfEmpty("")
                .flatMap(response -> {
                    logger.info("PrepaidODRequestData From Redis: {}  " , response);
                    PrepaidODRequestData prepaidODRequestData = null;
                    List<PrepaidODRequestDataLines> lines = null;
                    Line[] requestLines = null;
                    if (StringUtilities.isEmptyOrNull(response)) {
                        logger.error(REDIS_DATA_NOT_FOUND_ERROR_CODE, response);
                    } else {
                        try {
                            prepaidODRequestData = mapper.readValue(response, PrepaidODRequestData.class);
                            lines = prepaidODRequestData.getLines();
                            requestLines = addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
                        } catch (JsonProcessingException e) {
                            logger.error("Failed to get data from redis:", e);
                        }
                    }
                    if (null != requestLines && null != lines) {
                    	String mtnRequestLine = requestLines[0].getMtn();
                    	List<PrepaidODRequestDataLines> dataLines = lines.stream().filter(line-> line.getMtn().equalsIgnoreCase(mtnRequestLine)).toList();
                        PrepaidODRequestDataLines dataLine = dataLines.get(0);
                        String flow = dataLine.getFlow();
                        /*String flow = Objects.nonNull(addAccessoryPEGARequest) && Objects.nonNull(addAccessoryPEGARequest.getServiceBody()) && Objects.nonNull(addAccessoryPEGARequest.getServiceBody().getServiceRequest()) 
									&& Objects.nonNull(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext()) && Objects.nonNull(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo())?addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType():PrepayAdaptorCartConstants.NSE;
                    	*/
                    	if(dataLine.isCheckoutFlag()) {
                     	   
                        	PrepaidODAddAccessoriesRequest prepaidODAddAccessoriesRequest = new PrepaidODAddAccessoriesRequest();
       						List<PrepaidODAccessory> accessoryList = new ArrayList<>();
       						PrepaidODAccessory targetAaccessory = new PrepaidODAccessory();
       						
    						String flowName=PrepayAdaptorCartUtil.getODFlowName(flow);
       						targetAaccessory.setFlow(flowName);
    						// add accessory action (add or remove)
    						if(null != requestLines[0].getAccessories().getAdd()) {
    							if(requestLines[0].getAccessories().getAdd().length>0) {
    							
    								targetAaccessory.setAction(PrepayAdaptorCartConstants.PREPAY_OD_ACCESSORY_ADD_ACTION);
    								targetAaccessory.setAccQty(requestLines[0].getAccessories().getAdd()[0].getQty());
    								targetAaccessory.setAccSkuId(requestLines[0].getAccessories().getAdd()[0].getAccessorySkuID());
    								targetAaccessory.setAccSorId(requestLines[0].getAccessories().getAdd()[0].getId());
    								targetAaccessory.setAccCategory(requestLines[0].getAccessories().getAdd()[0].getCategory());
    								targetAaccessory.setAccessoryBundle(requestLines[0].getAccessories().getAdd()[0].getAccessoryBundle());
    								targetAaccessory.setDevCommerceId(dataLine.getLineItemId());
    								if(null != requestLines[0].getAccessories().getAdd()[0].getProductId()) {
    								targetAaccessory.setAccProdId(requestLines[0].getAccessories().getAdd()[0].getProductId());
    								}
    								accessoryList.add(targetAaccessory);
    								prepaidODAddAccessoriesRequest.setAccessories(accessoryList);
    							}
    						} else if((null != requestLines[0].getAccessories().getRemove())&&(requestLines[0].getAccessories().getRemove().length>0)) {
    								String requestSorId=requestLines[0].getAccessories().getRemove()[0].getId();
    								List<PrepaidODRequestDataAccessorySkuIds>  existingSorId= dataLine.getAccessorySkuIds().stream().filter(accList-> accList.getSorId().equalsIgnoreCase(requestSorId)).toList();
    								int removeAccessoryQty= 1;
    								for (PrepaidODRequestDataAccessorySkuIds accDetails : existingSorId) {
    									if(removeAccessoryQty<=Integer.parseInt(requestLines[0].getAccessories().getRemove()[0].getQty())) {
    									PrepaidODAccessory targetRemoveAccessory = new PrepaidODAccessory();
    									targetRemoveAccessory.setAction(PrepayAdaptorCartConstants.PREPAY_OD_ACCESSORY_REMOVE_ACTION);
    									//targetRemoveAccessory.setFlow(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
    									targetRemoveAccessory.setFlow(flowName);
    									targetRemoveAccessory.setCommerceItemId(accDetails.getAccessoryCommerceId());
    									targetRemoveAccessory.setAccQty("");
    									targetRemoveAccessory.setAccSkuId("");
    									targetRemoveAccessory.setAccSorId("");
    									targetRemoveAccessory.setAccCategory("");
    									targetRemoveAccessory.setDevCommerceId("");
    									if(null != requestLines[0].getAccessories().getRemove()[0].getProductId()) {
        									targetRemoveAccessory.setAccProdId(requestLines[0].getAccessories().getRemove()[0].getProductId());
        								}
    									accessoryList.add(targetRemoveAccessory);
    									removeAccessoryQty++;
    									}
									}
    								prepaidODAddAccessoriesRequest.setAccessories(accessoryList);

    						}
    						PrepaidAdaptorWebClientRequest prepaidODAddAccessoriesLegacyServiceRequest = getPrepaidAddAccessoriesLegacyServiceRequest(prepaidODAddAccessoriesRequest, prepaidODRequestData);
    						logger.info("Add Accessory Request: {}",prepaidODAddAccessoriesLegacyServiceRequest);
    						// call add accessories call
    						return callODAddAccessories(httpRequest,dataLine, prepaidODRequestData, prepaidODAddAccessoriesLegacyServiceRequest, addAccessoryPEGARequest);
                     	}
                    }
                    if (null != requestLines && null != lines) {
                        if ((Arrays.stream(requestLines).filter(ln -> ln.getAccessories().getRemove()!=null).findAny().isPresent())){
                             updateLineInfo(requestLines, lines);
                            }
                        else if((Arrays.stream(requestLines).filter(ln -> ln.getAccessories().getAdd()!=null).findAny().isPresent())) {
                            if(accessoriesCountCheck(requestLines, lines)) {
                                updateLineInfo(requestLines, lines);
                            }else{
                                AddAccessoriesPEGAResponse addAccessoriesPEGAResponse = new AddAccessoriesPEGAResponse();
                                List<Error> accessoryLimitErrorList = PrepayAdaptorCartUtil.buildErrorResponse(PrepayAdaptorCartConstants.ADDACCESSORY_LIMIT_EXCEEDED_NAME,
                                        PrepayAdaptorCartConstants.ADDACCESSORY_LIMIT_EXCEEDED_ID, PrepayAdaptorCartConstants.ADDACCESSORY_LIMIT_EXCEEDED_MSG,
                                        PrepayAdaptorCartConstants.ADDACCESSORY_ERROR_CATEGORY);
                                addAccessoriesPEGAResponse.setErrors(accessoryLimitErrorList);
                                return Mono.just(ResponseEntity.status(HttpStatus.OK).body(addAccessoriesPEGAResponse));
                            }
                        }
                    }
                    prepaidODRequestData.setLines(lines);
                    return prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, prepaidODRequestData)
                            .doOnError(err -> logger.error(REDIS_DATA_NOT_FOUND_ERROR_CODE, err))
                            .flatMap(upsertResp -> {
                                logger.info("PrepaidODRequestData From Redis: {} " , upsertResp);
                                AddAccessoriesPEGAResponse addAccessoriesPEGAResponse = mapRequestToResponse(addAccessoryPEGARequest);
                                return Mono.just(ResponseEntity.status(HttpStatus.OK).body(addAccessoriesPEGAResponse));
                            });
                });
    }

  public Mono<ResponseEntity<AddAccessoriesPEGAResponse>> callODAddAccessories(ServerHttpRequest httpRequest, PrepaidODRequestDataLines dataLine, PrepaidODRequestData prepaidODRequestData,
			PrepaidAdaptorWebClientRequest prepaidODAddAccessoriesLegacyServiceRequest, AddAccessoryPEGARequest addAccessoryPEGARequest) {
	  return prepayBusinessCartWebclient.getPrepayServiceResponse(httpRequest, prepaidODAddAccessoriesLegacyServiceRequest)
				.doOnError(error -> logger.error("Failed to get response for prepaidOD AddAccessory service, error: {}", error))
				.flatMap(accessoryResponseEntity -> {
					logger.info("Successful response from api: {}", prepaidODAddAccessoriesLegacyServiceRequest.getUrl());
					logger.info("Error while calling prepaidOD AddAccessory Service, status code: {} \n response body: {}", accessoryResponseEntity.getStatusCode(), accessoryResponseEntity.getBody());
				
					if (!accessoryResponseEntity.getStatusCode().is2xxSuccessful()) {
							logger.error("Error while calling prepaidOD AddAccessory Service, status code: {}", accessoryResponseEntity.getStatusCode());
							AddAccessoriesPEGAResponse addAccessoriesPEGAResponse = new AddAccessoriesPEGAResponse();
                            List<Error> accessoryErrorList = PrepayAdaptorCartUtil.buildErrorResponse(PrepayAdaptorCartConstants.ADDACCESSORY_ERROR_NAME,
                                PrepayAdaptorCartConstants.ADDACCESSORY_ERROR_ID, PrepayAdaptorCartConstants.ADDACCESSORY_ERROR_MSG,
                                PrepayAdaptorCartConstants.ADDACCESSORY_SYSTEM_ERROR_CATEGORY);
                            addAccessoriesPEGAResponse.setErrors(accessoryErrorList);
                            return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(addAccessoriesPEGAResponse));
					}
					PrepaidODAddAccessoriesResponse addAccessoriesResponse = null;
					boolean accessorySuccess = false;
					try {
						addAccessoriesResponse = mapper.readValue(accessoryResponseEntity.getBody(), PrepaidODAddAccessoriesResponse.class);
						logger.info("addAccessoriesResponse play : {}", mapper.writeValueAsString(addAccessoriesResponse));
						accessorySuccess = (addAccessoriesResponse.getOutput()!=null && addAccessoriesResponse.getErrorMap()==null)?true:false;
					} catch (JsonProcessingException e) {
						logger.error("Failed to convert response received from PrepaidOD AddAccessories: {}", e);
						AddAccessoriesPEGAResponse addAccessoriesPEGAResponse = new AddAccessoriesPEGAResponse();
                        List<Error> accessoryErrorList = PrepayAdaptorCartUtil.buildErrorResponse(PrepayAdaptorCartConstants.ADDACCESSORY_ERROR_NAME,
                                PrepayAdaptorCartConstants.ADDACCESSORY_ERROR_ID, PrepayAdaptorCartConstants.ADDACCESSORY_ERROR_MSG,
                                PrepayAdaptorCartConstants.ADDACCESSORY_SYSTEM_ERROR_CATEGORY);
                        addAccessoriesPEGAResponse.setErrors(accessoryErrorList);
                        return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(addAccessoriesPEGAResponse));
					}
					List<String> completedSteps = dataLine.getCompletedProcessSteps();
					completedSteps.add(ACCESSORIES_INTERSTIAL);
					dataLine.setCompletedProcessSteps(completedSteps);
					
					if(!accessorySuccess) {
						// return error response
                        String errorMsg = Objects.nonNull(addAccessoriesResponse.getErrorMap())?addAccessoriesResponse.getErrorMap().get(addAccessoriesResponse.getErrorMap().keySet().toArray()[0]):PrepayAdaptorCartConstants.ADDACCESSORY_ERROR_MSG;
                        if(Objects.nonNull(addAccessoryPEGARequest) && Objects.nonNull(addAccessoryPEGARequest.getServiceBody()) &&
								Objects.nonNull(addAccessoryPEGARequest.getServiceBody().getServiceRequest()) &&
								Objects.nonNull(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext()) &&
								Objects.nonNull(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo()) &&
								Objects.nonNull(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()) &&
								Objects.nonNull(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getAccessories()) &&
								Objects.nonNull(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getAccessories().getAdd()) &&
								Objects.nonNull(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getAccessories().getAdd()[0].getDisplayName())) {
							errorMsg = addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getAccessories().getAdd()[0].getDisplayName()
									+ " " + addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getAccessories().getAdd()[0].getColor()
									+" "+errorMsg;
						} else if(Objects.nonNull(addAccessoryPEGARequest) && Objects.nonNull(addAccessoryPEGARequest.getServiceBody()) &&
								Objects.nonNull(addAccessoryPEGARequest.getServiceBody().getServiceRequest()) &&
								Objects.nonNull(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext()) &&
								Objects.nonNull(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo()) &&
								Objects.nonNull(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()) &&
								Objects.nonNull(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getAccessories()) &&
								Objects.nonNull(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getAccessories().getRemove()) &&
								Objects.nonNull(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getAccessories().getRemove()[0].getDisplayName())) {
							errorMsg = addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getAccessories().getRemove()[0].getDisplayName() + " " + errorMsg;
						}
						List<Error> accessoryErrorList = PrepayAdaptorCartUtil.buildErrorResponse(PrepayAdaptorCartConstants.ADDACCESSORY_ERROR_NAME,
                                PrepayAdaptorCartConstants.ADDACCESSORY_ERROR_ID, errorMsg, PrepayAdaptorCartConstants.ADDACCESSORY_ERROR_CATEGORY);

						AddAccessoriesPEGAResponse addAccessoriesPEGAResponse = new AddAccessoriesPEGAResponse();
						addAccessoriesPEGAResponse.setErrors(accessoryErrorList);
                        return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(addAccessoriesPEGAResponse));
					}
					int dataLineIndex = prepaidODRequestData.getLines().indexOf(dataLine);
					List<PrepaidODRequestDataAccessorySkuIds> accList=null;
					if(null != addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getAccessories().getAdd()) {
						accList=new ArrayList<>();
						for (PrepaidODAddAccessoriesOutput prepaidODAddAccessoriesOutput : addAccessoriesResponse.getOutput()) {
							PrepaidODRequestDataAccessorySkuIds newAccessorySkuIds=new PrepaidODRequestDataAccessorySkuIds();
							newAccessorySkuIds.setAccessoryCommerceId(prepaidODAddAccessoriesOutput.getAccCommerceId());
							newAccessorySkuIds.setSorId(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getAccessories().getAdd()[0].getId());
	                        newAccessorySkuIds.setSkuId(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getAccessories().getAdd()[0].getAccessorySkuID());
	                        newAccessorySkuIds.setDisplayName(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getAccessories().getAdd()[0].getDisplayName());
	                        newAccessorySkuIds.setImgUrl(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getAccessories().getAdd()[0].getImgUrl());
	                        newAccessorySkuIds.setColor(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getAccessories().getAdd()[0].getColor());
	                        newAccessorySkuIds.setPrice(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getAccessories().getAdd()[0].getPrice());
							newAccessorySkuIds.setDiscountedPrice(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getAccessories().getAdd()[0].getDiscountAmount());
	                        newAccessorySkuIds.setQty("1");
	                        newAccessorySkuIds.setManufacturer(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getAccessories().getAdd()[0].getManufacturer());
	                        newAccessorySkuIds.setDescription(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getAccessories().getAdd()[0].getDescription());
	                        accList.add(newAccessorySkuIds);
						}
						
						if (CollectionUtils.size(dataLine.getAccessorySkuIds())>0) {
							dataLine.getAccessorySkuIds().addAll(accList);
						} else {
							dataLine.setAccessorySkuIds(accList);
						}
						prepaidODRequestData.getLines().set(dataLineIndex, dataLine);
					}else if(null != addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getAccessories().getRemove()) {
						
						for (PrepaidODAddAccessoriesOutput prepaidODAddAccessoriesOutput : addAccessoriesResponse
								.getOutput()) {
							dataLine.getAccessorySkuIds().removeIf(accDetails -> prepaidODAddAccessoriesOutput
									.getAccCommerceId().equalsIgnoreCase(accDetails.getAccessoryCommerceId()));
						}
						prepaidODRequestData.getLines().set(dataLineIndex, dataLine);
					}
					
					return prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, prepaidODRequestData)
							.doOnError(err -> logger.error("Failed to update the PrepaidODRequestData to Redis in PrepaidODAddDevice", err))
							.flatMap(upsertResp -> {
								logger.info("Successfully upserted PrepaidODRequestData to Redis: {}", upsertResp);
								return Mono.just(new ResponseEntity<AddAccessoriesPEGAResponse>(mapAddAccessoryResponse(addAccessoryPEGARequest, completedSteps, PrepayAdaptorCartConstants.SUCCESS_MSG, PrepayAdaptorCartConstants.RESPONSE_SUCCESS_CODE, prepaidODRequestData), HttpStatus.OK));
							}); 
				});
		
	}

   private AddAccessoriesPEGAResponse mapAddAccessoryResponse(AddAccessoryPEGARequest addAccessoryPEGARequest,List<String> completedSteps, String accessoryMsg, String accessoryCode, PrepaidODRequestData prepaidODRequestData) {

		AddAccessoriesPEGAResponse addAccessoriesPEGAResponse = new AddAccessoriesPEGAResponse();
	    CartServiceServiceHeader cartServiceServiceHeader = new CartServiceServiceHeader();
	    cartServiceServiceHeader.setStatusCode(accessoryCode);
	    cartServiceServiceHeader.setStatusMsg(accessoryMsg);
	    cartServiceServiceHeader.setServiceName(addAccessoryPEGARequest.getServiceHeader().getServiceName());
	    cartServiceServiceHeader.setCorrelationId(addAccessoryPEGARequest.getServiceHeader().getCorrelationId());
	    addAccessoriesPEGAResponse.setServiceHeader(cartServiceServiceHeader);
	    AddAccServiceResponse addAccServiceResponse = new AddAccServiceResponse();
	    CartServiceContextInfo cartServiceContextInfo = new CartServiceContextInfo();
	    //ProcessStep and ProcessAction value to be modified further
	    AddAccContext context = new AddAccContext();
	    
	    CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
		String mtn = Arrays.stream(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines())
					.map(x -> x.getMtn()).findFirst().orElse(PrepayAdaptorCartConstants.DEFAULT_NSE_LINE);
	   	List<PrepaidODRequestDataLines> dataLine;
		boolean checkoutFlag = false;

		if(Objects.nonNull(prepaidODRequestData) && CollectionUtilities.isNotEmptyOrNull(prepaidODRequestData.getLines())) {
			dataLine = prepaidODRequestData.getLines().stream().filter(line -> line.getMtn().equalsIgnoreCase(mtn)).toList();
			   checkoutFlag= dataLine.get(0).isCheckoutFlag();
		}
		AvailablePaths availablePath = new AvailablePaths();
		List<AvailablePaths> availablePaths = new ArrayList<>();

		if(checkoutFlag) {
			cartServiceContextInfo.setProcessStep(PrepayAdaptorCartConstants.CHECKOUT_PLAN_PROCESS_STEP);
		    availablePath.setPath(PrepayAdaptorCartConstants.CHECKOUT_PLAN_PROCESS_STEP);
		} else {
			cartServiceContextInfo.setProcessStep(PrepayAdaptorCartConstants.ACCESSORIES_INTERSTIAL);
			availablePath.setPath(PrepayAdaptorCartConstants.ACCESSORIES_INTERSTIAL);
		}
		availablePaths.add(availablePath);
	    cartServiceContextInfo.setAvailablePaths(availablePaths);
	   	cartServiceContextInfo.setProcessAction("");
	   	customerInfo.setCustomerType(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCustomerType());
	   	customerInfo.setAccountNumber(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getAccountNumber());
	   	customerInfo.setCartCreator(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCartCreator());
	   	customerInfo.setProcessingMTN(Objects.nonNull(prepaidODRequestData) && Objects.nonNull(prepaidODRequestData.getLines()) && Objects.nonNull(prepaidODRequestData.getLines().get(0))?prepaidODRequestData.getLines().get(0).getMtn():PrepayAdaptorCartConstants.DEFAULT_NSE_LINE);
	   	customerInfo.setGlobalId(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getGlobalId());
	   	context.setCustomerInfo(customerInfo);
	   	CartServiceCartInfo cartInfo = new CartServiceCartInfo();
	   	Line[] lines = addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
		Line[] newLines = new Line[lines.length];

		for (int i = 0; i < lines.length; i++) {
	    	Line line = new Line();
	        line.setMtn(lines[i].getMtn());
	        line.setLineActivityType(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	        newLines[i] = line;
	    }
	    cartInfo.setLines(newLines);
	    cartInfo.setDiscountPromoTotal(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getDiscountPromoTotal());
	    cartInfo.setRegisterNumber(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getRegisterNumber());
	    cartInfo.setProtectionNotRequired(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().isProtectionNotRequired());
	    context.setCartInfo(cartInfo);
	    ProcessMTNList[] processMTNList = new ProcessMTNList[1];
	    ProcessMTNList processMTNList1 = new ProcessMTNList();
	    String[] completeSteps = new String[completedSteps.size()];

	    for(int i=0;i<completedSteps.size();i++) {
	    	completeSteps[i]=completedSteps.get(i);
		}
	    processMTNList1.setCompletedprocessSteps(completeSteps);
	    processMTNList[0] = processMTNList1;
	    context.setProcessMTNList(processMTNList);
	    AddAccServiceBody addAccServiceBody = new AddAccServiceBody();
	    context.setContextInfo(cartServiceContextInfo);
	    addAccServiceResponse.setContext(context);
	    addAccServiceBody.setServiceResponse(addAccServiceResponse);
	    addAccessoriesPEGAResponse.setServiceBody(addAccServiceBody);
	    return addAccessoriesPEGAResponse;
	
}

    private boolean accessoriesCountCheck(Line[] requestLines, List<PrepaidODRequestDataLines> lines) {

        AtomicBoolean addNewAccessory = new AtomicBoolean(false);
        int cartLevelAccessoryCount = 0;

        for (PrepaidODRequestDataLines e : lines) {
            try {
                List<PrepaidODRequestDataAccessorySkuIds> existingAccessorySkuIdsList = (null != e.getAccessorySkuIds()) ? e.getAccessorySkuIds() : new ArrayList<PrepaidODRequestDataAccessorySkuIds>();
                for (PrepaidODRequestDataAccessorySkuIds accessoryList : existingAccessorySkuIdsList)
                    cartLevelAccessoryCount = cartLevelAccessoryCount + Integer.parseInt(accessoryList.getQty());
                if ((cartLevelAccessoryCount > prepayMaxAccessoriesPerLine)) {
                    return false;
                }
            } catch (Exception ex) {
                logger.error("Exception in accessoriesCountCheck:" + "{}", ex);
            }
        }
        for (Line ln : requestLines) {
            if (null != ln.getAccessories().getAdd()) {
                int requestCount = 0;
                for (Accessory accessory : ln.getAccessories().getAdd()) {
                    requestCount = requestCount + Integer.parseInt(accessory.getQty());
                }
                cartLevelAccessoryCount = requestCount + cartLevelAccessoryCount;
                if (cartLevelAccessoryCount > prepayMaxAccessoriesPerLine) {
                    return false;
                }
            }
        }
        for (Line ln : requestLines) {
            lines.stream().filter(Objects::nonNull).forEach(e -> {
                try {
                    if (e.getMtn().equalsIgnoreCase(ln.getMtn())) {
                        List<PrepaidODRequestDataAccessorySkuIds> existingAccessorySkuIdsList = (null != e.getAccessorySkuIds()) ? e.getAccessorySkuIds() : new ArrayList<PrepaidODRequestDataAccessorySkuIds>();
                        int count = 0;
                        for (PrepaidODRequestDataAccessorySkuIds accessoryList : existingAccessorySkuIdsList)
                            count = count + Integer.parseInt(accessoryList.getQty());
                        if ((count > prepayMaxAccessoriesPerLine)) {
                            addNewAccessory.set(false);
                        } else {
                            if (null != ln.getAccessories().getAdd()) {
                                int requestCount = 0;
                                for (Accessory accessory : ln.getAccessories().getAdd()) {
                                    requestCount = requestCount + Integer.parseInt(accessory.getQty());
                                }
                                count = requestCount + count;
                                if (count > prepayMaxAccessoriesPerLine) {
                                    addNewAccessory.set(false);
                                } else {
                                    addNewAccessory.set(true);
                                }
                            }
                        }
                    }

                } catch (Exception ex) {
                    logger.error("Exception in accessoriesCountCheck:" + "{}", ex);
                }
            });
        }
        return addNewAccessory.get();

    }

    private void updateLineInfo(Line[] requestLines, List<PrepaidODRequestDataLines> lines) {
        for (Line ln : requestLines) {
            lines.stream().filter(Objects::nonNull).forEach(e -> {
                try {
                    if (e.getMtn().equalsIgnoreCase(ln.getMtn())) {
                    	
                    	if(e.isCheckoutFlag()) {
                    		// Implement code which calls Edit Cart and updates accessories on the Play services
                    		logger.info("Start for updation on the accessories on the OD ");
                    	}
                    	List<PrepaidODRequestDataAccessorySkuIds> existingAccessorySkuIdsList = (null!= e.getAccessorySkuIds())?e.getAccessorySkuIds():new ArrayList<PrepaidODRequestDataAccessorySkuIds>();
                        PrepaidODRequestDataAccessorySkuIds newAccessorySkuIds = new PrepaidODRequestDataAccessorySkuIds();
                        if(null != ln.getAccessories().getAdd()) {
                        	
                        for (Accessory accessory : ln.getAccessories().getAdd()) {
                        	for (int i = 0; i < Integer.parseInt(accessory.getQty()); i++) {
                        		newAccessorySkuIds.setSorId(accessory.getId());
                                newAccessorySkuIds.setSkuId(accessory.getAccessorySkuID());
                                newAccessorySkuIds.setDisplayName(accessory.getDisplayName());
                                newAccessorySkuIds.setImgUrl(accessory.getImgUrl());
                                newAccessorySkuIds.setColor(accessory.getColor());
                                newAccessorySkuIds.setPrice(accessory.getPrice());
								newAccessorySkuIds.setDiscountedPrice(accessory.getDiscountAmount());
                                newAccessorySkuIds.setQty("1");
                                newAccessorySkuIds.setManufacturer(accessory.getManufacturer());
                                newAccessorySkuIds.setDescription(accessory.getDescription());
                                newAccessorySkuIds.setAccessoryCommerceId("");
                                existingAccessorySkuIdsList.add(newAccessorySkuIds);
                                logger.info("added new accessory : {}", accessory.getId());
                        	}
                           }
                        logger.info("about to set accessories to the redis");
                        e.setAccessorySkuIds(existingAccessorySkuIdsList);
                        }
                        if(null != ln.getAccessories().getRemove()) {
                        	List<Integer> accIndexList=new ArrayList<>();
                        	for (Accessory accessory : ln.getAccessories().getRemove()) {
                        		int qtyCount= 1;
                        		for (PrepaidODRequestDataAccessorySkuIds  acDetails: existingAccessorySkuIdsList) {
                        			if(accessory.getId().equalsIgnoreCase(acDetails.getSorId()) && qtyCount<=Integer.parseInt(accessory.getQty())){
                        				logger.info("Accessory SorId : {} and total qty : {} ", acDetails.getSorId(), accessory.getQty());
                        				accIndexList.add(existingAccessorySkuIdsList.indexOf(acDetails));
                        				qtyCount++;
                        			}
								}
                        	}
                        	logger.info("Accessories need to remove SorIds : {} ", accIndexList.size());
                        	for (int accessoryIndex : accIndexList) {
                        		existingAccessorySkuIdsList.remove(accessoryIndex);
							}
                        	logger.info("Total accessories after removing SorIds : {} ", existingAccessorySkuIdsList.size());
                        	e.setAccessorySkuIds(existingAccessorySkuIdsList);
                        }
                    }
                } catch (Exception ex) {
                    logger.error("Exception in updating line:" + "{}", ex);
                }
            });

        }
    }

    private AddAccessoriesPEGAResponse mapRequestToResponse(AddAccessoryPEGARequest addAccessoryPEGARequest) {
        AddAccessoriesPEGAResponse addAccessoriesPEGAResponse = new AddAccessoriesPEGAResponse();
        CartServiceServiceHeader cartServiceServiceHeader = new CartServiceServiceHeader();
        cartServiceServiceHeader.setStatusCode("00");
        cartServiceServiceHeader.setStatusMsg("SUCCESS");
        cartServiceServiceHeader.setServiceName(addAccessoryPEGARequest.getServiceHeader().getServiceName());
        cartServiceServiceHeader.setCorrelationId(addAccessoryPEGARequest.getServiceHeader().getCorrelationId());
        addAccessoriesPEGAResponse.setServiceHeader(cartServiceServiceHeader);
        AddAccServiceResponse addAccServiceResponse = new AddAccServiceResponse();
        CartServiceContextInfo cartServiceContextInfo = new CartServiceContextInfo();
        //ProcessStep and ProcessAction value to be modified further
        cartServiceContextInfo.setProcessStep("AccessoryInterestial");
        cartServiceContextInfo.setProcessAction("");
        AddAccContext context = new AddAccContext();
        context.setContextInfo(cartServiceContextInfo);
        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setCustomerType(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCustomerType());
        customerInfo.setAccountNumber(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getAccountNumber());
        customerInfo.setCartCreator(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCartCreator());
        customerInfo.setProcessingMTN(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getProcessingMTN());
        customerInfo.setGlobalId(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getGlobalId());
        context.setCustomerInfo(customerInfo);
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        Line[] lines = addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
        Line[] newLines = new Line[lines.length];
        for (int i = 0; i < lines.length; i++) {
            Line line = new Line();
            line.setMtn(lines[i].getMtn());
            line.setLineActivityType(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
            newLines[i] = line;
        }
        cartInfo.setLines(newLines);
        cartInfo.setDiscountPromoTotal(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getDiscountPromoTotal());
        cartInfo.setRegisterNumber(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getRegisterNumber());
        cartInfo.setProtectionNotRequired(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().isProtectionNotRequired());
        context.setCartInfo(cartInfo);
        ProcessMTNList[] processMTNList = new ProcessMTNList[1];
        ProcessMTNList processMTNList1 = new ProcessMTNList();
        processMTNList1.setMtn(Arrays.stream(addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()).map(x ->
                x.getMtn()).findFirst().orElse(null));
        String[] completedProcessSteps = new String[1];
        completedProcessSteps[0] = addAccessoryPEGARequest.getServiceBody().getServiceRequest().getContext().getContextInfo().getProcessStep();
        processMTNList1.setCompletedprocessSteps(completedProcessSteps);
        processMTNList[0] = processMTNList1;
        context.setProcessMTNList(processMTNList);
        AddAccServiceBody addAccServiceBody = new AddAccServiceBody();
        addAccServiceResponse.setContext(context);
        addAccServiceBody.setServiceResponse(addAccServiceResponse);
        addAccessoriesPEGAResponse.setServiceBody(addAccServiceBody);
        return addAccessoriesPEGAResponse;
    }
    
	private PrepaidAdaptorWebClientRequest getPrepaidAddAccessoriesLegacyServiceRequest(PrepaidODAddAccessoriesRequest prepaidODAddAccessoriesRequest, PrepaidODRequestData prepaidODRequestData) {
		PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
		prepaidAdaptorWebClientRequest.setUrl(addAccessoryPrepaidLegacyServiceUrl);
		prepaidAdaptorWebClientRequest.setRequestBody(prepaidODAddAccessoriesRequest);
		prepaidAdaptorWebClientRequest.setRequestType(HttpMethod.POST.toString());
		prepaidAdaptorWebClientRequest.setHeader(PrepayAdaptorCartUtil.getPrepayODServiceCommonHeaders(prepaidODRequestData));
		return prepaidAdaptorWebClientRequest;
	}


}
