package onevz.soe.prepay.adaptor.cart.model.updateContactInfo.play;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class AccountInfo {
    private String zipcode;

    private String firstName;

    private String lastName;

    private Address address;

    private String mdnNumber;

    private String fullName;

    private String middleName;

    private String accountOwner;
}

