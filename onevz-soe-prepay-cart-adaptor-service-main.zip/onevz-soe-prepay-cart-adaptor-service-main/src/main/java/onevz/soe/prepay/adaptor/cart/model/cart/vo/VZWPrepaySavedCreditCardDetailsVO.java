package onevz.soe.prepay.adaptor.cart.model.cart.vo;

import java.io.Serializable;

public class VZWPrepaySavedCreditCardDetailsVO implements Serializable {

    private static final long serialVersionUID = 1L;

    private String creditCardNumber;
    private String creditCardType;
    private String creditCardExpiryMonth;
    private String creditCardExpiryYear;
    private boolean autoPayEnabled;

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    private String zipCode;

    private boolean savedCard;


    public boolean isSavedCard() {
        return savedCard;
    }

    public void setSavedCard(boolean savedCard) {
        this.savedCard = savedCard;
    }

    public boolean isAutoPayEnabled() {
        return autoPayEnabled;
    }

    public void setAutoPayEnabled(boolean autoPayEnabled) {
        this.autoPayEnabled = autoPayEnabled;
    }





    public String getCreditCardNumber() {
        return creditCardNumber;
    }

    public void setCreditCardNumber(String creditCardNumber) {
        this.creditCardNumber = creditCardNumber;
    }

    public String getCreditCardType() {
        return creditCardType;
    }

    public void setCreditCardType(String creditCardType) {
        this.creditCardType = creditCardType;
    }

    public String getCreditCardExpiryMonth() {
        return creditCardExpiryMonth;
    }

    public void setCreditCardExpiryMonth(String creditCardExpiryMonth) {
        this.creditCardExpiryMonth = creditCardExpiryMonth;
    }

    public String getCreditCardExpiryYear() {
        return creditCardExpiryYear;
    }

    public void setCreditCardExpiryYear(String creditCardExpiryYear) {
        this.creditCardExpiryYear = creditCardExpiryYear;
    }
}
