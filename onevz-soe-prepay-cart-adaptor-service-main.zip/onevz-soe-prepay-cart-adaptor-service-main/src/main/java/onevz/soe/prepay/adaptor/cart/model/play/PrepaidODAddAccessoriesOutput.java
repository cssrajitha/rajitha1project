package onevz.soe.prepay.adaptor.cart.model.play;

import lombok.Data;

@Data
public class PrepaidODAddAccessoriesOutput {
	private boolean itemRemoved;
	private boolean itemAdded;
	private String orderId;
	private String sorId;
	private String accCommerceId;
}
