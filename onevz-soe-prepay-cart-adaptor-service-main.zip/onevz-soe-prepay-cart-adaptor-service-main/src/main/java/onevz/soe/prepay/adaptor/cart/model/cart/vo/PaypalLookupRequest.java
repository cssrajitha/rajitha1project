package onevz.soe.prepay.adaptor.cart.model.cart.vo;

import java.io.Serializable;

public class PaypalLookupRequest implements Serializable{

	private static final long serialVersionUID = 1L;
	private String orderId;
	private String flow;

	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getFlow() {
		return flow;
	}
	public void setFlow(String flow) {
		this.flow = flow;
	}
	
}