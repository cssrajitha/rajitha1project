package onevz.soe.prepay.adaptor.cart.model.cart.vo;
import lombok.Data;

@Data
public class VZWPrepayEditCartResponsePayload {
    private VZWPrepayEditCartResponsePageData pageData;

}
