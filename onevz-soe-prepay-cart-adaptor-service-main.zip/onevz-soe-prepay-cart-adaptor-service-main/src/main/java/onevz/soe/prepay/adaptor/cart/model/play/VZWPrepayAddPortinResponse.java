package onevz.soe.prepay.adaptor.cart.model.play;

import lombok.Data;

@Data

public class VZWPrepayAddPortinResponse {
    private Integer status;
    private String statusCode;
    private VZWAddPortinPayload payload;
    private Errors errors;
}
