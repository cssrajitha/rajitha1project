package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;


public class TradeInInfo implements Serializable{
	//set serialVersionUID to default to fix class cast issues during de-serialization
	//Please do not change it
	private static final long serialVersionUID = 1L;
	private String id;
	private int version;
	private String tradeInReferenceNumber;
	private String tradeInPromoCode;
	private BigDecimal totalTradeInAmount; // total traded devices Amount value
	private List<TradeInDevice> tradeInDeviceList;
	private String orderId;
	private BigDecimal consolidatedMonthlyCredit;
	private BigDecimal consolidatedOneTimeCredit;
	private String tradeinOrderStatus;
	public BigDecimal getConsolidatedMonthlyCredit() {
		return consolidatedMonthlyCredit;
	}
	public void setConsolidatedMonthlyCredit(BigDecimal consolidatedMonthlyCredit) {
		this.consolidatedMonthlyCredit = consolidatedMonthlyCredit;
	}
	public BigDecimal getConsolidatedOneTimeCredit() {
		return consolidatedOneTimeCredit;
	}
	public void setConsolidatedOneTimeCredit(BigDecimal consolidatedOneTimeCredit) {
		this.consolidatedOneTimeCredit = consolidatedOneTimeCredit;
	}
	/**
	 * @return the orderId
	 */
	public String getOrderId() {
		return orderId;
	}
	/**
	 * @param orderId the orderId to set
	 */
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the version
	 */
	public int getVersion() {
		return version;
	}
	/**
	 * @param version the version to set
	 */
	public void setVersion(int version) {
		this.version = version;
	}
	public String getTradeInReferenceNumber() {
		return tradeInReferenceNumber;
	}
	public void setTradeInReferenceNumber(String tradeInReferenceNumber) {
		this.tradeInReferenceNumber = tradeInReferenceNumber;
	}
	public String getTradeInPromoCode() {
		return tradeInPromoCode;
	}
	public void setTradeInPromoCode(String tradeInPromoCode) {
		this.tradeInPromoCode = tradeInPromoCode;
	}
	public BigDecimal getTotalTradeInAmount() {
		return totalTradeInAmount;
	}
	public void setTotalTradeInAmount(BigDecimal totalTradeInAmount) {
		this.totalTradeInAmount = totalTradeInAmount;
	}
	public List<TradeInDevice> getTradeInDeviceList() {
		if(null == tradeInDeviceList){
			tradeInDeviceList = new ArrayList<>();
		}
		return tradeInDeviceList;
	}
	public void setTradeInDeviceList(List<TradeInDevice> tradeInDeviceList) {
		this.tradeInDeviceList = tradeInDeviceList;
	}

	public String getTradeinOrderStatus() {
		return tradeinOrderStatus;
	}

	public void setTradeinOrderStatus(String tradeinOrderStatus) {
		this.tradeinOrderStatus = tradeinOrderStatus;
	}
}
