package onevz.soe.prepay.adaptor.cart.util;

import onevz.soe.cart.model.common.CartServiceCartInfo;
import onevz.soe.cart.model.common.CartServiceCustomerInfo;
import onevz.soe.cart.model.common.CartServiceServiceHeader;
import onevz.soe.cart.model.common.PortLine;
import onevz.soe.cart.model.common.ProcessMTNList;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.common.model.PrepaidODRequestDataLines;
import onevz.soe.assignmtn.request.pega.AssignMtnCartServiceCustomerInfo;
import onevz.soe.assignmtn.request.pega.PegaPortInContext;
import onevz.soe.assignmtn.request.pega.PegaServiceResponse;
import onevz.soe.assignmtn.reponse.pega.PortinPEGAResponse;
import onevz.soe.assignmtn.request.pega.PegaServiceRequest;
import onevz.soe.assignmtn.request.pega.PegaPortinCartInfo;
import onevz.soe.assignmtn.request.pega.PortinServiceBody;
import onevz.soe.assignmtn.request.pega.PortinPEGARequest;
import onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants;
import onevz.soe.prepay.adaptor.cart.model.play.VZWPrepayAddPortinRequest;
import onevz.soe.prepay.adaptor.cart.model.play.VZWPrepayAddPortinResponse;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.bpm.model.request.ContextInfo;
import onevz.soe.wsclient.bpm.model.response.AvailablePaths;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class PrepayAddPortinFormatterUtil {

    private PrepayAddPortinFormatterUtil(){

    }

    private static final Logger logger = LoggerFactory.getLogger(PrepayAddPortinFormatterUtil.class);

    public static VZWPrepayAddPortinRequest getVZWPrepayAddPortinRequest(PortinPEGARequest bpmServiceRequest, PrepaidODRequestData redisData){

		PortinServiceBody serviceBody = bpmServiceRequest.getServiceBody();
		PegaServiceRequest serviceRequest = serviceBody.getServiceRequest();
		PegaPortInContext context = serviceRequest.getContext();
		PegaPortinCartInfo cartInfo = context.getCartInfo();
		
		PortLine[] lines = cartInfo.getPortLines();
		String mtn = Objects.nonNull(lines)?lines[0].getMtn():"";
		String lineItemId = "";
		
		if(Objects.nonNull(redisData) && CollectionUtilities.isNotEmptyOrNull(redisData.getLines())) {
			List<PrepaidODRequestDataLines> dataLines = redisData.getLines().stream().filter(line->line.getMtn().equalsIgnoreCase(mtn)).collect(Collectors.toList());
			lineItemId = CollectionUtilities.isNotEmptyOrNull(dataLines)?dataLines.get(0).getLineItemId():"";
		}
		
		VZWPrepayAddPortinRequest vzwPrepayAddPortinRequest = new VZWPrepayAddPortinRequest();
		vzwPrepayAddPortinRequest.setLineItemId(lineItemId);

        if(lines != null && lines.length > 0) {
            PortLine portLine = lines[0];
            String firstName = "";
            String lastName = "";
            String contactNumber = "";
            
            if(Objects.nonNull(portLine) && Objects.nonNull(redisData)) {
            	firstName = Objects.nonNull(portLine.getFirstName())?portLine.getFirstName():redisData.getFirstName();
            	lastName = Objects.nonNull(portLine.getLastName())?portLine.getLastName():redisData.getLastName();
            	contactNumber = Objects.nonNull(portLine.getContactNumber())?portLine.getContactNumber():redisData.getContactNumber();
            
	            vzwPrepayAddPortinRequest.setLastName(lastName);
	            vzwPrepayAddPortinRequest.setAccountPin(portLine.getAccountPinOrPassword());
	            vzwPrepayAddPortinRequest.setContactNumber(StringUtilities.removeAll(contactNumber,"."));
	            vzwPrepayAddPortinRequest.setExistingAccountNumber(portLine.getAccountNumber());
	            vzwPrepayAddPortinRequest.setCity(portLine.getCity());
	            vzwPrepayAddPortinRequest.setZipCode(portLine.getZipCode());
	            vzwPrepayAddPortinRequest.setState(portLine.getState());
	            vzwPrepayAddPortinRequest.setExistingNumber(StringUtilities.removeAll(portLine.getPortInNumber(),"."));
	            vzwPrepayAddPortinRequest.setFirstName(firstName);
	            vzwPrepayAddPortinRequest.setAddress1(portLine.getAddress1());
	            vzwPrepayAddPortinRequest.setAddress2(portLine.getAddress2());
            }
        }
        return vzwPrepayAddPortinRequest;
    }

    private static CartServiceServiceHeader getResponseCartServiceHeader
            ( PortinPEGARequest bpmServiceRequest, VZWPrepayAddPortinResponse vzwPrepayAddPortinResponse){

        String statusMsg = "";
        String statusCode = "";
  
        if(Objects.nonNull(vzwPrepayAddPortinResponse.getPayload())){
        	statusMsg = PrepayAdaptorCartConstants.SUCCESS_MSG;
            statusCode = vzwPrepayAddPortinResponse.getStatusCode();
        }else {
            statusMsg = PrepayAdaptorCartConstants.FAILURE_MSG;
            statusCode = vzwPrepayAddPortinResponse.getStatusCode();
        }
        CartServiceServiceHeader cartServiceServiceHeader = new CartServiceServiceHeader();
        cartServiceServiceHeader.setClientId(bpmServiceRequest.getServiceHeader().getClientId());
        cartServiceServiceHeader.setStatusMsg(statusMsg);
        cartServiceServiceHeader.setCorrelationId(bpmServiceRequest.getServiceHeader().getCorrelationId());
        cartServiceServiceHeader.setSessionId(bpmServiceRequest.getServiceHeader().getSessionId());
        cartServiceServiceHeader.setServiceName(bpmServiceRequest.getServiceHeader().getServiceName());
        cartServiceServiceHeader.setUserId(bpmServiceRequest.getServiceHeader().getUserId());
        cartServiceServiceHeader.setStatusCode(statusCode);
        return cartServiceServiceHeader;
    }

    private static PegaPortInContext getResponsePegaPortInContext(PortinPEGARequest bpmServiceRequest,VZWPrepayAddPortinResponse vzwPrepayAddPortinResponse, PrepaidODRequestData redisData, String enableSecurePin){

        PegaPortInContext pegaPortInContext = new PegaPortInContext();
    	ProcessMTNList listData = new ProcessMTNList();
		
        ContextInfo contextInfo = new ContextInfo();
        contextInfo.setCallReason(bpmServiceRequest.getServiceHeader().getServiceName());
        AvailablePaths availablePath = new AvailablePaths();

        if(redisData.isNumberAssignedToAllLines()) {
          	contextInfo.setProcessStep(PrepayAdaptorCartConstants.ACCOUNT_PIN_PROCESS_STEP);
	       	availablePath.setPath(PrepayAdaptorCartConstants.ACCOUNT_PIN_PROCESS_STEP);
        } else {
        	contextInfo.setProcessStep(PrepayAdaptorCartConstants.ASSIGN_NUMBERS_PROCESS_STEP);
        	availablePath.setPath(PrepayAdaptorCartConstants.ASSIGN_NUMBERS_PROCESS_STEP);
        }
        List<AvailablePaths> availablePaths = new ArrayList<>();
        availablePaths.add(availablePath);
        contextInfo.setAvailablePaths(availablePaths);
        contextInfo.setProcessAction("");
        contextInfo.setIntent(bpmServiceRequest.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());

        CartServiceCustomerInfo cartServiceCustomerInfo = new CartServiceCustomerInfo();
        AssignMtnCartServiceCustomerInfo assignmtnCustInfo = new AssignMtnCartServiceCustomerInfo();
        cartServiceCustomerInfo.setCustomerType((bpmServiceRequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCustomerType()));
        cartServiceCustomerInfo.setAccountNumber(bpmServiceRequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getAccountNumber());
        cartServiceCustomerInfo.setCartCreator(bpmServiceRequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCartCreator());
        cartServiceCustomerInfo.setRegisterNumber(bpmServiceRequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getRegisterNumber());
        cartServiceCustomerInfo.setGlobalId(bpmServiceRequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getGlobalId());
  
        assignmtnCustInfo.setCustomerType((bpmServiceRequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCustomerType()));
        assignmtnCustInfo.setAccountNumber(bpmServiceRequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getAccountNumber());
        assignmtnCustInfo.setCartCreator(bpmServiceRequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCartCreator());
        assignmtnCustInfo.setRegisterNumber(bpmServiceRequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getRegisterNumber());
        assignmtnCustInfo.setGlobalId(bpmServiceRequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getGlobalId());

        String requestMtn = bpmServiceRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0].getMtn();
        CartServiceCartInfo cartServiceCartInfo = new CartServiceCartInfo();
        PegaPortinCartInfo portInCartInfo = new PegaPortinCartInfo();
        PortLine[] responseLines = new PortLine[1];
        PortLine line = new PortLine();
        ProcessMTNList[] mtnList = new ProcessMTNList[1];
        
        if(Objects.nonNull(vzwPrepayAddPortinResponse.getPayload())){
        	cartServiceCustomerInfo.setProcessingMTN(nextProcessingMtn(requestMtn, redisData));
        	assignmtnCustInfo.setProcessingMTN(nextProcessingMtn(requestMtn, redisData));
        	listData.setMtn(nextProcessingMtn(requestMtn,redisData));
        	line.setStatus(1);
        	cartServiceCartInfo.setStatusCode("1");
        	cartServiceCartInfo.setStatusMsg(PrepayAdaptorCartConstants.SUCCESS_MSG);
        	portInCartInfo.setStatusCode("1");
        	portInCartInfo.setStatusMsg(PrepayAdaptorCartConstants.SUCCESS_MSG);
        } else {
        	cartServiceCustomerInfo.setProcessingMTN(requestMtn); 
        	assignmtnCustInfo.setProcessingMTN(requestMtn); 
        	listData.setMtn(requestMtn);
        	line.setStatus(0);
        	cartServiceCartInfo.setStatusCode("0");
        	cartServiceCartInfo.setStatusMsg(PrepayAdaptorCartConstants.FAILURE_MSG);
        	portInCartInfo.setStatusCode("0");
        	portInCartInfo.setStatusMsg(PrepayAdaptorCartConstants.FAILURE_MSG);
        }
        mtnList[0] = listData;
        
        if(Objects.nonNull(vzwPrepayAddPortinResponse.getPayload())) {
            line.setMtn(vzwPrepayAddPortinResponse.getPayload().getPageData().getTransferNumberDetails().get(0).getUpdatedNpaNxxNumber());
        }
        if(Objects.nonNull(bpmServiceRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines())) {
        	line.setLineNumber(bpmServiceRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0].getMtn());
        }
        line.setLineActivityType(bpmServiceRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
        if(Objects.nonNull(vzwPrepayAddPortinResponse.getPayload().getPageData().getTransferNumberDetails())) {
        	line.setMtn(vzwPrepayAddPortinResponse.getPayload().getPageData().getTransferNumberDetails().get(0).getUpdatedNpaNxxNumber());
        }
        line.setCurrentPlanType("");
        responseLines[0] = line;
        cartServiceCartInfo.setLines(responseLines);
        portInCartInfo.setLines(responseLines);
        pegaPortInContext.setProcessMTNList(mtnList);
        pegaPortInContext.setCaseId(null);
        pegaPortInContext.setContextInfo(contextInfo);
        pegaPortInContext.setCustomerInfo(cartServiceCustomerInfo);
        pegaPortInContext.setCustomerInfo(assignmtnCustInfo);
        pegaPortInContext.setCartInfo(cartServiceCartInfo);
        pegaPortInContext.setCartInfo(portInCartInfo);

        return pegaPortInContext;
    }

    public static PortinPEGAResponse getPortinPEGAResponse(PortinPEGARequest bpmServiceRequest, VZWPrepayAddPortinResponse vzwPrepayAddPortinResponse, PrepaidODRequestData redisData, String enableSecurePin){
        PortinPEGAResponse portinPEGAResponse = new PortinPEGAResponse();
        portinPEGAResponse.setServiceHeader(getResponseCartServiceHeader(bpmServiceRequest,  vzwPrepayAddPortinResponse));
        PortinServiceBody portinServiceBody = new PortinServiceBody();
        PegaServiceResponse pegaServiceResponse = new PegaServiceResponse();
        pegaServiceResponse.setContext(getResponsePegaPortInContext(bpmServiceRequest, vzwPrepayAddPortinResponse, redisData, enableSecurePin));
        portinServiceBody.setServiceResponse(pegaServiceResponse);
        portinPEGAResponse.setServiceBody(portinServiceBody);
        return  portinPEGAResponse;
    }
    
    private static String nextProcessingMtn(String requestMtn, PrepaidODRequestData redisData) {
    	
    	logger.info("Mtn in add-portin request: {}", requestMtn);
    	String nextMtn = "";
    	
    	if(Objects.nonNull(redisData)) {
    		
	    	if(redisData.isNumberAssignedToAllLines()) {
	    		nextMtn = redisData.getLines().get(0).getMtn();	
	    	} else {
	    		
	    		 List<String> remainingMtns = redisData.getLines().stream().filter(line -> !line.isNumAssigned())
	    		 							  .map(filteredLines -> filteredLines.getMtn()).collect(Collectors.toList());
	    		 remainingMtns.remove(requestMtn);
	    		 nextMtn = remainingMtns.get(0);
	    	}
    	}
    	logger.info("Next Processing Mtn: {}", nextMtn);
    	return nextMtn;
    }

}
