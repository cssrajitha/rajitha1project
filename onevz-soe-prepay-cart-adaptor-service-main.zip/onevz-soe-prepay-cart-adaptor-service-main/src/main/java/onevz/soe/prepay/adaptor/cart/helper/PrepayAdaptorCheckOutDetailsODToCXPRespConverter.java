package onevz.soe.prepay.adaptor.cart.helper;

import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.common.model.PrepaidODRequestDataAccessorySkuIds;
import onevz.soe.common.model.PrepaidODRequestDataLines;
import onevz.soe.orderprocess.model.checkoutdetails.*;
import onevz.soe.orderprocess.request.CheckoutDetailsCXPRequest;
import onevz.soe.orderprocess.response.cxp.CheckoutDetailsCXPResponse;
import onevz.soe.orderprocess.response.cxp.CheckoutDetailsResponseData;
import onevz.soe.prepay.adaptor.cart.constants.CartValidationErrorEnum;
import onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants;
import onevz.soe.prepay.adaptor.cart.model.cart.vo.*;
import onevz.soe.prepay.adaptor.cart.model.play.VZWPrepayOrderVO;
import onevz.soe.prepay.adaptor.cart.model.play.shippingoptions.AvailableDeliveryWindows;
import onevz.soe.prepay.adaptor.cart.model.play.shippingoptions.ShippingOption;
import onevz.soe.prepay.adaptor.cart.model.play.shippingoptions.VZWPrepayShippingResponseVO;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpCookie;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.*;

@Component
public class PrepayAdaptorCheckOutDetailsODToCXPRespConverter {

    private static final Logger logger = LoggerFactory.getLogger(PrepayAdaptorCheckOutDetailsODToCXPRespConverter.class);

	@Value("${enablePricePlanRefresh}")
	private String enablePricePlanRefresh;


    public CheckoutDetailsCXPResponse translateCheckoutDetails(VZWPrepayOrderVO pageData, PrepaidODRequestData prepaidODRequestData, ServerHttpRequest httpRequest, CheckoutDetailsCXPRequest checkoutDetailsCXPRequest) {

        CheckoutDetailsCXPResponse checkoutDetailsCXPResponse = new CheckoutDetailsCXPResponse();
        CheckoutDetailsResponseData checkoutDetailsResponseData = new CheckoutDetailsResponseData();

        checkoutDetailsCXPResponse.setData(checkoutDetailsResponseData);
        Meta meta = new Meta();
        checkoutDetailsCXPResponse.setMeta(meta);
        if (null == pageData) return checkoutDetailsCXPResponse;

        checkoutDetailsCXPResponse.getData().setEnableFamilyPricing(pageData.isEnableFamilyPricing());

        Cart cart = new Cart();
        /*********Cart::Start***********/

        setPricePlanRefreshFlag(cart);

        cart.setHolidayReturnPolicyEnabled(pageData.isHolidayPolicyEnable());
        cart.setEnableIphoneSEPromo(pageData.isEnableIphoneSEPromo());
        cart.setDevicePromotionId(pageData.getDevicePromotionId());



        /*********CartHeader::Start***********/
        CartHeader cartHeader = new CartHeader();
        cartHeader.setSourceSystem(getChannelId(httpRequest));
        populatecartId(checkoutDetailsCXPRequest, cartHeader);
        populateOrderZipCode(pageData, prepaidODRequestData, cartHeader);

        cartHeader.setSessionId(pageData.getSessionId());
        cartHeader.setCartCreatorChannelId(getChannelId(httpRequest));
        populateEmailAddress(pageData, cartHeader);
        cart.setCartHeader(cartHeader);
        /*********CartHeader::End***********/

        /*********Orderdetails::Start***********/
        OrderDetails orderDetails = new OrderDetails();
        orderDetails.setTotalTaxAmount(pageData.getOrderTax());
        orderDetails.setTotalDueToday(pageData.getOrderTotal());
        orderDetails.setTotalDueMonthly(pageData.getDueMonthly());
        orderDetails.setSubTotalDueMonthly(pageData.getDueMonthly());
        orderDetails.setOrderChannelId(getChannelId(httpRequest));
        if(StringUtilities.isNotEmptyOrNull(pageData.getOrderNumber())){
            orderDetails.setOrderNumber(Long.parseLong(pageData.getOrderNumber()));
        }
        orderDetails.setCustomerType(getCustomerTypeBasedOnFlow(pageData.getFlow()));
        orderDetails.setSubTotalDueToday(pageData.getDueToday());
        orderDetails.setSubTotalDueTodayWithoutUpgradeFee(pageData.getDueToday());
        orderDetails.setTotalBTAEligibleAmount(pageData.getOrderTotal());
        orderDetails.setRunningTotalDueToday(pageData.getOrderTotal());
        orderDetails.setTotalDueMonthlyAfterDiscounts(pageData.getDueMonthly());
        orderDetails.setTotalActivationFees(pageData.getTotalActivationfee());
        Address billngAddress = getAddressFromAccountInfo(pageData.getBillingAddress());
        orderDetails.setBillingState(null!=billngAddress.getState()?billngAddress.getState():null);
        orderDetails.setAutoPayEnabled(pageData.isAutoPayEnabled());
        orderDetails.setAutoPaySavings(pageData.getAutopaySavings());

        //orderdetails.spocs
        setSpocDetails(billngAddress, orderDetails);

        //orderdetails.orderlist
        ArrayList<OrderList> orderLists = new ArrayList<>();
        OrderList orderList = new OrderList();
        if(StringUtilities.isNotEmptyOrNull(pageData.getOrderNumber())){
            orderList.setOrderNumber(Long.parseLong(pageData.getOrderNumber()));
        }
        orderList.setDigitalOrderId(pageData.getOrderNumber());
        settingOrderActivityType(pageData, orderList);
        orderLists.add(orderList);
        orderDetails.setOrderList(orderLists);

        //orderdetails.chargeSummary
        ArrayList<ChargeSummary> chargeSummaryItemsList = new ArrayList<>();
        ChargeSummary chargeSummaryItem = new ChargeSummary();
        chargeSummaryItem.setChargeType(CHARGE_TYPE);
        chargeSummaryItemsList.add(chargeSummaryItem);
        orderDetails.setChargeSummary(chargeSummaryItemsList);

        //orderDetails.cartTotalDiscounts
        DiscountSummary discountSummary = getDiscountSummary(pageData);

        //TODO:: need to iterate over the pageData.getPromotions and populate the CartPomoInfo and set OfferAmount
        //pageData.getPromotions()

        orderDetails.setCartTotalDiscounts(discountSummary);

        //orderDetails.getTaxDetailsList(); //TODO:: Need to revisit below orderdetail.getTaxdetails -- pageData.getTaxDetailsList

        /*********Orderdetails::End***********/

        /************LineDeatils::Start****************/
        LineDetails lineDetails = new LineDetails();
        setNumOfLines(pageData, lineDetails);
        lineDetails.setNumOfAccessoryAndDeviceItemsInCart(CollectionUtils.size(pageData.getDeviceList())
                + CollectionUtils.size(pageData.getAccessoryList()));
        lineDetails.setIsAutoPayEnrolled(pageData.isAutoPayEnabled()?"Y":"N");

        //*****linedetails.payments--start
        ArrayList<CartPaymentInfo> cartPaymentInfos = new ArrayList<>();
        CartPaymentInfo cartPaymentInfo = new CartPaymentInfo();
        cartPaymentInfo.setPaymentSequence(1);

        cartPaymentInfo.setPaymentAmount((float)pageData.getOrderTotal());
        cartPaymentInfo.setPaymRegisterNum("30");
        CreditCardPayment creditCardPayment = new CreditCardPayment();
        PaypalPaymentDetails paypalDetails = new PaypalPaymentDetails();
        PaypalPaymentAuthenticateDetails paypalPayment = new PaypalPaymentAuthenticateDetails();
        String paymentMethod=null;
        if(StringUtilities.isNotEmptyOrNull(pageData.getPaymentMethod())) {
            if(PAYMENT_METHOD_PAYPAL.equalsIgnoreCase(pageData.getPaymentMethod())){
                cartPaymentInfo.setPaymentType("PY");
                paypalPayment.setPaypal_orderNumber(pageData.getOrderNumber());
                paypalPayment.setPaypal_processorUserEmail(pageData.getPaypalInfo());
                paypalPayment.setPaypal_shippingMethod(pageData.getShippingMethod());
                paypalPayment.setPaypal_paymentMethod(PrepayAdaptorCartConstants.PAYPAL);
                	
                if(Objects.nonNull(pageData.getBillingAddress()) && Objects.nonNull(pageData.getBillingAddress().getAddress())) {
                	paypalPayment.setPaypal_processorBillingAddress1(Objects.nonNull(pageData.getBillingAddress().getAddress().getAddressLine1())?pageData.getBillingAddress().getAddress().getAddressLine1():"");
                	paypalPayment.setPaypal_processorBillingAddress2(Objects.nonNull(pageData.getBillingAddress().getAddress().getAddressLine2())?pageData.getBillingAddress().getAddress().getAddressLine2():"");
                	paypalPayment.setPaypal_processorBillingCity(Objects.nonNull(pageData.getBillingAddress().getAddress().getCity())?pageData.getBillingAddress().getAddress().getCity():"");
                	paypalPayment.setPaypal_processorBillingState(Objects.nonNull(pageData.getBillingAddress().getAddress().getState())?pageData.getBillingAddress().getAddress().getState():"");
                	paypalPayment.setPaypal_processorBillingPostalCode(Objects.nonNull(pageData.getBillingAddress().getAddress().getZip())?pageData.getBillingAddress().getAddress().getZip():"");
                	String name ="";
                	
                	if(Objects.nonNull(pageData.getBillingAddress().getFirstName()) && Objects.nonNull(pageData.getBillingAddress().getLastName())) {
                		name = pageData.getBillingAddress().getFirstName() + pageData.getBillingAddress().getLastName();
                	}
                	paypalPayment.setPaypal_processorBillingFullName(Objects.nonNull(pageData.getBillingAddress().getFullName())?pageData.getBillingAddress().getFullName():name);
                	
                }
                paypalDetails.setPaypalPaymentAuthenticateDetails(paypalPayment);
                cartPaymentInfo.setPaypalPaymentDetails(paypalDetails);
            } else if(PAYMENT_METHOD_APPLEPAY.equalsIgnoreCase(pageData.getPaymentMethod())) {
                cartPaymentInfo.setPaymentType("AP");
            } else { //set credit card type VISA 1111
                paymentMethod = pageData.getPaymentMethod().toUpperCase();
                String[] paymentMethodTokens = paymentMethod.split(" ");
                if(2 == paymentMethodTokens.length){
                    if (CR_PAYMENT_METHODS.contains(paymentMethodTokens[0].trim().toUpperCase())) {
                        cartPaymentInfo.setPaymentType(PAYMENT_OPTION_CREDITCARD_TYPE);
                    }
                    creditCardPayment.setCardNumber(paymentMethodTokens[1]);
                }
                creditCardPayment.setCardType(paymentMethodTokens[0]);
                creditCardPayment.setCardAddressZip(billngAddress.getZipCode());
                creditCardPayment.setPreAuthCheck(false);
                CardAdditionalInfo cardAdditionalInfo = new CardAdditionalInfo();
                cardAdditionalInfo.setFirstName(billngAddress.getFirstName());
                cardAdditionalInfo.setLastName(billngAddress.getLastName());
                cardAdditionalInfo.setAddressLine1(billngAddress.getAddressLine1());
                cardAdditionalInfo.setCity(billngAddress.getCity());
                cardAdditionalInfo.setState(billngAddress.getState());
                creditCardPayment.setCardAdditionalInfo(cardAdditionalInfo);
                cartPaymentInfo.setCreditCardDetails(creditCardPayment);
            }
            if(StringUtilities.isNotEmptyOrNull(pageData.getOrderNumber())){
                cartPaymentInfo.setOrderNumber(Long.parseLong(pageData.getOrderNumber()));
            }
            cartPaymentInfos.add(cartPaymentInfo);
            lineDetails.setPayments(cartPaymentInfos);
        }
        if(CollectionUtilities.isNotEmptyOrNull(pageData.getRefillCards())){
            cartPaymentInfos.add(getRefillCartPaymentInfo(pageData));
            lineDetails.setPayments(cartPaymentInfos);
        }
        //*****linedetails.payments--end

        //*****linedetails.lininfo --start
        lineDetails.setLineInfo(getLineInfo(pageData, prepaidODRequestData, orderDetails));
        cart.setLineDetails(lineDetails);
        //*****linedetails.lininfo --end
        /************LineDeatils::End****************/

        /**********GlobalPromotions::Start****************/
        GlobalPromotions globalPromotions = new GlobalPromotions();
        ArrayList<PromoDetails> promoDetailsList = new ArrayList<>();

        List<VZWPrepayPromotion> prepayPromotionList = pageData.getPromotions();
        if(CollectionUtilities.isNotEmptyOrNull(prepayPromotionList)){
            for (VZWPrepayPromotion vzwPrepayPromotion : prepayPromotionList) {
                PromoDetails promoDetails = new PromoDetails();
                promoDetails.setSkuId(vzwPrepayPromotion.getSkuId());
                promoDetails.setPromotionId(vzwPrepayPromotion.getBarCode());
                promoDetailsList.add(promoDetails);
            }
            globalPromotions.setPromoDetails(promoDetailsList);
        }
        cart.setGlobalPromotions(globalPromotions);
        /**********GlobalPromotions::End****************/

        /**********CartValidationErrors::Start****************/
        ArrayList<CartValidationErrors> cartValidationErrorsList = getCartValidationErrors(cart,prepaidODRequestData);
        cart.setCartValidationErrors(cartValidationErrorsList);
        /**********CartValidationErrors::End****************/

        setHubReadyFlag(prepaidODRequestData, cart);
        cart.setOrderDetails(orderDetails);
        cart.setEditType(Objects.nonNull(prepaidODRequestData)?prepaidODRequestData.getEditType():"");
        checkoutDetailsResponseData.setCart(cart);
        /*********Cart::End***********/


        /*********PaymentOptions::Start***********/
        Payment payment = new Payment();
        payment.setOrderTotal((int)pageData.getOrderTotal());

        setPaymentOptions(payment, pageData);
        checkoutDetailsResponseData.setPayment(payment);
        /*********PaymentOptions::End***********/

        /*********shipment************/
        checkoutDetailsResponseData.getShipment();
        return checkoutDetailsCXPResponse;
    }

    private static void populateEmailAddress(VZWPrepayOrderVO pageData, CartHeader cartHeader) {
        if(null!= pageData.getAccountInfo() && null!= pageData.getAccountInfo().getAddress()
                && StringUtilities.isNotEmptyOrNull(pageData.getAccountInfo().getAddress().getEmailAddress()))
            cartHeader.setEmailAddress(pageData.getAccountInfo().getAddress().getEmailAddress());
    }

    private static void populatecartId(CheckoutDetailsCXPRequest checkoutDetailsCXPRequest, CartHeader cartHeader) {
        if(null!= checkoutDetailsCXPRequest && null!= checkoutDetailsCXPRequest.getData()
                && StringUtilities.isNotEmptyOrNull(checkoutDetailsCXPRequest.getData().getCartId()))
            cartHeader.setCartId(checkoutDetailsCXPRequest.getData().getCartId());
    }

    private static DiscountSummary getDiscountSummary(VZWPrepayOrderVO pageData) {
        DiscountSummary discountSummary = new DiscountSummary();
        double totalDeviceDiscount = pageData.getTotalDevicesDiscount();
        double totalAccessoriesDiscount = pageData.getTotalAccessoriesDiscount();
        double autoPayDiscount = pageData.getAutopaySavings();
        double orderDiscAmt = pageData.getOrderDiscount();
        double multiLineDiscount = 0.0;
        double smartphoneTotalMLDiscount = 0.0;  //PREGRO-6429_Family_Pricing
        double totalBundleDiscount=0.0;

        List<PrepayPlanVO> prepayPlanList = pageData.getPlanList();

        for(PrepayPlanVO prepayPlan : prepayPlanList) {

            //PREGRO-6434_Family_Pricing
            if(pageData.isEnableFamilyPricing() && !prepayPlan.isBundleDiscountApplied() && prepayPlan.getDescription()!=null && (prepayPlan.getDescription().contains("Smartphone")
                            || prepayPlan.getDescription().contains("Unlimited"))){
                smartphoneTotalMLDiscount += (prepayPlan.getActualPlanPrice() - prepayPlan.getDueToday());
            }else if(!prepayPlan.isBundleDiscountApplied()){
                multiLineDiscount += (prepayPlan.getActualPlanPrice() - prepayPlan.getDueToday());
            }
            if(prepayPlan.isBundleDiscountApplied()){
                totalBundleDiscount += prepayPlan.getPlanBundleDiscount();
            }
        }
        discountSummary.setTotalDiscount(String.valueOf(orderDiscAmt != 0.0?orderDiscAmt+autoPayDiscount+multiLineDiscount+smartphoneTotalMLDiscount+totalBundleDiscount:totalDeviceDiscount+totalAccessoriesDiscount+autoPayDiscount+multiLineDiscount+smartphoneTotalMLDiscount+totalBundleDiscount));

        discountSummary.setTotalDevicesDiscount(totalDeviceDiscount);
        discountSummary.setTotalAccessoriesDiscount(totalAccessoriesDiscount);
        discountSummary.setTotalAutoPayDiscount(autoPayDiscount);
        discountSummary.setTotalMultiLineDiscount(multiLineDiscount);
        discountSummary.setSmartphoneTotalMLDiscount(smartphoneTotalMLDiscount);
        discountSummary.setAutoPayTotalAmount(pageData.getAutoPayTotalAmount());
        discountSummary.setTotalBundleDiscount(totalBundleDiscount);
        return discountSummary;
    }

    private static void setHubReadyFlag(PrepaidODRequestData prepaidODRequestData, Cart cart) {
        cart.setHubReadyForCheckout(prepaidODRequestData.getLines().stream().anyMatch(line -> line.isCheckoutFlag()));
    }

    private static void setSpocDetails(Address billngAddress, OrderDetails orderDetails) {
        Spocs spocs = new Spocs();
        NotificationOptions notificationOptions = new NotificationOptions();
        notificationOptions.setContactPhoneNumber(null!= billngAddress.getPhoneNumber()? billngAddress.getPhoneNumber():null);
        notificationOptions.setPrimaryEmailId(null!= billngAddress.getEmailId()? billngAddress.getEmailId():null);
        spocs.setNotificationOptions(notificationOptions);
        orderDetails.setSpocs(spocs);
    }

    private void setPricePlanRefreshFlag(Cart cart) {
        cart.setPricePlanRefreshEnabled("true".equalsIgnoreCase(enablePricePlanRefresh));
    }

    private static void setNumOfLines(VZWPrepayOrderVO pageData, LineDetails lineDetails) {
        if("NSE".equalsIgnoreCase(pageData.getFlow())) {
            lineDetails.setNumOfLines(pageData.getDeviceList().size());
        }
        if("PAL".equalsIgnoreCase(pageData.getFlow())) {
            lineDetails.setNumofLinesAAL(pageData.getDeviceList().size());
        }
        if("PUP".equalsIgnoreCase(pageData.getFlow())){
            lineDetails.setNumofLinesEUP(pageData.getDeviceList().size());
        }
    }

    private static void settingOrderActivityType(VZWPrepayOrderVO pageData, OrderList orderList) {
        String flow = pageData.getFlow();
        if(NSP.equalsIgnoreCase(flow) || NAP.equalsIgnoreCase(flow)) {
            orderList.setOrderActivityType(NSE_BYOD);
        }else if(PAL.equalsIgnoreCase(flow)) {
            orderList.setOrderActivityType(AAL);
        }else if(PUP.equalsIgnoreCase(flow)) {
            orderList.setOrderActivityType(EUP);
        }else{
            orderList.setOrderActivityType(PASO.equalsIgnoreCase(flow)?BYOD:flow);
        }
    }

    private static void populateOrderZipCode(VZWPrepayOrderVO pageData, PrepaidODRequestData prepaidODRequestData, CartHeader cartHeader) {
        String orderZipCode = "";
        if(null!= pageData.getAccountInfo() && null!= pageData.getAccountInfo().getAddress()) {
        	orderZipCode=StringUtilities.isNotEmptyOrNull(pageData.getOrderZipcode())? pageData.getOrderZipcode():(Objects.nonNull(prepaidODRequestData)? prepaidODRequestData.getZipCode():"");
        }else {
        	orderZipCode=(Objects.nonNull(prepaidODRequestData)? prepaidODRequestData.getZipCode():"");
        }
        cartHeader.setCartCreatorZipCode(orderZipCode);
    }

    private ArrayList<CartLineInfo> getLineInfo(VZWPrepayOrderVO pageData, PrepaidODRequestData prepaidODRequestData, OrderDetails orderDetails) {

        ArrayList<CartLineInfo> cartLineInfoList = new ArrayList<>();
        if(null == pageData || null == pageData.getDeviceList()) return cartLineInfoList;
        int count = 1 ;
        boolean accessoryPresent=false;
        if(!pageData.getAccessoryList().isEmpty())
            accessoryPresent=true;

        AtomicReference<Double> totalFutureDiscount = new AtomicReference<>((double) 0);
        AtomicReference<Integer> futureDiscountMonths = new AtomicReference<>((int) 0);
        for(PrepayDeviceVO prepayLine : pageData.getDeviceList()){
            //*****lineInfoItem
            String mtn = getMTNFromPrepaidODRequestData(prepayLine, prepaidODRequestData);
            CartLineInfo lineInfoItem = new CartLineInfo();
            lineInfoItem.setMultiLineSeqNumber(count);
            String lineActivityType = populateLineActivityType(pageData, prepaidODRequestData, prepayLine);


            lineInfoItem.setLineActivityType(lineActivityType);
            lineInfoItem.setPortinMtnAssignment(prepayLine.isPortInDevice());
            lineInfoItem.setIspuEligible(false);
            lineInfoItem.setSddEligible(false);
            lineInfoItem.setMobileNumber(mtn);
            lineInfoItem.setIspuItem(false);
            lineInfoItem.setIspuItemBYOD(false);
            lineInfoItem.setIspuRepAssisted(false);
            lineInfoItem.setCpe(false);
            //lineInfoItem.setTotalDueMonthly(); //TODO:: plans total + feature monthly
            lineInfoItem.setLineNumber(mtn);
            lineInfoItem.setDeviceTypeSelected(prepayLine.getItemType());
            lineInfoItem.setLineSortingNumber(count);
            lineInfoItem.setAccountOwner(prepayLine.isAccountOwner()?"Y":"N");
            lineInfoItem.setLineSecurityPin(prepayLine.getLineSecurityPin());
            lineInfoItem.setSecurityQuestion(prepayLine.getSecurityQuestion());
            lineInfoItem.setSecurityAnswer(prepayLine.getSecurityAnswer());
            
            //*****lineInfoItem.serviceInfo------START
            ServiceInfo serviceInfo = new ServiceInfo();
            serviceInfo.setMtn(mtn);
            serviceInfo.setDacc(prepayLine.getDaccCode());

            //*****lineInfoItem.serviceInfo.primaryuserinfo
            PrimaryUserInfo primaryUserInfo = new PrimaryUserInfo();
            AccountInfoVO accountInfoFromBillingAddress = pageData.getBillingAddress();
            if(accountInfoFromBillingAddress !=null){
                primaryUserInfo.setFirstName(accountInfoFromBillingAddress.getFirstName());
                primaryUserInfo.setLastName(accountInfoFromBillingAddress.getLastName());
                Address address = getAddressFromAccountInfo(accountInfoFromBillingAddress);
                primaryUserInfo.setAddress(address);
                primaryUserInfo.setEmailId(address.getEmailId());
            }
            serviceInfo.setPrimaryUserInfo(primaryUserInfo);

            //*****lineInfoItem.serviceInfo.newpriceplanInfo
            PricePlanInfo pricePlanInfo = getPlanDetailsForLine(pageData,prepayLine,orderDetails);
            serviceInfo.setNewPricePlanInfo(pricePlanInfo);

            //*****lineInfoItem.serviceInfo.planDetails
            PlanDetails planDetails = new PlanDetails();

            //PREGRO-6434_Family_Pricing
            double planMLPrice = 0.0;
            if(pageData.isEnableFamilyPricing()){
                planMLPrice=  StringUtilities.isNotEmptyOrNull(pricePlanInfo.getActualPlanPrice()) &&
                        StringUtilities.isNotEmptyOrNull(pricePlanInfo.getDiscount()) ?
                        Double.parseDouble(pricePlanInfo.getActualPlanPrice()) - Double.parseDouble(pricePlanInfo.getDiscount()) : 0.0;
                planDetails.setPlanMLPrice(Double.toString(planMLPrice));
                planDetails.setPlanMLDiscount(pricePlanInfo.getPlanMLDiscount());
                planDetails.setAutoPaySaving(Objects.nonNull(pricePlanInfo.getAutoPaySaving())?(pricePlanInfo.getAutoPaySaving()):0.0);
                planDetails.setPlanDiscountedPrice(Objects.nonNull(pricePlanInfo.getPlanDiscountedPrice())?convertToIntFromString(pricePlanInfo.getPlanDiscountedPrice()): 0);
            }
            //Family_Pricing_End

            planDetails.setPlanPrice(null != pricePlanInfo? convertToIntFromString(pricePlanInfo.getPlanPrice()): 0);
            planDetails.setActualPlanPrice(StringUtilities.isNotEmptyOrNull(pricePlanInfo.getActualPlanPrice())?pricePlanInfo.getActualPlanPrice():"");
            planDetails.setDiscount(StringUtilities.isNotEmptyOrNull(pricePlanInfo.getDiscount())?pricePlanInfo.getDiscount():"0.0");
            planDetails.setDiscountedPrice(Objects.nonNull(pricePlanInfo.getDiscountedPrice())?String.valueOf(pricePlanInfo.getDiscountedPrice()):"0.0");
            planDetails.setDisneyPlusPromo(pricePlanInfo.isDisneyPlusPromo()?true:false);
            planDetails.setPlanBundleDiscount(pricePlanInfo.getPlanBundleDiscount());
            planDetails.setBundleDiscountEligible(pricePlanInfo.isBundleDiscountEligible());
            serviceInfo.setPlanDetails(planDetails);
                        

            //*****lineInfoItem.serviceInfo.selectedfeatureslist
            serviceInfo.setSelectedFeaturesList(getFeaturesListForLine(pageData, prepayLine));

            //*****lineInfoItem.serviceInfo.serviceAddress--start
            Address serviceAddress = getAddressFromAccountInfo(accountInfoFromBillingAddress);
            serviceInfo.setServiceAddress(serviceAddress);
            lineInfoItem.setServiceInfo(serviceInfo);
            //*****lineInfoItem.serviceInfo.serviceAddress--end
            //*****lineInfoItem.serviceInfo--------END

            //*****lineInfoItem.itemsInfo --------Start
            ArrayList<ItemsInfo> itemsInfoList = new ArrayList<>();
            ItemsInfo itemsInfo = new ItemsInfo();
            Shipping shipping = new Shipping();
            shipping.setShippingDescription(pageData.getShippingMethod());
            shipping.setShippingOptionId(pageData.getShippingOptionId());
            shipping.setShippingCode(pageData.getShippingOptionId());
            shipping.setShippingCost(pageData.getShippingPrice());  //TODO:: check to see if we need set discounted
            shipping.setDiscountedPrice(pageData.getShippingPrice());
            shipping.setEstimatedDeliveryDateText(pageData.getEstimatedDeliveryDate());//TODO::Formatting need to revisit
            shipping.setEstDeliveryDate(pageData.getEstimatedDeliveryDate());//TODO::Formatting need to revisit

            //*****lineInfoItem.itemsInfo.shipping --------Start
            Address shippingAddress = getAddressFromAccountInfo(pageData.getAccountInfo());
            shipping.setLastName(shippingAddress.getLastName());
            shipping.setFirstName(shippingAddress.getFirstName());
            shipping.setEmail(shippingAddress.getEmail());
            shipping.setCbrPhone(shippingAddress.getPhoneNumber());
            shipping.setAddress(shippingAddress);

            //itemsInfo.setShipping(shipping);
            //*****lineInfoItem.itemsInfo.shipping --------End

            //*****lineInfoItem.itemsInfo.cartItems --Start
            CartItems cartItems = new CartItems();
            ArrayList<CartItem> cartItemList = new ArrayList<>();

            cartItemList.add(getCartItemForDevice(pageData, prepayLine, mtn, orderDetails, prepaidODRequestData));

            cartItemList.forEach(cartItem ->
                    {
                        totalFutureDiscount.set(totalFutureDiscount.get()+cartItem.getFutureDiscount());

                        if(cartItem.getFutureDiscountMonths()>0)
                            futureDiscountMonths.set(cartItem.getFutureDiscountMonths());
                    });

            //Add SimItem to cartItems //TODO:: need check if any condition need evaluate like purchasePath
            getCartItemForSIM(cartItemList, prepayLine);

            List<String> accList = new ArrayList<>();
            //lineInfoItem.itemsInfo.cartItems -- accessories
            if(CollectionUtils.size(pageData.getAccessoryList())>0){
                pageData.getAccessoryList().stream()
                        .filter(accessoryVO -> accessoryVO.getDeviceCommerceItemId().equalsIgnoreCase(prepayLine.getId()))
                        .forEach(filteredAccessoryVO-> {
                        	accList.add(filteredAccessoryVO.getSorId());
                            cartItemList.add(getCartItemForAccessory(pageData, filteredAccessoryVO, mtn, orderDetails));
                            
                        });
            }
            // Write accessory lines which are filed to add to the cart (out of stock scenario)
            if(Objects.nonNull(prepaidODRequestData) && CollectionUtilities.isNotEmptyOrNull(prepaidODRequestData.getLines())) {
	            List<PrepaidODRequestDataLines> dataLines = prepaidODRequestData.getLines().stream().filter(lines->lines.getMtn().equalsIgnoreCase(mtn)).collect(Collectors.toList());
	            if(CollectionUtilities.isNotEmptyOrNull(dataLines) && Objects.nonNull(dataLines.get(0)) && CollectionUtilities.isNotEmptyOrNull(dataLines.get(0).getAccessorySkuIds())) {
		            List<PrepaidODRequestDataAccessorySkuIds> filterAccList = dataLines.get(0).getAccessorySkuIds().stream().filter(accessoryItem->!accList.contains(accessoryItem.getSorId())).collect(Collectors.toList());
		            filterAccList.stream().forEach(filterAccVO ->
		            	cartItemList.add(getCartItemForAccessoryRedis(filterAccVO,mtn)));
	            }
            }
            
            
            //*****lineInfoItem.itemsInfo.cartItems.taxdetails -- end
            cartItems.setCartItem(cartItemList);
            itemsInfo.setCartItems(cartItems);
            //*****lineInfoItem.itemsInfo.cartItems --END

            itemsInfoList.add(itemsInfo);

            lineInfoItem.setItemsInfo(itemsInfoList);
            //*****lineInfoItem.itemsInfo -------END

           // Optional<CartItem> containsAccessory=cartItemList.stream().filter(cartItem -> null!=cartItem.getCartItemType() && cartItem.getCartItemType().equalsIgnoreCase("ACCESSORY")).findAny();

            if(!"NAP".equalsIgnoreCase(pageData.getPurchasePath()) || accessoryPresent) {
                itemsInfo.setShipping(shipping);
            }

            //*****lineInfoItem.mtnDetails -------Start
            MtnDetails mtnDetails = new MtnDetails();
            mtnDetails.setLineNumber(mtn);
            mtnDetails.setPortInDevice(prepayLine.isPortInDevice());
            String npaNXX = prepayLine.getNpaNxxCode();
            if(StringUtilities.isNotEmptyOrNull(npaNXX)){
                mtnDetails.setNpaNXX(npaNXX);
            } else if(StringUtilities.isNotEmptyOrNull(npaNXX) && npaNXX.endsWith("-XXXX")) {
            	mtnDetails.setNpaNXX(StringUtils.remove(npaNXX, "-XXXX"));
            }
            lineInfoItem.setMtnDetails(mtnDetails);
            //*****lineInfoItem.mtnDetails -------END

           NumberShareDeviceInfo numberShareDeviceInfo = new NumberShareDeviceInfo();

            Optional<PrepaidODRequestDataLines> numberShareLine = prepaidODRequestData.getLines().stream().filter(lines-> StringUtilities.isNotEmptyOrNull(lines.getLineItemId()) && lines.getLineItemId().equalsIgnoreCase(prepayLine.getNumberShareLineItemId())).findFirst();

            if(numberShareLine.isPresent()){
                numberShareDeviceInfo.setLineNo(numberShareLine.get().getSelectedMtn());
                numberShareDeviceInfo.setName(numberShareLine.get().getDisplayName());
            }
            lineInfoItem.setNumberShareDeviceInfo(numberShareDeviceInfo);



            //*****lineInfoItem.oneTimeCharges -------Start
            ArrayList<OneTimeCharges> oneTimeChargesList = new ArrayList<>();
            OneTimeCharges oneTimeCharges = new OneTimeCharges();
            oneTimeCharges.setChargeType(CHARGE_TYPE);
            oneTimeCharges.setAmount(prepayLine.getActivationFee());
            oneTimeCharges.setFinalPrice(prepayLine.getActivationFee());
            oneTimeChargesList.add(oneTimeCharges);
            lineInfoItem.setOneTimeCharges(oneTimeChargesList);
            //*****lineInfoItem.mtnDetails -------END

            lineInfoItem.setTotalDueToday(getLineTotalDueToday(lineInfoItem));
            lineInfoItem.setTotalDueTodayWithoutTax(getLineTotalDueTodayWithoutTax(lineInfoItem)); //TODO:: revisit
            lineInfoItem.setTotalDueTodayWithoutTaxAndUpgradeFee(getLineTotalDueTodayWithoutTaxAndUpgradeFee(lineInfoItem));//TODO:: revisit

            count++;
            cartLineInfoList.add(lineInfoItem);
        }
        orderDetails.getCartTotalDiscounts().setTotalFutureDiscount(totalFutureDiscount.get());
        orderDetails.getCartTotalDiscounts().setFutureDiscountMonths(futureDiscountMonths.get());

        double totalDiscount = Double.parseDouble(orderDetails.getCartTotalDiscounts().getTotalDiscount()) + totalFutureDiscount.get()*futureDiscountMonths.get();
        orderDetails.getCartTotalDiscounts().setTotalDiscount(String.valueOf(totalDiscount));
        return cartLineInfoList;

    }

    private static String populateLineActivityType(VZWPrepayOrderVO pageData, PrepaidODRequestData prepaidODRequestData, PrepayDeviceVO prepayLine) {
        String lineActivityType = StringUtilities.isEmptyOrNull(prepayLine.getPurchasePath())?NSE: prepayLine.getPurchasePath();
        if(prepaidODRequestData.isLoggedIn() && (NSP.equalsIgnoreCase(lineActivityType) || NAP.equalsIgnoreCase(lineActivityType) && PASO.equalsIgnoreCase(pageData.getFlow()))) {
            lineActivityType = BYOD;
        } else if(prepaidODRequestData.isLoggedIn() && (PAL.equalsIgnoreCase(pageData.getFlow()))){
            lineActivityType=AAL;
        }else if(prepaidODRequestData.isLoggedIn() && (PUP.equalsIgnoreCase(pageData.getFlow()))) {
            lineActivityType=EUP;
        } else {
            lineActivityType = (NSP.equalsIgnoreCase(lineActivityType) || NAP.equalsIgnoreCase(lineActivityType) ? NSE_BYOD : lineActivityType);
        }
        return lineActivityType;
    }

    private CartItem getCartItemForAccessoryRedis(PrepaidODRequestDataAccessorySkuIds prepaidOdRequestDataAccessory, String mtn) {
    	CartItem cartItemAccessory = new CartItem();
        cartItemAccessory.setCartItemType(CART_ITEM_TYPE_ACCESSORY);
        cartItemAccessory.setSkuId(prepaidOdRequestDataAccessory.getSkuId()!=null?prepaidOdRequestDataAccessory.getSkuId():"");
        cartItemAccessory.setSorId(prepaidOdRequestDataAccessory.getSorId()!=null?prepaidOdRequestDataAccessory.getSorId():"");
        cartItemAccessory.setManufacturer(prepaidOdRequestDataAccessory.getManufacturer()!=null?prepaidOdRequestDataAccessory.getManufacturer():"");
        cartItemAccessory.setDescription(prepaidOdRequestDataAccessory.getDisplayName()!=null?prepaidOdRequestDataAccessory.getDisplayName():"");
        cartItemAccessory.setDeviceDisplayName(prepaidOdRequestDataAccessory.getDisplayName()!=null?prepaidOdRequestDataAccessory.getDisplayName():"");
        cartItemAccessory.setMobileNumber(mtn);
        cartItemAccessory.setQty(0);
        return setCartItemAccessoryData(cartItemAccessory,prepaidOdRequestDataAccessory);
	}

    public CartItem setCartItemAccessoryData(CartItem cartItemAccessoryData,PrepaidODRequestDataAccessorySkuIds prepaidODRequestDataAccessorySkuIds){
        cartItemAccessoryData.setItemPrice(prepaidODRequestDataAccessorySkuIds.getPrice()!=null?prepaidODRequestDataAccessorySkuIds.getPrice():"");
        cartItemAccessoryData.setDiscountedPrice(prepaidODRequestDataAccessorySkuIds.getDiscountedPrice()!=null?prepaidODRequestDataAccessorySkuIds.getDiscountedPrice():"");

        ImageUrlMap accessoryImageUrlMap = new ImageUrlMap();
        String defaultImgUrl = StringUtilities.substringBefore(prepaidODRequestDataAccessorySkuIds.getImgUrl(),"?");
        accessoryImageUrlMap.setMediumImage(defaultImgUrl + PrepayAdaptorCartConstants.ACCESSORY_MEDIUM_SUFFIX);
        accessoryImageUrlMap.setLargeImage(defaultImgUrl + PrepayAdaptorCartConstants.ACCESSORY_LARGE_SUFFIX);
        accessoryImageUrlMap.setDefaultImage(defaultImgUrl);
        accessoryImageUrlMap.setMiniImage(defaultImgUrl + PrepayAdaptorCartConstants.ACCESSORY_MINI_SUFFIX);
        accessoryImageUrlMap.setThumbImage(defaultImgUrl + PrepayAdaptorCartConstants.ACCESSORY_THUMB_SUFFIX);
        cartItemAccessoryData.setImageUrlMap(accessoryImageUrlMap);

        Color accessoryColor = new Color();
        accessoryColor.setColorDisplayName(prepaidODRequestDataAccessorySkuIds.getColor());
        cartItemAccessoryData.setColor(accessoryColor);
        return cartItemAccessoryData;
    }

	private Address getAddressFromAccountInfo(AccountInfoVO accountInfo ){
        Address address = new Address();
        if(accountInfo !=null){
            AddressVO accountAddress = accountInfo.getAddress();
            String addressLine1 = accountAddress.getAddressLine1();
            int spaceIndex = addressLine1.indexOf(' ');
            if (spaceIndex >= 0) {
                address.setStreetNumber(addressLine1.substring(0, spaceIndex));
            }
            if (addressLine1.length() > spaceIndex + 1) {
                address.setStreetName(addressLine1.substring(spaceIndex + 1));
            }
            address.setFirstName(accountInfo.getFirstName());
            address.setLastName(accountInfo.getLastName());
            address.setAddressLine1(StringUtilities.isNotEmptyOrNull(addressLine1)?StringUtils.capitalize(addressLine1):"");

            address.setCity(accountAddress.getCity());
            address.setState(accountAddress.getState());
            address.setZipCode(null!=accountAddress.getZip()?accountAddress.getZip():accountInfo.getZipcode());
            address.setEmailId(accountAddress.getEmailAddress());
            address.setPhoneNumber(accountAddress.getAltPhoneNumber());
        }
        return address;
    }


    public String getChannelId(ServerHttpRequest httpRequest) {
        String channelId = httpRequest.getHeaders().containsKey("channelId")
                ? httpRequest.getHeaders().getFirst("channelId")
                : "";
        return channelId;
    }

    public String getSessionId(ServerHttpRequest httpRequest) {

        String sessionId = httpRequest.getHeaders().containsKey(SESSION_ID)
                ? httpRequest.getHeaders().getFirst(SESSION_ID)
                : "";

        if(null != httpRequest && null!= httpRequest.getCookies() && StringUtilities.isEmptyOrNull(sessionId) ) {
            HttpCookie digitalSessionIdCookie = httpRequest.getCookies().getFirst(SESSION_ID);
            if(null!=digitalSessionIdCookie) sessionId = digitalSessionIdCookie.getValue();
        }
        if(StringUtilities.isEmptyOrNull(sessionId)) sessionId = "";

        return sessionId;
    }

    private String getCustomerTypeBasedOnFlow(String flow){
        String customerType = "N";  //Need confirmation on other customer types

        return customerType;
    }

    private String getMTNFromPrepaidODRequestData(PrepayDeviceVO prepayLine, PrepaidODRequestData prepaidODRequestData){
        if(null == prepayLine || null == prepayLine.getId()
                || null == prepaidODRequestData || CollectionUtilities.isEmptyOrNull(prepaidODRequestData.getLines())){
            return null;
        }

        Optional<PrepaidODRequestDataLines> prepayODLineOptional = prepaidODRequestData.getLines().stream()
                .filter(prepaidODLine -> null!=prepaidODLine.getLineItemId() && prepaidODLine.getLineItemId().equalsIgnoreCase(prepayLine.getId())).findFirst();
        return prepayODLineOptional.isPresent()?prepayODLineOptional.get().getMtn():null;

    }

    private SelcetedFeaturesList getFeaturesListForLine(VZWPrepayOrderVO pageData, PrepayDeviceVO prepayLine){
        if(null == pageData || null == prepayLine || null == prepayLine.getPlanItemId()
                || CollectionUtilities.isEmptyOrNull(pageData.getPlanList())) return null;
        SelcetedFeaturesList selectedFeaturesList = new SelcetedFeaturesList();
        PrepayPlanVO prepayPlanVO = pageData.getPlanList().stream()
                .filter(prepayPlan->prepayPlan.getId().equalsIgnoreCase(prepayLine.getPlanItemId())).findFirst().orElse(null);
        if(CollectionUtils.size(pageData.getFeatureList()) > 0 && Objects.nonNull(prepayPlanVO) && StringUtilities.isNotEmptyOrNull(prepayPlanVO.getFeatureLineItemId())){
            String[] planFeatureIds = prepayPlanVO.getFeatureLineItemId().split(",");
            selectedFeaturesList.setFeaturesCount(planFeatureIds.length);
            ArrayList<VisFeatures> visFeaturesList = new ArrayList<>(planFeatureIds.length);
            List<PrepayFeatureVO> lineLevelFeatures = pageData.getFeatureList().stream()
                    .filter(feature-> Arrays.stream(planFeatureIds).anyMatch(planFeatureId -> planFeatureId.equalsIgnoreCase(feature.getId()))).collect(Collectors.toList());
            for(PrepayFeatureVO prepayFeatureVO : lineLevelFeatures){
                VisFeatures visFeatures = new VisFeatures();
                visFeatures.setVisFeatureCode(prepayFeatureVO.getSorId());
                visFeatures.setFeatureSkuId(prepayFeatureVO.getSkuId());
                visFeatures.setFeatureDesc(prepayFeatureVO.getDisplayName());
                visFeatures.setAddDeleteInd("A");
                visFeatures.setLevel("L");
                visFeatures.setType("SFO");
                visFeatures.setCustomerSelected("Y");
                visFeatures.setFeaturePrice(String.valueOf(prepayFeatureVO.getDueMonthly()));
                visFeatures.setSource("FOM");
                visFeatures.setSfopackageGroupCode("MI");
                visFeaturesList.add(visFeatures);
            }
            selectedFeaturesList.setVisFeature(visFeaturesList);
        }else {
            selectedFeaturesList.setFeaturesCount(0);
        }
        return selectedFeaturesList;
    }

    private PricePlanInfo getPlanDetailsForLine(VZWPrepayOrderVO pageData, PrepayDeviceVO prepayLine, OrderDetails orderDetails){
        if(null == pageData || null == prepayLine || null == prepayLine.getPlanItemId()
                || CollectionUtilities.isEmptyOrNull(pageData.getPlanList())) return null;

        List<PrepayPlanVO> prepayPlanVOList = pageData.getPlanList();
        PricePlanInfo pricePlanInfo = new PricePlanInfo();
        if(CollectionUtilities.isNotEmptyOrNull(prepayPlanVOList)){
            PrepayPlanVO prepayPlanVO =  prepayPlanVOList.stream()
                    .filter(prepayPlan-> prepayPlan.getId().equalsIgnoreCase(prepayLine.getPlanItemId())).findFirst().orElse(null);
            if(null != prepayPlanVO){
                pricePlanInfo.setPricePlanCode(prepayPlanVO.getSorId());
                pricePlanInfo.setPlanDescription(prepayPlanVO.getDescription());
                if((PLAN_UNLIMITED_PLUS_CODE.equalsIgnoreCase(prepayPlanVO.getSorId()) || PLAN_UNLIMITED_PLUS_CODE2.equalsIgnoreCase(prepayPlanVO.getSorId())) && !PLAN_UNLIMITED_PLUS_TEXT.equalsIgnoreCase(prepayPlanVO.getPlanSize()))
                	pricePlanInfo.setPricePlanDesc(PLAN_UNLIMITED_PLUS_TEXT);
                else if (PLAN_UNLIMITED_SMARTWATCH_CODE.equalsIgnoreCase(prepayPlanVO.getSorId()))
                    pricePlanInfo.setPricePlanDesc(PLAN_UNLIMITED_TEXT);
                else if (PLAN_NUMBERSHARE_SMARTWATCH_CODE.equalsIgnoreCase(prepayPlanVO.getSorId()))
                    pricePlanInfo.setPricePlanDesc(PLAN_NUMBERSHARE_TEXT);
                else {
                	pricePlanInfo.setPricePlanDesc(StringUtilities.isNotEmptyOrNull(prepayPlanVO.getPlanSize())?StringUtilities.firstLetterToUpperCase(prepayPlanVO.getPlanSize()):"");
                }
            
                
                pricePlanInfo.setDataAllowance(StringUtilities.isNotEmptyOrNull(prepayPlanVO.getPlanSize())?StringUtilities.firstLetterToUpperCase(prepayPlanVO.getPlanSize()):"");
                pricePlanInfo.setPlanPrice(String.valueOf(prepayPlanVO.getDueMonthly()));
                pricePlanInfo.setActualPlanPrice(String.valueOf(prepayPlanVO.getActualPlanPrice()));
                //Family_Pricing_Start
                if(pageData.isEnableFamilyPricing()){
                    if(!prepayLine.isAccountOwner()){
                        pricePlanInfo.setDiscount(StringUtilities.isNotEmptyOrNull(String.valueOf(prepayPlanVO.getDiscount()))?String.valueOf(prepayPlanVO.getDiscount()):"0.0");
                    } else {
                        pricePlanInfo.setDiscount("0.0");
                    }
                    pricePlanInfo.setPlanMLDiscount(StringUtilities.isNotEmptyOrNull(String.valueOf(prepayPlanVO.getDiscount()))?String.valueOf(prepayPlanVO.getDiscount()):"0.0");
                    pricePlanInfo.setPlanDiscountedPrice(String.valueOf(prepayPlanVO.getActualPlanPrice()-prepayPlanVO.getDiscount()));
                    pricePlanInfo.setAutoPaySaving(prepayPlanVO.getAutoPaySaving());
                }else{
                    pricePlanInfo.setDiscount(String.valueOf(prepayPlanVO.getDiscount()));
                }
               //Family_Pricing_End
                pricePlanInfo.setDiscountedPrice(Objects.nonNull(prepayPlanVO.getDueMonthly())?String.valueOf(prepayPlanVO.getDueMonthly()):"0.0");
                pricePlanInfo.setPlanId(prepayPlanVO.getSkuId());
                pricePlanInfo.setPlanDisplayName(StringUtilities.isNotEmptyOrNull(prepayPlanVO.getSkuDisplayName())?prepayPlanVO.getSkuDisplayName():"");
                pricePlanInfo.setDisneyPlusPromo(Objects.nonNull(prepayPlanVO.isDisneyPlusPromo())?(prepayPlanVO.isDisneyPlusPromo()?true:false):false);
                pricePlanInfo.setPlanBundleDiscount(String.valueOf(prepayPlanVO.getPlanBundleDiscount()));
                pricePlanInfo.setBundleDiscountEligible(prepayPlanVO.isBundleDiscountApplied());
                if(((pricePlanInfo.getPricePlanDesc()).equalsIgnoreCase(PLAN_UNLIMITED_PLUS_TEXT) || (pricePlanInfo.getPricePlanDesc()).equalsIgnoreCase(PLAN_UNLIMITED_TEXT)) && FIVEG_DEVICE.equalsIgnoreCase(prepayLine.getDeviceSorType()) && DEVICE_CATEGORY_SP.equalsIgnoreCase(prepayLine.getItemType()) && DEVICE_APPLE.equalsIgnoreCase(prepayLine.getBrandName()) && StringUtilities.isEmptyOrNull(prepayLine.getPurchasePath()) || NSE.equalsIgnoreCase(prepayLine.getPurchasePath())) {
                	//pricePlanInfo.setPromo300(true);
                	DiscountSummary discSummaryUpdated = orderDetails.getCartTotalDiscounts();
                	String totalCurrDiscount = Objects.nonNull(discSummaryUpdated)?discSummaryUpdated.getTotalDiscount():"";
                	Double totCurrDisc = NumberUtils.isCreatable(totalCurrDiscount)?Double.parseDouble(totalCurrDiscount):0.0;
                	
                	if(Objects.nonNull(discSummaryUpdated)) {
                		discSummaryUpdated.setTotalDiscount(String.valueOf(totCurrDisc));
                	}
                	orderDetails.setCartTotalDiscounts(discSummaryUpdated);       	
                }
            }
        }
        return pricePlanInfo;
    }

    private CartItem getCartItemForDevice(VZWPrepayOrderVO pageData, PrepayDeviceVO prepayLine, String mtn, OrderDetails orderDetails, PrepaidODRequestData prepaidODRequestData){
        CartItem cartItemItem = new CartItem();

        cartItemItem.setItemCode(prepayLine.getSorId());
        cartItemItem.setSorId(prepayLine.getSorId());
        if((StringUtilities.isNotEmptyOrNull(prepayLine.getItemType()))&&((CART_ITEM_TYPE_DEVICE_LIST.contains(prepayLine.getItemType().toUpperCase())) || DEVICETYPE_SMARTWATCH.equalsIgnoreCase(prepayLine.getItemType()))){

                cartItemItem.setCartItemType(CART_ITEM_TYPE_DEVICE);

        }

        cartItemItem.setSkuId(prepayLine.getSkuId());
        cartItemItem.setProductId(prepayLine.getProductId());
        //Sending IMEI only for Smartwatches
        if(prepayLine.getItemType()!=null && prepayLine.getItemType().equalsIgnoreCase(DEVICETYPE_SMARTWATCH))
            cartItemItem.setDeviceId(prepayLine.getImei());

        if(prepayLine.getItemType()!=null && !prepayLine.getItemType().equalsIgnoreCase(DEVICETYPE_SMARTWATCH)) {
            List<PrepaidODRequestDataLines> smartWatchOnCart = prepaidODRequestData.getLines().stream().filter(lines -> lines.isSmartWatch() && StringUtilities.isNotEmptyOrNull(lines.getPlanSorId()) && lines.getPlanSorId().equals("28445")).collect(Collectors.toList());
            List<PrepaidODRequestDataLines> smartPhoneOnCart = prepaidODRequestData.getLines().stream().filter(lines -> lines.isSmartPhone()).collect(Collectors.toList());
            cartItemItem.setEnableSWNumberSelectionBanner(CollectionUtils.size(smartWatchOnCart) == 1 && CollectionUtils.size(smartPhoneOnCart) == 1 && (!smartPhoneOnCart.stream().filter(lines -> Arrays.stream(smartWatchOnCart.get(0).getNumbershareEligibleOS().split(",")).anyMatch(eligibleOS -> eligibleOS.contains(lines.getOsType()))).collect(Collectors.toList()).isEmpty()));
        }
        PrepaidODRequestDataLines currentRedisLine = prepaidODRequestData.getLines().stream().filter(line->
                line.getMtn().equalsIgnoreCase(mtn)).findFirst().orElse(new PrepaidODRequestDataLines());

        cartItemItem.setOsType(currentRedisLine.getOsType());
        cartItemItem.setCatalogPrice(prepayLine.getListPrice());
        cartItemItem.setItemNrpPrice(prepayLine.getRawTotalAmount());
        cartItemItem.setCapacity((prepayLine.getCapacity() !=null)?prepayLine.getCapacity().toUpperCase():"");
        cartItemItem.setManufacturer(prepayLine.getBrandName());
        cartItemItem.setSorDeviceCategory(prepayLine.getItemType());
        cartItemItem.setDeviceDueToday(String.valueOf(prepayLine.getTotalDueToday()));
        cartItemItem.setDeviceDueMonthly(String.valueOf(prepayLine.getTotalDueMonthly()));
        cartItemItem.setDiscountedPrice(String.valueOf(prepayLine.getItemAmount()));
        cartItemItem.setDescription(prepayLine.getSkuDisplayName());
        cartItemItem.setMobileNumber(mtn);
        cartItemItem.setQty(prepayLine.getQuantity());
        // BYOD changes
        cartItemItem.setImei(Objects.nonNull(prepayLine.getImei())?prepayLine.getImei():"");
        cartItemItem.setImei2(Objects.nonNull(prepayLine.getImei2())?prepayLine.getImei2():"");
        cartItemItem.setRequestedEsimImei(Objects.nonNull(prepayLine.getRequestedEsimImei())?prepayLine.getRequestedEsimImei():"");
        cartItemItem.setSmartIMEI(Objects.nonNull(prepayLine.isSmartImeiDevice())?prepayLine.isSmartImeiDevice():false);
        cartItemItem.setSmartImeiDevice(Objects.nonNull(prepayLine.isSmartImeiDevice())?prepayLine.isSmartImeiDevice():false);
        cartItemItem.setESIMEnabledDevice(Objects.nonNull(prepayLine.isESIMEnabledDevice())?prepayLine.isESIMEnabledDevice():false); 
        cartItemItem.setEsimOnlyDevice(Objects.nonNull(prepayLine.isEsimOnlyDevice())?prepayLine.isEsimOnlyDevice():false);
        cartItemItem.setEsimCompatible(Objects.nonNull(prepayLine.isEsimCompatible())?prepayLine.isEsimCompatible():false);
        
        if(StringUtilities.isNotEmptyOrNull(prepayLine.getRequestedEsimImei()) && prepayLine.isESIMEnabledDevice()) {
        	cartItemItem.setESimFlow(true);
        }
        List<PrepaidODRequestDataLines> lines = prepaidODRequestData.getLines().stream().filter(line->line.getMtn().equalsIgnoreCase(mtn)).collect(Collectors.toList());
        PrepaidODRequestDataLines lineToProcess = CollectionUtilities.isNotEmptyOrNull(lines)?lines.get(0):null;
        if(null!=lineToProcess) {
            lineToProcess.setESimId(Objects.nonNull(prepayLine.getImei2()) ? prepayLine.getImei2() : "");
        }
        cartItemItem.setEsimId(Objects.nonNull(prepayLine.getImei2())?prepayLine.getImei2():"");

        double fullRetailPrice = Objects.nonNull(prepayLine.getFullRetailListPrice())?prepayLine.getFullRetailListPrice():0.0;
        double rawTotalAmount = Objects.nonNull(prepayLine.getRawTotalAmount())?prepayLine.getRawTotalAmount():0.0;
        double itemPrice = fullRetailPrice != 0.0?fullRetailPrice:rawTotalAmount;
        double discountedPrice = Objects.nonNull(prepayLine.getListPrice())?prepayLine.getListPrice():0.0;
        cartItemItem.setItemPrice(String.valueOf(itemPrice));
        cartItemItem.setDiscountedPrice(String.valueOf(discountedPrice));
        
        //BYOD related fileds
        cartItemItem.setSimId(prepayLine.getSimId());

        if(pageData.getOrderDiscount() == 0.0) {
        	DiscountSummary discSummary = orderDetails.getCartTotalDiscounts();
        	double discount = Objects.nonNull(discSummary.getTotalDiscount())?Double.parseDouble(discSummary.getTotalDiscount()):0.0;

        	discount = (BigDecimal.valueOf(discount + (itemPrice-discountedPrice)).setScale(2, RoundingMode.HALF_UP)).doubleValue();
        	discSummary.setTotalDiscount(String.valueOf(discount));
        	orderDetails.setCartTotalDiscounts(discSummary);
        }
        cartItemItem.setTaxAmount(prepayLine.getDeviceTax());
        cartItemItem.setDeviceDisplayName(prepayLine.getSkuDisplayName());
        cartItemItem.setItemCost(prepayLine.getItemAmount());
        cartItemItem.setAccountOwner(prepayLine.isAccountOwner());
        cartItemItem.setAccountMember(prepayLine.isAccountMember());
        cartItemItem.setDeviceSorType(prepayLine.getDeviceSorType());

        //*****lineInfoItem.itemsInfo.cartItems.color --start
        Color color = new Color();
        color.setColorDisplayName(prepayLine.getColor());
        cartItemItem.setColor(color);
        //*****lineInfoItem.itemsInfo.cartItems.color --End

        //*****lineInfoItem.itemsInfo.cartItems.imageurlmap --start
        ImageUrlMap imageUrlMap = new ImageUrlMap();
        String deviceDefaultImage =  StringUtils.substringBefore(prepayLine.getImageUrl(),"?");
        imageUrlMap.setDefaultImage(deviceDefaultImage);
        imageUrlMap.setMiniImage(deviceDefaultImage + PrepayAdaptorCartConstants.DEVICE_MINI_SUFFIX);
        imageUrlMap.setLargeImage(deviceDefaultImage + PrepayAdaptorCartConstants.DEVICE_LARGE_SUFFIX);
        imageUrlMap.setMediumImage(deviceDefaultImage + PrepayAdaptorCartConstants.DEVICE_MEDIUM_SUFFIX);
        imageUrlMap.setThumbImage(deviceDefaultImage + PrepayAdaptorCartConstants.DEVICE_THUMB_SUFFIX);
        
        
        cartItemItem.setImageUrlMap(imageUrlMap);
        //*****lineInfoItem.itemsInfo.cartItems.imageurlmap --end

        //*****lineInfoItem.itemsInfo.cartItems.taxdetails --start
        if (CollectionUtilities.isNotEmptyOrNull(prepayLine.getTaxDetails())) {
            HashMap<String, Double> taxDeatilsMap = prepayLine.getTaxDetails();
            ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();
            taxDeatilsMap.forEach((key, value)->{
                TaxDetailInfo taxDetailInfo = new TaxDetailInfo();
                taxDetailInfo.setTaxDescription(key);
                taxDetailInfo.setTaxAmount(String.valueOf(value));
                taxDetailInfoList.add(taxDetailInfo);
            });
            cartItemItem.setTaxDetailsList(taxDetailInfoList);
        }

        cartItemItem.setCanonicalUrl(CANONICAL_URL_DEVICE + "/" + prepayLine.getSeoName());
        cartItemItem.setFutureDiscount(prepayLine.getFutureDiscount());
        cartItemItem.setFutureDiscountMonths(prepayLine.getFutureDiscountMonths());
        cartItemItem.setSavingUpto(cartItemItem.getItemNrpPrice() - cartItemItem.getItemCost() + ( cartItemItem.getFutureDiscount() * cartItemItem.getFutureDiscountMonths() ) );
        return cartItemItem;
    }

    private void getCartItemForSIM(ArrayList<CartItem> cartItemList, PrepayDeviceVO prepayLine){
        if((StringUtilities.isNotEmptyOrNull(prepayLine.getItemType()))&&(CART_ITEM_TYPE_SIM.equalsIgnoreCase(prepayLine.getItemType().toUpperCase()))){
               CartItem cartItemItem = new CartItem();
               cartItemItem.setCartItemType(CART_ITEM_TYPE_SIM);
               cartItemItem.setDescription(prepayLine.getSimDisplayName());
               cartItemList.add(cartItemItem);

        }
    }

    private CartItem getCartItemForAccessory(VZWPrepayOrderVO pageData, PrepayAccessoryVO prepayAccessoryVO, String mtn, OrderDetails orderDetails){
        CartItem cartItemItem = new CartItem();
        if(StringUtilities.isNotEmptyOrNull(prepayAccessoryVO.getSorId())) {
        cartItemItem.setItemCode(prepayAccessoryVO.getSorId());
        cartItemItem.setSorId(prepayAccessoryVO.getSorId());
        }
        cartItemItem.setDescription(prepayAccessoryVO.getSkuDisplayName());
        if((StringUtilities.isNotEmptyOrNull(prepayAccessoryVO.getItemType()))&&(CART_ITEM_TYPE_ACCESSORIES_INLINE.equalsIgnoreCase(prepayAccessoryVO.getItemType().toUpperCase()))){
                cartItemItem.setCartItemType(CART_ITEM_TYPE_ACCESSORY);
        }
        cartItemItem.setMobileNumber(mtn);
        cartItemItem.setQty(prepayAccessoryVO.getQuantity());
        cartItemItem.setSkuId(prepayAccessoryVO.getSkuId());
        cartItemItem.setProductId(prepayAccessoryVO.getProductId());
        cartItemItem.setCatalogPrice(prepayAccessoryVO.getListPrice());
        cartItemItem.setItemNrpPrice(prepayAccessoryVO.getRawTotalAmount());
        cartItemItem.setCapacity(prepayAccessoryVO.getCapacity());
        cartItemItem.setManufacturer(prepayAccessoryVO.getBrandName());
        cartItemItem.setSorDeviceCategory(prepayAccessoryVO.getItemType());
        cartItemItem.setDeviceDueToday(String.valueOf(prepayAccessoryVO.getTotalDueToday()));
        cartItemItem.setDiscountedPrice(String.valueOf(prepayAccessoryVO.getListPrice()));
        cartItemItem.setDescription(prepayAccessoryVO.getSkuDisplayName());

        double fullRetailPrice = Objects.nonNull(prepayAccessoryVO.getFullRetailListPrice())?prepayAccessoryVO.getFullRetailListPrice():0.0;
        double rawTotalAmount = Objects.nonNull(prepayAccessoryVO.getRawTotalAmount())?prepayAccessoryVO.getRawTotalAmount():0.0;
        double itemPrice = fullRetailPrice != 0.0?fullRetailPrice:rawTotalAmount;

        double discountedPrice = Objects.nonNull(prepayAccessoryVO.getItemAmount())?prepayAccessoryVO.getItemAmount():0.0;
        discountedPrice = BigDecimal.valueOf(discountedPrice).setScale(2, RoundingMode.HALF_UP).doubleValue();
        cartItemItem.setItemPrice(String.valueOf(itemPrice));
        cartItemItem.setDiscountedPrice(String.valueOf(discountedPrice));
        
        if(pageData.getOrderDiscount() == 0.0) {
        	DiscountSummary discSummary = orderDetails.getCartTotalDiscounts();
        	double discount = Objects.nonNull(discSummary.getTotalDiscount())?Double.parseDouble(discSummary.getTotalDiscount()):0.0;

        	discount = (BigDecimal.valueOf(discount + (itemPrice-discountedPrice)).setScale(2, RoundingMode.HALF_UP)).doubleValue();
        	discSummary.setTotalDiscount(String.valueOf(discount));
        	orderDetails.setCartTotalDiscounts(discSummary);
        }
        cartItemItem.setTaxAmount(prepayAccessoryVO.getDeviceTax());
        cartItemItem.setDeviceDisplayName(prepayAccessoryVO.getSkuDisplayName());
        cartItemItem.setItemCost(prepayAccessoryVO.getItemAmount());

        //*****lineInfoItem.itemsInfo.cartItems.color --start
        Color color = new Color();
        color.setColorDisplayName(prepayAccessoryVO.getColor());
        cartItemItem.setColor(color);
        //*****lineInfoItem.itemsInfo.cartItems.color --End

        //*****lineInfoItem.itemsInfo.cartItems.imageurlmap --start
        ImageUrlMap imageUrlMap = new ImageUrlMap();
        String accessoryImageUrl = StringUtils.substringBefore(prepayAccessoryVO.getMiniImageUrl(), "?");
        imageUrlMap.setDefaultImage(accessoryImageUrl);
        imageUrlMap.setMiniImage(accessoryImageUrl+ PrepayAdaptorCartConstants.ACCESSORY_MINI_SUFFIX);
        imageUrlMap.setMediumImage(accessoryImageUrl+ PrepayAdaptorCartConstants.ACCESSORY_MEDIUM_SUFFIX);
        imageUrlMap.setLargeImage(accessoryImageUrl+ PrepayAdaptorCartConstants.ACCESSORY_LARGE_SUFFIX);
        imageUrlMap.setThumbImage(accessoryImageUrl+ PrepayAdaptorCartConstants.ACCESSORY_THUMB_SUFFIX);

        cartItemItem.setImageUrlMap(imageUrlMap);
        //*****lineInfoItem.itemsInfo.cartItems.imageurlmap --end

        //*****lineInfoItem.itemsInfo.cartItems.taxdetails --start
        if (CollectionUtilities.isNotEmptyOrNull(prepayAccessoryVO.getTaxDetails())) {
            ArrayList<TaxDetailInfo> taxDetailInfoList = new ArrayList<>();
            AtomicInteger counter = new AtomicInteger(0);
            prepayAccessoryVO.getTaxDetails().stream().forEach(taxDetail -> {
                TaxDetailInfo taxDetailInfo = new TaxDetailInfo();
                taxDetailInfo.setTaxSequenceNum(counter.getAndIncrement());
                taxDetailInfo.setTaxAmount(String.valueOf(taxDetail.getTaxAmount()));
                taxDetailInfo.setTaxDescription(taxDetail.getTaxDescription());
                taxDetailInfo.setTaxType(taxDetail.getTaxType());
                taxDetailInfo.setMldSequenceNum(convertToIntFromString(taxDetail.getTaxLineItemId()));
                taxDetailInfoList.add(taxDetailInfo);
            });
            cartItemItem.setTaxDetailsList(taxDetailInfoList);
        }
        cartItemItem.setCanonicalUrl(CANONCIAL_URL_ACCESSORY + "/" + prepayAccessoryVO.getSeoName());

        return cartItemItem;
    }

    private double getLineTotalDueToday(CartLineInfo lineInfoItem){

        double lineTotalDueToday = 0;
        try {
            Integer planTotal = lineInfoItem.getServiceInfo().getPlanDetails().getPlanPrice();
            Double featuresPriceTotal = lineInfoItem.getServiceInfo().getSelectedFeaturesList().getVisFeature().stream().
                    map(visFeatures -> Double.valueOf(visFeatures.getFeaturePrice())).collect(Collectors.summingDouble(Double::doubleValue));
            Double deviceAndAccessoriesPriceTotal = lineInfoItem.getItemsInfo().get(0).getCartItems().getCartItem().stream()
                    .map(cartItem -> Double.valueOf(cartItem.getDiscountedPrice())).collect(Collectors.summingDouble(Double::doubleValue));
            lineTotalDueToday = Double.valueOf(planTotal) + featuresPriceTotal + deviceAndAccessoriesPriceTotal;
        }catch (Exception e){
            lineTotalDueToday = 0;
        }
        return lineTotalDueToday;

    }

    private double getLineTotalDueTodayWithoutTax(CartLineInfo lineInfoItem){

        double lineTotalDueToday = 0;
        try {
            Integer planTotal = lineInfoItem.getServiceInfo().getPlanDetails().getPlanPrice();
            Double featuresPriceTotal = lineInfoItem.getServiceInfo().getSelectedFeaturesList().getVisFeature().stream().
                    map(visFeatures -> Double.valueOf(visFeatures.getFeaturePrice())).collect(Collectors.summingDouble(Double::doubleValue));
            Double deviceAndAccessoriesPriceTotal = lineInfoItem.getItemsInfo().get(0).getCartItems().getCartItem().stream()
                    .map(cartItem -> Double.valueOf(cartItem.getDiscountedPrice())).collect(Collectors.summingDouble(Double::doubleValue));
            lineTotalDueToday = Double.valueOf(planTotal) + featuresPriceTotal + deviceAndAccessoriesPriceTotal;
        }catch (Exception e){
            lineTotalDueToday = 0;
        }
        return lineTotalDueToday;

    }

    private double getLineTotalDueTodayWithoutTaxAndUpgradeFee(CartLineInfo lineInfoItem){

        double lineTotalDueToday = 0;
        try {
            Integer planTotal = lineInfoItem.getServiceInfo().getPlanDetails().getPlanPrice();
            Double featuresPriceTotal = lineInfoItem.getServiceInfo().getSelectedFeaturesList().getVisFeature().stream().
                    map(visFeatures -> Double.valueOf(visFeatures.getFeaturePrice())).collect(Collectors.summingDouble(Double::doubleValue));
            Double deviceAndAccessoriesPriceTotal = lineInfoItem.getItemsInfo().get(0).getCartItems().getCartItem().stream()
                    .map(cartItem -> Double.valueOf(cartItem.getDiscountedPrice())).collect(Collectors.summingDouble(Double::doubleValue));
            lineTotalDueToday = Double.valueOf(planTotal) + featuresPriceTotal + deviceAndAccessoriesPriceTotal;
        }catch (Exception e){
            lineTotalDueToday = 0;
        }
        return lineTotalDueToday;

    }

    public ArrayList<CartValidationErrors> getCartValidationErrors(Cart cart, PrepaidODRequestData prepaidODRequestData){
        ArrayList<CartValidationErrors> cartValidationErrorsList = new ArrayList<>();
        ArrayList<CartValidationErrorEnum> cartValidationErrorEnumsList = new ArrayList<>();
        //cartcreator validation (1001)
        if(StringUtilities.isEmptyOrNull(cart.getCartHeader().getCartCreator()))
            cartValidationErrorEnumsList.add(CartValidationErrorEnum.CART_CREATOR_MISSING);

        if (StringUtilities.isEmptyOrNull(cart.getCartHeader().getEmailAddress()))
            cartValidationErrorEnumsList.add(CartValidationErrorEnum.PRIMARY_EMAIL_MISSING);

        //Contact Phone is missing
        if (null == cart.getOrderDetails() || null == cart.getOrderDetails().getSpocs() || null == cart.getOrderDetails().getSpocs().getNotificationOptions()
                || StringUtilities.isEmptyOrNull(cart.getOrderDetails().getSpocs().getNotificationOptions().getContactPhoneNumber()))
            cartValidationErrorEnumsList.add(CartValidationErrorEnum.CONTACT_NUMBER_MISSING);



        //line level cart validations
        if(null!=cart.getLineDetails() && null!=cart.getLineDetails().getLineInfo() && CollectionUtils.size(cart.getLineDetails().getLineInfo())>0) {
            //PricePlan Info
            List<CartLineInfo> linesWithoutPlansInfoList = cart.getLineDetails().getLineInfo().stream().filter(cartLineInfo ->
                    (null == cartLineInfo.getServiceInfo() || null == cartLineInfo.getServiceInfo().getNewPricePlanInfo()
                            || StringUtilities.isEmptyOrNull(cartLineInfo.getServiceInfo().getNewPricePlanInfo().getPricePlanCode()))).collect(Collectors.toList());
            long linesWithoutPlansInfo = linesWithoutPlansInfoList.size();
            if (linesWithoutPlansInfo > 0) {
                CartValidationErrorEnum.PRICEPLANID_NOT_POPULATED.setFieldPath(linesWithoutPlansInfoList.stream().map(cartLineInfo -> cartLineInfo.getServiceInfo().getMtn()).collect(Collectors.joining(",")));
                cartValidationErrorEnumsList.add(CartValidationErrorEnum.PRICEPLANID_NOT_POPULATED);
            }

            //npaNXX assignment
            long linesWithoutNpaNXX = cart.getLineDetails().getLineInfo().size();
            if (linesWithoutNpaNXX > 0 && !prepaidODRequestData.isNumberAssignedToAllLines()) {
                CartValidationErrorEnum.NPANXX_NUMBER_NOT_ASSIGNED.setFieldPath(cart.getLineDetails().getLineInfo().stream().map(cartLineInfo -> cartLineInfo.getServiceInfo().getMtn()).collect(Collectors.joining(",")));
                cartValidationErrorEnumsList.add(CartValidationErrorEnum.NPANXX_NUMBER_NOT_ASSIGNED);
            }

                //Validations (originally should be shipping)
                AtomicBoolean isFirstNameEmpty = new AtomicBoolean(false);
                AtomicBoolean isLastNameEmpty = new AtomicBoolean(false);
                AtomicBoolean isEmailAddressEmpty = new AtomicBoolean(false);
                AtomicBoolean isPhoneNumberEmpty = new AtomicBoolean(false);
                AtomicBoolean isPersonnelInfoEmpty = new AtomicBoolean(false);
                AtomicBoolean linesExistsWithoutShipping = new AtomicBoolean(false);

                cart.getLineDetails().getLineInfo().stream().forEach(cartLineInfo -> {
                        if(!prepaidODRequestData.isLoggedIn()) {
                            if (null == cartLineInfo.getServiceInfo() || null == cartLineInfo.getServiceInfo().getServiceAddress()) {
                                isFirstNameEmpty.set(true);
                                isLastNameEmpty.set(true);
                                isEmailAddressEmpty.set(true);
                                isPhoneNumberEmpty.set(true);
                            } else {
                                if (StringUtilities.isEmptyOrNull(cartLineInfo.getServiceInfo().getServiceAddress().getFirstName()))
                                    isFirstNameEmpty.set(true);
                                if (StringUtilities.isEmptyOrNull(cartLineInfo.getServiceInfo().getServiceAddress().getFirstName()))
                                    isFirstNameEmpty.set(true);
                                if (StringUtilities.isEmptyOrNull(cartLineInfo.getServiceInfo().getServiceAddress().getLastName()))
                                    isLastNameEmpty.set(true);
                                if (StringUtilities.isEmptyOrNull(cartLineInfo.getServiceInfo().getServiceAddress().getEmailId()))
                                    isEmailAddressEmpty.set(true);
                                if (StringUtilities.isEmptyOrNull(cartLineInfo.getServiceInfo().getServiceAddress().getPhoneNumber()))
                                    isPhoneNumberEmpty.set(true);
                            }
                            if (null == cartLineInfo.getServiceInfo() || null == cartLineInfo.getServiceInfo().getPrimaryUserInfo() || null == cartLineInfo.getServiceInfo().getPrimaryUserInfo().getFirstName()) {
                                isPersonnelInfoEmpty.set(true);
                            }

                        }

                    //shipping

                    if (cartLineInfo.getItemsInfo() == null || cartLineInfo.getItemsInfo().get(0) == null || cartLineInfo.getItemsInfo().get(0).getShipping() == null || StringUtilities.isEmptyOrNull(cartLineInfo.getItemsInfo().get(0).getShipping().getShippingCode())) {
                        linesExistsWithoutShipping.set(true);
                    }

                });



            if (linesExistsWithoutShipping.get())
                cartValidationErrorEnumsList.add(CartValidationErrorEnum.SHIPPING_REQUIRED);
       //     if(!prepaidODRequestData.isLoggedIn()) {
                if (isFirstNameEmpty.get())
                    cartValidationErrorEnumsList.add(CartValidationErrorEnum.FIRST_NAME_MISSING_SHIPPING);
                if (isLastNameEmpty.get())
                    cartValidationErrorEnumsList.add(CartValidationErrorEnum.LAST_NAME_MISSING_SHIPPING);
                if (isEmailAddressEmpty.get())
                    cartValidationErrorEnumsList.add(CartValidationErrorEnum.EMAIL_ADDRESS_MISSING);
                if (isPhoneNumberEmpty.get())
                    cartValidationErrorEnumsList.add(CartValidationErrorEnum.PHONE_NUMBER_MISSING);
       //     }
            if (null != cart.getLineDetails() && CollectionUtils.size(cart.getLineDetails().getPayments()) == 0)
                cartValidationErrorEnumsList.add(CartValidationErrorEnum.PAYMENT_REQUIRED);

            //personnel and payment
            if (null != cart.getLineDetails() && CollectionUtils.size(cart.getLineDetails().getPayments()) == 0
                    && isPersonnelInfoEmpty.get())
                cartValidationErrorEnumsList.add(CartValidationErrorEnum.PERSONAL_PAYMENT_INFORMATION);
        }
        if(prepaidODRequestData.isLoggedIn()) {
            cartValidationErrorEnumsList.add(CartValidationErrorEnum.AGREEMENTS_REQUIRED);
        }
       // cartValidationErrorEnumsList.add(CartValidationErrorEnum.PERSONAL_PAYMENT_INFORMATION);//TODO:: remove this

        cartValidationErrorEnumsList.forEach(cartValidationErrorEnum -> {
            CartValidationErrors cartValidationError = new CartValidationErrors();
            cartValidationError.setErrorCode(cartValidationErrorEnum.getErrorCode());
            cartValidationError.setErrorCategory(cartValidationErrorEnum.getErrorCategory());
            cartValidationError.setErrorLevel(cartValidationErrorEnum.getErrorLevel());
            cartValidationError.setErrorMessage(cartValidationErrorEnum.getErrorMessage());
            cartValidationError.setFieldName(cartValidationErrorEnum.getFieldName());
            cartValidationError.setFieldPath(cartValidationErrorEnum.getFieldPath());
            cartValidationErrorsList.add(cartValidationError);
        });

        return cartValidationErrorsList;
    }

    private CartPaymentInfo getRefillCartPaymentInfo(VZWPrepayOrderVO pageData){
        CartPaymentInfo cartPaymentInfo = new CartPaymentInfo();
        cartPaymentInfo.setPaymentType("RC");
        RefillCardPayment refillCardPayment = new RefillCardPayment();
        VZWPrepayPaymentVO vzwPrepayPaymentVO = pageData.getRefillCardDetails();
        refillCardPayment.setAmountCreditFromRC(pageData.getAmountCredit());
        refillCardPayment.setRemainingDueFromRC(vzwPrepayPaymentVO.getRemainingDue());
        //Fill the refill cards in refillCardPaymentOption payment header
        List<AppliedRC> appliedRCList = new ArrayList<>();
        if(CollectionUtilities.isNotEmptyOrNull(vzwPrepayPaymentVO.getPaymentGrpIdList())){
            vzwPrepayPaymentVO.getPaymentGrpIdList().stream().forEach(prepayRefillCardPaymentVO->{
                AppliedRC appliedRC = new AppliedRC();
                appliedRC.setRefillCardNumber(prepayRefillCardPaymentVO.getPincard());
                appliedRC.setPaymentGrpId(prepayRefillCardPaymentVO.getPaymentGrpId());
                appliedRC.setAmountApplied(prepayRefillCardPaymentVO.getAmounApplied());
                appliedRC.setBalance(prepayRefillCardPaymentVO.getBalance());
                appliedRCList.add(appliedRC);
            });
        }
        refillCardPayment.setAppliedRCList(appliedRCList);
        cartPaymentInfo.setRefillCardPaymentDetails(refillCardPayment);
        return cartPaymentInfo;
    }

    public CheckoutDetailsCXPResponse updateShippingDetails(CheckoutDetailsCXPResponse checkoutDetailsCXPResponse, VZWPrepayShippingResponseVO shippingResponse, boolean isByodFlow){

        if(null==checkoutDetailsCXPResponse || null==checkoutDetailsCXPResponse.getData()
                || null==checkoutDetailsCXPResponse.getData().getCart() || null==checkoutDetailsCXPResponse.getData().getCart().getLineDetails()
                || 0==CollectionUtils.size(checkoutDetailsCXPResponse.getData().getCart().getLineDetails().getLineInfo())
                || 0==CollectionUtils.size(shippingResponse.getShippingOption())){
            return checkoutDetailsCXPResponse;
        }

        Shipment shipment = new Shipment();
        List<LineInfo> shipmentLines = new ArrayList<>();

        updateShippingAndLineInfo(checkoutDetailsCXPResponse, shippingResponse, isByodFlow, shipmentLines);
        shipment.setLines(shipmentLines);
        checkoutDetailsCXPResponse.getData().setShipment(shipment);

        return checkoutDetailsCXPResponse;
    }

    private void updateShippingAndLineInfo(CheckoutDetailsCXPResponse checkoutDetailsCXPResponse, VZWPrepayShippingResponseVO shippingResponse, boolean isByodFlow, List<LineInfo> shipmentLines) {
        for(CartLineInfo cartLineInfo : checkoutDetailsCXPResponse.getData().getCart().getLineDetails().getLineInfo()){
            LineInfo lineInfo = new LineInfo();
            lineInfo.setMultiLineSeqNumber(cartLineInfo.getMultiLineSeqNumber());
            if(null!=cartLineInfo.getServiceInfo()
                    && null!=cartLineInfo.getServiceInfo().getPrimaryUserInfo() && null!=cartLineInfo.getServiceInfo().getPrimaryUserInfo().getAddress())
                lineInfo.setAddress(cartLineInfo.getServiceInfo().getPrimaryUserInfo().getAddress());

            if(CollectionUtils.size(cartLineInfo.getItemsInfo())==1 && null!=cartLineInfo.getItemsInfo().get(0).getShipping()) //TODO:: Confirming CartLineInfo.itemsInfo(is always size1)
                lineInfo.setSelectedOptionCode(cartLineInfo.getItemsInfo().get(0).getShipping().getShippingCode());

            ArrayList<Shipping> shippingList = new ArrayList<>();
            if(null!= shippingResponse && CollectionUtils.size(shippingResponse.getShippingOption())>0){
                updateShippingList(shippingResponse, lineInfo, shippingList);
            }
            if(isByodFlow){
                //Display only freeshipping Option to the BYOD flow
                Optional<Shipping> freeShippingOption = shippingList.stream().filter(shippingOption -> shippingOption.getShippingCost()==0).findFirst();
                if(freeShippingOption.isPresent()){
                    shippingList =new ArrayList<>();
                    shippingList.add(freeShippingOption.get());
                }
            }
            lineInfo.setShippingOptions(shippingList);
            lineInfo.setIspuEligible(cartLineInfo.isIspuEligible());
            lineInfo.setSddEligible(cartLineInfo.isSddEligible());
            lineInfo.setPurchasePath(cartLineInfo.getLineActivityType());
            lineInfo.setMtn(cartLineInfo.getLineNumber());
            shipmentLines.add(lineInfo);
        }
    }

    private void updateShippingList(VZWPrepayShippingResponseVO shippingResponse, LineInfo lineInfo, ArrayList<Shipping> shippingList) {
        for(ShippingOption prepayShippingOption : shippingResponse.getShippingOption()){
            Shipping shipping = new Shipping();
            shipping.setDepletionLocationCode(prepayShippingOption.getDepletionLocationCode());
            shipping.setDescription(prepayShippingOption.getShippingDescription());//check again
            shipping.setShippingDescription(prepayShippingOption.getShippingDescription());
            shipping.setShippingCost(prepayShippingOption.getShippingCost());
            shipping.setDiscountedPrice(prepayShippingOption.getShippingCost());
            shipping.setEstimatedDeliveryDate(prepayShippingOption.getEstimatedDeliveryDate());
            shipping.setEstimatedDeliveryDateText(prepayShippingOption.getEstimatedDeliveryDate());
            shipping.setEstimatedDeliveryDate(prepayShippingOption.getEstimatedDeliveryDate());
            shipping.setLocationSalesIdForSDD(prepayShippingOption.getSddLocationSalesId());
            shipping.setName(prepayShippingOption.getName());
            shipping.setShippingCode(prepayShippingOption.getShippingOptionId());
            shipping.setShippingOptionId(prepayShippingOption.getShippingOptionId());
            shipping.setShortDescription(prepayShippingOption.getShortDescription());
            shipping.setSignatureRequired(prepayShippingOption.getSignatureRequired());
            shipping.setActive(prepayShippingOption.isActive());
            if(null != prepayShippingOption.getShippingOptionId()
                    && prepayShippingOption.getShippingOptionId().equalsIgnoreCase(lineInfo.getSelectedOptionCode()))
                shipping.setAddedShippingOptionId(true);
            shipping.setFreeOvernightShipping(prepayShippingOption.isOvernightShipping());
            shipping.setTwoDayShipping(prepayShippingOption.isTwoDayShipping());
            shipping.setDiscountedPriceDesc(Double.toString(prepayShippingOption.getShippingCost()));


            if(CollectionUtils.size(prepayShippingOption.getSddAvailableWindows())>0){
                ArrayList<SDDAvailableWindow> sddAvailableWindowList = new ArrayList<>();
                for(AvailableDeliveryWindows prepayAvailableWindow: prepayShippingOption.getSddAvailableWindows()){
                    SDDAvailableWindow sddAvailableWindow = new SDDAvailableWindow();
                    sddAvailableWindow.setFormattedStartTime(prepayAvailableWindow.getFormattedStartTime());
                    sddAvailableWindow.setFormattedEndTime(prepayAvailableWindow.getFormattedEndTime());
                    sddAvailableWindow.setStartTime(prepayAvailableWindow.getStartTime());
                    sddAvailableWindow.setEndTime(prepayAvailableWindow.getEndTime());
                    sddAvailableWindow.setId(prepayAvailableWindow.getId());
                    sddAvailableWindow.setStartsAt(prepayAvailableWindow.getStartsAt());
                    sddAvailableWindow.setEndsAt(prepayAvailableWindow.getEndsAt());
                    sddAvailableWindowList.add(sddAvailableWindow);
                }
                shipping.setSddAvailableWindows(sddAvailableWindowList);
            }
            shippingList.add(shipping);
        }
    }

    private void setPaymentOptions(Payment payment, VZWPrepayOrderVO pageData){
        ArrayList<PaymentHeader> paymentOptions = new ArrayList<>();
        //Add Creditcard by default
        PaymentHeader ccPaymentOption = new PaymentHeader();
        ccPaymentOption.setPaymentType(PAYMENT_OPTION_CREDITCARD_TYPE);
        if(null!=pageData.getCustomerSavedCreditCard() ){
            VZWPrepaySavedCreditCardDetailsVO savedCreditCardDetailsVO = pageData.getCustomerSavedCreditCard();
            ccPaymentOption.setSavedCC(String.valueOf(savedCreditCardDetailsVO.isSavedCard()));
            SavedCC savedCC = new SavedCC();
            savedCC.setCreditCardNumber(savedCreditCardDetailsVO.getCreditCardNumber());
            savedCC.setCreditCardType(savedCreditCardDetailsVO.getCreditCardType());
            savedCC.setExpiryMonth(savedCreditCardDetailsVO.getCreditCardExpiryMonth());
            savedCC.setExpiryYear(savedCreditCardDetailsVO.getCreditCardExpiryYear());
            savedCC.setZipCode(savedCreditCardDetailsVO.getZipCode());
            ccPaymentOption.setSavedCCList(new SavedCC[]{savedCC});
        }
        ccPaymentOption.setSupportedCardTypes(CR_PAYMENT_METHODS.stream().map(String::toLowerCase).collect(Collectors.joining("|")));
        ccPaymentOption.setJwtToken(pageData.getJwtToken());
        ccPaymentOption.setApplePayEnabled(false);
        ccPaymentOption.setPayPalEnabled(false);
        paymentOptions.add(ccPaymentOption);
        //If flow is NSP(BYOD) then set the RefillCard as paymentoption
        if((!NSE.equalsIgnoreCase(pageData.getFlow()) && Arrays.asList(NSP, NAP, PASO).contains(pageData.getFlow()))
            && 0 == pageData.getAccessoryList().size()){ //Disabling the RC Option when there are accessories in Cart
            PaymentHeader refillCardPaymentOption = new PaymentHeader();
            refillCardPaymentOption.setPaymentType(PAYMENT_OPTION_REFILLCARD_TYPE);
            paymentOptions.add(refillCardPaymentOption);
        }

        if(CollectionUtils.size(pageData.getDigitalPaymentOptions())>0){
            Map<String, Object> digitalPaymentOptions = pageData.getDigitalPaymentOptions();
            //Paypal
            boolean paypalEnabled=(boolean)digitalPaymentOptions.get("paypalEnabled");
            if(paypalEnabled){
                PaymentHeader paypalPaymentOption = new PaymentHeader();
                paypalPaymentOption.setPaymentType(PAYMENT_OPTION_PAYPAL_TYPE);
                paypalPaymentOption.setJwtToken(pageData.getJwtToken());
                paypalPaymentOption.setApplePayEnabled(false);
                paypalPaymentOption.setPayPalEnabled(true);
                paypalPaymentOption.setPayPalLookUpUrl(pageData.getPaypalInfo());
                paymentOptions.add(paypalPaymentOption);
            }
            //ApplePlay

            logger.info("pageData from Play Response ={}",pageData);
            boolean applepayEnabled=(boolean)digitalPaymentOptions.get("applepayEnabled");
            if(applepayEnabled){
                ApplePaymentRequest applePaymentRequest=new ApplePaymentRequest();
                PaymentHeader applePayPaymentOption = new PaymentHeader();
                applePayPaymentOption.setPaymentType(PAYMENT_OPTION_APPLEPAY_TYPE);
                applePayPaymentOption.setJwtToken(pageData.getJwtToken());
                applePayPaymentOption.setApplePayEnabled(true);
                applePayPaymentOption.setPayPalEnabled(false);

                applePaymentRequest.setTotalAmount(String.valueOf(pageData.getOrderTotal()));
                applePaymentRequest.setRequestBillingInfoFromApple(new String[]{"postalAddress"});
                applePaymentRequest.setRequestShippingInfoFromApple(new String[]{"email"});
                applePaymentRequest.setOrderTotalLabel("VERIZON (TOTAL PENDING)");
                if(CollectionUtils.size(pageData.getApplePayInfo())>0) {
                    Map<String, Object> applePayInfo = pageData.getApplePayInfo();
                    applePayPaymentOption.setTransactionId((String) applePayInfo.get("transactionId"));
                    applePayPaymentOption.setEmailAddress((String) applePayInfo.get("emailAddress"));
                    applePayPaymentOption.setType((String) applePayInfo.get("paymentDataType"));
                    applePaymentRequest.setTotalAmount(applePayInfo.get("transactionAmount").toString());
                }
                if(null!=digitalPaymentOptions.get("prepaySOEApplepayEnabled"))
                 applePayPaymentOption.setPrepaySOEApplepayEnabled((boolean)digitalPaymentOptions.get("prepaySOEApplepayEnabled"));

                applePaymentRequest.setAppleMerchantIdentifier(String.valueOf(digitalPaymentOptions.get("applePayMerchantId")));
                applePaymentRequest.setApplePayEnabled(true);
                applePayPaymentOption.setApplePaymentRequest(applePaymentRequest);

                paymentOptions.add(applePayPaymentOption);
            }
        }
        payment.setPaymentOptions(paymentOptions);
    }

    public int convertToIntFromString(String src){
        int target = 0;
        if (StringUtilities.isEmptyOrNull(src)) return target;
        try{
            target = Double.valueOf(src).intValue();
        }catch (Exception e){
            target = 0;
        }
        return target;
    }
//

}
