package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;

public class SkuBarcodeVO implements Serializable{
	private static final long serialVersionUID = 1L;
	private String mPromoSkuId;
	private String mOfferId;
	private double mDiscountAmount;
	private String mOfferType;
	private int mContractDuration;
	private String mPriceType ;
	private String mTypeIndicator;
	private boolean mRebateAllowedIndicator;
	


	/**
	 * @return the rebateAllowedIndicator
	 */
	public boolean isRebateAllowedIndicator() {
		return mRebateAllowedIndicator;
	}
	/**
	 * @param pRebateAllowedIndicator the rebateAllowedIndicator to set
	 */
	public void setRebateAllowedIndicator(boolean pRebateAllowedIndicator) {
		mRebateAllowedIndicator = pRebateAllowedIndicator;
	}
	/**
	 * @return the promoSkuId
	 */
	public String getPromoSkuId() {
		return mPromoSkuId;
	}
	/**
	 * @param pPromoSkuId the promoSkuId to set
	 */
	public void setPromoSkuId(String pPromoSkuId) {
		mPromoSkuId = pPromoSkuId;
	}
	/**
	 * @return the offerId
	 */
	public String getOfferId() {
		return mOfferId;
	}
	/**
	 * @param pOfferId the offerId to set
	 */
	public void setOfferId(String pOfferId) {
		mOfferId = pOfferId;
	}
	/**
	 * @return the discountAmount
	 */
	public double getDiscountAmount() {
		return mDiscountAmount;
	}
	/**
	 * @param pDiscountAmount the discountAmount to set
	 */
	public void setDiscountAmount(double pDiscountAmount) {
		mDiscountAmount = pDiscountAmount;
	}
	/**
	 * @return the offerType
	 */
	public String getOfferType() {
		return mOfferType;
	}
	/**
	 * @param pOfferType the offerType to set
	 */
	public void setOfferType(String pOfferType) {
		mOfferType = pOfferType;
	}
	/**
	 * @return the contractDuration
	 */
	public int getContractDuration() {
		return mContractDuration;
	}
	/**
	 * @param pContractDuration the contractDuration to set
	 */
	public void setContractDuration(int pContractDuration) {
		mContractDuration = pContractDuration;
	}
	/**
	 * @return the priceType
	 */
	public String getPriceType() {
		return mPriceType;
	}
	/**
	 * @param pPriceType the priceType to set
	 */
	public void setPriceType(String pPriceType) {
		mPriceType = pPriceType;
	}
	/**
	 * @return the typeIndicator
	 */
	public String getTypeIndicator() {
		return mTypeIndicator;
	}
	/**
	 * @param pTypeIndicator the typeIndicator to set
	 */
	public void setTypeIndicator(String pTypeIndicator) {
		mTypeIndicator = pTypeIndicator;
	}
}
