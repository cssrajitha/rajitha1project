package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;

public class ACHInfo implements Serializable{
    private String id;
    private String accountNumber;
    private String routingNumber;
    private String lastFourAccountNumber;
    private String pieKeyID;
    private String piePhaseID;
    private  String encryptionType;

    public String getEncryptionType() {
        return encryptionType;
    }

    public void setEncryptionType(String encryptionType) {
        this.encryptionType = encryptionType;
    }

    public String getPieKeyID() {
        return pieKeyID;
    }

    public void setPieKeyID(String pieKeyID) {
        this.pieKeyID = pieKeyID;
    }

    public String getPiePhaseID() {
        return piePhaseID;
    }

    public void setPiePhaseID(String piePhaseID) {
        this.piePhaseID = piePhaseID;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLastFourAccountNumber() {
        return lastFourAccountNumber;
    }

    public void setLastFourAccountNumber(String lastFourAccountNumber) {
        this.lastFourAccountNumber = lastFourAccountNumber;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getRoutingNumber() {
        return routingNumber;
    }

    public void setRoutingNumber(String routingNumber) {
        this.routingNumber = routingNumber;
    }
}
