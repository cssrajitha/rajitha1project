package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;

public class FraudRule implements Serializable {
    private String ruleId;
    private String ruleDesc;
    private String ruleSourcePath;
    private String ruleDestinationPath;
    private String ruleDestinationValue;
    private String ruleOperation;

    public String getRuleId() {
        return ruleId;
    }

    public void setRuleId(String ruleId) {
        this.ruleId = ruleId;
    }

    public String getRuleDesc() {
        return ruleDesc;
    }

    public void setRuleDesc(String ruleDesc) {
        this.ruleDesc = ruleDesc;
    }

    public String getRuleSourcePath() {
        return ruleSourcePath;
    }

    public void setRuleSourcePath(String ruleSourcePath) {
        this.ruleSourcePath = ruleSourcePath;
    }

    public String getRuleDestinationPath() {
        return ruleDestinationPath;
    }

    public void setRuleDestinationPath(String ruleDestinationPath) {
        this.ruleDestinationPath = ruleDestinationPath;
    }

    public String getRuleDestinationValue() {
        return ruleDestinationValue;
    }

    public void setRuleDestinationValue(String ruleDestinationValue) {
        this.ruleDestinationValue = ruleDestinationValue;
    }

    public String getRuleOperation() {
        return ruleOperation;
    }

    public void setRuleOperation(String ruleOperation) {
        this.ruleOperation = ruleOperation;
    }
}
