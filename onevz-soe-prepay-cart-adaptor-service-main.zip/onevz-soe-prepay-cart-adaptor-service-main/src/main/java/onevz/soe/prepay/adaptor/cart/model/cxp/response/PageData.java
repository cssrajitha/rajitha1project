package onevz.soe.prepay.adaptor.cart.model.cxp.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class PageData {
    String zipCode;
    String state;
    String city;
    String[] mtns;
    boolean success;
}
