package onevz.soe.prepay.adaptor.cart.model.cart.vo;

import java.io.Serializable;
import java.util.HashMap;

import onevz.soe.prepay.adaptor.cart.model.play.VZWPrepayOrderVO;

public class VZWPrepayOrderSubmitVO implements Serializable {

    private static final long serialVersionUID = 1L;

    private String orderId;
    private boolean orderSubmitted;
    private boolean success;
    private HashMap<String,String> errorMap ;
    private HashMap<String,Object> extraParams ;
    private VZWPrepayOrderVO orderVo;

    public HashMap<String, Object> getExtraParams() {
        return extraParams;
    }

    public void setExtraParams(HashMap<String, Object> extraParams) {
        this.extraParams = extraParams;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public boolean isOrderSubmitted() {
        return orderSubmitted;
    }

    public void setOrderSubmitted(boolean orderSubmitted) {
        this.orderSubmitted = orderSubmitted;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public HashMap<String, String> getErrorMap() {
        return errorMap;
    }

    public void setErrorMap(HashMap<String, String> errorMap) {
        this.errorMap = errorMap;
    }

    public VZWPrepayOrderVO getOrderVo() {
        return orderVo;
    }

    public void setOrderVo(VZWPrepayOrderVO orderVo) {
        this.orderVo = orderVo;
    }
}
