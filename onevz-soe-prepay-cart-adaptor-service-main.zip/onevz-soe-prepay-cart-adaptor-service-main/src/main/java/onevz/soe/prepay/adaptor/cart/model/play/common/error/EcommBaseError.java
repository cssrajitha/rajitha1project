package onevz.soe.prepay.adaptor.cart.model.play.common.error;

import java.io.Serializable;

/**
 * Created by eesamma on 10/20/2017.
 */
public class EcommBaseError  implements Serializable {

    private String playSessionId;
    private String orderId;
    private String errorCode;
    private String errorMessage;
    private String innerErrorMessage;
    //private ActorRef controllerRef;
    private EcommValidationError ecommValidationError;
    private String deviceLineItemId;
    private String errorFlowCode;

    public String getDeviceLineItemId() {
        return deviceLineItemId;
    }

    public void setDeviceLineItemId(String deviceLineItemId) {
        this.deviceLineItemId = deviceLineItemId;
    }

    public String getPlaySessionId() {
        return playSessionId;
    }

    public void setPlaySessionId(String playSessionId) {
        this.playSessionId = playSessionId;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getInnerErrorMessage() {
        return innerErrorMessage;
    }

    public void setInnerErrorMessage(String innerErrorMessage) {
        this.innerErrorMessage = innerErrorMessage;
    }


    /*public ActorRef getControllerRef() {
        return controllerRef;
    }

    public void setControllerRef(ActorRef controllerRef) {
        this.controllerRef = controllerRef;
    }
    */
    public EcommValidationError getEcommValidationError() {
        return ecommValidationError;
    }

    public void setEcommValidationError(EcommValidationError ecommValidationError) {
        this.ecommValidationError = ecommValidationError;
    }

    public String getErrorFlowCode() {
        return errorFlowCode;
    }

    public void setErrorFlowCode(String errorFlowCode) {
        this.errorFlowCode = errorFlowCode;
    }
}
