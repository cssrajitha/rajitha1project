package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;
import java.util.List;

public class AccBundleDetailsVO  implements Serializable {

	private String discountedPrice;
	private String imgUrl;
	private String regularPrice;
	private String savedPrice;
	private String displayName;
	private String bundleDescription;
	private String skuID;

	private List<AccBundleBreackdownDetailsVO> bundleBreakdown;

	public String getDiscountedPrice() {
		return discountedPrice;
	}

	public void setDiscountedPrice(String discountedPrice) {
		this.discountedPrice = discountedPrice;
	}

	public String getImgUrl() {
		return imgUrl;
	}

	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}

	public String getRegularPrice() {
		return regularPrice;
	}

	public void setRegularPrice(String regularPrice) {
		this.regularPrice = regularPrice;
	}

	public String getSavedPrice() {
		return savedPrice;
	}

	public void setSavedPrice(String savedPrice) {
		this.savedPrice = savedPrice;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getBundleDescription() {
		return bundleDescription;
	}

	public void setBundleDescription(String bundleDescription) {
		this.bundleDescription = bundleDescription;
	}

	public String getSkuID() {
		return skuID;
	}

	public void setSkuID(String skuID) {
		this.skuID = skuID;
	}

	public List<AccBundleBreackdownDetailsVO> getBundleBreakdown() {
		return bundleBreakdown;
	}

	public void setBundleBreakdown(List<AccBundleBreackdownDetailsVO> bundleBreakdown) {
		this.bundleBreakdown = bundleBreakdown;
	}
}
