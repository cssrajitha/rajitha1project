package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;
import java.util.Map;

public class StoreInfo implements Serializable {

	private static final long serialVersionUID = 1L;

	private String storeInfoId;
	private String storeId;
	private String sorId;
	private String name;
	private String address1;
	private String address2;
	private String netaceLocationCode;
	private String city;
	private String state;
	private String postalCode;
	private String timing;
	private Map<String, String> hours;
	private String phoneNumber;
	private String distance;
	private double latitude;
	private double longitude;
	private String fipsCode;
	private String mapAddress;
	private String directStore;

	public String getDirectStore() {
		return directStore;
	}

	public void setDirectStore(String directStore) {
		this.directStore = directStore;
	}

	public Map<String, String> getHours() {
		return hours;
	}

	public void setHours(Map<String, String> hours) {
		this.hours = hours;
	}

	public String getStoreInfoId() {
		return storeInfoId;
	}

	public void setStoreInfoId(String storeInfoId) {
		this.storeInfoId = storeInfoId;
	}

	public String getStoreId() {
		return storeId;
	}

	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}

	public String getSorId() {
		return sorId;
	}

	public void setSorId(String sorId) {
		this.sorId = sorId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getTiming() {
		return timing;
	}

	public void setTiming(String timing) {
		this.timing = timing;
	}

	public String getNetaceLocationCode() {
		return netaceLocationCode;
	}

	public void setNetaceLocationCode(String netaceLocationCode) {
		this.netaceLocationCode = netaceLocationCode;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

    public String getDistance() {return distance;}

    public void setDistance(String distance) {this.distance = distance; }

    public double getLatitude() {return latitude;}

    public void setLatitude(double latitude) {this.latitude = latitude;}

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

	public String getFipsCode() { 		return fipsCode; 	}

	public void setFipsCode(String fipsCode) { 		this.fipsCode = fipsCode; 	}

	public String getMapAddress() { 		return mapAddress; 	}

	public void setMapAddress(String mapAddress) { 		this.mapAddress = mapAddress; 	}
}
