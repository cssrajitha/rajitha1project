package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;

public class RecycleDeviceOffer implements Serializable {
	private String id;
	private int version;
	private String offerId;
	private String offerType;
	private String offerName;
	private String offerDescription;
	private double offerAmount;
	private String cmEligibleMtn;
	private Integer buyMldSeqNum;
	private String buyItemCode;
	private String promoCode;
	private String otherBuyLocationCode;
	private Integer otherBuyItemOrderNum;
	private Integer otherBuyItemSeqNum;
	private String barcodeID;
	private String promoCreditType;
	private String tradeInDeviceId;

	public String getTradeInDeviceId() {
		return tradeInDeviceId;
	}

	public void setTradeInDeviceId(String tradeInDeviceId) {
		this.tradeInDeviceId = tradeInDeviceId;
	}

	public String getBarcodeID() {
		return barcodeID;
	}

	public void setBarcodeID(String pBarcodeID) {
		barcodeID = pBarcodeID;
	}

	public String getOtherBuyLocationCode() {
		return otherBuyLocationCode;
	}

	public void setOtherBuyLocationCode(String pOtherBuyLocationCode) {
		otherBuyLocationCode = pOtherBuyLocationCode;
	}

	public Integer getOtherBuyItemOrderNum() {
		return otherBuyItemOrderNum;
	}

	public void setOtherBuyItemOrderNum(Integer pOtherBuyItemOrderNum) {
		otherBuyItemOrderNum = pOtherBuyItemOrderNum;
	}

	public Integer getOtherBuyItemSeqNum() {
		return otherBuyItemSeqNum;
	}

	public void setOtherBuyItemSeqNum(Integer pOtherBuyItemSeqNum) {
		otherBuyItemSeqNum = pOtherBuyItemSeqNum;
	}

	public String getCmEligibleMtn() {
		return cmEligibleMtn;
	}

	public void setCmEligibleMtn(String cmEligibleMtn) {
		this.cmEligibleMtn = cmEligibleMtn;
	}

	public String getOfferId() {
		return offerId;
	}

	public void setOfferId(String offerId) {
		this.offerId = offerId;
	}

	public String getOfferType() {
		return offerType;
	}

	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}

	public String getOfferName() {
		return offerName;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public void setOfferName(String offerName) {
		this.offerName = offerName;
	}

	public String getOfferDescription() {
		return offerDescription;
	}

	public void setOfferDescription(String offerDescription) {
		this.offerDescription = offerDescription;
	}

	public double getOfferAmount() {
		return offerAmount;
	}

	public void setOfferAmount(double offerAmount) {
		this.offerAmount = offerAmount;
	}

	public Integer getBuyMldSeqNum() {
		return buyMldSeqNum;
	}

	public void setBuyMldSeqNum(Integer buyMldSeqNum) {
		this.buyMldSeqNum = buyMldSeqNum;
	}

	public String getBuyItemCode() {
		return buyItemCode;
	}

	public void setBuyItemCode(String buyItemCode) {
		this.buyItemCode = buyItemCode;
	}

	public String getPromoCode() {
		return promoCode;
	}

	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}

	public String getPromoCreditType() {
		return promoCreditType;
	}

	public void setPromoCreditType(String promoCreditType) {
		this.promoCreditType = promoCreditType;
	}

}
