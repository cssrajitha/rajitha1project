package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;

public class InstallApptSelectedDateInfo implements Serializable {

    private static final long serialVersionUID = 1L;
    private String serviceProviderAccount;
    private String serviceProviderName;
    private String availableDate;
    private String availableDay;
    private String availableType;
    private String slotStartTime;
    private String slotLength;
  	private String requestControllerId;
    private String eventCorrelationId;
    private String specialInstructions;

    public String getSpecialInstructions() {
        return specialInstructions;
    }

    public void setSpecialInstructions(String specialInstructions) {
        this.specialInstructions = specialInstructions;
    }

    public String getEventCorrelationId() {
        return eventCorrelationId;
    }

    public void setEventCorrelationId(String eventCorrelationId) {
        this.eventCorrelationId = eventCorrelationId;
    }

    public String getRequestControllerId() {
        return requestControllerId;
    }

    public void setRequestControllerId(String requestControllerId) {
        this.requestControllerId = requestControllerId;
    }
  
    public String getServiceProviderAccount() {
        return serviceProviderAccount;
    }

    public void setServiceProviderAccount(String serviceProviderAccount) {
        this.serviceProviderAccount = serviceProviderAccount;
    }

    public String getServiceProviderName() {
        return serviceProviderName;
    }

    public void setServiceProviderName(String serviceProviderName) {
        this.serviceProviderName = serviceProviderName;
    }

    public String getAvailableDate() {
        return availableDate;
    }

    public void setAvailableDate(String availableDate) {
        this.availableDate = availableDate;
    }

    public String getAvailableDay() {
        return availableDay;
    }

    public void setAvailableDay(String availableDay) {
        this.availableDay = availableDay;
    }

    public String getAvailableType() {
        return availableType;
    }

    public void setAvailableType(String availableType) {
        this.availableType = availableType;
    }

    public String getSlotStartTime() {
        return slotStartTime;
    }

    public void setSlotStartTime(String slotStartTime) {
        this.slotStartTime = slotStartTime;
    }

    public String getSlotLength() {
        return slotLength;
    }

    public void setSlotLength(String slotLength) {
        this.slotLength = slotLength;
    }
}
