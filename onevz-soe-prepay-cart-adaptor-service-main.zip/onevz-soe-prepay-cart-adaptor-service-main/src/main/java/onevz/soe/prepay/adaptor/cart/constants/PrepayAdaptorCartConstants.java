package onevz.soe.prepay.adaptor.cart.constants;

import java.util.Arrays;
import java.util.List;


/**
 * Cart Constants class.
 */
public class PrepayAdaptorCartConstants {

	public static final List<String> CR_PAYMENT_METHODS = Arrays.asList("VISA", "MASTERCARD", "DISCOVER", "AMERICANEXPRESS", "AMEX");
	public static final String PAYMENT_METHOD_PAYPAL = "paypal";
	public static final String PAYPAL = "PayPal";
	public static final String PAYMENT_METHOD_APPLEPAY = "applepay";
	public static final String PAYMENT_OPTION_CREDITCARD_TYPE = "CR";
	public static final String PAYMENT_OPTION_PAYPAL_TYPE = "PY";
	public static final String PAYMENT_OPTION_APPLEPAY_TYPE = "AP";
	public static final String PAYMENT_OPTION_REFILLCARD_TYPE = "RC";

	public static final String DEVICETYPE_TABLET="TABLET";
	public static final List<String> CART_ITEM_TYPE_DEVICE_LIST = Arrays.asList("SMARTPHONE", "BASICPHONE", DEVICETYPE_TABLET, "INTERNET_AND_HOME", "CARCONNECT", "BASIC_PHONE_DEVICE");
	public static final String CART_ITEM_TYPE_ACCESSORIES_INLINE = "INLINE_ACCESSORIES";
	public static final String CART_ITEM_TYPE_DEVICE = "DEVICE";

	public static final String DEVICETYPE_SMARTWATCH = "SMARTWATCH";
	public static final String CART_ITEM_TYPE_ACCESSORY = "ACCESSORY";
	public static final String CART_ITEM_TYPE_SIM = "SIM";
	public static final String CANONICAL_URL_DEVICE = "smartphones";
	public static final String CANONCIAL_URL_ACCESSORY = "accessories";
	public static final String PEGA_RSPNS_FTCH_EXCPTN_STRNG = "Exception fetching response from PEGA ";
	public static final String CXP_RSPNS_PRCSS_EXCPTN_STRNG = "Exception processing cxp response ";
	public static final String CXP_RSPNS_FTCH_EXCPTN_STRNG = "Exception fetching response from CXP ";
	public static final String JSON_PRCSSNG_EXCPTN_STRNG = "Exception Processing JSON: ";
	public static final String REDIS_FORMATTED_UI_REQUEST = "UI Request after retrieving from redis: ";
	public static final String UPDATE = "UPDATE";
	public static final String CART_ID = "cartId";
	public static final String COMPLETED_CARTID_CONST = "completedCartId";
	public static final String ECPD_PROFILE_ID = "ecpdId";
	public static final String PROMO_TYPE = "promoType";
	public static final String NOPROMO = "NOPROMO";
	public static final String LOGGEDINUSER = "loggedInUser";
	public static final String REMOVEOFFERREDISDATA = "removeOfferRedisData";
	public static final String CHANNEL_ID_BBP = "VZW-DOTCOM-BBP";
	public static final String CART_MTN_LIST = "cartMtnList";
	public static final String INTEND_TYPE = "intendType";
	public static final String ACTION = "action";
	public static final String ENG_US = "eng-us";
	public static final String SOE_CART_SERVICE = "CartService";
	public static final String WARNING = "Warning";
	public static final String ERROR = "Error";
	public static final String CXP = "CXP";
	public static final String CASE_ID = "caseId";
	public static final String COMPLETED_CASEID_CONST = "completedCaseId";
	public static final String VERIFIED_NAME = "verifiedName";
	public static final String ACCOUNT_NUMBER = "accountNumber";
	public static final String CART_CREATOR = "cartCreator";
	public static final String PROCESSING_MTN = "processingMTN";
	public static final String INTENT = "INTENT";
	public static final String LINE_DETAILS = "lineDetails";
	public static final String MANUAL_DISCOUNT = "manualDiscount";
	public static final String ACTFEEWAIVER = "actFeeWaiver";
	public static final String ADD = "ADD";
	public static final String ADDACTFEEWAIVER="addActFeeWaiver";
	public static final String REMOVEACTFEEWAIVER="removeActFeeWaiver";
	public static final String SKU_ID = "skuId";
	public static final String DISCOUNT_REASON_CODE = "discountReasonCode";
	public static final String SHARED_DETAILS = "sharedDetails";
	public static final String BUY_OUT_FLAG = "buyOutFlag";
	public static final String BUY_OUT_SELECTED = "buyOutSelected";
	public static final String EDGE_UP_SELECTED = "edgeUpSelected";
	public static final String AMOUNT = "amount";
	public static final String EXCEPTION_WRITING_RESPONSE = "Exception writing response # {}";
	public static final String ACCESSORIES = "accessories";
	public static final String ACCESSORY = "accessory";
	public static final String ACCESSORY_C = "Accessory";
	public static final String FEATURES = "features";
	public static final String ACCESSORY_ID = "accessoryId";
	public static final String FEATURE_ID = "featureId";
	public static final String MSNG_FLDS_ERR_CODE = "701";
	public static final String FIVEG_ADDR_MISSING = "712";
	public static final String MISSING_FIELDS = "MISSING_FIELDS";
	public static final String ADD_DEVICE = "addDevice";
	public static final String SHOPPING_CART = "ShoppingCart";
	public static final String ADD_PLAN = "addPlan";
	public static final String SHIPMENT = "shipment";
	public static final String SHIPMENT_ADDRESS = "shipmentAddress";
	public static final String CHANNEL_ID = "channelId";
	public static final String CUSTOMER_ID = "customerId";
	public static final String MTN = "mtn";
	public static final String ADD_BARCODE_OFFER = "addBarCodeOffer";
	public static final String CLIENT = "client";
	public static final String DATA = "data";
	public static final String DEVICE = "device";
	public static final String SIM = "sim";
	public static final String ID = "id";
	public static final String CLIENT_APP_NAME = "clientAppName";
	public static final String CANCEL = "Cancel";
	public static final String RETRIEVE_CURRENT_FEATURES = "retrieveCurrentFeatures";
	public static final String ADD_DEVICE_REQUEST = "addDeviceRequest";
	public static final String INTENT_TOKEN_RESPONSE = "intentTokenResponse";
	public static final String IMEI = "imei";
	public static final String ICCID = "iccid";
	public static final String IMEI2 = "imei2";
	public static final String HANDS_OFF_TOKEN = "handsOffToken";

	public static final String ADD_SERVICE_ADDRESS = "addServiceAddress";
	public static final String ADD_BILLING_ADDRESS = "addBillingAddress";
	public static final String ADD_E911_ADDRESS = "addE911Address";
	public static final String ADD_IC_DOWNPAYMENT = "addInstantCreditDownPayment";
	public static final String REMOVE_PLAN = "removePlan";
	public static final String SALES_ORDER_PURCHASE = "SalesOrderPurchase";
	public static final String REMOVE_LINES = "removeLines";
	public static final String REMOVE_ITEM = "removeItem";
	public static final String REMOVE_ACCESSORY = "removeAccessory";
	public static final String ADD_ACCESSORY = "addAccessory";
	public static final String ADD_FEATURES = "addFeatures";
	public static final String MAY_BE_LATER = "mayBeLater";
	public static final String REMOVE_FEATURE = "removeFeature";
	public static final String INITIATE_CHECKOUT = "initiateCheckout";
	public static final String PROCEED_TO_ORDER = "proceedToOrder";
	public static final String ADD_BUYOUT_AMT = "addBuyOutAmt";
	public static final String ADD_EDGEUP_AMT = "addEdgeUpAmt";
	public static final String ADD_DOWNPAYMENT = "addDownPayment";
	public static final String PAST_DUE = "pastDue";
	public static final String CREATE_LINE = "createLine";
	public static final String AAL = "AAL";
	public static final String UPGRADE = "Upgrade";
	public static final String ADD_NUMBERSHARE = "addNumberShare";
	public static final String UPDATE_DEVICESIMID = "updateDeviceSimId";
	public static final String CLEINT = "client";
	public static final String EUP = "EUP";
	public static final String BYOD = "BYOD";
	public static final String DEO = "DEO";
	public static final String DEVICEACC = "DEVICE-ACC";
	public static final String FEATURES_PDP = "FeaturesPDP";
	public static final String FIVEGBOLT = "5GBOLT";
	public static final String ADD_FIVEGBOLT = "add5GBolt";
	public static final String FEATURES_REQUIRED = "Account & Line level features (atleast one required)";
	public static final String FEATURES_AND_SUBSCRIPTIONS = "features & mcsSubscription (atleast one required)";
	public static final String SUBSCRIPTION = "mscSubscription";
	public static final String SUBSCRIPTION_ITEMID = "mscSubscription itemId";
	public static final String SUBSCRIPTION_PRICEPLANID = "mscSubscription pricePlanId";
	public static final String SUBSCRIPTION_PRICE = "mscSubscription price";
	public static final String SUBSCRIPTION_NAME = "mscSubscription name";
	public static final String SUBSCRIPTION_DESCRIPTION = "mscSubscription description";
	public static final String APPLICABLE_MTNS = "mtns";
	public static final String DISCOUNT_AMT_PRCNT = "discountAmount & discountPercent (atleast one required)";
	public static final String DECODED_TOKEN = "Received decodedSSOToken";
	public static final String PAPERLESSBILLING = "paperlessBilling";
	public static final String TRADEINTYPE = "tradeInType";
	public static final String MULTI_LINE_BOGO = "Multi Line BOGO";
	public static final String MULTI_LINE_BMSM = "Multi Line BMSM";
	public static final String BICT = "BICT";
	public static final String TRADE = "Trade";
	public static final String REMOVE_OFFER = "removeOffer";
	public static final String ADD_SELLER_PRICE = "addSellerPrice";
	public static final String REMOVE_OFFERS_DETAILS = "removeOffersDetails";
	public static final String PROCESS_STEP = "processStep";
	public static final String PROCESS_ACTION = "processAction";
	public static final String PLAN = "plan";
	public static final String DEVICEID = "deviceId";
	public static final String SIMID = "simId";
	public static final String EFFECTIVE_DATE = "effectiveDate";
	public static final String PASTDUE = "pastdue";
	public static final String ASSIGN_MTN = "assignMtn";
	public static final String INTERIM_PAGE = "InterimPage";
	public static final String INTERIM = "Interim";
	public static final String EFFECTIVE_DATE_UPDATE = "EffectiveDateUpdate";
	public static final String ASSIGN_NUMBERS = "AssignNumbers";
	public static final String LINES = "lines";
	public static final String NPANXX = "npaNxx";
	public static final String DEASSIGN_MTN = "deassignMtn";
	public static final String DEASSIGN_NUMBERS = "De-assignNumbers";
	public static final String SAVE_CART = "saveCart";
	public static final String SAVE_CART_AND_QUOTES= "saveCartAndQuotes";
	public static final String ORDERREVIEW_SHIPPING = "OrderReview-Shipping";
	public static final String SELLERPRICE = "SellerPrice";
	public static final String PARSING_ERROR = "error parsing request: ";
	public static final String AAL_5G = "AAL_5G";
	public static final String FIVEGBULK = "FIVEGBULK";
	public static final String GIFT_PURCHASE_FLAG = "giftPurchaseFlag";
	public static final String CHAT_ID = "CHATID";
	public static final String ADD_CHAT_ID = "addChatId";
	public static final String CHAT_ID_FIELD = "chatId";
	public static final String OMNI_CARE = "OMNI-CARE";
	public static final String OMNI_TELESALES = "OMNI-TELESALES";
	public static final String CHANNEL_ASSISTED = "assisted";
	public static final String CHANNEL_DIGITAL = "digital";
	public static final String REVOKE_REBATES = "REVOKEREBATES";
	public static final String USER = "user";
	public static final String PORTIN_LATER = "PORTINLATER";
	public static final String UPDATE_PORTIN_LATER = "PortInLater";
	public static final String ORDER_REVIEW_SHIPPING = "OrderReview-Shipping";
	public static final String VOID_ORDER = "voidOrder";
	public static final String CANCEL_ISPU = "CancelISPU-LocalOrder";
	public static final String ISPU_TO_DFILL = "ispuToDFill";
	public static final String GRIDWALLPDP = "GridWallPDP";
	public static final String MANUAL_PAIRING = "MANUALPAIRING";
	public static final String UPDATE_MANUAL_PAIRING = "Update-ManualPairing";
	public static final String SALES_REP_AND_LOCATION_CODE = "SALESREPANDLOCATIONCODE";
	public static final String UPDATE_SALES_REP = "Update-SalesRepLocation";
	public static final String SPLIT_EXCEEDED_AMOUNT = "splitExceededAmount";
	public static final String CANCEL_CASE = "cancelCase";
	public static final String VZW_ECOM = "VZW-ECOM";
	public static final String CHECKOUT = "checkOut";
	public static final String ADD_ALLOCATION_AMOUNT = "addAllocationAmount";
	public static final String NEGATIVE_BUYOUTAMT = "buyoutAmt";
	public static final String EDGEUP = "edgeup";
	public static final String NEGATIVE_EDGEUP_AMOUNT = "edgeupAmount";
	public static final String STANDALONEACCESSORY ="StandAloneAccessory";
	public static final String STANDALONE ="standalone";
	public static final String DEVICEID_VALIDATION = "deviceIdValidation";
	public static final String ADD_DEVICE_SIM = "addDeviceSim";
	public static final String MYOFFER_DATA ="myOfferData";
	public static final String RETRIEVECART_DATA ="retrieveCartData";
	public static final String CONFLICTED_SPOS = "conflictedSPOs";
	public static final String HUM_WIFI = "humWifiSFOs";
	public static final String ACC = "ACC";
	public static final String CART = "CART";
	public static final String BARCODE_UNSUCCESSFUL = "Barcode validated un-successfully";
	public static final String SFO = "SFO";
	public static final String SPO = "SPO";
	public static final String FIVE_G_UWB_BOLT = "5GUWBBOLT";
	public static final String FIVE_G_UWB_BOLT_ADDED = "5GUWBBOLTGAIN";
	public static final String FIVE_G_UWB_BOLT_DROPPED = "5GUWBBOLTLOST";
	public static final String PAIR_TO = "PAIRTO";
	public static final String PAIR_TO_ADDED = "TABLET-DISCOUNT-ADDED";
	public static final String PAIR_TO_DROPED = "TABLET-DISCOUNT-LOST";
	public static final String PAIR_TO_DROPED_ALL = "TABLET-DISCOUNT-LOST-ALL";
	public static final String FREE_APPLE_MUSIC_LOSS = "FREEAPPLEMUSICLOST";
	public static final String DELETE_ALL_ACCESSORIES = "deleteAllAccessories";
	public static final String SMARTFAM = "SMARTFAM";
	public static final String SMARTFAM_DROPPED = "SMART-FAMILY-DROP";
	public static final String SMARTFAM_ADDED = "SMART-FAMILY-ADD";
	public static final String DISPLAY_IN_DISCOUNT_PORTAL = "DISPLAY_IN_DISCOUNT_PORTAL";
	public static final String APPLY_TO_PLAN_ACCESS = "APPLY_TO_PLAN_ACCESS";
	public static final String KIDS4LINE = "KIDS4LINE";
	public static final String FIRSTRESPD = "FIRSTRESPD";
	public static final String TEACHER = "TEACHER";
	public static final String MILITARY = "MILITARY";
	public static final String AAL_PROMO_INTERCEPT = "aalPromoIntercept";
	public static final String SETUP_LATER = "SetUpLater";
	public static final String ACTIVATE_LATER = "ACTIVATELATER";
	public static final String DISNEY_ENROLLED_SPOID = "1640";
	public static final String FIVEG_UPSELL = "isfiveGUpSellSelected";
	public static final String PASTDUEBALANCE = "mdnselection/pastdue.html";
	public static final String DPPSUMMARY = "dppagreement.html";
	public static final String TWOYEARUPGRADE = "earlytwoyearagreement.html";
	public static final String MTNSELECTIONPAGE = "mdnselection.html";
	public static final String GENERIC_ERROR = "error/genericError.html";
	public static final String ITEM_TYPE = "itemType";
	public static final String DEVICE_ACCESSORY = "Device/Accessory";
	public static final String ADD_ACCESSORY_REQUEST = "addAccessoryRequest";
	public static final String MTN_SELECTION_PAGE = "MTNSelectionPage";
	public static final String GRIDWALL_PDP = "GridWallPDP";
	public static final String ADD_FEATURES_REQUEST ="addFeaturesRequest";
	public static final String MYOFFER_ETR_DATA = "myOfferVzUpETRData";
	public static final String EQP = "EQP";
	public static final String RESTRICTED_PRODUCT_TYPE ="restrictedProductType";
	public static final String DEVICE_DOLLARS = "DEVICE_DOLLARS";
	public static final String VALIDATE_DEVICE_SIM_ID_PAGE= "ValidateDeviceSimIdPage";
	public static final String MTN_TO_PLANID_MAP = "mtnToPlanIdMap";
	public static final String MTN_TO_LOAN_STATUS_MAP = "mtnToLoanStatusMap";
	public static final String ONE_CLICK_CHECKOUT = "oneClickCheckout";
	public static final String PROMOHUB_SPOKE_JOURNEY = "spokeJourney";
	public static final String ACCESSORIES_INTERSTIAL = "AccessoryInterestial";
	public static final String DEVICE_COUNT = "deviceCount";
	public static final String CART_HAS_PCD = "cartHasPCD";
	public static final String DEVICE_BEST_VALUE_OFFER_DATA = "deviceBestValuePromoData";
	public static final String BVP_ACCEPTED = "81";
	public static final String BVP_VIEW = "82";
	public static final String BVP_REJECTED = "83";
	public static final String COMPLIANCE_TYPE= "ComplianceType";
	public static final String MMTIER= "mtier";
	public static final String MYOFFER= "OFFERS";
	public static final String PLAN_SELECTION= "PlanSelection";
	public static final String CPC= "CPC";
	public static final String VZW_DOTCOM = "VZW-DOTCOM";
	public static final String FEATURES_RESPONSE = "featuresResponse";
	public static final String REMOVE_LINES_SUCCESS = "Lines Deleted Succesfully!";
	public static final String EXIT_PAGE = "ExitPage";
	public static final String CLEAR_ITEMS= "CLEARITEMS";
	public static final String CLEAR = "Cancel";
	public static final String REMOVE_DEVICE = "removeDevice";
	public static final String REMOVE = "REMOVE";
	public static final String REMOVE_DEVICE_SUCCESS = "Device has been removed successfully..";
	public static final String INELIGIBLE_UPGRADE_LINES = "ineligibleUpgradeLines";

	public static final String TRANSFER_UPGRADE = "TransferUpgrade";
	public static final String COMPLETE_TRANSFER = "completeTransfer";
	public static final String ALTERNATEUPGRADE = "ALTERNATEUPGRADE";
	public static final String CANCEL_TRANSFER_UPGRADE = "cancelTransferUpgrade";
	public static final String TRANSFER_FROM = "transferFrom";
	public static final String CANCEL_EDGE_UP = "cancelEdgeUp";
	public static final String DONOR_MTN = "donorMtn";
	public static final String RECIPIENT_MTN = "recipientMtn";
	public static final String FIVEG_HOME = "5GHome";
	public static final String ORDER_INFORMATION = "ORDERINFORMATION";
	public static final String ADD_NICK_NAME = "addNickName";
	public static final String INACTIVE = "Inactive";
	public static final String PROMO_HUB = "PromoHub";
	public static final String MYOFFER_HEXPLAN_INFO="myOfferHexPlanInfo";
	public static final String MTN_LIST="mtnList";
	public static final String EUPBYOD = "EUPBYOD";
	public static final String BUYSIM = "BUYSIM";
	public static final String UPDATE_BARCODE = "updateBarcode";
	public static final String CART_ORDER_FLOW_TYPE = "cartOrderFlowType";
	public static final String CART_COUNT = "cartCount";
	public static final String MTN_FLOW = "mtnFlow";
	public static final String FIVEG_ADDRESS = "fiveGAddress";
	public static final String DEVICE_SOR_ID = "deviceSorId";
	public static final String PLAN_SOR_ID = "planSorId";
	public static final String THROTTLE_LIST = "throttleList";
	public static final String EXPRESS = "express ";
	public static final String VZW_ROLES="vzwRoles";
	public static final String ROLE = "role";
	public static final String W_AAL = "w/aal";
	public static final String W_EUP = "w/eup";
	public static final String EXPRESS_EUP = "express eup";
	public static final String EXPRESS_AAL = "express aal";
	public static final String EUP_W_AAL = "eup w/aal";
	public static final String AAL_W_EUP = "aal w/eup";
	public static final String S_AAL = "aal";
	public static final String S_EUP = "eup";
	public static final String DEVICE_CATEGORY_NAME="deviceCategoryName";
	public static final String DEVICE_PRODUCT_ID="deviceProductId";
	public static final String DEVICE_PROD_ID="deviceProdId";
	public static final String LOCATION_CODE ="ORDERLOC";
	public static final String VALIDATION_ERROR = " REQUEST VALIDATION ERROR";
	public static final String ACCOUNT_INFO_VALIDATE = "accountInfoValidate";
	public static final String ACCESSORY_SOR_ID = "accessorySorId";
	public static final String NSO = "nso";
	public static final String ESO = "eso";
	public static final String NAO = "nao";
	public static final String ACCESSORY_CATEGORY_NAME = "accessoryCategoryName";
	public static final String CRADLE_FLOW_JOURNEY = "cradleFlowJourney";
	public static final String ONE_CLICK_CHECKOUT_FOR_ACCESSORY = "oneClickCheckoutForAccessory";
	public static final String ACCESSORY_PRODUCT_ID = "accessoryProductId";
	public static final String EXPRESS_FLOW_FOR_ACCESSORY = "expressFlowForAccessory";
	public static final String ACCESSORY_COUNT_LIST = "accessoryCountList";
	public static final String WFM_ORDER_INFO = "WFMORDERINFO";
	public static final String READ_ORDER_PAGE = "ReadOrderPage";
	public static final String UPDATE_WFM = "updateWFM";
	public static final String DP_CHANGED = "DP_CHANGED";
	public static final String DP_INELIGIBLE = "DP_INELIGIBLE";
	public static final String DP_INELIGIBLE_MSG = "Based on your credit history, you'll need to pay the full retail price on your order.";
	public static final String DP_CHANGED_MSG = "Based on your credit history, you'll need to make a down payment on your order which will reduce your monthly payments.";
	public static final String DP_CHANGED_MSG_5G = "<div><h1>So based on your credit, you will need to pay $#price# today.</h1> <div class='margin18 noSideMargin fontSize_5'>" +
			"By paying this amount upfront, you'll pay $#monthlyPrice# less towards your equipment each month. </div></div>";
	// Plan change warning message related code
	public static final String CLOUD_STORAGE_DROPPED_KEY = "CLOUD_STORAGE_DROPPED_KEY";
	public static final String CLOUD_STORAGE_DROPPED_AUTO_ENROLLED_KEY = "CLOUD_STORAGE_DROPPED_AUTO_ENROLLED_KEY";
	public static final String ECPD_DISCOUNT_NOT_CARRY_OVER_KEY = "ECPD_DISCOUNT_NOT_CARRY_OVER_KEY";
	public static final String ECPD_KIDS_DISCOUNT_NOT_CARRY_OVER_KEY = "ECPD_KIDS_DISCOUNT_NOT_CARRY_OVER_KEY";
	public static final String APPLE_MUSIC_NEW_MEXICO_BILLING_KEY = "APPLE_MUSIC_NEW_MEXICO_BILLING_KEY";
	public static final String APPLE_MUSIC_BILLING_KEY = "APPLE_MUSIC_BILLING_KEY";
	public static final String MPP_PAIRED_PHONE_DISCOUNT_KEY = "MPP_PAIRED_PHONE_DISCOUNT_KEY";
	public static final String DISNEY_PLUS_DROPPED_KEY = "DISNEY_PLUS_DROPPED_KEY";
	public static final String ECPD_ID_MILITARY = "3186257";
	public static final String ECPD_ID_FIRST_RESPONDER = "4769885";
	public static final String ECPD_ID_EMPLOYEE = "815125";
	public static final String HEX_CATEGORY = "67";
	public static final String ABOVE_UNLIMITED_PLAN = "17994";
	public static final String CLOUD_STORAGE_SFO = "86211";
	public static final String APPLE_MUSIC_INCLUDED_SPO = "1464";
	public static final String APPLE_MUSIC_SUBSCRIPTION_SPO = "1381";
	public static final String VZ_VIDEO = "VZVIDEO";
	public static final String NEW_MEXICO = "NM";
	public static final String MPP_LOSS_MSG_FOR_START_PLANS = "26907,26911,26926,39385,39387,39390"; // play more unlimited(269070, do more unlimited(26911), get more unlimited(26926)
	public static final String MPP_LOSS_MSG_SELECTED_PLAN = "26872";
	public static final String ENFORCE_KIDS_PLAN_KEY = "ENFORCE_KIDS_PLAN_KEY";
	public static final String JUST_KIDS_PROMO_LOSS_KEY = "JUST_KIDS_PROMO_LOSS_KEY";
	public static final String KIDS_PLAN_SOR_COLLECTION_CODE = "VPMET";
	public static final String HEX_PLAN_SOR_COLLECTION_CODE = "VPUNL";
	public static final String HEX_PLAN_SOR_CATEGORY_CODE = "67";

	public static final String RPS_INTENT = "rpsIntent";

	public static final String RETAIL_IPAD = "OMNI-RETAIL-TAB";

	public static final String SAVE_FOR_LATER = "saveForLater";
	public static final String DELETE_SAVE_FOR_LATER = "deleteSaveForLater";
	public static final String REMOVE_SAVE_FOR_LATER = "removeSaveForLater";

	public static final String PRE_CONFIGURE="preconfigure";
	public static final String PRE_CONFIGURED="Preconfigured";
	public static final String CLEAR_CART = "CLEARCART";
	public static final String CLEAR_ALL = "ClearAll";
	public static final String REQUEST_VALIDATION_ERROR = "REQUEST_VALIDATION_ERROR";

	public static final String EXPRESS_STORE = "EXPRESS_STORE";
	public static final String DIGITAL = "digital";
	public static final String ASSISTED = "assisted";
	public static final String ADD_ACCESSORY_AND_CHECKOUT = "addAccessoryAndCheckout";

	public static final String INTERNAL_SERVER_ERROR = "Internal Server Error";
	public static final String EXCEPTION_ERROR_CODE = "500";
	public static final String EXCEPTION = "Exception";

	public static final String INVALID_REQUEST_ERROR = "Invalid Request Data";
	public static final String INVALID_REQUEST_ERROR_CODE = "400";

	public static final String RPS_FLOW_PAIRING_MODE = "rpsFlowPairingMode";
	public static final String RPS_FLOW_IMEI = "rpsFlowIMEI";
	public static final String RPS_FLOW_PHONE_MTN = "rpsFlowPhoneMtn";
	public static final String RPS_FLOW_TRANSACTION_ID= "transaction-id";
	public static final String RPS_FLOW_SERVICE_CODE= "service-code";
	public static final String RPS_FLOW_TOKEN= "token";
	public static final String RPS_FLOW_PRIMARY_DEVICE_MDN= "primary-device-mdn";
	public static final String RPS_FLOW_ASSOCIATED_SUBSCRIPTION= "associated-subscription";
	public static final String RPS_FLOW_ESIM_DOWNLOAD_DELAY= "esim-download-delay";
	public static final String RPS_FLOW_DEVICE_USER_AGENT= "device-user-agent";
	public static final String RPS_FLOW_ASSOCIATED_SUBSCRIPTION_TWO= "2";
	public static final String RPS_FLOW_NUMBERSHARE= "numbershare";
	public static final String RPS_FLOW_STANDALONE= "standalone";
	public static final String RPS_USER_FLOW= "rpsUserFlow";
	public static final String RPS_OS_TYPE= "rpsOsType";
	public static final String RPS_DEVICE_MFG= "rpsDeviceMfg";
	public static final String VZW_RPS = "VZW-RPS";
	public static final String FALSE= "false";
	public static final String TRUE_FLAG = "true";

	public static final String FLORIDA_RINGBELL_EXCEPTION= "3246";
	public static final String FEA= "FEA";
	public static final String MOBILE_SECURE = "mobileSecure";
	public static final String ACCOUNT_MEMBER = "accountMember";
	public static final String KEEP_PLAN = "keepPlan";
	public static final String CONFIRMATION = "Confirmation";

	public static final String STORE_LOCATION_STATE = "storeLocationState";
	public static final String BILLING_STATE = "billingState";
	public static final String CUSTOMER_ADDRESS_STATE = "customerAddressState";
	public static final String LINELEVEL_DIGITALSECURE_SUBSCRIPTION_COUNT = "lineLevelDigitalSecureSubscriptionCount";

	public static final String NY="NY";
	public static final String PROTECTING_DIGITAL_SECURE_MORE_THAN_2_LINES_OUTSIDE_NY= "Protecting 3 or more lines requires an upgrade to the account-level subscription for billing address outside of NY.";
	public static final String PROTECTING_DIGITAL_SECURE_MORE_THAN_2_LINES_NY_CUSTOMER= "Protecting 3 or more lines with Digital Secure NY requires an upgrade to the account level subscription.";
	public static final String DIGITAL_SECURE_SUBSCRIPTION_ITEM_ID_LL= "307355196";
	public static final String DIGITAL_SECURE_SUBSCRIPTION_ITEM_ID_AL= "307462196";
	public static final String DIGITAL_SECURE_LL = "Billing address outside of NY will be charged $5.00/month.";
	public static final String DIGITAL_SECURE_AL = "Billing address outside of NY will be charged $10.00/month.";
	public static final String RTD_KEY = "RTD_JSON";
	public static final String MYOFFERS = "MYOFFERS";
	public static final String UPGRADE_FEE = "UPGRADE_FEE";

	public static final String REFUND_EXCHANGE = "REX";
	public static final String CONTRACT_CHANGE = "CCH";
	public static final String EXCHANGE = "EXC";
	public static final String SALES_ORDER_ADJUSTMENT = "SalesOrderAdjustment";
	public static final String NEW_CUSTOMER = "N";
	public static final String PASO ="PASO";
	public static final String NSP ="NSP";
	public static final String NAP ="NAP";
	public static final String NSE ="NSE";

	public static final String PAL ="PAL";

	public static final String PUP ="PUP";
	public static final String NSE_BYOD = "NSEBYOD";
	public static final String NSE_5G = "NSE_5G";
	public static final String EPP_RESTRICTIONS= "3261";
	public static final String EPP_RESTRICTIONS2= "3263";
	public static final String EDGE_BUYOUT_KEY = "edgeBuyoutRequest";
	public static final String INDIVIDUAL = "Individual";
	public static final String PLAN_OVERAGE_BACKDATE_MSG = "Choosing the current date will result in overage due to unbilled usage and proration. Recommend picking back date";
	public static final String PLAN_OVERAGE_FUTUREDATE_MSG = "Choosing the current date will result in overage due to unbilled usage and proration. Recommend picking future date";
	public static final String EMPTY_STRING = "";
	public static final String STATUS_UPDATE = "STATUS-UPDATE";

	public static final String BBP_IMEI = "bbpimei";
	public static final String BBP_ICCID= "bbpiccid";
	public static final String IS_SMARTPHONE= "isSmartphone";
	public static final String BBP_IMEI2 = "bbpimei2";
	public static final String IS_ESIMDEVICE= "isEsimDevice";
	public static final String BBP_FLOWTYPE = "bbpFlowType";
	public static final String BBP_DEFAULT_ZIPCODE_FOR_TABLETFLOW = "bbpDefaultZipcodeForTabletFlow";
	public static final String BBP_SDKDEVICE_FIRSTNAME = "bbpSDKDeviceFirstName";
	public static final String BBP_SDKDEVICE_LASTNAME = "bbpSDKDeviceLastName";
	public static final String BBP_SDKDEVICE_PHONENUMBER = "bbpSDKDevicePhoneNumber";
	public static final String BBP_SDKDEVICE_EMAIL = "bbpSDKDeviceEmail";
	public static final String BBP_SDKDEVICE_ZIPCODE = "bbpSDKDeviceZipcode";
	public static final String BBP_DEVICESIMVALIDATION_FLAG = "isDeviceSimValidationAPISuccess";
	public static final String IS_SDKDEVICE= "isSDKDevice";

	public static final String BBP_ZIPCODE= "bbpZipcode";
	public static final String VZW_BBP = "VZW-DOTCOM-BBP";
	public static final String INTENT_TYPE = "intentType";
	public static final String IS_APPLEDEVICE = "isAppleDevice";

	public static final String COOKIE_ECPD_TOKEN = "ecpdcookie";
	public static final String COOKIE_ECPD_DOMAIN = "domainCookie";
	public static final String COOKIE_SALESREPID = "RepIdCookieText";
	public static final String COOKIE_REFERRAL_VENDOR = "AFFILIATE";
	public static final String ADDACCOUNTPIN = "addAccountPIN";
	public static final String ACCOUNTINFO_ORDERREVIEW = "AccountInfo/OrderReview";

	/*
	 * https://onejira.verizon.com/browse/NSADT-55837-fix for the user id
	 */
	public static final String DEFAULT_USER_ID= "nsa_tester";
	public static final String FLEX="Flex";
	public static final String ITEM_DETAILS = "itemDetails";
	public static final String ITEM_CODE = "itemCode";
	public static final String QTY = "quantity";
	public static final String REFUND_TYPE = "refundType";
	public static final String RETURN_TYPE = "returnType";
	public static final String USERCONTACTINFO = "USERCONTACTINFO";

	public static final String CREDIT_APP_NUM = "creditAppNum";

	public static final String GARMIN_DACC= "01159";
	public static final String TRACKER_DACC= "01157";
	public static final String GIZMO_DACC= "01350";

	public static final String RING_LAUNCHPACKAGESKU= "4K11V90ENV";
	public static final String GIZMO_LAUNCHPACKAGESKU= "QTAX53B,QTAX53P";

	public static final String RING_PRODNAME= "ring";
	public static final String TRACKER_PRODTYPE= "4G_LOCATOR";
	public static final String PHONE="phone";
	public static final String TABLET="Tablet";
	public static final String DEVICETYPE_PHONE="PHONE";
	public static final String DEVICETYPE_RING="RING_DEVICE";
	public static final String DEVICETYPE_TRACKER="TRACKER_DEVICE";
	public static final String DEVICETYPE_GIZMO="GIZMO_DEVICE";
	public static final String DEVICETYPE_GARMIN="GARMIN_DEVICE";
	public static final String DEVICETYPE_BBP="bbpDeviceType";
	public static final String EXISTING_CUSTOMER = "EXISTINGCUSTOMER";
	public static final String HOST_NAMES_REGEX = "verizon.com|verizonwireless.com|vzwqa1.verizonwireless.com|vzwqa2.verizonwireless.com|vzwqa3.verizonwireless.com|vzwqa4.verizonwireless.com|vzwqa5.verizonwireless.com|vzwqa6.verizonwireless.com|vzwqa7.verizonwireless.com|vzwqa8.verizonwireless.com";
	public static final List<String> tabletDeviceCategoryList = Arrays.asList("4g internet", "4g tablet",
			"4g netbooks", "4g netbooks and tablet", "4g connected device","5g tablet","5g laptop","5g internet");

	public static final String FMI_CHECK = "FMIcheck";
	public static final String FMI_OVERRIDE = "FMI-OVERRIDE";

	public static final String BBP_INTENT_ORDERSELFSERVICE ="vzw.intent.OrderStatusSelfService";
	public static final String DEVID = "devid";
	public static final String EID = "eid";
	public static final String CHAT_STORE = "CHAT-STORE";
	public static final String QUOTE_PRICING = "quotePricingValues";
	public static final String VALIDATE_ORDER_KEY = "voKey";

	public static final String CUST_TYPE = "custType";
	public static final String VISION_CUSTTYPE_PE = "PE";
	public static final String VISION_CUSTTYPE_BE = "BE";
	public static final String VISION_CUSTTYPE_ME = "ME";
	public static final String CUST_TYPE_B2C = "B2C";
	public static final String CUST_TYPE_B2E = "B2E";
	public static final String CUST_TYPE_EPP = "EPP";
	public static final String REX="REX";
	public static final String INTENDTYPE="intendType";
	public static final String INTENTTYPE="intentType";
	public static final String CASEID = "caseId";
	public static final String CARTID = "cartId";
	public static final String WISHLIST_FLOW = "wishListFlow";
	public static final String BYOD_FLOW_CHECKOUT = "byodFromCheckout";

	// 5G constants

	public static final String PROF_SETUP = "Professional SetUp";
	public static final String SELF_SETUP = "Self SetUp";
	public static final String FIVEG_HOME_QUALIFIED = "fiveGHomeQualified";
	public static final String LTE_HOME_QUALIFIED = "LTEQualified";
	public static final String LAUNCH_TYPE = "launchType";
	public static final String ADDRESS_TYPE = "addressType";
	public static final String INSTALL_TYPE = "installType";
	public static final String EVENTCORRELATIONID = "eventCorrelationId";
	public static final String ADDRESSLINE1 = "addressLine1";
	public static final String ADDRESSLINE2 = "addressLine2";
	public static final String CITY = "city";
	public static final String STATE = "state";
	public static final String ZIPCODE = "zipCode";
	public static final String LONGITUDE = "longitude";
	public static final String LATITUDE = "latitude";
	public static final String FLOOR_NUMBER = "floor";
	public static final String LTEHOMESKU = "LTEHomeSku";
	public static final String BUILDING_ID = "buildingId";
	public static final String BUNDLENAME = "bundleName";
	public static final String BUNDLEID = "bundleId";
	public static final String BUNDLE_TYPE = "bundleType";
	public static final String LTE_ACTION_INDICATOR = "Z";
	public static final String LTE_CONTRACT_TERM = "VERIZON_EDGE";
	public static final String LTE_FRP_PRICETYPE = "FRP";
	public static final String LTE_DPP_PRICETYPE = "DPP";
	public static final String FIVEG_CONTRACT_TERM = "MONTH_TO_MONTH";
	public static final String LAUNCHTYPE_FCL = "FCL";
	public static final String LAUNCHTYPE_4GH = "4GH";
	public static final String FIPS_CODE = "fipsCode";
	public static final String ITEMTYPE_PLAN = "PLAN";
	public static final String ITEMTYPE_SUBSCRIPTION = "SUBSCRIPTION";
	public static final String ITEMTYPE_PROTECTION = "PROTECTION";
	public static final String COVID_QUES_ANSWERED = "covidQuestionareAnswered";
	public static final String INTENT_EUP_LTE = "EUP_LTE";
	public static final String LTE_UPGRADE_SKU = "ASK-NCQ1338";
	public static final String IS_REDESIGN_FLOW = "redesignFlow";

	//5g pega constants

	public static final String BPM_SALES_ORDER_PURCHASE = "SalesOrderPurchase";
	public static final String BPM_PEGA_GENERATED_MESSAGE = "PEGA generated message";
	public static final String FIVEG_THROTTLE_NAME = "HOMESAFETY_TRIAL_WITHOUT_MTNS";


	public static final String ESIM_IPAD_DACCS = "esim.ipad.daccs";
	public static final String ESIM_LAPTOP_DACCS = "esim.laptop.daccs";
	public static final String IPAD = "IPAD";
	public static final String LAPTOP = "LAPTOP";
	public static final String SMARTPHONE = "PHONE";
	public static final String IS_PROPSECT = "isProspect";
	public static final String ESIM_PHONE_DACCS = "esim.phone.daccs";
	public static final Boolean TRUE = true;
	public static final String MANAGE_ACCOUNT = "MANAGEACCOUNT";
	public static final String IN_FLIGHT_ORDER = "inFlightOrder";
	//PSTGRO-6849
	public static final String EBB_WARNING_COMBO = "By switching plans, you'll lose your discount.You are currently receiving a promotional discount based on your current plan. Switching will end this discount at the end of your next bill cycle. In addition, you are currently receiving a temporary Emergency Broadband discount. By switching plans, you will lose that discount.";
	//PSTGRO-6578
	public static final String EBB_WARNING_NONCOMBO = "You are currently receiving a temporary Emergency Broadband discount. By switching plans, you will lose that discount.";
	public static final String EMERGENCY_BROADBAND_DISCOUNT_SPO_1946 = "1946";
	public static final String EMERGENCY_BROADBAND_DISCOUNT_SPO_1945 = "1945";
	public static final String EBB_DISCOUNT_KEY = "EBB_DISCOUNT_KEY";

	public static final String ADD_MANUAL_DISCOUNT = "addManualDiscount";
	public static final String ADD_EFFECTIVE_DATE = "addEffectiveDate";
	public static final String IS_PRE_QUALIFIED_NBX = "isPreQualifiedNBX";

	public static final String GRIDWALL_URL = "/sales/digital/gridwall.html";
	public static final String STATUS_SUCCESS = "Success";
	public static final String STATUS_FAILURE = "Failed";

	public static final String CHANNEL_ID_NUMBERLINK = "VZW-NUMBERLINK";
	public static final String ORDERSUBMIT = "OrderSubmit";
	public static final String ACCESSORIES_INTERSTIAL_PROSPECT = "AccessoryInterestialProspect";

	public static final String BYOD_ESIM_FLOW = "byodEsimFlow";
	public static final String BYOD_DEVICE_SOR_DISPLAYNAME = "byodDeviceSorDisplayName";

	public static final String EXTERNAL_ID="externalid";
	public static final String GIG="gig";
	//esim byod
	public static final String DEVICE_CATEGORY_SMARTPHONE="Smartphone";
	public static final String ESIM_MODEL_NAME="eSIM";
	public static final String PREPAID_MODEL_NAME=" PP";
	public static final String ESIM_INDICATOR="-E";
	public static final String ESIM_SKU="esimSKU";
	public static final String PSIM_SKU="psimSKU";
	public static final String NSE_BYOD_LANDING ="NSEBYODLanding";
	public static final String BYOD_SIMID_PAGE = "BYODSimIDPage";
	public static final String ESIM = "eSim";
	public static final String PSIM = "pSim";
	public static final String VERIZON = "VERIZON";
	public static final String ATT = "ATT";
	public static final String SPRINT = "SPRINT";
	public static final String TMOBILE = "T-MOBILE";

	//Abandon cart constants
	public static final String LAST_DEVICE_PROD_ID="dev_prod_id";
	public static final String LAST_DEVICE_SOR_ID="dev_sor_id";
	public static final String NAME="name";
	public static final String MAKE="make";
	public static final String CATEGORY_ID="categoryId";
	public static final String CONTRACT_TERM="contractTerm";
	public static final String DEVICE_IMAGE_URL="img";
	public static final String PLAN_ID="plan_id";
	public static final String LAST_ACC_PROD_ID="acc_prod_id";
	public static final String LAST_ACC_SOR_ID="acc_sor_id";
	public static final String ACC_IMAGE_URL="acc_img";
	public static final String ACC_NAME="acc_name";
	public static final String CDL_CART_INFO="cdlCartInfo";

	public static final String SMARTPHONES="Smartphones";
	public static final String ACC_URL="acc_url";
	public static final String ACC_CATEGORY_ID="acc_categoryId";
	public static final String RTM_SESSION_ID="sessionId";
	public static final String ABANDON_CART="abandonCart";
	public static final String CART_TYPE="carttype";

	public static final String LOST_ACC_SOR_ID = "lostAccessorySorId";
	public static final String Z1_OFFER_CODE = "z1OfferCode";
	public static final String Z1_OFFER_CODE_APPLIED = "z1OfferApplied";
	public static final String OMNI_INDIRECT = "OMNI-INDIRECT";
	public static final String UPG_FEE = "UPGRADEFEE";
	public static final String SAFETECH_SESSION_ID = "safeTechSessionId";

	public static final String CDL_CART_TYPE="cdlCartType";
	public static final String EMAIL_ADDRESS = "prEmailId";/*MVP2*/
	public static final String CBR = "cbr";
	public static final String SESSION_ID = "digital_ig_session";
	public static final String ADDRESS_REQUEST="addressRequest";

	public static final String D2D_LOCATION_CODE= "locationId";
	public static final String IS_D2D_FLOW= "isD2DFlow";
	public static final String MUC_ELIGIBLE_FLAG= "fiveGMUCEligible";
	public static final String CREDIT_CHECK_FAILURE_COUNTER= "creditCheckFailedCount";
	public static final String CREDIT_CHECK_FAILURE_RESPONSE= "creditCheckMaxAttemptedFailure";
	public static final String FLOW_TYPE_NUMBERLINK = "NUMBERLINK_NEW";
	public static final String FLOW_TYPE_NUMBERLINK_MODIFY = "NUMBERLINK_MODIFY";
	public static final String SUCCESS_URL = "successUrl";
	public static final String EXTERNALID = "externalid";

	public static final String SAMSUNG = "SAMSUNG";
	public static final String MOTOROLA = "MOTOROLA";
	public static final String SONY = "SONY";
	public static final String IPHONE = "IPHONE";
	public static final String SAMSUNG_DEVICENAME = "Samsung";
	public static final String MOTOROLA_DEVICENAME = "Motorola";
	public static final String SONY_DEVICENAME = "Sony";
	public static final String IPHONE_DEVICENAME = "iPhone";

	public static final String INTENT_REDIS = "intent";
	public static final List<String> VZPH_ID = Arrays.asList("1614");
	public static final String VZPH_REMOVED = "vzphRemoved";
	public static final List<String> CDE_PLAN_EQUIP_CODES = Arrays.asList("JPK","USJ","IHP","JTP","CAN");
	public static final String CDE_STD_PLAN_OFFR_TYPE_GRP_NO = "0000000015";
	public static final String CDE_VPC_PLAN_OFFR_TYPE_GRP_NO = "0000000002";
	public static final String AUTO_PAY_ENROLLED = "autoPayEnrolled";
	public static final String FIFTY_PERCENT_DISC_DROP_FEATUE_CODE = "1465";
	public static final String AUTOPAY_DISC_DROP_FEATUE_CODE = "1247";
	public static final String NSE_LTE = "NSE_LTE";/*MVP2*/
	public static final String AAL_LTE = "AAL_LTE";/*MVP2*/
	public static final String FLOW_TYPE_NUMBERLINK1 = "NUMBERLINK";
	public static final String IVR = "IVR";
	public static final String PROMO_MAX_COUNT = "promoMaxCount";
	public static final String PROMO_VALID_MAX_COUNT = "promoValidMaxCount";
	public static final String SERVICE_NAME_NUMBERLINK = "NumberLink";
	public static final String PROTECTION_VERSION = "protectionVersion";
	public static final String AUTOPAY_LOST = "AUTOPAY_LOST";
	public static final String AUTOPAY = "AUTOPAY";
	public static final String CHANNEL = "channel";

	public static final String UNDEFINED = "undefined";
	public static final String RING = "RING";
	public static final String GARMIN = "GARMIN";
	public static final String TRACKER = "TRACKER";

	public static final String SDK_RING_DACCS = "sdk.ring.daccs";
	public static final String SDK_GARMIN_DACCS = "sdk.garmin.daccs";
	public static final String SDK_TRACKER_DACCS = "sdk.tracker.daccs";
	public static final String PORT_IN = "portIn";
	public static final String EMAIL_ID_REGEX = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
	public static final String D2D_POS_AGENTID = "d2dPosAgentID";
	public static final String NSE_NEW_LINE = "nse/new-line";
	public static final String EXCBYOD = "EXCBYOD";
	public static final String PROSPECT_CART_COUNT = "prospectCartCount";
	public static final String EXISTING_CASE = "existingCase";
	public static final int ERROR_ID_INT = 412;
	public static final int SUCCESS_ID_INT = 200;
	public static final String SOE_SERVICE_NAME = "onevz-soe-cart-service";
	public static final String ERROR_ID = "R1001";
	public static final String ERROR_NAME = "Precondition Failed";
	public static final String INFORMATION_LINK ="/sales/digital/expressCheckout.html?pageName=cart";

	public static final String NSEACC="NSEACC";

	public static final String ORIGINATING_CLIENT_IP = "OriginatingClientIp";
	public static final String CLIENT_IP = "clientIp";
	public static final String ICONIC_TEST_INTENT = "iconicTestIntent";
	public static final String IS_PROSPECT = "isProspect";
	public static final String IS_DIRECT_APPLY = "isDirectApply";
	public static final String REP_ID = "repId";
	public static final String STORE_NAME = "storeName";
	public static final String ICONIC_TEST_INTENT_FROM_CRADLE = "iconicTestIntentFromCradle";
	//5G-Upgrade
	public static final String EUP_5G_REPAIR = "EUP_5G_REPAIR";
	public static final String EUP_5G_BUNDLE = "BUNDLE";
	public static final String EUP_5G_PROF_SETUP = "5GHomeGeminiProfSetup";
	public static final String EUP_5G_CUSTOMER_PROFILE_ADDRESS = "CustomerProfileAddressGQLResponse";
	//Cband
	public static final String NETWORK_BANDWIDTH_TYPE ="networkBandwidthType";
	public static final String CBAND_SKU ="cBandSku";
	public static final String NUMBER_OF_LINES = "numberOfLines";
	public static final String ACCOUNT_CAP_EXCEEDED= "3238";
	public static final String PAST_DUE_BALANCE = "PAST_DUE_BALANCE";
	//clearAndContinue standalone accessory NSEACC implementation
	public static final String PROSPECT_CARTID ="prospectCartId";
	//clearAndContinue standalone accessory NSEACC implementation
	public static final String CONNECTED_TO_ADDED = "CONNECTED-DEVICE-GAIN";
	public static final String MULTI_LINE = "mulitiline";
	public static final String DIGITAL_CHANNEL = "Digital";
	public static final String GIFTITEM = "GIFTITEM";

	public static final String BOGO_MTN ="bogoMtn";
	public static final String NMC_GOOGLE_PLAY_PASS_LOSS = "NMC-GOOGLE-PLAY-PASS-LOSS";
	public static final String GOOGLE_PLAY_PASS_LOSS = "GOOGLE-PLAY-PASS-LOSS";
	public static final String GOOGLE_PLAY_PASS_GAIN = "GOOGLE-PLAY-PASS-GAIN";
	public static final String STATE_NEW_MEXICO = "STATE_NM";
	public static final String STEP_UP = "STEP_UP";
	public static final String PAID_CONVERSION = "PAIDCONVERSION";
	public static final String GOOGLE_PLAY_INCLUSION = "GOOGLE_PLAY_INCLUSION";
	public static final String APPLE_ARCADE_INCLUSION = "APPLE_ARCADE_INCLUSION";
	public static final String NMC_APPLE_ARCADE_LOSS = "NMC-APPLE-ARCADE-LOSS";
	public static final String APPLE_ARCADE_GAIN = "APPLE-ARCADE-GAIN";
	public static final String APPLE_ARCADE_LOSS = "APPLE-ARCADE-LOSS";
	public static final String NMC_APPLE_ARCADE_GOOGLE_PLAY_LOSS = "NMC-APPLE-ARCADE-GOOGLE-PLAY-LOSS";
	public static final String APPLE_ARCADE_GOOGLE_PLAY_LOSS = "APPLE-ARCADE-GOOGLE-PLAY-LOSS";
	public static final String APPLE_ARCADE_GOOGLE_PLAY_GAIN = "APPLE-ARCADE-GOOGLE-PLAY-GAIN";
	public static final String TRAVEL_PASS_LOST = "TRAVEL-PASS-LOSS";
	public static final String TPMIXMATCH = "TPMIXMATCH";
	public static final String DROP = "DROP";
	public static final String VERIZON_CLOUD_DISCOUNT = "VERIZON_CLOUD_DISCOUNT";
	public static final String CLOUD_DISCOUNT_GAIN_1TB = "CLOUD_DISCOUNT_GAIN_1TB";
	public static final String CLOUD_DISCOUNT_GAIN_600GB = "CLOUD_DISCOUNT_GAIN_600GB";
	public static final String CLOUD_DISCOUNT_LOSS_1TB = "CLOUD_DISCOUNT_LOSS_1TB";
	public static final String CLOUD_DISCOUNT_LOSS_600GB = "CLOUD_DISCOUNT_LOSS_600GB";
	public static final String TPFREEDAYS_LONGMSG = "TPFREEDAYS_LONGMSG";
	public static final String TPFREEDAYS_TPMIXMATCH = "TPFREEDAYS_LONGMSG";
	public static final String ACCESSORY_FINANCING_OFFERS_INFO = "accessoryFinancingOfferInfo";
	//AddPlan
	public static final String PREPAY_ADD_PLAN_REQUEST  = "prepay_addPlanRequest";
	//AddDevice
	public static final String PREPAY_ADD_DEVICE_REQUEST = "prepay_addDeviceRequest";
	public static final String PREPAY_ADD_FEATURES_REQUEST = "prepay_addFeaturesRequest";
	public static final String PREPAY_ADD_ACCESSORY_REQUEST = "prepay_addAccessoryRequest";
	public static final String PREPAY_OD_REQUEST_DATA = "prepay_odRequestData";
	public static final String PREPAY_REDIS_INTENT_TYPE = "intentType";
	
	public static final String PREPAY_OD_REQUEST_ECOMM_SESSION = "ECOMM_SESSION";
	public static final String PREPAY_OD_REQUEST_P_CSRFTKN = "p_csrftkn";
	public static final String PREPAY_OD_REQUEST_P_CSRF_TOKEN = "p-csrf-token";
	public static final String PREPAY_OD_REQUEST_FLOW = "FLOW";
	public static final String PREPAY_MTN_NEWLINE_PREFIX = "newLine";
	
	public static final String PREPAY_CHECKOUT_ITEM_TYPE_DEVICE = "DEVICE";
	public static final int PREPAY_CHECKOUT_DEVICE_QTY = 1;

	public static final String PREPAY_OD_ACCESSORY_ADD_ACTION = "add";
	public static final String PREPAY_OD_ACCESSORY_REMOVE_ACTION = "remove";
	
	public static final String HOTSPOT_PLAN_ID="28365";
	
	public static final String SUCCESS_MSG="SUCCESS";
	public static final String FAILURE_MSG="FAILURE";
	public static final int SUCCESS_CODE=200;
	public static final String RESPONSE_SUCCESS_CODE="00";
	public static final String RESPONSE_FAILURE_CODE="01";
	public static final String RESPONSE_SUCCESS_CODE_02="02";
	public static final String CONTACTINFO = "ContactInfo";
	public static final String CART_CONTACT_INFO_SUCCESS_CODE = "1";
	public static final String USER_CONTACT_INFO_UPDATE_SUCCESS_MSG="USERCONTACTINFO is Updated Successfully";

	public  enum FeatureActionTypeEnum {ADD, REMOVE}
	public  enum PlanActionTypeEnum {ADD, UPDATE}
	public static final String FEATURE_SKUID_MOBILE_HOTSPOT = "sku3920521";
	public static final String PREPAY_OD_EDITCART_FLOW_DEVICE = DEVICE;
	public static final String ADDDEVICE_LIMIT_EXCEEDED_NAME = "CART_DEVICE_EXCEED10";
	public static final  String ADDDEVICE_LIMIT_EXCEEDED_ID = "3255";
	public static final  String ADDDEVICE_LIMIT_EXCEEDED_MSG = "Maximum Devices Limit is Exceeded";
	public static final  String ADDDEVICE_LIMIT_EXCEEDED_CATEGORY = "BUSINESSERR";
	public static final  String PROACTIVE_CHAT_CUSTOMER_ERR_MSG="We see you are experiencing issues with your order. Chat now to connect to a live agent for further assistance";
	public static final  String PROACTIVE_CHAT_INDICATOR="Y";
	public static final  String ADDPORTIN_FAILURE_NAME = "PORTIN_NOT_VALID";
	public static final String ADDPORTIN_FAILURE_ID = "8255";
	public static final String ADDPORTIN_FAILURE_MSG = "Failure to port-in number";
	public static final  String ADDPORTIN_FAILURE_BUSINESS = "BUSINESSERR";
	public static final String ADDPORTIN_FAILURE_SYSTEM = "SYSTEMERR";
	public static final  String SHIPMENT_PROCESS_STEP = "Shipment";
	public static final  String ACCOUNT_PIN_PROCESS_STEP = "accountpin";
	public static final String ASSIGN_NUMBERS_PROCESS_STEP = ASSIGN_NUMBERS;
	
	public static final  String DEVICE_LARGE_SUFFIX = "?$device-lg$";
	public static final  String DEVICE_MEDIUM_SUFFIX = "?$device-med$";
	public static final  String DEVICE_THUMB_SUFFIX = "?$device-thumb$";
	public static final String DEVICE_MINI_SUFFIX = "?$device-mini$";
	
	public static final String ACCESSORY_LARGE_SUFFIX = "?$acc-lg$";
	public static final String ACCESSORY_MEDIUM_SUFFIX = "?$acc-med$";
	public static final String ACCESSORY_THUMB_SUFFIX = "?$acc-thumb$";
	public static final String ACCESSORY_MINI_SUFFIX = "?$acc-mini$";
	
	public static final  String SYSTEM_ERROR_CATEGORY = "SYSTEM_ERR";
	public static final String BUSINESS_ERROR_CATEGORY = "BUSINESS_ERR";
	
	public static final String PERSONALINFO_INVALID_ADDRESS_NAME = "ADDRESS_VALIDATION_ERROR";
	public static final String PERSONALINFO_INVALID_ADDRESS_ID = "3604";
	public static final String PERSONALINFO_INVALID_ADDRESS_MSG = "Invalid Address. Please try again.";
	public static final String PERSONALINFO_INVALID_ADDRESS_CATEGORY = BUSINESS_ERROR_CATEGORY;
	public static final  String PERSONALINFO_SYSTEM_ERROR_MSG = "Failed to Update Personal Info. Please try again.";
	public static final String PERSONALINFO_SYSTEM_ERROR_NAME = "PERSONAL_INFO_SYSTEM_ERROR";
	public static final  String PERSONALINFO_SYSTEM_ERROR_ID = "8804";
	public static final String CART_CONTACT_INFO_FAILURE_CODE = "0";
	public static final String USER_CONTACT_INFO_UPDATE_FAILURE_MSG="USERCONTACTINFO is Failed to Update";

	public static final String NEW_PLANS_PROCESS_STEP = "NewRecommendedPlanSelection";
	public static final String HOTSPOT_PLAN_PROCESS_STEP = "HOTSPOT";
	public static final String CHECKOUT_PLAN_PROCESS_STEP = "ONECLICKCHECKOUT";
	public static final String ACCOUNT_OWNER_PROCESS_STEP = "ACCOUNTOWNER";
	public static final String ADD_DEVICE_PREPAY_PROCESS_STEP = "ADDDEVICEPREPAY";
	public static final String PAYMENT_PROCESS_STEP = "Payment";
	
	public static final String ACCOUNT_OWNER_ERROR_NAME = "UPDATE_ACCOUNT_OWNER_ERROR";
	public static final  String ACCOUNT_OWNER_ERROR_ID = "3614";
	public static final  String ACCOUNT_OWNER_ERROR_MSG = "Failed to Update Account Owner. Please try again.";
	public static final String ACCOUNT_OWNER_BUS_ERROR_CATEGORY = "BUSINESS_ERR";
	public static final String ACCOUNT_OWNER_SYSTEM_ERROR_CATEGORY = SYSTEM_ERROR_CATEGORY;
	public static final String ACCOUNT_OWNER_EDIT_FLOW_NAME = "updateAccountOwner";
	
	public static final  String DEFAULT_NSE_LINE="newLine1";
	
	public static final  String ENDPOINT = "endPoint";
	
	public static final String CHARGE_TYPE = "One time activation fee";

	public static final String ADDDEVICE_PREPAID_OD_ERROR_NAMESPACE = "SOE-PREPAID-OD";
	public static final String ADDDEVICE_PREPAID_OD_ERROR_CARTADAPTOR_NAMESPACE = "SOE-PREPAID-CART-ADAPTOR";
	public static final String ADDDEVICE_PREPAID_OD_ERROR_CATEGORY_INTERNALSERVER = "PrepaidCartAdaptor-InternalServerError";

	public static final String ADDACCESSORY_ERROR_NAME = "CART_ACCESSORY_BUSINESS_EXCEPTION";
	public static final String ADDACCESSORY_ERROR_ID = "4256";
	public static final  String ADDACCESSORY_ERROR_MSG = "Device trying to add is Out of Stock";
	public static final  String ADDACCESSORY_ERROR_CATEGORY = ADDDEVICE_LIMIT_EXCEEDED_CATEGORY;

	public static final  String ADDACCESSORY_SYSTEM_ERROR_CATEGORY = ADDPORTIN_FAILURE_SYSTEM;
	public static final String ADDACCESSORY_LIMIT_EXCEEDED_NAME = "CART_ACCESSORY_BUSINESS_EXCEPTION_EXCEED";
	public static final  String ADDACCESSORY_LIMIT_EXCEEDED_ID = "3256";
	public static  final String ADDACCESSORY_LIMIT_EXCEEDED_MSG = "Maximum Accessories Limit is Exceeded";
	public static final String PLAN_UNLIMITED_TEXT = "Unlimited";

	public static final String PLAN_NUMBERSHARE_TEXT = "NumberShare";
	public static final String PLAN_UNLIMITED_PLUS_TEXT = "Unlimited Plus";
	public static final String PLAN_UNLIMITED_PLUS_CODE = "28401";
	public static final String PLAN_UNLIMITED_PLUS_CODE2 = "28399";

	public static final String PLAN_UNLIMITED_SMARTWATCH_CODE = "28443";

	public static final String PLAN_NUMBERSHARE_SMARTWATCH_CODE = "28445";
	public static final String NOT_NOW_FEATURE = "xxx";

	public static final  String VALIDZIPCODE_FAILURE_NAME = "PREPAY_INVALID_ZIP_CODE_MSG";

	public static final  String VALIDZIPCODE_FAILURE_MESSAGE = "The Zip Code you’ve entered is outside of our network coverage area. In order to establish service with Verizon, your billing and shipping addresses, and your primary place of use, must be within the areas served by the network Verizon owns and operates.";

	public static final String ERR_CATEGORY_PREPAID_OD_ADD_DEVICE = "ERR_PREPAID_OD_ADD_DEVICE";
	public static final String SYSTEM_FAILURE_PREPAID_OD = "Error while loading the Cart Page";

	public static final String ERR_MSG_REDIS_FAILED = "Failed to get the RedisData and returned error";
	public static final String ERR_MSG_REDIS_FAILED_EMPTY = "Error while fetching redis data - Redis returned empty";
	public static final String ERR_MSG_REDIS_FAILED_PARSING = "Error while fetching redis data - Failed to convert data";
	public static final String ERR_MSG_VALIDATION_ERROR_MTN = "Error while mtn information from Redis - Matching MTN not found for input";
	public static final String ERR_MSG_SWITCHSIM_ESIMONLY = "SwitchSim is not possible for the ESIM only devices";
	public static final String ERR_MSG_SWITCHSIM_INVALID_INPUTS = "Invalid inputs are passed to SwitchSim call";
	public static final String ERR_MSG_SWITCHSIM_SMARTIMEI_ESIM_NOT_ALLOWED = "Invalid inputs are passed to SwitchSim call - SmartIMEI flow doesn't allow ESIM";
	public static final String ERR_MSG_SWITCHSIM_FROM_ESIM_NOT_ALLOWED = "SwitchSim can not be invoked when ESIM is already in cart";
	public static final String ERR_MSG_SWITCHSIM_FROM_ESIM_MISMATCH = "SwitchSim can not be invoked as ESIM mismatched";
	public static final String ERR_MSG_SWITCHSIM_MISC_ERROR = "SwitchSim can't be invoked .. misc error";

	public static final String SWITCHSIM_FAILURE_NAME = "SWITCH_SIM_FAILURE";
	public static final String SWITCHSIM_FAILURE_BUSINESS = "BUSINESSERR";
	public static final String SWITCHSIM_FAILURE_SYSTEM = "SYSTEMERR";
	public static final String SWITCHSIM_OD_EDIT_FLOW_NAME = "switchSim";
	public static final String SWITCHSIM_OD_SIMTYPE_ESIM = "ESIM";
	public static final String SWITCHSIM_OD_SIMTYPE_PSIM = "PSIM";
	public static final String SWITCHSIM_OD_SIMTYPE_VZSIM = "VZSIM";
	public static final String FIVEG_DEVICE = "5GE";
	public static final String DEVICE_CATEGORY_SP = "smartphone";
	public static final String DEVICE_APPLE = "Apple";
	public static final double PROMO_300 = 300;

	public static final String SMARTPHONE_DEFAULT_PLAN = "sku3920514";
	public static final String DATADEVICE_DEFAULT_PLAN = "sku4680019";

	public static final String SMARTWATCH_DEFAULT_PLAN="sku6007707";

	public static final String ADD_PREPAY_FAILURE_CODE = "01";
	public static final String ADD_PREPAY_FAILURE_MESSAGE = "We see you are experiencing issues with your order. Chat now to connect to a live agent for further assistance";

	public static final String NO_TAX = "NoTax";
	public static final String PREPAID_OD_INTERNAL_SERVER_ERROR = "PrepaidOD-InternalServerError";

	public static final String JSON_CONVERSION_EXCEPTION = "Exception occur during converting response to String";

	public static final String JSON_CONVERSION_EXCEPTION_MESSAGE="Exception occur during converting response to String {}";

	public static final String REDIS_DATA_NOT_FOUND_ERROR_CODE ="Failed and return error {}";




	private PrepayAdaptorCartConstants() {

	}
}


