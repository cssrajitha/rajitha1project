package onevz.soe.prepay.adaptor.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.model.addDevice.AddDeviceContext;
import onevz.soe.cart.model.addDevice.AddDeviceServiceBody;
import onevz.soe.cart.model.addDevice.AddDeviceServiceResponse;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.requests.AddDevicePEGARequest;
import onevz.soe.cart.responses.AddDevicePEGAResponse;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.common.model.PrepaidODRequestDataAccessorySkuIds;
import onevz.soe.common.model.PrepaidODRequestDataLines;
import onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants;
import onevz.soe.prepay.adaptor.cart.model.bpm.*;
import onevz.soe.prepay.adaptor.cart.model.cart.removelines.RemoveLineItemsRequest;
import onevz.soe.prepay.adaptor.cart.model.play.*;
import onevz.soe.prepay.adaptor.cart.model.play.common.error.EcommValidationError;
import onevz.soe.prepay.adaptor.cart.util.PrepayAdaptorCartUtil;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.spring.web.RequestDataBuilder;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.bpm.model.response.Error;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import onevz.soe.wsclient.prepay.webclient.model.PrepaidAdaptorWebClientRequest;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;
import reactor.core.publisher.Mono;

import java.util.*;
import java.util.stream.Collectors;

import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.*;

@Service
public class PrepayAdaptorCartAddDeviceHelper {

	@Autowired
	private ObjectMapper mapper;
	
	@Autowired
	private PrepayAdaptorWebClient prepayAdaptorWebClient;

	@Autowired
	SOELoginSessionBean sessionBean;

	@Autowired
	PrepayCartRedisHelper prepayCartRedisHelper;
	
	@Value("${maxDevicesAllowedPromoHub}")
	private int maxDevicesAllowedPromoHub;
	
	@Value("${addDevicePrepaidLegacyServiceUrl}")
	private String addDevicePrepaidLegacyServiceUrl;

	@Value("${addAccessoryPrepaidLegacyServiceUrl}")
	private String addAccessoryPrepaidLegacyServiceUrl;

	@Value("${removeLinesPrepaidLegacyServiceUrl}")
	private String removeLinesPrepaidLegacyServiceUrl;

	@Value("${prepaid.accountowner.selection.flag:true}")
	private boolean prepaidAccountOwnerSelectionFlag;

	private static final Logger logger = LoggerFactory.getLogger(PrepayAdaptorCartAddDeviceHelper.class);

	/**
	 * @param httpRequest
	 * @param addDevicePEGARequest
	 * @return AddDevicePEGAResponse
	 */
	public Mono<ResponseEntity<AddDevicePEGAResponse>> addDevice(ServerHttpRequest httpRequest, AddDevicePEGARequest addDevicePEGARequest) {
		logger.debug(" add-device adaptor Request: {}", addDevicePEGARequest);
		return prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)
			.doOnError(err -> logger.error("Failed and return error {0}", err))
			.defaultIfEmpty("")
			.flatMap(response -> {
				logger.info("PrepaidODRequestData From Redis::{}", response);
				String ecommSessionId= null;
				String pCsrfToken= null;
				ecommSessionId = RequestDataBuilder.withContext().fromAll().getValue(PREPAY_OD_REQUEST_ECOMM_SESSION);
				pCsrfToken = RequestDataBuilder.withContext().fromAll().getValue(PREPAY_OD_REQUEST_P_CSRFTKN);

				if(StringUtilities.isEmptyOrNull(ecommSessionId)) ecommSessionId = getHeaderValue(httpRequest, PREPAY_OD_REQUEST_ECOMM_SESSION);

				if(StringUtilities.isEmptyOrNull(pCsrfToken)) pCsrfToken = getHeaderValue(httpRequest, PREPAY_OD_REQUEST_P_CSRFTKN);

				logger.info("AddDevice Request headers: ECOMM_SESSION: {}\np_csrftkn: {}",ecommSessionId,pCsrfToken);
				int lineValue = 0;
				PrepaidODRequestData prepaidODRequestData = null;
				List<PrepaidODRequestDataLines> lines = null;

				if( StringUtilities.isEmptyOrNull(response)){
					lineValue = 1;
					lines = new ArrayList<PrepaidODRequestDataLines>();
					prepaidODRequestData = new PrepaidODRequestData();
					prepaidODRequestData.setCurr_line(lineValue);
				}else {
					try {
						prepaidODRequestData = mapper.readValue(response, PrepaidODRequestData.class);
					} catch (JsonProcessingException e) {
						logger.error("Failed to get data from redis:", e);
					}

					if (prepaidODRequestData.isOrderConfirmation()) {  // Order Confirmation is true
						prepaidODRequestData = null;
						lineValue = 1;
						prepaidODRequestData = new PrepaidODRequestData();
						prepaidODRequestData.setCurr_line(lineValue);
					} else {   // Order Confirmation is false and Redis is not empty
						if (null != prepaidODRequestData.getLines()) {
							List<PrepaidODRequestDataLines> linesWithCheckoutFlagFalse = prepaidODRequestData.getLines().stream().filter(line -> !line.isCheckoutFlag()).toList();

							if (linesWithCheckoutFlagFalse.size() > 1) {// blocking from adding 3rd device when checkout flag is False for two devices.
								AddDevicePEGAResponse pegaResponse = getAddDevicePEGAResponse(addDevicePEGARequest, prepaidODRequestData);
								pegaResponse.getServiceHeader().setStatusCode(PrepayAdaptorCartConstants.RESPONSE_SUCCESS_CODE_02);
								return Mono.just(ResponseEntity.status(HttpStatus.OK).body(pegaResponse));
							}
						} else {
							lineValue = 1;
						}
						lineValue = prepaidODRequestData.getCurr_line();
						prepaidODRequestData.setCurr_line(lineValue++);
						ecommSessionId = (prepaidODRequestData.getEcommSessionId()) != null ? prepaidODRequestData.getEcommSessionId() : ecommSessionId;
						pCsrfToken = (prepaidODRequestData.getPCsrfToken()) != null ? prepaidODRequestData.getPCsrfToken() : pCsrfToken;
						lines = prepaidODRequestData.getLines();

						if ((null != lines) && (lines.size() >= maxDevicesAllowedPromoHub)) {
							logger.error("Max allowed Device is reached, we cannot add more devices to the cart");
							return errorResponse(ADDDEVICE_LIMIT_EXCEEDED_NAME, ADDDEVICE_LIMIT_EXCEEDED_ID, ADDDEVICE_LIMIT_EXCEEDED_MSG, ADDDEVICE_LIMIT_EXCEEDED_CATEGORY);
						}
					}
				}
				prepaidODRequestData.setCurr_line(lineValue);
				prepaidODRequestData.setEcommSessionId(ecommSessionId);
				prepaidODRequestData.setPCsrfToken(pCsrfToken);
				String lastLine = CollectionUtilities.isNotEmptyOrNull(prepaidODRequestData.getLines())?prepaidODRequestData.getLines().get(prepaidODRequestData.getLines().size()-1).getMtn():"newLine0";
				String lineNo = lastLine.replace("newLine", "");
				String newLine = StringUtilities.isNotEmptyOrNull(lineNo)?String.valueOf(Integer.parseInt(lineNo)+1):"1";
				lines = (lines==null)? new ArrayList<>():lines;
				lines.add(getLineData(PREPAY_MTN_NEWLINE_PREFIX + newLine , addDevicePEGARequest));
				prepaidODRequestData.setLines(lines);
					 
				if(Objects.nonNull(prepaidODRequestData) && CollectionUtilities.isNotEmptyOrNull(prepaidODRequestData.getLines()) && prepaidODRequestData.getLines().size() == 1) {
					prepaidODRequestData.setAccountOwner(PREPAY_MTN_NEWLINE_PREFIX + newLine);
					logger.info("Updated {} as Account Owner",prepaidODRequestData.getAccountOwner());
				}
					 
				if(Objects.nonNull(addDevicePEGARequest) && Objects.nonNull(addDevicePEGARequest.getServiceBody())
					 && Objects.nonNull(addDevicePEGARequest.getServiceBody().getServiceRequest())
					 && Objects.nonNull(addDevicePEGARequest.getServiceBody().getServiceRequest().getContext())
					 && Objects.nonNull(addDevicePEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo())) {
					prepaidODRequestData.setZipCode(addDevicePEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getZipCode());
				}
				AddDevicePEGAResponse requestResponse = getAddDevicePEGAResponse(addDevicePEGARequest,prepaidODRequestData);
				return prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, prepaidODRequestData)
					.doOnError(err -> logger.error("Failed and return error {0}", err))
					.flatMap(upsertResp -> {
						logger.info("PrepaidODRequestData From Redis:: {} ", upsertResp);
						return Mono.just(ResponseEntity.status(HttpStatus.OK).body(requestResponse));
					});
			});
	}
	
	
	private Mono<? extends ResponseEntity<AddDevicePEGAResponse>> errorResponse(String name, String id, String message,
			String category) {
		AddDevicePEGAResponse addDevicePEGAResponse = new AddDevicePEGAResponse();
         List<Error> errors = new ArrayList<Error>();
         Error error = new Error();
         error.setName(name);
         error.setId(id);
         error.setMessage(message);
         error.setErrorCategory(category);
         error.setProactiveChatCustomMSG(PROACTIVE_CHAT_CUSTOMER_ERR_MSG);
         error.setProactiveChatIndicator(PROACTIVE_CHAT_INDICATOR);
         errors.add(error);
         addDevicePEGAResponse.setErrors(errors);
         return Mono.just(ResponseEntity.status(HttpStatus.OK).body(addDevicePEGAResponse));
	}

	/**
	 * @param httpRequest
	 * @param addDeviceToPrepayODBpmRequest
	 * @return AddDeviceToPrepayODBpmResponse
	 */
	public Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> addDeviceToPrepayOD(ServerHttpRequest httpRequest, AddDeviceToPrepayODBpmRequest addDeviceToPrepayODBpmRequest) {
		logger.debug(" add-device-prepay adaptor Request: {} {}", httpRequest.toString(), addDeviceToPrepayODBpmRequest);
		return prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)
				.doOnError(err -> logger.error("Failed to read PrepaidODRequestData from Redis, error:", err))
				.flatMap(response -> {
					logger.info("PrepaidODRequestData From Redis:: {} ", response);
					try{
						if (StringUtilities.isEmptyOrNull(response)) {
							logger.error("PrepaidODRequestData from Redis is empty {}", response);
							return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(prepareAddDevicePrepayODBpmResponseWithInternalError("500", "PrepaidODRequestData from Redis is empty", ADDDEVICE_PREPAID_OD_ERROR_CATEGORY_INTERNALSERVER, ADDDEVICE_PREPAID_OD_ERROR_CARTADAPTOR_NAMESPACE), HttpStatus.INTERNAL_SERVER_ERROR));
						} else {
							PrepaidODRequestData prepaidODRequestData = mapper.readValue(response, PrepaidODRequestData.class);
							if(null == prepaidODRequestData.getLines() || 0 == prepaidODRequestData.getLines().size()){
								return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(prepareAddDevicePrepayODBpmResponseWithInternalError("500", "No Devices to process in Redis", ADDDEVICE_PREPAID_OD_ERROR_CATEGORY_INTERNALSERVER, ADDDEVICE_PREPAID_OD_ERROR_CARTADAPTOR_NAMESPACE), HttpStatus.INTERNAL_SERVER_ERROR));
							}
							List<PrepaidODRequestDataLines> linesToProcess = prepaidODRequestData.getLines().stream().filter(line-> line.isCheckoutFlag() == false).toList();

							if(null == linesToProcess || 0== linesToProcess.size()){
								return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(prepareAddDevicePrepayODBpmResponseWithInternalError("200", "No Devices to process with checkoutflag=false", ADDDEVICE_PREPAID_OD_ERROR_CATEGORY_INTERNALSERVER, ADDDEVICE_PREPAID_OD_ERROR_CARTADAPTOR_NAMESPACE), HttpStatus.OK));
							}
							PrepaidODRequestDataLines lineToProcess = linesToProcess.stream().findFirst().get();
							//Create play AddDevice bean
								boolean loggedIn = prepaidODRequestData.isLoggedIn();
							PrepaidODAddDeviceRequest prepaidODAddDeviceRequest = getPrepayODAddDeviceRequest(lineToProcess, addDeviceToPrepayODBpmRequest);
							//call the adddevice play call
							PrepaidAdaptorWebClientRequest prepaidODAddDeviceLegacyServiceRequest = getPrepaidAddDeviceLegacyServiceRequest(prepaidODAddDeviceRequest, prepaidODRequestData);
							logger.info("Add Device OD call Request Endpoint: {} \n Request Body: {} \n Request Headers: {}",prepaidODAddDeviceLegacyServiceRequest.getUrl(), prepaidODAddDeviceLegacyServiceRequest.getRequestBody(), prepaidODAddDeviceLegacyServiceRequest.getHeader());
							
							return prepayAdaptorWebClient.getPrepayServiceResponse(httpRequest, prepaidODAddDeviceLegacyServiceRequest)
									.doOnError(error -> logger.error("Failed to get response for prepaidODAddDeviceLegacy service, error:", error))
									.flatMap(responseEntity -> {
										if (!responseEntity.getStatusCode().is2xxSuccessful()) {
											logger.error("Error while calling endpoint: {} with status code: {}", prepaidODAddDeviceLegacyServiceRequest.getUrl(), responseEntity.getStatusCode());
											return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(prepareAddDevicePrepayODBpmResponseWithInternalError(String.valueOf(responseEntity.getStatusCode()), "Error while getting response from PrepayOD-AddDevice call", PREPAID_OD_INTERNAL_SERVER_ERROR, ADDDEVICE_PREPAID_OD_ERROR_NAMESPACE), responseEntity.getStatusCode()));
										}
										//get the output
										VZWPrepayAddOrUpdateCartResponse addDevicePrepayODResponse = null;
										try {
											addDevicePrepayODResponse = mapper.readValue(responseEntity.getBody(), VZWPrepayAddOrUpdateCartResponse.class);
											logger.info("Add Device OD service response : {}", mapper.writeValueAsString(addDevicePrepayODResponse));
											if (200 != addDevicePrepayODResponse.getStatus()) {
												logger.error("Error while calling endpoint: {} with status code: {}", prepaidODAddDeviceLegacyServiceRequest.getUrl(), responseEntity.getStatusCode());
												return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(
														prepareAddDevicePrepayODBpmResponseWithError(addDevicePrepayODResponse), responseEntity.getStatusCode())
												);
											}
										} catch (JsonProcessingException e) {
											logger.error("Failed to convert response received from PrepaidOD Accessories", e);
											return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(prepareAddDevicePrepayODBpmResponseWithInternalError(String.valueOf(responseEntity.getStatusCode()), "Error while processing JSON response from PrepayOD-AddDevice call", PREPAID_OD_INTERNAL_SERVER_ERROR, ADDDEVICE_PREPAID_OD_ERROR_NAMESPACE), HttpStatus.INTERNAL_SERVER_ERROR));
										}

										//call the addAccessories play call
										if(null!=lineToProcess.getAccessorySkuIds() && 0<lineToProcess.getAccessorySkuIds().size()){
											PrepaidODAddAccessoriesRequest prepaidODAccessoriesRequest = getPrepaidODAddAccessoriesRequest(lineToProcess, addDeviceToPrepayODBpmRequest, addDevicePrepayODResponse);
											PrepaidAdaptorWebClientRequest prepaidODAddAccessoriesLegacyServiceRequest = getPrepaidAddAccessoriesLegacyServiceRequest(prepaidODAccessoriesRequest, prepaidODRequestData);
											logger.info("Add Accessory OD call Request Endpoint: {} \n Request Body: {} \n Request Headers: {}",prepaidODAddAccessoriesLegacyServiceRequest.getUrl(), prepaidODAddAccessoriesLegacyServiceRequest.getRequestBody(), prepaidODAddAccessoriesLegacyServiceRequest.getHeader());
											
											return prepayAdaptorWebClient.getPrepayServiceResponse(httpRequest, prepaidODAddAccessoriesLegacyServiceRequest)
													.doOnError(error -> logger.error("Failed to get response for prepaidODAddDeviceLegacy service, error:", error))
													.flatMap(accessoryResponseEntity -> {
														if (!accessoryResponseEntity.getStatusCode().is2xxSuccessful()) {
															logger.error("Error while calling endpoint: {} with status code: {}", prepaidODAddDeviceLegacyServiceRequest.getUrl(), accessoryResponseEntity.getStatusCode());
															return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(new AddDeviceToPrepayODBpmResponse(), accessoryResponseEntity.getStatusCode()));
														}
														//get the output
														PrepaidODAddAccessoriesResponse addAccessoriesResponse = null;
														try {
															addAccessoriesResponse = mapper.readValue(accessoryResponseEntity.getBody(), PrepaidODAddAccessoriesResponse.class);
															logger.info("Add Accessory OD service response : {}", mapper.writeValueAsString(addAccessoriesResponse));
														} catch (JsonProcessingException e) {
															logger.error("Failed to convert response received from PrepaidOD AddAccessories", e);
															return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(new AddDeviceToPrepayODBpmResponse(), HttpStatus.INTERNAL_SERVER_ERROR));
														}
														int index = prepaidODRequestData.getLines().indexOf(lineToProcess);
														lineToProcess.setCheckoutFlag(true);
														prepaidODRequestData.getLines().set(index,lineToProcess);

														return prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, prepaidODRequestData)
																.doOnError(err -> logger.error("Failed to update the PrepaidODRequestData to Redis in PrepaidODAddDevice", err))
																.flatMap(upsertResp -> {
																	logger.info("Successfully upserted PrepaidODRequestData to Redis:: {} ", upsertResp);
																	return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(new AddDeviceToPrepayODBpmResponse(), HttpStatus.OK));
																});
													});
										}
										int index = prepaidODRequestData.getLines().indexOf(lineToProcess);
										lineToProcess.setCheckoutFlag(true);
										prepaidODRequestData.getLines().set(index,lineToProcess);

										return prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, prepaidODRequestData)
												.doOnError(err -> logger.error("Failed to update the PrepaidODRequestData to Redis in PrepaidODAddDevice", err))
												.flatMap(upsertResp -> {
													logger.info("Successfully upserted PrepaidODRequestData to Redis:: {} ", upsertResp);
													return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(new AddDeviceToPrepayODBpmResponse(), HttpStatus.OK));
												});
										});
						}
					}catch (JsonProcessingException ex){
						logger.error("Failed to convert response received from PrepaidOD AddDevice", ex);
						return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(new AddDeviceToPrepayODBpmResponse(), HttpStatus.INTERNAL_SERVER_ERROR));
					}
				});
	}

	/**
	 * @param httpRequest
	 * @param addDeviceToPrepayODBpmRequest
	 * @return AddDeviceToPrepayODBpmResponse
	 */

	public Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> addDeviceToPrepayODMultiLine(ServerHttpRequest httpRequest, AddDeviceToPrepayODBpmRequest addDeviceToPrepayODBpmRequest) {
		logger.debug(" add-device-prepay adaptor Request: {}",  addDeviceToPrepayODBpmRequest);
		return prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)
				.doOnError(err -> logger.error("Failed to read PrepaidODRequestData from Redis, error: {}", err))
				.flatMap(response -> {
					logger.info("PrepaidODRequestData From Redis:: {} ", response);
					try {
						if (StringUtilities.isEmptyOrNull(response)) {
							logger.error("PrepaidODRequestData from Redis is empty {}", response);
							return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(prepareAddDevicePrepayODBpmResponseWithInternalError("500", "PrepaidODRequestData from Redis is empty", ADDDEVICE_PREPAID_OD_ERROR_CATEGORY_INTERNALSERVER, ADDDEVICE_PREPAID_OD_ERROR_CARTADAPTOR_NAMESPACE), HttpStatus.INTERNAL_SERVER_ERROR));
						} else {
							PrepaidODRequestData prepaidODRequestData = mapper.readValue(response, PrepaidODRequestData.class);
							if (null == prepaidODRequestData || 0 == CollectionUtils.size(prepaidODRequestData.getLines())) {
								return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(prepareAddDevicePrepayODBpmResponseWithInternalError("500", "No Devices to process in Redis", ADDDEVICE_PREPAID_OD_ERROR_CATEGORY_INTERNALSERVER, ADDDEVICE_PREPAID_OD_ERROR_CARTADAPTOR_NAMESPACE), HttpStatus.INTERNAL_SERVER_ERROR));
							}
							List<PrepaidODRequestDataLines> linesToProcess = prepaidODRequestData.getLines().stream().filter(line -> line.isCheckoutFlag() == false).toList();
							if(null == linesToProcess || 0== linesToProcess.size()){
								AddDeviceToPrepayODBpmResponse addDevicePrepayResponse = new AddDeviceToPrepayODBpmResponse();
								populateAddDevicePrepayResponse(prepaidODRequestData, null, null, addDevicePrepayResponse, new AddDeviceToPrepayODServiceBody(), new AddDeviceContext(), new CartServiceContextInfo(), new AddDeviceToPrepayODServiceResponse(), new AddDeviceToPrepayODAddAccessoriesResponse(),true);
								return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(addDevicePrepayResponse, HttpStatus.OK));
								//return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(prepareAddDevicePrepayODBpmResponseWithInternalError("200", "No Devices to process with checkoutflag as false", ADDDEVICE_PREPAID_OD_ERROR_CATEGORY_INTERNALSERVER, ADDDEVICE_PREPAID_OD_ERROR_CARTADAPTOR_NAMESPACE), HttpStatus.OK));
							}
							List<Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>>> lineMonos = new ArrayList<>();
							Map<String, Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>>> lineMonosMap = new HashMap<>();
							List<String> mtnList = new ArrayList<>();
							linesToProcess.forEach(lineToProcess -> {

								Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> lineMono = getLineDeviceAndAccessoryMono(lineToProcess, addDeviceToPrepayODBpmRequest, prepaidODRequestData, httpRequest);
								lineMonos.add(lineMono);
								mtnList.add(lineToProcess.getMtn());
								lineMonosMap.put(lineToProcess.getMtn(), lineMono);
								logger.info("AddDevice Lines Processed after added to lineMonosMap: {}",lineMonosMap.size());
							});

							//At max only two devices can be with checkoutflag=false
							if(2 == CollectionUtils.size(lineMonosMap)){

								Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> lineItem1 = lineMonosMap.get(CollectionUtilities.isNotEmptyOrNull(mtnList)?mtnList.get(0):PREPAY_MTN_NEWLINE_PREFIX+"1");
								Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> lineItem2 = lineMonosMap.get(CollectionUtilities.isNotEmptyOrNull(mtnList)?mtnList.get(1):PREPAY_MTN_NEWLINE_PREFIX+"2");

								//Following should never happened because both lineitem1 and lineitem2 should exists
								if(Objects.isNull(lineItem1) || Objects.isNull(lineItem2)) {
									logger.error("Rare error happened as addDeviceresponse for one of the multiline order is null");
									return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(prepareAddDevicePrepayODBpmResponseWithInternalError("500", "Multiline invalid Scneario", ADDDEVICE_PREPAID_OD_ERROR_CATEGORY_INTERNALSERVER, ADDDEVICE_PREPAID_OD_ERROR_CARTADAPTOR_NAMESPACE), HttpStatus.INTERNAL_SERVER_ERROR));
								}
								List<AddDeviceToPrepayODAddDeviceResponse> linesAddDeviceResponse = new ArrayList<>();
								List<AddDeviceToPrepayODAddAccessoriesOutput> linesAddAccessoriesOutput = new ArrayList<>();
								AddDeviceToPrepayODBpmResponse finalAddDevicePrepayResponse = new AddDeviceToPrepayODBpmResponse();
								AddDeviceToPrepayODServiceBody finalServiceBody = new AddDeviceToPrepayODServiceBody();
								AddDeviceContext context = new AddDeviceContext();
								CartServiceContextInfo contextInfo = new CartServiceContextInfo();
								AddDeviceToPrepayODServiceResponse finalServiceResponse = new AddDeviceToPrepayODServiceResponse();
								AddDeviceToPrepayODAddAccessoriesResponse finalAccessoriesResponse = new AddDeviceToPrepayODAddAccessoriesResponse();

								return lineItem1.flatMap(line1ResponseEntity -> {
									if (line1ResponseEntity.getStatusCode().is2xxSuccessful()) {
										AddDeviceToPrepayODBpmResponse line1Response = line1ResponseEntity.getBody();
										if (Objects.nonNull(line1Response.getErrors()) ) {
											// set error response to the PrepaidODAddDevicesResponse
											linesAddDeviceResponse.add(prepareErrorToAddDevicePrepayODResponse());
										} else {
											if (Objects.nonNull(line1Response) && Objects.nonNull(line1Response.getServiceBody())
													&& Objects.nonNull(line1Response.getServiceBody().getServiceResponse())
													&& CollectionUtilities.isNotEmptyOrNull(line1Response.getServiceBody().getServiceResponse().getPrepaidODAddDevicesResponse())) {
												linesAddDeviceResponse.add(line1Response.getServiceBody().getServiceResponse().getPrepaidODAddDevicesResponse().get(0));

												if (Objects.nonNull(line1Response) && Objects.nonNull(line1Response.getServiceBody())
														&& Objects.nonNull(line1Response.getServiceBody().getServiceResponse())
														&& Objects.nonNull(line1Response.getServiceBody().getServiceResponse().getPrepaidODAddAccessoriesResponse())
														&& CollectionUtilities.isNotEmptyOrNull(line1Response.getServiceBody().getServiceResponse().getPrepaidODAddAccessoriesResponse().getOutput())) {
													linesAddAccessoriesOutput.addAll(line1Response.getServiceBody().getServiceResponse().getPrepaidODAddAccessoriesResponse().getOutput());
												}
											}
										}
									}
									return lineItem2.flatMap(line2ResponseEntity -> {
										if (line2ResponseEntity.getStatusCode().is2xxSuccessful()) {
											AddDeviceToPrepayODBpmResponse line2Response = line2ResponseEntity.getBody();
											if (Objects.nonNull(line2Response.getErrors())) {
												// set error response to the PrepaidODAddDevicesResponse
												linesAddDeviceResponse.add(prepareErrorToAddDevicePrepayODResponse());
											} else {
												if (Objects.nonNull(line2Response) && Objects.nonNull(line2Response.getServiceBody())
														&& Objects.nonNull(line2Response.getServiceBody().getServiceResponse())
														&& CollectionUtilities.isNotEmptyOrNull(line2Response.getServiceBody().getServiceResponse().getPrepaidODAddDevicesResponse())) {
													linesAddDeviceResponse.add(line2Response.getServiceBody().getServiceResponse().getPrepaidODAddDevicesResponse().get(0));

													if (Objects.nonNull(line2Response) && Objects.nonNull(line2Response.getServiceBody())
															&& Objects.nonNull(line2Response.getServiceBody().getServiceResponse())
															&& Objects.nonNull(line2Response.getServiceBody().getServiceResponse().getPrepaidODAddAccessoriesResponse())
															&& CollectionUtilities.isNotEmptyOrNull(line2Response.getServiceBody().getServiceResponse().getPrepaidODAddAccessoriesResponse().getOutput())) {
														linesAddAccessoriesOutput.addAll(line2Response.getServiceBody().getServiceResponse().getPrepaidODAddAccessoriesResponse().getOutput());
													}
												}
											}
										}
										populateAddDevicePrepayResponse(prepaidODRequestData, linesAddDeviceResponse, linesAddAccessoriesOutput, finalAddDevicePrepayResponse, finalServiceBody, context, contextInfo, finalServiceResponse, finalAccessoriesResponse,true);
										return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(finalAddDevicePrepayResponse, HttpStatus.OK));
									});  // line 2
								}); // line 1
							} else {
								Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> lineItem1 = lineMonosMap.get(CollectionUtilities.isNotEmptyOrNull(mtnList)?mtnList.get(0):PREPAY_MTN_NEWLINE_PREFIX+"1");
								if(Objects.isNull(lineItem1)) {
									logger.error("Rare error happened as addDeviceresponse for one of the multiline order is null");
									return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(prepareAddDevicePrepayODBpmResponseWithInternalError("500", "Multiline invalid Scneario", ADDDEVICE_PREPAID_OD_ERROR_CATEGORY_INTERNALSERVER, ADDDEVICE_PREPAID_OD_ERROR_CARTADAPTOR_NAMESPACE), HttpStatus.INTERNAL_SERVER_ERROR));
								}

								return lineItem1.flatMap(line1ResponseEntity -> {
									if (line1ResponseEntity.getStatusCode().is2xxSuccessful()) {
										AddDeviceToPrepayODBpmResponse line1Response = line1ResponseEntity.getBody();
										if (Objects.nonNull(line1Response.getErrors()) ) {
											// set error response to the PrepaidODAddDevicesResponse
											AddDeviceToPrepayODServiceBody tServiceBody = new AddDeviceToPrepayODServiceBody();
											AddDeviceContext tContext = new AddDeviceContext();
											CartServiceContextInfo tContextInfo = new CartServiceContextInfo();
											AddDeviceToPrepayODServiceResponse tServiceResponse = new AddDeviceToPrepayODServiceResponse();
											List<AddDeviceToPrepayODAddDeviceResponse> tAddDevicePrepayList = new ArrayList<>();
											tAddDevicePrepayList.add(prepareErrorToAddDevicePrepayODResponse());
											line1Response.setErrors(null);
											populateAddDevicePrepayResponse(prepaidODRequestData, tAddDevicePrepayList, null, line1Response, tServiceBody, tContext, tContextInfo, tServiceResponse, null,false);

										} else {
											CartServiceContextInfo tContextInfo = new CartServiceContextInfo();

											if(prepaidAccountOwnerSelectionFlag && CollectionUtils.size(prepaidODRequestData.getLines())>1){

												if(prepaidODRequestData.isLoggedIn()) {
													tContextInfo.setProcessStep(ASSIGN_NUMBERS_PROCESS_STEP);
												} else {
													tContextInfo.setProcessStep(ACCOUNT_OWNER_PROCESS_STEP);
												}
											} else {
												if(prepaidODRequestData.isLoggedIn()) {
													tContextInfo.setProcessStep(ASSIGN_NUMBERS_PROCESS_STEP);
												} else {
													tContextInfo.setProcessStep(CHECKOUT_PLAN_PROCESS_STEP);
												}
											}
											line1Response.getServiceBody().getServiceResponse().getContext().setContextInfo(tContextInfo);
										}
										return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(line1Response, HttpStatus.OK));
									}
									return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(new AddDeviceToPrepayODBpmResponse(), HttpStatus.INTERNAL_SERVER_ERROR));
								});
								//return lineMonos.get(0);
							}
						}
					}catch (JsonProcessingException ex){
						logger.error("Failed to convert response received from PrepaidOD AddDevice", ex);
						return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(prepareAddDevicePrepayODBpmResponseWithInternalError("500", "Internal Server Error- JSON processing error during MultiLine processing", ADDDEVICE_PREPAID_OD_ERROR_CATEGORY_INTERNALSERVER, ADDDEVICE_PREPAID_OD_ERROR_CARTADAPTOR_NAMESPACE), HttpStatus.INTERNAL_SERVER_ERROR));
					}
				});
	}

	private void populateAddDevicePrepayResponse(PrepaidODRequestData prepaidODRequestData, List<AddDeviceToPrepayODAddDeviceResponse> linesAddDeviceResponse, List<AddDeviceToPrepayODAddAccessoriesOutput> linesAddAccessoriesOutput, AddDeviceToPrepayODBpmResponse finalAddDevicePrepayResponse, AddDeviceToPrepayODServiceBody finalServiceBody, AddDeviceContext context, CartServiceContextInfo contextInfo, AddDeviceToPrepayODServiceResponse finalServiceResponse, AddDeviceToPrepayODAddAccessoriesResponse finalAccessoriesResponse,boolean isSuccess) {

		if(CollectionUtilities.isNotEmptyOrNull(linesAddDeviceResponse)) {
			finalServiceResponse.setPrepaidODAddDevicesResponse(linesAddDeviceResponse);
		}
		if(CollectionUtilities.isNotEmptyOrNull(linesAddAccessoriesOutput)) {
			finalAccessoriesResponse.setOutput(linesAddAccessoriesOutput);
		}
		finalServiceResponse.setPrepaidODAddAccessoriesResponse(finalAccessoriesResponse);

		if(prepaidODRequestData.isLoggedIn()) {
			contextInfo.setProcessStep(ASSIGN_NUMBERS_PROCESS_STEP);
		} else if(prepaidAccountOwnerSelectionFlag && CollectionUtils.size(prepaidODRequestData.getLines())>1) {
			contextInfo.setProcessStep(ACCOUNT_OWNER_PROCESS_STEP);
		} else if(prepaidAccountOwnerSelectionFlag && CollectionUtils.size(prepaidODRequestData.getLines())==1 && isSuccess) {
			contextInfo.setProcessStep(CHECKOUT_PLAN_PROCESS_STEP);
		} else if(prepaidAccountOwnerSelectionFlag && CollectionUtils.size(prepaidODRequestData.getLines())<=1 && isSuccess==false) {
			contextInfo.setProcessStep(ADD_DEVICE_PREPAY_PROCESS_STEP);
		} else {
			contextInfo.setProcessStep(CHECKOUT_PLAN_PROCESS_STEP);
		}

		context.setContextInfo(contextInfo);
		finalServiceResponse.setContext(context);
		finalServiceBody.setServiceResponse(finalServiceResponse);
		finalAddDevicePrepayResponse.setServiceBody(finalServiceBody);
	}

/*
	public Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> addDeviceToPrepayODMultiLine2(ServerHttpRequest httpRequest, AddDeviceToPrepayODBpmRequest addDeviceToPrepayODBpmRequest) {
		logger.debug(" add-device-prepay adaptor Request: {}",  addDeviceToPrepayODBpmRequest);
		return prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)
				.doOnError(err -> logger.error("Failed to read PrepaidODRequestData from Redis, error: {}", err))
				.flatMap(response -> {
					logger.info("PrepaidODRequestData From Redis:: {} ", response);
					try {
						if (StringUtilities.isEmptyOrNull(response)) {
							logger.error("PrepaidODRequestData from Redis is empty {}", response);
							return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(prepareAddDevicePrepayODBpmResponseWithInternalError("500", "PrepaidODRequestData from Redis is empty", ADDDEVICE_PREPAID_OD_ERROR_CATEGORY_INTERNALSERVER, ADDDEVICE_PREPAID_OD_ERROR_CARTADAPTOR_NAMESPACE), HttpStatus.INTERNAL_SERVER_ERROR));
						} else {
							PrepaidODRequestData prepaidODRequestData = mapper.readValue(response, PrepaidODRequestData.class);
							if (null == prepaidODRequestData || 0 == CollectionUtils.size(prepaidODRequestData.getLines())) {
								return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(prepareAddDevicePrepayODBpmResponseWithInternalError("500", "No Devices to process in Redis", ADDDEVICE_PREPAID_OD_ERROR_CATEGORY_INTERNALSERVER, ADDDEVICE_PREPAID_OD_ERROR_CARTADAPTOR_NAMESPACE), HttpStatus.INTERNAL_SERVER_ERROR));
							}
							List<PrepaidODRequestDataLines> linesToProcess = prepaidODRequestData.getLines().stream().filter(line -> line.isCheckoutFlag() == false).collect(Collectors.toList());
							if(null == linesToProcess || 0== linesToProcess.size()){
								return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(prepareAddDevicePrepayODBpmResponseWithInternalError("200", "No Devices to process with checkoutflag as false", ADDDEVICE_PREPAID_OD_ERROR_CATEGORY_INTERNALSERVER, ADDDEVICE_PREPAID_OD_ERROR_CARTADAPTOR_NAMESPACE), HttpStatus.OK));
							}
							boolean loggedIn =prepaidODRequestData.isLoggedIn();
							List<Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>>> lineMonos = new ArrayList<>();
							Map<String, Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>>> lineMonosMap = new HashMap<>();
							linesToProcess.forEach(lineToProcess -> {

								Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> lineMono = getLineDeviceAndAccessoryMono(lineToProcess, addDeviceToPrepayODBpmRequest, prepaidODRequestData, httpRequest, loggedIn);
								lineMonos.add(lineMono);
								logger.info("AddDevice Lines Processed: {}",lineMonos.size());
								lineMonosMap.put(lineToProcess.getMtn(), lineMono);
								logger.info("AddDevice Lines Processed after aputting to lineMonosMap: {}",lineMonosMap.size());
							});

							//At max only two devices can be with checkoutflag=false
							if(2 == CollectionUtils.size(lineMonosMap)){
								Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> lineItem1 = lineMonosMap.get(PREPAY_MTN_NEWLINE_PREFIX+"1");
								Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> lineItem2 = lineMonosMap.get(PREPAY_MTN_NEWLINE_PREFIX+"2");
								//Following should never happened because both lineitem1 and lineitem2 should exists
								if(null == lineItem1 || null == lineItem2) return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(prepareAddDevicePrepayODBpmResponseWithInternalError("500", "Multiline invalid Scneario", ADDDEVICE_PREPAID_OD_ERROR_CATEGORY_INTERNALSERVER, ADDDEVICE_PREPAID_OD_ERROR_CARTADAPTOR_NAMESPACE), HttpStatus.INTERNAL_SERVER_ERROR));
								return lineItem1.flatMap(line1ResponseEntity -> {
									if (line1ResponseEntity.getStatusCode().is2xxSuccessful()) {
										return lineItem2.flatMap(line2ResponseEntity->{
											if (line2ResponseEntity.getStatusCode().is2xxSuccessful()) {
												//Aggregate both lines responses--
												AddDeviceToPrepayODBpmResponse line1Response = line1ResponseEntity.getBody();
												AddDeviceToPrepayODBpmResponse line2Response = line2ResponseEntity.getBody();
												if(null!=line1Response && null!=line2Response){
													//adding devices
													List<AddDeviceToPrepayODAddDeviceResponse> line2AddDeviceResponse = Optional.ofNullable(line2Response)
															.map(AddDeviceToPrepayODBpmResponse::getServiceBody)
															.map(AddDeviceToPrepayODServiceBody::getServiceResponse)
															.map(AddDeviceToPrepayODServiceResponse::getPrepaidODAddDevicesResponse)
															.orElse(new ArrayList<>());
													List<AddDeviceToPrepayODAddDeviceResponse> line1AddDeviceResponse = Optional.ofNullable(line1Response)
															.map(AddDeviceToPrepayODBpmResponse::getServiceBody)
															.map(AddDeviceToPrepayODServiceBody::getServiceResponse)
															.map(AddDeviceToPrepayODServiceResponse::getPrepaidODAddDevicesResponse)
															.orElse(new ArrayList<>());
													line1AddDeviceResponse.addAll(line2AddDeviceResponse);

													//accessories
													//AddDeviceToPrepayODAddAccessoriesOutput
													List<AddDeviceToPrepayODAddAccessoriesOutput> line2AccessoriesOutput = Optional.ofNullable(line2Response)
															.map(resp->resp.getServiceBody())
															.map(AddDeviceToPrepayODServiceBody::getServiceResponse)
															.map(AddDeviceToPrepayODServiceResponse::getPrepaidODAddAccessoriesResponse)
															.map(AddDeviceToPrepayODAddAccessoriesResponse::getOutput)
															.orElse(new ArrayList<AddDeviceToPrepayODAddAccessoriesOutput>() );
													List<AddDeviceToPrepayODAddAccessoriesOutput> line1AccessoriesOutput = Optional.ofNullable(line1Response)
															.map(AddDeviceToPrepayODBpmResponse::getServiceBody)
															.map(AddDeviceToPrepayODServiceBody::getServiceResponse)
															.map(AddDeviceToPrepayODServiceResponse::getPrepaidODAddAccessoriesResponse)
															.map(AddDeviceToPrepayODAddAccessoriesResponse::getOutput)
															.orElse(new ArrayList<AddDeviceToPrepayODAddAccessoriesOutput>() );
													line1AccessoriesOutput.addAll(line2AccessoriesOutput);

													//errorMap
													Map<String, String> line2AccessoriesErrorMap = Optional.ofNullable(line2Response)
															.map(AddDeviceToPrepayODBpmResponse::getServiceBody)
															.map(AddDeviceToPrepayODServiceBody::getServiceResponse)
															.map(AddDeviceToPrepayODServiceResponse::getPrepaidODAddAccessoriesResponse)
															.map(AddDeviceToPrepayODAddAccessoriesResponse::getErrorMap)
															.orElse(new HashMap<String, String>() );
													Map<String, String> line1AccessoriesErrorMap = Optional.ofNullable(line1Response)
															.map(AddDeviceToPrepayODBpmResponse::getServiceBody)
															.map(AddDeviceToPrepayODServiceBody::getServiceResponse)
															.map(AddDeviceToPrepayODServiceResponse::getPrepaidODAddAccessoriesResponse)
															.map(AddDeviceToPrepayODAddAccessoriesResponse::getErrorMap)
															.orElse(new HashMap<String, String>() );
													line1AccessoriesErrorMap.putAll(line1AccessoriesErrorMap);
													//set the acessorystatus message combination
													boolean accErrMapNotEmpty = Optional.ofNullable(line1Response)
															.map(AddDeviceToPrepayODBpmResponse::getServiceBody)
															.map(AddDeviceToPrepayODServiceBody::getServiceResponse)
															.map(AddDeviceToPrepayODServiceResponse::getPrepaidODAddAccessoriesResponse)
															.map(AddDeviceToPrepayODAddAccessoriesResponse::getErrorMap)
															.map(errMap->errMap.size()>0).orElse(false);
												}
												if(Objects.isNull(line1ResponseEntity.getBody().getServiceBody().getServiceResponse().getContext())) line1ResponseEntity.getBody().getServiceBody().getServiceResponse().setContext(new AddDeviceContext());
												if(Objects.isNull(line1ResponseEntity.getBody().getServiceBody().getServiceResponse().getContext().getContextInfo())) line1ResponseEntity.getBody().getServiceBody().getServiceResponse().getContext().setContextInfo(new CartServiceContextInfo());
												line1ResponseEntity.getBody().getServiceBody().getServiceResponse().setContext(getResponseContext(line1ResponseEntity.getBody().getServiceBody().getServiceResponse().getContext(), prepaidODRequestData));
												if(prepaidAccountOwnerSelectionFlag && CollectionUtils.size(prepaidODRequestData.getLines())>1){
													if(prepaidODRequestData.isLoggedIn()) {
														line1ResponseEntity.getBody().getServiceBody().getServiceResponse().getContext().getContextInfo().setProcessStep(ASSIGN_NUMBERS_PROCESS_STEP);
													}else {
														line1ResponseEntity.getBody().getServiceBody().getServiceResponse().getContext().getContextInfo().setProcessStep(ACCOUNT_OWNER_PROCESS_STEP);
													}

												}
												return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(line1ResponseEntity.getBody(), HttpStatus.OK));
											}else{
												logger.error("AddDevice Prepay - Error calling adddevice for second line {}", line2ResponseEntity);
												//call remove line for first line
												PrepaidODRequestDataLines lineToRemove = prepaidODRequestData.getLines().stream().filter(line -> (PREPAY_MTN_NEWLINE_PREFIX+"1").equals(line.getMtn())).findFirst().orElse(null);
												if(null!=lineToRemove && null != lineToRemove.getDeviceId()){
													RemoveLineItemsRequest removeLineItemsRequest = new RemoveLineItemsRequest();
													removeLineItemsRequest.setLineItemId(lineToRemove.getDeviceId());
													PrepaidAdaptorWebClientRequest prepaidODRemoveLineLegacyServiceRequest = getPrepaidRemoveLineLegacyServiceRequest(removeLineItemsRequest, prepaidODRequestData);
													logger.info("Remove Device OD call Request Endpoint: {} \n Request Body: {} \n Request Headers: {}",prepaidODRemoveLineLegacyServiceRequest.getUrl(), prepaidODRemoveLineLegacyServiceRequest.getRequestBody(), prepaidODRemoveLineLegacyServiceRequest.getHeader());

													return prepayAdaptorWebClient.getPrepayServiceResponse(httpRequest, prepaidODRemoveLineLegacyServiceRequest)
															.doOnError(error -> logger.error("Failed to get response for prepaidOD AddDevicePrepay-RemoveLines service, error:", error))
															.flatMap(removeLineItemResponseEntity -> {
																if (!removeLineItemResponseEntity.getStatusCode().is2xxSuccessful()) {
																	logger.error("Error while calling prepaidOD AddDevicePrepay-Removeline Service, status code: {}", removeLineItemResponseEntity.getStatusCode());
																	//return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(new AddDeviceToPrepayODBpmResponse(), accessoryResponseEntity.getStatusCode()));
																	// commenting following 2 lines as we should not remove EcommSesson and pcsrftoken
																	//prepaidODRequestData.setEcommSessionId(null);
																	//prepaidODRequestData.setPCsrfToken(null);
																}
																logger.info("Clear data in redis ");
																prepaidODRequestData.setLines(null);
																prepaidODRequestData.setCurr_line(0);
																prepaidODRequestData.setNumberAssignedToAllLines(false);
																prepaidODRequestData.setTotalNumAssignedLines(0);
																return prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, prepaidODRequestData)
																		.doOnError(err -> logger.error("Failed to update the PrepaidODRequestData to Redis in PrepaidODAddDevice", err))
																		.flatMap(upsertResp -> {
																			logger.info("Successfully upserted PrepaidODRequestData to Redis:: {} ", upsertResp);
																			//Construct response indicating the second AddDevice call failed
																			return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(line2ResponseEntity.getBody(), HttpStatus.OK));
																		});
															});
												}
												return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(prepareAddDevicePrepayODBpmResponseWithInternalError("500", "Unexpected Error during MultiLine processing", ADDDEVICE_PREPAID_OD_ERROR_CATEGORY_INTERNALSERVER, ADDDEVICE_PREPAID_OD_ERROR_CARTADAPTOR_NAMESPACE), HttpStatus.INTERNAL_SERVER_ERROR));
											}
										});
									}else{
										logger.error("AddDevice Prepay - Error calling adddevice for first line {}", line1ResponseEntity);
										return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(prepareAddDevicePrepayODBpmResponseWithInternalError(String.valueOf(line1ResponseEntity.getStatusCode()), "MultilineProcess: Error while getting response from PrepayOD-AddDevice call for first device", PREPAID_OD_INTERNAL_SERVER_ERROR, ADDDEVICE_PREPAID_OD_ERROR_NAMESPACE), HttpStatus.INTERNAL_SERVER_ERROR));
									}
								});
							} else {
								return lineMonos.get(0);
							}
						}
					}catch (JsonProcessingException ex){
						logger.error("Failed to convert response received from PrepaidOD AddDevice", ex);
						return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(prepareAddDevicePrepayODBpmResponseWithInternalError("500", "Internal Server Error- JSON processing error during MultiLine processing", ADDDEVICE_PREPAID_OD_ERROR_CATEGORY_INTERNALSERVER, ADDDEVICE_PREPAID_OD_ERROR_CARTADAPTOR_NAMESPACE), HttpStatus.INTERNAL_SERVER_ERROR));
					}
				});
	}
*/
	private Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> getLineDeviceAndAccessoryMono(PrepaidODRequestDataLines currLineToProcess, AddDeviceToPrepayODBpmRequest addDeviceToPrepayODBpmRequest
			, PrepaidODRequestData prepaidODRequestData, ServerHttpRequest httpRequest){
		logger.info("Current Line to Process: {}",currLineToProcess.getMtn());
		PrepaidODAddDeviceRequest prepaidODAddDeviceRequest = getPrepayODAddDeviceRequest(currLineToProcess, addDeviceToPrepayODBpmRequest);
		PrepaidAdaptorWebClientRequest prepaidODAddDeviceLegacyServiceRequest = getPrepaidAddDeviceLegacyServiceRequest(prepaidODAddDeviceRequest, prepaidODRequestData);
		logger.info("GetLineDeviceAccessoryMono: PrepayODAddDevice-Request Endpoint: {} \n Request Body: {} \n Request Headers: {}",prepaidODAddDeviceLegacyServiceRequest.getUrl(), prepaidODAddDeviceLegacyServiceRequest.getRequestBody(), prepaidODAddDeviceLegacyServiceRequest.getHeader());
		
		return prepayAdaptorWebClient.getPrepayServiceResponse(httpRequest, prepaidODAddDeviceLegacyServiceRequest)
				.doOnError(error -> logger.error("PrepayODAddDevice-Failed to get response for prepaidOD AddDevice service, error:", error))
				.flatMap(responseEntity -> {

					if (!responseEntity.getStatusCode().is2xxSuccessful()) {
						logger.error("PrepayODAddDevice-Error while calling endpoint: {} with status code: {}", prepaidODAddDeviceLegacyServiceRequest.getUrl(), responseEntity.getStatusCode());
						AddDeviceToPrepayODBpmResponse addDeviceToPrepayODBpmResponseError = prepareAddDevicePrepayODBpmResponseWithInternalError(String.valueOf(responseEntity.getStatusCode()), "MultilineProcess: Error while getting response from PrepayOD-AddDevice call for first device", PREPAID_OD_INTERNAL_SERVER_ERROR, ADDDEVICE_PREPAID_OD_ERROR_NAMESPACE);
						//Add Device error response need to set
						return removeLineFromRedis(prepaidODRequestData,currLineToProcess,addDeviceToPrepayODBpmResponseError);
						//return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(addDeviceToPrepayODBpmResponseError, responseEntity.getStatusCode()));
					}
					//get the output
					VZWPrepayAddOrUpdateCartResponse addDevicePrepayODResponse = null;

					try {
						addDevicePrepayODResponse = mapper.readValue(responseEntity.getBody(), VZWPrepayAddOrUpdateCartResponse.class);
						logger.info("GetLineDeviceAccessoryMono: Add Device OD service response : {}", mapper.writeValueAsString(addDevicePrepayODResponse));

						if (200 != addDevicePrepayODResponse.getStatus()) {
							logger.error("Error while calling endpoint: {} with status code: {}", prepaidODAddDeviceLegacyServiceRequest.getUrl(), responseEntity.getStatusCode());
							// remove line from Redis
							return removeLineFromRedis(prepaidODRequestData,currLineToProcess,prepareAddDevicePrepayODBpmResponseWithError(addDevicePrepayODResponse));
							//return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(prepareAddDevicePrepayODBpmResponseWithError(addDevicePrepayODResponse), HttpStatus.OK));
						}
					} catch (JsonProcessingException e) {
						logger.error("GetLineDeviceAccessoryMono: Failed to convert response received from PrepaidOD AddDevice", e);
						// remove line from Redis
						return removeLineFromRedis(prepaidODRequestData,currLineToProcess,prepareAddDevicePrepayODBpmResponseWithInternalError("500", "Internal Server Error- JSON processing error during adddevice processing", ADDDEVICE_PREPAID_OD_ERROR_CATEGORY_INTERNALSERVER, ADDDEVICE_PREPAID_OD_ERROR_CARTADAPTOR_NAMESPACE));
						//return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(prepareAddDevicePrepayODBpmResponseWithInternalError("500", "Internal Server Error- JSON processing error during adddevice processing", ADDDEVICE_PREPAID_OD_ERROR_CATEGORY_INTERNALSERVER, ADDDEVICE_PREPAID_OD_ERROR_CARTADAPTOR_NAMESPACE), HttpStatus.INTERNAL_SERVER_ERROR));
					}
					final String addDeviceLineItemId = addDevicePrepayODResponse.getDevCommerceId();

					if( 0 < CollectionUtils.size(currLineToProcess.getAccessorySkuIds())) {
						
						return processAccessories(currLineToProcess, prepaidODRequestData, httpRequest, addDevicePrepayODResponse, addDeviceLineItemId);
					
					} else {
						int index = prepaidODRequestData.getLines().indexOf(currLineToProcess);
						currLineToProcess.setCheckoutFlag(true);
						currLineToProcess.setLineItemId(addDeviceLineItemId);
						logger.info("Dev Commerce ID for {} is {}::  ",currLineToProcess.getMtn(), addDeviceLineItemId);
						prepaidODRequestData.getLines().set(index,currLineToProcess);

						AddDeviceToPrepayODAddDeviceResponse addDeviceToPrepayODAddDeviceResponse = new AddDeviceToPrepayODAddDeviceResponse();
						//setting deviceResponse
						BeanUtils.copyProperties(addDevicePrepayODResponse, addDeviceToPrepayODAddDeviceResponse);
						return updateRedisData(prepaidODRequestData, addDeviceToPrepayODAddDeviceResponse, null);
					}
				});
	}

	private Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> updateRedisData(PrepaidODRequestData prepaidODRequestData, AddDeviceToPrepayODAddDeviceResponse addDeviceToPrepayODAddDeviceResponse, AddDeviceToPrepayODAddAccessoriesResponse addDeviceToPrepayODAddAccessoriesResponse) {
		return prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, prepaidODRequestData)
				.doOnError(err -> logger.error("Failed to update the PrepaidODRequestData to Redis in PrepaidODAddDevice", err))
				.flatMap(upsertResp -> {
					logger.info("Successfully upserted PrepaidODRequestData to Redis:: {} ", upsertResp);
					AddDeviceToPrepayODBpmResponse addDeviceToPrepayODBpmResponse = prepayAddDevicePrepayODBpmResponse(addDeviceToPrepayODAddDeviceResponse, addDeviceToPrepayODAddAccessoriesResponse);
				/*	addDeviceToPrepayODBpmResponse.getServiceBody().getServiceResponse().setContext(getResponseContext(addDeviceToPrepayODBpmResponse.getServiceBody().getServiceResponse().getContext(), prepaidODRequestData));

					if (prepaidAccountOwnerSelectionFlag && CollectionUtils.size(prepaidODRequestData.getLines()) > 1) {
						if (prepaidODRequestData.isLoggedIn()) {
							addDeviceToPrepayODBpmResponse.getServiceBody().getServiceResponse().getContext().getContextInfo().setProcessStep(ASSIGN_NUMBERS_PROCESS_STEP);
						} else {
							addDeviceToPrepayODBpmResponse.getServiceBody().getServiceResponse().getContext().getContextInfo().setProcessStep(ACCOUNT_OWNER_PROCESS_STEP);
						}
					}*/
					return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(addDeviceToPrepayODBpmResponse, HttpStatus.OK));
				});
	}

	private Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> processAccessories(PrepaidODRequestDataLines currLineToProcess, PrepaidODRequestData prepaidODRequestData, ServerHttpRequest httpRequest, VZWPrepayAddOrUpdateCartResponse addDevicePrepayODResponse, String addDeviceLineItemId) {
		PrepaidODAddAccessoriesRequest prepaidODAddAccessoriesRequest = new PrepaidODAddAccessoriesRequest();
		List<PrepaidODAccessory> accessoryList = getAccessoriesList(currLineToProcess, addDevicePrepayODResponse);
		prepaidODAddAccessoriesRequest.setAccessories(accessoryList);
		PrepaidAdaptorWebClientRequest prepaidODAddAccessoriesLegacyServiceRequest = getPrepaidAddAccessoriesLegacyServiceRequest(prepaidODAddAccessoriesRequest, prepaidODRequestData);
		logger.info("GetLineDeviceAccessoryMono: Add Accessory OD call Request Endpoint: {} \n Request Body: {} \n Request Headers: {}",prepaidODAddAccessoriesLegacyServiceRequest.getUrl(), prepaidODAddAccessoriesLegacyServiceRequest.getRequestBody(), prepaidODAddAccessoriesLegacyServiceRequest.getHeader());

		return prepayAdaptorWebClient.getPrepayServiceResponse(httpRequest, prepaidODAddAccessoriesLegacyServiceRequest)
				.doOnError(error -> logger.error("GetLineDeviceAccessoryMono: Failed to get response for prepaidOD AddAccessory service, error:", error))
				.flatMap(accessoryResponseEntity -> {
					if (!accessoryResponseEntity.getStatusCode().is2xxSuccessful()) {
						logger.error("GetLineDeviceAccessoryMono: Error while calling prepaidOD AddAccessory Service, status code: {}", accessoryResponseEntity.getStatusCode());
						AddDeviceToPrepayODBpmResponse addAccessoriesToPrepayODError = prepareAddDevicePrepayODBpmResponseWithInternalError(String.valueOf(accessoryResponseEntity.getStatusCode()), "MultilineProcess: Error while getting response from PrepayOD-AddAccessory", PREPAID_OD_INTERNAL_SERVER_ERROR, ADDDEVICE_PREPAID_OD_ERROR_NAMESPACE);
						return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(addAccessoriesToPrepayODError, accessoryResponseEntity.getStatusCode()));
					}
					PrepaidODAddAccessoriesResponse addAccessoriesResponse = null;
					try {
						addAccessoriesResponse = mapper.readValue(accessoryResponseEntity.getBody(), PrepaidODAddAccessoriesResponse.class);
						logger.info("GetLineDeviceAccessoryMono: Add Accessory OD service response : {}", mapper.writeValueAsString(addAccessoriesResponse));
					} catch (JsonProcessingException e) {
						logger.error("Failed to convert response received from PrepaidOD AddAccessories", e);
						return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(prepareAddDevicePrepayODBpmResponseWithInternalError("500", "Internal Server Error- JSON processing error during addAccessories processing", ADDDEVICE_PREPAID_OD_ERROR_CATEGORY_INTERNALSERVER, ADDDEVICE_PREPAID_OD_ERROR_CARTADAPTOR_NAMESPACE), HttpStatus.INTERNAL_SERVER_ERROR));
					}
					int index = prepaidODRequestData.getLines().indexOf(currLineToProcess);
					currLineToProcess.setCheckoutFlag(true);
					currLineToProcess.setLineItemId(addDeviceLineItemId);
					logger.info("Dev Commerce ID for {} is {}::  ", currLineToProcess.getMtn(), addDeviceLineItemId);
					prepaidODRequestData.getLines().set(index, currLineToProcess);

					if (null != addAccessoriesResponse) {
						Optional.ofNullable(addAccessoriesResponse.getOutput()).orElse(new ArrayList<>()).stream().forEach(accessoryResponse ->
								Optional.ofNullable(currLineToProcess.getAccessorySkuIds()).orElse(new ArrayList<>())
										.stream()
										.filter(redisAcc -> redisAcc.getSorId().equals(accessoryResponse.getSorId()) && StringUtilities.isEmptyOrNull(redisAcc.getAccessoryCommerceId()))
										.findFirst().ifPresent(redisAccessory -> redisAccessory.setAccessoryCommerceId(accessoryResponse.getAccCommerceId())));
					}
					AddDeviceToPrepayODAddAccessoriesResponse addDeviceToPrepayODAddAccessoriesResponse = new AddDeviceToPrepayODAddAccessoriesResponse();
					AddDeviceToPrepayODAddDeviceResponse addDeviceToPrepayODAddDeviceResponse = new AddDeviceToPrepayODAddDeviceResponse();
					//BeanUtils.copyProperties(addAccessoriesResponse, addDeviceToPrepayODAddAccessoriesResponse);
					if(Objects.nonNull(addAccessoriesResponse)) {
						addDeviceToPrepayODAddAccessoriesResponse.setErrorMap(addAccessoriesResponse.getErrorMap());
						addDeviceToPrepayODAddAccessoriesResponse.setStatusCode(addAccessoriesResponse.getStatusCode());
						addDeviceToPrepayODAddAccessoriesResponse.setStatusMessage(addAccessoriesResponse.getStatusMessage());
						List<AddDeviceToPrepayODAddAccessoriesOutput> deviceToAccessoryList = new ArrayList<>();

						List<PrepaidODAddAccessoriesOutput> accessoryOutput =  addAccessoriesResponse.getOutput();
						if(CollectionUtilities.isNotEmptyOrNull(accessoryOutput)) {

							for(PrepaidODAddAccessoriesOutput accOutput: accessoryOutput) {
								AddDeviceToPrepayODAddAccessoriesOutput devToAccOutput = new AddDeviceToPrepayODAddAccessoriesOutput();
								devToAccOutput.setAccCommerceId(accOutput.getAccCommerceId());
								devToAccOutput.setSorId(accOutput.getSorId());
								devToAccOutput.setOrderId(accOutput.getOrderId());
								devToAccOutput.setItemAdded(true);
								devToAccOutput.setItemRemoved(false);
								deviceToAccessoryList.add(devToAccOutput);
							}
						}
						addDeviceToPrepayODAddAccessoriesResponse.setOutput(deviceToAccessoryList);
					}
					BeanUtils.copyProperties(addDevicePrepayODResponse, addDeviceToPrepayODAddDeviceResponse);

					return updateRedisData(prepaidODRequestData, addDeviceToPrepayODAddDeviceResponse, addDeviceToPrepayODAddAccessoriesResponse);
				});
	}

	private static List<PrepaidODAccessory> getAccessoriesList(PrepaidODRequestDataLines currLineToProcess, VZWPrepayAddOrUpdateCartResponse addDevicePrepayODResponse) {
		List<PrepaidODAccessory> accessoryList = new ArrayList<>();

		for(PrepaidODRequestDataAccessorySkuIds srcAccessory: currLineToProcess.getAccessorySkuIds()){
			PrepaidODAccessory targetAaccessory = new PrepaidODAccessory();
			targetAaccessory.setFlow(currLineToProcess.getFlow());
			targetAaccessory.setAccQty(srcAccessory.getQty());
			targetAaccessory.setAccSkuId(srcAccessory.getSkuId());
			targetAaccessory.setAccSorId(srcAccessory.getSorId());

			if( Objects.nonNull(addDevicePrepayODResponse)) {
				targetAaccessory.setDevCommerceId(addDevicePrepayODResponse.getDevCommerceId());
			}
			targetAaccessory.setAccCategory("");
			targetAaccessory.setAction(PREPAY_OD_ACCESSORY_ADD_ACTION);
			targetAaccessory.setAccessoryBundle(false);
			accessoryList.add(targetAaccessory);
		}
		return accessoryList;
	}
/*
	private Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> getLineDeviceAndAccessoryMono2(PrepaidODRequestDataLines currLineToProcess, AddDeviceToPrepayODBpmRequest addDeviceToPrepayODBpmRequest
			, PrepaidODRequestData prepaidODRequestData, ServerHttpRequest httpRequest, boolean loggedIn){
		logger.info("Current Line to Process: {}",currLineToProcess.getMtn());
		PrepaidODAddDeviceRequest prepaidODAddDeviceRequest = getPrepayODAddDeviceRequest(currLineToProcess, loggedIn);
		PrepaidAdaptorWebClientRequest prepaidODAddDeviceLegacyServiceRequest = getPrepaidAddDeviceLegacyServiceRequest(prepaidODAddDeviceRequest, prepaidODRequestData);
		logger.info("GetLineDeviceAccessoryMono: PrepayODAddDevice-Request Endpoint: {} \n Request Body: {} \n Request Headers: {}",prepaidODAddDeviceLegacyServiceRequest.getUrl(), prepaidODAddDeviceLegacyServiceRequest.getRequestBody(), prepaidODAddDeviceLegacyServiceRequest.getHeader());

		return prepayAdaptorWebClient.getPrepayServiceResponse(httpRequest, prepaidODAddDeviceLegacyServiceRequest)
				.doOnError(error -> logger.error("PrepayODAddDevice-Failed to get response for prepaidOD AddDevice service, error:", error))
				.flatMap(responseEntity -> {
					if (!responseEntity.getStatusCode().is2xxSuccessful()) {
						logger.error("PrepayODAddDevice-Error while calling endpoint: {} with status code: {}", prepaidODAddDeviceLegacyServiceRequest.getUrl(), responseEntity.getStatusCode());
						AddDeviceToPrepayODBpmResponse addDeviceToPrepayODBpmResponseError = prepareAddDevicePrepayODBpmResponseWithInternalError(String.valueOf(responseEntity.getStatusCode()), "MultilineProcess: Error while getting response from PrepayOD-AddDevice call for first device", PREPAID_OD_INTERNAL_SERVER_ERROR, ADDDEVICE_PREPAID_OD_ERROR_NAMESPACE);
						//Add Device error response need to set

						return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(addDeviceToPrepayODBpmResponseError, responseEntity.getStatusCode()));
					}
					//get the output
					VZWPrepayAddOrUpdateCartResponse addDevicePrepayODResponse = null;
					try {
						addDevicePrepayODResponse = mapper.readValue(responseEntity.getBody(), VZWPrepayAddOrUpdateCartResponse.class);
						logger.info("GetLineDeviceAccessoryMono: Add Device OD service response : {}", mapper.writeValueAsString(addDevicePrepayODResponse));
						if (200 != addDevicePrepayODResponse.getStatus()) {
							logger.error("Error while calling endpoint: {} with status code: {}", prepaidODAddDeviceLegacyServiceRequest.getUrl(), responseEntity.getStatusCode());
							return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(prepareAddDevicePrepayODBpmResponseWithError(addDevicePrepayODResponse), HttpStatus.OK));
						}
					} catch (JsonProcessingException e) {
						logger.error("GetLineDeviceAccessoryMono: Failed to convert response received from PrepaidOD AddDevice", e);
						return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(prepareAddDevicePrepayODBpmResponseWithInternalError("500", "Internal Server Error- JSON processing error during adddevice processing", ADDDEVICE_PREPAID_OD_ERROR_CATEGORY_INTERNALSERVER, ADDDEVICE_PREPAID_OD_ERROR_CARTADAPTOR_NAMESPACE), HttpStatus.INTERNAL_SERVER_ERROR));
					}
					final String addDeviceLineItemId = addDevicePrepayODResponse.getDevCommerceId();
					final VZWPrepayAddOrUpdateCartResponse addDevicePrepayODResponseFinalTmp = addDevicePrepayODResponse;
					if( 0 < CollectionUtils.size(currLineToProcess.getAccessorySkuIds())) {
						PrepaidODAddAccessoriesRequest prepaidODAddAccessoriesRequest = new PrepaidODAddAccessoriesRequest();
						List<PrepaidODAccessory> accessoryList = new ArrayList<>();
						for(PrepaidODRequestDataAccessorySkuIds srcAccessory: currLineToProcess.getAccessorySkuIds()){
							PrepaidODAccessory targetAaccessory = new PrepaidODAccessory();
							//targetAaccessory.setFlow(addDeviceToPrepayODBpmRequest.getServiceBody().getServiceRequest().getContext().getFlow());
							//targetAaccessory.setFlow(addDeviceToPrepayODBpmRequest.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
							targetAaccessory.setFlow(Objects.nonNull(currLineToProcess)?currLineToProcess.getFlow():NSE);
							targetAaccessory.setAccQty(srcAccessory.getQty());
							//targetAaccessory.setAccProdId(srcAccessory.get);
							targetAaccessory.setAccSkuId(srcAccessory.getSkuId());
							targetAaccessory.setAccSorId(srcAccessory.getSorId());
							if(null!=addDevicePrepayODResponse) targetAaccessory.setDevCommerceId(addDevicePrepayODResponse.getDevCommerceId());
							targetAaccessory.setAccCategory("");
							targetAaccessory.setAction(PREPAY_OD_ACCESSORY_ADD_ACTION);
							targetAaccessory.setAccessoryBundle(false);
							accessoryList.add(targetAaccessory);
						}
						prepaidODAddAccessoriesRequest.setAccessories(accessoryList);
						PrepaidAdaptorWebClientRequest prepaidODAddAccessoriesLegacyServiceRequest = getPrepaidAddAccessoriesLegacyServiceRequest(prepaidODAddAccessoriesRequest, prepaidODRequestData);
						logger.info("GetLineDeviceAccessoryMono: Add Accessory OD call Request Endpoint: {} \n Request Body: {} \n Request Headers: {}",prepaidODAddAccessoriesLegacyServiceRequest.getUrl(), prepaidODAddAccessoriesLegacyServiceRequest.getRequestBody(), prepaidODAddAccessoriesLegacyServiceRequest.getHeader());
						return prepayAdaptorWebClient.getPrepayServiceResponse(httpRequest, prepaidODAddAccessoriesLegacyServiceRequest)
								.doOnError(error -> logger.error("GetLineDeviceAccessoryMono: Failed to get response for prepaidOD AddAccessory service, error:", error))
								.flatMap(accessoryResponseEntity -> {
									if (!accessoryResponseEntity.getStatusCode().is2xxSuccessful()) {
										logger.error("GetLineDeviceAccessoryMono: Error while calling prepaidOD AddAccessory Service, status code: {}", accessoryResponseEntity.getStatusCode());
										AddDeviceToPrepayODBpmResponse addAccessoriesToPrepayODError = prepareAddDevicePrepayODBpmResponseWithInternalError(String.valueOf(accessoryResponseEntity.getStatusCode()), "MultilineProcess: Error while getting response from PrepayOD-AddAccessory", PREPAID_OD_INTERNAL_SERVER_ERROR, ADDDEVICE_PREPAID_OD_ERROR_NAMESPACE);
										return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(addAccessoriesToPrepayODError, accessoryResponseEntity.getStatusCode()));
									}
									PrepaidODAddAccessoriesResponse addAccessoriesResponse = null;
									try {
										addAccessoriesResponse = mapper.readValue(accessoryResponseEntity.getBody(), PrepaidODAddAccessoriesResponse.class);
										logger.info("GetLineDeviceAccessoryMono: Add Accessory OD service response : {}", mapper.writeValueAsString(addAccessoriesResponse));
									} catch (JsonProcessingException e) {
										logger.error("Failed to convert response received from PrepaidOD AddAccessories", e);
										return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(prepareAddDevicePrepayODBpmResponseWithInternalError("500", "Internal Server Error- JSON processing error during addAccessories processing", ADDDEVICE_PREPAID_OD_ERROR_CATEGORY_INTERNALSERVER, ADDDEVICE_PREPAID_OD_ERROR_CARTADAPTOR_NAMESPACE), HttpStatus.INTERNAL_SERVER_ERROR));
									}
									int index = prepaidODRequestData.getLines().indexOf(currLineToProcess);
									currLineToProcess.setCheckoutFlag(true);
									currLineToProcess.setLineItemId(addDeviceLineItemId);
									logger.info("Dev Commerce ID for {} is {}::  ",currLineToProcess.getMtn(), addDeviceLineItemId);
									if(null!= addAccessoriesResponse) {
										Optional.ofNullable(addAccessoriesResponse.getOutput()).orElse(new ArrayList<PrepaidODAddAccessoriesOutput>()).stream().forEach(accessoryResponse->
												Optional.ofNullable(currLineToProcess.getAccessorySkuIds()).orElse(new ArrayList<>())
														.stream()
														.filter(redisAcc->redisAcc.getSorId().equals(accessoryResponse.getSorId()) && StringUtilities.isEmptyOrNull(redisAcc.getAccessoryCommerceId()))
														.findFirst().ifPresent(redisAccessory->redisAccessory.setAccessoryCommerceId(accessoryResponse.getAccCommerceId())));
//Commented Start to display out of stock message in getCheckoutDetails
										//if there are failures, remove it from redis
//										if(CollectionUtils.size(addAccessoriesResponse.getErrorMap())>0){
//											Map<String, String> accessoriesErrorMap = Optional.ofNullable(addAccessoriesResponse.getErrorMap()).orElse(new HashMap<String, String>());
//											List<PrepaidODRequestDataAccessorySkuIds> accessoriesToRemoveFromRedis = Optional.ofNullable(currLineToProcess.getAccessorySkuIds()).orElse(new ArrayList<PrepaidODRequestDataAccessorySkuIds>())
//													.stream()
//													.filter(redisAcc->accessoriesErrorMap.keySet().contains(redisAcc.getSorId()))
////													.collect(Collectors.toList());
//											currLineToProcess.getAccessorySkuIds().removeAll(accessoriesToRemoveFromRedis);
//										}
//Comments End
									}

									prepaidODRequestData.getLines().set(index,currLineToProcess);
									AddDeviceToPrepayODAddAccessoriesResponse addDeviceToPrepayODAddAccessoriesResponse = new AddDeviceToPrepayODAddAccessoriesResponse();
									AddDeviceToPrepayODAddDeviceResponse addDeviceToPrepayODAddDeviceResponse = new AddDeviceToPrepayODAddDeviceResponse();
									BeanUtils.copyProperties(addAccessoriesResponse, addDeviceToPrepayODAddAccessoriesResponse);
									BeanUtils.copyProperties(addDevicePrepayODResponseFinalTmp, addDeviceToPrepayODAddDeviceResponse);
									return prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, prepaidODRequestData)
											.doOnError(err -> logger.error("Failed to update the PrepaidODRequestData to Redis in PrepaidODAddDevice", err))
											.flatMap(upsertResp -> {
												logger.info("Successfully upserted PrepaidODRequestData to Redis:: {} ", upsertResp);
												AddDeviceToPrepayODBpmResponse addDeviceToPrepayODBpmResponse = prepayAddDevicePrepayODBpmResponse(addDeviceToPrepayODAddDeviceResponse, addDeviceToPrepayODAddAccessoriesResponse);
												addDeviceToPrepayODBpmResponse.getServiceBody().getServiceResponse().setContext(getResponseContext(addDeviceToPrepayODBpmResponse.getServiceBody().getServiceResponse().getContext(), prepaidODRequestData));
												if(prepaidAccountOwnerSelectionFlag && CollectionUtils.size(prepaidODRequestData.getLines())>1){
													if(prepaidODRequestData.isLoggedIn()) {
														addDeviceToPrepayODBpmResponse.getServiceBody().getServiceResponse().getContext().getContextInfo().setProcessStep(ASSIGN_NUMBERS_PROCESS_STEP);
													}else {
														addDeviceToPrepayODBpmResponse.getServiceBody().getServiceResponse().getContext().getContextInfo().setProcessStep(ACCOUNT_OWNER_PROCESS_STEP);
													}
												}
												return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(addDeviceToPrepayODBpmResponse, HttpStatus.OK));
											});
								});
					} else {
						int index = prepaidODRequestData.getLines().indexOf(currLineToProcess);
						currLineToProcess.setCheckoutFlag(true);
						currLineToProcess.setLineItemId(addDeviceLineItemId);
						logger.info("Dev Commerce ID for {} is {}::  ",currLineToProcess.getMtn(), addDeviceLineItemId);
						prepaidODRequestData.getLines().set(index,currLineToProcess);

						return prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, prepaidODRequestData)
								.doOnError(err -> logger.error("Failed to update the PrepaidODRequestData to Redis in PrepaidODAddDevice", err))
								.flatMap(upsertResp -> {
									logger.info("Successfully upserted PrepaidODRequestData to Redis:: {} ", upsertResp);
									AddDeviceToPrepayODAddDeviceResponse addDeviceToPrepayODAddDeviceResponse = new AddDeviceToPrepayODAddDeviceResponse();
									//setting deviceResponse
									BeanUtils.copyProperties(addDevicePrepayODResponseFinalTmp, addDeviceToPrepayODAddDeviceResponse);
									AddDeviceToPrepayODBpmResponse addDeviceToPrepayODBpmResponse = prepayAddDevicePrepayODBpmResponse(addDeviceToPrepayODAddDeviceResponse, null);
									addDeviceToPrepayODBpmResponse.getServiceBody().getServiceResponse().setContext(getResponseContext(addDeviceToPrepayODBpmResponse.getServiceBody().getServiceResponse().getContext(), prepaidODRequestData));
									if(prepaidAccountOwnerSelectionFlag && CollectionUtils.size(prepaidODRequestData.getLines())>1){
										if(prepaidODRequestData.isLoggedIn()) {
											addDeviceToPrepayODBpmResponse.getServiceBody().getServiceResponse().getContext().getContextInfo().setProcessStep(ASSIGN_NUMBERS_PROCESS_STEP);
										}else {
											addDeviceToPrepayODBpmResponse.getServiceBody().getServiceResponse().getContext().getContextInfo().setProcessStep(ACCOUNT_OWNER_PROCESS_STEP);
										}
									}
									return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(addDeviceToPrepayODBpmResponse, HttpStatus.OK));
								});
					}
				});
	}
*/

	private AddDeviceContext getResponseContext(AddDeviceContext context,
												PrepaidODRequestData prepaidODRequestData) {
		AddDeviceContext deviceContext = new AddDeviceContext();
		boolean isLoggedIn = prepaidODRequestData.isLoggedIn();
		deviceContext.setContextInfo(getContextInfo(context.getContextInfo(),isLoggedIn));
		deviceContext.setCustomerInfo(context.getCustomerInfo());
		if(Objects.nonNull(prepaidODRequestData)) {
			deviceContext.setProcessMTNList(getProcessMTNList(context.getContextInfo(), prepaidODRequestData));
		}
		CartServiceCustomerInfo cartServiceCustomerInfo = new CartServiceCustomerInfo();
		List<PrepaidODRequestDataLines> dataLines = prepaidODRequestData.getLines();
		String processingMtn = CollectionUtilities.isNotEmptyOrNull(dataLines)?dataLines.get(dataLines.size()-1).getMtn():"";
		cartServiceCustomerInfo.setProcessingMTN(processingMtn);
		deviceContext.setCustomerInfo(cartServiceCustomerInfo);

		return deviceContext;
	}



	private ProcessMTNList[] getProcessMTNList(CartServiceContextInfo contextInfo, PrepaidODRequestData prepaidODRequestData) {
		ProcessMTNList listData = new ProcessMTNList();
		List<PrepaidODRequestDataLines> dataLines = prepaidODRequestData.getLines();
		listData.setMtn(CollectionUtilities.isNotEmptyOrNull(dataLines)?dataLines.get(dataLines.size()-1).getMtn():"");
		String[] processStep = {contextInfo.getProcessStep()};
		listData.setCompletedprocessSteps(processStep);
		return new ProcessMTNList[] {listData};
	}


	private CartServiceContextInfo getContextInfo(CartServiceContextInfo contextInfo, boolean isLoggedIn) {
		CartServiceContextInfo serviceContextInfo = new CartServiceContextInfo();
		if(isLoggedIn) {
			serviceContextInfo.setProcessStep(ASSIGN_NUMBERS_PROCESS_STEP);
		}else {
			serviceContextInfo.setProcessStep(CHECKOUT_PLAN_PROCESS_STEP);
		}
		serviceContextInfo.setCallReason(contextInfo.getCallReason());
		serviceContextInfo.setIntent(contextInfo.getIntent());
		return serviceContextInfo;
	}

	private PrepaidODRequestDataLines getLineData(String mtn, AddDevicePEGARequest addDevicePEGARequest) {
		PrepaidODRequestDataLines dataLine = new PrepaidODRequestDataLines();
		dataLine.setMtn(mtn);
		dataLine.setLineItemId(mtn);//Once getcheckoutdetails is called we need to update the lineItemId from prepayplay service
		Device device = null;

		if(Objects.nonNull(addDevicePEGARequest) && Objects.nonNull(addDevicePEGARequest.getServiceBody())
			&& Objects.nonNull(addDevicePEGARequest.getServiceBody().getServiceRequest())
			&& Objects.nonNull(addDevicePEGARequest.getServiceBody().getServiceRequest().getContext())) {
			
			if(Objects.nonNull(addDevicePEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo())
				&& Objects.nonNull(addDevicePEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines())) {
					device = addDevicePEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getDevice();
			}
			if(Objects.nonNull(addDevicePEGARequest.getServiceBody().getServiceRequest().getContext().getContextInfo())
				&& Objects.nonNull(addDevicePEGARequest.getServiceBody().getServiceRequest().getContext().getContextInfo().getProcessStep())) {
					dataLine.setCompletedProcessSteps(Arrays.asList(addDevicePEGARequest.getServiceBody().getServiceRequest().getContext().getContextInfo().getProcessStep()));
			}
			if(Objects.nonNull(addDevicePEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo())
					&& Objects.nonNull(addDevicePEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType())) {
				dataLine.setFlow(addDevicePEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
			}
		}
		if(null != device) {
			dataLine.setDeviceId(device.getDeviceId());
			dataLine.setDeviceSkuId(device.getDeviceSkuId());
			dataLine.setDeviceSorId(device.getId());
			dataLine.setImageUrl(device.getImageUrl());
			dataLine.setDisplayName(device.getDisplayName());
			dataLine.setCapacity(device.getCapacity());
			dataLine.setColor(device.getColor());
			dataLine.setDevicePrice(device.getDevicePrice());
			dataLine.setDescription(device.getDescription());
			dataLine.setManufacturer(device.getManufacturer());
			dataLine.setPdpUrl(device.getPdpUrl());
			dataLine.setBasicPhone(device.getCategory() != null && device.getCategory().equalsIgnoreCase("Basic Phones"));
			dataLine.setDataDevice(device.getCategory() != null && (device.getCategory().equalsIgnoreCase("Tablets") || device.getCategory().equalsIgnoreCase("Jetpack")));
			dataLine.setSmartWatch(device.getCategory() != null && device.getCategory().equalsIgnoreCase("SmartWatch"));
			dataLine.setSmartPhone(device.getCategory() != null && device.getCategory().equalsIgnoreCase("Smartphones"));
			dataLine.setOsType(device.getOperatingSystem()!=null ? device.getOperatingSystem().toUpperCase(): StringUtils.EMPTY);
			dataLine.setNumbershareEligibleOS(CollectionUtilities.isNotEmptyOrNull(device.getEligibleNumshareOS())?String.join(",",device.getEligibleNumshareOS()).toUpperCase(): String.valueOf(Collections.emptyList()));
		}
		return dataLine;
	}

	private String getHeaderValue(ServerHttpRequest httpRequest, String headerName) {
		List<String> headerValuesList = httpRequest.getHeaders().get(headerName);
		
		if(Objects.nonNull(headerValuesList) && CollectionUtilities.isNotEmptyOrNull(headerValuesList) 
			&&  StringUtilities.isNotEmptyOrNull(headerValuesList.get(0))) {
				return headerValuesList.get(0);
		}
		return null;
	}

	private PrepaidAdaptorWebClientRequest getPrepaidAddDeviceLegacyServiceRequest(PrepaidODAddDeviceRequest prepaidODAddDeviceRequest, PrepaidODRequestData prepaidODRequestData) {
		PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
		prepaidAdaptorWebClientRequest.setUrl(addDevicePrepaidLegacyServiceUrl);
		prepaidAdaptorWebClientRequest.setRequestBody(prepaidODAddDeviceRequest);
		prepaidAdaptorWebClientRequest.setRequestType(HttpMethod.POST.toString());
		prepaidAdaptorWebClientRequest.setHeader(PrepayAdaptorCartUtil.getPrepayODServiceCommonHeaders(prepaidODRequestData, prepaidODAddDeviceRequest.getFlow()));
		return prepaidAdaptorWebClientRequest;
	}

	private PrepaidAdaptorWebClientRequest getPrepaidAddAccessoriesLegacyServiceRequest(PrepaidODAddAccessoriesRequest prepaidODAddAccessoriesRequest, PrepaidODRequestData prepaidODRequestData) {
		PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
		prepaidAdaptorWebClientRequest.setUrl(addAccessoryPrepaidLegacyServiceUrl);
		prepaidAdaptorWebClientRequest.setRequestBody(prepaidODAddAccessoriesRequest);
		prepaidAdaptorWebClientRequest.setRequestType(HttpMethod.POST.toString());
		String flow = CollectionUtilities.isNotEmptyOrNull(prepaidODAddAccessoriesRequest.getAccessories())?prepaidODAddAccessoriesRequest.getAccessories().get(0).getFlow():NSE;
		prepaidAdaptorWebClientRequest.setHeader(PrepayAdaptorCartUtil.getPrepayODServiceCommonHeaders(prepaidODRequestData,flow));
		return prepaidAdaptorWebClientRequest;
	}


	private PrepaidODAddDeviceRequest getPrepayODAddDeviceRequest(PrepaidODRequestDataLines lineData, AddDeviceToPrepayODBpmRequest addDeviceToPrepayODBpmRequest){
		PrepaidODAddDeviceRequest prepaidODAddDeviceRequest = new PrepaidODAddDeviceRequest();
		prepaidODAddDeviceRequest.setProductId(lineData.getDeviceId());
		prepaidODAddDeviceRequest.setDeviceSkuId(lineData.getDeviceSkuId());
		prepaidODAddDeviceRequest.setQty("1");

		if(lineData.isSmartPhone() || lineData.isBasicPhone()) {
			prepaidODAddDeviceRequest.setPlanSkuId(StringUtilities.isNotEmptyOrNull(lineData.getPlanSkuId())?lineData.getPlanSkuId():SMARTPHONE_DEFAULT_PLAN);
		} else if(lineData.isDataDevice()) {
			prepaidODAddDeviceRequest.setPlanSkuId(StringUtilities.isNotEmptyOrNull(lineData.getPlanSkuId())?lineData.getPlanSkuId():DATADEVICE_DEFAULT_PLAN);
		} else if (lineData.isSmartWatch()) {
			prepaidODAddDeviceRequest.setPlanSkuId(StringUtilities.isNotEmptyOrNull(lineData.getPlanSkuId())?lineData.getPlanSkuId():SMARTWATCH_DEFAULT_PLAN);
		} else {
			prepaidODAddDeviceRequest.setPlanSkuId(lineData.getPlanSkuId());
		}
		
		if(StringUtilities.isNotEmptyOrNull(lineData.getUniqueDeviceId())) {
			prepaidODAddDeviceRequest.setUniqueDeviceId(lineData.getUniqueDeviceId());
		}
		boolean notNowFlag = false;
		
		if(null!=lineData.getFeatureSkuIds() && CollectionUtils.size(lineData.getFeatureSkuIds())>0){
			//removing xxx from featureskuid's for not now scenario
			if(lineData.getFeatureSkuIds().contains(NOT_NOW_FEATURE)) {
				notNowFlag = true;
			}
			lineData.getFeatureSkuIds().remove(NOT_NOW_FEATURE);
			prepaidODAddDeviceRequest.setFeatureSkuId(lineData.getFeatureSkuIds().stream().filter(Objects::nonNull).collect(Collectors.joining(",")));
			if(notNowFlag) {
				lineData.getFeatureSkuIds().add(NOT_NOW_FEATURE);
			}
		}else{
			prepaidODAddDeviceRequest.setFeatureSkuId("");
		}
		String flow = StringUtilities.isNotEmptyOrNull(lineData.getFlow())?lineData.getFlow():NSE;
		String flowName = PrepayAdaptorCartUtil.getODFlowName(flow);
		prepaidODAddDeviceRequest.setFlow(flowName);
		if(StringUtilities.isNotEmptyOrNull(lineData.getSelectedMtn()))
		prepaidODAddDeviceRequest.setSelectedMtn(lineData.getSelectedMtn());
		return prepaidODAddDeviceRequest;
	}

	private PrepaidODAddAccessoriesRequest getPrepaidODAddAccessoriesRequest(PrepaidODRequestDataLines lineData, AddDeviceToPrepayODBpmRequest addDeviceToPrepayODBpmRequest, VZWPrepayAddOrUpdateCartResponse addDevicePrepayODResponse){
		PrepaidODAddAccessoriesRequest prepaidODAddAccessoriesRequest = new PrepaidODAddAccessoriesRequest();
		String flow = StringUtilities.isNotEmptyOrNull(lineData.getFlow())?lineData.getFlow():NSE;
			List<PrepaidODAccessory> accessoryList = lineData.getAccessorySkuIds().stream().map(srcAccessory->{
				PrepaidODAccessory targetAaccessory = new PrepaidODAccessory();
				String flowName = PrepayAdaptorCartUtil.getODFlowName(flow);
				targetAaccessory.setFlow(flowName);
				//targetAaccessory.setFlow(null==addDeviceToPrepayODBpmRequest.getServiceBody().getServiceRequest().getContext().getFlow()?NSE:addDeviceToPrepayODBpmRequest.getServiceBody().getServiceRequest().getContext().getFlow());
				targetAaccessory.setAccQty(srcAccessory.getQty());
				targetAaccessory.setAccSkuId(srcAccessory.getSkuId());
				targetAaccessory.setAccSorId(srcAccessory.getSorId());
				if(null!=addDevicePrepayODResponse) targetAaccessory.setDevCommerceId(addDevicePrepayODResponse.getDevCommerceId());
				targetAaccessory.setAccCategory(""); //need to check where to get this
				targetAaccessory.setAction(PREPAY_OD_ACCESSORY_ADD_ACTION);
				targetAaccessory.setAccessoryBundle(false);
				return targetAaccessory;
			}).toList();
			prepaidODAddAccessoriesRequest.setAccessories(accessoryList);

		return prepaidODAddAccessoriesRequest;
	}

	private AddDevicePEGAResponse getAddDevicePEGAResponse(AddDevicePEGARequest addDevicePEGARequest,PrepaidODRequestData prepaidODRequestData) {
		addDevicePEGARequest.getServiceHeader().setStatusMsg(PrepayAdaptorCartConstants.SUCCESS_MSG);
		addDevicePEGARequest.getServiceHeader().setStatusCode(PrepayAdaptorCartConstants.RESPONSE_SUCCESS_CODE);
		AddDevicePEGAResponse response = new AddDevicePEGAResponse();
		response.setServiceHeader(addDevicePEGARequest.getServiceHeader());
		response.setServiceBody(getServiceBody(addDevicePEGARequest,prepaidODRequestData));
		return response;
	}
 	
	private AddDeviceServiceBody getServiceBody(AddDevicePEGARequest addDevicePEGARequest,
			PrepaidODRequestData prepaidODRequestData) {
		AddDeviceServiceBody diviveServiceBody = new AddDeviceServiceBody();
		diviveServiceBody.setServiceResponse(getServiceResponse(addDevicePEGARequest,prepaidODRequestData));
		return diviveServiceBody;
	}

	private AddDeviceServiceResponse getServiceResponse(AddDevicePEGARequest addDevicePEGARequest,
			PrepaidODRequestData prepaidODRequestData) {
		AddDeviceServiceResponse deviceServiceResponse = new AddDeviceServiceResponse();
		deviceServiceResponse.setContext(getResponseContext(addDevicePEGARequest,prepaidODRequestData));
		return deviceServiceResponse;
	}

	private AddDeviceContext getResponseContext(AddDevicePEGARequest addDevicePEGARequest,
			PrepaidODRequestData prepaidODRequestData) {
		AddDeviceContext deviceContext = new AddDeviceContext();
		deviceContext.setContextInfo(getContextInfo(addDevicePEGARequest));
		deviceContext.setCustomerInfo(getCustomerinfo(addDevicePEGARequest));
		deviceContext.setCartInfo(getCartInfo(addDevicePEGARequest,prepaidODRequestData));
		deviceContext.setProcessMTNList(getProcessMTNList(addDevicePEGARequest,prepaidODRequestData));
		return deviceContext;
	}

	private ProcessMTNList[] getProcessMTNList(AddDevicePEGARequest addDevicePEGARequest,PrepaidODRequestData prepaidODRequestData) {
		ProcessMTNList listData = new ProcessMTNList();
		List<PrepaidODRequestDataLines> dataLines = prepaidODRequestData.getLines();
		listData.setMtn(CollectionUtilities.isNotEmptyOrNull(dataLines)?dataLines.get(dataLines.size()-1).getMtn():"");
		String[] processStep = {addDevicePEGARequest.getServiceBody().getServiceRequest().getContext().getContextInfo().getProcessStep()};
		listData.setCompletedprocessSteps(processStep);
		return new ProcessMTNList[] {listData};
	}

	private CartServiceCartInfo getCartInfo(AddDevicePEGARequest addDevicePEGARequest,
			PrepaidODRequestData prepaidODRequestData) {
		CartServiceCartInfo cartInfo = new CartServiceCartInfo();
		cartInfo.setCartItemCount(prepaidODRequestData.getCurr_line());
		List<PrepaidODRequestDataLines> dataLines = prepaidODRequestData.getLines();
		Line deviceLine = new Line();
		if("NSE".equalsIgnoreCase(addDevicePEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType())) {
			//deviceLine.setMtn("newLine"+strCurrLine);
			deviceLine.setMtn(CollectionUtilities.isNotEmptyOrNull(dataLines)?dataLines.get(dataLines.size()-1).getMtn():"");
			deviceLine.setLineActivityType("NSE");
		}
		Line[] deviceLines = new Line[1];
		deviceLines[0] = deviceLine;
		cartInfo.setLines(deviceLines);
		return cartInfo;
	}

	private CartServiceCustomerInfo getCustomerinfo(AddDevicePEGARequest addDevicePEGARequest) {
		CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
		customerInfo.setCustomerType(addDevicePEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCustomerType());
		customerInfo.setAccountNumber(addDevicePEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getAccountNumber());
		customerInfo.setCartCreator(addDevicePEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCartCreator());
		customerInfo.setProcessingMTN(addDevicePEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getProcessingMTN());
		customerInfo.setRegisterNumber(addDevicePEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getRegisterNumber());
		customerInfo.setMtnFlow(addDevicePEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getMtnFlow());
		customerInfo.setGlobalId(addDevicePEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getGlobalId());
		return customerInfo;
	}

	private CartServiceContextInfo getContextInfo(AddDevicePEGARequest addDevicePEGARequest) {
		CartServiceContextInfo serviceContextInfo = new CartServiceContextInfo();
		serviceContextInfo.setProcessStep(PrepayAdaptorCartConstants.ACCESSORIES_INTERSTIAL);  // we need get it from redis 
		serviceContextInfo.setCallReason(addDevicePEGARequest.getServiceBody().getServiceRequest().getContext().getContextInfo().getCallReason());
		serviceContextInfo.setIntent(addDevicePEGARequest.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
		return serviceContextInfo;
	}

	private <T> Object getMockResponse(String filePath, Object obj) {
		try(java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(ResourceUtils.getURL(filePath).openStream()))) {
	        String responseStr = reader.lines().collect(java.util.stream.Collectors.joining());
    	    return mapper.readValue(responseStr, (Class<T>) obj);
		}catch(java.io.IOException io) {
			return null;
		}
	}

	private PrepaidAdaptorWebClientRequest getPrepaidRemoveLineLegacyServiceRequest(RemoveLineItemsRequest removeLineItemsRequest, PrepaidODRequestData prepaidODRequestData) {
		PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
		prepaidAdaptorWebClientRequest.setUrl(removeLinesPrepaidLegacyServiceUrl);
		prepaidAdaptorWebClientRequest.setRequestBody(removeLineItemsRequest);
		prepaidAdaptorWebClientRequest.setRequestType(HttpMethod.POST.toString());
		prepaidAdaptorWebClientRequest.setHeader(PrepayAdaptorCartUtil.getPrepayODServiceCommonHeaders(prepaidODRequestData));
		return prepaidAdaptorWebClientRequest;
	}

	private AddDeviceToPrepayODBpmResponse prepareAddDevicePrepayODBpmResponseWithInternalError(String errCode, String errMsg, String errCategory, String namespace){
		AddDeviceToPrepayODBpmResponse addDeviceToPrepayODBpmResponse = new AddDeviceToPrepayODBpmResponse();
		Error error = new Error();
		error.setErrorCode(errCode);
		error.setMessage(errMsg);
		error.setErrorCategory(errCategory);
		error.setDebug_id(namespace);
		error.setNamespace(namespace);
		List<Error> errors = new ArrayList<>();
		errors.add(error);
		addDeviceToPrepayODBpmResponse.setErrors(errors);
		return addDeviceToPrepayODBpmResponse;
	}

	private AddDeviceToPrepayODBpmResponse prepareAddDevicePrepayODBpmResponseWithError(VZWPrepayAddOrUpdateCartResponse addDevicePrepayODResponse){
		AddDeviceToPrepayODBpmResponse addDeviceToPrepayODBpmResponse = new AddDeviceToPrepayODBpmResponse();

		if(Objects.nonNull(addDevicePrepayODResponse) && Objects.nonNull(addDevicePrepayODResponse.getErrors())
				&& CollectionUtilities.isNotEmptyOrNull(addDevicePrepayODResponse.getErrors().getEcommApiErrorList())) {

			List<Error> errors = new ArrayList<>();
			addDevicePrepayODResponse.getErrors().getEcommApiErrorList().stream().forEach(apiError-> {
				Error error = new Error();
				error.setErrorCode(apiError.getStatusCode());
				error.setMessage(apiError.getMessage());
				error.setSystem(PrepayAdaptorCartConstants.SYSTEM_FAILURE_PREPAID_OD);
				error.setErrorCategory(PrepayAdaptorCartConstants.ERR_CATEGORY_PREPAID_OD_ADD_DEVICE);
				errors.add(error);
			});
			addDeviceToPrepayODBpmResponse.setErrors(errors);
		}
		logger.info("Error response from the addDeviceprepay: {}",addDeviceToPrepayODBpmResponse);
		return addDeviceToPrepayODBpmResponse;

	}

	private AddDeviceToPrepayODBpmResponse prepareAddDevicePrepayODBpmResponseWithError2(VZWPrepayAddOrUpdateCartResponse addDevicePrepayODResponse){
		AddDeviceToPrepayODBpmResponse addDeviceToPrepayODBpmResponse = new AddDeviceToPrepayODBpmResponse();
		Optional.ofNullable(addDevicePrepayODResponse)
				.map(errResp->Optional.ofNullable(addDevicePrepayODResponse.getErrors()).orElse(new EcommValidationError()))
				.map(ecommValidationError -> Optional.ofNullable(ecommValidationError.getEcommApiErrorList()).orElse(new ArrayList<>()))
				.ifPresent(ecommApiErrors -> {
					List<Error> errors = new ArrayList<>();
					ecommApiErrors.stream().forEach(ecommApiError -> {
						Error error = new Error();
						error.setErrorCode(ecommApiError.getStatusCode());
						error.setMessage(ecommApiError.getMessage());
						error.setSystem(PrepayAdaptorCartConstants.SYSTEM_FAILURE_PREPAID_OD);
						error.setErrorCategory(PrepayAdaptorCartConstants.ERR_CATEGORY_PREPAID_OD_ADD_DEVICE);
						errors.add(error);
					});
					addDeviceToPrepayODBpmResponse.setErrors(errors);
				});
		return addDeviceToPrepayODBpmResponse;
	}


	private AddDeviceToPrepayODBpmResponse prepayAddDevicePrepayODBpmResponse(AddDeviceToPrepayODAddDeviceResponse addDeviceToPrepayODAddDeviceResponse, AddDeviceToPrepayODAddAccessoriesResponse addDeviceToPrepayODAddAccessoriesResponse){
		//Set addAccessoriesResponse
		AddDeviceToPrepayODBpmResponse addDeviceToPrepayODBpmResponse = new AddDeviceToPrepayODBpmResponse();
		AddDeviceToPrepayODServiceBody addDeviceToPrepayODServiceBody = new AddDeviceToPrepayODServiceBody();
		AddDeviceToPrepayODServiceResponse addDeviceToPrepayODServiceResponse = new AddDeviceToPrepayODServiceResponse();
		AddDeviceContext addDeviceContext = new AddDeviceContext();
		CartServiceContextInfo cartServiceContextInfo = new CartServiceContextInfo();

		addDeviceToPrepayODServiceResponse.setPrepaidODAddAccessoriesResponse(addDeviceToPrepayODAddAccessoriesResponse);
		//setting deviceResponse
		List<AddDeviceToPrepayODAddDeviceResponse> addDeviceToPrepayODAddDeviceResponseList = new ArrayList<>();
		addDeviceToPrepayODAddDeviceResponseList.add(addDeviceToPrepayODAddDeviceResponse);
		addDeviceToPrepayODServiceResponse.setPrepaidODAddDevicesResponse(addDeviceToPrepayODAddDeviceResponseList);
		addDeviceContext.setContextInfo(cartServiceContextInfo);
		addDeviceToPrepayODServiceResponse.setContext(addDeviceContext);

		addDeviceToPrepayODServiceBody.setServiceResponse(addDeviceToPrepayODServiceResponse);
		addDeviceToPrepayODBpmResponse.setServiceBody(addDeviceToPrepayODServiceBody);

		return addDeviceToPrepayODBpmResponse;
	}

	private Mono<ResponseEntity<AddDeviceToPrepayODBpmResponse>> removeLineFromRedis(PrepaidODRequestData prepaidODRequestData,PrepaidODRequestDataLines currLineToProcess,AddDeviceToPrepayODBpmResponse addDeviceToPrepayODBpmResponse) {

		logger.info("Inside removeLineFromRedis: Going to remove line in Redis for mtn: {}",currLineToProcess.getMtn());

		if(Objects.nonNull(prepaidODRequestData) && CollectionUtilities.isNotEmptyOrNull(prepaidODRequestData.getLines()) && Objects.nonNull(currLineToProcess)) {
			List<PrepaidODRequestDataLines> targetDataLines = prepaidODRequestData.getLines().stream().filter(dataLines -> !dataLines.getMtn().equalsIgnoreCase(currLineToProcess.getMtn())).toList();
			prepaidODRequestData.setLines(targetDataLines);
			prepaidODRequestData.setCurr_line(CollectionUtilities.isNotEmptyOrNull(targetDataLines)?targetDataLines.size():0);

			if(prepaidODRequestData.getAccountOwner().equalsIgnoreCase(currLineToProcess.getMtn())) {
				prepaidODRequestData.setAccountOwner(CollectionUtilities.isNotEmptyOrNull(targetDataLines)?targetDataLines.get(0).getMtn():"");
			}

			return prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, prepaidODRequestData)
				.doOnError(err -> logger.error("Failed to remove addedevice prepayline Redis", err))
				.flatMap(upsertResp -> {
					logger.info("Successfully removed device line from Redis:: {} ", upsertResp);

					if (Objects.nonNull(addDeviceToPrepayODBpmResponse)) {
						return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(prepareAddDevicePrepayODBpmErrorResponse(), HttpStatus.OK));
					} else {
						return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(addDeviceToPrepayODBpmResponse, HttpStatus.OK));
					}
				});
		}
		return Mono.just(new ResponseEntity<AddDeviceToPrepayODBpmResponse>(new AddDeviceToPrepayODBpmResponse(), HttpStatus.INTERNAL_SERVER_ERROR));
	}

	private AddDeviceToPrepayODBpmResponse prepareAddDevicePrepayODBpmErrorResponse(){
		AddDeviceToPrepayODBpmResponse addDeviceToPrepayODBpmResponse = new AddDeviceToPrepayODBpmResponse();
		List<Error> errors = new ArrayList<>();
		Error error = new Error();
		error.setErrorCode(ADD_PREPAY_FAILURE_CODE);
		error.setMessage(ADD_PREPAY_FAILURE_MESSAGE);
		error.setSystem(SYSTEM_FAILURE_PREPAID_OD);
		error.setErrorCategory(ERR_CATEGORY_PREPAID_OD_ADD_DEVICE);
		errors.add(error);
		addDeviceToPrepayODBpmResponse.setErrors(errors);
		return addDeviceToPrepayODBpmResponse;
	}

	private AddDeviceToPrepayODAddDeviceResponse prepareErrorToAddDevicePrepayODResponse(){
		AddDeviceToPrepayODAddDeviceResponse errorToAddDevicePrepayResponse = new AddDeviceToPrepayODAddDeviceResponse();
		errorToAddDevicePrepayResponse.setOrderUpdated(false);
		errorToAddDevicePrepayResponse.setSuccess(false);
		HashMap<String,String> errorMap = new HashMap<>();
		errorMap.putIfAbsent("statusCode",ADD_PREPAY_FAILURE_CODE);
		errorMap.putIfAbsent("message",ADD_PREPAY_FAILURE_MESSAGE);
		errorToAddDevicePrepayResponse.setErrorMap(errorMap);
		logger.info("Error to AddDevicePrepay response object: {}",errorToAddDevicePrepayResponse);
		return errorToAddDevicePrepayResponse;
	}

}
