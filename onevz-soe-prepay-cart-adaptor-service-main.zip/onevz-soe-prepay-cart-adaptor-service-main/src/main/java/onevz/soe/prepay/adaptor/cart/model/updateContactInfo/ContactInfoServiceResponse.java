package onevz.soe.prepay.adaptor.cart.model.updateContactInfo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import onevz.soe.wsclient.bpm.model.response.ServiceResponse;

@lombok.Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ContactInfoServiceResponse extends ServiceResponse {
    private ContactInfoContext context;
}
