package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class SendEmailVo implements Serializable {

    private String email_to;
    private Integer sequence_num;
    private String email_body;
    private String lastupdate_es;
    private Integer retrieve_from_jsp;
    private String name;
    private Integer site_id;
    private String email_subject;
    private String email_from;

    public List<DeviceLineItem> getDeviceLineItem() {
        return deviceLineItem;
    }

    public void setDeviceLineItem(List<DeviceLineItem> deviceLineItem) {
        this.deviceLineItem = deviceLineItem;
    }

    public Map<String, String> getLabels() {
        return labels;
    }

    public void setLabels(Map<String, String> labels) {
        this.labels = labels;
    }

    public boolean isComboOrder() {
        return comboOrder;
    }

    public void setComboOrder(boolean comboOrder) {
        this.comboOrder = comboOrder;
    }

    private List<DeviceLineItem> deviceLineItem;
    private Map<String,String> labels;
    private boolean comboOrder;

    public String getEmail_to() {
        return email_to;
    }

    public void setEmail_to(String email_to) {
        this.email_to = email_to;
    }

    public Integer getSequence_num() {
        return sequence_num;
    }

    public void setSequence_num(Integer sequence_num) {
        this.sequence_num = sequence_num;
    }

    public String getEmail_body() {
        return email_body;
    }

    public void setEmail_body(String email_body) {
        this.email_body = email_body;
    }

    public String getLastupdate_es() {
        return lastupdate_es;
    }

    public void setLastupdate_es(String lastupdate_es) {
        this.lastupdate_es = lastupdate_es;
    }

    public Integer getRetrieve_from_jsp() {
        return retrieve_from_jsp;
    }

    public void setRetrieve_from_jsp(Integer retrieve_from_jsp) {
        this.retrieve_from_jsp = retrieve_from_jsp;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getSite_id() {
        return site_id;
    }

    public void setSite_id(Integer site_id) {
        this.site_id = site_id;
    }

    public String getEmail_subject() {
        return email_subject;
    }

    public void setEmail_subject(String email_subject) {
        this.email_subject = email_subject;
    }

    public String getEmail_from() {
        return email_from;
    }

    public void setEmail_from(String email_from) {
        this.email_from = email_from;
    }







}
