package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;
import java.util.Map;
import java.util.List;

public class CreditCard extends PaymentGroup implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -559007903627077408L;
	private String creditCardNumber;
	private String creditCardType;	
	private String creditCardExpMonth;
	private String creditCardExpYear;
	private String creditCardVerificationNumber;
	private String authenticationValue;
	private String ecommerceIndicator;
	private String secureTxnId;
	private String cardNumber;
	private String nickName;
	private String creditCardBillingZip;
	private String encryptedCardData;
	private String encryptedCardData2;

	private String paymentGateway;
	private String cybersourceRequestRefNumber;
	private String cybersourcePaymentToken;

	private List<PaymentStatus> creditStatus;
	private List<PaymentStatus> deditStatus;

	private Short paySeqNum;

	private String vzBrandCcInd;

	private String dsTransactionId;
	private String programProtocol;
	/**
	 * @return the deditStatus
	 */
	public List<PaymentStatus> getDeditStatus() {
		return deditStatus;
	}

	/**
	 * @param deditStatus the deditStatus to set
	 */
	public void setDeditStatus(List<PaymentStatus> deditStatus) {
		this.deditStatus = deditStatus;
	}

	/**
	 * @return the creditStatus
	 */
	public List<PaymentStatus> getCreditStatus() {
		return creditStatus;
	}

	/**
	 * @param creditStatus the creditStatus to set
	 */
	public void setCreditStatus(List<PaymentStatus> creditStatus) {
		this.creditStatus = creditStatus;
	}

	public String getCybersourceRequestRefNumber() {
		return  cybersourceRequestRefNumber ;
	}

	public void setCybersourceRequestRefNumber(String cybersourceRequestRefNumber) {
		this.cybersourceRequestRefNumber  =cybersourceRequestRefNumber;
	}

	public String getCybersourcePaymentToken() {
		return  cybersourcePaymentToken;
	}

	public void setCybersourcePaymentToken(String cybersourcePaymentToken) {
		this.cybersourcePaymentToken=cybersourcePaymentToken;
	}

	public String getPaymentGateway() {
		return paymentGateway;
	}

	public void setPaymentGateway(String paymentGateway) {
		this.paymentGateway = paymentGateway;
	}

	public Map<String, String> getCardinal3DInfo() {
		return cardinal3DInfo;
	}

	public void setCardinal3DInfo(Map<String, String> cardinal3DInfo) {
		this.cardinal3DInfo = cardinal3DInfo;
	}

	private Map<String,String> cardinal3DInfo;

	public String getCreditCardNumber() {
		return creditCardNumber;
	}

	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}

	public String getCreditCardType() {
		return creditCardType;
	}

	public void setCreditCardType(String creditCardType) {
		this.creditCardType = creditCardType;
	}	
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		StringBuffer sb = new StringBuffer();
		sb.append(" card number => " + this.creditCardNumber);
		sb.append(" card type => " + this.creditCardType);
		sb.append(" card expiration month => " + this.creditCardExpMonth);
		sb.append(" cart expiration year => " + this.creditCardExpYear);
		return sb.toString();
	}	

	public String getCreditCardExpYear() {
		return creditCardExpYear;
	}

	public void setCreditCardExpYear(String creditCardExpYear) {
		this.creditCardExpYear = creditCardExpYear;
	}

	public String getCreditCardVerificationNumber() {
		return creditCardVerificationNumber;
	}

	public void setCreditCardVerificationNumber(String creditCardVerificationNumber) {
		this.creditCardVerificationNumber = creditCardVerificationNumber;
	}

	public String getCreditCardExpMonth() {
		return this.creditCardExpMonth;
	}

	public void setCreditCardExpMonth(String creditCardExpMonth) {
		this.creditCardExpMonth = creditCardExpMonth;
	}

	public String getAuthenticationValue() {
		return authenticationValue;
	}

	public void setAuthenticationValue(String authenticationValue) {
		this.authenticationValue = authenticationValue;
	}	

	public String getEcommerceIndicator() {
		return ecommerceIndicator;
	}

	public void setEcommerceIndicator(String ecommerceIndicator) {
		this.ecommerceIndicator = ecommerceIndicator;
	}

	public String getSecureTxnId() {
		return secureTxnId;
	}

	public void setSecureTxnId(String secureTxnId) {
		this.secureTxnId = secureTxnId;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	@Override
	public String getPaymentMethod() {
		return "creditCard";
	}

	public String getCreditCardBillingZip() {
		return creditCardBillingZip;
	}

	public void setCreditCardBillingZip(String creditCardBillingZip) {
		this.creditCardBillingZip = creditCardBillingZip;
	}

	public String getEncryptedCardData() {
		return encryptedCardData;
	}

	public void setEncryptedCardData(String encryptedCardData) {
		this.encryptedCardData = encryptedCardData;
	}

	public String getEncryptedCardData2() {
		return encryptedCardData2;
	}

	public void setEncryptedCardData2(String encryptedCardData2) {
		this.encryptedCardData2 = encryptedCardData2;
	}
	public Short getPaySeqNum() {
		return paySeqNum;
	}

	public void setPaySeqNum(Short paySeqNum) {
		this.paySeqNum = paySeqNum;
	}

	public String getVzBrandCcInd() {
		return vzBrandCcInd;
	}

	public void setVzBrandCcInd(String vzBrandCcInd) {
		this.vzBrandCcInd = vzBrandCcInd;
	}

	public String getDsTransactionId() {
		return dsTransactionId;
	}

	public void setDsTransactionId(String dsTransactionId) {
		this.dsTransactionId = dsTransactionId;
	}

	public String getProgramProtocol() {
		return programProtocol;
	}

	public void setProgramProtocol(String programProtocol) {
		this.programProtocol = programProtocol;
	}
}
