package onevz.soe.prepay.adaptor.cart.model.cxp.common;

import lombok.Data;

/**
 * Holds information about CXP errors.
 */
@Data
public class CXPError {
    private String type;
}
