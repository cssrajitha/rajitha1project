package onevz.soe.prepay.adaptor.cart.model.play;

import lombok.Data;

@Data
public class PrepaidODAddDeviceRequest {
    private String productId;
    private String deviceSkuId;
    private String qty="1";
    private String planSkuId;
    private String featureSkuId;
    private String flow;
    private String uniqueDeviceId;
    private String selectedMtn;
}
