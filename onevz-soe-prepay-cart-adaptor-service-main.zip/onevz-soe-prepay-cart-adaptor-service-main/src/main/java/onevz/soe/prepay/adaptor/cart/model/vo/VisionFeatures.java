package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;

public class VisionFeatures implements Serializable {

	private static final long serialVersionUID = 1L;

	private String lineItemvisionFeatureId;
	private String deviceLineItemId;
	private String featureCode;
	
	private String featureType;
	
	private String featureInclusionIndicator;
	private double featurePrice;
	private String featureDescription;
	private int version;
	public String getLineItemvisionFeatureId() {
		return lineItemvisionFeatureId;
	}
	public void setLineItemvisionFeatureId(String lineItemvisionFeatureId) {
		this.lineItemvisionFeatureId = lineItemvisionFeatureId;
	}
	public String getDeviceLineItemId() {
		return deviceLineItemId;
	}
	public void setDeviceLineItemId(String deviceLineItemId) {
		this.deviceLineItemId = deviceLineItemId;
	}
	public String getFeatureCode() {
		return featureCode;
	}
	public void setFeatureCode(String featureCode) {
		this.featureCode = featureCode;
	}
	public String getFeatureInclusionIndicator() {
		return featureInclusionIndicator;
	}
	public void setFeatureInclusionIndicator(String featureInclusionIndicator) {
		this.featureInclusionIndicator = featureInclusionIndicator;
	}
	public double getFeaturePrice() {
		return featurePrice;
	}
	public void setFeaturePrice(double featurePrice) {
		this.featurePrice = featurePrice;
	}
	public String getFeatureDescription() {
		return featureDescription;
	}
	public void setFeatureDescription(String featureDescription) {
		this.featureDescription = featureDescription;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	public String getFeatureType() {
		return featureType;
	}
	public void setFeatureType(String featureType) {
		this.featureType = featureType;
	}
}
