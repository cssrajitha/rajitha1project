package onevz.soe.prepay.adaptor.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.model.common.ProcessMTNList;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.common.model.PrepaidODRequestDataLines;
import onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants;
import onevz.soe.prepay.adaptor.cart.model.updateContactInfo.*;
import onevz.soe.prepay.adaptor.cart.model.updateContactInfo.play.ContactInfoPrepayODRequest;
import onevz.soe.prepay.adaptor.cart.model.updateContactInfo.play.ContactInfoPrepayODResponse;
import onevz.soe.prepay.adaptor.cart.util.PrepayAdaptorCartUtil;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.bpm.model.ServiceHeader;
import onevz.soe.wsclient.bpm.model.request.ContextInfo;
import onevz.soe.wsclient.bpm.model.response.AvailablePaths;
import onevz.soe.wsclient.bpm.model.response.Error;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import onevz.soe.wsclient.prepay.webclient.model.PrepaidAdaptorWebClientRequest;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.*;


@Service
public class PrepayAdaptorCartPersonalInfoHelper {

    private static final Logger logger = LoggerFactory.getLogger(PrepayAdaptorCartPersonalInfoHelper.class);
    @Autowired
    PrepayCartRedisHelper prepayCartRedisHelper;
    @Autowired
    private ObjectMapper mapper;
    @Value("${contactInfoPrepaidLegacyServiceUrl}")
    private String contactInfoPrepaidLegacyServiceUrl;
    @Autowired
    private PrepayAdaptorWebClient prepayBusinessCartWebclient;

    public static ContactInfoPrepayODRequest convertToPrepayODRequest(ContactInfoRequest contactInfoUIRequest) {
        logger.info("Started convertToPrepayODRequest");

        ContactInfoPrepayODRequest contactInfoPrepayODRequest = new ContactInfoPrepayODRequest();

        contactInfoUIRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().stream().findFirst()
                .ifPresent(addressLine -> {
                	String phoneNumber = Strings.isNullOrEmpty(addressLine.getContactNumber()) ? "" : addressLine.getContactNumber();
                    contactInfoPrepayODRequest.setFirstName(addressLine.getFirstName());
                    contactInfoPrepayODRequest.setLastName(addressLine.getLastName());
                    contactInfoPrepayODRequest.setEmail(addressLine.getEmail());
                    phoneNumber = StringUtilities.removeAll(phoneNumber, ".");
                    contactInfoPrepayODRequest.setPhoneNumber(phoneNumber);
                    
                    if (null != addressLine.getAddress()) {
                        contactInfoPrepayODRequest.setCity(addressLine.getAddress().getCity());
                        contactInfoPrepayODRequest.setAddress1(addressLine.getAddress().getAddressLine1());
                        contactInfoPrepayODRequest.setAddress2(Strings.isNullOrEmpty(addressLine.getAddress().getAddressLine2()) ? ""
                                : addressLine.getAddress().getAddressLine2());
                        contactInfoPrepayODRequest.setState(addressLine.getAddress().getState());
                        contactInfoPrepayODRequest.setZip(addressLine.getAddress().getZipCode());
                        String addressPhone = addressLine.getAddress().getPhoneNumber();
                        
                        if( StringUtilities.isNotEmptyOrNull(addressPhone)) {
                        	addressPhone = StringUtilities.removeAll(addressPhone, ".");
                        }
                        contactInfoPrepayODRequest.setPhoneNumber(Strings.isNullOrEmpty(addressLine.getAddress().getPhoneNumber()) ?phoneNumber : addressPhone);
                    }
                });
        return contactInfoPrepayODRequest;
    }

    private static ServiceHeader getServiceResponseHeader(ContactInfoPrepayODResponse prepayODResponse, ContactInfoRequest request) {
        ServiceHeader serviceHeader = new ServiceHeader();

        if(prepayODResponse.getStatus() == (PrepayAdaptorCartConstants.SUCCESS_CODE)) {
            serviceHeader.setStatusMsg(PrepayAdaptorCartConstants.SUCCESS_MSG);
            serviceHeader.setStatusCode(PrepayAdaptorCartConstants.RESPONSE_SUCCESS_CODE);
        } else {
            serviceHeader.setStatusMsg(PrepayAdaptorCartConstants.FAILURE_MSG);
            serviceHeader.setStatusCode(PrepayAdaptorCartConstants.RESPONSE_FAILURE_CODE);
        }

        serviceHeader.setServiceName(request.getServiceHeader().getServiceName());
        serviceHeader.setUserId(request.getServiceHeader().getUserId());

        serviceHeader.setSessionId(request.getServiceHeader().getSessionId());
        return serviceHeader;
    }

    private static COntactInfoServiceBody getResponseServiceBody(ContactInfoRequest request, PrepaidODRequestData redisData,
                                                                 ContactInfoPrepayODResponse prepayODResponse) {
        COntactInfoServiceBody serviceBody = new COntactInfoServiceBody();
        serviceBody.setServiceResponse(getContactInfoServiceResponse(request, redisData, prepayODResponse));

        return serviceBody;
    }

    private static ContactInfoServiceResponse getContactInfoServiceResponse(ContactInfoRequest request, PrepaidODRequestData redisData, ContactInfoPrepayODResponse prepayODResponse) {
        ContactInfoServiceResponse serviceResponse = new ContactInfoServiceResponse();
        serviceResponse.setContext(getContext(request, redisData, prepayODResponse));

        return serviceResponse;
    }

    private static ContactInfoContext getContext(ContactInfoRequest request, PrepaidODRequestData redisData,
                                                 ContactInfoPrepayODResponse prepayODResponse) {
        ContactInfoContext context = new ContactInfoContext();
        context.setContextInfo(getContextInfo(request));
        context.setCustomerInfo(getCustomerInfo(request,redisData));
        context.setCartInfo(getCartInfo(prepayODResponse));
        ProcessMTNList mtnObj = new ProcessMTNList();
        mtnObj.setMtn((Objects.nonNull(redisData) && Objects.nonNull(redisData.getLines()) && Objects.nonNull(redisData.getLines().get(0)) && Objects.nonNull(redisData.getLines().get(0).getMtn()))?redisData.getLines().get(0).getMtn():PrepayAdaptorCartConstants.DEFAULT_NSE_LINE);
        String[] stepArr = new String[1];
        stepArr[0] = PrepayAdaptorCartConstants.CONTACTINFO;
        mtnObj.setCompletedprocessSteps(Objects.nonNull(redisData)?setCompletedProcessStep(redisData):stepArr);
        List<ProcessMTNList> mtnList = new ArrayList<>();
        mtnList.add(mtnObj);
        context.setProcessMTNList(mtnList);
        return context;
    }

    private static String[] setCompletedProcessStep(PrepaidODRequestData redisData) {

        List<String> stepsList = new ArrayList<>();
        
        if (CollectionUtils.isNotEmpty(redisData.getLines().get(0).getCompletedProcessSteps())) {
            stepsList = redisData.getLines().get(0).getCompletedProcessSteps();
        	logger.debug("Completed Process Steps: {} total steps: {}", stepsList, stepsList.size());
            stepsList.add(PrepayAdaptorCartConstants.CONTACTINFO);
        } stepsList.add(PrepayAdaptorCartConstants.CONTACTINFO);
        List<String> defaultStep = new ArrayList<>();
        defaultStep.add(PrepayAdaptorCartConstants.CONTACTINFO);

        if (CollectionUtilities.isNotEmptyOrNull(stepsList)) {
            return stepsList.toArray(new String[stepsList.size()]);
        } else {
            return defaultStep.toArray(new String[defaultStep.size()]);
        }
    }

    private static ContactInfoCartInfo getCartInfo(ContactInfoPrepayODResponse prepayODResponse) {
        ContactInfoCartInfo cartInfo = new ContactInfoCartInfo();

        if(prepayODResponse.getStatus() == (PrepayAdaptorCartConstants.SUCCESS_CODE)) {
            cartInfo.setStatusMessage(PrepayAdaptorCartConstants.USER_CONTACT_INFO_UPDATE_SUCCESS_MSG);
            cartInfo.setStatusCode(PrepayAdaptorCartConstants.CART_CONTACT_INFO_SUCCESS_CODE);
        } else {
            cartInfo.setStatusMessage(PrepayAdaptorCartConstants.USER_CONTACT_INFO_UPDATE_FAILURE_MSG);
            cartInfo.setStatusCode(PrepayAdaptorCartConstants.CART_CONTACT_INFO_FAILURE_CODE);
        }
        return cartInfo;
    }

    private static ContactInfoCustomerInfo getCustomerInfo(ContactInfoRequest request, PrepaidODRequestData redisData) {
        ContactInfoCustomerInfo customerInfo = new ContactInfoCustomerInfo();
        customerInfo.setAccountNumber(request.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getAccountNumber());
        customerInfo.setCartCreator(request.getServiceHeader().getSessionId());
        customerInfo.setRegisterNumber(request.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getRegisterNumber());
        customerInfo.setProcessingMTN((Objects.nonNull(redisData) && Objects.nonNull(redisData.getLines()) && Objects.nonNull(redisData.getLines().get(0)) && Objects.nonNull(redisData.getLines().get(0).getMtn()))?redisData.getLines().get(0).getMtn():PrepayAdaptorCartConstants.DEFAULT_NSE_LINE);
        customerInfo.setGlobalId(request.getServiceHeader().getSessionId());
        customerInfo.setCustomerType(request.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCustomerType());
        return customerInfo;
    }

    private static ContextInfo getContextInfo(ContactInfoRequest request) {
        ContextInfo contextInfo = new ContextInfo();
        contextInfo.setCallReason(request.getServiceBody().getServiceRequest().getContext().getContextInfo().getCallReason());
        contextInfo.setProcessStep(PrepayAdaptorCartConstants.ASSIGN_NUMBERS);
        contextInfo.setProcessAction("");
        AvailablePaths availablePath = new AvailablePaths();
        availablePath.setPath(PrepayAdaptorCartConstants.ASSIGN_NUMBERS);
        List<AvailablePaths> availablePaths = new ArrayList<>();
        availablePaths.add(availablePath);
        contextInfo.setAvailablePaths(availablePaths);

        return contextInfo;
    }

    public static ContactInfoResponse convertToPEGAResponse(ContactInfoRequest request,
                                                            ContactInfoPrepayODResponse prepayODResponse,
                                                            PrepaidODRequestData redisData) {
        ContactInfoResponse contactInfoResponse = new ContactInfoResponse();

        contactInfoResponse.setServiceHeader(getServiceResponseHeader(prepayODResponse, request));
        contactInfoResponse.setServiceBody(getResponseServiceBody(request, redisData, prepayODResponse));
        return contactInfoResponse;
    }

    public Mono<ResponseEntity<ContactInfoResponse>> updatePersonalInfo(ServerHttpRequest httpRequest, ContactInfoRequest contactInfoUIRequest) {
        return prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)
                .doOnError(err -> logger.error("Failed and return error", err))
                .defaultIfEmpty("")
                .flatMap(response -> {
                    logger.info("PrepaidODRequestData From Redis in updatePersonalInfo service:: {}", response);
                    PrepaidODRequestData prepaidODRequestData = null;
                    ContactInfoResponse contactInfoResp = new ContactInfoResponse();

                    if (StringUtilities.isEmptyOrNull(response)) {
                        logger.error("Failed to get data from redis {}", response);
                        return returnErrorResponse(contactInfoResp);

                    } else {

                        try {
                            prepaidODRequestData = mapper.readValue(response, PrepaidODRequestData.class);
                        } catch (JsonProcessingException e) {
                            logger.error("Failed to parse data from redis:", e);
                            return returnErrorResponse(contactInfoResp);
                        }
                    }
                    //converting prepay request to prepay OD request
                    ContactInfoPrepayODRequest contactInfoPrepayODRequest = convertToPrepayODRequest(contactInfoUIRequest);
                    String flow = Objects.nonNull(prepaidODRequestData) && CollectionUtilities.isNotEmptyOrNull(prepaidODRequestData.getLines())?prepaidODRequestData.getLines().get(prepaidODRequestData.getCurr_line()-1).getFlow():NSE;
                    /*String intendType = Objects.nonNull(contactInfoUIRequest) && Objects.nonNull(contactInfoUIRequest.getServiceBody()) 
                    		&& Objects.nonNull(contactInfoUIRequest.getServiceBody().getServiceRequest()) 
                    		&& Objects.nonNull(contactInfoUIRequest.getServiceBody().getServiceRequest().getContext())
                    		&& Objects.nonNull(contactInfoUIRequest.getServiceBody().getServiceRequest().getContext().getCartInfo())?contactInfoUIRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType():PrepayAdaptorCartConstants.NSE;
                    */
                    //preparing webclient to make prepayod call
                   //intendType = NSE;  // Setting to NSE as play is giving invalid address when we pass NSP for BYOD - check with BAU team
                   PrepaidAdaptorWebClientRequest prepaidLegacyServiceRequest = getPrepaidLegacyServiceRequest(contactInfoPrepayODRequest, prepaidODRequestData, flow);
                    //make prepay od call
                    return updatePersonalInfo(httpRequest, prepaidLegacyServiceRequest, contactInfoUIRequest, prepaidODRequestData);

                });
    }

    private Mono<ResponseEntity<ContactInfoResponse>> updatePersonalInfo(ServerHttpRequest httpRequest,
                                                                         PrepaidAdaptorWebClientRequest prepaidLegacyServiceRequest,
                                                                         ContactInfoRequest contactInfoUIRequest, PrepaidODRequestData redisData) {
        //actual prepay OD call in place
    	logger.info("Update Personal Info OD call Request Endpoint: {} \n Request Body: {} \n Request Headers: {}",prepaidLegacyServiceRequest.getUrl(), prepaidLegacyServiceRequest.getRequestBody(), prepaidLegacyServiceRequest.getHeader());
        return prepayBusinessCartWebclient.getPrepayServiceResponse(httpRequest, prepaidLegacyServiceRequest)
                .doOnError(error -> logger.error("Failed to get response from Update Personal Info OD Call: {0}", error))
                .flatMap(responseEntity -> {
                    ContactInfoResponse finalContactInfoPEGAResponse = new ContactInfoResponse();
                    ContactInfoPrepayODResponse prepayODResponse = new ContactInfoPrepayODResponse();
                    logger.info("Successful response from api: {}", prepaidLegacyServiceRequest.getUrl());
                    logger.info("Play response status code: {} \n Play response body: {}", responseEntity.getStatusCode(),responseEntity.getBody());

                    try {
                        if (!responseEntity.getStatusCode().is2xxSuccessful()) {
                            logger.error("Error while calling endpoint: {} with status code: {}",prepaidLegacyServiceRequest.getUrl(), responseEntity.getStatusCode());
                            // return error response
                            List<Error> errResp = PrepayAdaptorCartUtil.buildErrorResponse(PERSONALINFO_SYSTEM_ERROR_NAME, prepayODResponse.getStatusCode(), PERSONALINFO_SYSTEM_ERROR_MSG, PERSONALINFO_INVALID_ADDRESS_CATEGORY);
                            finalContactInfoPEGAResponse.setErrors(errResp);
                            return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(finalContactInfoPEGAResponse));
                        } else {
                            // check the error message in the body and build error response if error code exists
                            String responseString = responseEntity.getBody();
                            prepayODResponse = mapper.readValue(responseString, ContactInfoPrepayODResponse.class);
                            logger.info("Update Personal Info OD service response : {}", mapper.writeValueAsString(prepayODResponse));

                            if (null != prepayODResponse) {
                                if((prepayODResponse.getStatus().intValue() != 200 || prepayODResponse.getStatusCode().equalsIgnoreCase(RESPONSE_SUCCESS_CODE)) && null != prepayODResponse.getErrors()) {
                                    List<Error> errResp = PrepayAdaptorCartUtil.buildErrorResponse(PERSONALINFO_INVALID_ADDRESS_NAME, PERSONALINFO_INVALID_ADDRESS_ID, prepayODResponse.getErrors().getEcommApiErrorList().get(0).getMessage(), PERSONALINFO_INVALID_ADDRESS_CATEGORY);
                                    finalContactInfoPEGAResponse.setErrors(errResp);
                                    return Mono.just(ResponseEntity.status(HttpStatus.OK).body(finalContactInfoPEGAResponse));
                                }
                                //convert play response to prepay response
                                
                                if(Objects.nonNull(contactInfoUIRequest) && Objects.nonNull(contactInfoUIRequest.getServiceBody()) && Objects.nonNull(contactInfoUIRequest.getServiceBody().getServiceRequest())
                                		&& Objects.nonNull(contactInfoUIRequest.getServiceBody().getServiceRequest().getContext()) && Objects.nonNull(contactInfoUIRequest.getServiceBody().getServiceRequest().getContext().getCartInfo()) 
                                		&& Objects.nonNull(contactInfoUIRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()) && Objects.nonNull(contactInfoUIRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0))) {
                                	if(Objects.nonNull(contactInfoUIRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).getFirstName())) {
                                		redisData.setFirstName(contactInfoUIRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).getFirstName());
                                	}
                                	if(Objects.nonNull(contactInfoUIRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).getLastName())) {
                                		redisData.setLastName(contactInfoUIRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).getLastName());
                                	}
                                	if(Objects.nonNull(contactInfoUIRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).getContactNumber())) {
                                		redisData.setContactNumber(contactInfoUIRequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines().get(0).getContactNumber());
                                	}
                                }
                                		
                                return updateRedisWithPortInInfo(contactInfoUIRequest, redisData, responseEntity,
										prepayODResponse);
                  
                            } else {
                                logger.info("No Response returned");
                            }
                            logger.info(responseEntity.getBody());
                                                  
                            return Mono.just(ResponseEntity.status(responseEntity.getStatusCode()).body(finalContactInfoPEGAResponse));
                        }
                    } catch (JsonMappingException e) {
                        logger.error("Json Mapping Exception: {}", e.getMessage());
                        return returnErrorResponse(finalContactInfoPEGAResponse);
                    } catch (JsonProcessingException e) {
                        logger.error("Json Processing Exception: {}", e.getMessage());
                        return returnErrorResponse(finalContactInfoPEGAResponse);
                    }
                });
    }

	private Mono<? extends ResponseEntity<ContactInfoResponse>> updateRedisWithPortInInfo(
			ContactInfoRequest contactInfoUIRequest, PrepaidODRequestData redisData,
			ResponseEntity<String> responseEntity, ContactInfoPrepayODResponse prepayODResponse) {
		return prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, redisData)
			  .doOnError(err -> logger.error("Failed to update the PrepaidODRequestData to Redis", err))
			  .flatMap(upsertResp -> 
			  {
				  logger.info("Successfully inserted updated Redis Data: {}",upsertResp);
				ContactInfoResponse finalContactInfoPEGAResp = convertToPEGAResponse(contactInfoUIRequest, prepayODResponse, redisData);
				  return Mono.just(ResponseEntity.status(responseEntity.getStatusCode()).body(finalContactInfoPEGAResp));
			  });
	}

    private Mono<? extends ResponseEntity<ContactInfoResponse>> returnErrorResponse(
            ContactInfoResponse finalContactInfoPEGAResponse) {
        List<Error> errResp = PrepayAdaptorCartUtil.buildErrorResponse(PERSONALINFO_SYSTEM_ERROR_NAME, PERSONALINFO_SYSTEM_ERROR_ID, PERSONALINFO_SYSTEM_ERROR_MSG, PERSONALINFO_INVALID_ADDRESS_CATEGORY);
        finalContactInfoPEGAResponse.setErrors(errResp);
        return Mono.just(ResponseEntity.status(HttpStatus.OK).body(finalContactInfoPEGAResponse));
    }

    private PrepaidAdaptorWebClientRequest getPrepaidLegacyServiceRequest(ContactInfoPrepayODRequest contactInfoPrepayODRequest,
                                                                          PrepaidODRequestData prepaidODRequestData, String flow) {
        PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
        prepaidAdaptorWebClientRequest.setUrl(contactInfoPrepaidLegacyServiceUrl);
        prepaidAdaptorWebClientRequest.setRequestBody(contactInfoPrepayODRequest);
        prepaidAdaptorWebClientRequest.setRequestType(HttpMethod.POST.toString());
        prepaidAdaptorWebClientRequest.setHeader(PrepayAdaptorCartUtil.getPrepayODServiceCommonHeaders(prepaidODRequestData, flow));
        return prepaidAdaptorWebClientRequest;
    }


}
