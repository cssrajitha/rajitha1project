package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class PricingDetails implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private String pricingAdjustmentId;
	
	private String itemId;
	
	private String orderId;
	
	private String offerId;
	
	private Double offerAmount;
	
	private String description;
	
	private String offerType;
	
	private String priceListId;
	
	private Double listPrice;
	
	private String offerName;
	
	private Date creationDate;
	
	private Date lastModifiedDate;
	
	private int version;

	private Integer bicNoOfdelays;

	private List<PromoBadgeMessage> promoBadgeMessages;

	public List<PromoBadgeMessage> getPromoBadgeMessages() {
		return promoBadgeMessages;
	}

	public void setPromoBadgeMessages(List<PromoBadgeMessage> promoBadgeMessages) {
		this.promoBadgeMessages = promoBadgeMessages;
	}

	private boolean applied = true;
	
	public String getOfferId() {
		return offerId;
	}
	
	public void setOfferId(String offerId) {
		this.offerId = offerId;
	}

	public Double getOfferAmount() {
		if(offerAmount != null){
			return offerAmount;
		}else{
			return 0.00D;
		}
	}

	public void setOfferAmount(Double offerAmount) {
		this.offerAmount = offerAmount;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getOfferType() {
		return offerType;
	}

	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}
	public String getPriceListId() {
		return priceListId;
	}
	public void setPriceListId(String priceListId) {
		this.priceListId = priceListId;
	}
	public Double getListPrice() {
		if(listPrice != null){
			return listPrice;
		}else{
			return 0.00D;
		}
	}

	public void setListPrice(Double listPrice) {
		this.listPrice = listPrice;
	}
	public String getOfferName() {
		return offerName;
	}
	public void setOfferName(String offerName) {
		this.offerName = offerName;
	}

	public String getPricingAdjustmentId() {
		return pricingAdjustmentId;
	}

	public void setPricingAdjustmentId(String pricingAdjustmentId) {
		this.pricingAdjustmentId = pricingAdjustmentId;
	}

	public int getVersion() {
		return version;
	}

	public void updateVersion() {
		this.version += 1;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public boolean isApplied() {return applied;	}

	public void setApplied(boolean applied) {this.applied = applied;}

	public Integer getBicNoOfdelays() {
		if(this.bicNoOfdelays != null){
			return bicNoOfdelays;
		}else{
			return 0;
		}
	}

	public void setBicNoOfdelays(Integer bicNoOfdelays) {
		this.bicNoOfdelays = bicNoOfdelays;
	}
}
