package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;

public class CashPayment extends PaymentGroup implements Serializable {
    private static final long serialVersionUID = -559007903627077409L;

    String paymentAmount;
    Boolean cashPayment;
    String cashChangeDue;
    String paymentType;

    public Boolean getCashPayment() {
        return cashPayment;
    }

    public void setCashPayment(Boolean cashPayment) {
        this.cashPayment = cashPayment;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public String getPaymentAmount() {
        return paymentAmount;
    }

    public void setPaymentAmount(String paymentAmount) {
        this.paymentAmount = paymentAmount;
    }



    public String getCashChangeDue() {
        return cashChangeDue;
    }

    public void setCashChangeDue(String cashChangeDue) {
        this.cashChangeDue = cashChangeDue;
    }
}
