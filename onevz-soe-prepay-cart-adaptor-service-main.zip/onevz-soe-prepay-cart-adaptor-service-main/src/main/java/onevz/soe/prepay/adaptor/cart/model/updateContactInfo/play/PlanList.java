package onevz.soe.prepay.adaptor.cart.model.updateContactInfo.play;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PlanList {
    private String dueMonthly;

    private String eligibleForDoubleData;

    private String loyalityDiscountsEnabled;

    private TaxDetailList taxDetails;

    private String mobileHotspotEnabled;

    private String discount;

    private String description;

    private String title;

    private String autoPayToolTip;

    private String totalDueMonthly;

    private String autoPaySaving;

    private String featureLineItemId;

    private String sorId;

    private String id;

    private String skuId;

    private String productId;

    private String fourthLinePromoDiscount;

    private String planSize;

    private String accountOwner;

    private String discountApplied;

    private Promotions promotions;

    private String planDueMonthly;

    private String dueToday;

    private String bonusData;

    private String actualPlanPrice;

    private String itemTax;

    private String skuDisplayName;

    private String totalDueToday;

}
			
			