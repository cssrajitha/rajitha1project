package onevz.soe.prepay.adaptor.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.requests.SwitchSimCXPRequest;
import onevz.soe.cart.requests.SwitchSimCXPRequestData;
import onevz.soe.cart.responses.SwitchSimCXPResponse;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.common.model.PrepaidODRequestDataLines;
import onevz.soe.od.error.EcommApiError;
import onevz.soe.od.error.EcommValidationError;
import onevz.soe.prepay.adaptor.cart.model.cart.vo.VZWPrepayEditCartRequest;
import onevz.soe.prepay.adaptor.cart.model.cart.vo.VZWPrepayEditCartResponse;
import onevz.soe.prepay.adaptor.cart.model.cart.vo.VZWPrepayEditCartResponsePageData;
import onevz.soe.prepay.adaptor.cart.util.PrepayAdaptorCartUtil;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import onevz.soe.wsclient.prepay.webclient.model.PrepaidAdaptorWebClientRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.*;

@Service
public class PrepayAdaptorCartSwitchSimHelper {


	@Autowired
	private ObjectMapper mapper;

	@Autowired
	private PrepayAdaptorWebClient prepayBusinessCartWebclient;

	@Autowired
	private PrepayAdaptorWebClient prepayAdaptorWebClient;

	@Autowired
	PrepayCartRedisHelper prepayCartRedisHelper;

	@Value("${playPrepaidEditCart}")
	private String prepaidODeditCartUrl;

	private static final Logger logger = LoggerFactory.getLogger(PrepayAdaptorCartSwitchSimHelper.class);

	public Mono<ResponseEntity<SwitchSimCXPResponse>> switchSim(ServerHttpRequest httpRequest, SwitchSimCXPRequest switchSimCXPRequest){
		return prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)
				.doOnError(err -> logger.error(ERR_MSG_REDIS_FAILED, err))
				.defaultIfEmpty("")
				.flatMap(response -> {
					if (StringUtilities.isNotEmptyOrNull(response)) {
						logger.info("Redis Data From Redis:: {}", response);
						PrepaidODRequestData redisData = null;
						try {
							redisData = mapper.readValue(response, PrepaidODRequestData.class);
						} catch (JsonProcessingException e) {
							logger.error(ERR_MSG_REDIS_FAILED_PARSING, e);
							return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(buildSwitchSimMiscErrorResponse(ERR_MSG_REDIS_FAILED_PARSING)));
						}
						//mtn validation
						String mtnFromReq = Optional.ofNullable(switchSimCXPRequest.getData()).map(data-> data.getMtn()).orElse("");
						boolean mtnMatchFound = StringUtilities.isNotEmptyOrNull(mtnFromReq)? Optional.ofNullable(redisData.getLines()).orElse(new ArrayList<>())
								.stream().filter(prepaidODRequestDataLine -> mtnFromReq.equalsIgnoreCase(prepaidODRequestDataLine.getMtn())).collect(Collectors.counting())>0 : false;
						if(redisData.getCurr_line()<0 || !mtnMatchFound){
							logger.error("Invalid mtn {}", mtnFromReq);
							return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(buildSwitchSimMiscErrorResponse(ERR_MSG_VALIDATION_ERROR_MTN)));
						}
						//Preparing the OD request
						VZWPrepayEditCartRequest editCartODRequest = new VZWPrepayEditCartRequest();
						SwitchSimCXPRequestData switchSimCXPRequestData  = (null != switchSimCXPRequest.getData())? switchSimCXPRequest.getData():new SwitchSimCXPRequestData();
						PrepaidODRequestDataLines switchSimLine = Optional.ofNullable(redisData.getLines()).orElse(new ArrayList<>())
								.stream().filter(prepaidODRequestDataLine -> switchSimCXPRequest.getData().getMtn().equalsIgnoreCase(prepaidODRequestDataLine.getMtn())).findFirst().orElse(new PrepaidODRequestDataLines());
						String simIdFromRedis = switchSimLine.getSimId();
						String eSimIdFromRedis = switchSimLine.getESimId();
						String lineItemIdFromRedis = switchSimLine.getLineItemId();
						String flow = switchSimLine.getFlow();
						boolean isESimOnlyFlag = switchSimLine.isESimOnly();
						editCartODRequest.setLineItemId(lineItemIdFromRedis);
						if(isESimOnlyFlag){
							logger.error("SwitchSim can't be invoked for the ESIM only devices {}", mtnFromReq);
							return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(buildSwitchSimMiscErrorResponse(ERR_MSG_SWITCHSIM_ESIMONLY)));
						}

						if(StringUtilities.isEmptyOrNull(simIdFromRedis) && StringUtilities.isEmptyOrNull(eSimIdFromRedis)){  // Free Vz Sim
							if(SWITCHSIM_OD_SIMTYPE_PSIM.equalsIgnoreCase(switchSimCXPRequestData.getSimType())){
								editCartODRequest.setSimType(SWITCHSIM_OD_SIMTYPE_PSIM);
								editCartODRequest.setSimId(switchSimCXPRequestData.getSimId());
							}else if(SWITCHSIM_OD_SIMTYPE_ESIM.equalsIgnoreCase(switchSimCXPRequestData.getSimType())){
								if(switchSimCXPRequestData.isSmartImeiDevice()){
									logger.error("SwitchSim can't be invoked for the smartIMEI flow");
									return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(buildSwitchSimMiscErrorResponse(ERR_MSG_SWITCHSIM_SMARTIMEI_ESIM_NOT_ALLOWED)));
								}
								editCartODRequest.setSimType(SWITCHSIM_OD_SIMTYPE_ESIM);
							} else {
								logger.error("SwitchSim can't be invoked for the inputs provided, {}, {}, {}, {}", switchSimCXPRequestData.getSimType(), switchSimCXPRequestData.getSimId(), switchSimCXPRequestData.getESimId(), switchSimCXPRequestData.getMtn());
								return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(buildSwitchSimMiscErrorResponse(ERR_MSG_SWITCHSIM_INVALID_INPUTS)));
							}
						}else if(StringUtilities.isNotEmptyOrNull(simIdFromRedis)){   // I have psim
							if(SWITCHSIM_OD_SIMTYPE_VZSIM.equalsIgnoreCase(switchSimCXPRequestData.getSimType())
									&& StringUtilities.isEmptyOrNull(switchSimCXPRequestData.getSimId())){
								editCartODRequest.setSimType(SWITCHSIM_OD_SIMTYPE_PSIM);
							}else if(SWITCHSIM_OD_SIMTYPE_ESIM.equalsIgnoreCase(switchSimCXPRequestData.getSimType())
									&& StringUtilities.isNotEmptyOrNull(switchSimCXPRequestData.getESimId())){
								if(switchSimCXPRequestData.isSmartImeiDevice()){
									logger.error("SwitchSim can't be invoked for the smartIMEI flow");
									return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(buildSwitchSimMiscErrorResponse(ERR_MSG_SWITCHSIM_SMARTIMEI_ESIM_NOT_ALLOWED)));
								}
								editCartODRequest.setSimType(SWITCHSIM_OD_SIMTYPE_ESIM);
							}else if (SWITCHSIM_OD_SIMTYPE_PSIM.equalsIgnoreCase(switchSimCXPRequestData.getSimType())){
								editCartODRequest.setSimType(SWITCHSIM_OD_SIMTYPE_PSIM);
							} else {
								logger.error("SwitchSim can't be invoked for the inputs provided, {}, {}, {}, {}", switchSimCXPRequestData.getSimType(), switchSimCXPRequestData.getSimId(), switchSimCXPRequestData.getESimId(), switchSimCXPRequestData.getMtn());
								return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(buildSwitchSimMiscErrorResponse(ERR_MSG_SWITCHSIM_INVALID_INPUTS)));
							}
						}else if(StringUtilities.isNotEmptyOrNull(eSimIdFromRedis)){    // eSim scenario
							if(SWITCHSIM_OD_SIMTYPE_PSIM.equalsIgnoreCase(switchSimCXPRequestData.getSimType())
									&& StringUtilities.isNotEmptyOrNull(switchSimCXPRequestData.getSimId())) {
								editCartODRequest.setSimType(SWITCHSIM_OD_SIMTYPE_PSIM);
								editCartODRequest.setSimId(switchSimCXPRequestData.getSimId());
							} else if(SWITCHSIM_OD_SIMTYPE_VZSIM.equalsIgnoreCase(switchSimCXPRequestData.getSimType())
									&& StringUtilities.isEmptyOrNull(switchSimCXPRequestData.getSimId())){
								editCartODRequest.setSimType(SWITCHSIM_OD_SIMTYPE_PSIM);
							} else if(SWITCHSIM_OD_SIMTYPE_PSIM.equalsIgnoreCase(switchSimCXPRequestData.getSimType())
									&& StringUtilities.isEmptyOrNull(switchSimCXPRequestData.getSimId())){
								editCartODRequest.setSimType(SWITCHSIM_OD_SIMTYPE_PSIM);
							} else {
								logger.error("SwitchSim can't be invoked when ESIM is already in cart, inputs, {}, {}, {}, {}", switchSimCXPRequestData.getSimType(), switchSimCXPRequestData.getSimId(), switchSimCXPRequestData.getESimId(), switchSimCXPRequestData.getMtn());
								return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(buildSwitchSimMiscErrorResponse(ERR_MSG_SWITCHSIM_FROM_ESIM_NOT_ALLOWED)));
							}
						}
						PrepaidAdaptorWebClientRequest prepaidLegacyServiceRequest = getPrepaidLegacyServiceRequestForSwitchSim(switchSimCXPRequest, redisData, editCartODRequest,flow);
						if(Objects.isNull(prepaidLegacyServiceRequest)){
							logger.error("SwitchSim can't be invoked .. misc error, inputs, {}, {}, {}, {}", switchSimCXPRequestData.getSimType(), switchSimCXPRequestData.getSimId(), switchSimCXPRequestData.getESimId(), switchSimCXPRequestData.getMtn());
							return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(buildSwitchSimMiscErrorResponse(ERR_MSG_SWITCHSIM_MISC_ERROR)));
						}
						PrepaidODRequestData updatedRedisData = redisData;
						return prepayAdaptorWebClient.getPrepayServiceResponse(httpRequest, prepaidLegacyServiceRequest)
								.doOnError(error -> logger.error("Failed to get response, check exception for details.", error))
								.flatMap(responseEntity -> {
									SwitchSimCXPResponse switchSimCXPResponse = null;
									VZWPrepayEditCartResponse vzwPrepayEditCartResponse = null;
									try {
										vzwPrepayEditCartResponse = mapper.readValue(responseEntity.getBody(), VZWPrepayEditCartResponse.class);
										if (!responseEntity.getStatusCode().is2xxSuccessful()) {
											logger.error("Error while calling endpoint: {} with status code: {}", prepaidLegacyServiceRequest.getUrl(), responseEntity.getStatusCode());
											switchSimCXPResponse = buildSwitchSimErrorResponse(vzwPrepayEditCartResponse);
										} else {
											if(!"ok".equalsIgnoreCase(vzwPrepayEditCartResponse.getStatus())){
												switchSimCXPResponse = buildSwitchSimErrorResponse(vzwPrepayEditCartResponse);
												return Mono.just(ResponseEntity.status(responseEntity.getStatusCode()).body(switchSimCXPResponse));
											}
											switchSimCXPResponse = buildSwitchSimResponse(vzwPrepayEditCartResponse);
											//update redisdata with latest simcard information in line (eSIM should be already there)
											SwitchSimCXPResponse finalSwitchSimCXPResponse = switchSimCXPResponse;
											PrepaidODRequestDataLines lineToUpdate = Optional.ofNullable(updatedRedisData.getLines()).orElse(new ArrayList<>())
													.stream().filter(prepaidODRequestDataLine -> switchSimCXPRequest.getData().getMtn().equalsIgnoreCase(prepaidODRequestDataLine.getMtn())).findFirst().orElse(new PrepaidODRequestDataLines());
											if(SWITCHSIM_OD_SIMTYPE_PSIM.equalsIgnoreCase(switchSimCXPRequest.getData().getSimType())) {
												lineToUpdate.setSimId(switchSimCXPRequest.getData().getSimId());  // Update esim & vzsim
												lineToUpdate.setESimId(null);
											} else if(SWITCHSIM_OD_SIMTYPE_ESIM.equalsIgnoreCase(switchSimCXPRequest.getData().getSimType())) {
												lineToUpdate.setESimId(switchSimCXPRequest.getData().getESimId());
												lineToUpdate.setESimEnabledDevice(true);
												lineToUpdate.setSimId(null);
											}
											if (Objects.nonNull(switchSimCXPResponse)) {
												return prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, updatedRedisData)
														.doOnError(err -> logger.error("Failed to update redis and return error", err))
														.flatMap(redisUpdateResp -> {
															logger.info("PrepaidODRequestData From Redis is updated:: {}", redisUpdateResp);
															return Mono.just(ResponseEntity.status(responseEntity.getStatusCode()).body(finalSwitchSimCXPResponse));
														});
											}
										}
										return Mono.just(ResponseEntity.status(responseEntity.getStatusCode()).body(switchSimCXPResponse));
									}catch (Exception ex){
										logger.error("Error while processing, calling endpoint: {} with status code: {}", prepaidLegacyServiceRequest.getUrl(), responseEntity.getStatusCode());
										return Mono.just(ResponseEntity.status(responseEntity.getStatusCode()).body(switchSimCXPResponse));
									}
								});
					} else {
						logger.error(ERR_MSG_REDIS_FAILED_EMPTY);
						return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(buildSwitchSimMiscErrorResponse(ERR_MSG_REDIS_FAILED_EMPTY)));
					}
				});
	}

	private PrepaidAdaptorWebClientRequest getPrepaidLegacyServiceRequestForSwitchSim(SwitchSimCXPRequest request, PrepaidODRequestData prepaidODRequestData, VZWPrepayEditCartRequest editCartODRequest, String flow) {
		if(Objects.isNull(editCartODRequest)) return null;
		PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
		SwitchSimCXPRequestData switchSimCXPRequestData  = (null != request.getData())? request.getData():new SwitchSimCXPRequestData();
		logger.info("Switch SIM CXP Request Data: {}",switchSimCXPRequestData);
		editCartODRequest.setEditFlowName(SWITCHSIM_OD_EDIT_FLOW_NAME);
		prepaidAdaptorWebClientRequest.setUrl(prepaidODeditCartUrl);
		prepaidAdaptorWebClientRequest.setRequestType(HttpMethod.POST.toString());
		prepaidAdaptorWebClientRequest.setHeader(PrepayAdaptorCartUtil.getPrepayODServiceCommonHeaders(prepaidODRequestData,flow));
		prepaidAdaptorWebClientRequest.setRequestBody(editCartODRequest);
		return prepaidAdaptorWebClientRequest;
	}

	private SwitchSimCXPResponse buildSwitchSimResponse(VZWPrepayEditCartResponse vzwPrepayEditCartResponse){
		SwitchSimCXPResponse switchSimCXPResponse = new SwitchSimCXPResponse();
		if(Objects.nonNull(vzwPrepayEditCartResponse)){
			switchSimCXPResponse.setStatus(vzwPrepayEditCartResponse.getStatus());
			VZWPrepayEditCartResponsePageData pageData = Objects.nonNull(vzwPrepayEditCartResponse.getPayload())?vzwPrepayEditCartResponse.getPayload().getPageData():null;
			if(Objects.nonNull(pageData)){
				switchSimCXPResponse.setStatusCode(pageData.getStatus());
			}
			//Not populating the errors
		}
		return switchSimCXPResponse;
	}

	private SwitchSimCXPResponse buildSwitchSimErrorResponse(VZWPrepayEditCartResponse errorResponse){
		SwitchSimCXPResponse switchSimCXPResponse = new SwitchSimCXPResponse();
		Optional.ofNullable(errorResponse.getPayload().getPageData())
				.map(errResp->Optional.ofNullable(errResp.getErrors()).orElse(new EcommValidationError()))
				.map(ecommValidationError -> Optional.ofNullable(ecommValidationError.getEcommApiErrorList()).orElse(new ArrayList<EcommApiError>()))
				.ifPresent(ecommApiErrors -> {
					//iterate over apierrors and form the cxprespon
					List<CartError> errorResponseList = new ArrayList<>();
					ecommApiErrors.stream().forEach(ecommApiError -> {
						CartError cartError = new CartError();
						cartError.setName(SWITCHSIM_FAILURE_NAME);
						cartError.setId(ecommApiError.getStatusCode());
						cartError.setCode(ecommApiError.getStatusCode());
						cartError.setMessage(ecommApiError.getMessage());
						cartError.setErrorCategory(SWITCHSIM_FAILURE_SYSTEM);
						errorResponseList.add(cartError);
					});
					switchSimCXPResponse.setErrors(errorResponseList);
				});
		return switchSimCXPResponse;
	}

	private SwitchSimCXPResponse buildSwitchSimMiscErrorResponse(String errorMsg){
		SwitchSimCXPResponse switchSimCXPResponse = new SwitchSimCXPResponse();
		List<CartError> errorResponseList = new ArrayList<>();
		CartError cartError = new CartError();
		cartError.setName(SWITCHSIM_FAILURE_NAME);
		cartError.setMessage(errorMsg);
		cartError.setCode("01");
		cartError.setErrorCategory(SWITCHSIM_FAILURE_SYSTEM);
		errorResponseList.add(cartError);
		switchSimCXPResponse.setErrors(errorResponseList);
		switchSimCXPResponse.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
		return switchSimCXPResponse;
	}

}
