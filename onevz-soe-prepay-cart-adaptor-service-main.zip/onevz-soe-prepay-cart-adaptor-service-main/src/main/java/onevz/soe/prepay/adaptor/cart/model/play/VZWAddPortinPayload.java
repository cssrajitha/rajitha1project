package onevz.soe.prepay.adaptor.cart.model.play;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class VZWAddPortinPayload implements Serializable {
    private VZWAddPortinPageData pageData;

    public VZWAddPortinPageData getPageData() {
        return pageData;
    }

    public void setPageData(VZWAddPortinPageData pageData) {
        this.pageData = pageData;
    }

}
