package onevz.soe.prepay.adaptor.cart.model.shippingoptions;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.Data;

import java.util.List;

/**
 * Cart may include multi lines for upgrade/add a line/accessories/ all.
 * Each line will be associated with shipping option selected by customer.
 */
@Data
@JsonInclude(Include.NON_NULL)
public class Lines {

    private String multiLineSeqNumber;
    private String purchasePath;
    private String selectedOptionCode;
    private Boolean ispuEligible;
    private Boolean sddEligible;
    private Boolean addressChangeRequired;
    private Boolean showISPUErrorMessage;
    private Boolean showSDDErrorMessage;
    private String addressChangeRsnCode;
    private List<ShippingOptions> shippingOptions;
    private String sddSetupIncluded;
}
