package onevz.soe.prepay.adaptor.cart.model.play;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TransferNumberDetail {
    private boolean transferNumberSuccess;
    private String updatedNpaNxxNumber;
    private String deviceLineItemId;

    public boolean isTransferNumberSuccess() {
        return transferNumberSuccess;
    }

    public void setTransferNumberSuccess(boolean transferNumberSuccess) {
        this.transferNumberSuccess = transferNumberSuccess;
    }

    public String getUpdatedNpaNxxNumber() {
        return updatedNpaNxxNumber;
    }

    public void setUpdatedNpaNxxNumber(String updatedNpaNxxNumber) {
        this.updatedNpaNxxNumber = updatedNpaNxxNumber;
    }

    public String getDeviceLineItemId() {
        return deviceLineItemId;
    }

    public void setDeviceLineItemId(String deviceLineItemId) {
        this.deviceLineItemId = deviceLineItemId;
    }

}
