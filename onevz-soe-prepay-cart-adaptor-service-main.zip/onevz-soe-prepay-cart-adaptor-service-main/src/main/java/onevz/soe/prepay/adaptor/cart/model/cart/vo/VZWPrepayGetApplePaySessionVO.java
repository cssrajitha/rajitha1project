package onevz.soe.prepay.adaptor.cart.model.cart.vo;


public class VZWPrepayGetApplePaySessionVO {
	private String displayName;
	private String domainName;
	private String epochTimestamp;
	private String signature;
	private String merchantSessionIdentifier;
	private String nonce;
	private String merchantIdentifier;

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getDomainName() {
		return domainName;
	}

	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	public String getEpochTimestamp() {
		return epochTimestamp;
	}

	public void setEpochTimestamp(String epochTimestamp) {
		this.epochTimestamp = epochTimestamp;
	}

	public String getSignature() {
		return signature;
	}

	public void setSignature(String signature) {
		this.signature = signature;
	}

	public String getMerchantSessionIdentifier() {
		return merchantSessionIdentifier;
	}

	public void setMerchantSessionIdentifier(String merchantSessionIdentifier) {
		this.merchantSessionIdentifier = merchantSessionIdentifier;
	}

	public String getNonce() {
		return nonce;
	}

	public void setNonce(String nonce) {
		this.nonce = nonce;
	}

	public String getMerchantIdentifier() {
		return merchantIdentifier;
	}

	public void setMerchantIdentifier(String merchantIdentifier) {
		this.merchantIdentifier = merchantIdentifier;
	}

}
