package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;

public class AutoPayInfo implements Serializable {

    private String id;
    private boolean checkingAccountSelected;
    private ACHInfo checkingAccount;
    private VZWCreditCardInfoVO debitCardInfo;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public boolean isCheckingAccountSelected() {
        return checkingAccountSelected;
    }

    public void setCheckingAccountSelected(boolean checkingAccountSelected) {
        this.checkingAccountSelected = checkingAccountSelected;
    }

    public ACHInfo getCheckingAccount() {
        return checkingAccount;
    }

    public void setCheckingAccount(ACHInfo checkingAccount) {
        this.checkingAccount = checkingAccount;
    }

    public VZWCreditCardInfoVO getDebitCardInfo() {
        return debitCardInfo;
    }

    public void setDebitCardInfo(VZWCreditCardInfoVO debitCardInfo) {
        this.debitCardInfo = debitCardInfo;
    }

}
