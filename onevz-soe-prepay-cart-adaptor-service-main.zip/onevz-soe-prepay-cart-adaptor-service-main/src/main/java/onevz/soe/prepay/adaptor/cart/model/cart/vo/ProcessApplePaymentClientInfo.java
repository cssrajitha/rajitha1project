package onevz.soe.prepay.adaptor.cart.model.cart.vo;

/**
 * Created by w638278 on 1/17/2018.
 */
public class ProcessApplePaymentClientInfo {

    String clientId;
    String userId;
    String pwd;

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }
}
