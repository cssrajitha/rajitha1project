package onevz.soe.prepay.adaptor.cart.model.cart.vo;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class PrepayPlanVO implements Serializable {
    private static final long serialVersionUID = 1L;

    private String id;
    private String skuId;
    private String productId;
    private String sorId;
    private double dueMonthly;
    private double dueToday;
    private String skuDisplayName;
    private double itemTax;
    private double discount;
    private String planSize;
    private String description;
    private String featureLineItemId;
    private String title ;
    private double fourthLinePromoDiscount;
    private double autoPaySaving;
    private Map<String, Double> promotions;
    private String bonusData;
    private boolean eligibleForDoubleData;
    private double totalDueMonthly;
    private double totalDueToday;
    private double planDueMonthly;
    private double actualPlanPrice;
    private boolean isDiscountApplied;
    private boolean disneyPlusPromo;
    private double planBundleDiscount;
    private boolean bundleDiscountApplied;

    public boolean isBundleDiscountApplied() {
        return bundleDiscountApplied;
    }

    public void setBundleDiscountApplied(boolean bundleDiscountApplied) {
        this.bundleDiscountApplied = bundleDiscountApplied;
    }

    public double getPlanBundleDiscount() {
        return planBundleDiscount;
    }

    public void setPlanBundleDiscount(double planBundleDiscount) {
        this.planBundleDiscount = planBundleDiscount;
    }


    public boolean isDisneyPlusPromo() {
        return disneyPlusPromo;
    }

    public void setDisneyPlusPromo(boolean disneyPlusPromo) {
        this.disneyPlusPromo = disneyPlusPromo;
    }
    public boolean isAccountOwner() {
        return accountOwner;
    }

    public void setAccountOwner(boolean accountOwner) {
        this.accountOwner = accountOwner;
    }

    private boolean accountOwner;

    private boolean loyalityDiscountsEnabled;

    private boolean mobileHotspotEnabled;

    public boolean isLoyalityDiscountsEnabled() { return loyalityDiscountsEnabled; }

    public void setLoyalityDiscountsEnabled(boolean loyalityDiscountsEnabled) { this.loyalityDiscountsEnabled = loyalityDiscountsEnabled; }

    public boolean isMobileHotspotEnabled() { return mobileHotspotEnabled; }

    public void setMobileHotspotEnabled(boolean mobileHotspotEnabled) { this.mobileHotspotEnabled = mobileHotspotEnabled; }

	private AutopayTooltip autoPayToolTip;

    public AutopayTooltip getAutoPayToolTip() {
        return autoPayToolTip;
    }

    public void setAutoPayToolTip(AutopayTooltip autoPayToolTip) {
        this.autoPayToolTip = autoPayToolTip;
    }
	
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    private HashMap<String,Double> taxDetails;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSkuId() {
        return skuId;
    }

    public void setSkuId(String skuId) {
        this.skuId = skuId;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getSorId() {
        return sorId;
    }

    public void setSorId(String sorId) {
        this.sorId = sorId;
    }

    public double getDueMonthly() {
        return dueMonthly;
    }

    public void setDueMonthly(double dueMonthly) {
        this.dueMonthly = dueMonthly;
    }

    public double getDueToday() {
        return dueToday;
    }

    public void setDueToday(double dueToday) {
        this.dueToday = dueToday;
    }

    public String getSkuDisplayName() {
        return skuDisplayName;
    }

    public void setSkuDisplayName(String skuDisplayName) {
        this.skuDisplayName = skuDisplayName;
    }

    public double getItemTax() {
        return itemTax;
    }

    public void setItemTax(double itemTax) {
        this.itemTax = itemTax;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    public String getPlanSize() {
        return planSize;
    }

    public void setPlanSize(String planSize) {
        this.planSize = planSize;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFeatureLineItemId() {
        return featureLineItemId;
    }

    public void setFeatureLineItemId(String featureLineItemId) {
        this.featureLineItemId = featureLineItemId;
    }

    public HashMap<String, Double> getTaxDetails() {
        return taxDetails;
    }

    public void setTaxDetails(HashMap<String, Double> taxDetails) {
        this.taxDetails = taxDetails;
    }

    public double getFourthLinePromoDiscount() { return fourthLinePromoDiscount; }

    public void setFourthLinePromoDiscount(double fourthLinePromoDiscount) { this.fourthLinePromoDiscount = fourthLinePromoDiscount; }

    public double getAutoPaySaving() {
        return autoPaySaving;
    }

    public void setAutoPaySaving(double autoPaySaving) {
        this.autoPaySaving = autoPaySaving;
    }

    public Map<String, Double> getPromotions() {
        return promotions;
    }

    public void setPromotions(Map<String, Double> promotions) {
        this.promotions = promotions;
    }

    public String getBonusData() {
        return bonusData;
    }

    public void setBonusData(String bonusData) {
        this.bonusData = bonusData;
    }

    public boolean isEligibleForDoubleData() {
        return eligibleForDoubleData;
    }

    public void setEligibleForDoubleData(boolean eligibleForDoubleData) {
        this.eligibleForDoubleData = eligibleForDoubleData;
    }

    public double getTotalDueMonthly() {
        return totalDueMonthly;
    }

    public void setTotalDueMonthly(double totalDueMonthly) {
        this.totalDueMonthly = totalDueMonthly;
    }

    public double getTotalDueToday() {
        return totalDueToday;
    }

    public void setTotalDueToday(double totalDueToday) {
        this.totalDueToday = totalDueToday;
    }

    public double getPlanDueMonthly() {
        return planDueMonthly;
    }

    public void setPlanDueMonthly(double planDueMonthly) {
        this.planDueMonthly = planDueMonthly;
    }

    public double getActualPlanPrice() {
        return actualPlanPrice;
    }

    public void setActualPlanPrice(double actualPlanPrice) {
        this.actualPlanPrice = actualPlanPrice;
    }

    public boolean isDiscountApplied() {
        return isDiscountApplied;
    }

    public void setDiscountApplied(boolean discountApplied) {
        isDiscountApplied = discountApplied;
    }
}
