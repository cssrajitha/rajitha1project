package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;

public class VZWPromotion implements Serializable {

	private static final long serialVersionUID = 1L;
	private String barCodeId;

	private String promoAmount;

	private String itemAmount;

	private String itemType;

	private String promoName;

	private String sedOffer;

	private String itemCode;

	private String promoDescription;

	public String getBarCodeId() {
		return barCodeId;
	}

	public void setBarCodeId(String barCodeId) {
		this.barCodeId = barCodeId;
	}

	public String getPromoAmount() {
		return promoAmount;
	}

	public void setPromoAmount(String promoAmount) {
		this.promoAmount = promoAmount;
	}

	public String getItemAmount() {
		return itemAmount;
	}

	public void setItemAmount(String itemAmount) {
		this.itemAmount = itemAmount;
	}

	public String getItemType() {
		return itemType;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

	public String getPromoName() {
		return promoName;
	}

	public void setPromoName(String promoName) {
		this.promoName = promoName;
	}

	public String getSedOffer() {
		return sedOffer;
	}

	public void setSedOffer(String sedOffer) {
		this.sedOffer = sedOffer;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public String getPromoDescription() {
		return promoDescription;
	}

	public void setPromoDescription(String promoDescription) {
		this.promoDescription = promoDescription;
	}

	@Override
	public String toString() {
		return "ClassPojo [barCodeId = " + barCodeId + ", promoAmount = " + promoAmount + ", itemAmount = " + itemAmount
				+ ", itemType = " + itemType + ", promoName = " + promoName + ", sedOffer = " + sedOffer
				+ ", itemCode = " + itemCode + ", promoDescription = " + promoDescription + "]";
	}
}
