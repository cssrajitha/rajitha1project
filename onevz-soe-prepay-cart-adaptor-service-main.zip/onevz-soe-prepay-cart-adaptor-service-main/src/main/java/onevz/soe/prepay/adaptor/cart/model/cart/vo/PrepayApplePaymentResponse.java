package onevz.soe.prepay.adaptor.cart.model.cart.vo;

import onevz.soe.prepay.adaptor.cart.model.vo.ApplePay;

import java.io.Serializable;

public class PrepayApplePaymentResponse implements Serializable {
    private static final long serialVersionUID = 1L;

    private boolean applePaySelected;
    private ApplePay applePay;
    private int statusCode;
    private boolean success;
    private boolean error;

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public boolean isError() {
        return error;
    }

    public void setError(boolean error) {
        this.error = error;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }


    public ApplePay getApplePay() {
        return applePay;
    }

    public void setApplePay(ApplePay applePay) {
        this.applePay = applePay;
    }

    public boolean isApplePaySelected() {
        return applePaySelected;
    }

    public void setApplePaySelected(boolean applePaySelected) {
        this.applePaySelected = applePaySelected;
    }
}
