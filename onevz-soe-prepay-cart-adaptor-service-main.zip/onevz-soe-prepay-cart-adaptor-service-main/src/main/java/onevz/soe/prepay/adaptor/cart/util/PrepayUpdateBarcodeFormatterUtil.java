package onevz.soe.prepay.adaptor.cart.util;


import onevz.soe.cart.model.common.CartServiceServiceHeader;
import onevz.soe.cart.model.updateBarcode.UpdateBarcodeBarcodeId;
import onevz.soe.cart.requests.UpdateBarCodePEGARequest;
import onevz.soe.cart.responses.UpdateBarCodePEGAResponse;
import onevz.soe.prepay.adaptor.cart.model.cart.vo.UpdateBarcodePrepayOdRequest;
import onevz.soe.prepay.adaptor.cart.model.cart.vo.UpdateBarcodePrepayOdResponse;


import java.util.Optional;


public class PrepayUpdateBarcodeFormatterUtil {


    private PrepayUpdateBarcodeFormatterUtil() {

    }



    public static UpdateBarcodePrepayOdRequest formatUpdateBarcodeRequest(UpdateBarCodePEGARequest request) {
        UpdateBarcodePrepayOdRequest updateBarcodePrepayOdRequest = new UpdateBarcodePrepayOdRequest();
        if(null != request.getServiceBody().getServiceRequest().getContext().getCartInfo().getBarCodeIds() && !request.getServiceBody().getServiceRequest().getContext().getCartInfo().getBarCodeIds().isEmpty()){
            Optional<UpdateBarcodeBarcodeId> updateBarcodeBarcodeId = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getBarCodeIds().stream().findFirst();
            updateBarcodeBarcodeId.ifPresent(x -> updateBarcodePrepayOdRequest.setPromoCode(updateBarcodeBarcodeId.get().getBarCodeId()));
        }

        return updateBarcodePrepayOdRequest;
    }

    public static UpdateBarCodePEGAResponse formatUpdateBarcodeResponse(UpdateBarcodePrepayOdResponse updateShippingOptionPrepayOdResponse) {


        UpdateBarCodePEGAResponse updateBarCodePEGAResponse = new UpdateBarCodePEGAResponse();
        updateBarCodePEGAResponse.setServiceHeader(setServiceHeader(updateShippingOptionPrepayOdResponse));
        return updateBarCodePEGAResponse;
    }

    private static CartServiceServiceHeader setServiceHeader(UpdateBarcodePrepayOdResponse updateBarcodePrepayOdResponse) {
        CartServiceServiceHeader serviceHeader = new CartServiceServiceHeader();
        if (updateBarcodePrepayOdResponse.getStatusCode().equalsIgnoreCase("SUCCESS") || updateBarcodePrepayOdResponse.getStatusCode().equalsIgnoreCase("00")) {
            serviceHeader.setStatusMsg("SUCCESS");
            serviceHeader.setStatusCode("00");
        } else {
            serviceHeader.setStatusMsg("FAILED");
            serviceHeader.setStatusCode("01");
        }
        return serviceHeader;
    }




}
