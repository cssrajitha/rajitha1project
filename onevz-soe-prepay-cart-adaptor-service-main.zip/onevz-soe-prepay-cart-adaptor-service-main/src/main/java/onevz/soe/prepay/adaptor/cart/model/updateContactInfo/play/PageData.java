package onevz.soe.prepay.adaptor.cart.model.updateContactInfo.play;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;
import onevz.soe.od.model.VZWPrepayPromotion;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PageData {

    private RefillCardDetails refillCardDetails;

    private String orderNumber;

    private String autoPayTotalAmount;

    private String orderId;

    private String binProcessEventEnabled;

    private String shippingOptionId;

    private String autopaySavings;

    private String saveCreditCard;

    private String showGiftCardAmountExceedFlag;

    private String shippingRequired;

    private String paypalInfo;

    private String mot;

    private String linesCount;

    private String nextDueDate;

    private String paymentGroup;

    private DeviceList[] deviceList;

    private String autoPayAccount;

    private String inlinePromotionMessage;

    private String flow;

    private String autoPayEnabled;

    private String trialStatus;

    private String customerSavedCreditCard;

    private String shippingMethod;

    private String todaySavings;

    private String orderZipcode;

    private String fiveGToFourGTransition;

    private String estimatedDeliveryDate;

    private FeatureList[] featureList;

    private String shippingPrice;

    private DigitalPaymentOptions digitalPaymentOptions;

    private String paymentMethod;

    private PlanList[] planList;

    private String deviceFingerPrintEnabled;

    private String totalActivationfee;

    private String dueMonthly;

    private String binProcessEventMaxTimeout;

    private String pieEnabled;

    private String planSavings;

    private String dueNextCycle;

    private String accumulateInlineDiscount;

    private String applePayInfo;

    private String purchasePath;

    private String threeDSecured;

    private String amountCredit;

    private String monthlySavings;

    private AccountInfo accountInfo;

    private String cartCount;

    private String sessionId;

    private String orderTax;

    private String btstEnabled;

    private String orderTotal;

    private String giftCardMaxAmount;

    private TaxDetailList[] taxDetailList;

    private VZWPrepayPromotion[] promotions;

    private String planDueMonthly;

    private String holidayPolicyEnable;

    private String dueToday;

    private String[] refillCards;

    private String orderDiscount;

    private String jwtToken;

    private BillingAddress billingAddress;

    private String expressStoreGiftCardRemainingSpendAmount;
}

