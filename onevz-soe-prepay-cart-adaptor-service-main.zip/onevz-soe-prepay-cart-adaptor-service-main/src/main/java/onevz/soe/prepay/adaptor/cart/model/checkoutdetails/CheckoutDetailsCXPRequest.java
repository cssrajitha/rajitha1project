package onevz.soe.prepay.adaptor.cart.model.checkoutdetails;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import onevz.soe.orderprocess.request.IconicFlags;
import onevz.soe.orderprocess.request.OrderProcessCradleData;
import onevz.soe.validation.constraints.LocationCode;
import onevz.soe.validation.constraints.Vzid;

/**
 * @author VZ India
 *
 */


@lombok.Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CheckoutDetailsCXPRequest {

	private String client;
	
	private String user;
	
	private String clientCorrelationId;

	private String cartId;

	private String optimizeSDD;
	
	@LocationCode
	private String locationCode;

	@Vzid
	private String agreementId;
	
	private boolean installmentContracts = true;
	
	private boolean customerAgreements = true;
	
	private boolean cart = true;
	
	private boolean paymentOptions = true;
	
	private boolean shippingOptions = true;
	
	private boolean smsEnabledOptions = true;
	
	private boolean expressCheckout;

	private boolean validateOrder = true;
	
	private boolean promotionInfoRequired;
	
	private boolean deviceProductInfoRequired;
	
	private String safeTechSessionId;
	
	private OrderProcessCradleData cradle;

	private IconicFlags iconicFlags;

	private String cartCreator;

	private boolean qaIconicTesting;

	private String pageId;
	
	private String flowName;

	private String iconicTestIntent;

	private boolean disableSplitShipment;

	private String processStack;

}
