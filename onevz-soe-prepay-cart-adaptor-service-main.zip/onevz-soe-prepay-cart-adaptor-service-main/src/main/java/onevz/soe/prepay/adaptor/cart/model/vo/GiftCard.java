package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;

/**
 *
 */
public class GiftCard extends PaymentGroup implements Serializable {
    private static final long serialVersionUID = -559007903627077409L;
    private String mGiftCardAmount;
    private String mGiftCardNumber;
    private String mGiftCardPin;
    private String mGiftCardRemainingBalance;
    private String tokenizedGiftCardNumber;
    private String maskedGiftCardNumber;
    private String lastFourDigits;
    private String paymentType;

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public String getGiftCardRemainingBalance() {
        return mGiftCardRemainingBalance;
    }

    public void setGiftCardRemainingBalance(String mGiftCardRemainingBalance) {
        this.mGiftCardRemainingBalance = mGiftCardRemainingBalance;
    }

    public String getGiftCardAmount() {
        return mGiftCardAmount;
    }

    public void setGiftCardAmount(String pGiftCardAmount) {
        this.mGiftCardAmount = pGiftCardAmount;
    }

    public String getGiftCardNumber() {
        return mGiftCardNumber;
    }

    public void setGiftCardNumber(String pGiftCardNumber) {
        this.mGiftCardNumber = pGiftCardNumber;
    }

    public String getGiftCardPin() {
        return mGiftCardPin;
    }

    public void setGiftCardPin(String pGiftCardPin) {
        this.mGiftCardPin = pGiftCardPin;
    }

    public String getTokenizedGiftCardNumber() {
        return tokenizedGiftCardNumber;
    }

    public void setTokenizedGiftCardNumber(String tokenizedGiftCardNumber) {
        this.tokenizedGiftCardNumber = tokenizedGiftCardNumber;
    }

    public String getMaskedGiftCardNumber() {
        return maskedGiftCardNumber;
    }

    public void setMaskedGiftCardNumber(String maskedGiftCardNumber) {
        this.maskedGiftCardNumber = maskedGiftCardNumber;
    }

    public String getLastFourDigits() {
        return lastFourDigits;
    }

    public void setLastFourDigits(String lastFourDigits) {
        this.lastFourDigits = lastFourDigits;
    }
}
