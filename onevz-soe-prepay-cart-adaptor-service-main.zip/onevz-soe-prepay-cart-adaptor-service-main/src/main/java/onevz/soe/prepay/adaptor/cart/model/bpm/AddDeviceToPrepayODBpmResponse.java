package onevz.soe.prepay.adaptor.cart.model.bpm;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;
import onevz.soe.cart.model.common.CartServiceServiceHeader;
import onevz.soe.wsclient.bpm.model.response.BPMServiceResponse;

@Data
@JsonPropertyOrder({"serviceHeader","serviceBody"})
public class AddDeviceToPrepayODBpmResponse extends BPMServiceResponse {

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private AddDeviceToPrepayODServiceBody serviceBody;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private CartServiceServiceHeader serviceHeader;

}
