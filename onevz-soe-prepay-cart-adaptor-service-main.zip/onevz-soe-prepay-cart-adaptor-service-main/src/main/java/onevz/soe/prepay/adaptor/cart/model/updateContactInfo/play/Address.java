package onevz.soe.prepay.adaptor.cart.model.updateContactInfo.play;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Address {
    private String zip;

    private String emailAddress;

    private String altPhoneNumber;

    private String city;

    private String addressLine1;

    private String addressLine2;

    private String addressLine3;

    private String state;
}

