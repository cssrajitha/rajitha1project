package onevz.soe.prepay.adaptor.cart.model.updateContactInfo.play;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class FeatureList {
    private String dueMonthly;

    private String productId;

    private String taxDetails;

    private String dueToday;

    private String displayName;

    private String sorId;

    private String description;

    private String id;

    private String skuId;

}

