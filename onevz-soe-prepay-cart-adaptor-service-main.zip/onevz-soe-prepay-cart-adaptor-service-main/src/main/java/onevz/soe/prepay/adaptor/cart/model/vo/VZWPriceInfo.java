package onevz.soe.prepay.adaptor.cart.model.vo;

/**
 * Created by gumapa on 6/23/2017.
 */
public class VZWPriceInfo {


    private String ecpdCustPriceType;

    private String basePriceUsed;

    public String getEcpdCustPriceType() {
        return ecpdCustPriceType;
    }

    public void setEcpdCustPriceType(String ecpdCustPriceType) {
        this.ecpdCustPriceType = ecpdCustPriceType;
    }

    public String getBasePriceUsed() {
        return basePriceUsed;
    }

    public void setBasePriceUsed(String basePriceUsed) {
        this.basePriceUsed = basePriceUsed;
    }
}
