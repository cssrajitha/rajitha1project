package onevz.soe.prepay.adaptor.cart.model.vo;

/**
 * This class is used to store the details of the rebates
 * 
 * @author PA
 * 
 */
public class VZWRebates {
	/**
	 * Property used to hold the mCode
	 * 
	 */
	private String mCode;
	/**
	 * Property used to hold the mDescription
	 * 
	 */
	private String mDescription;
	/**
	 * Property used to hold the mSponsor
	 * 
	 */
	private String mSponsor;
	/**
	 * Property used to hold the mRebateAmount
	 * 
	 */
	private String mRebateAmount;
	/**
	 * Property used to hold the mEligibilityInd
	 * 
	 */
	private String mEligibilityInd;
	/**
	 * Property used to hold the mInstantRebate
	 * 
	 */
	private String mInstantRebate;
	/**
	 * Property used to hold the mRebateAllowed
	 * 
	 */
	private String mRebateAllowed;
	/**
	 * Property used to hold the mRuleId
	 * 
	 */
	private String mRuleId;
	
	/**
	 * Property used to hold the mCount
	 * 
	 */
	private Integer mCount;
	/**
	 * Property used to hold the mRebCode
	 * 
	 */


	/**
	 * Property used to hold the mRebOfferName
	 * 
	 */
	private String mRebOfferName;
	/**
	 * Property used to hold the mRebSponsor
	 * 
	 */
	private String mRebSponsor;
	/**
	 * Property used to hold the mRebAmount
	 * 
	 */
	private String mRebAmount;
	/**
	 * Property used to hold the mRebStatus
	 * 
	 */
	private String mRebStatus;
	/**
	 * Property used to hold the mRebSeqNum
	 * 
	 */
	private Integer mRebSeqNum;
	/**
	 * Property used to hold the mRebRuleId
	 * 
	 */
	private String mRebRuleId;
	/**
	 * Property used to hold the mInstantRebateFlag
	 * 
	 */
	private String mInstantRebateFlag;
	/**
	 * Property used to hold the mRebInstantInd
	 * 
	 */
	private String mRebInstantInd;

	/**
	 * This method is used to get the code
	 * 
	 * @return the code
	 */
	public String getCode() {
		return mCode;
	}

	/**
	 *This method is used to set the code
	 * 
	 * @param pCode
	 *            the code to set
	 */
	public void setCode(String pCode) {
		mCode = pCode;
	}

	/**
	 * This method is used to get the description
	 * 
	 * @return the description
	 */
	public String getDescription() {
		return mDescription;
	}

	/**
	 *This method is used to set the description
	 * 
	 * @param pDescription
	 *            the description to set
	 */
	public void setDescription(String pDescription) {
		mDescription = pDescription;
	}

	/**
	 * This method is used to get the sponsor
	 * 
	 * @return the sponsor
	 */
	public String getSponsor() {
		return mSponsor;
	}

	/**
	 *This method is used to set the sponsor
	 * 
	 * @param pSponsor
	 *            the sponsor to set
	 */
	public void setSponsor(String pSponsor) {
		mSponsor = pSponsor;
	}

	/**
	 * This method is used to get the rebateAmount
	 * 
	 * @return the rebateAmount
	 */
	public String getRebateAmount() {
		return mRebateAmount;
	}

	/**
	 *This method is used to set the rebateAmount
	 * 
	 * @param pRebateAmount
	 *            the rebateAmount to set
	 */
	public void setRebateAmount(String pRebateAmount) {
		mRebateAmount = pRebateAmount;
	}

	/**
	 * This method is used to get the eligibilityInd
	 * 
	 * @return the eligibilityInd
	 */
	public String getEligibilityInd() {
		return mEligibilityInd;
	}

	/**
	 *This method is used to set the eligibilityInd
	 * 
	 * @param pEligibilityInd
	 *            the eligibilityInd to set
	 */
	public void setEligibilityInd(String pEligibilityInd) {
		mEligibilityInd = pEligibilityInd;
	}

	/**
	 * This method is used to get the instantRebate
	 * 
	 * @return the instantRebate
	 */
	public String getInstantRebate() {
		return mInstantRebate;
	}

	/**
	 *This method is used to set the instantRebate
	 * 
	 * @param pInstantRebate
	 *            the instantRebate to set
	 */
	public void setInstantRebate(String pInstantRebate) {
		mInstantRebate = pInstantRebate;
	}

	/**
	 * This method is used to get the rebateAllowed
	 * 
	 * @return the rebateAllowed
	 */
	public String getRebateAllowed() {
		return mRebateAllowed;
	}

	/**
	 *This method is used to set the rebateAllowed
	 * 
	 * @param pRebateAllowed
	 *            the rebateAllowed to set
	 */
	public void setRebateAllowed(String pRebateAllowed) {
		mRebateAllowed = pRebateAllowed;
	}

	/**
	 * This method is used to get the ruleId
	 * 
	 * @return the ruleId
	 */
	public String getRuleId() {
		return mRuleId;
	}

	/**
	 *This method is used to set the ruleId
	 * 
	 * @param pRuleId
	 *            the ruleId to set
	 */
	public void setRuleId(String pRuleId) {
		mRuleId = pRuleId;
	}
	
	
	
	/**
	 * @return the instantRebateFlag
	 */
	public String getInstantRebateFlag() {
		return mInstantRebateFlag;
	}

	/**
	 * @param pInstantRebateFlag the instantRebateFlag to set
	 */
	public void setInstantRebateFlag(String pInstantRebateFlag) {
		mInstantRebateFlag = pInstantRebateFlag;
	}

	/**
	 * @return the count
	 */
	public Integer getCount() {
		return mCount;
	}

	/**
	 * @param pCount the count to set
	 */
	public void setCount(Integer pCount) {
		mCount = pCount;
	}



	/**
	 * @return the mRebOfferName
	 */
	public String getRebOfferName() {
		return mRebOfferName;
	}

	/**
	 * @param mRebOfferName the mRebOfferName to set
	 */
	public void setRebOfferName(String pRebOfferName) {
		this.mRebOfferName = pRebOfferName;
	}

	/**
	 * @return the mRebSponsor
	 */
	public String getRebSponsor() {
		return mRebSponsor;
	}

	/**
	 * @param mRebSponsor the mRebSponsor to set
	 */
	public void setRebSponsor(String pRebSponsor) {
		this.mRebSponsor = pRebSponsor;
	}

	/**
	 * @return the mRebAmount
	 */
	public String getRebAmount() {
		return mRebAmount;
	}

	/**
	 * @param mRebAmount the mRebAmount to set
	 */
	public void setRebAmount(String pRebAmount) {
		this.mRebAmount = pRebAmount;
	}

	/**
	 * @return the mRebStatus
	 */
	public String getRebStatus() {
		return mRebStatus;
	}

	/**
	 * @param mRebStatus the mRebStatus to set
	 */
	public void setRebStatus(String pRebStatus) {
		this.mRebStatus = pRebStatus;
	}

	/**
	 * @return the mRebSeqNum
	 */
	public Integer getRebSeqNum() {
		return mRebSeqNum;
	}

	/**
	 * @param mRebSeqNum the mRebSeqNum to set
	 */
	public void setRebSeqNum(Integer pRebSeqNum) {
		this.mRebSeqNum = pRebSeqNum;
	}

	/**
	 * @return the mRebRuleId
	 */
	public String getRebRuleId() {
		return mRebRuleId;
	}

	/**
	 * @param mRebRuleId the mRebRuleId to set
	 */
	public void setRebRuleId(String pRebRuleId) {
		this.mRebRuleId = pRebRuleId;
	}

	/**
	 * @return the mRebInstantInd
	 */
	public String getRebInstantInd() {
		return mRebInstantInd;
	}

	/**
	 * @param mRebInstantInd the mRebInstantInd to set
	 */
	public void setRebInstantInd(String pRebInstantInd) {
		this.mRebInstantInd = pRebInstantInd;
	}
	

}
