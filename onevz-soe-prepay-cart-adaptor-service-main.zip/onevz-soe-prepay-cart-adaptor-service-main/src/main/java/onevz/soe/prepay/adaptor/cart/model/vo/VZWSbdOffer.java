package onevz.soe.prepay.adaptor.cart.model.vo;


import java.io.Serializable;

/**
 * Created by gumapa on 6/23/2017.
 */
public class VZWSbdOffer implements Serializable{


    /**
     * Property used to hold the mOfferId
     *
     */
    private String mOfferId;
    /**
     * Property used to hold the mOfferType
     *
     */
    private String mOfferType;
    /**
     * Property used to hold the mOfferName
     *
     */
    private String mOfferName;
    /**
     * Property used to hold the mOfferDesc
     *
     */
    private String mOfferDesc;
    /**
     * Property used to hold the mDiscAmt
     *
     */
    private String mDiscAmt;
    /**
     * Property used to hold the mDiscPrcnt
     *
     */
    private short mDiscPrcnt;
    /**
     * Property used to hold the mDbdDelay
     *
     */
    private int mDbdDelay;
    private String existingOfferApplyInd;

    private String barcodeID;
    private String barcodeGroup;

    public String getExistingOfferApplyInd() {
        return existingOfferApplyInd;
    }

    public void setExistingOfferApplyInd(String existingOfferApplyInd) {
        this.existingOfferApplyInd = existingOfferApplyInd;
    }

    public String getMultiLineSeqNumber() {
        return multiLineSeqNumber;
    }

    public void setMultiLineSeqNumber(String multiLineSeqNumber) {
        this.multiLineSeqNumber = multiLineSeqNumber;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    private String multiLineSeqNumber;
    private String mobileNumber;

    /**
     * Property used to hold the mSbdDelay
     *
     */
    private int mSbdDelay;

    /**
     * property used to hold mBicBogoTargetItemSequence
     */
    private short mBicBogoTargetItemSequence;
    /**
     * property used to hold mBicBogoSequence
     */
    private Integer mBicBogoSequence;
    /**
     * property used to hold mBicBogoTargetOrderNum
     */
    private Integer mBicBogoTargetOrderNum;
    /**
     * property used to hold mBicBogoTargetLocationCode
     */
    private String mBicBogoTargetLocationCode;
    /**
     * property used to hold mBicBogoType
     */
    private String mBicBogoType;
    /**
     * property used to hold mBicBogoTargetMdn
     */
    private String mBicBogoTargetMdn;
    /**
     * property used to hold mDroppedLocation
     */
    private String mDroppedLocation;
    /**
     * property used to hold mDroppedOrderNum
     */
    private Integer mDroppedOrderNum;

    /**
     * property used to hold bicNoOfOccurences
     */
    private int bicNoOfOccurences;

    public int getBicNoOfOccurences() {
        return bicNoOfOccurences;
    }

    public void setBicNoOfOccurences(int bicNoOfOccurences) {
        this.bicNoOfOccurences = bicNoOfOccurences;
    }

    public short getBicBogoTargetItemSequence() {
        return mBicBogoTargetItemSequence;
    }

    public void setBicBogoTargetItemSequence(short bicBogoTargetItemSequence) {
        mBicBogoTargetItemSequence = bicBogoTargetItemSequence;
    }

    public int getBicBogoSequence() {
        return mBicBogoSequence;
    }

    public void setBicBogoSequence(int bicBogoSequence) {
        mBicBogoSequence = bicBogoSequence;
    }

    public int getBicBogoTargetOrderNum() {
        return mBicBogoTargetOrderNum;
    }

    public void setBicBogoTargetOrderNum(int bicBogoTargetOrderNum) {
        mBicBogoTargetOrderNum = bicBogoTargetOrderNum;
    }

    public String getBicBogoTargetLocationCode() {
        return mBicBogoTargetLocationCode;
    }

    public void setBicBogoTargetLocationCode(String bicBogoTargetLocationCode) {
        mBicBogoTargetLocationCode = bicBogoTargetLocationCode;
    }

    public String getBicBogoType() {
        return mBicBogoType;
    }

    public void setBicBogoType(String bicBogoType) {
        mBicBogoType = bicBogoType;
    }

    public String getBicBogoTargetMdn() {
        return mBicBogoTargetMdn;
    }

    public void setBicBogoTargetMdn(String bicBogoTargetMdn) {
        mBicBogoTargetMdn = bicBogoTargetMdn;
    }

    public String getDroppedLocation() {
        return mDroppedLocation;
    }

    public void setDroppedLocation(String droppedLocation) {
        mDroppedLocation = droppedLocation;
    }

    public Integer getDroppedOrderNum() {
        return mDroppedOrderNum;
    }

    public void setDroppedOrderNum(Integer droppedOrderNum) {
        mDroppedOrderNum = droppedOrderNum;
    }

    /**
     * This method is used to get the offerId
     *
     * @return the offerId
     */
    public String getOfferId() {
        return mOfferId;
    }

    /**
     *This method is used to set the offerId
     *
     * @param pOfferId
     *            the offerId to set
     */
    public void setOfferId(String pOfferId) {
        mOfferId = pOfferId;
    }

    /**
     * This method is used to get the offerType
     *
     * @return the offerType
     */
    public String getOfferType() {
        return mOfferType;
    }

    /**
     *This method is used to set the offerType
     *
     * @param pOfferType
     *            the offerType to set
     */
    public void setOfferType(String pOfferType) {
        mOfferType = pOfferType;
    }

    /**
     * This method is used to get the offerName
     *
     * @return the offerName
     */
    public String getOfferName() {
        return mOfferName;
    }

    /**
     *This method is used to set the offerName
     *
     * @param pOfferName
     *            the offerName to set
     */
    public void setOfferName(String pOfferName) {
        mOfferName = pOfferName;
    }

    /**
     * This method is used to get the offerDesc
     *
     * @return the offerDesc
     */
    public String getOfferDesc() {
        return mOfferDesc;
    }

    /**
     *This method is used to set the offerDesc
     *
     * @param pOfferDesc
     *            the offerDesc to set
     */
    public void setOfferDesc(String pOfferDesc) {
        mOfferDesc = pOfferDesc;
    }

    /**
     * This method is used to get the discAmt
     *
     * @return the discAmt
     */
    public String getDiscAmt() {
        return mDiscAmt;
    }

    /**
     *This method is used to set the discAmt
     *
     * @param pDiscAmt
     *            the discAmt to set
     */
    public void setDiscAmt(String pDiscAmt) {
        mDiscAmt = pDiscAmt;
    }

    /**
     * This method is used to get the discPrcnt
     *
     * @return the discPrcnt
     */
    public short getDiscPrcnt() {
        return mDiscPrcnt;
    }

    /**
     *This method is used to set the discPrcnt
     *
     * @param pDiscPrcnt
     *            the discPrcnt to set
     */
    public void setDiscPrcnt(short pDiscPrcnt) {
        mDiscPrcnt = pDiscPrcnt;
    }

    /**
     * This method is used to get the dbdDelay
     *
     * @return the dbdDelay
     */
    public int getDbdDelay() {
        return mDbdDelay;
    }

    /**
     *This method is used to set the dbdDelay
     *
     * @param pDbdDelay
     *            the dbdDelay to set
     */
    public void setDbdDelay(int pDbdDelay) {
        mDbdDelay = pDbdDelay;
    }

    /**
     * @return the sbdDelay
     */
    public int getSbdDelay() {
        return mSbdDelay;
    }

    /**
     * @param pSbdDelay the sbdDelay to set
     */
    public void setSbdDelay(int pSbdDelay) {
        mSbdDelay = pSbdDelay;
    }

    public String getBarcodeID() {
        return barcodeID;
    }

    public void setBarcodeID(String barcodeID) {
        this.barcodeID = barcodeID;
    }

    public String getBarcodeGroup() {
        return barcodeGroup;
    }

    public void setBarcodeGroup(String barcodeGroup) {
        this.barcodeGroup = barcodeGroup;
    }



}
