package onevz.soe.prepay.adaptor.cart.model.updateContactInfo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import onevz.soe.wsclient.bpm.model.CustomerInfo;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ContactInfoCustomerInfo extends CustomerInfo {

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value = "globalId")
    public String globalId;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value = "originalCreditApprovalNumber")
    public String originalCreditApprovalNumber;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value = "customerType")
    public String customerType;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value = "cbr")
    public String cbr;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty(value = "standaloneBYOD")
    private Boolean standaloneBYOD;
}
