package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;
import java.util.List;

public class OrderLineItem implements Serializable{
	
	private static final long serialVersionUID = -4538713847742807222L;
	private String id;
	
	private int quantity;
	private String type;
	private String skuId;
	private String productId;
	private String sorId;
	private Double itemAmount;
	private Double dueMonthly;
	private Double itemDiscount;
	private String displayName;
	private Double listPrice;
	private Double rawTotalAmount;
	private List<PricingDetails> pricingDetails;
	private String orderId;
	private int version;
	private boolean delete;
	private int inventoryLevel;
	private List<TaxDetail> taxDetails;
	private Double itemTaxes;
	private boolean ecpdDiscounted;
	private boolean isGiftCardAccessory;
	private String giftCardInfoId;

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getSkuId() {
		return skuId;
	}
	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getSorId() {
		return sorId;
	}
	public void setSorId(String sorId) {
		this.sorId = sorId;
	}
	public Double getItemAmount() {
		if(itemAmount != null){
			return itemAmount;
		}else{
			return 0.0D;
		}
	}
	public void setItemAmount(Double itemAmount) {
		this.itemAmount = itemAmount;
	}
	public Double getItemDiscount() {
		if(itemDiscount != null){
			return itemDiscount;
		}else{
			return 0.0D;
		}
	}
	public void setItemDiscount(Double itemDiscount) {
		this.itemDiscount = itemDiscount;
	}
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public Double getListPrice() {
		if(listPrice != null){
			return listPrice;
		}else{
			return 0.0D;
		}
	}
	public void setListPrice(Double listPrice) {
		this.listPrice = listPrice;
	}
	public Double getRawTotalAmount() {
		if(rawTotalAmount != null){
			return rawTotalAmount;
		}else{
			return 0.0D;
		}
	}
	public void setRawTotalAmount(Double rawTotalAmount) {
		this.rawTotalAmount = rawTotalAmount;
	}
	public List<PricingDetails> getPricingDetails() {
		return pricingDetails;
	}
	public void setPricingDetails(List<PricingDetails> pricingDetails) {
		this.pricingDetails = pricingDetails;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public double getDueMonthly() {
		if(dueMonthly != null){
			return dueMonthly;
		}else{
			return 0.0D;
		}
	}
	public void setDueMonthly(Double dueMonthly) {
		this.dueMonthly = dueMonthly;
	}
	
	public int getVersion() {
		return version;
	}

	public boolean isDelete() {
		return delete;
	}

	public void setDelete(boolean delete) {
		this.delete = delete;
	}

	public void updateVersion() {
		this.version += 1;
	}
	
	public int getInventoryLevel() {
		return inventoryLevel;
	}

	public void setInventoryLevel(int inventoryLevel) {
		this.inventoryLevel = inventoryLevel;
	}
	
	public List<TaxDetail> getTaxDetails() {
		return taxDetails;
	}

	public void setTaxDetails(List<TaxDetail> taxDetails) {
		this.taxDetails = taxDetails;
	}
	public Double getItemTaxes() {
		if(itemTaxes != null){
			return itemTaxes;
		}else{
			return 0.0D;
		}
	}

	public void setItemTaxes(Double itemTaxes) {
		this.itemTaxes = itemTaxes;
	}

	
	public void setVersion(int version) {
		this.version = version;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof OrderLineItem)) {
			return false;
		}
		OrderLineItem other = (OrderLineItem) obj;
		if (id == null) {
			if (other.id != null) {
				return false;
			}
		} else if (!id.equals(other.id)) {
			return false;
		}
		return true;
	}

	private String skuDisplayName;

	public String getSkuDisplayName() {
		return skuDisplayName;
	}

	public void setSkuDisplayName(String skuDisplayName) {
		this.skuDisplayName = skuDisplayName;
	}

	private boolean ispuEligibleFlag;

	public boolean isIspuEligibleFlag() {
		return ispuEligibleFlag;
	}

	public void setIspuEligibleFlag(boolean ispuEligibleFlag) {
		this.ispuEligibleFlag = ispuEligibleFlag;
	}

	private	boolean alwaysEligible;

	public boolean isAlwaysEligible() {
		return alwaysEligible;
	}

	public void setAlwaysEligible(boolean alwaysEligible) {
		this.alwaysEligible = alwaysEligible;
	}

	public boolean isEcpdDiscounted() {
		return ecpdDiscounted;
	}

	public void setEcpdDiscounted(boolean ecpdDiscounted) {
		this.ecpdDiscounted = ecpdDiscounted;
	}

	public boolean isGiftCardAccessory() {
		return isGiftCardAccessory;
	}

	public void setGiftCardAccessory(boolean giftCardAccessory) {
		isGiftCardAccessory = giftCardAccessory;
	}

	public String getGiftCardInfoId() {
		return giftCardInfoId;
	}

	public void setGiftCardInfoId(String giftCardInfoId) {
		this.giftCardInfoId = giftCardInfoId;
	}
}
