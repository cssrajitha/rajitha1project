package onevz.soe.prepay.adaptor.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.requests.AddZipcodeCXPRequest;
import onevz.soe.cart.requests.AddZipcodeCxpData;
import onevz.soe.cart.responses.AddZipcodeCXPResponse;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.od.error.EcommApiError;
import onevz.soe.od.error.EcommValidationError;
import onevz.soe.od.model.*;
import onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants;
import onevz.soe.prepay.adaptor.cart.util.PrepayAdaptorCartUtil;

import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import onevz.soe.wsclient.prepay.webclient.model.PrepaidAdaptorWebClientRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;

import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_DATA;

@Service
public class PrepayAdaptorValidateZipCodeHelper {

    Logger logger = LoggerFactory.getLogger(PrepayAdaptorValidateZipCodeHelper.class);

    @Autowired
    private PrepayCartRedisHelper redisHelper;

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    private PrepayAdaptorWebClient prepayAdaptorWebClient;

    @Value("${validateZipCodeLegacyServiceUrl}")
    private String validateZipCodeLegacyUrl;

    /**
     * @param httpRequest
     * @param addZipcodeCXPRequest
     * @return addZipcodeCXPResponse
     */

    public Mono<ResponseEntity<AddZipcodeCXPResponse>> validateZipCode(ServerHttpRequest httpRequest, AddZipcodeCXPRequest addZipcodeCXPRequest) {
        logger.info(" Starts validateZipCode Helper");
        return redisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)
                .doOnError(onError ->
                    logger.error(" Unable to get data from Redis {}", PREPAY_OD_REQUEST_DATA, onError)
                ).doOnSuccess(onSuccess ->
                    logger.info("Successfully retrieved data from Redis: {}", onSuccess)
                ).flatMap(response -> {
                    if (StringUtilities.isNotEmptyOrNull(response)) {
                        logger.info("Redis Data From Redis:: {}", response);
                        PrepaidODRequestData redisData = null;
                        try {
                            redisData = mapper.readValue(response, PrepaidODRequestData.class);
                        } catch (JsonProcessingException e) {
                            logger.error("Failed to parse data from redis:", e);
                            return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new AddZipcodeCXPResponse()));
                        }
                        PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = getPrepaidAdaptorWebClientRequest(addZipcodeCXPRequest, redisData);

                        PrepaidODRequestData finalRedisData = redisData;
                        return prepayAdaptorWebClient.getPrepayServiceResponse(httpRequest, prepaidAdaptorWebClientRequest)
                                .doOnError(error -> logger.error("Failed to get response, check exception for details.", error))
                                .flatMap(responseEntity -> {
                                    AddZipcodeCXPResponse addZipcodeCXPResponse = null;
                                    VZWValidateZipCodeResponseVO  validateZipCodeResponseVO = null;
                                    try {
                                        validateZipCodeResponseVO = mapper.readValue(responseEntity.getBody(), VZWValidateZipCodeResponseVO.class);
                                        if (!responseEntity.getStatusCode().is2xxSuccessful()) {
                                            logger.error("Error while calling endpoint: {} with status code: {}", prepaidAdaptorWebClientRequest.getUrl(), responseEntity.getStatusCode());
                                            addZipcodeCXPResponse = new AddZipcodeCXPResponse();
                                        } else {
                                            addZipcodeCXPResponse = buildValidateZipCodeResponse(validateZipCodeResponseVO);
                                            finalRedisData.setZipCode(addZipcodeCXPRequest.getData().getZipCode());
                                           return updateZipCodeDataInRedis(addZipcodeCXPRequest,finalRedisData,addZipcodeCXPResponse);

                                        }
                                        return Mono.just(ResponseEntity.status(responseEntity.getStatusCode()).body(addZipcodeCXPResponse));
                                    }catch (Exception ex){
                                        logger.error("Error while processing, calling endpoint: {} with status code: {}", prepaidAdaptorWebClientRequest.getUrl(), responseEntity.getStatusCode());
                                        return Mono.just(ResponseEntity.status(responseEntity.getStatusCode()).body(new AddZipcodeCXPResponse()));
                                    }
                                });
                    } else {
                        logger.error("Error while fetching redis data");
                        return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new AddZipcodeCXPResponse()));
                    }
                });
    }

    private PrepaidAdaptorWebClientRequest getPrepaidAdaptorWebClientRequest(AddZipcodeCXPRequest addZipcodeCXPRequest, PrepaidODRequestData prepaidODRequestData) {
        String zipCode = Optional.ofNullable(addZipcodeCXPRequest).map(addZipcodeCXPRequest1 -> Optional.ofNullable(addZipcodeCXPRequest1.getData()).orElse(new AddZipcodeCxpData()))
                .map(addZipcodeCxpData -> addZipcodeCxpData.getZipCode()).orElse("");
        PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
        prepaidAdaptorWebClientRequest.setUrl(validateZipCodeLegacyUrl + zipCode);
        prepaidAdaptorWebClientRequest.setRequestType(HttpMethod.GET.toString());
        prepaidAdaptorWebClientRequest.setHeader(PrepayAdaptorCartUtil.getPrepayODServiceCommonHeaders(prepaidODRequestData,Objects.nonNull(addZipcodeCXPRequest) && Objects.nonNull(addZipcodeCXPRequest.getData()) && Objects.nonNull(addZipcodeCXPRequest.getData().getIntendType())?addZipcodeCXPRequest.getData().getIntendType():PrepayAdaptorCartConstants.NSE));
        return prepaidAdaptorWebClientRequest;
    }

    private AddZipcodeCXPResponse buildValidateZipCodeResponse(VZWValidateZipCodeResponseVO validateZipCodeResponseVO){
        AddZipcodeCXPResponse zipcodeCXPResponse = new AddZipcodeCXPResponse();
        int status = Optional.ofNullable(validateZipCodeResponseVO).map(validateZipCodeResponseVO1 -> Optional.ofNullable(validateZipCodeResponseVO1.getStatus()).orElse(500)).orElse(500);
        String statusCode =Optional.ofNullable(validateZipCodeResponseVO).map(validateZipCodeResponseVO1 -> Optional.ofNullable(validateZipCodeResponseVO1.getStatusCode()).orElse("01")).orElse("01");
        zipcodeCXPResponse.setStatusCode(status);
        zipcodeCXPResponse.setStatusMsg(statusCode);
        if(200 != status || !statusCode.equalsIgnoreCase("00")){
            zipcodeCXPResponse = buildValidateZipCodeErrorResponse(validateZipCodeResponseVO);
            zipcodeCXPResponse.setStatus("Invalid");
        } else {
            AtomicReference<String> zipCode= new AtomicReference<>("");
            AtomicReference<Boolean> isValid= new AtomicReference<>(Boolean.FALSE);
            Optional.ofNullable(validateZipCodeResponseVO)
                    .map(validateZipCodeResponseVO1 -> Optional.ofNullable(validateZipCodeResponseVO1.getPayload()).orElse(new VZWValidateZipCodePayloadVO()))
                    .map(vzwValidateZipCodePayloadVO -> Optional.ofNullable(vzwValidateZipCodePayloadVO.getPageData()).orElse(new VZWValidateZipCodeVO()))
                    .ifPresent(vzwValidateZipCodeVO -> {
                        zipCode.set(vzwValidateZipCodeVO.getZipCode());
                        isValid.set(Boolean.TRUE);
                    });
            AddZipcodeCxpData addZipcodeCxpData = new AddZipcodeCxpData();
            addZipcodeCxpData.setZipCode(zipCode.get());
            addZipcodeCxpData.setStatusCode(status);
            addZipcodeCxpData.setStatus(statusCode);
            zipcodeCXPResponse.setData(addZipcodeCxpData);
            zipcodeCXPResponse.setStatus("Success");
        }
        return zipcodeCXPResponse;
    }

    private AddZipcodeCXPResponse buildValidateZipCodeErrorResponse(VZWValidateZipCodeResponseVO errorResponse){
        AddZipcodeCXPResponse addZipcodeCXPResponse = new AddZipcodeCXPResponse();
        Optional.ofNullable(errorResponse)
                .map(errResp->Optional.ofNullable(errorResponse.getErrors()).orElse(new EcommValidationError()))
                .map(ecommValidationError -> Optional.ofNullable(ecommValidationError.getEcommApiErrorList()).orElse(new ArrayList<EcommApiError>()))
                .ifPresent(ecommApiErrors -> {
                    List<CartError> errors = new ArrayList<>();
                    ecommApiErrors.stream().forEach(ecommApiError -> {
                        CartError cartError = new CartError();
                        cartError.setName(PrepayAdaptorCartConstants.VALIDZIPCODE_FAILURE_NAME);
                        cartError.setId(ecommApiError.getStatusCode());
                        cartError.setMessage(ecommApiError.getMessage());
                        if(ecommApiError.getMessage().equalsIgnoreCase(PrepayAdaptorCartConstants.VALIDZIPCODE_FAILURE_NAME))
                            cartError.setMessage(PrepayAdaptorCartConstants.VALIDZIPCODE_FAILURE_MESSAGE);
                        cartError.setCode(ecommApiError.getStatusCode());
                        cartError.setErrorCategory(PrepayAdaptorCartConstants.SYSTEM_FAILURE_PREPAID_OD);
                        errors.add(cartError);
                    });
                    addZipcodeCXPResponse.setErrors(errors);
                });
        return addZipcodeCXPResponse;
    }
    private Mono<? extends ResponseEntity<AddZipcodeCXPResponse>> updateZipCodeDataInRedis(
            AddZipcodeCXPRequest request, PrepaidODRequestData redisData,AddZipcodeCXPResponse response) {
        return redisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, redisData)
                .doOnError(err -> logger.error("Failed to update the PrepaidODRequestData to Redis", err))
                .flatMap(upsertResp ->
                {
                    logger.info("Successfully inserted updated Redis Data: {}",upsertResp);
                        return Mono.just(ResponseEntity.status(HttpStatus.OK).body(response));

                });
    }

}
