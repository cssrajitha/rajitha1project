package onevz.soe.prepay.adaptor.cart.model.cart.vo;

public class ApplePayResponseInfo {

	private String cardholderName;

	private String emailAddress;

	private String transactionId;

	private boolean applePaySelected;

	private String cardType;

	private String displayName;

	private String type;

	public String getCardholderName() {
		return cardholderName;
	}

	public void setCardholderName(String cardholderName) {
		this.cardholderName = cardholderName;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public boolean isApplePaySelected() {
		return applePaySelected;
	}

	public void setApplePaySelected(boolean applePaySelected) {
		this.applePaySelected = applePaySelected;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
}
