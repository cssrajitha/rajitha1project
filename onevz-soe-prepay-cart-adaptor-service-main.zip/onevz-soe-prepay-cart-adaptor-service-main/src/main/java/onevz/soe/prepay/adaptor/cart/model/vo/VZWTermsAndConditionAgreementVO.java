package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;
import java.util.Map;

public class VZWTermsAndConditionAgreementVO implements Serializable {

    private static final long serialVersionUID = 7817574045193107226L;

    private boolean customerAgreementAccepted;
    private boolean b2eEppAgreementAccepted;
    private boolean vzProtectAgreementAccepted;
    private Map<String, Boolean> edgeDeviceAgreement;
    private boolean ringDeviceAgreementAccepted;

    public boolean isRingDeviceAgreementAccepted() {
        return ringDeviceAgreementAccepted;
    }

    public void setRingDeviceAgreementAccepted(boolean ringDeviceAgreementAccepted) {
        this.ringDeviceAgreementAccepted = ringDeviceAgreementAccepted;
    }

    public boolean isCustomerAgreementAccepted() {
        return customerAgreementAccepted;
    }

    public void setCustomerAgreementAccepted(boolean customerAgreementAccepted) {
        this.customerAgreementAccepted = customerAgreementAccepted;
    }

    public boolean isB2eEppAgreementAccepted() {
        return b2eEppAgreementAccepted;
    }

    public void setB2eEppAgreementAccepted(boolean b2eEppAgreementAccepted) {
        this.b2eEppAgreementAccepted = b2eEppAgreementAccepted;
    }

    public boolean isVzProtectAgreementAccepted() {
        return vzProtectAgreementAccepted;
    }

    public void setVzProtectAgreementAccepted(boolean vzProtectAgreementAccepted) {
        this.vzProtectAgreementAccepted = vzProtectAgreementAccepted;
    }

    public Map<String, Boolean> getEdgeDeviceAgreement() {
        return edgeDeviceAgreement;
    }

    public void setEdgeDeviceAgreement(Map<String, Boolean> edgeDeviceAgreement) {
        this.edgeDeviceAgreement = edgeDeviceAgreement;
    }
}
