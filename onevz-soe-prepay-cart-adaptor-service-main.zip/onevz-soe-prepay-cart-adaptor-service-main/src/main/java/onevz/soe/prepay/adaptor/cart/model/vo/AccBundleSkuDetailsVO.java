package onevz.soe.prepay.adaptor.cart.model.vo;

public class AccBundleSkuDetailsVO extends AccessoryLineItem {

	private String name;

	private String imageUrl;

	private String price;

	private String discountedPrice;

	private boolean preSelected;

	private String id;

	private String sorId;

	private boolean color;

	private boolean comingSoonAcc;

	private boolean isAvailable;

	private boolean inCart;

	private String learnMoreLink;

	public String getDiscount_price() {
		return discount_price;
	}

	public void setDiscount_price(String discount_price) {
		this.discount_price = discount_price;
	}

	private String discount_price;

	public String getSorId() {
		return sorId;
	}

	public void setSorId(String sorId) {
		this.sorId = sorId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getDiscountedPrice() {
		return discountedPrice;
	}

	public void setDiscountedPrice(String discountedPrice) {
		this.discountedPrice = discountedPrice;
	}

	public boolean isPreSelected() {
		return preSelected;
	}

	public void setPreSelected(boolean preSelected) {
		this.preSelected = preSelected;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public boolean isColor() {
		return color;
	}

	public void setColor(boolean color) {
		this.color = color;
	}

	public boolean isComingSoonAcc() {
		return comingSoonAcc;
	}

	public void setComingSoonAcc(boolean comingSoonAcc) {
		this.comingSoonAcc = comingSoonAcc;
	}

	public boolean isAvailable() {
		return isAvailable;
	}

	public void setAvailable(boolean available) {
		isAvailable = available;
	}

	public boolean isInCart() {
		return inCart;
	}

	public void setInCart(boolean inCart) {
		this.inCart = inCart;
	}

	public String getLearnMoreLink() {
		return learnMoreLink;
	}

	public void setLearnMoreLink(String learnMoreLink) {
		this.learnMoreLink = learnMoreLink;
	}
}
