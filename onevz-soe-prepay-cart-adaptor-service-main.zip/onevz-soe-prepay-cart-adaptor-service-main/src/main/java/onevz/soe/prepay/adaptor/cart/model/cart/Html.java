package onevz.soe.prepay.adaptor.cart.model.cart;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Html {
    private String OD_PREPAID_CART_EUP_BANNER;

    private String OD_PREPAID_CART_TAXES_HEADING_HTML;

    private String OD_PREPAID_CART_ACTIVATION_FEE_HTML;

    private String OD_PREPAID_CART_DEVICE_MISMATCH_HTML;

    private String OD_PREPAID_SMARTPHONE_UNLIMITED_PLUS;

    private String OD_PREPAID_CART_MAX_LIMIT_REACHED_HTML;

    private String OD_PREPAID_CART_VARIANT_RETURN_POLICY_SUMMARY;

    private String OD_PREPAID_CART_RETURN_POLICY_SUMMARY_HTML;

    private String OD_PREPAID_TAX_PROMO_BANNER_HTML;

    private String OD_PREPAID_CART_HOLIDAY_RETURN_POLICY_LINK_TEXT;

    private String OD_PREPAID_PROMO_BANNER_HTML;

}