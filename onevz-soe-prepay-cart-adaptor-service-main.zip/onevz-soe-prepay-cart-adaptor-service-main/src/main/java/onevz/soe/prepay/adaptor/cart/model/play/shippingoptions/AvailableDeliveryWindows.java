package onevz.soe.prepay.adaptor.cart.model.play.shippingoptions;

import java.io.Serializable;

public class AvailableDeliveryWindows implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String id;

	private String expiresAt;

	private String startsAt;

	private String endsAt;

	private String expiresTime;

	private String startTime;

	private String endTime;

	private String formattedStartTime;

	private String formattedEndTime;

	private boolean error;

	private String errorResponse;

	/**
	 * @return the errorResponse
	 */
	public String getErrorResponse() {
		return errorResponse;
	}

	/**
	 * @param errorResponse the errorResponse to set
	 */
	public void setErrorResponse(String errorResponse) {
		this.errorResponse = errorResponse;
	}

	/**
	 * @return the error
	 */
	public boolean isError() {
		return error;
	}

	/**
	 * @param error the error to set
	 */
	public void setError(boolean error) {
		this.error = error;
	}

	public AvailableDeliveryWindows(String id, String expiresAt,
                                    String startsAt, String endsAt) {
		super();
		this.id = id;
		this.expiresAt = expiresAt;
		this.startsAt = startsAt;
		this.endsAt = endsAt;
	}

	public AvailableDeliveryWindows(){
	}

	public String getFormattedEndTime() {
		return formattedEndTime;
	}

	public void setFormattedEndTime(String formattedEndTime) {
		this.formattedEndTime = formattedEndTime;
	}

	public String getFormattedStartTime() {
		return formattedStartTime;
	}

	public void setFormattedStartTime(String formattedStartTime) {
		this.formattedStartTime = formattedStartTime;
	}

	public String getExpiresTime() {
		return expiresTime;
	}

	public void setExpiresTime(String expiresTime) {
		this.expiresTime = expiresTime;
	}

	public String getStartTime() {
		if (startTime == null) {
			return "01:00 pm";
		}
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		if (endTime == null) {
			return "04:00 pm";
		}
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}


	public String getExpiresAt() {
		return expiresAt;
	}

	public void setExpiresAt(String expiresAt) {
		this.expiresAt = expiresAt;
	}

	public String getStartsAt() {
		return startsAt;
	}

	public void setStartsAt(String startsAt) {
		this.startsAt = startsAt;
	}

	public String getEndsAt() {
		return endsAt;
	}

	public void setEndsAt(String endsAt) {
		this.endsAt = endsAt;
	}

	@Override
	public String toString() {
		return "AvailableDeliveryWindows [id=" + id + ", expires_at=" + expiresAt + ", starts_at=" + startsAt + ", ends_at=" + endsAt + ", expiresTime=" + expiresTime
				+ ", startTime=" + startTime + ", endTime=" + endTime + ", formattedStartTime=" + formattedStartTime + ", formattedEndTime=" + formattedEndTime + ", error=" + error
				+ ", errorResponse=" + errorResponse + "]";
	}


}
