package onevz.soe.prepay.adaptor.cart.model.cart.vo;

import java.io.Serializable;

public class PaypalAuthenticateRequest implements Serializable{

	private static final long serialVersionUID = 1L;
	private String orderId;
	private String flow;
	private String transactionId;
	private String payload;
	private String paypalOrderId;

	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getFlow() {
		return flow;
	}
	public void setFlow(String flow) {
		this.flow = flow;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getPayload() {
		return payload;
	}
	public void setPayload(String payload) {
		this.payload = payload;
	}
	public String getPaypalOrderId() {
		return paypalOrderId;
	}
	public void setPaypalOrderId(String paypalOrderId) {
		this.paypalOrderId = paypalOrderId;
	}
	
}