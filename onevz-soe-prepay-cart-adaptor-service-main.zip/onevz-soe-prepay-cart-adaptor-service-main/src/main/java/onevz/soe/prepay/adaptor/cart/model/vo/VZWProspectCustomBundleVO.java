package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


public class VZWProspectCustomBundleVO implements Serializable {
	private static final long serialVersionUID = 1L;
	private String customBundleName;
	private String customBundleListPrice;
	private String customBundleDiscountPrice;
	private String customBundleUImageUrl;
	private String customBundleEditUrl;
	private List<AccessoryLineItem> customBundleAccessories = new ArrayList<>();
	private String customBundleId;

	public String getCustomBundleName() {
		return customBundleName;
	}

	public void setCustomBundleName(String customBundleName) {
		this.customBundleName = customBundleName;
	}

	public String getCustomBundleListPrice() {
		return customBundleListPrice;
	}

	public void setCustomBundleListPrice(String customBundleListPrice) {
		this.customBundleListPrice = customBundleListPrice;
	}

	public String getCustomBundleDiscountPrice() {
		return customBundleDiscountPrice;
	}

	public void setCustomBundleDiscountPrice(String customBundleDiscountPrice) {
		this.customBundleDiscountPrice = customBundleDiscountPrice;
	}

	public String getCustomBundleUImageUrl() {
		return customBundleUImageUrl;
	}

	public void setCustomBundleUImageUrl(String customBundleUImageUrl) {
		this.customBundleUImageUrl = customBundleUImageUrl;
	}

	public List<AccessoryLineItem> getCustomBundleAccessories() {
		return customBundleAccessories;
	}

	public void setCustomBundleAccessories(List<AccessoryLineItem> customBundleAccessories) {
		this.customBundleAccessories = customBundleAccessories;
	}

	public String getCustomBundleEditUrl() {
		return customBundleEditUrl;
	}

	public void setCustomBundleEditUrl(String customBundleEditUrl) {
		this.customBundleEditUrl = customBundleEditUrl;
	}

	public String getCustomBundleId() {
		return customBundleId;
	}

	public void setCustomBundleId(String customBundleId) {
		this.customBundleId = customBundleId;
	}
}
