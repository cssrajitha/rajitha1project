package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;
import java.util.Date;



public class TradeInOrder implements Serializable {

	private static final long serialVersionUID = 1L;

    private String deviceRecycleOrderId;

    private String status;

    private String routeWFM;

    private String isPreOrder;

    private String isShipValidated;

    private String firstName;

    private String lastName;

    private String address1;

    private String address2;

    private String city;

    private String state;

    private String postalCode;

    private String phoneNumber;

    private String emailAddress;

    private String fipsCode;

    private String channelId;

    private String sessionId;

    private String zipCode;

    private String vendorId;

    private String clientOrderType;

    private String locationCode;

    private String orderType;

    private String posOrderNumber;

    private String buyReferenceNumber;

    private Date createDate;

    private String createdby;


    private Date updateDate;

    private String ipAddress;

    private String msgToWFM;

    private String origPosOrderNumber;

    private String origClientRefNumber;

    private String priMobileNumber;

    private String accountNumber;

    private String subAccountNumber;

    private String billingSystem;

    private Integer marketId;

    private String isPostLogin;

    private String aptNum;

    private String streetNum;

    private String streetType;

    private String addType;

    private String dir;

    private String ruralRte;

    private String ruralDel;

    private String zipCode4;

    private String suiteNumber;

    private String address3;

    private String country;

    private String county;

    private String zipcode5;

    private String companyName;

    private String ecpdId;

    private String custType;

    private String saleType;

    private String campaignMTN;

    private Integer buyMldSeqNum;

    private String buyItemCode;

    private String promoCode;

    private String atgOrderId;

    private Integer itemId;

    private String deviceIds;

    private Integer deviceCount;

    public String getDeviceRecycleOrderId() {
        return deviceRecycleOrderId;
    }
    public void setDeviceRecycleOrderId(String deviceRecycleOrderId) {
        this.deviceRecycleOrderId = deviceRecycleOrderId;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public String getRouteWFM() {
        return routeWFM;
    }
    public void setRouteWFM(String routeWFM) {
        this.routeWFM = routeWFM;
    }
    public String getIsPreOrder() {
        return isPreOrder;
    }
    public void setIsPreOrder(String isPreOrder) {
        this.isPreOrder = isPreOrder;
    }
    public String getIsShipValidated() {
        return isShipValidated;
    }
    public void setIsShipValidated(String isShipValidated) {
        this.isShipValidated = isShipValidated;
    }
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public String getAddress1() {
        return address1;
    }
    public void setAddress1(String address1) {
        this.address1 = address1;
    }
    public String getAddress2() {
        return address2;
    }
    public void setAddress2(String address2) {
        this.address2 = address2;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public String getState() {
        return state;
    }
    public void setState(String state) {
        this.state = state;
    }
    public String getPostalCode() {
        return postalCode;
    }
    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }
    public String getPhoneNumber() {
        return phoneNumber;
    }
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    public String getEmailAddress() {
        return emailAddress;
    }
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }
    public String getFipsCode() {
        return fipsCode;
    }
    public void setFipsCode(String fipsCode) {
        this.fipsCode = fipsCode;
    }
    public String getChannelId() {
        return channelId;
    }
    public void setChannelId(String channelId) {
        this.channelId = channelId;
    }
    public String getSessionId() {
        return sessionId;
    }
    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }
    public String getZipCode() {
        return zipCode;
    }
    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }
    public String getVendorId() {
        return vendorId;
    }
    public void setVendorId(String vendorId) {
        this.vendorId = vendorId;
    }
    public String getClientOrderType() {
        return clientOrderType;
    }
    public void setClientOrderType(String clientOrderType) {
        this.clientOrderType = clientOrderType;
    }
    public String getLocationCode() {
        return locationCode;
    }
    public void setLocationCode(String locationCode) {
        this.locationCode = locationCode;
    }
    public String getOrderType() {
        return orderType;
    }
    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }
    public String getPosOrderNumber() {
        return posOrderNumber;
    }
    public void setPosOrderNumber(String posOrderNumber) {
        this.posOrderNumber = posOrderNumber;
    }
    public String getBuyReferenceNumber() {
        return buyReferenceNumber;
    }
    public void setBuyReferenceNumber(String buyReferenceNumber) {
        this.buyReferenceNumber = buyReferenceNumber;
    }
    public Date getCreateDate() {
        return createDate;
    }
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }
    public String getCreatedby() {
        return createdby;
    }
    public void setCreatedby(String createdby) {
        this.createdby = createdby;
    }
    public Date getUpdateDate() {
        return updateDate;
    }
    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
    public String getIpAddress() {
        return ipAddress;
    }
    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }
    public String getMsgToWFM() {
        return msgToWFM;
    }
    public void setMsgToWFM(String msgToWFM) {
        this.msgToWFM = msgToWFM;
    }
    public String getOrigPosOrderNumber() {
        return origPosOrderNumber;
    }
    public void setOrigPosOrderNumber(String origPosOrderNumber) {
        this.origPosOrderNumber = origPosOrderNumber;
    }
    public String getOrigClientRefNumber() {
        return origClientRefNumber;
    }
    public void setOrigClientRefNumber(String origClientRefNumber) {
        this.origClientRefNumber = origClientRefNumber;
    }
    public String getPriMobileNumber() {
        return priMobileNumber;
    }
    public void setPriMobileNumber(String priMobileNumber) {
        this.priMobileNumber = priMobileNumber;
    }
    public String getAccountNumber() {
        return accountNumber;
    }
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }
    public String getSubAccountNumber() {
        return subAccountNumber;
    }
    public void setSubAccountNumber(String subAccountNumber) {
        this.subAccountNumber = subAccountNumber;
    }
    public String getBillingSystem() {
        return billingSystem;
    }
    public void setBillingSystem(String billingSystem) {
        this.billingSystem = billingSystem;
    }
    public Integer getMarketId() {
        return marketId;
    }
    public void setMarketId(Integer marketId) {
        this.marketId = marketId;
    }
    public String getIsPostLogin() {
        return isPostLogin;
    }
    public void setIsPostLogin(String isPostLogin) {
        this.isPostLogin = isPostLogin;
    }
    public String getAptNum() {
        return aptNum;
    }
    public void setAptNum(String aptNum) {
        this.aptNum = aptNum;
    }
    public String getStreetNum() {
        return streetNum;
    }
    public void setStreetNum(String streetNum) {
        this.streetNum = streetNum;
    }
    public String getStreetType() {
        return streetType;
    }
    public void setStreetType(String streetType) {
        this.streetType = streetType;
    }
    public String getAddType() {
        return addType;
    }
    public void setAddType(String addType) {
        this.addType = addType;
    }
    public String getDir() {
        return dir;
    }
    public void setDir(String dir) {
        this.dir = dir;
    }
    public String getRuralRte() {
        return ruralRte;
    }
    public void setRuralRte(String ruralRte) {
        this.ruralRte = ruralRte;
    }
    public String getRuralDel() {
        return ruralDel;
    }
    public void setRuralDel(String ruralDel) {
        this.ruralDel = ruralDel;
    }
    public String getZipCode4() {
        return zipCode4;
    }
    public void setZipCode4(String zipCode4) {
        this.zipCode4 = zipCode4;
    }
    public String getSuiteNumber() {
        return suiteNumber;
    }
    public void setSuiteNumber(String suiteNumber) {
        this.suiteNumber = suiteNumber;
    }
    public String getAddress3() {
        return address3;
    }
    public void setAddress3(String address3) {
        this.address3 = address3;
    }
    public String getCountry() {
        return country;
    }
    public void setCountry(String country) {
        this.country = country;
    }
    public String getCounty() {
        return county;
    }
    public void setCounty(String county) {
        this.county = county;
    }
    public String getZipcode5() {
        return zipcode5;
    }
    public void setZipcode5(String zipcode5) {
        this.zipcode5 = zipcode5;
    }
    public String getCompanyName() {
        return companyName;
    }
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
    public String getEcpdId() {
        return ecpdId;
    }
    public void setEcpdId(String ecpdId) {
        this.ecpdId = ecpdId;
    }
    public String getCustType() {
        return custType;
    }
    public void setCustType(String custType) {
        this.custType = custType;
    }
    public String getSaleType() {
        return saleType;
    }
    public void setSaleType(String saleType) {
        this.saleType = saleType;
    }
    public String getCampaignMTN() {
        return campaignMTN;
    }
    public void setCampaignMTN(String campaignMTN) {
        this.campaignMTN = campaignMTN;
    }
    public Integer getBuyMldSeqNum() {
        return buyMldSeqNum;
    }
    public void setBuyMldSeqNum(Integer buyMldSeqNum) {
        this.buyMldSeqNum = buyMldSeqNum;
    }
    public String getBuyItemCode() {
        return buyItemCode;
    }
    public void setBuyItemCode(String buyItemCode) {
        this.buyItemCode = buyItemCode;
    }
    public String getPromoCode() {
        return promoCode;
    }
    public void setPromoCode(String promoCode) {
        this.promoCode = promoCode;
    }
    public String getAtgOrderId() {
        return atgOrderId;
    }
    public void setAtgOrderId(String atgOrderId) {
        this.atgOrderId = atgOrderId;
    }
    public Integer getItemId() {
        return itemId;
    }
    public void setItemId(Integer itemId) {
        this.itemId = itemId;
    }
    public String getDeviceIds() {
        return deviceIds;
    }
    public void setDeviceIds(String deviceIds) {
        this.deviceIds = deviceIds;
    }
    public Integer getDeviceCount() {
        return deviceCount;
    }
    public void setDeviceCount(Integer deviceCount) {
        this.deviceCount = deviceCount;
    }

}
