package onevz.soe.prepay.adaptor.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.netty.util.internal.StringUtil;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants;
import onevz.soe.prepay.adaptor.cart.model.cxp.common.ETNIError400Response;
import onevz.soe.prepay.adaptor.cart.model.cxp.request.RetreiveNpanXXRequestModel;
import onevz.soe.prepay.adaptor.cart.model.cxp.response.NpanxxList;
import onevz.soe.prepay.adaptor.cart.model.cxp.response.PageData;
import onevz.soe.prepay.adaptor.cart.model.cxp.response.ResponseZipCodes;
import onevz.soe.prepay.adaptor.cart.model.cxp.response.RetrieveNpaNxxDataResponse;
import onevz.soe.prepay.adaptor.cart.model.cxp.response.RetrieveNpaNxxResponse;
import onevz.soe.prepay.adaptor.cart.model.play.common.error.EcommApiError;
import onevz.soe.prepay.adaptor.cart.util.PrepayAdaptorCartUtil;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import onevz.soe.wsclient.prepay.webclient.model.PrepaidAdaptorWebClientRequest;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_DATA;
import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_ECOMM_SESSION;
import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_FLOW;
import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_P_CSRFTKN;
import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_P_CSRF_TOKEN;

@Service
public class PrepayAdaptorAssignMTNHelper {

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    private PrepayAdaptorWebClient prepayAdaptorCartWebClient;

    @Value("${retrieveNPANXXPlayServiceURL}")
    private String retrieveNPANXXPlayServiceURL;

    @Autowired
    private PrepayCartRedisHelper redisHelper;

    private static final Logger logger = LoggerFactory.getLogger(PrepayAdaptorAssignMTNHelper.class);

    /**
     * @param httpRequest
     * @param retrieveNPANXXRequest
     * @return retrieveNPANXXResponse
     */

    public Mono<ResponseEntity<RetrieveNpaNxxResponse>> retrieveNPANXX(ServerHttpRequest httpRequest, RetreiveNpanXXRequestModel retrieveNPANXXRequest) {
        logger.info(" Starts retrieveNPANXX Helper");
        return redisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)
                .doOnError(onError ->
                    logger.error(" Unable to get data from Redis {}", PREPAY_OD_REQUEST_DATA, onError)
                ).doOnSuccess(onSuccess ->
                    logger.info("Successfully retrieved data from Redis: {}", onSuccess)
                ).flatMap(response -> {
                    if (StringUtilities.isNotEmptyOrNull(response)) {
                        logger.info("Redis Data From Redis:: {}", response);
                        PrepaidODRequestData redisData = null;
                        try {
                            redisData = mapper.readValue(response, PrepaidODRequestData.class);
                        } catch (JsonProcessingException e) {
                            logger.error("Failed to parse data from redis:", e);
                            return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new RetrieveNpaNxxResponse()));
                        }
                        PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = getPrepaidAdaptorWebClientRequest(retrieveNPANXXRequest, redisData);
                        return retrieveNPANXXPrepayODResponse(httpRequest, prepaidAdaptorWebClientRequest);
                    } else {
                        RetrieveNpaNxxResponse retrieveNpaNxxResponse = new RetrieveNpaNxxResponse();
                        return Mono.just(ResponseEntity.status(HttpStatus.OK).body(retrieveNpaNxxResponse));
                    }
                });
    }

    private Mono<ResponseEntity<RetrieveNpaNxxResponse>> retrieveNPANXXPrepayODResponse(ServerHttpRequest
                                                                                                httpRequest, PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest) {
        return prepayAdaptorCartWebClient.getPrepayServiceResponse(httpRequest, prepaidAdaptorWebClientRequest)
                .doOnError(error ->
                    logger.error("Failed to get response, check exception for details.", error)
                )
                .flatMap(response -> {
                    logger.debug(String.format("After getting response:%s", response.getBody().toString()));
                    ResponseZipCodes responseZipCodes = new ResponseZipCodes();
                    RetrieveNpaNxxResponse cxpResponseModel = new RetrieveNpaNxxResponse();
                    PageData pageData = new PageData();
                    List<NpanxxList> list = new ArrayList<>();
                    RetrieveNpaNxxDataResponse retrievedData = new RetrieveNpaNxxDataResponse();
                    if (!response.getStatusCode().is2xxSuccessful()) {
                        logger.error("Error while calling endpoint: {} with status code: {}", prepaidAdaptorWebClientRequest.getUrl(), response.getStatusCode());
                        logger.debug("Error while calling endpoint: {} with status code: {}", prepaidAdaptorWebClientRequest.getUrl(), response.getStatusCode());
                    } else {
                        try {
                            responseZipCodes = mapper.readValue(response.getBody(), ResponseZipCodes.class);
                            logger.debug("Response is {}" , responseZipCodes.getPayload());

                            if ((responseZipCodes.getStatus() != 200) && Objects.nonNull(responseZipCodes.getErrors()) && responseZipCodes.getPayload()==null)
                            {
                                    EcommApiError[] ecommApi = responseZipCodes.getErrors().getEcommApiErrorList();
                                    cxpResponseModel.setStatusMessage(ecommApi[0].getMessage());
                                    cxpResponseModel.setStatusCode("31002");
                                    cxpResponseModel.setErrors(new ETNIError400Response("404","NOT_FOUND"));
                                    return Mono.just(ResponseEntity.status(HttpStatus.OK).body(cxpResponseModel));


                            }
                            pageData = responseZipCodes.getPayload().getPageData();
                            String zip = pageData.getZipCode();
                            String state = pageData.getState();
                            String city = pageData.getCity();

                            for (String npan : pageData.getMtns()) {
                                NpanxxList eachRecord = new NpanxxList();
                                eachRecord.setCity(city);
                                eachRecord.setState(state);
                                eachRecord.setZip(zip);
                                String[] npaNxx = StringUtils.split(npan, "-");
                                eachRecord.setNpa(npaNxx[0]);
                                eachRecord.setNxx(npaNxx[1]);
                                list.add(eachRecord);
                            }

                            retrievedData.setNpanxxlist(list);
                            cxpResponseModel.setStatusCode(responseZipCodes.getStatusCode());
                            cxpResponseModel.setData(retrievedData);
                            cxpResponseModel.setErrors(new ETNIError400Response("200", "Success"));
                            return Mono.just(ResponseEntity.status(response.getStatusCode()).body(cxpResponseModel));
                        } catch (JsonProcessingException e) {
                            logger.error("NpaNxx Json processing error: {} ", e.getMessage());
                        }

                    }
                    return Mono.just(ResponseEntity.status(response.getStatusCode()).body(cxpResponseModel));
                });
    }

    private PrepaidAdaptorWebClientRequest getPrepaidAdaptorWebClientRequest(RetreiveNpanXXRequestModel
                                                                                     retrieveNPANXXRequest, PrepaidODRequestData redisData) {
        Map<String, String> urlParams = new HashMap<>();
        urlParams.put("zipCode", StringUtil.isNullOrEmpty(retrieveNPANXXRequest.getZipcode()) ? retrieveNPANXXRequest.getZip() : retrieveNPANXXRequest.getZipcode());
        urlParams.put("npanxx", retrieveNPANXXRequest.getNpanxx());
        urlParams.put("state", retrieveNPANXXRequest.getState());
        urlParams.put("city", retrieveNPANXXRequest.getCity());

        logger.debug("Before calling PrepaidAdaptorWebClientRequest");
        PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
        //prepaidAdaptorWebClientRequest.setHeader(PrepayAdaptorCartUtil.getPrepayODServiceCommonHeaders(redisData));
        String flowName = Objects.nonNull(redisData) && CollectionUtilities.isNotEmptyOrNull(redisData.getLines())?redisData.getLines().get(redisData.getCurr_line()-1).getFlow(): PrepayAdaptorCartConstants.NSE;
        logger.info("Flowname in RetrieveNpaNxx Service adaptor: {}", flowName);
        Map<String,String> headers=new HashMap<>();
        String flow = PrepayAdaptorCartUtil.getODFlowName(flowName);
        
        if(Objects.nonNull(redisData)) {
        
        String prepaidODRequestCookieStr = PREPAY_OD_REQUEST_ECOMM_SESSION + "=" + redisData.getEcommSessionId()+ ";" +PREPAY_OD_REQUEST_FLOW + "=" + flow + ";"
				+ PREPAY_OD_REQUEST_P_CSRFTKN + "=" + redisData.getPCsrfToken() + ";";
		headers.put(HttpHeaders.COOKIE, prepaidODRequestCookieStr);
		headers.put(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		headers.put(PREPAY_OD_REQUEST_P_CSRF_TOKEN, redisData.getPCsrfToken());
		prepaidAdaptorWebClientRequest.setHeader(headers);
        }
        prepaidAdaptorWebClientRequest.setUrl(retrieveNPANXXPlayServiceURL);
        prepaidAdaptorWebClientRequest.setUrlParameters(urlParams);
        prepaidAdaptorWebClientRequest.setRequestType("GET");
        return prepaidAdaptorWebClientRequest;
    }
}