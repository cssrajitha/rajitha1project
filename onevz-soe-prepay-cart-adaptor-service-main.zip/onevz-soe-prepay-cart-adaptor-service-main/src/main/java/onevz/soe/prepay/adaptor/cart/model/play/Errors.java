package onevz.soe.prepay.adaptor.cart.model.play;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import onevz.soe.prepay.adaptor.cart.model.play.common.error.EcommApiError;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Errors {
    private Integer status;
    private EcommApiError[] EcommApiErrorList;
}
