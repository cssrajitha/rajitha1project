package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by gumapa on 6/23/2017.
 */
public class VZWInstallmentPaymentSchedule implements Serializable {

    private static final long serialVersionUID = 1L;

    private String installmentPaymentScheduleCount;
    private List<String> paymentDate;

    /**
     * Gets the value of the installmentPaymentScheduleCount property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getInstallmentPaymentScheduleCount() {
        return installmentPaymentScheduleCount;
    }

    /**
     * Sets the value of the installmentPaymentScheduleCount property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setInstallmentPaymentScheduleCount(String value) {
        this.installmentPaymentScheduleCount = value;
    }

    /**
     * Gets the value of the paymentDate property.
     *
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the paymentDate property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPaymentDate().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     *
     *
     */
    public List<String> getPaymentDate() {
        if (paymentDate == null) {
            paymentDate = new ArrayList<String>();
        }
        return this.paymentDate;
    }

    public void setPaymentDate(List<String> paymentDate) {
        this.paymentDate = paymentDate;
    }

}
