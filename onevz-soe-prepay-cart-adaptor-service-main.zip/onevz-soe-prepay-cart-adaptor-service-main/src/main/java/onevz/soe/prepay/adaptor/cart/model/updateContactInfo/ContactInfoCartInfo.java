package onevz.soe.prepay.adaptor.cart.model.updateContactInfo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;
import onevz.soe.prepay.adaptor.cart.model.updateContactInfo.play.Address;
import onevz.soe.wsclient.bpm.model.CartInfo;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ContactInfoCartInfo extends CartInfo {
    public String itemType;
    public String intendType;
    public String action;
    public List<Line> lines;
    public boolean paperLessBilling;
    public boolean receiveSpecialOfferUpdates;
    public String accountPin;
    public Address billingAddress;
    private String statusCode;
    private String statusMessage;
}
