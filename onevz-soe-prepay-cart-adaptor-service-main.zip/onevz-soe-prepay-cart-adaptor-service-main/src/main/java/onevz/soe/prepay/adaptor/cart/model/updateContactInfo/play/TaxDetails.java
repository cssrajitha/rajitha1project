package onevz.soe.prepay.adaptor.cart.model.updateContactInfo.play;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class TaxDetails {
    @JsonProperty(value = "CAStateSalesTax")
    private String CAStateSalesTax;
    @JsonProperty(value = "CALocalSalesTax")
    private String CALocalSalesTax;

}