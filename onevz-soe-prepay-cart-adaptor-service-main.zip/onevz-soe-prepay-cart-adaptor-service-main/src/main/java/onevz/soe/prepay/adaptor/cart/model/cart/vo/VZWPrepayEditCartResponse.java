package onevz.soe.prepay.adaptor.cart.model.cart.vo;
import lombok.Data;

@Data
public class VZWPrepayEditCartResponse {
    private String status;
    private VZWPrepayEditCartResponsePayload payload;
}
