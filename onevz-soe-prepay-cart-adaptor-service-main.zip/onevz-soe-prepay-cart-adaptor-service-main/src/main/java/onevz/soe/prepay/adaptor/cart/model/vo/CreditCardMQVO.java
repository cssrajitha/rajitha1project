package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;
import java.util.Date;

public class CreditCardMQVO extends PaymentGroup implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -559007903627077408L;
	private String creditCardNumber;
	private String creditCardType;	
	private String creditCardExpMonth;
	private String creditCardExpYear;
	private String creditCardVerificationNumber;
	private String authenticationValue;
	private String ecommerceIndicator;
	private String secureTxnId;
	private int version;
	private Date lastModifedDate;
	private boolean creditCardValidated;
	private String billingAddressValidated = "N";
	private String paymentType;

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getCreditCardNumber() {
		return creditCardNumber;
	}

	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}

	public String getCreditCardType() {
		return creditCardType;
	}

	public void setCreditCardType(String creditCardType) {
		this.creditCardType = creditCardType;
	}	
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		StringBuffer sb = new StringBuffer();
		sb.append(" card number => " + this.creditCardNumber);
		sb.append(" card type => " + this.creditCardType);
		sb.append(" card expiration month => " + this.creditCardExpMonth);
		sb.append(" cart expiration year => " + this.creditCardExpYear);
		return sb.toString();
	}	

	public String getCreditCardExpYear() {
		return creditCardExpYear;
	}

	public void setCreditCardExpYear(String creditCardExpYear) {
		this.creditCardExpYear = creditCardExpYear;
	}

	public String getCreditCardVerificationNumber() {
		return creditCardVerificationNumber;
	}

	public void setCreditCardVerificationNumber(String creditCardVerificationNumber) {
		this.creditCardVerificationNumber = creditCardVerificationNumber;
	}

	public String getCreditCardExpMonth() {
		return this.creditCardExpMonth;
	}

	public void setCreditCardExpMonth(String creditCardExpMonth) {
		this.creditCardExpMonth = creditCardExpMonth;
	}

	public String getAuthenticationValue() {
		return authenticationValue;
	}

	public void setAuthenticationValue(String authenticationValue) {
		this.authenticationValue = authenticationValue;
	}	

	public String getEcommerceIndicator() {
		return ecommerceIndicator;
	}

	public void setEcommerceIndicator(String ecommerceIndicator) {
		this.ecommerceIndicator = ecommerceIndicator;
	}

	public String getSecureTxnId() {
		return secureTxnId;
	}

	public void setSecureTxnId(String secureTxnId) {
		this.secureTxnId = secureTxnId;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public Date getLastModifedDate() {
		return lastModifedDate;
	}

	public void setLastModifedDate(Date lastModifedDate) {
		this.lastModifedDate = lastModifedDate;
	}

	public boolean isCreditCardValidated() {
		return creditCardValidated;
	}

	public void setCreditCardValidated(boolean creditCardValidated) {
		this.creditCardValidated = creditCardValidated;
	}

	public String getBillingAddressValidated() {
		return billingAddressValidated;
	}

	public void setBillingAddressValidated(String billingAddressValidated) {
		this.billingAddressValidated = billingAddressValidated;
	}

}
