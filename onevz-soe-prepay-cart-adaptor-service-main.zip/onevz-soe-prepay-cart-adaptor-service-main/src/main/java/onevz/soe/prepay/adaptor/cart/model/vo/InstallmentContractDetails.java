package onevz.soe.prepay.adaptor.cart.model.vo;


import java.io.Serializable;

public class InstallmentContractDetails implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -7526977565059263347L;
	private String id;
	private String installmentContractResp;
	private VZWInstallmentContractDetail installmentContractDetails;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getInstallmentContractResp() {
		return installmentContractResp;
	}
	public void setInstallmentContractResp(String installmentContractResp) {
		this.installmentContractResp = installmentContractResp;
	}

	public VZWInstallmentContractDetail getInstallmentContractDetails() {
		return installmentContractDetails;
	}

	public void setInstallmentContractDetails(VZWInstallmentContractDetail installmentContractDetails) {
		this.installmentContractDetails = installmentContractDetails;
	}
}
