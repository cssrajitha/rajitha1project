package onevz.soe.prepay.adaptor.cart.model.bpm;

import lombok.Data;

import java.util.HashMap;
import java.util.List;

@Data
public class AddDeviceToPrepayODAddAccessoriesResponse {
    private List<AddDeviceToPrepayODAddAccessoriesOutput> output;
    private HashMap<String,String> errorMap ;
    private String statusMessage;
    private String statusCode;
}
