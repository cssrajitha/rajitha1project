package onevz.soe.prepay.adaptor.cart.model.play;

import onevz.soe.prepay.adaptor.cart.model.play.common.error.EcommBaseError;
import onevz.soe.prepay.adaptor.cart.model.play.common.error.EcommValidationError;

import java.io.Serializable;

import java.util.HashMap;

/**
 * Created by vempsr2 on 10/5/2017.
 */
public class VZWPrepayAddOrUpdateCartResponse implements Serializable{

    private static final long serialVersionUID = 1L;

    private String orderId;
    private boolean orderUpdated;
    private boolean success;
    private EcommValidationError errors;
    private HashMap<String,String> errorMap ;

    private EcommBaseError baseError;

    private int status;

    private int totalLines;

    private int cartCount ;
    private boolean is5gTo4gTransition;
    private String devCommerceId;

    public String getDevCommerceId() {
        return devCommerceId;
    }

    public void setDevCommerceId(String devCommerceId) {
        this.devCommerceId = devCommerceId;
    }

    public boolean isIs5gTo4gTransition() {
        return is5gTo4gTransition;
    }

    public void setIs5gTo4gTransition(boolean is5gTo4gTransition) {
        this.is5gTo4gTransition = is5gTo4gTransition;
    }


    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public boolean isOrderUpdated() {
        return orderUpdated;
    }

    public void setOrderUpdated(boolean orderUpdated) {
        this.orderUpdated = orderUpdated;
    }



    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public HashMap<String, String> getErrorMap() {
        return errorMap;
    }

    public void setErrorMap(HashMap<String, String> errorMap) {
        this.errorMap = errorMap;
    }

    public int getTotalLines() {
        return totalLines;
    }

    public void setTotalLines(int totalLines) {
        this.totalLines = totalLines;
    }

    public int getCartCount() {
        return cartCount;
    }

    public void setCartCount(int cartCount) {
        this.cartCount = cartCount;
    }

    public String getNextCyclePay() {
        return nextCyclePay;
    }

    public void setNextCyclePay(String nextCyclePay) {
        this.nextCyclePay = nextCyclePay;
    }

    public String nextCyclePay;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public EcommBaseError getBaseError() {
        return baseError;
    }

    public void setBaseError(EcommBaseError baseError) {
        this.baseError = baseError;
    }

    public EcommValidationError getErrors() {
        return errors;
    }

    public void setErrors(EcommValidationError errors) {
        this.errors = errors;
    }
}
