package onevz.soe.prepay.adaptor.cart.model.play;

import lombok.Data;

import java.util.List;

@Data
public class PrepaidODAddAccessoriesRequest {
    private List<PrepaidODAccessory> accessories;
}
