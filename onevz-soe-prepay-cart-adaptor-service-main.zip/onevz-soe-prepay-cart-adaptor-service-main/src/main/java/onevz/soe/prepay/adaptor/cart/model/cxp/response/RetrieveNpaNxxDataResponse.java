package onevz.soe.prepay.adaptor.cart.model.cxp.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * Developed By: Pavani M
 * Last Modified 2/3/2022 03:31 PM
 * Copyright (c) 2019. All right reserved
 *
 * POJO class
 */
@Getter
@Setter
@NoArgsConstructor
public class RetrieveNpaNxxDataResponse {
	private String npanxxOwner;
	private String resultTyp;
	private String rowPop;
	private List<NpanxxList> npanxxlist;
	private boolean enablePortInLater;
}
