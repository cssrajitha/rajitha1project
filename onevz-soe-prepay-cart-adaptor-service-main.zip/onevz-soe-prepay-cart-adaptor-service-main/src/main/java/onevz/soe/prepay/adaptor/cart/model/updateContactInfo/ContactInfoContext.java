package onevz.soe.prepay.adaptor.cart.model.updateContactInfo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;
import onevz.soe.cart.model.common.ProcessMTNList;
import onevz.soe.wsclient.bpm.model.Context;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ContactInfoContext extends Context {
    private ContactInfoCustomerInfo customerInfo;
    private ContactInfoCartInfo cartInfo;
    private List<ProcessMTNList> processMTNList;
}
