package onevz.soe.prepay.adaptor.cart.model.cart.vo;

import java.io.Serializable;
import java.util.Date;

public class TaxDetail implements Serializable{

	
	private static final long serialVersionUID = 1L;
	private String taxLineItemId;

	private String lineItemId;
	
	private String itemType;
	
	private String sorSkuId;
	private String taxType;
	private Double taxAmount;
	private String taxDescription;
	private int version;
	private String orderId;
	private Date createdDate;
	
	
	public String getLineItemId() {
		return lineItemId;
	}
	public void setLineItemId(String lineItemId) {
		this.lineItemId = lineItemId;
	}
	public String getItemType() {
		return itemType;
	}
	public void setItemType(String itemType) {
		this.itemType = itemType;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	/**
	 * @return the version
	 */
	public int getVersion() {
		return version;
	}
	/**
	 * @param version the version to set
	 */
	public void setVersion(int version) {
		this.version = version;
	}
	/**
	 * @return the taxLineItemId
	 */
	public String getTaxLineItemId() {
		return taxLineItemId;
	}
	/**
	 * @param taxLineItemId the taxLineItemId to set
	 */
	public void setTaxLineItemId(String taxLineItemId) {
		this.taxLineItemId = taxLineItemId;
	}
	
	public String getSorSkuId() {
		return sorSkuId;
	}
	public void setSorSkuId(String sorSkuId) {
		this.sorSkuId = sorSkuId;
	}
	public String getTaxType() {
		return taxType;
	}
	public void setTaxType(String taxType) {
		this.taxType = taxType;
	}
	
	public Double getTaxAmount() {
		if(taxAmount != null){
			return taxAmount;
		}else{
			return 0.0D;
		}
	}
	public void setTaxAmount(Double taxAmount) {
		this.taxAmount = taxAmount;
	}
	public String getTaxDescription() {
		return taxDescription;
	}
	public void setTaxDescription(String taxDescription) {
		this.taxDescription = taxDescription;
	}
	
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TaxDetail [sorSkuId=" + sorSkuId + ", taxType=" + taxType + ", taxAmount=" + taxAmount
				+ ", taxDescription=" + taxDescription + "]";
	}
	
}
