package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 *
 */
public class ShippingGroup implements Serializable {

	private static final long serialVersionUID = 1L;
	private String shippingGroupId;
	private String orderId;
	private String shippingGroupType;
	private String shippingType;
	private String shippingMethod;
	private String shippingMethodId;
	private String shippingGroupStatus;
	private String depletionLocation;
	private String deliveryDate;
	private String deliveryTime;
	private String fipsCode;
	private double rawShippingPrice;
	private double discountAmount;
	private double taxAmount;
	private String taxDescription;
	private String taxType;
	private String priceAdjustmentId;
	private double shippingCost;
	private double shippingSaving;
	private String signatureRequired="N";
	private Integer overnightShipPriorityFlag=0;
	private String storeInfoId;
   // private String shippingContactInfoId;
	private ContactInfo shippingContactInfo;
	private String estimatedDeliveryDate;
	private List<TaxDetail> taxDetails;
	private int version;
	private Date lastModifiedDate;
	private StoreInfo storeAddress;
    private boolean sameDayDelivery;
    private String sddDeliveryWindow;
	private String sddDeliveryWindowStartTime;
	private String sddDeliveryWindowEndTime;
	private String userTimeZone;
	private String sddDeliveryDate;
	private String sddLocationSalesId;
	private boolean curbsidestoreeligible;
	private String curbsidestoremessage;

	public String getIspuSetUpIndicator() {
		return ispuSetUpIndicator;
	}

	public void setIspuSetUpIndicator(String ispuSetUpIndicator) {
		this.ispuSetUpIndicator = ispuSetUpIndicator;
	}

	private String ispuSetUpIndicator;
	public StoreInfo getStoreAddress() {
		return storeAddress;
	}

	public void setStoreAddress(StoreInfo storeAddress) {
		this.storeAddress = storeAddress;
	}

	public Integer getOvernightShipPriorityFlag() {
		return overnightShipPriorityFlag;
	}

	public void setOvernightShipPriorityFlag(Integer overnightShipPriorityFlag) {
		this.overnightShipPriorityFlag = overnightShipPriorityFlag;
	}

	/*public String getShippingContactInfoId() {
		return shippingContactInfoId;
	}

	public void setShippingContactInfoId(String shippingContactInfoId) {
		this.shippingContactInfoId = shippingContactInfoId;
	}*/

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	/**
	 * @return the version
	 */
	public int getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(int version) {
		this.version = version;
	}

	public String getShippingGroupId() {
		return shippingGroupId;
	}

	public void setShippingGroupId(String shippingGroupId) {
		this.shippingGroupId = shippingGroupId;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getShippingGroupType() {
		return shippingGroupType;
	}

	public void setShippingGroupType(String shippingGroupType) {
		this.shippingGroupType = shippingGroupType;
	}

	public String getShippingType() {
		return shippingType;
	}

	public void setShippingType(String shippingType) {
		this.shippingType = shippingType;
	}

	public String getShippingMethod() {
		return shippingMethod;
	}

	public void setShippingMethod(String shippingMethod) {
		this.shippingMethod = shippingMethod;
	}

	public String getShippingMethodId() {
		return shippingMethodId;
	}

	public void setShippingMethodId(String shippingMethodId) {
		this.shippingMethodId = shippingMethodId;
	}

	public String getShippingGroupStatus() {
		return shippingGroupStatus;
	}

	public void setShippingGroupStatus(String shippingGroupStatus) {
		this.shippingGroupStatus = shippingGroupStatus;
	}

	public String getDepletionLocation() {
		return depletionLocation;
	}

	public void setDepletionLocation(String depletionLocation) {
		this.depletionLocation = depletionLocation;
	}

	public String getDeliveryDate() {
		return deliveryDate;
	}

	public void setDeliveryDate(String deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	public String getDeliveryTime() {
		return deliveryTime;
	}

	public void setDeliveryTime(String deliveryTime) {
		this.deliveryTime = deliveryTime;
	}

	public String getFipsCode() {
		return fipsCode;
	}

	public void setFipsCode(String fipsCode) {
		this.fipsCode = fipsCode;
	}

	public double getRawShippingPrice() {
		return rawShippingPrice;
	}

	public void setRawShippingPrice(double rawShippingPrice) {
		this.rawShippingPrice = rawShippingPrice;
	}

	public double getDiscountAmount() {
		return discountAmount;
	}

	public void setDiscountAmount(double discountAmount) {
		this.discountAmount = discountAmount;
	}

	public double getTaxAmount() {
		return taxAmount;
	}

	public void setTaxAmount(double taxAmount) {
		this.taxAmount = taxAmount;
	}

	public String getTaxDescription() {
		return taxDescription;
	}

	public void setTaxDescription(String taxDescription) {
		this.taxDescription = taxDescription;
	}

	public String getTaxType() {
		return taxType;
	}

	public void setTaxType(String taxType) {
		this.taxType = taxType;
	}

	public String getPriceAdjustmentId() {
		return priceAdjustmentId;
	}

	public void setPriceAdjustmentId(String priceAdjustmentId) {
		this.priceAdjustmentId = priceAdjustmentId;
	}

	public double getShippingCost() {
		return shippingCost;
	}

	public void setShippingCost(double shippingCost) {
		this.shippingCost = shippingCost;
	}

	public double getShippingSaving() {
		return shippingSaving;
	}

	public void setShippingSaving(double shippingSaving) {
		this.shippingSaving = shippingSaving;
	}

	public String getSignatureRequired() {
		return signatureRequired;
	}

	public void setSignatureRequired(String signatureRequired) {
		this.signatureRequired = signatureRequired;
	}

	public String getStoreInfoId() {
		return storeInfoId;
	}

	public void setStoreInfoId(String storeInfoId) {
		this.storeInfoId = storeInfoId;
	}

	public ContactInfo getShippingContactInfo() {
		return shippingContactInfo;
	}

	public void setShippingContactInfo(ContactInfo shippingContactInfo) {
		this.shippingContactInfo = shippingContactInfo;
	}

	public String getEstimatedDeliveryDate() {
		return estimatedDeliveryDate;
	}

	public void setEstimatedDeliveryDate(String estimatedDeliveryDate) {
		this.estimatedDeliveryDate = estimatedDeliveryDate;
	}

	public List<TaxDetail> getTaxDetails() {
		return taxDetails;
	}

	public void setTaxDetails(List<TaxDetail> taxDetails) {
		this.taxDetails = taxDetails;
	}
    public boolean isSameDayDelivery() {
        return sameDayDelivery;
    }

    public void setSameDayDelivery(boolean sameDayDelivery) {
        this.sameDayDelivery = sameDayDelivery;
    }

	public String getSddDeliveryWindow() {
		return sddDeliveryWindow;
	}

	public void setSddDeliveryWindow(String sddDeliveryWindow) {
		this.sddDeliveryWindow = sddDeliveryWindow;
	}

	public String getSddDeliveryWindowStartTime() {
		return sddDeliveryWindowStartTime;
	}

	public void setSddDeliveryWindowStartTime(String sddDeliveryWindowStartTime) {
		this.sddDeliveryWindowStartTime = sddDeliveryWindowStartTime;
	}

	public String getSddDeliveryWindowEndTime() {
		return sddDeliveryWindowEndTime;
	}

	public void setSddDeliveryWindowEndTime(String sddDeliveryWindowEndTime) {
		this.sddDeliveryWindowEndTime = sddDeliveryWindowEndTime;
	}

	public String getUserTimeZone() {
		return userTimeZone;
	}

	public void setUserTimeZone(String userTimeZone) {
		this.userTimeZone = userTimeZone;
	}

	public String getSddDeliveryDate() {
		return sddDeliveryDate;
	}

	public void setSddDeliveryDate(String sddDeliveryDate) {
		this.sddDeliveryDate = sddDeliveryDate;
	}

	public String getSddLocationSalesId() {
		return sddLocationSalesId;
	}

	public void setSddLocationSalesId(String sddLocationSalesId) {
		this.sddLocationSalesId = sddLocationSalesId;
	}

	public boolean getCurbsidestoreeligible() {
		return curbsidestoreeligible;
	}

	public void setCurbsidestoreeligible(boolean curbsidestoreeligible) {
		this.curbsidestoreeligible = curbsidestoreeligible;
	}


	public String getCurbsidestoremessage() {
		return curbsidestoremessage;
	}

	public void setCurbsidestoremessage(String curbsidestoremessage) {
		this.curbsidestoremessage = curbsidestoremessage;
	}
}
