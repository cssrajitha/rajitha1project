package onevz.soe.prepay.adaptor.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.common.model.PrepaidODRequestDataLines;
import onevz.soe.orderprocess.model.checkoutdetails.*;
import onevz.soe.orderprocess.request.CheckoutDetailsCXPRequest;
import onevz.soe.orderprocess.response.cxp.CheckoutDetailsCXPResponse;
import onevz.soe.orderprocess.response.cxp.CheckoutDetailsResponseData;
import onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants;
import onevz.soe.prepay.adaptor.cart.model.cart.vo.PrepayDeviceVO;
import onevz.soe.prepay.adaptor.cart.model.checkoutdetails.PendingStepsEnum;
import onevz.soe.prepay.adaptor.cart.model.play.CheckoutDetailsPrepayResponse;
import onevz.soe.prepay.adaptor.cart.model.play.VZWPrepayOrderVO;
import onevz.soe.prepay.adaptor.cart.model.play.shippingoptions.VZWPrepayShippingOptionsResponse;
import onevz.soe.prepay.adaptor.cart.model.play.shippingoptions.VZWPrepayShippingResponseVO;
import onevz.soe.prepay.adaptor.cart.util.PrepayAdaptorCartUtil;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import onevz.soe.wsclient.prepay.webclient.model.PrepaidAdaptorWebClientRequest;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.*;

@Service
public class PrepayAdaptorNSECheckoutDetailsHelper {

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    private PrepayAdaptorWebClient prepayAdaptorWebClient;

    @Autowired
    private PrepayCartRedisHelper prepayCartRedisHelper;

    @Autowired
    PrepayAdaptorCheckOutDetailsODToCXPRespConverter checkOutDetailsODToCXPRespConverter;

    @Value("${checkoutDetailsLegacyServiceUrl}")
    private String checkoutDetailsLegacyServiceUrl;

    @Value("${shippingDetailsLegacyServiceUrl}")
    private String shippingDetailsLegacyServiceUrl;

    private static Logger logger = LoggerFactory.getLogger(PrepayAdaptorNSECheckoutDetailsHelper.class);

    public Mono<ResponseEntity<CheckoutDetailsCXPResponse>> getCheckoutDetails(ServerHttpRequest httpRequest, CheckoutDetailsCXPRequest checkoutDetailsCXPRequest){
        logger.info("get-checkout-details adaptor Request: {}", checkoutDetailsCXPRequest);
        return prepayCartRedisHelper.getDataFromRedisAsString(PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_DATA)
                .doOnError(err -> Mono.just(new ResponseEntity<CheckoutDetailsCXPResponse>(new CheckoutDetailsCXPResponse(), HttpStatus.OK)))
                .flatMap(redisData -> {
                    logger.info("PrepaidODRequestData From Redis:: {} ", redisData);
                    if (StringUtilities.isEmptyOrNull(redisData)) {
                        logger.info("PrepaidODRequestData from Redis is empty {}", redisData);
                        return Mono.just(new ResponseEntity<CheckoutDetailsCXPResponse>(new CheckoutDetailsCXPResponse(), HttpStatus.INTERNAL_SERVER_ERROR));
                        //TODO:: Send proper error by setting SOEErrorMap
                    }
                    try {
                        PrepaidODRequestData prepaidODRequestData = mapper.readValue(redisData, PrepaidODRequestData.class);
                        // removing p_csrftkn check as that is not mandatory for checkout call on OD services side
                        //if(StringUtilities.isEmptyOrNull(prepaidODRequestData.getEcommSessionId()) || StringUtilities.isEmptyOrNull(prepaidODRequestData.getPCsrfToken())){
                        if(StringUtilities.isEmptyOrNull(prepaidODRequestData.getEcommSessionId())){
                            logger.info("ECOMM_SESSION is empty");
                            return Mono.just(new ResponseEntity<CheckoutDetailsCXPResponse>(new CheckoutDetailsCXPResponse(), HttpStatus.INTERNAL_SERVER_ERROR));
                            //TODO:: Send proper error by setting SOEErrorMap
                        }
                        if(Objects.isNull(prepaidODRequestData) || (Objects.nonNull(prepaidODRequestData) && CollectionUtilities.isEmptyOrNull(prepaidODRequestData.getLines()))) {
                            logger.info("Cart Lines are empty");
                            return Mono.just(new ResponseEntity<CheckoutDetailsCXPResponse>(new CheckoutDetailsCXPResponse(), HttpStatus.OK));
                        }

                        prepaidODRequestData.getLines().stream().forEach(line->line.setStageCheckpointFlag(true));

                        Optional<PrepaidODRequestDataLines> requestDataLineWithChecoutFlagOptional = prepaidODRequestData.getLines().stream().filter(line-> line.isCheckoutFlag() == false).findFirst();
                        Optional<PrepaidODRequestDataLines> requestDataLineWithPlansNotUpdated = prepaidODRequestData.getLines().stream().filter(line-> line.isPlanUpdated() == false).findFirst();

                        if(requestDataLineWithChecoutFlagOptional.isPresent() || (Objects.nonNull(checkoutDetailsCXPRequest.getData()) && checkoutDetailsCXPRequest.getData().isGridwall())){
                            Mono<ResponseEntity<CheckoutDetailsCXPResponse>> checkoutDetailsRespFromRedis = getResponseUsingPrepaidODRequestDataLines(checkoutDetailsCXPRequest, prepaidODRequestData, httpRequest);
                            //PrepaidODRequestDataLines dataLineToUpdate = requestDataLineWithChecoutFlagOptional.get();
                            //dataLineToUpdate.setStageCheckpointFlag(true); //Handling BackButton scenarios, set stageCheckoutFlag=true
                            return prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, prepaidODRequestData)
                                    .doOnError(err -> logger.info("Failed to update the PrepaidODRequestData to Redis", err))
                                    .flatMap(upsertResp -> {
                                        logger.info("Successfully inserted PrepaidODRequestData to Redis:: {}  " , upsertResp);
                                        return checkoutDetailsRespFromRedis;
                                    });
                        }

                        PrepaidAdaptorWebClientRequest prepaidLegacyServiceRequest = getPrepaidCheckoutDetailsServiceRequest(prepaidODRequestData, checkoutDetailsCXPRequest);
                        logger.info("BAU Soe Api Url : INFO Inside PrepayAdaptorNSECheckoutDetailsHelper: getCheckoutDetails: 108 {}", checkoutDetailsCXPRequest);
                        return prepayAdaptorWebClient.getPrepayServiceResponse(httpRequest, prepaidLegacyServiceRequest)
                                .doOnError(error -> logger.info("Failed to get response for prepaidODGetCheckoutDetails service, error:", error))
                                .flatMap(prepayODGetCheckoutDetailsResponseEntity -> {
                                    if (!prepayODGetCheckoutDetailsResponseEntity.getStatusCode().is2xxSuccessful()) {
                                        logger.info("Error while calling prepaidODGetCheckoutDetails Service, status code: {}", prepayODGetCheckoutDetailsResponseEntity.getStatusCode());
                                        return Mono.just(new ResponseEntity<CheckoutDetailsCXPResponse>(new CheckoutDetailsCXPResponse(), prepayODGetCheckoutDetailsResponseEntity.getStatusCode()));
                                    }
                                    CheckoutDetailsPrepayResponse checkoutDetailsPrepayResponse = null;
                                    CheckoutDetailsCXPResponse checkoutDetailsCXPResponse = null;
                                    try {
                                        checkoutDetailsPrepayResponse = mapper.readValue(prepayODGetCheckoutDetailsResponseEntity.getBody(), CheckoutDetailsPrepayResponse.class);

                                        logger.info("is submit order soe :: {}", checkoutDetailsCXPRequest.isSubmitOrderSoe());
                                        logger.info("get-checkout-details :: prepay OD response :: {}", prepayODGetCheckoutDetailsResponseEntity.getBody());
                                        logger.info("get-checkout-details :: Device list :: {}", checkoutDetailsPrepayResponse.getPayload().getPageData().getDeviceList());

                                        if(null != checkoutDetailsPrepayResponse && null != checkoutDetailsPrepayResponse.getPayload()
                                                && null != checkoutDetailsPrepayResponse.getPayload().getPageData()){
                                            VZWPrepayOrderVO vzwPrepayOrderVO = checkoutDetailsPrepayResponse.getPayload().getPageData();

                                            for(PrepayDeviceVO prepayLine : vzwPrepayOrderVO.getDeviceList()){
                                                if (StringUtilities.isNotEmptyOrNull(prepayLine.getNumberShareLineItemId())) {
                                                    for(PrepaidODRequestDataLines prepaidODRequestDataLine : prepaidODRequestData.getLines()){
                                                        if(prepaidODRequestDataLine.isCheckoutFlag()) {
                                                            if (prepaidODRequestDataLine.getLineItemId().equalsIgnoreCase(prepayLine.getId())) {
                                                                prepaidODRequestDataLine.setNumberShareLineItemId(prepayLine.getNumberShareLineItemId());
                                                                prepaidODRequestDataLine.setSelectedMtn(prepayLine.getNpaNxxCode());
                                                            }
                                                        }
                                                    }
                                                }
                                            }

                                            //TODO:: Error respons has different object structure
                                            CheckoutDetailsCXPResponse checkoutDetailsCXPResponse1 = checkOutDetailsODToCXPRespConverter.translateCheckoutDetails(vzwPrepayOrderVO, prepaidODRequestData, httpRequest, checkoutDetailsCXPRequest);
                                            //isByodFlow
                                            AtomicBoolean isByodFlow = new AtomicBoolean(false);
                                            if((!NSE.equalsIgnoreCase(vzwPrepayOrderVO.getFlow()) && Arrays.asList(NSP, NAP, PASO).contains(vzwPrepayOrderVO.getFlow()))){
                                                isByodFlow.set(true);
                                            }
                                            if(null!=checkoutDetailsCXPRequest.getData() && checkoutDetailsCXPRequest.getData().isShippingOptions() && getShippingOptionsFlag(vzwPrepayOrderVO)){
                                                PrepaidAdaptorWebClientRequest prepaidLegacyShippingServiceRequest = getPrepaidShippingServiceRequest(prepaidODRequestData);
                                                logger.info("BAU Soe Api Url : INFO Inside PrepayAdaptorNSECheckoutDetailsHelper: getCheckoutDetails: 148 {}", checkoutDetailsCXPRequest);
                                                return prepayAdaptorWebClient.getPrepayServiceResponse(httpRequest, prepaidLegacyShippingServiceRequest)
                                                        .doOnError(error -> logger.info("Failed to get response for prepaidODShippingDetails service, error:", error))
                                                        .flatMap(prepayODShippingDetailsResponseEntity -> {
                                                            logger.info("Successful response from api: {}", prepaidLegacyServiceRequest.getUrl());
                                                            if (!prepayODShippingDetailsResponseEntity.getStatusCode().is2xxSuccessful()) {
                                                                logger.info("Error while calling prepaidODShippingDetails Service, status code: {}", prepayODShippingDetailsResponseEntity.getStatusCode());
                                                                return Mono.just(ResponseEntity.ok(checkoutDetailsCXPResponse1));
                                                            }
                                                            VZWPrepayShippingOptionsResponse vzwPrepayShippingOptionsResponse = null;
                                                            VZWPrepayShippingResponseVO shippingResponse = null;
                                                            try {
                                                                vzwPrepayShippingOptionsResponse = mapper.readValue(prepayODShippingDetailsResponseEntity.getBody(), VZWPrepayShippingOptionsResponse.class);
                                                                if(null!=vzwPrepayShippingOptionsResponse.getPayload()) shippingResponse = vzwPrepayShippingOptionsResponse.getPayload().getPageData();

                                                            } catch (JsonProcessingException e) {
                                                                logger.info("Failed to convert response received from PrepaidOD CheckoutDetails ShippingOption", e);
                                                                //return Mono.just(new ResponseEntity<CheckoutDetailsCXPResponse>(new CheckoutDetailsCXPResponse(), HttpStatus.INTERNAL_SERVER_ERROR));
                                                            }
                                                            return Mono.just(new ResponseEntity<CheckoutDetailsCXPResponse>(checkOutDetailsODToCXPRespConverter.updateShippingDetails(checkoutDetailsCXPResponse1, shippingResponse, isByodFlow.get()), HttpStatus.OK));
                                                        });

                                            }

                                            return processingForSmartWatch(prepaidODRequestData,checkoutDetailsCXPResponse1);
                                           // return Mono.just(new ResponseEntity<CheckoutDetailsCXPResponse>(checkoutDetailsCXPResponse1, HttpStatus.OK));
                                        }

                                    } catch (JsonMappingException e) {
                                        logger.info("prepayOD response JsonMappingException : {}", e.getMessage());
                                    } catch (JsonProcessingException e) {
                                        logger.info("prepayOD response JsonProcessingException : {}", e.getMessage());
                                    }
                                    return Mono.just(ResponseEntity.status(prepayODGetCheckoutDetailsResponseEntity.getStatusCode()).body(checkoutDetailsCXPResponse));
                                });

                    } catch (JsonProcessingException ex) {
                        logger.info("Failed to convert response received from PrepaidOD CheckoutDetails", ex);
                        return Mono.just(new ResponseEntity<CheckoutDetailsCXPResponse>(new CheckoutDetailsCXPResponse(), HttpStatus.INTERNAL_SERVER_ERROR));
                        //TODO:: Send proper error by setting SOEErrorMap
                    }


                });
    }


    private Mono<ResponseEntity<CheckoutDetailsCXPResponse>> processingForSmartWatch(PrepaidODRequestData prepaidODRequestData,CheckoutDetailsCXPResponse response) {
        logger.info("processing for smartwatch");

        prepaidODRequestData.getLines().stream().forEach(e->e.setPaired(false));

        List<PrepaidODRequestDataLines> watchOnNumberShare=prepaidODRequestData.getLines().stream().filter(lineData->lineData.isSmartWatch() && StringUtilities.isNotEmptyOrNull(lineData.getPlanSorId()) && lineData.getPlanSorId().equals("28445")).collect(Collectors.toList());
        List<PrepaidODRequestDataLines> watchOnCart=prepaidODRequestData.getLines().stream().filter(lineData->lineData.isSmartWatch() && StringUtilities.isNotEmptyOrNull(lineData.getPlanSorId())).collect(Collectors.toList());
        List<String> blockerWatchList = new ArrayList<>();
        watchOnNumberShare.stream().forEach(watch->
                prepaidODRequestData.getLines().stream().filter(lineData->lineData.isSmartPhone() && !lineData.isPaired() && Arrays.stream(watch.getNumbershareEligibleOS().split(",")).anyMatch(eligibleOs->eligibleOs.contains(lineData.getOsType())))
                        .findFirst().ifPresentOrElse(lineData-> {
                            watch.setPaired(true);
                            lineData.setPaired(true);},()-> {
                            response.getData().getCart().setEnableSWBlockerBanner(true);
                            if (Objects.nonNull(response.getData()) && Objects.nonNull(response.getData().getCart())) {
                                response.getData().getCart().setEnableSWBlockerBanner(true);
                                blockerWatchList.add(watch.getDisplayName());
                        }
                        }));
        if (Objects.nonNull(response.getData()) && Objects.nonNull(response.getData().getCart())) {
            response.getData().getCart().setBlockerBannerSWNames(blockerWatchList);
        }

        Optional<PrepaidODRequestDataLines> smartWatchLine=prepaidODRequestData.getLines().stream().filter(line->line.isSmartWatch() && line.getMtn().equalsIgnoreCase("newLine1")).findFirst();
        if(smartWatchLine.isPresent() && StringUtilities.isNotEmptyOrNull(smartWatchLine.get().getPlanSorId()) && smartWatchLine.get().getPlanSorId().equals("28443") && prepaidODRequestData.isSkippedPlanForSWFlag())
        {
            prepaidODRequestData.getLines().stream().filter(lineData->lineData.isSmartPhone() && !lineData.isSmartImeiDevice() && !lineData.isPaired() && Arrays.stream(smartWatchLine.get().getNumbershareEligibleOS().split(",")).anyMatch(eligibleOs->eligibleOs.contains(lineData.getOsType()))).findFirst()
                    .ifPresent(line-> {
                        if(Objects.nonNull(response.getData().getCart())) {
                            response.getData().getCart().setEnableNSBanner(true);
                            smartWatchLine.get().setTrackIsNumberShareBanner(true);
                        }
                    });
        }
        else if(smartWatchLine.isPresent() && StringUtilities.isNotEmptyOrNull(smartWatchLine.get().getPlanSorId()) && smartWatchLine.get().getPlanSorId().equals("28445") && smartWatchLine.get().isTrackIsNumberShareBanner()){
            if(Objects.nonNull(response.getData().getCart()))
                response.getData().getCart().setEnableNSBanner(true);
        }

        if(CollectionUtils.size(watchOnCart)>0) {
            return prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, prepaidODRequestData)
                    .doOnError(err -> logger.error("Failed to update the PrepaidODRequestData to Redis", err))
                    .flatMap(upsertResp -> {
                        logger.info("Successfully inserted PrepaidODRequestData to Redis:: {}  ", upsertResp);
                        return Mono.just(new ResponseEntity<CheckoutDetailsCXPResponse>(response, HttpStatus.OK));
                    });
        }
        return Mono.just(new ResponseEntity<CheckoutDetailsCXPResponse>(response, HttpStatus.OK));
    }

    private boolean getShippingOptionsFlag(VZWPrepayOrderVO pageData) {
        if(NSE.equalsIgnoreCase(pageData.getFlow()) || CollectionUtils.size(pageData.getAccessoryList())>0) return true;

        if(Arrays.asList(NSP, NAP).contains(pageData.getFlow())
                && pageData.getDeviceList().stream().filter(device-> !NAP.equalsIgnoreCase(device.getPurchasePath())).count() == 0){
            return false;
        }
        return true;
    }

    private Mono<ResponseEntity<CheckoutDetailsCXPResponse>> getResponseUsingPrepaidODRequestDataLines(CheckoutDetailsCXPRequest checkoutDetailsCXPRequest,
                                                                                                       PrepaidODRequestData prepaidODRequestData, ServerHttpRequest httpRequest) {
        CheckoutDetailsCXPResponse checkoutDetailsCXPResponse = new CheckoutDetailsCXPResponse();
        CheckoutDetailsResponseData checkoutDetailsResponseData = new CheckoutDetailsResponseData();

        if(null==prepaidODRequestData || CollectionUtils.size(prepaidODRequestData.getLines())==0)
            return Mono.just(ResponseEntity.ok(checkoutDetailsCXPResponse));

        Meta meta = new Meta();
        checkoutDetailsCXPResponse.setMeta(meta);
        /*********Cart::Start***********/
        Cart cart = new Cart();

        /*********CartHeader::Start***********/
        CartHeader cartHeader = new CartHeader();
        cartHeader.setSourceSystem(checkOutDetailsODToCXPRespConverter.getChannelId(httpRequest));
        if(null!=checkoutDetailsCXPRequest && null!= checkoutDetailsCXPRequest.getData()
                && StringUtilities.isNotEmptyOrNull(checkoutDetailsCXPRequest.getData().getCartId()))
            cartHeader.setCartId(checkoutDetailsCXPRequest.getData().getCartId());
        cartHeader.setSessionId(checkOutDetailsODToCXPRespConverter.getSessionId(httpRequest));
        cartHeader.setCartCreatorChannelId(checkOutDetailsODToCXPRespConverter.getChannelId(httpRequest));
        cartHeader.setCartCreatorZipCode(Objects.nonNull(prepaidODRequestData)?prepaidODRequestData.getZipCode():"");
        cart.setCartHeader(cartHeader);
        /*********CartHeader::End***********/

        /*********Orderdetails::Start***********/
        OrderDetails orderDetails = new OrderDetails();
        orderDetails.setOrderChannelId(checkOutDetailsODToCXPRespConverter.getChannelId(httpRequest));
        cart.setOrderDetails(orderDetails);
        /*********Orderdetails::End***********/

        /************LineDeatils::Start****************/
        LineDetails lineDetails = new LineDetails();
        ArrayList<CartLineInfo> cartLineInfoList = new ArrayList<>();
        int count=1;
        int numOfAALLines=1;
        for(PrepaidODRequestDataLines prepaidODRequestDataLine : prepaidODRequestData.getLines()){
            if(prepaidODRequestDataLine.getFlow().equalsIgnoreCase("AAL")) {
                lineDetails.setNumofLinesAAL(numOfAALLines);
                numOfAALLines++;
            }
            CartLineInfo lineInfoItem = new CartLineInfo();
            lineInfoItem.setMultiLineSeqNumber(count);
            lineInfoItem.setMobileNumber(prepaidODRequestDataLine.getMtn());
            lineInfoItem.setLineNumber(prepaidODRequestDataLine.getMtn());
            lineInfoItem.setLineSortingNumber(count);
            lineInfoItem.setLineActivityType(prepaidODRequestDataLine.getFlow());

            //*****lineInfoItem.serviceInfo------START
            ServiceInfo serviceInfo = new ServiceInfo();
            Address serviceAddress = new Address();
            serviceAddress.setFirstName(prepaidODRequestData.getFirstName());
            serviceAddress.setLastName(prepaidODRequestData.getLastName());
            serviceAddress.setZipCode(prepaidODRequestData.getZipCode());
            serviceAddress.setPhoneNumber(prepaidODRequestData.getContactNumber());
            serviceInfo.setServiceAddress(serviceAddress);

            PrimaryUserInfo primaryUserInfo = new PrimaryUserInfo();
            primaryUserInfo.setAddress(serviceAddress);
            primaryUserInfo.setFirstName(prepaidODRequestData.getFirstName());
            primaryUserInfo.setLastName(prepaidODRequestData.getLastName());
            serviceInfo.setPrimaryUserInfo(primaryUserInfo);

            serviceInfo.setMtn(prepaidODRequestDataLine.getMtn());

            //*****lineInfoItem.serviceInfo.newpriceplanInfo
            PricePlanInfo pricePlanInfo = new PricePlanInfo();
            pricePlanInfo.setPricePlanCode(prepaidODRequestDataLine.getPlanSorId());
            pricePlanInfo.setPlanId(prepaidODRequestDataLine.getPlanSkuId());
            serviceInfo.setNewPricePlanInfo(pricePlanInfo);

            //*****lineInfoItem.serviceInfo.selectedfeatureslist
            if(CollectionUtils.size(prepaidODRequestDataLine.getFeatureSkuIds())>0){
                SelcetedFeaturesList selectedFeaturesList = new SelcetedFeaturesList();
                ArrayList<VisFeatures> visFeaturesList = prepaidODRequestDataLine.getFeatureSkuIds().stream().map(featureId->{
                    VisFeatures visFeatures = new VisFeatures();
                    visFeatures.setVisFeatureCode(featureId);
                    visFeatures.setFeatureSkuId(featureId);
                    visFeatures.setAddDeleteInd("A");
                    return visFeatures;
                }).collect(Collectors.toCollection(ArrayList::new));
                selectedFeaturesList.setVisFeature(visFeaturesList);
                serviceInfo.setSelectedFeaturesList(selectedFeaturesList);
            }
            lineInfoItem.setServiceInfo(serviceInfo);
            //*****lineInfoItem.serviceInfo--------END

            //*****lineInfoItem.itemsInfo --------Start
            ArrayList<ItemsInfo> itemsInfoList = new ArrayList<>();
            ItemsInfo itemsInfo = new ItemsInfo();

            //*****lineInfoItem.Shipping------START
            Shipping shipping = new Shipping();
            shipping.setLastName(prepaidODRequestData.getLastName());
            shipping.setFirstName(prepaidODRequestData.getFirstName());
            shipping.setAddress(serviceAddress);
            //shipping.setEmail("");
            shipping.setCbrPhone(prepaidODRequestData.getContactNumber());
            itemsInfo.setShipping(shipping);

            //*****lineInfoItem.Shipping------END

            //*****lineInfoItem.itemsInfo.cartItems --Start
            CartItems cartItems = new CartItems();
            ArrayList<CartItem> cartItemList = new ArrayList<>();

            CartItem cartItemDevice = new CartItem();

            cartItemDevice.setItemCode(prepaidODRequestDataLine.getDeviceSorId());
            cartItemDevice.setSorId(prepaidODRequestDataLine.getDeviceSorId());
            cartItemDevice.setCartItemType(CART_ITEM_TYPE_DEVICE);
            if(prepaidODRequestDataLine.isSmartPhone())
                 cartItemDevice.setSorDeviceCategory("SMARTPHONE");
            else if (prepaidODRequestDataLine.isSmartWatch())
                cartItemDevice.setSorDeviceCategory("SMARTWATCH");
            else if(prepaidODRequestDataLine.isBasicPhone())
                cartItemDevice.setSorDeviceCategory("BASICPHONE");
            else if(prepaidODRequestDataLine.isDataDevice())
                cartItemDevice.setSorDeviceCategory("INTERNET DEVICE");
            else
                cartItemDevice.setSorDeviceCategory(CART_ITEM_TYPE_DEVICE);
            cartItemDevice.setOsType((prepaidODRequestDataLine.getOsType()!=null)?prepaidODRequestDataLine.getOsType():"");
            cartItemDevice.setMobileNumber(prepaidODRequestDataLine.getMtn());
            cartItemDevice.setSkuId(prepaidODRequestDataLine.getDeviceSkuId());
            cartItemDevice.setProductId(prepaidODRequestDataLine.getDeviceId());
           //Sending IMEI only for Smartwatches
            if(prepaidODRequestDataLine.isSmartWatch())
                cartItemDevice.setDeviceId(prepaidODRequestDataLine.getImei());
            cartItemDevice.setQty(PrepayAdaptorCartConstants.PREPAY_CHECKOUT_DEVICE_QTY);
            //BYOD Related Fields
            cartItemDevice.setSimId(prepaidODRequestDataLine.getSimId());
            cartItemDevice.setESimFlow(prepaidODRequestDataLine.isESimEnabledDevice());
            cartItemDevice.setESIMEnabledDevice(prepaidODRequestDataLine.isESimEnabledDevice());
            cartItemDevice.setEsimOnlyDevice(prepaidODRequestDataLine.isESimOnly());
            cartItemDevice.setEsimId(prepaidODRequestDataLine.getESimId());
            //*****lineInfoItem.itemsInfo.cartItems.color --start
            Color color = new Color();
            color.setColorDisplayName(prepaidODRequestDataLine.getColor());
            cartItemDevice.setColor(color);
            //*****lineInfoItem.itemsInfo.cartItems.color --End

            //*****lineInfoItem.itemsInfo.cartItems.imageurlmap --start
            ImageUrlMap imageUrlMap = new ImageUrlMap();
            String defaultDeviceImgUrl = StringUtilities.substringBefore(prepaidODRequestDataLine.getImageUrl(),"?");
            imageUrlMap.setDefaultImage(defaultDeviceImgUrl);
            imageUrlMap.setLargeImage(defaultDeviceImgUrl + PrepayAdaptorCartConstants.DEVICE_LARGE_SUFFIX);
            imageUrlMap.setMediumImage(defaultDeviceImgUrl + PrepayAdaptorCartConstants.DEVICE_MEDIUM_SUFFIX);
            imageUrlMap.setMiniImage(defaultDeviceImgUrl + PrepayAdaptorCartConstants.DEVICE_MINI_SUFFIX);
            imageUrlMap.setThumbImage(defaultDeviceImgUrl + PrepayAdaptorCartConstants.DEVICE_THUMB_SUFFIX);
            cartItemDevice.setImageUrlMap(imageUrlMap);
            //*****lineInfoItem.itemsInfo.cartItems.imageurlmap --end

            cartItemDevice.setManufacturer(prepaidODRequestDataLine.getManufacturer()!=null?prepaidODRequestDataLine.getManufacturer():"");
            cartItemDevice.setDescription(prepaidODRequestDataLine.getDescription()!=null?prepaidODRequestDataLine.getDescription():"");
            cartItemDevice.setDeviceDisplayName(prepaidODRequestDataLine.getDisplayName()!=null?prepaidODRequestDataLine.getDisplayName():"");
            cartItemDevice.setCanonicalUrl(prepaidODRequestDataLine.getPdpUrl()!=null?prepaidODRequestDataLine.getPdpUrl():"");
            cartItemDevice.setCapacity((prepaidODRequestDataLine.getCapacity()!=null)?prepaidODRequestDataLine.getCapacity().toUpperCase():"");
            cartItemDevice.setItemPrice(prepaidODRequestDataLine.getDevicePrice()!=null?prepaidODRequestDataLine.getDevicePrice():"");
            cartItemDevice.setDiscountedPrice(prepaidODRequestDataLine.getDevicePrice()!=null?prepaidODRequestDataLine.getDevicePrice():"");
            cartItemList.add(cartItemDevice);

            //lineInfoItem.itemsInfo.cartItems -- simitem//TODO:: Need to check if we need this at all , as we are not using the data.
            //CartItem cartItemSim = new CartItem();
            //cartItemSim.setCartItemType(CART_ITEM_TYPE_SIM);
            //cartItemList.add(cartItemSim);

            //lineInfoItem.itemsInfo.cartItems -- accessories
            if(CollectionUtils.size(prepaidODRequestDataLine.getAccessorySkuIds())>0){
                ArrayList<CartItem> accessoryCartItemList = prepaidODRequestDataLine.getAccessorySkuIds().stream()
                        .map(prepaidOdRequestDataAccessory -> {
                            CartItem cartItemAccessory = new CartItem();
                            cartItemAccessory.setCartItemType(CART_ITEM_TYPE_ACCESSORY);
                            cartItemAccessory.setSkuId(prepaidOdRequestDataAccessory.getSkuId()!=null?prepaidOdRequestDataAccessory.getSkuId():"");
                            cartItemAccessory.setSorId(prepaidOdRequestDataAccessory.getSorId()!=null?prepaidOdRequestDataAccessory.getSorId():"");
                            cartItemAccessory.setManufacturer(prepaidOdRequestDataAccessory.getManufacturer()!=null?prepaidOdRequestDataAccessory.getManufacturer():"");
                            cartItemAccessory.setDescription(prepaidOdRequestDataAccessory.getDisplayName()!=null?prepaidOdRequestDataAccessory.getDisplayName():"");
                            cartItemAccessory.setDeviceDisplayName(prepaidOdRequestDataAccessory.getDisplayName()!=null?prepaidOdRequestDataAccessory.getDisplayName():"");
                            cartItemAccessory.setMobileNumber(prepaidODRequestDataLine.getMtn()!=null?prepaidODRequestDataLine.getMtn():"");
                            cartItemAccessory.setQty(checkOutDetailsODToCXPRespConverter.convertToIntFromString(prepaidOdRequestDataAccessory.getQty()));
                            //cartItemAccessory.setItemPrice(Objects.nonNull(prepaidOdRequestDataAccessory.getPrice())?prepaidOdRequestDataAccessory.getPrice():"0");
                            //cartItemAccessory.setDiscountedPrice(Objects.nonNull(prepaidOdRequestDataAccessory.getDiscountedPrice())?prepaidOdRequestDataAccessory.getDiscountedPrice():"0");
                            return checkOutDetailsODToCXPRespConverter.setCartItemAccessoryData(cartItemAccessory,prepaidOdRequestDataAccessory);
                        }).collect(Collectors.toCollection(ArrayList::new));
                cartItemList.addAll(accessoryCartItemList);
            }
            cartItems.setCartItem(cartItemList);
            itemsInfo.setCartItems(cartItems);
            //*****lineInfoItem.itemsInfo.cartItems --END

            itemsInfoList.add(itemsInfo);
            lineInfoItem.setItemsInfo(itemsInfoList);
            //*****lineInfoItem.itemsInfo -------END

            count++;
            cartLineInfoList.add(lineInfoItem);
        }
        lineDetails.setLineInfo(cartLineInfoList);
        cart.setLineDetails(lineDetails);
        //*****linedetails.lininfo --end

        /**********CartValidationErrors::Start****************/
        ArrayList<CartValidationErrors> cartValidationErrorsList = checkOutDetailsODToCXPRespConverter.getCartValidationErrors(cart,prepaidODRequestData);
        cart.setCartValidationErrors(cartValidationErrorsList);
        /**********CartValidationErrors::End****************/

        if(prepaidODRequestData.getLines().stream().filter(line->line.isCheckoutFlag() == true).count()>0){
            cart.setHubReadyForCheckout(true);
        }else{
            cart.setHubReadyForCheckout(false);
        }

        checkoutDetailsResponseData.setCart(cart);
        /*********Cart::End***********/

        /*********PendingSteps::Start***********/
        checkoutDetailsResponseData.setPendingSteps(addPendingSteps(checkoutDetailsResponseData, prepaidODRequestData));
        /*********PendingSteps::End***********/

        checkoutDetailsCXPResponse.setData(checkoutDetailsResponseData);

        return Mono.just(ResponseEntity.ok(checkoutDetailsCXPResponse));
    }

    public PrepaidAdaptorWebClientRequest getPrepaidCheckoutDetailsServiceRequest(PrepaidODRequestData prepaidODRequestData, CheckoutDetailsCXPRequest checkoutDetailsCXPRequest) {
        PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
        prepaidAdaptorWebClientRequest.setUrl(checkoutDetailsLegacyServiceUrl);
        prepaidAdaptorWebClientRequest.setRequestBody("{}");
        prepaidAdaptorWebClientRequest.setRequestType(HttpMethod.GET.toString());
        //prepaidAdaptorWebClientRequest.setHeader(PrepayAdaptorCartUtil.getPrepayODServiceCommonHeaders(prepaidODRequestData));
        Map<String,String> headers=new HashMap<>();
        String flowName = Objects.nonNull(prepaidODRequestData) && CollectionUtilities.isNotEmptyOrNull(prepaidODRequestData.getLines())?prepaidODRequestData.getLines().get(prepaidODRequestData.getCurr_line()-1).getFlow():NSE;
        String flow = PrepayAdaptorCartUtil.getODFlowName(flowName);
        if(Objects.nonNull(prepaidODRequestData)) {
            String prepaidODRequestCookieStr = PREPAY_OD_REQUEST_ECOMM_SESSION + "=" + prepaidODRequestData.getEcommSessionId() + ";"
                    + PREPAY_OD_REQUEST_FLOW + "=" + flow + ";" + PREPAY_OD_REQUEST_P_CSRFTKN + "=" + prepaidODRequestData.getPCsrfToken() + ";";
            headers.put(HttpHeaders.COOKIE, prepaidODRequestCookieStr);
            headers.put(PREPAY_OD_REQUEST_P_CSRF_TOKEN, prepaidODRequestData.getPCsrfToken());
        }
		headers.put(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);

		prepaidAdaptorWebClientRequest.setHeader(headers);
        Map<String, String> urlParams = new HashMap<>();
        
        if(checkoutDetailsCXPRequest.isSubmitOrderSoe()){
            urlParams.put("submitOrderSoe", String.valueOf(checkoutDetailsCXPRequest.isSubmitOrderSoe()));
            prepaidAdaptorWebClientRequest.setUrlParameters(urlParams);
        }
        return prepaidAdaptorWebClientRequest;
    }

    public PrepaidAdaptorWebClientRequest getPrepaidShippingServiceRequest(PrepaidODRequestData prepaidODRequestData) {
        PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
        prepaidAdaptorWebClientRequest.setUrl(shippingDetailsLegacyServiceUrl);
        prepaidAdaptorWebClientRequest.setRequestBody("{}");
        prepaidAdaptorWebClientRequest.setRequestType(HttpMethod.POST.toString());
        //prepaidAdaptorWebClientRequest.setHeader(PrepayAdaptorCartUtil.getPrepayODServiceCommonHeaders(prepaidODRequestData));
        Map<String,String> headers=new HashMap<>();
        String flowName = Objects.nonNull(prepaidODRequestData) && CollectionUtilities.isNotEmptyOrNull(prepaidODRequestData.getLines())?prepaidODRequestData.getLines().get(prepaidODRequestData.getCurr_line()-1).getFlow():NSE;
        String flow = PrepayAdaptorCartUtil.getODFlowName(flowName);
        if(Objects.nonNull(prepaidODRequestData)) {
		
        String prepaidODRequestCookieStr=PREPAY_OD_REQUEST_ECOMM_SESSION + "="+prepaidODRequestData.getEcommSessionId()+";"
                + PREPAY_OD_REQUEST_FLOW +"="+flow+";"+ PREPAY_OD_REQUEST_P_CSRFTKN +"="+prepaidODRequestData.getPCsrfToken()+";";
		headers.put(HttpHeaders.COOKIE, prepaidODRequestCookieStr);
		headers.put(PREPAY_OD_REQUEST_P_CSRF_TOKEN, prepaidODRequestData.getPCsrfToken());
        }
		headers.put(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		prepaidAdaptorWebClientRequest.setHeader(headers);
        return prepaidAdaptorWebClientRequest;
    }

    public Map<String, List<PendingItems>> addPendingSteps(CheckoutDetailsResponseData checkoutDetailsResponseData, PrepaidODRequestData prepaidODRequestData) {

        Map<String, List<PendingItems>> pendingSteps = new HashMap<>();
        if(null == prepaidODRequestData || CollectionUtils.size(prepaidODRequestData.getLines()) == 0 ){
            return pendingSteps;
        }

        for(PrepaidODRequestDataLines prepaidODRequestDataLine: prepaidODRequestData.getLines()){
            if(!prepaidODRequestDataLine.isCheckoutFlag() || (prepaidODRequestData.isLoggedIn() && !prepaidODRequestDataLine.isPlanUpdated())) {
                    List<PendingItems> lineLevelPendingSteps = new ArrayList<>();
                    if (CollectionUtils.size(prepaidODRequestDataLine.getCompletedProcessSteps()) > 0) {
                        if (prepaidODRequestData.isLoggedIn()) {
                            addNumberSelectionData(prepaidODRequestDataLine, lineLevelPendingSteps);
                            addplanSelectionData(prepaidODRequestDataLine, lineLevelPendingSteps);
                            // commented for Price Plan Refresh
       /*             if(!prepaidODRequestDataLine.getCompletedProcessSteps().contains(PendingStepsEnum.International_Selection.getStep())){
                        PendingItems internationaPlanSelectionPendingStep = new PendingItems();
                        internationaPlanSelectionPendingStep.setStep(PendingStepsEnum.International_Selection.getStep());
                        internationaPlanSelectionPendingStep.setId(PendingStepsEnum.International_Selection.getId());
                        internationaPlanSelectionPendingStep.setErrorLevel(PendingStepsEnum.International_Selection.getErrorLevel());
                        lineLevelPendingSteps.add(internationaPlanSelectionPendingStep);
                    }
         */
                        } else {
                                addplanSelectionData(prepaidODRequestDataLine, lineLevelPendingSteps);
                        }
                    }
                pendingSteps.put(prepaidODRequestDataLine.getMtn(), lineLevelPendingSteps);
            }
        }
        return pendingSteps;
    }

    private void addplanSelectionData(PrepaidODRequestDataLines prepaidODRequestDataLine,List<PendingItems> lineLevelPendingSteps){
        if (!prepaidODRequestDataLine.getCompletedProcessSteps().contains(PendingStepsEnum.PLAN_SELECTION.getStep())) {
            PendingItems planSelectionPendingStep = new PendingItems();
            planSelectionPendingStep.setStep(PendingStepsEnum.PLAN_SELECTION.getStep());
            planSelectionPendingStep.setId(PendingStepsEnum.PLAN_SELECTION.getId());
            planSelectionPendingStep.setErrorLevel(PendingStepsEnum.PLAN_SELECTION.getErrorLevel());
            lineLevelPendingSteps.add(planSelectionPendingStep);
        }
    }

    private void addNumberSelectionData(PrepaidODRequestDataLines prepaidODRequestDataLine,List<PendingItems> lineLevelPendingSteps){
        if (!prepaidODRequestDataLine.getCompletedProcessSteps().contains(PendingStepsEnum.NUMBER_SELECTION.getStep())) {
            PendingItems planSelectionPendingStep = new PendingItems();
            planSelectionPendingStep.setStep(PendingStepsEnum.NUMBER_SELECTION.getStep());
            planSelectionPendingStep.setId(PendingStepsEnum.NUMBER_SELECTION.getId());
            planSelectionPendingStep.setErrorLevel(PendingStepsEnum.NUMBER_SELECTION.getErrorLevel());
            lineLevelPendingSteps.add(planSelectionPendingStep);
        }
    }

}
