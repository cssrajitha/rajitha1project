package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;
import java.util.Map;

public class Settings implements Serializable {
    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = -7526977565059263347L;

    private String orderId;
    private boolean submitOrder;
    private Map<String, Integer> entityVersion;

    /**
     * @return the entityVersion
     */
    public Map<String, Integer> getEntityVersion() {
        return entityVersion;
    }
    /**
     * @param entityVersion the entityVersion to set
     */
    public void setEntityVersion(Map<String, Integer> entityVersion) {
        this.entityVersion = entityVersion;
    }
    /**
     * @return the submitOrder
     */
    public boolean isSubmitOrder() {
        return submitOrder;
    }
    /**
     * @param submitOrder the submitOrder to set
     */
    public void setSubmitOrder(boolean submitOrder) {
        this.submitOrder = submitOrder;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
}
