package onevz.soe.prepay.adaptor.cart.model.bpm;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import onevz.soe.cart.model.common.CartServiceCartInfo;
import onevz.soe.cart.model.common.CartServiceContextInfo;
import onevz.soe.cart.model.common.CartServiceCustomerInfo;
import onevz.soe.wsclient.bpm.model.Context;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper=true)
public class AddDeviceToPrepayODContext extends Context {

	@JsonInclude(Include.NON_NULL)
	@JsonProperty(value = "customerInfo")
	private CartServiceCustomerInfo customerInfo;

	@JsonInclude(Include.NON_NULL)
	@JsonProperty(value = "cartInfo")
	private CartServiceCartInfo cartInfo;

	@JsonInclude(Include.NON_NULL)
	@JsonProperty(value = "contextInfo")
	private CartServiceContextInfo contextInfo;

	private String flow;
}
