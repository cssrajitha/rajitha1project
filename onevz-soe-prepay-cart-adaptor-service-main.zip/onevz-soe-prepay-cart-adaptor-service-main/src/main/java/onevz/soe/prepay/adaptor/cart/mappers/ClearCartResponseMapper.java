package onevz.soe.prepay.adaptor.cart.mappers;

import onevz.soe.cart.responses.ClearCartPEGAResponse;
import onevz.soe.prepay.adaptor.cart.model.play.clearcart.VZWPrepayAPIClearCartResponse;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface ClearCartResponseMapper {

    ClearCartPEGAResponse playVZWPrepayAPIClearCartResponseToSOEClearCartPEGAResponse(VZWPrepayAPIClearCartResponse source);

    @InheritInverseConfiguration(name = "playVZWPrepayAPIClearCartResponseToSOEClearCartPEGAResponse")
    VZWPrepayAPIClearCartResponse soeClearCartPEGAResponseToVZWPrepayAPIClearCartResponse(ClearCartPEGAResponse source);

}
