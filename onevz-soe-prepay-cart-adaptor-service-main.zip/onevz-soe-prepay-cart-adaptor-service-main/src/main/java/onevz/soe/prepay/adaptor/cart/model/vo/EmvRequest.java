package onevz.soe.prepay.adaptor.cart.model.vo;


import java.io.Serializable;

public class EmvRequest implements Serializable {
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -7526977565059263347L;
	private String cryptogramCurrencyCode;
	private String cardSequenceNumber;
	private String applicationInterchangeProfile;
	private String dedicatedFileName;
	private String terminalVerificationResults;
	private String transactionDate;
	private String transactionType;
	private String cryptogramAmount;
	private String applicationVersionNumber;
	private String issuerApplicationData;
	private String terminalCountryCode;
	private String interfaceDeviceSerialNumber;
	private String applicationCryptogram;
	private String cryptogramInformationData;
	private String terminalCapabilityProfile;
	private String cvmResults;
	private String terminalType;
	private String applicationTransactionCounter;
	private String unpredictableNumber;
	private String transactionSequenceCounter;
	private String formFactorIndicator;
	private String issuerScriptResults;
	private String customerExclusiveData;

	public static long getSerialVersionUID() {
		return serialVersionUID;
	}

	public String getCryptogramCurrencyCode() {
		return cryptogramCurrencyCode;
	}

	public void setCryptogramCurrencyCode(String cryptogramCurrencyCode) {
		this.cryptogramCurrencyCode = cryptogramCurrencyCode;
	}

	public String getCardSequenceNumber() {
		return cardSequenceNumber;
	}

	public void setCardSequenceNumber(String cardSequenceNumber) {
		this.cardSequenceNumber = cardSequenceNumber;
	}

	public String getApplicationInterchangeProfile() {
		return applicationInterchangeProfile;
	}

	public void setApplicationInterchangeProfile(String applicationInterchangeProfile) {
		this.applicationInterchangeProfile = applicationInterchangeProfile;
	}

	public String getDedicatedFileName() {
		return dedicatedFileName;
	}

	public void setDedicatedFileName(String dedicatedFileName) {
		this.dedicatedFileName = dedicatedFileName;
	}

	public String getTerminalVerificationResults() {
		return terminalVerificationResults;
	}

	public void setTerminalVerificationResults(String terminalVerificationResults) {
		this.terminalVerificationResults = terminalVerificationResults;
	}

	public String getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getCryptogramAmount() {
		return cryptogramAmount;
	}

	public void setCryptogramAmount(String cryptogramAmount) {
		this.cryptogramAmount = cryptogramAmount;
	}

	public String getApplicationVersionNumber() {
		return applicationVersionNumber;
	}

	public void setApplicationVersionNumber(String applicationVersionNumber) {
		this.applicationVersionNumber = applicationVersionNumber;
	}

	public String getIssuerApplicationData() {
		return issuerApplicationData;
	}

	public void setIssuerApplicationData(String issuerApplicationData) {
		this.issuerApplicationData = issuerApplicationData;
	}

	public String getTerminalCountryCode() {
		return terminalCountryCode;
	}

	public void setTerminalCountryCode(String terminalCountryCode) {
		this.terminalCountryCode = terminalCountryCode;
	}

	public String getInterfaceDeviceSerialNumber() {
		return interfaceDeviceSerialNumber;
	}

	public void setInterfaceDeviceSerialNumber(String interfaceDeviceSerialNumber) {
		this.interfaceDeviceSerialNumber = interfaceDeviceSerialNumber;
	}

	public String getApplicationCryptogram() {
		return applicationCryptogram;
	}

	public void setApplicationCryptogram(String applicationCryptogram) {
		this.applicationCryptogram = applicationCryptogram;
	}

	public String getCryptogramInformationData() {
		return cryptogramInformationData;
	}

	public void setCryptogramInformationData(String cryptogramInformationData) {
		this.cryptogramInformationData = cryptogramInformationData;
	}

	public String getTerminalCapabilityProfile() {
		return terminalCapabilityProfile;
	}

	public void setTerminalCapabilityProfile(String terminalCapabilityProfile) {
		this.terminalCapabilityProfile = terminalCapabilityProfile;
	}

	public String getCvmResults() {
		return cvmResults;
	}

	public void setCvmResults(String cvmResults) {
		this.cvmResults = cvmResults;
	}

	public String getTerminalType() {
		return terminalType;
	}

	public void setTerminalType(String terminalType) {
		this.terminalType = terminalType;
	}

	public String getApplicationTransactionCounter() {
		return applicationTransactionCounter;
	}

	public void setApplicationTransactionCounter(String applicationTransactionCounter) {
		this.applicationTransactionCounter = applicationTransactionCounter;
	}

	public String getUnpredictableNumber() {
		return unpredictableNumber;
	}

	public void setUnpredictableNumber(String unpredictableNumber) {
		this.unpredictableNumber = unpredictableNumber;
	}

	public String getTransactionSequenceCounter() {
		return transactionSequenceCounter;
	}

	public void setTransactionSequenceCounter(String transactionSequenceCounter) {
		this.transactionSequenceCounter = transactionSequenceCounter;
	}

	public String getFormFactorIndicator() {
		return formFactorIndicator;
	}

	public void setFormFactorIndicator(String formFactorIndicator) {
		this.formFactorIndicator = formFactorIndicator;
	}

	public String getIssuerScriptResults() {
		return issuerScriptResults;
	}

	public void setIssuerScriptResults(String issuerScriptResults) {
		this.issuerScriptResults = issuerScriptResults;
	}

	public String getCustomerExclusiveData() {
		return customerExclusiveData;
	}

	public void setCustomerExclusiveData(String customerExclusiveData) {
		this.customerExclusiveData = customerExclusiveData;
	}
}
