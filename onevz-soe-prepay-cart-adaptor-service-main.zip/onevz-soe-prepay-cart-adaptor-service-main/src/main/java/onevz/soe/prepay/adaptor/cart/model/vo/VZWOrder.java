package onevz.soe.prepay.adaptor.cart.model.vo;
import java.io.Serializable;
import java.util.*;

/**
 * Created by vermaad on 1/4/2018.
 */
public class VZWOrder implements Serializable  {

    private static final long serialVersionUID = -4036113856498869733L;
    private String id;
    private Date lastModifiedDate;
    private String siteID;
    private String userID;
    private String channelID;
    private String locationCode;
    private Date submittedDate;
    private String status;
    private Double orderAmount;
    private Double orderTax;
    private Double orderDiscount;
    private String serviceZip;
    private String outletID;
    private String isSpecialUpgrade;
    private String flow;
    private Double subTotalDueMonthly;
    private Double subTotalDueToday;
    private String savedCartEmailId;
    private List<String> promoCodeIds = new ArrayList<>();
    private List<VZWPromotion> promotions = new ArrayList<>();
    //Use suborder clientReferenceNumber instead
    private String clientReferenceNumber;
    private int version;
    private Boolean delete;
    private String customerType;
    private Double totalActivationFees;
    private Double mailInRebateTotal;
    private ContactInfo contactInfo;
    private ContactInfo billingAddress;

    private List<PaymentGroup> paymentGroup;
    private String taxState;
    private String taxCity;
    private List<ShippingGroup> shippingGroups;
    // Added for Submit Order
    private OrderWriteServiceInfo orderWriteServiceInfo;
    private String billingSystem;
    private Boolean taxCalculated;
    private String clusterInfo;
    private String vendorId;
    private String lastAddedDeviceLineItemId;
    private Boolean includePlanAndFeatureTaxInDueMonthly;
    private String cartType;
    private Double totalUpgradeFee;
    private String playSessionId;
    private String creditApplicationNumber;
    private String marketId;
    private String confirmationNumber;
    private String transactionId;
    private String customerAgreementText;
    private String correlationId;
    private Boolean changed;
    private String originatingSystem;
    private Boolean liveSedCalled;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Date getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(Date lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getSiteID() {
        return siteID;
    }

    public void setSiteID(String siteID) {
        this.siteID = siteID;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getChannelID() {
        return channelID;
    }

    public void setChannelID(String channelID) {
        this.channelID = channelID;
    }

    public String getLocationCode() {
        return locationCode;
    }

    public void setLocationCode(String locationCode) {
        this.locationCode = locationCode;
    }

    public Date getSubmittedDate() {
        return submittedDate;
    }

    public void setSubmittedDate(Date submittedDate) {
        this.submittedDate = submittedDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Double getOrderAmount() {
        return orderAmount;
    }

    public void setOrderAmount(Double orderAmount) {
        this.orderAmount = orderAmount;
    }

    public Double getOrderTax() {
        return orderTax;
    }

    public void setOrderTax(Double orderTax) {
        this.orderTax = orderTax;
    }

    public Double getOrderDiscount() {
        return orderDiscount;
    }

    public void setOrderDiscount(Double orderDiscount) {
        this.orderDiscount = orderDiscount;
    }

    public String getServiceZip() {
        return serviceZip;
    }

    public void setServiceZip(String serviceZip) {
        this.serviceZip = serviceZip;
    }

    public String getOutletID() {
        return outletID;
    }

    public void setOutletID(String outletID) {
        this.outletID = outletID;
    }

    public String getIsSpecialUpgrade() {
        return isSpecialUpgrade;
    }

    public void setIsSpecialUpgrade(String isSpecialUpgrade) {
        this.isSpecialUpgrade = isSpecialUpgrade;
    }

    public String getFlow() {
        return flow;
    }

    public void setFlow(String flow) {
        this.flow = flow;
    }

    public Double getSubTotalDueMonthly() {
        return subTotalDueMonthly;
    }

    public void setSubTotalDueMonthly(Double subTotalDueMonthly) {
        this.subTotalDueMonthly = subTotalDueMonthly;
    }

    public Double getSubTotalDueToday() {
        return subTotalDueToday;
    }

    public void setSubTotalDueToday(Double subTotalDueToday) {
        this.subTotalDueToday = subTotalDueToday;
    }

    public String getSavedCartEmailId() {
        return savedCartEmailId;
    }

    public void setSavedCartEmailId(String savedCartEmailId) {
        this.savedCartEmailId = savedCartEmailId;
    }

    public List<String> getPromoCodeIds() {
        return promoCodeIds;
    }

    public void setPromoCodeIds(List<String> promoCodeIds) {
        this.promoCodeIds = promoCodeIds;
    }

    public List<VZWPromotion> getPromotions() {
        return promotions;
    }

    public void setPromotions(List<VZWPromotion> promotions) {
        this.promotions = promotions;
    }

    public String getClientReferenceNumber() {
        return clientReferenceNumber;
    }

    public void setClientReferenceNumber(String clientReferenceNumber) {
        this.clientReferenceNumber = clientReferenceNumber;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public Boolean getDelete() {
        return delete;
    }

    public void setDelete(Boolean delete) {
        this.delete = delete;
    }

    public String getCustomerType() {
        return customerType;
    }

    public void setCustomerType(String customerType) {
        this.customerType = customerType;
    }

    public Double getTotalActivationFees() {
        return totalActivationFees;
    }

    public void setTotalActivationFees(Double totalActivationFees) {
        this.totalActivationFees = totalActivationFees;
    }

    public Double getMailInRebateTotal() {
        return mailInRebateTotal;
    }

    public void setMailInRebateTotal(Double mailInRebateTotal) {
        this.mailInRebateTotal = mailInRebateTotal;
    }

    public ContactInfo getContactInfo() {
        return contactInfo;
    }

    public void setContactInfo(ContactInfo contactInfo) {
        this.contactInfo = contactInfo;
    }

    public ContactInfo getBillingAddress() {
        return billingAddress;
    }

    public void setBillingAddress(ContactInfo billingAddress) {
        this.billingAddress = billingAddress;
    }

    public List<PaymentGroup> getPaymentGroup() {
        return paymentGroup;
    }

    public void setPaymentGroup(List<PaymentGroup> paymentGroup) {
        this.paymentGroup = paymentGroup;
    }

    public String getTaxState() {
        return taxState;
    }

    public void setTaxState(String taxState) {
        this.taxState = taxState;
    }

    public String getTaxCity() {
        return taxCity;
    }

    public void setTaxCity(String taxCity) {
        this.taxCity = taxCity;
    }

    public List<ShippingGroup> getShippingGroups() {
        return shippingGroups;
    }

    public void setShippingGroups(List<ShippingGroup> shippingGroups) {
        this.shippingGroups = shippingGroups;
    }

    public OrderWriteServiceInfo getOrderWriteServiceInfo() {
        return orderWriteServiceInfo;
    }

    public void setOrderWriteServiceInfo(OrderWriteServiceInfo orderWriteServiceInfo) {
        this.orderWriteServiceInfo = orderWriteServiceInfo;
    }

    public String getBillingSystem() {
        return billingSystem;
    }

    public void setBillingSystem(String billingSystem) {
        this.billingSystem = billingSystem;
    }

    public Boolean getTaxCalculated() {
        return taxCalculated;
    }

    public void setTaxCalculated(Boolean taxCalculated) {
        this.taxCalculated = taxCalculated;
    }

    public String getClusterInfo() {
        return clusterInfo;
    }

    public void setClusterInfo(String clusterInfo) {
        this.clusterInfo = clusterInfo;
    }

    public String getVendorId() {
        return vendorId;
    }

    public void setVendorId(String vendorId) {
        this.vendorId = vendorId;
    }

    public String getLastAddedDeviceLineItemId() {
        return lastAddedDeviceLineItemId;
    }

    public void setLastAddedDeviceLineItemId(String lastAddedDeviceLineItemId) {
        this.lastAddedDeviceLineItemId = lastAddedDeviceLineItemId;
    }

    public Boolean getIncludePlanAndFeatureTaxInDueMonthly() {
        return includePlanAndFeatureTaxInDueMonthly;
    }

    public void setIncludePlanAndFeatureTaxInDueMonthly(Boolean includePlanAndFeatureTaxInDueMonthly) {
        this.includePlanAndFeatureTaxInDueMonthly = includePlanAndFeatureTaxInDueMonthly;
    }

    public String getCartType() {
        return cartType;
    }

    public void setCartType(String cartType) {
        this.cartType = cartType;
    }

    public Double getTotalUpgradeFee() {
        return totalUpgradeFee;
    }

    public void setTotalUpgradeFee(Double totalUpgradeFee) {
        this.totalUpgradeFee = totalUpgradeFee;
    }

    public String getPlaySessionId() {
        return playSessionId;
    }

    public void setPlaySessionId(String playSessionId) {
        this.playSessionId = playSessionId;
    }

    public String getCreditApplicationNumber() {
        return creditApplicationNumber;
    }

    public void setCreditApplicationNumber(String creditApplicationNumber) {
        this.creditApplicationNumber = creditApplicationNumber;
    }

    public String getMarketId() {
        return marketId;
    }

    public void setMarketId(String marketId) {
        this.marketId = marketId;
    }

    public String getConfirmationNumber() {
        return confirmationNumber;
    }

    public void setConfirmationNumber(String confirmationNumber) {
        this.confirmationNumber = confirmationNumber;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getCustomerAgreementText() {
        return customerAgreementText;
    }

    public void setCustomerAgreementText(String customerAgreementText) {
        this.customerAgreementText = customerAgreementText;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }


    public Boolean isChanged() {
        if(changed != null){
            return changed;
        }else{
            return true;
        }
    }

    public void setChanged(Boolean changed) {
        this.changed = changed;
    }

    public String getOriginatingSystem() {
        return originatingSystem;
    }

    public void setOriginatingSystem(String originatingSystem) {
        this.originatingSystem = originatingSystem;
    }

    /**
     * @return the liveSedCalled
     */
    public Boolean isLiveSedCalled() {
        return liveSedCalled;
    }

    /**
     * @param liveSedCalled the liveSedCalled to set
     */
    public void setLiveSedCalled(Boolean liveSedCalled) {
        this.liveSedCalled = liveSedCalled;
    }
}
