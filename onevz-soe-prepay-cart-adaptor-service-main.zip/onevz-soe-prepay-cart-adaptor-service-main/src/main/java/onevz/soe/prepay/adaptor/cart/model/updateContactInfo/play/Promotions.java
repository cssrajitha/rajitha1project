package onevz.soe.prepay.adaptor.cart.model.updateContactInfo.play;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import onevz.soe.orderprocess.model.checkoutdetails.PromoBadgeMessages;

@Getter
@Setter
@AllArgsConstructor
@ToString
@EqualsAndHashCode
@NoArgsConstructor

public class Promotions {

	private String promoType;
	private String promotionId;
	private String priority;
	private List<PromoBadgeMessages> promoBadgeMessages;
	private String discount;
	private String offerId; 
	
	
}