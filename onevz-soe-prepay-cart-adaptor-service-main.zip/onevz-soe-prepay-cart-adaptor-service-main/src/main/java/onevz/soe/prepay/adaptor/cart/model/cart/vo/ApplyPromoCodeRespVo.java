package onevz.soe.prepay.adaptor.cart.model.cart.vo;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApplyPromoCodeRespVo {

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public boolean isPromoAdded() {
        return promoAdded;
    }

    public void setPromoAdded(boolean promoAdded) {
        this.promoAdded = promoAdded;
    }

    private String orderId;

    private boolean promoAdded;

}
