
package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;

/**
 * @author v1mald4
 *
 */
public class ApplePay extends PaymentGroup implements Serializable {

	private static final long serialVersionUID = 1L;
	
	public String primaryAccountNumber;
	
	public String expirationDate;
	
	public String currencyCode;
	
	public double transactionAmount;

	public String cardholderName;
	
	public String deviceManufacturerIdentifier;
	
	public String paymentDataType;

	public String onlinePaymentCryptogram;

	public String eciIndicator ;
	
	public String emailAddress;
	
	public String transactionId;
 	
	public String cardType ;
	
	public String cardDisplayName ;

	public String cardName ;

	/**
	 * @return the primaryAccountNumber
	 */
	public String getPrimaryAccountNumber() {
		return primaryAccountNumber;
	}

	/**
	 * @param primaryAccountNumber the primaryAccountNumber to set
	 */
	public void setPrimaryAccountNumber(String primaryAccountNumber) {
		this.primaryAccountNumber = primaryAccountNumber;
	}

	/**
	 * @return the expirationDate
	 */
	public String getExpirationDate() {
		return expirationDate;
	}

	/**
	 * @param expirationDate the expirationDate to set
	 */
	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}

	/**
	 * @return the currencyCode
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}

	/**
	 * @param currencyCode the currencyCode to set
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	/**
	 * @return the transactionAmount
	 */
	public double getTransactionAmount() {
		return transactionAmount;
	}

	/**
	 * @param transactionAmount the transactionAmount to set
	 */
	public void setTransactionAmount(double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	/**
	 * @return the cardholderName
	 */
	public String getCardholderName() {
		return cardholderName;
	}

	/**
	 * @param cardholderName the cardholderName to set
	 */
	public void setCardholderName(String cardholderName) {
		this.cardholderName = cardholderName;
	}

	/**
	 * @return the deviceManufacturerIdentifier
	 */
	public String getDeviceManufacturerIdentifier() {
		return deviceManufacturerIdentifier;
	}

	/**
	 * @param deviceManufacturerIdentifier the deviceManufacturerIdentifier to set
	 */
	public void setDeviceManufacturerIdentifier(String deviceManufacturerIdentifier) {
		this.deviceManufacturerIdentifier = deviceManufacturerIdentifier;
	}

	/**
	 * @return the paymentDataType
	 */
	public String getPaymentDataType() {
		return paymentDataType;
	}

	/**
	 * @param paymentDataType the paymentDataType to set
	 */
	public void setPaymentDataType(String paymentDataType) {
		this.paymentDataType = paymentDataType;
	}

	/**
	 * @return the onlinePaymentCryptogram
	 */
	public String getOnlinePaymentCryptogram() {
		return onlinePaymentCryptogram;
	}

	/**
	 * @param onlinePaymentCryptogram the onlinePaymentCryptogram to set
	 */
	public void setOnlinePaymentCryptogram(String onlinePaymentCryptogram) {
		this.onlinePaymentCryptogram = onlinePaymentCryptogram;
	}

	/**
	 * @return the eciIndicator
	 */
	public String getEciIndicator() {
		return eciIndicator;
	}

	/**
	 * @param eciIndicator the eciIndicator to set
	 */
	public void setEciIndicator(String eciIndicator) {
		this.eciIndicator = eciIndicator;
	}

	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * @param emailAddress the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	/**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}

	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	/**
	 * @return the cardType
	 */
	public String getCardType() {
		return cardType;
	}

	/**
	 * @param cardType the cardType to set
	 */
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	/**
	 * @return the cardDisplayName
	 */
	public String getCardDisplayName() {
		return cardDisplayName;
	}

	/**
	 * @param cardDisplayName the cardDisplayName to set
	 */
	public void setCardDisplayName(String cardDisplayName) {
		this.cardDisplayName = cardDisplayName;
	}

	/**
	 * @return the cardName
	 */
	public String getCardName() {
		return cardName;
	}

	/**
	 * @param cardName the cardName to set
	 */
	public void setCardName(String cardName) {
		this.cardName = cardName;
	}
	
}
