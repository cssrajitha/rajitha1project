package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;
import java.util.Date;


public class EdgeUpDetails implements Serializable {
	
	private static final long serialVersionUID = 4134691905021647941L;
	
	private String edgeUpDetailId;
	
	private String originalOrderNumber;
	
	private String originalLocationCode;
	
	private String originalInstallmentLoanNumber;
	
	private String tradeInDeviceId;
	
	private String tradeInSku;
	
	private Date createDate;

	private String tradeInDeviceType;

	private String deviceIdOnInstallment;


	public String getTradeInDeviceType() {
		return tradeInDeviceType;
	}

	public void setTradeInDeviceType(String tradeInDeviceType) {
		this.tradeInDeviceType = tradeInDeviceType;
	}



	public String getDeviceIdOnInstallment() {
		return deviceIdOnInstallment;
	}

	public void setDeviceIdOnInstallment(String deviceIdOnInstallment) {
		this.deviceIdOnInstallment = deviceIdOnInstallment;
	}


	/**
	 * @return the edgeUpDetailId
	 */
	public String getEdgeUpDetailId() {
		return edgeUpDetailId;
	}

	/**
	 * @param edgeUpDetailId the edgeUpDetailId to set
	 */
	public void setEdgeUpDetailId(String edgeUpDetailId) {
		this.edgeUpDetailId = edgeUpDetailId;
	}

	/**
	 * @return the originalOrderNumber
	 */
	public String getOriginalOrderNumber() {
		return originalOrderNumber;
	}

	/**
	 * @param originalOrderNumber the originalOrderNumber to set
	 */
	public void setOriginalOrderNumber(String originalOrderNumber) {
		this.originalOrderNumber = originalOrderNumber;
	}

	/**
	 * @return the originalLocationCode
	 */
	public String getOriginalLocationCode() {
		return originalLocationCode;
	}

	/**
	 * @param originalLocationCode the originalLocationCode to set
	 */
	public void setOriginalLocationCode(String originalLocationCode) {
		this.originalLocationCode = originalLocationCode;
	}

	/**
	 * @return the originalInstallmentLoanNumber
	 */
	public String getOriginalInstallmentLoanNumber() {
		return originalInstallmentLoanNumber;
	}

	/**
	 * @param originalInstallmentLoanNumber the originalInstallmentLoanNumber to set
	 */
	public void setOriginalInstallmentLoanNumber(String originalInstallmentLoanNumber) {
		this.originalInstallmentLoanNumber = originalInstallmentLoanNumber;
	}

	/**
	 * @return the tradeInDeviceId
	 */
	public String getTradeInDeviceId() {
		return tradeInDeviceId;
	}

	/**
	 * @param tradeInDeviceId the tradeInDeviceId to set
	 */
	public void setTradeInDeviceId(String tradeInDeviceId) {
		this.tradeInDeviceId = tradeInDeviceId;
	}

	/**
	 * @return the tradeInSku
	 */
	public String getTradeInSku() {
		return tradeInSku;
	}

	/**
	 * @param tradeInSku the tradeInSku to set
	 */
	public void setTradeInSku(String tradeInSku) {
		this.tradeInSku = tradeInSku;
	}

	/**
	 * @return the createDate
	 */
	public Date getCreateDate() {
		return createDate;
	}

	/**
	 * @param createDate the createDate to set
	 */
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((edgeUpDetailId == null) ? 0 : edgeUpDetailId.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EdgeUpDetails other = (EdgeUpDetails) obj;
		if (edgeUpDetailId == null) {
			if (other.edgeUpDetailId != null)
				return false;
		} else if (!edgeUpDetailId.equals(other.edgeUpDetailId))
			return false;
		return true;
	}
	
	
}
