package onevz.soe.prepay.adaptor.cart.model.vo;


import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;
import java.util.Date;

public class ContactInfo implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -7526977565059263347L;
	private String id;
	private String emailAddress;	
	private String phoneNumber;
	private String lastName;
	private String firstName;
	private String zipCode;
	private String orderId;
	private String userId;
	private String npaNxxNumber;
	private String address1;
	private String address2;
	private String city;
	private String state;
	private boolean addressVerified;
	private boolean textAlertOptin;
	private boolean newsLetterOptin;
	private boolean paperFreeBillingIndicatorFlag;	
	private String middleName;
	private String firmName;
	private String businessName;
	private String apartmentNum;
	private String addressDirection;
	private String poBox;
	private String streetNumber;
	private String streetName;
	private String streetType;
	private String ruralRoute;
	private String ruralDel;
	private String zipCode4;
	private String zipCode5;
	private String faxNumber;
	private String addressType;
	private String country;
	private String prefix;
	private String suffix;
	private String postbox;   
	private String companyname; 	
	private String ruralrte; 
	private String county;	 
	private String address3; 
	private String postalcode;
	private int version;
	private String fips;
	private Date lastModifiedDate;
	private String addressConfirmationStatus;
	private String dateOfBirth;

	private String fiosContactNumber;

	public String getFiosContactNumber() {
		return fiosContactNumber;
	}

	public void setFiosContactNumber(String fiosContactNumber) {
		this.fiosContactNumber = fiosContactNumber;
	}


	/**
	 * @return the addressConfirmationStatus
	 */
	public String getAddressConfirmationStatus() {
		return addressConfirmationStatus;
	}

	/**
	 * @param addressConfirmationStatus the addressConfirmationStatus to set
	 */
	public void setAddressConfirmationStatus(String addressConfirmationStatus) {
		this.addressConfirmationStatus = addressConfirmationStatus;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	
	
	public String getPostbox() {
		return postbox;
	}
	public void setPostbox(String postbox) {
		this.postbox = postbox;
	}
	public String getCompanyname() {
		return companyname;
	}
	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}
	public String getRuralrte() {
		return ruralrte;
	}
	public void setRuralrte(String ruralrte) {
		this.ruralrte = ruralrte;
	}
	public String getCounty() {
		return county;
	}
	public void setCounty(String county) {
		this.county = county;
	}
	public String getAddress3() {
		return address3;
	}
	public void setAddress3(String address3) {
		this.address3 = address3;
	}
	public String getPostalcode() {
		try {
			return (StringUtils.isNotEmpty(postalcode) && postalcode.length() > 5) ? postalcode.substring(0, 5) : postalcode;
		}catch(Exception exp){
			return postalcode;
		}
	}
	public void setPostalcode(String postalcode) {
		try {
			this.postalcode = (StringUtils.isNotEmpty(postalcode) && postalcode.length() > 5) ? postalcode.substring(0, 5) : postalcode;
		}catch(Exception exp){
			this.postalcode = postalcode;
		}

	}
	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}
	/**
	 * @param emailAddress the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	/**
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}
	/**
	 * @param phoneNumber the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return the zipCode
	 */
	public String getZipCode() {
		return zipCode;
	}
	/**
	 * @param zipCode the zipCode to set
	 */
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	/**
	 * @return the orderId
	 */
	public String getOrderId() {
		return orderId;
	}
	/**
	 * @param orderId the orderId to set
	 */
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @return the npaNxxNumber
	 */
	public String getNpaNxxNumber() {
		return npaNxxNumber;
	}
	/**
	 * @param npaNxxNumber the npaNxxNumber to set
	 */
	public void setNpaNxxNumber(String npaNxxNumber) {
		this.npaNxxNumber = npaNxxNumber;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
	
	public boolean isTextAlertOptin() {
		return textAlertOptin;
	}
	public void setTextAlertOptin(boolean textAlertOptin) {
		this.textAlertOptin = textAlertOptin;
	}
	public boolean isNewsLetterOptin() {
		return newsLetterOptin;
	}
	public void setNewsLetterOptin(boolean newsLetterOptin) {
		this.newsLetterOptin = newsLetterOptin;
	}
	public boolean isPaperFreeBillingIndicatorFlag() {
		return paperFreeBillingIndicatorFlag;
	}
	public void setPaperFreeBillingIndicatorFlag(boolean paperFreeBillingIndicatorFlag) {
		this.paperFreeBillingIndicatorFlag = paperFreeBillingIndicatorFlag;
	}
	@Override
	public String toString() {
		
		StringBuilder sb = new StringBuilder();
		sb.append(" emailAddress => " + this.emailAddress);
		sb.append(" firstName => " + this.firstName);
		sb.append(" lastName => " + this.lastName);
		sb.append(" phoneNumber => " + this.phoneNumber);
		sb.append(" address1 => " + this.address1);
		sb.append(" address2 => " + this.address2);
		sb.append(" zipcode => " + this.zipCode);
		sb.append(" city => " + this.city);
		sb.append(" state => " + this.state);
		return sb.toString();
	}
	public boolean isAddressVerified() {
		return addressVerified;
	}
	public void setAddressVerified(boolean addressVerified) {
		this.addressVerified = addressVerified;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getFirmName() {
		return firmName;
	}
	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}
	public String getBusinessName() {
		return businessName;
	}
	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}
	public String getApartmentNum() {
		return apartmentNum;
	}
	public void setApartmentNum(String apartmentNum) {
		this.apartmentNum = apartmentNum;
	}
	public String getAddressDirection() {
		return addressDirection;
	}
	public void setAddressDirection(String addressDirection) {
		this.addressDirection = addressDirection;
	}
	public String getPoBox() {
		return poBox;
	}
	public void setPoBox(String poBox) {
		this.poBox = poBox;
	}
	public String getStreetNumber() {
		return streetNumber;
	}
	public void setStreetNumber(String streetNumber) {
		this.streetNumber = streetNumber;
	}
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	public String getStreetType() {
		return streetType;
	}
	public void setStreetType(String streetType) {
		this.streetType = streetType;
	}
	public String getRuralRoute() {
		return ruralRoute;
	}
	public void setRuralRoute(String ruralRoute) {
		this.ruralRoute = ruralRoute;
	}
	public String getRuralDel() {
		return ruralDel;
	}
	public void setRuralDel(String ruralDel) {
		this.ruralDel = ruralDel;
	}
	public String getZipCode4() {
		return zipCode4;
	}
	public void setZipCode4(String zipCode4) {
		this.zipCode4 = zipCode4;
	}
	public String getZipCode5() {
		return zipCode5;
	}
	public void setZipCode5(String zipCode5) {
		this.zipCode5 = zipCode5;
	}
	public String getFaxNumber() {
		return faxNumber;
	}
	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}
	public String getAddressType() {
		return addressType;
	}
	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getPrefix() {
		return prefix;
	}
	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}
	public String getSuffix() {
		return suffix;
	}
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}
	public String getFips() {return fips;}
	public void setFips(String fips) {this.fips = fips;}
	/**
	 * @return the version
	 */
	public int getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(int version) {
		this.version = version;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
}
