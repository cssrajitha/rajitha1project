package onevz.soe.prepay.adaptor.cart.util;

import onevz.soe.channels.SOEChannels;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants;
import onevz.soe.utilities.StringUtilities;
import org.apache.commons.collections4.CollectionUtils;
import onevz.soe.wsclient.bpm.model.response.Error;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Service;

import java.util.*;

import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.*;

@Service
public class PrepayAdaptorCartUtil {

	

	public static Map<String,String> getPrepayODServiceCommonHeaders(PrepaidODRequestData prepaidODRequestData) {
		return getPrepayODServiceCommonHeaders(prepaidODRequestData, NSE);
	}

	public static Map<String,String> getPrepayODServiceCommonHeaders(PrepaidODRequestData prepaidODRequestData, String flowName) {
		Map<String,String> headers=new HashMap<>();
		String flow = PrepayAdaptorCartUtil.getODFlowName(flowName);
		String prepaidODRequestCookieStr=PREPAY_OD_REQUEST_ECOMM_SESSION + "="+prepaidODRequestData.getEcommSessionId()+";"
				+ PREPAY_OD_REQUEST_P_CSRFTKN +"="+prepaidODRequestData.getPCsrfToken()+";"
				+ PREPAY_OD_REQUEST_FLOW +"="+flow+";";
		headers.put(HttpHeaders.COOKIE, prepaidODRequestCookieStr);
		headers.put(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		headers.put(PREPAY_OD_REQUEST_P_CSRF_TOKEN, prepaidODRequestData.getPCsrfToken());
		return headers;
	}

	/**
	 * 
	 * @param channelId
	 * @return channelType
	 */
	public static String getChannelType(String channelId) {
		if (channelId != null && SOEChannels.findByChannelName(channelId) != null) {
			return SOEChannels.findByChannelName(channelId).getChannelType();
		}
		return "";
	}

	/**
	 * 
	 * @param channelId
	 * @return channelType
	 */
	public static String getChannel(String channelId) {

		if (channelId != null && SOEChannels.findByChannelName(channelId) != null) {
			return SOEChannels.findByChannelName(channelId).getChannelType();
		}
		return null;
	}
	
	/**
	 * 
	 * @param depletionLocationCode
	 * @param channelId
	 * @return result
	 */
	public static String removeSpecialCharacters(String depletionLocationCode, String channelId) {
		String result = depletionLocationCode;
		if(PrepayAdaptorCartConstants.ASSISTED.equalsIgnoreCase(getChannelType(channelId)))	
			result = depletionLocationCode.replaceAll("[-+.^:,]","");
		
		return result;
	}

	public static boolean isDigital(String channelId) {
		return PrepayAdaptorCartConstants.DIGITAL.equalsIgnoreCase(PrepayAdaptorCartUtil.getChannelType(channelId));
	}
	
	public static boolean isDigitalChannel(String channelId) {
		boolean isDigitalChannel = Boolean.FALSE;
		if (SOEChannels.findByChannelName(channelId) != null
				&& "Digital".equalsIgnoreCase(SOEChannels.findByChannelName(channelId).getChannelType()))
			isDigitalChannel = Boolean.TRUE;
		return isDigitalChannel;
	}
	
	public static List<HttpMessageConverter<?>> responseToJsonEntityConverter(){
		List<HttpMessageConverter<?>> messageConverters = new ArrayList<HttpMessageConverter<?>>();

		MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();

		converter.setSupportedMediaTypes(Collections.singletonList(MediaType.ALL));
		messageConverters.add(converter);
		return messageConverters;
	}

	public static boolean isCollectionEmpty(final Collection<?> coll) {
		if(0 == CollectionUtils.size(coll)) return true;
		if(0 == coll.stream().filter(Objects::nonNull).count()) return true;
		return false;
	}

	public static boolean isCollectionNotEmpty(final Collection<?> coll) {
		return !isCollectionEmpty(coll);
	}
	
	public static List<Error> buildErrorResponse(String name, String id, String message, String errorCategory) {
		
        List<Error> errors = new ArrayList<Error>();
        Error error = new Error();
        error.setName(name);
        error.setId(id);
        error.setMessage(message);
        error.setErrorCategory(errorCategory);
        error.setProactiveChatCustomMSG(PrepayAdaptorCartConstants.PROACTIVE_CHAT_CUSTOMER_ERR_MSG);
        error.setProactiveChatIndicator(PrepayAdaptorCartConstants.PROACTIVE_CHAT_INDICATOR);
        errors.add(error);
        return errors;
	}

	public static String getODFlowName(String flowName) {
		String flow=NSE;
		if(StringUtilities.isEmptyOrNull(flowName)) {
			return flow;
		}
		switch(flowName) {
			case NSE_BYOD:
			case NSP:
				flow=NSP;
				break;
			case AAL:
				flow=PAL;
				break;
			case EUP:
				flow=PUP;
				break;
			case ESO:
			case BYOD:
			case PASO:
				flow=PASO;
				break;
			default:
				flow=NSE;
				break;
		}
		return flow;
	}

}
