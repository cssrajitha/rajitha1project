package onevz.soe.prepay.adaptor.cart.model.cart.vo;

import java.io.Serializable;
import java.util.HashMap;

public class PrepayFeatureVO implements Serializable {
    private static final long serialVersionUID = 1L;
    private String id;
    private String skuId;
    private String productId;
    private String sorId;
    private double dueToday;
    private double dueMonthly;
    private String displayName;
    private String description ;
    private HashMap<String,Double> taxDetails;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSkuId() {
        return skuId;
    }

    public void setSkuId(String skuId) {
        this.skuId = skuId;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getSorId() {
        return sorId;
    }

    public void setSorId(String sorId) {
        this.sorId = sorId;
    }

    public double getDueToday() {
        return dueToday;
    }

    public void setDueToday(double dueToday) {
        this.dueToday = dueToday;
    }

    public double getDueMonthly() {
        return dueMonthly;
    }

    public void setDueMonthly(double dueMonthly) {
        this.dueMonthly = dueMonthly;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public HashMap<String, Double> getTaxDetails() {
        return taxDetails;
    }

    public void setTaxDetails(HashMap<String, Double> taxDetails) {
        this.taxDetails = taxDetails;
    }
}
