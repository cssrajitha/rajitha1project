package onevz.soe.prepay.adaptor.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.model.clearCart.ClearCartContext;
import onevz.soe.cart.model.clearCart.ClearCartServiceBody;
import onevz.soe.cart.model.clearCart.ClearCartServiceResponse;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.requests.ClearCartPEGARequest;
import onevz.soe.cart.responses.ClearCartPEGAResponse;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.common.model.PrepaidODRequestDataLines;
import onevz.soe.prepay.adaptor.cart.model.play.clearcart.VZWPrepayAPIClearCartPayload;
import onevz.soe.prepay.adaptor.cart.model.play.clearcart.VZWPrepayAPIClearCartResponse;
import onevz.soe.prepay.adaptor.cart.model.play.clearcart.VZWPrepayAddOrUpdateCartResponse;
import onevz.soe.prepay.adaptor.cart.util.PrepayAdaptorCartUtil;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.bpm.model.response.Error;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import onevz.soe.wsclient.prepay.webclient.model.PrepaidAdaptorWebClientRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.*;
import java.util.stream.Collectors;

import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.*;

@Service
public class PrepayAdaptorCartClearHelper {

    private static final Logger logger = LoggerFactory.getLogger(PrepayAdaptorCartClearHelper.class);
    @Autowired
    SOELoginSessionBean sessionBean;

    @Autowired
    PrepayCartRedisHelper prepayCartRedisHelper;

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    private PrepayAdaptorWebClient prepayAdaptorWebClient;
    @Value("${clearCartPrepaidLegacyServiceUrl}")
    private String clearCartPrepaidLegacyServiceUrl;

    /**
     * @param httpRequest
     * @param clearCartPEGARequest
     * @return ClearCartPEGAResponse
     */
    public Mono<ResponseEntity<ClearCartPEGAResponse>> clearCart(ServerHttpRequest httpRequest, ClearCartPEGARequest clearCartPEGARequest) {
        return prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)
                .doOnError(err -> logger.error("Failed and return error {}", err))
                .defaultIfEmpty("")
                .flatMap(response -> {
                    logger.info("PrepaidODRequestData From Redis:: " + response);
                    PrepaidODRequestData prepaidODRequestData = null;
                    if (StringUtilities.isEmptyOrNull(response)) {
                        logger.error("Failed and return error {}", response);
                        return Mono.empty();
                    } else {
                        try {
                            prepaidODRequestData = mapper.readValue(response, PrepaidODRequestData.class);
                            
                            } catch (JsonProcessingException e) {
                            logger.error("Failed to get data from redis: {}", e);
                            return Mono.empty();
                        }
                        	List<PrepaidODRequestDataLines> lines = prepaidODRequestData.getLines();
                        	
                        	if(null == lines)
                        	{
                        		logger.error("There are no lines to delete");
                            	ClearCartPEGAResponse clearCartPEGAResponse = new ClearCartPEGAResponse();
                                List<Error> errors = new ArrayList<>();
                                Error error = new Error();
                                error.setName("CLEAR_CART_BUSINESS_EXCEPTION_NOLINES");
                                error.setId("8567");
                                error.setMessage("There are no lines to remove, Cart is already clear");
                                error.setErrorCategory("BUSINESSERR");
                                error.setProactiveChatCustomMSG("We see you are experiencing issues with your order. Chat now to connect to a live agent for further assistance");
                                error.setProactiveChatIndicator("Y");
                                errors.add(error);
                                clearCartPEGAResponse.setErrors(errors);
                                return Mono.just(ResponseEntity.status(HttpStatus.OK).body(clearCartPEGAResponse));
                        	}
                        	boolean checkOut = true;
                        	int numLines = 0;
                        	for (PrepaidODRequestDataLines ln : lines) 
                        	{
                        		numLines++;
                          		if(ln.isCheckoutFlag() == false)
                        		{
                        		  checkOut = false;
                        		}
                        	}
                        	if(!checkOut)
                        	{
                        		logger.info("Inside the clear cart service when checkoutFlag is false, about to remove cart from Redis");
                        		VZWPrepayAPIClearCartResponse redisPrepayResponse = new VZWPrepayAPIClearCartResponse();
                        		VZWPrepayAPIClearCartPayload redisPrepayPayload = new VZWPrepayAPIClearCartPayload();
                        		VZWPrepayAddOrUpdateCartResponse pageData = new VZWPrepayAddOrUpdateCartResponse();
                        		redisPrepayResponse.setStatus("ok");
                        		pageData.setOrderUpdated(true);
                        		pageData.setStatus(0);
                        		pageData.setSuccess(true);
                        		pageData.setErrorMap(null);
                        		pageData.setBaseError(null);
                        		pageData.setTotalLines(numLines);
                        		redisPrepayPayload.setPageData(pageData);
                        		redisPrepayResponse.setPayload(redisPrepayPayload);
                        		ClearCartPEGAResponse finalContactInfoPEGAResponse = convertToPEGAResponse(clearCartPEGARequest, redisPrepayResponse, prepaidODRequestData);
                                prepaidODRequestData.setLines(null);
                                prepaidODRequestData.setCurr_line(0);
                                prepaidODRequestData.setNumberAssignedToAllLines(false);
                                prepaidODRequestData.setZipCode("");
                                prepaidODRequestData.setAccountOwner("");
                                prepaidODRequestData.setTotalNumAssignedLines(0);
                                prepaidODRequestData.setAccountPinAssignedtoAllLines(false);
                                prepaidODRequestData.setPaypalPaRes("");
                                prepaidODRequestData.setPaypalMD("");
                                prepaidODRequestData.setRefillCardNumbers(new HashMap<>());
                                prepaidODRequestData.setAutoPay(false);
                                prepaidODRequestData.setAccountOwner("");
                        		return prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, prepaidODRequestData)
                                        .doOnError(err -> logger.error("Failed and return error {}", err))
                                        .flatMap(deleteResp -> {
                                            logger.info("PrepaidODRequestData From Redis Deleted::  " + deleteResp);
                                            //convert PrepayOD/Play response to prepay response
                                            //ClearCartPEGAResponse finalContactInfoPEGAResponse = convertToPEGAResponse(clearCartPEGARequest, finalPrepayODResponse, redisData);

                                            return Mono.just(ResponseEntity.status(HttpStatus.OK).body(finalContactInfoPEGAResponse));
                                        });
                        	}
                        	else
                        	{
                        		logger.info("Inside the clear cart service when checkoutFlag is true, about to remove cart from backend & Redis");
                        		String flow = Objects.nonNull(prepaidODRequestData) && CollectionUtilities.isNotEmptyOrNull(prepaidODRequestData.getLines())?prepaidODRequestData.getLines().get(prepaidODRequestData.getCurr_line()-1).getFlow():NSE;      
                        		/*String flow = Objects.nonNull(clearCartPEGARequest) && Objects.nonNull(clearCartPEGARequest.getServiceBody()) 
                        			&& Objects.nonNull(clearCartPEGARequest.getServiceBody().getServiceRequest()) 
                        			&& Objects.nonNull(clearCartPEGARequest.getServiceBody().getServiceRequest().getContext()) 
                        			&& Objects.nonNull(clearCartPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo())?clearCartPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType():PrepayAdaptorCartConstants.NSE;
                        		*/
                        		PrepaidAdaptorWebClientRequest prepaidLegacyServiceRequest = getPrepaidLegacyServiceRequest(prepaidODRequestData,flow);
                            //make prepayod call
                        		return handleClearCart(httpRequest, prepaidLegacyServiceRequest, clearCartPEGARequest, prepaidODRequestData);
                        	}
//                        else
//                        {
//                        	logger.error("There are no lines to delete");
//                        	ClearCartPEGAResponse clearCartPEGAResponse = new ClearCartPEGAResponse();
//                            List<Error> errors = new ArrayList<>();
//                            Error error = new Error();
//                            error.setName("CLEAR_CART_BUSINESS_EXCEPTION_NOLINES");
//                            error.setId("8567");
//                            error.setMessage("There are no lines to remove, Cart is already clear");
//                            error.setErrorCategory("BUSINESSERR");
//                            error.setProactiveChatCustomMSG("We see you are experiencing issues with your order. Chat now to connect to a live agent for further assistance");
//                            error.setProactiveChatIndicator("Y");
//                            errors.add(error);
//                            clearCartPEGAResponse.setErrors(errors);
//                            return Mono.just(ResponseEntity.status(HttpStatus.OK).body(clearCartPEGAResponse));
//                        }
                    }
                });
    }




    private Mono<ResponseEntity<ClearCartPEGAResponse>> handleClearCart(ServerHttpRequest httpRequest,
                                                                        PrepaidAdaptorWebClientRequest prepaidLegacyServiceRequest,
                                                                        ClearCartPEGARequest clearCartPEGARequest,
                                                                        PrepaidODRequestData redisData) {


        //actual PrepayOd/play call in place
        return prepayAdaptorWebClient.getPrepayServiceResponse(httpRequest, prepaidLegacyServiceRequest)
                .doOnError(error -> logger.error("Failed to get response: {}", error))
                .flatMap(responseEntity -> {
                    VZWPrepayAPIClearCartResponse prepayODResponse = null;

                    if (!responseEntity.getStatusCode().is2xxSuccessful()) {
                        logger.info("Play response status code: {}", responseEntity.getStatusCode());
                        logger.error("Error while calling endpoint: {} with status code: {}",
                                prepaidLegacyServiceRequest.getUrl(), responseEntity.getStatusCode());
                    } else {

                        try {
                            prepayODResponse = mapper.readValue(responseEntity.getBody(), VZWPrepayAPIClearCartResponse.class);
                        } catch (JsonProcessingException e) {
                            logger.error("Failed to get data from redis:", e);
                        }

                        if (Objects.nonNull(prepayODResponse)) {

                            //AddPlanPEGAResponse requestResponse = getAddPlanPEGAResponse(prepaidODRequestData,addPlanPEGARequest);
                            VZWPrepayAPIClearCartResponse finalPrepayODResponse = prepayODResponse;
                            ClearCartPEGAResponse finalContactInfoPEGAResponse = convertToPEGAResponse(clearCartPEGARequest, finalPrepayODResponse, redisData);
                            redisData.setLines(null);
                            redisData.setCurr_line(0);
                            redisData.setNumberAssignedToAllLines(false);
                            redisData.setTotalNumAssignedLines(0);
                            redisData.setPaypalMD("");
                            redisData.setZipCode("");
                            redisData.setAccountOwner("");
                            redisData.setPaypalPaRes("");
                            redisData.setAccountPinAssignedtoAllLines(false);
                            redisData.setPaypalPaRes("");
                            redisData.setPaypalMD("");
                            redisData.setRefillCardNumbers(new HashMap<>());
                            redisData.setAutoPay(false);
                            redisData.setAccountOwner("");
                             return prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, redisData)
                            //		return prepayCartRedisHelper.removeDataFromRedis(PREPAY_OD_REQUEST_DATA)
                                    .doOnError(err -> logger.error("Failed and return error {}", err))
                                    .flatMap(deleteResp -> {
                                        logger.info("PrepaidODRequestData From Redis::  " + deleteResp);
                                        //convert PrepayOD/Play response to prepay response
                                        //ClearCartPEGAResponse finalContactInfoPEGAResponse = convertToPEGAResponse(clearCartPEGARequest, finalPrepayODResponse, redisData);

                                        return Mono.just(ResponseEntity.status(HttpStatus.OK).body(finalContactInfoPEGAResponse));
                                    });
                        } else {
                            logger.info("No Response returned");
                        }
                    }

                    //return empty response
                    return Mono.just(null);
                });
    }

    public ClearCartPEGAResponse convertToPEGAResponse(ClearCartPEGARequest clearCartPEGARequest,
                                                        VZWPrepayAPIClearCartResponse prepayODResponse, PrepaidODRequestData redisData) {


        ClearCartPEGAResponse response = new ClearCartPEGAResponse();

        CartServiceServiceHeader serviceHeader = clearCartPEGARequest.getServiceHeader();
        if(prepayODResponse.getPayload().getPageData().isOrderUpdated()) {
            serviceHeader.setStatusMsg(STATUS_SUCCESS);
            serviceHeader.setStatusCode("00");
        } else {
            serviceHeader.setStatusMsg(STATUS_FAILURE);
            serviceHeader.setStatusCode("01");
        }
        response.setServiceHeader(serviceHeader);
        response.setServiceBody(getServiceBody(clearCartPEGARequest, redisData));
        return response;
    }


    private ClearCartServiceBody getServiceBody(ClearCartPEGARequest clearCartPEGARequest,
                                                PrepaidODRequestData redisData) {
        ClearCartServiceBody clearCartServiceBody = new ClearCartServiceBody();
        clearCartServiceBody.setServiceResponse(getServiceResponse(clearCartPEGARequest, redisData));
        return clearCartServiceBody;
    }

    private ClearCartServiceResponse getServiceResponse(ClearCartPEGARequest clearCartPEGARequest,
                                                        PrepaidODRequestData redisData) {
        ClearCartServiceResponse clearCartServiceResponse = new ClearCartServiceResponse();
        clearCartServiceResponse.setContext(getResponseContext(clearCartPEGARequest, redisData));
        return clearCartServiceResponse;
    }

    private ClearCartContext getResponseContext(ClearCartPEGARequest clearCartPEGARequest,
                                                PrepaidODRequestData redisData) {
        ClearCartContext clearCartContext = new ClearCartContext();
        try {
            clearCartContext.setContextInfo(getContextInfo(clearCartPEGARequest));
            clearCartContext.setCustomerInfo(getCustomerinfo(clearCartPEGARequest));
            clearCartContext.setCartInfo(getCartInfo(clearCartPEGARequest));
            clearCartContext.setProcessMTNList(getProcessMTNList(clearCartPEGARequest, redisData));

        } catch (Exception ex) {
            logger.error("Exception in building response{}", ex);
        }
        return clearCartContext;
    }

    public ProcessMTNList[] getProcessMTNList(ClearCartPEGARequest clearCartPEGARequest,
                                               PrepaidODRequestData redisData) {
        if(clearCartPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo()!=null && clearCartPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getProcessingMTN()!=null) {
            ProcessMTNList mtnList = new ProcessMTNList();
            mtnList.setMtn(clearCartPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getProcessingMTN());
            mtnList.setCompletedprocessSteps(setCompletedProcessStep(clearCartPEGARequest.getServiceBody().getServiceRequest().
                    getContext().getCustomerInfo().getProcessingMTN(), redisData));
            return Arrays.asList(mtnList).toArray(new ProcessMTNList[0]);
        } else {
            return null;
        }
    }

    private static String[] setCompletedProcessStep(String mtn, PrepaidODRequestData redisData) {

    	if(Objects.nonNull(redisData) && Objects.nonNull(redisData.getLines())) {
    		List<PrepaidODRequestDataLines> dataLines = redisData.getLines().stream().filter(lines-> lines.getMtn().equalsIgnoreCase(mtn)).collect(Collectors.toList());
    		List<String> stepsList = dataLines.get(0).getCompletedProcessSteps();
    		stepsList.add("ClearCart");

    		if (null != stepsList && !stepsList.isEmpty()) {
                return stepsList.toArray(new String[stepsList.size() - 1]);
            }
    	}
    	return new String[]{"ClearCart"};
    }


    public CartServiceCartInfo getCartInfo(ClearCartPEGARequest clearCartPEGARequest
                                            ) {
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(clearCartPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getCartId());
        return cartInfo;
    }

    public CartServiceCustomerInfo getCustomerinfo(ClearCartPEGARequest clearCartPEGARequest
                                                    ) {
        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setCustomerType(clearCartPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCustomerType());
        customerInfo.setAccountNumber(clearCartPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getAccountNumber());
        customerInfo.setCartCreator(clearCartPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCartCreator());
        customerInfo.setProcessingMTN(clearCartPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getProcessingMTN());
        customerInfo.setRegisterNumber(clearCartPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getRegisterNumber());
        customerInfo.setMtnFlow(clearCartPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getMtnFlow());
        customerInfo.setGlobalId(clearCartPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getGlobalId());
        return customerInfo;
    }

    public CartServiceContextInfo getContextInfo(ClearCartPEGARequest clearCartPEGARequest
                                                  ) {
        CartServiceContextInfo serviceContextInfo = new CartServiceContextInfo();
        serviceContextInfo.setCallReason(clearCartPEGARequest.getServiceBody().getServiceRequest().getContext().getContextInfo().getCallReason());
        serviceContextInfo.setIntent(clearCartPEGARequest.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
        serviceContextInfo.setProcessStep("PromoHub");  // we need get it from redis
        serviceContextInfo.setProcessAction("");
        return serviceContextInfo;
    }
    public PrepaidAdaptorWebClientRequest getPrepaidLegacyServiceRequest(PrepaidODRequestData prepaidODRequestData, String flow) {
        PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
        prepaidAdaptorWebClientRequest.setUrl(clearCartPrepaidLegacyServiceUrl);
        prepaidAdaptorWebClientRequest.setRequestBody("{}");
        prepaidAdaptorWebClientRequest.setRequestType(HttpMethod.GET.toString());
        prepaidAdaptorWebClientRequest.setHeader(PrepayAdaptorCartUtil.getPrepayODServiceCommonHeaders(prepaidODRequestData, flow));
        return prepaidAdaptorWebClientRequest;
    }

}
