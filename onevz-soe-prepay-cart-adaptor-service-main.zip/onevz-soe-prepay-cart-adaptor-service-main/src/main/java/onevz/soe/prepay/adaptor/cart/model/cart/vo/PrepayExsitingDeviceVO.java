package onevz.soe.prepay.adaptor.cart.model.cart.vo;

import java.io.Serializable;

public class PrepayExsitingDeviceVO implements Serializable {
    private static final long serialVersionUID = 1L;


    private String mdn;

    private String role ;

    private String firstName;

    private String lastName;

    private String skuId;

    private String brand;

    private String deviceModel;

    private String planSorId;

    private double planPrice;

    private String planDescription;

    private String deviceImageUrl;
}
