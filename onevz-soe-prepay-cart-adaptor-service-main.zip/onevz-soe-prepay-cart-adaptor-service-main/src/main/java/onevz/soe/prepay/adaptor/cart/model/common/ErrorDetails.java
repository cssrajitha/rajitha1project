package onevz.soe.prepay.adaptor.cart.model.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Holds the Error Details.
 */
public class ErrorDetails {
	@JsonInclude(Include.NON_NULL)
    @JsonProperty(value = "field")
    private String field;

    @JsonInclude(Include.NON_NULL)
    @JsonProperty(value = "value")
    private String value;

    @JsonInclude(Include.NON_NULL)
    @JsonProperty(value = "issue")
    private String issue;

    @JsonInclude(Include.NON_NULL)
    @JsonProperty(value = "location")
    private String location;


}
