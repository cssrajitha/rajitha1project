package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;
import java.util.List;

/**
 * SoftSKULine Item
 */
public class SoftSku5GLineItem implements Serializable{

    private String commerceItemId;
    private String skuId;
    private String sorId;
    private String productId;
    private String displayName;
    private double price;
    private String type;
    private List<TaxDetail> taxDetails;

    public String getCommerceItemId() {
        return commerceItemId;
    }

    public void setCommerceItemId(String commerceItemId) {
        this.commerceItemId = commerceItemId;
    }

    public String getSkuId() {
        return skuId;
    }

    public void setSkuId(String skuId) {
        this.skuId = skuId;
    }

    public String getSorId() {
        return sorId;
    }

    public void setSorId(String sorId) {
        this.sorId = sorId;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public SoftSku5GLineItem() {

    }

    public SoftSku5GLineItem(String commerceItemId) {
        this.commerceItemId = commerceItemId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<TaxDetail> getTaxDetails() {
        return taxDetails;
    }

    public void setTaxDetails(List<TaxDetail> taxDetails) {
        this.taxDetails = taxDetails;
    }
}