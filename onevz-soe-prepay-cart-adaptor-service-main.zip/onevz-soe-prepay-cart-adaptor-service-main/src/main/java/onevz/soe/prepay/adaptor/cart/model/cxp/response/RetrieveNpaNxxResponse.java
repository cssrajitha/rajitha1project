package onevz.soe.prepay.adaptor.cart.model.cxp.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import onevz.soe.prepay.adaptor.cart.model.cxp.common.ETNIError400Response;

@Getter
@Setter
@NoArgsConstructor
@ToString
@JsonInclude(JsonInclude.Include.ALWAYS)
public class RetrieveNpaNxxResponse {
	
	private RetrieveNpaNxxDataResponse data;
	private String statusMessage;
	private String statusCode;
	private ETNIError400Response errors;

}
