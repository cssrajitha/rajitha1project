package onevz.soe.prepay.adaptor.cart.model.checkoutdetails;

import io.jsonwebtoken.lang.Collections;

import java.util.ArrayList;
import java.util.List;


public enum PendingStepsEnum {
    PLAN_SELECTION("Blocker","noPromoPlanSelection","plan"),
    NUMBER_SELECTION("Blocker","transferNumber","number");
	// commented for Price Plan Refresh
    //International_Selection("Blocker","additionalFeatures","internationalplan");

     PendingStepsEnum(String errorLevel, String step, String id) {
        this.errorLevel = errorLevel;
        this.step = step;
        this.id = id;
    }

    public static List<PendingStepsEnum> getPendingSteps(){
         List<PendingStepsEnum> stepsEnums = new ArrayList<>();
         stepsEnums.addAll(Collections.arrayToList(PendingStepsEnum.values()));
         return stepsEnums;
    }

    private String errorLevel;
    private String step;
    private String id;

    public String getErrorLevel() {
        return errorLevel;
    }

    public void setErrorLevel(String errorLevel) {
        this.errorLevel = errorLevel;
    }

    public String getStep() {
        return step;
    }

    public void setStep(String step) {
        this.step = step;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
