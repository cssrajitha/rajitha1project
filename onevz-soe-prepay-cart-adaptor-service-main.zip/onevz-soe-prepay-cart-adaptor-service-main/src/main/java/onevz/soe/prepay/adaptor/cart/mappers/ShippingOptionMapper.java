package onevz.soe.prepay.adaptor.cart.mappers;

import onevz.soe.prepay.adaptor.cart.model.play.shippingoptions.ShippingOption;
import onevz.soe.prepay.adaptor.cart.model.shippingoptions.ShippingOptions;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface ShippingOptionMapper {

    @Mapping(source="estimatedDeliveryDate", target="estDeliveryDate")
    @Mapping(source="overnightShipping", target="freeOvernightShipping")
    @Mapping(expression = "java(source.getDiscountedShippingCost()>=0 ?false:true)", target="discounted")
    ShippingOptions playShippingOptionToSOEShippingOptions(ShippingOption source);

    @InheritInverseConfiguration(name = "playShippingOptionToSOEShippingOptions")
    @Mapping(target = "discountedShippingCost", ignore = true)
    ShippingOption soeShippingOptionsToPlayShippingOption(ShippingOptions source);

}
