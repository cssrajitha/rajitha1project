package onevz.soe.prepay.adaptor.cart.model.cart.vo;

public class ApplePayBillingInfo {
	private String firstName;
	private String lastName;
	private String addressLine1;
	private String addressLine2;
	private String locality;
	private String country;
	private String postalCode;
	private String administrativeArea;
	private String countryCode;
	private String emailAddress;
	private String phoneNumber;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getLocality() {
		return locality;
	}

	public void setLocality(String locality) {
		this.locality = locality;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getAdministrativeArea() {
		return administrativeArea;
	}

	public void setAdministrativeArea(String administrativeArea) {
		this.administrativeArea = administrativeArea;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getAddressLine1() {	return addressLine1; }

	public void setAddressLine1(String addressLine1) {	this.addressLine1 = addressLine1; }

	public String getAddressLine2() {	return addressLine2; }

	public void setAddressLine2(String addressLine2) {	this.addressLine2 = addressLine2; }

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
}
