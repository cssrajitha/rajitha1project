package onevz.soe.prepay.adaptor.cart.model.play.common.vo;

import java.io.Serializable;

public class CQContent implements Serializable{
    private static final long serialVersionUID = -6096280577046242346L;

    private String error;
    private String label;
    private String html;

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getHtml() {
        return html;
    }

    public void setHtml(String html) {
        this.html = html;
    }
}
