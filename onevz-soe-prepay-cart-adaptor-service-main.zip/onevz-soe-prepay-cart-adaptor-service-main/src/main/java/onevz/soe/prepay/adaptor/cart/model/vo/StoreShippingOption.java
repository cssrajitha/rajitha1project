package onevz.soe.prepay.adaptor.cart.model.vo;

public class StoreShippingOption {

	private String skuCode;
    private Object skuType;
    private Object orderCutOffTime;
    
	public String getSkuCode() {
		return skuCode;
	}
	public void setSkuCode(String skuCode) {
		this.skuCode = skuCode;
	}
	public Object getSkuType() {
		return skuType;
	}
	public void setSkuType(Object skuType) {
		this.skuType = skuType;
	}
	public Object getOrderCutOffTime() {
		return orderCutOffTime;
	}
	public void setOrderCutOffTime(Object orderCutOffTime) {
		this.orderCutOffTime = orderCutOffTime;
	}
}
