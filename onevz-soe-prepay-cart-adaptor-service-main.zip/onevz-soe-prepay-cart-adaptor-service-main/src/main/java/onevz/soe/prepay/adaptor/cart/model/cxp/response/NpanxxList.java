package onevz.soe.prepay.adaptor.cart.model.cxp.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Developed By: Pavani M
 * Last Modified 2/3/2022 03:31 PM
 * Copyright (c) 2019. All right reserved
 *
 * POJO class
 */
@Getter
@Setter
@NoArgsConstructor
public class NpanxxList {
	
	private String zip;
	private String mdnTyp;
	private String city;
	private String ngp2;
	private String locality;
	private String county;
	private String ngp1;
	private String nxx;
	private String mdnCount;
	private String billingSysId;
	private String homeBillId1;
	private String homeBillId2;
	private String prodTyp;
	private String state;
	private String npa;
	
}
