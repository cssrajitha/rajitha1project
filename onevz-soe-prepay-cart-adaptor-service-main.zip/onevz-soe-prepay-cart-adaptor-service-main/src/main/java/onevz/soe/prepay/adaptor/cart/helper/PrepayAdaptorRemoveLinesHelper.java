package onevz.soe.prepay.adaptor.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.removeLines.RemoveLinesContext;
import onevz.soe.cart.model.removeLines.RemoveLinesServiceBody;
import onevz.soe.cart.model.removeLines.RemoveLinesServiceResponse;
import onevz.soe.cart.requests.RemoveLinesPEGARequest;
import onevz.soe.cart.responses.AssignMtnPEGAResponse;
import onevz.soe.cart.responses.RemoveLinesPEGAResponse;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.common.model.PrepaidODRequestDataLines;
import onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants;
import onevz.soe.prepay.adaptor.cart.model.cart.removelines.RemoveLineItemsRequest;
import onevz.soe.prepay.adaptor.cart.model.cart.removelines.RemoveLinesDeriveModels;
import onevz.soe.prepay.adaptor.cart.model.play.RemoveLinesPrepayResponse;
import onevz.soe.prepay.adaptor.cart.util.PrepayAdaptorCartUtil;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.bpm.model.response.AvailablePaths;
import onevz.soe.wsclient.bpm.model.response.Error;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import onevz.soe.wsclient.prepay.webclient.model.PrepaidAdaptorWebClientRequest;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.*;
import java.util.stream.Collectors;

import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.*;


@Service
public class PrepayAdaptorRemoveLinesHelper {

    private static final Logger logger = LoggerFactory.getLogger(PrepayAdaptorRemoveLinesHelper.class);
    @Autowired
    SOELoginSessionBean sessionBean;

    @Autowired
    PrepayCartRedisHelper prepayCartRedisHelper;

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    private PrepayAdaptorWebClient prepayAdaptorWebClient;
    
    @Value("${removeLinesPrepaidLegacyServiceUrl}")
    private String removeLinesPrepaidLegacyServiceUrl;
    
	@Value("${accountOwner:true}")
    private String accountOwner;

    /**
     * @param httpRequest
     * @param request
     * @return RemoveLinesPEGAResponse
     */
    public Mono<ResponseEntity<RemoveLinesPEGAResponse>> removeLines(ServerHttpRequest httpRequest, RemoveLinesPEGARequest request) {

        return prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)
                .doOnError(err -> logger.error("Failed and return error {}", err))
                .defaultIfEmpty("")
                .flatMap(response -> {
                    logger.info("PrepaidODRequestData From Redis:: {}" , response);
                    PrepaidODRequestData prepaidODRequestData = null;
                    if (StringUtilities.isEmptyOrNull(response)) {
                        logger.error("Error in fetching redis data");
                        return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new RemoveLinesPEGAResponse()));
                    }
                    else 
                    {
                        try 
                        {
                            prepaidODRequestData = mapper.readValue(response, PrepaidODRequestData.class);
                        } 
                        catch (JsonProcessingException e) 
                        {
                            logger.error("Failed to get data from redis: {}", e);
                            //send Mono error response
                            return Mono.empty();
                        }
                        
                        Line[] requestLines = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines();
                        
                        if ((Objects.nonNull(String.valueOf(prepaidODRequestData))) && (Objects.nonNull(requestLines)))
                        {
                            List<PrepaidODRequestDataLines> redisLines = prepaidODRequestData.getLines();
                            List<String> linesToRemoveFromOD = new ArrayList<String>();
                            List<PrepaidODRequestDataLines> linesRemoveFromRedis = new ArrayList<>();
                            
                            if (null != requestLines && null != redisLines) 
                            {
                            	PrepaidODRequestData updatedODRequestData = new PrepaidODRequestData(); 
                            	List<PrepaidODRequestDataLines> updatedODRequestDataLines = new ArrayList<PrepaidODRequestDataLines>();
                            	RemoveLinesDeriveModels requestModel = new RemoveLinesDeriveModels();
                            	requestModel.setErrorResponse(false);
                            	requestModel.setRequestLines(requestLines);
                            	requestModel.setUpdatedRedisDataLines(updatedODRequestDataLines);
                            	requestModel.setRedisLines(redisLines);
                            	RemoveLinesDeriveModels updatedRequestModel = separateLines(requestModel);
                            	String intendType = Objects.nonNull(request.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType())?request.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType():PrepayAdaptorCartConstants.NSE;
                            	// Build Prepay OD service call request
                            	PrepaidAdaptorWebClientRequest prepaidLegacyServiceRequest = getPrepaidLegacyServiceRequest(updatedRequestModel.getLinesToRemove(), prepaidODRequestData,intendType);
                            	// Invoke Prepay OD call
                            	
                            	//make prepay od call
                                Mono<ResponseEntity<RemoveLinesPEGAResponse>> pegaResponse =
                                        invokePrepayAdaptorWebClient(httpRequest, prepaidLegacyServiceRequest,
                                                request, prepaidODRequestData, updatedRequestModel);

                                return pegaResponse;
                            
                             }
                            else
                            {
                            	logger.error("Redis Data Lines are not present");
                            	logger.error("There are no lines to remove");
                            	RemoveLinesPEGAResponse removeLinesPEGAResponse = new RemoveLinesPEGAResponse();
                                List<Error> errors = new ArrayList<>();
                                Error error = new Error();
                                error.setName("REMOVE_LINES_BUSINESS_EXCEPTION_NOLINES");
                                error.setId("8568");
                                error.setMessage("There are no lines to remove from Cart");
                                error.setErrorCategory("BUSINESSERR");
                                error.setProactiveChatCustomMSG("We see you are experiencing issues with your order. Chat now to connect to a live agent for further assistance");
                                error.setProactiveChatIndicator("Y");
                                errors.add(error);
                                removeLinesPEGAResponse.setErrors(errors);
                                return Mono.just(ResponseEntity.status(HttpStatus.OK).body(removeLinesPEGAResponse));
                            }
                        }
                        else
                        {
                        	// requestLines and Redis Data are null, so nothing to process return error response
                        }
                    }
   
                   return Mono.just(ResponseEntity.status(HttpStatus.OK).body(new RemoveLinesPEGAResponse()));

                });

    	}
    
    
    private RemoveLinesDeriveModels separateLines(RemoveLinesDeriveModels requestModel)
    {
    	   	
       	for (Line requestLine : requestModel.getRequestLines()) 
    	{
    		for (PrepaidODRequestDataLines redisLine : requestModel.getRedisLines()) 
    		{
    			if(requestLine.getMtn().equalsIgnoreCase(redisLine.getMtn()))
    			{
    				if(redisLine.isCheckoutFlag())
    				{
    					if(!Strings.isNullOrEmpty(redisLine.getLineItemId()))
    					{
    						//List<String> lineList = new ArrayList<String>();
    						//lineList.add(redisLine.getLineItemId());
    						requestModel.setLinesToRemove(redisLine.getLineItemId());
    						logger.debug("Added Line: {} to be removed from Prepay Cart",redisLine.getLineItemId());
    					}
    					else
    					{
    						logger.error("LineItemID for line: {} in redis is null",redisLine.getLineItemId());
    						requestModel.setErrorResponse(true);
    					}
    				}
    				else
    				{
    					logger.debug("Checkout Flag is false in Redis is null for the line: {} so adding this line to remove from Redis",requestLine.getMtn());
    				}
    			}
    			else
    			{
    				logger.info("Add this redisLine item back to the Redis as request Line identifier is matching the mtn value in Redis: {}", requestLine.getMtn());
    				(requestModel.getUpdatedRedisDataLines()).add(redisLine);
    				
    			}
    		}
    	}
       	return requestModel;
    }
    	

    private Mono<ResponseEntity<RemoveLinesPEGAResponse>> invokePrepayAdaptorWebClient(ServerHttpRequest httpRequest,
                                                                                       PrepaidAdaptorWebClientRequest prepaidLegacyServiceRequest,
                                                                                       RemoveLinesPEGARequest request,
                                                                                       PrepaidODRequestData redisData,
                                                                                       RemoveLinesDeriveModels updatedModel) {
    	PrepaidODRequestData updatedRedis = new PrepaidODRequestData();
    	updatedRedis.setEcommSessionId(redisData.getEcommSessionId());
    	updatedRedis.setPCsrfToken(redisData.getPCsrfToken());
    	updatedRedis.setLines(updatedModel.getUpdatedRedisDataLines());
    	updatedRedis.setCurr_line((updatedModel.getUpdatedRedisDataLines()).size());
    	updatedRedis.setZipCode(redisData.getZipCode());
        updatedRedis.setRefillCardNumbers(null!=redisData.getRefillCardNumbers()?redisData.getRefillCardNumbers(): Collections.emptyMap());
    	List<PrepaidODRequestDataLines> remainingLines = redisData.getLines().stream().filter(line->!line.getMtn().equalsIgnoreCase(request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getMtn())).collect(Collectors.toList());




    	if(redisData.getLines().size() > 2) {
    		if(redisData.getAccountOwner().equalsIgnoreCase(request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getMtn())) {
    			updatedRedis.setAccountOwner(remainingLines.get(0).getMtn());
    		} else {
    			updatedRedis.setAccountOwner(redisData.getAccountOwner());
    		}
    		
    	} else {
    		if(redisData.getLines().size() > 1) {
    			updatedRedis.setAccountOwner(remainingLines.get(0).getMtn());
    		} else {
    			updatedRedis.setAccountOwner("");
    		}
    	}

    	logger.info("Updating {} as account Owner",updatedRedis.getAccountOwner());
    	
    	if(StringUtils.isNotEmpty(updatedModel.getLinesToRemove()))
        {
        	logger.info("Line number: {} is identified to be removed from PrepayOD",updatedModel.getLinesToRemove());
	    	//actual PrepayOd/play call in place

            return prepayAdaptorWebClient.getPrepayServiceResponse(httpRequest, prepaidLegacyServiceRequest)
                    .doOnError(error -> logger.error("Failed to get response: {}", error))
                    .flatMap(responseEntity -> {
                        if (!responseEntity.getStatusCode().is2xxSuccessful()) {
                            logger.error("Error while calling endpoint: {} with status code: {}",
                                    prepaidLegacyServiceRequest.getUrl(), responseEntity.getStatusCode());
                        }
                        else {
                         RemoveLinesPrepayResponse removeLinesPrepayResponse = null;

                        try {
                            removeLinesPrepayResponse = mapper.readValue(responseEntity.getBody(), RemoveLinesPrepayResponse.class);

                                if (StringUtilities.isNotEmptyOrNull(removeLinesPrepayResponse.getStatus()) &&
                                        !removeLinesPrepayResponse.getStatus().equalsIgnoreCase("error")) {
                                         logger.info("Play response status code : {}", responseEntity.getStatusCode());

                                         for (int i = 0; i < redisData.getLines().size(); i++) {
                                    if (redisData.getLines().get(i).isCheckoutFlag()) {
                                        if (StringUtilities.isNotEmptyOrNull(removeLinesPrepayResponse.getPayload().getPageData().getLineItemIdToChangePLan())) {
                                            if (redisData.getLines().get(i).getLineItemId().equalsIgnoreCase(removeLinesPrepayResponse.getPayload().getPageData().getLineItemIdToChangePLan())) {
                                                updatedRedis.setLineItemIdToChangePLan(redisData.getLines().get(i).getMtn());
                                                redisData.setLineItemIdToChangePLan(redisData.getLines().get(i).getMtn());
                                            }
                                        }
                                    }
                                }
                            }
                        }catch (JsonProcessingException e) {
                            throw new RuntimeException(e);
                        }

                        String playActualResponse = responseEntity.getBody();

                        logger.info("Prepay RemoveDevice OD Response::{}", playActualResponse);
                        if (StringUtilities.isNotEmptyOrNull(removeLinesPrepayResponse.getStatus()) &&  !removeLinesPrepayResponse.getStatus().equalsIgnoreCase("error")) {
                        	return prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, updatedRedis)
                                    .doOnError(err -> logger.error("Failed and return error {}", err))
                                    .flatMap(upsertResp -> {
                                        logger.info("PrepaidODRequestData From Redis:: {} " , upsertResp);
                                        //convert PrepayOD/Play response to prepay response
                                        RemoveLinesPEGAResponse pegaResponse = convertToPEGAResponse(request, true, redisData);
                                        logger.info("Pega Response after OD Play RemoveDevice Call::{}", pegaResponse);
                                        return Mono.just(ResponseEntity.status(HttpStatus.OK).body(pegaResponse));
                                    });
                        } else {
                            logger.info("No Response returned");
                            return prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, redisData)
                                    .doOnError(err -> logger.error("Failed and return error {}", err))
                                    .flatMap(upsertResp -> {
                                        logger.info("PrepaidODRequestData From Redis:: {}  " , upsertResp);
                                        //convert PrepayOD/Play response to prepay response
                                        RemoveLinesPEGAResponse pegaResponse = convertToPEGAResponse(request, false, redisData);
                                        logger.info("Pega Response after RemoveDevice Call after removing data only from Redis::{}", pegaResponse);
                                        return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(pegaResponse));
                                    });
                            
                        }
                    }
                    //return empty response
                    return Mono.just(null);
                });
        }
        else
        {
        	updatedRedis.setLines(updatedModel.getUpdatedRedisDataLines());
            return prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, updatedRedis)
                    .doOnError(err -> logger.error("Failed and return error {}", err))
                    .flatMap(upsertResp -> {
                        logger.info("PrepaidODRequestData From Redis:: {} " , upsertResp);
                        //convert PrepayOD/Play response to prepay response
                        RemoveLinesPEGAResponse pegaResponse = convertToPEGAResponse(request, true, redisData);
                        return Mono.just(ResponseEntity.status(HttpStatus.OK).body(pegaResponse));
                    });
        	    	
        }
    }

    public RemoveLinesPEGAResponse convertToPEGAResponse(RemoveLinesPEGARequest request, boolean isOrderUpdated,
    		PrepaidODRequestData redisData) {


        RemoveLinesPEGAResponse response = new RemoveLinesPEGAResponse();

        CartServiceServiceHeader serviceHeader = request.getServiceHeader();
        if (isOrderUpdated) {
            serviceHeader.setStatusMsg(STATUS_SUCCESS);
            serviceHeader.setStatusCode("00");
        } else {
            serviceHeader.setStatusMsg(STATUS_FAILURE);
            serviceHeader.setStatusCode("01");
        }
        response.setServiceHeader(serviceHeader);
        response.setServiceBody(getServiceBody(request, redisData));
        return response;
    }

    private RemoveLinesServiceBody getServiceBody(RemoveLinesPEGARequest request,
                                                  PrepaidODRequestData redisData) {
        RemoveLinesServiceBody body = new RemoveLinesServiceBody();
        body.setServiceResponse(getServiceResponse(request, redisData));
        return body;
    }

    private RemoveLinesServiceResponse getServiceResponse(RemoveLinesPEGARequest request,
                                                          PrepaidODRequestData redisData) {
        RemoveLinesServiceResponse RemoveLinesServiceResponse = new RemoveLinesServiceResponse();
        RemoveLinesServiceResponse.setContext(getResponseContext(request, redisData));
        return RemoveLinesServiceResponse;
    }

    private RemoveLinesContext getResponseContext(RemoveLinesPEGARequest request,
                                                  PrepaidODRequestData redisData) {
        RemoveLinesContext RemoveLinesContext = new RemoveLinesContext();
        try {
            RemoveLinesContext.setContextInfo(getContextInfo(request, redisData));
            RemoveLinesContext.setCustomerInfo(getCustomerinfo(request, redisData));
            RemoveLinesContext.setCartInfo(getCartInfo(request, redisData));
            RemoveLinesContext.setProcessMTNList(getProcessMTNList(request, redisData));

        } catch (Exception ex) {
            logger.error("Exception in building response{}", ex);
        }
        return RemoveLinesContext;
    }

    private ProcessMTNList[] getProcessMTNList(RemoveLinesPEGARequest request,
                                               PrepaidODRequestData redisData) {
       	if(Objects.nonNull(request) && Objects.nonNull(request.getServiceBody()) 
    			&& Objects.nonNull(request.getServiceBody().getServiceRequest().getContext())
    			&& Objects.nonNull(request.getServiceBody().getServiceRequest().getContext().getCartInfo()) 
    			&& Objects.nonNull(request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines())
    			&& Objects.nonNull(redisData) && CollectionUtilities.isNotEmptyOrNull(redisData.getLines())) {
    		
            ProcessMTNList mtnList = new ProcessMTNList();
            mtnList.setMtn(redisData.getLines().get(0).getMtn());
            List<PrepaidODRequestDataLines> dataLines = redisData.getLines().stream().filter(line->line.getMtn().equalsIgnoreCase(request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getMtn())).collect(Collectors.toList());
            List<String> completedSteps = new ArrayList<>();
            
            if( Objects.nonNull(dataLines) && CollectionUtilities.isNotEmptyOrNull(dataLines) && Objects.nonNull(dataLines.get(0))) {
            	completedSteps = dataLines.get(0).getCompletedProcessSteps();
            }
            completedSteps.add(PrepayAdaptorCartConstants.REMOVE_LINES);
            mtnList.setCompletedprocessSteps(completedSteps.toArray(new String[completedSteps.size()]));
            return Arrays.asList(mtnList).toArray(new ProcessMTNList[0]);
        } else {
        	
            return null;
        }
    }

    private CartServiceCartInfo getCartInfo(RemoveLinesPEGARequest request,
                                            PrepaidODRequestData redisData) {
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        cartInfo.setCartId(request.getServiceBody().getServiceRequest().getContext().getCartInfo().getCartId());
        cartInfo.setLineItemIdToChangePLan(redisData.getLineItemIdToChangePLan());
        return cartInfo;
    }

    private CartServiceCustomerInfo getCustomerinfo(RemoveLinesPEGARequest request,
                                                    PrepaidODRequestData redisData) {
        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        customerInfo.setCustomerType(request.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCustomerType());
        customerInfo.setAccountNumber(request.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getAccountNumber());
        customerInfo.setCartCreator(request.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCartCreator());        
        customerInfo.setRegisterNumber(request.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getRegisterNumber());
        customerInfo.setMtnFlow(request.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getMtnFlow());
        customerInfo.setGlobalId(request.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getGlobalId());
        
        if(Objects.nonNull(redisData) && CollectionUtilities.isNotEmptyOrNull(redisData.getLines())) {
        	customerInfo.setProcessingMTN(redisData.getLines().get(0).getMtn());
		}
        return customerInfo;
    }

    private CartServiceContextInfo getContextInfo(RemoveLinesPEGARequest request,
                                                  PrepaidODRequestData redisData) {
        CartServiceContextInfo serviceContextInfo = new CartServiceContextInfo();
        serviceContextInfo.setCallReason(request.getServiceBody().getServiceRequest().getContext().getContextInfo().getCallReason());
        serviceContextInfo.setIntent(request.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
        serviceContextInfo.setProcessAction("");
        boolean notCheckoutFlag = false;
        if(Objects.nonNull(redisData) && Objects.nonNull(redisData.getLines()) && Objects.nonNull(request) && Objects.nonNull(request.getServiceBody())
        		&& Objects.nonNull(request.getServiceBody().getServiceRequest()) && Objects.nonNull(request.getServiceBody().getServiceRequest().getContext())
        		&& Objects.nonNull(request.getServiceBody().getServiceRequest().getContext().getCartInfo()) 
        		&& Objects.nonNull(request.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines())) {
        	List<PrepaidODRequestDataLines> notCheckoutLines = redisData.getLines().stream().filter(line->!line.isCheckoutFlag()).collect(Collectors.toList());
        	
	        notCheckoutFlag = CollectionUtilities.isNotEmptyOrNull(notCheckoutLines);
	        
        }
        AvailablePaths availablepath = new AvailablePaths();
        List<AvailablePaths> availablePaths = new ArrayList<>();
        
        
        if("true".equalsIgnoreCase(accountOwner) && Objects.nonNull(redisData) && CollectionUtilities.isNotEmptyOrNull(redisData.getLines()) && redisData.getLines().size() > 2 ) {
            if(notCheckoutFlag) {
                serviceContextInfo.setProcessStep(PrepayAdaptorCartConstants.PROMO_HUB);
                availablepath.setPath(PrepayAdaptorCartConstants.PROMO_HUB);
            } else {
                serviceContextInfo.setProcessStep(PrepayAdaptorCartConstants.ACCOUNT_OWNER_PROCESS_STEP);
                availablepath.setPath(PrepayAdaptorCartConstants.ACCOUNT_OWNER_PROCESS_STEP);
            }
        } else if(!notCheckoutFlag) {
        	serviceContextInfo.setProcessStep(PrepayAdaptorCartConstants.CHECKOUT_PLAN_PROCESS_STEP);
        	availablepath.setPath(PrepayAdaptorCartConstants.CHECKOUT_PLAN_PROCESS_STEP);
        } else {
        	serviceContextInfo.setProcessStep(PrepayAdaptorCartConstants.PROMO_HUB);
        	availablepath.setPath(PrepayAdaptorCartConstants.PROMO_HUB);
        }
        availablePaths.add(availablepath);
        serviceContextInfo.setAvailablePaths(availablePaths);
        return serviceContextInfo;
    }

    private PrepaidAdaptorWebClientRequest getPrepaidLegacyServiceRequest(String lineItemId, PrepaidODRequestData prepaidODRequestData, String flow) {
        //prepare play request body
        RemoveLineItemsRequest removeLineItemsRequest = new RemoveLineItemsRequest();
        removeLineItemsRequest.setLineItemId(lineItemId);
        //prepare web client Request
        PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
        prepaidAdaptorWebClientRequest.setUrl(removeLinesPrepaidLegacyServiceUrl);
        prepaidAdaptorWebClientRequest.setRequestBody(removeLineItemsRequest);
        prepaidAdaptorWebClientRequest.setRequestType(HttpMethod.POST.toString());
        prepaidAdaptorWebClientRequest.setHeader(PrepayAdaptorCartUtil.getPrepayODServiceCommonHeaders(prepaidODRequestData,flow));
        return prepaidAdaptorWebClientRequest;
    }
}
