package onevz.soe.prepay.adaptor.cart.model.cart.vo;

import java.io.Serializable;

public class PaypalLookupResponse implements Serializable{

	private static final long serialVersionUID = 1L;
	private String orderId;
	private String acsUrl;
	private String paypalOrderId;
	private String transactionId;
	private String payload;
	private String statusCode;
	private String message;
	
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getAcsUrl() {
		return acsUrl;
	}
	public void setAcsUrl(String acsUrl) {
		this.acsUrl = acsUrl;
	}
	public String getPaypalOrderId() {
		return paypalOrderId;
	}
	public void setPaypalOrderId(String paypalOrderId) {
		this.paypalOrderId = paypalOrderId;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getPayload() {
		return payload;
	}
	public void setPayload(String payload) {
		this.payload = payload;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
}