package onevz.soe.prepay.adaptor.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.requests.UpdateBarCodePEGARequest;
import onevz.soe.cart.responses.UpdateBarCodePEGAResponse;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants;
import onevz.soe.prepay.adaptor.cart.model.cart.vo.UpdateBarcodePrepayOdRequest;
import onevz.soe.prepay.adaptor.cart.model.cart.vo.UpdateBarcodePrepayOdResponse;
import onevz.soe.prepay.adaptor.cart.util.PrepayAdaptorCartUtil;
import onevz.soe.prepay.adaptor.cart.util.PrepayUpdateBarcodeFormatterUtil;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import onevz.soe.wsclient.prepay.webclient.model.PrepaidAdaptorWebClientRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_DATA;

import java.util.Objects;

@Service
public class PrepayAdaptorUpdateBarcodeHelper {

    private static final Logger logger = LoggerFactory.getLogger(PrepayAdaptorUpdateBarcodeHelper.class);

    @Autowired
    private ObjectMapper mapper;

    @Value("${updateBarcodePrepaidLegacyServiceUrl}")
    private String updateBarcodePrepaidLegacyServiceUrl;

    @Autowired
    private PrepayAdaptorWebClient prepayAdaptorWebClient;

    @Autowired
    private PrepayCartRedisHelper updateBarcodeRedisHelper;


    public Mono<ResponseEntity<UpdateBarCodePEGAResponse>> updateBarcode(ServerHttpRequest httpRequest, UpdateBarCodePEGARequest request) {
        UpdateBarcodePrepayOdRequest updateBarcodePrepayOdRequest = PrepayUpdateBarcodeFormatterUtil.formatUpdateBarcodeRequest(request);
        return updateBarcodeRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)
                .flatMap(response -> {
                    if (StringUtilities.isNotEmptyOrNull(response)) {
                        logger.info("Redis Data From Redis: {} " , response);
                        PrepaidODRequestData redisData = null;
                        try {
                            redisData = mapper.readValue(response, PrepaidODRequestData.class);
                        } catch (JsonProcessingException e) {
                            logger.error("Failed to get data from redis:", e);
                        }
                        PrepaidAdaptorWebClientRequest prepaidLegacyServiceRequest = getPrepaidLegacyServiceRequest(updateBarcodePrepayOdRequest, redisData);
                        return updateBarcode(httpRequest, prepaidLegacyServiceRequest);
                    } else {
                        UpdateBarCodePEGAResponse updateBarCodePEGAResponse = new UpdateBarCodePEGAResponse();
                        return Mono.just(ResponseEntity.status(HttpStatus.OK).body(updateBarCodePEGAResponse));
                    }
                });
    }

    private Mono<ResponseEntity<UpdateBarCodePEGAResponse>> updateBarcode(ServerHttpRequest httpRequest, PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest) {
        return prepayAdaptorWebClient.getPrepayServiceResponse(httpRequest, prepaidAdaptorWebClientRequest)
                .doOnError(error -> logger.error("Failed to get response", error))
                .flatMap(responseEntity -> {
                    UpdateBarCodePEGAResponse updateBarCodePEGAResponse = new UpdateBarCodePEGAResponse();
                    UpdateBarcodePrepayOdResponse restResponse = new UpdateBarcodePrepayOdResponse();
                    try {
                        if (!responseEntity.getStatusCode().is2xxSuccessful()) {
                            logger.info("Play response status code: {}", responseEntity.getStatusCode());
                            logger.error("Error while calling endpoint: {} with status code: {}",
                                    prepaidAdaptorWebClientRequest.getUrl(), responseEntity.getStatusCode());
                        } else {
                            String responseString = responseEntity.getBody();
                            restResponse = mapper.readValue(responseString, UpdateBarcodePrepayOdResponse.class);
                            if (null != restResponse) {
                                updateBarCodePEGAResponse = PrepayUpdateBarcodeFormatterUtil.formatUpdateBarcodeResponse(restResponse);
                            } else {
                                logger.info("No Response returned");
                            }
                           logger.info("Response from play: {}", responseEntity.getBody());
                            return Mono.just(ResponseEntity.status(responseEntity.getStatusCode()).body(updateBarCodePEGAResponse));
                        }
                    } catch (JsonMappingException e) {
                        logger.info("Exception : {}", e.getMessage());
                    } catch (JsonProcessingException e) {
                        logger.info("Exception : {}", e.getMessage());
                    }
                    return Mono.just(ResponseEntity.status(responseEntity.getStatusCode()).body(updateBarCodePEGAResponse));
                });
    }

    private PrepaidAdaptorWebClientRequest getPrepaidLegacyServiceRequest(UpdateBarcodePrepayOdRequest request, PrepaidODRequestData prepaidODRequestData) {
        PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
        prepaidAdaptorWebClientRequest.setUrl(updateBarcodePrepaidLegacyServiceUrl);
        prepaidAdaptorWebClientRequest.setRequestBody(request);
        prepaidAdaptorWebClientRequest.setRequestType("POST");
        String flow = Objects.nonNull(prepaidODRequestData) && CollectionUtilities.isNotEmptyOrNull(prepaidODRequestData.getLines())?prepaidODRequestData.getLines().get(prepaidODRequestData.getCurr_line()-1).getFlow():PrepayAdaptorCartConstants.NSE;
        prepaidAdaptorWebClientRequest.setHeader(PrepayAdaptorCartUtil.getPrepayODServiceCommonHeaders(prepaidODRequestData,flow));
        return prepaidAdaptorWebClientRequest;
    }




}
