package onevz.soe.prepay.adaptor.cart.model.cart.vo;


import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class UpdateBarcodePrepayOdResponse {

    /** The status code. */
    private String statusCode;

    /** The output. */
    private ApplyPromoCodeRespVo output;

    private PrepayCartVO cartVO ;

    public Map<String, String> getErrorMap() {
        return errorMap;
    }

    public void setErrorMap(Map<String, String> errorMap) {
        this.errorMap = errorMap;
    }

    private Map<String, String> errorMap;

    private String statusMessage;

    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public ApplyPromoCodeRespVo getOutput() {
        return output;
    }

    public void setOutput(ApplyPromoCodeRespVo output) {
        this.output = output;
    }

    public PrepayCartVO getCartVO() {
        return cartVO;
    }

    public void setCartVO(PrepayCartVO cartVO) {
        this.cartVO = cartVO;
    }
}
