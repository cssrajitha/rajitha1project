package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;

public class DeviceCondition implements Serializable{

    private String display_name;
    private String description;
    private String watch_overview_link;

    public String getDisplay_name() {
        return display_name;
    }

    public void setDisplay_name(String display_name) {
        this.display_name = display_name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    public String getWatch_overview_link() {
        return watch_overview_link;
    }

    public void setWatch_overview_link(String watch_overview_link) {
        this.watch_overview_link = watch_overview_link;
    }

}