package onevz.soe.prepay.adaptor.cart.model.cxp.common;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ETNIError400Response {
	private String errorCode;
	private String errorMsg;
}

