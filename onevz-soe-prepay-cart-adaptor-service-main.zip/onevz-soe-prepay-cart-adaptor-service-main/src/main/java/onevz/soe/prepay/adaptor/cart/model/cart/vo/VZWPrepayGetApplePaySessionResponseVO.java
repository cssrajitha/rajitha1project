package onevz.soe.prepay.adaptor.cart.model.cart.vo;


public class VZWPrepayGetApplePaySessionResponseVO {
	private VZWPrepayGetApplePaySessionServiceBodyVO svcBdy;

	public VZWPrepayGetApplePaySessionServiceBodyVO getSvcBdy() {
		return svcBdy;
	}

	public void setSvcBdy(VZWPrepayGetApplePaySessionServiceBodyVO svcBdy) {
		this.svcBdy = svcBdy;
	}
}
