package onevz.soe.prepay.adaptor.cart.model.vo;

public class Masterpass extends CreditCard {

    private String walletId;

    private String walletType;

    private String walletTxnId;

    private String emailAddress;

    public String getWalletId() {
        return walletId;
    }

    public void setWalletId(String walletId) {
        this.walletId = walletId;
    }

    public String getWalletType() {
        return walletType;
    }

    public void setWalletType(String walletType) {
        this.walletType = walletType;
    }

    public String getWalletTxnId() {
        return walletTxnId;
    }

    public void setWalletTxnId(String walletTxnId) {
        this.walletTxnId = walletTxnId;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }
}
