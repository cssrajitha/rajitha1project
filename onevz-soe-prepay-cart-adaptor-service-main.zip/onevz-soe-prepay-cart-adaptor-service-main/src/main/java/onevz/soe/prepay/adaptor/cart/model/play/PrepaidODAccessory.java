package onevz.soe.prepay.adaptor.cart.model.play;


import lombok.Data;

@Data
public class PrepaidODAccessory {
    private String flow;
    private String accQty="1";
    private String accProdId;
    private String accSkuId;
    private String accSorId;
    private String devCommerceId;
    private String accCategory;
    private String action;
    private boolean accessoryBundle;
    private String commerceItemId;
}
