package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;

public class BuyOutDetails implements Serializable{

    private static final long serialVersionUID = 1L;

    private String orignalInstallmentLoanNumber;
    private String orignalLoanDeviceId;
    private double buyOutAmt;

    public String getOrignalLoanDeviceId() {
        return orignalLoanDeviceId;
    }

    public void setOrignalLoanDeviceId(String orignalLoanDeviceId) {
        this.orignalLoanDeviceId = orignalLoanDeviceId;
    }

    public double getBuyOutAmt() {
        return buyOutAmt;
    }

    public void setBuyOutAmt(double buyOutAmt) {
        this.buyOutAmt = buyOutAmt;
    }

    public String getOrignalInstallmentLoanNumber() {
        return orignalInstallmentLoanNumber;
    }

    public void setOrignalInstallmentLoanNumber(String orignalInstallmentLoanNumber) {
        this.orignalInstallmentLoanNumber = orignalInstallmentLoanNumber;
    }
}
