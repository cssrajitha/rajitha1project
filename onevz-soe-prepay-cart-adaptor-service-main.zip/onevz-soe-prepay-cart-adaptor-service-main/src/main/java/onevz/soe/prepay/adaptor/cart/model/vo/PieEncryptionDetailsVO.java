package onevz.soe.prepay.adaptor.cart.model.vo;


public class PieEncryptionDetailsVO {
    private String keyId;
    private String phaseId;

    public String getKeyId() {
        return keyId;
    }

    public void setKeyId(String keyId) {
        this.keyId = keyId;
    }

    public String getPhaseId() {
        return phaseId;
    }

    public void setPhaseId(String phaseId) {
        this.phaseId = phaseId;
    }



}
