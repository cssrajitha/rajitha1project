package onevz.soe.prepay.adaptor.cart.controller;

import onevz.soe.prepay.adaptor.cart.exceptions.JsonValidator;
import onevz.soe.prepay.adaptor.cart.helper.PrepayAdaptorAssignMTNHelper;
import onevz.soe.prepay.adaptor.cart.model.cxp.request.RetreiveNpanXXRequestModel;
import onevz.soe.prepay.adaptor.cart.model.cxp.response.RetrieveNpaNxxResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import jakarta.validation.Valid;


/**
 * AssignMtn Controller class.
 */
//NSADT-53978 removing CrossOrigin annotation in every service.
//@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping(value = "prepaid-adaptor")
public class PrepayAdaptorAssignMTNUpdateOperationsController {

	private static final Logger logger = LoggerFactory.getLogger(PrepayAdaptorAssignMTNUpdateOperationsController.class);

	@Autowired
	JsonValidator validator;

	@Autowired
	private PrepayAdaptorAssignMTNHelper retreiveNpanxxsHelper;

	/**
	 *
	 * @param binder
	 */
	@InitBinder("*")
	public void initBinderByName(WebDataBinder binder) {
		binder.setDisallowedFields(new String[] { "genericHeader" });
	}

	/**
	 *
	 * @param httpRequest
	 * @param retrieveNpanXXRequest
	 * @return ResponseEntity
	 *
	 */
	@GetMapping(value = "/assignmtn/retreive-npanxx")
	public Mono<ResponseEntity<RetrieveNpaNxxResponse>> retrieveNpanxx(ServerHttpRequest httpRequest, @Valid RetreiveNpanXXRequestModel retrieveNpanXXRequest) {
		logger.debug("request for npanxx is: {}",retrieveNpanXXRequest);
		System.setProperty("endPoint", "retrieve-npanxx");
		return retreiveNpanxxsHelper.retrieveNPANXX(httpRequest, retrieveNpanXXRequest);
	}

}
