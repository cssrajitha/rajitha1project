package onevz.soe.prepay.adaptor.cart.model.cart;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class OfferDetailsContent {
    private String OD_PREPAID_CART_OFFER_BANNER_HEADING_TEXT;

    private String OD_PREPAID_JETPACK_TABLET_BANNER_SUB_HEADING_TEXT;

    private String OD_PREPAID_BANNER_SUB_HEADING_TEXT;

    private String OD_PREPAID_CART_OFFER_BANNER_SUB_HEADING_TEXT;

    private String OD_PREPAID_VARIANT_BANNER_HEADING;

    private String OD_PREPAID_CART_OFFER_BANNER_LINK_TEXT;

    private String OD_PREPAID_OFFER_DETAILS_POPUP_HEADING_TEXT;

    private String OD_PREPAID_OFFER_DETAILS_POPUP_CONTENT;

    private String OD_PREPAID_OFFER_DETAILS_POPUP_CTA_TEXT;

    private String OD_PREPAID_BANNER_HEADING_TEXT;
}