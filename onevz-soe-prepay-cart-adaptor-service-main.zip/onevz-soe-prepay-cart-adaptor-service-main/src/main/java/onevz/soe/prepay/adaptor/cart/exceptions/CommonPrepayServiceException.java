package onevz.soe.prepay.adaptor.cart.exceptions;


import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

/**
 * 
 * @author PANDSI9
 *
 */
public class CommonPrepayServiceException extends ResponseStatusException{

	/**
	 * 
	 * @param status
	 * @param message
	 */
	public CommonPrepayServiceException(HttpStatus status,String message) {
		super(status, message);
	}


}
