package onevz.soe.prepay.adaptor.cart.model.play;

//import com.vzw.order.vo.PaymentGroup;
//import com.vzw.order.vo.ShippingGroup;
//import com.vzw.prepay.account.AccountInfoVO;
//import com.vzw.prepay.cart.vo.*;
//import com.vzw.prepay.vo.order.VZWPrepaySavedCreditCardVO;

import io.swagger.v3.oas.annotations.media.Schema;
import onevz.soe.prepay.adaptor.cart.model.cart.vo.*;
import onevz.soe.prepay.adaptor.cart.model.vo.PaymentGroup;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * Represents a customer with product information.
 * This class serves as a data contract for product details,
 * including their unique identifier and name.
 */
@Schema(description = "This class serves as a data contract for product details")
public class VZWPrepayOrderVO implements Serializable {
    private static final long serialVersionUID = 1L;
    private String orderId;
    private String skuId;
    private String sorId;
    private String productId;
    private double orderTotal;
    private double orderTax;
    private double orderDiscount;
    private double todaySavings;
    private double monthlySavings;
    private String orderZipcode;
    private double dueMonthly;
    private double dueToday;
    private double shippingPrice;
    private String flow;
    private double totalActivationfee;
    private String sessionId;
    private List<PrepayAccessoryVO> accessoryList;
    private List<PrepayDeviceVO> deviceList;
    private List<PrepayPlanVO> planList;
    private List<PrepayFeatureVO> featureList;
    private List<PrepayTaxVO> taxDetailList;
    private AccountInfoVO accountInfo;
    private AccountInfoVO billingAddress;
    private int linesCount;
    private int cartCount;
    private String paymentMethod;
    private String paypalInfo;
    private String shippingMethod;
    private String shippingOptionId;
    private String estimatedDeliveryDate;
    private String orderNumber;
    private List<String> refillCards;
    private boolean pieEnabled;
    private double planSavings;
    private double  autopaySavings;
    private boolean autoPayEnabled;
    private boolean saveCreditCard;
    private boolean autoPayAccount;
    private double amountCredit;
    private boolean shippingRequired;
    private boolean btstEnabled;
    private String purchasePath;
    private VZWPrepayPaymentVO refillCardDetails;
    private boolean threeDSecured;
    private List<VZWPrepayPromotion> promotions;
    private boolean binProcessEventEnabled ;
    private Integer binProcessEventMaxTimeout;
    private boolean deviceFingerPrintEnabled;

    private Map<String, Object> digitalPaymentOptions;

    private List<PaymentGroup> paymentGroup;

    private double planDueMonthly;

    private String trialStatus;

    private boolean enableFamilyPricing;

    public boolean isEnableFamilyPricing() {
        return enableFamilyPricing;
    }

    public void setEnableFamilyPricing(boolean enableFamilyPricing) {
        this.enableFamilyPricing = enableFamilyPricing;
    }

    public VZWPrepayOrderVO() {
    }

    public boolean isMot() {
        return mot;
    }

    public void setMot(boolean mot) {
        this.mot = mot;
    }

    private boolean mot;

    private boolean fiveGToFourGTransition;
    private double accumulateInlineDiscount;
    private String inlinePromotionMessage;

    private boolean holidayPolicyEnable;
    private double totalDevicesDiscount;
    private double totalAccessoriesDiscount;
    private boolean enableIphoneSEPromo;

    @Schema(description = "this field hold device promotion ID")
    private String devicePromotionId;

    public boolean isEnableIphoneSEPromo() {
        return enableIphoneSEPromo;
    }

    public void setEnableIphoneSEPromo(boolean enableIphoneSEPromo) {
        this.enableIphoneSEPromo = enableIphoneSEPromo;
    }
    
    public boolean isHolidayPolicyEnable() {
        return holidayPolicyEnable;
    }

    public void setHolidayPolicyEnable(boolean holidayPolicyEnable) {
        this.holidayPolicyEnable = holidayPolicyEnable;
    }

    public double getAccumulateInlineDiscount() {
        return accumulateInlineDiscount;
    }

    public void setAccumulateInlineDiscount(double accumulateInlineDiscount) {
        this.accumulateInlineDiscount = accumulateInlineDiscount;
    }

    public String getInlinePromotionMessage() {
        return inlinePromotionMessage;
    }

    public void setInlinePromotionMessage(String inlinePromotionMessage) {
        this.inlinePromotionMessage = inlinePromotionMessage;
    }

    public boolean isFiveGToFourGTransition() {
        return fiveGToFourGTransition;
    }

    public void setFiveGToFourGTransition(boolean fiveGToFourGTransition) {
        this.fiveGToFourGTransition = fiveGToFourGTransition;
    }

    public String getTrialStatus() {
        return trialStatus;
    }

    public void setTrialStatus(String trialStatus) {
        this.trialStatus = trialStatus;
    }

    public List<PaymentGroup> getPaymentGroup() {
        return paymentGroup;
    }

    public void setPaymentGroup(List<PaymentGroup> paymentGroup) {
        this.paymentGroup = paymentGroup;
    }

    public String getShippingOptionId() {
        return shippingOptionId;
    }

    public void setShippingOptionId(String shippingOptionId) {
        this.shippingOptionId = shippingOptionId;
    }

    public Map<String, Object> getDigitalPaymentOptions() {
        return digitalPaymentOptions;
    }

    public void setDigitalPaymentOptions(Map<String, Object> digitalPaymentOptions) {
        this.digitalPaymentOptions = digitalPaymentOptions;
    }

    public boolean isThreeDSecured() {
        return threeDSecured;
    }

    public void setThreeDSecured(boolean threeDSecured) {
        this.threeDSecured = threeDSecured;
    }


    public VZWPrepayPaymentVO getRefillCardDetails() {
        return refillCardDetails;
    }

    public void setRefillCardDetails(VZWPrepayPaymentVO refillCardDetails) {
        this.refillCardDetails = refillCardDetails;
    }

    public String getPurchasePath() {
        return purchasePath;
    }

    public void setPurchasePath(String purchasePath) {
        this.purchasePath = purchasePath;
    }

    public boolean isShippingRequired() {
        return shippingRequired;
    }

    public void setShippingRequired(boolean shippingRequired) {
        this.shippingRequired = shippingRequired;
    }

    public List<String> getRefillCards() {
        return refillCards;
    }

    public void setRefillCards(List<String> refillCards) {
        this.refillCards = refillCards;
    }

    public double getAmountCredit() {
        return amountCredit;
    }

    public void setAmountCredit(double amountCredit) {
        this.amountCredit = amountCredit;
    }

    public boolean isAutoPayAccount() {
        return autoPayAccount;
    }

    public void setAutoPayAccount(boolean autoPayAccount) {
        this.autoPayAccount = autoPayAccount;
    }

    private VZWPrepaySavedCreditCardDetailsVO customerSavedCreditCard;

    public boolean isAutoPayEnabled() {
        return autoPayEnabled;
    }

    public void setAutoPayEnabled(boolean autoPayEnabled) {
        this.autoPayEnabled = autoPayEnabled;
    }

    public boolean isSaveCreditCard() {
        return saveCreditCard;
    }

    public void setSaveCreditCard(boolean saveCreditCard) {
        this.saveCreditCard = saveCreditCard;
    }

    public VZWPrepaySavedCreditCardDetailsVO getCustomerSavedCreditCard() {
        return customerSavedCreditCard;
    }

    public void setCustomerSavedCreditCard(VZWPrepaySavedCreditCardDetailsVO customerSavedCreditCard) {
        this.customerSavedCreditCard = customerSavedCreditCard;
    }

    private double autoPayTotalAmount;
    private Double expressStoreGiftCardRemainingSpendAmount;
    private boolean showGiftCardAmountExceedFlag;
    private Integer giftCardMaxAmount;

    public Integer getGiftCardMaxAmount() {
        return giftCardMaxAmount;
    }

    public void setGiftCardMaxAmount(Integer giftCardMaxAmount) {
        this.giftCardMaxAmount = giftCardMaxAmount;
    }


    public Double getExpressStoreGiftCardRemainingSpendAmount() {
        return expressStoreGiftCardRemainingSpendAmount;
    }

    public void setExpressStoreGiftCardRemainingSpendAmount(Double expressStoreGiftCardRemainingSpendAmount) {
        this.expressStoreGiftCardRemainingSpendAmount = expressStoreGiftCardRemainingSpendAmount;
    }

    public boolean isShowGiftCardAmountExceedFlag() {
        return showGiftCardAmountExceedFlag;
    }

    public void setShowGiftCardAmountExceedFlag(boolean showGiftCardAmountExceedFlag) {
        this.showGiftCardAmountExceedFlag = showGiftCardAmountExceedFlag;
    }

    public boolean isPieEnabled() {
        return pieEnabled;
    }

    public void setPieEnabled(boolean pieEnabled) {
        this.pieEnabled = pieEnabled;
    }

    public double getTodaySavings() {
        return todaySavings;
    }

    public void setTodaySavings(double todaySavings) {
        this.todaySavings = todaySavings;
    }

    public double getMonthlySavings() {
        return monthlySavings;
    }

    public void setMonthlySavings(double monthlySavings) {
        this.monthlySavings = monthlySavings;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public double getOrderTotal() {
        return orderTotal;
    }

    public void setOrderTotal(double orderTotal) {
        this.orderTotal = orderTotal;
    }

    public double getOrderTax() {
        return orderTax;
    }

    public void setOrderTax(double orderTax) {
        this.orderTax = orderTax;
    }

    public double getOrderDiscount() {
        return orderDiscount;
    }

    public void setOrderDiscount(double orderDiscount) {
        this.orderDiscount = orderDiscount;
    }

    public String getOrderZipcode() {
        return orderZipcode;
    }

    public void setOrderZipcode(String orderZipcode) {
        this.orderZipcode = orderZipcode;
    }

    public double getDueMonthly() {
        return dueMonthly;
    }

    public void setDueMonthly(double dueMonthly) {
        this.dueMonthly = dueMonthly;
    }

    public double getDueToday() {
        return dueToday;
    }

    public void setDueToday(double dueToday) {
        this.dueToday = dueToday;
    }

    public String getFlow() {
        return flow;
    }

    public void setFlow(String flow) {
        this.flow = flow;
    }

    public double getTotalActivationfee() {
        return totalActivationfee;
    }

    public void setTotalActivationfee(double totalActivationfee) {
        this.totalActivationfee = totalActivationfee;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public List<PrepayAccessoryVO> getAccessoryList() {
        return accessoryList;
    }

    public void setAccessoryList(List<PrepayAccessoryVO> accessoryList) {
        this.accessoryList = accessoryList;
    }

    public List<PrepayDeviceVO> getDeviceList() {
        return deviceList;
    }

    public void setDeviceList(List<PrepayDeviceVO> deviceList) {
        this.deviceList = deviceList;
    }

    public List<PrepayPlanVO> getPlanList() {
        return planList;
    }

    public void setPlanList(List<PrepayPlanVO> planList) {
        this.planList = planList;
    }

    public List<PrepayFeatureVO> getFeatureList() {
        return featureList;
    }

    public void setFeatureList(List<PrepayFeatureVO> featureList) {
        this.featureList = featureList;
    }

    public List<PrepayTaxVO> getTaxDetailList() {
        return taxDetailList;
    }

    public void setTaxDetailList(List<PrepayTaxVO> taxDetailList) {
        this.taxDetailList = taxDetailList;
    }

    public AccountInfoVO getAccountInfo() {
        return accountInfo;
    }

    public void setAccountInfo(AccountInfoVO accountInfo) {
        this.accountInfo = accountInfo;
    }

    public int getLinesCount() {
        return linesCount;
    }

    public void setLinesCount(int linesCount) {
        this.linesCount = linesCount;
    }

    public int getCartCount() {
        return cartCount;
    }

    public void setCartCount(int cartCount) {
        this.cartCount = cartCount;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getShippingMethod() {
        return shippingMethod;
    }

    public void setShippingMethod(String shippingMethod) {
        this.shippingMethod = shippingMethod;
    }

    public String getNextDueDate() {
        return nextDueDate;
    }

    public void setNextDueDate(String nextDueDate) {
        this.nextDueDate = nextDueDate;
    }

    private String nextDueDate;

    public double getDueNextCycle() {
        return dueNextCycle;
    }

    public void setDueNextCycle(double dueNextCycle) {
        this.dueNextCycle = dueNextCycle;
    }

    private double dueNextCycle;

    private String jwtToken;

    public String getEstimatedDeliveryDate() {
        return estimatedDeliveryDate;
    }

    public void setEstimatedDeliveryDate(String estimatedDeliveryDate) {
        this.estimatedDeliveryDate = estimatedDeliveryDate;
    }

    public double getShippingPrice() {
        return shippingPrice;
    }

    public void setShippingPrice(double shippingPrice) {
        this.shippingPrice = shippingPrice;
    }

    public double getAutoPayTotalAmount() {
        return autoPayTotalAmount;
    }

    public void setAutoPayTotalAmount(double autoPayTotalAmount) {
        this.autoPayTotalAmount = autoPayTotalAmount;
    }

    public void setBillingAddress(AccountInfoVO billingAddress) {
        this.billingAddress = billingAddress;
    }

    public AccountInfoVO getBillingAddress() {
        return billingAddress;
    }

    public boolean isBtstEnabled() {
        return btstEnabled;
    }

    public void setBtstEnabled(boolean btstEnabled) {
        this.btstEnabled = btstEnabled;
    }

    public double getPlanSavings() {
        return planSavings;
    }

    public void setPlanSavings(double planSavings) {
        this.planSavings = planSavings;
    }

    public double getAutopaySavings() {
        return autopaySavings;
    }

    public void setAutopaySavings(double autopaySavings) {
        this.autopaySavings = autopaySavings;
    }

    public List<VZWPrepayPromotion> getPromotions() {
        return promotions;
    }

    public void setPromotions(List<VZWPrepayPromotion> promotions) {
        this.promotions = promotions;
    }

    public boolean isBinProcessEventEnabled() {
        return binProcessEventEnabled;
    }

    public void setBinProcessEventEnabled(boolean binProcessEventEnabled) {
        this.binProcessEventEnabled = binProcessEventEnabled;
    }

    public Integer getBinProcessEventMaxTimeout() {
        return binProcessEventMaxTimeout;
    }

    public void setBinProcessEventMaxTimeout(Integer binProcessEventMaxTimeout) {
        this.binProcessEventMaxTimeout = binProcessEventMaxTimeout;
    }

    public String getJwtToken() {
        return jwtToken;
    }

    public void setJwtToken(String jwtToken) {
        this.jwtToken = jwtToken;
    }

    public boolean isDeviceFingerPrintEnabled() {
        return deviceFingerPrintEnabled;
    }

    public void setDeviceFingerPrintEnabled(boolean deviceFingerPrintEnabled) {
        this.deviceFingerPrintEnabled = deviceFingerPrintEnabled;
    }

    public String getPaypalInfo() {
        return paypalInfo;
    }

    public void setPaypalInfo(String paypalInfo) {
        this.paypalInfo = paypalInfo;
    }

    public double getPlanDueMonthly() {
        return planDueMonthly;
    }

    public void setPlanDueMonthly(double planDueMonthly) {
        this.planDueMonthly = planDueMonthly;
    }

    private Map<String,Object> applePayInfo;

    public Map<String, Object> getApplePayInfo() {
        return applePayInfo;
    }

    public void setApplePayInfo(Map<String, Object> applePayInfo) {
        this.applePayInfo = applePayInfo;
    }


    public String getSkuId() {
        return skuId;
    }

    public void setSkuId(String skuId) {
        this.skuId = skuId;
    }

    public String getSorId() {
        return sorId;
    }

    public void setSorId(String sorId) {
        this.sorId = sorId;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public double getTotalDevicesDiscount() {
        return totalDevicesDiscount;
    }

    public void setTotalDevicesDiscount(double totalDevicesDiscount) {
        this.totalDevicesDiscount = totalDevicesDiscount;
    }

    public double getTotalAccessoriesDiscount() {
        return totalAccessoriesDiscount;
    }

    public void setTotalAccessoriesDiscount(double totalAccessoriesDiscount) {
        this.totalAccessoriesDiscount = totalAccessoriesDiscount;
    }

    public String getDevicePromotionId() {
        return devicePromotionId;
    }

    public void setDevicePromotionId(String devicePromotionId) {
        this.devicePromotionId = devicePromotionId;
    }
}

