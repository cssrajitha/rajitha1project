package onevz.soe.prepay.adaptor.cart.model.play.shippingoptions;

import java.util.List;
import java.util.Map;

public class ShippingOptionsResponse {


	private List<ShippingOption> shippingOptions;
	private List<ShippingOption> vendorShippingOptions;
	private boolean preOrderOrBackOrderDeviceExits;
	
	private boolean poboFlag;
	
	private boolean isOrderEligibleForShipping;
	private boolean inStorePickUpEligible;
	private String preOrderBackOrderStatus;
	private String orderId;
	private String groupCategory;
	private Map<String, String> sddErrorCodes;

	public Map<String, String> getSddErrorCodes() {
		return sddErrorCodes;
	}

	public void setSddErrorCodes(Map<String, String> sddErrorCodes) {
		this.sddErrorCodes = sddErrorCodes;
	}

	public boolean isShipToMeEligible() {
		return isShipToMeEligible;
	}

	public void setShipToMeEligible(boolean shipToMeEligible) {
		isShipToMeEligible = shipToMeEligible;
	}

	private boolean isShipToMeEligible;

	public boolean isRedirectToCart() {
		return redirectToCart;
	}

	public void setRedirectToCart(boolean redirectToCart) {
		this.redirectToCart = redirectToCart;
	}

	private boolean redirectToCart;

	public String getIspuOverridedMessage() {
		return ispuOverridedMessage;
	}

	public void setIspuOverridedMessage(String ispuOverridedMessage) {
		this.ispuOverridedMessage = ispuOverridedMessage;
	}

	private String ispuOverridedMessage;

	public boolean isISPUOverrided() {
		return isISPUOverrided;
	}

	public void setISPUOverrided(boolean ISPUOverrided) {
		isISPUOverrided = ISPUOverrided;
	}

	private boolean isISPUOverrided;
	public boolean isInStorePickUpEligible() {
		return inStorePickUpEligible;
	}

	public void setInStorePickUpEligible(boolean inStorePickUpEligible) {
		this.inStorePickUpEligible = inStorePickUpEligible;
	}

	/**
	 * @return the isOrderEligibleForShipping
	 */
	public boolean isOrderEligibleForShipping() {
		return isOrderEligibleForShipping;
	}
	/**
	 * @param isOrderEligibleForShipping the isOrderEligibleForShipping to set
	 */
	public void setOrderEligibleForShipping(boolean isOrderEligibleForShipping) {
		this.isOrderEligibleForShipping = isOrderEligibleForShipping;
	}
	/**
	 * @return the shippingOptions
	 */
	public List<ShippingOption> getShippingOptions() {
		return shippingOptions;
	}
	/**
	 * @param shippingOptions the shippingOptions to set
	 */
	public void setShippingOptions(List<ShippingOption> shippingOptions) {
		this.shippingOptions = shippingOptions;
	}
	/**
	 * @return the preOrderOrBackOrderDeviceExits
	 */
	public boolean isPreOrderOrBackOrderDeviceExits() {
		return preOrderOrBackOrderDeviceExits;
	}
	/**
	 * @param preOrderOrBackOrderDeviceExits the preOrderOrBackOrderDeviceExits to set
	 */
	public void setPreOrderOrBackOrderDeviceExits(boolean preOrderOrBackOrderDeviceExits) {
		this.preOrderOrBackOrderDeviceExits = preOrderOrBackOrderDeviceExits;
	}
	/**
	 * @return the preOrderBackOrderStatus
	 */
	public String getPreOrderBackOrderStatus() {
		return preOrderBackOrderStatus;
	}
	/**
	 * @param preOrderBackOrderStatus the preOrderBackOrderStatus to set
	 */
	public void setPreOrderBackOrderStatus(String preOrderBackOrderStatus) {
		this.preOrderBackOrderStatus = preOrderBackOrderStatus;
	}
	/**
	 * @return the poboFlag
	 */
	public boolean isPoboFlag() {
		return poboFlag;
	}
	/**
	 * @param poboFlag the poboFlag to set
	 */
	public void setPoboFlag(boolean poboFlag) {
		this.poboFlag = poboFlag;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public List<ShippingOption> getVendorShippingOptions() {
		return vendorShippingOptions;
	}

	public void setVendorShippingOptions(List<ShippingOption> vendorShippingOptions) {
		this.vendorShippingOptions = vendorShippingOptions;
	}
	public String getGroupCategory() {
		return groupCategory;
	}

	public void setGroupCategory(String groupCategory) {
		this.groupCategory = groupCategory;
	}


}
