package onevz.soe.prepay.adaptor.cart.model.cart;

import lombok.*;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class CQContent {
    private static final long serialVersionUID = -6096280577046242346L;

    private Error error;
    private Label label;
    private Html html;

}
