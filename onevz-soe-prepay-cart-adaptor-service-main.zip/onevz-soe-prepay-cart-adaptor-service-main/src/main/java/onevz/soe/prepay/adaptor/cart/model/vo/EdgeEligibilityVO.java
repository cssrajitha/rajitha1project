package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;


public class EdgeEligibilityVO implements Serializable{
    private static final long serialVersionUID = 1L;
    private String eligibilityIndicator;
    private double profileRemainingSpendingLimitAmount;
    private double remainingLineSpendingLimitAmount;
    private double requiredDownPaymentPercentage;
    private double maxDownPaymentPerDirectChannel;
    private double maxDownPaymentPerInDirectChannel;
    private String maxDownPaymentPercentDirectChannel;
    private double profileSpendingLimitAmount;
    private double lineSpendingLimitAmount;
    private String riskProfileIdLetterThreshold;
    private String riskProfileId;
    private String customerTenureCode;
    private String creditClassCode;
    private String deviceLimitUseCode;
    public double getProfileSpendingLimitAmount() {
        return profileSpendingLimitAmount;
    }

    public void setProfileSpendingLimitAmount(double profileSpendingLimitAmount) {
        this.profileSpendingLimitAmount = profileSpendingLimitAmount;
    }

    private int numberOfPayments;

    public String getMaxDownPaymentPercentDirectChannel() {
        return maxDownPaymentPercentDirectChannel;
    }

    public void setMaxDownPaymentPercentDirectChannel(
            final String maxDownPaymentPercentDirectChannel) {
        this.maxDownPaymentPercentDirectChannel = maxDownPaymentPercentDirectChannel;
    }

    public double getMaxDownPaymentPertDirectChannel() {
        return maxDownPaymentPerDirectChannel;
    }

    public void setMaxDownPaymentPerDirectChannel(
            double maxDownPaymentPerDirectChannel) {
        this.maxDownPaymentPerDirectChannel = maxDownPaymentPerDirectChannel;
    }

    public double getMaxDownPaymentPerInDirectChannel() {
        return maxDownPaymentPerInDirectChannel;
    }

    public void setMaxDownPaymentPerInDirectChannel(
            double maxDownPaymentPerInDirectChannel) {
        this.maxDownPaymentPerInDirectChannel = maxDownPaymentPerInDirectChannel;
    }

    public String getEligibilityIndicator() {
        return eligibilityIndicator;
    }

    public void setEligibilityIndicator(String eligibilityIndicator) {
        this.eligibilityIndicator = eligibilityIndicator;
    }

    public double getProfileRemainingSpendingLimitAmount() {
        return profileRemainingSpendingLimitAmount;
    }

    public void setProfileRemainingSpendingLimitAmount(
            double profileRemainingSpendingLimitAmount) {
        this.profileRemainingSpendingLimitAmount = profileRemainingSpendingLimitAmount;
    }

    public double getRequiredDownPaymentPercentage() {
        return requiredDownPaymentPercentage;
    }

    public void setRequiredDownPaymentPercentage(double requiredDownPaymentPercentage) {
        this.requiredDownPaymentPercentage = requiredDownPaymentPercentage;
    }

    public int getNumberOfPayments() {
        return numberOfPayments;
    }

    public void setNumberOfPayments(int numberOfPayments) {
        this.numberOfPayments = numberOfPayments;
    }

    public String getRiskProfileIdLetterThreshold() {
        return riskProfileIdLetterThreshold;
    }

    public void setRiskProfileIdLetterThreshold(
            String riskProfileIdLetterThreshold) {
        this.riskProfileIdLetterThreshold = riskProfileIdLetterThreshold;
    }

    public String getRiskProfileId() {
        return riskProfileId;
    }

    public void setRiskProfileId(String riskProfileId) {
        this.riskProfileId = riskProfileId;
    }

    public String getCustomerTenureCode() {
        return customerTenureCode;
    }

    public void setCustomerTenureCode(String customerTenureCode) {
        this.customerTenureCode = customerTenureCode;
    }

    public String getCreditClassCode() {
        return creditClassCode;
    }

    public void setCreditClassCode(String creditClassCode) {
        this.creditClassCode = creditClassCode;
    }

    public double getLineSpendingLimitAmount() {
        return lineSpendingLimitAmount;
    }

    public void setLineSpendingLimitAmount(double lineSpendingLimitAmount) {
        this.lineSpendingLimitAmount = lineSpendingLimitAmount;
    }

    public double getRemainingLineSpendingLimitAmount() {
        return remainingLineSpendingLimitAmount;
    }

    public void setRemainingLineSpendingLimitAmount(double remainingLineSpendingLimitAmount) {
        this.remainingLineSpendingLimitAmount = remainingLineSpendingLimitAmount;
    }

    public String getDeviceLimitUseCode() {
        return deviceLimitUseCode;
    }

    public void setDeviceLimitUseCode(String deviceLimitUseCode) {
        this.deviceLimitUseCode = deviceLimitUseCode;
    }
}
