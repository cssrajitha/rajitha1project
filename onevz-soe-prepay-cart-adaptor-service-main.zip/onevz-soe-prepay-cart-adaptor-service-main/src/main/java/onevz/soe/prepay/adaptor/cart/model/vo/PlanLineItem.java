package onevz.soe.prepay.adaptor.cart.model.vo;


import java.util.Date;
import java.util.List;

/**
 *
 */
public class PlanLineItem extends OrderLineItem  {

   	private static final long serialVersionUID = 1L;
	private String planLevel;
	private Date lastModifiedDate;
	private boolean sharedPlan;
	private String planSize;
	private String dataAllowance;
	private int voiceAllowance;
	private boolean cpcDone;
	private String description;
	private String sorComponentType;

	private String planCategory;
	private String sorCategoryCode;
	private String sorCollectionCode;
	private String planPricingType;
	private boolean autopayEligible;
	private double autopayDiscount;
	private boolean phonePlan;
	private List<ActivationFee> activationFees;
	private String sorDataUnitOfMeasure;
	private String smartFamilyJustKidsParentSFO;
	private boolean tabletPlanDiscounted;
	private String discountEligiblePhonePlanId;
	private boolean phonePlanDiscounted;
	private double tabletDiscPercent;

	public boolean isBoltOnIndicator() {
		return boltOnIndicator;
	}

	public void setBoltOnIndicator(boolean boltOnIndicator) {
		this.boltOnIndicator = boltOnIndicator;
	}

	private boolean boltOnIndicator;


	public String getSorCollectionCode() {
		return sorCollectionCode;
	}

	public void setSorCollectionCode(String sorCollectionCode) {
		this.sorCollectionCode = sorCollectionCode;
	}

	public String getSorCategoryCode() {
		return sorCategoryCode;
	}

	public void setSorCategoryCode(String sorCategoryCode) {
		this.sorCategoryCode = sorCategoryCode;
	}

	public String getPlanCategory() {
        return planCategory;
    }

    public void setPlanCategory(String planCategory) {
        this.planCategory = planCategory;
    }

    public String getPlanLevel() {
		return planLevel;
	}

	public void setPlanLevel(String planLevel) {
		this.planLevel = planLevel;
	}
		
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PlanLevel:" + getPlanLevel());
		return builder.toString();
	}
    
	@Override
	public boolean equals(Object plan) {
		if (!(plan instanceof PlanLineItem)) {
			return false;
		}
		return this.getId().equals(((PlanLineItem)plan).getId());
	}
	
	@Override
	public int hashCode() {
		return this.getId().hashCode();
	}

	public boolean isSharedPlan() {
		return sharedPlan;
	}

	public void setSharedPlan(boolean sharedPlan) {
		this.sharedPlan = sharedPlan;
	}

	public boolean isCpcDone() {
		return cpcDone;
	}

	public void setCpcDone(boolean cpcDone) {
		this.cpcDone = cpcDone;
	}

	public String getPlanSize() {
		return planSize;
	}

	public void setPlanSize(String planSize) {
		this.planSize = planSize;
	}

	public String getDataAllowance() {
		return dataAllowance;
	}

	public void setDataAllowance(String dataAllowance) {
		this.dataAllowance = dataAllowance;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSorComponentType() {
		return sorComponentType;
	}

	public void setSorComponentType(String sorComponentType) {
		this.sorComponentType = sorComponentType;
	}

	public String getPlanPricingType() {
		return planPricingType;
	}

	public void setPlanPricingType(String planPricingType) {
		this.planPricingType = planPricingType;
	}

	public boolean isAutopayEligible() {
		return autopayEligible;
	}

	public void setAutopayEligible(boolean autopayEligible) {
		this.autopayEligible = autopayEligible;
	}

	public double getAutopayDiscount() {
		return autopayDiscount;
	}

	public void setAutopayDiscount(double autopayDiscount) {
		this.autopayDiscount = autopayDiscount;
	}



	private String planDeviceType;
	private String planDeviceCategory;

	public String getPlanDeviceType() {
		return planDeviceType;
	}

	public void setPlanDeviceType(String planDeviceType) {
		this.planDeviceType = planDeviceType;
	}

	public String getPlanDeviceCategory() {
		return planDeviceCategory;
	}

	public void setPlanDeviceCategory(String planDeviceCategory) {
		this.planDeviceCategory = planDeviceCategory;
	}

	public boolean isPhonePlan() {
		return phonePlan;
	}

	public void setPhonePlan(boolean phonePlan) {
		this.phonePlan = phonePlan;
	}

	public int getVoiceAllowance() {
		return voiceAllowance;
	}

	public void setVoiceAllowance(int voiceAllowance) {
		this.voiceAllowance = voiceAllowance;
	}

	public List<ActivationFee> getActivationFees() {
		return activationFees;
	}

	public void setActivationFees(List<ActivationFee> activationFees) {
		this.activationFees = activationFees;
	}

	public String getSorDataUnitOfMeasure() {
		return sorDataUnitOfMeasure;
	}

	public void setSorDataUnitOfMeasure(String sorDataUnitOfMeasure) {
		this.sorDataUnitOfMeasure = sorDataUnitOfMeasure;
	}

	public String getSmartFamilyJustKidsParentSFO() {
		return smartFamilyJustKidsParentSFO;
	}

	public void setSmartFamilyJustKidsParentSFO(String smartFamilyJustKidsParentSFO) {
		this.smartFamilyJustKidsParentSFO = smartFamilyJustKidsParentSFO;
	}

	public boolean isTabletPlanDiscounted() {
		return tabletPlanDiscounted;
	}

	public void setTabletPlanDiscounted(boolean tabletPlanDiscounted) {
		this.tabletPlanDiscounted = tabletPlanDiscounted;
	}

	public String getDiscountEligiblePhonePlanId() {
		return discountEligiblePhonePlanId;
	}

	public void setDiscountEligiblePhonePlanId(String discountEligiblePhonePlanId) {
		this.discountEligiblePhonePlanId = discountEligiblePhonePlanId;
	}

	public boolean isPhonePlanDiscounted() {
		return phonePlanDiscounted;
	}

	public void setPhonePlanDiscounted(boolean phonePlanDiscounted) {
		this.phonePlanDiscounted = phonePlanDiscounted;
	}

	public double getTabletDiscPercent() {
		return tabletDiscPercent;
	}

	public void setTabletDiscPercent(double tabletDiscPercent) {
		this.tabletDiscPercent = tabletDiscPercent;
	}
}
