package onevz.soe.prepay.adaptor.cart.model.cxp.shipping;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import onevz.soe.prepay.adaptor.cart.model.cxp.common.MetaTag;

/**
 * Holds data of zipcode, meta information for
 * retrieve market details by zipcode service.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RetrieveZipcodeMktDetailsRequest {
	private MetaTag meta;
	private RetrieveZipcodeMktDetailsRequestData data;
}
