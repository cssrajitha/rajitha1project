package onevz.soe.prepay.adaptor.cart.model.bpm;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import onevz.soe.wsclient.bpm.model.ServiceBody;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper=true)
public class AddDeviceToPrepayODServiceBody extends ServiceBody {

	@JsonInclude(Include.NON_NULL)
	@JsonProperty(value = "serviceRequest")
	private AddDeviceToPrepayODServiceRequest serviceRequest;
	
	@JsonInclude(Include.NON_NULL)
	@JsonProperty(value = "serviceResponse")
	private AddDeviceToPrepayODServiceResponse serviceResponse;
	
}
