package onevz.soe.prepay.adaptor.cart.model.updateContactInfo;

import lombok.*;
import onevz.soe.wsclient.bpm.model.request.ServiceRequest;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper = true)
public class ContactInfoServiceRequest extends ServiceRequest {
    private ContactInfoContext context;
}
