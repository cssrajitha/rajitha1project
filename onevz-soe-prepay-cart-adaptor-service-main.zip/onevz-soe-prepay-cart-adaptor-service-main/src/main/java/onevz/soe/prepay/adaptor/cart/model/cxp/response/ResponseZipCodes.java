package onevz.soe.prepay.adaptor.cart.model.cxp.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import onevz.soe.prepay.adaptor.cart.model.play.Errors;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ResponseZipCodes{
    int status;
    String statusCode;
    PayLoad payload;
    private Errors errors;
}

