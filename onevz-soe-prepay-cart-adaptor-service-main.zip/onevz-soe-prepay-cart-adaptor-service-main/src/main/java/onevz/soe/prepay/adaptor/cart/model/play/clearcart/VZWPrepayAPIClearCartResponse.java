package onevz.soe.prepay.adaptor.cart.model.play.clearcart;

import lombok.Data;

@Data
public class VZWPrepayAPIClearCartResponse {
    private String status;
    private VZWPrepayAPIClearCartPayload payload;
}
