package onevz.soe.prepay.adaptor.cart.model.cxp.shipping;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import onevz.soe.prepay.adaptor.cart.model.common.Errors;
import onevz.soe.prepay.adaptor.cart.model.cxp.common.MetaTag;

import java.util.List;
import java.util.Map;

/**
 * class RetrieveZipcodeMktDetailsResponse having data information.
 *
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RetrieveZipcodeMktDetailsResponse {
	private MetaTag meta;
	private RetrieveZipcodeMktDetailsResponseData data;
	private Map<String,String> warnings;
	private List<Errors> errors;
}
