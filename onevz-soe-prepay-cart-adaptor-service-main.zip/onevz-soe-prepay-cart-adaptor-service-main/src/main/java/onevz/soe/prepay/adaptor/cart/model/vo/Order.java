package onevz.soe.prepay.adaptor.cart.model.vo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;
import java.util.*;
import java.util.stream.Collectors;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Order implements Serializable {

	private static final long serialVersionUID = 7817574045193107226L;

	private String nseRecycleReferenceOrderNumber;
	private List<DeviceLineItem> deviceList = new ArrayList<>();
	private List<PlanLineItem> planList = new ArrayList<>();
	private List<FeatureLineItem> featureList = new ArrayList<>();
	private List<AccessoryLineItem> accessoryList = new ArrayList<>();
	private List<SoftSku5GLineItem> softSkuList = new ArrayList<>();
	private List<YttvSubscriptionLineItem> yttvSubscriptionList = new ArrayList<>();
	private String id;
	private Date lastModifiedDate;
	private String siteID;
	private String userID;
	private String originatingSystem;
	private String channelID;
	private String locationCode;
	private Date submittedDate;
	private String status;
	private Double orderAmount;
	private Double orderTax;
	private double totalPriceForTax;
	private Double orderDiscount;
	private Double securityDepositAmount;
	private String serviceZip;
	private String outletID;
	private Date accountEstablishedDate;
	private String creditServiceClass;
	private String lineCreditClass;
	private String creditApprovalStatus;
	private String creditStatusReason;
	private String creditStatusReasonMsg;
	private String paperFreeBillingIndicator;
	private String autoPayIndicator;
	private AutoPayInfo autoPayInfo;
	private String isSpecialUpgrade;
	private String intlEligibilityCheck;
	private String flow;
	private String internationalEligibilityCheck;
	private Boolean isTotalAccountProtection;
	private Double subTotalDueMonthly;
	private Double subTotalDueToday;
	private Boolean includeAccessoryForTax = true;
	private String savedCartEmailId;
	private List<String> promoCodeIds = new ArrayList<>();
	private List<VZWPromotion> promotions = new ArrayList<>();
	//Use suborder clientReferenceNumber instead
	private String clientReferenceNumber;
	private int version;
	private Boolean delete;
	private Double totalEdgeUpAmount;
	private String customerType;
	private Double totalActivationFees;
	private Double mailInRebateTotal;
	private ContactInfo contactInfo;
	private ContactInfo billingAddress;
	private String creditOptionSelected;
	private Boolean liveSedCalled;
	private String lastAddedPromoCode;
	private Double totalDownpayment;
	private String vztAccountNo;
	private List<PaymentGroup> paymentGroup;
	private String taxState;
	private String taxCity;
	private String accountPin;
	private Double lineAccessCharges;
	private Boolean instantDRCCredit;
	private Double instantCreditRemaining;
	private String socialSecurityNumber;
	private String dateOfBirth;
	private List<SubOrder> subOrders = new ArrayList<>();
	private boolean creditReadValidated;
	private List<ShippingGroup> shippingGroups;
	private String programEligibilityIndicator="N";
	private String eligibilityIndicator;
	private Double downpaymentPercent;
	private Double rawDownPaymentPercent;
	private Double remainingSpendingLimit;
	// Added for Submit Order
	private OrderWriteServiceInfo orderWriteServiceInfo;
	private String billingSystem;
	private Boolean taxCalculated;
	private String sddDeliveryDate;
	private String clusterInfo;
	private String vendorId;
	private String lastAddedDeviceLineItemId;
	private Boolean includePlanAndFeatureTaxInDueMonthly;
	private String cartType;
	private Date saveCartDate;
	private Double totalSecurityDepositAmount;
	private Double pastDueBalance;
	private Double totalEdgeBuyOutAmount;
	private Double employeeDiscount;
	private Double saveCartPrice;
	HashMap<String, String> productCorrelationIdMap;
	private SoftCreditInfo softCreditInfo;
	private String clientId;
	private Double totalUpgradeFee;
	private Map<String, String> specialInstructions;
	private String errorMessage;
	private boolean syncToDb;
	private String playSessionId;
	private String creditApplicationNumber;
	private String posOrderNumber;
	private EdgeEligibilityVO edgeEligibilityVO;
	private double downPaymentAmount;
	private String marketId;
	private Set<String> barcodeIds;
	private boolean discountCodeApplied;
	private boolean tradeInSelected;
	private TradeInInfo tradeInInfo;
	private boolean tradeInEmailSentAlready;
	//private List<ServiceChangedLineVo> serviceChangedLines;
	private double fnfDiscountPrice;
	private String fnfPromoCode;
	private double teacherOrNurseDiscount;
	private String teacherOrNurseOfferType;
	private VZWTermsAndConditionAgreementVO termsAndConditionAgreement;
	private boolean byodMVAOrder;
	private String dispositionOptionId;
	private String vzccAquisitionIndicator;
	private boolean issacPreQualifiedAndCardApproved;
	private boolean issacDirectApplyAndCardApproved;
	private String retrieveActivationCode;
	private String retrieveActivationErrorMsg;
	private String activatedESimMDN;
	private boolean esimEligibleIMEI;
	private boolean mhFlow;
	private String vztAccountNum;
	private double mhPromoAmt;

	private String mhCrosssSellSPOId;
	public String getMhCrosssSellSPOId() {
		return mhCrosssSellSPOId;
	}
	public void setMhCrosssSellSPOId(String mhCrosssSellSPOId) {
		this.mhCrosssSellSPOId = mhCrosssSellSPOId;
	}

	public boolean getMhFlow() {
		return mhFlow;
	}

	public void setMhFlow(boolean mhFlow) {
		this.mhFlow = mhFlow;
	}

	public String getVztAccountNum() {
		return vztAccountNum;
	}

	public void setVztAccountNum(String vztAccountNum) {
		this.vztAccountNum = vztAccountNum;
	}

	public double getMhPromoAmt() {
		return mhPromoAmt;
	}

	public void setMhPromoAmt(double mhPromoAmt) {
		this.mhPromoAmt = mhPromoAmt;
	}

	public String getRetrieveActivationCode() {
		return retrieveActivationCode;
	}

	public void setRetrieveActivationCode(String retrieveActivationCode) {
		this.retrieveActivationCode = retrieveActivationCode;
	}

	public String getRetrieveActivationErrorMsg() {
		return retrieveActivationErrorMsg;
	}

	public void setRetrieveActivationErrorMsg(String retrieveActivationErrorMsg) {
		this.retrieveActivationErrorMsg = retrieveActivationErrorMsg;
	}

	public boolean isByodMWEBOrder() {
		return byodMWEBOrder;
	}

	public void setByodMWEBOrder(boolean byodMWEBOrder) {
		this.byodMWEBOrder = byodMWEBOrder;
	}

	private boolean byodMWEBOrder;

	private boolean byodMVADesktop;

	public boolean isByodMVADesktop() {
		return byodMVADesktop;
	}

	public void setByodMVADesktop(boolean byodMVADesktop) {
		this.byodMVADesktop = byodMVADesktop;
	}

	public String getSelfInstallSetupDate() {
		return selfInstallSetupDate;
	}

	public void setSelfInstallSetupDate(String selfInstallSetupDate) {
		this.selfInstallSetupDate = selfInstallSetupDate;
	}

	private String selfInstallSetupDate;
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}

	//private List<PlanChangeImpactedLineVo> planChangeImpactedLines;
	//private VZWOrderKeyInfo orderKeyInfo;
	private int noOfcreditReadAttempts;
	private int noOfcreditReadAttemptsForPR;
	private int noOfSoftCreditReadAttemptsForPR;
	private int totalNoOfcreditReadAttemptsForPR;
	private int totalNoOfSoftCreditReadAttemptsForPR;
	private String switchContractAndCreditDepositRequired;

	private String accessoryCheckoutRedirectURL;

	private String confirmationNumber;
	private boolean creditConsent;
	private String installationType;
	private List<PromoBadgeMessage> globalPromoBadgeMessages;
	private double orderBalanceAmount;
	private String launchType;
	//private SharedCartHeader originalSCHeader;
	private String expPOBOCartHeading;
	private String expPOBOConfirmationHeading;
	private boolean soiFlag;
	private boolean soiShowAccountPlan;
	private String source;
	private String wirelessOrder;
	private String wirelineOrder;
	private String subOrderClientType;
	private String subOrderType;
	private String wirelineAccountNumber;
	private String wirelineAccountSubNumber;
	private String wirelessStatusDesc;
	private String wirelineStatusDesc;
	private String comboOrderId;
	private Double expressStoreGiftCardRemainingSpendAmount;
	private boolean expressStoreD2DOrder;
	private String d2dSource;
	private String EcpdUniqueId;
	private String EcpdVendorCode;
	private boolean mvaPlansFirstFlow;
	private String originalCreditApplicationNumber;

	public Double getExpressStoreGiftCardRemainingSpendAmount() {
		return expressStoreGiftCardRemainingSpendAmount;
	}

	public void setExpressStoreGiftCardRemainingSpendAmount(Double expressStoreGiftCardRemainingSpendAmount) {
		this.expressStoreGiftCardRemainingSpendAmount = expressStoreGiftCardRemainingSpendAmount;
	}

    private Map<String, String> sddNonEligibleReasonMap;

    public Map<String, String> getSddNonEligibleReasonMap() {
        return sddNonEligibleReasonMap;
    }

    public void setSddNonEligibleReasonMap(Map<String, String> sddNonEligibleReasonMap) {
        this.sddNonEligibleReasonMap = sddNonEligibleReasonMap;
    }

	public String getComboOrderId() {
		return comboOrderId;
	}

	public void setComboOrderId(String comboOrderId) {
		this.comboOrderId = comboOrderId;
	}

	private String agentId;
	private String agentOutletId;
	private String theBuyersRightToCancel;

	public String getTheBuyersRightToCancel() {
		return theBuyersRightToCancel;
	}

	public void setTheBuyersRightToCancel(String theBuyersRightToCancel) {
		this.theBuyersRightToCancel = theBuyersRightToCancel;
	}

	public String getAgentId() {
		return agentId;
	}

	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}

	public String getAgentOutletId() {
		return agentOutletId;
	}

	public void setAgentOutletId(String agentOutletId) {
		this.agentOutletId = agentOutletId;
	}

	public String getSubOrderClientType() {
		return subOrderClientType;
	}

	public void setSubOrderClientType(String subOrderClientType) {
		this.subOrderClientType = subOrderClientType;
	}

	public String getSubOrderType() {
		return subOrderType;
	}

	public void setSubOrderType(String subOrderType) {
		this.subOrderType = subOrderType;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}
	private String addOnOrderId;

	public String getAddOnOrderId() {
		if (StringUtils.isNotBlank(this.getId())){
			return new StringBuilder("ADDON-").append(this.getId()).toString();
		}
		return addOnOrderId;
	}
	public String getLaunchType() {
		return launchType;
	}

	public void setLaunchType(String launchType) {
		this.launchType = launchType;
	}

	public List<PromoBadgeMessage> getGlobalPromoBadgeMessages() {
		return globalPromoBadgeMessages;
	}

	public void setGlobalPromoBadgeMessages(List<PromoBadgeMessage> globalPromoBadgeMessages) {
		this.globalPromoBadgeMessages = globalPromoBadgeMessages;
	}

	public String getInstallationType() {
		return installationType;
	}

	public void setInstallationType(String installtionType) {
		this.installationType = installtionType;
	}

	public boolean isIWVOrder() {
		return isIWVOrder;
	}

	public void setIWVOrder(boolean IWVOrder) {
		isIWVOrder = IWVOrder;
	}

	public String getiWVDevicesAemURL() {
		return iWVDevicesAemURL;
	}

	public void setiWVDevicesAemURL(String iWVDevicesAemURL) {
		this.iWVDevicesAemURL = iWVDevicesAemURL;
	}

	public String getiWVByodURL() {
		return iWVByodURL;
	}

	public void setiWVByodURL(String iWVByodURL) {
		this.iWVByodURL = iWVByodURL;
	}

	public boolean isIWVDisplayRequired() {
		return isIWVDisplayRequired;
	}

	public void setIWVDisplayRequired(boolean IWVDisplayRequired) {
		isIWVDisplayRequired = IWVDisplayRequired;
	}

	private boolean isIWVOrder;
	private String iWVDevicesAemURL;
	private String iWVByodURL;
	private boolean isIWVDisplayRequired;

	private boolean creditCheckCompleted;

	private int noExamAvailApiCount;

	//private RecycleDeviceSessionBean recycleDevicesDetail;


	public boolean isCreditConsent() {
		return creditConsent;
	}

	public void setCreditConsent(boolean creditConsent) {
		this.creditConsent = creditConsent;
	}

	public String getAccessoryCheckoutRedirectURL() {
		return accessoryCheckoutRedirectURL;
	}

	public void setAccessoryCheckoutRedirectURL(String accessoryCheckoutRedirectURL) {
		this.accessoryCheckoutRedirectURL = accessoryCheckoutRedirectURL;
	}

	private String addOrderConfirmationNumber;
	//later we need to remove
	private String ssn;
	private String transactionId;
	private boolean optedForNewsletter;
	/** The revised dp. */
	private String revisedDP;
	private InstallationWindow installationWindow;
	private String fixedWirelessPromo;
	private EnforceData enforceData;
	private String installationFloor;

	public EnforceData getEnforceData() {
		return enforceData;
	}
    public void setEnforceData(EnforceData enforceData) {
		this.enforceData = enforceData;
	}

	public String getNseRecycleReferenceOrderNumber() {
		return nseRecycleReferenceOrderNumber;
	}

	public void setNseRecycleReferenceOrderNumber(String nseRecycleReferenceOrderNumber) {
		this.nseRecycleReferenceOrderNumber = nseRecycleReferenceOrderNumber;
	}
//this flag is used only in desktop

	private boolean isPortingDone;

	public boolean isPortingDone() {
		return isPortingDone;
	}

	public void setPortingDone(boolean portingDone) {
		isPortingDone = portingDone;
	}

	private String salesChannel;
	private String origin;

	private boolean isCustomerTNCAccepted;
	private boolean isTradeInTNCAccepted;
	private String serverHostIP;
	private List<VZWProspectCustomBundleVO> customBundles;


	public String getServerHostIP() {
		return serverHostIP;
	}

	public void setServerHostIP(String serverHostIP) {
		this.serverHostIP = serverHostIP;
	}



	public boolean isCustomerTNCAccepted()
		{
			return isCustomerTNCAccepted;
		}

	public void setCustomerTNCAccepted(boolean customerTNCAccepted)
		{
			isCustomerTNCAccepted = customerTNCAccepted;
		}

	public boolean isTradeInTNCAccepted()
		{
			return isTradeInTNCAccepted;
		}

	public void setTradeInTNCAccepted(boolean tradeInTNCAccepted)
		{
			isTradeInTNCAccepted = tradeInTNCAccepted;
		}
	private HashMap<String,String> telesalesProps = new HashMap<>();


	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getSalesChannel() {
		return salesChannel;
	}

	public void setSalesChannel(String salesChannel) {
		this.salesChannel = salesChannel;
	}
	public boolean isOptedForNewsletter() {
		return optedForNewsletter;
	}

	public void setOptedForNewsletter(boolean optedForNewsletter) {
		this.optedForNewsletter = optedForNewsletter;
	}
	
	
	public HashMap<String, String> getTelesalesProps() {
		return telesalesProps;
	}

	public void setTelesalesProps(HashMap<String, String> telesalesProps) {
		this.telesalesProps = telesalesProps;
	}

	private String customerAgreementText;
	private String correlationId;
	private String originatingIpAddress;
	private String blanketApprovalNumber;
	private int noOfEidServiceAttempts;
	private boolean eidServiceCalled;
	private String customerIDType;
	private  String customerIDNumber;
	private  String ispuState;
	private String visionCustomerType;
	private String ssnPieKeyId;
	private String ssnPhaseId;
    private String  ssnEncryptionType;
	private boolean sharedCartChanged;
	private boolean sharedCartSubmitted;
	private Long createdTimeInMillis;
	private String mylink;
	private ContactInfo userSelectedAddress;
	private Boolean isSuggestedAddress;
	private String browserAgent;
	private String modToken;
	private boolean isOrderModified;
	private boolean isCreditCheckDone;
	private String orderWriteResponseCode;

	public String getOrderWriteResponseCode() {
		return orderWriteResponseCode;
	}

	public void setOrderWriteResponseCode(String orderWriteResponseCode) {
		this.orderWriteResponseCode = orderWriteResponseCode;
	}

	public boolean isOrderModified() {
		return isOrderModified;
	}
	public void setOrderModified(boolean orderModified) {
		isOrderModified = orderModified;
	}

	public boolean isCreditCheckDone() {
		return isCreditCheckDone;
	}
	public void setCreditCheckDone(boolean creditCheckDone) {
		isCreditCheckDone = creditCheckDone;
	}

	public String getOneWayHashSsn() {
		return oneWayHashSsn;
	}

	public void setOneWayHashSsn(String oneWayHashSsn) {
		this.oneWayHashSsn = oneWayHashSsn;
	}

	private String oneWayHashSsn;

	private boolean acsUrlPresent3DSecure;
	private boolean lookupFailed3DSecure;
	private boolean benefitEligibility3DSecure;
	private boolean cardinalSetupDone3DSecure;
	private boolean popupDisplayed3DSecure;

	private String softCreditOrderPrelaunchIndicator;
	private String softCreditResult;

	public boolean isBlockGiftCard() {
		return blockGiftCard;
	}

	public void setBlockGiftCard(boolean blockGiftCard) {
		this.blockGiftCard = blockGiftCard;
	}

	private boolean blockGiftCard;

	public String getModToken() {
		return modToken;
	}

	public void setModToken(String modToken) {
		this.modToken = modToken;
	}
	public ContactInfo getUserSelectedAddress() {
		return userSelectedAddress;
	}

	public void setUserSelectedAddress(ContactInfo userSelectedAddress) {
		this.userSelectedAddress = userSelectedAddress;
	}

	public Boolean getSuggestedAddress() {
		return isSuggestedAddress;
	}

	public void setSuggestedAddress(Boolean suggestedAddress) {
		isSuggestedAddress = suggestedAddress;
	}
	public String getMylink() {
		return mylink;
	}

	public void setMylink(String mylink) {
		this.mylink = mylink;
	}

	public boolean isSharedCartChanged() {
		return sharedCartChanged;
	}

	public void setSharedCartChanged(boolean sharedCartChanged) {
		this.sharedCartChanged = sharedCartChanged;
	}

	public boolean isSharedCartSubmitted() {
		return sharedCartSubmitted;
	}

	public void setSharedCartSubmitted(boolean sharedCartSubmitted) {
		this.sharedCartSubmitted = sharedCartSubmitted;
	}

	public Double getRawDownPaymentPercent() {

		if(rawDownPaymentPercent != null){
			return rawDownPaymentPercent;
		}else{
			return 0.00D;
		}
	}

	public void setRawDownPaymentPercent(Double rawDownPaymentPercent) {
		this.rawDownPaymentPercent = rawDownPaymentPercent;
	}	public String getTransactionId() {
		return transactionId;
	}

	public String getAutoPayIndicator() {
		return autoPayIndicator;
	}

	public void setAutoPayIndicator(String autoPayIndicator) {
		this.autoPayIndicator = autoPayIndicator;
	}

	public AutoPayInfo getAutoPayInfo() {
		return autoPayInfo;
	}

	public void setAutoPayInfo(AutoPayInfo autoPayInfo) {
		this.autoPayInfo = autoPayInfo;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public void setRevisedDP(String revisedDP) {
		this.revisedDP = revisedDP;
	}

	public String getRevisedDP() {
		return revisedDP;
	}

	public boolean isComboOrder() {
		return comboOrder;
	}

	public void setComboOrder(boolean comboOrder) {
		this.comboOrder = comboOrder;
	}

	private boolean comboOrder;

	public String getVztAccountNo() {
		return vztAccountNo;
	}

	public void setVztAccountNo(String vztAccountNo) {
		this.vztAccountNo = vztAccountNo;
	}

	public String getEligibilityIndicator() {
		return eligibilityIndicator;
	}

	public void setEligibilityIndicator(String eligibilityIndicator) {
		this.eligibilityIndicator = eligibilityIndicator;
	}

	public String getPostPaidOrderType() {
		return postPaidOrderType;
	}

	public void setPostPaidOrderType(String postPaidOrderType) {
		this.postPaidOrderType = postPaidOrderType;
	}
	private String edgeDownPaymentAndCreditDepositRequired;
	public String getEdgeDownPaymentAndCreditDepositRequired() {
		return edgeDownPaymentAndCreditDepositRequired;
	}

	public void setEdgeDownPaymentAndCreditDepositRequired(String edgeDownPaymentAndCreditDepositRequired) {
		this.edgeDownPaymentAndCreditDepositRequired = edgeDownPaymentAndCreditDepositRequired;
	}


	private String postPaidOrderType;

	/**
	 * @return the syncToDb
	 */
	public boolean isSyncToDb() {
		return syncToDb;
	}

	/**
	 * @param syncToDb the syncToDb to set
	 */
	public void setSyncToDb(boolean syncToDb) {
		this.syncToDb = syncToDb;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(int version) {
		this.version = version;
	}

	//from upper funnel the barcodes offers should be persisted in order to calculate the discount in lower funnel after live SED call
	Map<String, List<SkuBarcodeVO>> barCodeOffers;
	private Double totalBarCodeDiscount;

	/**
	 * this flag will be set to true if an item is added to the cart
	 * or the quantity of the item is changed. This flag will be used
	 * to determine whether pricing has to be done
	 */
	private Boolean changed;
	private Object programElgInfo;
	/**
	 * Gets the program elg info.
	 *
	 * @return the program elg info
	 */
	public Object getProgramElgInfo() {
		return programElgInfo;
	}

	/**
	 * Sets the program elg info.
	 *
	 * @param programElgInfo the new program elg info
	 */
	public void setProgramElgInfo(Object programElgInfo) {
		this.programElgInfo = programElgInfo;
		if (programElgInfo == null) {
			setProgramEligibilityIndicator(null);
		}
	}
	public boolean isTradeInSelected() { return tradeInSelected; }

	public void setTradeInSelected(boolean tradeInSelected) {
		this.tradeInSelected = tradeInSelected;
	}

	public TradeInInfo getTradeInInfo() {
		if(null == tradeInInfo){
		this.tradeInInfo = new TradeInInfo();
	   }
	   return tradeInInfo;
	}
	public void setTradeInInfo(TradeInInfo tradeInInfo) {	this.tradeInInfo = tradeInInfo;	}

	public boolean isTradeInEmailSentAlready() {
		return tradeInEmailSentAlready;
	}
	public void setTradeInEmailSentAlready(boolean tradeInEmailSentAlready) { this.tradeInEmailSentAlready = tradeInEmailSentAlready; }

	public String getSiteID() {
		return siteID;
	}

	public void setSiteID(String siteID) {
		this.siteID = siteID;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getOriginatingSystem() {
		return originatingSystem;
	}

	public void setOriginatingSystem(String originatingSystem) {
		this.originatingSystem = originatingSystem;
	}

	public String getChannelID() {
		return channelID;
	}

	public void setChannelID(String channelID) {
		this.channelID = channelID;
	}

	public String getLocationCode() {
		return locationCode;
	}

	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}

	public Date getSubmittedDate() {
		return submittedDate;
	}

	public void setSubmittedDate(Date submittedDate) {
		this.submittedDate = submittedDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Double getOrderAmount() {
		if(orderAmount != null){
			return orderAmount;
		}else{
			return 0.0D;
		}
	}

	public void setOrderAmount(Double orderAmount) {
		this.orderAmount = orderAmount;
	}

	public Double getOrderTax() {
		if(orderTax != null){
			return orderTax;
		}else{
			return 0.0D;
		}

	}

	public void setOrderTax(Double orderTax) {
		this.orderTax = orderTax;
	}

	public double getTotalPriceForTax() {
		return totalPriceForTax;
	}

	public void setTotalPriceForTax(double totalPriceForTax) {
		this.totalPriceForTax = totalPriceForTax;
	}

	public Double getOrderDiscount() {
		if(orderDiscount != null){
			return orderDiscount;
		}else{
			return 0.0D;
		}
	}

	public void setOrderDiscount(Double orderDiscount) {
		this.orderDiscount = orderDiscount;
	}

	public Double getSecurityDepositAmount() {
		if(securityDepositAmount != null){
			return securityDepositAmount;
		}else{
			return 0.0D;
		}
	}

	public void setSecurityDepositAmount(Double securityDepositAmount) {
		this.securityDepositAmount = securityDepositAmount;
	}

	public String getServiceZip() {
		return serviceZip;
	}

	public void setServiceZip(String serviceZip) {
		this.serviceZip = serviceZip;
	}

	public String getOutletID() {
		return outletID;
	}

	public void setOutletID(String outletID) {
		this.outletID = outletID;
	}

	public Date getAccountEstablishedDate() {
		return accountEstablishedDate;
	}

	public void setAccountEstablishedDate(Date accountEstablishedDate) {
		this.accountEstablishedDate = accountEstablishedDate;
	}

	public String getCreditServiceClass() {
		return creditServiceClass;
	}

	public void setCreditServiceClass(String creditServiceClass) {
		this.creditServiceClass = creditServiceClass;
	}


	public String getCreditStatusReason() {
		return creditStatusReason;
	}

	public void setCreditStatusReason(String creditStatusReason) {
		this.creditStatusReason = creditStatusReason;
	}

	public List<DeviceLineItem> getDeviceList() {
		return deviceList;
	}

	public void setDeviceList(List<DeviceLineItem> deviceList) {
		this.deviceList = deviceList;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public Boolean isTotalAccountProtection() {
		return isTotalAccountProtection;
	}

	public void setTotalAccountProtection(Boolean isTotalAccountProtection) {
		this.isTotalAccountProtection = isTotalAccountProtection;
	}

	public Boolean addDevice(DeviceLineItem deviceLineItem) {
		return this.deviceList.add(deviceLineItem);
	}

	public Boolean addPlan(PlanLineItem planLineItem) {
		return this.planList.add(planLineItem);
	}

	public Boolean addFeature(FeatureLineItem featureLineItem) {
		return this.featureList.add(featureLineItem);
	}

	public Boolean addAccessory(AccessoryLineItem accessoryLineItem) {
		return this.accessoryList.add(accessoryLineItem);
	}

	public List<PlanLineItem> getPlanList() {
		return planList;
	}

	public List<FeatureLineItem> getFeatureList() {
		return featureList;
	}

	public List<AccessoryLineItem> getAccessoryList() {
		return accessoryList;
	}

	public List<YttvSubscriptionLineItem> getYttvSubscriptionList() {
		if(null == yttvSubscriptionList){
			yttvSubscriptionList = new ArrayList<>();
		}
		return yttvSubscriptionList;
	}

	public void setYttvSubscriptionList(List<YttvSubscriptionLineItem> yttvSubscriptionList) {
		this.yttvSubscriptionList = yttvSubscriptionList;
	}

	public void removePlan() {
		planList = new ArrayList<>();
	}

	public Boolean isIncludeAccessoryForTax() {
		if(includeAccessoryForTax !=null){
			return includeAccessoryForTax;
		}else{
			return true;
		}
	}

	public void setIncludeAccessoryForTax(Boolean includeAccessoryForTax) {
		this.includeAccessoryForTax = includeAccessoryForTax;
	}

	public Boolean isChanged() {
		if(changed != null){
			return changed;
		}else{
			return true;
		}
	}

	public void setChanged(Boolean changed) {
		this.changed = changed;
	}

	public String getSavedCartEmailId() {
		return savedCartEmailId;
	}

	public void setSavedCartEmailId(String savedCartEmailId) {
		this.savedCartEmailId = savedCartEmailId;
	}

	public List<String> getPromoCodeIds() {
		return promoCodeIds;
	}

	public void setPromoCodeIds(List<String> promoCodeIds) {
		this.promoCodeIds = promoCodeIds;
	}

	public Map<String, List<SkuBarcodeVO>> getBarCodeOffers() {
		return barCodeOffers;
	}

	public void setBarCodeOffers(Map<String, List<SkuBarcodeVO>> barCodeOffers) {
		this.barCodeOffers = barCodeOffers;
	}

	public Double getTotalBarCodeDiscount() {
		if(totalBarCodeDiscount != null){
			return totalBarCodeDiscount;
		}else{
			return 0.00D;
		}
	}

	public void setTotalBarCodeDiscount(Double totalBarCodeDiscount) {
		this.totalBarCodeDiscount = totalBarCodeDiscount;
	}

	public Double getTotalEdgeUpAmount() {
		if(totalEdgeUpAmount != null){
			return totalEdgeUpAmount;
		}else{
			return 0.00D;
		}
	}

	public void setTotalEdgeUpAmount(Double totalEdgeUpAmount) {
		this.totalEdgeUpAmount = totalEdgeUpAmount;
	}

	public String getCustomerType() {
		return customerType;
	}


	public int getVersion() {
		return version;
	}

	public Boolean isDelete() {
		return delete;
	}

	public void deleteOrder() {
		this.updateVersion();
		this.deviceList.clear();
		this.planList.clear();
		this.featureList.clear();
		this.accessoryList.clear();
		this.yttvSubscriptionList.clear();
		//this.subOrders.clear();
	}

	public void updateVersion() {
		this.version += 1;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public Double getTotalActivationFees() {
		if(totalActivationFees != null){
			return totalActivationFees;
		}else{
			return 0.00D;
		}
	}

	public void setTotalActivationFees(Double totalActivationFees) {
		this.totalActivationFees = totalActivationFees;
	}

	public Double getMailInRebateTotal() {
		if(mailInRebateTotal != null){
			return mailInRebateTotal;
		}else{
			return 0.00D;
		}
	}

	public void setMailInRebateTotal(Double mailInRebateTotal) {
		this.mailInRebateTotal = mailInRebateTotal;
	}

	public ContactInfo getContactInfo() {
		return contactInfo;
	}

	public void setContactInfo(ContactInfo contactInfo) {
		this.contactInfo = contactInfo;
	}

	public String getCreditOptionSelected() {
		return creditOptionSelected;
	}

	public void setCreditOptionSelected(String creditOptionSelected) {
		this.creditOptionSelected = creditOptionSelected;
	}



	/**
	 * @return the liveSedCalled
	 */
	public Boolean isLiveSedCalled() {
		return liveSedCalled;
	}

	/**
	 * @param liveSedCalled the liveSedCalled to set
	 */
	public void setLiveSedCalled(Boolean liveSedCalled) {
		this.liveSedCalled = liveSedCalled;
	}

	/**
	 * @return the lastAddedPromoCode
	 */
	public String getLastAddedPromoCode() {
		return lastAddedPromoCode;
	}

	/**
	 * @param lastAddedPromoCode the lastAddedPromoCode to set
	 */
	public void setLastAddedPromoCode(String lastAddedPromoCode) {
		this.lastAddedPromoCode = lastAddedPromoCode;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("OrderID:" + getId()).append('\n')
				.append('\n').append("CreditStatusReason:" + getCreditStatusReason()).append('\n')
				.append("CreditapprovalStatus:" + getCreditApprovalStatus()).append('\n')
				.append("OriginatingSystem:" + getOriginatingSystem()).append('\n').append("Status:" + getStatus())
				.append('\n').append("ChannelID:" + getChannelID()).append('\n')
				.append("CreditServiceClass:" + getCreditServiceClass()).append('\n')
				.append("LocationCode:" + getLocationCode()).append('\n').append("OutletID:" + getOutletID())
				.append('\n').append("SavedCartEmailId" + getSavedCartEmailId()).append("")
				.append("ServiceZip:" + getServiceZip()).append('\n').append("SiteID" + getSiteID()).append('\n')
				.append("UserID:" + getUserID()).append("DeviceList" + getDeviceList().iterator().toString())
				.append('\n').append("PlanList" + getPlanList().iterator().toString()).append('\n')
				.append("FeatureList" + getFeatureList().iterator().toString()).append('\n')
				.append("AccessoryList" + getAccessoryList().iterator().toString());
		return builder.toString();
	}

	public Double getTotalDownpayment() {
		if(totalDownpayment != null){
			return totalDownpayment;
		}else{
			return 0.00D;
		}
	}

	public void setTotalDownpayment(Double totalDownpayment) {
		this.totalDownpayment = totalDownpayment;
	}

	public List<PaymentGroup> getPaymentGroup() {
		return paymentGroup;
	}

	public void setPaymentGroup(List<PaymentGroup> paymentGroup) {
		this.paymentGroup = paymentGroup;
	}

	public String getAccountPin() {
		return accountPin;
	}

	public void setAccountPin(String accountPin) {
		this.accountPin = accountPin;
	}

	public String getTaxState() {
		return taxState;
	}

	public void setTaxState(String taxState) {
		this.taxState = taxState;
	}

	public String getTaxCity() {
		return taxCity;
	}

	public void setTaxCity(String taxCity) {
		this.taxCity = taxCity;
	}

	public String getSocialSecurityNumber() {
		return socialSecurityNumber;
	}

	public void setSocialSecurityNumber(String socialSecurityNumber) {
		this.socialSecurityNumber = socialSecurityNumber;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public List<SubOrder> getSubOrders() {
		return subOrders;
	}

	public void setSubOrders(List<SubOrder> subOrders) {
		this.subOrders = subOrders;
	}

	public Boolean addSubOrder(SubOrder subOrder) {
		return this.subOrders.add(subOrder);
	}

	public Double getLineAccessCharges() {
		if(lineAccessCharges != null){
			return lineAccessCharges;
		}else{
			return 0.00D;
		}
	}

	public void setLineAccessCharges(Double lineAccessCharges) {
		this.lineAccessCharges = lineAccessCharges;
	}

	public Boolean isInstantDRCCredit() {
		if(instantDRCCredit != null){
			return instantDRCCredit;
		}else{
			return false;
		}
	}

	public void setInstantDRCCredit(Boolean instantDRCCredit) {
		this.instantDRCCredit = instantDRCCredit;
	}

	public Double getInstantCreditRemaining() {
		if(instantCreditRemaining != null){
			return instantCreditRemaining;
		}else{
			return 0.00D;
		}
	}

	public void setInstantCreditRemaining(Double instantCreditRemaining) {
		this.instantCreditRemaining = instantCreditRemaining;
	}

	public Boolean isCreditReadValidated() {
		return creditReadValidated;
	}

	public void setCreditReadValidated(Boolean creditReadValidated) {
		this.creditReadValidated = creditReadValidated;
	}

	public String getCreditApprovalStatus() {
		return creditApprovalStatus;
	}

	public void setCreditApprovalStatus(String creditApprovalStatus) {
		this.creditApprovalStatus = creditApprovalStatus;
	}

	public String getInternationalEligibilityCheck() {
		return internationalEligibilityCheck;
	}

	public void setInternationalEligibilityCheck(String internationalEligibilityCheck) {
		this.internationalEligibilityCheck = internationalEligibilityCheck;
	}

	public List<ShippingGroup> getShippingGroups() {
		return shippingGroups;
	}

	public void setShippingGroups(List<ShippingGroup> shippingGroups) {
		this.shippingGroups = shippingGroups;
	}

	public String getProgramEligibilityIndicator() {
		return programEligibilityIndicator;
	}

	public void setProgramEligibilityIndicator(String programEligibilityIndicator) {
		this.programEligibilityIndicator = programEligibilityIndicator;
	}

	public Double getDownpaymentPercent() {
		if(downpaymentPercent != null){
			return downpaymentPercent;
		}else{
			return 0.00D;
		}
	}

	public void setDownpaymentPercent(Double downpaymentPercent) {
		this.downpaymentPercent = downpaymentPercent;
	}

	public OrderWriteServiceInfo getOrderWriteServiceInfo() {
		return orderWriteServiceInfo;
	}

	public void setOrderWriteServiceInfo(OrderWriteServiceInfo orderWriteServiceInfo) {
		this.orderWriteServiceInfo = orderWriteServiceInfo;
	}

	public String getBillingSystem() {
		return billingSystem;
	}

	public void setBillingSystem(String billingSystem) {
		this.billingSystem = billingSystem;
	}

	public String getFlow() {
		return flow;
	}

	public void setFlow(String flow) {
		this.flow = flow;
	}

	public ContactInfo getBillingAddress() {
		return billingAddress;
	}

	public void setBillingAddress(ContactInfo billingAddress) {
		this.billingAddress = billingAddress;
	}


	public String getSddDeliveryDate() {
		return sddDeliveryDate;
	}

	public void setSddDeliveryDate(String sddDeliveryDate) {
		this.sddDeliveryDate = sddDeliveryDate;
	}

	public String getClusterInfo() {
		return clusterInfo;
	}

	public void setClusterInfo(String clusterInfo) {
		this.clusterInfo = clusterInfo;
	}

	/**
	 * @return the paperFreeBillingIndicator
	 */
	public String getPaperFreeBillingIndicator() {
		return paperFreeBillingIndicator;
	}

	/**
	 * @param paperFreeBillingIndicator the paperFreeBillingIndicator to set
	 */
	public void setPaperFreeBillingIndicator(String paperFreeBillingIndicator) {
		this.paperFreeBillingIndicator = paperFreeBillingIndicator;
	}

	/**
	 * @return the isSpecialUpgrade
	 */
	public String getIsSpecialUpgrade() {
		return isSpecialUpgrade;
	}

	/**
	 * @param isSpecialUpgrade the isSpecialUpgrade to set
	 */
	public void setIsSpecialUpgrade(String isSpecialUpgrade) {
		this.isSpecialUpgrade = isSpecialUpgrade;
	}

	/**
	 * @return the intlEligibilityCheck
	 */
	public String getIntlEligibilityCheck() {
		return intlEligibilityCheck;
	}

	/**
	 * @param intlEligibilityCheck the intlEligibilityCheck to set
	 */
	public void setIntlEligibilityCheck(String intlEligibilityCheck) {
		this.intlEligibilityCheck = intlEligibilityCheck;
	}

	/**
	 * @param featureList the featureList to set
	 */
	public void setFeatureList(List<FeatureLineItem> featureList) {
		this.featureList = featureList;
	}

	/**
	 * @param planList the planList to set
	 */
	public void setPlanList(List<PlanLineItem> planList) {
		this.planList = planList;
	}

	/**
	 * @param accessoryList the accessoryList to set
	 */
	public void setAccessoryList(List<AccessoryLineItem> accessoryList) {
		this.accessoryList = accessoryList;
	}

	public Boolean getTaxCalculated() {
		return taxCalculated;
	}

	public void setTaxCalculated(Boolean taxCalculated) {
		this.taxCalculated = taxCalculated;
	}

	public Double getSubTotalDueMonthly() {
		if(subTotalDueMonthly != null){
			return subTotalDueMonthly;
		} else {
			return 0.0D;
		}
	}

	public void setSubTotalDueMonthly(Double subTotalDueMonthly) {
		this.subTotalDueMonthly = subTotalDueMonthly;
	}

	public Double getSubTotalDueToday() {
		if(subTotalDueToday != null){
			return subTotalDueToday;
		} else {
			return 0.0D;
		}
	}

	public void setSubTotalDueToday(Double subTotalDueToday) {
		this.subTotalDueToday = subTotalDueToday;
	}

	@JsonIgnore
	public Double getTotalDueToday() {
		Double subTtlDueToday = this.getSubTotalDueToday();
		//get the order tax amount
		Double taxAmount = this.getOrderTax();
		//get the shipping cost
		Double shippingCost = getShippingCost();
		return subTtlDueToday + taxAmount + shippingCost;
	}

	@JsonIgnore
	public Double getTotalDueMonthly() {
		Double subTtlDueMonthly = this.getSubTotalDueMonthly();
		Double taxAmount = 0.0D;
		if(isIncludePlanAndFeatureTaxInDueMonthly()){
			taxAmount = getMonthlyTaxAmount();
		}
		return subTtlDueMonthly + taxAmount;

	}

	public String getVendorId() {
		return vendorId;
	}

	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}

	public String getLastAddedDeviceLineItemId() {
		return lastAddedDeviceLineItemId;
	}

	public void setLastAddedDeviceLineItemId(String lastAddedDeviceLineItemId) {
		this.lastAddedDeviceLineItemId = lastAddedDeviceLineItemId;
	}

	@JsonIgnore
	public double getShippingCost(){
		double shippingCost = 0.0D;
		Optional<List<ShippingGroup>> sgs = Optional.ofNullable(this.getShippingGroups());
		if(sgs.isPresent() && !sgs.get().isEmpty()){
			shippingCost = sgs.get().stream().collect(Collectors.summingDouble(sg -> sg.getShippingCost()));
		}
		return shippingCost;
	}

	@JsonIgnore
	public double getMonthlyTaxAmount(){
		//get plan taxes
		Optional<List<PlanLineItem>> plans = Optional.ofNullable(this.getPlanList());
		Optional<List<FeatureLineItem>> features = Optional.ofNullable(this.getFeatureList());
		double totalTaxesForplans = 0.00D;
		if(plans.isPresent() && !plans.get().isEmpty()){
			totalTaxesForplans = plans.get().stream().collect(Collectors.summingDouble(device -> device.getItemTaxes()));
		}
		double totalTaxesForfeatures = 0.0D;
		if(features.isPresent() && !features.get().isEmpty()){
			totalTaxesForfeatures = features.get().stream().collect(Collectors.summingDouble(device -> device.getItemTaxes()));
		}
		return (totalTaxesForplans + totalTaxesForfeatures);
	}

	public Boolean isIncludePlanAndFeatureTaxInDueMonthly() {
		if(includePlanAndFeatureTaxInDueMonthly != null){
			return includePlanAndFeatureTaxInDueMonthly;
		}else{
			return false;
		}
	}

	public void setIncludePlanAndFeatureTaxInDueMonthly(Boolean includePlanAndFeatureTaxInDueMonthly) {
		this.includePlanAndFeatureTaxInDueMonthly = includePlanAndFeatureTaxInDueMonthly;
	}

	public String getCartType() {
		return cartType;
	}

	public void setCartType(String cartType) {
		this.cartType = cartType;
	}

	public Date getSaveCartDate() {
		return saveCartDate;
	}

	public void setSaveCartDate(Date saveCartDate) {
		this.saveCartDate = saveCartDate;
	}

	public Double getTotalSecurityDepositAmount() {
		if(totalSecurityDepositAmount != null){
			return totalSecurityDepositAmount;
		}else{
			return 0.0D;
		}
	}

	public void setTotalSecurityDepositAmount(Double totalSecurityDepositAmount) {
		this.totalSecurityDepositAmount = totalSecurityDepositAmount;
	}

	public Double getPastDueBalance() {
		if(pastDueBalance != null){
			return pastDueBalance;
		}else{
			return 0.0D;
		}
	}

	public void setPastDueBalance(Double pastDueBalance) {
		this.pastDueBalance = pastDueBalance;
	}

	public Double getTotalEdgeBuyOutAmount() {
		if(totalEdgeBuyOutAmount != null){
			return totalEdgeBuyOutAmount;
		}else{
			return 0.0D;
		}

	}

	public void setTotalEdgeBuyOutAmount(Double totalEdgeBuyOutAmount) {
		this.totalEdgeBuyOutAmount = totalEdgeBuyOutAmount;
	}

	public Double getEmployeeDiscount() {
		if(employeeDiscount != null){
			return employeeDiscount;
		}else{
			return 0.0D;
		}
	}

	public void setEmployeeDiscount(Double employeeDiscount) {
		this.employeeDiscount = employeeDiscount;
	}

	public Double getSaveCartPrice() {
		return saveCartPrice;
	}

	public void setSaveCartPrice(Double saveCartPrice) {
		this.saveCartPrice = saveCartPrice;
	}

	public HashMap<String, String> getProductCorrelationIdMap() {
		return productCorrelationIdMap;
	}

	public void setProductCorrelationIdMap(HashMap<String, String> productCorrelationIdMap) {
		this.productCorrelationIdMap = productCorrelationIdMap;
	}



	public Double getRemainingSpendingLimit() {
		return remainingSpendingLimit;
	}

	public void setRemainingSpendingLimit(Double remainingSpendingLimit) {
		this.remainingSpendingLimit = remainingSpendingLimit;
	}

	public SoftCreditInfo getSoftCreditInfo() {
		return softCreditInfo;
	}

	public void setSoftCreditInfo(SoftCreditInfo softCreditInfo) {
		this.softCreditInfo = softCreditInfo;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public Double getTotalUpgradeFee() {
		if(totalUpgradeFee != null){
			return totalUpgradeFee;
		}else{
			return 0.0D;
		}
	}

	public void setTotalUpgradeFee(Double totalUpgradeFee) {
		this.totalUpgradeFee = totalUpgradeFee;
	}

	public Map<String, String> getSpecialInstructions() {
		return specialInstructions;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getPlaySessionId() {
		if(StringUtils.isEmpty(playSessionId)){
			return correlationId;
		}
		return playSessionId;
	}

	public void setPlaySessionId(String playSessionId) {
		this.playSessionId = playSessionId;
	}

	public String getCreditApplicationNumber() {
		return creditApplicationNumber;
	}

	public void setCreditApplicationNumber(String creditApplicationNumber) {
		this.creditApplicationNumber = creditApplicationNumber;
	}



	public void setPosOrderNumber(String posOrderNumber) {
		this.posOrderNumber = posOrderNumber;
	}


	public String getPosOrderNumber() {
		// As of now we have only one Order. so getting from 0th one. if any future needs to modify.
		String lPosOrderNumber = this.posOrderNumber;
		/*if (getSubOrders() != null && getSubOrders().size() > 0) {
			return	getSubOrders().get(0).getPosOrderNumber();
		} else {
			lPosOrderNumber = posOrderNumber;
		}*/
		return lPosOrderNumber;

	}


	/**
	 * Gets the credit application num.
	 *
	 * @return - String
	 */
	@JsonIgnore
	public String getCreditApplicationNum() {
		// As of now we have only one Order. so getting from 0th one. if any future needs to modify.
		String lCreditAppNum = this.creditApplicationNumber;
		/*if (getSubOrders() != null && getSubOrders().size() > 0) {
			lCreditAppNum = getSubOrders()
					.get(0).getCreditApplicationNum();
		}*/

		return lCreditAppNum;
	} // end else

	public EdgeEligibilityVO getEdgeEligibilityVO() {
		return edgeEligibilityVO;
	}

	public void setEdgeEligibilityVO(EdgeEligibilityVO edgeEligibilityVO) {
		this.edgeEligibilityVO = edgeEligibilityVO;
	}

	public double getDownPaymentAmount() {
		return downPaymentAmount;
	}

	public void setDownPaymentAmount(double downPaymentAmount) {
		this.downPaymentAmount = downPaymentAmount;
	}

	public String getMarketId() {
		return marketId;
	}

	public void setMarketId(String marketId) {
		this.marketId = marketId;
	}

	/*public List<ServiceChangedLineVo> getServiceChangedLines() {
		return serviceChangedLines;
	}

	public void setServiceChangedLines(List<ServiceChangedLineVo> serviceChangedLines) {
		this.serviceChangedLines = serviceChangedLines;
	}

	/*public List<PlanChangeImpactedLineVo> getPlanChangeImpactedLines() {
		return planChangeImpactedLines;
	}

	public void setPlanChangeImpactedLines(List<PlanChangeImpactedLineVo> planChangeImpactedLines) {
		this.planChangeImpactedLines = planChangeImpactedLines;
	}*/

	public boolean isDiscountCodeApplied() {
		return discountCodeApplied;
	}

	public void setDiscountCodeApplied(boolean discountCodeApplied) {
		this.discountCodeApplied = discountCodeApplied;
	}

	public List<VZWPromotion> getPromotions() {
		return promotions;
	}

	public void setPromotions(List<VZWPromotion> promotions) {
		this.promotions = promotions;
	}

	public String getConfirmationNumber() {
		return confirmationNumber;
	}

	public void setConfirmationNumber(String confirmationNumber) {
		this.confirmationNumber = confirmationNumber;
	}

	public String getAddOrderConfirmationNumber() {
		return addOrderConfirmationNumber;
	}

	public void setAddOrderConfirmationNumber(String addOrderConfirmationNumber) {
		this.addOrderConfirmationNumber = addOrderConfirmationNumber;
	}

	public String getComputeOfferKey() {
		return computeOfferKey;
	}

	public void setComputeOfferKey(String computeOfferKey) {
		this.computeOfferKey = computeOfferKey;
	}

	private String computeOfferKey;

	public Set<String> getBarcodeIds() {
		return barcodeIds;
	}

	public void setBarcodeIds(Set<String> barcodeIds) {
		this.barcodeIds = barcodeIds;
	}

	//Added to maintain the count of failled attempts while submiting order to POS
	private int submitOrderFailedAttempts;

	public int getSubmitOrderFailedAttempts() {return submitOrderFailedAttempts;}

	public void setSubmitOrderFailedAttempts(int submitOrderFailedAttempts) {this.submitOrderFailedAttempts = submitOrderFailedAttempts;}

	private String currentSubOrder;
	public String getCurrentSubOrder() {
		return currentSubOrder;
	}

	public void setCurrentSubOrder(String currentSubOrder) {
		this.currentSubOrder = currentSubOrder;
	}

	private String salesRepId;
	public String getSalesRepId() {
		return salesRepId;
	}

	public void setSalesRepId(String salesRepId) {
		this.salesRepId = salesRepId;
	}

	private String sharedCartId;

	public String getSharedCartId() {
		return sharedCartId;
	}
	public void setSharedCartId(String sharedCartId) {
		this.sharedCartId = sharedCartId;
	}

	private String ecpdProfileId;

	private String uberPinlongitude;
	private String uberPinlatitude;

	public String getUberPinlongitude() {
		return uberPinlongitude;
	}

	public void setUberPinlongitude(String uberPinlongitude) {
		this.uberPinlongitude = uberPinlongitude;
	}

	public String getUberPinlatitude() {
		return uberPinlatitude;
	}

	public void setUberPinlatitude(String uberPinlatitude) {
		this.uberPinlatitude = uberPinlatitude;
	}

	public String getInstallbuildingId() {
		return installbuildingId;
	}

	public void setInstallbuildingId(String installbuildingId) {
		this.installbuildingId = installbuildingId;
	}

	private String installbuildingId;
	//B2E discount
	private Double accessDiscountPercentage;

	private String processorEmailId;
	private String processorUserId;

	public String getProcessorEmailId() {
		return processorEmailId;
	}

	public void setProcessorEmailId(String processorEmailId) {
		this.processorEmailId = processorEmailId;
	}

	public String getProcessorUserId() {
		return processorUserId;
	}

	public void setProcessorUserId(String processorUserId) {
		this.processorUserId = processorUserId;
	}


	public String getFullAuthFlag() {
		return fullAuthFlag;
	}

	public void setFullAuthFlag(String fullAuthFlag) {
		this.fullAuthFlag = fullAuthFlag;
	}

	private String fullAuthFlag;

	public String getEcpdProfileId() {
		return ecpdProfileId;
	}

	public void setEcpdProfileId(String ecpdProfileId) {
		this.ecpdProfileId = ecpdProfileId;
	}

	/*public VZWOrderKeyInfo getOrderKeyInfo() {
		return orderKeyInfo;
	}

	public void setOrderKeyInfo(VZWOrderKeyInfo orderKeyInfo) {
		this.orderKeyInfo = orderKeyInfo;
	}*/

	public int getNoOfcreditReadAttempts() {
		return noOfcreditReadAttempts;
	}

	public void setNoOfcreditReadAttempts(int noOfcreditReadAttempts) {
		this.noOfcreditReadAttempts = noOfcreditReadAttempts;
	}

	public String getClientReferenceNumber() {
		return clientReferenceNumber;
	}

	public void setClientReferenceNumber(String clientReferenceNumber) {
		this.clientReferenceNumber = clientReferenceNumber;
	}

	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public String getVisionCustomerType() {
		if (this.visionCustomerType != null) {
			return this.visionCustomerType;
		} else {
			this.visionCustomerType = "PE";
			if ("EPP".equalsIgnoreCase(getCustomerType())) {
				this.visionCustomerType = "ME";
			} else if ("B2E".equalsIgnoreCase(getCustomerType())) {
				this.visionCustomerType = "PE";
			}
			return this.visionCustomerType;
		}
	}

	public void setVisionCustomerType(String pVisionCustomerType) {
		this.visionCustomerType = pVisionCustomerType;
	}

	public String getCustomerAgreementText() {
		return customerAgreementText;
	}

	public void setCustomerAgreementText(String customerAgreementText) {
		this.customerAgreementText = customerAgreementText;
	}

	public String getCorrelationId() {
		return correlationId;
	}

	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}

	public String getOriginatingIpAddress() {
		return originatingIpAddress;
	}

	public void setOriginatingIpAddress(String originatingIpAddress) {
		this.originatingIpAddress = originatingIpAddress;
	}

	public String getBlanketApprovalNumber() {
		return blanketApprovalNumber;
	}

	public void setBlanketApprovalNumber(String blanketApprovalNumber) {
		this.blanketApprovalNumber = blanketApprovalNumber;
	}

	public int getNoOfEidServiceAttempts() {
		return noOfEidServiceAttempts;
	}

	public void setNoOfEidServiceAttempts(int noOfEidServiceAttempts) {
		this.noOfEidServiceAttempts = noOfEidServiceAttempts;
	}

	public boolean isEidServiceCalled() {
		return eidServiceCalled;
	}

	public void setEidServiceCalled(boolean eidServiceCalled) {
		this.eidServiceCalled = eidServiceCalled;
	}

	public String getCustomerIDType() {
		return customerIDType;
	}

	public void setCustomerIDType(String customerIDType) {
		this.customerIDType = customerIDType;
	}

	public String getCustomerIDNumber() {
		return customerIDNumber;
	}

	public void setCustomerIDNumber(String customerIDNumber) {
		this.customerIDNumber = customerIDNumber;
	}

	public String getIspuState() {
		return ispuState;
	}

	public void setIspuState(String ispuState) {
		this.ispuState = ispuState;
	}

	public Double getAccessDiscountPercentage() {
		if(this.accessDiscountPercentage == null){
			return 0.0D;
		}else {
			return accessDiscountPercentage;
		}
	}

	public void setAccessDiscountPercentage(Double accessDiscountPercentage) {this.accessDiscountPercentage = accessDiscountPercentage;
	}
    public String getSsnPieKeyId() {
        return ssnPieKeyId;
    }

    public void setSsnPieKeyId(String ssnPieKeyId) {
        this.ssnPieKeyId = ssnPieKeyId;
    }

    public String getSsnPhaseId() {
        return ssnPhaseId;
    }

    public void setSsnPhaseId(String ssnPhaseId) {
        this.ssnPhaseId = ssnPhaseId;
    }

    public String getSsnEncryptionType() {
        return ssnEncryptionType;
    }

    public void setSsnEncryptionType(String ssnEncryptionType) {
        this.ssnEncryptionType = ssnEncryptionType;
    }
	
	public int getNoOfcreditReadAttemptsForPR() {
        return noOfcreditReadAttemptsForPR;
    }
 
    public void setNoOfcreditReadAttemptsForPR(int noOfcreditReadAttemptsForPR) {
        this.noOfcreditReadAttemptsForPR = noOfcreditReadAttemptsForPR;
    }

	public String getSwitchContractAndCreditDepositRequired() {
		return switchContractAndCreditDepositRequired;
	}

	public void setSwitchContractAndCreditDepositRequired(String switchContractAndCreditDepositRequired) {
		this.switchContractAndCreditDepositRequired = switchContractAndCreditDepositRequired;
	}

	public Long getCreatedTimeInMillis() {
		return createdTimeInMillis;
	}

	public void setCreatedTimeInMillis(Long createdTimeInMillis) {
		this.createdTimeInMillis = createdTimeInMillis;
	}
	private String appStore;

	public String getAppStore() {
		return appStore;
	}

	public void setAppStore(String appStore) {
		this.appStore = appStore;
	}

	public int getTotalNoOfcreditReadAttemptsForPR() {
		return totalNoOfcreditReadAttemptsForPR;
	}

	public void setTotalNoOfcreditReadAttemptsForPR(int totalNoOfcreditReadAttemptsForPR) {
		this.totalNoOfcreditReadAttemptsForPR = totalNoOfcreditReadAttemptsForPR;
	}

	public String getCreditStatusReasonMsg() {
		return creditStatusReasonMsg;
	}

	public void setCreditStatusReasonMsg(String creditStatusReasonMsg) {
		this.creditStatusReasonMsg = creditStatusReasonMsg;
	}

	private int noOfLinesSelected;

	public int getNoOfLinesSelected() {
		return noOfLinesSelected;
	}

	public void setNoOfLinesSelected(int noOfLinesSelected) {
		this.noOfLinesSelected = noOfLinesSelected;
	}

	public InstallationWindow getInstallationWindow() {
		return installationWindow;
	}

	public void setInstallationWindow(InstallationWindow installationWindow) {
		this.installationWindow = installationWindow;
	}

	public String getFixedWirelessPromo() {
		return fixedWirelessPromo;
	}

	public void setFixedWirelessPromo(String fixedWirelessPromo) {
		this.fixedWirelessPromo = fixedWirelessPromo;
	}


	public int getNoExamAvailApiCount() {
		return noExamAvailApiCount;
	}

	public void setNoExamAvailApiCount(int noExamAvailApiCount) {
		this.noExamAvailApiCount = noExamAvailApiCount;
	}

	public boolean isCreditCheckCompleted() {
		return creditCheckCompleted;
	}

	public void setCreditCheckCompleted(boolean creditCheckCompleted) {
		this.creditCheckCompleted = creditCheckCompleted;
	}


	public String getBrowserAgent() {
		return browserAgent;
	}

	public void setBrowserAgent(String browserAgent) {
		this.browserAgent = browserAgent;
	}

	public boolean isAcsUrlPresent3DSecure() {
		return acsUrlPresent3DSecure;
	}
	public void setAcsUrlPresent3DSecure(boolean acsUrlPresent3DSecure) {
		this.acsUrlPresent3DSecure = acsUrlPresent3DSecure;
	}
	
	/*public RecycleDeviceSessionBean getRecycleDevicesDetail() {
		return recycleDevicesDetail;
	}


	public void setRecycleDevicesDetail(RecycleDeviceSessionBean recycleDevicesDetail) {
		this.recycleDevicesDetail = recycleDevicesDetail;
	}*/

	public boolean isLookupFailed3DSecure() {
		return lookupFailed3DSecure;
	}

	public void setLookupFailed3DSecure(boolean lookupFailed3DSecure) {
		this.lookupFailed3DSecure = lookupFailed3DSecure;
	}

	public boolean isBenefitEligibility3DSecure() {
		return benefitEligibility3DSecure;
	}

	public void setBenefitEligibility3DSecure(boolean benefitEligibility3DSecure) {
		this.benefitEligibility3DSecure = benefitEligibility3DSecure;
	}

	public boolean isCardinalSetupDone3DSecure() {
		return cardinalSetupDone3DSecure;
	}

	public void setCardinalSetupDone3DSecure(boolean cardinalSetupDone3DSecure) {
		this.cardinalSetupDone3DSecure = cardinalSetupDone3DSecure;
	}

	public boolean isPopupDisplayed3DSecure() {
		return popupDisplayed3DSecure;
	}

	public void setPopupDisplayed3DSecure(boolean popupDisplayed3DSecure) {
		this.popupDisplayed3DSecure = popupDisplayed3DSecure;
	}
	
	public List<VZWProspectCustomBundleVO> getCustomBundles() {
		return customBundles;
	}

	public void setCustomBundles(List<VZWProspectCustomBundleVO> customBundles) {
		this.customBundles = customBundles;
	}


	//added for Express Store
	private String orderFlow;

	public String getOrderFlow() {
		return orderFlow;
	}
	public void setOrderFlow(String orderFlow) {
		this.orderFlow = orderFlow;
	}

	private boolean xml6CheckPerformed;

	public boolean isXml6CheckPerformed() {
		return xml6CheckPerformed;
	}

	public void setXml6CheckPerformed(boolean xml6CheckPerformed) {
		this.xml6CheckPerformed = xml6CheckPerformed;
	}

	private double remainingBalance;

	public double getRemainingBalance() {
		return remainingBalance;
	}
	public void setRemainingBalance(double remainingBalance) {
		this.remainingBalance = remainingBalance;
	}

	private String storeId;

	public String getStoreId() {
		return storeId;
	}
	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}
	
	/*private List<FraudRuleEnum> fraudRuleStack;

	public List<FraudRuleEnum> getFraudRuleStack() {
		return fraudRuleStack;
	}

	public void setFraudRuleStack(List<FraudRuleEnum> fraudRuleStack) {
		this.fraudRuleStack = fraudRuleStack;
	}*/


	public int getNoOfSoftCreditReadAttemptsForPR() {
		return noOfSoftCreditReadAttemptsForPR;
	}

	public void setNoOfSoftCreditReadAttemptsForPR(int noOfSoftCreditReadAttemptsForPR) {
		this.noOfSoftCreditReadAttemptsForPR = noOfSoftCreditReadAttemptsForPR;
	}

	public int getTotalNoOfSoftCreditReadAttemptsForPR() {
		return totalNoOfSoftCreditReadAttemptsForPR;
	}

	public void setTotalNoOfSoftCreditReadAttemptsForPR(int totalNoOfSoftCreditReadAttemptsForPR) {
		this.totalNoOfSoftCreditReadAttemptsForPR = totalNoOfSoftCreditReadAttemptsForPR;
	}

	public List<SoftSku5GLineItem> getSoftSkuList() {
		return softSkuList;
	}

	public void setSoftSkuList(List<SoftSku5GLineItem> softSkuList) {
		this.softSkuList = softSkuList;
	}

	public String getInstallationFloor() {
		return installationFloor;
	}

	public void setInstallationFloor(String installationFloor) {
		this.installationFloor = installationFloor;
	}

	public String getSoftCreditOrderPrelaunchIndicator() {
		return softCreditOrderPrelaunchIndicator;
	}

	public void setSoftCreditOrderPrelaunchIndicator(String softCreditOrderPrelaunchIndicator) {
		this.softCreditOrderPrelaunchIndicator = softCreditOrderPrelaunchIndicator;
	}

	public String getSoftCreditResult() {
		return softCreditResult;
	}

	public void setSoftCreditResult(String softCreditResult) {
		this.softCreditResult = softCreditResult;
	}

	public String getBucketAllocator() {
		return bucketAllocator;
	}

	public void setBucketAllocator(String bucketAllocator) {
		this.bucketAllocator = bucketAllocator;
	}

	private String bucketAllocator;

	public double getOrderBalanceAmount() {
		return orderBalanceAmount;
	}

	public void setOrderBalanceAmount(double orderBalanceAmount) {
		this.orderBalanceAmount = orderBalanceAmount;
	}

	public String iwvSessionThrottled;
	public String getIwvSessionThrottled() {
		return iwvSessionThrottled;
	}

	public void setIwvSessionThrottled(String iwvSessionThrottled) {
		this.iwvSessionThrottled = iwvSessionThrottled;
	}

	/*public SharedCartHeader getOriginalSCHeader() {
		return originalSCHeader;
	}

	public void setOriginalSCHeader(SharedCartHeader originalSCHeader) {
		this.originalSCHeader = originalSCHeader;
	}*/

	public String getExpPOBOCartHeading() {
		return expPOBOCartHeading;
	}

	public void setExpPOBOCartHeading(String expPOBOCartHeading) {
		this.expPOBOCartHeading = expPOBOCartHeading;
	}

	public String getExpPOBOConfirmationHeading() {
		return expPOBOConfirmationHeading;
	}

	public void setExpPOBOConfirmationHeading(String expPOBOConfirmationHeading) {
		this.expPOBOConfirmationHeading = expPOBOConfirmationHeading;

	}

	public boolean isSoiFlag() {
		return soiFlag;
	}

	public void setSoiFlag(boolean soiFlag) {
		this.soiFlag = soiFlag;
	}

	public boolean isSoiShowAccountPlan() {
		return soiShowAccountPlan;
	}

	public void setSoiShowAccountPlan(boolean soiShowAccountPlan) {
		this.soiShowAccountPlan = soiShowAccountPlan;
	}
	//private FiosCustomerDetailsVO fiosCustomerDetails ;


	/*public boolean isSkipCreditCheck() {
		return skipCreditCheck;
	}

	public void setSkipCreditCheck(boolean skipCreditCheck) {
		this.skipCreditCheck = skipCreditCheck;
	}

	private boolean skipCreditCheck;*/

	// CXTDT-35973 - Join VZ, Cash Rounding discount missing in Submit payment call to POS
	/*private VZWCashRoundingDiscount vzwCashRoundingDiscount;

	public VZWCashRoundingDiscount getVzwCashRoundingDiscount() {
		return vzwCashRoundingDiscount;
	}

	public void setVzwCashRoundingDiscount(VZWCashRoundingDiscount vzwCashRoundingDiscount) {
		this.vzwCashRoundingDiscount = vzwCashRoundingDiscount;
	}*/

	private Set<String> inEligibleShippingMethodsRTI;

	public Set<String> getInEligibleShippingMethodsRTI() {
		if (null == inEligibleShippingMethodsRTI) {
			inEligibleShippingMethodsRTI = new HashSet<>();
		}
		return inEligibleShippingMethodsRTI;
	}

	public void setInEligibleShippingMethodsRTI(Set<String> inEligibleShippingMethodsRTI) {
		this.inEligibleShippingMethodsRTI = inEligibleShippingMethodsRTI;
	}

	public AddOnOrder getAddOnOrder() {
		return addOnOrder;
	}

	public void setAddOnOrder(AddOnOrder addOnOrder) {
		this.addOnOrder = addOnOrder;
	}

	private AddOnOrder addOnOrder;


	/*public FiosCustomerDetailsVO getFiosCustomerDetails(){
		if(Objects.nonNull(addOnOrder))
			return addOnOrder.getFiosCustomerDetails();
		return null;
	}*/

	/*public boolean isOmniCombo() {
		return omniCombo;
	}

	public void setOmniCombo(boolean omniCombo) {
		this.omniCombo = omniCombo;
	}*/

	@JsonIgnoreProperties(ignoreUnknown = true)
	public class AddOnOrder implements Serializable {
		private static final long serialVersionUID = -1L;

		private String id;

		private String playSessionId;

	//	private FiosCustomerDetailsVO fiosCustomerDetails;

		public String getId() {
			return id;
		}

		public void setId(String id) {
			this.id = id;
		}

		/*public FiosCustomerDetailsVO getFiosCustomerDetails() {
			return fiosCustomerDetails;
		}

		public void setFiosCustomerDetails(FiosCustomerDetailsVO fiosCustomerDetails) {
			this.fiosCustomerDetails = fiosCustomerDetails;
		}*/

		public String getPlaySessionId() {
			return playSessionId;
		}

		public void setPlaySessionId(String playSessionId) {
			this.playSessionId = playSessionId;
		}
	}

	public String getWirelessOrder() {
		return wirelessOrder;
	}

	public void setWirelessOrder(String wirelessOrder) {
		this.wirelessOrder = wirelessOrder;
	}

	public String getWirelineOrder() {
		return wirelineOrder;
	}

	public void setWirelineOrder(String wirelineOrder) {
		this.wirelineOrder = wirelineOrder;
	}

	public String getWirelineAccountNumber() {
		return wirelineAccountNumber;
	}

	public void setWirelineAccountNumber(String wirelineAccountNumber) {
		this.wirelineAccountNumber = wirelineAccountNumber;
	}

	public String getWirelineAccountSubNumber() {
		return wirelineAccountSubNumber;
	}

	public void setWirelineAccountSubNumber(String wirelineAccountSubNumber) {
		this.wirelineAccountSubNumber = wirelineAccountSubNumber;
	}

	public String getWirelessStatusDesc() {
		return wirelessStatusDesc;
	}

	public void setWirelessStatusDesc(String wirelessStatusDesc) {
		this.wirelessStatusDesc = wirelessStatusDesc;
	}

	public String getWirelineStatusDesc() {
		return wirelineStatusDesc;
	}

	public void setWirelineStatusDesc(String wirelineStatusDesc) {
		this.wirelineStatusDesc = wirelineStatusDesc;
	}
    private String setUpIndicatorISPU;

    public String getSetUpIndicatorISPU() {
        return setUpIndicatorISPU;
    }

    public void setSetUpIndicatorISPU(String setUpIndicatorISPU) {
        this.setUpIndicatorISPU = setUpIndicatorISPU;
    }

	public double getFnfDiscountPrice() {
		return fnfDiscountPrice;
	}

	public void setFnfDiscountPrice(double fnfDiscountPrice) {
		this.fnfDiscountPrice = fnfDiscountPrice;
	}

	public String getFnfPromoCode() {
		return fnfPromoCode;
	}

	public void setFnfPromoCode(String fnfPromoCode) {
		this.fnfPromoCode = fnfPromoCode;
	}

	public VZWTermsAndConditionAgreementVO getTermsAndConditionAgreement() {
		return termsAndConditionAgreement;
	}

	public void setTermsAndConditionAgreement(VZWTermsAndConditionAgreementVO termsAndConditionAgreement) {
		this.termsAndConditionAgreement = termsAndConditionAgreement;
	}

	private Boolean standaloneAccessories;

	public Boolean getStandaloneAccessories() {
		return this.standaloneAccessories;
	}

	public void setStandaloneAccessories(Boolean var1) {
		this.standaloneAccessories = var1;
	}

	public double getTeacherOrNurseDiscount() {
		return teacherOrNurseDiscount;
	}

	public void setTeacherOrNurseDiscount(double teacherOrNurseDiscount) {
		this.teacherOrNurseDiscount = teacherOrNurseDiscount;
	}

	public String getTeacherOrNurseOfferType() {
		return teacherOrNurseOfferType;
	}

	public void setTeacherOrNurseOfferType(String teacherOrNurseOfferType) {
		this.teacherOrNurseOfferType = teacherOrNurseOfferType;
	}

	private boolean d2dHomeOrder;

	public boolean isD2dHomeOrder() {
		return d2dHomeOrder;
	}

	public void setD2dHomeOrder(boolean d2dHomeOrder) {
		this.d2dHomeOrder = d2dHomeOrder;
	}

	private boolean partnerOrder;

	public boolean isPartnerOrder() {
		return partnerOrder;
	}

	public void setPartnerOrder(boolean partnerOrder) {
		this.partnerOrder = partnerOrder;
	}

	public boolean isByodMVAOrder() {
		return byodMVAOrder;
	}

	public void setByodMVAOrder(boolean byodMVAOrder) {
		this.byodMVAOrder = byodMVAOrder;
	}

	private String dtdAgentId;

	public String getDtdAgentId() {
		return dtdAgentId;
	}

	public void setDtdAgentId(String dtdAgentId) {
		this.dtdAgentId = dtdAgentId;
	}

	public boolean isExpressStoreD2DOrder() {
		return expressStoreD2DOrder;
	}

	public void setExpressStoreD2DOrder(boolean expressStoreD2DOrder) {
		this.expressStoreD2DOrder = expressStoreD2DOrder;
	}

	public String getD2dSource() {
		return d2dSource;
	}

	public void setD2dSource(String d2dSource) {
		this.d2dSource = d2dSource;
	}

	public String getEcpdUniqueId() {
		return EcpdUniqueId;
	}

	public void setEcpdUniqueId(String ecpdUniqueId) {
		EcpdUniqueId = ecpdUniqueId;
	}

	public String getEcpdVendorCode() {
		return EcpdVendorCode;
	}

	public void setEcpdVendorCode(String ecpdVendorCode) {
		EcpdVendorCode = ecpdVendorCode;
	}

	public boolean isMvaPlansFirstFlow() {
		return mvaPlansFirstFlow;
	}

	public void setMvaPlansFirstFlow(boolean mvaPlansFirstFlow) {
		this.mvaPlansFirstFlow = mvaPlansFirstFlow;
	}

	public String getVzccAquisitionIndicator() {
		return vzccAquisitionIndicator;
	}

	public void setVzccAquisitionIndicator(String vzccAquisitionIndicator) {
		this.vzccAquisitionIndicator = vzccAquisitionIndicator;
	}

	public String getDispositionOptionId() {
		return dispositionOptionId;
	}

	public void setDispositionOptionId(String dispositionOptionId) {
		this.dispositionOptionId = dispositionOptionId;
	}

	public String getOriginalCreditApplicationNumber() {
		return originalCreditApplicationNumber;
	}

	public void setOriginalCreditApplicationNumber(String originalCreditApplicationNumber) {
		this.originalCreditApplicationNumber = originalCreditApplicationNumber;
	}

	private String coverageBundleName;

	public String getCoverageBundleName() { return coverageBundleName; }

	public void setCoverageBundleName(String coverageBundleName) {
		this.coverageBundleName = coverageBundleName;
	}


	private boolean isWindowFaced;

	public boolean isWindowFaced() { return isWindowFaced; }

	public void setWindowFaced(boolean windowFaced) { isWindowFaced = windowFaced; }

	public boolean isIssacPreQualifiedAndCardApproved() {
		return issacPreQualifiedAndCardApproved;
	}

	public void setIssacPreQualifiedAndCardApproved(boolean issacPreQualifiedAndCardApproved) {
		this.issacPreQualifiedAndCardApproved = issacPreQualifiedAndCardApproved;
	}

	public boolean isIssacDirectApplyAndCardApproved() {
		return issacDirectApplyAndCardApproved;
	}

	public void setIssacDirectApplyAndCardApproved(boolean issacDirectApplyAndCardApproved) {
		this.issacDirectApplyAndCardApproved = issacDirectApplyAndCardApproved;
	}

	private String addressType;

	public String getAddressType() {
		return addressType;
	}

	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}

	private String ccApplicationId;

	public String getCcApplicationId() {
		return ccApplicationId;
	}

	public void setCcApplicationId(String ccApplicationId) {
		this.ccApplicationId = ccApplicationId;
	}
	public String getActivatedESimMDN() {
		return activatedESimMDN;
	}

	public void setActivatedESimMDN(String activatedESimMDN) {
		this.activatedESimMDN = activatedESimMDN;
	}

	private String selectedStreets;

	public String getSelectedStreets() {
		return selectedStreets;
	}

	public void setSelectedStreets(String selectedStreets) {
		this.selectedStreets = selectedStreets;
	}

	public boolean isEsimEligibleIMEI() {
		return esimEligibleIMEI;
	}

	public void setEsimEligibleIMEI(boolean esimEligibleIMEI) {
		this.esimEligibleIMEI = esimEligibleIMEI;
	}

	private boolean isMucOfferApplied;

	public boolean isMucOfferApplied() {
		return isMucOfferApplied;
	}

	public void setMucOfferApplied(boolean mucOfferApplied) {
		isMucOfferApplied = mucOfferApplied;
	}

	private boolean fiveGPreOrder;
	private String fiveGPreOrderEstLaunchDate;

	public boolean isFiveGPreOrder() {
		return fiveGPreOrder;
	}

	public void setFiveGPreOrder(boolean fiveGPreOrder) {
		this.fiveGPreOrder = fiveGPreOrder;
	}

	public String getFiveGPreOrderEstLaunchDate() {
		return fiveGPreOrderEstLaunchDate;
	}

	public void setFiveGPreOrderEstLaunchDate(String fiveGPreOrderEstLaunchDate) {
		this.fiveGPreOrderEstLaunchDate = fiveGPreOrderEstLaunchDate;
	}

	public String getLineCreditClass() {
		return lineCreditClass;
	}

	public void setLineCreditClass(String lineCreditClass) {
		this.lineCreditClass = lineCreditClass;
	}
}
