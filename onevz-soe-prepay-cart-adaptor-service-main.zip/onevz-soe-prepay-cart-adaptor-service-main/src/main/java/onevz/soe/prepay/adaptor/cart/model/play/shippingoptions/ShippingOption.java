/**
 * 
 */
package onevz.soe.prepay.adaptor.cart.model.play.shippingoptions;

import java.io.Serializable;
import java.util.List;

public class ShippingOption implements Serializable {


    private String shippingHeader;//TODO::NoMapping
    private String shippingCaption;//TODO::NoMapping
	private String estimatedDeliveryDate;//TODO::Estdeldata+time->estdeldate
	private String estimatedDeliveryTime;//TODO::one more field dateText:WeekDay, Month and Date format
	private double shippingCost;//TODO::samefieldname
	private String shippingDescription;//TODO::samefieldname
	private String shippingOptionId;//TODO::samefieldname
	private String shortDescription;//TODO::samefieldname
	private String signatureRequired;//TODO::samefieldname
	private boolean active;//TODO::samefieldname
	private boolean addedShippingOptionId;//TODO::samefieldnameccccc
	private String name;//TODO::samefieldname
	private boolean priorityShippingFlag;
	private boolean defaultShipping;
	private int noOfDays;
	private String deliverySentence;
	private boolean strikeoutPriceEnabled;
	private String strikeoutPrice;

	public boolean isStrikeoutPriceEnabled() {
		return strikeoutPriceEnabled;
	}

	public void setStrikeoutPriceEnabled(boolean strikeoutPriceEnabled) {
		this.strikeoutPriceEnabled = strikeoutPriceEnabled;
	}

	public String getStrikeoutPrice() {
		return strikeoutPrice;
	}

	public void setStrikeoutPrice(String strikeoutPrice) {
		this.strikeoutPrice = strikeoutPrice;
	}

	//	private String uniqueId;
	private boolean sDDEnabled;
	private String depletionLocationCode;
	private List<AvailableDeliveryWindows> sddAvailableWindows;

	private boolean overnightShipping;//TODO::freeOvernightShipping
	private boolean twoDayShipping; //TODO::samefieldname
	private String sourceId;
	private String sddLocationSalesId;
	private double discountedShippingCost; //TODO::samefieldname and also mapto to discounted,discountexist ---:0 then set as "false" else "true"
	private boolean sddAndSetupEligible;


	public boolean isSddAndSetupEligible() {
		return sddAndSetupEligible;
	}

	public void setSddAndSetupEligible(boolean sddAndSetupEligible) {
		this.sddAndSetupEligible = sddAndSetupEligible;
	}


	public String getShippingHeader() {
		return shippingHeader;
	}

	public void setShippingHeader(String shippingHeader) {
		this.shippingHeader = shippingHeader;
	}

	public String getShippingCaption() {
		return shippingCaption;
	}

	public void setShippingCaption(String shippingCaption) {
		this.shippingCaption = shippingCaption;
	}


	public String getDepletionLocationCode() {
		return depletionLocationCode;
	}
	public void setDepletionLocationCode(String depletionLocationCode) {
		this.depletionLocationCode = depletionLocationCode;
	}
	
	public boolean issDDEnabled() {
		return sDDEnabled;
	}
	public void setsDDEnabled(boolean sDDEnabled) {
		this.sDDEnabled = sDDEnabled;
	}
	public List<AvailableDeliveryWindows> getSddAvailableWindows() {
		return sddAvailableWindows;
	}
	public void setSddAvailableWindows(List<AvailableDeliveryWindows> sddAvailableWindows) {
		this.sddAvailableWindows = sddAvailableWindows;
	}
	/**
	 * @return the estimatedDeliveryDate
	 */
	public String getEstimatedDeliveryDate() {
		return estimatedDeliveryDate;
	}
	/**
	 * @param estimatedDeliveryDate the estimatedDeliveryDate to set
	 */
	public void setEstimatedDeliveryDate(String estimatedDeliveryDate) {
		this.estimatedDeliveryDate = estimatedDeliveryDate;
	}
	/**
	 * @return the shippingCost
	 */
	public double getShippingCost() {
		return shippingCost;
	}
	/**
	 * @param shippingCost the shippingCost to set
	 */
	public void setShippingCost(double shippingCost) {
		this.shippingCost = shippingCost;
	}
	/**
	 * @return the shippingDescription
	 */
	public String getShippingDescription() {
		return shippingDescription;
	}
	/**
	 * @param shippingDescription the shippingDescription to set
	 */
	public void setShippingDescription(String shippingDescription) {
		this.shippingDescription = shippingDescription;
	}
	/**
	 * @return the shippingOptionId
	 */
	public String getShippingOptionId() {
		return shippingOptionId;
	}
	/**
	 * @param shippingOptionId the shippingOptionId to set
	 */
	public void setShippingOptionId(String shippingOptionId) {
		this.shippingOptionId = shippingOptionId;
	}
	/**
	 * @return the shortDescription
	 */
	public String getShortDescription() {
		return shortDescription;
	}
	/**
	 * @param shortDescription the shortDescription to set
	 */
	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}
	/**
	 * @return the signatureRequired
	 */
	public String getSignatureRequired() {
		return signatureRequired;
	}
	/**
	 * @param signatureRequired the signatureRequired to set
	 */
	public void setSignatureRequired(String signatureRequired) {
		this.signatureRequired = signatureRequired;
	}
	/**
	 * @return the active
	 */
	public boolean isActive() {
		return active;
	}
	/**
	 * @param active the active to set
	 */
	public void setActive(boolean active) {
		this.active = active;
	}
	/**
	 * @return the addedShippingOptionId
	 */
	public boolean isAddedShippingOptionId() {
		return addedShippingOptionId;
	}
	/**
	 * @param addedShippingOptionId the addedShippingOptionId to set
	 */
	public void setAddedShippingOptionId(boolean addedShippingOptionId) {
		this.addedShippingOptionId = addedShippingOptionId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean isPriorityShippingFlag() {
		return priorityShippingFlag;
	}
	public void setPriorityShippingFlag(boolean priorityShippingFlag) {
		this.priorityShippingFlag = priorityShippingFlag;
	}
	/**
	 * @return the estimatedDeliveryTime
	 */
	public String getEstimatedDeliveryTime() {
		return estimatedDeliveryTime;
	}
	/**
	 * @param estimatedDeliveryTime the estimatedDeliveryTime to set
	 */
	public void setEstimatedDeliveryTime(String estimatedDeliveryTime) {
		this.estimatedDeliveryTime = estimatedDeliveryTime;
	}
	/**
	 * @return the defaultShipping
	 */
	public boolean isDefaultShipping() {
		return defaultShipping;
	}
	/**
	 * @param defaultShipping the defaultShipping to set
	 */
	public void setDefaultShipping(boolean defaultShipping) {
		this.defaultShipping = defaultShipping;
	}

	public boolean isOvernightShipping() {
		return overnightShipping;
	}

	public void setOvernightShipping(boolean overnightShipping) {
		this.overnightShipping = overnightShipping;
	}

	public boolean isTwoDayShipping() {
		return twoDayShipping;
	}

	public void setTwoDayShipping(boolean twoDayShipping) {
		this.twoDayShipping = twoDayShipping;
	}

	public String getDeliverySentence() { return deliverySentence;	}

	public void setDeliverySentence(String deliverySentence) {	this.deliverySentence = deliverySentence;	}

	public int getNoOfDays() {return noOfDays;}

	public void setNoOfDays(int noOfDays) {this.noOfDays = noOfDays;}

	public String getSourceId() {
		return sourceId;
	}

	public void setSourceId(String sourceId) {
		this.sourceId = sourceId;
	}

	public String getSddLocationSalesId() {
		return sddLocationSalesId;
	}

	public void setSddLocationSalesId(String sddLocationSalesId) {
		this.sddLocationSalesId = sddLocationSalesId;
	}


	public double getDiscountedShippingCost() {
		return discountedShippingCost;
	}

	public void setDiscountedShippingCost(double discountedShippingCost) {
		this.discountedShippingCost = discountedShippingCost;
	}
}
