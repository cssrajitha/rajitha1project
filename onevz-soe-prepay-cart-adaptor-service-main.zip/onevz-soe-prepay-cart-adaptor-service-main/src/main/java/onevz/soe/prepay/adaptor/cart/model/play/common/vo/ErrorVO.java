package onevz.soe.prepay.adaptor.cart.model.play.common.vo;

/**
 * Created by vempsr2 on 5/16/2017.
 */
public class ErrorVO {
    private String errorCode;

    private String errorKey;

    private String message;

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorKey() {
        return errorKey;
    }

    public void setErrorKey(String errorKey) {
        this.errorKey = errorKey;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "ErrorVO{" +
                "errorCode='" + errorCode + '\'' +
                ", errorKey='" + errorKey + '\'' +
                ", message='" + message + '\'' +
                '}';
    }
}
