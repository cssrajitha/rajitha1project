package onevz.soe.prepay.adaptor.cart.model;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@Setter
@Getter
public class PrepaidLegacyServiceResponse {

	private Object response;
	
}
