package onevz.soe.prepay.adaptor.cart.model.play.common.vo;

/**
 * Created by vempsr2 on 3/23/2017.
 */
public class VZWResponseVO<T> {

    private String status;

    private T payload;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public T getPayload() {
        return payload;
    }

    public void setPayload(T payload) {
        this.payload = payload;
    }

    private ErrorVO errors;

    public ErrorVO getErrors() {
        return errors;
    }

    public void setErrors(ErrorVO errors) {
        this.errors = errors;
    }
}
