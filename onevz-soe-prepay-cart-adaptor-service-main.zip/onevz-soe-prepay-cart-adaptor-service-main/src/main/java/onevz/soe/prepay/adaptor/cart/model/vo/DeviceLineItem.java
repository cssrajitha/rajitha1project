package onevz.soe.prepay.adaptor.cart.model.vo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.Date;
import java.util.List;

public class DeviceLineItem extends OrderLineItem {


	/**
	 *
	 */
	private static final long serialVersionUID = 2499096805473280545L;
	private String purchasePath;
	private Integer contractTerm=0;
	private boolean isEdgeContract;
	private boolean skipProtection;
	private Date expectedShippingDate;
	private String imageUrl;
	private String miniImageUrl;
	private String color;
	private String colorCode;
	private String colorCodeName;
	private String capacity;
	private String size;
	private String planLineItemId;
	private double edgeFullRetailPrce;
	private double edgeDeviceListPrice;
	private double edgeFirstMonthAmount;
	private double edgeMonthlyAmount;
	private double edgeOriginalFirstMonthAmount;
	private double edgeOriginalMonthlyAmount;
    private double edgeDiscountedFrp;
	private String priceListId;
	private double itemDownPayment;
	private String bogoType;
	private double barCodeDiscount;
	private String recycleStateInd;
	private String year;
	private String make;
	private String model;
	private String email;
	@JsonIgnore
	private String nickname;
	private boolean isFeaturesAvailble;
	private MdnStackingOfferTypeVO mdnStackingOfferTypeVO;
	private String computeOfferLineNum;
	private boolean warning;
	private String numberShareIndicator;
	private boolean graftActionChanged;
	private String deviceDescription;

	private String installtionType;
	private boolean homePhoneDeviceService;
	private boolean  wirelessDevice;

	public boolean isHomePhoneDeviceService() {
		return homePhoneDeviceService;
	}

	public void setHomePhoneDeviceService(boolean homePhoneDeviceService) {
		this.homePhoneDeviceService = homePhoneDeviceService;
	}

	public String getInstalltionType() {
		return installtionType;
	}

	public void setInstalltionType(String installtionType) {
		this.installtionType = installtionType;
	}

	private String dmdDeviceSorId;

	private String loanTerm;

	public String getLoanTerm() {
		return loanTerm;
	}

	public void setLoanTerm(String loanTerm) {
		this.loanTerm = loanTerm;
	}

	public boolean isWarning() {
		return warning;
	}

	public void setWarning(boolean warning) {
		this.warning = warning;
	}
	private boolean downgradePlan;
	public boolean isDowngradePlan() {
		return downgradePlan;
	}

	public void setDowngradePlan(boolean downgradePlan) {
		this.downgradePlan = downgradePlan;
	}

	public String getComputeOfferLineNum() {
		return computeOfferLineNum;
	}

	public void setComputeOfferLineNum(String computeOfferLineNum) {
		this.computeOfferLineNum = computeOfferLineNum;
	}

	public MdnStackingOfferTypeVO getMdnStackingOfferTypeVO() {
		return mdnStackingOfferTypeVO;
	}

	public void setMdnStackingOfferTypeVO(MdnStackingOfferTypeVO mdnStackingOfferTypeVO) {
		this.mdnStackingOfferTypeVO = mdnStackingOfferTypeVO;
	}

	public String getvModel() {
		return vModel;
	}

	public void setvModel(String vModel) {
		this.vModel = vModel;
	}


	public String getvColor() {
		return vColor;
	}

	public void setvColor(String vColor) {
		this.vColor = vColor;
	}

	public String getvEmail() {
		return vEmail;
	}

	public void setvEmail(String vEmail) {
		this.vEmail = vEmail;
	}
	
	public String getDmdDeviceSorId() {
          return dmdDeviceSorId;
       }

       public void setDmdDeviceSorId(String dmdDeviceSorId) {
               this.dmdDeviceSorId = dmdDeviceSorId;
       }

	private String vColor;
	private String vEmail;

	public String getvYear() {
		return vYear;
	}

	public void setvYear(String vYear) {
		this.vYear = vYear;
	}

	private String vYear;
	private String vModel;
	private String vMake;

	public String getvMake() {
		return vMake;
	}

	public void setvMake(String vMake) {
		this.vMake = vMake;
	}


	private String npanxxCode;
	private String mtnNumber;
	//For express store full 10 digit mtn
	private String ngpOut;
	private String minOut;

	private double upgradeFee;
	private double activationFee;
	private boolean cpe;
	private double recycleCreditAllocatedAmount;
	private InstallmentContractDetails installmentContractDetails;
	private String simId;
	private String imei;
	private String idType;
	//changes for trade in pricing
	private double monthlyCredit;
	private double monthlyDiscount;
	private List<VisionFeatures> visionFeatureList;
	private ContactInfo serviceAddress;
	private String dacc;
	private SimLineItem simItem;
	private String billingSystem;
	private NumberPortabilityVO numberPortabilityVO;
	private Date lastModifiedDate;
	private int securityDeposit;
	private String securityDepositWaiveCode;
	private boolean waiveActivationFees;
	private String stackableDataPromoCorrelationId;
	private String meaCode;
	private String upgradeReasonCodes;
	private String oldEsnNumber;
	private boolean network4gIndicator;
	private String minNumber;
	private String transferredFromMtn;
	private boolean twoDUpgradeItem;
	private String existingDeviceSorId;
	private Double twoDUpgradeDownpaymentPercentage;
	private boolean edgeUpBuyOutFlag;
	private EdgeUpDetails edgeUpDetails;
	private Double edgeupAmount;
	private Double edgeBuyoutAmount;
	private String upgradeOptionCode;
	private List<PromoBadgeMessage> promoBadgeMessages;
	private String offerType;
	private String downPaymentPercentage;
	private boolean edgeEligibleInd;
	private String deviceType;
	private String deviceManufacturerName;
	private BuyOutDetails buyOutDetails;
	private DevicePaymentConfig devicePaymentConfig;
	private String itemCost;
	//bill_to_acc_eligible_flag
	private boolean BTAEligibileFlag;

	private String trunkMTN;
	private String branchMTN;
	private String mldTrunkMTN;
	private String graftAction;
	private String shipCommitInd;

	private boolean numberShareCapable;
	private boolean sorHdVoiceInd;
	private boolean e911_addr_ind;
	private String brandName;
	private String sorDeviceCategory;
	private String deviceTypeIndicator;
	private boolean sameDayDelivery;

	private boolean appleCareFeatureAdded;

	private boolean isCnIdCapable;
	private boolean isSafeWifiEligible;
	private String cnIdCapableDesc;
	private String safeWifiEligibleDesc;

	private String numberShareHeader;
	private String nsHeaderTooltip;

	private List<String> dacc_ra_grp_cd;

	private String dsEs12Fqdn;
	private boolean eSimIndicator;
	private boolean qrScanNeededForEsimActivation;
	private boolean eSimEligible;

	public boolean isAnchorable() {
		return anchorable;
	}

	public void setAnchorable(boolean anchorable) {
		this.anchorable = anchorable;
	}

	public boolean isAnchorRequired() {
		return anchorRequired;
	}

	public void setAnchorRequired(boolean anchorRequired) {
		this.anchorRequired = anchorRequired;
	}

	private boolean anchorable;
	private boolean anchorRequired;

	public boolean iseSimEligible() {
		return eSimEligible;
	}

	public void seteSimEligible(boolean eSimEligible) {
		this.eSimEligible = eSimEligible;
	}

	public boolean iseSimIndicator() {
		return eSimIndicator;
	}

	public void seteSimIndicator(boolean eSimIndicator) {
		this.eSimIndicator = eSimIndicator;
	}

	public boolean isQrScanNeededForEsimActivation() {
		return qrScanNeededForEsimActivation;
	}

	public void setQrScanNeededForEsimActivation(boolean qrScanNeededForEsimActivation) {
		this.qrScanNeededForEsimActivation = qrScanNeededForEsimActivation;
	}

	public String getDsEs12Fqdn() {
		return dsEs12Fqdn;
	}

	public void setDsEs12Fqdn(String dsEs12Fqdn) {
		this.dsEs12Fqdn = dsEs12Fqdn;
	}

	public String getNumberShareHeader() {
		return numberShareHeader;
	}

	public void setNumberShareHeader(String numberShareHeader) {
		this.numberShareHeader = numberShareHeader;
	}

	public String getNsHeaderTooltip() {
		return nsHeaderTooltip;
	}

	public void setNsHeaderTooltip(String nsHeaderTooltip) {
		this.nsHeaderTooltip = nsHeaderTooltip;
	}

	public boolean isCnIdCapable() {
		return isCnIdCapable;
	}

	public void setCnIdCapable(boolean cnIdCapable) {
		isCnIdCapable = cnIdCapable;
	}

	public boolean isSafeWifiEligible() {
		return isSafeWifiEligible;
	}

	public void setSafeWifiEligible(boolean safeWifiEligible) {
		isSafeWifiEligible = safeWifiEligible;
	}

	public String getTotalNumberShareExtension() {
		return totalNumberShareExtension;
	}

	public void setTotalNumberShareExtension(String totalNumberShareExtension) {
		this.totalNumberShareExtension = totalNumberShareExtension;
	}

	private double appleCareFeaturePrce;
	private String dppAgreementText;
	private String dppAgreementDeviceName;
	private String phoneNumber;
	private String operatingSystem;
	private List<String> connectedWatchSupportedOs;

	private String salesId;
	private boolean newSimAdded;

	private String totalNumberShareExtension;


	private boolean edgeTNCAccepted;

	private boolean isPortinLater;

	private boolean isNewPortInNumber;
	private String portInNumber;
	private String portInNumberType;



	public boolean isPortinLater() {
		return isPortinLater;
	}

	public void setPortinLater(boolean portinLater) {
		isPortinLater = portinLater;
	}

	public boolean isEdgeTNCAccepted() {
		return edgeTNCAccepted;
	}

	public void setEdgeTNCAccepted(boolean edgeTNCAccepted) {
		this.edgeTNCAccepted = edgeTNCAccepted;
	}

	public boolean isNewSimAdded() {
		return newSimAdded;
	}

	public void setNewSimAdded(boolean newSimAdded) {
		this.newSimAdded = newSimAdded;
	}

	public String getSalesId() {return salesId;}

	public void setSalesId(String salesId) {this.salesId = salesId;}

	private String prodName;
	private String manufacturerCode;
	private Boolean newNumberSelected;
	private String estimatedArivalDate;
	private String iphoneShareId;

	public double getVoluntaryDownpayment() {
		return voluntaryDownpayment;
	}

	public void setVoluntaryDownpayment(double voluntaryDownpayment) {
		this.voluntaryDownpayment = voluntaryDownpayment;
	}

	private double voluntaryDownpayment;

	public boolean isSmartImeFlow() {
		return smartImeFlow;
	}

	public void setSmartImeFlow(boolean smartImeFlow) {
		this.smartImeFlow = smartImeFlow;
	}

	private String numbersharedDeviceId;
    private boolean smartImeFlow;
	private DeviceCondition deviceCondition;

	public String getIphoneShareId() {
		return iphoneShareId;
	}

	public void setIphoneShareId(String iphoneShareId) {
		this.iphoneShareId = iphoneShareId;
	}

	public String getColorCode() {
		return colorCode;
	}

	public void setColorCode(String colorCode) {
		this.colorCode = colorCode;
	}

	public String getColorCodeName() {
		return colorCodeName;
	}

	public void setColorCodeName(String colorCodeName) {
		this.colorCodeName = colorCodeName;
	}

	public String getDeviceTypeIndicator() {
		return deviceTypeIndicator;
	}

	public void setDeviceTypeIndicator(String deviceTypeIndicator) {
		this.deviceTypeIndicator = deviceTypeIndicator;
	}

	public String getMiniImageUrl() {
		return miniImageUrl;
	}

	public void setMiniImageUrl(String miniImageUrl) {
		this.miniImageUrl = miniImageUrl;
	}

	public boolean isSameDayDelivery() {
		return sameDayDelivery;
	}

	public void setSameDayDelivery(boolean sameDayDelivery) {
		this.sameDayDelivery = sameDayDelivery;
	}

	public String getGraftAction() {
		return graftAction;
	}

	public void setGraftAction(String graftAction) {
		this.graftAction = graftAction;
	}

	public String getTrunkMTN() {
		return trunkMTN;
	}

	public void setTrunkMTN(String trunkMTN) {
		this.trunkMTN = trunkMTN;
	}

	public String getBranchMTN() {
		return branchMTN;
	}

	public void setBranchMTN(String branchMTN) {
		this.branchMTN = branchMTN;
	}


	public InstallmentContractDetails getInstallmentContractDetails() {
		return installmentContractDetails;
	}

	public void setInstallmentContractDetails(InstallmentContractDetails installmentContractDetails) {
		this.installmentContractDetails = installmentContractDetails;
	}

	public DeviceLineItem(String id) {
		this.setId(id);
	}

	public DeviceLineItem() {
	}

	public double getUpgradeFee() {
		return upgradeFee;
	}

	public void setUpgradeFee(double upgradeFee) {
		this.upgradeFee = upgradeFee;
	}

	public double getActivationFee() {
		return activationFee;
	}

	public void setActivationFee(double activationFee) {
		this.activationFee = activationFee;
	}

	public String getMtnNumber() {
		return mtnNumber;
	}

	public void setMtnNumber(String mtnNumber) {
		this.mtnNumber = mtnNumber;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getCapacity() {
		return capacity;
	}

	public void setCapacity(String capacity) {
		this.capacity = capacity;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	private String flow;


	public String getPurchasePath() {
		return purchasePath;
	}

	public void setPurchasePath(String purchasePath) {
		this.purchasePath = purchasePath;
	}

	public Integer getContractTerm() {
		if(contractTerm == null) {
			contractTerm = 0;
		}
		return contractTerm;
	}

	public void setContractTerm(Integer contractTerm) {
		this.contractTerm = contractTerm;
	}

	public String getFlow() {
		return flow;
	}

	public void setFlow(String flow) {
		this.flow = flow;
	}

	public boolean isEdgeContract() {
		return isEdgeContract;
	}

	public void setEdgeContract(boolean isEdgeContract) {
		this.isEdgeContract = isEdgeContract;
	}

	public Date getExpectedShippingDate() {
		return expectedShippingDate;
	}

	public void setExpectedShippingDate(Date expectedShippingDate) {
		this.expectedShippingDate = expectedShippingDate;
	}


	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public String getPlanLineItemId() {
		return planLineItemId;
	}

	public void setPlanLineItemId(String planLineItemId) {
		this.planLineItemId = planLineItemId;
	}

	public double getEdgeFullRetailPrce() {
		return edgeFullRetailPrce;
	}

	public void setEdgeFullRetailPrce(double edgeFullRetailPrce) {
		this.edgeFullRetailPrce = edgeFullRetailPrce;
	}

	public double getEdgeDeviceListPrice() {
		return edgeDeviceListPrice;
	}

	public void setEdgeDeviceListPrice(double edgeDeviceListPrice) {
		this.edgeDeviceListPrice = edgeDeviceListPrice;
	}

	public double getEdgeFirstMonthAmount() {
		return edgeFirstMonthAmount;
	}

	public void setEdgeFirstMonthAmount(double edgeFirstMonthAmount) {
		this.edgeFirstMonthAmount = edgeFirstMonthAmount;
	}

	public double getEdgeMonthlyAmount() {
		return edgeMonthlyAmount;
	}

	public void setEdgeMonthlyAmount(double edgeMonthlyAmount) {
		this.edgeMonthlyAmount = edgeMonthlyAmount;
	}


	public String getPriceListId() {
		return priceListId;
	}

	public void setPriceListId(String priceListId) {
		this.priceListId = priceListId;
	}

	public double getItemDownPayment() {
		return itemDownPayment;
	}

	public void setItemDownPayment(double itemDownPayment) {
		this.itemDownPayment = itemDownPayment;
	}


	public String getBogoType() {
		return bogoType;
	}

	public void setBogoType(String bogoType) {
		this.bogoType = bogoType;
	}

	public double getBarCodeDiscount() {
		return barCodeDiscount;
	}

	public void setBarCodeDiscount(double barCodeDiscount) {
		this.barCodeDiscount = barCodeDiscount;
	}

	public String getRecycleStateInd() {
		return recycleStateInd;
	}

	public void setRecycleStateInd(String recycleStateInd) {
		this.recycleStateInd = recycleStateInd;
	}

	public String getNpanxxCode() {
		return npanxxCode;
	}

	public void setNpanxxCode(String npanxxCode) {
		this.npanxxCode = npanxxCode;
	}


	public boolean isCpe() {
		return cpe;
	}

	public void setCpe(boolean cpe) {
		this.cpe = cpe;
	}



	public String getSimId() {
		return simId;
	}

	public void setSimId(String simId) {
		this.simId = simId;
	}

	public String getImei() {
		return imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}

	public double getRecycleCreditAllocatedAmount() {
		return recycleCreditAllocatedAmount;
	}

	public void setRecycleCreditAllocatedAmount(double recycleCreditAllocatedAmount) {
		this.recycleCreditAllocatedAmount = recycleCreditAllocatedAmount;
	}

	public double getMonthlyCredit() {
		return monthlyCredit;
	}

	public void setMonthlyCredit(double monthlyCredit) {
		this.monthlyCredit = monthlyCredit;
	}

	public SimLineItem getSimItem() {
		return simItem;
	}

	public void addSimItem(SimLineItem simItem) {
		this.simItem = simItem;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Id:" + getId()).append('\n').append("priceListId:" + getPriceListId()).append('\n')
				.append("RecycleStateInd:" + getRecycleStateInd()).append('\n').append("BogoType:" + getBogoType())
				.append('\n').append("capacity:" + getCapacity()).append('\n').append("Color:" + getColor())
				.append('\n').append("Email:" + getEmail()).append('\n').append("flow:" + getFlow()).append('\n')
				.append("ImageUrl:" + getImageUrl()).append('\n').append("Make:" + getMake()).append('\n')
				.append("Model:" + getModel()).append('\n').append("PlanLineItemId:" + getPlanLineItemId()).append('\n')
				.append("PurchasePath:" + getPurchasePath()).append('\n').append("year:" + getYear()).append('\n')
				.append("DisplayName:" + getDisplayName()).append('\n').append("OrderId:" + getOrderId()).append('\n')
				.append("ProductId:" + getProductId()).append('\n').append("SkuId:" + getSkuId());
		return builder.toString();
	}

	@Override
	public boolean equals(Object deviceLineItem){
		if (!(deviceLineItem instanceof DeviceLineItem)) {
			return false;
		}
		return this.getId() == null ? false : this.getId().equalsIgnoreCase(((DeviceLineItem)deviceLineItem).getId());
	}

	@Override
	public int hashCode() {
		return this.getId().hashCode();
	}

	public List<VisionFeatures> getVisionFeatureList() {
		return visionFeatureList;
	}

	public void setVisionFeatureList(List<VisionFeatures> visionFeatureList) {
		this.visionFeatureList = visionFeatureList;
	}

	public ContactInfo getServiceAddress() {
		return serviceAddress;
	}

	public void setServiceAddress(ContactInfo serviceAddress) {
		this.serviceAddress = serviceAddress;
	}

	public String getDacc() {
		return dacc;
	}

	public void setDacc(String dacc) {
		this.dacc = dacc;
	}

	public String getBillingSystem() {
		return billingSystem;
	}

	public void setBillingSystem(String billingSystem) {
		this.billingSystem = billingSystem;
	}

	public NumberPortabilityVO getNumberPortabilityVO() {
		return numberPortabilityVO;
	}

	public void setNumberPortabilityVO(NumberPortabilityVO numberPortabilityVO) {
		this.numberPortabilityVO = numberPortabilityVO;
	}


	/**
	 * @return the lastModifiedDate
	 */
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	/**
	 * @param lastModifiedDate the lastModifiedDate to set
	 */
	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public int getSecurityDeposit() {
		return securityDeposit;
	}

	public void setSecurityDeposit(int securityDeposit) {
		this.securityDeposit = securityDeposit;
	}

	public String getSecurityDepositWaiveCode() {
		return securityDepositWaiveCode;
	}

	public void setSecurityDepositWaiveCode(String securityDepositWaiveCode) {
		this.securityDepositWaiveCode = securityDepositWaiveCode;
	}

	public void setSimItem(SimLineItem simItem) {
		this.simItem = simItem;
	}

	public String getIdType() {
		return idType;
	}

	public void setIdType(String idType) {
		this.idType = idType;
	}

	public boolean isWaiveActivationFees() {
		return waiveActivationFees;
	}

	public void setWaiveActivationFees(boolean waiveActivationFees) {
		this.waiveActivationFees = waiveActivationFees;
	}

	public String getStackableDataPromoCorrelationId() {
		return stackableDataPromoCorrelationId;
	}

	public void setStackableDataPromoCorrelationId(String stackableDataPromoCorrelationId) {
		this.stackableDataPromoCorrelationId = stackableDataPromoCorrelationId;
	}

	/**
	 * @return the meaCode
	 */
	public String getMeaCode() {
		return meaCode;
	}

	/**
	 * @param meaCode the meaCode to set
	 */
	public void setMeaCode(String meaCode) {
		this.meaCode = meaCode;
	}

	/**
	 * @return the upgradeReasonCodes
	 */
	public String getUpgradeReasonCodes() {
		return upgradeReasonCodes;
	}

	/**
	 * @param upgradeReasonCodes the upgradeReasonCodes to set
	 */
	public void setUpgradeReasonCodes(String upgradeReasonCodes) {
		this.upgradeReasonCodes = upgradeReasonCodes;
	}

	/**
	 * @return the oldEsnNumber
	 */
	public String getOldEsnNumber() {
		return oldEsnNumber;
	}

	/**
	 * @param oldEsnNumber the oldEsnNumber to set
	 */
	public void setOldEsnNumber(String oldEsnNumber) {
		this.oldEsnNumber = oldEsnNumber;
	}

	/**
	 * @return the network4gIndicator
	 */
	public boolean isNetwork4gIndicator() {
		return network4gIndicator;
	}

	/**
	 * @param network4gIndicator the network4gIndicator to set
	 */
	public void setNetwork4gIndicator(boolean network4gIndicator) {
		this.network4gIndicator = network4gIndicator;
	}

	/**
	 * @return the minNumber
	 */
	public String getMinNumber() {
		return minNumber;
	}

	/**
	 * @param minNumber the minNumber to set
	 */
	public void setMinNumber(String minNumber) {
		this.minNumber = minNumber;
	}

	/**
	 * @return the transferredFromMtn
	 */
	public String getTransferredFromMtn() {
		return transferredFromMtn;
	}

	/**
	 * @param transferredFromMtn the transferredFromMtn to set
	 */
	public void setTransferredFromMtn(String transferredFromMtn) {
		this.transferredFromMtn = transferredFromMtn;
	}

	/**
	 * @return the twoDUpgradeItem
	 */
	public boolean isTwoDUpgradeItem() {
		return twoDUpgradeItem;
	}

	/**
	 * @param twoDUpgradeItem the twoDUpgradeItem to set
	 */
	public void setTwoDUpgradeItem(boolean twoDUpgradeItem) {
		this.twoDUpgradeItem = twoDUpgradeItem;
	}

	/**
	 * @return the existingDeviceSorId
	 */
	public String getExistingDeviceSorId() {
		return existingDeviceSorId;
	}

	/**
	 * @param existingDeviceSorId the existingDeviceSorId to set
	 */
	public void setExistingDeviceSorId(String existingDeviceSorId) {
		this.existingDeviceSorId = existingDeviceSorId;
	}

	/**
	 * @return the twoDUpgradeDownpaymentPercentage
	 */
	public Double getTwoDUpgradeDownpaymentPercentage() {
		if(twoDUpgradeDownpaymentPercentage != null){
			return twoDUpgradeDownpaymentPercentage;
		}else{
			return 0.0D;
		}
	}

	/**
	 * @param twoDUpgradeDownpaymentPercentage the twoDUpgradeDownpaymentPercentage to set
	 */
	public void setTwoDUpgradeDownpaymentPercentage(Double twoDUpgradeDownpaymentPercentage) {
		this.twoDUpgradeDownpaymentPercentage = twoDUpgradeDownpaymentPercentage;
	}

	/**
	 * @return the edgeUpBuyOutFlag
	 */
	public boolean isEdgeUpBuyOutFlag() {
		return edgeUpBuyOutFlag;
	}

	/**
	 * @param edgeUpBuyOutFlag the edgeUpBuyOutFlag to set
	 */
	public void setEdgeUpBuyOutFlag(boolean edgeUpBuyOutFlag) {
		this.edgeUpBuyOutFlag = edgeUpBuyOutFlag;
	}

	/**
	 * @return the edgeUpDetails
	 */
	public EdgeUpDetails getEdgeUpDetails() {
		return edgeUpDetails;
	}

	/**
	 * @param edgeUpDetails the edgeUpDetails to set
	 */
	public void setEdgeUpDetails(EdgeUpDetails edgeUpDetails) {
		this.edgeUpDetails = edgeUpDetails;
	}

	/**
	 * @return the edgeupAmount
	 */
	public Double getEdgeupAmount() {
		if(edgeupAmount != null){
			return edgeupAmount;
		}else{
			return 0.0D;
		}
	}

	/**
	 * @param edgeupAmount the edgeupAmount to set
	 */
	public void setEdgeupAmount(Double edgeupAmount) {
		this.edgeupAmount = edgeupAmount;
	}

	/**
	 * @return the edgeBuyoutAmount
	 */
	public Double getEdgeBuyoutAmount() {
		if(edgeBuyoutAmount != null){
			return edgeBuyoutAmount;
		}else{
			return 0.0D;
		}
	}

	/**
	 * @param edgeBuyoutAmount the edgeBuyoutAmount to set
	 */
	public void setEdgeBuyoutAmount(Double edgeBuyoutAmount) {
		this.edgeBuyoutAmount = edgeBuyoutAmount;
	}

	@JsonIgnore
	public boolean isEdgeUp() {
		boolean isEdgeUp = false;
		if ((getEupEdgeType() == 1) || (getEupEdgeType() == 8)) {
			isEdgeUp = true;
		}
		return isEdgeUp;
	}

	private int getEupEdgeType() {
		int eupFlavour = 0;
		if (VZWPurchasePathEnum.EUP.toString().equals(getPurchasePath())) {
			if (VZWCommonConstants.EDGE_TO_EDGE_UPG_REA_CODE.equalsIgnoreCase(getUpgradeReasonCodes())) {
				eupFlavour = 1; // EDGE UPGRADE flow -> upgradeReasonCode == TA
			} else if (VZWCommonConstants.EARLY_EDGE_UPG_REA_CODE.equalsIgnoreCase(getUpgradeReasonCodes())) {
				eupFlavour = 2; // EARLY EDGE flow -> upgradeReasonCode == SA
			} else if (isEdgeContract() && VZWCommonConstants.EDGE_UPG_REA_CODE.equalsIgnoreCase(getUpgradeReasonCodes())) {
				eupFlavour = 3; // Native EDGE flow -> upgradeReasonCode == EA
			} else if (VZWCommonConstants.MONTH_TO_MONTH_UPG_REA_CODE.equalsIgnoreCase(getUpgradeReasonCodes())) {
				eupFlavour = 4; // EUP Month-To-Month flow -> upgradeReasonCode == UN
			} else if (VZWCommonConstants.MONTH_TO_MONTH_CERTIFIED_PRE_OWNED_UPG_REA_CODE.equalsIgnoreCase(getUpgradeReasonCodes())) {
				eupFlavour = 5; // EUP Month-To-Month With Certified Pre Owned device flow -> upgradeReasonCode == CP
			} else if (VZWCommonConstants.EARLY_UPG_REA_CODE.equalsIgnoreCase(getUpgradeReasonCodes())) {
				eupFlavour = 6; // EARLY UPGRADE flow -> upgradeReasonCode == E2
			} else if (VZWCommonConstants.EDGE_TO_TWOYR_UPG_REA_CODE.equalsIgnoreCase(getUpgradeReasonCodes())) {
				eupFlavour = 8;// EDGE TO TWO YEAR PRICE UPGRADE -> upgradeReasonCode == T2
			} else if (VZWCommonConstants.EARLY_EDGE_UPG_REA_CODE_SC.equalsIgnoreCase(getUpgradeReasonCodes())) {
				eupFlavour = 9;// EARLY EDGE flow -> upgradeReasonCode == SC
			} else if (VZWCommonConstants.EARLY_EDGE_UPG_REA_CODE_EC.equalsIgnoreCase(getUpgradeReasonCodes())) {
				eupFlavour = 10;// EARLY EDGE flow -> upgradeReasonCode == EC
			} else if (VZWCommonConstants.EDGE_2D_UPG_REA_CODE.equalsIgnoreCase(getUpgradeReasonCodes())) {
				eupFlavour = 11;// ALWAYS ELIGIBLE flow -> upgradeReasonCode == AA
			} else {
				eupFlavour = 7; // Regular EUP flow
			}
		}
		return eupFlavour;
	}

	@JsonIgnore
	public boolean isNativeEdge(){
		boolean isNativeEdge = false;
		if ((VZWPurchasePathEnum.EUP.toString().equals(getPurchasePath()))&&(getEupEdgeType() == 3 || getEupEdgeType() == 10)) {

				isNativeEdge = true;

		}
		return isNativeEdge;
	}

	@JsonIgnore
	public boolean isEarlyEdge() {
		boolean isEarlyEdge = false;
		if (getEupEdgeType() == 2 || getEupEdgeType() == 9) {
			isEarlyEdge = true;
		}
		return isEarlyEdge;
	}

	@JsonIgnore
	public boolean isApplyUpgradeFee() {
		boolean applyUpgradeFee = true;
		if(5 == getEupEdgeType()){
			applyUpgradeFee = false;
		}
		return applyUpgradeFee;
	}

	@JsonIgnore
	public boolean isMonthtoMonth() {
		boolean isMonthtoMonth = false;
		if (getEupEdgeType() == 4) {
			isMonthtoMonth = true;
		}
		return isMonthtoMonth;
	}

	@JsonIgnore
	public boolean isRegularEUP() {
		boolean isRegularEUP = false;
		if (getEupEdgeType() == 7) {
			isRegularEUP = true;
		}
		return isRegularEUP;
	}

	@JsonIgnore
	public boolean isEarlyUpgrade() {
		boolean isEarlyUpgrade = false;
		if (getEupEdgeType() == 6) {
			isEarlyUpgrade = true;
		}
		return isEarlyUpgrade;
	}

	/**
	 * @return the upgradeOptionCode
	 */
	public String getUpgradeOptionCode() {
		return upgradeOptionCode;
	}

	/**
	 * @param upgradeOptionCode the upgradeOptionCode to set
	 */
	public void setUpgradeOptionCode(String upgradeOptionCode) {
		this.upgradeOptionCode = upgradeOptionCode;
	}

	/**
	 * It returns flag to identify whether the device config item is Always Eligible or Not
	 *
	 * @return boolean : isAlwaysEligible
	 */

	@JsonIgnore
	public boolean isAlwaysEligible() {
		boolean isAlwaysEligible = false;
		if (getEupEdgeType() == 11) {
			isAlwaysEligible = true;
		}
		return isAlwaysEligible;
	}

	public List<PromoBadgeMessage> getPromoBadgeMessages() {
		return promoBadgeMessages;
	}

	public void setPromoBadgeMessages(List<PromoBadgeMessage> promoBadgeMessages) {
		this.promoBadgeMessages = promoBadgeMessages;
	}

	public String getOfferType() {
		return offerType;
	}

	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}

	public String getDownPaymentPercentage() {
		return downPaymentPercentage;
	}

	public void setDownPaymentPercentage(String downPaymentPercentage) {
		this.downPaymentPercentage = downPaymentPercentage;
	}

	private String dmdDeviceCategory;

	public String getDmdDeviceCategory() {
		return dmdDeviceCategory;
	}

	public void setDmdDeviceCategory(String dmdDeviceCategory) {
		this.dmdDeviceCategory = dmdDeviceCategory;
	}

	private List<String> userRemovedExistingFeatures;

	public List<String> getUserRemovedExistingFeatures() {
		return userRemovedExistingFeatures;
	}

	public void setUserRemovedExistingFeatures(List<String> userRemovedExistingFeatures) {
		this.userRemovedExistingFeatures = userRemovedExistingFeatures;
	}

	public boolean isEdgeEligibleInd() {
		return edgeEligibleInd;
	}

	public void setEdgeEligibleInd(boolean edgeEligibleInd) {
		this.edgeEligibleInd = edgeEligibleInd;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public String getDeviceManufacturerName() {
		return deviceManufacturerName;
	}

	public void setDeviceManufacturerName(String deviceManufacturerName) {
		this.deviceManufacturerName = deviceManufacturerName;
	}

	public BuyOutDetails getBuyOutDetails() {
		return buyOutDetails;
	}

	public void setBuyOutDetails(BuyOutDetails buyOutDetails) {
		this.buyOutDetails = buyOutDetails;
	}

	public DevicePaymentConfig getDevicePaymentConfig() {
		return devicePaymentConfig;

	}

	public void setDevicePaymentConfig(DevicePaymentConfig devicePaymentConfig) {
		this.devicePaymentConfig = devicePaymentConfig;
	}

	public String getItemCost() {
		return itemCost;
	}

	public void setItemCost(String itemCost) {
		this.itemCost = itemCost;
	}

	public boolean isBTAEligibileFlag() {
		return BTAEligibileFlag;
	}

	public void setBTAEligibileFlag(boolean BTAEligibileFlag) {
		this.BTAEligibileFlag = BTAEligibileFlag;
	}

	public E911AddressDetails getE911AddressDetails() {
		return e911AddressDetails;
	}

	public void setE911AddressDetails(E911AddressDetails e911AddressDetails) {
		this.e911AddressDetails = e911AddressDetails;
	}

	private E911AddressDetails e911AddressDetails;

	private boolean isNumberShare;

	public boolean isNumberShare() {
		return isNumberShare;
	}

	public void setNumberShare(boolean numberShare) {
		isNumberShare = numberShare;
	}

	public boolean isE911_addr_ind() {
		return e911_addr_ind;
	}
	public void setE911_addr_ind(boolean e911_addr_ind) {
		this.e911_addr_ind = e911_addr_ind;
	}

	private boolean rio;
	private boolean gs3;
	private boolean gs4;
	private boolean dubs;
	private boolean gs4CompatibleDevice;

	public boolean isGs4CompatibleDevice() {
		return gs4CompatibleDevice;
	}

	public void setGs4CompatibleDevice(boolean gs4CompatibleDevice) {
		this.gs4CompatibleDevice = gs4CompatibleDevice;
	}

	public boolean isGs3() {
		return gs3;
	}

	public void setGs3(boolean gs3) {
		this.gs3 = gs3;
	}

	public boolean isGs4() {
		return gs4;
	}

	public void setGs4(boolean gs4) {
		this.gs4 = gs4;
	}

	public boolean isDubs() {
		return dubs;
	}

	public void setDubs(boolean dubs) {
		this.dubs = dubs;
	}

	public boolean isRio() {
		return rio;
	}

	public void setRio(boolean rio) {
		this.rio = rio;
	}

	private String hostCommerceItemId;

	public String getHostCommerceItemId() {
		return hostCommerceItemId;
	}

	public void setHostCommerceItemId(String hostCommerceItemId) {
		this.hostCommerceItemId = hostCommerceItemId;
	}


	public List<VZWPromotion> getPromotions() {
		return promotions;
	}

	public void setPromotions(List<VZWPromotion> promotions) {
		this.promotions = promotions;
	}

	private List<VZWPromotion> promotions;

	public List<VZWSbdOffer> getVzwSbdOfferlist() {
		return vzwSbdOfferlist;
	}

	public void setVzwSbdOfferlist(List<VZWSbdOffer> vzwSbdOfferlist) {
		this.vzwSbdOfferlist = vzwSbdOfferlist;
	}

	private List<VZWSbdOffer> vzwSbdOfferlist;

	public String getShipCommitInd() {
		return shipCommitInd;
	}

	public void setShipCommitInd(String shipCommitInd) {
		this.shipCommitInd = shipCommitInd;
	}

	public String getMldTrunkMTN() { return mldTrunkMTN; }

	public void setMldTrunkMTN(String mldTrunkMTN) { this.mldTrunkMTN = mldTrunkMTN; }

	public boolean isNumberShareCapable() { return numberShareCapable; }

	public void setNumberShareCapable(boolean numberShareCapable) { this.numberShareCapable = numberShareCapable; }

	public boolean isSorHdVoiceInd() { return sorHdVoiceInd; }

	public void setSorHdVoiceInd(boolean sorHdVoiceInd) { this.sorHdVoiceInd = sorHdVoiceInd; }

	public String getBrandName() { return brandName; }

	public void setBrandName(String brandName) { this.brandName = brandName; }

	public String getSorDeviceCategory() { return sorDeviceCategory; }

	public void setSorDeviceCategory(String sorDeviceCategory) { this.sorDeviceCategory = sorDeviceCategory; }

	public double getEdgeOriginalFirstMonthAmount() {
		return edgeOriginalFirstMonthAmount;
	}

	public void setEdgeOriginalFirstMonthAmount(double edgeOriginalFirstMonthAmount) {
		this.edgeOriginalFirstMonthAmount = edgeOriginalFirstMonthAmount;
	}

	public double getEdgeOriginalMonthlyAmount() {
		return edgeOriginalMonthlyAmount;
	}

	public void setEdgeOriginalMonthlyAmount(double edgeOriginalMonthlyAmount) {
		this.edgeOriginalMonthlyAmount = edgeOriginalMonthlyAmount;
	}

	public boolean isAppleCareFeatureAdded() {
		return appleCareFeatureAdded;
	}

	public void setAppleCareFeatureAdded(boolean appleCareFeatureAdded) {
		this.appleCareFeatureAdded = appleCareFeatureAdded;
	}

	public double getAppleCareFeaturePrce() {
		return appleCareFeaturePrce;
	}

	public void setAppleCareFeaturePrce(double appleCareFeaturePrce) {
		this.appleCareFeaturePrce = appleCareFeaturePrce;
	}

	public String getDppAgreementText() {
		return dppAgreementText;
	}

	public void setDppAgreementText(String dppAgreementText) {
		this.dppAgreementText = dppAgreementText;
	}

	public String getDppAgreementDeviceName() {
		return dppAgreementDeviceName;
	}

	public void setDppAgreementDeviceName(String dppAgreementDeviceName) {
		this.dppAgreementDeviceName = dppAgreementDeviceName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getOperatingSystem() {
		return operatingSystem;
	}

	public void setOperatingSystem(String operatingSystem) {
		this.operatingSystem = operatingSystem;
	}

	public double getEdgeDiscountedFrp() {
		return edgeDiscountedFrp;
	}

	public void setEdgeDiscountedFrp(double edgeDiscountedFrp) {
		this.edgeDiscountedFrp = edgeDiscountedFrp;
	}

	public String getProdName() {
		return prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public String getManufacturerCode() {
		return manufacturerCode;
	}

	public void setManufacturerCode(String manufacturerCode) {
		this.manufacturerCode = manufacturerCode;
	}

	public Boolean getNewNumberSelected() {
		return newNumberSelected;
	}

	public void setNewNumberSelected(Boolean newNumberSelected) {
		this.newNumberSelected = newNumberSelected;
	}

	public String getEstimatedArivalDate() {return estimatedArivalDate;}

	public void setEstimatedArivalDate(String estimatedArivalDate) {this.estimatedArivalDate = estimatedArivalDate;}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public boolean isFeaturesAvailble() {
		return this.isFeaturesAvailble;
	}

	public void setFeaturesAvailble(boolean isFeaturesAvailble) {
		this.isFeaturesAvailble = isFeaturesAvailble;
	}

	public boolean isNewPortInNumber() {
		return isNewPortInNumber;
	}

	public void setNewPortInNumber(boolean newPortInNumber) {
		isNewPortInNumber = newPortInNumber;
	}

	public String getPortInNumber() {
		return portInNumber;
	}

	public void setPortInNumber(String portInNumber) {
		this.portInNumber = portInNumber;
	}

	public String getNumbersharedDeviceId() {
		return numbersharedDeviceId;
	}

	public void setNumbersharedDeviceId(String numbersharedDeviceId) {
		this.numbersharedDeviceId = numbersharedDeviceId;
	}

	public List<String> getConnectedWatchSupportedOs() {
		return connectedWatchSupportedOs;
	}
	/**
	 * Added for Agent COMM START
	 */
	private double salePrice;
	private double salePriceDiscount;

	public void setConnectedWatchSupportedOs(List<String> connectedWatchSupportedOs) {
		this.connectedWatchSupportedOs = connectedWatchSupportedOs;
	}
	public double getSalePrice() {
		return salePrice;
	}

	public void setSalePrice(double salePrice) {
		this.salePrice = salePrice;
	}

	public double getSalePriceDiscount() {
		return salePriceDiscount;
	}

	public void setSalePriceDiscount(double salePriceDiscount) {
		this.salePriceDiscount = salePriceDiscount;
	}

	/**
	 * Added for Agent COMM END
	 */

	private int noOfMonthlyCreditPayments;

	public int getNoOfMonthlyCreditPayments() {
		return noOfMonthlyCreditPayments;
	}

	public void setNoOfMonthlyCreditPayments(int noOfMonthlyCreditPayments) {
		this.noOfMonthlyCreditPayments = noOfMonthlyCreditPayments;
	}
	private boolean standaloneNumbershareEligible;

	public boolean isStandaloneNumbershareEligible() {
		return standaloneNumbershareEligible;
	}

	public void setStandaloneNumbershareEligible(boolean standaloneNumbershareEligible) {
		this.standaloneNumbershareEligible = standaloneNumbershareEligible;
	}

	public String getCnIdCapableDesc() {
		return cnIdCapableDesc;
	}

	public void setCnIdCapableDesc(String cnIdCapableDesc) {
		this.cnIdCapableDesc = cnIdCapableDesc;
	}

	public String getSafeWifiEligibleDesc() {
		return safeWifiEligibleDesc;
	}

	public void setSafeWifiEligibleDesc(String safeWifiEligibleDesc) {
		this.safeWifiEligibleDesc = safeWifiEligibleDesc;
	}
	private List<VZWSedOfferType> sedOfferlist;

	public List<VZWSedOfferType> getSedOfferlist() {
		return sedOfferlist;
	}

	public void setSedOfferlist(List<VZWSedOfferType> sedOfferlist) {
		this.sedOfferlist = sedOfferlist;
	}
	private List<VZWRebates> rebatesList;

	public List<VZWRebates> getRebatesList() {
		return rebatesList;
	}

	public void setRebatesList(List<VZWRebates> rebatesList) {
		this.rebatesList = rebatesList;
	}

	public double getMonthlyDiscount() {
		return monthlyDiscount;
	}

	public void setMonthlyDiscount(double monthlyDiscount) {
		this.monthlyDiscount = monthlyDiscount;
	}


	private double itemCredit;

	public double getItemCredit() {
		return itemCredit;
	}

	public void setItemCredit(double itemCredit) {
		this.itemCredit = itemCredit;
	}

	private boolean iwvDevice;

	public boolean isIwvDevice() {
		return iwvDevice;
	}

	public void setIwvDevice(boolean iwvDevice) {
		this.iwvDevice = iwvDevice;
	}

	public String getNgpOut() {
		return ngpOut;
	}

	public void setNgpOut(String ngpOut) {
		this.ngpOut = ngpOut;
	}

	public String getMinOut() {
		return minOut;
	}

	public void setMinOut(String minOut) {
		this.minOut = minOut;
	}

	public String getPortInNumberType() {
		return portInNumberType;
	}

	public void setPortInNumberType(String portInNumberType) {
		this.portInNumberType = portInNumberType;
	}

	public DeviceCondition getDeviceCondition() {
		return deviceCondition;
	}

	public void setDeviceCondition(DeviceCondition deviceCondition) {
		this.deviceCondition = deviceCondition;
	}

	public String getNumberShareIndicator() {
		return numberShareIndicator;
	}

	public void setNumberShareIndicator(String numberShareIndicator) {
		this.numberShareIndicator = numberShareIndicator;
	}

	public boolean isGraftActionChanged() {
		return graftActionChanged;
	}

	public void setGraftActionChanged(boolean graftActionChanged) {
		this.graftActionChanged = graftActionChanged;
	}

	public String getDeviceDescription() {
		return deviceDescription;
	}

	public void setDeviceDescription(String deviceDescription) {
		this.deviceDescription = deviceDescription;
	}

	public boolean isWirelessDevice() {
		return wirelessDevice;
	}

	public void setWirelessDevice(boolean wirelessDevice) {
		this.wirelessDevice = wirelessDevice;
	}

	public List<String> getDacc_ra_grp_cd() {
		return dacc_ra_grp_cd;
	}

	public void setDacc_ra_grp_cd(List<String> dacc_ra_grp_cd) {
		this.dacc_ra_grp_cd = dacc_ra_grp_cd;
	}

	private String shippingGroupId;

	public String getShippingGroupId() {  return shippingGroupId; }

	public void setShippingGroupId(String shippingGroupId) {	this.shippingGroupId = shippingGroupId;	}

	private boolean homeSafetyDevices;

	public boolean isHomeSafetyDevices() {
		return homeSafetyDevices;
	}

	public void setHomeSafetyDevices(boolean homeSafetyDevices) {
		this.homeSafetyDevices = homeSafetyDevices;
	}

	public boolean isSkipProtection() {
		return skipProtection;
	}

	public void setSkipProtection(boolean skipProtection) {
		this.skipProtection = skipProtection;
	}

}