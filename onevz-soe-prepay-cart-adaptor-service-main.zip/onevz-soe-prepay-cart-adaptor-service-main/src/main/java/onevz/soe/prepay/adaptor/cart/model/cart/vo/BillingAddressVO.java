
package onevz.soe.prepay.adaptor.cart.model.cart.vo;

import com.fasterxml.jackson.annotation.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "mdnNumber",
    "accountOwner",
    "firstName",
    "middleName",
    "zipcode",
    "fullName",
    "address",
    "lastName"
})
@Data
@Getter
@Setter
public class BillingAddressVO {

    @JsonProperty("mdnNumber")
    private Object mdnNumber;
    @JsonProperty("accountOwner")
    private Boolean accountOwner;
    @JsonProperty("firstName")
    private String firstName;
    @JsonProperty("middleName")
    private String middleName;
    @JsonProperty("zipcode")
    private String zipcode;
    @JsonProperty("fullName")
    private String fullName;
    @JsonProperty("address")
    private AddressVO address;
    @JsonProperty("lastName")
    private String lastName;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<>();
    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
