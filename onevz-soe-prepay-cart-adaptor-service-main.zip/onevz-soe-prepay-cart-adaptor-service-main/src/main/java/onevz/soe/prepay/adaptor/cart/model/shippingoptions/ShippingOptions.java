package onevz.soe.prepay.adaptor.cart.model.shippingoptions;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Contains shipping option type,
 * shipping cost, delivery date,
 * selected status.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(Include.NON_NULL)
public class ShippingOptions {
    private String shippingMethodName;
    private String shippingCode;
    private String shippingCost;
    private String deliveryDate;
    private boolean selected;
    private String depletionLocationCode;
    private String description;
    private String estimatedDeliveryDateText;
    private String expStoreShippingDesc;
    private String expStoreShippingMsg;
    private String locationSalesIdForSDD;
    private String shippingDescription;
    private String shippingOptionToolTip;
    private String shortDescription;
    private boolean signatureRequired;
    private boolean active;
    private List<SDDAvailableWindows> sddAvailableWindows;
    private String estDeliveryDate;
    private boolean freeOvernightShipping;
    private String name;
    private boolean discounted;
    private boolean twoDayShipping;
    private Double originalShippingCost;
}
