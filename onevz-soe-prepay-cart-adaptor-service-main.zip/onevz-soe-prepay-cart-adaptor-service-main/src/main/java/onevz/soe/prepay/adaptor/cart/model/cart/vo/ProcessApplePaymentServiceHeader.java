package onevz.soe.prepay.adaptor.cart.model.cart.vo;

/**
 * Created by w638278 on 1/17/2018.
 */
public class ProcessApplePaymentServiceHeader {

    ProcessApplePaymentClientInfo clientInfo;

    public ProcessApplePaymentClientInfo getClientInfo() {
        return clientInfo;
    }

    public void setClientInfo(ProcessApplePaymentClientInfo clientInfo) {
        this.clientInfo = clientInfo;
    }
}
