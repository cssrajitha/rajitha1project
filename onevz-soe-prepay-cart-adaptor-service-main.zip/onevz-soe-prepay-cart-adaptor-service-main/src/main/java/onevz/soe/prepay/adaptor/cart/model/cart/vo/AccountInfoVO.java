package onevz.soe.prepay.adaptor.cart.model.cart.vo;

import java.io.Serializable;

public class AccountInfoVO implements Serializable {
    private static final long serialVersionUID = 1L;

    private String mdnNumber;
    private boolean accountOwner;
    private String firstName;
    private String LastName;
    private String middleName;
    private String zipcode;
    private String fullName;
    private AddressVO address;

    public String getMdnNumber() {
        return mdnNumber;
    }

    public void setMdnNumber(String mdnNumber) {
        this.mdnNumber = mdnNumber;
    }

    public boolean isAccountOwner() {
        return accountOwner;
    }

    public void setAccountOwner(boolean accountOwner) {
        this.accountOwner = accountOwner;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getZipcode() {
        return zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public AddressVO getAddress() {
        return address;
    }

    public void setAddress(AddressVO address) {
        this.address = address;
    }
}
