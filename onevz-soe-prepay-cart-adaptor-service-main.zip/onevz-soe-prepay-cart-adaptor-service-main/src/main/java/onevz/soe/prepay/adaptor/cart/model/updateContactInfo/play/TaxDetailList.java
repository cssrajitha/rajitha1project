package onevz.soe.prepay.adaptor.cart.model.updateContactInfo.play;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class TaxDetailList {
    private String taxPrice;

    private String taxDetailsToDisplay;
}
