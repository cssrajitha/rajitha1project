package onevz.soe.prepay.adaptor.cart.model.play.common.error;

import java.io.Serializable;

/**
 * Created by eesamma on 10/20/2017.
 */
public class EcommServiceError implements Serializable{

    private String serviceErrorCode;
    private String serviceErrorMessage;
    private String serviceErrorInnerMessage;
    private String serviceName;
    private String subServiceName;

    public String getServiceErrorCode() {
        return serviceErrorCode;
    }

    public void setServiceErrorCode(String serviceErrorCode) {
        this.serviceErrorCode = serviceErrorCode;
    }

    public String getServiceErrorMessage() {
        return serviceErrorMessage;
    }

    public void setServiceErrorMessage(String serviceErrorMessage) {
        this.serviceErrorMessage = serviceErrorMessage;
    }

    public String getServiceErrorInnerMessage() {
        return serviceErrorInnerMessage;
    }

    public void setServiceErrorInnerMessage(String serviceErrorInnerMessage) {
        this.serviceErrorInnerMessage = serviceErrorInnerMessage;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getSubServiceName() {
        return subServiceName;
    }

    public void setSubServiceName(String subServiceName) {
        this.subServiceName = subServiceName;
    }
}
