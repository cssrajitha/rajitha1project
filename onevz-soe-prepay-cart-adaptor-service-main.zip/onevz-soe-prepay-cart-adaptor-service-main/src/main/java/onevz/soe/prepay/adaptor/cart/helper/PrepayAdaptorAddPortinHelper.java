package onevz.soe.prepay.adaptor.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.assignmtn.reponse.pega.PortinPEGAResponse;
import onevz.soe.assignmtn.request.pega.PortinPEGARequest;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.common.model.PrepaidODRequestDataLines;
import onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants;
import onevz.soe.prepay.adaptor.cart.model.play.VZWPrepayAddPortinRequest;
import onevz.soe.prepay.adaptor.cart.model.play.VZWPrepayAddPortinResponse;
import onevz.soe.prepay.adaptor.cart.model.play.common.error.EcommApiError;
import onevz.soe.prepay.adaptor.cart.util.PrepayAdaptorCartUtil;
import onevz.soe.prepay.adaptor.cart.util.PrepayAddPortinFormatterUtil;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.bpm.model.response.Error;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import onevz.soe.wsclient.prepay.webclient.model.PrepaidAdaptorWebClientRequest;
import org.apache.hc.core5.http.ContentType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.PREPAY_OD_REQUEST_DATA;

@Service
public class PrepayAdaptorAddPortinHelper {

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    private PrepayAdaptorWebClient prepayAdaptorWebClient;

    @Autowired
    SOELoginSessionBean sessionBean;

    @Autowired
    PrepayCartRedisHelper prepayCartRedisHelper;

    @Value("${addPortinPrepaidLegacyServiceUrl}")
    private String addPortinPrepaidLegacyServiceUrl;
    
    @Value("${enableSecurePin}")
    private String enableSecurePin;
    
    private static final Logger logger = LoggerFactory.getLogger(PrepayAdaptorAddPortinHelper.class);

    public Mono<ResponseEntity<PortinPEGAResponse>> addPortin(ServerHttpRequest httpRequest, PortinPEGARequest request) {
        
        return prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)
                .doOnError(onError ->
                    logger.error(" Unable to get data from Redis {}", onError)).doOnSuccess(onSuccess ->
                    logger.info("Successfully retrieved data from Redis: {}", onSuccess)).flatMap(redisResponse->{
                    logger.info(" redisData : {}", redisResponse);
                    if(redisResponse.isEmpty()) {
                        PortinPEGAResponse portinPEGAResponse = new PortinPEGAResponse();
                        return Mono.just(ResponseEntity.status(HttpStatus.OK).body(portinPEGAResponse));
                    }else {
                        PrepaidODRequestData redisData = null;

                        try {
                            redisData = mapper.readValue(redisResponse, PrepaidODRequestData.class);
                        } catch (JsonProcessingException e) {
                        	logger.error("JSON Processing error in add-portin:{}", e.getMessage());
                        }
                        //String flow = Objects.nonNull(request) && Objects.nonNull(request.getServiceBody()) && Objects.nonNull(request.getServiceBody().getServiceRequest()) && Objects.nonNull(request.getServiceBody().getServiceRequest().getContext()) && Objects.nonNull(request.getServiceBody().getServiceRequest().getContext().getCartInfo())?request.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType():PrepayAdaptorCartConstants.NSE;
                        String flow = Objects.nonNull(redisData) && CollectionUtilities.isNotEmptyOrNull(redisData.getLines())?redisData.getLines().get(redisData.getCurr_line()-1).getFlow():PrepayAdaptorCartConstants.NSE;
                        logger.info("Flowname in AddPortinHelper: {}", flow);
                        VZWPrepayAddPortinRequest vzwPrepayAddPortinRequest = PrepayAddPortinFormatterUtil.getVZWPrepayAddPortinRequest(request, redisData);
                        PrepaidAdaptorWebClientRequest prepaidLegacyServiceRequest = getPrepaidLegacyServiceRequest(vzwPrepayAddPortinRequest, redisData, flow);
                        logger.info("add-portIn Request body: {}",prepaidLegacyServiceRequest.getRequestBody());
                        logger.info("add-portIn Request headers: {}",prepaidLegacyServiceRequest.getHeader());
                        return addPortinCaller(httpRequest, prepaidLegacyServiceRequest, request, redisData);
                    }
                });
    }

    private Mono<ResponseEntity<PortinPEGAResponse>> addPortinCaller(ServerHttpRequest httpRequest, PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest, PortinPEGARequest request, PrepaidODRequestData redisData) {
        
    	return prepayAdaptorWebClient.getPrepayServiceResponse(httpRequest, prepaidAdaptorWebClientRequest)
                .doOnError(error -> logger.error("Failed to get response", error))
                .flatMap(responseEntity-> {
                    PortinPEGAResponse portinPEGAResponse = new PortinPEGAResponse();
                    logger.info("add-portIn Response body: {}",responseEntity.getBody());
                    logger.info("add-portIn Response status code: {}",responseEntity.getStatusCode());
                    try {
                        if (!responseEntity.getStatusCode().is2xxSuccessful()) {
                            logger.info("Play response status code: {}", responseEntity.getStatusCode());
                            logger.error("Error while calling endpoint: {} with status code: {}",
                                    prepaidAdaptorWebClientRequest.getUrl(), responseEntity.getStatusCode());
                            String name = PrepayAdaptorCartConstants.ADDPORTIN_FAILURE_NAME;
                            String id = PrepayAdaptorCartConstants.ADDPORTIN_FAILURE_ID;
                            String message = PrepayAdaptorCartConstants.ADDPORTIN_FAILURE_MSG;
                            String errorCategory = PrepayAdaptorCartConstants.ADDPORTIN_FAILURE_SYSTEM;
                            String responseString = responseEntity.getBody();
                            
                            if(!StringUtilities.isEmptyOrNull(responseString)) {
                            	VZWPrepayAddPortinResponse errorResponse = mapper.readValue(responseString, VZWPrepayAddPortinResponse.class);
	                            
	                            if (null != errorResponse && null != errorResponse.getErrors()) {
	                                EcommApiError[] ecommApi = errorResponse.getErrors().getEcommApiErrorList();
	                            	message = ecommApi[0].getMessage();
	                            	errorCategory = PrepayAdaptorCartConstants.ADDPORTIN_FAILURE_BUSINESS;
	                            }  
                            }
                            List<Error> errors = PrepayAdaptorCartUtil.buildErrorResponse(name, id, message, errorCategory);
                            portinPEGAResponse.setErrors(errors);
                            return Mono.just(ResponseEntity.status(HttpStatus.OK).body(portinPEGAResponse));
 
                        } else {
                        	
                            String name = PrepayAdaptorCartConstants.ADDPORTIN_FAILURE_NAME;
                            String id = PrepayAdaptorCartConstants.ADDPORTIN_FAILURE_ID;
                            String message = PrepayAdaptorCartConstants.ADDPORTIN_FAILURE_MSG;
                            String errorCategory = PrepayAdaptorCartConstants.ADDPORTIN_FAILURE_SYSTEM;
                            String responseString = responseEntity.getBody();
                            
                            if(!StringUtilities.isEmptyOrNull(responseString)) {
                            	VZWPrepayAddPortinResponse restResponse = mapper.readValue(responseString, VZWPrepayAddPortinResponse.class);
                            
                            if (null != restResponse && null != restResponse.getErrors()) {
                                EcommApiError[] ecommApi = restResponse.getErrors().getEcommApiErrorList();
                            	message = ecommApi[0].getMessage();
                            	errorCategory = PrepayAdaptorCartConstants.ADDPORTIN_FAILURE_BUSINESS;
                            	List<Error> errors = PrepayAdaptorCartUtil.buildErrorResponse(name, id, message, errorCategory);
                                portinPEGAResponse.setErrors(errors);
                                return Mono.just(ResponseEntity.status(HttpStatus.OK).body(portinPEGAResponse));
                            } else {
                            	
                            	//update redis with number assignment status
                            	String mtn = request.getServiceBody().getServiceRequest().getContext().getCartInfo().getPortLines()[0].getMtn();

                                return getPegaResponse(request, redisData, restResponse, mtn);
                            }
  
                        } else {
                        	logger.error("AddPortIn OD response is empty");
                        	return Mono.just(ResponseEntity.status(HttpStatus.OK).body(portinPEGAResponse));
                        }
                      }

                    } catch (JsonMappingException e) {
                        logger.info("Json Mapping Error: {}", e.getMessage());
                        return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new PortinPEGAResponse()));
                    } catch (JsonProcessingException e) {
                        logger.info("JsonProcessing Error: {}", e.getMessage());
                        return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new PortinPEGAResponse()));
                    }
                });
    }

    private Mono<ResponseEntity<PortinPEGAResponse>> getPegaResponse(PortinPEGARequest request, PrepaidODRequestData redisData, VZWPrepayAddPortinResponse restResponse, String mtn) {
        String mtnRedis;
        try {
            List<PrepaidODRequestDataLines> dataLines = redisData.getLines();
            List<PrepaidODRequestDataLines> linesToProcess = redisData.getLines().stream().filter(line-> line.getMtn().equalsIgnoreCase(mtn)).toList();
             PrepaidODRequestDataLines lineToProcess = linesToProcess.get(0);
mtnRedis = Objects.nonNull(lineToProcess)?lineToProcess.getMtn():"";
logger.info("mtn of the line in Redis: {}",mtnRedis);
if(null!=lineToProcess) {
    lineToProcess.setNumAssigned(true);
}
int currNumNotAssignedLines = redisData.getLines().stream().filter(line-> !(line.isNumAssigned())).toList().size();
dataLines.set(dataLines.indexOf(lineToProcess), lineToProcess);
redisData.setLines(dataLines);

            checkNumberAssignedToLines(redisData, currNumNotAssignedLines);
            redisData.setTotalNumAssignedLines(redisData.getLines().size()-currNumNotAssignedLines);
//upsert redisData to Redis
            return prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, redisData)
                    .doOnError(err -> logger.error("Failed to update the PrepaidODRequestData to Redis", err))
                    .flatMap(upsertResp ->
                    {
                        logger.info("Successfully inserted updated Redis Data: {}", upsertResp);
                        PortinPEGAResponse portinResponse = PrepayAddPortinFormatterUtil.getPortinPEGAResponse(request, restResponse, redisData, enableSecurePin);
                        return Mono.justOrEmpty(ResponseEntity.status(HttpStatus.OK).body(portinResponse));
                    });						        
            
        } catch (Exception ex) {
            logger.error("MTN in the add-portin request is not matching the mtn in Redis");
            return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new PortinPEGAResponse()));
        }
    }

    private void checkNumberAssignedToLines(PrepaidODRequestData redisData, int currNumNotAssignedLines) {
        if(currNumNotAssignedLines >0) {
        redisData.setNumberAssignedToAllLines(false);
        } else {
        redisData.setNumberAssignedToAllLines(true);
        }
    }

    private PrepaidAdaptorWebClientRequest getPrepaidLegacyServiceRequest(VZWPrepayAddPortinRequest request, PrepaidODRequestData redisData, String flow) {
        PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
        Map<String,String> headers = new HashMap<>();
        String flowName = PrepayAdaptorCartUtil.getODFlowName(flow);

        headers.put("p-csrf-token", redisData.getPCsrfToken());
        String prepayODCookie = "ECOMM_SESSION=" + redisData.getEcommSessionId() + ";" + "p_csrftkn=" + redisData.getPCsrfToken() + ";flow=" + flowName;
        headers.put("Cookie", prepayODCookie);
        headers.put("Content-Type", String.valueOf(ContentType.APPLICATION_JSON));
        prepaidAdaptorWebClientRequest.setUrl(addPortinPrepaidLegacyServiceUrl);
        prepaidAdaptorWebClientRequest.setRequestBody(request);
        prepaidAdaptorWebClientRequest.setRequestType("POST");
        prepaidAdaptorWebClientRequest.setHeader(headers);
        return prepaidAdaptorWebClientRequest;
    }

}
