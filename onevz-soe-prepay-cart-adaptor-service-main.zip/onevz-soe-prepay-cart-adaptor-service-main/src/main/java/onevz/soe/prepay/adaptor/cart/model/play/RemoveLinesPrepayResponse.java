package onevz.soe.prepay.adaptor.cart.model.play;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)

public class RemoveLinesPrepayResponse {
    private String status;
    private VZWRemoveLinesPayload payload;

}
