package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;

/**
 * The Class VZWCreditCardInfoVO.
 */
public class VZWCreditCardInfoVO implements Serializable {

	private String id;

	/** The saved card name. */
	private String savedCardNickName;

	/** The preselected saved card name. */
	private boolean preselectCard;

	/** The credit card number. */
	private String creditCardNumber;

	/** The credit card exp month. */
	private String creditCardExpMonth;

	/** The credit card exp year. */
	private String creditCardExpYear;

	/** The billing zip code. */
	private String billingZipCode;

	/** The credit card type. */
	private String creditCardType;

	private String debitElegible;

	private String creditCardVerificationNumber;

	/** The credit card Last 4 Digits. */
	private String cardLast4Digits;
	private ContactInfo billingAddress;

	private String PieEncryptionDetailsVO;
	private PieEncryptionDetailsVO pieEncrptionDetails;
	private String encryptionType;
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public PieEncryptionDetailsVO getPieEncrptionDetails() {
		return pieEncrptionDetails;
	}

	public void setPieEncrptionDetails(PieEncryptionDetailsVO pieEncrptionDetails) {
		this.pieEncrptionDetails = pieEncrptionDetails;
	}

	public String getPieEncryptionDetailsVO() {	return PieEncryptionDetailsVO;}

	public void setPieEncryptionDetailsVO(String pieEncryptionDetailsVO) {	PieEncryptionDetailsVO = pieEncryptionDetailsVO;}

	/**
	 * @return the cardLast4Digits
	 */
	public String getCardLast4Digits() {
		return cardLast4Digits;
	}

	/**
	 * @param pCardLast4Digits the cardLast4Digits to set
	 */
	public void setCardLast4Digits(String pCardLast4Digits) {
		cardLast4Digits = pCardLast4Digits;
	}

	/**
	 * Gets the credit card number.
	 *
	 * @return the credit card number
	 */
	public String getCreditCardNumber() {
		return creditCardNumber;
	}

	/**
	 * Sets the credit card number.
	 *
	 * @param creditCardNumber the new credit card number
	 */
	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}

	/**
	 * Gets the credit card exp month.
	 *
	 * @return the credit card exp month
	 */
	public String getCreditCardExpMonth() {
		return creditCardExpMonth;
	}

	/**
	 * Sets the credit card exp month.
	 *
	 * @param creditCardExpMonth the new credit card exp month
	 */
	public void setCreditCardExpMonth(String creditCardExpMonth) {
		this.creditCardExpMonth = creditCardExpMonth;
	}

	/**
	 * Gets the credit card exp year.
	 *
	 * @return the credit card exp year
	 */
	public String getCreditCardExpYear() {
		return creditCardExpYear;
	}

	/**
	 * Sets the credit card exp year.
	 *
	 * @param creditCardExpYear the new credit card exp year
	 */
	public void setCreditCardExpYear(String creditCardExpYear) {
		this.creditCardExpYear = creditCardExpYear;
	}

	/**
	 * Gets the billing zip code.
	 *
	 * @return the billing zip code
	 */
	public String getBillingZipCode() {
		return billingZipCode;
	}

	/**
	 * Sets the billing zip code.
	 *
	 * @param billingZipCode the new billing zip code
	 */
	public void setBillingZipCode(String billingZipCode) {
		this.billingZipCode = billingZipCode;
	}

	/**
	 * Gets the saved card nick name.
	 *
	 * @return the saved card nick name
	 */
	public String getSavedCardNickName() {
		return savedCardNickName;
	}

	/**
	 * Sets the saved card nick name.
	 *
	 * @param savedCardNickName the new saved card nick name
	 */
	public void setSavedCardNickName(String savedCardNickName) {
		this.savedCardNickName = savedCardNickName;
	}

	/**
	 * Checks if is preselected card.
	 *
	 * @return true, if is preselected card
	 */
	public boolean isPreselectCard() {
		return preselectCard;
	}

	/**
	 * Sets the preselected card.
	 *
	 * @param  preselectCard new preselected card
	 */
	public void setPreselectCard(boolean preselectCard) {
		this.preselectCard = preselectCard;
	}

	/**
	 * Gets the credit card type.
	 *
	 * @return the credit card type
	 */
	public String getCreditCardType() {
		return creditCardType;
	}

	/**
	 * Sets the credit card type.
	 *
	 * @param creditCardType the new credit card type
	 */
	public void setCreditCardType(String creditCardType) {
		this.creditCardType = creditCardType;
	}

	public String getCreditCardVerificationNumber() {
		return creditCardVerificationNumber;
	}

	public void setCreditCardVerificationNumber(String creditCardVerificationNumber) {
		this.creditCardVerificationNumber = creditCardVerificationNumber;
	}

	private String mDisplayCVV;

	/**
	 * @return the displayCVV
	 */
	public String getDisplayCVV() {
		return mDisplayCVV;
	}

	/**
	 * @param pDisplayCVV
	 *            the displayCVV to set
	 */
	public void setDisplayCVV(String pDisplayCVV) {
		mDisplayCVV = pDisplayCVV;
	}

	public ContactInfo getBillingAddress() {
		return billingAddress;
	}

	public void setBillingAddress(ContactInfo billingAddress) {
		this.billingAddress = billingAddress;
	}

	public String getEncryptionType() {	return encryptionType;}

	public void setEncryptionType(String encryptionType) {	this.encryptionType = encryptionType; }

	public String getDebitElegible() {
		return debitElegible;
	}

	public void setDebitElegible(String debitElegible) {
		this.debitElegible = debitElegible;
	}
}
