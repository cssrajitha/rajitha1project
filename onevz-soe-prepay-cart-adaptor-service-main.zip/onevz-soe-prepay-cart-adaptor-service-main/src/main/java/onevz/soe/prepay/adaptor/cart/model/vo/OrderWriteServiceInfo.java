package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;
import java.util.Date;

public class OrderWriteServiceInfo implements Serializable {
	
	/**
	 * serialVersionUID
	 */
	private static long serialVersionUID = -7526977565059263347L;
	
	private String id;
	private String orderId;
	private String originatingIpAddress;
	private String isPreOrder="N";
	private String timeZone;
	private String overNightShipPriority="N";
	private String customerType;
	private String customerAssoc;
	private String groupId;
	private String invoiceNode;
	private String dacc;
	private String accountNumber;
	private String accountSubNumber;
	private String primaryMdn;
	private String employerName;
	private String employerCity;
	private String employerState;
	private String nePhoneNumber;
	private String ecpdProfileId;
	private String accessDiscountPercent;
	private String profileType;
	private String vendorOrderId;
	private String billingSystem;
	private String customerTypeCode;
	private String defaultSalesRepId;
	private String salesRepId;
	private String zipCode;
	private String locationCode;
	private String outletId;
	private ContactInfo paypalBillingAddress;
	private ContactInfo paypalShippingAddress;
	private int version;
	private Date lastModifiedDate;
	private String customerTypeForPreorder;

	public String getCustomerTypeForPreorder() {
		return customerTypeForPreorder;
	}

	public void setCustomerTypeForPreorder(String customerTypeForPreorder) {
		this.customerTypeForPreorder = customerTypeForPreorder;
	}

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getOriginatingIpAddress() {
		return originatingIpAddress;
	}
	public void setOriginatingIpAddress(String originatingIpAddress) {
		this.originatingIpAddress = originatingIpAddress;
	}
	public String getIsPreOrder() {
		return isPreOrder;
	}
	public void setIsPreOrder(String isPreOrder) {
		this.isPreOrder = isPreOrder;
	}
	public String getTimeZone() {
		return timeZone;
	}
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}
	
	public String getCustomerType() {
		return customerType;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	public String getCustomerAssoc() {
		return customerAssoc;
	}
	public void setCustomerAssoc(String customerAssoc) {
		this.customerAssoc = customerAssoc;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getInvoiceNode() {
		return invoiceNode;
	}
	public void setInvoiceNode(String invoiceNode) {
		this.invoiceNode = invoiceNode;
	}
	public String getDacc() {
		return dacc;
	}
	public void setDacc(String dacc) {
		this.dacc = dacc;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountSubNumber() {
		return accountSubNumber;
	}
	public void setAccountSubNumber(String accountSubNumber) {
		this.accountSubNumber = accountSubNumber;
	}
	public String getPrimaryMdn() {
		return primaryMdn;
	}
	public void setPrimaryMdn(String primaryMdn) {
		this.primaryMdn = primaryMdn;
	}
	public String getEmployerName() {
		return employerName;
	}
	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}
	public String getEmployerCity() {
		return employerCity;
	}
	public void setEmployerCity(String employerCity) {
		this.employerCity = employerCity;
	}
	public String getEmployerState() {
		return employerState;
	}
	public void setEmployerState(String employerState) {
		this.employerState = employerState;
	}
	public String getNePhoneNumber() {
		return nePhoneNumber;
	}
	public void setNePhoneNumber(String nePhoneNumber) {
		this.nePhoneNumber = nePhoneNumber;
	}
	public String getEcpdProfileId() {
		return ecpdProfileId;
	}
	public void setEcpdProfileId(String ecpdProfileId) {
		this.ecpdProfileId = ecpdProfileId;
	}
	public String getAccessDiscountPercent() {
		return accessDiscountPercent;
	}
	public void setAccessDiscountPercent(String accessDiscountPercent) {
		this.accessDiscountPercent = accessDiscountPercent;
	}
	public String getProfileType() {
		return profileType;
	}
	public void setProfileType(String profileType) {
		this.profileType = profileType;
	}
	public String getVendorOrderId() {
		return vendorOrderId;
	}
	public void setVendorOrderId(String vendorOrderId) {
		this.vendorOrderId = vendorOrderId;
	}
	public String getBillingSystem() {
		return billingSystem;
	}
	public void setBillingSystem(String billingSystem) {
		this.billingSystem = billingSystem;
	}
	public String getCustomerTypeCode() {
		return customerTypeCode;
	}
	public void setCustomerTypeCode(String customerTypeCode) {
		this.customerTypeCode = customerTypeCode;
	}
	public String getDefaultSalesRepId() {
		return defaultSalesRepId;
	}
	public void setDefaultSalesRepId(String defaultSalesRepId) {
		this.defaultSalesRepId = defaultSalesRepId;
	}
	public String getSalesRepId() {
		return salesRepId;
	}
	public void setSalesRepId(String salesRepId) {
		this.salesRepId = salesRepId;
	}
	public ContactInfo getPaypalBillingAddress() {
		return paypalBillingAddress;
	}
	public void setPaypalBillingAddress(ContactInfo paypalBillingAddress) {
		this.paypalBillingAddress = paypalBillingAddress;
	}
	public ContactInfo getPaypalShippingAddress() {
		return paypalShippingAddress;
	}
	public void setPaypalShippingAddress(ContactInfo paypalShippingAddress) {
		this.paypalShippingAddress = paypalShippingAddress;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public String getOutletId() {
		return outletId;
	}
	public void setOutletId(String outletId) {
		this.outletId = outletId;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	/**
	 * @return the lastModifiedDate
	 */
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}
	/**
	 * @param lastModifiedDate the lastModifiedDate to set
	 */
	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	/**
	 * @param serialversionuid the serialversionuid to set
	 */
	public static void setSerialversionuid(long serialversionuid) {
		serialVersionUID = serialversionuid;
	}
	/**
	 * @return the overNightShipPriority
	 */
	public String getOverNightShipPriority() {
		return overNightShipPriority;
	}
	/**
	 * @param overNightShipPriority the overNightShipPriority to set
	 */
	public void setOverNightShipPriority(String overNightShipPriority) {
		this.overNightShipPriority = overNightShipPriority;
	}
}
