package onevz.soe.prepay.adaptor.cart.model.cart.vo;

/**
 * Created by w638278 on 1/17/2018.
 */
public class ProcessApplePaymentDecryptToken {
    String applicationExpirationDate;
    String applicationPrimaryAccountNumber;
    String currencyCode;
    String deviceManufacturerIdentifier;
    String paymentDataType;
    String transactionAmount;
    ProcessApplePaymentPaymentData paymentData;

    public String getApplicationExpirationDate() {
        return applicationExpirationDate;
    }

    public void setApplicationExpirationDate(String applicationExpirationDate) {
        this.applicationExpirationDate = applicationExpirationDate;
    }

    public String getApplicationPrimaryAccountNumber() {
        return applicationPrimaryAccountNumber;
    }

    public void setApplicationPrimaryAccountNumber(String applicationPrimaryAccountNumber) {
        this.applicationPrimaryAccountNumber = applicationPrimaryAccountNumber;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getDeviceManufacturerIdentifier() {
        return deviceManufacturerIdentifier;
    }

    public void setDeviceManufacturerIdentifier(String deviceManufacturerIdentifier) {
        this.deviceManufacturerIdentifier = deviceManufacturerIdentifier;
    }

    public String getPaymentDataType() {
        return paymentDataType;
    }

    public void setPaymentDataType(String paymentDataType) {
        this.paymentDataType = paymentDataType;
    }

    public String getTransactionAmount() {
        return transactionAmount;
    }

    public void setTransactionAmount(String transactionAmount) {
        this.transactionAmount = transactionAmount;
    }

    public ProcessApplePaymentPaymentData getPaymentData() {
        return paymentData;
    }

    public void setPaymentData(ProcessApplePaymentPaymentData paymentData) {
        this.paymentData = paymentData;
    }
}
