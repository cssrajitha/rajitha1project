package onevz.soe.prepay.adaptor.cart.model.vo;


import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.*;

public class VZWCommonConstants {

    public static final String REDIS_THREAD_KEY = "akka.redis.config.threads";

    public static final String ES_THREAD_KEY = "akka.es.config.threads";

    public static final String REDIS_CLIENTS = "akka.redis.config.clients";

    public static final String REDIS_CONNECTION_TYPE = "akka.redis.config.connectionType";

    public static final String AKKA_BACKEND_CLUSTER = "akka.cluster.roles = [backend]";
    public static final String CLUSTER_CONTROLLER_NAME = "clusterController";
    public static final String ACTOR_APPLICATION_NAME = "application";
    public static final String HASHEDSUBSCRIBERNUMBER ="hashedSubscriberNumber";
    public static final String SUBSCRIBERNUMBER ="subscribernumber";
    public static final String HASHEDMDN = "hashedMdn";

    public static final String SUCCESS_STATUS_CODE = "00";
    public static final String FAILURE_STATUS_CODE = "01";
    public static final String ICONIC_SKUS = "ICONIC_SKUS";
    public static final String PROMO_ICONIC_SKUS = "PROMO_ICONIC_SKUS";

    public static final String STATUS_CODE = "statusCode";
    public static final String STATUS_MESSAGE = "statusMessage";
    public static final String OUTPUT = "output";
    public static final String SERVICE_FAILED = "Service Failed";
    public static final String VALIDATION_ERROR = "VALIDATION_ERROR";

    public static final String REDIS_HOST_KEY = "akka.redis.config.host";

    public static final String REDIS_PORT_KEY = "akka.redis.config.port";

    public static final String REDIS_TIMEOUT_KEY = "akka.redis.config.timeout";

    public static final String REDIS_MAX_ACTIVE_KEY = "akka.redis.config.maxActive";

    public static final String REDIS_MAX_WAIT_KEY = "akka.redis.config.maxWait";

    public static final String REDIS_ACCOUNT_MODULE_ROLE = "akka.cluster.roles = [backend]";

    public static final String REDIS_ACCOUNT_MODULE_FILE = "accountDetailService";

    public static final String EPS_CALCULATE_TAX_QTASK = "CALCTAX";
    public static final String EPS_WALLET_INQUIRY_QTASK = "CCINFOFRM";

    public static final int HTTP_CONNECTION_TIMEOUT = 120000;

    public static final String REDIS_MAX_ACTIVE = "1";

    public static final String REDIS_MAX_WAIT = "100";

    public static final String MS_CLIENT_ID = "MS_CLIENT_ID";

    public static final String MS_HOSTNAME = "MS_HOST";

    public static final String MS_SCHEME = "MS_SCHEME";

    public static final String MS_USERNAME = "MS_USERNAME";

    public static final String MS_DC_SPECIFIC = "MS_DC_SPECIFIC";

    public static final String MS_DC_CLIENT_ID = "MS_DC_CLIENT_ID";

    public static final String MS_DC_HOSTNAME = "MS_DC_HOSTNAME";

    public static final String MS_DC_SCHEME = "MS_DC_SCHEME";

    public static final String MS_DC_USERNAME = "MS_DC_USERNAME";

    public static final String HTTP_SECURED = "HTTPSecured";

    public static final String CLIENTID = "clientId";
    public static final String CLIENT_TRANSACTION_ID = "clientTransactionId";
    public static final String CORRELATIONID = "correlationId";

    public static final String PD = "pd";

    public static final String UN = "un";

    public static final String CONTEXT_PATH = "/eservices/model";

    public static final String SET_COOKIES = "Set-Cookie";

    public static final String SEMI_COLON = ";";

    public static final String EQUAL = "=";

    public static final String PATH = "path";

    public static final String DOMAIN = "domain";

    public static final String EXPIRES = "expires";

    public static final String JSESSIONID = "JSESSIONID";

    public static final String GLOBALID = "GLOBALID";

    public static final String JSIDVZW = "JSIDVZW";

    public static final String NSC = "NSC";

    public static final String REDIS_KEY = "vzw_ecomm_props";
    public static final String QUESTION = "?";

    public static final String REDIS_ORDER_CONF_VO_KEY = "vzw_order_confirmation_vo";
    public static final String REDIS_COMPLETE_ORDER_VO_KEY = "vze_complete_order_detail_key";
    public static final String REDIS_GET_EXISTING_FEATURES_BASED_ON_FOM_KEY = "vzw_get_existing_features_based_on_fom_key";
    public static final String REDIS_GET_EXISTING_PLAN_AND_FEATURE_KEY = "vzw_get_existing_plan_and_feature_key";
    public static final String REDIS_GET_COMPATIBLE_FEATURES_KEY = "vzw_get_compatible_features_key";

    public static final String DECRYPTION_ALGORITHM = "DECRYPTION_ALGORITHM";
    public static final String ECPD_KEY = "ECPD_KEY";
    public static final String UPGRADE_MTN_DECRYPTION_KEY = "UPGRADE_MTN_DECRYPTION_KEY";

    public static final String EXP_ADD_TO_CART_ACTOR = "expressAddToCartActor";
    public static final String GET_FEATURES_ACTOR = "getFeaturesActor";
    public static final String PAST_DUE_CHECKOUT_ACTOR = "pastDueCheckoutActor";
    public static final String ESN = "ESN";
    public static final String ICC = "ICC";
    public static final String IME = "IME";

    // Actor names to register in cluster(from Akka apps) and to be consumed in
    // client(play)
    public static final String PROSPECT_SERVICE_ACTOR_ROOT = "/user/preorder_prospect_";
    public static final String PROSPECT_SERVICE_PREORDER_ACTOR_ROOT = "preorder_prospect_";
    public static final String BUSINESS_ACTOR_COMPATIBLE_FEATURE = "compatibleFeaturesBusiness";
    public static final String TIME_OUT_RETRIEVE_DEVICE_SIME_INFO = "retrieveDeviceSimInfo";
    public static final String TIME_OUT_PROGRAM_ELIGIBILITY = "programEligibility";
    public static final String TIME_OUT_INSTALLMENT_LOAN_MAINTENANCE = "installmentLoanMaintenance";
    public static final String TIME_OUT_INSTALLMENT_LOAN_MAINTENANCE_FOR_BUYOUT = "installmentLoanMaintenanceForBuyout";
    public static final String DEVICE_SOR_ID = "deviceSorId";

    public static final String SERVICE_ACTOR_ROOT = "/user/preorder_";
    public static final String SERVICE_PREORDER_ACTOR_ROOT = "preorder_";
    public static final String SERVICE_ACTOR_GRIDWALL = "gridWallDetail";
    public static final String SERVICE_ACTOR_DEVICE_DETAIL = "deviceDetail";
    public static final String SERVICE_ACTOR_GET_FEATURES = "getFeatures";
    public static final String SERVICE_ACTOR_EXP_ADD_TO_CART = "expAddToCart";
    public static final String SERVICE_ACTOR_ACCOUNT_DETAIL = "accountDetail";
    public static final String SERVICE_ACTOR_CANCEL_PENDING = "cancelPending";
    public static final String SERVICE_ACTOR_AAL_ALLOWED = "aalAllowed";
    public static final String SERVICE_ACTOR_TRADEIN_DEVICE_DETAILS = "tradeInDeviceDetails";
    public static final String SERVICE_ACTOR_TRADEIN_QUESTIONNAIRE = "tradeinQuestionnaire";
    public static final String SERVICE_ACTOR_TRADEIN_APPRAISAL = "tradeInAppraisal";
    public static final String SERVICE_ACTOR_TRADEIN_SUBMIT = "tradeInSubmit";
    public static final String SERVICE_ACTOR_TRADEIN_KILL_SWITCH = "tradeInKillSwitch";

    public static final String SERVICE_ACTOR_GET_CART_DETAIL = "ProspectGetCartDetails";
    public static final String SERVICE_ACTOR_CART_ADD_UPDATE_FEATURE = "addOrUpdateFeature";
    public static final String SERVICE_ACTOR_CART_ADD_UPDATE_DEVICE = "addUpdateDevice";
    public static final String SERVICE_ACTOR_CART_ADD_UPDATE_PLAN = "addUpdatePlan";
    public static final String SERVICE_ACTOR_CART_CHANGE_ZIPCODE = "changeZipCode";
    public static final String SERVICE_ACTOR_CART_REMOVE_PROMOCODE = "removePromoCode";
    public static final String SERVICE_ACTOR_GET_CART_COMPATIBLE_FEATURE = "getCompatibleFeatures";
    public static final String SERVICE_ACTOR_GET_MTN_DETAILS = "getMTNDetails";
    public static final String LOOKUP_SHARED_CART_INTEGRATION_ACTOR = "ProsepctLookupSharedCartIntegrationActor";
    public static final String LOOKUP_SHARED_CART_SERVICE_ACTOR = "ProsepctLookupSharedCartActor";
    public static final String DISCARD_SHARED_CART_SERVICE_ACTOR = "ProsepctDiscardSharedCartServiceActor";
    public static final String DISCARD_SHARED_CART_BUSINESS_ACTOR = "ProsepctDiscardSharedCartBusinessActor";
    public static final String DISCARD_SHARED_CART_INTEGRATION_ACTOR = "ProsepctDiscardSharedCartIntegrationActor";

    public static final String SERVICE_ACTOR_EXPRESS_ADD_CART = "expAddToCart";
    public static final String SERVICE_ACTOR_GET_CART_FEATURES = "getFeatures";
    public static final String SERVICE_ACTOR_CART_APPLY_PROMOCODE = "applyPromoCode";
    public static final String SERVICE_ACTOR_CLEAR_CART = "clearCart";
    public static final String SERVICE_ACTOR_PLAN_DETAIL = "planDetail";
    public static final String SERVICE_ACTOR_EXPRESS_CHECKOUT = "expressCheckout";
    // Complete order details service
    public static final String SERVICE_ACTOR_COMPLETE_ORDER_DETAILS = "completeOrderDetails";
    public static final String SERVICE_ACTOR_SUBMIT_EDGE_DOWN_PAYMENT = "submitEdgeDownPayment";
    public static final String SERVICE_ACTOR_INITIATE_CHECKOUT = "initiateCheckout";
    public static final String SERVICE_ACTOR_CLUSTER_CONTROLLER = "clusterController";
    public static final String SERVICE_ACTOR_EXPRESS_CHECKOUT_SUPERVISOR = "expressCheckoutSupervisor";
    public static final String SERVICE_ACTOR_CHEKOUT_MAIN = "chekoutMain";
    public static final String SERVICE_ACTOR_STORE_DETAILS = "storeDetails";
    public static final String SERVICE_ACTOR_UPDATE_SHIPPING = "updateShippingInfo";
    public static final String SERVICE_ACTOR_UPDATE_DEVICE_SERVICE_ADDRESS = "updateDeviceServiceAddress";
    public static final String SERVICE_ACTOR_UPDATE_PAYMENT = "updatePaymentInfo";
    public static final String SERVICE_ACTOR_ORDER_CONFIRMATION = "orderConfirmation";
    public static final String SERVICE_ACTOR_SUBMIT_ORDER = "submitOrder";
    public static final String SERVICE_ACTOR_VALIDATE_ORDER = "validateOrder";
    public static final String SERVICE_ACTOR_TERMS_CONDITIONS = "termsAndConditions";
    public static final String SERVICE_ACTOR_ACCEPT_DEPOSIT = "acceptDeposit";
    public static final String GET_NPA_NXX_NUMBER_ACTOR = "getNpaNxxNumberActor";
    public static final String UPDATE_NPA_NXX_NUMBER_ACTOR = "updateNpaNxxNumberActor";
    public static final String AAL_EXPRESS_ADD_TO_CART_ACTOR = "aalExpressAddToCartActor";
    public static final String GET_EXISTING_PLAN_AND_FEATURE_ACTOR = "getExistingPlanAndFeatureActor";
    public static final String SERVICE_ACTOR_CART_ADD_UPDATE_PLAN_FEATURE = "addOrUpdatePlanFeature";
    public static final String SERVICE_ACTOR_GET_PROTECTION_FEATURE = "getProtectionFeatures";
    public static final String SERVICE_ACTOR_FETCH_SMS_ENABLED_DEVICES = "fetchSMSEnabledDevices";
    public static final String SERVICE_ACTOR_SEND_SMS = "sendSMS";
    public static final String SERVICE_ACTOR_VALIDATE_AUTH_CODE = "validateAuthCode";
    public static final String SERVICE_ACTOR_TRADE_IN_TERMS_AND_CONDITIONS = "tradeInTermsAndConditions";
    public static final String SERVICE_ACTOR_CART_ADD_REMOVE_ACCESSORY = "addRemoveAccessory";
    public static final String SERVICE_ACTOR_PAY_OFF_PAST_DUE_PAYMENT = "payOffPastDuePayment";
    public static final String SERVICE_ACTOR_PAST_DUE_CHECKOUT = "pastDueCheckout";
    public static final String REDIS_SESSION_TIMEOUT = "akka.redis.config.sessionTimeout";
    public static final String REDIS_DEFAULT_SESSION_TIMEOUT = "10800";
    public static final String REDIS_SCHEME_KEY = "akka.redis.config.scheme";
    public static final String REDIS_TYPE = "akka.redis.config.type";
    public static final String REDIS_DEFAULT_TYPE = "cluster";
    public static final String REDIS_CLUSTER_TYPE = "cluster";
    public static final String REDIS_STANDALONE_TYPE = "standalone";
    public static final String REDIS_CLUSTER_HOST = "akka.redis.config.clusterHost";
    public static final String REDIS_SLAVE_HOST_KEY = "akka.redis.config.slaveHost";
    public static final String REDIS_SLAVE_PORT_KEY = "akka.redis.config.slavePort";
    public static final String REDIS_SLAVE_TIMEOUT_KEY = "akka.redis.config.slaveTimeout";
    public static final String REDIS_SLAVE_MAX_ACTIVE_KEY = "akka.redis.config.slaveMaxActive";
    public static final String REDIS_SLAVE_MAX_WAIT_KEY = "akka.redis.config.slaveMaxWait";
    public static final String REDIS_MASTER_SCHEME = "master";
    public static final String REDIS_SLAVE_SCHEME = "slave";
    public static final String PROSPECT_ADDRESS_VALIDATION_SERVICE = "addressValidationService";
    public static final String CACHE_TRADE_IN_PROMO_VO_KEY = "CACHE_TRADE_IN_PROMO_VO_KEY";
    public static final String CACHE_TRANSFORM_TRADE_IN_PROMO_VO_KEY = "CACHE_TRANSFORM_TRADE_IN_PROMO_VO_KEY";
    public static final String CACHE_TRADE_IN_FLAG_KEY = "CACHE_TRADE_IN_FLAG_KEY";
    public static final String INTIATE_CHECKOUT_ACCEPT_DEPOSIT_STAGE = "intiateCheckoutState";
    public static final String INITATE_CHECKOUT_SUBMIT_DOWNPAYMENT_STAGE = "submitDownpaymentState";
    public static final String REDIS_CONFIRMATION_ENSIGHTEN_VO_KEY = "REDIS_CONFIRMATION_ENSIGHTEN_VO_KEY";
    public static final String REDIS_ORDER_REVIEW_ENSIGHTEN_VO_KEY = "REDIS_ORDER_REVIEW_ENSIGHTEN_VO_KEY";
    public static final String INTIATE_CHECKOUT_ERROR_STAGE = "intiateCheckoutErrorState";
    public static final String REDIS_INTIATE_CHECKOUT_STAGE = "redisIntiateCheckoutState";
    public static final String REDIS_EDGE_DOWNPAYMENT_AMOUNT = "redisEdgeDownpaymentAmount";

    public static final String CACHE_TRADE_IN_PROMO_TERMS_COND_KEY = "CACHE_TRADE_IN_PROMO_TERMS_COND_KEY";
    public static final String ONEDIGITAL_ENSIGHTON_NAME = "vzw_mobile_store";
    public static final String ONEDIGITAL_DESKTOP_ENSIGHTON_NAME = "vzw_desktop_store";

    public static final String LOG_START = "Start";
    public static final String LOG_END = "End";
    public static final String TIME_TAKEN = "It took {} milliseconds to execute {}";
    public static final String HYPHEN = " - ";
    public static final String AMPHERSAND = "&";
    public static final String PLAN_INFO_CACHEKEY = "PLAN_INFO";
    public static final String CPC_CACHEKEY_SEPARATOR = "_";
    public static final String PROMOTION_CACHEKEY = "PRICE_PROMO";
    public static final String RECOMMENDED_PLAN_CACHEKEY = "RECOMMENDED_PLAN";

    // Error codes
    public static final String STATUS_CODE_GENERIC_ERROR = "10";
    public static final String STATUS_CODE_JSON_PARSING_ERROR = "11"; // This is
    // json
    // parsing
    // error
    // code
    public static final String STATUS_CODE_INITIATE_CHECKOUT_ERROR = "12";
    public static final String STATUS_CODE_ALTERNATE_FLOW = "21"; // This is
    // alternate
    // flow
    // codes
    // ....
    // starting
    // from 20

    public static final String REDIS_CHECKOUT_ERROR_JSON = "CHECKOUT_ERROR_JSON";

    public static final String ADD_UPDATE_FEATURE = "addUpdateFeatureService";
    public static final String ADD_UPDATE_PLAN = "addUpdatePlanService";
    public static final String VZW_ERROR_KEYS = "vzw_error_keys";
    public static final String NINETY_NINE = "99";

    public static final String UNDERSCORE = "_";
    public static final String ICONIC = "ICONIC";
    public static final String API_ERROR = "_API_ERROR";

    public static final String USER_DEVICE_TYPE = "userDeviceType";
    public static final String DESKTOP = "DESKTOP";


    public static final String PRE_ORDER = "preorder";
    public static final String BACK_ORDER = "backorder";
    public static final String EDGE = "edge";
    public static final String EDGE_CONTRACT_TERM = "99";
    public static final String SINGLE_LINE = "single line";
    public static final String MULTI_LINE = "multi line";
    public static final String ACCOUNT_NUMBER = "accountNumber";
    public static final String LOGIN_MTN = "loginMTN";
    public static final String FLOW = "flow";
    public static final String ZIPCODE = "ZIPCODE";
    public static final String USER_ZIP_CODE = "zipCode";
    public static final String AUTHENTICATED = "authenticated";
    public static final String UNAUTHENTICATED = "unauthenticated";
    public static final String CITY = "CITY";
    public static final String ROLE = "role";
    public static final String B2E = "B2E";
    public static final String GREETINGNAME = "greetingName";
    public static final String CUSTOMER_TYPE = "custType";
    public static final String ECPD_ID_QUERY_PARAM = "f";
    public static final String RYL_SSRV_ECPD_PROFILE_ID = "ryl_ssrv_ecpd_profile_id";
    public static final String N = "N";
    public static final String EMPTY_STRING = "";
    public static final String COMMA = ",";

    public static final String TRADEIN_GOTO_CART_IND = "gotoCart";

    public static final String HYPHEN_STR = "-";

    public static final String ACCOUNT_SHARE_PLAN_CACHEKEY = "ACCOUNT_SHARE_PLAN";

    /**
     * constant holds comma symbol
     */
    public static final String COMMA_SYMBOL = ", ";
    /**
     * constant holds hifun symbol
     */
    public static final String HIFUN_SYMBOL = "-";
    /**
     * constant to hold Hash symbol
     */
    public static final String HASH_SYMBOL = "#";
    /**
     * Constant to hold Empty String
     */
    public static final String BLANKSPACE = "";
    /**
     * This property holds the constant 'Y'
     */
    public static final String Y = "Y";

    // Pendingorder conditions

    public static final String SUS = "SUS";
    public static final String REC = "REC";
    public static final String DIS = "DIS";
    public static final String SFO = "SFO";
    public static final String LPP = "LPP";
    public static final String APP = "APP";

    public static final String SUSPEND = "Suspend";
    public static final String RECONNECT = "Reconnect";
    public static final String DISCONNECT = "Disconnect";
    public static final String PO_FEATURE_CHANGE = "Feature Change";
    public static final String LINE_LEVEL_PRICE_PLAN = "Line Level Price Plan";
    public static final String ACCOUNT_LEVEL_PRICE_PLAN = "Account Level Price Plan";

    public static final String PRODUCT_OFFERS_CACHEKEY = "PROD_OFFER";

    public static final String ACCOUNT_PRODUCT_OFFERS_CACHEKEY = "ACCT_PROD_OFFER";

    public static final String MULTILINE_FEATURES_CACHEKEY = "MULTILINE_FEATURES";
    public static final String MULTILINE_FEATURES_AAL_CACHEKEY = "MULTILINE_FEATURES_AAL";
    public static final String MULTILINE_FEATURES_FIP_CACHEKEY = "MULTILINE_FEATURES_FIP";

    public static final String CPC_SELECTED_PLAN_CACHEKEY = "SEL_PLAN";

    public static final String CPC_BILL_CYCLE_FE_JSON_CACHEKEY = "billCycleFeJson";

    public static final String S = "S";
    public static final String M = "M";
    public static final String L = "L";
    public static final String U = "U";

    public static final String TVP2 = "TVP2";

    public static final String ME = "ME";

    public static final String TVP3 = "TVP3";

    public static final String UNLIMITED_SOR_DATA_ALLOWANCE = "9999";

    public static final String CPC_TVP2_CATEGORY_CODE_1 = "56";

    public static final String CPC_TVP2_CATEGORY_CODE_2 = "60";

    public static final String CPC_TVP1_CATEGORY_CODE_2 = "54";

    public static final String CPC_ME_CATEGORY_CODE_1 = "50";

    public static final String CPC_ME_CATEGORY_CODE_2 = "52";


    public static final String GENERIC_ERROR_JSON = "GENERIC_ERROR_JSON";
    public static final String COMMON_PROPS = "vzw_ecomm_props";
    public static final String ERRORPAGE = "ERRORPAGE";
    public static final String GLOBAL_NAV_JSON = "GLOBAL_NAV_JSON_PREORDER";
    public static final String AREA_REGION = "areaRegion";
    public static final String DEVICE_TYPE = "deviceType";
    public static final String LEGACY_MOBILE_ERROR_JSON = "LEGACY_MOBILE_ERROR_JSON";
    public static final String ONE_DIGITAL_MOBILE_ERROR_JSON = "ONE_DIGITAL_MOBILE_ERROR_JSON";
    public static final String LEGACY_DESKTOP_ERROR_JSON = "LEGACY_DESKTOP_ERROR_JSON";

    public static final String INS = "INS";
    public static final String LAC = "LAC";
    public static final String OPT = "OPT";
    public static final String UNDER_SCORE = "_";
    public static final String ENABLE_CUSTOM_DISPATCHER = "ENABLE_CUSTOM_DISPATCHER";
    public static final String PAGE_NAME_TRADEIN = "TRADEIN";
    public static final String JSON_OUTPUT_TYPE = "json";
    public static final String SALT_SHA256 = "ONEDIGITAL_SALT_SHA256_STRING";

    public static final String SMS_DEVICE_INFO = "SMS_DEVICE_INFO";

    public static final String GRIDWALL_CACHE_WARMUP_CALL = "GRIDWALL_CACHE_WARMUP_CALL";
    public static final String SERVICE_ACTOR_RETRIEVE_CART = "retrieveCart";
    public static final String HAS_SUBMITTED_TRADEIN_CREDIT = "hasSubmittedTradeinCredit";
    public static final String ACCOUNT_SERVICE_ACTOR = "acctServiceActor";
    public static final String PENDING_ORDER = "PENDING_ORDER";
    public static final String CART_DEVICE_MAX_LIMIT_REACHED = "CART_DEVICE_MAX_LIMIT_REACHED";
    public static final String ACCT_LINE_LIMIT = "ACCT_LINE_LIMIT";
    public static final String TVPSL_MAX_LIMIT_EXCEEDED = "TVPSL_MAX_LIMIT_EXCEEDED";
    public static final String TVPSL_SMARTPHONE_MAX_LIMIT_EXCEEDED = "TVPSL_SMARTPHONE_MAX_LIMIT_EXCEEDED";
    public static final String TVPSL_TABLET_MAX_LIMIT_EXCEEDED = "TVPSL_TABLET_MAX_LIMIT_EXCEEDED";
    public static final String TVPSL_CONNECTED_DEVICE_MAX_LIMIT_EXCEEDED = "TVPSL_CONNECTED_DEVICE_MAX_LIMIT_EXCEEDED";
    public static final String CONNECTED_CAR = "Connected Car";
    public static final String EMAIL_HASH = "ehash";
    public static final String EMAIL_HASH_2 = "ehash2";

    public static final String ERROR_PAGE = "ERRORPAGE";
    public static final String CPC_ERROR_PAGE = "CPC_ERROR_PAGE";
    public static final String RECOMMENDEPLAN_API_URL_KEY = "recommendedPlan_api_url";

    public static final String CPC_CONTEXT_PATH = "/digital/cpc";

    public static final String CURRENCY_SYMBOL = "$";
    public static final String CURRENCY_CODE_USD = "USD";

    public static final String CPC_SAFETY_MODE_PARAM = "safetyMode";

    public static final String SAFETY_MODE_ENABLED = "yes";

    public static final String KEY_SEPERATOR = "_";

    public static final String CPC_RESP_CACHE_KEYS = "vzw_cpc_cachekeys";

    public static final String CPC_LANDINGPAGE_RESP_CACHEKEY = "CPC_LANDINGPAGE_RESP_CACHEKEY";


    public static final String CPC_EXPLOREPAGE_RESP_CACHEKEY_TVP2 = "CPC_EXPLOREPAGE_RESP_CACHEKEY_TVP2";

    public static final String CPC_EXPLOREPAGE_RESP_CACHEKEY_LEGACY = "CPC_EXPLOREPAGE_RESP_CACHEKEY_LEGACY";

    public static final String CPC_EXPLOREPAGE_RESP_CACHEKEY_SL = "CPC_EXPLOREPAGE_RESP_CACHEKEY_SL";
    public static final String CPC_EXPLOREPAGE_RESP_CACHEKEY_ML = "CPC_EXPLOREPAGE_RESP_CACHEKEY_ML";

    public static final String ME_FLOW = "ME";
    public static final String TVP2_FLOW = "TVP2";
    public static final String TVP2_FLOW_SL = "TVP2_SL";
    public static final String TVP2_FLOW_ML = "TVP2_ML";

    public static final String CPC_FLOW_CACHE_KEY = "CPC_FLOW_CACHE_KEY";

    public static final String CPC_SAFETYMODE_RESP_CACHEKEY = "CPC_SAFETYMODE_RESP_CACHEKEY";

    public static final String CPC_EFFDATE_RESP_CACHEKEY = "CPC_EFFDATE_RESP_CACHEKEY";
    public static final String CPC_CACHE_LOGIN_MTN = "CPC_CACHE_LOGIN_MTN";

    public static final String CACHE_PATTERN = "*";

    public static final String ENABLE_ACCOUNT_ASYNC_CALL = "ENABLE_ACCOUNT_ASYNC_CALL";
    public static final String ENABLE_ACCOUNT_ASYNC_CALL_TRUE = "Y";

    public static final String CPC_SUCCESSFUL = "cpcSuccessful";
    public static final String SERVICE_ACTOR_INITIATE_SESSION = "initiateSession";

    public static final String ORDER_CONFIRMATION_IMG_URL = "https://ss7.vzw.com/is/image/VerizonWireless/1.3_MV_BuyandUpgrade_ConfirmationPage_Interstital";


    public static final String CORE_LOG_INDEX = "ecom_prospect_akkalog";
    public static final String PLAY_LOG_TYPE = "ecom_prospect_playlogs";

    public static final String SERVICE_ACTOR_TRADEIN_DEVICES = "tradeInDevices";
    public static final String SERVICE_ACTOR_TRADEIN_CARRIERS = "tradeInCarrierService";
    public static final String SERVICE_ACTOR_TRADEIN_SUMMARY = "tradeInSummary";
    public static final String SERVICE_ACTOR_TRADEIN_POPULATE_SHIPPING_INFO = "tradeInPopulateShippingInfo";
    public static final String SERVICE_ACTOR_TRADEIN_DEVICE_LANDING = "tradeInDeviceLandingPage";
    public static final String SERVICE_ACTOR_TRADEIN_UPDATE_SHIPPING_INFO = "tradeInUpdateShippingInfo";
    public static final String SERVICE_ACTOR_TRADEIN_PROMOTION = "tradeInPromotion";
    public static final String SERVICE_ACTOR_TRADEIN_DEVICE_VARIANT_DETAILS = "tradeInDeviceVariants";
    public static final String SERVICE_ACTOR_TRADEIN_DEVICE_ID_VALIDATION = "tradeInDeviceIdValidation";
    public static final String SERVICE_ACTOR_TRADED_DEVICES = "tradedDevices";
    public static final String SERVICE_ACTOR_DOTCOM_CART = "dotcomCartDetails";
    public static final String SERVICE_ACTOR_SUBMIT_TRADEIN = "submitTradeIn";
    public static final String SERVICE_ACTOR_REMOVE_TRADEIN = "removeTradeIn";
    public static final String SERVICE_ACTOR_ACCOUNT_DEVICE_TRADEIN = "tradeInAccountDevice";
    public static final String PLAN_TYPE_SL = "SL";
    public static final String PLAN_TYPE_ML = "ML";
    public static final String EMAIL_CART_IS_SHOP_ALLOWED_ERROR = "EMAIL_CART_IS_SHOP_ALLOWED_ERROR";
    public static final String EMAIL_CART_IS_MTN_ELIGIBLE_UPGRADE = "EMAIL_CART_IS_MTN_ELIGIBLE_UPGRADE_ERROR";
    public static final String ELIGIBLE_OFFERS_ACTOR = "eligibleOffersActor";

    public static final String INPUT_DATA = "inputData";
    public static final String PRICE_PLAN_ID_99999 = "99999";
    public static final String SERVICE_ACTOR_RTD_MY_OFFER_DETAIL = "rtdMyOfferActor";
    public static final String SERVICE_ACTOR_MS_MY_OFFERS = "msMyOffers";
    public static final String SERVICE_ACTOR_RTD_NBA = "rtdNBA";
    public static final String SERVICE_ACTOR_RTD_OFFER = "rtdNBAOffer";
    public static final String DATE_FORMAT = "MM/dd/yyyy";

    //RTD My Offer
    public static final String KILL_MY_OFFER_INTEGRATION = "KILL_MY_OFFER_INTEGRATION";
    public static final String RTD_MY_OFFER_FLOW_LIST = "RTD_MY_OFFER_FLOW_LIST";
    public static final String RTD_MY_OFFER_DISALLOW_FLOW_LIST = "RTD_MY_OFFER_DISALLOW_FLOW_LIST";
    public static final String MYOFFER_CQ_KEYS = "MYOFFER_CQ_KEYS";
    public static final String SECONDARY_CTA_LABEL = "SECONDARY_CTA_LABEL";
    public static final String PRIMARY_CTA_LABEL = "PRIMARY_CTA_LABEL";
    public static final String LABEL = "label";
    public static final String MY_OFFERS_LIST_CACHE_KEY = "MY_OFFERS_LIST";
    public static final String DISPLAY_MY_OFFERS_IN_PAGES = "DISPLAY_MY_OFFERS_IN_PAGES";
    public static final String TVP1 = "TVP1";
    public static final String RTD_SUCCESS_CODE = "0";
    public static final String RTD_CALL_REASON_OFFERS = "Offers";
    public static final String RTD_CALL_REASON_ACTIONS = "Actions";
    public static final String RTD_RECOMMENDATION_LIST = "RTD_RECOMMENDATION_LIST";

    public static final String SERVICE_ACTOR_RTD_SUBMIT = "rtdSubmitService";
    public static final String SERVICE_ACTOR_RTD_CAPTURE_INTEGRATION = "rtdCaptureIntegration";
    public static final String SERVICE_ACTOR_RTD_PROPOSITION = "rtdPropositionService";

    public static final String SERVICE_ACTOR_NUMBER_SHARE_MTN_DEATIL_INFO = "numberShareEligibleMtnInfo";

    public static final String DESTINATION_URL = "destinationURL";

    public static final String MY_OFFERS_DATA_MAP_OFFER_ID = "offerId";
    public static final String MY_OFFERS_DATA_MAP_RANK = "rank";
    public static final String MY_OFFERS_DATA_MAP_COMPLIANCE_CODE = "complianceCode";
    public static final String MY_OFFERS_DATA_MAP_FULFILLMENT_CODE = "fulfillmentCode";
    public static final String MY_OFFERS_DATA_MAP_MTN = "t";
    public static final String MY_OFFERS_DATA_MAP_CACHE_KEY = "MY_OFFERS_DATA_MAP";
    public static final String MYOFFER_CQ = "MYOFFER_CQ_";

    public static final String SERVICE_ACTOR_ACCESSORIES_DETAIL = "accessoriesDetail";

    //Recommended Accessories
    public static final String SERVICE_ACTOR_ACCESSORIES = "recommendedAccessories";
    public static final String RECOMMENDED_ACCESSORIES_ACTOR = "recommendedAccessoriesActor";

    public static final String PROPOSITION_DISPOSITION_OPTION_ID = "78";

    public static final String UPGRADE_REASON = "upgradeReason";
    public static final String CATEGORY_TYPE = "categoryType";
    public static final String RESTRICTED_OFFER = "restrictedOffer";
    public static final String REQUIRED_TURN_IN = "requiredTurnIn";
    public static final String EXTERNAL_ID = "externalID";
    public static final String SERVICE_ACTOR_SUBMIT_NUMBER_SHARE = "submitNumberShare";
    public static final String SUBMIT_NUMBER_SHARE_BUSINESS_ACTOR = "submitNumberShareBusinessActor";
    public static final String AUTOPAY_ACTOR_ROOT = "autoPayUpdateBusinessActor";
    public static final String VALIDATE_DEBIT_CARD_ACTOR="validateDebitCardBusinessActor";
    public static final String MY_OFFER_WUF = "wuf";
    public static final String MY_OFFER_RESTRICTED_OFFER = "restrictedOffer";

    public static final String CONNECTED_DEVICE = "Connected Device";
    public static final String TABLET = "Tablet";
    public static final String NUMBER_SHARE_ELIGIBLE = "numberShareEligible";
    public static final String COLON = ":";
    public static final String CAMPAIGN = "CMP";

    public static final String MY_OFFERS_PROPOSITION_ID = "MY_OFFERS_PROPOSITION_ID";


    public static final String ACCEPT_HEADER = "Accept";
    public static final String ACCEPT_HEADER_VALUE = "application/json";
    public static final String USER_AGENT_HEADER = "User-Agent";

    public static final String NO_CACHE_CONTROL="no-cache";

    public static final String IS_PAST_DUE = "isPastDue";
    public static final String PAST_DUE_ACCEPTED = "pastDueAccepted";
    public static final String IGNORE_PAST_DUE = "ignorePastDue";
    public static final String ADD_PAST_DUE_TO_ORDER = "addPastDueToOrder";
    public static final String HAS_SUBMITTED_NUMBERSHARE_DETAILS = "hasSubmittedNumberShareDetails";

    public static final String SHOP_LANDING_URL_MAPPING = "SHOP_LANDING_URL_MAPPING";

    public static final String NAV_STATE_ELIGIBLE_TITLES = "NAV_STATE_ELIGIBLE_TITLES";

    public static final String MYOFFERS_TYPE_TO_OFFERIDS_MAP = "MYOFFERS_TYPE_TO_OFFERIDS_MAP";

    public static final String INTENT_DECISION_ACTOR = "intentDecision";

    public static final String FROM_EMAIL = "fromEmail";

    public static final String PAST_DUE_ENABLED = "PAST_DUE_ENABLED";
    //Promo
    public static final String PROMO_ERROR_LABEL_CQ_KEYS = "PROMO_ERROR_LABEL_PREORDER_CQ_KEYS";
    public static final String ERROR_LABEL = "ERROR_LABEL_";
    public static final String PROMO = "promo";

    public static final String PAST_DUE_PAGE_MTN_NEXT_LINK = "PAST_DUE_PAGE_MTN_NEXT_LINK";
    public static final String PAST_DUE_PAGE_AUTH_NEXT_LINK = "PAST_DUE_PAGE_AUTH_NEXT_LINK";
    public static final String PAST_DUE_PAGE_NO_THANKS_LINK = "PAST_DUE_PAGE_NO_THANKS_LINK";

    public static final String MY_OFFERS_DATA_RANK = "rank";
    public static final String MY_OFFERS_DATA_EXTERNAL_ID = "externalID";
    public static final String MY_OFFERS_DATA_PROPOSITION_ID = "propositionID";
    public static final String MY_OFFERS_DATA_DISPOSITION_LIST_ID = "dispositionListID";
    public static final String MY_OFFERS_DATA_DISPOSITION_OPTION_ACCEPT_ID = "dispositionOptionAcceptID";
    public static final String MY_OFFERS_DATA_DISPOSITION_LABEL_ACCEPT = "Accept";
    public static final String MY_OFFERS_DISPOSITION_DATA_MAP = "MY_OFFERS_DISPOSITION_DATA_MAP";
    public static final String ACC_COUNT = "ACC_COUNT";

    public static final String INITIATE_CHECKOUT_SUCCESS = "INITIATE_CHECKOUT_SUCCESS";

    public static final String ENABLED_FLAG = "Y";

    public static final String ICONIC_FLOW_ENABLED = "ICONIC_FLOW_ENABLED";
    public static final String ICONIC_FEATURE_FOM_ENABLED = "ICONIC_FEATURE_FOM_ENABLED";

    public static final String ACCESS_RULES_MAP = "ACCESS_RULES_MAP";
    public static final String ACCESS_RULES_METHODS_MAP = "ACCESS_RULES_METHODS_MAP";
    public static final String ACCOUNT_MANAGER = "accountManager";
    public static final String ACCOUNT_HOLDER = "accountHolder";
    public static final String Z = "Z";
    public static final String MTN_INSTALLMENT_TYPE_CODE_E = "E";

    public static final String MIXED_PURCHASE_PATHS = "MOT";

    public static final String PLAY_SESSION = "playSessionId";

    public static final String FEATURE_LAC = "LAC";
    public static final String PIPE_KEY = "|";

    public static final String MTN_STATUS_CODE_S = "S";
    public static final String MTN_STATUS_REASON_CODE_99 = "99";
    public static final double DEFAULT_LINE_ACCESS_CHARGE = 20;

    public static final String POS_SERVICE_ACTOR_ADD_UPDATE_ADDRESS = "addOrUpdateAddress";
    public static final String POS_SERVICE_ACTOR_SPLIT_ADDRESS = "splitAddress";
    public static final String POS_SERVICE_ACTOR_GENERATE_INSTALLMENT_CONTRACT = "generateInstallmentContract";
    public static final String ADDRESS_VALIDATION_SERVICE = "addressValidation";

    // Plan SorCategory Codes
    public static final String SOR_CATEGORY_CODE_59 = "59";
    public static final String SOR_CATEGORY_CODE_50 = "50";
    public static final String SOR_CATEGORY_CODE_51 = "51";
    public static final String SOR_CATEGORY_CODE_52 = "52";
    public static final String SOR_CATEGORY_CODE_53 = "53";
    public static final String SOR_CATEGORY_CODE_54 = "54";
    public static final String SOR_CATEGORY_CODE_55 = "55";
    public static final String SOR_CATEGORY_CODE_56 = "56";
    public static final String SOR_CATEGORY_CODE_60 = "60";
    public static final String SOR_CATEGORY_CODE_33 = "33";
    public static final String SOR_CATEGORY_CODE_21 = "21";
    public static final String SOR_CATEGORY_CODE_48 = "48";
    public static final String SOR_CATEGORY_CODE_36 = "36";
    public static final String SOR_CATEGORY_CODE_61 = "61";
    public static final String SOR_CATEGORY_CODE_67 = "67";
    public static final String SOR_CATEGORY_CODE_28 = "28";
    public static final String EUP_SUBMITTED_ORDERS_FR_DB = "fromDb";
    public static final String EUP_SUBMITTED_ORDERS_FR_OBJ = "fromObj";
    public static final String POS_ORDER_SHAREPLEX_ITEM = "posOrderSharePlexStatus";
    public static final String MTN = "mtn";

    public static final String BTA_TAX_WAIVE_IND = "BTA";

    public static final String CAS_CLUSTER_NAME = "CAS_CLUSTER_NAME";
    public static final String CAS_CLUSTER_NODES = "CAS_CLUSTER_NODES";
    public static final String ES_CLUSTER_NAME = "ES_CLUSTER_NAME";
    public static final String ES_CLUSTER_NODES = "ES_CLUSTER_NODES";
    public static final String CUSTOMER_TYPE_CODE_PE = "PE";
    public static final String CUSTOMER_TYPE_CODE_ME = "ME";
    public static final String CUSTOMER_TYPE_CODE_SL = "SL";
    public static final String CUSTOMER_TYPE_CODE_BE = "BE";

    public static final String CUSTOMER_TYPE_CODE_BD = "BD";
    public static final String EPP_CUSTOMER_TYPE = "EPP";
    public static final String B2E_CUSTOMER_TYPE = "B2E";
    public static final String B2C_CUSTOMER_TYPE = "B2C";

    public static final String B2C_CHANNEL_ID = "B2C";
    public static final String B2E_CHANNEL_ID = "B2E";

    public static final String B2C_SALES_REP_ID = "NPB2C";

    public static final String MONTHLY_PRICE_CONTRACT_TERM = "99";
    public static final String TWO_YEAR_CONTRACT_TERM = "24";
    public static final String FULL_RETAIL_CONTRACT_TERM = "0";

    public static final String CQ_LABEL = "label";
    public static final String CQ_HTML = "html";
    public static final String CQ_ERROR = "error";
    public static final String ACCESS_RULES_CQ_CONTENT = "ACCESS_RULES_PREORDER_CQ_KEYS";

    public static final String INTERNET = "Internet";
    public static final String HOMESOLUTIONS = "Home Solutions";
    public static final String CONNECTEDDEVICES = "3G Connected Device";
    public static final String TABLET_NAME = "Tablet";
    public static final String SMARTPHONE = "Smartphone";
    public static final String BASIC_PHONE = "Basic Phone";
    public static final String OTHER_DEVICES = "Other Devices";
    public static final String BASIC_PHONE_NO_SPACE = "BasicPhone";
    public static final String OTHER_DEVICES_NO_SPACE = "OtherDevices";
    public static final String ALIAS_IND_YES = "Y";
    public static final String SMARTPHONES = "smartphones";


    public static final String ZIP_CODE = "zip_code";
    public static final String RESPONSE = "response ";
    public static final String EPP = "EPP";
    public static final Object ALL_CUSTOMER_TYPE = "All";
    public static final String NSE_FLOW = "NSE";
    public static final String NSO_FLOW = "NSO";
    public static final String EUP_FLOW = "EUP";
    public static final String AAL_FLOW = "AAL";
    public static final String CPC_ONLY = "CPCONLY";
    public static final String AM_ROLE = "amRole";
    public static final String ACCOUNT_LEVEL_ACCESS_RULES_ERROR_CODES_MAPPING = "accountLevelAccessRulesErrorCodesMapping";
    public static final String MTN_LEVEL_ACCESS_RULES_ERROR_CODES_MAPPING = "mtnLevelAccessRulesErrorCodesMapping";
    public static final String SINGLE_LINE_NON_PHONE_PLANS = "97975,97991,97993,97994,97995,98986,98061,98245,97379,97380,97381,98315,97382,97383,97384,98314,23772";
    public static final String PLAN_LEVEL_ACCOUNT = "Account Level";
    public static final String PLAN_LEVEL_LINE = "Line Level";
    public static final String PLAN_TYPE_SINGLE_LINE = "Single Line";
    public static final String PLAN_TYPE_VOICE_ONLY = "Voice Only";
    public static final String PLAN_TYPE_MBB = "MBB";
    public static final String PLAN_TYPE_TVP2_SL = "TVP2_SL";
    public static final String PLAN_TYPE_TVP = "TVP";
    public static final String PLAN_TYPE_ME = "ME";
    //TVP2 SL sor collection code
    public static final String SOR_COLLECTION_CODE_TV203 = "TV203";

    public static final String OD_SELECTED_MTN_CHECK_FOR_EUP_ACCESS_RULES_ENABLE = "OD_SELECTED_MTN_CHECK_FOR_EUP_ACCESS_RULES_ENABLE";
    public static final String OD_POSTPAY_COMBO_ORDER_ENABLE = "OD_POSTPAY_COMBO_ORDER_ENABLE";

    public static final String POSTPAID_EUP_PO_REASON_CODES_KEY = "POSTPAID_EUP_PO_REASON_CODES";


    public static final String INSTALLMENT_LOAN_STATUS_CODE = "A";

    public static final String INSTALLMENT_LOAN_STATUS_CODE_AA = "AA";

    public static final String INSTALLMENT_LOAN_STATUS_CODE_AR = "AR";

    public static final String INSTALLMENT_LOAN_STATUS_CODE_E = "E";

    public static final String INSTALLMENT_LOAN_STATUS_CODE_U = "U";

    public static final String AKKA_LOG_INDEX = "ecom_onedigital_cpcakkalogs";

    public static final String INTERNET_AND_HOME = "INTERNET_AND_HOME";

    public static final String BATTERY_ACC_ITEM_DETECTED_IN_CART_MSG = "We noticed you have a battery in your cart";
    public static final String BATTERY_ACC_ITEM_DETECTED_IN_CART = "BATTERY_ACC_ITEM_DETECTED_IN_CART";

    /**
     * This property holds the constant 'B2E_TYPE_USER'
     */
    public static final String B2E_TYPE_USER = "B2E";
    /**
     * This property holds the constant 'B2C_TYPE_USER'
     */
    public static final String B2C_TYPE_USER = "B2C";
    /**
     * This property holds the constant 'EPP_TYPE_USER'
     */
    public static final String EPP_TYPE_USER = "EPP";
    public static final String RIO_DAC_CODE = "01032";
    public static final String GS3_DAC_CODE = "SAMSUNG_GEAR_S3_DACC_CODES";
    public static final String GS4_DAC_CODE = "SAMSUNG_GEAR_S4_DACC_CODES";
    public static final String DUBS_DAC_CODE = "DUBS_DAC_CODES";
    public static final String FEATURE_INDEX = "FEATURE_INDEX";
    public static final String FEATURE_INDEX_TYPE = "FEATURE_INDEX_TYPE";
    public static final String PLAN_INDEX = "PLAN_INDEX";
    public static final String PLAN_INDEX_TYPE = "PLAN_INDEX_TYPE";
    public static final String INVENTORY_INDEX = "INVENTORY_INDEX";
    public static final String INVENTORY_TYPE = "INVENTORY_TYPE";
    public static final String ACCESSOIRES_INVENTORY_INDEX = "ACCESSOIRES_INVENTORY_INDEX";
    public static final String ACCESSORIES_INVENTORY_TYPE = "ACCESSORIES_INVENTORY_TYPE";
    public static final String RECYCLING_DEVICES_INDEX = "RECYCLING_DEVICES_INDEX";
    public static final String RECYCLING_DEVICES_TYPE_AHEAD = "RECYCLING_DEVICES_TYPE_AHEAD";
    public static final String RECYCLING_DEVICES_MAX_VALUE_INDEX = "RECYCLING_DEVICES_MAX_VALUE_INDEX";
    public static final String RECYCLING_DEVICES_TYPE = "RECYCLING_DEVICES_TYPE";
    public static final String RECYCLING_DEVICES_MAX_VALUE_TYPE = "RECYCLING_DEVICES_MAX_VALUE_TYPE";
    public static final String RECYCLING_QESTIONS_INDEX = "RECYCLING_QESTIONS_INDEX";
    public static final String RECYCLING_QESTIONS_TYPE = "RECYCLING_QESTIONS_TYPE";
    public static final String DEVICES_INDEX = "DEVICES_INDEX";
    public static final String DEVICES_TYPE = "DEVICES_TYPE";
    public static final String MYLINK_INDEX = "MYLINK_INDEX";
    public static final String MYLINK_TYPE = "MYLINK_TYPE";
    public static final String ACCESSORIES_SEO_INDEX = "ACCESSORIES_SEO_INDEX";
    public static final String ACCESSORIES_SEO_TYPE = "ACCESSORIES_SEO_TYPE";
    public static final String PRODUCT_SIM_INDEX = "PRODUCT_SIM_INDEX";
    public static final String PRODUCT_SIM_TYPE = "PRODUCT_SIM_TYPE";
    public static final String ACCESSORIES_INDEX = "ACCESSORIES_INDEX";
    public static final String ACCESSORIES_INDEX_TYPE = "ACCESSORIES_INDEX_TYPE";
    public static final String ACCESSORIES_TYPE = "ACCESSORIES_TYPE";
    public static final String ACCESSORIES_RATINGS_INDEX = "ACCESSORIES_RATINGS_INDEX";
    public static final String ACCESSORIES_PRODUCT_TYPE = "product_accessory";
    public static final String ACCESSORIES_VIDEO_FIX="ACCESSORIES_VIDEO_FIX";
    public static final String ACCESSORIES_PRODUCT_BUNDLE_TYPE = "product_bundle";
    public static final String ACCESSORIES_NAME = "Accessories";
    public static final String ACCESSORIES_SITE_NAME = "accessories";
    public static final String DEVICES = "DEVICES";
    public static final String ACCESSORIES = "ACCESSORIES";
    public static final String GLOBAL_TEXT_INDEX = "GLOBAL_TEXT_INDEX";
    public static final String GLOBAL_TEXT_TYPE = "GLOBAL_TEXT_TYPE";
    public static final String DISCOUNT_BUNDLE_ELIGIBLE = "Discount Bundle Eligible";
    public static final String BUNDLE_BUILD_PDP_URL_CONSTANT  = "/od/cust/accessories/make-your-own-bundle?action=buildBundle&bundleItems=";
    public static final String BUNDLE_BUILD_PDP_URL  = "BUNDLE_BUILD_PDP_URL";

    public static final String MOD_TOKEN_INDEX_NAME = "MOD_TOKEN_INDEX";
    public static final String MOD_TOKEN_INDEX_TYPE = "MOD_TOKEN_INDEX_TYPE";

    public static final String STORE_LOCATOR_INDEX = "STORE_LOCATOR_INDEX";
    public static final String STORE_LOCATOR_INDEX_TYPE = "STORE_LOCATOR_INDEX_TYPE";

    public static final String PLAN_FEATURE_INDEX = "PLAN_FEATURE_INDEX";
    public static final String PLAN_FEATURE_INDEX_TYPE = "PLAN_FEATURE_INDEX_TYPE";
    public static final String DISABLE_ELASTIC_FOR_PREORDER_MTN_DETAILS = "DISABLE_ELASTIC_FOR_PREORDER_MTN_DETAILS";

    public static final String ZIPCODE_MARKET_INDEX = "ZIPCODE_MARKET_INDEX";
    public static final String ZIPCODE_MARKET_INDEX_TYPE = "ZIPCODE_MARKET_INDEX_TYPE";

    public static final String GEOLOCATION_INDEX = "GEOLOCATION_INDEX";
    public static final String GEOLOCATION_INDEX_TYPE = "GEOLOCATION_INDEX_TYPE";


    public static final String COMPATIBLE_PLAN_INDEX = "COMPATIBLE_PLAN_INDEX";
    public static final String COMPATIBLE_PLAN_INDEX_TYPE = "COMPATIBLE_PLAN_INDEX_TYPE";
    public static final String PLAN_DETAILS_INDEX = "PLAN_DETAILS_INDEX";
    public static final String PLAN_DETAILS_INDEX_TYPE = "PLAN_DETAILS_INDEX_TYPE";
    public static final String PLAN_COMPONENT_TYPE_V = "V";
    public static final String PLAN_COMPONENT_TYPE_VM = "VM";
    public static final String PLAN_COMPONENT_TYPE_VD = "VD";
    public static final String PLAN_COMPONENT_TYPE_D1 = "D1";
    public static final String PLAN_COMPONENT_TYPE_D2 = "D2";
    public static final String PLAN_TYPE_ME_TALK = "METalk";
    public static final String PLAN_TYPE_ME_TALKTEXTDATA = "METalkTextData";
    public static final String PLAN_TYPE_ME_DATA = "MEData";
    public static final String PLAN_TYPE_TVP_TALK = "TVPTalk";
    public static final String PLAN_TYPE_TVP1 = "TVP1.0";
    public static final String PLAN_TYPE_TVP2 = "TVP2.0";
    public static final String PLAN_TYPE_TVP3_SL = "TVP3_SL";
    public static final String PLAN_TYPE_TVP3 = "TVP3.0";
    public static final String BYOD_DUMMY_SKU = "ECOM-SERVICE-SKU";

    public static final String SERVICE_ACTOR_PROMO_LF = "promotionLF";
    public static final String SERVICE_ACTOR_PROMO_UF = "promotionUF";

    /**
     * Property used to hold the "STRING_CONSTANT_ONE"
     */
    public static final String STRING_CONSTANT_ONE = "1";
    public static final String STRING_CONSTANT_17 = "17";

    public static final String ORDER_ID = "orderId";
    public static final String ORIGIN = "origin";
    public static final String SMARTPHONE_DEVICE = "SMARTPHONE";
    public static final String SOURCE_URL = "source_url";
    public static final String FORWARD_SLASH = "/";

    public static final String TABLET_DEVICE = "TABLET";
    public static final String INTERNET_AND_HOME_DEVICE = "INTERNET_AND_HOME";
    public static final String CONNECTED_DEVICE_DEVICE = "CONNECTED_DEVICE";

    public static final String SMARTPHONE_DEVICE_TYPE = "3G Smartphone,4G Smartphone,5G Smartphone";
    public static final String TABLET_DEVICE_TYPE = "4G Tablet,3G Tablet,3G Tablets,4G Tablets,5G Tablet,5G Tablets";
    public static final String INTERNET_HOME_DEVICE_TYPE = "4G Router,4G Internet,3G Internet,4G Netbooks,Home Solutions";
    public static final String CONNECTED_DEVICE_TYPE = "3G Connected Device,4G Connected Device";

    public static final String DEVICE_ALLOWED_FOR_TVPSL = "SMARTPHONE,TABLET,CONNECTED_DEVICE";

    public static final String DEVICE = "Device";

    public static final String FLOW_TYPE = "flow_type";
    public static final String ORIGINATING_SYSTEM = "originating_system";
    public static final String VENDORID_REF_CUSTOMER_TYPE = "customer_type";
    public static final String AFFILIATE_TYPE = "affiliate_type";
    public static final String VENDOR_ID = "vendor_id";
    public static final String VREF_AFFILIATE_NOT_VALID_VAL = "NA_VAL";

    public static final String UBERPIN_LATITUDE = "uberPin_latitude";
    public static final String INSTALLBUILDING_ID = "installbuildingId";
    public static final String UBERPIN_LONGITUDE = "uberPin_longitude";

    // Installment Constants


    public static final String LOAN_TYPE_ACTIVE = "Active";

    public static final String LOAN_TYPE_PENDING = "Pending";

    public static final String ALWAYS_ELIGIBLE_KILL_SWITCH = "ALWAYS_ELIGIBLE_KILL_SWITCH";

    public static final String DEVICE_FAMILY_TYPE_CONNECTED = "Connected";


    public static final String SALES_MAKER_CUSTOMER_TYPE = "salesMakerCustomerType";
    public static final String CUSTOMER_TYPE_TO_ACC_LIMIT_MAP = "customerTypeToAccLimitMap";

    public static final String BASIC_PHONE_DEVICE_TYPE_KEY = "basicPhoneDeviceType";
    public static final String BASIC_PHONE_DEVICE_TYPE = "Basic Phones,Basic,Feature Phones,Feature Phone Unleashed,3G Multimedia";

    /**
     * Property to hold SKU_SFO
     */
    public static final String SKU_SFO = "sku-sfo";
    public static final String FEATURE_INCLUDED = "INCLUDED";
    public static final String FEATURE_OPTIONAL = "OPTIONAL";
    public static final String FEATURE_INSURANCE = "INSURANCE";
    public static final String INSUR = "INSUR";
    /**
     * This property holds the constant 'DATE_FORMAT_NO_TIME'. Basically used
     * for formating date alone and no time.
     */
    public static final String DATE_FORMAT_NO_TIME = "MM/dd/yyyy";
    public static final String ALIAS_IND_NO = "N";


    public static final String EDGE_UP_NOT_ELIGIBLE = "edgeUpNotEligibile";

    public static final String DISPLAY_EDGE_UP_NOT_ELIGIBLE_MSG = "displayEdgeUpNotEligibileMsg";

    public static final String EDGE_UP_ELIGIBLE_WITH_QUALIFYING_AMOUNT = "edgeUpEligibleWithQA";

    public static final String EDGE_UP_ELIGIBLE = "edgeUpEligibile";

    public static final String EDGE_FULL_BUYOUT_ONLY = "edgeFullBuyoutOnly";

    public static final String EDGE_UP_ON_BUY_OUT_CONTRACT = "edgeUPOnBuyOutContract";

    public static final String EDGE_UP_MTN_MISMATCH = "mtnMismatch";

    public static final String EDGE_UP_LOAN_NUMBER_MISMATCH = "loanNumberMismatch";

    public static final String PENDING_EDGE_UP = "pendingEdgeUp";

    public static final String ELIGIBLE_FOR_UPGRADE = "eligibleForUpgrade";

    public static final String IS_EDGEUP = "isEdgeup";


    public static final List<String> ACTIVE_LOAN_STATUS_CODE_LIST = Collections.unmodifiableList(Arrays.asList("A", "AA", "AR"));

    public static final String LOAN_MAINTENANCE_DETAILS_INQUIRY_INVALID_DATA_EXCEPTION = "laonMaintenanceDetailsInquiryInvalidDataException";

    public static final String LOAN_MAINTENANCE_DETAILS_INQUIRY_REPOSITORY_EXCEPTION = "laonMaintenanceDetailsInquiryRepositoryException";

    public static final String LOAN_MAINTENANCE_DETAILS_INQUIRY_SERVICE_EXCEPTION = "laonMaintenanceDetailsInquirySeviceException";

    public static final String LOAN_MAINTENANCE_DETAILS_INQUIRY_EXCEPTION = "laonMaintenanceDetailsInquiryWithException";

    public static final String CONSTANT_DOT = ".";
    public static final String DOLLOR_SYMBOL = "$";
    public static final String FEATURE_SPO = "SPO";
    public static final String CHARGE_CODE_ACCOUNT_LEVEL = "A";
    /**
     * This property holds the constant 'PIPE_SYMBOL'
     */
    public static final String PIPE_SYMBOL = "|";
    /**
     * constant to hold Feature value
     */
    public static final String FEATURE = "Feature";
    public static final String ACCESSORY = "Accessory";
    public static final String CUSTOM_BUNDLE = "CustomBundle";

    public static final Map<String, String> hashMap = new HashMap<>();

    static {
        hashMap.put("VOT_PENDING_ORDER", "01");
        hashMap.put("MTN_PERMANENTLY_INACTIVE", "02");
        hashMap.put("MTN_SUSPENDED", "03");
        hashMap.put("STAR_INDICATOR", "04");
        hashMap.put("HUB_DEVICE_INDICATOR", "05");
        hashMap.put("MTN_INSTALLMENT_CODE", "06");
        hashMap.put("PPLAN_PEND_ORD_IND", "08");
        hashMap.put("ICONIC_PENDING_ORDER", "09");
        hashMap.put("EUP_WITH_SPO_PENDING_ORDER", "10");
        hashMap.put("LINE_LEVEL_PENDING_ORDER", "11");
        hashMap.put(PENDING_ORDER, "12");
        hashMap.put("MDN_EXISTS_IN_CART_FOR_UPG", "13");
        hashMap.put("HUM_DEVICE_INDICATOR", "14");
    }
    public static final Map<String, String> MTN_LEVEL_ACCESS_RULES_ERROR_MAP = hashMap;


    /**
     * constant to hold Success
     */
    public static final String SUCCESS = "Success";
    public static final  String FAILURE = "Failure";
    public static final String TEXT_PARTIALMONTHCHARGES = "Monthly Access/Allowance Minutes - When you change your calling plan, we will bill for a partial "
            + "month or portion of the monthly access charge calculated from the date you begin service to the effective date of the calling plan change, plus the next month's access charge if we bill you in advance.";

    /**
     * The text promotions.
     */
    public static final String TEXT_PROMOTIONS = "By changing to the new calling plan, I will receive promotions (if any) "
            + "that apply to my new plan. The promotions associated with my current plan may no longer be valid.";
    public static final String ENABLE_SPLIT_SHIPMENT = "ENABLE_SPLIT_SHIPMENT";

    public static final String NUMBERSHARE_GRAFTING = "G";

    public static final String DEFAULT_LOCATION_CODE = "9999999";
    public static final String PARAM_MAP = "paramMap";
    public static final String EXCEPTION = "Exception";
    public static final String PENDING_ORDER_NOT_FOUND_ACCOUNT_MSG = "pending order not found in account";
    public static final String PENDING_ORDER_NOT_FOUND_ACCOUNT = "PENDING_ORDER_NOT_FOUND_ACCOUNT";
    public static final String PENDING_ORDER_NOT_FOUND_MTN_MSG = "pending order not found with mtn provided";
    public static final String PENDING_ORDER_NOT_FOUND_MTN = "PENDING_ORDER_NOT_FOUND_MTN";

    public static final String IGNORE_CASH_ONLY_IND = "ignoreCashOnlyInd";
    public static final String IGNORE_COLLECTIONS_IND = "ignoreCollectionsInd";
    public static final String SERVICE_SUCCESS_MESSAGE = "Service completed Successfully.";


    public static final String GENERIC_SERVICE_EXCEPTION_MSG = "Problem Occured while processing request";
    public static final String GENERIC_SERVICE_EXCEPTION = "GENERIC_SERVICE_EXCEPTION";
    public static final String POSTPAY_SITE_ID = "POSTPAY_SITE_ID";

    public static final String ZERO_STIRNG = "0";
    public static final int ZERO = 0;

    public static final String VZW_PROPERTY_RESOURCES = "com.vzw.common.constant.VZWPropertyNameResources";
    public static final String OTHER = "OTHER";
    public static final double DOUBLE_ZERO = 0.0D;
    public static final String POST_PAID_SITE_ID = "400001";
    public static final String PREPAY_SITE_ID = "100002";
    public static final int ONE = 1;
    public static final String VISA_TYPE = "visa";
    public static final String VISA_TYPE_CAMEL_C = "Visa";
    public static final String MASTER_TYPE = "master";
    public static final String MASTERCARD_TYPE_LOWER_C = "mastercard";
    public static final String MASTERCARD_TYPE = "masterCard";

    public static final String AMEX_TYPE = "amex";
    public static final String AMEX_TYPE_C = "Amex";
    public static final String DISCOVER_TYPE = "discover";
    public static final String DISCOVER_TYPE_C = "Discover";


    public static final String EDGE_TO_TWOYR_UPG_REA_CODE = "T2";
    public static final  String DEVICE_TYPE_4GE = "4GE";
    public static final String SIM = "Sim";
    public static final String PLAN = "Plan";
    public static final String DACC_PREPAY = "P";
    public static final String BUNDLE = "Bundle";
    public static final String MONEY = "Money";
    public static final String ISMONTHLYPREPAY = "isMonthlyPrePay";
    public static final String PLANAMOUNT = "planAmount";
    public static final String PLANCODE = "planCode";
    public static final String ACTIVECODE = "activeCode";
    public static final String ACTIVEFEE = "activeFee";
    public static final String CONFIGITEM = "configItem";
    public static final  String ORDER = "Order";
    public static final String ITEMCODE_PLAN_MONEY = "SURESTART";
    public static final String PHONE_ITEM_TYPE = "PHONE";


    public static final String SITE_NAME_ID_MAP = "SITE_NAME_ID_MAP";
    public static final String ORDER_TYPE = "ORDER_TYPE";
    public static final String LOCATION_CODE = "LOCATION_CODE";
    public static final String DEFAULT_TIMEZONE = "DEFAULT_TIMEZONE";
    public static final String CREDIT_APPROVAL_STATUS = "CREDIT_APPROVAL_STATUS";
    public static final String MOBILE_NUMBER = "MOBILE_NUMBER";
    public static final String BUSS_OR_INDV_CUSTOMER = "BUSS_OR_INDV_CUSTOMER";
    public static final String DEPLETION_TYPE = "DEPLETION_TYPE";
    public static final String UPGRADE_IND = "UPGRADE_IND";
    public static final String TAX_EXEMPT_ID = "TAX_EXEMPT_ID";
    public static final String CONTRACT_TERM = "CONTRACT_TERM";
    public static final String DEFAULT_MARKET_ITEM_ID = "DEFAULT_MARKET_ITEM_ID";
    public static final String ITEM_TAB_SEQ_NUM = "ITEM_TAB_SEQ_NUM";
    public static final String SALE_TYPE = "SALE_TYPE";
    public static final String DEVICE_TYPE_CONF = "DEVICE_TYPE";
    public static final String DEVICE_ID = "DEVICE_ID";
    public static final String PRICE_PLAN_CATEGORY = "PRICE_PLAN_CATEGORY";
    public static final String CONTRACT_RANGE = "CONTRACT_RANGE";
    public static final String OLD_PLAN_FLAG = "OLD_PLAN_FLAG";
    public static final String NEW_PLAN_FLAG = "NEW_PLAN_FLAG";
    public static final String RATE_PLAN_TYPE = "RATE_PLAN_TYPE";
    public static final String PRICE_PLANE_QUIP_IND = "PRICE_PLANE_QUIP_IND";
    public static final String LONG_DISTANCE_CARRIER_CODE = "LONG_DISTANCE_CARRIER_CODE";
    public static final String VIS_ACTIVATION_OUTLET = "VIS_ACTIVATION_OUTLET";
    public static final String PRODUCT_ID = "PRODUCT_ID";
    public static final String CONTRACT_END_DATE = "CONTRACT_END_DATE";
    public static final String CUSTOMER_CLASS = "CUSTOMER_CLASS";
    public static final String CUSTOMERTYPE_CODE = "CUSTOMERTYPE_CODE";
    public static final String CUSTOMERTYPE = "CUSTOMER_TYPE";
    public static final String CUSTOMER_ASSOC = "CUSTOMER_ASSOC";
    public static final String INVOICE_NODE = "INVOICE_NODE";
    public static final String STI_IND = "STI_IND";
    public static final String PINCODE = "PINCODE";
    public static final String TRANSACTION_TYPE = "TRANSACTION_TYPE";
    public static final String PHONE_CALLS = "PHONE_CALLS";
    public static final String EMAILS = "EMAILS";
    public static final String SURVEYS = "SURVEYS";
    public static final String WALDO_VALIDATION = "WALDO_VALIDATION";
    public static final String PURCHASE_INDICATOR = "PURCHASE_INDICATOR";
    public static final String TERMINAL_OPTION_CODE = "TERMINAL_OPTION_CODE";
    public static final String ATTENTION = "ATTENTION";
    public static final String DISCRSN_CODE = "DISCRSN_CODE";
    public static final String MIN_NUMBER = "MIN_NUMBER";
    public static final String BILLING_SYSTEM = "BILLING_SYSTEM";
    public static final String PRICE_TYPE = "PRICE_TYPE";
    public static final String URSP_PRICE_TYPE = "URSP_PRICE_TYPE";
    public static final String CREDIT_CARD_PREAUTH_TYPE_VALUE_MAP = "CREDIT_CARD_PREAUTH_TYPE_VALUE_MAP";
    public static final String CREDIT_CARD_TYPE_TO_NAME_MAP = "CREDIT_CARD_TYPE_TO_NAME_MAP";
    public static final String VIS_BILL_FORMAT_CODE = "VIS_BILL_FORMAT_CODE";
    public static final String NPA_NXX_RESULTS_FROM = "NPA_NXX_RESULTS_FROM";
    public static final String BILLING_SYSTEM_OF_MTN = "BILLING_SYSTEM_OF_MTN";

    public static final String MAX_ALLOWED_ITEMS_IN_CART = "MAX_ALLOWED_ITEMS_IN_CART";
    public static final String MAX_DEVICES_ALLOWED_IN_CART = "MAX_DEVICES_ALLOWED_IN_CART";
    public static final String POSTPAY_SITE_ID_VAL = "400001";
    public static final String VISION_CLIENT_ID = "VZW-INTERN";
    public static final String DUMMY_SKU_SOR_ID = "DUMMY_SKU_SOR_ID";

    public static final String BYOD_UNLIMITED_PLAN_BLOCKED_DEVICE_SOR_IDS = "BYOD_UNLIMITED_PLAN_BLOCKED_DEVICE_SOR_IDS";
    public static final String NSO_E_SIM_CAPABLE="nso_eSimCapable";
    public static final String NSO_NUMBERSHARE_CAPABLE="nso_numberShareCapable";
    public static final String CATALOG_REF_ID = "catalogRefId";
    public static final String SMART_IMEI_DESKTOP_WHITE_LIST_MTNS = "SMART_IMEI_DESKTOP_WHITE_LIST_MTNS";
    public static final String SMART_IMEI_DESKTOP_THROTTLE_MTN_LIST = "SMART_IMEI_DESKTOP_THROTTLE_MTN_LIST";
    public static final String SMART_IMEI_THROTTLE_ENABLED = "SMART_IMEI_THROTTLE_ENABLED";
    public static final String SMART_IMEI_FLOW_ENABLED = "SMART_IMEI_FLOW_ENABLED";
    public static final String EMPTY = "";
    public static final String ASURION_DEVICE = "ASURION";
    public static final String GSMA_DEVICE = "GSMA";
    public static final String GRANDFATHERED = "grandfathered";
    public static final String NSO_SIM_ID="nso_simId";
    public static final String NSO_EMBEDDED_SIM_ID="nso_embedded_simId";

    public static final String ADD = "ADD";
    public static final String REMOVE = "REMOVE";

    public static final String SECURE_IMAGE_PATH = "SECURE_IMAGE_PATH";
    public static final String DEVICE_IMAGE_LARGE = "DEVICE_IMAGE_LARGE";
    public static final String DEVICE_IMAGE_MINI = "DEVICE_IMAGE_MINI";

    //CHeckout related
    public static final String ENABLE_PREAUTH_PROP_KEY = "ICONIC_ENABLE_PREAUTH";
    public static final String BILL_TYPE_CODE_POSTPAID = "C";
    public static final String DEFAULT_SHIPPING_OPTION_ID = "DEFAULT_SHIPPING_OPTION_ID";
    public static final String DEFAULT_SHIPPING_OPTION_SHORT_DESCRIPTION = "DEFAULT_SHIPPING_OPTION_SHORT_DESCRIPTION";
    public static final String DEFAULT_SHIPPING_OPTION_SHIPPING_DESCRIPTION = "DEFAULT_SHIPPING_OPTION_SHIPPING_DESCRIPTION";
    public static final String DEFAULT_SHIPPING_OPTION_COST = "DEFAULT_SHIPPING_OPTION_COST";

    public static final String GET_MTN_DETAILS_BUSINESS_ACTOR = "getMTNDetailsBusinessActor";
    public static final String SELECTED_MTN_DETAILS_ACTOR = "selectedMTNDetailsBusinessActor";

    public static final String BILL_TYPE_CODE = "C";
    public static final String CUSTOMER_TYPE_CODE = "PE";
    /**
     * constant to hold DEVICE_TYPE_3G
     */
    public static final String DEVICE_TYPE_3G = "3G";
    /**
     * constant to hold DEVICE_TYPE_4G
     */
    public static final String DEVICE_TYPE_4G = "4G";
    public static final  String DEVICE_TYPE_5G = "5G";

    public static final String EDGE_TO_EDGE_UPG_REA_CODE = "TA";
    public static final String EARLY_EDGE_UPG_REA_CODE = "SA";
    public static final String EARLY_EDGE_UPG_REA_CODE_SC = "SC";
    public static final String EARLY_EDGE_UPG_REA_CODE_EC = "EC";
    public static final String EARLY_UPG_REA_CODE = "E2";
    public static final String MONTH_TO_MONTH_UPG_REA_CODE = "UN";
    public static final String MONTH_TO_MONTH_CERTIFIED_PRE_OWNED_UPG_REA_CODE = "CP";
    public static final String EDGE_2D_UPG_REA_CODE = "2D";
    public static final String EDGE_UPG_REA_CODE = "EA";

    public static final String UPGRADE_FEE = "UPGRADE_FEE";
    public static final String UPGRADE_FEE_DPP_FRP = "UPGRADE_FEE_DPP_FRP";
    public static final String APPLY_UPGRADE_FEE_ENABLED = "APPLY_UPGRADE_FEE_ENABLED";
    public static final String UPGRADE_FEE_WAIVED_OFF_EXISTING_PRODUCT_LIST = "UPGRADE_FEE_WAIVED_OFF_EXISTING_PRODUCT_LIST";
    public static final String UPGRADE_FEE_WAIVED_OFF_SELECTED_PRODUCT_LIST = "UPGRADE_FEE_WAIVED_OFF_SELECTED_PRODUCT_LIST";
    public static final String ACTIVATION_FEE_WAIVED_OFF_SELECTED_PRODUCT_LIST = "ACTIVATION_FEE_WAIVED_OFF_SELECTED_PRODUCT_LIST";

    public static final String TYPE_INDICATOR_A = "A";
    public static final String FEATURE_TYPE_SPO = "SPO";
    public static final String FEATURE_TYPE_TAP = "TAP";

    public static final String STATL_IND = "S";

    public static final String TYPE_INDICATOR_D = "D";

    public static final String CPC_ICONIC_NEW_FOM_FLOW = "AAL";
    public static final String SKU_RESTRICTIONS_INDEX = "SKU_RESTRICTIONS_INDEX";
    public static final String SKU_RESTRICTIONS_INDEX_TYPE = "SKU_RESTRICTIONS_INDEX_TYPE";
    public static final String PRICE_INDEX = "PRICE_INDEX";
    public static final String PRICE_INDEX_TYPE = "PRICE_INDEX_TYPE";
    public static final String ACCESSORIES_PRICE_INDEX = "ACCESSORIES_PRICE_INDEX";
    public static final String ACCESSORIES_PRICE_INDEX_TYPE = "ACCESSORIES_PRICE_INDEX_TYPE";
    public static final String TIME_OUT_CREDIT_WRITE = "submitCredit";

    public static final String TIME_OUT_CREDIT_READ = "retrieveCredit";

    public static final String VALIDATE_TRANSFER_NUMBER = "validateTransferNumberActor";

    public static final String UPDATE_PORT_IN_NUMBER_ACTOR = "updatePortInNumberActor";

    public static final String MF_MTN_DETAILS = "mfMtnDetails";

    public static final String ADDRESS_SERVICE_SUCCESS_CODE = "99000";

    public static final String APT = "APT";

    public static final String EDGE_BUY_OUT_CHECK_ENABLED = "EDGE_BUY_OUT_CHECK_ENABLED";
    public static final String DEVICE_ID_MISMATCH_MTN_ELIGIBILITY_CHECK_ENABLED = "DEVICE_ID_MISMATCH_MTN_ELIGIBILITY_CHECK_ENABLED";
    public static final String SMARTPHONE_DEVICE_TYPE_LIST = "SMARTPHONE_DEVICE_TYPE_LIST";
    public static final String BASICPHONE_DEVICE_TYPE_LIST = "BASICPHONE_DEVICE_TYPE_LIST";
    public static final String TABLET_DEVICE_TYPE_LIST = "TABLET_DEVICE_TYPE_LIST";
    public static final String INTERNET_HOME_DEVICE_TYPE_LIST = "INTERNET_HOME_DEVICE_TYPE_LIST";
    public static final String CONNECTED_DEVICE_TYPE_LIST = "CONNECTED_DEVICE_TYPE_LIST";
    public static final String BASIC_PHONE_DEVICE_TYPE_LIST = "BASIC_PHONE_DEVICE_TYPE_LIST";
    public static final String ORIGINATING_SYSTEM_VENDOR_ID_MAP = "ORIGINATING_SYSTEM_VENDOR_ID_MAP";
    public static final String ORIGINATING_SYSTEM_VENDOR_ID_MAP_AFFILIATES = "ORIGINATING_SYSTEM_VENDOR_ID_MAP_AFFILIATES";
    public static final Double DOUBLE_ZERO_AMOUNT = 0.00;
    public static final String TAX_PRO_INT_ACTOR_REF = "taxProcessorIntegrationActorRef";
    public static final String UPDATE_PAYMENT_INFO_URL = "UPDATE_PAYMENT_INFO_URL";
    public static final String UPDATE_SHIPPING_INFO_URL = "UPDATE_SHIPPING_INFO_URL";
    public static final String PAST_DUE_CHECKOUT_URL = "PAST_DUE_CHECKOUT_URL";
    public static final String UPDATE_DEVICE_SERVICE_ADDRESS_URL = "UPDATE_DEVICE_SERVICE_ADDRESS_URL";
    public static final String SUBMIT_ORDER_URL = "SUBMIT_ORDER_URL";
    public static final String STORE_DETAILS_URL = "STORE_DETAILS_URL";

    /**
     * +     * Property used to hold the INCLUDED.
     * +
     */
    public static final String INCLUDED = "INC";

    /**
     * Property used to hold the MESSAGE.
     */
    public static final String MESSAGE = "MESSAGE";

    /**
     * Property used to hold the DATA.
     */
    public static final String DATA = "DATA";
    public static final String CONTRACT_EXP_DATE = "$contractExpDate$";
    public static final String MORE_EVERY_THING_DATA_ALLOWANCE = "MORE_EVERY_THING_DATA_ALLOWANCE";
    public static final String SMART_PHONE_STRING_3G_4G = "SMART_PHONE_STRING_3G_4G";
    public static final String LAC_FEE = "$lineAccessFee$";
    public static final String FINAL_LAC_FEE = "$finalLineAccessFee$";
    public static final String DOLLAR_SYMBOL = "$";

    public static final String TIME_OUT_RETRIEVE_BASIC_MTN_INFO_ACTOR = "retrieveBasicMtnInfo";

    public static final  String TECH_COACH_SFO_ID = "77963";
    public static final String PROTECTION_PACKAGE_GROUP_CODE = "EQ";

    //MF actors
    public static final String MF_SERVICE_ACTOR_GET_CART_DETAIL = "mfGetCartDetails";
    public static final String MF_SERVICE_ACTOR_CLEAR_CART = "mfClearCart";

    public static final String TIME_OUT_CM_ACTOR_ELIGIBILTY = "cMEligibility";
    public static final String METHOD_ENTERING_MESSAGE = "Entering into method [{0}] of [{1}]";

    public static final String NEW_DEVICE_LABEL = "NEW_DEVICE_LABEL";
    public static final String UPGRADE_DEVICE_LABEL = "UPGRADE_DEVICE_LABEL";
    public static final String DEVICE_LABEL = "deviceLabel";
    public static final String DEVICE_NAME = "deviceName";
    public static final String NAME_LABEL_MAP = "nameLabelMap";
    public static final String EDGE_DEVICE_NAME = "edgeDeviceName";
    public static final String EDGE_TERMS_CONDITIONS = "edgeTermsAndCondition";
    public static final String LINE_ITEM_ID = "lineItemId";
    public static final String ORDER_CONFIRM_TITLE = "ORDER_CONFIRM_TITLE";
    public static final String ORDER_CONFIRM_SUBTITLE = "ORDER_CONFIRM_SUBTITLE";
    public static final String ORDER_CONFIRM_SUBTITLE_SPLIT_SHIPMENT = "ORDER_CONFIRM_SPLIT_SHIPMENT";
    public static final String ORDER_CONFIRM_MESSAGE_SINGLE = "ORDER_CONFIRM_MESSAGE_SINGLE";
    public static final String ORDER_CONFIRM_PROTECTION_URL = "ORDER_CONFIRM_PROTECTION_URL";
    public static final String ORDER_CONFIRM_ACCESSORIES_URL = "ORDER_CONFIRM_ACCESSORIES_URL";
    public static final String ORDER_CONFIRMATION_DATE_MESSAGE = "ORDER_CONFIRMATION_DATE_MESSAGE";
    public static final String ORDER_CONFIRMATION_SHIP_DATE_MESSAGE = "ORDER_CONFIRMATION_SHIP_DATE_MESSAGE";
    public static final String ORDER_CONFIRMATION_DELIVERY_DATE_MESSAGE = "ORDER_CONFIRMATION_DELIVERY_DATE_MESSAGE";

    public static final String REVIEW_ORDER_SUBTITLE_SPLIT_SHIPMENT = "REVIEW_ORDER_SPLIT_SHIPMENT";
    /**
     * Constant to hold the Log Debug constant to indicate the flow inside the
     * method
     */
    public static final String METHOD_EXITS_MESSAGE = "Exiting from the method [{0}] of [{1}]";

    public static final String TYPE_INDICATOR_Z = "Z";

    //CreditWrite Kill switch.
    public static final String CREDIT_WRITE_KILL_SWITCH = "CREDIT_WRITE_KILL_SWITCH";
    //BTA Kill Switch
    public static final String PREORDER_BTA_ENABLED = "PREORDER_BTA_ENABLED";
    public static final String BTA_ENABLED_FOR_DPP = "BTA_ENABLED_FOR_DPP";
    public static final String PREORDER_BTA_ENABLED_DPP_AAL = "PREORDER_BTA_ENABLED_DPP_AAL";
    public static final String EDGE_TERMS_CONFIG = "edgeTermsConfigMap";
    public static final String EDGE_LOAN_TERM = "edgeTerm";
    public static final String EDGE_PERCENTAGE = "edgePercentage";

    public static final String CACHE_KEY = "CACHE_KEY";
    public static final String TIME_OUT_CHECK_ORDER_ACTIVITY_RESTRICTIONS = "checkOrderActivityRestrictions";
    public static final String PRODUCT_OFFERS_AVAILABLE_OFFERS_SUB_SERVICE = "availableOffers";
    public static final int TOTAL_NR_OF_INSTANCES = 10000;
    public static final boolean ALLOWLOCALROUTES = false;
    public static final String CPC_PLAN_AKKA_ROLE = "preorderCPCPlanAkka";
    public static final String VZW_API_KEY = "vzw_api_props";

    public static final String CPC_ACC_NO = "00001";
    public static final String CPC_ORDER_TYPE = "C";
    public static final String AUTH_FLOW_ORDER_TYPE = "C";
    public static final String UN_AUTH_FLOW_ORDER_TYPE = "A";
    public static final String SPO_ACCOUNT_PROTECTION_CATEGORY_CODE = "EQ";
    public static final String EXISTING_SPO_ACCOUNT_PROTECTION = "existingTAPSpo";
    public static final String SFO_TYPE = "SS";
    public static final String DACC_CODE_STR = "dacc_code";
    public static final String PLAN_SOR_ID_STR = "plan_sor_id";
    public static final String CLIENT_ID_STR = "client_id";
    public static final String FEATURE_SOR_ID_STR = "sfo_sor_id";
    public static final String MARKET = "major_market";
    public static final String REGION = "region";
    public static final String AREA = "area";
    public static final String SFO_TYPE_STR = "sfo_type";
    public static final String WILDCARD = "ANY";
    public static final int MAX_SEARCH_RESULTS = 1000;
    public static final String SUBSIDY = "subsidy";
    public static final String CUST_TYPE = "cust_type";
    public static final String IN = "IN";
    public static final String AN = "AN";
    public static final String SOR_STATUS_A = "A";
    public static final String SOR_STATUS_E = "E";

    public static final String EPS_3D_SECURE_MESSAGEINFO_VERSION = "EPS_3D_SECURE_MESSAGEINFO_VERSION";
    public static final String STORE_LEVEL_ISPU_INDEX = "STORE_LEVEL_ISPU_INDEX";
    public static final String STORE_LEVEL_ISPU_DETAILS = "STORE_LEVEL_ISPU_DETAILS";
    public static final String ENABLE_VENDING_MACHINE_ORDER_KEY = "ENABLE_VENDING_MACHINE_ORDER";
    public static final String VENDING_MACHIN_STORE_TYPE_IN_SEESION = "isVendingMachine";
    public static final String VENDING_MACHINE_VENDOR_ID = "VENDING-MACHINE";
    public static final String VENDING_MACHINE_CHANNEL_ID = "B2E";
    public static final String VENDING_MACHINE_CLIENT_ORDER_TYPE = "VEN-ACCNLND";


    public static String ESERROR = "Error connection to elastic search";
    public static final String ENABLE_CPC_RETRIEVE_CUSTOMER_PROFILE_SERVICE = "ENABLE_CPC_RETRIEVE_CUSTOMER_PROFILE_SERVICE";

    public static final String INVENTORY_FROM_REDIS_ENABLED = "INVENTORY_FROM_REDIS_ENABLED";
    public static final String INVENTORY_CHECK_5G_ENABLED = "INVENTORY_CHECK_5G_ENABLED";

    public static final String TRADEIN_SELECTED = "tradeinSelected";
    public static final String COMPUTE_TAX = "COMPUTE_TAX";

    public static final String VALIDATE_BAR_CODE_ACTOR_REF = "validateBarCodeServiceActor";
    public static final String COMPUTE_OFFER_SERVICE_ACTOR_REF = "computeOfferServiceActor";
    public static final String SHARED_CART_SERVICE_ACTOR_REF = "sharedCartServiceActor";
    public static final String SHARED_CART_BUSINESS_ACTOR_REF = "sharedCartBusinesActor";
    public static final String CREDIT_READ_POOLING_DELAY_TYPE = "CREDIT_READ_POOLING_DELAY_TYPE";
    public static final String PURCHASE_PATH_DELAY_TYPE = "purchasePath";
    public static final String CREDIT_STATUS_DELAY_TYPE = "CreditStatus";
    public static final String CREDIT_WRITE_COMPLETED_ON = "CREDIT_WRITE_COMPLETED_ON";
    public static final String CREDIT_READ_BEGINS_AT = "CREDIT_READ_BEGINS_AT";
    public static final String CREDIT_READ_ENDS_AT = "CREDIT_READ_ENDS_AT";

    public static final String CREDIT_READ_MAX_REATTEMPT_COUNT = "CREDIT_READ_MAX_REATTEMPT_COUNT";
    public static final String CREDIT_READ_REATTEMPT_COUNT = "CREDIT_READ_REATTEMPT_COUNT";
    public static final String CREDIT_READ_DELAY_STATUS_CODES = "CREDIT_READ_DELAY_STATUS_CODES";
    public static final String CREDIT_READ_STATUS_CODE_DELAY = "CREDIT_READ_STATUS_CODE_DELAY";
    public static final String CREDIT_READ_REQUEST = "CREDIT_READ_REQUEST";
    public static final String ENABLE_STUBBED_RESPONSE = "ENABLE_STUBBED_RESPONSE";
    public static final String API_INTEGRATION_SERVICE_NAME_KEY = "API_INTEGRATION_SERVICE_NAME_KEY";
    public static final String ICONIC_TRADEIN_EDIT_RES = "ICONIC_TRADEIN_EDIT_RES";

    //creating these constants for timeout config
    public static final String RETRIEVE_CC_INTEGRATION_ACTOR = "retrieveCCIntegrationActor";
    public static final String SPLIT_ADDRESS_INTEGRATION_ACTOR = "splitAddressIntegrationActor";
    public static final String GENERATE_INSTALLMENT_CONTRACT_INTEGRATION_ACTOR = "generateInstallmentContractIntegrationActor";
    public static final String TERMS_AND_CONDITIONS_BUSINESS_ACTOR = "termsAndConditionsBusinessActor";
    public static final String CREDIT_CARD_PREAUTH_INTEGRATION_ACTOR = "creditCardPreauthIntegrationActor";

    public static final String CART_COUNT = "OD_CART_COUNT";
    public static final String CART_COUNT_COOKIE_NAME = "cartCount";

    public static final String CUSTOMER_TYPE_CODE_AG = "AG";
    public static final String PRODUCT_VALIDATION_INTEGRATION_ACTOR = "productValidationIntegrationActor";
    public static final String CART_VALIDATION_ACTOR = "cartValidationActor";
    public static final String EXISTING_FEATURE_BASED_ON_FOM_ACTOR = "existingFeatureBasedOnFOMActor";
    public static final String NPANXX_LOOKUP_SERVICE_ACTOR = "npaNxxLookupServiceActor";
    public static final String COMPUTE_OFFER_SERVICE_ACTOR = "computeOfferServiceActor";
    public static final String VALIDATE_BARCODE_BUSINESS_ACTOR = "validateBarCodeBusinessActor";
    public static final String PREORDER_GET_CART_DETAILS_BUSINESS_ACTOR = "preorderGetCartDetailsBusinessActor";
    public static final String ADD_UPDATE_PLAN_BUSINESS_ACTOR = "addUpdatePlanBusinessActor";
    public static final String PREORDER_GET_COMPATIBLE_FEATURES_BUSINESS_ACTOR = "preorderGetCompatibleFeaturesBusinessActor";
    public static final String PREORDER_ADD_UPDATE_DEVICE_BUSINESS_ACTOR = "preOrderAddUpdateDeviceBusinessActor";
    public static final String PREORDER_MULTILINE_FEATURES_VALIDATION_WITH_FOM_INTEGRATION_ACTOR = "preOrderMultiLineFeaturesValidationWithFOMIntegrationActor";
    public static final String GET_NPANXX_NUMBER_BUSINESS_ACTOR = "getNpaNxxNumberBusinessActor";
    public static final String UPDATE_PORTIN_BUSINESS_ACTOR = "updatePortInBusinessActor";
    public static final String PREORDER_CLEAR_CART_BUSINESS_ACTOR = "preorderClearCartBusinessActor";
    public static final String PREORDER_GET_EXISTING_FEATURES_BASED_ON_FOM_BUSINESS_ACTOR = "preOrderGetExistingFeaturesBasedOnFOMBusinessActor";
    public static final String PREORDER_MULTILINE_AVAILABLE_FEATURES_INTEGRATION_ACTOR = "preOrderMultiLineAvailableFeaturesIntegrationActor";

    public static final String SERVICE_ACTOR_TRADEIN_DEVICE_DETAILS_FORAPP = "tradeInDeviceDetails_forapp";
    public static final String SERVICE_ACTOR_TRADEIN_APPRAISAL_FORAPP = "tradeInAppraisal_forapp";
    public static final String SERVICE_ACTOR_TRADEIN_QUESTIONNAIRE_FORAPP = "tradeinQuestionnaire_forapp";
    public static final String ACTOR_AAL_PROMPT_TRADEIN_DEVICE_ACTOR = "aalPromptTradeinDeviceDetailActor";
    public static final String CPC_FOM_SERVICE_PATH = "multiLineFeatures";
    public static final String CPC_EFF_DATE_SERVICE_PATH = "effectiveDate";
    public static final String CPC_PROD_VALIDATION_SERVICE_PATH = "productValidation";
    public static final String CPC_FOM_ACTIVATION_SERVICE_PATH = "cpc_multiLineActivationFOM";
    public static final String CPC_FEATURES_IMP_FOM_PATH = "cpc_fomImpactedByPrice";

    public static final String FAILURE_ERROR_MAP_CODE = "99";
    public static final String FAILURE_ERROR_MAP_MSG = "Your request could not be processed at this time. Please try again later.";
    public static final String ACCESSORY_RESTRICTED_ROLES_FOR_BTA = "ACCESSORY_RESTRICTED_ROLES_FOR_BTA";

    public static final String AVAILABILITY_STATUS_IN_STOCK = "1000";
    public static final String AVAILABILITY_STATUS_OUT_OF_STOCK = "1001";
    public static final String AVAILABILITY_STATUS_PREORDER = "1002";
    public static final String AVAILABILITY_STATUS_BACKORDER = "1003";
    public static final String AVAILABILITY_STATUS_DERIVED = "1004";
    public static final String AVAILABILITY_STATUS_DISCONTINUED = "1005";

    public static final String SHIP_COMMIT_INDICATOR_SHIP_DATE = "S";
    public static final String SHIP_COMMIT_INDICATOR_DELIVERY_DATE = "D";

    public static final String CURR_PLAN_SWITCH = "CURR_PLAN_SWITCH";
    public static final String CPC_API_CACHE = "CPC_API_CACHE";
    public static final String UNLIMITED_BASIC_ML = "UNLIMITED_BASIC_ML";
    public static final String UNLIMITED_PREM_ML = "UNLIMITED_PREM_ML";
    public static final String CPC_AAL_ASYNC = "CPC_AAL_ASYNC";
    public static final String BACK_DATE_KEY = "BACK_DATE_KEY";
    public static final String DATA_TO_TRADE_IN = "DATA_TO_TRADEIN";
    public static final String TRADE_IN_REDIRECT_URL = "TRADE_IN_REDIRECT_URL";
    public static final String CPC_PLAN_CHANGE_FLAG = "cpcPlanChangeFlag";
    public static final String SERVICE_ACTOR_TRADEIN_SUBMIT_FORAPP = "tradeInSubmit_forapp";
    public static final String MISSING_REDIS_KEY_INDICATOR = "MISSING_REDIS_KEY_INDICATOR";
    public static final String NUMBER_SHARE_ELIGIBLE_MTNLIST_ACTOR = "numberShareEligibleMtnListActor";
    public static final String NUMBER_SHARE_SELECT_DEVICE_BUSINESS_ACTOR = "numberShareSelectDeviceBusinessActor";
    public static final String NUMBER_SHARE_RETRIEVE_MTN_BRANCH_TYPE = "NUMBER_SHARE_RETRIEVE_MTN_BRANCH_TYPE";
    public static final String NUMBER_SHARE_RETRIEVE_PAIRING_STATUS_ACTOR = "retrievePairingStatusActor";

    public static final String PREORDER_CONSTANT = "PO";
    public static final String MOBILE = "MOBILE";
    public static final String MF_APP = "APP";
    public static final String SERVICE_ACTOR_COMPUTE_OFFER_API = "computeOfferAPI";
    public static final String PREORDER_REMOVE_BARCODE_BUSINESS_ACTOR = "preorderRemoveBarcodeBusinessActor";
    public static final String ADD_E911ADDRESS_BUSINESS_ACTOR = "addE911AddressBusinessActor";
    public static final String RIO_DEVICE = "RIO_DEVICE";
    public static final String E911_REQUIRED = "E911_REQUIRED";
    public static final String BGSA_CODE = "978";
    public static final String NEW_OUTLET_ID = "08253";
    public static final String LINE_ITEM_TYPE = "A";
    public static final String NR = "NR";
    public static final String PI = "PI";

    public static final String NUMBER_SHARE_DEVICE_ID = "NUMBER_SHARE_DEVICE_ID";
    public static final String NUMBERSHARE_DEVICEID_BRANCHTYPE_MAP = "NUMBERSHARE_DEVICEID_BRANCHTYPE_MAP";
    public static final String NS_RETRIEVE_MTN_LIST_ERROR_MAP = "NS_RETRIEVE_MTN_LIST_ERROR_MAP";
    public static final String NS_COMPATIBLE_MSG_RIO = "NS_COMPATIBLE_MSG_RIO";
    public static final String NS_COMPATIBLE_MSG = "NS_COMPATIBLE_MSG";

    public static final String ORIGINATING_SYSTEM_KEY = "ORIGINATING_SYSTEM";
    public static final String ORIGINATING_SYSTEM_MOBILE = "Mobile";
    public static final String ORIGINATING_SYSTEM_DESKTOP = "Desktop";
    public static final String ORIGINATING_SYSTEM_TABLET = "Tablet";
    public static final String ORIGINATING_SYSTEM_APPIOS = "App-iOS";
    public static final String ORIGINATING_SYSTEM_APPANDRIOD = "App-Android";
    public static final String ORIGINATING_SYSTEM_MFIOS = "Mf-iOS";
    public static final String ORIGINATING_SYSTEM_MFANDRIOD = "Mf-Android";
    public static final String ORIGINATING_SYSTEM_MDOT = "MDOT";
    public static final String ORIGINATING_SYSTEM_DOTCOM_PROMO = "Dotcom-Promo";
    public static final String ORIGINATING_SYSTEM_RV_DESKTOP = "Web-RV-Desktop";
    public static final String ORIGINATING_SYSTEM_RV_MOBILE = "Web-RV-Mobile";
    public static final String VZW_FIOS_CLIENTID = "VZW-FIOS";

    public static final String MDOT = "MDOT";
    public static final String DOTCOM_PROMO = "DOTCOM-PROMO";
    public static final String VZW_PPC_CLIENTID = "VZW-PPC";
    public static final String NUMBERSHARE_UNGRAFTING = "U";
    public static final String CLIENT_MDOT = "CLIENT_MDOT";
    public static final String CLIENT_TDOT = "CLIENT_TDOT";
    public static final String CLIENT_DESK = "CLIENT_DESK";
    public static final String CLIENT_MAPP = "CLIENT_MAPP";
    public static final String CLIENT_MIPP = "CLIENT_MIPP";
    public static final String CLIENT_VZWDOTCOM = "CLIENT_VZWDOTCOM";
    public static final String TRADEIN_EXIST_IN_ORDER = "TRADEIN_EXIST_IN_ORDER";
    public static final String EPP_RESTRICTED_ERROR_JSON = "EPP_RESTRICTED_ERROR_JSON";

    //for Affiliates Tagging
    public static final String AFFILIATE_COOKIE_VALUE = "AFFILIATE_VALUE";
    public static final String MSO_COOKIE_VALUE = "MSO_VALUE";
    public static final String AFFILIATES_VENDOR_CJM_ID_KEY = "cjmVendorId";
    public static final String AFFILIATES_VENDOR_PERFORMICS_ID_KEY = "performicsVendorId";
    public static final String AFFILIATES_VENDOR_PEPPER_JAM_ID_KEY = "pepperjamVendorId";
    public static final String AFFILIATES_VENDOR_ONLINE_MEDIA_ID_KEY = "onlinemediaVendorId";
    public static final String AFFILIATES_VENDOR_COMCAST_ID_KEY = "comcastVendorId";
    public static final String AFFILIATES_VENDOR_TWC_ID_KEY = "twcVendorId";
    public static final String DEFAULT_IMAGE_NAME = "generic_phone?$device-thumb$";
    public static final String THUMB_IMAGE_NAME = "?$device-thumb$";
    public static final String DEFAULT_IMAGE_PATH = "https://ss7.vzw.com/is/image/VerizonWireless/";
    public static final String ENABLE_COMPUTE_OFFER_FOR_CART_CALL_ONLY = "ENABLE_COMPUTE_OFFER_FOR_CART_CALL_ONLY";
    public static final String COMPUTE_OFFER = "COMPUTE_OFFER";
    public static final String COUNTRY_US = "US";

    public static final String RIO_BRANCH_TYPE = "R";
    public static final String DEFAULT_FEATURE_SOR_ID = "DEFAULT_FEATURE_SOR_ID";

    public static final int BUSINESS_ERR_CODE = 500;

    public static final int GENERIC_ERR_CODE = 400;

    public static final int SUCCESS_CODE = 200;


    public static final String PREORDER_USER_ACCOUNT_PLANINFO = "PreOrderUserAccountPlanInfoVO";
    public static final String PREORDER_ORDER_OBJECT = "PreOrderObject";


    public static final String CHECKOUT_GENERIC_ERROR_MESSAGE = "CHECKOUT_GENERIC_ERROR_MESSAGE";

    public static final String CPC_ENABLED_KILL_SWITCH = "CPC_ENABLED_KILL_SWITCH";

    public static final String SALE_REP_ID_COOKIE_ENCRYPTED_VALUE = "saleRepIdCookieEncryptedValue";

    public static final String ICONIC_VENDOR_ID_SUFFIX = "ICONIC";

    public static final String DISPLAY_NAME = "displayName";
    public static final String INTRO_TEXT = "introText";
    public static final String LEGAL = "legal";

    public static final String AVAILABLE_FEATURES_WITH_FOM = "availableFeaturesWithFOM";
    public static final String IGNORE_CACHING = "ignoreCaching";
    public static final String RIO_CONNECTED_DEVICE_DACC_CODE = "RIO_CONNECTED_DEVICE_DACC_CODE";
    public static final String DEVICE_SPEC_INDEX = "DEVICE_SPEC_INDEX";
    public static final String DEVICE_SPEC_TYPE = "DEVICE_SPEC_TYPE";
    public static final String ACCESSORY_SPEC_INDEX = "ACCESSORY_SPEC_INDEX";
    public static final String ACCESSORY_TECHSPEC_INDEX = "ACCESSORY_TECHSPEC_INDEX";
    public static final String DEVICE_FEATURE_INDEX = "DEVICE_FEATURE_INDEX";
    public static final String DEVICE_FEATURE_TYPE = "DEVICE_FEATURE_TYPE";
    public static final String ACCESSORY_FEATURE_INDEX = "ACCESSORY_FEATURE_INDEX";
    public static final String DEVICES_RATINGS_INDEX = "DEVICES_RATINGS_INDEX";
    public static final String DEVICES_RATINGS_TYPE = "DEVICES_RATINGS_TYPE";
    public static final String DEVICE_PRODUCT_ID = "devprod_id";
    public static final String ACCESSORIES_PRODUCT_ID = "acc_prod_id";
    public static final String DEVICE_SEO_URL_NAME = "seo_url_name";
    public static final String BUNDLE_PRODUCT_ID = "bundle_id";
    public static final String DEVICE_CANONICAL_URL = "canonical_url";
    public static final String DEVICE_SEO_DISPLAY_NAME = "display_name";
    public static final String DEVICE_START_DATE = "start_date";
    public static final String DEVICE_SEO_MANUFACTURER_NAME = "manufacturer.name";
    public static final String DEVICE_META_ROBOTS_INDEX = "meta_robots_index";
    public static final String DEVICE_META_ROBOTS_FOLLOW = "meta_robots_follow";
    public static final String PRODUCT_SITE_AWARE_PROPS = "product_site_aware_props";
    public static final String PRICE_OFFERS_INDEX = "PRICE_OFFERS_INDEX";
    public static final String PRICE_OFFERS_TYPE = "PRICE_OFFERS_TYPE";
    public static final String CREDIT_OPTION_INDEX = "CREDIT_OPTION_INDEX";
    public static final String CREDIT_OPTION_TYPE = "CREDIT_OPTION_TYPE";
    public static final String EPS_PLANS_INDEX = "EPS_COMPATIBLE_PLAN";
    public static final String EPS_ITEMS_TYPE = "details";

    public static final String EPS_COMPATIBLE_PLAN_INDEX = "EPS_COMPATIBLE_PLAN_INDEX";
    public static final String EPS_COMPATIBLE_PLAN_INDEX_TYPE = "EPS_COMPATIBLE_PLAN_INDEX_TYPE";

    public static final String SUN = "Sun";
    public static final String MON = "Mon";
    public static final String TUE = "Tue";
    public static final String WED = "Wed";
    public static final String THU = "Thu";
    public static final String FRI = "Fri";
    public static final String SAT = "Sat";
    public static final String STR_NINE_NINE = "99";
    public static final String STR_STORE_CLOSED = "Closed";
    public static final String ID = "id";
    public static final Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES).setDateFormat("yyyy-dd-mm'T'hh:mm:ss")
            .setDateFormat("yyyy-dd-mm'T'hh:mm:ss.SSS'Z'").create();
    public static final String ITEM_AVAILABLLE = "Available";
    public static final String VZW_STORE_COUNT = "VZW_STORE_COUNT";
    public static final String VZW_STORE_NATIONAL_RETAILS = "VZW_STORE_NATIONAL_RETAILS";
    public static final String ITEM_NOT_AVAILABLLE = "Not Available";

    public static final String VZW_STORE_LOCATOR_BASE_URL = "VZW_STORE_LOCATOR_BASE_URL";
    public static final String VZW_STORE_LOCATOR_SERVICENAME = "VZW_STORE_LOCATOR_SERVICENAME";
    public static final String VZW_STORE_LOCATOR_TOKEN = "VZW_STORE_LOCATOR_TOKEN";


    /**
     * Property used to hold the MaxResults
     */
    public static final String MAXRESULT_INDIRECT = "25";
    /**
     * Property used to hold the store type
     */
    public static final String STORE_TYPE_INDIRECT = "Indirect";
    /**
     * Property used to hold the store type
     */
    public static final String STORE_TYPE_DIRECT = "Direct";
    /**
     * Property used to hold the MAXRESULT_DIRECT
     */
    public static final String MAXRESULT_DIRECT = "25";
    /**
     * Property used to hold the STORE DISTANCE
     */
    public static final String DISTANCE = "distance";

    /**
     * Property used to hold the STORE CHANNEL
     */
    public static final String CHANNEL = "channel";
    /**
     * Property used to hold the store type
     */
    public static final String STORE_TYPE_ALL = "All";
    /**
     * Property used to hold the MaxResults
     */
    public static final String MAXRESULTS = "maxResults";
    public static final String MAXRESULTS_VALUE = "25";
    public static final String ATG_ECOM_DESK = "ATG-ECOM-DESK";

    /**
     * Property used to hold the Street
     */
    public static final String STREET = "street";

    /**
     * Property used to hold the ZIP
     */
    public static final String ZIP = "zip";

    /**
     * Property used to hold the ZIP
     */
    /**
     * Property used to hold the state
     */
    public static final String STATE = "state";

    /**
     * Property used to hold the latitude
     */
    public static final String LATITUDE = "latitude";
    /**
     * Property used to hold the state
     */
    public static final String LONGITUDE = "longitude";

    public static final String ISPU_MILES = "25";

    /**
     * Property used to hold the service token
     */
    public static final String TOKEN = "token";

    public static final String ECPD_TOKEN = "ecpdToken";
    public static final String ECPD_PROFILE_ID = "ecpdProfileId";
    public static final String IS_TOKEN_EXPIRED = "expired";
    /**
     * Property used to hold the Range
     */
    public static final String RANGE = "range";

    public static final String SHIPPING_OPTIONS_INDEX = "SHIPPING_OPTIONS_INDEX";
    public static final String SHIPPING_OPTIONS_INDEX_TYPE = "SHIPPING_OPTIONS_INDEX_TYPE";
    public static final String SHIPPING_OPTIONS_MAX_SEARCH_RESULTS = "SHIPPING_OPTIONS_MAX_SEARCH_RESULTS";

    public static final String SHIPPING_OPTIONS_RULES_INDEX = "SHIPPING_OPTIONS_RULES_INDEX";
    public static final String SHIPPING_OPTIONS_RULES_INDEX_TYPE = "SHIPPING_OPTIONS_RULES_INDEX_TYPE";

    public static final String SHIPPING_OPTIONS_RULES_ZIP_INDEX_TYPE = "SHIPPING_OPTIONS_RULES_ZIP_INDEX_TYPE";

    public static final String SERVICE_ACTOR_PAYPAL_CMPI_LOOKUP = "paypalCmpiLookUp";
    public static final String SERVICE_ACTOR_PAYPAL_CENTINEL = "paypalCentinel";
    public static final String SERVICE_ACTOR_PAYPAL_CMPI_AUTH = "paypalCmpiAuth";
    public static final String PAYPAL_CMPI_LOOKUP_INFO = "paypalCmpiInfo";
    public static final String PAYPAL_FLOW_ENABLED = "PAYPAL_FLOW_ENABLED";


    public static final String PLAN_LISTING_CQ_KEYS = "PROSPECT_PLAN_LISTING";
    public static final String AUTOPAY_PAPERFREE_DISCOUNT_FEE = "AUTOPAY_PAPERFREE_DISCOUNT_FEE";
    public static final String AUTOPAY_PAPERFREE_DISCOUNT_NOTIFICATION = "AUTOPAY_PAPERFREE_DISCOUNT_NOTIFICATION";
    public static final String AUTOPAY_PAPERFEE_DISCOUNT_KEY = "AUTOPAY_PAPERFREE_DISCOUNT";
    public static final int AUTOPAY_AND_PAPER_FREE_BILLING_DISCOUNT_PER_LINE = 5;
    public static final String JAX_GO_PLAN_SOR_ID = "99230";
    public static final String JAX_BEYOND_PLAN_SOR_ID = "99231";
    public static final String FIVE_GB_PLAN_SIZE_CODE = "5";
    public static final String TWO_GB_PLAN_SIZE_CODE = "S";
    public static final String FOUR_GB_PLAN_SIZE_CODE = "M";
    public static final String EIGHT_GB_PLAN_SIZE_CODE = "L";
    public static final String JAX_PLAN_SOR_CATEGORY_CODE = "61";
    public static final String JAX_PLAN = "JAX";
    public static final String JAX_PLAN_SIZE = "U";
    public static final String PHONE_PLAN_ACCESS_MSG = "Phone plan access";
    public static final String LINE_ACCESS_FEE_MSG = "Line access fee";
    public static final String VZW_COMMON_PROPS = "vzw_ecomm_props";
    public static final String SOURCE_OF_REQUEST = "sourceofrequest";
    public static final String GRAFANA_TRACKING_FROM_EMAIL = "grafanaTrackingFromEmail";
    public static final String EXPERIENCE_FLAG = "experienceFlag";
    public static final String PROSPECT_SERVICE_ACTOR_PERSONAL_INFORMATION = "updatePersonalInfo";
    public static final String PROSPECT_SERVICE_ACTOR_GET_MARKET_DETAILS = "getMarketDetails";
    public static final String CONTENT_TYPE = "Content-Type";
    public static final String CHANNEL_ID = "channelid";

    public static final String CONTENT_ENCODING = "application/x-www-form-urlencoded";

    public static final String PROSPECT_SERVICE_ACTOR_UPDATE_CONTACT_INFO = "updateContactInfo";
    public static final String PROSPECT_SERVICE_ACTOR_RUN_CREDIT = "runCredit";
    public static final String PROSPECT_SERVICE_ACTOR_RUN_SOFT_CREDIT = "runSoftCredit";

    public static final String PROSPECT_SERVICE_ACTOR_ACCEPT_DOWNPAYMENT = "acceptDownpayment";
    public static final String PROSPECT_SERVICE_ACTOR_ACCEPT_QUOTE = "acceptQuote";
    public static final String PROSPECT_SERVICE_ACTOR_GET_SHIPPING_OPTIONS = "getShippingOptions";
    public static final String PROSPECT_SERVICE_ACTOR_UPDATE_BILLING_ADDRESS = "updateBillingAddress";
    public static final String PROSPECT_SERVICE_ACTOR_UPDATE_SHIPPING_ADDRESS = "updateShippingAddress";
    public static final String PROSPECT_SERVICE_ACTOR_UPDATE_SERVICE_ADDRESS = "updateServiceAddress";
    public static final String PROSPECT_SERVICE_ACTOR_UPDATE_SHIPPING_OPTIONS = "updateShippingOptions";
    public static final String PROSPECT_SERVICE_ACTOR_SUBMIT_ORDER = "prospectSubmitOrder";
    public static final String PROSPECT_SERVICE_ACTOR_GUEST_SUBMIT_ORDER = "guestSubmitOrder";
    public static final String PROSPECT_SERVICE_ACTOR_GUEST_SUBMIT_ORDER_MGR = "guestSubmitOrderManager";
    public static final String PROSPECT_SERVICE_ACTOR_PAYPAL_CENTINEL = "prospectCentinelWorker";


    public static final String PROSPECT_SERVICE_ACTOR_SAVE_CART = "saveCart";

    public static final String PROSPECT_SERVICE_ACTOR_CLEAR_CART = "clearProspectCart";

    public static final String PROSPECT_SERVICE_ACTOR_UPDATE_SHIPPING_DETAILS = "updateShippingDetails";

    public static final String PROSPECT_SERVICE_ACTOR_UPDATE_ACESSORY_CART = "updateAcessoryCart";
    public static final String ENABLE_RTN_EXC_DEV_FLOW = "ENABLE_RTN_EXC_DEV_FLOW";
    public static final String BIC_KEY = "bic_props";

    public static final String PROSPECT_SERVICE_ACTOR_UPDATE_PAYMENT_INFO = "updateProspectPaymentInfo";

    public static final String PROSPECT_SERVICE_ACTOR_UPDATE_ACCOUNT_PIN = "updateAccountPin";

    public static final String PROSPECT_SERVICE_ACTOR_GET_TERMS_CONDITIONS = "getTermsAndConditions";

    public static final String PROSPECT_SERVICE_ACTOR_GET_PHONE_NUMBERS = "getPhoneNumbers";

    public static final String PROSPECT_SERVICE_ACTOR_PORT_IN_PHONE_NUMBER = "portInPhoneNumber";

    public static final String PROSPECT_SERVICE_ACTOR_EXPRESS_CHECKOUT = "checkoutExpress";

    public static final String PROSPECT_SERVICE_ACTOR_GET_NUNBER_PAGE_DATA = "getNumberPageData";

    public static final String PROSPECT_SERVICE_ACTOR_VALIDATE_ADDRESS = "validateAddress";

    public static final String PROSPECT_SERVICE_ACTOR_VALIDATE_SIM = "validateSim";

    public static final String PROSPECT_SERVICE_ACTOR_GET_ISPU_STORES = "getIspuStores";

    public static final String PROSPECT_SERVICE_ACTOR_UPDATE_SERVICE_CONFIGURATION = "updateServiceConfiguration";

    public static final String PROSPECT_SERVICE_ACTOR_UPDATE_PORTIN_DETAILS = "updatePortinDetails";

    public static final String PROSPECT_SERVICE_ACTOR_CHECKOUT_ORDER_DETAILS = "checkoutOrderDetails";

    public static final String PROSPECT_SERVICE_ACTOR_UPDATE_CONTACTINFO_PREFERENCES = "updateContactInfoAndPreferences";

    public static final String ADD_E911_ADDRESS_ACTOR = "addE911AddressActor";

    public static final String MOBILE_CONNECTED_DEVICE_APPLE_FILTER = "MOBILE_CONNECTED_DEVICE_APPLE_FILTER";

    public static final String MOBILE_CONNECTED_DEVICE_APPLE_FILTER_DISPLAY_NAME = "MOBILE_CONNECTED_DEVICE_APPLE_FILTER_DISPLAY_NAME";

    public static final String CPC_REQUIRED = "CPC_REQUIRED";

    public static final String OD_DT_COMBO_ORDER_ENABLED = "OD_DT_COMBO_ORDER_ENABLED";

    public static final String PLAN_CHANGE_FLOW = "PLAN_CHANGE_FLOW";

    public static final String DT_NUMBER_SHARE_ENABLED = "DT_NUMBER_SHARE_ENABLED";

    public static final String DT_NUMBER_SHARE_DEVICES_LIST = "DT_NUMBER_SHARE_DEVICES_LIST";

    public static final String DT_RIO_PROMO_DEVICE_MAP = "DT_RIO_PROMO_DEVICE_MAP";

    public static final String DT_GW_RESTRICTED_DEVICES = "DT_GW_RESTRICTED_DEVICES";

    public static final String GW_RESTRICTED_DEVICES = "GW_RESTRICTED_DEVICES";

    public static final String DT_URL_REDIRECT_MAPPING = "DT_URL_REDIRECT_MAPPING";

    public static final String URL_REDIRECT_MAPPING = "URL_REDIRECT_MAPPING";

    public static final String BLANK_SPACE =  "";

    public static final String FELIX_TO_JAX_ENABLED = "FELIX_TO_JAX_ENABLED";

    public static final String DESKTOP_FELIX_TO_JAX_ENABLED = "DESKTOP_FELIX_TO_JAX_ENABLED";

    public static final String JAX_PLAN_VALUE = "jaxPlan";
    public static final String PROSPECT_SERVICE_ACTOR_TRADEIN = "prospectTradeinActor";
    public static final String VZWAPP_DEVICE_LIST = "VZWAPP_DEVICE_LIST";

    public static final String IS_ACCOUNT_MEMBER = "isAccountMember";
    public static final String SERVICE_ACTOR_EMAIL_MEMBER_CART_TO_OWNER = "emailCartToOwner";
    public static final String SESSION_ID = "SESSION_ID";
    public static final int EXPRESS_CHECKOUT_CANCELLED = 409;
    public static final int ASK_CALL_FOR_ACTOR_TIMEOUT_INT = 120000;
    public static final String APPLICATION_CLIENT_IDENTIFIER = "ONEDIGITAL";
    public static final String SERVICE_ACTOR_GET_PROSPECT_CART_DETAIL = "ProspectGetCartDetails";
    public static final String SERVICE_ACTOR_GET_NSE_CART_TAX_DETAIL = "getNseCartTaxDetails";
    public static final String DEVICE_LINE_ITEM_EXISTS = "DEVICE_LINE_ITEM_EXISTS";
    public static final String ADDORUPDATE_DEVICE_RESPONSE_FAILURE = "ADDORUPDATE_DEVICE_RESPONSE_FAILURE";
    public static final String SERVICE_IO_ERROR = "SERVICE_IO_ERROR";
    public static final String BAD_REQUEST = "BAD_REQUEST";
    public static final String PLAN_NOT_COMPATIBLE_FOR_DEVICES = "PLAN_NOT_COMPATIBLE_FOR_DEVICES";
    public static final String INVALID_INPUT_ERROR = "INVALID_INPUT_ERROR";
    public static final String INVALID_ADDRESS = "INVALID_ADDRESS";

    public static final String ASK_CALL_FOR_ACTOR_TIMEOUT = "ask_call_for_actor_timeout";

    //Common use literals
    public static final String PAYLOAD = "payload";
    public static final String STATUS = "status";
    public static final String OK = "ok";
    public static final String ERROR_MAP = "errorMap";
    public static final String ERROR_STRING = "error";
    public static final String FALSE_STRING = "false";
    public static final String TRUE_STRING = "true";

    public static final String HTTP_POST = "POST";
    public static final String HTTP_GET = "GET";
    public static final String HTTP_PUT = "PUT";
    public static final String HTTP_DELETE = "DELETE";

    public static final String AUTHORIZATION = "Authorization";
    public static final String USERNAME = "userName";
    public static final String PASS = "pass";
    public static final String ENTITY = "entity";
    public static final String BEARER = "Bearer";
    public static final String APPLICATION_NAME = "oneDigital";
    public static final String REDIS_HOST = "localhost";

    public static final String REDIS_PORT = "6379";

    public static final String REDIS_TIMEOUT = "10000";
    public static final String SWITCHER_MOBILE_AUTHTOKEN = "switcher_mobile_authtoken";
    public static final String SWITCHER_WEB_AUTHTOKEN = "switcher_web_authtoken";
    public static final int HTTP_CONNECTION_TIMEOUT_INT = 120000;
    public static final String ONEDIGITAL_MOBILE = "ONEDIGITAL_MOBILE";
    public static final String ONEDIGITAL_WEB = "ONEDIGITAL_WEB";
    public static final String STRING_ZERO = "0";

    public static final String ZIP_CODE_MARKET_INDEX = "ZIP_CODE_MARKET_INDEX";
    public static final String ZIP_CODE_MARKET_TYPE = "ZIP_CODE_MARKET_TYPE";

    public static final String SEO_REDIRECT_INDEX = "SEO_REDIRECT_INDEX";
    public static final String SEO_REDIRECT_TYPE = "SEO_REDIRECT_TYPE";
    public static final String SEO_HITS_SIZE = "SEO_HITS_SIZE";

    public static final String APPLY_PROMO_CODE_NSE = "applyPromoCodeNSE";

    public static final String SUBMITTED = "SUBMITTED";
    public static final String FAILED = "FAILED";
    public static final String MANUAL = "MANUAL";

    public static final String SESSION_HEADER_VO = "SessionHeaderVO";

    //Kafka Constants
    public static final String ORDER_PROCESSOR_FLOW_ENABLED = "ORDER_PROCESSOR_FLOW_ENABLED";
    public static final String BOOTSTRAP_SERVERS = "bootstrap.servers";
    public static final String KEY_SERIALIZER = "key.serializer";
    public static final String VALUE_SERIALIZER = "value.serializer";
    public static final String KEY_DESERIALIZER = "key.deserializer";
    public static final String VALUE_DESERIALIZER = "value.deserializer";
    public static final String GROUP_ID = "group.id";
    public static final String STRING_SERIALIZER = "org.apache.kafka.common.serialization.StringSerializer";
    public static final String ORDER_SERIALIZER = "com.vzw.serializer.OrderSerializer";
    public static final String STRING_DESERIALIZER = "org.apache.kafka.common.serialization.StringDeserializer";
    public static final String ORDER_DESERIALIZER = "com.vzw.serializer.OrderDeserializer";
    public static final String KAFKA_SUBMIT_ORDER_TOPIC = "KAFKA_SUBMIT_ORDER_TOPIC";
    public static final String KAFKA_SUBMIT_ORDER_TOPIC_GROUP = "KAFKA_SUBMIT_ORDER_TOPIC_GROUP";
    public static final String KAFKA_BOOTSTRAP_SERVERS = "KAFKA_BOOTSTRAP_SERVERS";
    public static final String KAFKA_SAVE_ORDER_TOPIC = "vzw.persistorder";
    public static final String KAFKA_3D_SECURE_TOPIC = "KAFKA_3D_SECURE_TOPIC";
    public static final String KAFKA_AVRO_SERIALIZER = "io.confluent.kafka.serializers.KafkaAvroSerializer";

    public static final String ORDER_PROCESSOR_DB_URL = "ORDER_PROCESSOR_DB_URL";
    public static final String ORDER_PROCESSOR_DB_SSL_URL = "ORDER_PROCESSOR_DB_SSL_URL";
    public static final String ON_CLOUD_FLAG = "ON_CLOUD_FLAG";
    public static final String ORDER_PROCESSOR_DB_USER_NAME = "ORDER_PROCESSOR_DB_USER_NAME";
    public static final String ORDER_PROCESSOR_DB_POOL_MIN_IDLE = "ORDER_PROCESSOR_DB_POOL_MIN_IDLE";
    public static final String ORDER_PROCESSOR_DB_POOL_MAX_IDLE = "ORDER_PROCESSOR_DB_POOL_MAX_IDLE";
    public static final String ORDER_PROCESSOR_DB_POOL_INITIAL_SIZE = "ORDER_PROCESSOR_DB_POOL_INITIAL_SIZE";
    public static final String ORDER_PROCESSOR_DB_POOL_MAX_TOTAL = "ORDER_PROCESSOR_DB_POOL_MAX_TOTAL";

    public static final String ENABLE_NSE_PCI_COMPLIANCE = "ENABLE_NSE_PCI_COMPLIANCE";
    public static final String NSE_PCI_ENCDNC_KEY = "NSE_PCI_ENCDNC_KEY";
    public static final String NSE_PCI_KEY_SEPARATOR = "nseja2017";
    public static final Integer NSE_PCI_AES_KEY_SIZE = 128;
    public static final Integer NSE_PCI_AES_ITERATION_COUNT = 1000;

    public static final String SERVICE_ACTOR_ORDER_PROCESSOR = "orderProcessor";
    public static final String SERVICE_ACTOR_ORDER_PERSISTENCE_ACTOR = "orderPersistence";
    public static final String SERVICE_ACTOR_ORDER_PUSH_FAIL_ORDER_ACTOR = "pushfailOrder";
    public static final String FAILED_ORDER_STATUS = "REPROCESS";
    public static final String ORDER_RETRY_INTERVAL = "ORDER_RETRY_INTERVAL";
    public static final String ORDER_RETRY_ATTEMPTS = "ORDER_RETRY_ATTEMPTS";
    public static final String PROSPECT_ORDER_REPROCESSOR_SCHEDULER_INTERVAL = "PROSPECT_ORDER_REPROCESSOR_SCHEDULER_INTERVAL";
    public static final String CLIENT_APP_NAME_SELFSERV = "SELFSRV";
    public static final String ORDERCONFORM = "orderConform";
    public static final String INVENTORY_SHIP_COMMIT_INDEX_D = "D";
    public static final int TEN = 10;
    public static final int CONSTANT_THREE = 3;
    public static final int CONSTANT_SIX = 6;
    public static final String PARENTHESIS_OPEN = "(";
    public static final String PARENTHESIS_CLOSE = ")";

    public static final double LISTPRICE_ZERO = 0.00;
    public static final String SWITCHER_SERVICE_ACTOR_ROOT = "/user/switcher_";
    public static final String SERVICE_SWITCHER_ACTOR_ROOT = "switcher_";
    public static final String SERVICE_ACTOR_GET_PAYMENT_PAGE_DATA = "getPaymentPageData";

    public static final String SPO_INTL = "INTLVOICE";
    public static final String SPO_GLOBAL = "GLOBAL";
    public static final String SPO_GLBL = "GLBL";
    public static final String SPO_DTL = "DTL";
    public static final String SPO_MUTEX = "MUTEX";
    public static final String SPO_INTL_CLASS_CODE = "INTEL";
    public static final String GLOBAL_CATEGORY_CODE = "GLOBAL";
    public static final String NOPRORATE_CATEGORY_CODE = "NOPRORATE";
    public static final String DAILY_CATEGORY_CODE = "INTLDAILY";
    public static final String GLOBAL_NOPRORATE_MONTHLY = "GLOBAL_NOPRORATE_MONTHLY";
    public static final String GLOBAL_NOPRORATE_ONETIME = "GLOBAL_NOPRORATE_ONETIME";
    public static final String IS_MONTHLY = "Monthly";
    public static final String IS_ONETIME = "OneTime";
    public static final String IS_DAILY = "Daily";
    public static final String DAILY_PRICING = "DAILY_PRICING";

    public static final String ISPU_CACHE_KEY = "_ISPUStores";
    public static final String IOS = "iOS";

    public static final String SKIP_KAFKA_AND_PROCESS_ORDER = "SKIP_KAFKA_AND_PROCESS_ORDER";
    public static final String SKIP_ORDER_JSON_PERSISTENCE = "SKIP_ORDER_JSON_PERSISTENCE";


    public static final String CLIENT_REFERENCE_NUMBER_PREFIX = "CLIENT_REFERENCE_NUMBER_PREFIX";

    public static final String ENABLE_NSE_KAFKA_PROCESS = "enable_nse_kafka_process";


    public static final String PROSPECT_ORDER_REPROCESSOR_ENABLED = "PROSPECT_ORDER_REPROCESSOR_ENABLED";

    public static final String BASIC_PHONE_DEVICE = "BASIC_PHONE_DEVICE";

    public static final String ENABLE_DB_CONNECTION = "ENABLE_DB_CONNECTION";

    public static final String ECPD_LIABILITY_TYPE = "E";

    public static final String ENABLE_PAPER_FREE_BILLING_IND = "ENABLE_PAPER_FREE_BILLING_IND";
    public static final String NEW_NUMBER_SELECTED = "newNumberSelected";
    public static final String SHIPPING_OPTION_SECLETED = "shippingOptionSelected";
    public static final String AGENT_SITEID_MAPPING = "AGENT_SITEID_MAPPING";
    public static final String AGENT_SITEID_PREFIX_MAPPING = "AGENT_SITE_ID_PREFIX_MAP";
    public static final String DEFAULT_SITE_ID = "DEFAULT_SITE_ID";

    public static final String GET_DEVICES_SERVICE_ACTOR = "getDevicesServiceActor";
    public static final String GET_ACCESSORY_SERVICE_ACTOR = "getAccessoriesServiceActor";

    public static final String CURRENT_PAGE = "currentPage";

    public static final String ACCESSORIES_BUNDLE_INDEX = "ACCESSORIES_BUNDLE_INDEX";

    public static final String ACCESSORIES_BUNDLE_INDEX_NEW = "ACCESSORIES_BUNDLE_INDEX_NEW";

    public static final String ACCESSORIES_BUNDLE_INDEX_TYPE = "ACCESSORIES_BUNDLE_INDEX_TYPE";

    public static final String GET_DEVICE_DETAILS_SERVICE_ACTOR = "getDeviceDetailsServiceActor";

    public static final String ACCESSORIES_GIFT_CARD_INDEX = "ACCESSORIES_GIFT_CARD_INDEX";

    public static final String ACCESSORIES_GIFT_CARD_INDEX_TYPE = "ACCESSORIES_GIFT_CARD_INDEX_TYPE";

    public static final String BLANK_WHITE_SPACE = " ";

    public static final String GET_ACCESSORY_DETAILS_SERVICE_ACTOR = "getAccessoryDetailsServiceActor";
    public static final String SERVICE_ACTOR_MASTERPASS_CHECKOUT = "masterpassPaymentServiceActor";
    public static final String MASTERPASS_CALL_BACKURL = "/digital/prospect/checkout/processPaymentData";
    public static final String MASTERPASS_CHECKOUT_ID = "MASTERPASS_CHECKOUT_ID";
    public static final String MASTERPASS_ENABLED = "MASTERPASS_ENABLED";
    public static final String PAYMENT_METHOD_REDESIGN = "PAYMENT_METHOD_REDESIGN";
    public static final String MASTERPASS_CALLBACK_URL = "MASTERPASS_CALLBACK_URL";
    public static final String SWITCHER_MASTERPASS_CALLBACK_URL = "SWITCHER_MASTERPASS_CALLBACK_URL";
    public static final String SWITCHER_MASTERPASS_CHECKOUT_ID = "SWITCHER_MASTERPASS_CHECKOUT_ID";
    public static final String MASTERPASS_ALLOWED_CARD_TYPES = "MASTERPASS_ALLOWED_CARD_TYPES";
    public static final String MASTERPASS_WALLET_TYPE = "M";
    public static final String MASTERPASS_PAYMENT_MODE = "masterpass";
    public static final String BASIC_PHONE_COUNT = "basicPhone";
    public static final String SMART_PHONE_COUNT = "smartPhone";
    public static final String CONNECTED_DEVICE_COUNT = "connectedDevice";
    public static final String SINGLE_LINE_PLANS = "SINGLE_LINE_PLANS";
    public static final String AGENT_SITE_CLIENT_APP_NAME_MAP = "AGENT_SITE_CLIENT_APP_NAME_MAP";
    public static final String IS_AGENT_SITE = "IS_AGENT_SITE";
    public static final String AGENT_SITE_LISTING_TYPE_MAP = "AGENT_SITE_LISTING_TYPE_MAP";
    public static final String REDIS_MATERPASS_PAYMENT_FAILURE_KEY = "vzw_masterpass_payment_failure_key";
    public static final String MASTERPASS_CARD_PREAUTH_FAILURE_MESSAGE = "The credit/debit card you submitted has been declined. Please choose another saved card or enter a new one.";
    /**
     *
     */
    public static final String MF_HEADER_CLIENT_ID = "clientId";

    public static final String MF_HEADER_ADDITIONAL_CLIENT_INFO = "additionalClientInfo";

    public static final String MF_HEADER_UN = "un";
    public static final String MF_HEADER_PD = "pd";

    public static final String MF_CLIENT_ID_LIST = "MF_CLIENT_ID_LIST";
    public static final String MF_CLIENT_ID_CREDENTIALS_MAP = "MF_CLIENT_ID_CREDENTIALS_MAP";
    public static final String AM_LOGIN_MTN = "AM_MOBILE_NUMBER";
    public static final String PREPAY_CONSTANT = "Prepay";
    public static final String POSTPAID_CONSTANT = "Postpaid";

    public static final String OD_PROSPECT_SWITCHER_TAP_ON_REMOVE = "OD_PROSPECT_SWITCHER_TAP_ON_REMOVE";
    public static final String TOTAL_LINE_COUNT = "TOTAL_LINE_COUNT";
    public static final String TAP_LINES = "TAP_LINES";
    public static final String TAP_CQ_CONTENT = "tapCQContent";
    public static final String REMOVE_TAP_HEADER = "removeTapHeader";
    public static final String REMOVE_TAP_DESC = "removeTapDesc";
    public static final String REMOVE_TAP_YES = "removeTapYes";
    public static final String REMOVE_TAP_NO = "removeTapNo";
    public static final String MAIN_TAP_LINES = "mainTapLines";
    public static final String MAIN_TAP_LINES_LABLE = "mainTapLinesLable";
    public static final String MAIN_TAP_LINES_LABLE_TRAY = "mainTapLinesLableTray";
    public static final String ADDITIONAL_TAP_LINES1 = "addTapLines1";
    public static final String ADDITIONAL_TAP_LINES1_LABLE = "addTapLines1Lable";
    public static final String ADDITIONAL_TAP_LINES1_LABLE_TRAY = "addTapLines1LableTray";
    public static final String ADDITIONAL_TAP_LINES2 = "addTapLines2";
    public static final String ADDITIONAL_TAP_LINES2_LABLE = "addTapLines2Lable";
    public static final String ADDITIONAL_TAP_LINES2_LABLE_TRAY = "addTapLines2LableTray";
    public static final String ALL_TAP_LINES = "allTapLines";
    public static final String ALL_FIVE_LINES_STR = "All Five Lines";
    public static final String MAIN_TAP_LINES_LABLE_TRAY_STR = "Base payment for 3 lines";
    public static final String FIRST_THREE_LINES_STR = "First three lines";
    public static final String THREE_LINES_STR = "Three devices";
    public static final String FOUR_LINES_STR = "Four devices";
    public static final String FOURTH_LINES_STR = "Fourth lines";
    public static final String FIVE_LINES_STR = "Five devices";
    public static final String FIFTH_LINES_STR = "Fifth lines";


    public static final String REDIS_CONFIG_CLUSTER_HOST = "akka.application.config.configClusterHost";

    //CQ Keys newly added/updated
    public static final String PROSPECT_CHECKOUT_SHIPPING = "PROSPECT_CHECKOUT_SHIPPING";
    public static final String OD_PROSPECT_IN_STORE_PICKUP_HEADING = "OD_PROSPECT_IN_STORE_PICKUP_HEADING";
    public static final String OD_PROSPECT_IN_STORE_PICKUP_DESC_MOBILE = "OD_PROSPECT_IN_STORE_PICKUP_DESC_MOBILE";
    public static final String OD_PROSPECT_IN_STORE_PICKUP_DESC_DESKTOP_TAB = "OD_PROSPECT_IN_STORE_PICKUP_DESC_DESKTOP_TAB";

    //common String literal
    public static final String ONEDIGITAL_SWITCHER = "ONEDIGITAL-SWITCHER";
    public static final String ONEDIGITAL_NSE = "ONEDIGITAL-NSE";
    public static final String ONEDIGITAL_5G = "ONEDIGITAL-5G";
    public static final String USER_AGENT = "userAgent";
    public static final String GET_PRODUCT_DETAILS = "getProductDetails";
    public static final String RESPONSE_STR = "Response: ";
    public static final String ISPU = "ispu";
    public static final String ISPU_UC = "ISPU";
    public static final String MF_HEADER_TOKENIZATION_ENABLED = "TOKENIZATION_ENABLED";
    public static final String SERVICES_TOKENIZATION_ENABLED_HEADER = "SERVICES_TOKENIZATION_ENABLED_HEADER";
    public static final String GREATPLAINS_INDEX = "GREATPLAINS_INDEX";
    public static final String GREATPLAINS_INDEX_TYPE = "GREATPLAINS_INDEX_TYPE";
    public static final String SHARED_5G_USER_DATA_SERIALIZER = "com.vzw.serializer.Shared5GUserSerializer";
    public static final String SHARED_5G_USER_DATA_DESERIALIZER = "com.vzw.serializer.Shared5GUserDeserializer";
    public static final String SKIP_KAFKA_AND_PROCESS_5G_SHARED_USER_DATA = "SKIP_KAFKA_AND_PROCESS_5G_SHARED_USER_DATA";
    public static final String SKIP_5G_SHARED_USER_INFO = "SKIP_5G_SHARED_USER_INFO";

    public enum PLAYAPP {
        ECOMM_CUST_STORE, ECOMM_CUST_CAMPAIGN_STORE, ECOMM_STORE_PROSPECT, STORE, CPC, UF_STORE,
        PROSPECT, TRADE_IN, HOMEPAGE, ECOMM_SWITCHER_PROSPECT, ECOMM_STORE_TRADEIN, ECOMM_PROSPECT_MANUAL_ORDER_PROCESSOR, PREPAID_STORE, ECOMM_STORE_MOBILE_AND_HOME, ECOMM_COMMON
    }

    public static final String GET_YEARS = "getYears";
    public static final String GET_MAKE = "getMake";
    public static final String GET_MODEL = "getModel";
    public static final String TELEMATICS_HUM_TRANSPORT_PROTOCOL = "telematics_transport_protocol";
    public static final String HUM_ADDT_FEATURE_SKU_ID = "HUM_ADDT_FEATURE_SKU_ID";
    public static final String HUM_ADDT_FEATURE_SKU_IDS = "HUM_ADDT_FEATURE_SKU_IDS";
    public static final String HUM_PROTECTION_FEATURE_SKU_ID = "HUM_PROTECTION_FEATURE_SKU_ID";
    public static final String EDIT_PROTECTION_HUM = "EDIT_PROTECTION_HUM";
    public static final String HUM_PROXY_ENABLED = "HUM_PROXY_ENABLED";
    public static final String HUM_FILTER_MULTILINE_PLANS_ENABLED = "HUM_FILTER_MULTILINE_PLANS_ENABLED";
    public static final String HUM_AXIS_SO_TIMEOUT = "telematics_axis_default_connection_timeout";
    public static final String HUM_AXIS_CONNECTION_TIMEOUT = "telematics_axis_so_connection_timeout";
    public static final String DEFAULT_HUMX_SORID = "default_HumX_SorId";
    public static final String DEFAULT_HUMPLUS_SORID = "default_HumPlus_SorId";
    public static final String HUM_COLOR_LIST = "HUM_COLOR_LIST";
    public static final String PROXY_HOST = "proxy_host";
    public static final String PROXY_PORT = "proxy_port";
    public static final String TELEMATICS_PROXY_SET = "telematics_proxy_set";
    public static final int DEFAULT_CACHE_EXPIRY_TIME = 300;
    public static final String HUM_PLUS = "humPlus";
    public static final String HUM_X = "humX";
    public static final String HUM_VEHICLE_COMPATIBLE_CHECK_SERVICE_ACTOR = "humIsCompatibleVehicleServiceActor";
    public static final String HUM_EXISTIN_EMAIL_ADDRESS_CHECK_SERVICE_ACTOR = "humExistingEmailAddressCheckServiceActor";

    public static final String DEVICE_SMARTPHONE = "SMARTPHONE";
    public static final String DEVICE_TABLET = "TABLET";
    public static final String DEVICE_INTERNET_AND_HOME = "INTERNET_AND_HOME";
    public static final String DEVICE_CONNECTED_DEVICE = "CONNECTED_DEVICE";
    public static final String DEVICE_BASIC_PHONE_DEVICE = "BASIC_PHONE_DEVICE";
    public static final String AXIS_HTTPS_PROXY_HOST = "https.proxyHost";
    public static final String AXIS_HTTPS_PROXY_PORT = "https.proxyPort";
    public static final String AXIS_HTTP_PROXY_HOST = "http.proxyHost";
    public static final String AXIS_HTTP_PROXY_PORT = "http.proxyPort";

    //3DSecure constants
    public static final String SKIP_UI_3D_SECURE_SETUP_FLAG_FOR_CMPILOOKUP = "SKIP_UI_3D_SECURE_SETUP_FLAG_FOR_CMPILOOKUP";
    public static final String EPS_3D_SECURE_ENABLED = "EPS_3D_SECURE_ENABLED";
    public static final String EPS_3D_SECURE_MOBILE_ENABLED = "EPS_3D_SECURE_MOBILE_ENABLED";
    public static final String EPS_3D_SECURE_DESKTOP_ENABLED = "EPS_3D_SECURE_DESKTOP_ENABLED";
    public static final String EPS_3D_SECURE_KAFKA_ENABLED = "EPS_3D_SECURE_KAFKA_ENABLED";
    public static final String SECURITY_DEPOSIT_WAIVER_ENABLED = "SECURITY_DEPOSIT_WAIVER_ENABLED";
    public static final String EPS_3D_SECURE_TRANSACTION_MODE_ECOM = "S";
    public static final String EPS_3D_SECURE_CUSTOMER_TYPE_ENROLLED = "Y";
    public static final String EPS_3D_SECURE_MERCHANT_ID = "EPS_3D_SECURE_MERCHANT_ID";
    public static final String EPS_3D_SECURE_MERCHANT_TOKEN = "EPS_3D_SECURE_MERCHANT_TOKEN";
    public static final String EPS_3D_SECURE_PROCESSOR_ID = "EPS_3D_SECURE_PROCESSOR_ID";
    public static final String EPS_3D_SECURE_TRANSACTION_TYPE = "EPS_3D_SECURE_TRANSACTION_TYPE";
    public static final String EPS_3D_SECURE_JWT_APIKEY = "EPS_3D_SECURE_JWT_APIKEY";
    public static final String EPS_3D_SECURE_JWT_APIIDENTIFIER = "EPS_3D_SECURE_JWT_APIIDENTIFIER";
    public static final String EPS_3D_SECURE_JWT_ORGUNITID = "EPS_3D_SECURE_JWT_ORGUNITID";
    public static final String EPS_3D_SECURE_JWT_EXPIRY_TIME = "EPS_3D_SECURE_JWT_EXPIRY_TIME";
    public static final String EPS_3D_SECURE_SOURCE_CD = "EPS_3D_SECURE_SOURCE_CD";
    public static final String EPS_3D_SECURE_ACTION_LOOKUP = "EPS_3D_SECURE_ACTION_LOOKUP";
    public static final String EPS_3D_SECURE_ACTION_JWT_VERIFY = "EPS_3D_SECURE_ACTION_JWT_VERIFY";
    public static final String EPS_3D_SECURE_FEATURES_LIST = "EPS_3D_SECURE_FEATURES_LIST";

    public static final String SHIPPING_CODES_SDD = "SHIPPING_CODES_SDD";
    public static final String SHIPPING_CODES_OVERNIGHT = "SHIPPING_CODES_OVERNIGHT";
    public static final String SHIPPING_CODES_PRIORITY = "SHIPPING_CODES_PRIORITY";
    public static final String SHIPPING_CODES_GROUND = "SHIPPING_CODES_GROUND";
    public static final String SHIPPING_CODES_ISPU = "SHIPPING_CODES_ISPU";
    public static final String EPS_3D_SECURE_DEFAULT_SHIPPING_CODE = "EPS_3D_SECURE_DEFAULT_SHIPPING_CODE";
    public static final String EPS_3D_SECURE_SHIPPING_CODE_SAME_DAY = "01";
    public static final String EPS_3D_SECURE_SHIPPING_CODE_OVERNIGHT = "02";
    public static final String EPS_3D_SECURE_SHIPPING_CODE_PRIORITY = "03";
    public static final String EPS_3D_SECURE_SHIPPING_CODE_GROUND = "04";
    public static final String EPS_3D_SECURE_SHIPPING_CODE_ELECTRONIC = "05";
    public static final String EPS_3D_SECURE_SHIPPING_CODE_ISPU = "06";

    public static final String PROCESS_CARDINAL_RESPONSE = "PROCESS_CARDINAL_RESPONSE";
    public static final String CLIENT_APP_NAME_PREPAY = "ATG-ECOM-PREPAY";
    public static final String VZW_PROSPECT_PIE_ENCRIPTION_ENABLED = "VZW_PROSPECT_PIE_ENCRIPTION_ENABLED";
    public static final String PIE = "PIE";
    public static final String PCC = "PCC";
    public static final String CPO_DEVICE_SELECTED_FROM_DP_OVERLAY = "isCPODeviceSelectedFromDPOverlay";
    public static final String APPROVED_DEVICE_SELECTED_FROM_DP_OVERLAY = "isApprovedDeviceSelectedFromDPOverlay";


    public static final String BOOKMARKED_URL = "bookMarkedUrl";
    public static final String UF_DESKTOP_FLOW_DISABLED = "UF_DESKTOP_FLOW_DISABLED";
    public static final String RECOM_ACC_ENABLED = "RECOM_ACC_ENABLED";
    public static final String RECOMMENDED_BUNDLES_FROM_ENDECA = "RECOMMENDED_BUNDLES_FROM_ENDECA";
    public static final String RECOMMENDED_ACC_FROM_ENDECA = "RECOMMENDED_BUNDLES_FROM_ENDECA";
    public static final String ENABLE_FALLBACK_ACC_FROM_ELASTIC = "ENABLE_FALLBACK_ACC_FROM_ELASTIC";
    public static final String ENABLE_FALLBACK_BUNDLES_FROM_ELASTIC = "ENABLE_FALLBACK_BUNDLES_FROM_ELASTIC";
    public static final String RECOMMENDED_ACCESSORIES_INDEX = "RECOMMENDED_ACCESSORIES_INDEX";
    public static final String ECPD_DISCOUNT = "ECPD";
    public static final String OOS_CHECK_ACCESSORIES_ENABLED = "OOS_CHECK_ACCESSORIES_ENABLED";
    public static final String RECOMMENDED_ACCESSORIES_BUNDLES_ACTOR = "recommendedAccessoriesBundlesActor";
    public static final String ACCESSORY_IMAGE_MEDIUM = "ACCESSORY_IMAGE_MEDIUM";
    public static final String ECPD_ACCESSORY_CHECK = "ECPD_ACCESSORY_CHECK";
    public static final String SERVICE_ACTOR_CART_ADD_UPDATE_ACCESSORY = "addUpdateAccessory";
    public static final String DEVICE_MOBILE = "MOBILE";
    public static final String SERVICE_ACTOR_COMPATIBLE_BUNDLE_ACCESSORIES = "compatibleBundleAccessories";
    public static final String SERVICE_ACTOR_INLINE_ACCESSORIES = "inlineAccessories";
    public static final String ECOMM_RECOM_ACCESSORIES_ENABLED = "ECOMM_RECOM_ACCESSORIES_ENABLED";
    public static final String ECOMM_RECOM_ACCESSORIES_APPLECARE_FETCH = "ECOMM_RECOM_ACCESSORIES_APPLECARE_FETCH";

    public static final String NO_TAP_ELIGIBLE_DACC = "NO_TAP_ELIGIBLE_DACC";

    public static final String VENDORID_REACTIVE_ENABLE = "VENDORID_REACTIVE_ENABLE";
    public static final String APPEND_VENDORID_AFFILIATE_ENABLE = "APPEND_VENDORID_AFFILIATE_ENABLE";
    public static final String VENDORID_B2CVENDORID = "VENDORID_B2CVENDORID";
    public static final String VENDORID_EPPVENDORID = "VENDORID_EPPVENDORID";
    public static final String VENDORID_B2EVENDORID = "VENDORID_B2EVENDORID";
    public static final String VENDORID_EPPCJMVENDORIDPREFIX = "VENDORID_EPPCJMVENDORIDPREFIX";
    public static final String VENDORID_B2ECJMVENDORIDPREFIX = "VENDORID_B2ECJMVENDORIDPREFIX";
    public static final String VENDORID_B2CDESKTOP = "VENDORID_B2CDESKTOP";
    public static final String VENDORID_B2CMOBILE = "VENDORID_B2CMOBILE";
    public static final String VENDORID_B2CAPP_ANDROID = "VENDORID_B2CAPP_ANDROID";
    public static final String VENDORID_B2CAPP_IOS = "VENDORID_B2CAPP_IOS";
    public static final String VENDORID_B2CMF_IOS = "VENDORID_B2CMF_IOS";
    public static final String VENDORID_B2CMF_ANDROID = "VENDORID_B2CMF_ANDROID";
    public static final String VENDORID_B2CTABLET = "VENDORID_B2CTABLET";
    public static final String VENDORID_B2EDESKTOP = "VENDORID_B2EDESKTOP";
    public static final String VENDORID_B2EMOBILE = "VENDORID_B2EMOBILE";
    public static final String VENDORID_B2EAPP_ANDROID = "VENDORID_B2EAPP_ANDROID";
    public static final String VENDORID_B2EAPP_IOS = "VENDORID_B2EAPP_IOS";
    public static final String VENDORID_B2EMF_ANDROID = "VENDORID_B2EMF_ANDROID";
    public static final String VENDORID_B2EMF_IOS = "VENDORID_B2EMF_IOS";
    public static final String VENDORID_B2ETABLET = "VENDORID_B2ETABLET";
    public static final String VENDORID_EPPDESKTOP = "VENDORID_EPPDESKTOP";
    public static final String VENDORID_EPPMOBILE = "VENDORID_EPPMOBILE";
    public static final String VENDORID_EPPAPP_ANDROID = "VENDORID_EPPAPP_ANDROID";
    public static final String VENDORID_EPPAPP_IOS = "VENDORID_EPPAPP_IOS";
    public static final String VENDORID_EPPMF_ANDROID = "VENDORID_EPPMF_ANDROID";
    public static final String VENDORID_EPPMF_IOS = "VENDORID_EPPMF_IOS";
    public static final String VENDORID_EPPTABLET = "VENDORID_EPPTABLET";
    public static final String VENDORID_B2CWEB_RV_DESKTOP = "VENDORID_B2CWEB_RV_DESKTOP";
    public static final String VENDORID_B2CWEB_RV_MOBILE = "VENDORID_B2CWEB_RV_MOBILE";
    public static final String VENDORID_B2EWEB_RV_DESKTOP = "VENDORID_B2EWEB_RV_DESKTOP";
    public static final String VENDORID_B2EWEB_RV_MOBILE = "VENDORID_B2EWEB_RV_MOBILE";
    public static final String VENDORID_EPPWEB_RV_DESKTOP = "VENDORID_EPPWEB_RV_DESKTOP";
    public static final String VENDORID_EPPWEB_RV_MOBILE = "VENDORID_EPPWEB_RV_MOBILE";
    public static final String VENDORID_B2CRV_TELESALES = "VENDORID_B2CRV_TELESALES";
    public static final String VENDORID_B2ERV_TELESALES = "VENDORID_B2ERV_TELESALES";
    public static final String VENDORID_EPPRV_TELESALES = "VENDORID_EPPRV_TELESALES";
    public static final String VENDORID_B2CVZW_FIOS = "VENDORID_B2CVZW_FIOS";
    public static final String VENDORID_B2CVZW_PPC_DESKTOP = "VENDORID_B2CVZW_PPC_DESKTOP";
    public static final String VENDORID_B2CVZW_PPC_MOBILE = "VENDORID_B2CVZW_PPC_MOBILE";
    public static final String TRADEIN_SUBMISSIONID_ENDPOINT = "TRADEIN_SUBMISSIONID_ENDPOINT";
    public static final String DISPLAY_RECOMMENDED_COMPATIBLE_ACCESSORIES = "display_recommended_compatible_accessories";
    public static final String EXCLUDE_RECOMMENDED_COMPATIBLE_ACCESSORIES = "exclude_recommended_compatible_accessories";
    public static final String STRING_TRUE = "true";
    public static final String STRING_NULL = "null";
    public static final String MIN_RECOM_COMP_ACCES_COUNT_ON_PDP = "min_recom_comp_acces_count_on_pdp";
    public static final String GET_PROMO_LANDING_SERVICE_ACTOR = "getPromoLandingServiceActor";
    public static final String GET_PROMO_LANDING_BUSINESS_ACTOR = "getPromoLandingBusinessActor";
    public static final String STORES_INDEX = "STORES_INDEX";
    public static final String STORES_TYPE = "STORES_TYPE";
    public static final String SPACE = " ";
    public static final String STORES_LOCATION_FIELD = "STORES_LOCATION_FIELD";
    public static final String CUSTOMER_INSIGHTS_INTEGRATION_ACTOR = "getCustomerInsightsIntegrationActor";
    public static final String CACHE_FOR_MARKET_DETAILS_ENABLE = "CACHE_FOR_MARKET_DETAILS_ENABLE";
    public static final String GUAVA_CACHE_FOR_MARKET_DETAILS_ENABLE = "GUAVA_CACHE_FOR_MARKET_DETAILS_ENABLE";
    public static final String MARKET_DETAILS = "MARKET_DETAILS_";
    public static final String POSTPAID_ZIP_RESTRICTED_HARD_STOP_ERROR_MESSAGE = "POSTPAID_ZIP_RESTRICTED_HARD_STOP_ERROR_MESSAGE";
    public static final String DISABLE_AFFILIATE_CLIENTINFO_VENDORID_UPDATE = "DISABLE_AFFILIATE_CLIENTINFO_VENDORID_UPDATE";
    public static final String ORDER_WRITE_BROWSER_AGENT_LENGTH = "ORDER_WRITE_BROWSER_AGENT_LENGTH";
    public static final String SKIP_KAFKA_AND_PROCESS_PREPAY_ORDER = "SKIP_KAFKA_AND_PROCESS_PREPAY_ORDER";
    public static final String VENDOR_ACCESSOIRES_INVENTORY_INDEX = "VENDOR_ACCESSOIRES_INVENTORY_INDEX";
    public static final String VENDOR_ACCESSORIES_INVENTORY_TYPE = "VENDOR_ACCESSORIES_INVENTORY_TYPE";
    public static final String VENDOR_ACCESSORIES_INDEX = "VENDOR_ACCESSORIES_INDEX";
    public static final String VENDOR_ACCESSORIES_INDEX_TYPE = "VENDOR_ACCESSORIES_INDEX_TYPE";

    public static final String MYPAGE_VALIDATE_SALES_REP_ACTOR = "validateSalesRepActor";
    public static final String MYPAGE_MYLINK_DEVICE_LIST = "SALES_REP_MyPage_MyLinkList";
    public static final String MYPAGE_REP_ROOT_URL = "http://www.vzw.com/user/";

    public static final String MYLINK_DATA_CONSUMER_ACTOR = "myLinkDataConsumerActor";
    public static final String MYLINK_DATA_CONSUMER_BUSINESS_ACTOR = "myLinkDataConsumerBusinessActor";
    public static final String MYLINK_VALIDATE_SALES_REP_ACTOR = "validateSalesRepActor";
    public static final String MYLINK_UPDATE_CLICK_ACTOR = "myLinkUpdateClickActor";

    public static final String MYLINK_COOKIE_REP_ID_COOKIE_TEXT = "RepIdCookieText";
    public static final String MYLINK_COOKIE_MY_LINK_SALES_DOMAIN = "MyLinkSalesDomain";
    public static final String MYLINK_COOKIE_MY_LINK_AGENT_OUTLET_ID = "MyLinkAgentOutletId";
    public static final String MYLINK_COOKIE_MY_LINK_AGENT_SITE_ID = "MyLinkAgentSiteId";

    public static final String MYLINK_ENABLE_SALESREPID_VALIDATION = "MYLINK_ENABLE_SALESREPID_VALIDATION";
    public static final String MYLINK_REP_ID_VALID = "repIdValid";
    public static final String MYLINK_SALES_CHANNEL = "salesChannel";
    public static final String MYLINK_REP_ID = "repId";
    public static final String MYLINK_REDIRECT_URL = "redirectUrl";
    public static final String MYLINK_RECORD_UPDATE_COUNT = "recordsUpdated";
    public static final String MYLINK_SALES_GIVEN_NAME = "salesRepGivenName";
    public static final String MYLINK_VALID_SALES_REP_ID = "validSalesRepId";
    public static final String MYLINK_LOGIN_SHOW_MODAL = "showModal";
    public static final String MYLINK_LOGIN_SUCCESS = "success";
    public static final String ERROR_MESSAGE = "errorMessage";
    public static final String MYLINK_LOGIN_ERROR_MESSAGE = "We are unable to validate the Rep Id. Click 'Continue', if you like to proceed.";
    public static final String MYLINK_MFAPP = "MFAPP";
    public static final String MYLINK_VANITY_FLOW = "VanityFlow";


    //Mylink Error constant parameters
    public static final String MYLINK_VALIDATE_SALES_REP_API_FAILURE_CODE = "02";
    public static final String MYLINK_VALIDATE_SALES_REP_API_FAILURE_MSG = "DVS validateSalesRep API failed Service-Error";
    public static final String MYLINK_VALIDATE_ELASTIC_SEARCH_REP_API_FAILURE_MSG = "Rep ID Invalid - No rep found in ElasticSearch";


    public static final String MYLINK_PERSIST_SYSTEM_ERROR_CODE = "04";
    public static final String MYLINK_PERSIST_SYSTEM_ERROR_MSG = "System error";

    public static final String MYLINK_PERSIST_DATABASE_ERROR_CODE = "03";
    public static final String MYLINK_PERSIST_DATABASE_ERROR_MSG = "Database error";

    public static final String MYLINK_PERSIST_SERVICE_SUCCESS_CODE = "00";
    public static final String MYLINK_PERSIST_SERVICE_SUCCESS_MSG = "Service Completed Successfully";
    public static final String MYLINK_PERSIST_SERVICE_SUCCESS_MSG_2 = "Service Completed Successfully with Note: Entry may not be immediately available as database is taking longer than expected to update.";

    public static final String MYLINK_PERSIST_ECODE_CLICK_ENABLED_KEY = "MYLINK_PERSIST_ECODE_CLICK_ENABLED_KEY";

    public static final String REDIS_ENCPASS_KEY = "akka.redis.config.encryptedPassword";
    public static final String REDIS_PASS_ENC_SALT_KEY = "akka.redis.config.passwordEncryptionSalt";
    public static final String REDIS_PASS_ENC_IV_KEY = "akka.redis.config.passwordEncryptionIV";
    public static final String REDIS_PASS_ENC_PASSPHRASE_KEY = "akka.redis.config.passwordEncryptionPassPhrase";

    public static final String REDIS_CONFIG_CLUSTER_ENCPASS_KEY = "akka.application.config.encryptedPassword";
    public static final String REDIS_CONFIG_CLUSTER_PASS_ENC_SALT_KEY = "akka.application.config.passwordEncryptionSalt";
    public static final String REDIS_CONFIG_CLUSTER_PASS_ENC_IV_KEY = "akka.application.config.passwordEncryptionIV";
    public static final String REDIS_CONFIG_CLUSTER_PASS_ENC_PASSPHRASE_KEY = "akka.application.config.passwordEncryptionPassPhrase";

    public static final String REDIS_SSL_ENABLED_KEY = "akka.redis.config.sslEnabled";
    public static final String REDIS_CONFIG_CLUSTER_SSL_ENABLED_KEY = "akka.application.config.sslEnabled";
    public static final String PROSPECT_APPLICATION_ID = "PROSPECT_APPLICATION_ID";
    public static final String DISABLE_FEATURES_UNDER_DEVICE_DETAIL = "DISABLE_FEATURES_UNDER_DEVICE_DETAIL";
    //1D changes
    public static final String ONEDIGITAL_PROSPECT = "ONEDIGITAL-PROSPECT";

    public static final String GNAV_JSON_DOMAIN = "GNAV_JSON_DOMAIN";
    public static final String SITE_ID_LABEL = "SITE_ID_LABEL";

    //Timeout changes
    public static final String SPLT_ADDR_INT_ACTOR_PERS_INF_REQ_MILLIS_TIMEOUT = "SPLT_ADDR_INT_ACTOR_PERS_INF_REQ_MILLIS";
    public static final String SPLT_ADDR_INT_ACTOR_DEV_ADDR_UPD_REQ_MILLIS_TIMEOUT = "SPLT_ADDR_INT_ACTOR_DEV_ADDR_UPD_REQ_MILLIS";
    public static final String SPLT_ADDR_INT_ACTOR_UPD_PAY_INF_BUSS_ADDRVAL_MILLIS_TIMEOUT = "SPLT_ADDR_INT_ACTOR_UPD_PAY_INF_BUSS_ADDRVAL_MILLIS";
    public static final String SPLT_ADDR_INT_ACTOR_VALIDATE_SHP_ADDR_BUSS_REQ_MILLIS_TIMEOUT = "SPLT_ADDR_INT_ACTOR_VALIDATE_SHP_ADDR_BUSS_REQ_MILLIS";
    public static final String SPLT_ADDR_INT_ACTOR_VALIDATE_PORT_BUSS_REQ_MILLIS_TIMEOUT = "SPLT_ADDR_INT_ACTOR_VALIDATE_PORT_BUSS_REQ_MILLIS";
    public static final String CONF_EMAIL_INT_ACTOR_REQ_MILLIS_TIMEOUT = "CONF_EMAIL_INT_ACTOR_REQ_MILLIS";
    public static final String CONF_EMAIL_INT_ACTOR_RES_MILLIS_TIMEOUT = "CONF_EMAIL_INT_ACTOR_RES_MILLIS";
    public static final String SUB_TRADEIN_SERV_ACTOR_SUB_ORD_SERV_MILLIS_TIMEOUT = "SUB_TRADEIN_SERV_ACTOR_SUB_ORD_SERV_MILLIS";
    public static final String REAPPR_TRADEIN_SERV_ACT_GET_CART_BUSS_MILLIS_TIMEOUT = "REAPPR_TRADEIN_SERV_ACT_GET_CART_BUSS_MILLIS";
    public static final String THREED_SEC_LOOK_INT_ACTOR_UPD_PAY_INF_BUSS_MILLIS_TIMEOUT = "THREED_SEC_LOOK_INT_ACTOR_UPD_PAY_INF_BUSS_MILLIS";
    public static final String GFT_CARD_PREAUTH_INT_ACTOR_UPD_PAY_INF_BUSS_1_MILLIS_TIMEOUT = "GFT_CARD_PREAUTH_INT_ACTOR_UPD_PAY_INF_BUSS_1_MILLIS";
    public static final String GFT_CARD_PREAUTH_INT_ACTOR_UPD_PAY_INF_BUSS_2_MILLIS_TIMEOUT = "GFT_CARD_PREAUTH_INT_ACTOR_UPD_PAY_INF_BUSS_2_MILLIS";
    public static final String CREDIT_CARD_PREAUTH_INT_ACTOR_UPD_PAY_INF_BUSS_MILLIS_TIMEOUT = "CREDIT_CARD_PREAUTH_INT_ACTOR_UPD_PAY_INF_BUSS_MILLIS";
    public static final String ECPD_PROF_INT_ACTOR_GET_ECPD_BUSS_MILLIS_TIMEOUT = "ECPD_PROF_INT_ACTOR_GET_ECPD_BUSS_MILLIS";
    public static final String ECPD_PROF_INT_ACTOR_BASE_CONT_MILLIS_TIMEOUT = "ECPD_PROF_INT_ACTOR_BASE_CONT_MILLIS";
    public static final String ECPD_PROF_ACTOR_BASE_CONT_MILLIS_TIMEOUT = "ECPD_PROF_ACTOR_BASE_CONT_MILLIS";
    public static final String ECPD_ACC_COMM_INT_ACTOR_GET_ECPD_BUSS_MILLIS_TIMEOUT = "ECPD_ACC_COMM_INT_ACTOR_GET_ECPD_BUSS_MILLIS";
    public static final String ECPD_ACC_COMM_INT_ACTOR_BASE_CONT_MILLIS_TIMEOUT = "ECPD_ACC_COMM_INT_ACTOR_BASE_CONT_MILLIS";
    public static final String ADD_UPD_CART_BUSS_PLN_FRST_MILLIS_TIMEOUT = "ADD_UPD_CART_BUSS_PLN_FRST_MILLIS";
    public static final String RET_ITEM_QAN_INT_ACTOR_PDP_STOR_LOC_BUSS_MILLIS_TIMEOUT = "RET_ITEM_QAN_INT_ACTOR_PDP_STOR_LOC_BUSS_MILLIS";
    public static final String GET_CART_PROMO_BUSS_ACT_ITEM_PRIC_SERV_MILLIS_TIMEOUT = "GET_CART_PROMO_BUSS_ACT_ITEM_PRIC_SERV_MILLIS";
    public static final String COMP_OFFR_SERV_ACT_ITEM_PRIC_SERV_MILLIS_TIMEOUT = "COMP_OFFR_SERV_ACT_ITEM_PRIC_SERV_MILLIS";
    public static final String TAX_PROCES_INT_ACT_POS_TAX_CAL_MILLIS_TIMEOUT = "TAX_PROCES_INT_ACT_POS_TAX_CAL_MILLIS";
    public static final String TAX_PROCES_INT_ACT_POS_TAX_CAL_PREPAID_MILLIS_TIMEOUT = "TAX_PROCES_INT_ACT_POS_TAX_CAL_PREPAID_MILLIS";
    public static final String TAX_PROCES_INT_ACT_PROS_PRIC_ACOTOR_MILLIS_TIMEOUT = "TAX_PROCES_INT_ACT_PROS_PRIC_ACOTOR_MILLIS";
    public static final String GET_PDP_PROMO_BUSS_ACT_POS_DEV_CONFIG_MILLIS_TIMEOUT = "GET_PDP_PROMO_BUSS_ACT_POS_DEV_CONFIG_MILLIS";
    public static final String GET_PDP_PROMO_BUSS_ACT_PROS_PRIC_ACOTOR_MILLIS_TIMEOUT = "GET_PDP_PROMO_BUSS_ACT_PROS_PRIC_ACOTOR_MILLIS";
    public static final String PROD_VAL_CART_BUSS_ACT_GET_CART_BUSS_MILLIS_TIMEOUT = "PROD_VAL_CART_BUSS_ACT_GET_CART_BUSS_MILLIS";
    public static final String SUB_SHARED_CART_INT_ACTOR_SUB_SHARED_CART_BUSS_MILLIS_TIMEOUT = "SUB_SHARED_CART_INT_ACTOR_SUB_SHARED_CART_BUSS_MILLIS";
    public static final String SUB_SHARED_CART_INT_ACTOR_SUB_SHARED_CART_BUSS_BILL_MILLIS_TIMEOUT = "SUB_SHARED_CART_INT_ACTOR_SUB_SHARED_CART_BUSS_BILL_MILLIS";
    public static final String BYOD_LAND_ACTOR_LAND_CONT_MILLIS_TIMEOUT = "BYOD_LAND_ACTOR_LAND_CONT_MILLIS";
    public static final String ACCP_DEPOSITE_ACTOR_ACCP_DEPO_CONT_MILLIS_TIMEOUT = "ACCP_DEPOSITE_ACTOR_ACCP_DEPO_CONT_MILLIS";
    public static final String GET_APPLE_PAY_SESSION_APPLE_PAY_CONT_MILLIS_TIMEOUT = "GET_APPLE_PAY_SESSION_APPLE_PAY_CONT_MILLIS";
    public static final String DECR_APPLE_PAY_TOKEN_APPLE_PAY_CONT_MILLIS_TIMEOUT = "DECR_APPLE_PAY_TOKEN_APPLE_PAY_CONT_MILLIS";
    public static final String YMM_SERV_ACTOR_YEAR_MM_CONT_MILLIS_TIMEOUT = "YMM_SERV_ACTOR_YEAR_MM_CONT_MILLIS";
    public static final String YMM_SERV_ACTOR_YEAR_MM_CONT_MODEL_MILLIS_TIMEOUT = "YMM_SERV_ACTOR_YEAR_MM_CONT_MODEL_MILLIS";
    public static final String YMM_SERV_ACTOR_YEAR_MM_CONT_MAKE_MILLIS_TIMEOUT = "YMM_SERV_ACTOR_YEAR_MM_CONT_MAKE_MILLIS";
    public static final String ZIP_VAL_ACTOR_VAL_ZIP_CONT_MILLIS_TIMEOUT = "ZIP_VAL_ACTOR_VAL_ZIP_CONT_MILLIS";
    public static final String ZIP_VAL_ACTOR_GEO_DATA_CONT_MILLIS_TIMEOUT = "ZIP_VAL_ACTOR_GEO_DATA_CONT_MILLIS";
    public static final String GEO_LOC_ACTOR_GEO_DATA_CONT_MILLIS_TIMEOUT = "GEO_LOC_ACTOR_GEO_DATA_CONT_MILLIS";
    public static final String SIM_VAL_SERV_ACTOR_VAL_SIM_CONT_MILLIS_TIMEOUT = "SIM_VAL_SERV_ACTOR_VAL_SIM_CONT_MILLIS";
    public static final String UPD_BILL_ADDR_UPD_BILL_ADDR_CONT_MILLIS_TIMEOUT = "UPD_BILL_ADDR_UPD_BILL_ADDR_CONT_MILLIS";
    public static final String ADD_E911_ADDR_E911_ADDR_CONT_MILLIS_TIMEOUT = "ADD_E911_ADDR_E911_ADDR_CONT_MILLIS";
    public static final String DEV_CONFIG_ACTOR_DEV_CONFIG_CONT_MILLIS_TIMEOUT = "DEV_CONFIG_ACTOR_DEV_CONFIG_CONT_MILLIS";
    public static final String DEV_CONFIG_ACTOR_REACT_DEV_CONFIG_CONT_MILLIS_TIMEOUT = "DEV_CONFIG_ACTOR_REACT_DEV_CONFIG_CONT_MILLIS";
    public static final String PROTECT_FEATURE_ACTOR_DEV_CONFIG_CONT_MILLIS_TIMEOUT = "PROTECT_FEATURE_ACTOR_DEV_CONFIG_CONT_MILLIS";
    public static final String PROTECT_FEATURE_ACTOR_REACT_DEV_CONFIG_CONT_MILLIS_TIMEOUT = "PROTECT_FEATURE_ACTOR_REACT_DEV_CONFIG_CONT_MILLIS";
    public static final String COMP_ACCESS_ACTOR_DEV_CONFIG_CONT_MILLIS_TIMEOUT = "COMP_ACCESS_ACTOR_DEV_CONFIG_CONT_MILLIS";
    public static final String COMP_ACCESS_ACTOR_DEV_CONFIG_CONT_BUNDLE_MILLIS_TIMEOUT = "COMP_ACCESS_ACTOR_DEV_CONFIG_CONT_BUNDLE_MILLIS";
    public static final String COMP_ACCESS_ACTOR_REACT_DEV_CONFIG_CONT_MILLIS_TIMEOUT = "COMP_ACCESS_ACTOR_REACT_DEV_CONFIG_CONT_MILLIS";
    public static final String COMP_ACCESS_ACTOR_COMP_ACCESS_CONT_MILLIS_TIMEOUT = "COMP_ACCESS_ACTOR_COMP_ACCESS_CONT_MILLIS";
    public static final String ACCESS_DETAILS_ACTOR_ACCESS_DETAILS_CONT_MILLIS_TIMEOUT = "ACCESS_DETAILS_ACTOR_ACCESS_DETAILS_CONT_MILLIS";
    public static final String HUM_EXIST_EMAIL_CHK_ACTOR_HUM_DEV_CONT_MILLIS_TIMEOUT = "HUM_EXIST_EMAIL_CHK_ACTOR_HUM_DEV_CONT_MILLIS";
    public static final String IS_COMP_VHCL_HUM_ACTOR_HUM_DEV_CONT_MILLIS_TIMEOUT = "IS_COMP_VHCL_HUM_ACTOR_HUM_DEV_CONT_MILLIS";
    public static final String PDP_FEATURE_ACTOR_BROWSE_CONT_MILLIS_TIMEOUT = "PDP_FEATURE_ACTOR_BROWSE_CONT_MILLIS";
    public static final String PLAN_ACTOR_CART_CONT_MILLIS_TIMEOUT = "PLAN_ACTOR_CART_CONT_MILLIS";
    public static final String PLAN_ACTOR_PLAN_CONT_COMP_MILLIS_TIMEOUT = "PLAN_ACTOR_PLAN_CONT_COMP_MILLIS";
    public static final String PLAN_ACTOR_PLAN_CONT_LIST_MILLIS_TIMEOUT = "PLAN_ACTOR_PLAN_CONT_LIST_MILLIS";
    public static final String PLAN_ACTOR_PLAN_CONT_LIST_SERV_MILLIS_TIMEOUT = "PLAN_ACTOR_PLAN_CONT_LIST_SERV_MILLIS";
    public static final String SHPING_MTHD_ACTOR_PERS_INF_CONT_MILLIS_TIMEOUT = "SHPING_MTHD_ACTOR_PERS_INF_CONT_MILLIS";
    public static final String GET_CART_DETAILS_ACTOR_CART_CONT_MILLIS_TIMEOUT = "GET_CART_DETAILS_ACTOR_CART_CONT_MILLIS";
    public static final String GET_CART_DETAILS_ACTOR_CART_CONT_PROMO_MILLIS_TIMEOUT = "GET_CART_DETAILS_ACTOR_CART_CONT_PROMO_MILLIS";
    public static final String GET_CART_DETAILS_ACTOR_CART_CONT_RETRIVE_LAMBDA_MILLIS_TIMEOUT = "GET_CART_DETAILS_ACTOR_CART_CONT_RETRIVE_LAMBDA_MILLIS";
    public static final String GET_CART_DETAILS_ACTOR_CART_CONT_RETRIVE_MILLIS_TIMEOUT = "GET_CART_DETAILS_ACTOR_CART_CONT_RETRIVE_MILLIS";
    public static final String PREPAY_AUTOPAY_ENABLED = "prepayAutoEnabled";
    public static final String PREPAY_SAVE_CREDIT_INFO = "prepaySaveCreditInfo";
    public static final String DEFAULT_CREDIT_REASON_CODE = "2Y";
    public static final String PROFILE_EMAIL = "profileEmail";
    public static final String ENFORCE_API_BUSS_ACTOR_MILLIS_TIMEOUT = "ENFORCE_API_BUSS_ACTOR_MILLIS";


    public static final String CONFIGURABLE_ACCESSORIES_INDEX = "CONFIGURABLE_ACCESSORIES_INDEX";
    public static final String GIFT_CARD_ACCESSORY_ENABLED = "GIFT_CARD_ACCESSORY_ENABLED";
    public static final String ACCESSORY_GIFT_CARD_SKU_IDS = "ACCESSORY_GIFT_CARD_SKU_IDS";
    public static final int AVAILABILITY_STATUS_PREORDERABLE = 1002;
    public static final int AVAILABILITY_STATUS_BACKORDERABLE = 1003;
    public static final String SHIP_BY_TXT = "SHIP_BY_TXT";
    public static final String SHIP_BY_CONSTANT = "S";
    public static final String DELIVER_BY_TXT = "DELIVER_BY_TXT";
    public static final String DELIVER_BY_CONSTANT = "D";

    public static final String DEFAULT_ASYNC_CONNECTIONS_REQUEST_TIMEOUT = "DEFAULT_ASYNC_CONNECTIONS_REQUEST_TIMEOUT";
    public static final String DEFAULT_LT_ASYNC_CONNECTIONS_REQUEST_TIMEOUT = "DEFAULT_LT_ASYNC_CONNECTIONS_REQUEST_TIMEOUT";

    public static final String CRM_CAMPAIGN_LEAD_INFO_INDEX = "CRM_CAMPAIGN_LEAD_INFO_INDEX";
    public static final String CRM_CAMPAIGN_LEAD_INFO_INDEX_TYPE = "CRM_CAMPAIGN_LEAD_INFO_INDEX_TYPE";

    public static final String BUSINESS_PROPERTIES_LIST_INFO_INDEX = "BUSINESS_PROPERTIES_LIST_INFO_INDEX";
    public static final String BUSINESS_PROPERTIES_LIST_INFO_INDEX_TYPE = "BUSINESS_PROPERTIES_LIST_INFO_INDEX_TYPE";

    public static final String VENDORID_5G_NSE_SUFFIX = "-5G-NSE";
    public static final String DEVICE_5G_SERVICE = "DEVICE_5G_SERVICE";
    public static final String DEVICE_4G_SERVICE = "DEVICE_4G_SERVICE";
    public static final String AGENT_GLOBAL_SITE_ID = "AGENT_GLOBAL_SITE_ID";
    public static final String NEXUS_INDEX = "NEXUS_INDEX";
    public static final String NEXUS_TYPE = "NEXUS_TYPE";
    public static final String SHIPPING_OPTIONS_AGENT_INDEX = "SHIPPING_OPTIONS_AGENT_INDEX";
    public static final String ENABLE_PROMO_CODE_ON_CART = "ENABLE_PROMO_CODE_ON_CART";
    public static final String ENABLE_TRADE_IN_FOR_AGENT = "ENABLE_TRADE_IN_FOR_AGENT";

    public static final String AGENT_MARKET_DETAILS = "AGENT_MARKET_DETAILS";
    public static final String AGENT_ZIPCODE_MARKET_INDEX = "AGENT_ZIPCODE_MARKET_INDEX";
    public static final String AGENT_ZIPCODE_MARKET_INDEX_TYPE = "AGENT_ZIPCODE_MARKET_INDEX_TYPE";

    //Adding CyberSource related Actors
    public static final String PROSPECT_GET_CYBERSOURCE_SIGNED_DATA_SERVICE_ACTOR = "getCybersourceSignedDataService";
    public static final String PROSPECT_GET_CYBERSOURCE_SIGNED_DATA_BUSINESS_ACTOR = "getCybersourceSignedDataBusinessActor";
    public static final String SERVICE_ACTOR_GET_CYBERSOURCE_SIGNED_DATA_SERVICE = "getCybersourceSignedDataService";
    public static final String SERVICE_ACTOR_UPDATE_CYBERSOURCE_PAYMENT = "updateCybersourcePaymentInfo";
    public static final String SERVICE_ACTOR_UPDATE_CYBERSOURCE_PAYMENT_BUSINESS = "updateCybersourcePaymentInfoBusiness";
    public static final String BUSINESS_ACTOR_AUTHORIZE_CYBERSOURCE_PAYMENT = "authorizeCybersourcePaymentBusinessActor";
    public static final String SERVICE_ACTOR_AUTHORIZE_CYBERSOURCE_PAYMENT_INTEGRATION_ACTOR = "authorizeCybersourcePaymentIntegrationActor";
    public static final String SERVICE_ACTOR_VIP_AUTHORIZE_CYBERSOURCE_PAYMENT_INTEGRATION_ACTOR = "vipAuthorizeCybersourcePaymentIntegrationActor";

    public static final String CHECKOUT_CYBERSOURCE_AUTHORIZATION_FAIL_ERROR_MESSAGE = "CHECKOUT_CYBERSOURCE_AUTHORIZATION_FAIL_ERROR_MESSAGE";
    public static final String SITE_ID = "siteId";
    public static final String GS4_COMPATIBLE_ANDROID_DACC = "GS4_COMPATIBLE_ANDROID_DACC";
    public static final String NSO_CLIENT_ORDER_TYPE = "SVCSLND";
    public static final String DPP_DEFAULT_TERM = "DPP_DEFAULT_TERM";
    public static final String EMAIL = "email";
    public static final String CUSTOMER ="customer";
    public static final String USER_ROLE = "userRole";
    public static final String PROSPECT ="prospect";
    public static final String FLOW_NAME = "flow_name";
    public static final String PREPAY_NSE ="prepay nse";
    public static final String  SHOP_PATH ="shopPath";
    public static final String  ELASTIC_ERROR_MESSAGE ="Elastic Exception occured for ";
    public static final String ELASTIC_EMPTY_RESPONSE_MSG ="Elastic Exception occured Empty response returned from  ";
    public static final String SEND_EMAIL_INDEX= "SEND_EMAIL_INDEX";
    public static final String ES_FAILURE = "ES_FAILURE";
    public static final String SEND_EMAIL_TYPE= "SEND_EMAIL_TYPE";
    //ORDERCONFIRMATIONAGENT Constants
    public static final String COMPLETE_ORDER_EMAIL_ACTOR ="orderConfirmationEmailDetails";
    public static final String COMPLETE_ORDER_SEND_EMAIL_ACTOR ="orderConfirmationSendEmail";
    public static final String AGENT_ORDER_CONFIRMATION_EMAIL_TEMPLATE_NAME= "AGENT_ORDER_CONFIRMATION_EMAIL_TEMPLATE_NAME";
    public static final String SEND_EMAIL_MAILBODY_PLACEHOLDER= "SEND_EMAIL_MAILBODY_PLACEHOLDER";
    public static final String CONFIRMATION_EMAIL_SMTP_AGENT_KILL_SWITCH = "CONFIRMATION_EMAIL_SMTP_AGENT_KILL_SWITCH";
    public static final String JAX_PLAN_IDS = "JAX_PLAN_IDS";

    public static final String VENDOR_ACCESSORIES_SKU = "vendorAccessoriesProduct";
    public static final String REDIS_CYBERSOURCE_PAYMENT_AUTHENTICATION_FAILURE_KEY = "REDIS_CYBERSOURCE_PAYMENT_AUTHENTICATION_FAILURE_KEY";
    
    public static final String SERVICE_ACTOR_SMART_IMEI_DEVICE_SEARCH = "smartIMEIDeviceSearch";
    public static final String SMART_IMEI_DEVICE_MODEL_NAME_TYPEAHEAD = "model_name_typeahead";
    public static final String SMART_IMEI_DEVICE_MAKE_TYPEAHEAD = "make_typeahead";
    public static final String SMART_IMEI_DEVICE_CATEGORY_TYPEAHEAD = "device_category_typeahead";
    public static final String SMART_IMEI_CARRIER = "carrier";
    public static final String SMART_IMEI_TYPEAHEADS_INDEX = "SMART_IMEI_TYPEAHEADS_INDEX";
    public static final String SMART_IMEI_TYPEAHEADS = "SMART_IMEI_TYPEAHEADS";
    public static final String SMART_IMEI_TYPEAHEADS_SIZE = "SMART_IMEI_TYPEAHEADS_SIZE";
    public static final String SMART_IMEI_BRANDS_TYPEAHEADS_SIZE = "SMART_IMEI_BRANDS_TYPEAHEADS_SIZE";
    public static final String SMART_IMEI_SUPPRESS_CARRIERS = "SMART_IMEI_SUPPRESS_CARRIERS";
    public static final String DID_YOU_MEAN = "did_you_mean";
    public static final String DID_YOU_MEAN_RESPONSE = "didYouMean";
    public static final String SMART_IMEI_TYPEAHEAD_MERGE_ENABLED = "SMART_IMEI_TYPEAHEAD_MERGE_ENABLED";
    public static final String SMART_IMEI_TYPEAHEAD_STOP_WORDS = "SMART_IMEI_TYPEAHEAD_STOP_WORDS";
    public static final String SMART_IMEI_BUSINESS_ACTOR_TIMEOUT = "smartIMEIBusinessActor_timeout";
    public static final String ERROR = "ERROR";

    public static final String AGENT_VENDOR_REPOSITORY_INDEX="AGENT_VENDOR_REPOSITORY_INDEX";
    public static final String AGENT_VENDOR_REPOSITORY_INDEX_TYPE="AGENT_VENDOR_REPOSITORY_INDEX_TYPE";
    public static final String AGENT_VENDOR_REPOSITORY_MAX_SEARCH_RESULTS="AGENT_VENDOR_REPOSITORY_MAX_SEARCH_RESULTS";
    public static final String AGENT_VENDOR_INVENTORY_HTML_TAGS_ENCODE_MAP = "AGENT_VENDOR_INVENTORY_HTML_TAGS_ENCODE_MAP";
    public static final String AGENT_VENDOR_ITEM_AVAILABILITY_INDEX = "AGENT_VENDOR_ITEM_AVAILABILITY_INDEX";
    public static final String AGENT_VENDOR_ITEM_AVAILABILITY_INDEX_TYPE ="AGENT_VENDOR_ITEM_AVAILABILITY_INDEX_TYPE";


    //agentsavecartemail constants
    public static final String AGENT_SAVED_CART_EMAIL_DEVICES_IN_CART_LABEL= "AGENT_SAVED_CART_EMAIL_DEVICES_IN_CART_LABEL";
    public static final String AGENT_SAVED_CART_EMAIL_DEVICE_IN_CART_LABEL= "AGENT_SAVED_CART_EMAIL_DEVICE_IN_CART_LABEL";
    public static final String HOST_URL_AGENT_SITE= "HOST_URL_AGENT_SITE";
    public static final String ACTION_URL_GET_CART= "ACTION_URL_GET_CART";
    public static final String SLASH = "/";
    public static final String AGENT_SITE_ID_SITE_NAME_MAP = "AGENT_SITE_ID_SITE_NAME_MAP";
    public static final String AGENT_SAVED_CART_EMAIL_TEMPLATE_NAME= "AGENT_SAVED_CART_EMAIL_TEMPLATE_NAME";
    public static final String AGENT_SAVED_CART_SMTP_KILL_SWITCH= "AGENT_SAVED_CART_SMTP_KILL_SWITCH";
    public static final String SAVE_CART_EMAIL_FOOTER= "SAVE_CART_EMAIL_FOOTER";
    public static final String AGENT_EMAIL_NSE_DEVICE_LABEL= "AGENT_EMAIL_NSE_DEVICE_LABEL";

    public static final String INLINE_ACCESSORIES = "INLINE_ACCESSORIES";

    public static final String CREATE_ATG_ORDER_API_INTEGRATION_SERVICE_URL = "/com/vzw/services/cart/CreateCartActor/createOrder";
    public static final String ATG_REST_CONTEXT_PATH ="/rest/model";
    public static final String VENDOR_SHIPPING_GROUP_TYPE = "vendorHardgoodShippingGroup";
    public static final String KAFKA_SUBMIT_ORDER_AGENT_TOPIC = "KAFKA_SUBMIT_ORDER_AGENT_TOPIC";
    public static final String KAFKA_SUBMIT_ORDER_AGENT_TOPIC_GROUP = "KAFKA_SUBMIT_ORDER_AGENT_TOPIC_GROUP";
    public static final String SERVICE_ACTOR_AGENT_SUBMIT_ORDER_PROCESSOR = "orderProcessor";
    public static final String CREATE_ATG_ORDER_API_INTEGRATION_KILL_SWITCH = "CREATE_ATG_ORDER_API_INTEGRATION_KILL_SWITCH";
    public static final String ECPDPROFILE_ID = "ecpdProfileId";
    public static final String VENDOR_ACCESSORIES_PRODUCT = "VENDOR_ACCESSORIES_PRODUCT";
    public static final String AGENT_ACTIVE_PROMO_STATUS_LIST = "AGENT_ACTIVE_PROMO_STATUS_LIST";

    //Pixel Constants
    public static final String GLOBAL_PIXEL_COMMOM_KEY="GLOBAL_PIXEL";
    public static final String PAGE_PIXEL_COMMOM_KEY="PAGE_PIXEL";
    public static final String PIXEL_HEAER="HEADER";
    public static final String PIXEL_FOOTER="FOOTER";
    public static final String PIXEL_BODY="BODY";
    public static final String ENABLE_PIXEL_TAGGING_AGENT_KILL_SWITCH ="ENABLE_PIXEL_TAGGING_AGENT_KILL_SWITCH";
    public static final String ENABLE_MULTIPLE_DOMAIN_KILL_SWITCH ="ENABLE_MULTIPLE_DOMAIN_KILL_SWITCH";
    public static final String CQ_INDEX = "CQ_INDEX";
    public static final String CQ_HTML_TYPE = "CQ_HTML_TYPE";
    public static final String CQ_ERROR_TYPE = "CQ_ERROR_TYPE";
    public static final String CQ_LABEL_TYPE = "CQ_LABEL_TYPE";

    public static final String CQ_INDEX_NEW = "CQ_INDEX_NEW";
    public static final String CQ_ERROR_TYPE_NEW = "CQ_ERROR_TYPE_NEW";
    public static final String CQ_LABEL_TYPE_NEW = "CQ_LABEL_TYPE_NEW";

    public static final String ENABLE_DECISION_MANAGER = "ENABLE_DECISION_MANAGER";
    public static final String DEFAULT_SMART_LOCATOR_PRODUCT_ID = "dev10560041,dev11160061";
    public static final String VERIZON_SMART_LOCATOR_PRODUCT_ID = "VERIZON_SMART_LOCATOR_PRODUCT_ID";
    public static final String DEFAULT_APPLICATION_NAME = "ufstore";

    public static final String DECISION_MANAGER_ORG_ID = "DECISION_MANAGER_ORG_ID";
    public static final String WHITE_LISTED_MTNS_KEY = "whiteListedMtns";
    public static final String GW_RESTRICTION_RULES = "UF_gw_a2c_restriction_rules";
    public static final String PDP_RESTRICTION_RULES = "UF_pdp_a2c_rsestriction_rules";
    public static final String UF_NSE_VERIZON_SMART_LOCATOR_ENABLED = "UF_nse_smart_locator_a2c_enabled";
    public static final String UF_AAL_VERIZON_SMART_LOCATOR_ENABLED = "UF_aal_smart_locator_a2c_enabled";
    public static final String PLANS_5G_TO_4G_MAP = "PLANS_5G_TO_4G_MAP";
    public static final String EPS_3D_SECURE_TRANSACTION_MODE_MFAPP = "P";
    public static final String EPS_3D_SECURE_PRODUCT_CODE_GENERAL_RETAIL = "GEN";

    public static final String INVENTORY_STATUS_FROM_REDIS_IN_STOCK = "S";
    public static final String INVENTORY_STATUS_FROM_REDIS_PREORDER = "P";
    public static final String INVENTORY_STATUS_FROM_REDIS_BACKORDER = "B";
    public static final String INVENTORY_SKU_INV_EXPSHIPDATE_FROM_REDIS = "SKU_INV_EXPSHIPDATE";
    public static final String AVAILABILITY_STATUS_IN_STOCK_DESC = "The item is available in stock";
    public static final String AVAILABILITY_STATUS_OUT_OF_STOCK_DESC = "The item is out of stock";
    public static final String AVAILABILITY_STATUS_PREORDERABLE_DESC = "The item can be pre ordered";
    public static final String AVAILABILITY_STATUS_BACKORDERABLE_DESC = "The item can be ordered but it will be available on future date";
    
    public static final String SERVICE_ACTOR_BYOD_SMART_IMEI_DEVICE = "smartImeiDeviceServiceActor";
    public static final String BUSINESS_ACTOR_BYOD_SMART_IMEI_DEVICE = "smartImeiDeviceBusinessActor";
    public static final String SMART_IMEI_BYOD_DEVICES_INDEX = "SMART_IMEI_BYOD_DEVICES_INDEX";
    public static final String SMART_IMEI_BYOD_DEVICES_TYPE = "SMART_IMEI_BYOD_DEVICES_TYPE";
    public static final String SMART_IMEI_DUAL_SIM_BLOCKED_DEVICE_PROD_IDS = "SMART_IMEI_DUAL_SIM_BLOCKED_DEVICE_PROD_IDS";
    public static final String SMART_IMEI_FLOW = "smartIMEIFlow";

    public static final int DEVICE_AVAILABILITY_STATUS_OUT_OF_STOCK = 1001;
    public static final int DEVICE_AVAILABILITY_STATUS_IN_STOCK = 1000;
    public static final int DEVICE_AVAILABILITY_STATUS_PREORDERABLE = 1002;
    public static final int DEVICE_AVAILABILITY_STATUS_BACKORDERABLE = 1003;
    public static final String INVENTORY_SKU_INVTYPE_FROM_REDIS = "SKU_INVTYPE_";
    public static final String INVENTORY_STATUS_FROM_REDIS_OUT_OF_STOCK = "O";

    // Adding Kill Switch to Enable/Disable Cybersource Full AUTH
    public static final String ENABLE_CYBERSOURCE_AUTH_TRANSACTION = "ENABLE_CYBERSOURCE_AUTH_TRANSACTION";

    public static final String DECLINE_DEVICE_PROTECTION = "Decline Device Protection";

    public static final String ISPU_ENFORCE_API_BUSS_ACTOR_MILLIS_TIMEOUT =  "ISPU_ENFORCE_API_BUSS_ACTOR_MILLIS";
    public static final String ISPU_PMT_FRAUD_LOW_RISK="Low Risk";
    public static final String ISPU_PMT_FRAUD_MODERATE_RISK="Moderate Risk";
    public static final String ISPU_PMT_FRAUD_HIGH_RISK="High Risk";
	
	public static final String SUBMIT_PAYMENT_INTEGRATION_ACTOR = "submitPaymentIntegrationActor";
    public static final String SUBMIT_PAYMENT_BUSINESS_ACTOR = "submitPaymentBusinessActor";
	public static final String CHARGE_PAYMENT_INTEGRATION_ACTOR = "chargePaymentIntegrationActor";
    public static final String CHARGE_PAYMENT_BUSINESS_ACTOR = "chargePaymentBusinessActor";
    public static final String CHARGE_PAYMENT_SERVICE_ACTOR = "chargePaymentServiceActor";

    public static final String GET_RESERVE_NPA_NXX_TIME_OUT = "GET_RESERVE_NPA_NXX_TIME_OUT";
    public static final String GET_RELEASE_NPA_NXX_TIME_OUT = "GET_RELEASE_NPA_NXX_TIME_OUT";

	public static final String ISPU_ENFORCE_PMT_ERROR_MSG="ISPU_ENFORCE_PMT_ERROR_MSG";

    public static final String SOFT_CREDIT_CHECK_DAILY_PREQUALIFY_LIMIT = "SOFT_CREDIT_CHECK_DAILY_PREQUALIFY_LIMIT";
    public static final String SOFT_CREDIT_CHECK_DAILY_ACCESS_COUNTER = "softCreditCounter";
    public static final String PREQUALIFY_TIME_WINDOW = "PREQUALIFY_TIME_WINDOW";
    public static final String PREQUALIFY_TIME_ZONE = "PREQUALIFY_TIME_ZONE";
    public static final String SOFT_CREDIT_PDP_FLOW = "PDP";
    public static final String SOFT_CREDIT_CART_FLOW = "CART";
    public static final String MONTHLY_LOAN_TERM = "24";
    public static final String DEFAULT_START_TIME = "07:00:00 AM";
    public static final String DEFAULT_END_TIME = "06:59:59 PM";
    public static final String DEFAULT_TIME_ZONE = "PST";
    public static final String PREQUAL_TIME_WINDOW_FORMAT = "hh:mm:ss a";
    public static final String DEFAULT_TIME_ZONE_LOCATION = "America/New_York";
    public static final int DAILY_PREQUAL_LIMIT_FALLBACK = 500;
    public static final String SOFT_CREDIT_PROCESSED = "softCreditProcessed";
    public static final String SOFT_CREDIT_RAN_FROM = "softCreditRanFrom";
    public static final String SOFT_CREDIT_RAN_ALREADY = "softCreditRanAlready";
    public static final String DISPLAY_SOFT_CREDIT_CHECK_LINK = "DISPLAY_SOFT_CREDIT_CHECK_LINK";
    public static final String UF_REDIS_KEY_MONTHLY_CONTRACT_TERMS_SUPPORTED = "UF_monthly_supported_contract_terms";
    public static final String PREQUAL_TIME_WINDOW_ALLOWED = "PREQUAL_TIME_WINDOW_ALLOWED";
    public static final String UF_MONTHLY_LOAN_TERMS_SUPPORTED_FALL_BACK = "99";
    public static final String SOFT_CREDIT_SITES_ALLOWED_LIST = "soft_credit_sites_allowed_list";
    public static final String SOFT_CREDIT_CATEGORY_ALLOWED_LIST = "soft_credit_category_allowed_list";
    public static final String ELIGIBILITY = "eligibility";
    public static final String ELIGIBILITY_FAILURE_REASON = "eligibilityFailureReason";
    public static final String SOFT_CREDIT_THROTTLE_STRATEGY = "softCreditThrottleStrategy";
    public static final String SOFT_CREDIT_CHECK = "softCreditCheck";
    public static final String NUANCE_CHAT_CREDIT_CHECK = "nuanceChatCreditCheck";
    public static final String SOFT_CREDIT_THROTTLE_COUNT = "soft_credit_throttle_count";
    public static final String SOFT_CREDIT_THROTTLE_PERCENTAGE = "soft_credit_throttle_percentage";
    public static final String PARAM_1 =  "param1";
    public static final String PARAM_2 =  "param2";
    public static final String TRY_AGAIN = "Try again";
    public static final String SKIP_THIS = "Skip this";
    public static final String BUTTON_TEXT = "buttonText";
    public static final String LINK_TEXT = "linkText";
    public static final String ERRORS_STRING = "errors";
    public static final String ERROR_MSG = "errorMsg";
    public static final String ERROR_KEY = "errorKey";
    public static final String PLEASE_TRY_AGAIN = "Please try again.";
    public static final String PLEASE_TRY_AGAIN_MSG = "There is a temporary glitch right now, please try again later.";
    public static final String PREQUAL_TIME_WINDOW_NOT_ALLOWED = "PREQUAL_TIME_WINDOW_NOT_ALLOWED";
    public static final String SITE_ID_NOT_SUPPORTED = "SITE_ID_NOT_SUPPORTED";
    public static final String CATEGORY_NOT_SUPPORTED ="CATEGORY_NOT_SUPPORTED";
    public static final String DAILY_PREQUAL_LIMIT_CROSSED = "DAILY_PREQUAL_LIMIT_CROSSED";
    public static final String LOGGED_IN_USER = "LoggedInUser";
    public static final String WRONG_CONTRACT_TYPE_SELECTED = "WRONG_CONTRACT_TYPE_SELECTED";
    public static final String MAXIMUM_THROTTLE_ALLOWED = "softCreditThrottleStrategy=nuanceChatCreditCheck";
    public static final String DISPLAY_SOFT_CREDIT_LINK = "displaySoftCreditLink";
    public static final String SOFT_CREDIT_ELIGIBLE = "softCreditEligible";
    public static final String SOFT_CREDIT_ERROR_EXISTS = "softCreditErrorExists";
    public static final String SOFT_CREDIT_EDGE_PREFIX = "softCreditEdgePreFix";
    public static final String SOFT_CREDIT_EDGE_PREFIX_TEXT = "softCreditEdgePreFixText";
    public static final String SOFT_CREDIT_CHECK_DETAILS = "softCreditCheckDetails";
    public static final String SOFT_CREDIT_INFO = "softCreditInfo";
	public static final String RISKY_HEADER = "RISKY_HEADER";
    public static final String RISKY_REQUEST = "riskyrequest";
    public static final String PAGE_DATA = "pageData";
    public static final String PAY_LOAD = "payload";
    public static final String STATUS_200 = "200";
    public static final String STATUS_500 = "500";
    public static final String FIVEG_HOME_FCL_OW_ENABLED = "FIVEG_HOME_FCL_OW_ENABLED";
    public static final String FIVEG_ORDER_TYPE_FCL = "FCL";
    public static final String FIVEG_ORDER_TYPE_ICL = "ICL";
    public static final String INSTALLATION_TYPE_SELF = "S";
    public static final String INSTALLATION_TYPE_PROFESSIONAL = "P";
    public static final String UF_ISPU_ACC_ENABLED = "UF_ISPU_ACC_ENABLED";
    public static final String STORE_LEVEL_ISPU_ACCESSORIES_INDEX = "STORE_LEVEL_ISPU_ACCESSORIES_INDEX";
    public static final String GW_FILTER_ISPU_SUPPORT_URLS = "GW_FILTER_ISPU_SUPPORT_URLS";
    public static final String GW_FILTER_ISPU_NON_SUPPORT_URLS = "GW_FILTER_ISPU_NON_SUPPORT_URLS";
    public static final String AC_GW_FILTER_ISPU_NON_SUPPORT_URLS = "AC_GW_FILTER_ISPU_NON_SUPPORT_URLS";
    public static final String DEFAULT_PAYMENT_ERROR_MSG="DEFAULT_PAYMENT_ERROR_MSG";


    public static final String SOFT_SKU = "softSku";

    public static final String ENABLE_BILLER_ID_CHANGES = "ENABLE_BILLER_ID_CHANGES";



    public static final String MF_HEADER_ORIGINATING_IP = "ORIGINATING_IP";
    public static final String EVOLV_PROXY_ENABLED="EVOLV_PROXY_ENABLED";
    public static final String EVOLV_PROSPECT_PROXY_HOST="EVOLV_PROSPECT_PROXY_HOST";
    public static final String EVOLV_PROSPECT_PROXY_PORT="EVOLV_PROSPECT_PROXY_PORT";
    public static final String EVOLV_ALLOCATIONS_API_URL="EVOLV_ALLOCATIONS_API_URL";
    public static final String EVOLV_TEST_OVERRIDE="EVOLV_TEST_OVERRIDE";
    public static final String EVOLV_ALLOCATIONS_CONFIRMATION_API_URL="EVOLV_ALLOCATIONS_CONFIRMATION_API_URL";
    public static final String EVOLV_ALLOCATIONS_EVENTS_API_URL="EVOLV_ALLOCATIONS_EVENTS_API_URL";
    public static final String CONFIRAMATION_TYPE="confirmation";
    public static final String CONVERSION_TYPE="conversion";
    public  static  final String SMART_IMEI_EMPTY_CARRIER_ALT_NAME="SMART_IMEI_EMPTY_CARRIER_ALT_NAME";
    public static final String EMPTY_CARRIER_DEVICES_FOR_SMART_IMEI_ENABLED = "EMPTY_CARRIER_DEVICES_FOR_SMART_IMEI_ENABLED";
    public static final String EVOLV_REQUEST_TIMEOUT="EVOLV_REQUEST_TIMEOUT";



    public static final String FIXED_COVERAGE_LEAD_REQUEST_TIMEOUT="FIXED_COVERAGE_LEAD_REQUEST_TIMEOUT";
    public static final String SWITCHER_SHARED_CART_API_ENABLED="SWITCHER_SHARED_CART_API_ENABLED";
    public static final String INSTALLATION_REQUEST_TYPE_SELF = "self";
     public static final String PRICE_DEVICES_COMPOSITE_INDEX = "PRICE_DEVICES_COMPOSITE_INDEX";
    public static final String PRICE_DEVICES_COMPOSITE_INDEX_TYPE = "PRICE_DEVICES_COMPOSITE_INDEX_TYPE";
    public static final String MONTHLY_LOAN_TERM_36 = "36";

    public static final String EXPRESS_STORE_ISPU_ACCESSORIES_INDEX = "EXPRESS_STORE_ISPU_ACCESSORIES_INDEX";
    public static final String EXPRESS_STORE_ISPU_DEVICE_INDEX = "EXPRESS_STORE_ISPU_DEVICE_INDEX";
    public static final String TABLETS_CATEGORY = "tablets";
    public static final String ES_CLUSTER_NODES_MF = "ES_CLUSTER_NODES_MF";


    public static final String CONNECTED_DEVICES_CATEGORY = "connected-devices";
    public static final String BASIC_PHONES_CATEGORY = "basic-phones";
    public static final String VENDORID_EXP_STORE = "VZWCOM-EXPRESS-STORE";
    public static final String FCL_INSTALLATION_TYPE_PROFESSIONAL = "professional";
    public static final String EXPRESS_STORE_DEVICES_ISPU_ENABLED = "EXPRESS_STORE_DEVICES_ISPU_ENABLED";
    public static final String EXPRESS_STORE_ACC_ISPU_ENABLED = "EXPRESS_STORE_ACC_ISPU_ENABLED";
	public static final String EVENT_CORRELATION_ID = "eventCorrelationId";
	public static final Integer INT_NINETY_NINE = 99;

    public static final String STORE_LEVEL_ISPU_ACCESSORIES_SIZE = "STORE_LEVEL_ISPU_ACCESSORIES_SIZE";
    public static final String REDIS_CLUSTER_SSL = "akka.redis.config.sslEnabled";
    public static final String APP_ON_CLOUD_FLAG = "akka.config.oncloud";
    public static final String SOI_PROXY_ENABLED="SOI_PROXY_ENABLED";
    public static final String SOI_PROSPECT_PROXY_HOST="SOI_PROSPECT_PROXY_HOST";
    public static final String SOI_PROSPECT_PROXY_PORT="SOI_PROSPECT_PROXY_PORT";
    public static final String SOI_REQUEST_TIMEOUT ="SOI_REQUEST_TIMEOUT";

    public static final String SOI_AGGREGATES_API_RETRY_COUNTS="SOI_AGGREGATES_API_RETRY_COUNTS";
    public static final String SOI_ACCESS_TOKEN="SOI_ACCESS_TOKEN";
    public static final String SOI_PMT_AUTH_KEY= "pmt-auth-key";
    public static final String SOI_AGGREGATES_PLANS_INSIGHTS_NAME_VALUE="SOI_AGGREGATES_PLANS_INSIGHTS_NAME_VALUE";
    public static final String SOI_KSW_PLANS_PAGE_DISP= "SOI_KSW_PLANS_PAGE_DISP";

    public static final String SOI_CLEAR_ACCESS_TOKEN_LABEL="SOI_CLEAR_ACCESS_TOKEN_LABEL";
    public static final String SOI_AGGREGATES_SERVICE_NAME_VALUE="SOI_AGGREGATES_SERVICE_NAME_VALUE";
    public static final String SOI_PDM_SERVICE_SOURCE = "SOI_PDM_SERVICE_SOURCE";
    public static final String SOI_AGGREGATES_INSIGHTS_NAME_VALUE = "SOI_AGGREGATES_INSIGHTS_NAME_VALUE";
    public static final String SOI_AGGREGATES_RT_INSIGHTS_NAME_VALUE ="SOI_AGGREGATES_RT_INSIGHTS_NAME_VALUE";
    public static final String SOI_AGGREGATES_CHANNEL_VALUE = "SOI_AGGREGATES_CHANNEL_VALUE";
    public static final String SOI_KSW_TOKEN_API="SOI_KSW_TOKEN_API";

    public static final String CLUSTER_NAME="akka.cluster-name";


    public static final String ORDER_NUMBER = "orderNumber";
    public static final String LOCATIONCODE = "locationCode";
    public static final String REFUND_TAX_TIME_STAMP = "refundTaxTimeStamp";
    public static final String RETRIEVE_ITEM_TAX_WITH_DISCOUNT_INTEGRATION_ACTOR = "retrieveItemTaxWithDiscountIntegrationActor";
    public static final String RETRIEVE_ITEM_TAX_WITH_DISCOUNT_SERVICE_ACTOR = "retrieveItemTaxWithDiscountServiceActor";

    public static final String ISPU_STORES_ORDER_FLAG = "ISPU_STORES_ORDER_FLAG";

    public static final String RETRIEVE_5G_SHAREDCART_BUSS_MILLIS_TIMEOUT = "RETRIEVE_5G_SHAREDCART_BUSS_MILLIS_TIMEOUT";
    public static final String PORTIN_ORDER = "PORTIN_ORDER";
    public static final String PDP_SELECTED_DEVICE_SOR_ID = "PDP_SELECTED_DEVICE_SOR_ID";

    public static final String EXPRESS_STORE_DATE_FORMAT_CART = "MMM";
    public static final String EXPRESS_STORE_DATE_FORMAT_CONFIRMATION = "MM/dd/yy";
    public static final String EXPRESS_STORE_SHIP_BY_TXT = "EXPRESS_STORE_SHIP_BY_TXT";
    public static final String EXPRESS_STORE_DELIVER_BY_TXT = "EXPRESS_STORE_DELIVER_BY_TXT";

    public static final String EXPRESS_STORE_MULTI_BO_CART_TXT = "EXPRESS_STORE_MULTI_BO_CART_TXT";
    public static final String EXPRESS_STORE_MULTI_PO_CART_TXT = "EXPRESS_STORE_MULTI_PO_CART_TXT";
    public static final String EXPRESS_STORE_BO_CART_TXT = "EXPRESS_STORE_BO_CART_TXT";
    public static final String EXPRESS_STORE_PO_CART_TXT = "EXPRESS_STORE_PO_CART_TXT";
    public static final String EXPRESS_STORE_SINGLE_BO_CONFIRM_TXT = "EXPRESS_STORE_SINGLE_BO_CONFIRM_TXT";
    public static final String EXPRESS_STORE_SINGLE_PO_CONFIRM_TXT = "EXPRESS_STORE_SINGLE_PO_CONFIRM_TXT";
    public static final String EXPRESS_STORE_MULTI_BO_CONFIRM_TXT = "EXPRESS_STORE_MULTI_BO_CONFIRM_TXT";
    public static final String EXPRESS_STORE_MULTI_PO_CONFIRM_TXT = "EXPRESS_STORE_MULTI_PO_CONFIRM_TXT";
    public static final String EXPRESS_STORE_MULTI_BO_SAME_SHIP_DATE_CONFIRM_TXT = "EXPRESS_STORE_MULTI_BO_SAME_SHIP_DATE_CONFIRM_TXT";
    public static final String EXPRESS_STORE_MULTI_PO_SAME_SHIP_DATE_CONFIRM_TXT = "EXPRESS_STORE_MULTI_PO_SAME_SHIP_DATE_CONFIRM_TXT";
    public static final String EXPRESS_STORE_CART_SHIPPING_DATE_FORMAT = "#MMM D#";
    public static final String EXPRESS_STORE_CONFIRMATION_SHIPPING_DATE_FORMAT = "#MM/DD/YYYY#";
    public static final String LOG_BUILD_INFO_ENABLED="logBuildInfoEnabled";
    public static final String JAR_EXTENSION=".jar";
    public static final String EXPRESS_STORE_ISPU_ACCESSORY_INDEX = "EXPRESS_STORE_ISPU_ACCESSORY_INDEX";
    public static final String EXPRESS_STORE_ISPU_DEVICE_TYPE = "EXPRESS_STORE_ISPU_DEVICE_TYPE";
    public static final String EXPRESS_STORE_ISPU_ACCESSORY_TYPE = "EXPRESS_STORE_ISPU_ACCESSORY_TYPE";
    public static final String SUBMIT_ALL_CONTRACT_RECEIPT_MILLIS_TIMEOUT = "SUBMIT_ALL_CONTRACT_RECEIPT_MILLIS_TIMEOUT";

    public static final String UF_COUNT_DOWN_REDIS_INFO_ENABLED_DEVICE_IDS = "UF_COUNT_DOWN_REDIS_INFO_ENABLED_DEVICE_IDS";
    public static final String UF_COUNT_DOWN_REDIS_INFO_ENABLED = "UF_COUNT_DOWN_REDIS_INFO_ENABLED";
    public static final String UF_COUNT_DOWN_TIMER_TEXT = "UF_COUNT_DOWN_TIMER_TEXT";
    public static final String UF_COUNT_DOWN_TEXT = "UF_COUNT_DOWN_TEXT";
    public static final String UF_COUNT_DOWN_TIMER_TEXT_FROM_REDIS = "countDownTimerTextFromRedis";
    public static final String UF_COUNT_DOWN_TEXT_FROM_REDIS = "countDownTextFromRedis";

    public static final String UF_START_DATE_REDIS_INFO_ENABLED_DEVICE_IDS = "UF_START_DATE_REDIS_INFO_ENABLED_DEVICE_IDS";
    public static final String UF_START_DATE_FROM_REDIS = "UF_START_DATE_FROM_REDIS";
    public static final String UF_PDP_TIMER_FORMAT = "UF_PDP_TIMER_FORMAT";

    public static final String STREAMING_EXTENDER_YTTV_MAP = "5G_STREAMING_EXTENDER_YTTV_MAP";
    public static final String TWENTY_FOUR_MONTH_PAYMENTS = "24 Monthly payments";
    public static final String RETAIL_PRICE = "Retail price";
    public static final String SOR_DISPLAY_NAME = "sor_display_name";
    public static final String META_TILE = "meta_title";
    public static final String SHOW_CASE_FLAG="showcase_flag";
	public static final String AUTOPAY_TOOLTIP_MESSAGE = "AUTOPAY_TOOLTIP_MESSAGE";
    public static final String AUTOPAY_TOOLTIP_OVERLAY_MESSAGE = "AUTOPAY_TOOLTIP_OVERLAY_MESSAGE";
    public static final String PLAN_SOR_IDS_TOOLTIP = "PLAN_SOR_IDS_TOOLTIP";
	public static final String AMAZON_OFFER_PLAN_CATEGORY_CODES = "AMAZON_OFFER_PLAN_CATEGORY_CODES";
    public static final String AMAZON_OFFER_ENABLED = "AMAZON_OFFER_ENABLED";
    public static final String AMAZON_OFFER_START_DATE = "AMAZON_OFFER_START_DATE";
    public static final String AMAZON_OFFER_END_DATE = "AMAZON_OFFER_END_DATE";
    public static final String AMAZON_OFFER_TIME_ZONE = "AMAZON_OFFER_TIME_ZONE";

    public static final String SHOW_AVAILABLE_STORES_ISPU_FLAG = "SHOW_AVAILABLE_STORES_ISPU_FLAG";
    public static final String SHOW_AVAILABLE_STORES_ISPU = "SHOW_AVAILABLE_STORES_ISPU";
    public static final String FIOS_PROXY_HOST = "FIOS_PROXY_HOST";
    public static final String FIOS_PROXY_PORT = "FIOS_PROXY_PORT";
    public static final String FIOS_PROXY_ENABLED = "FIOS_PROXY_ENABLED";
    public static final String FIOS_REQUEST_TIMEOUT = "FIOS_REQUEST_TIMEOUT";
    public static final String BRAND_SEO_MANUFACTURER_NAME = "manufacturer.seo_url_name";

    public static final String ORIGIN_5G_SWITCHER = "ONEDIGITAL-5G";
    public static final String PROSPECT_CART_COOKIE_CONFIG_NAME= "PROSPECT_CART_AVAILABLE_COOKIENAME";
    public static final String PROSPECT_CART_COOKIE_NAME = "prospectCartAvailable";
    public static final String PROSPECT_CART_COOKIE_VALUE = "TRUE";
    public static final String PROSPECT_SWITCHER_COMBO_ORDER_KEY = "PROSPECT_SWITCHER_COMBO_ORDER_ENABLED";
    public static final String BYOD_NO_CREDIT_CHECK_COOKIES_NAME ="BYOD_NO_CREDIT_CHECK_COOKIES_NAME";
    public static final String BYOD_NO_CREDIT_CHECK_ENABLE ="BYOD_NO_CREDIT_CHECK_ENABLE";
    public static final String PROSPECT_ELIGIBLE_FLOWS_FOR_NCC ="PROSPECT_ELIGIBLE_FLOWS_FOR_NCC";

    public static final String M_H_API_PROPS="m_h_api_props";
    public static final String RTI_ISPU_MODAL_CQ_KEYS = "RTI_ISPU_MODAL_CQ_KEYS";
    public static final String TITLE = "title";
    public static final String CONTENT = "content";
    public static final String PRIMARY_LABEL = "primaryLabel";
    public static final String PRIMARY_BUTTON_URL = "primaryButtonURL";
    public static final String SECONDARY_LABEL = "secondaryLabel";
    public static final String SECONDARY_BUTTON_URL = "secondaryButtonURL";
    public static final String MESSAGE_RTI_CQ = "message";
    public static final String RTI_ISPU_DFILL_FAILURE_CQ_KEYS = "RTI_ISPU_DFILL_FAILURE_CQ_KEYS";
    public static final String RTI_ISPU_FAILURE_CQ_KEYS = "RTI_ISPU_FAILURE_CQ_KEYS";
    public static final String RTI_DFILL_FAILURE_CQ_KEYS = "RTI_DFILL_FAILURE_CQ_KEYS";
    public static final String VERIZON_UP_GW_ACTOR = "verizonUpGwActor";
    public static final String SUB_ORDER_TYPE_HOME= "HOME";
    public static final String SUB_ORDER_TYPE_MOBILITY= "MOBILITY";

    public static final String IS_AEM_CIRCUIT_BREAKER_ENABLED = "IS_AEM_CIRCUIT_BREAKER_ENABLED";
    public static final String RTI_ISPU = "ISPU";
    public static final String RTI_DFILL = "DFILL";
    public static final String RTI_FAILURE_STATUS_CODE = "15";


    public static final String DACC_RA_GRP_CD_CHECK_ENABLED_FOR_CF ="DACC_RA_GRP_CD_CHECK_ENABLED_FOR_CF";
    public static final String VZPRO = "VZPRO";

    public static final String ISPU_FLOW_LOGGER_ENABLED = "ISPU_FLOW_LOGGER_ENABLED";
    public static final String RTI_RETRY_COUNT = "rtiRetryCount";
    public static final String VZPH_SL_REMOVAL_ALERT_MSG="VZPH_SL_REMOVAL_ALERT_MSG";
    public static final String VZPH_MD_REMOVAL_ALERT_MSG="VZPH_MD_REMOVAL_ALERT_MSG";
    public static final String VZPH_OVERLAY_TITLE_LABEL="title";
    public static final String VZPH_OVERLAY_DETAILS_LABEL="details";
    public static final String VZPH_OVERLAY_BUTTON_LABEL="buttonLabel";


    public static final String VZPH_SL_CREDIT_FEATURE_ID="VZPH_SL_CREDIT_FEATURE_ID";
    public static final String VZPH_MD_CREDIT_FEATURE_ID="VZPH_MD_CREDIT_FEATURE_ID";
    public static final String CREDIT_AMOUNT_MD_DOLLAR="$CREDIT_AMOUNT_MD$";
    public static final String CREDIT_AMOUNT_SL_DOLLAR="$CREDIT_AMOUNT_SL$";

    public static final String PROSPECT_VZP_HOME_CQ_CONTENT_WEB="PROSPECT_VZP_HOME_CQ_CONTENT_WEB";
    public static final String VZPH_SL_OVERLAY_TITLE="VZPH_SL_OVERLAY_TITLE";
    public static final String VZPH_SL_OVERLAY_DETAILS="VZPH_SL_OVERLAY_DETAILS";
    public static final String VZPH_MD_OVERLAY_TITLE="VZPH_MD_OVERLAY_TITLE";
    public static final String VZPH_MD_OVERLAY_DETAILS="VZPH_MD_OVERLAY_DETAILS";
    public static final String VZPH_OVERLAY_BUTTON_LABEL_TEXT="VZPH_OVERLAY_BUTTON_LABEL_TEXT";
    public static final String VZPH_SL_PROMO_MSG="VZPH_SL_PROMO_MSG";
    public static final String VZPH_MD_PROMO_MSG="VZPH_MD_PROMO_MSG";
    public static final String ENABLE_VZPHOME_MSGS="ENABLE_VZPHOME_MSGS";
    public static final String VZ_PROTECT_SOR_IDS = "VZ_PROTECT_SOR_IDS";
    public static final String VZ_PROTECT_MD_SOR_IDS = "VZ_PROTECT_MD_SOR_IDS";
    public static final String HASH_ACCT_NUM = "hashAcctNum";
    public static final String HASH_LOGIN_MDN = "hashLoginMdn";

    public static final String VZW_PREPAY_AKKA_LOG_INDEX = "ecom_prospect_akkalog";
    public static final String VZW_GIFT_CARD_MAX_AMOUNT_KEY = "giftCardMaxAmount";
    public static final String VZW_GIFT_CARD_MAX_AMOUNT_PREPAY_FLOW = "1000";
    public static final String VZW_GIFT_CARD_MAX_AMOUNT_PROSPECT_FLOW = "1000";

    public static final String X_API_KEY = "x-api-key";

    public static final String FALSE = "false";
    public static final String CIRCUIT_BREAKER_SDD_RTA_MAX_FAILURES = "CIRCUIT_BREAKER_SDD_RTA_MAX_FAILURES";
    public static final String CIRCUIT_BREAKER_SDD_RTA_CALL_TIMEOUT = "CIRCUIT_BREAKER_SDD_RTA_CALL_TIMEOUT";
    public static final String CIRCUIT_BREAKER_SDD_RTA_RESET_TIMEOUT = "CIRCUIT_BREAKER_SDD_RTA_RESET_TIMEOUT";
    public static final String SDD_RTA_CIRCUIT_BREAKER_ENABLED = "SDD_RTA_CIRCUIT_BREAKER_ENABLED";
    public static final String SDD_RTA_CHECK_ENABLED = "SDD_RTA_CHECK_ENABLED";
    public static final String SDD_RTA_INTEGRATION_ACTOR = "sddRTAIntegrationActor";

    public static final String EXPRESS_STORE = "ExpressStore";
    public static final String LOGISTYX_API_URL_ENABLED = "LOGISTYX_API_URL_ENABLED";
    public static final String LOGISTYX_API_URL = "LOGISTYX_API_URL";

    public static final String VERIZON_DOT_COM = "verizon.com";
    public static final String VERIZON_WIRELESS_DOT_COM = "verizonwireless.com";
    public static final String CRADLE_USER_NAVIGATION = "CRADLE_USER_NAVIGATION";
    public static final String SOI_RECOMMENDATIONS_CHANNEL_ID = "SOI_RECOMMENDATIONS_CHANNEL_ID";
    public static final String SOI_RECOMMENDATIONS_DEVICES_INSIGHTS="SOI_RECOMMENDATIONS_DEVICES_INSIGHTS";
    public static final String SOI_RECOMMENDATIONS_CHANNEL_ID_NAME = "channelId";
    public static final String BUSINESS_ACTOR_INSPICIO_EMAIL = "inspicioEmailBusinessActor";
    public static final String INTEGRATION_ACTOR_INSPICIO_EMAIL = "inspicioEmailIntegrationActor";
    public static final String INSPICIO_CUSTOMER_SIGNATURE = "inspicio_customer_signature";

    public static final String SOI_RECOMMENDATIONS_INSIGHT_CATAGORY = "scores";
    public static final String SOI_PROTECTION_RECOMMENDATIONS_INSIGHT_CATEGORY = "rt_scores";
    public static final String SOI_PROTECTION_RECOMMENDATIONS_VISITOR_ID = "Prospect_API";
    public static final String SOI_RECOMMENDATIONS_INSIGHT_NAME = "rfi_score";
    public static final String SOI_RECOMMENDATIONS_API_KEY = "x-soe-apikey";
    public static final String SOI_RECOMMENDATIONS_API_VALUE = "uFWjzl4du5e46whYg73iCGqriX2l62C9";
    public static final String SOI_RECOMMENDATIONS_USECASE_ID = "UID_DEVICE_RCMD";
    public static final String SOI_RECOMMENDATIONS_CLIENT_ID = "vzw_mvo_services";
    public static final String SOI_RECOMMENDATIONS_SERVICE_NAME = "serviceName";

    public static final String LAUNCH_TYPE = "launchType";
    public static final String FOUR_GH_LAUNCH_TYPE = "4GH";
    public static final String LTE_EDGE_DUE_MONTHLY_TEXT = "See due monthly section for payment details.";

    public static final String IS_D2D_FIVE_HOME_FLOW = "isD2DFiveHomeFlow";
    public static final String D2D_AGENT_LOCATION_CODE = "d2dAgentLocationCode";
    public static final String D2D_AGENT_OUTLET_ID = "d2dAgentOutletID";

    public static final String PREPAY_MOBILE_HOTSPOT_PLAN_SOR_ID = "PREPAY_MOBILE_HOTSPOT_PLAN_SOR_ID";
    public static final String PREPAY_LOYALITY_DISABLE_PLAN_SOR_ID = "PREPAY_LOYALITY_DISABLE_PLAN_SOR_ID";
    public static final String PREPAY_MOBILE_HOTSPOT_FEATURE_SOR_ID = "PREPAY_MOBILE_HOTSPOT_FEATURE_SOR_ID";
    public static final String PREPAY_BYOD_CCINTRIAL_FLOW_ENABLE = "PREPAY_BYOD_CCINTRIAL_FLOW_ENABLE";
    public static final String PREPAY_BYOD_CC_ORDERSTATUS_ITERATIVE_COUNTER = "PREPAY_BYOD_CC_ORDERSTATUS_ITERATIVE_COUNTER";
    public static final String PREPAY_BYOD_CC_ORDERSTATUS_ITERATIVE_INTERVAL = "PREPAY_BYOD_CC_ORDERSTATUS_ITERATIVE_INTERVAL";
    public static final String PREPAY_NSE_NSO_ENABLE = "PREPAY_NSE_NSO_ENABLE";
    public static final String D2D_AGENT_ID = "d2dAgentID";

    public static final String CONFIRMATION_EMAIL_D2D_TIMEOUT = "CONFIRMATION_EMAIL_D2D";
    // OS and browser details
    public static final String UF_BROWSER_OS_DETAIL_HEADER_NAME = "browserOSDetail";
    public static final String UF_BROWSER_TYPE = "browserType";
    public static final String UF_OS_TYPE = "osType";

    public static final String D2D_EXPRESS_STORE_OUTLET_ID = "wirelessOutletId";
    public static final String D2D_EXPRESS_STORE_LOCATION_ID = "wirelessLocationId";
    public static final String CAMPAIGN_CODE = "campaignCode";
    public static final String SAVE_CART_EMAIL_PARAM = "scEmail";
    public static final String SAVE_CART_MTN_PARAM = "scMtn";
    public static final String ACTIVE_SAVE_CART_5G_ENABLED = "ACTIVE_SAVE_CART_5G_ENABLED";
    public static final String DISABLE_SAVE_CART_MTN = "DISABLE_SAVE_CART_MTN";

    public static final String MTN_NUMBERS_HEADER_NAME = "mtnNumbers";

    public static final String EXPRESS_STORE_TYPE= "Express Store";
    public static final String ENABLE_EXPRESS_STORE_D2D_JSON_ONE_MESSAGE = "ENABLE_EXPRESS_STORE_D2D_JSON_ONE_MESSAGE";
    public static final String FIVEG_HOME_REDESIGN_ENABLED = "HOME_REDESIGN_ENABLED";

    public static final String SUBMIT_MULTILINE_ACTIVATION_RESPONSE_KEY = "SubmitMultilineActivationResponse";
    public static final String CREATE_SAP_ORDER_RESPONSE_KEY = "SapCreateOrderResponse";
    public static final String PREPAY_5G_UWB_PLAN_SOR_ID = "PREPAY_5G_UWB_PLAN_SOR_ID";
    public static final String ISSAC_PEGA_CJCM_CLIENTID="ISSAC_PEGA_CJCM_CLIENTID";
    public static final String ISSAC_PEGA_RTD_CLIENTID_MF="ISSAC_PEGA_RTD_CLIENTID_MF";
    public static final String ISSAC_PEGA_RTD_CLIENTID_ES="ISSAC_PEGA_RTD_CLIENTID_ES";
    public static final String CJCM_CREATE_APPLICATION_API_URL = "pega_cjcm_create_api_url";
    public static final String SYNCHRONY_URL = "SYNCHRONY_URL";
    public static final String POST_BACK_URL = "POST_BACK_URL";
    public static final String LOCATION_CODE_ISSAC = "LC";
    public static final String CAMPAIGIN_MAIL_ISSAC = "CID";
    public static final String CC_LEARN_MORE_MODEL_CQ_CONTENT ="CC_LEARN_MORE_MODEL_CQ_CONTENT";
    public static final String OUTLET_ID_DEFAULT ="14569";
    public static final String ISSAC_PEGA_CJCM_CHANNEL_TYPE="ISSAC_PEGA_CJCM_CHANNEL_TYPE";
    public static final String DIGITAL_CHANNEL="DIGITAL_CHANNEL";
    public static final String ELIGIBLE_USER_ROLES_FOR_ACCOUNT_MANAGER_API_CALL = "ELIGIBLE_USER_ROLES_FOR_ACCOUNT_MANAGER_API_CALL";
    public static final String ACCOUNT_MANAGER_API_CALL = "ACCOUNT_MANAGER_API_CALL";
    public static final String CONTROLLER_REF = "ControllerRef";
    public static final String CREATE_APPLICATION_SERVICE_ACTOR = "createApplicationServiceActor";
    public static final String RTD_NPX_API_URL = "rtd_nbx_api_url";
    public static final String ISSAC_PEGA_RTD_CLIENTID = "ISSAC_PEGA_RTD_CLIENTID";
    public static final String NBX_ELIGIBLE_PREPOSITION_ID = "NBX_ELIGIBLE_PREPOSITION_ID";
    public static final String NBX_ENABLE_ISAAC = "NBX_ENABLE_ISAAC";
    public static final String NBX_SERVICE_ACTOR_TIMEOUT = "NBX_SERVICE_ACTOR";
    public static final String VZCARDAPPLY = "vzCardApply";
    public static final String NBX_ELIGIBLE_DIRECT_APPLY_PREPOSITION_ID = "NBX_ELIGIBLE_DIRECT_APPLY_PREPOSITION_ID";
    public static final String ISSAC_ENABLED_FOR_DOTCOM = "ISSAC_ENABLED_FOR_DOTCOM";
    public static final String ISSAC_APPLY_NOW_URL = "ISSAC_APPLY_NOW_URL";
    public static final String ISSAC_POST_BACK_URL = "ISSAC_POST_BACK_URL";
    public static final String ISSAC_AEM_CONTENT_URL = "ISSAC_AEM_CONTENT_URL";
    public static final String VERIZON_VISA_CARD = "verizonCreditCard";
    public static final String ISSAC_QUICK_SCREEN_CONTENT = "ISSAC_QUICK_SCREEN_CONTENT";
    public static final String ISSAC_QUICK_SCREEN_VARIATIONS_ENABLED = "ISSAC_QUICK_SCREEN_VARIATIONS_ENABLED";
    public static final String VERIZON_DOLLAR_REWARD_TYPE = "Verizon Dollars Recurring";
	
	public static final String VERIZON_DOLLAR_PERCENTAGE = "2";
    public static final String ERROR_MESSAGES_IN_ITEM_MISMATCH_SCENARIO ="ERROR_MESSAGES_IN_ITEM_MISMATCH_SCENARIO";
    public static final String EXPRESS_STORE_BAG_INDEX = "EXPRESS_STORE_BAG_INDEX";
    public static final String EXPRESS_STORE_BAG_TYPE = "EXPRESS_STORE_BAG_TYPE";
    public static final String ENABLE_BAG_FOR_EXPRESS_STORE = "ENABLE_BAG_FOR_EXPRESS_STORE";
    public static final String EXPRESS_STORE_SPECIFIC_CHANNEL_ID = "EXPRESS_STORE_SPECIFIC_CHANNEL_ID";

    public static final String D2D_EXPRESS_STORE = "d2dExpressStore";

    public static final String GET_SORID_FROM_FIRST_ELASTIC_HIT = "GET_SORID_FROM_FIRST_ELASTIC_HIT";
    public static final String FIVEG_MCU_OFFER_CODE = "5G_MCU_OFFER_CODE";
    public static final String MUC_OFFER_ELIGIBLE = "MUC_OFFER_ELIGIBLE";
    public static final String EXPRESS_STORE_LOCATION_STATE = "EXPRESS_STORE_LOCATION_STATE";


    public static final String BRTC_FLAG = "TheBuyersRightToCancel";
    public static final String D2D_FINAL_CREDIT_APPROVAL_STATUS = "D2D_FINAL_CREDIT_APPROVAL_STATUS";
    public static final String EXPRESS_STORE_D2D_CREDITREAD_CHECK= "EXPRESS_STORE_D2D_CREDITREAD_CHECK";
    public static final String CBAND_LAUNCH_TYPE = "CBAND";
    public static final String CBAND_FLOW_ENABLED = "isCbandFlowEnabled";
    public static final String FIVEG_PREORDER_EST_SHIP_DATE = "FIVEG_PREORDER_EST_SHIP_DATE";
    public static final String FIVEG_PREORDER_STR_DATE_FORMAT = "EEEE, MMM dd, yyyy";

}
