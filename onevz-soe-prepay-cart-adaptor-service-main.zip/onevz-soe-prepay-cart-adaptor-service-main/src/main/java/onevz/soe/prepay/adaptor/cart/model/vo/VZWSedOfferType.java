package onevz.soe.prepay.adaptor.cart.model.vo;

/**
 * This class is used to store details of VZWSedOffer
 * 
 * @author PA
 * 
 */
public class VZWSedOfferType {
	/**
	 * Property used to hold the mOfferId
	 * 
	 */
	private String mOfferId;
	/**
	 * Property used to hold the mOfferType
	 * 
	 */
	private String mOfferType;
	/**
	 * Property used to hold the mOfferName
	 * 
	 */
	private String mOfferName;
	/**
	 * Property used to hold the mOfferDesc
	 * 
	 */
	private String mOfferDesc;
	/**
	 * Property used to hold the mOfferAmount
	 * 
	 */
	private String mOfferAmount;
	/**
	 * Property used to hold the mRebateAllowedFlag
	 * 
	 */
	private String mRebateAllowedFlag;
	/**
	 * Property used to hold the mParentOfferId
	 * 
	 */
	private String mParentOfferId;
	/**
	 * Property used to hold the mParentOfferName
	 * 
	 */
	private String mParentOfferName;
	/**
	 * Property used to hold the mParentOfferDesc
	 * 
	 */
	private String mParentOfferDesc;
	/**
	 * Property used to hold the mBogoOrderLoc
	 * 
	 */
	private String mBogoOrderLoc;
	/**
	 * Property used to hold the mBogoOrderNum
	 * 
	 */
	private String mBogoOrderNum;
	/**
	 * Property used to hold the mBogoItemSeqNum
	 * 
	 */
	private String mBogoItemSeqNum;
	/**
	 * Property used to hold the mBagxSeqNum
	 * 
	 */
	private String mBagxSeqNum;
	/**
	 * Property used to hold the mBarcodeID
	 * 
	 */
	private String mBarcodeID;
	
	/**
	 * Property used to hold the mBundleSeqNum
	 * 
	 */
	private String mBundleSeqNum;

	/**
	 * This method is used to get the offerId
	 * 
	 * @return the offerId
	 */
	public String getOfferId() {
		return mOfferId;
	}

	/**
	 *This method is used to set the offerId
	 * 
	 * @param pOfferId
	 *            the offerId to set
	 */
	public void setOfferId(String pOfferId) {
		mOfferId = pOfferId;
	}

	/**
	 * This method is used to get the offerType
	 * 
	 * @return the offerType
	 */
	public String getOfferType() {
		return mOfferType;
	}

	/**
	 *This method is used to set the offerType
	 * 
	 * @param pOfferType
	 *            the offerType to set
	 */
	public void setOfferType(String pOfferType) {
		mOfferType = pOfferType;
	}

	/**
	 * This method is used to get the offerName
	 * 
	 * @return the offerName
	 */
	public String getOfferName() {
		return mOfferName;
	}

	/**
	 *This method is used to set the offerName
	 * 
	 * @param pOfferName
	 *            the offerName to set
	 */
	public void setOfferName(String pOfferName) {
		mOfferName = pOfferName;
	}

	/**
	 * This method is used to get the offerDesc
	 * 
	 * @return the offerDesc
	 */
	public String getOfferDesc() {
		return mOfferDesc;
	}

	/**
	 *This method is used to set the offerDesc
	 * 
	 * @param pOfferDesc
	 *            the offerDesc to set
	 */
	public void setOfferDesc(String pOfferDesc) {
		mOfferDesc = pOfferDesc;
	}

	/**
	 * This method is used to get the offerAmount
	 * 
	 * @return the offerAmount
	 */
	public String getOfferAmount() {
		return mOfferAmount;
	}

	/**
	 *This method is used to set the offerAmount
	 * 
	 * @param pOfferAmount
	 *            the offerAmount to set
	 */
	public void setOfferAmount(String pOfferAmount) {
		mOfferAmount = pOfferAmount;
	}

	/**
	 * This method is used to get the rebateAllowedFlag
	 * 
	 * @return the rebateAllowedFlag
	 */
	public String getRebateAllowedFlag() {
		return mRebateAllowedFlag;
	}

	/**
	 *This method is used to set the rebateAllowedFlag
	 * 
	 * @param pRebateAllowedFlag
	 *            the rebateAllowedFlag to set
	 */
	public void setRebateAllowedFlag(String pRebateAllowedFlag) {
		mRebateAllowedFlag = pRebateAllowedFlag;
	}

	/**
	 * This method is used to get the parentOfferId
	 * 
	 * @return the parentOfferId
	 */
	public String getParentOfferId() {
		return mParentOfferId;
	}

	/**
	 *This method is used to set the parentOfferId
	 * 
	 * @param pParentOfferId
	 *            the parentOfferId to set
	 */
	public void setParentOfferId(String pParentOfferId) {
		mParentOfferId = pParentOfferId;
	}

	/**
	 * This method is used to get the parentOfferName
	 * 
	 * @return the parentOfferName
	 */
	public String getParentOfferName() {
		return mParentOfferName;
	}

	/**
	 *This method is used to set the parentOfferName
	 * 
	 * @param pParentOfferName
	 *            the parentOfferName to set
	 */
	public void setParentOfferName(String pParentOfferName) {
		mParentOfferName = pParentOfferName;
	}

	/**
	 * This method is used to get the parentOfferDesc
	 * 
	 * @return the parentOfferDesc
	 */
	public String getParentOfferDesc() {
		return mParentOfferDesc;
	}

	/**
	 *This method is used to set the parentOfferDesc
	 * 
	 * @param pParentOfferDesc
	 *            the parentOfferDesc to set
	 */
	public void setParentOfferDesc(String pParentOfferDesc) {
		mParentOfferDesc = pParentOfferDesc;
	}

	/**
	 * This method is used to get the bogoOrderLoc
	 * 
	 * @return the bogoOrderLoc
	 */
	public String getBogoOrderLoc() {
		return mBogoOrderLoc;
	}

	/**
	 *This method is used to set the bogoOrderLoc
	 * 
	 * @param pBogoOrderLoc
	 *            the bogoOrderLoc to set
	 */
	public void setBogoOrderLoc(String pBogoOrderLoc) {
		mBogoOrderLoc = pBogoOrderLoc;
	}

	/**
	 * This method is used to get the bogoOrderNum
	 * 
	 * @return the bogoOrderNum
	 */
	public String getBogoOrderNum() {
		return mBogoOrderNum;
	}

	/**
	 *This method is used to set the bogoOrderNum
	 * 
	 * @param pBogoOrderNum
	 *            the bogoOrderNum to set
	 */
	public void setBogoOrderNum(String pBogoOrderNum) {
		mBogoOrderNum = pBogoOrderNum;
	}

	/**
	 * This method is used to get the bogoItemSeqNum
	 * 
	 * @return the bogoItemSeqNum
	 */
	public String getBogoItemSeqNum() {
		return mBogoItemSeqNum;
	}

	/**
	 *This method is used to set the bogoItemSeqNum
	 * 
	 * @param pBogoItemSeqNum
	 *            the bogoItemSeqNum to set
	 */
	public void setBogoItemSeqNum(String pBogoItemSeqNum) {
		mBogoItemSeqNum = pBogoItemSeqNum;
	}

	/**
	 * This method is used to get the bagxSeqNum
	 * 
	 * @return the bagxSeqNum
	 */
	public String getBagxSeqNum() {
		return mBagxSeqNum;
	}

	/**
	 *This method is used to set the bagxSeqNum
	 * 
	 * @param pBagxSeqNum
	 *            the bagxSeqNum to set
	 */
	public void setBagxSeqNum(String pBagxSeqNum) {
		mBagxSeqNum = pBagxSeqNum;
	}

	/**
	 * This method is used to get the barcodeID
	 * 
	 * @return the barcodeID
	 */
	public String getBarcodeID() {
		return mBarcodeID;
	}

	/**
	 *This method is used to set the barcodeID
	 * 
	 * @param pBarcodeID
	 *            the barcodeID to set
	 */
	public void setBarcodeID(String pBarcodeID) {
		mBarcodeID = pBarcodeID;
	}

	
	/**
	 * @return the bundleSeqNum
	 */
	public String getBundleSeqNum() {
		return mBundleSeqNum;
	}

	/**
	 * @param pBundleSeqNum the bundleSeqNum to set
	 */
	public void setBundleSeqNum(String pBundleSeqNum) {
		mBundleSeqNum = pBundleSeqNum;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((mBagxSeqNum == null) ? 0 : mBagxSeqNum.hashCode());
		result = prime * result
				+ ((mBarcodeID == null) ? 0 : mBarcodeID.hashCode());
		result = prime * result
				+ ((mBogoItemSeqNum == null) ? 0 : mBogoItemSeqNum.hashCode());
		result = prime * result
				+ ((mBogoOrderLoc == null) ? 0 : mBogoOrderLoc.hashCode());
		result = prime * result
				+ ((mBogoOrderNum == null) ? 0 : mBogoOrderNum.hashCode());
		result = prime * result
				+ ((mOfferAmount == null) ? 0 : mOfferAmount.hashCode());
		result = prime * result
				+ ((mOfferDesc == null) ? 0 : mOfferDesc.hashCode());
		result = prime * result
				+ ((mOfferId == null) ? 0 : mOfferId.hashCode());
		result = prime * result
				+ ((mOfferName == null) ? 0 : mOfferName.hashCode());
		result = prime * result
				+ ((mOfferType == null) ? 0 : mOfferType.hashCode());
		result = prime
				* result
				+ ((mParentOfferDesc == null) ? 0 : mParentOfferDesc.hashCode());
		result = prime * result
				+ ((mParentOfferId == null) ? 0 : mParentOfferId.hashCode());
		result = prime
				* result
				+ ((mParentOfferName == null) ? 0 : mParentOfferName.hashCode());
		result = prime
				* result
				+ ((mRebateAllowedFlag == null) ? 0 : mRebateAllowedFlag
						.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		VZWSedOfferType other = (VZWSedOfferType) obj;
		if (mBagxSeqNum == null) {
			if (other.mBagxSeqNum != null)
				return false;
		} else if (!mBagxSeqNum.equals(other.mBagxSeqNum))
			return false;
		if (mBarcodeID == null) {
			if (other.mBarcodeID != null)
				return false;
		} else if (!mBarcodeID.equals(other.mBarcodeID))
			return false;
		if (mBogoItemSeqNum == null) {
			if (other.mBogoItemSeqNum != null)
				return false;
		} else if (!mBogoItemSeqNum.equals(other.mBogoItemSeqNum))
			return false;
		if (mBogoOrderLoc == null) {
			if (other.mBogoOrderLoc != null)
				return false;
		} else if (!mBogoOrderLoc.equals(other.mBogoOrderLoc))
			return false;
		if (mBogoOrderNum == null) {
			if (other.mBogoOrderNum != null)
				return false;
		} else if (!mBogoOrderNum.equals(other.mBogoOrderNum))
			return false;
		if (mOfferAmount == null) {
			if (other.mOfferAmount != null)
				return false;
		} else if (!mOfferAmount.equals(other.mOfferAmount))
			return false;
		if (mOfferDesc == null) {
			if (other.mOfferDesc != null)
				return false;
		} else if (!mOfferDesc.equals(other.mOfferDesc))
			return false;
		if (mOfferId == null) {
			if (other.mOfferId != null)
				return false;
		} else if (!mOfferId.equals(other.mOfferId))
			return false;
		if (mOfferName == null) {
			if (other.mOfferName != null)
				return false;
		} else if (!mOfferName.equals(other.mOfferName))
			return false;
		if (mOfferType == null) {
			if (other.mOfferType != null)
				return false;
		} else if (!mOfferType.equals(other.mOfferType))
			return false;
		if (mParentOfferDesc == null) {
			if (other.mParentOfferDesc != null)
				return false;
		} else if (!mParentOfferDesc.equals(other.mParentOfferDesc))
			return false;
		if (mParentOfferId == null) {
			if (other.mParentOfferId != null)
				return false;
		} else if (!mParentOfferId.equals(other.mParentOfferId))
			return false;
		if (mParentOfferName == null) {
			if (other.mParentOfferName != null)
				return false;
		} else if (!mParentOfferName.equals(other.mParentOfferName))
			return false;
		if (mRebateAllowedFlag == null) {
			if (other.mRebateAllowedFlag != null)
				return false;
		} else if (!mRebateAllowedFlag.equals(other.mRebateAllowedFlag))
			return false;
		return true;
	}
	private String mDiscAmt;
	/**
	 * Property used to hold the mDiscPrcnt
	 * 
	 */
	private short mDiscPrcnt;
	/**
	 * Property used to hold the mTargetBogoOrder
	 * 
	 */
	private String mTargetBogoOrder;
	/**
	 * Property used to hold the mTargetBogoItem
	 * 
	 */
	private String mTargetBogoItem;
	/**
	 * Property used to hold the mTargetBogoItemPriceType
	 * 
	 */
	private String mTargetBogoItemPriceType;
	/**
	 * Property used to hold the mBogoTargetLocation
	 * 
	 */
	private String mBogoTargetLocation;
	/**
	 * Property used to hold the mBagxLinkSeqNum
	 * 
	 */
	private String mBagxLinkSeqNum;
	/**
	 * Property used to hold the mBagxLinkCluster
	 * 
	 */
	private String mBagxLinkCluster;
	/**
	 * Property used to hold the mParentOfferIdDesc
	 * 
	 */
	private String mParentOfferIdDesc;
	/**
	 * Property used to hold the mThresholdAmount
	 * 
	 */
	private String mThresholdAmount;
	/**
	 * Property used to hold the mPriceInfo
	 * 
	 */
	private VZWPriceInfo mPriceInfo;
	/**
	 * Property used to hold the mRebatesAllowed
	 * 
	 */
	private String mRebatesAllowed;
	/**
	 * Property used to hold the mMgrDRC
	 * 
	 */
	private String mMgrDRC;
	/**
	 * Property used to hold the mMgrDrcDesc
	 * 
	 */
	private String mMgrDrcDesc;
	/**
	 * Property used to hold the mBarcodeID
	 * 
	 */
	private String mDescription;

	/**
	 * This method is used to get the discAmt
	 * 
	 * @return the discAmt
	 */
	public String getDiscAmt() {
		return mDiscAmt;
	}

	/**
	 *This method is used to set the discAmt
	 * 
	 * @param pDiscAmt
	 *            the discAmt to set
	 */
	public void setDiscAmt(String pDiscAmt) {
		mDiscAmt = pDiscAmt;
	}

	/**
	 * This method is used to get the discPrcnt
	 * 
	 * @return the discPrcnt
	 */
	public short getDiscPrcnt() {
		return mDiscPrcnt;
	}

	/**
	 *This method is used to set the discPrcnt
	 * 
	 * @param pDiscPrcnt
	 *            the discPrcnt to set
	 */
	public void setDiscPrcnt(short pDiscPrcnt) {
		mDiscPrcnt = pDiscPrcnt;
	}
 
	/**
	 * This method is used to get the targetBogoOrder
	 * 
	 * @return the targetBogoOrder
	 */
	public String getTargetBogoOrder() {
		return mTargetBogoOrder;
	}

	/**
	 *This method is used to set the targetBogoOrder
	 * 
	 * @param pTargetBogoOrder
	 *            the targetBogoOrder to set
	 */
	public void setTargetBogoOrder(String pTargetBogoOrder) {
		mTargetBogoOrder = pTargetBogoOrder;
	}

	/**
	 * This method is used to get the targetBogoItem
	 * 
	 * @return the targetBogoItem
	 */
	public String getTargetBogoItem() {
		return mTargetBogoItem;
	}

	/**
	 *This method is used to set the targetBogoItem
	 * 
	 * @param pTargetBogoItem
	 *            the targetBogoItem to set
	 */
	public void setTargetBogoItem(String pTargetBogoItem) {
		mTargetBogoItem = pTargetBogoItem;
	}

	/**
	 * This method is used to get the targetBogoItemPriceType
	 * 
	 * @return the targetBogoItemPriceType
	 */
	public String getTargetBogoItemPriceType() {
		return mTargetBogoItemPriceType;
	}

	/**
	 *This method is used to set the targetBogoItemPriceType
	 * 
	 * @param pTargetBogoItemPriceType
	 *            the targetBogoItemPriceType to set
	 */
	public void setTargetBogoItemPriceType(String pTargetBogoItemPriceType) {
		mTargetBogoItemPriceType = pTargetBogoItemPriceType;
	}

	/**
	 * This method is used to get the bogoTargetLocation
	 * 
	 * @return the bogoTargetLocation
	 */
	public String getBogoTargetLocation() {
		return mBogoTargetLocation;
	}

	/**
	 *This method is used to set the bogoTargetLocation
	 * 
	 * @param pBogoTargetLocation
	 *            the bogoTargetLocation to set
	 */
	public void setBogoTargetLocation(String pBogoTargetLocation) {
		mBogoTargetLocation = pBogoTargetLocation;
	}

	/**
	 * This method is used to get the bagxLinkSeqNum
	 * 
	 * @return the bagxLinkSeqNum
	 */
	public String getBagxLinkSeqNum() {
		return mBagxLinkSeqNum;
	}

	/**
	 *This method is used to set the bagxLinkSeqNum
	 * 
	 * @param pBagxLinkSeqNum
	 *            the bagxLinkSeqNum to set
	 */
	public void setBagxLinkSeqNum(String pBagxLinkSeqNum) {
		mBagxLinkSeqNum = pBagxLinkSeqNum;
	}

	/**
	 * This method is used to get the bagxLinkCluster
	 * 
	 * @return the bagxLinkCluster
	 */
	public String getBagxLinkCluster() {
		return mBagxLinkCluster;
	}

	/**
	 *This method is used to set the bagxLinkCluster
	 * 
	 * @param pBagxLinkCluster
	 *            the bagxLinkCluster to set
	 */
	public void setBagxLinkCluster(String pBagxLinkCluster) {
		mBagxLinkCluster = pBagxLinkCluster;
	}

	/**
	 * This method is used to get the parentOfferIdDesc
	 * 
	 * @return the parentOfferIdDesc
	 */
	public String getParentOfferIdDesc() {
		return mParentOfferIdDesc;
	}

	/**
	 *This method is used to set the parentOfferIdDesc
	 * 
	 * @param pParentOfferIdDesc
	 *            the parentOfferIdDesc to set
	 */
	public void setParentOfferIdDesc(String pParentOfferIdDesc) {
		mParentOfferIdDesc = pParentOfferIdDesc;
	}

	/**
	 * This method is used to get the thresholdAmount
	 * 
	 * @return the thresholdAmount
	 */
	public String getThresholdAmount() {
		return mThresholdAmount;
	}

	/**
	 *This method is used to set the thresholdAmount
	 * 
	 * @param pThresholdAmount
	 *            the thresholdAmount to set
	 */
	public void setThresholdAmount(String pThresholdAmount) {
		mThresholdAmount = pThresholdAmount;
	}

	/**
	 * This method is used to get the priceInfo
	 * 
	 * @return the priceInfo
	 */
	public VZWPriceInfo getPriceInfo() {
		return mPriceInfo;
	}
	/**
	 * This method is used to get the description
	 * 
	 * @return the description
	 */
	public String getDescription() {
		return mDescription;
	}

	/**
	 *This method is used to set the description
	 * 
	 * @param pDescription
	 *            the description to set
	 */
	public void setDescription(String pDescription) {
		mDescription = pDescription;
	}
	/**
	 * This method is used to get the mgrDRC
	 * 
	 * @return the mgrDRC
	 */
	public String getMgrDRC() {
		return mMgrDRC;
	}

	/**
	 *This method is used to set the mgrDRC
	 * 
	 * @param pMgrDRC
	 *            the mgrDRC to set
	 */
	public void setMgrDRC(String pMgrDRC) {
		mMgrDRC = pMgrDRC;
	}
	
	/**
	 * This method is used to get the rebatesAllowed
	 * 
	 * @return the rebatesAllowed
	 */
	public String getRebatesAllowed() {
		return mRebatesAllowed;
	}

	/**
	 *This method is used to set the rebatesAllowed
	 * 
	 * @param pRebatesAllowed
	 *            the rebatesAllowed to set
	 */
	public void setRebatesAllowed(String pRebatesAllowed) {
		mRebatesAllowed = pRebatesAllowed;
	}
	/**
	 * This method is used to get the mgrDrcDesc
	 * 
	 * @return the mgrDrcDesc
	 */
	public String getMgrDrcDesc() {
		return mMgrDrcDesc;
	}

	/**
	 *This method is used to set the mgrDrcDesc
	 * 
	 * @param pMgrDrcDesc
	 *            the mgrDrcDesc to set
	 */
	public void setMgrDrcDesc(String pMgrDrcDesc) {
		mMgrDrcDesc = pMgrDrcDesc;
	}
}
