package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;

/**
 * Created by vkashe on 8/18/2017.
 */
public class DevicePaymentCategoryType implements Serializable {

    private static final long serialVersionUID = 1L;

    private String categoryName;
    private String categoryCode;

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getCategoryCode() {
        return categoryCode;
    }

    public void setCategoryCode(String categoryCode) {
        this.categoryCode = categoryCode;
    }
}
