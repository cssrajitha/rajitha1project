package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;


public class TradeInDevice implements Serializable{

	private static final long serialVersionUID = 1L;
	private String id;
	private int version;
	private String deviceId;
	private Date lastModifiedDate;
	private Date createdDate;
	private BigDecimal appraisedPrice;  //Final Appraised Price
	private BigDecimal monthlyCredit;
	private String itemId;
	private BigDecimal organicPrice;
	private BigDecimal computedPrice;
	private BigDecimal appliedPrice;
	private BigDecimal promoValue;
	private BigDecimal deductionOnOrganic;
	private BigDecimal deductionOnPromo;
	private boolean deviceGoodCondition;
	private String deviceIdType;
	private Date tncAcceptanceDate;
	private String sorId;
	private String model;
	private String modelName;
	private String itemType;
	private String image;
	private String memory;
	private String color;
	private String os;
	private String displayName;
	private String manufacturer;
	private String promoQualifyMesage;
	private Map<Integer, String> questionAnsMap = new TreeMap<Integer, String>();
	private List<TradeInQuestionVO> tradeInQuestionVoList;
	private String zipCode;
	private boolean termsAccepted;
	private boolean submitted;
	private String carrier;
	private String offerType;
	private String deviceCreditType;
	private List<RecycleDeviceOffer> offerList;
	private String submissionId;
	private boolean isFindMyIPhoneOn; //FindMyIPhone
	private String tradeInInfoId;
	private String orderId;
	
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getTradeInInfoId() {
		return tradeInInfoId;
	}
	public void setTradeInInfoId(String tradeInInfoId) {
		this.tradeInInfoId = tradeInInfoId;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	public String getDeviceCreditType() {
		return deviceCreditType;
	}
	public void setDeviceCreditType(String deviceCreditType) {
		this.deviceCreditType = deviceCreditType;
	}
	public List<RecycleDeviceOffer> getOfferList() {
		return offerList;
	}
	public void setOfferList(List<RecycleDeviceOffer> offerList) {
		this.offerList = offerList;
	}
	public String getOfferType() {
		return offerType;
	}
	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public boolean isTermsAccepted() {
		return termsAccepted;
	}
	public void setTermsAccepted(boolean termsAccepted) {
		this.termsAccepted = termsAccepted;
	}
	public boolean isSubmitted() {
		return submitted;
	}
	public void setSubmitted(boolean submitted) {
		this.submitted = submitted;
	}
	public Date getTncAcceptanceDate() {
		return tncAcceptanceDate;
	}
	public void setTncAcceptanceDate(Date tncAcceptanceDate) {
		this.tncAcceptanceDate = tncAcceptanceDate;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public String getSorId() {
		return sorId;
	}
	public List<TradeInQuestionVO> getTradeInQuestionVoList() {
		return tradeInQuestionVoList;
	}
	public void setTradeInQuestionVoList(List<TradeInQuestionVO> tradeInQuestionVoList) {
		this.tradeInQuestionVoList = tradeInQuestionVoList;
	}
	public void setSorId(String sorId) {
		this.sorId = sorId;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getItemType() {
		return itemType;
	}
	public void setItemType(String itemType) {
		this.itemType = itemType;
	}
	public BigDecimal getAppraisedPrice() {
		return appraisedPrice;
	}
	public void setAppraisedPrice(BigDecimal appraisedPrice) {
		this.appraisedPrice = appraisedPrice;
	}
	public BigDecimal getMonthlyCredit() {
		return monthlyCredit;
	}
	public void setMonthlyCredit(BigDecimal monthlyCredit) {
		this.monthlyCredit = monthlyCredit;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getMemory() {
		return memory;
	}
	public void setMemory(String memory) {
		this.memory = memory;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getOs() {
		return os;
	}
	public void setOs(String os) {
		this.os = os;
	}
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public String getPromoQualifyMesage() {
		return promoQualifyMesage;
	}
	public void setPromoQualifyMesage(String promoQualifyMesage) {
		this.promoQualifyMesage = promoQualifyMesage;
	}
	public Map<Integer, String> getQuestionAnsMap() {
		return questionAnsMap;
	}
	public void setQuestionAnsMap(Map<Integer, String> questionAnsMap) {
		this.questionAnsMap = questionAnsMap;
	}
	public String getCarrier() {
		return carrier;
	}
	public void setCarrier(String carrier) {
		this.carrier = carrier;
	}
	public String getItemId() {
		return itemId;
	}
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	
	public boolean isDeviceGoodCondition() {
		return deviceGoodCondition;
	}
	public void setDeviceGoodCondition(boolean deviceGoodCondition) {
		this.deviceGoodCondition = deviceGoodCondition;
	}
	public String getDeviceIdType() {
		return deviceIdType;
	}
	public void setDeviceIdType(String deviceIdType) {
		this.deviceIdType = deviceIdType;
	}
	public String getSubmissionId() {
		return submissionId;
	}
	public void setSubmissionId(String submissionId) {
		this.submissionId = submissionId;
	}
	public BigDecimal getOrganicPrice() {
		return organicPrice;
	}
	public void setOrganicPrice(BigDecimal organicPrice) {
		this.organicPrice = organicPrice;
	}
	public BigDecimal getComputedPrice() {
		return computedPrice;
	}
	public void setComputedPrice(BigDecimal computedPrice) {
		this.computedPrice = computedPrice;
	}
	public BigDecimal getAppliedPrice() {
		return appliedPrice;
	}
	public void setAppliedPrice(BigDecimal appliedPrice) {
		this.appliedPrice = appliedPrice;
	}
	public BigDecimal getPromoValue() {
		return promoValue;
	}
	public void setPromoValue(BigDecimal promoValue) {
		this.promoValue = promoValue;
	}
	public BigDecimal getDeductionOnOrganic() {
		return deductionOnOrganic;
	}
	public void setDeductionOnOrganic(BigDecimal deductionOnOrganic) {
		this.deductionOnOrganic = deductionOnOrganic;
	}
	public BigDecimal getDeductionOnPromo() {
		return deductionOnPromo;
	}
	public void setDeductionOnPromo(BigDecimal deductionOnPromo) {
		this.deductionOnPromo = deductionOnPromo;
	}
	public boolean isFindMyIPhoneOn() {
		return isFindMyIPhoneOn;
	}
	public void setFindMyIPhoneOn(boolean isFindMyIPhoneOn) {
		this.isFindMyIPhoneOn = isFindMyIPhoneOn;
	}
	
}
