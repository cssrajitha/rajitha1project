package onevz.soe.prepay.adaptor.cart.model.cart.vo;


public class AccountInformation {
	private String primaryAccountNumber;
	private String expirationDate;
	private String currencyCode;
	private double transactionAmount;
	private String cardholderName;
	private String deviceManufacturerIdentifier;
	private String paymentDataType;
	private String onlinePaymentCryptogram;
	private String eciIndicator;
	private String emailAddress;
	private String transactionId;
	private String cardType;
	private String displayName;
	private String cardName;

	public String getPrimaryAccountNumber() {
		return primaryAccountNumber;
	}

	public void setPrimaryAccountNumber(String primaryAccountNumber) {
		this.primaryAccountNumber = primaryAccountNumber;
	}

	public String getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public double getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public String getCardholderName() {
		return cardholderName;
	}

	public void setCardholderName(String cardholderName) {
		this.cardholderName = cardholderName;
	}

	public String getDeviceManufacturerIdentifier() {
		return deviceManufacturerIdentifier;
	}

	public void setDeviceManufacturerIdentifier(String deviceManufacturerIdentifier) {
		this.deviceManufacturerIdentifier = deviceManufacturerIdentifier;
	}

	public String getPaymentDataType() {
		return paymentDataType;
	}

	public void setPaymentDataType(String paymentDataType) {
		this.paymentDataType = paymentDataType;
	}

	public String getOnlinePaymentCryptogram() {
		return onlinePaymentCryptogram;
	}

	public void setOnlinePaymentCryptogram(String onlinePaymentCryptogram) {
		this.onlinePaymentCryptogram = onlinePaymentCryptogram;
	}

	public String getEciIndicator() {
		return eciIndicator;
	}

	public void setEciIndicator(String eciIndicator) {
		this.eciIndicator = eciIndicator;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getCardName() {
		return cardName;
	}

	public void setCardName(String cardName) {
		this.cardName = cardName;
	}

}
