package onevz.soe.prepay.adaptor.cart.model.bpm;

import lombok.Data;

@Data
public class AddDeviceToPrepayODAddAccessoriesOutput {
	private boolean itemRemoved;
	private boolean itemAdded;
	private String orderId;
	private String sorId;
	private String accCommerceId;
}
