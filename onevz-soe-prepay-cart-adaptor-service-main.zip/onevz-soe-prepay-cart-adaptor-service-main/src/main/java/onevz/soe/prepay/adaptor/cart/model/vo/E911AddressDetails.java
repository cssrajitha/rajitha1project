package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;

public class E911AddressDetails implements Serializable{

    //private String e911AddressId;
    private String address1;
    private String address2;
    private String city;
    private String state;
    private String zipCode4;
    private String zipCode;
    private String country;
    //private String deviceLineItemId;

    /*public String getE911AddressId() {
        return e911AddressId;
    }

    public void setE911AddressId(String e911AddressId) {
        this.e911AddressId = e911AddressId;
    }

    public String getDeviceLineItemId() {
        return deviceLineItemId;
    }

    public void setDeviceLineItemId(String deviceLineItemId) {
        this.deviceLineItemId = deviceLineItemId;
    }*/

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZipCode4() {
        return zipCode4;
    }

    public void setZipCode4(String zipCode4) {
        this.zipCode4 = zipCode4;
    }
}
