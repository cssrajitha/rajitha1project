package onevz.soe.prepay.adaptor.cart.constants;



public enum CartValidationErrorEnum {
    CART_CREATOR_MISSING("1001", PrepayAdaptorCartConstants.WARNING, "Cart Creator is missing in CartHeader","", "Cart", ""),
    PRIMARY_EMAIL_MISSING("1005", PrepayAdaptorCartConstants.WARNING, "Primary EmailID is missing in cart orderdetails", "", "Cart", ""),
    CONTACT_NUMBER_MISSING("1006", PrepayAdaptorCartConstants.WARNING, "Contact PhoneNumber is missing in cart orderdetails","","Cart", ""),
    CORRELATIONID_MISSING("1009", PrepayAdaptorCartConstants.WARNING, "CorrelationID is missing in ServiceInfo","","Cart", ""),
    NPANXX_NUMBER_NOT_ASSIGNED("1010", PrepayAdaptorCartConstants.WARNING, "NPANXX Number is not assigned to AAL line in the cart","","Cart", ""),
    FIRST_NAME_MISSING_SHIPPING("1014", PrepayAdaptorCartConstants.WARNING, "First Name is missing in shipping addresstype","","Cart", ""),
    LAST_NAME_MISSING_SHIPPING("1015", PrepayAdaptorCartConstants.WARNING, "Last Name is missing in shipping addresstype","", "Cart", ""),
    EMAIL_ADDRESS_MISSING ("1016", PrepayAdaptorCartConstants.WARNING, "Email Address is missing in shipping addresstype","","Cart", ""),
    PHONE_NUMBER_MISSING("1017", PrepayAdaptorCartConstants.WARNING, "Phone Number is missing in shipping addresstype","", "Cart", ""),
    PRICEPLANID_NOT_POPULATED ("1023","Blocker", "New PricePlanId is not populated for NSE line.","","Cart", ""),
    PERSONAL_PAYMENT_INFORMATION("1075", PrepayAdaptorCartConstants.WARNING, "Enter personal and payment information","","Cart", ""),
    SHIPPING_REQUIRED("1090", PrepayAdaptorCartConstants.WARNING, "Shipping is Required","","Cart", ""),
    PAYMENT_REQUIRED("1091", PrepayAdaptorCartConstants.WARNING, "Payment is Required","", "Cart", ""),
    AGREEMENTS_REQUIRED("1095", PrepayAdaptorCartConstants.WARNING, "Agreements are Required", "","Cart","");


    CartValidationErrorEnum(String errorCode, String errorLevel, String errorMessage, String fieldPath, String errorCategory, String fieldName) {
        this.errorLevel = errorLevel;
        this.errorMessage = errorMessage;
        this.fieldPath = fieldPath;
        this.errorCategory = errorCategory;
        this.errorCode = errorCode;
        this.fieldName = fieldName;
    }

    private String errorLevel;
    private String errorMessage;
    private String fieldPath;
    private String errorCategory;
    private String errorCode;
    private String fieldName;

    public String getErrorLevel() {
        return errorLevel;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public String getFieldPath() {
        return fieldPath;
    }

    public String getErrorCategory() {
        return errorCategory;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldPath(String fieldPath) { this.fieldPath = fieldPath; }
}
