package onevz.soe.prepay.adaptor.cart.model.cxp.request;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class RetreiveNpanXXRequestModel {

    private String city;
    private String state;
    private String zipcode;
    private String zip;
    private String npanxx;
    private String billerId;

}
