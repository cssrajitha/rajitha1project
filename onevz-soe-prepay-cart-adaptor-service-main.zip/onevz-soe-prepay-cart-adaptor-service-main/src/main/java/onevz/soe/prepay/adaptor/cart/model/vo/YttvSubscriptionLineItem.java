package onevz.soe.prepay.adaptor.cart.model.vo;

public class YttvSubscriptionLineItem extends OrderLineItem{

   
	private static final long serialVersionUID = 1L;
	private String pricePlanPackageId;

	private String pricePlanPackageDesc;
	private String displayName;

	private Double purchasePrice;
	private Double discountPrice;
	private  String pricePlanPackageType;

	private String unitType;

	public String getUnits() {
		return units;
	}

	public void setUnits(String units) {
		this.units = units;
	}

	private String units;

	private String vendorPriceId;


	private boolean selected;

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	@Override
	public String getProductId() {
		return productId;
	}

	@Override
	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getPriceText() {
		return priceText;
	}

	public void setPriceText(String priceText) {
		this.priceText = priceText;
	}

	public String getSubTitleText() {
		return subTitleText;
	}

	public void setSubTitleText(String subTitleText) {
		this.subTitleText = subTitleText;
	}

	public String getDescriptionText() {
		return descriptionText;
	}

	public void setDescriptionText(String descriptionText) {
		this.descriptionText = descriptionText;
	}

	public String getDisclaimerText() {
		return disclaimerText;
	}

	public void setDisclaimerText(String disclaimerText) {
		this.disclaimerText = disclaimerText;
	}

	private String productId;
	private String priceText;
	private String subTitleText;
	private String descriptionText;
	private String disclaimerText;
	private String addressDisclaimerText;

	public String getAddressDisclaimerText() {
		return addressDisclaimerText;
	}

	public void setAddressDisclaimerText(String addressDisclaimerText) {
		this.addressDisclaimerText = addressDisclaimerText;
	}

	public String getToolTip() {
		return toolTip;
	}

	public void setToolTip(String toolTip) {
		this.toolTip = toolTip;
	}

	private String toolTip;




	public String getPricePlanPackageId() {
		return pricePlanPackageId;
	}

	public void setPricePlanPackageId(String pricePlanPackageId) {
		this.pricePlanPackageId = pricePlanPackageId;
	}

	public String getPricePlanPackageDesc() {
		return pricePlanPackageDesc;
	}

	public void setPricePlanPackageDesc(String pricePlanPackageDesc) {
		this.pricePlanPackageDesc = pricePlanPackageDesc;
	}

	@Override
	public String getDisplayName() {
		return displayName;
	}

	@Override
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public Double getPurchasePrice() {
		if(purchasePrice != null){
			return purchasePrice;
		}else{
			return 0.0D;
		}
	}

	public void setPurchasePrice(Double purchasePrice) {
		this.purchasePrice = purchasePrice;
	}

	public Double getDiscountPrice() {
		if(discountPrice != null){
			return discountPrice;
		}else{
			return 0.0D;
		}

	}

	public void setDiscountPrice(Double discountPrice) {
		this.discountPrice = discountPrice;
	}

	public String getPricePlanPackageType() {
		return pricePlanPackageType;
	}

	public void setPricePlanPackageType(String pricePlanPackageType) {
		this.pricePlanPackageType = pricePlanPackageType;
	}

	public String getUnitType() {
		return unitType;
	}

	public void setUnitType(String unitType) {
		this.unitType = unitType;
	}

	public String getVendorPriceId() {
		return vendorPriceId;
	}

	public void setVendorPriceId(String vendorPriceId) {
		this.vendorPriceId = vendorPriceId;
	}

	public String getDeviceItemId() {
		return deviceItemId;
	}

	public void setDeviceItemId(String deviceItemId) {
		this.deviceItemId = deviceItemId;
	}

	public boolean isFirstPurchase() {
		return isFirstPurchase;
	}

	public void setFirstPurchase(boolean firstPurchase) {
		isFirstPurchase = firstPurchase;
	}

	private String deviceItemId;
	private boolean isFirstPurchase;

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		return builder.toString();
	}

	public boolean equalsYttvSubscriptionLineItem(YttvSubscriptionLineItem yttvSubscriptionLineItem) {
		return yttvSubscriptionLineItem == null ? false : this.getPricePlanPackageId().equalsIgnoreCase(yttvSubscriptionLineItem.getPricePlanPackageId());
	}
}
