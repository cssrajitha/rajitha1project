package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;

public class YttvSubscriptionInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    public boolean isFirstPurchase() {
        return isFirstPurchase;
    }

    public void setFirstPurchase(boolean firstPurchase) {
        isFirstPurchase = firstPurchase;
    }

    public onevz.soe.prepay.adaptor.cart.model.vo.PricePlanPackageType getPricePlanPackageType() {
        return PricePlanPackageType;
    }

    public void setPricePlanPackageType(onevz.soe.prepay.adaptor.cart.model.vo.PricePlanPackageType pricePlanPackageType) {
        PricePlanPackageType = pricePlanPackageType;
    }

    private boolean isFirstPurchase;
    private PricePlanPackageType PricePlanPackageType;
    private String itemId;


    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }
}
