package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;

public class DeviceList implements Serializable {

    private static final long serialVersionUID = 1L;

    public long getDeviceKey() {
        return DeviceKey;
    }

    public void setDeviceKey(long deviceKey) {
        DeviceKey = deviceKey;
    }

    private long DeviceKey;


}
