package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;

public class HttpRequestHeaders implements Serializable {
    private String Host;
    private String Connection;
    private String Accept;
    private String Referer;
    private String AcceptEncoding;
    private String AcceptLanguage;

    public HttpRequestHeaders(){

    }

    public HttpRequestHeaders(String host, String connection, String accept, String referer, String acceptEncoding, String acceptLanguage) {
        Host = host;
        Connection = connection;
        Accept = accept;
        Referer = referer;
        AcceptEncoding = acceptEncoding;
        AcceptLanguage = acceptLanguage;
    }

    public String getReferer() {
        return Referer;
    }

    public void setReferer(String referer) {
        Referer = referer;
    }

    public String getHost() {
        return Host;
    }

    public void setHost(String host) {
        Host = host;
    }

    public String getConnection() {
        return Connection;
    }

    public void setConnection(String connection) {
        Connection = connection;
    }

    public String getAccept() {
        return Accept;
    }

    public void setAccept(String accept) {
        Accept = accept;
    }

    public String getAcceptEncoding() {
        return AcceptEncoding;
    }

    public void setAcceptEncoding(String acceptEncoding) {
        AcceptEncoding = acceptEncoding;
    }

    public String getAcceptLanguage() {
        return AcceptLanguage;
    }

    public void setAcceptLanguage(String acceptLanguage) {
        AcceptLanguage = acceptLanguage;
    }

}
