package onevz.soe.prepay.adaptor.cart.model.play;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class VZWCheckoutPayload implements Serializable {
	
	
	private VZWPrepayOrderVO pageData;


}