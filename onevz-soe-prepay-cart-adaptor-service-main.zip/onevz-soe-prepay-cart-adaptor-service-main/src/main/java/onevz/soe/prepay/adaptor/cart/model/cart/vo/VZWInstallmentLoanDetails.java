/**
 * 
 */
package onevz.soe.prepay.adaptor.cart.model.cart.vo;


import java.io.Serializable;

/**
 * This class is used for InstallmentLoanMaintenance Service API
 * @author c0karam
 *
 */
public class VZWInstallmentLoanDetails implements Serializable {

	private static final long serialVersionUID = 1L;
	/**
	 * property to hold InstallmentLoanMaintenance API Response Data
	 */
	private String mtn;
	private String installmentLoanNumber;
	private String pendingLoanIndicator;
	private String status;
	private String deviceIdType;
	private String deviceId;
	private String loanAmount;
	private String firstInstallmentAmount;
	private String loanTaxableBaseAmount;
	private String loanTaxCallectedAmount;
	private String downPaymentAmount;
	private String downPaymentTaxCollectedAmount;
	private String loanTotalFinanceChargedAmount;
	private String financeChargedCollectedAmount;
	private String financeChargedTaxCollectedAmount;
	private String loanTermMonthsQty;
	private String loanMonthlyPaymentAmount;
	private String totalPrincipalUnpaid;
	private String totalBuyoutAmount;
	private String installmentPrincipalUnpaid;
	private String financeChargeAmountUnpaid;
	private String taxAmountUnpaid;
	private String installmentPrincipalUnbilled;
	private String financeChargeAmountUnbilled;
	private String taxAmountUnbilled;
	private String installmentLoanType;
	private String skuId;
	private String deviceReturnStatusCode;
	private String deviceReturnStatusDate;
	private String earlyBuyoutAmount;
	private String earlyUnbilledPrincipalAmount;
	private String earlyUnbilledTaxAmount;
	private String earlyUnpaidARPrincipalAmount;
	private String earlyUnpaidARTaxAmount;
	private String edgeUpPrincipleUnpaid;
	private String pastTradeInRestrictionTimePeriod;
	private String edgeUpOriginalCost;
	private String firstInstallmentCollectedAtPOSIndicator;
	private String stateOverrideTaxBasisAmount;
	private String numberOfInstallmentsBilled;
	private String numberOfInstallmentsToBill;
	private String loanSalesDate;
	private String equipmentOrderNumber;
	private String netaceLocId;
	private String edgeUpRequiredPercentage;
//	errorInfo
	private String errorCode;
	private String errorMsg;
//	ValidateOrderInfo 
	private String validationTypeCode;
	private String includeInitialValidationIndicator;
	private String equipmentOrderTypeCode;
	private String depletionLocationType;
	private String statusCode;
	private String statusReasonCode;
	private String esnReasonCode;
	private String geoCode;
	private double paidAmountPercentage;
	private String upgradeOptionCode;
	private String upgradeDeviceCategoryText;
	private boolean mtnMismatch;
	private String buyoutFlag;
	private String buyoutEligibilityMessage;
	
	public boolean isMtnMismatch() {
		return mtnMismatch;
	}

	public void setMtnMismatch(boolean mtnMismatch) {
		this.mtnMismatch = mtnMismatch;
	}

	public String getEdgeUpRequiredPercentage() {
		return edgeUpRequiredPercentage;
	}

	public void setEdgeUpRequiredPercentage(final String edgeUpRequiredPercentage) {
		this.edgeUpRequiredPercentage = edgeUpRequiredPercentage;
	}

	public String getEquipmentOrderNumber() {
		return equipmentOrderNumber;
	}

	public void setEquipmentOrderNumber(String equipmentOrderNumber) {
		this.equipmentOrderNumber = equipmentOrderNumber;
	}

	public String getNetaceLocId() {
		return netaceLocId;
	}

	public void setNetaceLocId(String netaceLocId) {
		this.netaceLocId = netaceLocId;
	}

	/**
	 * @return the mtn
	 */
	public String getMtn() {
		return mtn;
	}

	/**
	 * @param mtn the mtn to set
	 */
	public void setMtn(String mtn) {
		this.mtn = mtn;
	}

	/**
	 * @return the installmentLoanNumber
	 */
	public String getInstallmentLoanNumber() {
		return installmentLoanNumber;
	}

	/**
	 * @return the pendingLoanIndicator
	 */
	public String getPendingLoanIndicator() {
		return pendingLoanIndicator;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @return the deviceIdType
	 */
	public String getDeviceIdType() {
		return deviceIdType;
	}

	/**
	 * @return the deviceId
	 */
	public String getDeviceId() {
		return deviceId;
	}

	/**
	 * @return the loanAmount
	 */
	public String getLoanAmount() {
		return loanAmount;
	}

	/**
	 * @return the firstInstallmentAmount
	 */
	public String getFirstInstallmentAmount() {
		return firstInstallmentAmount;
	}

	/**
	 * @return the loanTaxableBaseAmount
	 */
	public String getLoanTaxableBaseAmount() {
		return loanTaxableBaseAmount;
	}

	/**
	 * @return the loanTaxCallectedAmount
	 */
	public String getLoanTaxCallectedAmount() {
		return loanTaxCallectedAmount;
	}

	/**
	 * @return the downPaymentAmount
	 */
	public String getDownPaymentAmount() {
		return downPaymentAmount;
	}

	/**
	 * @return the downPaymentTaxCollectedAmount
	 */
	public String getDownPaymentTaxCollectedAmount() {
		return downPaymentTaxCollectedAmount;
	}

	/**
	 * @return the loanTotalFinanceChargedAmount
	 */
	public String getLoanTotalFinanceChargedAmount() {
		return loanTotalFinanceChargedAmount;
	}

	/**
	 * @return the financeChargedCollectedAmount
	 */
	public String getFinanceChargedCollectedAmount() {
		return financeChargedCollectedAmount;
	}

	/**
	 * @return the financeChargedTaxCollectedAmount
	 */
	public String getFinanceChargedTaxCollectedAmount() {
		return financeChargedTaxCollectedAmount;
	}

	/**
	 * @return the loanTermMonthsQty
	 */
	public String getLoanTermMonthsQty() {
		return loanTermMonthsQty;
	}

	/**
	 * @return the loanMonthlyPaymentAmount
	 */
	public String getLoanMonthlyPaymentAmount() {
		return loanMonthlyPaymentAmount;
	}

	/**
	 * @return the totalPrincipalUnpaid
	 */
	public String getTotalPrincipalUnpaid() {
		return totalPrincipalUnpaid;
	}

	/**
	 * @return the totalBuyoutAmount
	 */
	public String getTotalBuyoutAmount() {
		return totalBuyoutAmount;
	}

	/**
	 * @return the installmentPrincipalUnpaid
	 */
	public String getInstallmentPrincipalUnpaid() {
		return installmentPrincipalUnpaid;
	}

	/**
	 * @return the financeChargeAmountUnpaid
	 */
	public String getFinanceChargeAmountUnpaid() {
		return financeChargeAmountUnpaid;
	}

	/**
	 * @return the taxAmountUnpaid
	 */
	public String getTaxAmountUnpaid() {
		return taxAmountUnpaid;
	}

	/**
	 * @return the installmentPrincipalUnbilled
	 */
	public String getInstallmentPrincipalUnbilled() {
		return installmentPrincipalUnbilled;
	}

	/**
	 * @return the financeChargeAmountUnbilled
	 */
	public String getFinanceChargeAmountUnbilled() {
		return financeChargeAmountUnbilled;
	}

	/**
	 * @return the taxAmountUnbilled
	 */
	public String getTaxAmountUnbilled() {
		return taxAmountUnbilled;
	}

	/**
	 * @return the installmentLoanType
	 */
	public String getInstallmentLoanType() {
		return installmentLoanType;
	}

	/**
	 * @return the skuId
	 */
	public String getSkuId() {
		return skuId;
	}

	/**
	 * @return the deviceReturnStatusCode
	 */
	public String getDeviceReturnStatusCode() {
		return deviceReturnStatusCode;
	}

	/**
	 * @return the deviceReturnStatusDate
	 */
	public String getDeviceReturnStatusDate() {
		return deviceReturnStatusDate;
	}

	/**
	 * @return the earlyBuyoutAmount
	 */
	public String getEarlyBuyoutAmount() {
		return earlyBuyoutAmount;
	}

	/**
	 * @return the earlyUnbilledPrincipalAmount
	 */
	public String getEarlyUnbilledPrincipalAmount() {
		return earlyUnbilledPrincipalAmount;
	}

	/**
	 * @return the earlyUnbilledTaxAmount
	 */
	public String getEarlyUnbilledTaxAmount() {
		return earlyUnbilledTaxAmount;
	}

	/**
	 * @return the earlyUnpaidARPrincipalAmount
	 */
	public String getEarlyUnpaidARPrincipalAmount() {
		return earlyUnpaidARPrincipalAmount;
	}

	/**
	 * @return the earlyUnpaidARTaxAmount
	 */
	public String getEarlyUnpaidARTaxAmount() {
		return earlyUnpaidARTaxAmount;
	}

	/**
	 * @return the edgeUpPrincipleUnpaid
	 */
	public String getEdgeUpPrincipleUnpaid() {
		return edgeUpPrincipleUnpaid;
	}

	/**
	 * @return the pastTradeInRestrictionTimePeriod
	 */
	public String getPastTradeInRestrictionTimePeriod() {
		return pastTradeInRestrictionTimePeriod;
	}

	/**
	 * @return the edgeUpOriginalCost
	 */
	public String getEdgeUpOriginalCost() {
		return edgeUpOriginalCost;
	}

	/**
	 * @return the firstInstallmentCollectedAtPOSIndicator
	 */
	public String getFirstInstallmentCollectedAtPOSIndicator() {
		return firstInstallmentCollectedAtPOSIndicator;
	}

	/**
	 * @return the stateOverrideTaxBasisAmount
	 */
	public String getStateOverrideTaxBasisAmount() {
		return stateOverrideTaxBasisAmount;
	}

	/**
	 * @param installmentLoanNumber the installmentLoanNumber to set
	 */
	public void setInstallmentLoanNumber(String installmentLoanNumber) {
		this.installmentLoanNumber = installmentLoanNumber;
	}

	/**
	 * @param pendingLoanIndicator the pendingLoanIndicator to set
	 */
	public void setPendingLoanIndicator(String pendingLoanIndicator) {
		this.pendingLoanIndicator = pendingLoanIndicator;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @param deviceIdType the deviceIdType to set
	 */
	public void setDeviceIdType(String deviceIdType) {
		this.deviceIdType = deviceIdType;
	}

	/**
	 * @param deviceId the deviceId to set
	 */
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	/**
	 * @param loanAmount the loanAmount to set
	 */
	public void setLoanAmount(String loanAmount) {
		this.loanAmount = loanAmount;
	}

	/**
	 * @param firstInstallmentAmount the firstInstallmentAmount to set
	 */
	public void setFirstInstallmentAmount(String firstInstallmentAmount) {
		this.firstInstallmentAmount = firstInstallmentAmount;
	}

	/**
	 * @param loanTaxableBaseAmount the loanTaxableBaseAmount to set
	 */
	public void setLoanTaxableBaseAmount(String loanTaxableBaseAmount) {
		this.loanTaxableBaseAmount = loanTaxableBaseAmount;
	}

	/**
	 * @param loanTaxCallectedAmount the loanTaxCallectedAmount to set
	 */
	public void setLoanTaxCallectedAmount(String loanTaxCallectedAmount) {
		this.loanTaxCallectedAmount = loanTaxCallectedAmount;
	}

	/**
	 * @param downPaymentAmount the downPaymentAmount to set
	 */
	public void setDownPaymentAmount(String downPaymentAmount) {
		this.downPaymentAmount = downPaymentAmount;
	}

	/**
	 * @param downPaymentTaxCollectedAmount the downPaymentTaxCollectedAmount to set
	 */
	public void setDownPaymentTaxCollectedAmount(
			String downPaymentTaxCollectedAmount) {
		this.downPaymentTaxCollectedAmount = downPaymentTaxCollectedAmount;
	}

	/**
	 * @param loanTotalFinanceChargedAmount the loanTotalFinanceChargedAmount to set
	 */
	public void setLoanTotalFinanceChargedAmount(
			String loanTotalFinanceChargedAmount) {
		this.loanTotalFinanceChargedAmount = loanTotalFinanceChargedAmount;
	}

	/**
	 * @param financeChargedCollectedAmount the financeChargedCollectedAmount to set
	 */
	public void setFinanceChargedCollectedAmount(
			String financeChargedCollectedAmount) {
		this.financeChargedCollectedAmount = financeChargedCollectedAmount;
	}

	/**
	 * @param financeChargedTaxCollectedAmount the financeChargedTaxCollectedAmount to set
	 */
	public void setFinanceChargedTaxCollectedAmount(
			String financeChargedTaxCollectedAmount) {
		this.financeChargedTaxCollectedAmount = financeChargedTaxCollectedAmount;
	}

	/**
	 * @param loanTermMonthsQty the loanTermMonthsQty to set
	 */
	public void setLoanTermMonthsQty(String loanTermMonthsQty) {
		this.loanTermMonthsQty = loanTermMonthsQty;
	}

	/**
	 * @param loanMonthlyPaymentAmount the loanMonthlyPaymentAmount to set
	 */
	public void setLoanMonthlyPaymentAmount(String loanMonthlyPaymentAmount) {
		this.loanMonthlyPaymentAmount = loanMonthlyPaymentAmount;
	}

	/**
	 * @param totalPrincipalUnpaid the totalPrincipalUnpaid to set
	 */
	public void setTotalPrincipalUnpaid(String totalPrincipalUnpaid) {
		this.totalPrincipalUnpaid = totalPrincipalUnpaid;
	}

	/**
	 * @param totalBuyoutAmount the totalBuyoutAmount to set
	 */
	public void setTotalBuyoutAmount(String totalBuyoutAmount) {
		this.totalBuyoutAmount = totalBuyoutAmount;
	}

	/**
	 * @param installmentPrincipalUnpaid the installmentPrincipalUnpaid to set
	 */
	public void setInstallmentPrincipalUnpaid(String installmentPrincipalUnpaid) {
		this.installmentPrincipalUnpaid = installmentPrincipalUnpaid;
	}

	/**
	 * @param financeChargeAmountUnpaid the financeChargeAmountUnpaid to set
	 */
	public void setFinanceChargeAmountUnpaid(String financeChargeAmountUnpaid) {
		this.financeChargeAmountUnpaid = financeChargeAmountUnpaid;
	}

	/**
	 * @param taxAmountUnpaid the taxAmountUnpaid to set
	 */
	public void setTaxAmountUnpaid(String taxAmountUnpaid) {
		this.taxAmountUnpaid = taxAmountUnpaid;
	}

	/**
	 * @param installmentPrincipalUnbilled the installmentPrincipalUnbilled to set
	 */
	public void setInstallmentPrincipalUnbilled(String installmentPrincipalUnbilled) {
		this.installmentPrincipalUnbilled = installmentPrincipalUnbilled;
	}

	/**
	 * @param financeChargeAmountUnbilled the financeChargeAmountUnbilled to set
	 */
	public void setFinanceChargeAmountUnbilled(String financeChargeAmountUnbilled) {
		this.financeChargeAmountUnbilled = financeChargeAmountUnbilled;
	}

	/**
	 * @param taxAmountUnbilled the taxAmountUnbilled to set
	 */
	public void setTaxAmountUnbilled(String taxAmountUnbilled) {
		this.taxAmountUnbilled = taxAmountUnbilled;
	}

	/**
	 * @param installmentLoanType the installmentLoanType to set
	 */
	public void setInstallmentLoanType(String installmentLoanType) {
		this.installmentLoanType = installmentLoanType;
	}

	/**
	 * @param skuId the skuId to set
	 */
	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}

	/**
	 * @param deviceReturnStatusCode the deviceReturnStatusCode to set
	 */
	public void setDeviceReturnStatusCode(String deviceReturnStatusCode) {
		this.deviceReturnStatusCode = deviceReturnStatusCode;
	}

	/**
	 * @param deviceReturnStatusDate the deviceReturnStatusDate to set
	 */
	public void setDeviceReturnStatusDate(String deviceReturnStatusDate) {
		this.deviceReturnStatusDate = deviceReturnStatusDate;
	}

	/**
	 * @param earlyBuyoutAmount the earlyBuyoutAmount to set
	 */
	public void setEarlyBuyoutAmount(String earlyBuyoutAmount) {
		this.earlyBuyoutAmount = earlyBuyoutAmount;
	}

	/**
	 * @param earlyUnbilledPrincipalAmount the earlyUnbilledPrincipalAmount to set
	 */
	public void setEarlyUnbilledPrincipalAmount(String earlyUnbilledPrincipalAmount) {
		this.earlyUnbilledPrincipalAmount = earlyUnbilledPrincipalAmount;
	}

	/**
	 * @param earlyUnbilledTaxAmount the earlyUnbilledTaxAmount to set
	 */
	public void setEarlyUnbilledTaxAmount(String earlyUnbilledTaxAmount) {
		this.earlyUnbilledTaxAmount = earlyUnbilledTaxAmount;
	}

	/**
	 * @param earlyUnpaidARPrincipalAmount the earlyUnpaidARPrincipalAmount to set
	 */
	public void setEarlyUnpaidARPrincipalAmount(String earlyUnpaidARPrincipalAmount) {
		this.earlyUnpaidARPrincipalAmount = earlyUnpaidARPrincipalAmount;
	}

	/**
	 * @param earlyUnpaidARTaxAmount the earlyUnpaidARTaxAmount to set
	 */
	public void setEarlyUnpaidARTaxAmount(String earlyUnpaidARTaxAmount) {
		this.earlyUnpaidARTaxAmount = earlyUnpaidARTaxAmount;
	}

	/**
	 * @param edgeUpPrincipleUnpaid the edgeUpPrincipleUnpaid to set
	 */
	public void setEdgeUpPrincipleUnpaid(String edgeUpPrincipleUnpaid) {
		this.edgeUpPrincipleUnpaid = edgeUpPrincipleUnpaid;
	}

	/**
	 * @param pastTradeInRestrictionTimePeriod the pastTradeInRestrictionTimePeriod to set
	 */
	public void setPastTradeInRestrictionTimePeriod(
			String pastTradeInRestrictionTimePeriod) {
		this.pastTradeInRestrictionTimePeriod = pastTradeInRestrictionTimePeriod;
	}

	/**
	 * @param edgeUpOriginalCost the edgeUpOriginalCost to set
	 */
	public void setEdgeUpOriginalCost(String edgeUpOriginalCost) {
		this.edgeUpOriginalCost = edgeUpOriginalCost;
	}

	/**
	 * @param firstInstallmentCollectedAtPOSIndicator the firstInstallmentCollectedAtPOSIndicator to set
	 */
	public void setFirstInstallmentCollectedAtPOSIndicator(
			String firstInstallmentCollectedAtPOSIndicator) {
		this.firstInstallmentCollectedAtPOSIndicator = firstInstallmentCollectedAtPOSIndicator;
	}

	/**
	 * @param stateOverrideTaxBasisAmount the stateOverrideTaxBasisAmount to set
	 */
	public void setStateOverrideTaxBasisAmount(String stateOverrideTaxBasisAmount) {
		this.stateOverrideTaxBasisAmount = stateOverrideTaxBasisAmount;
	}

	/**
	 * @return the numberOfInstallmentsBilled
	 */
	public String getNumberOfInstallmentsBilled() {
		return numberOfInstallmentsBilled;
	}

	/**
	 * @param numberOfInstallmentsBilled the numberOfInstallmentsBilled to set
	 */
	public void setNumberOfInstallmentsBilled(String numberOfInstallmentsBilled) {
		this.numberOfInstallmentsBilled = numberOfInstallmentsBilled;
	}

	public String getNumberOfInstallmentsToBill() {
		return numberOfInstallmentsToBill;
	}

	public void setNumberOfInstallmentsToBill(String numberOfInstallmentsToBill) {
		this.numberOfInstallmentsToBill = numberOfInstallmentsToBill;
	}

	/**
	 * @return the loanSalesDate
	 */
	public String getLoanSalesDate() {
		return loanSalesDate;
	}

	/**
	 * @param loanSalesDate the loanSalesDate to set
	 */
	public void setLoanSalesDate(String loanSalesDate) {
		this.loanSalesDate = loanSalesDate;
	}
	// 

	public String getValidationTypeCode() {
		return validationTypeCode;
	}

	public void setValidationTypeCode(String validationTypeCode) {
		this.validationTypeCode = validationTypeCode;
	}

	public String getIncludeInitialValidationIndicator() {
		return includeInitialValidationIndicator;
	}

	public void setIncludeInitialValidationIndicator(
			String includeInitialValidationIndicator) {
		this.includeInitialValidationIndicator = includeInitialValidationIndicator;
	}

	public String getEquipmentOrderTypeCode() {
		return equipmentOrderTypeCode;
	}

	public void setEquipmentOrderTypeCode(String equipmentOrderTypeCode) {
		this.equipmentOrderTypeCode = equipmentOrderTypeCode;
	}

	public String getDepletionLocationType() {
		return depletionLocationType;
	}

	public void setDepletionLocationType(String depletionLocationType) {
		this.depletionLocationType = depletionLocationType;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusReasonCode() {
		return statusReasonCode;
	}

	public void setStatusReasonCode(String statusReasonCode) {
		this.statusReasonCode = statusReasonCode;
	}

	public String getEsnReasonCode() {
		return esnReasonCode;
	}

	public void setEsnReasonCode(String esnReasonCode) {
		this.esnReasonCode = esnReasonCode;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getGeoCode() {
		return geoCode;
	}

	public void setGeoCode(String geoCode) {
		this.geoCode = geoCode;
	}

	public double getPaidAmountPercentage() {
		return paidAmountPercentage;
	}

	public void setPaidAmountPercentage(double paidAmountPercentage) {
		this.paidAmountPercentage = paidAmountPercentage;
	}

	public String getUpgradeOptionCode() {
		return upgradeOptionCode;
	}

	public void setUpgradeOptionCode(String upgradeOptionCode) {
		this.upgradeOptionCode = upgradeOptionCode;
	}

	public String getUpgradeDeviceCategoryText() {
		return upgradeDeviceCategoryText;
	}

	public void setUpgradeDeviceCategoryText(String upgradeDeviceCategoryText) {
		this.upgradeDeviceCategoryText = upgradeDeviceCategoryText;
	}

	public String getBuyoutFlag() {
		return buyoutFlag;
	}

	public void setBuyoutFlag(String buyoutFlag) {
		this.buyoutFlag = buyoutFlag;
	}

	public String getBuyoutEligibilityMessage() {
		return buyoutEligibilityMessage;
	}

	public void setBuyoutEligibilityMessage(String buyoutEligibilityMessage) {
		this.buyoutEligibilityMessage = buyoutEligibilityMessage;
	}
	
}
