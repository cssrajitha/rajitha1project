package onevz.soe.prepay.adaptor.cart.model.vo;

/**
 * 
 */


import java.io.Serializable;

/**
 * This is populated only for soft credit check.
 * 
 *
 */
public class SoftCreditInfo implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	
	private boolean creditWriteValidated;
	
	private Double downPaymentPercentage;
	
	private Double remainingSpendingLimit;
	
	private String creditIndicator;
	
	private String blanketApprovalNum;
	
	private String programEligibilityIndicator;
	
	private boolean quoteAccepted;

	public boolean isCreditWriteValidated() {
		return creditWriteValidated;
	}

	public void setCreditWriteValidated(boolean creditWriteValidated) {
		this.creditWriteValidated = creditWriteValidated;
	}

	public Double getDownPaymentPercentage() {
		return downPaymentPercentage;
	}

	public void setDownPaymentPercentage(Double downPaymentPercentage) {
		this.downPaymentPercentage = downPaymentPercentage;
	}

	public Double getRemainingSpendingLimit() {
		return remainingSpendingLimit;
	}

	public void setRemainingSpendingLimit(Double remainingSpendingLimit) {
		this.remainingSpendingLimit = remainingSpendingLimit;
	}

	public String getCreditIndicator() {
		return creditIndicator;
	}

	public void setCreditIndicator(String creditIndicator) {
		this.creditIndicator = creditIndicator;
	}

	public String getBlanketApprovalNum() {
		return blanketApprovalNum;
	}

	public void setBlanketApprovalNum(String blanketApprovalNum) {
		this.blanketApprovalNum = blanketApprovalNum;
	}

	public String getProgramEligibilityIndicator() {
		return programEligibilityIndicator;
	}

	public void setProgramEligibilityIndicator(String programEligibilityIndicator) {
		this.programEligibilityIndicator = programEligibilityIndicator;
	}

	public boolean isQuoteAccepted() {
		return quoteAccepted;
	}

	public void setQuoteAccepted(boolean quoteAccepted) {
		this.quoteAccepted = quoteAccepted;
	}	

	

}
