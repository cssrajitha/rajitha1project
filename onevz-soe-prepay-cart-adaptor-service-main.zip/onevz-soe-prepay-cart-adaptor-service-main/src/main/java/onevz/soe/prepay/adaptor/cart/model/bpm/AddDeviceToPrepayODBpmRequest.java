package onevz.soe.prepay.adaptor.cart.model.bpm;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;
import onevz.soe.cart.model.common.CartServiceServiceHeader;
import onevz.soe.wsclient.bpm.model.request.BPMServiceRequest;

@Data
@JsonPropertyOrder({"serviceHeader","serviceBody"})
public class AddDeviceToPrepayODBpmRequest extends BPMServiceRequest {

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private AddDeviceToPrepayODServiceBody serviceBody;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private CartServiceServiceHeader serviceHeader;

}
