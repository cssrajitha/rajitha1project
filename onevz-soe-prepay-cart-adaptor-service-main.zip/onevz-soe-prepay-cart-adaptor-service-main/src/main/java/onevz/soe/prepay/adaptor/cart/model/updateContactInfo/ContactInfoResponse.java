package onevz.soe.prepay.adaptor.cart.model.updateContactInfo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;
import onevz.soe.wsclient.bpm.model.response.BPMServiceResponse;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ContactInfoResponse extends BPMServiceResponse {
    private COntactInfoServiceBody serviceBody;

}
