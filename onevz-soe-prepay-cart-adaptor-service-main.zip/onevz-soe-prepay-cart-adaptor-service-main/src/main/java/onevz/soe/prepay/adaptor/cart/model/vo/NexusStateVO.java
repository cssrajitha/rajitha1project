package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.NO_TAX;

public class NexusStateVO implements Serializable {
    State state;
    boolean nexus;
    String monthlyPrice = NO_TAX; //default as NoTax
    String twoYearPrice = NO_TAX; //default as NoTax
    String fullRetailPrice = NO_TAX; //default as NoTax
    private List<String> siteIds = new ArrayList<>();

    public State getState() {
        return state;
    }

    public void setState(State state) {
        this.state = state;
    }

    public boolean isNexus() {
        return nexus;
    }

    public void setNexus(boolean nexus) {
        this.nexus = nexus;
    }

    public String getMonthlyPrice() {
        return monthlyPrice;
    }

    public void setMonthlyPrice(String monthlyPrice) {
        this.monthlyPrice = monthlyPrice;
    }

    public String getTwoYearPrice() {
        return twoYearPrice;
    }

    public void setTwoYearPrice(String twoYearPrice) {
        this.twoYearPrice = twoYearPrice;
    }

    public String getFullRetailPrice() {
        return fullRetailPrice;
    }

    public void setFullRetailPrice(String fullRetailPrice) {
        this.fullRetailPrice = fullRetailPrice;
    }

    public List<String> getSiteIds() {
        return siteIds;
    }

    public void setSiteIds(List<String> siteIds) {
        this.siteIds = siteIds;
    }

    public class State implements Serializable {
        String id;
        String stateName;
        String stateAbbrevation;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getStateName() {
            return stateName;
        }

        public void setStateName(String stateName) {
            this.stateName = stateName;
        }

        public String getStateAbbrevation() {
            return stateAbbrevation;
        }

        public void setStateAbbrevation(String stateAbbrevation) {
            this.stateAbbrevation = stateAbbrevation;
        }
    }
}
