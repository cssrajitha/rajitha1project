package onevz.soe.prepay.adaptor.cart.model.bpm;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import onevz.soe.wsclient.bpm.model.request.ServiceRequest;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper=true)
public class AddDeviceToPrepayODServiceRequest extends ServiceRequest {

	@JsonInclude(Include.NON_NULL)
	@JsonProperty(value = "context")
	private AddDeviceToPrepayODContext context;
}
