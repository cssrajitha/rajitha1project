package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;
import java.util.List;

public class EnforceData implements Serializable{

    private String vzSessionId;
    private String vzOrderId;
    private String visitorId;
    private String orderStartTime;
    private String orderEndTime;
    private String shareCartIndicator="N";
    private DeviceFingerPrint deviceFingerPrint;
    private String suspectedFraud;
    private List<String> suspectedFraudReasons;
    private List<AuthResult> authResults;

    public List<AuthResult> getAuthResults() {
        return authResults;
    }

    public void setAuthResults(List<AuthResult> authResults) {
        this.authResults = authResults;
    }

    public String getSuspectedFraud() {
        return suspectedFraud;
    }

    public void setSuspectedFraud(String suspectedFraud) {
        this.suspectedFraud = suspectedFraud;
    }

    public List<String> getSuspectedFraudReasons() {
        return suspectedFraudReasons;
    }

    public void setSuspectedFraudReasons(List<String> suspectedFraudReasons) {
        this.suspectedFraudReasons = suspectedFraudReasons;
    }
    public DeviceFingerPrint getDeviceFingerPrint() {
        return deviceFingerPrint;
    }

    public void setDeviceFingerPrint(DeviceFingerPrint deviceFingerPrint) {
        this.deviceFingerPrint = deviceFingerPrint;
    }

    public String getVzSessionId() {
        return vzSessionId;
    }

    public void setVzSessionId(String vzSessionId) {
        this.vzSessionId = vzSessionId;
    }

    public String getVzOrderId() {
        return vzOrderId;
    }

    public void setVzOrderId(String vzOrderId) {
        this.vzOrderId = vzOrderId;
    }

    public String getVisitorId() {
        return visitorId;
    }

    public void setVisitorId(String visitorId) {
        this.visitorId = visitorId;
    }

    public String getOrderStartTime() {
        return orderStartTime;
    }

    public void setOrderStartTime(String orderStartTime) {
        this.orderStartTime = orderStartTime;
    }

    public String getOrderEndTime() {
        return orderEndTime;
    }

    public void setOrderEndTime(String orderEndTime) {
        this.orderEndTime = orderEndTime;
    }

    public String getShareCartIndicator() {
        return shareCartIndicator;
    }

    public void setShareCartIndicator(String shareCartIndicator) {
        this.shareCartIndicator = shareCartIndicator;
    }

}
