package onevz.soe.prepay.adaptor.cart.model.cart.removelines;


import lombok.Data;

@Data
public class RemoveLineItemsRequest {

	private String lineItemId;
}
