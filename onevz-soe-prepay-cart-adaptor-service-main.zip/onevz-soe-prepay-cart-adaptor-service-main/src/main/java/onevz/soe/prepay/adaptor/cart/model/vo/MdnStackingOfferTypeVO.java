package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;

public class MdnStackingOfferTypeVO implements Serializable {
    private String mtn;
    private String stackMldSequence;
    private Integer offerId;
    private String allowStackWithTrade;

    public String getMtn() {
        return mtn;
    }

    public void setMtn(String mtn) {
        this.mtn = mtn;
    }

    public String getStackMldSequence() {
        return stackMldSequence;
    }

    public void setStackMldSequence(String stackMldSequence) {
        this.stackMldSequence = stackMldSequence;
    }

    public Integer getOfferId() {
        return offerId;
    }

    public void setOfferId(Integer offerId) {
        this.offerId = offerId;
    }

    public String getAllowStackWithTrade() {
        return allowStackWithTrade;
    }

    public void setAllowStackWithTrade(String allowStackWithTrade) {
        this.allowStackWithTrade = allowStackWithTrade;
    }
}
