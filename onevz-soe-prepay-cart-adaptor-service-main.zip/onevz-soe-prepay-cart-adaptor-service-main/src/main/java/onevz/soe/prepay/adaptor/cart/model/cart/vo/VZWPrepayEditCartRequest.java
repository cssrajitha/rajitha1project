package onevz.soe.prepay.adaptor.cart.model.cart.vo;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class VZWPrepayEditCartRequest {
    private String deviceSkuId;
    private String editFlowName;
    private String featureSkuId;
    private String lineItemId;
    private String planSkuId;
    private String productId;
    private String simType;
    private String simId;
    private int quantity;
    private String flow;
}
