package onevz.soe.prepay.adaptor.cart.model.play;

import lombok.Data;

import java.util.HashMap;
import java.util.List;

@Data
public class PrepaidODAddAccessoriesResponse {
    private List<PrepaidODAddAccessoriesOutput> output;
    private HashMap<String,String> errorMap ;
    private String statusMessage;
    private String statusCode;
}
