package onevz.soe.prepay.adaptor.cart.model.play;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class VZWAddPortinPageData {
    private List<TransferNumberDetail> transferNumberDetails;
    private String orderId;

    public List<TransferNumberDetail> getTransferNumberDetails() {
        return transferNumberDetails;
    }

    public void setTransferNumberDetails(List<TransferNumberDetail> transferNumberDetails) {
        this.transferNumberDetails = transferNumberDetails;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

}
