package onevz.soe.prepay.adaptor.cart.model.play.common.error;

import java.io.Serializable;

/**
 * Created by eesamma on 10/24/2017.
 */
public class EcommApiError implements Serializable {

    private String statusCode;
    private String message;
    private String developerMessage;
    private String moreInfo;
    private HomeSafetyInfo homeSafetyInfo;

    public HomeSafetyInfo getHomeSafetyInfo() {
        return homeSafetyInfo;
    }

    public void setHomeSafetyInfo(HomeSafetyInfo homeSafetyInfo) {
        this.homeSafetyInfo = homeSafetyInfo;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getDeveloperMessage() {
        return developerMessage;
    }

    public void setDeveloperMessage(String developerMessage) {
        this.developerMessage = developerMessage;
    }

    public String getMoreInfo() {
        return moreInfo;
    }

    public void setMoreInfo(String moreInfo) {
        this.moreInfo = moreInfo;
    }
}
