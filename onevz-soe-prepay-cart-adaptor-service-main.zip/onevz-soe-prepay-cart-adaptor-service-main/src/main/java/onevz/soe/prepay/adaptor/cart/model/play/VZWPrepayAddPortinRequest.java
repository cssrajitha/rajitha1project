package onevz.soe.prepay.adaptor.cart.model.play;

import lombok.Data;

@Data

public class VZWPrepayAddPortinRequest {
    private String lastName;
    private String accountPin;
    private String contactNumber;
    private String existingAccountNumber;
    private String city;
    private String zipCode;
    private String state;
    private String existingNumber;
    private String firstName;
    private String address1;
    private String address2;
    private String lineItemId;
}
