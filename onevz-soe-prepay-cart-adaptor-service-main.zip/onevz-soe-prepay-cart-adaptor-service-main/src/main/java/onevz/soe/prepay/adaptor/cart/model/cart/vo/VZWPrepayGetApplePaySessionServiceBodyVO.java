package onevz.soe.prepay.adaptor.cart.model.cart.vo;

/**
 * Created by w638278 on 1/17/2018.
 */
public class VZWPrepayGetApplePaySessionServiceBodyVO {
	private VZWPrepayGetApplePaySessionVO getSessionRes;

	public VZWPrepayGetApplePaySessionVO getGetSessionRes() {
		return getSessionRes;
	}

	public void setGetSessionRes(VZWPrepayGetApplePaySessionVO getSessionRes) {
		this.getSessionRes = getSessionRes;
	}

}
