package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;
import java.util.Date;

public class BillToAccountMQVO implements Serializable {

	private static final long serialVersionUID = -559007903627077408L;

	private String billingAddressValidated;
	private String accountNumber;
	private double btaAmountLimit;
	private double btaAmountRemaining;
	private double btaAmountMinusCurrentOrder;
	private Date lastModifiedDate;
	private int version;

	public String getBillingAddressValidated() {
		return billingAddressValidated;
	}

	public void setBillingAddressValidated(String billingAddressValidated) {
		this.billingAddressValidated = billingAddressValidated;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public double getBtaAmountLimit() {
		return btaAmountLimit;
	}

	public void setBtaAmountLimit(double btaAmountLimit) {
		this.btaAmountLimit = btaAmountLimit;
	}

	public double getBtaAmountRemaining() {
		return btaAmountRemaining;
	}

	public void setBtaAmountRemaining(double btaAmountRemaining) {
		this.btaAmountRemaining = btaAmountRemaining;
	}

	public double getBtaAmountMinusCurrentOrder() {
		return btaAmountMinusCurrentOrder;
	}

	public void setBtaAmountMinusCurrentOrder(double btaAmountMinusCurrentOrder) {
		this.btaAmountMinusCurrentOrder = btaAmountMinusCurrentOrder;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}
}
