package onevz.soe.prepay.adaptor.cart.model.updateContactInfo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import onevz.soe.cart.model.common.Address;

@lombok.Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Line{
    private String firstName;
    private String lastName;
    private String email;
    private String contactNumber;
    private Address address;
    private String mtn;
    private String phoneNumber;
}
