package onevz.soe.prepay.adaptor.cart.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.activation.cxp.response.OrderConfirmationCXPResponse;
import onevz.soe.orderprocess.request.CheckoutDetailsCXPRequest;
import onevz.soe.orderprocess.response.cxp.CheckoutDetailsCXPResponse;
import onevz.soe.prepay.adaptor.cart.helper.PrepayAdaptorNSECheckoutDetailsHelper;
import onevz.soe.prepay.adaptor.cart.util.PrepayAdaptorOrderConfirmationRedesignUtil;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import jakarta.validation.Valid;


@RestController
@RequestMapping(value = "prepaid-adaptor")
public class PrepayAdaptorCheckoutDetailsServiceController {

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    PrepayAdaptorNSECheckoutDetailsHelper prepayAdaptorNSECheckoutDetailsHelper;

    @Autowired
    private PrepayAdaptorWebClient prepayBusinessCartWebclient;

    @Value("${checkoutDetailsLegacyServiceUrl}")
    private String checkoutDetailsServiceUrl;

    private static Logger logger = LoggerFactory.getLogger(PrepayAdaptorCheckoutDetailsServiceController.class);

    @PostMapping("/cart/get-checkout-details")
    public Mono<ResponseEntity<CheckoutDetailsCXPResponse>> getCheckoutDetails(ServerHttpRequest httpRequest,
                                                                               @Valid @RequestBody CheckoutDetailsCXPRequest checkoutDetailsCXPRequest) {
        System.setProperty("endPoint", "get-checkout-details");
        logger.debug("getCheckoutDetails Request: {}", checkoutDetailsCXPRequest);
        logger.info("BAU Soe Api Url : INFO Inside PrepayAdaptorCheckoutDetailsServiceController: getCheckoutDetails {}", checkoutDetailsCXPRequest);
        logger.debug("BAU Soe Api Url : DEBUG Inside PrepayAdaptorCheckoutDetailsServiceController: getCheckoutDetails {}", checkoutDetailsCXPRequest);
        return prepayAdaptorNSECheckoutDetailsHelper.getCheckoutDetails(httpRequest, checkoutDetailsCXPRequest);

    }

    @PostMapping("/cart/getOrderConfirmationRedesignPage")
    public Mono<OrderConfirmationCXPResponse> getOrderConfirmationRedesignPage(ServerHttpRequest httpRequest) {
        System.setProperty("endPoint", "getOrderConfirmationRedesignPage");
        logger.debug("getOrderConfirmationRedesignPage ");
        CheckoutDetailsCXPRequest checkoutDetailsCXPRequest=new CheckoutDetailsCXPRequest();
        checkoutDetailsCXPRequest.setSubmitOrderSoe(true);
        return prepayAdaptorNSECheckoutDetailsHelper.getCheckoutDetails(httpRequest, checkoutDetailsCXPRequest).
                flatMap(responseEntity -> {
                    OrderConfirmationCXPResponse orderConfirmationCXPResponse = PrepayAdaptorOrderConfirmationRedesignUtil.formatOrderConfirmationCXPResponse(responseEntity.getBody());
                    return Mono.just(orderConfirmationCXPResponse);
                });

    }




}
