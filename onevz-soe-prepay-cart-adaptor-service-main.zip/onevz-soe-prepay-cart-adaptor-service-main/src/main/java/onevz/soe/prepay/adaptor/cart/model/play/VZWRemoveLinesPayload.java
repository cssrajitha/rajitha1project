package onevz.soe.prepay.adaptor.cart.model.play;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;
import onevz.soe.prepay.adaptor.cart.model.cart.vo.PrepayCartVO;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class VZWRemoveLinesPayload implements Serializable {

    private PrepayCartVO pageData;
}
