package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;

public class ThreatMetrixDetails implements Serializable {
    private String sessionId;
    private boolean success;

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }
}
