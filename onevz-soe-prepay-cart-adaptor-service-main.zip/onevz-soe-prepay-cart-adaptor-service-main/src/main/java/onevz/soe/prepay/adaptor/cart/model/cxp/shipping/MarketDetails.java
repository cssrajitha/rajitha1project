package onevz.soe.prepay.adaptor.cart.model.cxp.shipping;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Holds data of retrieve market details by zipcode service.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor

public class MarketDetails {
	
	@JsonProperty(value = "city")
	private  String city; 
	@JsonProperty(value = "state")
	private  String state;
	@JsonProperty(value = "zipCode")
	private  String zipCode;
	@JsonProperty(value = "majorMarket")
	private  String majorMarket;
	@JsonProperty(value = "region")
	private  String region;
	@JsonProperty(value = "marketId")
	private  String marketId;
	@JsonProperty(value = "marketName")
	private  String marketName;
	@JsonProperty(value = "areaCode")
	private  String areaCode;
	@JsonProperty(value = "shippingTimeZone")
	private  String shippingTimeZone;
	@JsonProperty(value = "netAceLocation")
	private  String netAceLocation;
	@JsonProperty(value = "b2cNetAceLocation")
	private  String b2cNetAceLocation;
	@JsonProperty(value = "eppNetAceLocation")
	private  String eppNetAceLocation;
	@JsonProperty(value = "b2eNetAceLocation")
	private  String b2eNetAceLocation;
	@JsonProperty(value = "regionCode")
	private  String regionCode;

}
