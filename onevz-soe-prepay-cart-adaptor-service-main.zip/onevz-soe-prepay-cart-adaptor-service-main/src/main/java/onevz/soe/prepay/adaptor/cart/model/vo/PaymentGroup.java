package onevz.soe.prepay.adaptor.cart.model.vo;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class PaymentGroup implements Serializable {

	private static final long serialVersionUID = 569647076933864075L;

	private String id;
	private String orderId;
	private String paymentMethod;
	private boolean creditCardValidated;
	private String billingAddressValidated = "N";
	private double amount;
	private ContactInfo billingAddress;
	private int version;
	private Date lastModifiedDate;
	private BillToAccountMQVO billToAccountMQVO;
	private CreditCardMQVO creditCardMQVO;
	private PaypalMQVO paypalMQVO;
	private boolean pieEncrypted;
	private String dsTransactionId;
	private String programProtocol;

	public String getOneWayHashTokenValue() {
		return oneWayHashTokenValue;
	}

	public void setOneWayHashTokenValue(String oneWayHashTokenValue) {
		this.oneWayHashTokenValue = oneWayHashTokenValue;
	}

	private String encryptionType;
	private String tokenizedValue;
	private String oneWayHashTokenValue;

	public BillToAccountMQVO getBillToAccountMQVO() {
		return billToAccountMQVO;
	}

	public void setBillToAccountMQVO(BillToAccountMQVO billToAccountMQVO) {
		this.billToAccountMQVO = billToAccountMQVO;
	}

	public CreditCardMQVO getCreditCardMQVO() {
		return creditCardMQVO;
	}

	public void setCreditCardMQVO(CreditCardMQVO creditCardMQVO) {
		this.creditCardMQVO = creditCardMQVO;
	}

	public PaypalMQVO getPaypalMQVO() {
		return paypalMQVO;
	}

	public void setPaypalMQVO(PaypalMQVO paypalMQVO) {
		this.paypalMQVO = paypalMQVO;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public boolean isCreditCardValidated() {
		return creditCardValidated;
	}

	public void setCreditCardValidated(boolean creditCardValidated) {
		this.creditCardValidated = creditCardValidated;
	}

	public String isBillingAddressValidated() {
		return billingAddressValidated;
	}

	public void setBillingAddressValidated(String billingAddressValidated) {
		this.billingAddressValidated = billingAddressValidated;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public ContactInfo getBillingAddress() {
		return billingAddress;
	}

	public void setBillingAddress(ContactInfo billingAddress) {
		this.billingAddress = billingAddress;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}
	
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getEncryptionType() {
		return encryptionType;
	}

	public void setEncryptionType(String encryptionType) {
		this.encryptionType = encryptionType;
	}

	public String getTokenizedValue() {
		return tokenizedValue;
	}

	public void setTokenizedValue(String tokenizedValue) {
		this.tokenizedValue = tokenizedValue;
	}

	public boolean isPieEncrypted() {
		return pieEncrypted;
	}

	public void setPieEncrypted(boolean pieEncrypted) {
		this.pieEncrypted = pieEncrypted;
	}

	public String getDsTransactionId() {
		return dsTransactionId;
	}

	public void setDsTransactionId(String dsTransactionId) {
		this.dsTransactionId = dsTransactionId;
	}

	public String getProgramProtocol() {
		return programProtocol;
	}

	public void setProgramProtocol(String programProtocol) {
		this.programProtocol = programProtocol;
	}

	@Override
	public String toString() {
		return "PaymentGroup [id=" + id + ", orderId=" + orderId + ", paymentMethod=" + paymentMethod
				+ ", creditCardValidated=" + creditCardValidated + ", billingAddressValidated="
				+ billingAddressValidated + ", amount=" + amount + ", billingAddress=" + billingAddress + ", version="
				+ version + ", lastModifedDate=" + lastModifiedDate + ", dsTransactionId=" + dsTransactionId
				+ ", programProtocol=" + programProtocol + "]";
	}

}
