package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;

public class ActivationFee implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String contractId;
	private double amount;
	
	public String getContractId() {
		return contractId;
	}
	
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}
	
	public double getAmount() {
		return amount;
	}
	
	public void setAmount(double amount) {
		this.amount = amount;
	}
}
