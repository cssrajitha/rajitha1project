package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;
import java.util.List;

public class AccBundleBreackdownDetailsVO implements Serializable {

	private String brand;
	private String displayName;
	private int capacity;
	private String productID;
	//private String imageUrl;
	private List<AccBundleSkuDetailsVO> skuDetails;

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public String getProductID() {
		return productID;
	}

	public void setProductID(String productID) {
		this.productID = productID;
	}

	/*public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}*/

	public List<AccBundleSkuDetailsVO> getSkuDetails() {
		return skuDetails;
	}

	public void setSkuDetails(List<AccBundleSkuDetailsVO> skuDetails) {
		this.skuDetails = skuDetails;
	}
}
