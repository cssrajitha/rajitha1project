package onevz.soe.prepay.adaptor.cart.model.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

/**
 * Holds the Errors
 */
@Data
public class Errors {
	
	@JsonInclude(Include.NON_NULL)
	@JsonProperty(value = "details")
	private List<ErrorDetails> detailList;

	@JsonInclude(Include.NON_NULL)
	@JsonProperty(value = "namespace")
	private String namespace;

	@JsonInclude(Include.NON_NULL)
	@JsonProperty(value = "id")
	private String id;
	
	@JsonInclude(Include.NON_NULL)
	@JsonProperty(value = "message")
	private String message;
	
	@JsonInclude(Include.NON_NULL)
	@JsonProperty(value = "debug_id")
	private String debug_id;
	
	@JsonInclude(Include.NON_NULL)
	@JsonProperty(value = "name")
	private String name;
	
	@JsonInclude(Include.NON_NULL)
	@JsonProperty(value = "code")
	private String code;
	
	@JsonInclude(Include.NON_NULL)
	@JsonProperty(value = "type")
	private String type;


}
