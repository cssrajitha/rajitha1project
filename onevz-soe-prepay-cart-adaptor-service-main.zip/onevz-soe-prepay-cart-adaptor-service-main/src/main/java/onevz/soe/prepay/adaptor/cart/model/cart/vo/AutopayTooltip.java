package onevz.soe.prepay.adaptor.cart.model.cart.vo;

import java.io.Serializable;

public class AutopayTooltip implements Serializable {
    private static final long serialVersionUID = 1L;


    private String toolTipMessage;
    private String toolTipOverlayMessage;

    public String getToolTipMessage() {
        return toolTipMessage;
    }

    public void setToolTipMessage(String toolTipMessage) {
        this.toolTipMessage = toolTipMessage;
    }

    public String getToolTipOverlayMessage() {
        return toolTipOverlayMessage;
    }

    public void setToolTipOverlayMessage(String toolTipOverlayMessage) {
        this.toolTipOverlayMessage = toolTipOverlayMessage;
    }
}
