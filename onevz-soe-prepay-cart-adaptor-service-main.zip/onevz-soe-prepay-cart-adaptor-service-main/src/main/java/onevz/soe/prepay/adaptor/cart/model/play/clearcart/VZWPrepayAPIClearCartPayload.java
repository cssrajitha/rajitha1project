package onevz.soe.prepay.adaptor.cart.model.play.clearcart;

import lombok.Data;
import onevz.soe.prepay.adaptor.cart.model.cart.CQContent;


@Data
public class VZWPrepayAPIClearCartPayload {
    private CQContent cqContent;
    private VZWPrepayAddOrUpdateCartResponse pageData;
    

}
