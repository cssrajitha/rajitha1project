package onevz.soe.prepay.adaptor.cart.model.cart.vo;

/**
 * Created by w638278 on 1/17/2018.
 */
public class ProcessApplePaymentPaymentData {

    String onlinePaymentCryptogram;
    String eciIndicator;

    public String getOnlinePaymentCryptogram() {
        return onlinePaymentCryptogram;
    }

    public void setOnlinePaymentCryptogram(String onlinePaymentCryptogram) {
        this.onlinePaymentCryptogram = onlinePaymentCryptogram;
    }

    public String getEciIndicator() {
        return eciIndicator;
    }

    public void setEciIndicator(String eciIndicator) {
        this.eciIndicator = eciIndicator;
    }
}
