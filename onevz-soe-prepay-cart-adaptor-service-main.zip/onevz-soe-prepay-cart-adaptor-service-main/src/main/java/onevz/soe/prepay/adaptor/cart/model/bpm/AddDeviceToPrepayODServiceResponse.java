package onevz.soe.prepay.adaptor.cart.model.bpm;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import onevz.soe.cart.model.addDevice.AddDeviceContext;
import onevz.soe.wsclient.bpm.model.response.ServiceResponse;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(callSuper=true)
public class AddDeviceToPrepayODServiceResponse extends ServiceResponse {

	@JsonInclude(Include.NON_NULL)
	@JsonProperty(value = "context")
	private AddDeviceContext context;

	@JsonInclude(Include.NON_NULL)
	@JsonProperty(value = "prepaidODAddDevicesResponse")
	private List<AddDeviceToPrepayODAddDeviceResponse> prepaidODAddDevicesResponse;

	@JsonInclude(Include.NON_NULL)
	@JsonProperty(value = "prepaidODAddAccessoriesResponse")
	private AddDeviceToPrepayODAddAccessoriesResponse prepaidODAddAccessoriesResponse;



}
