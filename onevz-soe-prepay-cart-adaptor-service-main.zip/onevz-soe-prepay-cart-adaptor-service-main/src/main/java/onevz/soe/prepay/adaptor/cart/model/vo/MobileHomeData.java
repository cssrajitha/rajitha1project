package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;

public class MobileHomeData implements Serializable {
    private String accessToken;
    private String issuedAt;
    private String expiresIn;
    private String prospectCsrfToken;
    private String shopPath;
    private String areaCode;

    public String getShopPath() {
        return shopPath;
    }

    public void setShopPath(String shopPath) {
        this.shopPath = shopPath;
    }

    public String getAreaCode() {
        return areaCode;
    }

    public void setAreaCode(String areaCode) {
        this.areaCode = areaCode;
    }

    public String getProspectCsrfToken() {
        return prospectCsrfToken;
    }

    public void setProspectCsrfToken(String prospectCsrfToken) {
        this.prospectCsrfToken = prospectCsrfToken;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getIssuedAt() {
        return issuedAt;
    }

    public void setIssuedAt(String issuedAt) {
        this.issuedAt = issuedAt;
    }

    public String getExpiresIn() {
        return expiresIn;
    }

    public void setExpiresIn(String expiresIn) {
        this.expiresIn = expiresIn;
    }
}
