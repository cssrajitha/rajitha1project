package onevz.soe.prepay.adaptor.cart.model.cart.removelines;


import onevz.soe.prepay.adaptor.cart.model.vo.DeviceLineItem;

import java.util.List;

public class RemoveLineItemsResponse   {

    private String orderId;
    private boolean orderUpdated;

    private List<DeviceLineItem> deviceLineItemInfo;

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public boolean isOrderUpdated() {
        return orderUpdated;
    }

    public void setOrderUpdated(boolean orderUpdated) {
        this.orderUpdated = orderUpdated;
    }

    public List<DeviceLineItem> getDeviceLineItemInfo() {
        return deviceLineItemInfo;
    }

    public void setDeviceLineItemInfo(List<DeviceLineItem> deviceLineItemInfo) {
        this.deviceLineItemInfo = deviceLineItemInfo;
    }
}
