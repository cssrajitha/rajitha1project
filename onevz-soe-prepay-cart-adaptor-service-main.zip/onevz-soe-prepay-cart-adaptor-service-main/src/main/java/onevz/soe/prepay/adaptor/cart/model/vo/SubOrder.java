/**
 * 
 */
package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;


/**
 *
 */
public class SubOrder implements Serializable {

	
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	private String subOrderId;
	
	private Boolean taxCalculated;
	
	private String clientOrderType;
	
	private Boolean creditWriteValidated;
	
	private String clientReferenceNumber;
	
	private String creditApplicationNumber;
	
	private String posOrderNumber;
	
	private String suborderType;
	
	private String subOrderStatus;
	
	private Date lastModifiedDate;
	
	private Date createdDate;
	
	private String orderId;
	
	private int version;
	
	private String creditApplicationNum;
	
	private String transactionId;

	private String creditApprovalStatus;

	private double securityDepositAmount;

	private String creditStatusReason;
	private String serviceClass;
	private String internationalEligibilityCheck;
	private boolean creditReadValidated;
	private String clusterInfo;
	private String outletId;
	private String cartType;
	private double dueToday;

	public short getPaymentSequenceNumber() {
		return paymentSequenceNumber;
	}

	public void setPaymentSequenceNumber(short paymentSequenceNumber) {
		this.paymentSequenceNumber = paymentSequenceNumber;
	}

	private short paymentSequenceNumber;

	public String getFullAuthFlag() {
		return fullAuthFlag;
	}

	public void setFullAuthFlag(String fullAuthFlag) {
		this.fullAuthFlag = fullAuthFlag;
	}

	private String fullAuthFlag;
	public double getDueToday() {
		return dueToday;
	}

	public void setDueToday(double dueToday) {
		this.dueToday = dueToday;
	}

	public Map<String, Double> getPaymentTypePaymentAmountMap() {
		return paymentTypePaymentAmountMap;
	}

	public void setPaymentTypePaymentAmountMap(Map<String, Double> paymentTypePaymentAmountMap) {
		this.paymentTypePaymentAmountMap = paymentTypePaymentAmountMap;
	}

	private Map<String, Double> paymentTypePaymentAmountMap;
	/**
	 * @return the creditApplicationNum
	 */
	public String getCreditApplicationNum() {
		return creditApplicationNum;
	}

	/**
	 * @param creditApplicationNum the creditApplicationNum to set
	 */
	public void setCreditApplicationNum(String creditApplicationNum) {
		this.creditApplicationNum = creditApplicationNum;
	}

	public String getSubOrderId() {
		return subOrderId;
	}

	public void setSubOrderId(String subOrderId) {
		this.subOrderId = subOrderId;
	}

	public Boolean isTaxCalculated() {
		if(taxCalculated != null){
			return taxCalculated;
		}else{
			return false;
		}
	}

	public void setTaxCalculated(Boolean taxCalculated) {
		this.taxCalculated = taxCalculated;
	}

	public String getClientOrderType() {
		return clientOrderType;
	}

	public void setClientOrderType(String clientOrderType) {
		this.clientOrderType = clientOrderType;
	}

	public Boolean isCreditWriteValidated() {
		if(creditWriteValidated != null){
			return creditWriteValidated;
		}else{
			return false;
		}
	}

	public void setCreditWriteValidated(Boolean creditWriteValidated) {
		this.creditWriteValidated = creditWriteValidated;
	}

	public String getClientReferenceNumber() {
		return clientReferenceNumber;
	}

	public void setClientReferenceNumber(String clientReferenceNumber) {
		this.clientReferenceNumber = clientReferenceNumber;
	}

	public String getPosOrderNumber() {
		return posOrderNumber;
	}

	public void setPosOrderNumber(String posOrderNumber) {
		this.posOrderNumber = posOrderNumber;
	}

	public String getSuborderType() {
		return suborderType;
	}

	public void setSuborderType(String suborderType) {
		this.suborderType = suborderType;
	}

	public String getSubOrderStatus() {
		return subOrderStatus;
	}

	public void setSubOrderStatus(String subOrderStatus) {
		this.subOrderStatus = subOrderStatus;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public int getVersion() {
		return version;
	}

	public void updateVersion() {
		this.version += 1;
		this.setLastModifiedDate(Calendar.getInstance().getTime());
	}
	
	public String getCreditApplicationNumber() {
		return creditApplicationNumber;
	}

	public void setCreditApplicationNumber(String creditApplicationNumber) {
		this.creditApplicationNumber = creditApplicationNumber;
	}
	
	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getCreditApprovalStatus() {
		return creditApprovalStatus;
	}

	public void setCreditApprovalStatus(String creditApprovalStatus) {
		this.creditApprovalStatus = creditApprovalStatus;
	}

	public double getSecurityDepositAmount() {
		return securityDepositAmount;
	}

	public void setSecurityDepositAmount(double securityDepositAmount) {
		this.securityDepositAmount = securityDepositAmount;
	}

	public String getCreditStatusReason() {
		return creditStatusReason;
	}

	public void setCreditStatusReason(String creditStatusReason) {
		this.creditStatusReason = creditStatusReason;
	}

	public String getInternationalEligibilityCheck() {
		return internationalEligibilityCheck;
	}

	public void setInternationalEligibilityCheck(String internationalEligibilityCheck) {
		this.internationalEligibilityCheck = internationalEligibilityCheck;
	}

	public String getServiceClass() {
		return serviceClass;
	}

	public void setServiceClass(String serviceClass) {
		this.serviceClass = serviceClass;
	}

	public boolean isCreditReadValidated() {
		return creditReadValidated;
	}

	public void setCreditReadValidated(boolean creditReadValidated) {
		this.creditReadValidated = creditReadValidated;
	}

	public String getClusterInfo() {
		return clusterInfo;
	}

	public void setClusterInfo(String clusterInfo) {
		this.clusterInfo = clusterInfo;
	}

	public String getOutletId() {
		return outletId;
	}

	public void setOutletId(String outletId) {
		this.outletId = outletId;
	}

	public String getCartType() {
		return cartType;
	}

	public void setCartType(String cartType) {
		this.cartType = cartType;
	}

}
