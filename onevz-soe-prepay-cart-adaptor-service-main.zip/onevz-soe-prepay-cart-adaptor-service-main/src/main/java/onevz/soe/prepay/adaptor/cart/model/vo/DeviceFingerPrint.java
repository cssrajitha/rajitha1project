package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;
import java.util.List;

public class DeviceFingerPrint implements Serializable {

    private HttpRequestHeaders httpRequestHeaders;
    private String touchSupport;
    private String listOfInstalledFonts;
    private List<String> listOfMimeTypes;
    private String cookieStatus;
    private ScreenResolution screenResolution;

    public DeviceFingerPrint(){

    }

    public DeviceFingerPrint(ScreenResolution screenResolution, String touchSupport, String listOfInstalledFonts, List<String> listOfMimeTypes, String cookieStatus) {
        this.screenResolution = screenResolution;
        this.touchSupport = touchSupport;
        this.listOfInstalledFonts = listOfInstalledFonts;
        this.listOfMimeTypes = listOfMimeTypes;
        this.cookieStatus = cookieStatus;
    }

    public HttpRequestHeaders getHttpRequestHeaders() {
        return httpRequestHeaders;
    }

    public void setHttpRequestHeaders(HttpRequestHeaders httpRequestHeaders) {
        this.httpRequestHeaders = httpRequestHeaders;
    }

    public String getTouchSupport() {
        return touchSupport;
    }

    public void setTouchSupport(String touchSupport) {
        this.touchSupport = touchSupport;
    }

    public String getListOfInstalledFonts() {
        return listOfInstalledFonts;
    }

    public void setListOfInstalledFonts(String listOfInstalledFonts) {
        this.listOfInstalledFonts = listOfInstalledFonts;
    }

    public String getCookieStatus() {
        return cookieStatus;
    }

    public void setCookieStatus(String cookieStatus) {
        this.cookieStatus = cookieStatus;
    }

    public ScreenResolution getScreenResolution() {
        return screenResolution;
    }

    public void setScreenResolution(ScreenResolution screenResolution) {
        this.screenResolution = screenResolution;
    }

    public List<String> getListOfMimeTypes() {
        return listOfMimeTypes;
    }

    public void setListOfMimeTypes(List<String> listOfMimeTypes) {
        this.listOfMimeTypes = listOfMimeTypes;
    }

}
