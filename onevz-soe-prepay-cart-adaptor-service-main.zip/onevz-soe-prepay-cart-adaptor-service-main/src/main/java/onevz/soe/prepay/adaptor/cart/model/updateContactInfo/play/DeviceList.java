package onevz.soe.prepay.adaptor.cart.model.updateContactInfo.play;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class DeviceList {
    private String rawTotalAmount;

    private String itemType;

    private String color;

    private String accountMember;

    private TaxDetails taxDetails;

    private String autoPaymentEligible;

    private String simDisplayName;

    private String seoName;

    private String capacity;

    private String inlinePromo;

    private String existingDevice;

    private String totalDueMonthly;

    private String fullRetailListPrice;

    private String activationFee;

    private String purchasePath;

    private String itemAmount;

    private String imageUrl;

    private String sorId;

    private String id;

    private String skuId;

    private String daccCode;

    private String brandName;

    private String quantity;

    private String deviceSorType;

    private String productId;

    private String trialStatus;

    private String miniImageUrl;

    private String accountOwner;

    private String npaNxxCode;

    private String planItemId;

    private String deviceTax;

    private String portInDevice;

    private String skuDisplayName;

    private String listPrice;

    private String totalDueToday;
}

