package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

/**
 * Created by vkashe on 8/17/2017.
 */
public class DevicePaymentConfig implements Serializable {

    private static final long serialVersionUID = 1L;

    String configId;
    Integer term;
    Integer percentage;
    Date startDate;
    Date endDate;
    String upgradeOptionCode;
    String description;
    Set<DevicePaymentCategoryType> devicePaymentCategoryType;

    public String getConfigId() {
        return configId;
    }

    public void setConfigId(String configId) {
        this.configId = configId;
    }

    public Integer getTerm() {
        return term;
    }

    public void setTerm(Integer term) {
        this.term = term;
    }

    public Integer getPercentage() {
        return percentage;
    }

    public void setPercentage(Integer percentage) {
        this.percentage = percentage;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getUpgradeOptionCode() {
        return upgradeOptionCode;
    }

    public void setUpgradeOptionCode(String upgradeOptionCode) {
        this.upgradeOptionCode = upgradeOptionCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Set<DevicePaymentCategoryType> getDevicePaymentCategoryType() {
        return devicePaymentCategoryType;
    }

    public void setDevicePaymentCategoryType(Set<DevicePaymentCategoryType> devicePaymentCategoryType) {
        this.devicePaymentCategoryType = devicePaymentCategoryType;
    }
}
