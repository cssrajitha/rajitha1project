package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

@Data
public class PaymentStatus implements Serializable {


	private String mTransactionId = null;

	private double mAmount = 0.0D;

	private boolean mTransactionSuccess = false;

	private String mErrorMessage = null;

	private Date mTransactionTimestamp = null;

	private Date mAuthorizationExpiration = null;

	private String mAvsCode = null;

	private String mAvsDescriptiveResult = null;

	private String appCode = null;
	private String cvvCode = null;
	private String statusCode = null;

	/**
	 * @return the mTransactionId
	 */
	public String getTransactionId() {
		return mTransactionId;
	}

	/**
	 * @param pTransactionId the mTransactionId to set
	 */
	public void setTransactionId(String pTransactionId) {
		this.mTransactionId = pTransactionId;
	}

	/**
	 * @return the mAmount
	 */
	public double getAmount() {
		return mAmount;
	}

	/**
	 * @param mAmount the mAmount to set
	 */
	public void setAmount(double mAmount) {
		this.mAmount = mAmount;
	}

	/**
	 * @return the mTransactionSuccess
	 */
	public boolean isTransactionSuccess() {
		return mTransactionSuccess;
	}

	/**
	 * @param mTransactionSuccess the mTransactionSuccess to set
	 */
	public void setTransactionSuccess(boolean pTransactionSuccess) {
		this.mTransactionSuccess = pTransactionSuccess;
	}

	/**
	 * @return the mErrorMessage
	 */
	public String getErrorMessage() {
		return mErrorMessage;
	}

	/**
	 * @param pErrorMessage the mErrorMessage to set
	 */
	public void setErrorMessage(String pErrorMessage) {
		this.mErrorMessage = pErrorMessage;
	}

	/**
	 * @return the mTransactionTimestamp
	 */
	public Date getTransactionTimestamp() {
		return mTransactionTimestamp;
	}

	/**
	 * @param pTransactionTimestamp the mTransactionTimestamp to set
	 */
	public void setTransactionTimestamp(Date pTransactionTimestamp) {
		this.mTransactionTimestamp = pTransactionTimestamp;
	}

	/**
	 * @return the mAuthorizationExpiration
	 */
	public Date getAuthorizationExpiration() {
		return mAuthorizationExpiration;
	}

	/**
	 * @param pAuthorizationExpiration the mAuthorizationExpiration to set
	 */
	public void setAuthorizationExpiration(Date pAuthorizationExpiration) {
		this.mAuthorizationExpiration = pAuthorizationExpiration;
	}

	/**
	 * @return the mAvsCode
	 */
	public String getAvsCode() {
		return mAvsCode;
	}

	/**
	 * @param pAvsCode the mAvsCode to set
	 */
	public void setAvsCode(String pAvsCode) {
		this.mAvsCode = pAvsCode;
	}

	/**
	 * @return the mAvsDescriptiveResult
	 */
	public String getAvsDescriptiveResult() {
		return mAvsDescriptiveResult;
	}

	/**
	 * @param pAvsDescriptiveResult the mAvsDescriptiveResult to set
	 */
	public void setAvsDescriptiveResult(String pAvsDescriptiveResult) {
		this.mAvsDescriptiveResult = pAvsDescriptiveResult;
	}

	public String getAppCode() {
		return appCode;
	}

	public void setAppCode(String appCode) {
		this.appCode = appCode;
	}

	public String getCvvCode() {
		return cvvCode;
	}

	public void setCvvCode(String cvvCode) {
		this.cvvCode = cvvCode;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}



}
