
package onevz.soe.prepay.adaptor.cart.model.cart.vo;

import com.fasterxml.jackson.annotation.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "paymentGrpIdList",
    "remainingDue"
})
@Data
@Getter
@Setter
public class RefillCardDetailsVO {

    @JsonProperty("paymentGrpIdList")
    private List<Object> paymentGrpIdList = null;
    @JsonProperty("remainingDue")
    private Double remainingDue;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<>();
    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
