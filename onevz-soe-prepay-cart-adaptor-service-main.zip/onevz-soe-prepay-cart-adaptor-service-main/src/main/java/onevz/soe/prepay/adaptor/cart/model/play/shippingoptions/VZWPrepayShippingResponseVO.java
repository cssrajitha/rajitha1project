package onevz.soe.prepay.adaptor.cart.model.play.shippingoptions;

import java.io.Serializable;
import java.util.List;

public class VZWPrepayShippingResponseVO implements Serializable {
    private static final long serialVersionUID = 1L;
    private String orderId;
    private List<ShippingOption> shippingOption ;

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public List<ShippingOption> getShippingOption() {
        return shippingOption;
    }

    public void setShippingOption(List<ShippingOption> shippingOption) {
        this.shippingOption = shippingOption;
    }
}
