package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;

public class BillToAccount extends PaymentGroup implements Serializable {
	
	private static final long serialVersionUID = -559007903627077408L;

	private boolean btaEligible;
	private String accountNumber;
	private double btaAmntLimit;
	private double btaAmntRemaining;
	private double btaAmntMinusCurrentOrder;
	
	public boolean isBtaEligible() {
		return btaEligible;
	}

	public void setBtaEligible(boolean btaEligible) {
		this.btaEligible = btaEligible;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public double getBtaAmntLimit() {
		return btaAmntLimit;
	}

	public void setBtaAmntLimit(double btaAmntLimit) {
		this.btaAmntLimit = btaAmntLimit;
	}

	public double getBtaAmntRemaining() {
		return btaAmntRemaining;
	}

	public void setBtaAmntRemaining(double btaAmntRemaining) {
		this.btaAmntRemaining = btaAmntRemaining;
	}

	public double getBtaAmntMinusCurrentOrder() {
		return btaAmntMinusCurrentOrder;
	}

	public void setBtaAmntMinusCurrentOrder(double btaAmntMinusCurrentOrder) {
		this.btaAmntMinusCurrentOrder = btaAmntMinusCurrentOrder;
	}
}
