package onevz.soe.prepay.adaptor.cart.model.vo;


import java.io.Serializable;

public class EmvPayment extends PaymentGroup implements Serializable{

	/**
	 *
	 */
	private static final long serialVersionUID = -559007903627077408L;

	private String entryMode;
	private String emvFallback;
	private String fallbackEntryMode;
	private String emvDevice;
	private String emvApplicationID;
	private String pinEntryStatus;
	private String cardPin;
	private String pinKeySerialNumber;
	private String encryptedCardData;
	private String encryptedCardData2;
	private String encryptType;
	private boolean emvContactless;
	private String paymentAmount;
	private String paymentType;
	private String applicationTransactionCounter;
	private boolean isEncrypted;
	private String replyBack;
	private String hostDecision;
	private String displayResults;
	private short paySeqNum;
	private String acquirerReferenceData;
	private EmvRequest emvRequest;

	public String getAcquirerReferenceData() {
		return acquirerReferenceData;
	}

	public void setAcquirerReferenceData(String acquirerReferenceData) {
		this.acquirerReferenceData = acquirerReferenceData;
	}

	public String getEntryMode() {
		return entryMode;
	}

	public void setEntryMode(String entryMode) {
		this.entryMode = entryMode;
	}

	public String getEmvFallback() {
		return emvFallback;
	}

	public void setEmvFallback(String emvFallback) {
		this.emvFallback = emvFallback;
	}

	public String getFallbackEntryMode() {
		return fallbackEntryMode;
	}

	public void setFallbackEntryMode(String fallbackEntryMode) {
		this.fallbackEntryMode = fallbackEntryMode;
	}

	public String getEmvDevice() {
		return emvDevice;
	}

	public void setEmvDevice(String emvDevice) {
		this.emvDevice = emvDevice;
	}

	public String getEmvApplicationID() {
		return emvApplicationID;
	}

	public void setEmvApplicationID(String emvApplicationID) {
		this.emvApplicationID = emvApplicationID;
	}

	public String getPinEntryStatus() {
		return pinEntryStatus;
	}

	public void setPinEntryStatus(String pinEntryStatus) {
		this.pinEntryStatus = pinEntryStatus;
	}

	public String getCardPin() {
		return cardPin;
	}

	public void setCardPin(String cardPin) {
		this.cardPin = cardPin;
	}

	public String getPinKeySerialNumber() {
		return pinKeySerialNumber;
	}

	public void setPinKeySerialNumber(String pinKeySerialNumber) {
		this.pinKeySerialNumber = pinKeySerialNumber;
	}

	public String getEncryptedCardData() {
		return encryptedCardData;
	}

	public void setEncryptedCardData(String encryptedCardData) {
		this.encryptedCardData = encryptedCardData;
	}

	public String getEncryptedCardData2() {
		return encryptedCardData2;
	}

	public void setEncryptedCardData2(String encryptedCardData2) {
		this.encryptedCardData2 = encryptedCardData2;
	}

	public String getEncryptType() {
		return encryptType;
	}

	public void setEncryptType(String encryptType) {
		this.encryptType = encryptType;
	}

	public boolean isEmvContactless() {
		return emvContactless;
	}

	public void setEmvContactless(boolean emvContactless) {
		this.emvContactless = emvContactless;
	}

	public String getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(String paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getApplicationTransactionCounter() {
		return applicationTransactionCounter;
	}

	public void setApplicationTransactionCounter(String applicationTransactionCounter) {
		this.applicationTransactionCounter = applicationTransactionCounter;
	}

	public boolean isEncrypted() {
		return isEncrypted;
	}

	public void setEncrypted(boolean encrypted) {
		isEncrypted = encrypted;
	}

	public String getReplyBack() {
		return replyBack;
	}

	public void setReplyBack(String replyBack) {
		this.replyBack = replyBack;
	}

	public String getHostDecision() {
		return hostDecision;
	}

	public void setHostDecision(String hostDecision) {
		this.hostDecision = hostDecision;
	}

	public String getDisplayResults() {
		return displayResults;
	}

	public void setDisplayResults(String displayResults) {
		this.displayResults = displayResults;
	}

	public EmvRequest getEmvRequest() {
		return emvRequest;
	}

	public void setEmvRequest(EmvRequest emvRequest) {
		this.emvRequest = emvRequest;
	}

	public short getPaySeqNum() {
		return paySeqNum;
	}

	public void setPaySeqNum(short paySeqNum) {
		this.paySeqNum = paySeqNum;
	}
}
