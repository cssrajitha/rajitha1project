package onevz.soe.prepay.adaptor.cart.model.cart.removelines;

import java.util.List;

public class RemoveLineItem {

    private List<String> linesToRemove;

    public List<String> getLinesToRemove() {
        return linesToRemove;
    }

    public void setLinesToRemove(List<String> linesToRemove) {
        this.linesToRemove = linesToRemove;
    }
}
