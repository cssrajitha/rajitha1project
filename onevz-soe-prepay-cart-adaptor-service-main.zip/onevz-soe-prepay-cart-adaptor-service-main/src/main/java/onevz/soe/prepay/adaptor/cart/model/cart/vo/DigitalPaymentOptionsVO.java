
package onevz.soe.prepay.adaptor.cart.model.cart.vo;

import com.fasterxml.jackson.annotation.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "applepayEnabled",
    "applePayMerchantId",
    "paypalEnabled"
})
@Data
@Getter
@Setter
public class DigitalPaymentOptionsVO {

    @JsonProperty("applepayEnabled")
    private Boolean applepayEnabled;
    @JsonProperty("applePayMerchantId")
    private String applePayMerchantId;
    @JsonProperty("paypalEnabled")
    private Boolean paypalEnabled;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<>();
    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
