package onevz.soe.prepay.adaptor.cart.model.play.shippingoptions;

import lombok.Data;

@Data
public class VZWPrepayShippingOptionsResponsePayload {
    private VZWPrepayShippingResponseVO pageData;
}
