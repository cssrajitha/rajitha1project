package onevz.soe.prepay.adaptor.cart.model.play.common.error;

import java.io.Serializable;

public class HomeSafetyInfo implements Serializable {

    private String isRingDeviceRistricted;
    private String header;
    private String subHeader;
    private String goToLink;

    public String getIsRingDeviceRistricted() {
        return isRingDeviceRistricted;
    }

    public void setIsRingDeviceRistricted(String isRingDeviceRistricted) {
        this.isRingDeviceRistricted = isRingDeviceRistricted;
    }

    public String getHeader() {
        return header;
    }

    public void setHeader(String header) {
        this.header = header;
    }

    public String getSubHeader() {
        return subHeader;
    }

    public void setSubHeader(String subHeader) {
        this.subHeader = subHeader;
    }

    public String getGoToLink() {
        return goToLink;
    }

    public void setGoToLink(String goToLink) {
        this.goToLink = goToLink;
    }
}
