package onevz.soe.prepay.adaptor.cart.model.cart.vo;


import com.fasterxml.jackson.annotation.JsonInclude;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class PrepayCartVO implements Serializable {
    private static final long serialVersionUID = 1L;

    private int status;
    private String orderId;
    private double orderTotal;
    private double orderTax;
    private double orderDiscount;
    private double monthlySavings;
    private String orderZipcode;
    private double dueMonthly;
    private double dueToday;
    private String flow;
    private double totalActivationfee;
    private String sessionId;
    private List<PrepayDeviceVO> deviceList;
    private List<PrepayPlanVO> planList;
    private List<PrepayFeatureVO> featureList;
    private List<PrepayTaxVO> taxDetailList;
    private AccountInfoVO accountInfo;
    private double todaySavings;
    private int linesCount;
    private int cartCount;
    private boolean accountOwnerUpdate;
    private String itemType;
    private int maxDeviceLimit;
    private int accountDeviceLimit;
    private Set<VZWPrepayPromotion> promotions;
    private boolean promoAdded;
    private Map<String, String> digitalPaymentOptions;
    private boolean taxPromoEnabled;
    private boolean deviceFingerPrintEnabled;
    private double planDueMonthly;

    private int maxCartLimit;

    private String trialStatus;

    private boolean is5G_EWB_Device;
    private boolean nseNsoFlag;
    private boolean isMOT;
    private double accumulateInlineDiscount;
    private String inlinePromotionMessage;

    private String lineItemIdToChangePLan;

    public String getLineItemIdToChangePLan() {
        return lineItemIdToChangePLan;
    }
    public void setLineItemIdToChangePLan(String lineItemIdToChangePLan) {
        this.lineItemIdToChangePLan = lineItemIdToChangePLan;
    }
    private boolean holidayPolicyEnable;


    public boolean isHolidayPolicyEnable() {
        return holidayPolicyEnable;
    }

    public void setHolidayPolicyEnable(boolean holidayPolicyEnable) {
        this.holidayPolicyEnable = holidayPolicyEnable;
    }


    public double getAccumulateInlineDiscount() {
        return accumulateInlineDiscount;
    }

    public void setAccumulateInlineDiscount(double accumulateInlineDiscount) {
        this.accumulateInlineDiscount = accumulateInlineDiscount;
    }

    public String getInlinePromotionMessage() {
        return inlinePromotionMessage;
    }

    public void setInlinePromotionMessage(String inlinePromotionMessage) {
        this.inlinePromotionMessage = inlinePromotionMessage;
    }

    public boolean isMOT() {
        return isMOT;
    }

    public void setMOT(boolean MOT) {
        isMOT = MOT;
    }

    public boolean isNseNsoFlag() {
        return nseNsoFlag;
    }

    public void setNseNsoFlag(boolean nseNsoFlag) {
        this.nseNsoFlag = nseNsoFlag;
    }

    public String getTrialStatus() {
        return trialStatus;
    }

    public void setTrialStatus(String trialStatus) {
        this.trialStatus = trialStatus;
    }

    public int getMaxDeviceLimit() {
        return maxDeviceLimit;
    }

    public void setMaxDeviceLimit(int maxDeviceLimit) {
        this.maxDeviceLimit = maxDeviceLimit;
    }

    public String getItemType() {
        return itemType;
    }

    public void setItemType(String itemType) {
        this.itemType = itemType;
    }

    public boolean isAccountOwnerUpdate() {
        return accountOwnerUpdate;
    }

    public void setAccountOwnerUpdate(boolean accountOwnerUpdate) {
        this.accountOwnerUpdate = accountOwnerUpdate;
    }

    public double getTodaySavings() {
        return todaySavings;
    }

    public void setTodaySavings(double todaySavings) {
        this.todaySavings = todaySavings;
    }

    private HashMap<String,Double> shippingDetails;

    public double getMonthlySavings() {
        return monthlySavings;
    }

    public void setMonthlySavings(double monthlySavings) {
        this.monthlySavings = monthlySavings;
    }

    public String getNextDueDate() {
        return nextDueDate;
    }

    public void setNextDueDate(String nextDueDate) {
        this.nextDueDate = nextDueDate;
    }

    private String nextDueDate;

    public double getDueNextCycle() {
        return dueNextCycle;
    }

    public void setDueNextCycle(double dueNextCycle) {
        this.dueNextCycle = dueNextCycle;
    }

    private double dueNextCycle;

    public HashMap<String, Double> getShippingDetails() {
        return shippingDetails;
    }

    public void setShippingDetails(HashMap<String, Double> shippingDetails) {
        this.shippingDetails = shippingDetails;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public double getOrderTotal() {
        return orderTotal;
    }

    public void setOrderTotal(double orderTotal) {
        this.orderTotal = orderTotal;
    }

    public double getOrderTax() {
        return orderTax;
    }

    public void setOrderTax(double orderTax) {
        this.orderTax = orderTax;
    }

    public double getOrderDiscount() {
        return orderDiscount;
    }

    public void setOrderDiscount(double orderDiscount) {
        this.orderDiscount = orderDiscount;
    }

    public String getOrderZipcode() {
        return orderZipcode;
    }

    public void setOrderZipcode(String orderZipcode) {
        this.orderZipcode = orderZipcode;
    }

    public double getDueMonthly() {
        return dueMonthly;
    }

    public void setDueMonthly(double dueMonthly) {
        this.dueMonthly = dueMonthly;
    }

    public double getPlanDueMonthly() {
        return planDueMonthly;
    }

    public void setPlanDueMonthly(double planDueMonthly) {
        this.planDueMonthly = planDueMonthly;
    }
    public double getDueToday() {
        return dueToday;
    }

    public void setDueToday(double dueToday) {
        this.dueToday = dueToday;
    }

    public String getFlow() {
        return flow;
    }

    public void setFlow(String flow) {
        this.flow = flow;
    }

    public double getTotalActivationfee() {
        return totalActivationfee;
    }

    public void setTotalActivationfee(double totalActivationfee) {
        this.totalActivationfee = totalActivationfee;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public List<PrepayDeviceVO> getDeviceList() {
        return deviceList;
    }

    public void setDeviceList(List<PrepayDeviceVO> deviceList) {
        this.deviceList = deviceList;
    }

    public List<PrepayFeatureVO> getFeatureList() {
        return featureList;
    }

    public void setFeatureList(List<PrepayFeatureVO> featureList) {
        this.featureList = featureList;
    }

    public List<PrepayPlanVO> getPlanList() {
        return planList;
    }

    public void setPlanList(List<PrepayPlanVO> planList) {
        this.planList = planList;
    }

    public AccountInfoVO getAccountInfo() {
        return accountInfo;
    }

    public void setAccountInfo(AccountInfoVO accountInfo) {
        this.accountInfo = accountInfo;
    }

    public int getLinesCount() {
        return linesCount;
    }

    public void setLinesCount(int linesCount) {
        this.linesCount = linesCount;
    }

    public int getCartCount() {
        return cartCount;
    }

    public void setCartCount(int cartCount) {
        this.cartCount = cartCount;
    }

    public List<PrepayTaxVO> getTaxDetailList() {
        return taxDetailList;
    }

    public void setTaxDetailList(List<PrepayTaxVO> taxDetailList) {
        this.taxDetailList = taxDetailList;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getAccountDeviceLimit() {
        return accountDeviceLimit;
    }

    public void setAccountDeviceLimit(int accountDeviceLimit) {
        this.accountDeviceLimit = accountDeviceLimit;
    }

    public int getMaxCartLimit() {
        return maxCartLimit;
    }

    public void setMaxCartLimit(int maxCartLimit) {
        this.maxCartLimit = maxCartLimit;
    }

    public Set<VZWPrepayPromotion> getPromotions() {
        return promotions;
    }

    public void setPromotions(Set<VZWPrepayPromotion> promotions) {
        this.promotions = promotions;
    }

    public boolean isPromoAdded() {
        return promoAdded;
    }

    public void setPromoAdded(boolean promoAdded) {
        this.promoAdded = promoAdded;
    }

    public boolean isTaxPromoEnabled() {
        return taxPromoEnabled;
    }

    public void setTaxPromoEnabled(boolean taxPromoEnabled) {
        this.taxPromoEnabled = taxPromoEnabled;
    }

    public boolean isDeviceFingerPrintEnabled() {
        return deviceFingerPrintEnabled;
    }

    public void setDeviceFingerPrintEnabled(boolean deviceFingerPrintEnabled) {
        this.deviceFingerPrintEnabled = deviceFingerPrintEnabled;
    }

    public Map<String, String> getDigitalPaymentOptions() {
        return digitalPaymentOptions;
    }

    public void setDigitalPaymentOptions(Map<String, String> digitalPaymentOptions) {
        this.digitalPaymentOptions = digitalPaymentOptions;
    }

    public boolean isIs5G_EWB_Device() {
        return is5G_EWB_Device;
    }

    public void setIs5G_EWB_Device(boolean is5G_EWB_Device) {
        this.is5G_EWB_Device = is5G_EWB_Device;
    }
	
	private boolean offerDataToBeShowed;
	
	 public boolean isOfferDataToBeShowed() {
        return offerDataToBeShowed;
    }

    public void setOfferDataToBeShowed(boolean offerDataToBeShowed) {
        this.offerDataToBeShowed = offerDataToBeShowed;
    }

}
