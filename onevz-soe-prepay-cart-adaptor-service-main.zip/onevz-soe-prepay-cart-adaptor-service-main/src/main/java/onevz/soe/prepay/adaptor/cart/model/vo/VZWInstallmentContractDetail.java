package onevz.soe.prepay.adaptor.cart.model.vo;

import java.io.Serializable;
import java.math.BigInteger;

/**
 * Created by gumapa on 6/23/2017.
 */
public class VZWInstallmentContractDetail implements Serializable{

    private static final long serialVersionUID = 1L;

    private String locationCode;
    private int creditApplicationNum;
    private BigInteger orderNum;
    private VZWInstallmentType installmentType;
    private String installmentLoanNumber;
    private String mobileNumber;
    private String itemCode;
    private String depletionType;
    private String creditClass;
    private String loanTerm;
    private String downPaymentAmount;
    private String firstMonthPaymentAmount;
    private String balanceLoanAmount;
    private String mirAmount;
    private String taxBasis;
    private String taxAmount;
    private String financeChargeAmount;
    private String financeChargedTaxAmount;
    private String deviceTaxPrice;
    private String loanStatus;
    private String mtnEffectiveDate;
    private String loanAmount;
    private String taxGroupID;
    private String taxItemID;
    private String productId;
    private String firstCollectedAmount;
    private String taxGeoAddressType;
    private String loanMonthlyPaymentAmount;
    private String loanTaxCollectedAmount;
    private String loanTaxableBaseAmount;
    private String downPaymentTaxCollectedAmount;
    private String loanTotalFinancialChargeAmount;
    private String financeChargedCollectedAmount;
    private String financeChargedTaxCollectedAmount;
    private String calculatedAPR;
    private String machineType;
    private String previousInstallmentLoanNumber;
    private VZWInstallmentPaymentSchedule installmentPaymentSchedule;
    private String firstmonthPaymentCollected;
    private String stateOverrideTaxBasisAmount;
    private String deviceTaxOnContract;
    private String agreementPercentage;
    private String upgradeOptionCode;
    private String upgradeDeviceCategoryText;

    private String taxOnContractForDisplay;

    private boolean mBtaTaxWaiveIndicator;

    public String getTaxOnContractForDisplay() {
        return taxOnContractForDisplay;
    }

    public void setTaxOnContractForDisplay(String taxOnContractForDisplay) {
        this.taxOnContractForDisplay = taxOnContractForDisplay;
    }


    public String getStateOverrideTaxBasisAmount() {
        return stateOverrideTaxBasisAmount;
    }

    public void setStateOverrideTaxBasisAmount(String stateOverrideTaxBasisAmount) {
        this.stateOverrideTaxBasisAmount = stateOverrideTaxBasisAmount;
    }

    /**
     * Gets the value of the locationCode property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getLocationCode() {
        return locationCode;
    }

    /**
     * Sets the value of the locationCode property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setLocationCode(String value) {
        this.locationCode = value;
    }

    /**
     * Gets the value of the creditApplicationNum property.
     *
     */
    public int getCreditApplicationNum() {
        return creditApplicationNum;
    }

    /**
     * Sets the value of the creditApplicationNum property.
     *
     */
    public void setCreditApplicationNum(int value) {
        this.creditApplicationNum = value;
    }

    /**
     * Gets the value of the orderNum property.
     *
     * @return
     *     possible object is
     *     {@link BigInteger }
     *
     */
    public BigInteger getOrderNum() {
        return orderNum;
    }

    /**
     * Sets the value of the orderNum property.
     *
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *
     */
    public void setOrderNum(BigInteger value) {
        this.orderNum = value;
    }

    /**
     * Gets the value of the installmentType property.
     *
     * @return
     *     possible object is
     *
     *
     */
    public VZWInstallmentType getInstallmentType() {
        return installmentType;
    }

    /**
     * Sets the value of the installmentType property.
     *
     * @param value
     *     allowed object is
     *
     *
     */
    public void setInstallmentType(VZWInstallmentType value) {
        this.installmentType = value;
    }

    /**
     * Gets the value of the installmentLoanNumber property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getInstallmentLoanNumber() {
        return installmentLoanNumber;
    }

    /**
     * Sets the value of the installmentLoanNumber property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setInstallmentLoanNumber(String value) {
        this.installmentLoanNumber = value;
    }

    /**
     * Gets the value of the mobileNumber property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getMobileNumber() {
        return mobileNumber;
    }

    /**
     * Sets the value of the mobileNumber property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setMobileNumber(String value) {
        this.mobileNumber = value;
    }

    /**
     * Gets the value of the itemCode property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getItemCode() {
        return itemCode;
    }

    /**
     * Sets the value of the itemCode property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setItemCode(String value) {
        this.itemCode = value;
    }

    /**
     * Gets the value of the depletionType property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getDepletionType() {
        return depletionType;
    }

    /**
     * Sets the value of the depletionType property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setDepletionType(String value) {
        this.depletionType = value;
    }

    /**
     * Gets the value of the creditClass property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getCreditClass() {
        return creditClass;
    }

    /**
     * Sets the value of the creditClass property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setCreditClass(String value) {
        this.creditClass = value;
    }

    /**
     * Gets the value of the loanTerm property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getLoanTerm() {
        return loanTerm;
    }

    /**
     * Sets the value of the loanTerm property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setLoanTerm(String value) {
        this.loanTerm = value;
    }

    /**
     * Gets the value of the downPaymentAmount property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getDownPaymentAmount() {
        return downPaymentAmount;
    }

    /**
     * Sets the value of the downPaymentAmount property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setDownPaymentAmount(String value) {
        this.downPaymentAmount = value;
    }

    /**
     * Gets the value of the firstMonthPaymentAmount property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getFirstMonthPaymentAmount() {
        return firstMonthPaymentAmount;
    }

    /**
     * Sets the value of the firstMonthPaymentAmount property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setFirstMonthPaymentAmount(String value) {
        this.firstMonthPaymentAmount = value;
    }

    /**
     * Gets the value of the balanceLoanAmount property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getBalanceLoanAmount() {
        return balanceLoanAmount;
    }

    /**
     * Sets the value of the balanceLoanAmount property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setBalanceLoanAmount(String value) {
        this.balanceLoanAmount = value;
    }

    /**
     * Gets the value of the mirAmount property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getMIRAmount() {
        return mirAmount;
    }

    /**
     * Sets the value of the mirAmount property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setMIRAmount(String value) {
        this.mirAmount = value;
    }

    /**
     * Gets the value of the taxBasis property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getTaxBasis() {
        return taxBasis;
    }

    /**
     * Sets the value of the taxBasis property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setTaxBasis(String value) {
        this.taxBasis = value;
    }

    /**
     * Gets the value of the taxAmount property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getTaxAmount() {
        return taxAmount;
    }

    /**
     * Sets the value of the taxAmount property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setTaxAmount(String value) {
        this.taxAmount = value;
    }

    /**
     * Gets the value of the financeChargeAmount property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getFinanceChargeAmount() {
        return financeChargeAmount;
    }

    /**
     * Sets the value of the financeChargeAmount property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setFinanceChargeAmount(String value) {
        this.financeChargeAmount = value;
    }

    /**
     * Gets the value of the financeChargedTaxAmount property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getFinanceChargedTaxAmount() {
        return financeChargedTaxAmount;
    }

    /**
     * Sets the value of the financeChargedTaxAmount property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setFinanceChargedTaxAmount(String value) {
        this.financeChargedTaxAmount = value;
    }

    /**
     * Gets the value of the deviceTaxPrice property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getDeviceTaxPrice() {
        return deviceTaxPrice;
    }

    /**
     * Sets the value of the deviceTaxPrice property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setDeviceTaxPrice(String value) {
        this.deviceTaxPrice = value;
    }

    /**
     * Gets the value of the loanStatus property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getLoanStatus() {
        return loanStatus;
    }

    /**
     * Sets the value of the loanStatus property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setLoanStatus(String value) {
        this.loanStatus = value;
    }

    /**
     * Gets the value of the mtnEffectiveDate property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getMtnEffectiveDate() {
        return mtnEffectiveDate;
    }

    /**
     * Sets the value of the mtnEffectiveDate property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setMtnEffectiveDate(String value) {
        this.mtnEffectiveDate = value;
    }

    /**
     * Gets the value of the loanAmount property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getLoanAmount() {
        return loanAmount;
    }

    /**
     * Sets the value of the loanAmount property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setLoanAmount(String value) {
        this.loanAmount = value;
    }

    /**
     * Gets the value of the taxGroupID property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getTaxGroupID() {
        return taxGroupID;
    }

    /**
     * Sets the value of the taxGroupID property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setTaxGroupID(String value) {
        this.taxGroupID = value;
    }

    /**
     * Gets the value of the taxItemID property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getTaxItemID() {
        return taxItemID;
    }

    /**
     * Sets the value of the taxItemID property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setTaxItemID(String value) {
        this.taxItemID = value;
    }

    /**
     * Gets the value of the productId property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getProductId() {
        return productId;
    }

    /**
     * Sets the value of the productId property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setProductId(String value) {
        this.productId = value;
    }

    /**
     * Gets the value of the firstCollectedAmount property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getFirstCollectedAmount() {
        return firstCollectedAmount;
    }

    /**
     * Sets the value of the firstCollectedAmount property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setFirstCollectedAmount(String value) {
        this.firstCollectedAmount = value;
    }

    /**
     * Gets the value of the taxGeoAddressType property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getTaxGeoAddressType() {
        return taxGeoAddressType;
    }

    /**
     * Sets the value of the taxGeoAddressType property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setTaxGeoAddressType(String value) {
        this.taxGeoAddressType = value;
    }

    /**
     * Gets the value of the loanMonthlyPaymentAmount property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getLoanMonthlyPaymentAmount() {
        return loanMonthlyPaymentAmount;
    }

    /**
     * Sets the value of the loanMonthlyPaymentAmount property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setLoanMonthlyPaymentAmount(String value) {
        this.loanMonthlyPaymentAmount = value;
    }

    /**
     * Gets the value of the loanTaxCollectedAmount property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getLoanTaxCollectedAmount() {
        return loanTaxCollectedAmount;
    }

    /**
     * Sets the value of the loanTaxCollectedAmount property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setLoanTaxCollectedAmount(String value) {
        this.loanTaxCollectedAmount = value;
    }

    /**
     * Gets the value of the loanTaxableBaseAmount property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getLoanTaxableBaseAmount() {
        return loanTaxableBaseAmount;
    }

    /**
     * Sets the value of the loanTaxableBaseAmount property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setLoanTaxableBaseAmount(String value) {
        this.loanTaxableBaseAmount = value;
    }

    /**
     * Gets the value of the downPaymentTaxCollectedAmount property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getDownPaymentTaxCollectedAmount() {
        return downPaymentTaxCollectedAmount;
    }

    /**
     * Sets the value of the downPaymentTaxCollectedAmount property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setDownPaymentTaxCollectedAmount(String value) {
        this.downPaymentTaxCollectedAmount = value;
    }

    /**
     * Gets the value of the loanTotalFinancialChargeAmount property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getLoanTotalFinancialChargeAmount() {
        return loanTotalFinancialChargeAmount;
    }

    /**
     * Sets the value of the loanTotalFinancialChargeAmount property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setLoanTotalFinancialChargeAmount(String value) {
        this.loanTotalFinancialChargeAmount = value;
    }

    /**
     * Gets the value of the financeChargedCollectedAmount property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getFinanceChargedCollectedAmount() {
        return financeChargedCollectedAmount;
    }

    /**
     * Sets the value of the financeChargedCollectedAmount property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setFinanceChargedCollectedAmount(String value) {
        this.financeChargedCollectedAmount = value;
    }

    /**
     * Gets the value of the financeChargedTaxCollectedAmount property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getFinanceChargedTaxCollectedAmount() {
        return financeChargedTaxCollectedAmount;
    }

    /**
     * Sets the value of the financeChargedTaxCollectedAmount property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setFinanceChargedTaxCollectedAmount(String value) {
        this.financeChargedTaxCollectedAmount = value;
    }

    /**
     * Gets the value of the calculatedAPR property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getCalculatedAPR() {
        return calculatedAPR;
    }

    /**
     * Sets the value of the calculatedAPR property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setCalculatedAPR(String value) {
        this.calculatedAPR = value;
    }

    /**
     * Gets the value of the machineType property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getMachineType() {
        return machineType;
    }

    /**
     * Sets the value of the machineType property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setMachineType(String value) {
        this.machineType = value;
    }

    /**
     * Gets the value of the previousInstallmentLoanNumber property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getPreviousInstallmentLoanNumber() {
        return previousInstallmentLoanNumber;
    }

    /**
     * Sets the value of the previousInstallmentLoanNumber property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setPreviousInstallmentLoanNumber(String value) {
        this.previousInstallmentLoanNumber = value;
    }

    /**
     * Gets the value of the installmentPaymentSchedule property.
     *
     * @return
     *     possible object is
     *     {@link VZWInstallmentPaymentSchedule }
     *
     */
    public VZWInstallmentPaymentSchedule getInstallmentPaymentSchedule() {
        return installmentPaymentSchedule;
    }

    /**
     * Sets the value of the installmentPaymentSchedule property.
     *
     *
     *     allowed object is
     *     {@link VZWInstallmentPaymentSchedule }
     *
     */
    public void setInstallmentPaymentSchedule(VZWInstallmentPaymentSchedule paymentScheduleObj) {
        this.installmentPaymentSchedule = paymentScheduleObj;
    }

    /**
     * Gets the value of the firstmonthPaymentCollected property.
     *
     * @return
     *     possible object is
     *     {@link String }
     *
     */
    public String getFirstmonthPaymentCollected() {
        return firstmonthPaymentCollected;
    }

    /**
     * Sets the value of the firstmonthPaymentCollected property.
     *
     * @param value
     *     allowed object is
     *     {@link String }
     *
     */
    public void setFirstmonthPaymentCollected(String value) {
        this.firstmonthPaymentCollected = value;
    }

    public String getDeviceTaxOnContract() {
        return deviceTaxOnContract;
    }

    public void setDeviceTaxOnContract(String deviceTaxOnContract) {
        this.deviceTaxOnContract = deviceTaxOnContract;
    }

    public String getAgreementPercentage() {
        return agreementPercentage;
    }

    public void setAgreementPercentage(String agreementPercentage) {
        this.agreementPercentage = agreementPercentage;
    }

    public String getUpgradeOptionCode() {
        return upgradeOptionCode;
    }

    public void setUpgradeOptionCode(String upgradeOptionCode) {
        this.upgradeOptionCode = upgradeOptionCode;
    }

    public String getUpgradeDeviceCategoryText() {
        return upgradeDeviceCategoryText;
    }

    public void setUpgradeDeviceCategoryText(String upgradeDeviceCategoryText) {
        this.upgradeDeviceCategoryText = upgradeDeviceCategoryText;
    }

    /**
     * This method is used to get the btaTaxWaiveIndicator
     *
     * @return the btaTaxWaiveIndicator
     */
    public boolean isBtaTaxWaiveIndicator() {
        return mBtaTaxWaiveIndicator;
    }

    /**
     *This method is used to set the btaTaxWaiveIndicator
     *
     * @param pBtaTaxWaiveIndicator the btaTaxWaiveIndicator to set
     */
    public void setBtaTaxWaiveIndicator(boolean pBtaTaxWaiveIndicator) {
        mBtaTaxWaiveIndicator = pBtaTaxWaiveIndicator;
    }
}
