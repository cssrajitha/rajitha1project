package onevz.soe.prepay.adaptor.cart.model.cxp.shipping;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Holds data of zipcode information for
 * retrieve market details by zipcode service.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RetrieveZipcodeMktDetailsRequestData {
	
	private String zipCode;
	
	private String stateCode;
}
