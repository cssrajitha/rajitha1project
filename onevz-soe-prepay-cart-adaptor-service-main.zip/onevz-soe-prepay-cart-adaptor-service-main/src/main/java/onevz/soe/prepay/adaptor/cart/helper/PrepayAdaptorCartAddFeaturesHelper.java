package onevz.soe.prepay.adaptor.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import onevz.soe.cart.model.addFeature.AddFeaturesContext;
import onevz.soe.cart.model.addFeature.AddFeaturesServiceBody;
import onevz.soe.cart.model.addFeature.AddFeaturesServiceRequest;
import onevz.soe.cart.model.addFeature.AddFeaturesServiceResponse;
import onevz.soe.cart.model.common.CartServiceCartInfo;
import onevz.soe.cart.model.common.CartServiceCustomerInfo;
import onevz.soe.cart.model.common.Line;
import onevz.soe.cart.model.common.ProcessMTNList;
import onevz.soe.cart.requests.AddFeaturesPEGARequest;
import onevz.soe.cart.responses.AddFeaturesPEGAResponse;
import onevz.soe.common.model.PrepaidODRequestData;
import onevz.soe.common.model.PrepaidODRequestDataLines;
import onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants;
import onevz.soe.prepay.adaptor.cart.model.cart.vo.VZWPrepayEditCartRequest;
import onevz.soe.prepay.adaptor.cart.util.PrepayAdaptorCartUtil;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.StringUtilities;
import onevz.soe.wsclient.bpm.model.request.ContextInfo;
import onevz.soe.wsclient.bpm.model.response.AvailablePaths;
import onevz.soe.wsclient.bpm.model.response.Error;
import onevz.soe.wsclient.prepay.webclient.PrepayAdaptorWebClient;
import onevz.soe.wsclient.prepay.webclient.model.PrepaidAdaptorWebClientRequest;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import onevz.soe.cart.model.common.Feature;

import java.util.*;
import java.util.stream.Collectors;

import static onevz.soe.prepay.adaptor.cart.constants.PrepayAdaptorCartConstants.*;

@Service
public class PrepayAdaptorCartAddFeaturesHelper {

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    private PrepayAdaptorWebClient prepayBusinessCartWebclient;
    
	@Autowired
	PrepayCartRedisHelper prepayCartRedisHelper;

    @Autowired
    SOELoginSessionBean sessionBean;

	@Value("${playPrepaidEditCart}")
	private String playPrepaidEditCart;
	
	@Value("${accountOwner}")
    private String accountOwner;

    private static final Logger logger = LoggerFactory.getLogger(PrepayAdaptorCartAddFeaturesHelper.class);

    public Mono<ResponseEntity<AddFeaturesPEGAResponse>> addFeature(ServerHttpRequest httpRequest, AddFeaturesPEGARequest addFeaturesPEGARequest) {
		//Request Validation
		if(Optional.ofNullable(addFeaturesPEGARequest).map(AddFeaturesPEGARequest::getServiceBody).map(AddFeaturesServiceBody::getServiceRequest).map(AddFeaturesServiceRequest::getContext)
				.map(AddFeaturesContext::getCartInfo).map(CartServiceCartInfo::getLines).map(lines->CollectionUtils.size(lines)).orElse(0).equals(0)){
			return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(addFeaturesPEGAResponseInvalidRequestError()));
		}
		List<Line> requestLinesList = Arrays.asList(Optional.ofNullable(addFeaturesPEGARequest).orElse(new AddFeaturesPEGARequest()).getServiceBody().getServiceRequest().getContext().getCartInfo().getLines());

		String mtnFromRequestTm = null;
		Feature featureRequestTm = null;
		String featureActionTypeTm = null;
		if(PrepayAdaptorCartUtil.isCollectionNotEmpty(requestLinesList)
				&& StringUtilities.isNotEmptyOrNull(requestLinesList.get(0).getMtn())) {
				mtnFromRequestTm = requestLinesList.get(0).getMtn();

				if(null != requestLinesList.get(0).getFeatures()
						&& PrepayAdaptorCartUtil.isCollectionNotEmpty(requestLinesList.get(0).getFeatures().getAdd())){
					featureRequestTm = requestLinesList.get(0).getFeatures().getAdd().get(0);
					featureActionTypeTm = FeatureActionTypeEnum.ADD.toString();
				}else if(null != requestLinesList.get(0).getFeatures()
						&& PrepayAdaptorCartUtil.isCollectionNotEmpty(requestLinesList.get(0).getFeatures().getRemove())){
					featureRequestTm = requestLinesList.get(0).getFeatures().getRemove().get(0);
					featureActionTypeTm = FeatureActionTypeEnum.REMOVE.toString();
				}
		}
		if(null == featureRequestTm || StringUtilities.isEmptyOrNull(mtnFromRequestTm)) {
			return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(addFeaturesPEGAResponseInternalServerError()));
		}
		final String mtnFromRequest = mtnFromRequestTm;
		final Feature featureRequest = featureRequestTm;
		final String featureActionType = featureActionTypeTm;

		return prepayCartRedisHelper.getDataFromRedisAsString(PREPAY_OD_REQUEST_DATA)
				.doOnError(err -> logger.error("Failed and return error {}", err))
				.defaultIfEmpty("")
				.flatMap(response -> {
					logger.info("PrepaidODRequestData From Redis:: {}", response);	
					PrepaidODRequestData prepaidODRequestData = null;
					List<PrepaidODRequestDataLines> linesFromRedis = null;

					if( StringUtilities.isEmptyOrNull(response)){
						logger.error("Failed to get data from redis {}",response);
						return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(addFeaturesPEGAResponseInternalServerError()));
					}

					try {
						prepaidODRequestData = mapper.readValue(response, PrepaidODRequestData.class);
						linesFromRedis = prepaidODRequestData.getLines();
					} catch (JsonProcessingException e) {
						logger.error("Error while parsing redis Data for Add/Edit Feature:", e);
						return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(addFeaturesPEGAResponseInternalServerError()));
					}

					//Check if it is addfeatureRequest or editfeatureRequest
					if(PrepayAdaptorCartUtil.isCollectionNotEmpty(linesFromRedis)){
						List<PrepaidODRequestDataLines> redisLinesToModify = linesFromRedis.stream().filter(lineFromRedis-> mtnFromRequest.equalsIgnoreCase(lineFromRedis.getMtn())).collect(Collectors.toList());
						if(PrepayAdaptorCartUtil.isCollectionEmpty(redisLinesToModify)){
							return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(addFeaturesPEGAResponseInternalServerError()));
						}
						//check the features list, if it is empty then make addFeature call
						PrepaidODRequestDataLines redisLineToModify = redisLinesToModify.get(0);
						List<String> existingFeatureSkuIdList = PrepayAdaptorCartUtil.isCollectionEmpty(redisLineToModify.getFeatureSkuIds())?new ArrayList<>(): new ArrayList<>(redisLineToModify.getFeatureSkuIds());
						if(FeatureActionTypeEnum.ADD.toString().equalsIgnoreCase(featureActionType)){
							//Add feature  id
							if(PrepayAdaptorCartUtil.isCollectionEmpty(redisLineToModify.getFeatureSkuIds())){
								List<String> featuresListToAdd = new ArrayList<>(2);
								featuresListToAdd.add(featureRequest.getSkuId());
								redisLineToModify.setFeatureSkuIds(featuresListToAdd);
							} else {
								// update the featureid in the redis
								List<String> featuresListToAdd = new ArrayList<>(2);
								if(FEATURE_SKUID_MOBILE_HOTSPOT.equalsIgnoreCase(featureRequest.getSkuId())){
									featuresListToAdd.add(FEATURE_SKUID_MOBILE_HOTSPOT);
									switch(redisLineToModify.getFeatureSkuIds().size()){
										case 1:
											if(!redisLineToModify.getFeatureSkuIds().contains(FEATURE_SKUID_MOBILE_HOTSPOT)){
												featuresListToAdd.add(redisLineToModify.getFeatureSkuIds().get(0));
											}
											break;
										case 2:
											redisLineToModify.getFeatureSkuIds().stream()
													.filter(skuid->!FEATURE_SKUID_MOBILE_HOTSPOT.equalsIgnoreCase(skuid))
													.findFirst().ifPresent(featuresListToAdd::add);
											break;
									}
								}else{
									if(redisLineToModify.getFeatureSkuIds().contains(FEATURE_SKUID_MOBILE_HOTSPOT)){
										featuresListToAdd.add(FEATURE_SKUID_MOBILE_HOTSPOT);
										featuresListToAdd.add(featureRequest.getSkuId());
									}else{
										featuresListToAdd.add(featureRequest.getSkuId());
									}
								}
								redisLineToModify.setFeatureSkuIds(featuresListToAdd);
							}
						} else if(FeatureActionTypeEnum.REMOVE.toString().equalsIgnoreCase(featureActionType)){
							//remove feature
							if(PrepayAdaptorCartUtil.isCollectionEmpty(redisLineToModify.getFeatureSkuIds())
									|| !redisLineToModify.getFeatureSkuIds().contains(featureRequest.getSkuId())){
								return Mono.just(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(addFeaturesPEGAResponseInvalidRequestError()));
							} else {
								if(redisLineToModify.getFeatureSkuIds().size()>1)
								{
									List<String> featuresListToAdd = new ArrayList<>(2);
									featuresListToAdd.add(FEATURE_SKUID_MOBILE_HOTSPOT);
									redisLineToModify.setFeatureSkuIds(featuresListToAdd);
								}else
								{
								redisLineToModify.getFeatureSkuIds().remove(featureRequest.getSkuId());
								}
							}
						}

						PrepaidODRequestData finalPrepaidODRequestData = prepaidODRequestData;
						//check checkout flag is false
						if(redisLineToModify.isCheckoutFlag()){
								
							//make Editcart Prepay OD call
							PrepaidAdaptorWebClientRequest prepaidLegacyServiceRequest = getEditCartPrepaidLegacyServiceRequest(redisLineToModify, finalPrepaidODRequestData);
							
							return prepayBusinessCartWebclient.getPrepayServiceResponse(httpRequest, prepaidLegacyServiceRequest)
									.doOnError(error -> logger.error("Failed to get response, check exception for details.", error))
									.flatMap(editCartResponseEntity -> {
										if (!editCartResponseEntity.getStatusCode().is2xxSuccessful()) {
											logger.error("Error while calling prepaidODEditCart Service, status code: {}", editCartResponseEntity.getStatusCode());
											redisLineToModify.setFeatureSkuIds(existingFeatureSkuIdList);
											return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(addFeaturesPEGAResponseInternalServerError()));

										}
										logger.info("prepaidODEditCart Service is successful ");
										return prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, finalPrepaidODRequestData)
												.doOnError(err -> logger.error("Failed and return error {}", err))
												.flatMap(upsertResp -> {
													logger.info("PrepaidODRequestData From Redis:: {} ", upsertResp);
													return Mono.just(ResponseEntity.status(HttpStatus.OK).body(getAddFeaturePEGAResponse(true, finalPrepaidODRequestData, addFeaturesPEGARequest)));
												});
									});
						} else {
							//just update the redis
							return prepayCartRedisHelper.upsertDataIntoRedisAsStr(PREPAY_OD_REQUEST_DATA, finalPrepaidODRequestData)
									.doOnError(err -> logger.error("Failed to udpate redis and return error {}", err))
									.flatMap(upsertResp -> {
										logger.info("PrepaidODRequestData From Redis:: {} ", upsertResp);
										return Mono.just(ResponseEntity.status(HttpStatus.OK).body(getAddFeaturePEGAResponse(true, finalPrepaidODRequestData, addFeaturesPEGARequest)));
									});
						}
					} else {
						return Mono.just(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(addFeaturesPEGAResponseInternalServerError()));
					}
				});
    }
    

	private AddFeaturesPEGAResponse getAddFeaturePEGAResponse(boolean updateLine, PrepaidODRequestData prepaidODRequestData,
			AddFeaturesPEGARequest addFeaturesPEGARequest) {
		AddFeaturesPEGAResponse addFeaturesPEGAResponse = new AddFeaturesPEGAResponse();
		if(updateLine){
			addFeaturesPEGARequest.getServiceHeader().setStatusMsg(SUCCESS_MSG);
			addFeaturesPEGARequest.getServiceHeader().setStatusCode(RESPONSE_SUCCESS_CODE);
		}else{
			addFeaturesPEGARequest.getServiceHeader().setStatusMsg(FAILURE_MSG);
			addFeaturesPEGARequest.getServiceHeader().setStatusCode(RESPONSE_FAILURE_CODE);
		}
		addFeaturesPEGAResponse.setServiceHeader(addFeaturesPEGARequest.getServiceHeader());
		addFeaturesPEGAResponse.setServiceBody(getServiceBody(updateLine, addFeaturesPEGARequest,prepaidODRequestData));
		return addFeaturesPEGAResponse;
	}

	private AddFeaturesPEGAResponse addFeaturesPEGAResponseInternalServerError(){
		AddFeaturesPEGAResponse addFeaturesPEGAResponseError = new AddFeaturesPEGAResponse();
		List<Error> errors = new ArrayList<>();
		Error error = new Error();
		error.setErrorCode(PrepayAdaptorCartConstants.INVALID_REQUEST_ERROR_CODE);
		error.setMessage(PrepayAdaptorCartConstants.INVALID_REQUEST_ERROR);
		errors.add(error);
		addFeaturesPEGAResponseError.setErrors(errors);
		return addFeaturesPEGAResponseError;
	}

	private AddFeaturesPEGAResponse addFeaturesPEGAResponseInvalidRequestError(){
		AddFeaturesPEGAResponse addFeaturesPEGAResponseError = new AddFeaturesPEGAResponse();
		List<Error> errors = new ArrayList<>();
		Error error = new Error();
		error.setErrorCode(INVALID_REQUEST_ERROR);
		error.setMessage(INVALID_REQUEST_ERROR_CODE);
		errors.add(error);
		addFeaturesPEGAResponseError.setErrors(errors);
		return addFeaturesPEGAResponseError;
	}

	private AddFeaturesServiceBody getServiceBody(boolean updateLine, AddFeaturesPEGARequest addFeaturesPEGARequest,
			PrepaidODRequestData prepaidODRequestData) {
		AddFeaturesServiceBody addFeaturesServiceBody = new AddFeaturesServiceBody();
		addFeaturesServiceBody.setServiceResponse(getServiceResponse(updateLine,addFeaturesPEGARequest,prepaidODRequestData));
		return addFeaturesServiceBody;
	}


	private AddFeaturesServiceResponse getServiceResponse(boolean updateLine, AddFeaturesPEGARequest addFeaturesPEGARequest,
			PrepaidODRequestData prepaidODRequestData) {
		AddFeaturesServiceResponse addFeaturesServiceResponse = new AddFeaturesServiceResponse();
		addFeaturesServiceResponse.setContext(getResponseContext(updateLine,addFeaturesPEGARequest,prepaidODRequestData));
		return addFeaturesServiceResponse;
	}


	private AddFeaturesContext getResponseContext(boolean updateLine, AddFeaturesPEGARequest addFeaturesPEGARequest,
			PrepaidODRequestData prepaidODRequestData) {
		AddFeaturesContext addFeaturesContext = new AddFeaturesContext();
		try {
			addFeaturesContext.setCartInfo(getCartInfo(addFeaturesPEGARequest));
			String nextProcessStep = CHECKOUT_PLAN_PROCESS_STEP;
			boolean checkoutFlag = false;
			if(Objects.nonNull(addFeaturesPEGARequest) && Objects.nonNull(addFeaturesPEGARequest.getServiceBody())
				&& Objects.nonNull(addFeaturesPEGARequest.getServiceBody().getServiceRequest()) 
				&& Objects.nonNull(addFeaturesPEGARequest.getServiceBody().getServiceRequest().getContext())
				&& Objects.nonNull(addFeaturesPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo())
				&& Objects.nonNull(addFeaturesPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines())
				&& Objects.nonNull(prepaidODRequestData) && Objects.nonNull(prepaidODRequestData.getLines())) {
				
					List<PrepaidODRequestDataLines> dataLines = prepaidODRequestData.getLines().stream().filter(line->line.getMtn().equalsIgnoreCase(addFeaturesPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getMtn())).collect(Collectors.toList());
					checkoutFlag = dataLines.get(0).isCheckoutFlag();			
			}
			String nextMtn = Objects.nonNull(prepaidODRequestData) && CollectionUtilities.isNotEmptyOrNull(prepaidODRequestData.getLines())?prepaidODRequestData.getLines().get(0).getMtn():DEFAULT_NSE_LINE; 
			
			if(checkoutFlag) {
				if(Objects.nonNull(prepaidODRequestData) && CollectionUtilities.isNotEmptyOrNull(prepaidODRequestData.getLines()) && prepaidODRequestData.getLines().size() > 1) {
					// check if for any line checkout flag is false then set process step to Add Device prepay
					List<PrepaidODRequestDataLines> notCheckedOutLines = prepaidODRequestData.getLines().stream().filter(line -> !line.isCheckoutFlag()).collect(Collectors.toList());
					
					if(CollectionUtilities.isNotEmptyOrNull(notCheckedOutLines) && notCheckedOutLines.size() > 0 ) {
						nextProcessStep = ADD_DEVICE_PREPAY_PROCESS_STEP;
						nextMtn = notCheckedOutLines.get(0).getMtn();
					} else {
						nextProcessStep = "true".equalsIgnoreCase(accountOwner)?ACCOUNT_OWNER_PROCESS_STEP:CHECKOUT_PLAN_PROCESS_STEP;
					}
				} else {
					nextProcessStep = CHECKOUT_PLAN_PROCESS_STEP;
					
				}	
			} else {
				nextProcessStep = ADD_DEVICE_PREPAY_PROCESS_STEP;
				
			}
			
			if(Objects.nonNull(prepaidODRequestData.getLines())) {
				
				List<PrepaidODRequestDataLines> remainingLines = prepaidODRequestData.getLines().stream().filter(line -> (line.getFeatureSkuIds()!=null)?line.getFeatureSkuIds().isEmpty():true).collect(Collectors.toList());
			
				if(CollectionUtilities.isNotEmptyOrNull(remainingLines)) {
					List<PrepaidODRequestDataLines> hotspotFeaturesLines = remainingLines.stream().filter(lines->lines.getPlanSorId().equalsIgnoreCase(PrepayAdaptorCartConstants.HOTSPOT_PLAN_ID)).collect(Collectors.toList());
					
					if(CollectionUtilities.isNotEmptyOrNull(hotspotFeaturesLines)) {
						nextMtn = hotspotFeaturesLines.get(0).getMtn();
						nextProcessStep = HOTSPOT_PLAN_PROCESS_STEP;
					}
				}	
			}
			ProcessMTNList listData = new ProcessMTNList();
			ProcessMTNList[] mtnList = new ProcessMTNList[1];
	        
			CartServiceCustomerInfo cartServiceCustomerInfo = new CartServiceCustomerInfo();
			
			if(Objects.nonNull(addFeaturesPEGARequest) && Objects.nonNull(addFeaturesPEGARequest.getServiceBody()) 
					&& Objects.nonNull(addFeaturesPEGARequest.getServiceBody().getServiceRequest()) 
					&& Objects.nonNull(addFeaturesPEGARequest.getServiceBody().getServiceRequest().getContext()) 
					&& Objects.nonNull(addFeaturesPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo())){
			
				cartServiceCustomerInfo.setCustomerType(addFeaturesPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCustomerType());
				cartServiceCustomerInfo.setAccountNumber(addFeaturesPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getAccountNumber());
				cartServiceCustomerInfo.setCartCreator(addFeaturesPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCartCreator());
				cartServiceCustomerInfo.setRegisterNumber(addFeaturesPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getRegisterNumber());
				cartServiceCustomerInfo.setMtnFlow(addFeaturesPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getMtnFlow());
				cartServiceCustomerInfo.setGlobalId(addFeaturesPEGARequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getGlobalId());
			}			
			ContextInfo contextInfo = new ContextInfo();
			if(Objects.nonNull(addFeaturesPEGARequest) && Objects.nonNull(addFeaturesPEGARequest.getServiceBody()) 
					&& Objects.nonNull(addFeaturesPEGARequest.getServiceBody().getServiceRequest()) 
					&& Objects.nonNull(addFeaturesPEGARequest.getServiceBody().getServiceRequest().getContext()) 
					&& Objects.nonNull(addFeaturesPEGARequest.getServiceBody().getServiceRequest().getContext().getContextInfo())){
				contextInfo.setCallReason(addFeaturesPEGARequest.getServiceBody().getServiceRequest().getContext().getContextInfo().getCallReason());
				contextInfo.setIntent(addFeaturesPEGARequest.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
		    }
						
			AvailablePaths availablePath = new AvailablePaths();
			List <AvailablePaths> availablePaths;
						
		    if(updateLine) {
		    	 cartServiceCustomerInfo.setProcessingMTN(nextMtn);
		         listData.setMtn(nextMtn);  
		         contextInfo.setProcessStep(nextProcessStep);
		         contextInfo.setProcessAction("");
		         
		         availablePaths = new ArrayList<>();
		         availablePath.setPath(nextProcessStep);
		         availablePaths.add(availablePath);
		         contextInfo.setAvailablePaths(availablePaths);
		    }else{
		    	if (Objects.nonNull(addFeaturesPEGARequest) && Objects.nonNull(addFeaturesPEGARequest.getServiceBody()) 
					&& Objects.nonNull(addFeaturesPEGARequest.getServiceBody().getServiceRequest()) 
					&& Objects.nonNull(addFeaturesPEGARequest.getServiceBody().getServiceRequest().getContext()) 
					&& Objects.nonNull(addFeaturesPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo()) 
					&& Objects.nonNull(addFeaturesPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines())) {
		    		
			    	cartServiceCustomerInfo.setProcessingMTN(addFeaturesPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getMtn());
			    	listData.setMtn(addFeaturesPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getMtn());
		    	}
		    	contextInfo.setProcessAction("");
		    	
		    	if(Objects.nonNull(addFeaturesPEGARequest) && Objects.nonNull(addFeaturesPEGARequest.getServiceBody()) 
						&& Objects.nonNull(addFeaturesPEGARequest.getServiceBody().getServiceRequest()) 
						&& Objects.nonNull(addFeaturesPEGARequest.getServiceBody().getServiceRequest().getContext()) 
						&& Objects.nonNull(addFeaturesPEGARequest.getServiceBody().getServiceRequest().getContext().getContextInfo())){
		    		
			    	contextInfo.setProcessStep(addFeaturesPEGARequest.getServiceBody().getServiceRequest().getContext().getContextInfo().getProcessStep());
			        availablePaths = new ArrayList<>();
			        availablePath.setPath(addFeaturesPEGARequest.getServiceBody().getServiceRequest().getContext().getContextInfo().getProcessStep());
			        availablePaths.add(availablePath);
			        contextInfo.setAvailablePaths(availablePaths);
		    	}
		    }
		    
            List<PrepaidODRequestDataLines> lineToProcess = prepaidODRequestData.getLines().stream().filter(line->line.getMtn().equalsIgnoreCase(addFeaturesPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()[0].getMtn())).collect(Collectors.toList());
            List<String> completedSteps = lineToProcess.get(0).getCompletedProcessSteps();
            completedSteps.add(addFeaturesPEGARequest.getServiceBody().getServiceRequest().getContext().getContextInfo().getProcessStep());
            listData.setCompletedprocessSteps(completedSteps.toArray(new String[completedSteps.size()]));
		    mtnList[0] = listData;
		    
			addFeaturesContext.setContextInfo(contextInfo);
			addFeaturesContext.setCustomerInfo(cartServiceCustomerInfo);
			
			addFeaturesContext.setProcessMTNList(mtnList);		
		}catch(Exception ex) {
			logger.error("Exception in building response: {0}", ex);
		}
		return addFeaturesContext;
	}

	private CartServiceCartInfo getCartInfo(AddFeaturesPEGARequest addFeaturesPEGARequest) {
		CartServiceCartInfo cartServiceCartInfo = new CartServiceCartInfo();
		cartServiceCartInfo.setCartItemCount(addFeaturesPEGARequest.getServiceBody().getServiceRequest().getContext().getCartInfo().getCartItemCount());
		return cartServiceCartInfo;
	}

    private PrepaidAdaptorWebClientRequest getEditCartPrepaidLegacyServiceRequest(PrepaidODRequestDataLines redisLineToModify,PrepaidODRequestData prepaidODRequestData) {
		VZWPrepayEditCartRequest prepayEditCartRequest = new VZWPrepayEditCartRequest();
		prepayEditCartRequest.setDeviceSkuId(redisLineToModify.getDeviceSkuId());
		prepayEditCartRequest.setEditFlowName(PrepayAdaptorCartConstants.PREPAY_OD_EDITCART_FLOW_DEVICE);
		boolean notNowFlag = false;
		
		if(redisLineToModify.getFeatureSkuIds().contains(NOT_NOW_FEATURE)) {
			notNowFlag = true;
		}
		redisLineToModify.getFeatureSkuIds().remove(NOT_NOW_FEATURE);
			
		prepayEditCartRequest.setFeatureSkuId(redisLineToModify.getFeatureSkuIds().stream().collect(Collectors.joining(",")));
		
		prepayEditCartRequest.setLineItemId(redisLineToModify.getLineItemId());
		prepayEditCartRequest.setPlanSkuId(redisLineToModify.getPlanSkuId());
		prepayEditCartRequest.setProductId(redisLineToModify.getDeviceId());
		prepayEditCartRequest.setQuantity(1);
		
		if(notNowFlag) {
			redisLineToModify.getFeatureSkuIds().add(NOT_NOW_FEATURE);
		}
        PrepaidAdaptorWebClientRequest prepaidAdaptorWebClientRequest = new PrepaidAdaptorWebClientRequest();
		prepaidAdaptorWebClientRequest.setUrl(playPrepaidEditCart);
		prepaidAdaptorWebClientRequest.setHeader(PrepayAdaptorCartUtil.getPrepayODServiceCommonHeaders(prepaidODRequestData));
        prepaidAdaptorWebClientRequest.setRequestBody(prepayEditCartRequest);
		prepaidAdaptorWebClientRequest.setRequestType(HttpMethod.POST.toString());
        return prepaidAdaptorWebClientRequest;
    }

   
}