package onevz.soe.prepay.adaptor.cart.model.play.common.error;

import java.io.Serializable;
import java.util.List;

/**
 * Created by eesamma on 10/24/2017.
 */
public class EcommValidationError implements Serializable{
    private int status;
    private List<EcommApiError> ecommApiErrorList;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public List<EcommApiError> getEcommApiErrorList() {
        return ecommApiErrorList;
    }

    public void setEcommApiErrorList(List<EcommApiError> ecommApiErrorList) {
        this.ecommApiErrorList = ecommApiErrorList;
    }
}
