package onevz.soe.prepay.adaptor.cart.model.cart.vo;

import java.io.Serializable;
import java.util.List;

public class VZWPrepayPaymentVO implements Serializable {

    private static final long serialVersionUID = 1L;

    private List<VZWPrepayRefillCardPaymentVO>  paymentGrpIdList ;

    private double remainingDue ;

    public List<VZWPrepayRefillCardPaymentVO> getPaymentGrpIdList() {
        return paymentGrpIdList;
    }

    public void setPaymentGrpIdList(List<VZWPrepayRefillCardPaymentVO> paymentGrpIdList) {
        this.paymentGrpIdList = paymentGrpIdList;
    }

    public double getRemainingDue() {
        return remainingDue;
    }

    public void setRemainingDue(double remainingDue) {
        this.remainingDue = remainingDue;
    }
}
