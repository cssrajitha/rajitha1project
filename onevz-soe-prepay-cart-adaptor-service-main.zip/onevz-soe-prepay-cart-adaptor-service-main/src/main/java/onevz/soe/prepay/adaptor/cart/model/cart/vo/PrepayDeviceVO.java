package onevz.soe.prepay.adaptor.cart.model.cart.vo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import onevz.soe.od.model.PrepayExsitingDeviceVO;

import java.io.Serializable;
import java.util.HashMap;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PrepayDeviceVO implements Serializable {
    
    private String Id ;
    private int quantity;
    private String skuId;
    private String productId;
    private String seoName ;
    private String sorId;
    private double listPrice;
    private double itemAmount;
    private double rawTotalAmount;
    private double deviceTax;
    private String skuDisplayName;
    private double activationFee;
    private String color;
    private String capacity;
    private String brandName;
    private String imageUrl;
    private String miniImageUrl;
    private String planItemId;
    private String numberShareLineItemId;
    private boolean accountMember;
    private boolean accountOwner;
    private boolean portInDevice;
    private String daccCode;
    private String simDisplayName;
    private String purchasePath;
    private String simId;
    private String itemType;
    private double totalDueMonthly;
    private double totalDueToday;
    private String trialStatus;
    private String deviceSorType;
    private boolean fiftyPercentPromoApplied;
    private String npaNxxCode;
    private boolean isInlinePromo;
    private String lineSecurityPin;
    private String securityQuestion;
    private String securityAnswer;
    private String deviceFirstName;
    private String deviceLastName;
    private boolean autoPaymentEligible;
	private double fullRetailListPrice;
    private PrepayExsitingDeviceVO existingDevice;
    private boolean esimCompatible;
    private boolean esimOnlyDevice;
    private boolean smartImeiDevice;
    @JsonProperty(value="eSIMEnabledDevice")
    private boolean eSIMEnabledDevice;
                    
    private String imei;
    private String imei2;
    private String requestedEsimImei;
    private HashMap<String,Double> taxDetails;
    private double futureDiscount;
    private int futureDiscountMonths;

}