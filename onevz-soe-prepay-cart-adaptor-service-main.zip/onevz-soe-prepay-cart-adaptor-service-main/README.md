# onevz-soe-prepay-cart-bussiness-service

## Workspace Setup
* Clone this repo.  
* Do an `mvn clean install` on this repo.
* Run the jar (ending with exec) from the newly created `target` folder.
* Import the project in the IDE of your choice.
* Copy /onevz-soe-prepay-cart-business-service/helm/onevz-soe-prepay-cart-business-service/containers/onevz-soe-prepay-cart-business-service/config-map/nsd2/src/main/resources/application.properties and paste in /onevz-soe-prepay-cart-business-service/src/main/resources/.

## Coding Standards
* All code must have JUnit Test Cases. Coverage should be greater than 70%.   
