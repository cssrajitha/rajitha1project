package com.aafes.sgpos.sgposservices.Gateway;

import com.aafes.sgpos.sgposservices.Config.EncryptorConfig;
import com.aafes.sgpos.sgposservices.generated.Control.CVSRequest;
import com.aafes.sgpos.sgposservices.generated.Control.Header;
import com.aafes.sgpos.sgposservices.generated.Control.SGPOSServices;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.mq.jakarta.jms.MQConnection;
import org.json.simple.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.*;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.lang.reflect.Field;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

//@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = {ccdVerificationCVSTests.class})
public class ccdVerificationCVSTests {

    @Mock
    private ccdVerificationCVS ccdVerificationCVS;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private EncryptorConfig encryptorConfig;

    @Mock
    private SGPOSServices sgposServices;

    @Mock
    private ObjectMapper objectMapper;

    @Value("${ccd.CCDUserName}")
    private String CCDUserName = "testUser";
    @Value("${ccd.CCDPassword}")
    private String CCDPassword = "testPassword";
    @Value("${ccd.CCDClientID}")
    private String CCDClientID = "testClientID";
    @Value("${ccd.CCDURL:http://testccdurl.com}")
    public String CCDURL;
    @Value("${timeOut.ccdCallTimeout}")
    private String ccdCallTimeout = "5000";
    @Value("${timeOut.ccdCallReadTimeout}")
    private String ccdCallReadTimeout = "5000";

    private static final ObjectMapper mapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(ccdVerificationCVS, "CCDUserName", "testUser");
        ReflectionTestUtils.setField(ccdVerificationCVS, "CCDPassword", "testPass");
        ReflectionTestUtils.setField(ccdVerificationCVS, "CCDClientID", "testClientID");
        ReflectionTestUtils.setField(ccdVerificationCVS, "CCDURL", "http://testccdurl.com");
        ReflectionTestUtils.setField(ccdVerificationCVS, "ccdCallTimeout", "5000");
        ReflectionTestUtils.setField(ccdVerificationCVS, "ccdCallReadTimeout", "5000");
    }

    @Test
    public void testCCDCallSuccessEDIPI() throws Exception {
        when(sgposServices.getCVSRequest()).thenReturn(mock(CVSRequest.class));

        Header mockHeader = new Header();
        mockHeader.setTraceID("12345");
        when(sgposServices.getHeader()).thenReturn(mockHeader);
        assertEquals("12345", sgposServices.getHeader().getTraceID());

        CVSRequest mockCVSRequest = mock(CVSRequest.class);
        when(sgposServices.getCVSRequest()).thenReturn(mockCVSRequest);
        when(mockCVSRequest.getCustomerType()).thenReturn(CVSRequest.CustomerType.valueOf("EDIPI"));
        when(mockCVSRequest.getCustomerID()).thenReturn("12345");
        when(encryptorConfig.decrypt(anyString())).thenReturn("DecryptedPassword");
        when(sgposServices.getCVSRequest()).thenReturn(mockCVSRequest);

        JSONObject mockResponseBody = new JSONObject();
        mockResponseBody.put("respStatus", "000");
        ResponseEntity<Object> responseEntity = new ResponseEntity<>(mockResponseBody.toString(), HttpStatus.OK);
        JSONObject result = new JSONObject();
        result.put("ccdCall", true);
        result.put("ssn", "123-45-6789");
        result.put("respStatus", "000");

        when(ccdVerificationCVS.CCDCall(sgposServices)).thenReturn(result);

        JSONObject jsonObjectResult = new JSONObject();
        assertNotNull(jsonObjectResult);
        assertEquals(true, result.get("ccdCall"));
        assertEquals("123-45-6789", result.get("ssn"));
        assertEquals("000", result.get("respStatus"));
    }

    @Test
    public void testCCDCallFailureWithStatusNot000() throws Exception {
        // Mock necessary methods and data
        SGPOSServices sgposServices = mock(SGPOSServices.class, RETURNS_DEEP_STUBS);
        when(encryptorConfig.decrypt(CCDPassword)).thenReturn("decryptedPassword");
        when(sgposServices.getCVSRequest().getCustomerType()).thenReturn(CVSRequest.CustomerType.SSN);
        when(sgposServices.getCVSRequest().getCustomerID()).thenReturn("98765");

        when(sgposServices.getCVSRequest()).thenReturn(mock(CVSRequest.class));

        Header mockHeader = new Header();
        mockHeader.setTraceID("12345");
        when(sgposServices.getHeader()).thenReturn(mockHeader);
        assertEquals("12345", sgposServices.getHeader().getTraceID());

        CVSRequest mockCVSRequest = mock(CVSRequest.class);
        when(sgposServices.getCVSRequest()).thenReturn(mockCVSRequest);
        when(mockCVSRequest.getCustomerType()).thenReturn(CVSRequest.CustomerType.valueOf("EDIPI"));
        when(mockCVSRequest.getCustomerID()).thenReturn("12345");
        when(encryptorConfig.decrypt(anyString())).thenReturn("DecryptedPassword");
        when(sgposServices.getCVSRequest()).thenReturn(mockCVSRequest);

        JSONObject mockResponseBody = new JSONObject();
        mockResponseBody.put("respStatus", "100");
        ResponseEntity<Object> responseEntity = new ResponseEntity<>(mockResponseBody.toString(), HttpStatus.OK);

        JSONObject result = new JSONObject();
        result.put("ccdCall", false);
        result.put("abcde", "123-45-6789");
        result.put("respStatus", "100");

        when(ccdVerificationCVS.CCDCall(sgposServices)).thenReturn(result);

        JSONObject jsonObjectResult = new JSONObject();
        assertNotNull(jsonObjectResult);
        assertEquals(false, result.get("ccdCall"));
        assertNotEquals("123-45-6789", result.get("ssn"));
        assertEquals("100", result.get("respStatus"));
    }
//
@Test
public void testCCDCallFailureWithStatusCode102() throws Exception {
    // Mock necessary methods and data
    SGPOSServices sgposServices = mock(SGPOSServices.class, RETURNS_DEEP_STUBS);
    when(encryptorConfig.decrypt(CCDPassword)).thenReturn("decryptedPassword");
    when(sgposServices.getCVSRequest().getCustomerType()).thenReturn(CVSRequest.CustomerType.SSN);
    when(sgposServices.getCVSRequest().getCustomerID()).thenReturn("98765");

    when(sgposServices.getCVSRequest()).thenReturn(mock(CVSRequest.class));

    Header mockHeader = new Header();
    mockHeader.setTraceID("12345");
    when(sgposServices.getHeader()).thenReturn(mockHeader);
    assertEquals("12345", sgposServices.getHeader().getTraceID());

    CVSRequest mockCVSRequest = mock(CVSRequest.class);
    when(sgposServices.getCVSRequest()).thenReturn(mockCVSRequest);
    when(mockCVSRequest.getCustomerType()).thenReturn(CVSRequest.CustomerType.valueOf("EDIPI"));
    when(mockCVSRequest.getCustomerID()).thenReturn("12345");
    when(encryptorConfig.decrypt(anyString())).thenReturn("DecryptedPassword");
    when(sgposServices.getCVSRequest()).thenReturn(mockCVSRequest);

    JSONObject mockResponseBody = new JSONObject();
    mockResponseBody.put("respStatus", "102");
    ResponseEntity<Object> responseEntity = new ResponseEntity<>(mockResponseBody.toString(), HttpStatus.OK);

    JSONObject result = new JSONObject();
    result.put("ccdCall", false);
    result.put("abcde", "123-45-6789");
    result.put("respStatus", "102");

    when(ccdVerificationCVS.CCDCall(sgposServices)).thenReturn(result);

    JSONObject jsonObjectResult = new JSONObject();
    assertNotNull(jsonObjectResult);
    assertEquals(false, result.get("ccdCall"));
    assertNotEquals("123-45-6789", result.get("ssn"));
    assertEquals("102", result.get("respStatus"));
}
   @Test
    public void testCCDCallFailureWithStatus902() throws Exception {
        // Mock necessary methods and data
        SGPOSServices sgposServices = mock(SGPOSServices.class, RETURNS_DEEP_STUBS);
        when(encryptorConfig.decrypt(CCDPassword)).thenReturn("decryptedPassword");
        when(sgposServices.getCVSRequest().getCustomerType()).thenReturn(CVSRequest.CustomerType.SSN);
        when(sgposServices.getCVSRequest().getCustomerID()).thenReturn("98765");

        when(sgposServices.getCVSRequest()).thenReturn(mock(CVSRequest.class));

        Header mockHeader = new Header();
        mockHeader.setTraceID("12345");
        when(sgposServices.getHeader()).thenReturn(mockHeader);
        assertEquals("12345", sgposServices.getHeader().getTraceID());

        CVSRequest mockCVSRequest = mock(CVSRequest.class);
        when(sgposServices.getCVSRequest()).thenReturn(mockCVSRequest);
        when(mockCVSRequest.getCustomerType()).thenReturn(CVSRequest.CustomerType.valueOf("EDIPI"));
        when(mockCVSRequest.getCustomerID()).thenReturn("12345");
        when(encryptorConfig.decrypt(anyString())).thenReturn("DecryptedPassword");
        when(sgposServices.getCVSRequest()).thenReturn(mockCVSRequest);

        JSONObject mockResponseBody = new JSONObject();
        mockResponseBody.put("respStatus", "902");
        ResponseEntity<Object> responseEntity = new ResponseEntity<>(mockResponseBody.toString(), HttpStatus.OK);

        JSONObject result = new JSONObject();
        result.put("ccdCall", false);
        result.put("abcde", "123-45-6789");
        result.put("respStatus", "902");

        when(ccdVerificationCVS.CCDCall(sgposServices)).thenReturn(result);

        JSONObject jsonObjectResult = new JSONObject();
        assertNotNull(jsonObjectResult);
        assertEquals(false, result.get("ccdCall"));
        assertNotEquals("123-45-6789", result.get("ssn"));
        assertEquals("902", result.get("respStatus"));
    }
}