/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aafes.sgpos.sgposservices.config;

/**
 *
 * @author bhendarkart
 */
import com.aafes.sgpos.sgposservices.Config.EncryptorConfig;
import com.aafes.sgpos.sgposservices.Config.JmsConfig;
import com.ibm.mq.jakarta.jms.MQQueueConnectionFactory;
import com.ibm.msg.client.jakarta.wmq.WMQConstants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.connection.UserCredentialsConnectionFactoryAdapter;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class JmsConfigTest {
    @InjectMocks
    private JmsConfig jmsConfig;

    @Mock
    private EncryptorConfig encryptorConfig;

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);

        // Inject @Value fields for QM1
        ReflectionTestUtils.setField(jmsConfig, "qManagerName1", "QM1");
        ReflectionTestUtils.setField(jmsConfig, "mqHostName1", "host1");
        ReflectionTestUtils.setField(jmsConfig, "qChannelName1", "channel1");
        ReflectionTestUtils.setField(jmsConfig, "qPort1", "1414");
        ReflectionTestUtils.setField(jmsConfig, "requestQ1", "RQ1");
        ReflectionTestUtils.setField(jmsConfig, "cicsUserName", "user1");
        ReflectionTestUtils.setField(jmsConfig, "cicsPassword", "encryptedPass");

        // Inject @Value fields for QM2
        ReflectionTestUtils.setField(jmsConfig, "qManagerName2", "QM2");
        ReflectionTestUtils.setField(jmsConfig, "mqHostName2", "host2");
        ReflectionTestUtils.setField(jmsConfig, "qChannelName2", "channel2");
        ReflectionTestUtils.setField(jmsConfig, "qPort2", "1415");
        ReflectionTestUtils.setField(jmsConfig, "requestQ2", "RQ2");

        ReflectionTestUtils.setField(jmsConfig, "encryptorConfig", encryptorConfig);
        when(encryptorConfig.decrypt("encryptedPass")).thenReturn("decryptedPass");
    }

    @Test
void testConnectionFactoryQM1() throws Exception {
    // Create the adapter using your configuration method
    UserCredentialsConnectionFactoryAdapter adapter = jmsConfig.connectionFactoryQM1();
    assertNotNull(adapter);

    // 🛠️ Access private fields using ReflectionTestUtils
    String username = (String) ReflectionTestUtils.getField(adapter, "username");
    String password = (String) ReflectionTestUtils.getField(adapter, "password");
    Object factoryObj = ReflectionTestUtils.getField(adapter, "targetConnectionFactory");

    assertEquals("user1", username);
    assertEquals("decryptedPass", password);
    assertNotNull(factoryObj);
    assertTrue(factoryObj instanceof MQQueueConnectionFactory);

    MQQueueConnectionFactory factory = (MQQueueConnectionFactory) factoryObj;

    // Validate factory setup
    assertEquals("QM1", factory.getQueueManager());
    assertEquals("host1", factory.getHostName());
    assertEquals("channel1", factory.getChannel());
    assertEquals(1414, factory.getPort());
    assertEquals(WMQConstants.WMQ_CM_CLIENT, factory.getTransportType());
}


    @Test
    void testJmsTemplateQM1() throws Exception {
        JmsTemplate jmsTemplate = jmsConfig.jmsTemplateQM1();
        assertNotNull(jmsTemplate);
        assertNotNull(jmsTemplate.getConnectionFactory());
    }

    @Test
    void testConnectionFactoryQM2() throws Exception {
        UserCredentialsConnectionFactoryAdapter adapter = jmsConfig.connectionFactoryQM2();
        assertNotNull(adapter);
        
        Object factoryObj = ReflectionTestUtils.getField(adapter, "targetConnectionFactory");
        assertNotNull(factoryObj);
        assertTrue(factoryObj instanceof MQQueueConnectionFactory);

        MQQueueConnectionFactory factory = (MQQueueConnectionFactory) factoryObj;

        assertEquals("QM2", factory.getQueueManager());
        assertEquals("host2", factory.getHostName());
        assertEquals("channel2", factory.getChannel());
        assertEquals(1415, factory.getPort());
        assertTrue(factory.getClientID().startsWith("myClientId-"));
        assertTrue(factory.getTargetClientMatching());  // 🟢 corrected method name
    }

    @Test
    void testCachingConnectionFactoryQM2() throws Exception {
        UserCredentialsConnectionFactoryAdapter adapter = jmsConfig.connectionFactoryQM2();
        CachingConnectionFactory cachingFactory = jmsConfig.cachingConnectionFactory(adapter);

        assertNotNull(cachingFactory);
        assertEquals(500, cachingFactory.getSessionCacheSize());

        
        boolean reconnectValue = (boolean) ReflectionTestUtils.getField(cachingFactory, "reconnectOnException");
        assertTrue(reconnectValue, "ReconnectOnException should be enabled");
    }


    @Test
    void testJmsTemplateQM2() throws Exception {
        JmsTemplate jmsTemplate = jmsConfig.jmsTemplateQM2();
        assertNotNull(jmsTemplate);
        assertNotNull(jmsTemplate.getConnectionFactory());
    }
}

