package com.aafes.sgpos.sgposservices.Gateway;

import com.aafes.sgpos.sgposservices.Config.EncryptorConfig;
import com.aafes.sgpos.sgposservices.Config.WalkerResponse;
import com.aafes.sgpos.sgposservices.Entity.fac_fmf;
import com.aafes.sgpos.sgposservices.Repository.storeOpenCloseMessagesRepository;
import com.aafes.sgpos.sgposservices.Service.SGPOSServicesservice;
import com.aafes.sgpos.sgposservices.generated.Control.*;
import com.aafes.sgpos.sgposservices.util.BuildErrorResponseUtil;
import com.aafes.sgpos.sgposservices.walkerinterface.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;


class ORISVerificationTest {

    @InjectMocks
    private orisVerification orisVerification;

    @Mock
    private EncryptorConfig encryptorConfig;
    @Mock
    private WalkerResponse walkerResponse;
    @Mock
    private BuildErrorResponseUtil buildErrorResponseUtil;
    @Mock
    private storeOpenCloseMessagesRepository resaQueueRepository;
    @Mock(answer = Answers.RETURNS_DEEP_STUBS)
    private ApplyTXNResponse applyTXNResponse;

    @Mock(answer = Answers.RETURNS_DEEP_STUBS)
    private ConnectToWalkerResponse connectToWalkerResponse;

    @Mock
    private SGPOSServices sgposServices;
    @Mock
    private List<fac_fmf> facility;
    @Mock
    private Header header;

    @Mock
    private fac_fmf fac;
    @Mock
    private ORISRequest orisRequest;


    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        when(sgposServices.getHeader()).thenReturn(header);
        when(header.getFacilityNumber()).thenReturn("123456");
    }

    @Test
    void testLogin_Success() {
        ConnectToWalker mockWalker = mock(ConnectToWalker.class);
        when(mockWalker.getStrZuser()).thenReturn("testUser");
        when(mockWalker.getStrZpass()).thenReturn("testPass");
        when(walkerResponse.signIn(any(ConnectToWalker.class))).thenReturn(new ConnectToWalkerResponse());
        when(encryptorConfig.decrypt("testPass")).thenReturn("decryptedPass");

        ConnectToWalkerResponse result = orisVerification.login(sgposServices);

        assertNotNull(result);
        verify(walkerResponse, times(1)).signIn(any(ConnectToWalker.class));
    }

    @Test
    void testLogin_Failure() {
        when(walkerResponse.signIn(any(ConnectToWalker.class))).thenThrow(new RuntimeException("Connection error"));
        when(buildErrorResponseUtil.buildErrorResponseAdd(any(), eq("ORIS_TIME_OUT"))).thenReturn(sgposServices);

        ConnectToWalkerResponse result = orisVerification.login(sgposServices);

        assertNotNull(result);
        verify(walkerResponse, times(1)).signIn(any(ConnectToWalker.class));
    }

    @Test
    void testParseSalesDate_Valid() {
        String validDate = "120515103040";
        String result = orisVerification.parseSalesDate(validDate);
        assertNotNull(result);
        assertEquals("120515", result);
    }

    @Test
    void testParseSalesDate_Invalid() {
        String invalidDate = "invalid-date";
        Exception exception = assertThrows(Exception.class, () -> {
            orisVerification.parseSalesDate(invalidDate);
        });
    }


    @Test
    void testApplyTXN_UnknownRequestType() {
        when(sgposServices.getORISRequest()).thenReturn(null);
        when(sgposServices.getHeader()).thenReturn(header);
        when(header.getFacilityNumber()).thenReturn("123456");

        when(connectToWalkerResponse.getConnectToWalkerResult().getEncodedHtmlResponse())
                .thenReturn("mockHtml".getBytes());


        when(walkerResponse.applytxn(any(ApplyTXN.class))).thenReturn(applyTXNResponse);

        ApplyTXNResponse response = orisVerification.applyTXN(connectToWalkerResponse, sgposServices, facility);

        assertNotNull(response);
    }

    @Test
    void testLoggOff_Success() {
        when(applyTXNResponse.getApplyTXNResult().getToken()).thenReturn("mockToken");

        LogOffWalkerResponse logOffResponse = new LogOffWalkerResponse();
        when(walkerResponse.logoff(any(LogOffWalker.class))).thenReturn(logOffResponse);

        LogOffWalkerResponse response = orisVerification.loggOff(applyTXNResponse, sgposServices);

        assertNotNull(response);
    }

    @Test
    void testLogin_Failure_NoRequests() {
        when(walkerResponse.signIn(any(ConnectToWalker.class))).thenThrow(new RuntimeException("Connection error"));
        when(sgposServices.getStoreOpenCloseRequest()).thenReturn(null);
        when(sgposServices.getORISRequest()).thenReturn(null);
        when(buildErrorResponseUtil.buildErrorResponseAdd(any(), eq("ORIS_TIME_OUT"))).thenReturn(sgposServices);

        ConnectToWalkerResponse result = orisVerification.login(sgposServices);

        assertNotNull(result);
        verify(walkerResponse, times(1)).signIn(any(ConnectToWalker.class));
    }

    @Test
    void testLoggOff_Exception_ORISRequest() {
        when(applyTXNResponse.getApplyTXNResult().getToken()).thenReturn("mockToken");
        when(walkerResponse.logoff(any(LogOffWalker.class))).thenThrow(new RuntimeException("Timeout"));

        ORISRequest orisRequest = mock(ORISRequest.class);
        when(sgposServices.getORISRequest()).thenReturn(orisRequest);
        when(buildErrorResponseUtil.buildErrorResponseAdd(any(), eq("ORIS_TIME_OUT"))).thenReturn(sgposServices);

        LogOffWalkerResponse response = orisVerification.loggOff(applyTXNResponse, sgposServices);

        assertNotNull(response);
    }


    @Test
    void testLoggOff_Exception_StoreOpenCloseRequest() {
        when(applyTXNResponse.getApplyTXNResult().getToken()).thenReturn("mockToken");
        when(walkerResponse.logoff(any(LogOffWalker.class))).thenThrow(new RuntimeException("Timeout"));

        when(sgposServices.getStoreOpenCloseRequest()).thenReturn(mock(StoreOpenCloseRequest.class));
        when(buildErrorResponseUtil.buildErrorResponseAdd(any(), eq("SOC_TIME_OUT"))).thenReturn(sgposServices);

        LogOffWalkerResponse response = orisVerification.loggOff(applyTXNResponse, sgposServices);

        assertNotNull(response);
    }

    @Test
    void testApplyTXN_PreauthRequest_Success() {
        when(sgposServices.getORISRequest()).thenReturn(orisRequest);
        when(orisRequest.getRequestType()).thenReturn("PREAUTH");
        when(orisRequest.getCustomerID()).thenReturn("CUST123");
        when(orisRequest.getReceivableType()).thenReturn("ABC12");
        when(orisRequest.getBillingToOffice()).thenReturn("BILLTO");

        when(connectToWalkerResponse.getConnectToWalkerResult().getEncodedHtmlResponse())
                .thenReturn("mockHtml".getBytes());

        when(walkerResponse.applytxn(any(ApplyTXN.class))).thenReturn(applyTXNResponse);

        List<fac_fmf> facility = Arrays.asList(fac);
        ApplyTXNResponse response = orisVerification.applyTXN(connectToWalkerResponse, sgposServices, facility);

        assertNotNull(response);
    }

    @Test
    void testApplyTXN_FinalauthRequest_Success() {
        when(sgposServices.getORISRequest()).thenReturn(orisRequest);
        when(orisRequest.getRequestType()).thenReturn("FINALAUTH");
        when(orisRequest.getCustomerID()).thenReturn("CUST123");
        when(orisRequest.getReceivableType()).thenReturn("ABC12");
        when(orisRequest.getBillingToOffice()).thenReturn("BILLTO");
        when(orisRequest.getBusinessDate()).thenReturn("120515103040");
        when(orisRequest.getAmount()).thenReturn("100.00");
        when(orisRequest.getFacPhoneNum()).thenReturn("1234567890");
        when(orisRequest.getCashierNameTag()).thenReturn("Cashier");
        when(orisRequest.getReceivedBy()).thenReturn("Receiver");
        when(orisRequest.getInvoiceQuantity()).thenReturn("10");
        when(orisRequest.getGLAccountNumber()).thenReturn("GL12345");
        when(orisRequest.getPODONbr()).thenReturn("PO123");
        when(orisRequest.getRemarks()).thenReturn("Test remarks");
        when(header.getTraceID()).thenReturn("TRACE123");

        when(fac.getFAC_MGR()).thenReturn("Manager");

        when(connectToWalkerResponse.getConnectToWalkerResult().getEncodedHtmlResponse())
                .thenReturn("mockHtml".getBytes());

        when(walkerResponse.applytxn(any(ApplyTXN.class))).thenReturn(applyTXNResponse);

        List<fac_fmf> facility = Arrays.asList(fac);
        ApplyTXNResponse response = orisVerification.applyTXN(connectToWalkerResponse, sgposServices, facility);

        assertNotNull(response);
    }

    @Test
    void testParseSalesDate_NullInput() {
        Exception exception = assertThrows(NullPointerException.class, () -> {
            orisVerification.parseSalesDate(null);
        });
        assertNotNull(exception);
    }

    @Test
    void testLoggOff_NullApplyTXNResponse() {
        Exception exception = assertThrows(NullPointerException.class, () -> {
            orisVerification.loggOff(null, sgposServices);
        });
        assertNotNull(exception);
    }

    @Test
    void testApplyTXN_FallbackToLQ2Transaction() {
        when(sgposServices.getORISRequest()).thenReturn(null);
        when(sgposServices.getHeader()).thenReturn(header);
        when(header.getFacilityNumber()).thenReturn("123456");
        when(connectToWalkerResponse.getConnectToWalkerResult().getEncodedHtmlResponse())
                .thenReturn("mockHtml".getBytes());
        when(walkerResponse.applytxn(any(ApplyTXN.class))).thenReturn(applyTXNResponse);

        ApplyTXNResponse response = orisVerification.applyTXN(connectToWalkerResponse, sgposServices, facility);
        assertNotNull(response);
        verify(walkerResponse, times(1)).applytxn(any(ApplyTXN.class));
    }
    @Test
    void testApplyTXN_ExceptionWithStoreOpenCloseRequest() {
        when(sgposServices.getORISRequest()).thenReturn(null);
        when(sgposServices.getStoreOpenCloseRequest()).thenReturn(mock(StoreOpenCloseRequest.class));
        when(sgposServices.getHeader()).thenReturn(header);
        when(header.getFacilityNumber()).thenReturn("123456");
        when(header.getTraceID()).thenReturn("TRACE123");
        when(connectToWalkerResponse.getConnectToWalkerResult().getEncodedHtmlResponse())
                .thenReturn("mockHtml".getBytes());
        when(walkerResponse.applytxn(any(ApplyTXN.class))).thenThrow(new RuntimeException("Timeout"));
        when(buildErrorResponseUtil.buildErrorResponseAdd(any(), eq("PARTIAL_APPROVED"))).thenReturn(sgposServices);

        ApplyTXNResponse response = orisVerification.applyTXN(connectToWalkerResponse, sgposServices, facility);
        assertNotNull(response);
    }

@Test
void testApplyTXN_ExceptionWithORISRequest() {
    when(sgposServices.getORISRequest()).thenReturn(orisRequest);
    when(orisRequest.getRequestType()).thenReturn("PREAUTH");
    when(sgposServices.getHeader()).thenReturn(header);
    when(header.getFacilityNumber()).thenReturn("123456");
    when(connectToWalkerResponse.getConnectToWalkerResult().getEncodedHtmlResponse())
        .thenReturn("mockHtml".getBytes());
    when(walkerResponse.applytxn(any(ApplyTXN.class))).thenThrow(new RuntimeException("Timeout"));
    when(buildErrorResponseUtil.buildErrorResponseAdd(any(), eq("ORIS_TIME_OUT"))).thenReturn(sgposServices);

    ApplyTXNResponse response = orisVerification.applyTXN(connectToWalkerResponse, sgposServices, facility);
    assertNotNull(response);
}
@Test
void testApplyTXN_FinalauthRequest_NullOptionalFields() {
    when(sgposServices.getORISRequest()).thenReturn(orisRequest);
    when(orisRequest.getRequestType()).thenReturn("FINALAUTH");
    when(orisRequest.getCustomerID()).thenReturn("CUST123");
    when(orisRequest.getReceivableType()).thenReturn("ABC12");
    when(orisRequest.getBillingToOffice()).thenReturn("BILLTO");
    when(orisRequest.getBusinessDate()).thenReturn("120515103040");
    when(orisRequest.getAmount()).thenReturn("100.00");
    when(orisRequest.getFacPhoneNum()).thenReturn("1234567890");
    when(orisRequest.getCashierNameTag()).thenReturn("Cashier");
    when(orisRequest.getReceivedBy()).thenReturn("Receiver");
    when(orisRequest.getInvoiceQuantity()).thenReturn("10");
    when(orisRequest.getGLAccountNumber()).thenReturn("GL12345");
    when(orisRequest.getPODONbr()).thenReturn(null); // <=== important
    when(orisRequest.getRemarks()).thenReturn(null);  // <=== important
    when(header.getTraceID()).thenReturn("TRACE123");

    when(fac.getFAC_MGR()).thenReturn("Manager");
    when(connectToWalkerResponse.getConnectToWalkerResult().getEncodedHtmlResponse())
            .thenReturn("mockHtml".getBytes());
    when(walkerResponse.applytxn(any(ApplyTXN.class))).thenReturn(applyTXNResponse);

    List<fac_fmf> facility = Arrays.asList(fac);
    ApplyTXNResponse response = orisVerification.applyTXN(connectToWalkerResponse, sgposServices, facility);

    assertNotNull(response);
}
    @Test
    void testApplyTXN_ExceptionWithStoreOpenCloseRequestSaveMessage() {
        StoreOpenCloseRequest storeOpenCloseRequest = mock(StoreOpenCloseRequest.class);
        when(sgposServices.getStoreOpenCloseRequest()).thenReturn(storeOpenCloseRequest);
        when(storeOpenCloseRequest.getBusinessDate()).thenReturn("20250806");
        when(storeOpenCloseRequest.getRequestType()).thenReturn("OPEN");

        when(sgposServices.getHeader()).thenReturn(header);
        when(header.getTraceID()).thenReturn("TRACE123");
        when(header.getFacilityNumber()).thenReturn("FAC001");

        when(connectToWalkerResponse.getConnectToWalkerResult().getEncodedHtmlResponse()).thenReturn("mockHtml".getBytes());

        when(walkerResponse.applytxn(any(ApplyTXN.class)))
                .thenThrow(new RuntimeException("Timeout error"));

        when(buildErrorResponseUtil.buildErrorResponseAdd(any(), eq("PARTIAL_APPROVED"))).thenReturn(sgposServices);

        ApplyTXNResponse response = orisVerification.applyTXN(connectToWalkerResponse, sgposServices, facility);

        assertNotNull(response);

        verify(resaQueueRepository, times(1)).save(any());
        verify(buildErrorResponseUtil, times(1)).buildErrorResponseAdd(sgposServices, "PARTIAL_APPROVED");
    }
    @Test
    void testApplyTXN_ExceptionWithORISRequestOnly() {
        when(sgposServices.getStoreOpenCloseRequest()).thenReturn(null);
        when(sgposServices.getORISRequest()).thenReturn(orisRequest);
        when(orisRequest.getRequestType()).thenReturn("UNKNOWN");
        when(sgposServices.getHeader()).thenReturn(header);
        when(header.getFacilityNumber()).thenReturn("123456");
        when(connectToWalkerResponse.getConnectToWalkerResult().getEncodedHtmlResponse())
                .thenReturn("mockHtml".getBytes());

        when(walkerResponse.applytxn(any(ApplyTXN.class)))
                .thenThrow(new RuntimeException("ORIS timeout"));

        when(buildErrorResponseUtil.buildErrorResponseAdd(any(), eq("ORIS_TIME_OUT"))).thenReturn(sgposServices);

        ApplyTXNResponse response = orisVerification.applyTXN(connectToWalkerResponse, sgposServices, facility);

        assertNotNull(response);

        verify(resaQueueRepository, never()).save(any());
        verify(buildErrorResponseUtil, times(1)).buildErrorResponseAdd(sgposServices, "ORIS_TIME_OUT");
    }

    @Test
    void testApplyTXN_ExceptionWithNoRequestObjects() {
        when(sgposServices.getStoreOpenCloseRequest()).thenReturn(null);
        when(sgposServices.getORISRequest()).thenReturn(null);
        when(connectToWalkerResponse.getConnectToWalkerResult().getEncodedHtmlResponse()).thenReturn("mockHtml".getBytes());

        when(walkerResponse.applytxn(any(ApplyTXN.class)))
                .thenThrow(new RuntimeException("Generic ORIS error"));

        when(buildErrorResponseUtil.buildErrorResponseAdd(any(), eq("ORIS_TIME_OUT"))).thenReturn(sgposServices);

        ApplyTXNResponse response = orisVerification.applyTXN(connectToWalkerResponse, sgposServices, facility);

        assertNotNull(response);

        verify(resaQueueRepository, never()).save(any());
        verify(buildErrorResponseUtil, times(1)).buildErrorResponseAdd(sgposServices, "ORIS_TIME_OUT");
    }


}