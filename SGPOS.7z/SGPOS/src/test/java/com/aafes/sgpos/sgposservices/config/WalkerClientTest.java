/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aafes.sgpos.sgposservices.config;
import com.aafes.sgpos.sgposservices.Config.WalkerClient;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.client.core.SoapActionCallback;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;

/**
 *
 * @author bhendarkart
 */
public class WalkerClientTest {
    private WalkerClient walkerClient;
    private WebServiceTemplate webServiceTemplate;

    @BeforeEach
    public void setUp() {
        walkerClient = new WalkerClient();
        webServiceTemplate = Mockito.mock(WebServiceTemplate.class);
        walkerClient.setWebServiceTemplate(webServiceTemplate);
    }

    @Test
    public void testCallWebService_shouldReturnExpectedResponse() {
        Object mockRequest = new Object();
        Object mockResponse = new Object();
        String soapActionUrl = "http://mock-soap-action-url";

        // Mock behavior
        Mockito.when(webServiceTemplate.marshalSendAndReceive(eq(mockRequest), any(SoapActionCallback.class)))
                .thenReturn(mockResponse);

        // Execute
        Object response = walkerClient.callWebService("http://endpoint-url", mockRequest, soapActionUrl);

        // Verify
        assertNotNull(response);
        assertEquals(mockResponse, response);
    }
}
