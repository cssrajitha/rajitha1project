/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aafes.sgpos.sgposservices.config;

/**
 *
 * @author bhendarkart
 */
import com.aafes.sgpos.sgposservices.Config.EncryptorConfig;
import com.aafes.sgpos.sgposservices.Config.MysqlConfig;
import java.lang.reflect.Field;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.test.util.ReflectionTestUtils;

import javax.sql.DataSource;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class MysqlConfigTest {

    private MysqlConfig mysqlConfig;
    private EncryptorConfig encryptorConfig;

    @BeforeEach
    void setUp() {
        mysqlConfig = new MysqlConfig();

        // Inject private fields using ReflectionTestUtils
        ReflectionTestUtils.setField(mysqlConfig, "url", "jdbc:mysql://localhost:3306/testdb");
        ReflectionTestUtils.setField(mysqlConfig, "username", "testuser");
        ReflectionTestUtils.setField(mysqlConfig, "encryptedPassword", "encryptedPass");

        // Create mock EncryptorConfig
        encryptorConfig = mock(EncryptorConfig.class);
        when(encryptorConfig.decrypt("encryptedPass")).thenReturn("decryptedPass");

        // Inject mock encryptor
        ReflectionTestUtils.setField(mysqlConfig, "encryptorConfig", encryptorConfig);

    }

    @Test
    void testDataSourceBean_shouldInitializeCorrectly() {
        // Create config instance
        MysqlConfig mysqlConfig = new MysqlConfig();

        // Inject private fields
        ReflectionTestUtils.setField(mysqlConfig, "url", "jdbc:mysql://localhost:3306/testdb");
        ReflectionTestUtils.setField(mysqlConfig, "username", "testuser");
        ReflectionTestUtils.setField(mysqlConfig, "encryptedPassword", "secret123");

        // Mock encryptor and inject
        EncryptorConfig encryptorConfig = mock(EncryptorConfig.class);
        when(encryptorConfig.decrypt("secret123")).thenReturn("decryptedPass");
        ReflectionTestUtils.setField(mysqlConfig, "encryptorConfig", encryptorConfig);

        // Call method
        DataSource dataSource = mysqlConfig.dataSource();

        // Verify data source
        assertNotNull(dataSource, "DataSource should not be null");

        // Print class name for clarity
        System.out.println("DataSource type: " + dataSource.getClass().getName());

        // If it’s not exactly DriverManagerDataSource, allow subclass/override
        assertTrue(dataSource.getClass().getName().contains("DriverManagerDataSource"), "Unexpected DataSource type");

        // Cast safely
        DriverManagerDataSource driverSource = (DriverManagerDataSource) dataSource;
        assertEquals("jdbc:mysql://localhost:3306/testdb", driverSource.getUrl());
        assertEquals("testuser", driverSource.getUsername());
        assertEquals("decryptedPass", driverSource.getPassword());
    }




}
