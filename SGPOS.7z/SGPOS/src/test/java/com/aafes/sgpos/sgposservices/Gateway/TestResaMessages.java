/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aafes.sgpos.sgposservices.Gateway;
import com.aafes.sgpos.sgposservices.Config.EncryptorConfig;
import com.aafes.sgpos.sgposservices.Repository.storeOpenCloseMessagesRepository;
import com.aafes.sgpos.sgposservices.Control.storeOpenCloseMessagesStatus;
import com.aafes.sgpos.sgposservices.generated.Control.SGPOSServices;
import com.aafes.sgpos.sgposservices.generated.Control.StoreOpenCloseRequest;
import com.aafes.sgpos.sgposservices.generated.Control.Header;
import com.aafes.sgpos.sgposservices.util.BuildErrorResponseUtil;
import jakarta.jms.BytesMessage;
import jakarta.jms.JMSException;
import org.mockito.quality.Strictness;

import jakarta.jms.Message;
import jakarta.jms.Session;

import org.json.simple.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import org.springframework.jms.core.JmsOperations;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import org.mockito.junit.jupiter.MockitoSettings;
import org.springframework.jms.JmsException;
import org.springframework.jms.core.MessageCreator;


/**
 *
 * @author bhendarkart
 */
@MockitoSettings(strictness = Strictness.LENIENT)
@ExtendWith(MockitoExtension.class)
public class TestResaMessages {

    @Mock
    private JmsOperations jmsOperations;

    @Mock
    private storeOpenCloseMessagesRepository resaQueueRepository;

    @Mock
    private BuildErrorResponseUtil buildErrorResponseUtil;

    @Mock
    private SGPOSServices sgposservices;

    @Mock
    private Header header;

    @Mock
    private StoreOpenCloseRequest storeOpenCloseRequest;

    @Test
    void testFormatRecordProducesExpectedOutput() {
        ResaMessages service = new ResaMessages(null); // JmsTemplate is unused here

        storeOpenCloseMessagesStatus msg = new storeOpenCloseMessagesStatus();
        msg.setMsgSendDateTime("240716123456");
        msg.setFacilityNumber("123");
        msg.setStoreStatus("OPEN");
        msg.setDateAndTimeStamp("2025-07-16");

        String formatted = service.formatRecord(msg);
        assertEquals("240716123456,123,OPEN,2025-07-16", formatted);
    }

    @Test
    void testSendMessageReturnsSuccess() {
        ResaMessages service = new ResaMessages(null);

        // Inject only what's required
        ReflectionTestUtils.setField(service, "requestQ", "DUMMY.Q");
        ReflectionTestUtils.setField(service, "jmsOperations", jmsOperations);

        // Minimal necessary stubbing for success scenario
        Header header = mock(Header.class);
        when(header.getTraceID()).thenReturn("TRACE123");
        when(sgposservices.getHeader()).thenReturn(header);

        // Simulate successful send
        doNothing().when(jmsOperations).send(anyString(), any());

        String result = service.sendMessage("OPEN,123,2025-07-16", sgposservices);
        assertEquals("SUCCESS", result);
    }


    @Test
    void testSendMessageHandlesJmsException() {
        ResaMessages service = new ResaMessages(null);
        ReflectionTestUtils.setField(service, "requestQ", "DUMMY.Q");
        ReflectionTestUtils.setField(service, "jmsOperations", jmsOperations);
        ReflectionTestUtils.setField(service, "resaQueueRepository", resaQueueRepository);
        ReflectionTestUtils.setField(service, "buildErrorResponseUtil", buildErrorResponseUtil);

        when(sgposservices.getHeader()).thenReturn(header);
        when(header.getTraceID()).thenReturn("TRACE123");
        when(header.getFacilityNumber()).thenReturn("FAC001");
        when(sgposservices.getStoreOpenCloseRequest()).thenReturn(storeOpenCloseRequest);
        when(storeOpenCloseRequest.getRequestType()).thenReturn("OPEN");
        when(storeOpenCloseRequest.getBusinessDate()).thenReturn("2025-07-16");

        when(buildErrorResponseUtil.buildErrorResponseAdd(any(), eq("PARTIAL_APPROVED"))).thenReturn(sgposservices);
        doThrow(new JmsException("Simulated MQ error") {}).when(jmsOperations).send(anyString(), any());

        String result = service.sendMessage("OPEN,123,2025-07-16", sgposservices);

        assertEquals("FAILED", result);
        verify(resaQueueRepository, times(1)).save(any());
        verify(buildErrorResponseUtil, times(1)).buildErrorResponseAdd(any(), eq("PARTIAL_APPROVED"));
    }
    @Test
    void testBookToResaRunsSuccessfully() {
        ResaMessages service = new ResaMessages(null);

        // Inject required dependencies
        ReflectionTestUtils.setField(service, "requestQ", "TEST.Q");
        ReflectionTestUtils.setField(service, "jmsOperations", jmsOperations);
        ReflectionTestUtils.setField(service, "resaQueueRepository", resaQueueRepository);
        ReflectionTestUtils.setField(service, "buildErrorResponseUtil", buildErrorResponseUtil);

        // Mock SGPOSServices structure
        when(sgposservices.getHeader()).thenReturn(header);
        when(sgposservices.getStoreOpenCloseRequest()).thenReturn(storeOpenCloseRequest);
        when(header.getFacilityNumber()).thenReturn("FAC001");
        when(header.getTraceID()).thenReturn("TRACE123");
        when(storeOpenCloseRequest.getRequestType()).thenReturn("OPEN");
        when(storeOpenCloseRequest.getBusinessDate()).thenReturn("2025-07-16");

        // Run the method
        service.bookToResa(sgposservices);

        // Verify sendMessage was invoked via MQ
        verify(jmsOperations, atLeastOnce()).send(anyString(), any());
    }
    @Test
void testBookToResaTriggersMessageSendWithExpectedPayload() {
    ResaMessages service = new ResaMessages(null);
    ReflectionTestUtils.setField(service, "requestQ", "MOCK.Q");
    ReflectionTestUtils.setField(service, "jmsOperations", jmsOperations);

    Header header = mock(Header.class);
    when(header.getFacilityNumber()).thenReturn("FAC001");
    when(header.getTraceID()).thenReturn("TRACE123");

    StoreOpenCloseRequest request = mock(StoreOpenCloseRequest.class);
    when(request.getRequestType()).thenReturn("CLOSE");
    when(request.getBusinessDate()).thenReturn("2025-07-17");

    when(sgposservices.getHeader()).thenReturn(header);
    when(sgposservices.getStoreOpenCloseRequest()).thenReturn(request);

    doNothing().when(jmsOperations).send(anyString(), any());

    service.bookToResa(sgposservices);

    verify(jmsOperations).send(contains("MOCK.Q"), any());
}
    @Test
    void testMessageCreationInsideSendMessage() throws JMSException {
        ResaMessages service = new ResaMessages(null);
        ReflectionTestUtils.setField(service, "requestQ", "TEST.Q");
        ReflectionTestUtils.setField(service, "jmsOperations", jmsOperations);

        Session mockSession = mock(Session.class);
        BytesMessage mockMessage = mock(BytesMessage.class);

        when(mockSession.createBytesMessage()).thenReturn(mockMessage);

        // Capture the lambda passed to send
        ArgumentCaptor<MessageCreator> captor = ArgumentCaptor.forClass(MessageCreator.class);
        doNothing().when(jmsOperations).send(anyString(), captor.capture());

        Header header = mock(Header.class);
        when(header.getFacilityNumber()).thenReturn("FAC001");
        when(header.getTraceID()).thenReturn("TRACE123");
        StoreOpenCloseRequest request = mock(StoreOpenCloseRequest.class);
        when(request.getRequestType()).thenReturn("OPEN");
        when(request.getBusinessDate()).thenReturn("2025-07-16");

        when(sgposservices.getHeader()).thenReturn(header);
        when(sgposservices.getStoreOpenCloseRequest()).thenReturn(request);

        String result = service.sendMessage("OPEN,FAC001,2025-07-16", sgposservices);
        assertEquals("SUCCESS", result);

        // Trigger the captured MessageCreator logic
        MessageCreator creator = captor.getValue();
        creator.createMessage(mockSession);

        verify(mockSession, times(1)).createBytesMessage();
        verify(mockMessage).setJMSCorrelationID(anyString());
        verify(mockMessage).writeBytes(any());
    }
    @Test
    void testTransIdSetterAndGetter() {
        ResaMessages service = new ResaMessages(null);
        service.setTransId("TX12345");
        assertEquals("TX12345", service.getTransId());
    }

    @Test
    void testRequestQSetterAndGetter() {
        ResaMessages service = new ResaMessages(null);
        service.setRequestQ("QUEUE.TEST");
        assertEquals("QUEUE.TEST", service.getRequestQ());
    }
    @Test
    void testLogASCIIMethodViaReflection() throws Exception {
        ResaMessages service = new ResaMessages(null);

        String label = "Payload: ";
        byte[] payload = "Hello World".getBytes("UTF-8");

        java.lang.reflect.Method method = ResaMessages.class.getDeclaredMethod("logASCII", String.class, byte[].class);
        method.setAccessible(true); // override visibility

        // No exception expected, just verifying invocation
        method.invoke(service, label, payload);
    }

}