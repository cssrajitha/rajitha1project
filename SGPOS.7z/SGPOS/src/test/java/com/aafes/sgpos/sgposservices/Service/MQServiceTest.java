package com.aafes.sgpos.sgposservices.Service;


import com.aafes.sgpos.sgposservices.Exception.GatewayException;
import com.aafes.sgpos.sgposservices.Gateway.MQMessage;
import com.aafes.sgpos.sgposservices.Config.EncryptorConfig;
import com.aafes.sgpos.sgposservices.generated.Control.CVSRequest;
import com.aafes.sgpos.sgposservices.generated.Control.IGLASRequest;
import com.aafes.sgpos.sgposservices.generated.Control.SGPOSServices;
import com.aafes.sgpos.sgposservices.util.BuildErrorResponseUtil;
import com.ibm.msg.client.jakarta.wmq.WMQConstants;
import jakarta.jms.*;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class MQServiceTest {

    @InjectMocks
    private MQService mqService;

    @Mock
    private BuildErrorResponseUtil buildErrorResponseUtil;

    @Mock
    private EncryptorConfig encryptorConfig;

    @Mock
    private MQMessage mqMessage;

    @Mock
    private SGPOSServices sgposServices;

    @Mock
    private BytesMessage bytesMessage;

    @Mock
    private TextMessage textMessage;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(mqService, "replyToQ", "testQueue");
    }


@Test
void testMQConnection_WithBytesMessage_ShouldReturnAsciiResponse() throws Exception {
    byte[] fullPayload = new byte[300];
    String testAscii = "TestASCII";

    // Place ASCII content at offset 195
    System.arraycopy(testAscii.getBytes(StandardCharsets.US_ASCII), 0, fullPayload, 195, testAscii.length());

    when(mqMessage.sendMessageQue(anyString(), anyString(), eq(sgposServices))).thenReturn(bytesMessage);
    when(bytesMessage.getBodyLength()).thenReturn((long) fullPayload.length);
    doAnswer(invocation -> {
        byte[] buffer = invocation.getArgument(0);
        System.arraycopy(fullPayload, 0, buffer, 0, fullPayload.length);
        return null;
    }).when(bytesMessage).readBytes(any(byte[].class));

    when(bytesMessage.getStringProperty(WMQConstants.JMS_IBM_CHARACTER_SET)).thenReturn("US-ASCII");
    when(sgposServices.getCVSRequest()).thenReturn(this.request());

    String result = mqService.mqConnection("TestPayload", sgposServices);

    // Clean control characters and trailing whitespace
    String cleanedResult = result.replaceAll("[\\p{C}\\p{Z}]", "").strip();

    assertEquals(testAscii, cleanedResult, "Expected sanitized ASCII response");
}


    @Test
    void testMQConnection_WithTextMessage_ShouldReturnNull() throws Exception {
        when(mqMessage.sendMessageQue(anyString(), anyString(), eq(sgposServices))).thenReturn(textMessage);
        when(textMessage.getText()).thenReturn("TextPayload");
        when(sgposServices.getCVSRequest()).thenReturn(this.request());

        String result = mqService.mqConnection("TestPayload", sgposServices);

        assertNull(result);  // method does not extract text from TextMessage
    }
public CVSRequest request(){
        CVSRequest request =new CVSRequest();
       // request.setRequestType("Inquiry");
    request.setCustomerID("2106910847");
    request.setCustomerType(CVSRequest.CustomerType.valueOf("EDIPI"));
    request.setCashbackRequestedAmount("100");
    return request;
}
    public IGLASRequest Irequest(){
        IGLASRequest request =new IGLASRequest();
         request.setCbn("e");
        request.setFunctionCode("Sales");
        request.setCashierNumber("123       ");
        request.setExpiryDate("    ");
        request.setAccount("                   ");
        request.setAmount("00000000");
        request.setTranCode("N05");
        request.setTransF1("     ");
        request.setAuthLevel("0");
        request.setAuthKey("N");
        request.setAuthSupervisor("N");
        request.setReasonCode("000");
        request.setReasonDescription("VALIDATION");
        request.setLen(" ");
        request.setFacIdentifier("F2:");
        request.setFacilityNumber("1367507100");
        request.setRecordSeperator2("\u001E");
        request.setEtx(" ");
        return request;
    }
    @Test
    void testMQConnection_WithNullMessage_ShouldCallTimeoutHandler() throws Exception {
        when(mqMessage.sendMessageQue(anyString(), anyString(), eq(sgposServices))).thenReturn(null);
        when(sgposServices.getCVSRequest()).thenReturn(this.request());

        mqService.mqConnection("TestPayload", sgposServices);

        assertTrue(true);
    }

    @Test
    void testMQConnection_WithGatewayException_ShouldCallErrorResponse() throws Exception {
        when(mqMessage.sendMessageQue(anyString(), anyString(), eq(sgposServices)))
                .thenThrow(new GatewayException("Mock MQ failure"));
        when(sgposServices.getIGLASRequest()).thenReturn(this.Irequest());

        mqService.mqConnection("TestPayload", sgposServices);

        verify(buildErrorResponseUtil).buildErrorResponseAdd(eq(sgposServices), eq("IGLAS_TIME_OUT"));
    }

    @Test
    void testMQConnection_WithGenericException_ShouldCallErrorResponse() throws Exception {
        when(mqMessage.sendMessageQue(anyString(), anyString(), eq(sgposServices)))
                .thenThrow(new RuntimeException("Unexpected error"));
        when(sgposServices.getCVSRequest()).thenReturn(this.request());

        mqService.mqConnection("TestPayload", sgposServices);

        verify(buildErrorResponseUtil).buildErrorResponseAdd(eq(sgposServices), eq("CVS_TIME_OUT"));
    }
    @Test
    void testMQConnection_WithUnknownMessageType_ShouldReturnNull() throws Exception {
        Message mockMessage = mock(Message.class);
        when(mqMessage.sendMessageQue(any(), any(), any())).thenReturn(mockMessage);
        when(sgposServices.getIGLASRequest()).thenReturn(Irequest());

        String result = mqService.mqConnection("Payload", sgposServices);
        assertNull(result);
    }
    @Test
    void testMQConnection_WithNoRequestType_ShouldHandleGracefully() throws Exception {
        when(mqMessage.sendMessageQue(any(), any(), any())).thenReturn(null);
        when(sgposServices.getCVSRequest()).thenReturn(null);
        when(sgposServices.getIGLASRequest()).thenReturn(null);

        String result = mqService.mqConnection("Payload", sgposServices);
        assertNull(result);
    }
    @Test
    void testGetCorrelationIDWithCalendar_ShouldReturnValidByteArray() throws Exception {
        // Use reflection to access the private static method
        Method method = MQService.class.getDeclaredMethod("getCorrelationIDWithCalendar");
        method.setAccessible(true);

        byte[] correlationIdBytes = (byte[]) method.invoke(null); // static method, so target is null
        String correlationId = new String(correlationIdBytes, StandardCharsets.UTF_8);

        // Verify length
        assertEquals(24, correlationIdBytes.length, "Correlation ID should be exactly 24 bytes");

        // Verify basic format components
        assertTrue(correlationId.matches("\\d{4}\\d{4}[a-zA-Z0-9]{16}"),
                   "Correlation ID should start with year + day-of-year followed by UUID part");
    }
    @Test
    void testMQConnection_BytesMessage_WithProperOffsetExtraction() throws Exception {
        byte[] fullPayload = new byte[300];
        String expectedText = "10";
        byte[] asciiText = expectedText.getBytes(StandardCharsets.US_ASCII);

        // Clear all bytes
        Arrays.fill(fullPayload, (byte) 0x00);

        // Place "10" at offset 195
        System.arraycopy(asciiText, 0, fullPayload, 195, asciiText.length);

        // Truncate all bytes beyond expected
        for (int i = 195 + asciiText.length; i < fullPayload.length; i++) {
            fullPayload[i] = (byte) ' '; // Use space padding or 0x00
        }

        // Mock MQ behavior
        when(mqMessage.sendMessageQue(any(), any(), eq(sgposServices))).thenReturn(bytesMessage);
        when(bytesMessage.getBodyLength()).thenReturn((long) fullPayload.length);
        doAnswer(invocation -> {
            byte[] buffer = invocation.getArgument(0);
            System.arraycopy(fullPayload, 0, buffer, 0, fullPayload.length);
            return null;
        }).when(bytesMessage).readBytes(any());

        when(bytesMessage.getStringProperty(WMQConstants.JMS_IBM_CHARACTER_SET)).thenReturn("US-ASCII");
        when(sgposServices.getCVSRequest()).thenReturn(request());

        String actual = mqService.mqConnection("payload", sgposServices);

        // Use .strip() or explicitly compare
        assertEquals(expectedText, actual.strip());
}
    @Test
    void testMQConnection_WithIGLASRequest_ShouldLogResponse() throws Exception {
        // Simulate a valid message with response payload
        byte[] dummyPayload = "IGLAS Response".getBytes(StandardCharsets.US_ASCII);
        byte[] fullPayload = new byte[250];
        System.arraycopy(dummyPayload, 0, fullPayload, 195, dummyPayload.length);

        when(mqMessage.sendMessageQue(anyString(), anyString(), eq(sgposServices))).thenReturn(bytesMessage);
        when(bytesMessage.getBodyLength()).thenReturn((long) fullPayload.length);
        doAnswer(invocation -> {
            byte[] buffer = invocation.getArgument(0);
            System.arraycopy(fullPayload, 0, buffer, 0, fullPayload.length);
            return null;
        }).when(bytesMessage).readBytes(any());
        when(bytesMessage.getStringProperty(WMQConstants.JMS_IBM_CHARACTER_SET)).thenReturn("US-ASCII");

        when(sgposServices.getCVSRequest()).thenReturn(null);
        when(sgposServices.getIGLASRequest()).thenReturn(Irequest());

        String result = mqService.mqConnection("TestPayload", sgposServices);
        assertTrue(result.contains("IGLAS Response"));
    }
    @Test
    void testMQConnection_WithException_ShouldFallbackToCVSTimeout() throws Exception {
        when(mqMessage.sendMessageQue(anyString(), anyString(), eq(sgposServices))).thenThrow(new RuntimeException("Boom"));
        when(sgposServices.getCVSRequest()).thenReturn(request());

        mqService.mqConnection("Payload", sgposServices);

        verify(buildErrorResponseUtil).buildErrorResponseAdd(sgposServices, "CVS_TIME_OUT");
    }

    @Test
    void testMQConnection_WithException_ShouldFallbackToIGLASTimeout() throws Exception {
        when(mqMessage.sendMessageQue(anyString(), anyString(), eq(sgposServices))).thenThrow(new RuntimeException("Boom"));
        when(sgposServices.getCVSRequest()).thenReturn(null);
        when(sgposServices.getIGLASRequest()).thenReturn(Irequest());

        mqService.mqConnection("Payload", sgposServices);

        verify(buildErrorResponseUtil).buildErrorResponseAdd(sgposServices, "IGLAS_TIME_OUT");
    }
    @Test
    void testMQConnection_MessagePresentButEmptyString_CVSRequestTriggersTimeout() throws Exception {
        Message mockMessage = mock(Message.class);

        when(mqMessage.sendMessageQue(anyString(), anyString(), eq(sgposServices))).thenReturn(mockMessage);
        when(mockMessage.toString()).thenReturn(""); // triggers the ELSE block

        when(sgposServices.getCVSRequest()).thenReturn(request()); // CVS request exists
        when(sgposServices.getIGLASRequest()).thenReturn(null);

        when(buildErrorResponseUtil.buildErrorResponseAdd(eq(sgposServices), eq("CVS_TIME_OUT"))).thenReturn(sgposServices);

        mqService.mqConnection("TestPayload", sgposServices);

        verify(buildErrorResponseUtil, times(1)).buildErrorResponseAdd(sgposServices, "CVS_TIME_OUT");
    }
    @Test
    void testMQConnection_MessagePresentButEmptyString_IGLASRequestTriggersTimeout() throws Exception {
        Message mockMessage = mock(Message.class);

        when(mqMessage.sendMessageQue(anyString(), anyString(), eq(sgposServices))).thenReturn(mockMessage);
        when(mockMessage.toString()).thenReturn(""); // triggers the ELSE block

        when(sgposServices.getCVSRequest()).thenReturn(null);
        when(sgposServices.getIGLASRequest()).thenReturn(Irequest());

        when(buildErrorResponseUtil.buildErrorResponseAdd(eq(sgposServices), eq("IGLAS_TIME_OUT"))).thenReturn(sgposServices);

        mqService.mqConnection("TestPayload", sgposServices);

        verify(buildErrorResponseUtil, times(1)).buildErrorResponseAdd(sgposServices, "IGLAS_TIME_OUT");
    }
    @Test
    void testMQConnection_GatewayExceptionWithCVSRequest_ShouldHandleTimeout() throws Exception {
        // Arrange
        when(mqMessage.sendMessageQue(anyString(), anyString(), eq(sgposServices)))
                .thenThrow(new GatewayException("Simulated MQ failure"));

        // CVSRequest exists → triggers the if block
        when(sgposServices.getCVSRequest()).thenReturn(request());
        when(sgposServices.getIGLASRequest()).thenReturn(null);

        when(buildErrorResponseUtil.buildErrorResponseAdd(eq(sgposServices), eq("CVS_TIME_OUT")))
                .thenReturn(sgposServices);

        // Act
        String result = mqService.mqConnection("TestPayload", sgposServices);

        // Assert
        assertNull(result);  // no actual return expected
        verify(buildErrorResponseUtil, times(1)).buildErrorResponseAdd(sgposServices, "CVS_TIME_OUT");
    }

}
