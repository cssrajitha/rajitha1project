/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aafes.sgpos.sgposservices.ControlTest;
import com.aafes.sgpos.sgposservices.Control.storeOpenCloseMessagesStatus;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author bhendarkart
 */
public class storeOpenCloseMessagesStatusTest {

    @Test
    void testGettersAndSetters() {
        storeOpenCloseMessagesStatus status = new storeOpenCloseMessagesStatus();

        status.setMsgSendDateTime("2025-07-24T10:00:00");
        status.setFacilityNumber("FAC-12345");
        status.setStoreStatus("OPEN");
        status.setDateAndTimeStamp("2025-07-24T10:01:00");

        assertEquals("2025-07-24T10:00:00", status.getMsgSendDateTime());
        assertEquals("FAC-12345", status.getFacilityNumber());
        assertEquals("OPEN", status.getStoreStatus());
        assertEquals("2025-07-24T10:01:00", status.getDateAndTimeStamp());
    }

    @Test
    void testToStringMethod() {
        storeOpenCloseMessagesStatus status = new storeOpenCloseMessagesStatus();
        status.setMsgSendDateTime("2025-07-24T08:00:00");
        status.setFacilityNumber("FAC-99999");
        status.setStoreStatus("CLOSED");
        status.setDateAndTimeStamp("2025-07-24T08:30:00");

        String output = status.toString();

        assertTrue(output.contains("msgSendDateTime='2025-07-24T08:00:00'"));
        assertTrue(output.contains("facilityNumber='FAC-99999'"));
        assertTrue(output.contains("storeStatus='CLOSED'"));
        assertTrue(output.contains("dateAndTimeStamp='2025-07-24T08:30:00'"));
    }

    @Test
    void testDefaultValuesAreNull() {
        storeOpenCloseMessagesStatus status = new storeOpenCloseMessagesStatus();

        assertNull(status.getMsgSendDateTime());
        assertNull(status.getFacilityNumber());
        assertNull(status.getStoreStatus());
        assertNull(status.getDateAndTimeStamp());
    }
}
