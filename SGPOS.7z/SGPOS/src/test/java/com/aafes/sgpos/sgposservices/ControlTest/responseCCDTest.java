/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aafes.sgpos.sgposservices.ControlTest;
import com.aafes.sgpos.sgposservices.Control.responseCCD;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author bhendarkart
 */
public class responseCCDTest {
    
    @Test
    void testSettersAndGetters() {
        responseCCD response = new responseCCD();

        response.setRespStatus("SUCCESS");
        response.setRespMessage("Operation completed");
        response.setDODEDIPersonalId("DODEDI-12345");
        Object dummyCustomer = new Object();
        response.setCustomer(dummyCustomer);

        assertEquals("SUCCESS", response.getRespStatus());
        assertEquals("Operation completed", response.getRespMessage());
        assertEquals("DODEDI-12345", response.getDODEDIPersonalId());
        assertEquals(dummyCustomer, response.getCustomer());
    }

    @Test
    void testToStringIncludesFields() {
        responseCCD response = new responseCCD();
        response.setRespStatus("FAILURE");
        response.setRespMessage("Unauthorized access");
        response.setDODEDIPersonalId("DODEDI-99999");
        response.setCustomer("SampleCustomer");

        String toString = response.toString();

        assertTrue(toString.contains("respStatus='FAILURE'"));
        assertTrue(toString.contains("respMessage='Unauthorized access'"));
        assertTrue(toString.contains("DODEDIPersonalId='DODEDI-99999'"));
        assertTrue(toString.contains("Customer=SampleCustomer"));
    }

    @Test
    void testDefaultValuesAreNull() {
        responseCCD response = new responseCCD();

        assertNull(response.getRespStatus());
        assertNull(response.getRespMessage());
        assertNull(response.getDODEDIPersonalId());
        assertNull(response.getCustomer());
    }
    
}
