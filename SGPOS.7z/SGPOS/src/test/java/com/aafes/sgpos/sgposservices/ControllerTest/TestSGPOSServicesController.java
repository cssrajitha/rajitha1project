/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aafes.sgpos.sgposservices.ControllerTest;

import com.aafes.sgpos.sgposservices.Controller.SGPOSServicesController;
import com.aafes.sgpos.sgposservices.Service.OauthValidationService;
import com.aafes.sgpos.sgposservices.Control.OauthResponse;
import com.aafes.sgpos.sgposservices.generated.Control.SGPOSServices;
import com.aafes.sgpos.sgposservices.Service.SGPOSServicesservice;
import com.aafes.sgpos.sgposservices.util.BuildErrorResponseUtil;
import com.aafes.sgpos.sgposservices.util.ValidateRequestUtil;
import com.aafes.sgpos.sgposservices.util.ValidateSchemaUtil;
import com.networknt.schema.JsonSchema;
import jakarta.servlet.http.HttpServletResponse;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import com.aafes.sgpos.sgposservices.generated.Control.Response;


/**
 *
 * @author bhendarkart
 */

public class TestSGPOSServicesController {

    @InjectMocks
    private SGPOSServicesController controller;

    @Mock
    private BuildErrorResponseUtil buildErrorResponseUtil;

    @Mock
    private SGPOSServicesservice response;

    @Mock
    private OauthValidationService oauthValidation;

    @Mock
    private JsonSchema schema;

    @Mock
    private HttpServletResponse httpServletResponse;


    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }



    @Test
    public void testAuthorizationHeader_validBearerToken() {
        String header = "Bearer validToken";
        String token = header.split(" ")[1];
        assertEquals("validToken", token);
    }

    @Test
    public void testAuthorizationHeader_invalidFormat() {
        String header = "InvalidTokenFormat";
        String[] parts = header.split(" ");
        String token = parts.length == 2 ? parts[1] : "";
        assertEquals("", token);
    }

    @Test
    public void testOauthValidation_activeTrue() {
        OauthResponse oauthResponse = new OauthResponse();
        oauthResponse.setActive("true");
        JSONObject request = new JSONObject();
        when(oauthValidation.oauthTokenValidation(anyString(), any(JSONObject.class))).thenReturn(oauthResponse);
        assertEquals("true", oauthValidation.oauthTokenValidation("token", request).getActive());
    }

    @Test
    public void testOauthValidation_activeFalse() {
        OauthResponse oauthResponse = new OauthResponse();
        oauthResponse.setActive("false");
        JSONObject request = new JSONObject();
        when(oauthValidation.oauthTokenValidation(anyString(), any(JSONObject.class))).thenReturn(oauthResponse);
        assertEquals("false", oauthValidation.oauthTokenValidation("token", request).getActive());
    }

    @Test
    public void testMaskNumber_validInput() {
        String masked = SGPOSServicesController.maskNumber("1234567890");
        assertEquals("xxxxxxxxxx", masked);
    }

    @Test
    public void testMaskNumber_nullOrEmpty() {
        assertEquals("", SGPOSServicesController.maskNumber(null));
        assertEquals("", SGPOSServicesController.maskNumber(""));
    }

   

    @Test
    public void testSgPosService_invalidToken() throws Exception {
        String gatewayRequest = "{\"header\":{\"traceID\":\"abc123\",\"facilityNumber\":\"001\",\"application\":\"SGPOS\"}}";

        OauthResponse oauthResponse = new OauthResponse();
        oauthResponse.setActive("false");

        when(oauthValidation.oauthTokenValidation(anyString(), any(JSONObject.class)))
                .thenReturn(oauthResponse);

        SGPOSServices actualResponse = controller.sgPosService(gatewayRequest, "Bearer invalidToken", httpServletResponse);

        assertEquals("invalid_token", actualResponse.getAdditionalProperties().get("error"));
        assertEquals("The access token provided is invalid.", actualResponse.getAdditionalProperties().get("error_description"));
        verify(httpServletResponse).setStatus(401);
    }

    @Test
    public void testSGPOSservice_validRequest() throws Exception {
        String gatewayRequest = "{\"header\":{\"traceID\":\"abc123\",\"facilityNumber\":\"001\",\"application\":\"SGPOS\"},\"storeOpenCloseRequest\":{\"requestType\":\"OPEN\"}}";
        JSONObject request = new JSONObject(gatewayRequest);

        // Mock schema and field validation
        ValidateSchemaUtil mockSchemaUtil = mock(ValidateSchemaUtil.class);
        ValidateRequestUtil mockRequestUtil = mock(ValidateRequestUtil.class);
        when(mockSchemaUtil.validateJsonRequest(anyString(), any(), any())).thenReturn("");
        when(mockRequestUtil.validateFieldsAdd(any())).thenReturn("");

        ReflectionTestUtils.setField(controller, "validateSchemaUtil", mockSchemaUtil);
        ReflectionTestUtils.setField(controller, "validateRequestUtil", mockRequestUtil);

        SGPOSServices result = controller.SGPOSservice(gatewayRequest, request);

        assertNotNull(result);
    }
    @Test
    public void testSGPOSservice_schemaValidationFails() throws Exception {
        String gatewayRequest = "{\"header\":{\"traceID\":\"abc123\"}}";
        JSONObject request = new JSONObject(gatewayRequest);

        ValidateSchemaUtil mockSchemaUtil = mock(ValidateSchemaUtil.class);
        when(mockSchemaUtil.validateJsonRequest(anyString(), any(), any())).thenReturn("Schema error");

        ReflectionTestUtils.setField(controller, "validateSchemaUtil", mockSchemaUtil);

        SGPOSServices errorResponse = new SGPOSServices();
        when(buildErrorResponseUtil.buildErrorResponseAdd(any(), eq("INVALID_REQUEST"))).thenReturn(errorResponse);

        SGPOSServices result = controller.SGPOSservice(gatewayRequest, request);

        assertEquals(errorResponse, result);
    }
    @Test
    public void testSchemaInit_success() throws IOException {
        // Create a temporary dummy schema file
        File tempSchemaFile = File.createTempFile("schema", ".json");
        try (FileOutputStream fos = new FileOutputStream(tempSchemaFile)) {
            fos.write("{\"$schema\":\"http://json-schema.org/draft-07/schema#\"}".getBytes());
        }

        // Inject the path into the controller
        ReflectionTestUtils.setField(controller, "pathsgpos", tempSchemaFile.getAbsolutePath());

        // Call the method
        controller.schemaInit();

        // Validate that schemaSgPosServices is initialized
        JsonSchema schema = (JsonSchema) ReflectionTestUtils.getField(controller, "schemaSgPosServices");
        assertNotNull(schema, "Schema should be initialized");

        // Clean up
        tempSchemaFile.deleteOnExit();
    }
    @Test
    public void testRequestType_storeOpenCloseRequest() throws Exception {
        String gatewayRequest = """
    {
        "header": {
            "traceID": "abc123",
            "facilityNumber": "001",
            "application": "SGPOS"
        },
        "storeOpenCloseRequest": {
            "requestType": "OPEN"
        }
    }
    """;

        OauthResponse oauthResponse = new OauthResponse();
        oauthResponse.setActive("true");

        SGPOSServices expectedResponse = new SGPOSServices();
        Response responseObj = new Response();
        responseObj.setReasonCode("00");
        responseObj.setReasonDescription("Success");
        responseObj.setResponse("Approved");
        expectedResponse.setResponse(responseObj);

        when(oauthValidation.oauthTokenValidation(anyString(), any(JSONObject.class)))
                .thenReturn(oauthResponse);

        SGPOSServicesController spyController = Mockito.spy(controller);
        doReturn(expectedResponse).when(spyController).SGPOSservice(anyString(), any(JSONObject.class));

        SGPOSServices actualResponse = spyController.sgPosService(gatewayRequest, "Bearer validToken", httpServletResponse);

        assertEquals("00", actualResponse.getResponse().getReasonCode());
    }

    @Test
    public void testRequestType_CVSRequest_withEmptyType() throws Exception {
        String gatewayRequest = """
    {
        "header": {
            "traceID": "abc123",
            "facilityNumber": "001",
            "application": "SGPOS"
        },
        "CVSRequest": {
            "requestType": ""
        }
    }
    """;

        OauthResponse oauthResponse = new OauthResponse();
        oauthResponse.setActive("true");

        SGPOSServices expectedResponse = new SGPOSServices();
        Response responseObj = new Response();
        responseObj.setReasonCode("00");
        responseObj.setReasonDescription("Success");
        responseObj.setResponse("Approved");
        expectedResponse.setResponse(responseObj);

        when(oauthValidation.oauthTokenValidation(anyString(), any(JSONObject.class)))
                .thenReturn(oauthResponse);

        SGPOSServicesController spyController = Mockito.spy(controller);
        doReturn(expectedResponse).when(spyController).SGPOSservice(anyString(), any(JSONObject.class));

        SGPOSServices actualResponse = spyController.sgPosService(gatewayRequest, "Bearer validToken", httpServletResponse);

        assertEquals("00", actualResponse.getResponse().getReasonCode());
    }

    @Test
    public void testRequestType_IGLASRequest_functionCode() throws Exception {
        String gatewayRequest = """
    {
        "header": {
            "traceID": "abc123",
            "facilityNumber": "001",
            "application": "SGPOS"
        },
        "IGLASRequest": {
            "functionCode": "FUNC123"
        }
    }
    """;

        OauthResponse oauthResponse = new OauthResponse();
        oauthResponse.setActive("true");

        SGPOSServices expectedResponse = new SGPOSServices();
        Response responseObj = new Response();
        responseObj.setReasonCode("00");
        responseObj.setReasonDescription("Success");
        responseObj.setResponse("Approved");
        expectedResponse.setResponse(responseObj);

        when(oauthValidation.oauthTokenValidation(anyString(), any(JSONObject.class)))
                .thenReturn(oauthResponse);

        SGPOSServicesController spyController = Mockito.spy(controller);
        doReturn(expectedResponse).when(spyController).SGPOSservice(anyString(), any(JSONObject.class));

        SGPOSServices actualResponse = spyController.sgPosService(gatewayRequest, "Bearer validToken", httpServletResponse);

        assertEquals("00", actualResponse.getResponse().getReasonCode());
    }

}

