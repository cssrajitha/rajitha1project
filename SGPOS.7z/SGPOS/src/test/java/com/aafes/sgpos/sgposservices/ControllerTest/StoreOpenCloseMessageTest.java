package com.aafes.sgpos.sgposservices.ControllerTest;
import com.aafes.sgpos.sgposservices.Controller.StoreOpenCloseMessagesController;
import com.aafes.sgpos.sgposservices.Entity.storeOpenCloseMessages;
import com.aafes.sgpos.sgposservices.Repository.storeOpenCloseMessagesRepository;
import com.aafes.sgpos.sgposservices.Service.SGPOSServicesservice;
import com.aafes.sgpos.sgposservices.Service.storeOpenCloseProcessingDaysService;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.*;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import java.util.List;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.xpath;
import com.aafes.sgpos.sgposservices.generated.Control.SGPOSServices;


@WebMvcTest(StoreOpenCloseMessagesController.class)
@Import(StoreOpenCloseMessagesController.class)
@AutoConfigureMockMvc(addFilters = false)
public class StoreOpenCloseMessageTest {
   
    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private storeOpenCloseMessagesRepository storeOpenCloseMessagesRepository;

    @MockitoBean
    private storeOpenCloseProcessingDaysService storeOpenCloseProcessingDaysService;

    @MockitoBean
    private SGPOSServicesservice sgposServicesservice;
    
    
    @BeforeEach
    void setup() throws JsonProcessingException{
        when(storeOpenCloseMessagesRepository.findByDate(any()))
            .thenReturn(List.of(new storeOpenCloseMessages()));

        when(storeOpenCloseProcessingDaysService.bookToResa(anyList(), anyList(), any(SGPOSServices.class)))
            .thenReturn(List.of("SUCCESS"));
    }

    @Test
    void testFromToDateReturnsSuccess() throws Exception {
        String xmlRequest = """
            <storeOpenCloseResaQ>
                <fromDate>2024-07-01</fromDate>
                <toDate>2024-07-01</toDate>
                <processDays>1</processDays>
            </storeOpenCloseResaQ>
            """;

        mockMvc.perform(post("/1/storeopenclosemessages")
                .contentType(MediaType.APPLICATION_XML)
                .accept(MediaType.APPLICATION_XML)
                .content(xmlRequest))
            .andExpect(status().isOk())
            .andExpect(xpath("/storeOpenCloseResaQ/ResponseType").string("SUCCESS"));
    }

    @Test
    void testInvalidDateReturnsFailed() throws Exception {
        String xmlRequest = """
            <storeOpenCloseResaQ>
                <fromDate>bad-date</fromDate>
                <toDate>bad-date</toDate>
                <processDays>1</processDays>
            </storeOpenCloseResaQ>
            """;

        mockMvc.perform(post("/1/storeopenclosemessages")
                .contentType(MediaType.APPLICATION_XML)
                .accept(MediaType.APPLICATION_XML)
                .content(xmlRequest))
            .andExpect(status().isOk())
            .andExpect(xpath("/storeOpenCloseResaQ/ResponseType").string("FAILED"));
    }


    @Test
    void testValidProcessDaysReturnsSuccess() throws Exception {
        String xmlRequest = """
            <storeOpenCloseResaQ>
                <fromDate></fromDate>
                <toDate></toDate>
                <processDays>1</processDays>
            </storeOpenCloseResaQ>
            """;

        mockMvc.perform(post("/1/storeopenclosemessages")
                .contentType(MediaType.APPLICATION_XML)
                .accept(MediaType.APPLICATION_XML)
                .content(xmlRequest))
            .andExpect(status().isOk())
            .andExpect(xpath("/storeOpenCloseResaQ/ResponseType").string("SUCCESS"));
    }

    @Test
    void testInvalidProcessDaysReturnsFailed() throws Exception {
        String xmlRequest = """
            <storeOpenCloseResaQ>
                <fromDate></fromDate>
                <toDate></toDate>
                <processDays>xyz</processDays>
            </storeOpenCloseResaQ>
            """;

        mockMvc.perform(post("/1/storeopenclosemessages")
                .contentType(MediaType.APPLICATION_XML)
                .accept(MediaType.APPLICATION_XML)
                .content(xmlRequest))
            .andExpect(status().isOk())
            .andExpect(xpath("/storeOpenCloseResaQ/ResponseType").string("FAILED"));
    }
    @Test
    void testProcessDaysOutsideValidRangeShouldFail() throws Exception {
        String xmlRequest = """
        <storeOpenCloseResaQ>
            <processDays>10</processDays>
        </storeOpenCloseResaQ>
        """;

        mockMvc.perform(post("/1/storeopenclosemessages")
                        .contentType(MediaType.APPLICATION_XML)
                        .accept(MediaType.APPLICATION_XML)
                        .content(xmlRequest))
                .andExpect(status().isOk())
                .andExpect(xpath("/storeOpenCloseResaQ/ResponseType").string("FAILED"));
    }
    @Test
    void testEmptyProcessDaysLengthInvalidShouldFail() throws Exception {
        String xmlRequest = """
        <storeOpenCloseResaQ>
            <processDays></processDays>
        </storeOpenCloseResaQ>
        """;

        mockMvc.perform(post("/1/storeopenclosemessages")
                        .contentType(MediaType.APPLICATION_XML)
                        .accept(MediaType.APPLICATION_XML)
                        .content(xmlRequest))
                .andExpect(status().isOk())
                .andExpect(xpath("/storeOpenCloseResaQ/ResponseType").string("FAILED"));
    }
    @Test
    void testMissingToDateShouldFail() throws Exception {
        String xmlRequest = """
        <storeOpenCloseResaQ>
            <fromDate>2025-07-01</fromDate>
        </storeOpenCloseResaQ>
        """;

        mockMvc.perform(post("/1/storeopenclosemessages")
                        .contentType(MediaType.APPLICATION_XML)
                        .accept(MediaType.APPLICATION_XML)
                        .content(xmlRequest))
                .andExpect(status().isOk())
                .andExpect(xpath("/storeOpenCloseResaQ/ResponseType").string("FAILED"));
    }


}
