/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aafes.sgpos.sgposservices.Gateway;

import com.aafes.sgpos.sgposservices.Config.EncryptorConfig;
import com.aafes.sgpos.sgposservices.Gateway.MQMessage;
import com.aafes.sgpos.sgposservices.generated.Control.Header;
import com.aafes.sgpos.sgposservices.generated.Control.SGPOSServices;
import jakarta.jms.*;
import java.io.UnsupportedEncodingException;
//import jakarta.jms.Destination;
import java.math.BigInteger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jms.core.JmsOperations;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.*;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.jms.core.MessageCreator;


/**
 *
 * @author bhendarkart
 */
@MockitoSettings(strictness = Strictness.LENIENT)
@ExtendWith(MockitoExtension.class)
public class MQMessageTest {
    
    @InjectMocks
    MQMessage mqMessage;

    @Mock
    JmsOperations jmsOperations;

    @Mock
    EncryptorConfig encryptorConfig;

    @Mock
    Session session;

    @Mock
    BytesMessage bytesMessage;

    @Mock
    SGPOSServices sgPosServices;

    @Mock
    Header header;

    @Mock
    Message responseMessage;
    
    @Mock
jakarta.jms.Queue destination;

    @BeforeEach
    void setup() {
        ReflectionTestUtils.setField(mqMessage, "destinationName", "REQUEST.QUEUE");
        ReflectionTestUtils.setField(mqMessage, "replyToQ", "RESPONSE.QUEUE");
        ReflectionTestUtils.setField(mqMessage, "cicsMQFunc", "CICSFUNC");
        ReflectionTestUtils.setField(mqMessage, "qPassword", "encryptedPass");
        ReflectionTestUtils.setField(mqMessage, "setTransId", "TXN001");
        ReflectionTestUtils.setField(mqMessage, "qUser", "testUser");
        ReflectionTestUtils.setField(mqMessage, "qManagerName", "QMGR");
        ReflectionTestUtils.setField(mqMessage, "cicsMQProgName", "PROG01");
    }


    @Test
    void testSendMessageQue_validMessage_shouldSendAndReceive() throws JMSException {
        // Arrange
        String payload = "TestPayload";
        String correlationId = "ABC123DEF456XYZ789GHI012";
        String expectedHexCorrelationID = String.format("%024x", new BigInteger(1,
                correlationId.substring(0, 24).getBytes()));
        String expectedSelector = "JMSCorrelationID='ID:" + expectedHexCorrelationID + "'";

        // Mock SGPOSServices and its Header
        Mockito.when(sgPosServices.getHeader()).thenReturn(header);
        Mockito.when(header.getTraceID()).thenReturn("TraceID001");

        // Mock password decryption
        Mockito.when(encryptorConfig.decrypt("encryptedPass")).thenReturn("decryptedPass");

        // Mock jmsOperations.receiveSelected return value
        Mockito.when(jmsOperations.receiveSelected(Mockito.anyString(), Mockito.eq(expectedSelector)))
                .thenReturn(responseMessage);

        // Act
        Message result = mqMessage.sendMessageQue(payload, correlationId, sgPosServices);

        // Assert
        assertNotNull(result, "Returned message should not be null");
        Mockito.verify(jmsOperations).send(Mockito.anyString(), Mockito.any(MessageCreator.class));
        Mockito.verify(jmsOperations).receiveSelected(Mockito.anyString(), Mockito.eq(expectedSelector));
    }


    @Test
    void testSendMessageQue_throwsExceptionWhenPasswordDecryptionFails() {
        String payload = "Payload";
        String correlationId = "CORR123456789";
        
        Mockito.when(encryptorConfig.decrypt("encryptedPass"))
               .thenThrow(new RuntimeException("Decryption failed"));

        Mockito.when(sgPosServices.getHeader()).thenReturn(header);
        Mockito.when(header.getTraceID()).thenReturn("TraceID002");

        assertThrows(RuntimeException.class, () -> {
            mqMessage.sendMessageQue(payload, correlationId, sgPosServices);
        });
    }

    @Test
    void testSendMessageQue_shouldThrowRuntimeException_onWriteBytesFailure() throws JMSException {
        String payload = "Payload";
        String correlationId = "ABC123DEF456XYZ789GHI012";

        // Arrange input and mocks
        Mockito.when(encryptorConfig.decrypt("encryptedPass")).thenReturn("decryptedPass");
        Mockito.when(sgPosServices.getHeader()).thenReturn(header);
        Mockito.when(header.getTraceID()).thenReturn("TRACE123");

        // Mock destination and BytesMessage
        Mockito.when(session.createQueue(Mockito.anyString())).thenReturn(destination);
        Mockito.when(session.createBytesMessage()).thenReturn(bytesMessage);

        // Simulate first writeBytes (header) succeeds, second one (cicsMQProgName) fails
       Mockito.doNothing()
       .doThrow(new RuntimeException("Simulated encoding failure"))
       .when(bytesMessage).writeBytes(Mockito.any(byte[].class));

        // Force jmsOperations.send to run the MessageCreator manually
        Mockito.doAnswer(invocation -> {
            MessageCreator mc = invocation.getArgument(1);
            mc.createMessage(session);  // simulate creation logic where exception will occur
            return null;
        }).when(jmsOperations).send(Mockito.anyString(), Mockito.any());

        // Act & Assert
        assertThrows(RuntimeException.class, () ->
                mqMessage.sendMessageQue(payload, correlationId, sgPosServices));
    }



    @Test
void SendMessageQue_shouldHandleShortCorrelationId() throws JMSException {
    String payload = "Payload";
    String correlationId = "CORR123456789ABCDEFGHJKL"; // now 24 chars

    Mockito.when(encryptorConfig.decrypt("encryptedPass")).thenReturn("pass");
    Mockito.when(sgPosServices.getHeader()).thenReturn(header);
    Mockito.when(header.getTraceID()).thenReturn("Trace");

    Mockito.when(jmsOperations.receiveSelected(Mockito.anyString(), Mockito.anyString()))
            .thenReturn(responseMessage);

    assertDoesNotThrow(() -> mqMessage.sendMessageQue(payload, correlationId, sgPosServices));
}
 @Test
    void testSendMessageQue_shouldHandleNullTraceIdGracefully() throws JMSException {
        String payload = "Payload";
        String correlationId = "CORR123456789ABCDEFGHJKL";

        Mockito.when(encryptorConfig.decrypt("encryptedPass")).thenReturn("pass");
        Mockito.when(sgPosServices.getHeader()).thenReturn(header);
        Mockito.when(header.getTraceID()).thenReturn(null);

        Mockito.when(jmsOperations.receiveSelected(Mockito.anyString(), Mockito.anyString()))
                .thenReturn(responseMessage);

        Message result = mqMessage.sendMessageQue(payload, correlationId, sgPosServices);
        assertNotNull(result);
    }
    @Test
    void testCreateMessage_shouldSetHeadersAndPayloadCorrectly() throws JMSException, UnsupportedEncodingException {
        String payload = "MyTestPayload";
        String correlationId = "CORRID123456789ABCDEFGHJKL";

        Mockito.when(encryptorConfig.decrypt("encryptedPass")).thenReturn("pass");
        Mockito.when(sgPosServices.getHeader()).thenReturn(header);
        Mockito.when(header.getTraceID()).thenReturn("Trace123");
        Mockito.when(session.createQueue(Mockito.anyString())).thenReturn(destination);
        Mockito.when(session.createBytesMessage()).thenReturn(bytesMessage);

        // Simulate successful writeBytes and writeUTF
        Mockito.doNothing().when(bytesMessage).writeBytes(Mockito.any(byte[].class));
        Mockito.doNothing().when(bytesMessage).writeUTF(Mockito.anyString());

        // Act: manually trigger message creation
        MessageCreator creator = mc -> {
            return mqMessage.sendMessageQue(payload, correlationId, sgPosServices);
        };

        // Run send method to invoke MessageCreator
        Mockito.doAnswer(invocation -> {
            MessageCreator mc = invocation.getArgument(1);
            mc.createMessage(session);
            return null;
        }).when(jmsOperations).send(Mockito.anyString(), Mockito.any(MessageCreator.class));

        mqMessage.sendMessageQue(payload, correlationId, sgPosServices);

        // Assert headers set
        Mockito.verify(bytesMessage).setJMSCorrelationID(correlationId);
        Mockito.verify(bytesMessage).setJMSMessageID(correlationId);
        Mockito.verify(bytesMessage).setJMSReplyTo(destination);

        // Assert payload written
        Mockito.verify(bytesMessage).writeBytes(" 1208".getBytes());
        Mockito.verify(bytesMessage).writeUTF(payload);

        // Assert program name written in CP500 encoding
        Mockito.verify(bytesMessage).writeBytes("PROG01".getBytes("CP500"));
    }

}
