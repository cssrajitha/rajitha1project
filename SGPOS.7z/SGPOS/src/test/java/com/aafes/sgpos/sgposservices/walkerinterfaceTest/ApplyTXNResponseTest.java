/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aafes.sgpos.sgposservices.walkerinterfaceTest;
import com.aafes.sgpos.sgposservices.walkerinterface.ApplyTXNResponse;
import com.aafes.sgpos.sgposservices.walkerinterface.ServerAccessProperties;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author bhendarkart
 */
public class ApplyTXNResponseTest {


    @Test
    void testSetAndGetApplyTXNResult() {
        ApplyTXNResponse response = new ApplyTXNResponse();

        ServerAccessProperties mockResult = new ServerAccessProperties();
        // Optionally set fields on mockResult if needed

        response.setApplyTXNResult(mockResult);

        assertEquals(mockResult, response.getApplyTXNResult());
    }

    @Test
    void testDefaultValueIsNull() {
        ApplyTXNResponse response = new ApplyTXNResponse();
        assertNull(response.getApplyTXNResult(), "Expected null by default before setting");
    }
}
