package com.aafes.sgpos.sgposservices.Gateway;

import com.aafes.sgpos.sgposservices.Config.EncryptorConfig;
import com.aafes.sgpos.sgposservices.generated.Control.IDCheckRequest;
import com.aafes.sgpos.sgposservices.generated.Control.SGPOSServices;
import org.json.simple.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mock;
import org.mockito.MockedConstruction;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.*;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import org.springframework.web.client.RestTemplate;

@ExtendWith(MockitoExtension.class)
public class TestCcdVerificationIDCHECK {

    @Mock
    private EncryptorConfig encryptorConfig;

    @Mock
    private SGPOSServices sgposservices;

    @Mock
    private IDCheckRequest idCheckRequest;

    private ccdVerificationIDCHECK service;

    @BeforeEach
    void setup() {
        service = new ccdVerificationIDCHECK();

        ReflectionTestUtils.setField(service, "CCDURL", "http://dummy-url");
        ReflectionTestUtils.setField(service, "CCDClientID", "dummy-client-id");
        ReflectionTestUtils.setField(service, "CCDUserName", "dummy-user");
        ReflectionTestUtils.setField(service, "CCDPassword", "dummy-pass");
        ReflectionTestUtils.setField(service, "encryptorConfig", encryptorConfig);
        ReflectionTestUtils.setField(service, "ccdCallTimeout", "2000");
        ReflectionTestUtils.setField(service, "ccdCallReadTimeout", "2000");

        when(encryptorConfig.decrypt(anyString())).thenReturn("decrypted-pass");
        when(sgposservices.getIDCheckRequest()).thenReturn(idCheckRequest);
        when(idCheckRequest.getCustomerID()).thenReturn("123456");
    }

    @Test
    void testCCDCall_successfulResponse_000() throws Exception {
        Map<String, Object> customerObj = Map.of("CID", "CID001");
        Map<String, Object> responseBody = Map.of(
                "respStatus", "000",
                "Customer", customerObj
        );

        ResponseEntity<Object> responseEntity = new ResponseEntity<>(responseBody, HttpStatus.OK);

        try (MockedConstruction<RestTemplate> mocked = mockConstruction(RestTemplate.class,
                (mock, context) -> {
                    when(mock.exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(Object.class)))
                            .thenReturn(responseEntity);
                })) {

            JSONObject result = service.CCDCall(sgposservices);

            assertNotNull(result);
            assertEquals("CID001", result.get("CID"));
            assertEquals("000", result.get("reasonCode"));
        }
    }


    @ParameterizedTest
    @ValueSource(strings = {"100", "201", "202", "203", "998", "901", "903"})
    void testCCDCall_allKnownStatusCodes(String statusCode) throws Exception {
        Map<String, Object> responseBody = Map.of("respStatus", statusCode);
        ResponseEntity<Object> responseEntity = new ResponseEntity<>(responseBody, HttpStatus.OK);

        try (MockedConstruction<RestTemplate> mocked = mockConstruction(RestTemplate.class,
                (mock, context) -> {
                    when(mock.exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(Object.class)))
                            .thenReturn(responseEntity);
                })) {

            JSONObject result = service.CCDCall(sgposservices);

            assertEquals(statusCode, result.get("reasonCode"));
            assertNull(result.get("CID"));
        }
    }

}
