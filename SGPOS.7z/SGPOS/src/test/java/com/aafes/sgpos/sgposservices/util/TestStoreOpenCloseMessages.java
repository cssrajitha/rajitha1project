/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aafes.sgpos.sgposservices.util;
import com.aafes.sgpos.sgposservices.Entity.storeOpenCloseMessages;
import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;

/**
 *
 * @author bhendarkart
 */
public class TestStoreOpenCloseMessages {
    @Test
    public void testSettersAndGetters() {
        storeOpenCloseMessages message = new storeOpenCloseMessages();

        message.setGateway("GATEWAY_01");
        message.setReceiveddate("2025-08-06");
        message.setTraceid("TRACE123");
        message.setFacility("FAC001");
        message.setReqdateandtime("2025-08-06T13:45:00");
        message.setMsgsenddatetime("2025-08-06T13:46:00");
        message.setRequesttype("OPEN");
        message.setStatus("SUCCESS");

        assertThat(message.getGateway()).isEqualTo("GATEWAY_01");
        assertThat(message.getReceiveddate()).isEqualTo("2025-08-06");
        assertThat(message.getTraceid()).isEqualTo("TRACE123");
        assertThat(message.getFacility()).isEqualTo("FAC001");
        assertThat(message.getReqdateandtime()).isEqualTo("2025-08-06T13:45:00");
        assertThat(message.getMsgsenddatetime()).isEqualTo("2025-08-06T13:46:00");
        assertThat(message.getRequesttype()).isEqualTo("OPEN");
        assertThat(message.getStatus()).isEqualTo("SUCCESS");
    }

    @Test
    public void testToStringMethod() {
        storeOpenCloseMessages message = new storeOpenCloseMessages();
        message.setGateway("GATEWAY_01");
        message.setReceiveddate("2025-08-06");
        message.setTraceid("TRACE123");
        message.setFacility("FAC001");
        message.setReqdateandtime("2025-08-06T13:45:00");
        message.setMsgsenddatetime("2025-08-06T13:46:00");
        message.setRequesttype("OPEN");
        message.setStatus("SUCCESS");

        String expected = "storeOpenCloseMessages{" +
                "receiveddate='2025-08-06', " +
                "gateway='GATEWAY_01', " +
                "traceid='TRACE123', " +
                "facility='FAC001', " +
                "reqdateandtime='2025-08-06T13:45:00', " +
                "msgsenddatetime='2025-08-06T13:46:00', " +
                "requesttype='OPEN', " +
                "status='SUCCESS'}";

        assertThat(message.toString()).isEqualTo(expected);
    }
}
