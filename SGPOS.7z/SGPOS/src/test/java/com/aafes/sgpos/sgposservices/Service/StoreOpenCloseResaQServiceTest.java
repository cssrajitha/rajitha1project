package com.aafes.sgpos.sgposservices.Service;
import com.aafes.sgpos.sgposservices.Control.storeOpenCloseMessagesStatus;
import com.aafes.sgpos.sgposservices.Entity.storeOpenCloseMessages;
import com.aafes.sgpos.sgposservices.Entity.storeOpenCloseMessages;
import com.aafes.sgpos.sgposservices.Gateway.ResaMessages;
import com.aafes.sgpos.sgposservices.Gateway.orisVerification;
import com.aafes.sgpos.sgposservices.Repository.storeOpenCloseMessagesRepository;
import com.aafes.sgpos.sgposservices.generated.Control.Header;
import com.aafes.sgpos.sgposservices.generated.Control.SGPOSServices;
import com.aafes.sgpos.sgposservices.generated.Control.StoreOpenCloseRequest;
import com.aafes.sgpos.sgposservices.Repository.storeOpenCloseMessagesRepository;
import com.aafes.sgpos.sgposservices.walkerinterface.ApplyTXNResponse;
import com.aafes.sgpos.sgposservices.walkerinterface.ConnectToWalkerResponse;
import com.aafes.sgpos.sgposservices.walkerinterface.LogOffWalkerResponse;
import com.aafes.sgpos.sgposservices.walkerinterface.ServerAccessProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import jakarta.jms.JMSException;
import jakarta.jms.Session;
import jakarta.jms.Message;
import jakarta.jms.TextMessage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.mockito.Mock;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jms.JmsException;
import org.springframework.jms.core.JmsOperations;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(classes = {StoreOpenCloseResaQServiceTest.class})
public class StoreOpenCloseResaQServiceTest {

    @InjectMocks
    private storeOpenCloseProcessingDaysService storeOpenCloseProcessingDaysService;

    @Mock
    private JmsTemplate jmsTemplate;

    @Mock
    private orisVerification orisVerification;

    @Mock
    private ApplyTXNResponse applyTXNResponse;

    @Mock
    private ConnectToWalkerResponse walkerResponse;

    @Mock
    private LogOffWalkerResponse logOffWalkerResponse;

    @Mock
    private SGPOSServices sgposServices;

    @Mock
    private ResaMessages resaMessages;

    @Mock
    private TextMessage mockTextMessage;

    @Mock(answer = Answers.RETURNS_DEEP_STUBS)
    private Session mockSession;

    @Mock
    private storeOpenCloseMessagesRepository storeOpenCloseMessagesRepository;

    @Mock
    private JmsOperations jmsOperations;

    @BeforeEach
    void setUp() throws JMSException {
        MockitoAnnotations.openMocks(this);

        // Simulate JMS behavior: create a TextMessage from session
        when(mockSession.createTextMessage(anyString())).thenReturn(mockTextMessage);

        // Optionally mock other JMS artifacts if used in your tests
        when(mockTextMessage.getText()).thenReturn("Mock message text");
    }

    @Test
    void testBookToResa_NoRecords() throws JsonProcessingException {
        List<storeOpenCloseMessages> resaQueue = new ArrayList<>();
        List<String> sC = new ArrayList<>();
        SGPOSServices sgposServices = mock(SGPOSServices.class);
        List<String> result = storeOpenCloseProcessingDaysService.bookToResa(resaQueue, sC, sgposServices);

        assertEquals(1, result.size()); // Should contain "NO_RECORDS"
        assertEquals("NO_RECORDS", result.get(0));
    }

    //TestCase for the sendMessage(String payload, SGPOSServices sgposservices) method
    @Test
    void testSendMessageSuccess() {
        String payload = "Test Payload";
        String rec = "Formatted Record";
        SGPOSServices sgposServices = mock(SGPOSServices.class);
        Header mockHeader = new Header();
        mockHeader.setTraceID("12345");
        when(sgposServices.getHeader()).thenReturn(mockHeader);

        when(resaMessages.formatRecord(any(storeOpenCloseMessagesStatus.class))).thenReturn(rec);
        when(resaMessages.sendMessage(anyString(), any(SGPOSServices.class))).thenReturn("SUCCESS");
        assertEquals("12345", sgposServices.getHeader().getTraceID());

        String result = resaMessages.sendMessage(payload, sgposServices);
        assertEquals("SUCCESS", result);
    }

    @Test
    void testSendMessageFailure() {
        String payload = "Test Payload";
        String rec = "Formatted Record";
        SGPOSServices sgposServices = mock(SGPOSServices.class);

        Header mockHeader = new Header();
        mockHeader.setTraceID("12345");
        when(sgposServices.getHeader()).thenReturn(mockHeader);
        assertEquals("12345", sgposServices.getHeader().getTraceID());

        when(resaMessages.formatRecord(any(storeOpenCloseMessagesStatus.class))).thenReturn(rec);
        when(resaMessages.sendMessage(anyString(), any(SGPOSServices.class))).thenReturn("FAILED");

        List<String> sC = new ArrayList<>();
        storeOpenCloseMessages resa = new storeOpenCloseMessages();
        resa.setGateway("resa");
        resa.setFacility("123");

        // Simulating repository call to delete failed record
        storeOpenCloseMessagesRepository.deletebyDFT("2025-02-01", "resa", "123", "trace123");

        StoreOpenCloseRequest mockRequest = new StoreOpenCloseRequest();
        mockRequest.setBusinessDate("02-10-2025");
        when(sgposServices.getStoreOpenCloseRequest()).thenReturn(mockRequest);
        String result = resaMessages.sendMessage(payload, sgposServices);

        assertEquals("FAILED", result);
    }

    @Test
    void testBookToResa_ValidData() throws JsonProcessingException {
        List<storeOpenCloseMessages> resaQueue = new ArrayList<>();
        SGPOSServices sgposServices = mock(SGPOSServices.class);
        storeOpenCloseMessages message = new storeOpenCloseMessages();
        message.setGateway("resa");
        message.setFacility("123");
        message.setTraceid("trace123");
        resaQueue.add(message);

        List<String> sC = new ArrayList<>();
        when(resaMessages.formatRecord(any(storeOpenCloseMessagesStatus.class))).thenReturn("Formatted Record");
        when(resaMessages.sendMessage(anyString(), any(SGPOSServices.class))).thenReturn("SUCCESS");

        List<String> result = storeOpenCloseProcessingDaysService.bookToResa(resaQueue, sC, sgposServices);
        assertEquals(2, result.size()); // Should contain "SUCCESS" and "NO_RECORDS"
        assertEquals("SUCCESS", result.get(0));
    }

    @Test
    void testBookToResa_WithOrisGateway_ShouldInvokeSocOris() throws JsonProcessingException {
        // Arrange test message
        storeOpenCloseMessages msg = new storeOpenCloseMessages();
        msg.setGateway("oris");
        msg.setFacility("456");
        msg.setTraceid("ORIS_TRACE");
        msg.setRequesttype("OPEN");
        msg.setReqdateandtime("20250711");
        msg.setReceiveddate("20250711");

        List<storeOpenCloseMessages> resaQueue = List.of(msg);
        List<String> statusCollector = new ArrayList<>();

        // Mock header and SGPOSServices
        Header header = new Header();
        header.setTraceID("ORIS_TRACE");
        header.setFacilityNumber("456");

        SGPOSServices sgposServices = new SGPOSServices();
        sgposServices.setHeader(header);

        // Stub: ServerAccessProperties (deep stub inside ConnectToWalkerResponse)
        ServerAccessProperties accessProps = mock(ServerAccessProperties.class);
        when(accessProps.getStatus()).thenReturn("OK");

        ConnectToWalkerResponse walkerResp = mock(ConnectToWalkerResponse.class);
        when(walkerResp.getConnectToWalkerResult()).thenReturn(accessProps);
        when(orisVerification.login(any())).thenReturn(walkerResp);

        // Stub: ApplyTXNResponse using deep stubbing
        ApplyTXNResponse applyResp = mock(ApplyTXNResponse.class, Answers.RETURNS_DEEP_STUBS);
        when(applyResp.getApplyTXNResult().getStatus()).thenReturn("OK");
        when(applyResp.getApplyTXNResult().getEncodedHtmlResponse())
                .thenReturn("MockResponseContent".getBytes());

        when(orisVerification.applyTXN(any(), any(), any())).thenReturn(applyResp);

        // Stub: Logoff response
        LogOffWalkerResponse logoffResp = mock(LogOffWalkerResponse.class);
        when(orisVerification.loggOff(any(), any())).thenReturn(logoffResp);

        // Act
        List<String> result = storeOpenCloseProcessingDaysService
                .bookToResa(resaQueue, statusCollector, sgposServices);

        // Assert
        assertNotNull(result);
        assertTrue(result.contains("SUCCESS") || result.contains("FAILED"));
    }

    @Test
    void testSocOris_shouldFailWhenApplyTXNResponseIsNull() throws JsonProcessingException {
        // Arrange
        SGPOSServices sgposServices = new SGPOSServices();
        Header header = new Header();
        header.setTraceID("TRACE001");
        header.setFacilityNumber("FAC001");
        sgposServices.setHeader(header);

        ConnectToWalkerResponse walkerResp = mock(ConnectToWalkerResponse.class, Answers.RETURNS_DEEP_STUBS);
        when(walkerResp.getConnectToWalkerResult().getStatus()).thenReturn("OK");
        when(orisVerification.login(any())).thenReturn(walkerResp);

        when(orisVerification.applyTXN(any(), any(), any())).thenReturn(null); // simulate null response


    }
}
