/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aafes.sgpos.sgposservices.util;
import com.networknt.schema.JsonSchema;
import com.networknt.schema.ValidationMessage;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 *
 * @author bhendarkart
 */
public class ValidateSchemaUtilTest {
    private ValidateSchemaUtil util;
    private JsonSchema schema;

    @BeforeEach
    void setup() {
        util = new ValidateSchemaUtil();
        schema = mock(JsonSchema.class);
    }

    @Test
    void testValidJson_noValidationErrors() {
        String jsonReq = "{\"name\":\"John\",\"age\":30}";
        JSONObject sgPosServices = new JSONObject();

        when(schema.validate(any())).thenReturn(Set.of());

        String result = util.validateJsonRequest(jsonReq, schema, sgPosServices);
        assertNull(result); // No errors expected
    }

    @Test
    void testInvalidJson_withValidationErrors() {
        String jsonReq = "{\"name\":123}"; // Assume name should be a string
        JSONObject sgPosServices = new JSONObject();

        ValidationMessage msg1 = mock(ValidationMessage.class);
        when(msg1.getMessage()).thenReturn("name: must be a string");

        ValidationMessage msg2 = mock(ValidationMessage.class);
        when(msg2.getMessage()).thenReturn("age: is missing");

        when(schema.validate(any())).thenReturn(Set.of(msg1, msg2));

        String result = util.validateJsonRequest(jsonReq, schema, sgPosServices);
        assertNotNull(result);
        assertTrue(result.contains("name: must be a string"));
        assertTrue(result.contains("age: is missing"));
    }

    @Test
    void testMalformedJson_throwsException() {
        String jsonReq = "{invalidJson:}"; // Malformed JSON
        JSONObject sgPosServices = new JSONObject();

        String result = util.validateJsonRequest(jsonReq, schema, sgPosServices);
        assertNotNull(result);
        assertTrue(result.contains("Exception"));
    }
}
