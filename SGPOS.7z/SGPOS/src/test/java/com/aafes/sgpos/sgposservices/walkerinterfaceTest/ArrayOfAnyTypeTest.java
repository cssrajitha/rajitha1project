/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aafes.sgpos.sgposservices.walkerinterfaceTest;
import com.aafes.sgpos.sgposservices.walkerinterface.ArrayOfAnyType;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author bhendarkart
 */
public class ArrayOfAnyTypeTest {

    @Test
    void testInitialListIsEmpty() {
        ArrayOfAnyType array = new ArrayOfAnyType();
        List<Object> list = array.getAnyType();

        assertNotNull(list, "List should be initialized");
        assertTrue(list.isEmpty(), "List should be empty initially");
    }

    @Test
    void testAddItemToList() {
        ArrayOfAnyType array = new ArrayOfAnyType();
        Object sample = "TestString";
        array.getAnyType().add(sample);

        List<Object> list = array.getAnyType();
        assertEquals(1, list.size());
        assertEquals(sample, list.get(0));
    }

    @Test
    void testMultipleItemsAdded() {
        ArrayOfAnyType array = new ArrayOfAnyType();
        array.getAnyType().add("First");
        array.getAnyType().add(123);
        array.getAnyType().add(true);

        List<Object> list = array.getAnyType();
        assertEquals(3, list.size());
        assertEquals("First", list.get(0));
        assertEquals(123, list.get(1));
        assertEquals(true, list.get(2));
    }
}