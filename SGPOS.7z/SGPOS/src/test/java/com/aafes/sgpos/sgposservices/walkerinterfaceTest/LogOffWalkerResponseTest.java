/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aafes.sgpos.sgposservices.walkerinterfaceTest;
import com.aafes.sgpos.sgposservices.walkerinterface.LogOffWalkerResponse;
import com.aafes.sgpos.sgposservices.walkerinterface.ServerAccessProperties;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author bhendarkart
 */
public class LogOffWalkerResponseTest {

    @Test
    void testSetAndGetLogOffWalkerResult() {
        LogOffWalkerResponse response = new LogOffWalkerResponse();

        ServerAccessProperties mockResult = new ServerAccessProperties();
        // Optionally set fields on mockResult here if needed

        response.setLogOffWalkerResult(mockResult);

        assertEquals(mockResult, response.getLogOffWalkerResult());
    }

    @Test
    void testDefaultValueIsNull() {
        LogOffWalkerResponse response = new LogOffWalkerResponse();

        assertNull(response.getLogOffWalkerResult(), "Expected default value to be null");
    }
    
}
