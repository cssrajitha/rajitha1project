/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aafes.sgpos.sgposservices.walkerinterfaceTest;
import com.aafes.sgpos.sgposservices.walkerinterface.ConnectToWalker;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author bhendarkart
 */
public class ConnectToWalkerTest {

    @Test
    void testSettersAndGetters() {
        ConnectToWalker walker = new ConnectToWalker();

        walker.setStrURL("http://test-url.com");
        walker.setStrZuser("walkerUser");
        walker.setStrZpass("securePass123");

        assertEquals("http://test-url.com", walker.getStrURL());
        assertEquals("walkerUser", walker.getStrZuser());
        assertEquals("securePass123", walker.getStrZpass());
    }

    @Test
    void testDefaultValuesAreNull() {
        ConnectToWalker walker = new ConnectToWalker();

        assertNull(walker.getStrURL(), "strURL should be null by default");
        assertNull(walker.getStrZuser(), "strZuser should be null by default");
        assertNull(walker.getStrZpass(), "strZpass should be null by default");
    }
}
