/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aafes.sgpos.sgposservices.config;

import com.aafes.sgpos.sgposservices.Config.WalkerClient;
import com.aafes.sgpos.sgposservices.Config.WalkerResponse;
import com.aafes.sgpos.sgposservices.walkerinterface.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 *
 * @author bhendarkart
 */
public class WalkerResponseTest {
    @InjectMocks
    private WalkerResponse walkerResponse;

    @Mock
    private WalkerClient walkerclient;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        // Inject mock config values
        ReflectionTestUtils.setField(walkerResponse, "url", "http://baseurl.com");
        ReflectionTestUtils.setField(walkerResponse, "applyTXNUrl", "http://baseurl.com/apply");
        ReflectionTestUtils.setField(walkerResponse, "loginUrl", "http://baseurl.com/login");
        ReflectionTestUtils.setField(walkerResponse, "logOffUrl", "http://baseurl.com/logoff");
    }
    @Test
    void testSignIn_shouldReturnAcknowledgement() {
        ConnectToWalker request = new ConnectToWalker();
        ConnectToWalkerResponse mockResponse = new ConnectToWalkerResponse();

        when(walkerclient.callWebService("http://baseurl.com", request, "http://baseurl.com/login"))
                .thenReturn(mockResponse);

        ConnectToWalkerResponse result = walkerResponse.signIn(request);

        assertSame(mockResponse, result);
        verify(walkerclient).callWebService("http://baseurl.com", request, "http://baseurl.com/login");
    }
    @Test
    void testApplytxn_shouldReturnAcknowledgement() {
        ApplyTXN request = new ApplyTXN();
        ApplyTXNResponse mockResponse = new ApplyTXNResponse();

        when(walkerclient.callWebService("http://baseurl.com", request, "http://baseurl.com/apply"))
                .thenReturn(mockResponse);

        ApplyTXNResponse result = walkerResponse.applytxn(request);

        assertSame(mockResponse, result);
        verify(walkerclient).callWebService("http://baseurl.com", request, "http://baseurl.com/apply");
    }
    @Test
    void testLogoff_shouldReturnAcknowledgement() {
        LogOffWalker request = new LogOffWalker();
        LogOffWalkerResponse mockResponse = new LogOffWalkerResponse();

        when(walkerclient.callWebService("http://baseurl.com", request, "http://baseurl.com/logoff"))
                .thenReturn(mockResponse);

        LogOffWalkerResponse result = walkerResponse.logoff(request);

        assertSame(mockResponse, result);
        verify(walkerclient).callWebService("http://baseurl.com", request, "http://baseurl.com/logoff");
    }
}
