package com.aafes.sgpos.sgposservices.walkerinterfaceTest;
import com.aafes.sgpos.sgposservices.walkerinterface.LogOffWalker;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class LogOffWalkerTest {

    @Test
    void testSettersAndGetters() {
        LogOffWalker logOffWalker = new LogOffWalker();

        logOffWalker.setToken("secure-token-123");
        logOffWalker.setStrURL("http://logout.service.url");

        assertEquals("secure-token-123", logOffWalker.getToken());
        assertEquals("http://logout.service.url", logOffWalker.getStrURL());
    }

    @Test
    void testDefaultValuesAreNull() {
        LogOffWalker logOffWalker = new LogOffWalker();

        assertNull(logOffWalker.getToken(), "Token should be null initially");
        assertNull(logOffWalker.getStrURL(), "strURL should be null initially");
    }
}
