/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aafes.sgpos.sgposservices.Service;

import com.aafes.sgpos.sgposservices.Control.OauthResponse;
import java.lang.reflect.Field;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.*;
import org.springframework.core.env.Environment;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;


/**
 *
 * @author bhendarkart
 */
public class OAuthValidationServiceTest {

    @InjectMocks
    private OauthValidationService oauthValidationService;

    @Mock
    private Environment env;

    @Mock
    private RestTemplate restTemplate;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);

        when(env.getProperty("oauth2.client.client-id")).thenReturn("client-id");
        when(env.getProperty("oauth2.client.client-secret")).thenReturn("client-secret");
        when(env.getProperty("oauth2.resource.token-info-uri")).thenReturn("http://oauth-server/token-info");
        when(env.getProperty("oauth2.client.connectTimeout")).thenReturn("5000");
    }

    @Test
    void testEnvironmentPropertiesUsed() {
        when(env.getProperty("oauth2.client.client-id")).thenReturn("client-id");
        when(env.getProperty("oauth2.client.client-secret")).thenReturn("secret");
        when(env.getProperty("oauth2.resource.token-info-uri")).thenReturn("http://localhost");
        when(env.getProperty("oauth2.client.connectTimeout")).thenReturn("2000");
        when(env.getProperty("oauth2.client.readTimeout")).thenReturn("3000");

        JSONObject sgPosServices = new JSONObject()
                .put("header", new JSONObject()
                        .put("traceID", "trace123")
                        .put("application", "testApp"));

        OauthResponse response = oauthValidationService.oauthTokenValidation("myToken", sgPosServices);

        assertNotNull(response);
        System.out.println("Code: " + response.getReasonCode());
        System.out.println("Desc: " + response.getResponseDescription());
    }

    @Test
    void testEmptyToken() throws NoSuchFieldException, IllegalAccessException {

        String token = "";

        JSONObject sgPosServices = new JSONObject()
                .put("header", new JSONObject()
                        .put("traceID", "dummyTrace")
                        .put("application", "dummyApp"));

        Field envField = OauthValidationService.class.getDeclaredField("env");
        envField.setAccessible(true);
        envField.set(oauthValidationService, env);

        OauthResponse response = oauthValidationService.oauthTokenValidation(token, sgPosServices);

        assertNotNull(response);
        assertEquals("OA_TOK_MISSIN", response.getReasonCode());
        assertEquals("OAUTH_TOKEN_MISSING", response.getResponseDescription());
    }

    @Test
    void testNullToken() {
        String token = null;
        JSONObject sgPosServices = new JSONObject()
                .put("header", new JSONObject()
                        .put("traceID", "dummyTrace")
                        .put("application", "dummyApp"));

        OauthResponse response = oauthValidationService.oauthTokenValidation(token, sgPosServices);

        assertNotNull(response);
        assertEquals("OA_TOK_MISSIN", response.getReasonCode());
        assertEquals("OAUTH_TOKEN_MISSING", response.getResponseDescription());
    }

    @Test
    void testOAuthServerDownCombinedError() {
        RuntimeException exception = new RuntimeException("Error: 404 Not Found and 500 Internal Server Error");

        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(OauthResponse.class)))
                .thenThrow(exception);

        JSONObject sgPosServices = new JSONObject()
                .put("header", new JSONObject()
                        .put("traceID", "combinedErrorTrace")
                        .put("application", "unitTestApp"));

        OauthResponse response = oauthValidationService.oauthTokenValidation("sampleToken", sgPosServices);

        assertEquals("OA_SRVR_DOWN", response.getReasonCode());
        assertEquals("OAUTH_SERVER_DOWN", response.getResponseDescription());
        assertEquals("true", response.getActive());
    }

    @Test
    void testOAuthServerDownWith404And500InExceptionMessage() {
        // Prepare an exception with a message containing both "404" and "500"
        RuntimeException exception = new RuntimeException("Error: 404 Not Found and 500 Internal Server Error");

        // Mock restTemplate.exchange to throw this exception
        when(restTemplate.exchange(
                anyString(),
                eq(HttpMethod.POST),
                any(HttpEntity.class),
                eq(OauthResponse.class)))
                .thenThrow(exception);

        JSONObject sgPosServices = new JSONObject()
                .put("header", new JSONObject()
                        .put("traceID", "traceFor404500")
                        .put("application", "testApp"));

        OauthResponse response = oauthValidationService.oauthTokenValidation("someToken", sgPosServices);

        assertNotNull(response);
        assertEquals("true", response.getActive());
        assertEquals("OA_SRVR_DOWN", response.getReasonCode());
        assertEquals("OAUTH_SERVER_DOWN", response.getResponseDescription());
    }



}
