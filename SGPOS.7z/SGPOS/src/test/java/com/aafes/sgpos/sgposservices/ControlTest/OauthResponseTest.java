/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aafes.sgpos.sgposservices.ControlTest;
import com.aafes.sgpos.sgposservices.Control.OauthResponse;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


/**
 *
 * @author bhendarkart
 */
public class OauthResponseTest {
    @Test
    void testGetterSetterMethods() {
        OauthResponse response = new OauthResponse();

        response.setActive("true");
        response.setReasonCode("200");
        response.setResponseDescription("Success");
        response.setStatusCode(true);

        assertEquals("true", response.getActive());
        assertEquals("200", response.getReasonCode());
        assertEquals("Success", response.getResponseDescription());
        assertTrue(response.getStatusCode());
    }

    @Test
    void testToStringMethod() {
        OauthResponse response = new OauthResponse();
        response.setActive("false");
        response.setReasonCode("401");
        response.setResponseDescription("Unauthorized");

        String result = response.toString();
        assertTrue(result.contains("Active=false"));
        assertTrue(result.contains("ReasonCode=401"));
        assertTrue(result.contains("ResponseDescription=Unauthorized"));
    }
}
