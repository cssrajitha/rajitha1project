/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aafes.sgpos.sgposservices.walkerinterfaceTest;
import com.aafes.sgpos.sgposservices.walkerinterface.ApplyTXN;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author bhendarkart
 */
public class ApplyTXNTest {
    @Test
    void testGettersAndSetters() {
        ApplyTXN txn = new ApplyTXN();

        String postData = "sampleData";
        byte[] html = new byte[]{1, 2, 3, 4};
        String url = "http://example.com";
        String cc = "Visa";
        String txnCode = "TXN123";
        String cntlEntity = "ControlX";

        txn.setStrPostData(postData);
        txn.setEncodedHtml(html);
        txn.setStrURL(url);
        txn.setStrCC(cc);
        txn.setStrTxn(txnCode);
        txn.setStrCntlEntity(cntlEntity);

        assertEquals(postData, txn.getStrPostData());
        assertArrayEquals(html, txn.getEncodedHtml());
        assertEquals(url, txn.getStrURL());
        assertEquals(cc, txn.getStrCC());
        assertEquals(txnCode, txn.getStrTxn());
        assertEquals(cntlEntity, txn.getStrCntlEntity());
    }

    @Test
    void testDefaultValuesAreNull() {
        ApplyTXN txn = new ApplyTXN();

        assertNull(txn.getStrPostData());
        assertNull(txn.getEncodedHtml());
        assertNull(txn.getStrURL());
        assertNull(txn.getStrCC());
        assertNull(txn.getStrTxn());
        assertNull(txn.getStrCntlEntity());
    }
}
