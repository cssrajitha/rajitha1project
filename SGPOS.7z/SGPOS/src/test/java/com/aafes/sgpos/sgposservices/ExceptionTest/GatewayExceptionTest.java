/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aafes.sgpos.sgposservices.ExceptionTest;
import com.aafes.sgpos.sgposservices.Exception.GatewayException;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author bhendarkart
 */
public class GatewayExceptionTest {

    @Test
    void testConstructor_withMessageAndCause() {
        Throwable cause = new RuntimeException("Root cause");
        GatewayException ex = new GatewayException("Error occurred", cause);

        assertEquals("Error occurred", ex.getMessage());
        assertEquals(cause, ex.getCause());

        // Default values
        assertEquals('T', ReflectionTestUtils.getField(ex, "responseType"));
        assertEquals("999", ReflectionTestUtils.getField(ex, "reasonCode"));
    }

    @Test
    void testConstructor_withMessageOnly() {
        GatewayException ex = new GatewayException("Simple error");

        assertEquals("Simple error", ex.getMessage());
        assertNull(ex.getCause());

        assertEquals('T', ReflectionTestUtils.getField(ex, "responseType"));
        assertEquals("999", ReflectionTestUtils.getField(ex, "reasonCode"));
    }

    @Test
    void testConstructor_withMessageAndResponseType() {
        GatewayException ex = new GatewayException("Typed error", 'E');

        assertEquals("Typed error", ex.getMessage());
        assertEquals('E', ReflectionTestUtils.getField(ex, "responseType"));
        assertEquals("999", ReflectionTestUtils.getField(ex, "reasonCode"));
    }

    @Test
    void testConstructor_withMessageResponseTypeAndReasonCode() {
        GatewayException ex = new GatewayException("Full error", 'F', "123");

        assertEquals("Full error", ex.getMessage());
        assertEquals('F', ReflectionTestUtils.getField(ex, "responseType"));
        assertEquals("123", ReflectionTestUtils.getField(ex, "reasonCode"));
    }
}
