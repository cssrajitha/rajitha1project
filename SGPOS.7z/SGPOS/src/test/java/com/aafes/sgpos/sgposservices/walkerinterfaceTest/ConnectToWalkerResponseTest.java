/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aafes.sgpos.sgposservices.walkerinterfaceTest;
import com.aafes.sgpos.sgposservices.walkerinterface.ConnectToWalkerResponse;
import com.aafes.sgpos.sgposservices.walkerinterface.ServerAccessProperties;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author bhendarkart
 */
public class ConnectToWalkerResponseTest {

    @Test
    void testSetAndGetConnectToWalkerResult() {
        ConnectToWalkerResponse response = new ConnectToWalkerResponse();

        ServerAccessProperties result = new ServerAccessProperties();
        // Optionally set fields on result here if needed

        response.setConnectToWalkerResult(result);

        assertEquals(result, response.getConnectToWalkerResult());
    }

    @Test
    void testDefaultValueIsNull() {
        ConnectToWalkerResponse response = new ConnectToWalkerResponse();

        assertNull(response.getConnectToWalkerResult(), "Expected default value to be null");
    }
}
