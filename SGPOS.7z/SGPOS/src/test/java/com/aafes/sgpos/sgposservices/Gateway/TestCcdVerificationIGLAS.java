/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aafes.sgpos.sgposservices.Gateway;

import com.aafes.sgpos.sgposservices.Config.EncryptorConfig;
import com.aafes.sgpos.sgposservices.generated.Control.IGLASRequest;
import com.aafes.sgpos.sgposservices.generated.Control.SGPOSServices;
import org.json.simple.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockedConstruction;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.*;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import org.mockito.junit.jupiter.MockitoSettings;

/**
 *
 * @author bhendarkart
 */
@ExtendWith(MockitoExtension.class)
public class TestCcdVerificationIGLAS {
    @Mock
    private EncryptorConfig encryptorConfig;

    @Mock
    private SGPOSServices sgposservices;

    private ccdVerificationIGLAS createService() {
        ccdVerificationIGLAS service = new ccdVerificationIGLAS();
        ReflectionTestUtils.setField(service, "CCDURL", "http://test-url");
        ReflectionTestUtils.setField(service, "CCDClientID", "client-id");
        ReflectionTestUtils.setField(service, "CCDUserName", "user");
        ReflectionTestUtils.setField(service, "CCDPassword", "password");
        ReflectionTestUtils.setField(service, "encryptorConfig", encryptorConfig);
        ReflectionTestUtils.setField(service, "ccdCallTimeout", "1000");
        ReflectionTestUtils.setField(service, "ccdCallReadTimeout", "1000");
        return service;
    }

    private void prepareRequest(String ssn, String tranCode) {
        IGLASRequest iglasRequest = mock(IGLASRequest.class);
        when(sgposservices.getIGLASRequest()).thenReturn(iglasRequest);
        when(iglasRequest.getSsn()).thenReturn(ssn);
        // Only stub tranCode if needed
        if (tranCode != null) {
            when(iglasRequest.getTranCode()).thenReturn(tranCode);
        }
    }

    private MockedConstruction<RestTemplate> simulateRestCall(Map<String, Object> responseData) {
        ResponseEntity<Object> mockResponse = new ResponseEntity<>(responseData, HttpStatus.OK);
        return mockConstruction(RestTemplate.class, (restTemplate, context) -> {
            when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(Object.class)))
                    .thenReturn(mockResponse);
        });
    }

    @Test
    void testResp000() throws Exception {
        ccdVerificationIGLAS service = createService();
        prepareRequest("123456", null); // no tranCode needed
        when(encryptorConfig.decrypt(anyString())).thenReturn("decrypted");

        try (MockedConstruction<RestTemplate> mocked = simulateRestCall(Map.of("respStatus", "000"))) {
            JSONObject result = service.CCDCall(sgposservices);
            assertTrue((Boolean) result.get("ccdCall"));
            assertNull(result.get("reasonCode"));
        }
    }
    @Test
    void testResp100WithMC2() throws Exception {
        ccdVerificationIGLAS service = createService();
        prepareRequest("999999", "MC2");
        when(encryptorConfig.decrypt(anyString())).thenReturn("decrypted");

        try (MockedConstruction<RestTemplate> mocked = simulateRestCall(Map.of("respStatus", "100"))) {
            JSONObject result = service.CCDCall(sgposservices);
            assertTrue((Boolean) result.get("ccdCall"));
            assertEquals("100", result.get("reasonCode"));
        }
    }
    @Test
    void testResp100WithNonMC2() throws Exception {
        ccdVerificationIGLAS service = createService();
        prepareRequest("888888", "TX2");
        when(encryptorConfig.decrypt(anyString())).thenReturn("decrypted");

        try (MockedConstruction<RestTemplate> mocked = simulateRestCall(Map.of("respStatus", "100"))) {
            JSONObject result = service.CCDCall(sgposservices);
            assertFalse((Boolean) result.get("ccdCall"));
            assertEquals("100", result.get("reasonCode"));
        }
    }
    @Test
    void testResp101() throws Exception {
        ccdVerificationIGLAS service = createService();
        prepareRequest("777777", null); // tranCode not needed
        when(encryptorConfig.decrypt(anyString())).thenReturn("decrypted");

        try (MockedConstruction<RestTemplate> mocked = simulateRestCall(Map.of("respStatus", "101"))) {
            JSONObject result = service.CCDCall(sgposservices);
            assertTrue((Boolean) result.get("ccdCall"));
            assertEquals("101", result.get("reasonCode"));
        }
    }

    @Test
    void testResp102() throws Exception {
        ccdVerificationIGLAS service = createService();
        prepareRequest("666666", null); // tranCode not needed
        when(encryptorConfig.decrypt(anyString())).thenReturn("decrypted");

        try (MockedConstruction<RestTemplate> mocked = simulateRestCall(Map.of("respStatus", "102"))) {
            JSONObject result = service.CCDCall(sgposservices);
            assertFalse((Boolean) result.get("ccdCall"));
            assertEquals("102", result.get("reasonCode"));
        }
    }
    @Test
    void testResp901WithMC2() throws Exception {
        ccdVerificationIGLAS service = createService();
        prepareRequest("555555", "MC2");
        when(encryptorConfig.decrypt(anyString())).thenReturn("decrypted");

        try (MockedConstruction<RestTemplate> mocked = simulateRestCall(Map.of("respStatus", "901"))) {
            JSONObject result = service.CCDCall(sgposservices);
            assertTrue((Boolean) result.get("ccdCall"));
            assertEquals("901", result.get("reasonCode"));
        }
    }
    @Test
    void testFallbackRespXYZWithNonMC2() throws Exception {
        ccdVerificationIGLAS service = createService();
        prepareRequest("444444", "TX4");
        when(encryptorConfig.decrypt(anyString())).thenReturn("decrypted");

        try (MockedConstruction<RestTemplate> mocked = simulateRestCall(Map.of("respStatus", "XYZ"))) {
            JSONObject result = service.CCDCall(sgposservices);
            assertFalse((Boolean) result.get("ccdCall"));
            assertEquals("999", result.get("reasonCode"));
        }
    }

    @Test
    void testFallbackRespXYZWithMC2() throws Exception {
        ccdVerificationIGLAS service = createService();
        prepareRequest("333333", "MC2");
        when(encryptorConfig.decrypt(anyString())).thenReturn("decrypted");

        try (MockedConstruction<RestTemplate> mocked = simulateRestCall(Map.of("respStatus", "XYZ"))) {
            JSONObject result = service.CCDCall(sgposservices);
            assertTrue((Boolean) result.get("ccdCall"));
            assertEquals("XYZ", result.get("reasonCode"));
        }
    }
}

