package com.aafes.sgpos.sgposservices.config;

import com.aafes.sgpos.sgposservices.Control.SGPOSRequestType;
import com.aafes.sgpos.sgposservices.generated.Control.Header;
import com.aafes.sgpos.sgposservices.generated.Control.ORISRequest;
import com.aafes.sgpos.sgposservices.util.BuildErrorResponseUtil;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;

import com.aafes.sgpos.sgposservices.Config.OrisValidation;
import com.aafes.sgpos.sgposservices.generated.Control.SGPOSServices;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

public class OrisValidationTest {
    @InjectMocks
    private OrisValidation orisValidation;
    @Mock
    private BuildErrorResponseUtil buildErrorResponseUtil;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testEmptyCheckWithNullCustomerID() {
        SGPOSServices input = new SGPOSServices();
        Header header = new Header();
        header.setFacilityNumber("");
        header.setLocalDateTime("230505230102");
        header.setTraceID("");
        input.setHeader(header);

        ORISRequest orisRequest = new ORISRequest();
        orisRequest.setRequestType(SGPOSRequestType.FINALAUTH);
        orisRequest.setCustomerID(" ");
        orisRequest.setReceivableType(" ");
        orisRequest.setBillingToOffice("");
        orisRequest.setBusinessDate("");
        orisRequest.setPODONbr("");
        orisRequest.setFacPhoneNum("");
        orisRequest.setFacManagerName("");
        orisRequest.setCashierID("");
        orisRequest.setGLAccountNumber("");
        orisRequest.setCashierNameTag("");
        orisRequest.setAmount("");

        input.setORISRequest(orisRequest);

        Mockito.when(buildErrorResponseUtil.buildErrorResponseAdd(Mockito.any(), Mockito.eq("INVALID_REQUEST")))
                .thenReturn(input);
        SGPOSServices result = orisValidation.emptyCheck(input);
        Assertions.assertNotNull(result, "Should handle null header gracefully");
    }
    @Test
    void testEmptyCheckWithNullCustomerIDWithDetails() {
        SGPOSServices input = new SGPOSServices();
        Header header = new Header();
        header.setFacilityNumber("");
        header.setLocalDateTime("230505230102");
        header.setTraceID("");
        input.setHeader(header);

        ORISRequest orisRequest = new ORISRequest();
        orisRequest.setRequestType(SGPOSRequestType.FINALAUTH);
        orisRequest.setCustomerID("sacsa");
        orisRequest.setReceivableType("sacsac ");
        orisRequest.setBillingToOffice("ascsca");
        orisRequest.setBusinessDate("ascas");
        orisRequest.setPODONbr("ascc");
        orisRequest.setFacPhoneNum("sacsa");
        orisRequest.setFacManagerName("ascsc");
        orisRequest.setCashierID("sac");
        orisRequest.setGLAccountNumber("asc");
        orisRequest.setCashierNameTag("asc");
        orisRequest.setAmount("22");

        input.setORISRequest(orisRequest);

        Mockito.when(buildErrorResponseUtil.buildErrorResponseAdd(Mockito.any(), Mockito.eq("INVALID_REQUEST")))
                .thenReturn(input);
        SGPOSServices result = orisValidation.emptyCheck(input);
        Assertions.assertNotNull(result, "Should handle null header gracefully");
    }




}
