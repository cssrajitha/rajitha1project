package com.aafes.sgpos.sgposservices.util;

import com.aafes.sgpos.sgposservices.Control.SGPOSResponseType;
import com.aafes.sgpos.sgposservices.generated.Control.Response;
import com.aafes.sgpos.sgposservices.generated.Control.SGPOSServices;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.core.env.Environment;

public class BuildErrorResponseUtilTest {
    private Environment env;
    private BuildErrorResponseUtil buildErrorResponseUtil;

    @Before
    public void setUp() {
        env = Mockito.mock(Environment.class);
        buildErrorResponseUtil = new BuildErrorResponseUtil();
        buildErrorResponseUtil.setEnv(env);
    }

    @Test
    public void testBuildResponseAdd() {
        SGPOSServices sgposServices = new SGPOSServices();
        SGPOSServices sgPos = new SGPOSServices();
        buildResponseAdd(sgPos);
        try {
            sgposServices = buildErrorResponseUtil.buildErrorResponseAdd(sgposServices, "INVALID_REQUEST");
            Assert.assertTrue(true);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }
    @Test
    public void testBuildResponseAddCVSTimeout() {
        SGPOSServices sgposServices = new SGPOSServices();
        SGPOSServices sgPos = new SGPOSServices();
        buildResponseAdd(sgPos);
        try {
            sgposServices = buildErrorResponseUtil.buildErrorResponseAdd(sgposServices, "CVS_TIME_OUT");
            Assert.assertTrue(true);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }
    @Test
    public void testBuildResponseAddIGLASTimeout() {
        SGPOSServices sgposServices = new SGPOSServices();
        SGPOSServices sgPos = new SGPOSServices();
        buildResponseAdd(sgPos);
        try {
            sgposServices = buildErrorResponseUtil.buildErrorResponseAdd(sgposServices, "IGLAS_TIME_OUT");
            Assert.assertTrue(true);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }
    @Test
    public void testBuildResponseAddOrisTimeout() {
        SGPOSServices sgposServices = new SGPOSServices();
        SGPOSServices sgPos = new SGPOSServices();
        buildResponseAdd(sgPos);
        try {
            sgposServices = buildErrorResponseUtil.buildErrorResponseAdd(sgposServices, "ORIS_TIME_OUT");
            Assert.assertTrue(true);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }
    @Test
    public void testBuildResponseAddSOCTimeout() {
        SGPOSServices sgposServices = new SGPOSServices();
        SGPOSServices sgPos = new SGPOSServices();
        buildResponseAdd(sgPos);
        try {
            sgposServices = buildErrorResponseUtil.buildErrorResponseAdd(sgposServices, "SOC_TIME_OUT");
            Assert.assertTrue(true);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }
    @Test
    public void testBuildResponseAddSOATimeout() {
        SGPOSServices sgposServices = new SGPOSServices();
        SGPOSServices sgPos = new SGPOSServices();
        buildResponseAdd(sgPos);
        try {
            sgposServices = buildErrorResponseUtil.buildErrorResponseAdd(sgposServices, "SOA_TIME_OUT");
            Assert.assertTrue(true);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }
    @Test
    public void testBuildResponseAddPartialApproved() {
        SGPOSServices sgposServices = new SGPOSServices();
        SGPOSServices sgPos = new SGPOSServices();
        buildResponseAdd(sgPos);
        try {
            sgposServices = buildErrorResponseUtil.buildErrorResponseAdd(sgposServices, "PARTIAL_APPROVED");
            Assert.assertTrue(true);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testBuildResponseOris() {
        SGPOSServices sgposServices = new SGPOSServices();
        SGPOSServices sgPos = new SGPOSServices();
        buildResponseAdd(sgPos);
        try {
            sgposServices = buildErrorResponseUtil.buildErrorResponseOris(sgposServices, "INVALID_REQUEST", "P850");
            Assert.assertEquals(sgPos, sgposServices);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }
    @Test
    public void testBuildErrorResponseAdd_ORISTimeout_ShouldSetTimeout() {
        Mockito.when(env.getProperty("ORIS_TIME_OUT", String.class)).thenReturn("P001");
        SGPOSServices result = buildErrorResponseUtil.buildErrorResponseAdd(new SGPOSServices(), "ORIS_TIME_OUT");

        Assert.assertEquals(SGPOSResponseType.TIMEOUT, result.getResponse().getResponse());
        Assert.assertEquals("ORIS_TIME_OUT", result.getResponse().getReasonDescription());
        Assert.assertEquals("P001", result.getResponse().getReasonCode());
    }

    @Test
    public void testBuildErrorResponseAdd_SOCTimeout_ShouldSetTimeout() {
        Mockito.when(env.getProperty("SOC_TIME_OUT", String.class)).thenReturn("P002");
        SGPOSServices result = buildErrorResponseUtil.buildErrorResponseAdd(new SGPOSServices(), "SOC_TIME_OUT");

        Assert.assertEquals(SGPOSResponseType.TIMEOUT, result.getResponse().getResponse());
        Assert.assertEquals("SOC_TIME_OUT", result.getResponse().getReasonDescription());
        Assert.assertEquals("P002", result.getResponse().getReasonCode());
    }

    @Test
    public void testBuildErrorResponseAdd_SOATimeout_ShouldSetTimeout() {
        Mockito.when(env.getProperty("SOA_TIME_OUT", String.class)).thenReturn("P003");
        SGPOSServices result = buildErrorResponseUtil.buildErrorResponseAdd(new SGPOSServices(), "SOA_TIME_OUT");

        Assert.assertEquals(SGPOSResponseType.TIMEOUT, result.getResponse().getResponse());
        Assert.assertEquals("SOA_TIME_OUT", result.getResponse().getReasonDescription());
        Assert.assertEquals("P003", result.getResponse().getReasonCode());
    }


    public void buildResponseAdd(SGPOSServices sgPos) {
        Response response = new Response();
        response.setReasonCode("P850");
        response.setReasonDescription("INVALID_REQUEST");
        response.setResponse(SGPOSResponseType.DECLINED);
        sgPos.setResponse(response);
        sgPos.setHeader(sgPos.getHeader());
        sgPos.setCVSRequest(null);
        sgPos.setORISRequest(null);
    }
    @Test
    public void testBuildErrorResponseAdd_IGLASTimeout_ShouldSetTimeout() {
        Mockito.when(env.getProperty("IGLAS_TIME_OUT", String.class)).thenReturn("P004");

        SGPOSServices result = buildErrorResponseUtil.buildErrorResponseAdd(new SGPOSServices(), "IGLAS_TIME_OUT");

        Assert.assertEquals(SGPOSResponseType.TIMEOUT, result.getResponse().getResponse());
        Assert.assertEquals("IGLAS_TIME_OUT", result.getResponse().getReasonDescription());
        Assert.assertEquals("P004", result.getResponse().getReasonCode());
    }


}

