/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aafes.sgpos.sgposservices.config;
import com.aafes.sgpos.sgposservices.Config.CassandraConfig;
import com.aafes.sgpos.sgposservices.Config.EncryptorConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.data.cassandra.config.CqlSessionFactoryBean;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 *
 * @author bhendarkart
 */
public class CassandraConfigTest {
     private CassandraConfig cassandraConfig;
     private EncryptorConfig encryptorConfig;

     @BeforeEach
     void setUp() {
          cassandraConfig = new CassandraConfig();

          // Inject mock values using ReflectionTestUtils
          ReflectionTestUtils.setField(cassandraConfig, "keyspaceName", "test_keyspace");
          ReflectionTestUtils.setField(cassandraConfig, "cassandraHost", "localhost");
          ReflectionTestUtils.setField(cassandraConfig, "port", "9042");
          ReflectionTestUtils.setField(cassandraConfig, "userName", "encryptedUser");
          ReflectionTestUtils.setField(cassandraConfig, "password", "encryptedPass");
          ReflectionTestUtils.setField(cassandraConfig, "localdataCenter", "datacenter1");
          ReflectionTestUtils.setField(cassandraConfig, "baseDir", "/mock/path");

          // Mock EncryptorConfig
          encryptorConfig = Mockito.mock(EncryptorConfig.class);
          when(encryptorConfig.decrypt("encryptedUser")).thenReturn("decryptedUser");
          when(encryptorConfig.decrypt("encryptedPass")).thenReturn("decryptedPass");

          ReflectionTestUtils.setField(cassandraConfig, "encryptorConfig", encryptorConfig);
     }

     @Test
     void testGetKeyspaceName_usingReflection() throws Exception {
          var method = CassandraConfig.class.getDeclaredMethod("getKeyspaceName");
          method.setAccessible(true); // override protection
          String keyspace = (String) method.invoke(cassandraConfig);
          assertEquals("test_keyspace", keyspace, "Keyspace name mismatch");
     }

     @Test
     void testGetContactPoints() {
          assertEquals("localhost", cassandraConfig.getContactPoints());
     }

     @Test
     void testGetEntityBasePackages() {
          String[] packages = cassandraConfig.getEntityBasePackages();
          assertNotNull(packages);
          assertEquals("com.aafes.sgpos.sgposservices.Entity", packages[0]);
     }
    
}
