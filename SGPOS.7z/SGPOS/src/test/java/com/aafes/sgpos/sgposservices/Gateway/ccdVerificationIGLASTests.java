package com.aafes.sgpos.sgposservices.Gateway;

import com.aafes.sgpos.sgposservices.Config.EncryptorConfig;
import com.aafes.sgpos.sgposservices.generated.Control.CVSRequest;
import com.aafes.sgpos.sgposservices.generated.Control.Header;
import com.aafes.sgpos.sgposservices.generated.Control.IGLASRequest;
import com.aafes.sgpos.sgposservices.generated.Control.SGPOSServices;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.simple.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockedConstruction;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.when;

//@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = {ccdVerificationIGLASTests.class})
public class ccdVerificationIGLASTests {

    @Mock
    private ccdVerificationIGLAS ccdVerificationIGLAS;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private EncryptorConfig encryptorConfig;

    @Mock
    private SGPOSServices sgposServices;

    @Mock
    private ObjectMapper objectMapper;

    @Value("${ccd.CCDUserName}")
    private String CCDUserName = "testUser";
    @Value("${ccd.CCDPassword}")
    private String CCDPassword = "testPassword";
    @Value("${ccd.CCDClientID}")
    private String CCDClientID = "testClientID";
    @Value("${ccd.CCDURL:http://testccdurl.com}")
    public String CCDURL;
    @Value("${timeOut.ccdCallTimeout}")
    private String ccdCallTimeout = "5000";
    @Value("${timeOut.ccdCallReadTimeout}")
    private String ccdCallReadTimeout = "5000";

    private static final ObjectMapper mapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(ccdVerificationIGLAS, "CCDUserName", "testUser");
        ReflectionTestUtils.setField(ccdVerificationIGLAS, "CCDPassword", "testPass");
        ReflectionTestUtils.setField(ccdVerificationIGLAS, "CCDClientID", "testClientID");
        ReflectionTestUtils.setField(ccdVerificationIGLAS, "CCDURL", "http://testccdurl.com");
        ReflectionTestUtils.setField(ccdVerificationIGLAS, "ccdCallTimeout", "5000");
        ReflectionTestUtils.setField(ccdVerificationIGLAS, "ccdCallReadTimeout", "5000");
    }

    @Test
    public void testCCDCallSuccessEDIPI() throws Exception {
        when(sgposServices.getIGLASRequest()).thenReturn(mock(IGLASRequest.class));

        Header mockHeader = new Header();
        mockHeader.setTraceID("12345");
        when(sgposServices.getHeader()).thenReturn(mockHeader);
        assertEquals("12345", sgposServices.getHeader().getTraceID());

        IGLASRequest mockIGLASRequest = mock(IGLASRequest.class);
        when(sgposServices.getIGLASRequest()).thenReturn(mockIGLASRequest);
        when(mockIGLASRequest.getSsn()).thenReturn("EDIPI");
        when(mockIGLASRequest.getFacilityNumber()).thenReturn("12345");
        when(encryptorConfig.decrypt(anyString())).thenReturn("DecryptedPassword");
        when(sgposServices.getIGLASRequest()).thenReturn(mockIGLASRequest);

        JSONObject mockResponseBody = new JSONObject();
        mockResponseBody.put("respStatus", "000");
        ResponseEntity<Object> responseEntity = new ResponseEntity<>(mockResponseBody.toString(), HttpStatus.OK);
        JSONObject result = new JSONObject();
        result.put("ccdCall", true);
        result.put("ssn", "123-45-6789");
        result.put("respStatus", "000");

        when(ccdVerificationIGLAS.CCDCall(sgposServices)).thenReturn(result);

        JSONObject jsonObjectResult = new JSONObject();
        assertNotNull(jsonObjectResult);
        assertEquals(true, result.get("ccdCall"));
        assertEquals("123-45-6789", result.get("ssn"));
        assertEquals("000", result.get("respStatus"));
    }

    @Test
    public void testCCDCallFailureWithStatusNot000() throws Exception {
        // Mock necessary methods and data
        SGPOSServices sgposServices = mock(SGPOSServices.class, RETURNS_DEEP_STUBS);
        when(encryptorConfig.decrypt(CCDPassword)).thenReturn("decryptedPassword");
        when(sgposServices.getIGLASRequest().getSsn()).thenReturn("SSN");
        when(sgposServices.getIGLASRequest().getFacilityNumber()).thenReturn("98765");

        when(sgposServices.getIGLASRequest()).thenReturn(mock(IGLASRequest.class));

        Header mockHeader = new Header();
        mockHeader.setTraceID("12345");
        when(sgposServices.getHeader()).thenReturn(mockHeader);
        assertEquals("12345", sgposServices.getHeader().getTraceID());

        IGLASRequest mockIGLASRequest = mock(IGLASRequest.class);
        when(sgposServices.getIGLASRequest()).thenReturn(mockIGLASRequest);
        when(mockIGLASRequest.getSsn()).thenReturn("EDIPI");
        when(mockIGLASRequest.getFacilityNumber()).thenReturn("12345");
        when(encryptorConfig.decrypt(anyString())).thenReturn("DecryptedPassword");
        when(sgposServices.getIGLASRequest()).thenReturn(mockIGLASRequest);

        JSONObject mockResponseBody = new JSONObject();
        mockResponseBody.put("respStatus", "000");
        ResponseEntity<Object> responseEntity = new ResponseEntity<>(mockResponseBody.toString(), HttpStatus.OK);

        JSONObject result = new JSONObject();
        result.put("ccdCall", false);
        result.put("abcde", "123-45-6789");
        result.put("respStatus", "000");

        when(ccdVerificationIGLAS.CCDCall(sgposServices)).thenReturn(result);

        JSONObject jsonObjectResult = new JSONObject();
        assertNotNull(jsonObjectResult);
        assertEquals(false, result.get("ccdCall"));
        assertNotEquals("123-45-6789", result.get("ssn"));
        assertEquals("000", result.get("respStatus"));
    }
    //
    @Test
    public void testCCDCallFailureWithStatusCode100() throws Exception {
        // Mock necessary methods and data
        SGPOSServices sgposServices = mock(SGPOSServices.class, RETURNS_DEEP_STUBS);
        when(encryptorConfig.decrypt(CCDPassword)).thenReturn("decryptedPassword");
        when(sgposServices.getIGLASRequest().getSsn()).thenReturn("SSN");
        when(sgposServices.getIGLASRequest().getFacilityNumber()).thenReturn("98765");

        when(sgposServices.getIGLASRequest()).thenReturn(mock(IGLASRequest.class));

        Header mockHeader = new Header();
        mockHeader.setTraceID("12345");
        when(sgposServices.getHeader()).thenReturn(mockHeader);
        assertEquals("12345", sgposServices.getHeader().getTraceID());

        IGLASRequest mockIGLASRequest = mock(IGLASRequest.class);
        when(sgposServices.getIGLASRequest()).thenReturn(mockIGLASRequest);
        when(mockIGLASRequest.getSsn()).thenReturn("EDIPI");
        when(mockIGLASRequest.getFacilityNumber()).thenReturn("12345");
        when(encryptorConfig.decrypt(anyString())).thenReturn("DecryptedPassword");
        when(sgposServices.getIGLASRequest()).thenReturn(mockIGLASRequest);

        JSONObject mockResponseBody = new JSONObject();
        mockResponseBody.put("respStatus", "100");
        ResponseEntity<Object> responseEntity = new ResponseEntity<>(mockResponseBody.toString(), HttpStatus.OK);

        JSONObject result = new JSONObject();
        result.put("ccdCall", false);
        result.put("abcde", "123-45-6789");
        result.put("respStatus", "100");

        when(ccdVerificationIGLAS.CCDCall(sgposServices)).thenReturn(result);

        JSONObject jsonObjectResult = new JSONObject();
        assertNotNull(jsonObjectResult);
        assertEquals(false, result.get("ccdCall"));
        assertNotEquals("123-45-6789", result.get("ssn"));
        assertEquals("100", result.get("respStatus"));
    }
    @Test
    public void testCCDCallFailureWithStatus102() throws Exception {
        // Mock necessary methods and data
            SGPOSServices sgposServices = mock(SGPOSServices.class, RETURNS_DEEP_STUBS);
            when(encryptorConfig.decrypt(CCDPassword)).thenReturn("decryptedPassword");
            when(sgposServices.getIGLASRequest().getSsn()).thenReturn("SSN");
            when(sgposServices.getIGLASRequest().getFacilityNumber()).thenReturn("98765");

            when(sgposServices.getIGLASRequest()).thenReturn(mock(IGLASRequest.class));

            Header mockHeader = new Header();
            mockHeader.setTraceID("12345");
            when(sgposServices.getHeader()).thenReturn(mockHeader);
            assertEquals("12345", sgposServices.getHeader().getTraceID());

            IGLASRequest mockIGLASRequest = mock(IGLASRequest.class);
            when(sgposServices.getIGLASRequest()).thenReturn(mockIGLASRequest);
            when(mockIGLASRequest.getSsn()).thenReturn("EDIPI");
            when(mockIGLASRequest.getFacilityNumber()).thenReturn("12345");
            when(encryptorConfig.decrypt(anyString())).thenReturn("DecryptedPassword");
            when(sgposServices.getIGLASRequest()).thenReturn(mockIGLASRequest);

            JSONObject mockResponseBody = new JSONObject();
            mockResponseBody.put("respStatus", "102");
            ResponseEntity<Object> responseEntity = new ResponseEntity<>(mockResponseBody.toString(), HttpStatus.OK);

            JSONObject result = new JSONObject();
            result.put("ccdCall", false);
            result.put("abcde", "123-45-6789");
            result.put("respStatus", "102");

            when(ccdVerificationIGLAS.CCDCall(sgposServices)).thenReturn(result);

            JSONObject jsonObjectResult = new JSONObject();
            assertNotNull(jsonObjectResult);
            assertEquals(false, result.get("ccdCall"));
            assertNotEquals("123-45-6789", result.get("ssn"));
            assertEquals("102", result.get("respStatus"));
    }

    @Test
    public void testCCDCallFailureWithStatus901() throws Exception {
        // Mock necessary methods and data
        SGPOSServices sgposServices = mock(SGPOSServices.class, RETURNS_DEEP_STUBS);
        when(encryptorConfig.decrypt(CCDPassword)).thenReturn("decryptedPassword");
        when(sgposServices.getIGLASRequest().getSsn()).thenReturn("SSN");
        when(sgposServices.getIGLASRequest().getFacilityNumber()).thenReturn("98765");

        when(sgposServices.getIGLASRequest()).thenReturn(mock(IGLASRequest.class));

        Header mockHeader = new Header();
        mockHeader.setTraceID("12345");
        when(sgposServices.getHeader()).thenReturn(mockHeader);
        assertEquals("12345", sgposServices.getHeader().getTraceID());

        IGLASRequest mockIGLASRequest = mock(IGLASRequest.class);
        when(sgposServices.getIGLASRequest()).thenReturn(mockIGLASRequest);
        when(mockIGLASRequest.getSsn()).thenReturn("EDIPI");
        when(mockIGLASRequest.getFacilityNumber()).thenReturn("12345");
        when(encryptorConfig.decrypt(anyString())).thenReturn("DecryptedPassword");
        when(sgposServices.getIGLASRequest()).thenReturn(mockIGLASRequest);

        JSONObject mockResponseBody = new JSONObject();
        mockResponseBody.put("respStatus", "901");
        ResponseEntity<Object> responseEntity = new ResponseEntity<>(mockResponseBody.toString(), HttpStatus.OK);

        JSONObject result = new JSONObject();
        result.put("ccdCall", false);
        result.put("abcde", "123-45-6789");
        result.put("respStatus", "901");

        when(ccdVerificationIGLAS.CCDCall(sgposServices)).thenReturn(result);

        JSONObject jsonObjectResult = new JSONObject();
        assertNotNull(jsonObjectResult);
        assertEquals(false, result.get("ccdCall"));
        assertNotEquals("123-45-6789", result.get("ssn"));
        assertEquals("901", result.get("respStatus"));
    }

    @Test
    public void testCCDCallFailureWithStatusDefault() throws Exception {
        // Mock necessary methods and data
        SGPOSServices sgposServices = mock(SGPOSServices.class, RETURNS_DEEP_STUBS);
        when(encryptorConfig.decrypt(CCDPassword)).thenReturn("decryptedPassword");
        when(sgposServices.getIGLASRequest().getSsn()).thenReturn("SSN");
        when(sgposServices.getIGLASRequest().getFacilityNumber()).thenReturn("98765");

        when(sgposServices.getIGLASRequest()).thenReturn(mock(IGLASRequest.class));

        Header mockHeader = new Header();
        mockHeader.setTraceID("12345");
        when(sgposServices.getHeader()).thenReturn(mockHeader);
        assertEquals("12345", sgposServices.getHeader().getTraceID());

        IGLASRequest mockIGLASRequest = mock(IGLASRequest.class);
        when(sgposServices.getIGLASRequest()).thenReturn(mockIGLASRequest);
        when(mockIGLASRequest.getSsn()).thenReturn("EDIPI");
        when(mockIGLASRequest.getFacilityNumber()).thenReturn("12345");
        when(encryptorConfig.decrypt(anyString())).thenReturn("DecryptedPassword");
        when(sgposServices.getIGLASRequest()).thenReturn(mockIGLASRequest);

        JSONObject mockResponseBody = new JSONObject();
        mockResponseBody.put("respStatus", "999");
        ResponseEntity<Object> responseEntity = new ResponseEntity<>(mockResponseBody.toString(), HttpStatus.OK);

        JSONObject result = new JSONObject();
        result.put("ccdCall", false);
        result.put("abcde", "123-45-6789");
        result.put("respStatus", "999");

        when(ccdVerificationIGLAS.CCDCall(sgposServices)).thenReturn(result);

        JSONObject jsonObjectResult = new JSONObject();
        assertNotNull(jsonObjectResult);
        assertEquals(false, result.get("ccdCall"));
        assertNotEquals("123-45-6789", result.get("ssn"));
        assertEquals("999", result.get("respStatus"));
    }
    @Test
    public void testCCDCallRespStatus901WithTranCodeOtherThanMC2() throws Exception {
        // Arrange
        SGPOSServices sgposServices = mock(SGPOSServices.class);
        IGLASRequest mockIGLASRequest = mock(IGLASRequest.class);
        when(mockIGLASRequest.getSsn()).thenReturn("123456789");
        when(mockIGLASRequest.getTranCode()).thenReturn("TX99"); // triggers false branch
        when(sgposServices.getIGLASRequest()).thenReturn(mockIGLASRequest);

        EncryptorConfig encryptorConfig = mock(EncryptorConfig.class);
        when(encryptorConfig.decrypt(anyString())).thenReturn("decryptedPassword");

        ccdVerificationIGLAS service = new ccdVerificationIGLAS();
        ReflectionTestUtils.setField(service, "CCDUserName", "user");
        ReflectionTestUtils.setField(service, "CCDPassword", "password");
        ReflectionTestUtils.setField(service, "CCDClientID", "clientId");
        ReflectionTestUtils.setField(service, "CCDURL", "http://test-url");
        ReflectionTestUtils.setField(service, "ccdCallTimeout", "1000");
        ReflectionTestUtils.setField(service, "ccdCallReadTimeout", "1000");
        ReflectionTestUtils.setField(service, "encryptorConfig", encryptorConfig);

        try (MockedConstruction<RestTemplate> mocked = mockConstruction(RestTemplate.class,
                (restTemplate, context) -> {
                    when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(Object.class)))
                            .thenReturn(new ResponseEntity<>(Map.of("respStatus", "901"), HttpStatus.OK));
                })) {
            // Act
            JSONObject result = service.CCDCall(sgposServices);

            // Assert
            assertFalse((Boolean) result.get("ccdCall"));
            assertEquals("901", result.get("reasonCode"));
        }
    }


}