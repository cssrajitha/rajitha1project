package com.aafes.sgpos.sgposservices.ControllerTest;

import com.aafes.sgpos.sgposservices.Controller.SGPOSServicesController;
import com.aafes.sgpos.sgposservices.Config.WalkerClient;
import com.aafes.sgpos.sgposservices.Service.SGPOSServicesservice;
import com.aafes.sgpos.sgposservices.util.BuildErrorResponseUtil;
import com.aafes.sgpos.sgposservices.util.ValidateRequestUtil;
import com.aafes.sgpos.sgposservices.util.ValidateSchemaUtil;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.networknt.schema.JsonSchema;
import com.networknt.schema.JsonSchemaFactory;
import com.networknt.schema.SpecVersion;
import org.junit.Before;
import org.mockito.Mockito;
import org.springframework.core.env.Environment;
import org.springframework.web.client.RestTemplate;

import java.io.BufferedInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class SGPOSServicesControllerTest {
    private RestTemplate restTemplate;
    private SGPOSServicesController sgposServicesController;
    private Environment env;
    private JsonSchema schema;
    private static JsonSchemaFactory schemaFactory;
    private JsonSchema schemaSgPosServices;
    private InputStream schemaStreamSgPos;
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    BuildErrorResponseUtil buildErrorResponseUtil;

    private SGPOSServicesservice response;

    private WalkerClient orisclient;


    ValidateSchemaUtil validateSchemaUtil = new ValidateSchemaUtil();
    ValidateRequestUtil validateRequestUtil = new ValidateRequestUtil();

    public SGPOSServicesControllerTest() {
    }
    @Before
    public void setUpClass() throws FileNotFoundException {
        restTemplate = Mockito.mock(RestTemplate.class);
        sgposServicesController = new SGPOSServicesController();
        env = Mockito.mock(Environment.class);
        buildErrorResponseUtil = Mockito.mock(BuildErrorResponseUtil.class);
        sgposServicesController.setBuildErrorResponseUtil(buildErrorResponseUtil);
        //sgposServicesController.setEnv(env);
        sgposServicesController.getBuildErrorResponseUtil();
        //sgposServicesController.getEnv();
        Mockito.when(env.getProperty("mask.requestFields")).thenReturn("cid");
        Mockito.when(env.getProperty("jsonPath.sGPOSServices")).thenReturn("json/SGPOSServices.json");
        JsonSchemaFactory schemaFactory = JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V7);
        schemaStreamSgPos= new BufferedInputStream(TypeReference.class.getResourceAsStream("json/SGPOSServices.json"));
        schema = schemaFactory.getSchema(schemaStreamSgPos);
        sgposServicesController.setSchemaAdd(schema);
    }

}
