/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aafes.sgpos.sgposservices.ControlTest;
import com.aafes.sgpos.sgposservices.Control.requestCCD;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author bhendarkart
 */
public class requestCCDTest {
    @Test
    void testSettersAndGetters() {
        requestCCD request = new requestCCD();

        request.setSSN("123-45-6789");
        request.setCID("CID001");
        request.setDODEDIPersonalId("DODEDI-987654");

        assertEquals("123-45-6789", request.getSSN());
        assertEquals("CID001", request.getCID());
        assertEquals("DODEDI-987654", request.getDODEDIPersonalId());
    }

    @Test
    void testToStringContainsFields() {
        requestCCD request = new requestCCD();
        request.setSSN("111-22-3333");
        request.setCID("CID002");
        request.setDODEDIPersonalId("DODEDI-123456");

        String output = request.toString();

        assertTrue(output.contains("SSN='111-22-3333'"));
        assertTrue(output.contains("CID='CID002'"));
        assertTrue(output.contains("DODEDIPersonalId='DODEDI-123456'"));
    }

    @Test
    void testDefaultValuesAreNull() {
        requestCCD request = new requestCCD();

        assertNull(request.getSSN());
        assertNull(request.getCID());
        assertNull(request.getDODEDIPersonalId());
    }
}
