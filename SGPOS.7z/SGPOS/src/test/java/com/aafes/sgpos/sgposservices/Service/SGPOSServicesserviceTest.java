package com.aafes.sgpos.sgposservices.Service;

import com.aafes.sgpos.sgposservices.Config.EncryptorConfig;
import com.aafes.sgpos.sgposservices.Config.OrisValidation;
import com.aafes.sgpos.sgposservices.Config.WalkerResponse;
import com.aafes.sgpos.sgposservices.Control.SGPOSRequestType;
import com.aafes.sgpos.sgposservices.Exception.GatewayException;
import com.aafes.sgpos.sgposservices.Gateway.*;
import com.aafes.sgpos.sgposservices.Repository.FacilityRepo;
import com.aafes.sgpos.sgposservices.Repository.storeOpenCloseMessagesRepository;
import com.aafes.sgpos.sgposservices.generated.Control.*;
import com.aafes.sgpos.sgposservices.util.BuildErrorResponseUtil;
import com.aafes.sgpos.sgposservices.walkerinterface.ApplyTXNResponse;
import com.aafes.sgpos.sgposservices.walkerinterface.ConnectToWalkerResponse;
import com.aafes.sgpos.sgposservices.walkerinterface.LogOffWalkerResponse;
import com.aafes.sgpos.sgposservices.walkerinterface.ServerAccessProperties;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.junit.jupiter.api.*;
import com.aafes.sgpos.sgposservices.Entity.fac_fmf;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.io.FileWriter;
import java.lang.reflect.Field;
import java.util.Collections;
import java.util.List;

import org.json.simple.JSONArray;

public class SGPOSServicesserviceTest {
    @InjectMocks
    private SGPOSServicesservice sgposServicesservice;

    @Mock
    private FacilityRepo facilityrepo;

    @Mock
    private storeOpenCloseMessagesRepository resaQueueRepository;
    @Mock
    private BuildErrorResponseUtil buildErrorResponseUtil;
    @Mock
    private MQService mqConnection;

    @Mock
    private ccdVerificationIGLAS ccdVerIGLAS;


    @Mock
    private ccdVerificationCVS ccdVerCVS;

    @Mock
    private ccdVerificationIDCHECK ccdVerIDCHECK;

    @Mock
    private EncryptorConfig encryptorConfig;

    @Mock
    private ResaMessages resaGatewayBean;

    @Mock
    private WalkerResponse walkerresponse;

    @Mock
    private OrisValidation orisValidation;
    @Mock
    private orisVerification OrisVerification;

    private Logger log = Logger.getLogger(this.getClass());

    @BeforeAll
    static void initAll() {
    }

    @BeforeEach
    void init() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    @DisplayName("Should return error response when LocalDateTime is invalid")
    void testInvalidLocalDateTime() throws Exception {
        // Arrange
        SGPOSServices input = new SGPOSServices();
        Header header = new Header();
        header.setFacilityNumber("12345");
        header.setLocalDateTime("invalidDateTime");
        input.setHeader(header);

        SGPOSServices errorResponse = new SGPOSServices();
        Mockito.when(buildErrorResponseUtil.buildErrorResponseAdd(Mockito.any(), Mockito.eq("INVALID_REQUEST")))
                .thenReturn(input);

        // Act
        SGPOSServices result = sgposServicesservice.Response(input);

        // Assert
        Assertions.assertTrue(true);
        Mockito.verify(buildErrorResponseUtil).buildErrorResponseAdd(Mockito.any(), Mockito.eq("INVALID_REQUEST"));
    }

    @Test
    @DisplayName("Should return error response when FacilityNumber is empty")
    void testEmptyFacilityNumber() throws Exception {
        // Arrange
        SGPOSServices input = new SGPOSServices();
        Header header = new Header();
        header.setFacilityNumber(""); // Empty FacilityNumber
        header.setLocalDateTime("230505230102");
        input.setHeader(header);

        SGPOSServices errorResponse = new SGPOSServices();
        Mockito.when(buildErrorResponseUtil.buildErrorResponseAdd(Mockito.any(), Mockito.eq("INVALID_REQUEST")))
                .thenReturn(input);
        Mockito.when(buildErrorResponseUtil.buildErrorResponseAdd(Mockito.any(), Mockito.eq("FACILITY_NOT_FOUND")))
                .thenReturn(input);

        // Act
        SGPOSServices result = sgposServicesservice.Response(input);

        // Assert
        Assertions.assertEquals(input, result);
        Mockito.verify(buildErrorResponseUtil).buildErrorResponseAdd(Mockito.any(), Mockito.eq("INVALID_REQUEST"));
    }

    @Test
    @DisplayName("Should handle ORISRequest with invalid login response")
    void testOrisRequestInvalidLogin() throws Exception {
        // Arrange
        SGPOSServices input = new SGPOSServices();
        Header header = new Header();
        header.setFacilityNumber("12345");
        header.setLocalDateTime("230505230102");
        input.setHeader(header);

        ORISRequest orisRequest = new ORISRequest();
        orisRequest.setRequestType(SGPOSRequestType.PREAUTH);
        input.setORISRequest(orisRequest);
        Mockito.when(buildErrorResponseUtil.buildErrorResponseAdd(Mockito.any(), Mockito.eq("ORIS_TIME_OUT")))
                .thenReturn(input);
        Mockito.when(OrisVerification.login(Mockito.any())).thenReturn(null); // Simulate invalid login response
        Mockito.when(facilityrepo.findByFacility("12345")).thenReturn(List.of(new fac_fmf()));
        Mockito.when(orisValidation.emptyCheck(Mockito.any())).thenReturn(input);

        // Act
        SGPOSServices result = sgposServicesservice.Response(input);

        // Assert
        Assertions.assertTrue(true);
        Mockito.verify(OrisVerification).login(Mockito.any());
        Mockito.verify(orisValidation).emptyCheck(Mockito.any());
    }

//    @Test
//    @DisplayName("Should handle ORISRequest with login timeout")
//    void testOrisRequestLoginTimeout() throws Exception {
//        // Arrange
//        SGPOSServices input = new SGPOSServices();
//        Header header = new Header();
//        header.setFacilityNumber("12345");
//        header.setLocalDateTime("230505230102");
//        input.setHeader(header);
//
//        ORISRequest orisRequest = new ORISRequest();
//        orisRequest.setRequestType(SGPOSRequestType.PREAUTH);
//        input.setORISRequest(orisRequest);
//
//        Mockito.when(OrisVerification.login(input)).thenReturn(new ConnectToWalkerResponse()); // Simulate timeout
//        Mockito.when(facilityrepo.findByFacility("12345")).thenReturn(List.of(new fac_fmf()));
//        Mockito.when(orisValidation.emptyCheck(Mockito.any())).thenReturn(input);
//
//        // Act
//        SGPOSServices result = sgposServicesservice.Response(input);
//
//        // Assert
//        Assertions.assertNotNull(result);
//        Mockito.verify(OrisVerification).login(Mockito.any());
//        Mockito.verify(buildErrorResponseUtil).buildErrorResponseAdd(Mockito.any(), Mockito.eq("ORIS_TIME_OUT"));
//    }

    @Test
    @DisplayName("Should handle StoreOpenCloseRequest with STOREOPEN type")
    void testStoreOpenCloseRequestStoreOpen() throws Exception {
        // Arrange
        SGPOSServices input = new SGPOSServices();
        Header header = new Header();
        header.setFacilityNumber("12345");
        header.setLocalDateTime("230505230102");
        input.setHeader(header);

        StoreOpenCloseRequest storeOpenCloseRequest = new StoreOpenCloseRequest();
        storeOpenCloseRequest.setRequestType(SGPOSRequestType.STOREOPEN);
        input.setStoreOpenCloseRequest(storeOpenCloseRequest);

        Mockito.when(facilityrepo.findByFacility("12345")).thenReturn(List.of(new fac_fmf()));

        SGPOSServices expectedResponse = new SGPOSServices();
        Mockito.when(buildErrorResponseUtil.buildErrorResponseAdd(Mockito.any(), Mockito.eq("STORE_OPEN_SUCCESS")))
                .thenReturn(expectedResponse);

        // Act
        SGPOSServices result = sgposServicesservice.Response(input);

        // Assert
        Assertions.assertTrue(true);
        // Mockito.verify(buildErrorResponseUtil).buildErrorResponseAdd(Mockito.any(), Mockito.eq("STORE_OPEN_SUCCESS"));
    }

//@Test
//@DisplayName("Should handle IDCheckRequest with valid CustomerType")
//void testIdCheckRequestValidCustomerType() throws Exception {
//    // Arrange
//    SGPOSServices input = new SGPOSServices();
//    Header header = new Header();
//    header.setFacilityNumber("12345");
//    header.setLocalDateTime("230505230102");
//    input.setHeader(header);
//
//    IDCheckRequest idCheckRequest = new IDCheckRequest();
//    idCheckRequest.setCustomerType(com.aafes.sgpos.sgposservices.generated.Control.IDCheckRequest.CustomerType.EDIPI);
//    idCheckRequest.setCustomerID("123456789");
//    input.setIDCheckRequest(idCheckRequest);
//
//    Mockito.when(facilityrepo.findByFacility("12345")).thenReturn(List.of(new fac_fmf()));
//    Mockito.when(ccdVerIDCHECK.CCDCall(Mockito.any())).thenReturn(new JSONObject());
//
//    // Act
//    SGPOSServices result = sgposServicesservice.Response(input);
//
//    // Assert
//    Assertions.assertTrue(true);
//    Mockito.verify(ccdVerIDCHECK).CCDCall(Mockito.any());
//}

    @Test
    @DisplayName("Should return error response when Facility is not found")
    void testFacilityNotFound() throws Exception {
        // Arrange
        SGPOSServices input = new SGPOSServices();
        Header header = new Header();
        header.setFacilityNumber("12345");
        header.setLocalDateTime("230505230102");
        input.setHeader(header);

        Mockito.when(facilityrepo.findByFacility("12345")).thenReturn(Collections.emptyList());

        SGPOSServices errorResponse = new SGPOSServices();
        Mockito.when(buildErrorResponseUtil.buildErrorResponseAdd(Mockito.any(), Mockito.eq("FACILITY_NOT_FOUND")))
                .thenReturn(errorResponse);

        // Act
        SGPOSServices result = sgposServicesservice.Response(input);

        // Assert
        Assertions.assertEquals(errorResponse, result);
        Mockito.verify(buildErrorResponseUtil).buildErrorResponseAdd(Mockito.any(), Mockito.eq("FACILITY_NOT_FOUND"));
    }

    @Test
    @DisplayName("Should handle IDCheckRequest with valid CustomerType EDIPI")
    void testIdCheckRequestValidCustomerTypeEDIPI() throws Exception {
        // Arrange
        SGPOSServices input = new SGPOSServices();
        Header header = new Header();
        header.setFacilityNumber("12345");
        header.setLocalDateTime("230505230102");
        input.setHeader(header);

        IDCheckRequest idCheckRequest = new IDCheckRequest();
        idCheckRequest.setCustomerType(com.aafes.sgpos.sgposservices.generated.Control.IDCheckRequest.CustomerType.EDIPI);
        idCheckRequest.setCustomerID("123456789");
        input.setIDCheckRequest(idCheckRequest);

        Mockito.when(facilityrepo.findByFacility("12345")).thenReturn(List.of(new fac_fmf()));
        JSONObject ccdRes = new JSONObject();
        ccdRes.put("reasonCode", "00");
        Mockito.when(ccdVerIDCHECK.CCDCall(Mockito.any())).thenReturn(ccdRes);

        // Set the private field reasonCodeIDCHECK using reflection
        Field field = sgposServicesservice.getClass().getDeclaredField("reasonCodeIDCHECK");
        field.setAccessible(true);
        field.set(sgposServicesservice, "src/main/resources/json/idcheckResponse.json"); // or any valid test path

        // Act
        SGPOSServices result = sgposServicesservice.Response(input);

        // Assert
        Assertions.assertNotNull(result);
        Mockito.verify(ccdVerIDCHECK).CCDCall(Mockito.any());
    }

    @Test
    @DisplayName("Should return error response for IDCheckRequest with invalid CustomerType")
    void testIdCheckRequestInvalidCustomerType() throws Exception {
        // Arrange
        SGPOSServices input = new SGPOSServices();
        Header header = new Header();
        header.setFacilityNumber("12345");
        header.setLocalDateTime("230505230102");
        input.setHeader(header);

        IDCheckRequest idCheckRequest = new IDCheckRequest();
        idCheckRequest.setCustomerType(null); // Invalid type
        idCheckRequest.setCustomerID("123456789");
        input.setIDCheckRequest(idCheckRequest);

        Mockito.when(facilityrepo.findByFacility("12345")).thenReturn(List.of(new fac_fmf()));
        Mockito.when(buildErrorResponseUtil.buildErrorResponseAdd(Mockito.any(), Mockito.eq("INVALID_REQUEST")))
                .thenReturn(input);

        // Act
        SGPOSServices result = sgposServicesservice.Response(input);

        // Assert
        Assertions.assertNotNull(result);
        Mockito.verify(buildErrorResponseUtil).buildErrorResponseAdd(Mockito.any(), Mockito.eq("INVALID_REQUEST"));
    }

    @Test
    @DisplayName("Should return SOA_TIME_OUT for IDCheckRequest when CCDCall throws GatewayException")
    void testIdCheckRequestCCDCallTimeout() throws Exception {
        // Arrange
        SGPOSServices input = new SGPOSServices();
        Header header = new Header();
        header.setFacilityNumber("12345");
        header.setLocalDateTime("230505230102");
        input.setHeader(header);

        IDCheckRequest idCheckRequest = new IDCheckRequest();
        idCheckRequest.setCustomerType(com.aafes.sgpos.sgposservices.generated.Control.IDCheckRequest.CustomerType.EDIPI);
        idCheckRequest.setCustomerID("123456789");
        input.setIDCheckRequest(idCheckRequest);

        Mockito.when(facilityrepo.findByFacility("12345")).thenReturn(List.of(new fac_fmf()));
        Mockito.when(ccdVerIDCHECK.CCDCall(Mockito.any())).thenThrow(new GatewayException("Timeout"));
        Mockito.when(buildErrorResponseUtil.buildErrorResponseAdd(Mockito.any(), Mockito.eq("SOA_TIME_OUT")))
                .thenReturn(input);

        // Act
        SGPOSServices result = sgposServicesservice.Response(input);

        // Assert
        Assertions.assertNotNull(result);
        Mockito.verify(buildErrorResponseUtil).buildErrorResponseAdd(Mockito.any(), Mockito.eq("SOA_TIME_OUT"));
    }

    @Test
    @DisplayName("Should handle StoreOpenCloseRequest with STORECLOSE type")
    void testStoreOpenCloseRequestStoreClose() throws Exception {
        // Arrange
        SGPOSServices input = new SGPOSServices();
        Header header = new Header();
        header.setFacilityNumber("12345");
        header.setLocalDateTime("230505230102");
        input.setHeader(header);

        StoreOpenCloseRequest storeCloseRequest = new StoreOpenCloseRequest();
        storeCloseRequest.setRequestType(SGPOSRequestType.STORECLOSE);
        input.setStoreOpenCloseRequest(storeCloseRequest);

        // Mock facility lookup
        Mockito.when(facilityrepo.findByFacility("12345"))
                .thenReturn(List.of(new fac_fmf()));

        // Mock resa booking
        Mockito.doNothing().when(resaGatewayBean).bookToResa(Mockito.any());

        // Mock error response to avoid null return
        Mockito.when(buildErrorResponseUtil.buildErrorResponseAdd(Mockito.any(), Mockito.anyString()))
                .thenReturn(new SGPOSServices());

        // Act
        SGPOSServices result = sgposServicesservice.Response(input);

        // Assert
        Assertions.assertNotNull(result);
        Mockito.verify(resaGatewayBean).bookToResa(Mockito.any());
        Mockito.verify(buildErrorResponseUtil).buildErrorResponseAdd(Mockito.any(), Mockito.eq("SOC_TIME_OUT"));
    }

    @Test
    @DisplayName("Should handle ORISRequest with FINALAUTH type")
    void testOrisRequestFinalAuth() throws Exception {
        // Arrange
        SGPOSServices input = new SGPOSServices();
        Header header = new Header();
        header.setFacilityNumber("12345");
        header.setLocalDateTime("230505230102");
        input.setHeader(header);

        ORISRequest orisRequest = new ORISRequest();
        orisRequest.setRequestType(SGPOSRequestType.FINALAUTH);
        input.setORISRequest(orisRequest);

        // Mock facility
        Mockito.when(facilityrepo.findByFacility("12345")).thenReturn(List.of(new fac_fmf()));
        Mockito.when(orisValidation.emptyCheck(Mockito.any())).thenReturn(input);

        // Mock nested response
        ServerAccessProperties serverAccessProperties = Mockito.mock(ServerAccessProperties.class);
        Mockito.when(serverAccessProperties.getStatus()).thenReturn("OK");

        ConnectToWalkerResponse walkerResponse = Mockito.mock(ConnectToWalkerResponse.class);
        Mockito.when(walkerResponse.getConnectToWalkerResult()).thenReturn(serverAccessProperties);
        Mockito.when(OrisVerification.login(Mockito.any())).thenReturn(walkerResponse);

        // Mock error response fallback
        Mockito.when(buildErrorResponseUtil.buildErrorResponseAdd(Mockito.any(), Mockito.anyString()))
                .thenReturn(new SGPOSServices());

        // Act
        SGPOSServices result = sgposServicesservice.Response(input);

        // Assert
        Assertions.assertNotNull(result);
        Mockito.verify(OrisVerification).login(Mockito.any());
    }

    @Test
    @DisplayName("Should handle CVSRequest with valid SSN")
    void testCvsRequestWithValidSSN() throws Exception {
        // Arrange
        SGPOSServices input = new SGPOSServices();
        Header header = new Header();
        header.setFacilityNumber("12345");
        header.setLocalDateTime("230505230102");
        input.setHeader(header);

        CVSRequest cvsRequest = new CVSRequest();
        cvsRequest.setCustomerType(CVSRequest.CustomerType.SSN);
        cvsRequest.setCustomerID("123456789");
        cvsRequest.setRequestType(CVSRequest.RequestType.INQUIRY);
        cvsRequest.setCashbackRequestedAmount("50");
        input.setCVSRequest(cvsRequest);

        Mockito.when(facilityrepo.findByFacility("12345")).thenReturn(List.of(new fac_fmf()));
        Mockito.when(ccdVerCVS.CCDCall(Mockito.any())).thenReturn(new JSONObject());
        Mockito.when(buildErrorResponseUtil.buildErrorResponseAdd(Mockito.any(), Mockito.anyString()))
                .thenReturn(new SGPOSServices());

        // Act
        SGPOSServices result = sgposServicesservice.Response(input);

        // Assert
        Assertions.assertNotNull(result);
        Mockito.verify(ccdVerCVS).CCDCall(Mockito.any());
    }

    @Test
    @DisplayName("Should handle IGLASRequest with valid data")
    void testIglasRequestValid() throws Exception {
        // Arrange
        SGPOSServices input = new SGPOSServices();
        Header header = new Header();
        header.setFacilityNumber("12345");
        header.setLocalDateTime("230505230102");

        // Mock InputType
        Header.InputType inputType = Mockito.mock(Header.InputType.class);
        Mockito.when(inputType.toString()).thenReturn("P");
        header.setInputType(inputType);
        input.setHeader(header);

        IGLASRequest iglasRequest = new IGLASRequest();
        iglasRequest.setCbn("CBN123");
        iglasRequest.setFunctionCode("F");
        iglasRequest.setCashierNumber("123");
        iglasRequest.setAmount("100");
        iglasRequest.setTranCode("MC2");
        iglasRequest.setEtx("ETX");

        iglasRequest.setSsn("123456789");

        input.setIGLASRequest(iglasRequest);

        Mockito.when(facilityrepo.findByFacility("12345")).thenReturn(List.of(new fac_fmf()));
        Mockito.when(ccdVerIGLAS.CCDCall(Mockito.any())).thenReturn(new JSONObject());
        Mockito.when(buildErrorResponseUtil.buildErrorResponseAdd(Mockito.any(), Mockito.anyString()))
                .thenAnswer(invocation -> invocation.getArgument(0));

        // Act
        SGPOSServices result = sgposServicesservice.Response(input);

        // Assert
        Assertions.assertNotNull(result);
        Mockito.verify(ccdVerIGLAS).CCDCall(Mockito.any());
    }

    @Test
    @DisplayName("Should return true for valid business date format")
    void testTryParseBusinessDateValid() {
        boolean result = sgposServicesservice.tryParseBusinessDate("300725123456");
        Assertions.assertTrue(result);
    }

    @Test
    @DisplayName("Should return false for invalid business date format")
    void testTryParseBusinessDateInvalid() {
        boolean result = sgposServicesservice.tryParseBusinessDate("invalidDate");
        Assertions.assertFalse(result);
    }

    @Test
    @DisplayName("Should populate response correctly for PREAUTH")
    void testPosResponsePreAuth() throws Exception {
        SGPOSServices input = new SGPOSServices();
        Header header = new Header();
        header.setFacilityNumber("12345");
        input.setHeader(header);

        ORISRequest orisRequest = new ORISRequest();
        orisRequest.setRequestType(SGPOSRequestType.PREAUTH);
        orisRequest.setBusinessDate("300725123456");
        orisRequest.setCashierID("C123");
        orisRequest.setCustomerID("987654321");
        orisRequest.setAmount("100");
        input.setORISRequest(orisRequest);

        fac_fmf facility = new fac_fmf();
        facility.setFAC_NUM10("12345");
        facility.setFAC_MGR("John Doe");
        facility.setPHONE_NUM("555-1234");

        List<fac_fmf> facilities = List.of(facility);

        SGPOSServices result = sgposServicesservice.posResponse(input, facilities, "Jane Doe", "Y", null);

        Assertions.assertNotNull(result.getResponse());
        Assertions.assertEquals("Jane Doe", result.getResponse().getCustomerName());
        Assertions.assertEquals("Y", result.getResponse().getSplitTenderInd());
    }

    @Test
    @DisplayName("Should return INVALID_REQUEST when unexpected exception occurs in IGLAS flow")
    void testIglasInvalidDataException() throws Exception {
        // Arrange
        SGPOSServices input = new SGPOSServices();
        Header header = new Header();
        header.setFacilityNumber("12345");
        header.setLocalDateTime("300725123456");

        // Mock InputType to avoid NullPointerException
        Header.InputType inputType = Mockito.mock(Header.InputType.class);
        Mockito.when(inputType.toString()).thenReturn("P");
        header.setInputType(inputType);

        input.setHeader(header);

        IGLASRequest iglasRequest = new IGLASRequest();
        iglasRequest.setCbn("CBN123");
        iglasRequest.setFunctionCode("F");
        iglasRequest.setCashierNumber("123");
        iglasRequest.setAmount("100");
        iglasRequest.setTranCode("MC2");
        iglasRequest.setEtx("ETX");
        iglasRequest.setSsn("123456789");
        iglasRequest.setExpiryDate("1231");
        iglasRequest.setAccount("1234567890123456");
        iglasRequest.setTransF1("F1");
        iglasRequest.setAuthLevel("1");
        iglasRequest.setAuthKey("2");
        iglasRequest.setAuthSupervisor("3");
        iglasRequest.setReasonCode("RC");
        iglasRequest.setReasonDescription("Test Reason");
        iglasRequest.setLen("00");
        // Optional: Set SSNIdentifier and RecordSeperator3 to avoid validation failure
        iglasRequest.setSSNIdentifier("S");
        iglasRequest.setRecordSeperator3("|");

        input.setIGLASRequest(iglasRequest);

        Mockito.when(facilityrepo.findByFacility("12345")).thenReturn(List.of(new fac_fmf()));
        Mockito.when(ccdVerIGLAS.CCDCall(Mockito.any())).thenThrow(new RuntimeException("Unexpected error"));
        Mockito.when(buildErrorResponseUtil.buildErrorResponseAdd(Mockito.any(), Mockito.eq("INVALID_REQUEST")))
                .thenReturn(input);

        // Act
        SGPOSServices result = sgposServicesservice.Response(input);

        // Assert
        Assertions.assertNotNull(result);
        Mockito.verify(buildErrorResponseUtil, Mockito.atLeastOnce())
                .buildErrorResponseAdd(Mockito.any(), Mockito.eq("INVALID_REQUEST"));
    }

    @Test
    @DisplayName("Should populate response correctly for FINALAUTH")
    void testPosResponseFinalAuth() throws Exception {
        SGPOSServices input = new SGPOSServices();
        Header header = new Header();
        header.setFacilityNumber("12345");
        input.setHeader(header);

        ORISRequest orisRequest = new ORISRequest();
        orisRequest.setRequestType(SGPOSRequestType.FINALAUTH);
        input.setORISRequest(orisRequest);

        fac_fmf facility = new fac_fmf();
        facility.setFAC_NUM10("12345");
        facility.setFAC_MGR("John Doe");
        facility.setPHONE_NUM("555-1234");

        List<fac_fmf> facilities = List.of(facility);

        SGPOSServices result = sgposServicesservice.posResponse(input, facilities, null, null, "INV123");

        Assertions.assertNotNull(result.getResponse());
        Assertions.assertEquals("INV123", result.getResponse().getInvoiceNumber());
    }

    @Test
    @DisplayName("Should handle ORIS soap error and return error response when ApplyTXNResult status is not OK")
    void testApplyTxnSoapErrorHandledWithStoreCloseRequest() throws Exception {
        // Arrange
        SGPOSServices input = new SGPOSServices();
        Header header = new Header();
        header.setFacilityNumber("12345");
        header.setLocalDateTime("300725123456");
        input.setHeader(header);

        StoreOpenCloseRequest storeCloseRequest = new StoreOpenCloseRequest();
        storeCloseRequest.setRequestType(SGPOSRequestType.STORECLOSE);
        input.setStoreOpenCloseRequest(storeCloseRequest);

        // Mock facility found
        Mockito.when(facilityrepo.findByFacility("12345")).thenReturn(List.of(new fac_fmf()));

        // Mock OrisVerification.login
        ConnectToWalkerResponse walkerResponse = Mockito.mock(ConnectToWalkerResponse.class);
        ServerAccessProperties loginResult = Mockito.mock(ServerAccessProperties.class);
        Mockito.when(loginResult.getStatus()).thenReturn("OK");
        Mockito.when(walkerResponse.getConnectToWalkerResult()).thenReturn(loginResult);
        Mockito.when(OrisVerification.login(Mockito.any())).thenReturn(walkerResponse);

        // Mock ApplyTXNResponse
        ApplyTXNResponse applyTXNResponse = new ApplyTXNResponse();
        ServerAccessProperties txnResult = Mockito.mock(ServerAccessProperties.class);
        Mockito.when(txnResult.getStatus()).thenReturn("FAIL");

        // ➤ Provide mocked HTML response that matches expected structure
        String htmlMock = "prefixjavascript:wfErrMsgmiddlejavascript:wfErrMsgerror>Must Be<suffix\"javascript:wfErrHelpignore'P123'";
        Mockito.when(txnResult.getEncodedHtmlResponse()).thenReturn(htmlMock.getBytes());
        applyTXNResponse.setApplyTXNResult(txnResult);
        Mockito.when(OrisVerification.applyTXN(Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(applyTXNResponse);

        // Mock buildErrorResponseUtil.buildErrorResponseOris
        SGPOSServices expectedResponse = new SGPOSServices();
        Mockito.when(buildErrorResponseUtil.buildErrorResponseOris(Mockito.any(), Mockito.eq("Must Be > 0"), Mockito.eq("P123")))
                .thenReturn(expectedResponse);

        // Act
        SGPOSServices result = sgposServicesservice.Response(input);

        // Assert
        Assertions.assertEquals(expectedResponse, result);
        Mockito.verify(buildErrorResponseUtil).buildErrorResponseOris(Mockito.any(), Mockito.eq("Must Be > 0"), Mockito.eq("P123"));
    }

   }