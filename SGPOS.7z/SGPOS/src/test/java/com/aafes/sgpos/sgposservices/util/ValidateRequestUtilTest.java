package com.aafes.sgpos.sgposservices.util;
import com.aafes.sgpos.sgposservices.generated.Control.CVSRequest;
import com.aafes.sgpos.sgposservices.generated.Control.IGLASRequest;
import com.aafes.sgpos.sgposservices.generated.Control.ORISRequest;
import com.aafes.sgpos.sgposservices.generated.Control.SGPOSServices;
import com.aafes.sgpos.sgposservices.generated.Control.StoreOpenCloseRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.text.ParseException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ValidateRequestUtilTest {

    private ValidateRequestUtil util;

    @BeforeEach
    void setup() {
        util = new ValidateRequestUtil();
    }

    @Test
    void testValidCVSRequestWithSSN() throws ParseException {
        CVSRequest cvsRequest = mock(CVSRequest.class);
        when(cvsRequest.getCustomerType()).thenReturn(CVSRequest.CustomerType.SSN);
        when(cvsRequest.getCustomerID()).thenReturn("123456789");
        when(cvsRequest.getCashbackRequestedAmount()).thenReturn("100");

        SGPOSServices request = mock(SGPOSServices.class);
        when(request.getCVSRequest()).thenReturn(cvsRequest);

        String result = util.validateFieldsAdd(request);
        assertEquals("", result);
    }

    @Test
    void testInvalidCVSRequestWithNonNumericSSN() throws ParseException {
        CVSRequest cvsRequest = mock(CVSRequest.class);
        when(cvsRequest.getCustomerType()).thenReturn(CVSRequest.CustomerType.SSN);
        when(cvsRequest.getCustomerID()).thenReturn("ABC123XYZ");

        SGPOSServices request = mock(SGPOSServices.class);
        when(request.getCVSRequest()).thenReturn(cvsRequest);

        String result = util.validateFieldsAdd(request);
        assertEquals("INVALID_REQUEST", result);
    }

    @Test
    void testValidIGLASRequestWithNumericSSN() throws ParseException {
        IGLASRequest iglasRequest = mock(IGLASRequest.class);
        when(iglasRequest.getSsn()).thenReturn("987654321");

        SGPOSServices request = mock(SGPOSServices.class);
        when(request.getCVSRequest()).thenReturn(null);
        when(request.getIGLASRequest()).thenReturn(iglasRequest);

        String result = util.validateFieldsAdd(request);
        assertEquals("", result);
    }

    @Test
    void testInvalidIGLASRequestWithNonNumericSSN() throws ParseException {
        IGLASRequest iglasRequest = mock(IGLASRequest.class);
        when(iglasRequest.getSsn()).thenReturn("SSN-INVALID");

        SGPOSServices request = mock(SGPOSServices.class);
        when(request.getCVSRequest()).thenReturn(null);
        when(request.getIGLASRequest()).thenReturn(iglasRequest);

        String result = util.validateFieldsAdd(request);
        assertEquals("INVALID_REQUEST", result);
    }

    @Test
    void testORISRequestPresent() throws ParseException {
        ORISRequest orisRequest = mock(ORISRequest.class);
        when(orisRequest.getRequestType()).thenReturn("INQUIRY");

        SGPOSServices request = mock(SGPOSServices.class);
        when(request.getCVSRequest()).thenReturn(null);
        when(request.getIGLASRequest()).thenReturn(null);
        when(request.getORISRequest()).thenReturn(orisRequest);

        String result = util.validateFieldsAdd(request);
        assertEquals("", result);
    }

    @Test
    void testStoreOpenCloseRequestPresent() throws ParseException {
        StoreOpenCloseRequest storeRequest = mock(StoreOpenCloseRequest.class);
        when(storeRequest.getRequestType()).thenReturn("OPEN");

        SGPOSServices request = mock(SGPOSServices.class);
        when(request.getCVSRequest()).thenReturn(null);
        when(request.getIGLASRequest()).thenReturn(null);
        when(request.getORISRequest()).thenReturn(null);
        when(request.getStoreOpenCloseRequest()).thenReturn(storeRequest);

        String result = util.validateFieldsAdd(request);
        assertEquals("", result);
    }

    @Test
    void testEmptyRequest() throws ParseException {
        SGPOSServices request = mock(SGPOSServices.class);
        when(request.getCVSRequest()).thenReturn(null);
        when(request.getIGLASRequest()).thenReturn(null);
        when(request.getORISRequest()).thenReturn(null);
        when(request.getStoreOpenCloseRequest()).thenReturn(null);

        String result = util.validateFieldsAdd(request);
        assertEquals("", result);
    }
}
