/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aafes.sgpos.sgposservices.walkerinterfaceTest;
import com.aafes.sgpos.sgposservices.walkerinterface.WalkerInterfaceSoap;
import com.aafes.sgpos.sgposservices.walkerinterface.ServerAccessProperties;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 *
 * @author bhendarkart
 */
public class WalkerInterfaceSoapTest {
    @Test
    void testConnectToWalker() {
        WalkerInterfaceSoap walker = Mockito.mock(WalkerInterfaceSoap.class);
        ServerAccessProperties expected = new ServerAccessProperties();
        expected.setToken("mockToken");

        Mockito.when(walker.connectToWalker("mockUrl", "mockUser", "mockPass")).thenReturn(expected);

        ServerAccessProperties result = walker.connectToWalker("mockUrl", "mockUser", "mockPass");

        assertEquals("mockToken", result.getToken());
    }

    @Test
    void testApplyTXN() {
        WalkerInterfaceSoap walker = Mockito.mock(WalkerInterfaceSoap.class);
        ServerAccessProperties expected = new ServerAccessProperties();
        expected.setStatus("Success");

        String postData = "Sample Data";
        byte[] encodedHtml = "<html><body>Mock HTML</body></html>".getBytes(StandardCharsets.UTF_8);

        Mockito.when(walker.applyTXN(postData, encodedHtml, "mockUrl", "mockCC", "mockTxn", "mockEntity"))
                .thenReturn(expected);

        ServerAccessProperties result = walker.applyTXN(postData, encodedHtml, "mockUrl", "mockCC", "mockTxn", "mockEntity");

        assertEquals("Success", result.getStatus());
    }

    @Test
    void testLogOffWalker() {
        WalkerInterfaceSoap walker = Mockito.mock(WalkerInterfaceSoap.class);
        ServerAccessProperties expected = new ServerAccessProperties();
        expected.setStatus("Logged Off");

        Mockito.when(walker.logOffWalker("mockToken", "mockUrl")).thenReturn(expected);

        ServerAccessProperties result = walker.logOffWalker("mockToken", "mockUrl");

        assertEquals("Logged Off", result.getStatus());
    }
}
