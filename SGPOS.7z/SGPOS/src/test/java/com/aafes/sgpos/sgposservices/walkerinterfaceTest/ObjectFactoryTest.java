package com.aafes.sgpos.sgposservices.walkerinterfaceTest;
import com.aafes.sgpos.sgposservices.walkerinterface.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ObjectFactoryTest {


    ObjectFactory factory = new ObjectFactory();

    @Test
    void testCreateApplyTXN() {
        ApplyTXN txn = factory.createApplyTXN();
        assertNotNull(txn);
    }

    @Test
    void testCreateApplyTXNResponse() {
        ApplyTXNResponse response = factory.createApplyTXNResponse();
        assertNotNull(response);
    }

    @Test
    void testCreateServerAccessProperties() {
        ServerAccessProperties props = factory.createServerAccessProperties();
        assertNotNull(props);
    }

    @Test
    void testCreateLogOffWalker() {
        LogOffWalker logoff = factory.createLogOffWalker();
        assertNotNull(logoff);
    }

    @Test
    void testCreateLogOffWalkerResponse() {
        LogOffWalkerResponse response = factory.createLogOffWalkerResponse();
        assertNotNull(response);
    }

    @Test
    void testCreateConnectToWalker() {
        ConnectToWalker connect = factory.createConnectToWalker();
        assertNotNull(connect);
    }

    @Test
    void testCreateConnectToWalkerResponse() {
        ConnectToWalkerResponse response = factory.createConnectToWalkerResponse();
        assertNotNull(response);
    }

    @Test
    void testCreateArrayOfAnyType() {
        ArrayOfAnyType array = factory.createArrayOfAnyType();
        assertNotNull(array);
        assertTrue(array.getAnyType().isEmpty());
    }
}
