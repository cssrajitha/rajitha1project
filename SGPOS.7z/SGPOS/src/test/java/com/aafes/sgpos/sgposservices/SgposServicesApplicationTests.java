package com.aafes.sgpos.sgposservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = {SgposServicesApplicationTests.class})
class SgposServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
