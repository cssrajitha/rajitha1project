/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aafes.sgpos.sgposservices.config;

import com.aafes.sgpos.sgposservices.Config.EncryptorConfig;
import com.aafes.sgpos.sgposservices.Config.KeystoreInit;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.autoconfigure.web.ServerProperties;
import org.springframework.boot.web.server.Ssl;
import org.springframework.core.env.Environment;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 *
 * @author bhendarkart
 */
public class KeystoreInitTest {

    private KeystoreInit keystoreInit;
    private EncryptorConfig mockEncryptor;
    private Environment mockEnvironment;

    @BeforeEach
    void setUp() {
        mockEnvironment = mock(Environment.class);
        keystoreInit = new KeystoreInit(mockEnvironment);

        mockEncryptor = mock(EncryptorConfig.class);
        ReflectionTestUtils.setField(keystoreInit, "encryptorConfig", mockEncryptor);
        ReflectionTestUtils.setField(keystoreInit, "keystorePass", "encryptedPass");

        when(mockEncryptor.decrypt("encryptedPass")).thenReturn("decryptedPass");
    }

    @Test
    void testGetKeystorePassword_successfulDecryption() {
        String result = ReflectionTestUtils.invokeMethod(keystoreInit, "getKeystorePassword");
        assertEquals("decryptedPass", result);
    }

    @Test
    void testGetKeystorePassword_decryptionFailsGracefully() {
        when(mockEncryptor.decrypt("encryptedPass")).thenThrow(new RuntimeException("decryption error"));

        String result = ReflectionTestUtils.invokeMethod(keystoreInit, "getKeystorePassword");
        assertEquals("encryptedPass", result); // fallback to original
    }

    @Test
    void testServerPropertiesBeanSetup() {
        ServerProperties serverProperties = keystoreInit.serverProperties();
        assertNotNull(serverProperties);

        Ssl ssl = serverProperties.getSsl();
        assertNotNull(ssl);
        assertEquals("decryptedPass", ssl.getKeyPassword());

        // Also check system property override
        assertEquals("decryptedPass", System.getProperty("server.ssl.key-store-password"));
    }
}
