/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aafes.sgpos.sgposservices.Gateway;

import com.aafes.sgpos.sgposservices.Config.EncryptorConfig;
import com.aafes.sgpos.sgposservices.Control.customerType;
import com.aafes.sgpos.sgposservices.generated.Control.CVSRequest;
import com.aafes.sgpos.sgposservices.generated.Control.Header;
import com.aafes.sgpos.sgposservices.generated.Control.SGPOSServices;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.lang.reflect.Field;
//import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.*;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.web.client.RestTemplate;
//import org.json.simple.JSONObject;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import org.mockito.Spy;
import org.springframework.test.util.ReflectionTestUtils;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
 
import java.util.Map;
 
import org.json.simple.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
 
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedConstruction;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.*;
 
import org.springframework.test.util.ReflectionTestUtils;
 
/**
 *
 * @author bhendarkart
 */
@ExtendWith(MockitoExtension.class)
public class TestCcdVerificationCVS {

    @Mock
    private EncryptorConfig encryptorConfig;

    @Mock
    private SGPOSServices sgposservices;

    @Mock
    private CVSRequest cvsRequest;

    @Test
    void testCcdCallSuccessWithSSN() throws Exception {
        ccdVerificationCVS service = new ccdVerificationCVS();

        // Inject config fields
        ReflectionTestUtils.setField(service, "CCDURL", "http://dummy-url");
        ReflectionTestUtils.setField(service, "CCDClientID", "dummy-client-id");
        ReflectionTestUtils.setField(service, "CCDUserName", "dummy-user");
        ReflectionTestUtils.setField(service, "CCDPassword", "dummy-pass");
        ReflectionTestUtils.setField(service, "encryptorConfig", encryptorConfig);
        ReflectionTestUtils.setField(service, "ccdCallTimeout", "2000");
        ReflectionTestUtils.setField(service, "ccdCallReadTimeout", "2000");

        // Mock inputs
        when(sgposservices.getCVSRequest()).thenReturn(cvsRequest);
        when(cvsRequest.getCustomerType()).thenReturn(CVSRequest.CustomerType.SSN);  // Must match service condition
        when(cvsRequest.getCustomerID()).thenReturn("123456");
        when(encryptorConfig.decrypt(anyString())).thenReturn("decrypted-pass");

        // Build CCD response
        Map<String, Object> responseBody = new HashMap<>();
        responseBody.put("respStatus", "000");
        responseBody.put("Customer", Map.of("SSN", "123456"));

        ResponseEntity<Object> mockResponse = new ResponseEntity<>(responseBody, HttpStatus.OK);

        // Simulate RestTemplate with mocked exchange
        try (MockedConstruction<RestTemplate> mocked = mockConstruction(RestTemplate.class,
                (mockRestTemplate, context) -> {
                    when(mockRestTemplate.exchange(
                            anyString(),
                            eq(HttpMethod.POST),
                            any(HttpEntity.class),
                            eq(Object.class)
                    )).thenReturn(mockResponse);
                })) {

            // Call actual method
            JSONObject result = service.CCDCall(sgposservices);

            // Assertions
            assertNotNull(result);
            assertTrue((Boolean) result.get("ccdCall"));
            assertNull(result.get("ssn"));
             
        }
    }
   
@Test
void testCcdCallWithResponse100() throws Exception {
    ccdVerificationCVS service = new ccdVerificationCVS();

    // Inject fields
    ReflectionTestUtils.setField(service, "CCDURL", "http://dummy-url");
    ReflectionTestUtils.setField(service, "CCDClientID", "dummy-client-id");
    ReflectionTestUtils.setField(service, "CCDUserName", "dummy-user");
    ReflectionTestUtils.setField(service, "CCDPassword", "dummy-pass");
    ReflectionTestUtils.setField(service, "encryptorConfig", encryptorConfig);
    ReflectionTestUtils.setField(service, "ccdCallTimeout", "2000");
    ReflectionTestUtils.setField(service, "ccdCallReadTimeout", "2000");

    // Mock inputs
    when(sgposservices.getCVSRequest()).thenReturn(cvsRequest);
    when(cvsRequest.getCustomerType()).thenReturn(CVSRequest.CustomerType.SSN);  
    when(cvsRequest.getCustomerID()).thenReturn("123456");
    when(encryptorConfig.decrypt(anyString())).thenReturn("decrypted-pass");

    // CCD response
    Map<String, Object> responseBody = Map.of("respStatus", "100");
    ResponseEntity<Object> mockResponse = new ResponseEntity<>(responseBody, HttpStatus.OK);

    try (MockedConstruction<RestTemplate> mocked = mockConstruction(RestTemplate.class,
            (mockRestTemplate, context) -> {
                when(mockRestTemplate.exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(Object.class)))
                        .thenReturn(mockResponse);
            })) {

        JSONObject result = service.CCDCall(sgposservices);

        assertNotNull(result);
        assertTrue((Boolean) result.get("ccdCall"));  // SSN returns true
        assertEquals("100", result.get("reasonCode"));
        assertNull(result.get("ssn"));
    }
}
@Test
void testCcdCallWithFallbackResponse902() throws Exception {
    ccdVerificationCVS service = new ccdVerificationCVS();

    // Inject fields
    ReflectionTestUtils.setField(service, "CCDURL", "http://dummy-url");
    ReflectionTestUtils.setField(service, "CCDClientID", "dummy-client-id");
    ReflectionTestUtils.setField(service, "CCDUserName", "dummy-user");
    ReflectionTestUtils.setField(service, "CCDPassword", "dummy-pass");
    ReflectionTestUtils.setField(service, "encryptorConfig", encryptorConfig);
    ReflectionTestUtils.setField(service, "ccdCallTimeout", "2000");
    ReflectionTestUtils.setField(service, "ccdCallReadTimeout", "2000");

    // Mock inputs
    when(sgposservices.getCVSRequest()).thenReturn(cvsRequest);
    when(cvsRequest.getCustomerType()).thenReturn(CVSRequest.CustomerType.EDIPI);
    when(cvsRequest.getCustomerID()).thenReturn("1122334455");
    when(encryptorConfig.decrypt(anyString())).thenReturn("decrypted-pass");

    // CCD response
    Map<String, Object> responseBody = Map.of("respStatus", "XYZ");  // unexpected code
    ResponseEntity<Object> mockResponse = new ResponseEntity<>(responseBody, HttpStatus.OK);

    try (MockedConstruction<RestTemplate> mocked = mockConstruction(RestTemplate.class,
            (mockRestTemplate, context) -> {
                when(mockRestTemplate.exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(Object.class)))
                        .thenReturn(mockResponse);
            })) {

        JSONObject result = service.CCDCall(sgposservices);

        assertNotNull(result);
        assertFalse((Boolean) result.get("ccdCall"));
        assertEquals("902", result.get("reasonCode"));  // Default fallback
    }
}
@Test
void testCcdCallWithResponse901() throws Exception {
    ccdVerificationCVS service = new ccdVerificationCVS();

    // Inject fields
    ReflectionTestUtils.setField(service, "CCDURL", "http://dummy-url");
    ReflectionTestUtils.setField(service, "CCDClientID", "dummy-client-id");
    ReflectionTestUtils.setField(service, "CCDUserName", "dummy-user");
    ReflectionTestUtils.setField(service, "CCDPassword", "dummy-pass");
    ReflectionTestUtils.setField(service, "encryptorConfig", encryptorConfig);
    ReflectionTestUtils.setField(service, "ccdCallTimeout", "2000");
    ReflectionTestUtils.setField(service, "ccdCallReadTimeout", "2000");

    // Mock inputs
    when(sgposservices.getCVSRequest()).thenReturn(cvsRequest);
    when(cvsRequest.getCustomerType()).thenReturn(CVSRequest.CustomerType.EDIPI);
    when(cvsRequest.getCustomerID()).thenReturn("7891011");
    when(encryptorConfig.decrypt(anyString())).thenReturn("decrypted-pass");

    // CCD response
    Map<String, Object> responseBody = Map.of("respStatus", "901");
    ResponseEntity<Object> mockResponse = new ResponseEntity<>(responseBody, HttpStatus.OK);

    try (MockedConstruction<RestTemplate> mocked = mockConstruction(RestTemplate.class,
            (mockRestTemplate, context) -> {
                when(mockRestTemplate.exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(Object.class)))
                        .thenReturn(mockResponse);
            })) {

        JSONObject result = service.CCDCall(sgposservices);

        assertNotNull(result);
        assertFalse((Boolean) result.get("ccdCall"));
        assertEquals("901", result.get("reasonCode"));
    }
}
@Test
void testCcdCallWithResponse101ForSSN() throws Exception {
    ccdVerificationCVS service = new ccdVerificationCVS();

    ReflectionTestUtils.setField(service, "CCDURL", "http://dummy-url");
    ReflectionTestUtils.setField(service, "CCDClientID", "dummy-client-id");
    ReflectionTestUtils.setField(service, "CCDUserName", "dummy-user");
    ReflectionTestUtils.setField(service, "CCDPassword", "dummy-pass");
    ReflectionTestUtils.setField(service, "encryptorConfig", encryptorConfig);
    ReflectionTestUtils.setField(service, "ccdCallTimeout", "2000");
    ReflectionTestUtils.setField(service, "ccdCallReadTimeout", "2000");

    when(sgposservices.getCVSRequest()).thenReturn(cvsRequest);
    when(cvsRequest.getCustomerType()).thenReturn(CVSRequest.CustomerType.SSN);
    when(cvsRequest.getCustomerID()).thenReturn("123456");
    when(encryptorConfig.decrypt(anyString())).thenReturn("decrypted-pass");

    Map<String, Object> responseBody = Map.of("respStatus", "101");

    ResponseEntity<Object> mockResponse = new ResponseEntity<>(responseBody, HttpStatus.OK);

    try (MockedConstruction<RestTemplate> mocked = mockConstruction(RestTemplate.class,
            (mockRestTemplate, context) -> {
                when(mockRestTemplate.exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(Object.class)))
                        .thenReturn(mockResponse);
            })) {

        JSONObject result = service.CCDCall(sgposservices);

        assertNotNull(result);
        assertTrue((Boolean) result.get("ccdCall"));
        assertEquals("101", result.get("reasonCode"));
        assertEquals("123456", result.get("ssn")); // echoed back for SSN type
    }
}
@Test
void testCcdCallWithResponse102() throws Exception {
    ccdVerificationCVS service = new ccdVerificationCVS();

    ReflectionTestUtils.setField(service, "CCDURL", "http://dummy-url");
    ReflectionTestUtils.setField(service, "CCDClientID", "dummy-client-id");
    ReflectionTestUtils.setField(service, "CCDUserName", "dummy-user");
    ReflectionTestUtils.setField(service, "CCDPassword", "dummy-pass");
    ReflectionTestUtils.setField(service, "encryptorConfig", encryptorConfig);
    ReflectionTestUtils.setField(service, "ccdCallTimeout", "2000");
    ReflectionTestUtils.setField(service, "ccdCallReadTimeout", "2000");

    when(sgposservices.getCVSRequest()).thenReturn(cvsRequest);
    when(cvsRequest.getCustomerType()).thenReturn(CVSRequest.CustomerType.EDIPI);
    when(cvsRequest.getCustomerID()).thenReturn("999111");
    when(encryptorConfig.decrypt(anyString())).thenReturn("decrypted-pass");

    Map<String, Object> responseBody = Map.of("respStatus", "102");

    ResponseEntity<Object> mockResponse = new ResponseEntity<>(responseBody, HttpStatus.OK);

    try (MockedConstruction<RestTemplate> mocked = mockConstruction(RestTemplate.class,
            (mockRestTemplate, context) -> {
                when(mockRestTemplate.exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(Object.class)))
                        .thenReturn(mockResponse);
            })) {

        JSONObject result = service.CCDCall(sgposservices);

        assertNotNull(result);
        assertFalse((Boolean) result.get("ccdCall"));
        assertEquals("102", result.get("reasonCode"));
    }
}

    @Test
    void testExtractSSNFromCustomerObject() throws Exception {
        ccdVerificationCVS service = new ccdVerificationCVS();

        // Inject fields
        ReflectionTestUtils.setField(service, "CCDURL", "http://dummy-url");
        ReflectionTestUtils.setField(service, "CCDClientID", "dummy-client-id");
        ReflectionTestUtils.setField(service, "CCDUserName", "dummy-user");
        ReflectionTestUtils.setField(service, "CCDPassword", "dummy-pass");
        ReflectionTestUtils.setField(service, "encryptorConfig", encryptorConfig);
        ReflectionTestUtils.setField(service, "ccdCallTimeout", "2000");
        ReflectionTestUtils.setField(service, "ccdCallReadTimeout", "2000");

        // Mock input data
        when(sgposservices.getCVSRequest()).thenReturn(cvsRequest);
        when(cvsRequest.getCustomerType()).thenReturn(CVSRequest.CustomerType.EDIPI); // must not be SSN to trigger those lines
        when(cvsRequest.getCustomerID()).thenReturn("9988776655");
        when(encryptorConfig.decrypt(anyString())).thenReturn("decrypted-pass");

        // CCD mock response with Customer object
        Map<String, Object> customerData = new HashMap<>();
        customerData.put("SSN", "123456789");

        Map<String, Object> responseBody = new HashMap<>();
        responseBody.put("respStatus", "000");
        responseBody.put("Customer", customerData);

        ResponseEntity<Object> mockResponse = new ResponseEntity<>(responseBody, HttpStatus.OK);

        try (MockedConstruction<RestTemplate> mocked = mockConstruction(RestTemplate.class,
                (mockRestTemplate, context) -> {
                    when(mockRestTemplate.exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(Object.class)))
                            .thenReturn(mockResponse);
                })) {

            JSONObject result = service.CCDCall(sgposservices);

            // Verify output
            assertNotNull(result);
            assertTrue((Boolean) result.get("ccdCall"));
            assertEquals("123456789", result.get("ssn"));
        }
    }
    @Test
    void testCcdCallFailureWithReasonCode() throws Exception {
        ccdVerificationCVS service = new ccdVerificationCVS();

        // Inject dependencies
        ReflectionTestUtils.setField(service, "CCDURL", "http://dummy-url");
        ReflectionTestUtils.setField(service, "CCDClientID", "dummy-client-id");
        ReflectionTestUtils.setField(service, "CCDUserName", "dummy-user");
        ReflectionTestUtils.setField(service, "CCDPassword", "dummy-pass");
        ReflectionTestUtils.setField(service, "encryptorConfig", encryptorConfig);
        ReflectionTestUtils.setField(service, "ccdCallTimeout", "2000");
        ReflectionTestUtils.setField(service, "ccdCallReadTimeout", "2000");

        // Mock request
        when(sgposservices.getCVSRequest()).thenReturn(cvsRequest);
        when(cvsRequest.getCustomerType()).thenReturn(CVSRequest.CustomerType.EDIPI);  // Not SSN
        when(cvsRequest.getCustomerID()).thenReturn("1122334455");
        when(encryptorConfig.decrypt(anyString())).thenReturn("decrypted-pass");

        // CCD failure response
        Map<String, Object> responseBody = Map.of("respStatus", "102");  // or use "901", "XYZ", etc.
        ResponseEntity<Object> mockResponse = new ResponseEntity<>(responseBody, HttpStatus.OK);

        try (MockedConstruction<RestTemplate> mocked = mockConstruction(RestTemplate.class,
                (mockRestTemplate, context) -> {
                    when(mockRestTemplate.exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(Object.class)))
                            .thenReturn(mockResponse);
                })) {

            // Execute the method
            JSONObject result = service.CCDCall(sgposservices);

            // Validate the response
            assertNotNull(result);
            assertFalse((Boolean) result.get("ccdCall"));             // Verification should fail
            assertEquals("102", result.get("reasonCode"));            // Captures failure reason
        }
    }
    @ParameterizedTest
    @ValueSource(strings = {"100", "101"})
    void testCcdCallHandlesStatus100And101(String respStatusCode) throws Exception {
        ccdVerificationCVS service = new ccdVerificationCVS();

        // Inject required dependencies
        ReflectionTestUtils.setField(service, "CCDURL", "http://dummy-url");
        ReflectionTestUtils.setField(service, "CCDClientID", "dummy-client-id");
        ReflectionTestUtils.setField(service, "CCDUserName", "dummy-user");
        ReflectionTestUtils.setField(service, "CCDPassword", "dummy-pass");
        ReflectionTestUtils.setField(service, "encryptorConfig", encryptorConfig);
        ReflectionTestUtils.setField(service, "ccdCallTimeout", "2000");
        ReflectionTestUtils.setField(service, "ccdCallReadTimeout", "2000");

        // Setup mocks
        when(sgposservices.getCVSRequest()).thenReturn(cvsRequest);
        when(cvsRequest.getCustomerType()).thenReturn(CVSRequest.CustomerType.EDIPI);
        when(cvsRequest.getCustomerID()).thenReturn("1122334455");
        when(encryptorConfig.decrypt(anyString())).thenReturn("decrypted-pass");

        // Simulated CCD response
        Map<String, Object> responseBody = Map.of("respStatus", respStatusCode);
        ResponseEntity<Object> mockResponse = new ResponseEntity<>(responseBody, HttpStatus.OK);

        try (MockedConstruction<RestTemplate> mocked = mockConstruction(RestTemplate.class,
                (mockRestTemplate, context) -> {
                    when(mockRestTemplate.exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(Object.class)))
                            .thenReturn(mockResponse);
                })) {

            // Run method
            JSONObject result = service.CCDCall(sgposservices);

            // Validate
            assertNotNull(result);
            assertFalse((Boolean) result.get("ccdCall"));             // Should be false for 100/101
            assertEquals(respStatusCode, result.get("reasonCode"));   // Should match input code
        }
    }


    }
