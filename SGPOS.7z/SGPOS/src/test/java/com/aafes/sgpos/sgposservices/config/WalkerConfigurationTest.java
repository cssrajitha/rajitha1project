/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aafes.sgpos.sgposservices.config;

/**
 *
 * @author bhendarkart
 */
import com.aafes.sgpos.sgposservices.Config.WalkerClient;
import com.aafes.sgpos.sgposservices.Config.WalkerConfiguration;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.ws.transport.http.HttpComponentsMessageSender;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Field;
import org.apache.http.client.HttpClient;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.impl.client.DefaultHttpClient;
import org.springframework.ws.transport.WebServiceMessageSender;
public class WalkerConfigurationTest {
    
    private WalkerConfiguration walkerConfiguration;

    @BeforeEach
    void setup() {
        walkerConfiguration = new WalkerConfiguration();

        // Inject mock values into @Value fields
        ReflectionTestUtils.setField(walkerConfiguration, "url", "http://mocked-url.com");
        ReflectionTestUtils.setField(walkerConfiguration, "orisCallTimeout", "3000");
        ReflectionTestUtils.setField(walkerConfiguration, "orisCallReadTimeout", "5000");
    }

    @Test
    void testMarshallerBean_shouldHaveCorrectContextPath() {
        Jaxb2Marshaller marshaller = walkerConfiguration.marshaller();

        assertNotNull(marshaller);
        assertEquals("com.aafes.sgpos.sgposservices.walkerinterface", marshaller.getContextPath());
    }
    @Test
    void testMarshaller_shouldHaveCorrectContextPath() {
        Jaxb2Marshaller marshaller = walkerConfiguration.marshaller();

        assertNotNull(marshaller);
        assertEquals("com.aafes.sgpos.sgposservices.walkerinterface", marshaller.getContextPath());
    }

    @Test
    void testWalkerClientBean_shouldBeConfiguredCorrectly() {
        // Create marshaller
        Jaxb2Marshaller marshaller = walkerConfiguration.marshaller();
        WalkerClient client = walkerConfiguration.walkerClient(marshaller);

        assertNotNull(client, "WalkerClient should not be null");
        assertEquals("http://mocked-url.com", client.getDefaultUri(), "Default URI mismatch");
        assertEquals(marshaller, client.getMarshaller());
        assertEquals(marshaller, client.getUnmarshaller());

        WebServiceMessageSender[] senders = client.getMessageSenders();
        assertNotNull(senders);
        assertTrue(senders.length > 0);

        HttpComponentsMessageSender sender = (HttpComponentsMessageSender) senders[0];
        assertNotNull(sender);
    }


}
