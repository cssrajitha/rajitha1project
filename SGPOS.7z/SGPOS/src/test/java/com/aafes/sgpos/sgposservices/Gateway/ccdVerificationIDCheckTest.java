package com.aafes.sgpos.sgposservices.Gateway;

import com.aafes.sgpos.sgposservices.Config.EncryptorConfig;
import com.aafes.sgpos.sgposservices.generated.Control.CVSRequest;
import com.aafes.sgpos.sgposservices.generated.Control.Header;
import com.aafes.sgpos.sgposservices.generated.Control.IDCheckRequest;
import com.aafes.sgpos.sgposservices.generated.Control.SGPOSServices;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.simple.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;

//@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = {ccdVerificationIDCheckTest.class})
public class ccdVerificationIDCheckTest {

    @Mock
    private ccdVerificationIDCHECK ccdVerificationIDCHECK;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private EncryptorConfig encryptorConfig;

    @Mock
    private SGPOSServices sgposServices;

    @Mock
    private ObjectMapper objectMapper;

    @Value("${ccd.CCDUserName}")
    private String CCDUserName = "testUser";
    @Value("${ccd.CCDPassword}")
    private String CCDPassword = "testPassword";
    @Value("${ccd.CCDClientID}")
    private String CCDClientID = "testClientID";
    @Value("${ccd.CCDURL:http://testccdurl.com}")
    public String CCDURL;
    @Value("${timeOut.ccdCallTimeout}")
    private String ccdCallTimeout = "5000";
    @Value("${timeOut.ccdCallReadTimeout}")
    private String ccdCallReadTimeout = "5000";

    private static final ObjectMapper mapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(ccdVerificationIDCHECK, "CCDUserName", "testUser");
        ReflectionTestUtils.setField(ccdVerificationIDCHECK, "CCDPassword", "testPass");
        ReflectionTestUtils.setField(ccdVerificationIDCHECK, "CCDClientID", "testClientID");
        ReflectionTestUtils.setField(ccdVerificationIDCHECK, "CCDURL", "http://testccdurl.com");
        ReflectionTestUtils.setField(ccdVerificationIDCHECK, "ccdCallTimeout", "5000");
        ReflectionTestUtils.setField(ccdVerificationIDCHECK, "ccdCallReadTimeout", "5000");
    }

    @Test
    public void testCCDCallSuccessEDIPI() throws Exception {
        when(sgposServices.getIDCheckRequest()).thenReturn(mock(IDCheckRequest.class));

        Header mockHeader = new Header();
        mockHeader.setTraceID("12345");
        when(sgposServices.getHeader()).thenReturn(mockHeader);
        assertEquals("12345", sgposServices.getHeader().getTraceID());

        IDCheckRequest mockIDCheckRequest = mock(IDCheckRequest.class);
        when(sgposServices.getIDCheckRequest()).thenReturn(mockIDCheckRequest);
        when(mockIDCheckRequest.getCustomerType()).thenReturn(IDCheckRequest.CustomerType.valueOf("EDIPI"));
        when(mockIDCheckRequest.getCustomerID()).thenReturn("12345");
        when(encryptorConfig.decrypt(anyString())).thenReturn("DecryptedPassword");
        when(sgposServices.getIDCheckRequest()).thenReturn(mockIDCheckRequest);

        JSONObject mockResponseBody = new JSONObject();
        mockResponseBody.put("respStatus", "000");
        ResponseEntity<Object> responseEntity = new ResponseEntity<>(mockResponseBody.toString(), HttpStatus.OK);
        JSONObject result = new JSONObject();
        result.put("ccdCall", true);
        result.put("ssn", "123-45-6789");
        result.put("respStatus", "000");

        when(ccdVerificationIDCHECK.CCDCall(sgposServices)).thenReturn(result);

        JSONObject jsonObjectResult = new JSONObject();
        assertNotNull(jsonObjectResult);
        assertEquals(true, result.get("ccdCall"));
        assertEquals("123-45-6789", result.get("ssn"));
        assertEquals("000", result.get("respStatus"));
    }

    @Test
    public void testCCDCallFailureWithStatusNot000() throws Exception {
        // Mock necessary methods and data
        SGPOSServices sgposServices = mock(SGPOSServices.class, RETURNS_DEEP_STUBS);
        when(encryptorConfig.decrypt(CCDPassword)).thenReturn("decryptedPassword");
        when(sgposServices.getIDCheckRequest().getCustomerType()).thenReturn(IDCheckRequest.CustomerType.EDIPI);
        when(sgposServices.getIDCheckRequest().getCustomerID()).thenReturn("DODEDIPersonalId");

        when(sgposServices.getIDCheckRequest()).thenReturn(mock(IDCheckRequest.class));

        Header mockHeader = new Header();
        mockHeader.setTraceID("12345");
        when(sgposServices.getHeader()).thenReturn(mockHeader);
        assertEquals("12345", sgposServices.getHeader().getTraceID());

        IDCheckRequest mockIDCheckRequest = mock(IDCheckRequest.class);
        when(sgposServices.getIDCheckRequest()).thenReturn(mockIDCheckRequest);
        when(mockIDCheckRequest.getCustomerType()).thenReturn(IDCheckRequest.CustomerType.valueOf("EDIPI"));
        when(mockIDCheckRequest.getCustomerID()).thenReturn("12345");
        when(encryptorConfig.decrypt(anyString())).thenReturn("DecryptedPassword");
        when(sgposServices.getIDCheckRequest()).thenReturn(mockIDCheckRequest);

        JSONObject mockResponseBody = new JSONObject();
        mockResponseBody.put("respStatus", "000");
        ResponseEntity<Object> responseEntity = new ResponseEntity<>(mockResponseBody.toString(), HttpStatus.OK);

        JSONObject result = new JSONObject();
        result.put("ccdCall", false);
        result.put("abcde", "123-45-6789");
        result.put("respStatus", "000");

        when(ccdVerificationIDCHECK.CCDCall(sgposServices)).thenReturn(result);

        JSONObject jsonObjectResult = new JSONObject();
        assertNotNull(jsonObjectResult);
        assertEquals(false, result.get("ccdCall"));
        assertNotEquals("123-45-6789", result.get("ssn"));
        assertEquals("000", result.get("respStatus"));
    }
    //
    @Test
    public void testCCDCallFailureWithStatusCode100() throws Exception {
        // Mock necessary methods and data
        SGPOSServices sgposServices = mock(SGPOSServices.class, RETURNS_DEEP_STUBS);
        when(encryptorConfig.decrypt(CCDPassword)).thenReturn("decryptedPassword");
        when(sgposServices.getIDCheckRequest().getCustomerType()).thenReturn(IDCheckRequest.CustomerType.EDIPI);
        when(sgposServices.getIDCheckRequest().getCustomerID()).thenReturn("98765");

        when(sgposServices.getIDCheckRequest()).thenReturn(mock(IDCheckRequest.class));

        Header mockHeader = new Header();
        mockHeader.setTraceID("12345");
        when(sgposServices.getHeader()).thenReturn(mockHeader);
        assertEquals("12345", sgposServices.getHeader().getTraceID());

        IDCheckRequest mockIDCheckRequest = mock(IDCheckRequest.class);
        when(sgposServices.getIDCheckRequest()).thenReturn(mockIDCheckRequest);
        when(mockIDCheckRequest.getCustomerType()).thenReturn(IDCheckRequest.CustomerType.valueOf("EDIPI"));
        when(mockIDCheckRequest.getCustomerID()).thenReturn("12345");
        when(encryptorConfig.decrypt(anyString())).thenReturn("DecryptedPassword");
        when(sgposServices.getIDCheckRequest()).thenReturn(mockIDCheckRequest);

        JSONObject mockResponseBody = new JSONObject();
        mockResponseBody.put("respStatus", "100");
        ResponseEntity<Object> responseEntity = new ResponseEntity<>(mockResponseBody.toString(), HttpStatus.OK);

        JSONObject result = new JSONObject();
        result.put("ccdCall", false);
        result.put("abcde", "123-45-6789");
        result.put("respStatus", "100");

        when(ccdVerificationIDCHECK.CCDCall(sgposServices)).thenReturn(result);

        JSONObject jsonObjectResult = new JSONObject();
        assertNotNull(jsonObjectResult);
        assertEquals(false, result.get("ccdCall"));
        assertNotEquals("123-45-6789", result.get("ssn"));
        assertEquals("100", result.get("respStatus"));
    }
    @Test
    public void testCCDCallFailureWithStatus201() throws Exception {
        // Mock necessary methods and data
        SGPOSServices sgposServices = mock(SGPOSServices.class, RETURNS_DEEP_STUBS);
        when(encryptorConfig.decrypt(CCDPassword)).thenReturn("decryptedPassword");
        when(sgposServices.getIDCheckRequest().getCustomerType()).thenReturn(IDCheckRequest.CustomerType.EDIPI);
        when(sgposServices.getIDCheckRequest().getCustomerID()).thenReturn("98765");

        when(sgposServices.getIDCheckRequest()).thenReturn(mock(IDCheckRequest.class));

        Header mockHeader = new Header();
        mockHeader.setTraceID("12345");
        when(sgposServices.getHeader()).thenReturn(mockHeader);
        assertEquals("12345", sgposServices.getHeader().getTraceID());

        IDCheckRequest mockIDCheckRequest = mock(IDCheckRequest.class);
        when(sgposServices.getIDCheckRequest()).thenReturn(mockIDCheckRequest);
        when(mockIDCheckRequest.getCustomerType()).thenReturn(IDCheckRequest.CustomerType.valueOf("EDIPI"));
        when(mockIDCheckRequest.getCustomerID()).thenReturn("12345");
        when(encryptorConfig.decrypt(anyString())).thenReturn("DecryptedPassword");
        when(sgposServices.getIDCheckRequest()).thenReturn(mockIDCheckRequest);

        JSONObject mockResponseBody = new JSONObject();
        mockResponseBody.put("respStatus", "201");
        ResponseEntity<Object> responseEntity = new ResponseEntity<>(mockResponseBody.toString(), HttpStatus.OK);

        JSONObject result = new JSONObject();
        result.put("ccdCall", false);
        result.put("abcde", "123-45-6789");
        result.put("respStatus", "201");

        when(ccdVerificationIDCHECK.CCDCall(sgposServices)).thenReturn(result);

        JSONObject jsonObjectResult = new JSONObject();
        assertNotNull(jsonObjectResult);
        assertEquals(false, result.get("ccdCall"));
        assertNotEquals("123-45-6789", result.get("ssn"));
        assertEquals("201", result.get("respStatus"));
    }

    @Test
    public void testCCDCallFailureWithStatus202() throws Exception {
        // Mock necessary methods and data
        SGPOSServices sgposServices = mock(SGPOSServices.class, RETURNS_DEEP_STUBS);
        when(encryptorConfig.decrypt(CCDPassword)).thenReturn("decryptedPassword");
        when(sgposServices.getIDCheckRequest().getCustomerType()).thenReturn(IDCheckRequest.CustomerType.EDIPI);
        when(sgposServices.getIDCheckRequest().getCustomerID()).thenReturn("98765");

        when(sgposServices.getIDCheckRequest()).thenReturn(mock(IDCheckRequest.class));

        Header mockHeader = new Header();
        mockHeader.setTraceID("12345");
        when(sgposServices.getHeader()).thenReturn(mockHeader);
        assertEquals("12345", sgposServices.getHeader().getTraceID());

        IDCheckRequest mockIDCheckRequest = mock(IDCheckRequest.class);
        when(sgposServices.getIDCheckRequest()).thenReturn(mockIDCheckRequest);
        when(mockIDCheckRequest.getCustomerType()).thenReturn(IDCheckRequest.CustomerType.valueOf("EDIPI"));
        when(mockIDCheckRequest.getCustomerID()).thenReturn("12345");
        when(encryptorConfig.decrypt(anyString())).thenReturn("DecryptedPassword");
        when(sgposServices.getIDCheckRequest()).thenReturn(mockIDCheckRequest);

        JSONObject mockResponseBody = new JSONObject();
        mockResponseBody.put("respStatus", "202");
        ResponseEntity<Object> responseEntity = new ResponseEntity<>(mockResponseBody.toString(), HttpStatus.OK);

        JSONObject result = new JSONObject();
        result.put("ccdCall", false);
        result.put("abcde", "123-45-6789");
        result.put("respStatus", "202");

        when(ccdVerificationIDCHECK.CCDCall(sgposServices)).thenReturn(result);

        JSONObject jsonObjectResult = new JSONObject();
        assertNotNull(jsonObjectResult);
        assertEquals(false, result.get("ccdCall"));
        assertNotEquals("123-45-6789", result.get("ssn"));
        assertEquals("202", result.get("respStatus"));
    }

    @Test
    public void testCCDCallFailureWithStatus203() throws Exception {
        // Mock necessary methods and data
        SGPOSServices sgposServices = mock(SGPOSServices.class, RETURNS_DEEP_STUBS);
        when(encryptorConfig.decrypt(CCDPassword)).thenReturn("decryptedPassword");
        when(sgposServices.getIDCheckRequest().getCustomerType()).thenReturn(IDCheckRequest.CustomerType.EDIPI);
        when(sgposServices.getIDCheckRequest().getCustomerID()).thenReturn("98765");

        when(sgposServices.getIDCheckRequest()).thenReturn(mock(IDCheckRequest.class));

        Header mockHeader = new Header();
        mockHeader.setTraceID("12345");
        when(sgposServices.getHeader()).thenReturn(mockHeader);
        assertEquals("12345", sgposServices.getHeader().getTraceID());

        IDCheckRequest mockIDCheckRequest = mock(IDCheckRequest.class);
        when(sgposServices.getIDCheckRequest()).thenReturn(mockIDCheckRequest);
        when(mockIDCheckRequest.getCustomerType()).thenReturn(IDCheckRequest.CustomerType.valueOf("EDIPI"));
        when(mockIDCheckRequest.getCustomerID()).thenReturn("12345");
        when(encryptorConfig.decrypt(anyString())).thenReturn("DecryptedPassword");
        when(sgposServices.getIDCheckRequest()).thenReturn(mockIDCheckRequest);

        JSONObject mockResponseBody = new JSONObject();
        mockResponseBody.put("respStatus", "203");
        ResponseEntity<Object> responseEntity = new ResponseEntity<>(mockResponseBody.toString(), HttpStatus.OK);

        JSONObject result = new JSONObject();
        result.put("ccdCall", false);
        result.put("abcde", "123-45-6789");
        result.put("respStatus", "203");

        when(ccdVerificationIDCHECK.CCDCall(sgposServices)).thenReturn(result);

        JSONObject jsonObjectResult = new JSONObject();
        assertNotNull(jsonObjectResult);
        assertEquals(false, result.get("ccdCall"));
        assertNotEquals("123-45-6789", result.get("ssn"));
        assertEquals("203", result.get("respStatus"));
    }

    @Test
    public void testCCDCallFailureWithStatus998() throws Exception {
        // Mock necessary methods and data
        SGPOSServices sgposServices = mock(SGPOSServices.class, RETURNS_DEEP_STUBS);
        when(encryptorConfig.decrypt(CCDPassword)).thenReturn("decryptedPassword");
        when(sgposServices.getIDCheckRequest().getCustomerType()).thenReturn(IDCheckRequest.CustomerType.EDIPI);
        when(sgposServices.getIDCheckRequest().getCustomerID()).thenReturn("98765");

        when(sgposServices.getIDCheckRequest()).thenReturn(mock(IDCheckRequest.class));

        Header mockHeader = new Header();
        mockHeader.setTraceID("12345");
        when(sgposServices.getHeader()).thenReturn(mockHeader);
        assertEquals("12345", sgposServices.getHeader().getTraceID());

        IDCheckRequest mockIDCheckRequest = mock(IDCheckRequest.class);
        when(sgposServices.getIDCheckRequest()).thenReturn(mockIDCheckRequest);
        when(mockIDCheckRequest.getCustomerType()).thenReturn(IDCheckRequest.CustomerType.valueOf("EDIPI"));
        when(mockIDCheckRequest.getCustomerID()).thenReturn("12345");
        when(encryptorConfig.decrypt(anyString())).thenReturn("DecryptedPassword");
        when(sgposServices.getIDCheckRequest()).thenReturn(mockIDCheckRequest);

        JSONObject mockResponseBody = new JSONObject();
        mockResponseBody.put("respStatus", "998");
        ResponseEntity<Object> responseEntity = new ResponseEntity<>(mockResponseBody.toString(), HttpStatus.OK);

        JSONObject result = new JSONObject();
        result.put("ccdCall", false);
        result.put("abcde", "123-45-6789");
        result.put("respStatus", "998");

        when(ccdVerificationIDCHECK.CCDCall(sgposServices)).thenReturn(result);

        JSONObject jsonObjectResult = new JSONObject();
        assertNotNull(jsonObjectResult);
        assertEquals(false, result.get("ccdCall"));
        assertNotEquals("123-45-6789", result.get("ssn"));
        assertEquals("998", result.get("respStatus"));
    }

    @Test
    public void testCCDCallFailureWithStatus901() throws Exception {
        // Mock necessary methods and data
        SGPOSServices sgposServices = mock(SGPOSServices.class, RETURNS_DEEP_STUBS);
        when(encryptorConfig.decrypt(CCDPassword)).thenReturn("decryptedPassword");
        when(sgposServices.getIDCheckRequest().getCustomerType()).thenReturn(IDCheckRequest.CustomerType.EDIPI);
        when(sgposServices.getIDCheckRequest().getCustomerID()).thenReturn("98765");

        when(sgposServices.getIDCheckRequest()).thenReturn(mock(IDCheckRequest.class));

        Header mockHeader = new Header();
        mockHeader.setTraceID("12345");
        when(sgposServices.getHeader()).thenReturn(mockHeader);
        assertEquals("12345", sgposServices.getHeader().getTraceID());

        IDCheckRequest mockIDCheckRequest = mock(IDCheckRequest.class);
        when(sgposServices.getIDCheckRequest()).thenReturn(mockIDCheckRequest);
        when(mockIDCheckRequest.getCustomerType()).thenReturn(IDCheckRequest.CustomerType.valueOf("EDIPI"));
        when(mockIDCheckRequest.getCustomerID()).thenReturn("12345");
        when(encryptorConfig.decrypt(anyString())).thenReturn("DecryptedPassword");
        when(sgposServices.getIDCheckRequest()).thenReturn(mockIDCheckRequest);

        JSONObject mockResponseBody = new JSONObject();
        mockResponseBody.put("respStatus", "901");
        ResponseEntity<Object> responseEntity = new ResponseEntity<>(mockResponseBody.toString(), HttpStatus.OK);

        JSONObject result = new JSONObject();
        result.put("ccdCall", false);
        result.put("abcde", "123-45-6789");
        result.put("respStatus", "901");

        when(ccdVerificationIDCHECK.CCDCall(sgposServices)).thenReturn(result);

        JSONObject jsonObjectResult = new JSONObject();
        assertNotNull(jsonObjectResult);
        assertEquals(false, result.get("ccdCall"));
        assertNotEquals("123-45-6789", result.get("ssn"));
        assertEquals("901", result.get("respStatus"));
    }

    @Test
    public void testCCDCallFailureWithStatus903() throws Exception {
        // Mock necessary methods and data
        SGPOSServices sgposServices = mock(SGPOSServices.class, RETURNS_DEEP_STUBS);
        when(encryptorConfig.decrypt(CCDPassword)).thenReturn("decryptedPassword");
        when(sgposServices.getIDCheckRequest().getCustomerType()).thenReturn(IDCheckRequest.CustomerType.EDIPI);
        when(sgposServices.getIDCheckRequest().getCustomerID()).thenReturn("98765");

        when(sgposServices.getIDCheckRequest()).thenReturn(mock(IDCheckRequest.class));

        Header mockHeader = new Header();
        mockHeader.setTraceID("12345");
        when(sgposServices.getHeader()).thenReturn(mockHeader);
        assertEquals("12345", sgposServices.getHeader().getTraceID());

        IDCheckRequest mockIDCheckRequest = mock(IDCheckRequest.class);
        when(sgposServices.getIDCheckRequest()).thenReturn(mockIDCheckRequest);
        when(mockIDCheckRequest.getCustomerType()).thenReturn(IDCheckRequest.CustomerType.valueOf("EDIPI"));
        when(mockIDCheckRequest.getCustomerID()).thenReturn("12345");
        when(encryptorConfig.decrypt(anyString())).thenReturn("DecryptedPassword");
        when(sgposServices.getIDCheckRequest()).thenReturn(mockIDCheckRequest);

        JSONObject mockResponseBody = new JSONObject();
        mockResponseBody.put("respStatus", "903");
        ResponseEntity<Object> responseEntity = new ResponseEntity<>(mockResponseBody.toString(), HttpStatus.OK);

        JSONObject result = new JSONObject();
        result.put("ccdCall", false);
        result.put("abcde", "123-45-6789");
        result.put("respStatus", "903");

        when(ccdVerificationIDCHECK.CCDCall(sgposServices)).thenReturn(result);

        JSONObject jsonObjectResult = new JSONObject();
        assertNotNull(jsonObjectResult);
        assertEquals(false, result.get("ccdCall"));
        assertNotEquals("123-45-6789", result.get("ssn"));
        assertEquals("903", result.get("respStatus"));
    }

    @Test
    public void testCCDCallFailureWithStatusDefault() throws Exception {
        // Mock necessary methods and data
        SGPOSServices sgposServices = mock(SGPOSServices.class, RETURNS_DEEP_STUBS);
        when(encryptorConfig.decrypt(CCDPassword)).thenReturn("decryptedPassword");
        when(sgposServices.getIDCheckRequest().getCustomerType()).thenReturn(IDCheckRequest.CustomerType.EDIPI);
        when(sgposServices.getIDCheckRequest().getCustomerID()).thenReturn("98765");

        when(sgposServices.getIDCheckRequest()).thenReturn(mock(IDCheckRequest.class));

        Header mockHeader = new Header();
        mockHeader.setTraceID("12345");
        when(sgposServices.getHeader()).thenReturn(mockHeader);
        assertEquals("12345", sgposServices.getHeader().getTraceID());

        IDCheckRequest mockIDCheckRequest = mock(IDCheckRequest.class);
        when(sgposServices.getIDCheckRequest()).thenReturn(mockIDCheckRequest);
        when(mockIDCheckRequest.getCustomerType()).thenReturn(IDCheckRequest.CustomerType.valueOf("EDIPI"));
        when(mockIDCheckRequest.getCustomerID()).thenReturn("12345");
        when(encryptorConfig.decrypt(anyString())).thenReturn("DecryptedPassword");
        when(sgposServices.getIDCheckRequest()).thenReturn(mockIDCheckRequest);

        JSONObject mockResponseBody = new JSONObject();
        mockResponseBody.put("respStatus", "902");
        ResponseEntity<Object> responseEntity = new ResponseEntity<>(mockResponseBody.toString(), HttpStatus.OK);

        JSONObject result = new JSONObject();
        result.put("ccdCall", false);
        result.put("abcde", "123-45-6789");
        result.put("respStatus", "902");

        when(ccdVerificationIDCHECK.CCDCall(sgposServices)).thenReturn(result);

        JSONObject jsonObjectResult = new JSONObject();
        assertNotNull(jsonObjectResult);
        assertEquals(false, result.get("ccdCall"));
        assertNotEquals("123-45-6789", result.get("ssn"));
        assertEquals("902", result.get("respStatus"));
    }
}
