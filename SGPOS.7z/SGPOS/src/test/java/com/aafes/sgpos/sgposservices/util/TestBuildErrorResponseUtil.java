/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aafes.sgpos.sgposservices.util;

import com.aafes.sgpos.sgposservices.Control.SGPOSResponseType;
import com.aafes.sgpos.sgposservices.generated.Control.Response;
import com.aafes.sgpos.sgposservices.generated.Control.SGPOSServices;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.core.env.Environment;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

/**
 *
 * @author bhendarkart
 */
public class TestBuildErrorResponseUtil {


    private BuildErrorResponseUtil util;
    private Environment env;
    private SGPOSServices sgposservices;

    @BeforeEach
    void setup() {
        env = mock(Environment.class);
        sgposservices = spy(new SGPOSServices());
        util = new BuildErrorResponseUtil();
        util.setEnv(env);

        when(sgposservices.getHeader()).thenReturn(null); // optional stub
    }

    @Test
    void testBuildErrorResponseAdd_timeoutReason() {
        when(env.getProperty("CVS_TIME_OUT", String.class)).thenReturn("408");

        SGPOSServices result = util.buildErrorResponseAdd(sgposservices, "CVS_TIME_OUT");

        assertNotNull(result);
        Response response = result.getResponse();
        assertNotNull(response);
        assertEquals("408", response.getReasonCode());
        assertEquals("CVS_TIME_OUT", response.getReasonDescription());
        assertEquals(SGPOSResponseType.TIMEOUT, response.getResponse());
    }

    @Test
    void testBuildErrorResponseAdd_partialApproved() {
        when(env.getProperty("PARTIAL_APPROVED", String.class)).thenReturn("206");

        SGPOSServices result = util.buildErrorResponseAdd(sgposservices, "PARTIAL_APPROVED");

        Response response = result.getResponse();
        assertNotNull(response);
        assertEquals("206", response.getReasonCode());
        assertEquals(SGPOSResponseType.APPROVED, response.getResponse());
    }

    @Test
    void testBuildErrorResponseAdd_declinedFallback() {
        when(env.getProperty("UNKNOWN_REASON", String.class)).thenReturn("999");

        SGPOSServices result = util.buildErrorResponseAdd(sgposservices, "UNKNOWN_REASON");

        Response response = result.getResponse();
        assertNotNull(response);
        assertEquals("999", response.getReasonCode());
        assertEquals(SGPOSResponseType.DECLINED, response.getResponse());
    }

    @Test
    void testBuildErrorResponseOris() {
        SGPOSServices result = util.buildErrorResponseOris(sgposservices, "ORIS failure", "501");

        Response response = result.getResponse();
        assertNotNull(response);
        assertEquals("501", response.getReasonCode());
        assertEquals("ORIS failure", response.getReasonDescription());
        assertEquals(SGPOSResponseType.DECLINED, response.getResponse());
    }

    @Test
    void testBuildErrorResponseCCD() {
        SGPOSServices result = util.buildErrorResponseCCD(sgposservices, "CCD error", "403");

        Response response = result.getResponse();
        assertNotNull(response);
        assertEquals("403", response.getReasonCode());
        assertEquals("CCD error", response.getReasonDescription());
        assertEquals(SGPOSResponseType.DECLINED, response.getResponse());
    }
}
