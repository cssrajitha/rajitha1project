/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aafes.sgpos.sgposservices.util;
import ch.qos.logback.classic.spi.ILoggingEvent;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import ch.qos.logback.classic.LoggerContext;

/**
 *
 * @author bhendarkart
 */
public class MaskingPatternLayoutTest {
    private MaskingPatternLayout layout;

    @BeforeEach
    void setup() {
        layout = new MaskingPatternLayout();
        layout.setContext(new LoggerContext());
        layout.setPattern("%msg");
        layout.start();
    }

    @Test
    void testMaskingSSN() {
        ILoggingEvent event = mock(ILoggingEvent.class);
        when(event.getFormattedMessage()).thenReturn("{\"SSN\":\"123456789\"}");

        String result = layout.doLayout(event);
        assertEquals("{\"SSN\":\"*****789\"}", result);
    }

    @Test
    void testMaskingCID() {
        ILoggingEvent event = mock(ILoggingEvent.class);
        when(event.getFormattedMessage()).thenReturn("{\"CID\":\"987654321\"}");

        String result = layout.doLayout(event);
        assertEquals("{\"CID\":\"*****321\"}", result);
    }

    @Test
    void testMaskingCustomerID() {
        ILoggingEvent event = mock(ILoggingEvent.class);
        when(event.getFormattedMessage()).thenReturn("{\"customerID\":\"555667788\"}");

        String result = layout.doLayout(event);
        assertEquals("{\"customerID\":\"*****788\"}", result);
    }

    @Test
    void testMaskingMultipleFields() {
        ILoggingEvent event = mock(ILoggingEvent.class);
        when(event.getFormattedMessage()).thenReturn(
                "{\"SSN\":\"123456789\",\"CID\":\"987654321\",\"CustomerID\":\"111222333\"}"
        );

        String result = layout.doLayout(event);
        assertEquals(
                "{\"SSN\":\"*****789\",\"CID\":\"*****321\",\"CustomerID\":\"*****333\"}",
                result
        );
    }

    @Test
    void testMaskingShortValues() {
        ILoggingEvent event = mock(ILoggingEvent.class);
        when(event.getFormattedMessage()).thenReturn("{\"SSN\":\"123\"}");

        String result = layout.doLayout(event);
        assertEquals("{\"SSN\":\"*****123\"}", result); // ✅ Expect masking even for short values
    }


    @Test
    void testCaseInsensitiveFieldNames() {
        ILoggingEvent event = mock(ILoggingEvent.class);
        when(event.getFormattedMessage()).thenReturn("{\"DODEDIPersonalId\":\"ABCDEF123\"}");

        String result = layout.doLayout(event);
        assertEquals("{\"DODEDIPersonalId\":\"*****123\"}", result);
    }
}
