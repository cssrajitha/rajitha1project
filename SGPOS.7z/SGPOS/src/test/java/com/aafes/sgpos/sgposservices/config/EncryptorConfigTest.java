/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aafes.sgpos.sgposservices.config;

import com.aafes.sgpos.sgposservices.Config.EncryptorConfig;
import org.keyczar.Crypter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.keyczar.exceptions.KeyczarException;
import org.mockito.MockedConstruction;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;


/**
 *
 * @author bhendarkart
 */

public class EncryptorConfigTest {
    private EncryptorConfig encryptorConfig;

    @BeforeEach
    void setup() {
        encryptorConfig = new EncryptorConfig();
        // Simulate injected baseDir
        ReflectionTestUtils.setField(encryptorConfig, "baseDir", "/test/base/dir");
    }

    @Test
    void testDecrypt_String_success() {
        try (MockedConstruction<Crypter> mockCrypter = mockConstruction(Crypter.class,
                (crypter, context) -> when(crypter.decrypt("encryptedText")).thenReturn("plaintext"))) {

            String decrypted = encryptorConfig.decrypt("encryptedText");
            assertEquals("plaintext", decrypted);
        }
    }

    @Test
    void testEncrypt_String_success() {
        ReflectionTestUtils.setField(encryptorConfig, "keysPath", "/test/path/to/keys");

        try (MockedConstruction<Crypter> mockCrypter = mockConstruction(Crypter.class,
                (crypter, context) -> when(crypter.encrypt("plaintext")).thenReturn("encryptedText"))) {

            String encrypted = encryptorConfig.encrypt("plaintext");
            assertEquals("encryptedText", encrypted);
        }
    }

    @Test
    void testDecrypt_ByteArray_success() {
        byte[] encryptedBytes = new byte[]{1, 2, 3};
        byte[] decryptedBytes = new byte[]{9, 8, 7};
        ReflectionTestUtils.setField(encryptorConfig, "keysPath", "/test/path/to/keys");

        try (MockedConstruction<Crypter> mockCrypter = mockConstruction(Crypter.class,
                (crypter, context) -> when(crypter.decrypt(encryptedBytes)).thenReturn(decryptedBytes))) {

            byte[] result = encryptorConfig.decrypt(encryptedBytes);
            assertArrayEquals(decryptedBytes, result);
        }
    }

    @Test
    void testEncrypt_ByteArray_success() {
        byte[] plainBytes = new byte[]{4, 5, 6};
        byte[] encryptedBytes = new byte[]{7, 8, 9};
        ReflectionTestUtils.setField(encryptorConfig, "keysPath", "/test/path/to/keys");

        try (MockedConstruction<Crypter> mockCrypter = mockConstruction(Crypter.class,
                (crypter, context) -> when(crypter.encrypt(plainBytes)).thenReturn(encryptedBytes))) {

            byte[] result = encryptorConfig.encrypt(plainBytes);
            assertArrayEquals(encryptedBytes, result);
        }
    }
    @Test
    void testDecrypt_String_failure_returnsNull() {
        try (MockedConstruction<Crypter> mockCrypter = mockConstruction(Crypter.class,
                (crypter, context) -> when(crypter.decrypt("badText")).thenThrow(new RuntimeException("Decryption failed")))) {

            String result = encryptorConfig.decrypt("badText");
            assertNull(result, "Should return null when decryption fails");
        }
    }

    @Test
    void testDecrypt_KeyczarException_returnsNull() {
        try (MockedConstruction<Crypter> mockCrypter = mockConstruction(Crypter.class,
                (crypter, context) -> when(crypter.decrypt("errorText")).thenThrow(new KeyczarException("Decryption error")))) {

            String result = encryptorConfig.decrypt("errorText");
            assertNull(result, "Should return null when Keyczar decryption fails");
        }
    }
    @Test
    void testEncrypt_KeyczarException_returnsNull() {
        ReflectionTestUtils.setField(encryptorConfig, "keysPath", "/test/path/to/keys");

        try (MockedConstruction<Crypter> mockCrypter = mockConstruction(Crypter.class,
                (crypter, context) -> when(crypter.encrypt("plainText")).thenThrow(new KeyczarException("Encryption error")))) {

            String result = encryptorConfig.encrypt("plainText");
            assertNull(result, "Should return null when Keyczar encryption fails");
        }
    }
    @Test
    void testDecrypt_ByteArray_KeyczarException_shouldReturnNull() {
        byte[] encryptedBytes = new byte[]{1, 2, 3};

        // Simulate Keyczar failure
        try (MockedConstruction<Crypter> mockCrypter = mockConstruction(Crypter.class,
                (crypter, context) -> {
                    when(crypter.decrypt(encryptedBytes)).thenThrow(new KeyczarException("Byte array decryption failed"));
                })) {

            byte[] result = encryptorConfig.decrypt(encryptedBytes);

            // Validate result
            assertNull(result, "Should return null when Keyczar byte array decryption fails");
        }
    }

}