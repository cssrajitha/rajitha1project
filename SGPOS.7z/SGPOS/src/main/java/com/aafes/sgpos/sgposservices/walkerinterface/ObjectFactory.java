
package com.aafes.sgpos.sgposservices.walkerinterface;

import jakarta.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.aafes.sgpos.sgposservices.walkerinterface package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.aafes.sgpos.sgposservices.walkerinterface
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ApplyTXN }
     * 
     */
    public ApplyTXN createApplyTXN() {
        return new ApplyTXN();
    }

    /**
     * Create an instance of {@link ApplyTXNResponse }
     * 
     */
    public ApplyTXNResponse createApplyTXNResponse() {
        return new ApplyTXNResponse();
    }

    /**
     * Create an instance of {@link ServerAccessProperties }
     * 
     */
    public ServerAccessProperties createServerAccessProperties() {
        return new ServerAccessProperties();
    }

    /**
     * Create an instance of {@link LogOffWalker }
     * 
     */
    public LogOffWalker createLogOffWalker() {
        return new LogOffWalker();
    }

    /**
     * Create an instance of {@link LogOffWalkerResponse }
     * 
     */
    public LogOffWalkerResponse createLogOffWalkerResponse() {
        return new LogOffWalkerResponse();
    }

    /**
     * Create an instance of {@link ConnectToWalker }
     * 
     */
    public ConnectToWalker createConnectToWalker() {
        return new ConnectToWalker();
    }

    /**
     * Create an instance of {@link ConnectToWalkerResponse }
     * 
     */
    public ConnectToWalkerResponse createConnectToWalkerResponse() {
        return new ConnectToWalkerResponse();
    }

    /**
     * Create an instance of {@link ArrayOfAnyType }
     * 
     */
    public ArrayOfAnyType createArrayOfAnyType() {
        return new ArrayOfAnyType();
    }

}
