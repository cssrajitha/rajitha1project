package com.aafes.sgpos.sgposservices.Control;

public class tranCode {
    public static final String MC2 = "MC2";
}
