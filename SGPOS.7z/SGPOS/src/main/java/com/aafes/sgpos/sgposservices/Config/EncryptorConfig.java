package com.aafes.sgpos.sgposservices.Config;

import org.keyczar.Crypter;
import org.keyczar.exceptions.KeyczarException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.File;
@Component
public class EncryptorConfig {

    private String keysPath;

    @Value("${cryptoKeysDir}")
    private String baseDir;

    private final Logger LOG = (Logger) LoggerFactory.getLogger(EncryptorConfig.class);

//    public EncryptorConfig(String keysPath, String logConfigPath) {
//        this.keysPath = keysPath;
//        System.setProperty("log4j.configuration", logConfigPath);
//        LOG.info("Encryptor-> Encryptor-> System.getProperty(\"log4j.configuration\"): " + System.getProperty("log4j.configuration"));
//    }

    public  String decrypt(String ciphertext) {
        this.keysPath = baseDir + File.separator + "crypto" + File.separator + "keys";
        String logPath = baseDir + File.separator + "crypto.log4j.properties";

        System.setProperty("log4j.configuration", logPath);
        LOG.debug("Encryptor-> Encryptor-> System.getProperty(\"log4j.configuration\"): " + System.getProperty("log4j.configuration"));
        LOG.debug("Encryptor-> decrypt-> keysPath: " + keysPath);
        String plaintext = null;
        try {
            Crypter crypter = new Crypter(keysPath);
            LOG.debug("Encryptor-> decrypt-> Before crypter.decrypt-> ciphertext " + ciphertext);
            plaintext = crypter.decrypt(ciphertext);
            LOG.debug("Encryptor-> decrypt-> After crypter.decrypt-> plaintext " + plaintext);
        } catch (KeyczarException ex) {
            LOG.error("Keyczar is having trouble decrypting.");
            LOG.error(ex.toString());
        } catch (Exception e) {
            LOG.error("Exception in Keyczar decrypting.");
            LOG.error(e.toString());
        }
        return plaintext;
    }

    public  String encrypt(String plaintext) {
        String ciphertext = null;
        try {
            Crypter crypter = new Crypter(keysPath);
            ciphertext = crypter.encrypt(plaintext);
        } catch (KeyczarException ex) {
            LOG.error("Keyczar is having trouble encrypting.");
            LOG.error(ex.toString());
        }
        return ciphertext;
    }

    public byte[] decrypt(byte[] cipherBytes) {
        byte[] plainBytes = null;
        try {
            Crypter crypter = new Crypter(keysPath);
            plainBytes = crypter.decrypt(cipherBytes);
        } catch (KeyczarException ex) {
            LOG.error("Keyczar is having trouble decrypting a byte array.");
            LOG.error(ex.toString());
        }
        return plainBytes;
    }

    public byte[] encrypt(byte[] plainBytes) {
        byte[] cipherBytes = null;
        try {
            Crypter crypter = new Crypter(keysPath);
            cipherBytes = crypter.encrypt(plainBytes);
        } catch (KeyczarException ex) {
            LOG.error("Keyczar is having trouble encrypting a byte array.");
            LOG.error(ex.toString());
        }
        return cipherBytes;
    }


}
