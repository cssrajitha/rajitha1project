package com.aafes.sgpos.sgposservices.Gateway;

import com.aafes.sgpos.sgposservices.Config.EncryptorConfig;
import com.aafes.sgpos.sgposservices.Control.tranCode;
import com.aafes.sgpos.sgposservices.generated.Control.SGPOSServices;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class ccdVerificationIGLAS {
    private static final Logger LOG = (Logger) LoggerFactory.getLogger(ccdVerificationIGLAS.class);

    @Autowired
    private RestTemplate restTemplate;
    @Value("${ccd.CCDUserName}")
    private String CCDUserName;
    @Value("${ccd.CCDPassword}")
    private String CCDPassword;
    @Value("${ccd.CCDClientID}")
    private String CCDClientID;
    @Value("${ccd.CCDURL}")
    private String CCDURL;
    @Value("${timeOut.ccdCallTimeout}")
    private String ccdCallTimeout;
    @Value("${timeOut.ccdCallReadTimeout}")
    private String ccdCallReadTimeout;
    @Autowired
    EncryptorConfig encryptorConfig;

    private SimpleClientHttpRequestFactory getClientHttpRequestFactory() {

        SimpleClientHttpRequestFactory clientHttpRequestFactory = new SimpleClientHttpRequestFactory();
        clientHttpRequestFactory.setConnectTimeout(Integer.parseInt(ccdCallTimeout));
        clientHttpRequestFactory.setReadTimeout(Integer.parseInt(ccdCallReadTimeout));
        return clientHttpRequestFactory;
    }

    public JSONObject CCDCall(SGPOSServices sgposservices) throws JsonProcessingException {
        Boolean res = false;
        JSONObject ccdRes = new JSONObject();
        ObjectMapper mapper = new ObjectMapper();
        HttpHeaders headers = new HttpHeaders();
        headers.setBasicAuth(CCDUserName, encryptorConfig.decrypt(CCDPassword));
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("ClientId", CCDClientID);
        JSONObject personJsonObject = new JSONObject();
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        if (null != sgposservices.getIGLASRequest().getSsn() && !sgposservices.getIGLASRequest().getSsn().isEmpty()) {
            personJsonObject.put("SSN", sgposservices.getIGLASRequest().getSsn());
        }
        //LOG.info("CCD Request :");
        LOG.info("CCD Request :"+ String.valueOf(personJsonObject));
        HttpEntity<String> requestCCD = new HttpEntity<String>(personJsonObject.toString(), headers);

        //  TimeOut timeoutCCD=new TimeOut();
        restTemplate = new RestTemplate(this.getClientHttpRequestFactory());//timeoutCCD.getClientHttpRequestFactoryIGLAS());
        ResponseEntity<Object> response = restTemplate.exchange(CCDURL, HttpMethod.POST,
                requestCCD, Object.class);
       // LOG.info("CCD Response");
        JSONObject obj;
        if (response.hasBody()) {
            obj = mapper.convertValue(response.getBody(), JSONObject.class);
            LOG.info("CCD Response: "+obj.toString());
            switch (obj.get("respStatus").toString()) {
                case "000" -> {
                    ccdRes.put("ccdCall", true);
                }
                case "100" -> {
                    if (sgposservices.getIGLASRequest().getTranCode().equalsIgnoreCase(tranCode.MC2)) {
                        ccdRes.put("ccdCall", true);
                        ccdRes.put("reasonCode", obj.get("respStatus").toString());
                    } else {
                        ccdRes.put("ccdCall", false);
                        ccdRes.put("reasonCode", obj.get("respStatus").toString());
                    }
                }
                case "101" -> {
                    ccdRes.put("ccdCall", true);
                    ccdRes.put("reasonCode", obj.get("respStatus").toString());
                }
                case "102" -> {
                    ccdRes.put("ccdCall", false);
                    ccdRes.put("reasonCode", obj.get("respStatus").toString());
                }
                case "901" -> {
                    if (sgposservices.getIGLASRequest().getTranCode().equalsIgnoreCase(tranCode.MC2)) {
                        ccdRes.put("ccdCall", true);
                        ccdRes.put("reasonCode", obj.get("respStatus").toString());
                    } else {
                        ccdRes.put("ccdCall", false);
                        ccdRes.put("reasonCode", obj.get("respStatus").toString());
                    }
                }
                default -> {
                    if (sgposservices.getIGLASRequest().getTranCode().equalsIgnoreCase(tranCode.MC2)) {
                        ccdRes.put("ccdCall", true);
                        ccdRes.put("reasonCode", obj.get("respStatus").toString());
                    } else {
                        ccdRes.put("ccdCall", false);
                        ccdRes.put("reasonCode", "999");
                    }
                }

            }
        }
        return ccdRes;
    }


}
