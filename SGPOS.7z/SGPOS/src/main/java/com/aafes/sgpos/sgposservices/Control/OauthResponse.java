package com.aafes.sgpos.sgposservices.Control;

public class OauthResponse {
    public String Active;
    public String ReasonCode;
    public String ResponseDescription;
    public boolean statusCode;




    public boolean getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(boolean isalive) {
        this.statusCode = isalive;
    }

    public String getResponseDescription() {
        return ResponseDescription;
    }

    public void setResponseDescription(String responseDescription) {
        ResponseDescription = responseDescription;
    }

    public String getReasonCode() {
        return ReasonCode;
    }

    public void setReasonCode(String reasonCode) {
        ReasonCode = reasonCode;
    }

    public String getActive() {
        return Active;
    }

    public void setActive(String active) {
        Active = active;
    }

    @Override
    public String toString() {
        return "oauth [Active=" + Active + ", ReasonCode=" + ReasonCode + ", ResponseDescription=" + ResponseDescription
                + "]";
    }

}


