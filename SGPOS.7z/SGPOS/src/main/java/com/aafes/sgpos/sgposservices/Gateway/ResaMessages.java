package com.aafes.sgpos.sgposservices.Gateway;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import com.aafes.sgpos.sgposservices.Repository.storeOpenCloseMessagesRepository;
import com.aafes.sgpos.sgposservices.Control.storeOpenCloseMessagesStatus;

import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import com.aafes.sgpos.sgposservices.generated.Control.SGPOSServices;
import com.aafes.sgpos.sgposservices.generated.Control.StoreOpenCloseResaQ;
import com.aafes.sgpos.sgposservices.util.BuildErrorResponseUtil;
import jakarta.jms.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.JmsException;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.core.JmsOperations;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

/**
 *
 * @author sriramm
 */
@Service
@EnableJms
public class ResaMessages {

    private static final Logger LOG
            = LoggerFactory.getLogger(ResaMessages.class.getSimpleName());
    static final DecimalFormat TIME_FORMAT = new DecimalFormat("0000;0000");
    private static final Charset ASCII = Charset.forName("ISO-8859-1");
//    private MQQueueConnectionFactory cf = null;
//    private MQQueueConnection connection = null;

    @Value("${spring.jms.ibm.mq.queue-manager-2.requestQ}")
    private String requestQ;

    @Value("${spring.jms.ibm.mq.queue-manager-1.requestQ}")
    private String requestQ1;

    @Autowired
    private JmsTemplate jmsTemplate;

@Autowired
private storeOpenCloseMessagesRepository resaQueueRepository;

    @Autowired
    private JmsTemplate jmsTemplateQM2;

    @Autowired
    @Qualifier("SocJmsOperations")
    private JmsOperations jmsOperations;

    @Autowired
    @Qualifier("SocJmsOperations")
    private JmsTemplate jmsOperations1;

    @Autowired
    BuildErrorResponseUtil buildErrorResponseUtil;
    // Default TransID
    private String transId = "";
//    @Autowired
//    storeOpenCloseProcessingDaysService storeOpenCloseProcessingDaysService;

    public ResaMessages(JmsTemplate jmsTemplate) {
        this.jmsTemplate = jmsTemplate;
    }
    @Async
    public void bookToResa(SGPOSServices sgposservices) {
StoreOpenCloseResaQ storeOpenCloseResaQ= new StoreOpenCloseResaQ();
//        if (onlineApproved(t) && t.getFacility7() != null
    storeOpenCloseMessagesStatus booking = new storeOpenCloseMessagesStatus();
        DateFormat dateFormat = new SimpleDateFormat("yyMMddHHmmss");
        Date date = new Date();
            booking.setMsgSendDateTime(dateFormat.format(date));
            booking.setFacilityNumber(sgposservices.getHeader().getFacilityNumber());
            booking.setStoreStatus(sgposservices.getStoreOpenCloseRequest().getRequestType());
            booking.setDateAndTimeStamp(sgposservices.getStoreOpenCloseRequest().getBusinessDate());

            String rec = formatRecord(booking);
            sendMessage(rec, sgposservices);
            LOG.info("Got response from IIB service" );
//        }

    }




    public String formatRecord(storeOpenCloseMessagesStatus booking) {
        StringBuilder sb = new StringBuilder();
        sb.append(booking.getMsgSendDateTime());
        sb.append(",").append(booking.getFacilityNumber());
        sb.append(",").append(booking.getStoreStatus());
        sb.append(",").append(booking.getDateAndTimeStamp());
        String rec = sb.toString();
        return rec;
    }

    public String sendMessage(String payload, SGPOSServices sgposservices) {
        StoreOpenCloseResaQ storeOpenCloseResaQ=new StoreOpenCloseResaQ();
        StringBuilder logString = new StringBuilder();
        String correlationId = new String(getCorrelationIDWithCalendar());
        try{
            //LOG.info("Sending request to Resa: TraceID " +sgposservices.getHeader().getTraceID());
            LOG.info("Sending request to Resa: " +payload);
          //  jmsOperations1.convertAndSend(requestQ, payload);
            String finalCorrelationId = correlationId;
            jmsOperations.send("queue:///"+requestQ+"?targetClient=1", new MessageCreator() {
                public Message createMessage(Session session) throws JMSException {
                    BytesMessage message = session.createBytesMessage();
                    message.setJMSCorrelationID(finalCorrelationId);
                    message.writeBytes(payload.getBytes(ASCII));
                    LOG.debug(message.toString());
                //    LOG.info("MQ Message sent successfully: " +message);
                    return message;


                }
            });
            correlationId= "SUCCESS";
        }catch(JmsException jmsex){
            LOG.error("Unable to send MQ Message.{}" + jmsex.getMessage(),jmsex );
            storeOpenCloseResaQ.setResponseType("FAILED");
            correlationId="FAILED";
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date date = new Date();
            DateFormat dateFormatMsg = new SimpleDateFormat("yyMMddHHmmss");
            Date dateMsg = new Date();
            com.aafes.sgpos.sgposservices.Entity.storeOpenCloseMessages storeOpenCloseMessages=new com.aafes.sgpos.sgposservices.Entity.storeOpenCloseMessages();
            if(null != sgposservices.getStoreOpenCloseRequest()) {
                storeOpenCloseMessages.setReceiveddate(dateFormat.format(date));
                storeOpenCloseMessages.setTraceid(sgposservices.getHeader().getTraceID());
                storeOpenCloseMessages.setGateway("resa");
                storeOpenCloseMessages.setFacility(sgposservices.getHeader().getFacilityNumber());
                storeOpenCloseMessages.setReqdateandtime(sgposservices.getStoreOpenCloseRequest().getBusinessDate());
                storeOpenCloseMessages.setMsgsenddatetime(dateFormatMsg.format(dateMsg));
                storeOpenCloseMessages.setRequesttype(sgposservices.getStoreOpenCloseRequest().getRequestType());
                storeOpenCloseMessages.setStatus(jmsex.getMessage());
                resaQueueRepository.save(storeOpenCloseMessages);
                sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "PARTIAL_APPROVED");
            }
        }
        return correlationId;
    }
    private static byte[] getCorrelationIDWithCalendar() {
        Calendar cal = Calendar.getInstance();
        String val = String.valueOf(cal.get(Calendar.YEAR));
        val += TIME_FORMAT.format(cal.get(Calendar.DAY_OF_YEAR));
        val += UUID.randomUUID().toString().replaceAll("-", "");
        return val.substring(0, 24).getBytes();
    }

    public String getTransId() {
        return transId;
    }

    public void setTransId(String transId) {
        this.transId = transId;
    }


    public String getRequestQ() {
        return requestQ;
    }

    public void setRequestQ(String requestQ) {
        this.requestQ = requestQ;
    }




    private void logASCII(String label, byte[] payload) {
        try {
            LOG.info(label + new String(payload, "UTF-8"));
//            if (LOG.isDebugEnabled()) {
//                LOG.debug(label + new String(payload, "UTF-8"));
//            }
        } catch (UnsupportedEncodingException ex) {
            LOG.error(ex.toString());
        }
    }

}
