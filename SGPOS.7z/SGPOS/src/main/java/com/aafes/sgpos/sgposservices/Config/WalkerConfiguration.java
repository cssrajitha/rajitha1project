package com.aafes.sgpos.sgposservices.Config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Service;
import org.springframework.ws.transport.http.HttpComponentsMessageSender;

@Configuration
@Service
public class WalkerConfiguration {
    @Value("${oris.url}")
    private String url;
    @Value("${timeOut.orisCallTimeout}")
    private String orisCallTimeout;
    @Value("${timeOut.orisCallReadTimeout}")
    private String orisCallReadTimeout;
    @Bean
    public Jaxb2Marshaller marshaller() {
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        // this package must match the package in the <generatePackage> specified in
        // pom.xml
        marshaller.setContextPath("com.aafes.sgpos.sgposservices.walkerinterface");
        return marshaller;
    }

    @Bean
    public WalkerClient walkerClient(Jaxb2Marshaller marshaller) {
        WalkerClient client = new WalkerClient();
        client.setDefaultUri(url);
       // client.setDefaultUri("https://hqws02.aafes.com/WalkerInterface/WalkerInterface.asmx");
        client.setMarshaller(marshaller);
        client.setUnmarshaller(marshaller);
        HttpComponentsMessageSender httpComponentsMessageSender = new HttpComponentsMessageSender();
        httpComponentsMessageSender.setReadTimeout(Integer.parseInt(orisCallTimeout));
        httpComponentsMessageSender.setConnectionTimeout(Integer.parseInt(orisCallReadTimeout));
        client.setMessageSender(httpComponentsMessageSender);
        return client;
    }
}
