
package com.aafes.sgpos.sgposservices.walkerinterface;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="strPostData" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="encodedHtml" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/&gt;
 *         &lt;element name="strURL" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="strCC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="strTxn" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="strCntlEntity" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "strPostData",
    "encodedHtml",
    "strURL",
    "strCC",
    "strTxn",
    "strCntlEntity"
})
@XmlRootElement(name = "ApplyTXN")
public class ApplyTXN {

    protected String strPostData;
    protected byte[] encodedHtml;
    protected String strURL;
    protected String strCC;
    protected String strTxn;
    protected String strCntlEntity;

    /**
     * Gets the value of the strPostData property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrPostData() {
        return strPostData;
    }

    /**
     * Sets the value of the strPostData property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrPostData(String value) {
        this.strPostData = value;
    }

    /**
     * Gets the value of the encodedHtml property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getEncodedHtml() {
        return encodedHtml;
    }

    /**
     * Sets the value of the encodedHtml property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setEncodedHtml(byte[] value) {
        this.encodedHtml = value;
    }

    /**
     * Gets the value of the strURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrURL() {
        return strURL;
    }

    /**
     * Sets the value of the strURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrURL(String value) {
        this.strURL = value;
    }

    /**
     * Gets the value of the strCC property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrCC() {
        return strCC;
    }

    /**
     * Sets the value of the strCC property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrCC(String value) {
        this.strCC = value;
    }

    /**
     * Gets the value of the strTxn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrTxn() {
        return strTxn;
    }

    /**
     * Sets the value of the strTxn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrTxn(String value) {
        this.strTxn = value;
    }

    /**
     * Gets the value of the strCntlEntity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrCntlEntity() {
        return strCntlEntity;
    }

    /**
     * Sets the value of the strCntlEntity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrCntlEntity(String value) {
        this.strCntlEntity = value;
    }

}
