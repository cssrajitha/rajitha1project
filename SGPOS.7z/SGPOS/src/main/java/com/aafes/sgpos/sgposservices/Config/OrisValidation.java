package com.aafes.sgpos.sgposservices.Config;

import com.aafes.sgpos.sgposservices.Control.SGPOSRequestType;
import com.aafes.sgpos.sgposservices.util.BuildErrorResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import com.aafes.sgpos.sgposservices.generated.Control.Response;
import com.aafes.sgpos.sgposservices.generated.Control.SGPOSServices;

import java.text.SimpleDateFormat;
import java.util.Date;

@Configuration
public class OrisValidation {
    @Autowired
    BuildErrorResponseUtil buildErrorResponseUtil;
    private static final Logger LOG = (Logger) LoggerFactory.getLogger(OrisValidation.class);
    //Field validation for oris
    public SGPOSServices emptyCheck(SGPOSServices sgposservices) {
        if (sgposservices.getORISRequest().getCustomerID().trim().isEmpty()) {
            LOG.info("Validation of Customer Id has failed. Error->  Customer Id Cannot Be Empty " );
            sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "INVALID_REQUEST");
        }
        if (sgposservices.getHeader().getFacilityNumber().trim().isEmpty()) {
            LOG.info("Validation of Facility Number has failed. Error->  Facility Number Cannot Be Empty " );
            sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "INVALID_REQUEST");
        }
        if (sgposservices.getORISRequest().getReceivableType().trim().isEmpty()) {
            LOG.info("Validation of Receivable type has failed. Error->  Receivable type Cannot Be Empty ");
            sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "INVALID_REQUEST");
        }
        if (sgposservices.getORISRequest().getBillingToOffice().trim().isEmpty()) {
            LOG.info("Validation of Billing TO Office has failed. Error->  Billing TO Office Cannot Be Empty ");
            sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "INVALID_REQUEST");
        } else if (!sgposservices.getORISRequest().getBillingToOffice().equalsIgnoreCase("L") && !sgposservices.getORISRequest().getBillingToOffice().equalsIgnoreCase("S") &&
                !sgposservices.getORISRequest().getBillingToOffice().equalsIgnoreCase("C")) {
            LOG.info("Validation of Billing To Office has failed. Error->  Billing TO Office must be 'L' or 'S' or 'C' ");
            sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "INVALID_REQUEST");
        }
        if (null != sgposservices && sgposservices.getORISRequest().getRequestType().equalsIgnoreCase(SGPOSRequestType.FINALAUTH)) {
            if (sgposservices.getORISRequest().getBusinessDate().trim().isEmpty()) {
                LOG.info("Validation of Business Date has failed. Error->  Business Date Cannot Be Empty " );
                sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "INVALID_REQUEST");
            }
            if (null != sgposservices.getORISRequest().getPODONbr()) {
                if (sgposservices.getORISRequest().getPODONbr().trim().isEmpty()) {
                    LOG.info("Validation of PODO Number has failed. Error->  PODO Number Cannot Be Empty " );
                    sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "INVALID_REQUEST");
                }
            }
            if (sgposservices.getORISRequest().getFacPhoneNum().trim().isEmpty()) {
                LOG.info("Validation of Facility Phone Number has failed. Error->  Facility Phone Number Cannot Be Empty ");
                sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "INVALID_REQUEST");
            }
            if (sgposservices.getORISRequest().getCashierNameTag().trim().isEmpty()) {
                LOG.info("Validation of Cashier Name has failed. Error->  Cashier Name Cannot Be Empty " );
                sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "INVALID_REQUEST");
            }
            if (sgposservices.getORISRequest().getAmount().trim().isEmpty()) {
                LOG.info("Validation of Amount has failed. Error->  Amount Cannot Be Empty " );
                sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "INVALID_REQUEST");
            }
            if (sgposservices.getORISRequest().getGLAccountNumber().trim().isEmpty()) {
                LOG.info("Validation of GL Account Number has failed. Error->  GL Account Number Cannot Be Empty " );
                sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "INVALID_REQUEST");
            }
            if (sgposservices.getHeader().getTraceID().trim().isEmpty()) {
                LOG.info("Validation of TraceId has failed. Error->  Trace ID Cannot Be Empty " );
                sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "INVALID_REQUEST");
            }
            boolean businessDate = this.tryParse(sgposservices.getORISRequest().getBusinessDate());
            if (!businessDate) {
                LOG.info("Validation of Business date has failed. Error->  Please Enter Business date yymmddhhmmss: " );
                sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "INVALID_REQUEST");
            }
        }
        return sgposservices;
    }
    public Boolean tryParse(String s) {
        SimpleDateFormat df = new SimpleDateFormat("yyMMddHHmmss");
        df.setLenient(false);
        Boolean valid = false;
        try {
            Date dateToParse = df.parse(s);
            valid = true;
        } catch (java.text.ParseException e) {
            valid = false;
        }
        return valid;
    }

}
