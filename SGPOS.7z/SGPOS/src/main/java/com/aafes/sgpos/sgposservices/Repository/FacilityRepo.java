package com.aafes.sgpos.sgposservices.Repository;

import com.aafes.sgpos.sgposservices.Entity.fac_fmf;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FacilityRepo extends JpaRepository<fac_fmf, Integer> {


        @Query(value = "SELECT FAC_NUM10,FAC_MGR,PHONE_NUM FROM fac_fmf where FAC_NUM10= :FAC_NUM10", nativeQuery = true)
        List<fac_fmf> findByFacility(@Param("FAC_NUM10") String FAC_NUM10);

}
