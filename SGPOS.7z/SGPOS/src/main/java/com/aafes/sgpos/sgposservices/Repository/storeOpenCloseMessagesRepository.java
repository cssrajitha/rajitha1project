package com.aafes.sgpos.sgposservices.Repository;


import com.aafes.sgpos.sgposservices.Entity.storeOpenCloseMessages;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface storeOpenCloseMessagesRepository extends CassandraRepository<storeOpenCloseMessages, String> {


    @Query("select * from sgposservices.storeopenclosemessages where receiveddate=?0")
    List<storeOpenCloseMessages> findByDate(String toDate);


    @Query("delete from sgposservices.storeopenclosemessages where receiveddate=?0 and gateway=?1 and facility=?2 and traceid=?3")
    void deletebyDFT(String date, String gateway, String facility, String traceid);

}
