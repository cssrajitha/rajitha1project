package com.aafes.sgpos.sgposservices.Controller;

import com.aafes.sgpos.sgposservices.Entity.storeOpenCloseMessages;
import com.aafes.sgpos.sgposservices.Repository.storeOpenCloseMessagesRepository;
import com.aafes.sgpos.sgposservices.Service.SGPOSServicesservice;
import com.aafes.sgpos.sgposservices.Service.storeOpenCloseProcessingDaysService;
import com.aafes.sgpos.sgposservices.generated.Control.SGPOSServices;
import com.aafes.sgpos.sgposservices.generated.Control.StoreOpenCloseResaQ;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

//import javax.jms.JMSException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.*;
import java.util.regex.Pattern;

@RestController
public class StoreOpenCloseMessagesController {
    private static final Logger LOG = (Logger) LoggerFactory.getLogger(StoreOpenCloseMessagesController.class);

    @Autowired
    storeOpenCloseMessagesRepository storeOpenCloseMessagesRepository;
    @Autowired
    storeOpenCloseProcessingDaysService storeOpenCloseProcessingDaysService;
    @Autowired
    SGPOSServicesservice sgposServicesservice;

    @PostMapping(value = "/1/storeopenclosemessages", produces = MediaType.APPLICATION_XML_VALUE)
    public StoreOpenCloseResaQ processXmlData(@RequestBody StoreOpenCloseResaQ storeOpenCloseResaQ, SGPOSServices sgPosServices) throws Exception {
       List<storeOpenCloseMessages> storeOpenCloseMessages = new ArrayList<storeOpenCloseMessages>();
       String toDate="";
        List<String> sC = new ArrayList<String>();
    if (null != storeOpenCloseResaQ.getFromDate() && !storeOpenCloseResaQ.getFromDate().isEmpty() && null != storeOpenCloseResaQ.getToDate() && !storeOpenCloseResaQ.getToDate().isEmpty()) {

        Date isFromDate = this.isValidDateTime(storeOpenCloseResaQ.getFromDate());
        Date isToDate = this.isValidDateTime(storeOpenCloseResaQ.getToDate());
        Date current = new Date();

        if (isFromDate != null && isToDate != null
                && !isFromDate.after(isToDate)
                && !isFromDate.after(current)
                && !isToDate.after(current) && storeOpenCloseResaQ.getFromDate().length() ==10 && storeOpenCloseResaQ.getToDate().length() ==10) {
            LocalDate date = LocalDate.parse(storeOpenCloseResaQ.getFromDate());
            LocalDate endDate = LocalDate.parse(storeOpenCloseResaQ.getToDate());
            int i=0;
            do {
                toDate = String.valueOf(date);
                LOG.info("Fetching Records from : " + toDate);
                storeOpenCloseMessages = storeOpenCloseMessagesRepository.findByDate(toDate);
                LOG.info("Records :" + storeOpenCloseMessages);

                    sC = storeOpenCloseProcessingDaysService.bookToResa(storeOpenCloseMessages, sC, sgPosServices);

                    date = date.plusDays(1);
                i++;
            } while (endDate.isAfter(date) || endDate.isEqual(date));
        } else {
LOG.info("From and To date format is wrong ");
            sC.add("FAILED");
        }
        // toDate= storeOpenCloseResaQ.getToDate();
    } else if(null != storeOpenCloseResaQ.getProcessDays() && !storeOpenCloseResaQ.getProcessDays().isEmpty() && storeOpenCloseResaQ.getProcessDays().length()==1){
        String pattern = "[1-9]+";

        boolean matches = Pattern.matches(pattern, storeOpenCloseResaQ.getProcessDays());
        if(matches) {
            LocalDate date = LocalDate.now();
            LocalDate endDate = date.minusDays(Integer.parseInt(storeOpenCloseResaQ.getProcessDays()));
            do {
                toDate = String.valueOf(date);
                LOG.info("Fetching Records from : " + toDate );
                storeOpenCloseMessages = storeOpenCloseMessagesRepository.findByDate(toDate);
                LOG.info("Records :" + storeOpenCloseMessages);
                sC = storeOpenCloseProcessingDaysService.bookToResa(storeOpenCloseMessages, sC, sgPosServices);
                date = date.minusDays(1);
            } while (endDate.isBefore(date));
        }else{
            LOG.info("Process Days accepts only 1-9 as input " );
            sC.add("FAILED");
        }
    }else{
        if(null != storeOpenCloseResaQ.getProcessDays() && storeOpenCloseResaQ.getProcessDays().isEmpty() && storeOpenCloseResaQ.getProcessDays().length()!=1) {
            LOG.info("Process Days is mandatory");
            sC.add("FAILED");
        }else if (null != storeOpenCloseResaQ.getFromDate() && !storeOpenCloseResaQ.getFromDate().isEmpty()) {
            LOG.info(" To date is mandatory");
            sC.add("FAILED");
        }else if ( null != storeOpenCloseResaQ.getToDate() && !storeOpenCloseResaQ.getToDate().isEmpty()) {
            LOG.info("From date is mandatory");
            sC.add("FAILED");
        }else{ LOG.info("From date and To date is mandatory or Process Days mandatory");
            sC.add("FAILED");
        }

    }

    if (sC.contains("FAILED")) {
        storeOpenCloseResaQ.setResponseType("FAILED");
    } else if (sC.contains("SUCCESS") && !sC.contains("FAILED")) {
        storeOpenCloseResaQ.setResponseType("SUCCESS");
    } else {
        storeOpenCloseResaQ.setResponseType("NO_RECORDS");
   // }
}
        return storeOpenCloseResaQ;

       //
    }
    private Date isValidDateTime(String ts) {
        try {
            DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            format.setLenient(false);
            return format.parse(ts);

        } catch (ParseException p) {
            return null;
        }
    }



}
