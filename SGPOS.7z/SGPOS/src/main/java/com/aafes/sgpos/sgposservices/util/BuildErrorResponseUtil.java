package com.aafes.sgpos.sgposservices.util;

import com.aafes.sgpos.sgposservices.Control.SGPOSResponseType;
import com.aafes.sgpos.sgposservices.generated.Control.Response;
import com.aafes.sgpos.sgposservices.generated.Control.SGPOSServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Component
public class BuildErrorResponseUtil {
    @Autowired
    private Environment env;



    public SGPOSServices buildErrorResponseAdd(SGPOSServices sgposservices, String reason) {
        //Error response mapping

        Response response = new Response();
        response.setReasonCode(env.getProperty(reason, String.class));
        response.setReasonDescription(reason);
        if(reason.equalsIgnoreCase("CVS_TIME_OUT")){
            response.setResponse(SGPOSResponseType.TIMEOUT);
        }else if(reason.equalsIgnoreCase("IGLAS_TIME_OUT")){
            response.setResponse(SGPOSResponseType.TIMEOUT);
        }else if(reason.equalsIgnoreCase("ORIS_TIME_OUT")){
            response.setResponse(SGPOSResponseType.TIMEOUT);
        }else if(reason.equalsIgnoreCase("SOC_TIME_OUT")){
            response.setResponse(SGPOSResponseType.TIMEOUT);
        }else if(reason.equalsIgnoreCase("SOA_TIME_OUT")){
            response.setResponse(SGPOSResponseType.TIMEOUT);
        } else if(reason.equalsIgnoreCase("PARTIAL_APPROVED")){
        response.setResponse(SGPOSResponseType.APPROVED);
    }else{
            response.setResponse(SGPOSResponseType.DECLINED);
        }
        sgposservices.setResponse(response);
        sgposservices.setHeader(sgposservices.getHeader());
        return sgposservices;
    }
    public SGPOSServices buildErrorResponseOris(SGPOSServices sgposservices, String reason, String responseCode) {
        //Error response mapping

        Response response = new Response();
        response.setReasonCode(responseCode);
        response.setReasonDescription(reason);
        response.setResponse(SGPOSResponseType.DECLINED);
        sgposservices.setResponse(response);
        sgposservices.setHeader(sgposservices.getHeader());
        return sgposservices;
    }
    public SGPOSServices buildErrorResponseCCD(SGPOSServices sgposservices, String reason, String responseCode) {
        //Error response mapping

        Response response = new Response();
        response.setReasonCode(responseCode);
        response.setReasonDescription(reason);
        response.setResponse(SGPOSResponseType.DECLINED);
        sgposservices.setResponse(response);
        sgposservices.setHeader(sgposservices.getHeader());
        return sgposservices;
    }


    public void setEnv(Environment env) {
        this.env = env;
    }
}
