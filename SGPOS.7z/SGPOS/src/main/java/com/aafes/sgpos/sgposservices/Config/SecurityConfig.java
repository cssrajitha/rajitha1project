package com.aafes.sgpos.sgposservices.Config;



import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

//    @Value("${security.hsts.enabled:false}")
//    private boolean hstsEnabled;

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {


        http
                .csrf(csrf -> csrf.disable())
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/1/sgposservices").permitAll()
                        .requestMatchers("/1/storeopenclosemessages").permitAll()
                        .anyRequest().authenticated());

//        if (hstsEnabled) {
//            http.headers(headers -> headers
//                    .httpStrictTransportSecurity(hsts -> hsts
//                            .includeSuabDomains(true)
//                            .maxAgeInSeconds(31536000)
//                            .preload(true)
//                    )
//            );
//        }

        return http.build();
    }

}

