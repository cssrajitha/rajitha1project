package com.aafes.sgpos.sgposservices.Controller;


import com.aafes.sgpos.sgposservices.Service.OauthValidationService;
import com.aafes.sgpos.sgposservices.Control.OauthResponse;
import com.aafes.sgpos.sgposservices.Control.SGPOSRequestType;
import com.aafes.sgpos.sgposservices.generated.Control.SGPOSServices;
import com.aafes.sgpos.sgposservices.Service.SGPOSServicesservice;
import com.aafes.sgpos.sgposservices.util.BuildErrorResponseUtil;
import com.aafes.sgpos.sgposservices.util.ValidateRequestUtil;
import com.aafes.sgpos.sgposservices.util.ValidateSchemaUtil;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.networknt.schema.JsonSchema;
import com.networknt.schema.JsonSchemaFactory;
import com.networknt.schema.SpecVersion;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.xml.soap.SOAPException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.expression.ParseException;
import org.springframework.web.bind.annotation.*;

import javax.annotation.PostConstruct;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

@RestController
@RequestMapping("/1/sgposservices")
public class SGPOSServicesController {
    //    @Autowired
//    private Environment env;
    private JsonSchema schema;
    private static JsonSchemaFactory schemaFactory;
    private JsonSchema schemaSgPosServices;
    private InputStream schemaStreamSgPos;
    private static final ObjectMapper OBJECT_MAPPER;

    @Autowired
    BuildErrorResponseUtil buildErrorResponseUtil;

    @Autowired
    private SGPOSServicesservice response;
    @Value("${jsonPath.sGPOSServices}")
    private String pathsgpos;

    @Autowired
    OauthValidationService oauthValidation;
    
    ValidateSchemaUtil validateSchemaUtil = new ValidateSchemaUtil();
    ValidateRequestUtil validateRequestUtil =  new ValidateRequestUtil();

    static {
        OBJECT_MAPPER = new ObjectMapper();
        OBJECT_MAPPER.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, false);
        OBJECT_MAPPER.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    @PostConstruct
    public void schemaInit() throws IOException {
        LOG.info("INSIDE schemainit");
        try {
            // String pathsgpos = env.getProperty("jsonPath.sGPOSServices");
            schemaFactory = JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V7);

            schemaStreamSgPos = new BufferedInputStream(new FileInputStream(pathsgpos));

            schemaSgPosServices = schemaFactory.getSchema(schemaStreamSgPos);

            LOG.info("EXITING schemainit");
        } catch (Exception e) {
            LOG.error("Exception occured: " + e);
        } finally {
                schemaStreamSgPos.close();
        }

    }

    private static final Logger LOG = (Logger) LoggerFactory.getLogger(SGPOSServicesController.class);

    private String responseToClient = "";
    private String requestId = "";
    private String applicationId = "";
    private String uuid = "";
    private String userId = "";
    private String requestType = "";
    private String cardType = "";

    @PutMapping
    public SGPOSServices sgPosService(@RequestBody String gatewayRequest, @RequestHeader(value = "Authorization") String autherization, HttpServletResponse responseClient) throws ParseException, JsonProcessingException {
        SGPOSServices sgposservices = new SGPOSServices();
        StringBuilder tempString = new StringBuilder();
        JSONObject request = new JSONObject(gatewayRequest);
        MDC.put("TraceID", request.getJSONObject("header").optString("traceID"));
        LOG.info("From client:" + gatewayRequest.replaceAll("(\"customerID\"\\s*:\\s*\")[0-9]*(\\d{3}\")","$1********$2").replace("\n", "").replace("\r", "").replaceAll("\\s", ""));
        String requestType=null;
        SGPOSServices sgposServicesRequest = null;
        long starTime = System.nanoTime();
        LOG.info("Token received from client ");
        LOG.info("Sending request to oauth " );
        String authToken = null;
        if (null != autherization
                && (autherization.contains("Bearer")
                || autherization.contains("bearer")) ) {

            authToken = autherization.split(" ").length==2?autherization.split(" ")[1]:"";
		//	LOG.info("response from oauth-> " + authToken);
            LOG.info("Response received from oauth:" +authToken);
        }
        OauthResponse oauthResponse = new OauthResponse();
        oauthResponse = oauthValidation.oauthTokenValidation(authToken, request);
        // LOG.info("response from oauth-> " + oauthResponse.getActive()+ oauthResponse.getReasonCode());
        if(null !=oauthResponse.getActive() && oauthResponse.getActive().equalsIgnoreCase("true")) {
            // sgposServicesRequest = buildErrorResponseUtil.buildErrorResponseAdd(sgposServicesRequest, "INVALID_REQUEST");
            try {
                if(!request.isNull("storeOpenCloseRequest")){
                    requestType=request.getJSONObject("storeOpenCloseRequest").optString("requestType");
                }else if(!request.isNull("ORISRequest")){
                    requestType=request.getJSONObject("ORISRequest").optString("requestType");
                }else  if(!request.isNull("CVSRequest")){
                    if(!request.getJSONObject("CVSRequest").optString("requestType").trim().isEmpty()) {
                        requestType = request.getJSONObject("CVSRequest").optString("requestType");
                    }else{
                        requestType= SGPOSRequestType.INQUIRY;
                    }
                }else  if(!request.isNull("IGLASRequest")){
                    requestType=request.getJSONObject("IGLASRequest").optString("functionCode");
                }
                sgposservices = SGPOSservice(gatewayRequest, request);
            } catch (Exception ex) {
                LOG.error("Error from call to SGPOSservices: " + ex);
                sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "INTERNAL_SERVER_ERROR");
               ObjectMapper objectMapper = new ObjectMapper();
               String sgposservicesJSON = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(sgposservices);
                LOG.info("From client:  " +sgposservicesJSON.replace("\n", "").replace("\r", "").replaceAll("\\s", ""));

            }

            long endTime = System.nanoTime();

            long timeElapsed = (endTime - starTime) / 1000000;
            JSONObject response = new JSONObject(sgposservices);
            LOG.info("To client:  " +response);
            LOG.info(tempString.append("Elapsed_Time_SGPOS Services|")
                    .append(request.getJSONObject("header").optString("facilityNumber"))
                    .append("|")
                    .append(request.getJSONObject("header").optString("traceID"))
                    .append("|")
                    .append(request.getJSONObject("header").optString("application"))
                    .append("|")
                    .append(requestType)
                    .append("|")
                    .append(sgposservices.getResponse().getReasonCode())
                    .append("|")
                    .append(sgposservices.getResponse().getReasonDescription())
                    .append("|")
                    .append(sgposservices.getResponse().getResponse())
                    .append("|")
                    .append(timeElapsed)
                    .append(" ms")
                    .toString());
            tempString.setLength(0);
        }else {
            long endTime = System.nanoTime();

            long timeElapsed = (endTime - starTime) / 1000000;

            // Response response =new Response();
            sgposservices.setAdditionalProperty("error_description", "The access token provided is invalid.");
            sgposservices.setAdditionalProperty("error", "invalid_token");
            // sgposservices.setHeader(sgposservices.getHeader());
            //sgposservices.setResponse(response);
            LOG.info(tempString.append("Elapsed_Time_OAuth|")
                    .append(requestType)
                    .append("|")
                    .append("invalid_token")
                    .append("|")
                    .append("The access token provided is invalid.")
                    .append("|")
                    .append(timeElapsed)
                    .append(" ms")
                    .toString());
            tempString.setLength(0);
            responseClient.setStatus(401);
        }MDC.clear();
        return sgposservices;
    }

    public SGPOSServices SGPOSservice(String gatewayRequest, JSONObject request) throws IOException, java.text.ParseException, InterruptedException,  org.json.simple.parser.ParseException, SOAPException {
        String validationResponse = "";
        String requestValidationError = "";
        SGPOSServices sgposServices = new SGPOSServices();
        try {

//            if(!request.isNull("header")){
//                sgposServices.setHeader(request.getJSONObject("header"));
//            }
            OBJECT_MAPPER.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true);
            sgposServices = OBJECT_MAPPER.readValue(gatewayRequest, SGPOSServices.class);
            if (null != sgposServices) {
                validationResponse = validateSchemaUtil.validateJsonRequest(gatewayRequest, schemaSgPosServices, request);
            } else {
                validationResponse = "Failed to process request";
            }
        } catch (Exception e) {
            LOG.error("Exception in JSON request validation: " + e.getMessage());
            //  requestId = StringUtils.substringBetween(gatewayRequest.replaceAll(" ", ""), "\"" + "requestid".trim() + "\":\"", "\",");
            validationResponse = "Failed to process request";
        }
        if (validationResponse == null || validationResponse.isEmpty()) {
            requestValidationError = validateRequestUtil.validateFieldsAdd(sgposServices);
            if (requestValidationError.isEmpty()) {
                ObjectMapper mapper = new ObjectMapper();
                mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
                String json = mapper.writeValueAsString(sgposServices);

               // LOG.info("SGPOS services Request" + json.replace("\n", "").replace("\r", "").replaceAll("\\s", ""));
                LOG.debug("SGPOS services Request" + json);
                response.Response(sgposServices);
            } else {
                LOG.info("RequestValidationError: " + requestValidationError );
                sgposServices = buildErrorResponseUtil.buildErrorResponseAdd(sgposServices, requestValidationError);
            }
        } else {
            LOG.info("Schema Validation of request from client has failed. Error: " + validationResponse );
            sgposServices = buildErrorResponseUtil.buildErrorResponseAdd(sgposServices, "INVALID_REQUEST");
        }
        if (sgposServices != null) {
            sgposServices.setORISRequest(null);
            sgposServices.setIGLASRequest(null);
            sgposServices.setCVSRequest(null);
            sgposServices.setStoreOpenCloseRequest(null);
        }
        return sgposServices;
    }

//    public Environment getEnv() {
//        return env;
//    }
//
//    public void setEnv(Environment env) {
//        this.env = env;
//    }


    public BuildErrorResponseUtil getBuildErrorResponseUtil() {
        return buildErrorResponseUtil;
    }

    public void setBuildErrorResponseUtil(BuildErrorResponseUtil buildErrorResponseUtil) {
        this.buildErrorResponseUtil = buildErrorResponseUtil;
    }

    public void setValidateSchemaUtil(ValidateSchemaUtil validateSchemaUtil) {
        this.validateSchemaUtil = validateSchemaUtil;
    }

    public void setValidateRequestUtil(ValidateRequestUtil validateRequestUtil) {
        this.validateRequestUtil = validateRequestUtil;
    }

    public void setSchemaAdd(JsonSchema schemaAdd) {
        this.schema = schemaAdd;
    }
    public static String maskNumber(String number) {
        String maskednumber ="";
        if(number != null && !number.trim().isEmpty()){
            int index = 0;
            StringBuilder masked = new StringBuilder();
            for (int i = 0; i < number.length(); i++) {
                //  char c = mask.charAt(i);
//                if (c == '#') {
//                    masked.append(number.charAt(index));
//                    index++;
//                } else if (c == 'x') {
//                    masked.append(c);
//                    index++;
//                } else {
                masked.append('x');
                // }
            }
            maskednumber = masked.toString();
        }
        return maskednumber;
    }

}
