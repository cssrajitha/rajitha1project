package com.aafes.sgpos.sgposservices.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.networknt.schema.JsonSchema;
import com.networknt.schema.ValidationMessage;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Set;


public class ValidateSchemaUtil {
    private static final Logger LOG = (Logger) LoggerFactory.getLogger(ValidateSchemaUtil.class);

    public String validateJsonRequest(String jsonReq, JsonSchema schema, JSONObject sgPosServices) {

        ObjectMapper objectMapper = new ObjectMapper();   StringBuilder validationMsg = null;
        try {
              JsonNode json = objectMapper.readTree(jsonReq);
          Set<ValidationMessage> validationResult = schema.validate(json);
            if (validationResult.isEmpty()) {
                LOG.info("No schema validation errors ");
            } else {
                validationMsg = new StringBuilder();
                for (ValidationMessage vm : validationResult) {
                    if (validationMsg.length() == 0) {
                        validationMsg.append(vm.getMessage());
                    } else {
                        validationMsg.append(", ").append(vm.getMessage());
                    }
                }
                LOG.info("Validation errors: " + validationMsg.toString());
            }
        } catch (Exception e) {
            LOG.error("Exception occurred: ", e);
            validationMsg = new StringBuilder(e.toString());
        }
        if (null == validationMsg) {
            return null;
        } else return validationMsg.toString();
    }

}
