package com.aafes.sgpos.sgposservices.Config;

import jakarta.annotation.Nonnull;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.cassandra.config.AbstractCassandraConfiguration;
import org.springframework.data.cassandra.config.CqlSessionFactoryBean ;
import org.springframework.data.cassandra.repository.config.EnableCassandraRepositories;


import java.io.File;

@Configuration
@EnableCassandraRepositories("com.aafes.sgpos.sgposservices.Repository")
public class CassandraConfig extends AbstractCassandraConfiguration {

    private static final Logger LOG = (Logger) LoggerFactory.getLogger(CassandraConfig.class);
    @Value("${spring.data.cassandra.keyspace-name}")
    protected String keyspaceName;

    @Value("${spring.data.cassandra.contact-points}")
    protected String cassandraHost;

    @Value("${spring.data.cassandra.port}")
    protected String port;

    @Value("${spring.data.cassandra.username}")
    protected String userName;

    @Value("${spring.data.cassandra.password}")
    protected String password;

    @Value("${spring.data.cassandra.consistency-level}")
    protected String consistencyLevel;
    @Value("${spring.data.cassandra.local-datacenter}")
    protected String localdataCenter;

    @Value("${cryptoKeysDir}")
    protected String baseDir;

    @Value("${spring.data.cassandra.retry-time}")
    protected long retryTime;

    @Autowired
    EncryptorConfig encryptorConfig;

    @PostConstruct
    public void init() {
        cassandraHost = cassandraHost.replace(" ","");
        LOG.info(" keyspaceName :" + keyspaceName);
        LOG.info(" cassandraHost :" + cassandraHost);
        LOG.info(" port :" + port);
        LOG.info(" userName :" + userName);
        LOG.info(" password :" + password);
    }

    @Override
    protected String getKeyspaceName() {
        return keyspaceName;
    }

    @Override
    public String getContactPoints() {
        return cassandraHost;
    }

    @Override
    public String[] getEntityBasePackages() {
        return new String[]{"com.aafes.sgpos.sgposservices.Entity"};
    }

    @Bean
    @Nonnull
    @Override
    public CqlSessionFactoryBean  cassandraSession() {
        LOG.info("Connecting to Cassandra");
        //This method creates a cluster for cassandra database
        CqlSessionFactoryBean  sessionFactory = super.cassandraSession();;
        sessionFactory.setContactPoints(cassandraHost);
        decryptValues();
        LOG.info("Values from properties file : port " + port + ", userName " + userName);
        sessionFactory.setPort(Integer.parseInt(port));
        sessionFactory.setUsername(userName);
        sessionFactory.setPassword(password);
        sessionFactory.setLocalDatacenter(localdataCenter);
        sessionFactory.setKeyspaceName(keyspaceName);
        return sessionFactory;
    }

    public void decryptValues() {
        LOG.info("Values from properties file : baseDir " + baseDir);
        String keysPath = baseDir + File.separator + "crypto" + File.separator + "keys";
        String logPath = baseDir + File.separator + "crypto.log4j.properties";

        //EncryptorConfig encryptor = new EncryptorConfig(keysPath, logPath);
        try {
            userName = encryptorConfig.decrypt(userName);
            password = encryptorConfig.decrypt(password);
        } catch (Exception e) {
            LOG.error("Exception occurred during decryption of cassandra details",e);
        }
    }
}

