package com.aafes.sgpos.sgposservices.Gateway;
import com.aafes.sgpos.sgposservices.Config.EncryptorConfig;
import com.aafes.sgpos.sgposservices.generated.Control.SGPOSServices;
import com.ibm.mq.MQC;
import com.ibm.mq.headers.MQCIH;
import com.ibm.mq.headers.MQHeader;
import jakarta.jms.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsOperations;
import org.springframework.jms.core.MessageCreator;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;

import static com.ibm.mq.constants.CMQC.*;
import static com.ibm.mq.constants.CMQC.MQAT_JAVA;


@Component("sgposmq")
public class MQMessage {

    private static final Logger LOG = LoggerFactory.getLogger(MQMessage.class);

    @Autowired
    @Qualifier("jmsTemplateQM1")
    private JmsOperations jmsOperations;

//    @Autowired
//    @Qualifier("jmsTemplateQM1")
//    private JmsTemplate jmsTemplate;

    @Value("${spring.jms.ibm.mq.queue-manager-1.requestQ}")
    private String destinationName;

    @Value("${spring.jms.ibm.mq.queue-manager-1.responseQ}")
    private String replyToQ;

    @Value("${spring.jms.ibm.mq.queue-manager-1.cicsMQFunc}")
    private String cicsMQFunc;

    @Value("${spring.jms.ibm.mq.queue-manager-1.qPassword}")
    private String qPassword;
    @Value("${spring.jms.ibm.mq.queue-manager-1.setTransId}")
    private String setTransId;

    @Value("${spring.jms.ibm.mq.queue-manager-1.qUser}")
    private String qUser;
    @Value("${spring.jms.ibm.mq.queue-manager-1.qManagerName}")
    private String qManagerName;

    @Value("${spring.jms.ibm.mq.queue-manager-1.cicsMQProgName}")
    private String cicsMQProgName;

    @Autowired
    EncryptorConfig encryptorConfig;

    @SendTo
    public Message sendMessageQue(String message, String correlationId, SGPOSServices sgPosServices){
        final String payload = message;
        String traceID = sgPosServices.getHeader().getTraceID();
        jmsOperations.send("queue:///"+destinationName+"?targetClient=1&mdMessageContext=1&mdWriteEnabled=true", new MessageCreator() {
            @Override
            public Message createMessage(Session session) throws JMSException {
                Destination destination = session.createQueue(replyToQ);
                BytesMessage message = session.createBytesMessage();
                MQCIH cih = new MQCIH();
                cih.setVersion(2);
                cih.setFunction(cicsMQFunc);
                cih.setAuthenticator(encryptorConfig.decrypt(qPassword));
                cih.setTransactionId(setTransId);
                cih.setUOWControl(MQCUOWC_ONLY);
                cih.setFlags(MQCIH_REPLY_WITHOUT_NULLS | MQCIH_PASS_EXPIRATION
                        | MQCIH_SYNC_ON_RETURN);
                cih.setReplyToFormat(MQFMT_NONE);
                cih.setFormat(MQFMT_NONE);
                cih.setLinkType(1);
                cih.setOutputDataLength(1600);

                MQHeader header = cih;

                ByteArrayOutputStream out = new ByteArrayOutputStream();
                try {
                    header.write(new DataOutputStream(out));
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                byte[] hd = out.toByteArray();

                message.setStringProperty("JMS_IBM_Format", MQFMT_CICS); //Struc Length v1=164 v2=180

                //  bm.setStringProperty("JMS_IBM_Format", MQFMT_CICS);   //Struc Length v1=164 v2=180
                message.setStringProperty("JMS_IBM_MQMD_UserIdentifier", qUser);
                message.setStringProperty("JMS_IBM_MQMD_ReplyToQ", replyToQ);
                message.setStringProperty("JMS_IBM_MQMD_ReplyToQMgr", qManagerName);

                message.setIntProperty("JMS_IBM_Character_Set", 1208);
                message.setIntProperty("JMS_IBM_MQMD_Priority", 0);
                message.setIntProperty("JMS_IBM_MQMD_Expiry", 10000);
                message.setIntProperty("JMS_IBM_MQMD_Persistence",
                        MQPER_NOT_PERSISTENT);
                message.setObjectProperty("JMS_IBM_MQMD_CorrelId",
                        MQC.MQCI_NEW_SESSION);
                message.setIntProperty("JMS_IBM_MsgType", MQC.MQMT_REQUEST);

                message.setObjectProperty("JMS_IBM_MQMD_MsgId", correlationId.
                        getBytes());
                message.setIntProperty("JMS_IBM_MQMD_Report",
                        MQRO_COPY_MSG_ID_TO_CORREL_ID);
                message.setIntProperty("JMS_IBM_MQMD_PutApplType", MQAT_JAVA);

                message.writeBytes(hd);
                //  String cicsMQProgName = cicsMQProgName;
                try {
                    message.writeBytes(cicsMQProgName.getBytes("CP500"));
                } catch (UnsupportedEncodingException e) {
                    throw new RuntimeException(e);
                }
               // String correlationid= Arrays.toString(correlationId.getBytes());

                message.setJMSCorrelationID(correlationId);
                message.setJMSMessageID(correlationId);
                message.writeBytes(" 1208".getBytes());
                message.writeUTF(payload);
                message.setJMSReplyTo(destination);
               // LOG.info(message.toString());

                LOG.info("[{}] message placed in {} Queue: ",correlationId,destinationName);
                return message;
            }


    });
        String hexCorrelationID = String.format("%024x", new BigInteger(1,
                correlationId.substring(0, 24).getBytes()));

        String messageSelector = "JMSCorrelationID='ID:" + hexCorrelationID + "'";
        LOG.info(messageSelector);
        Message message1 = jmsOperations.receiveSelected("queue:///"+replyToQ, messageSelector);
       // LOG.info(String.valueOf(message1));
        return message1;
    }
    //this is for working example for jmslisntner
//    @JmsListener(destination = "MQT2.STARGATE.RESPONSE")
//    public void receiveMessage(Message response) {
//        LOG.info(String.valueOf(response));
//    }
}
