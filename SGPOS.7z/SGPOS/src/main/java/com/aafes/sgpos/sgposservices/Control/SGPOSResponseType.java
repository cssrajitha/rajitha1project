package com.aafes.sgpos.sgposservices.Control;

final public class SGPOSResponseType {
    public static final String APPROVED = "Approved";
    public static final String DECLINED = "Decline";
    public static final String TIMEOUT = "TIMEOUT";
}
