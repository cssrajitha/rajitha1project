package com.aafes.sgpos.sgposservices.Control;

public class storeOpenCloseMessagesStatus {
private String msgSendDateTime;
private String facilityNumber;
    private String storeStatus;
    private String dateAndTimeStamp;

    public String getMsgSendDateTime() {
        return msgSendDateTime;
    }

    public void setMsgSendDateTime(String msgSendDateTime) {
        this.msgSendDateTime = msgSendDateTime;
    }

    public String getFacilityNumber() {
        return facilityNumber;
    }

    public void setFacilityNumber(String facilityNumber) {
        this.facilityNumber = facilityNumber;
    }

    public String getStoreStatus() {
        return storeStatus;
    }

    public void setStoreStatus(String storeStatus) {
        this.storeStatus = storeStatus;
    }

    public String getDateAndTimeStamp() {
        return dateAndTimeStamp;
    }

    public void setDateAndTimeStamp(String dateAndTimeStamp) {
        this.dateAndTimeStamp = dateAndTimeStamp;
    }

    @Override
    public String toString() {
        return "ResaBooking{" +
                "msgSendDateTime='" + msgSendDateTime + '\'' +
                ", facilityNumber='" + facilityNumber + '\'' +
                ", storeStatus='" + storeStatus + '\'' +
                ", dateAndTimeStamp='" + dateAndTimeStamp + '\'' +
                '}';
    }
}
