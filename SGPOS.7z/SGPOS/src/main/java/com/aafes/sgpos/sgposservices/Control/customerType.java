package com.aafes.sgpos.sgposservices.Control;

public class customerType {

    public static final String EDIPI = "EDIPI";
    public static final String CID = "CID";
    public static final String SSN = "SSN";
    public static final String FOREIGNID = "FOREIGNID";




}
