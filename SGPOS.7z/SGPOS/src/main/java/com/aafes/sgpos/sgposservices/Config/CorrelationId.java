package com.aafes.sgpos.sgposservices.Config;

import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.UUID;

/**
 *
 * @author sriramm
 */
public class CorrelationId {
    static final DecimalFormat TIME_FORMAT = new DecimalFormat("0000;0000");
    public static byte[] getCorrelationIDWithCalendar() {
        Calendar cal = Calendar.getInstance();
        String val = String.valueOf(cal.get(Calendar.YEAR));
        val += TIME_FORMAT.format(cal.get(Calendar.DAY_OF_YEAR));
        val += UUID.randomUUID().toString().replaceAll("-", "");
        return val.substring(0, 24).getBytes();
    }

}

