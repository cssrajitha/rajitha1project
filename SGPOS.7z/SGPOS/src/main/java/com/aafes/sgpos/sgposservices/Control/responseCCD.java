package com.aafes.sgpos.sgposservices.Control;

public class responseCCD {
    private String respStatus;
    private String respMessage;
    private String DODEDIPersonalId;
    private Object Customer;

    public String getRespStatus() {
        return respStatus;
    }

    public void setRespStatus(String respStatus) {
        this.respStatus = respStatus;
    }

    public String getRespMessage() {
        return respMessage;
    }

    public void setRespMessage(String respMessage) {
        this.respMessage = respMessage;
    }

    public String getDODEDIPersonalId() {
        return DODEDIPersonalId;
    }

    public void setDODEDIPersonalId(String DODEDIPersonalId) {
        this.DODEDIPersonalId = DODEDIPersonalId;
    }

    public Object getCustomer() {
        return Customer;
    }

    public void setCustomer(Object customer) {
        Customer = customer;
    }

    @Override
    public String toString() {
        return "response{" +
                "respStatus='" + respStatus + '\'' +
                ", respMessage='" + respMessage + '\'' +
                ", DODEDIPersonalId='" + DODEDIPersonalId + '\'' +
                ", Customer=" + Customer +
                '}';
    }
}


