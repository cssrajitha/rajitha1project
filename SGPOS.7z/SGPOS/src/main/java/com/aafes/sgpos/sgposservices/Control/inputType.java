package com.aafes.sgpos.sgposservices.Control;

public class inputType {
    public static final String SWIPED = "Swiped";
    public static final String KEYED = "Keyed";
    public static final String SCANNED = "Scanned";


}
