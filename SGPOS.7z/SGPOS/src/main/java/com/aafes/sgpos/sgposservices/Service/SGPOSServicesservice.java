package com.aafes.sgpos.sgposservices.Service;

import com.aafes.sgpos.sgposservices.Config.OrisValidation;
import com.aafes.sgpos.sgposservices.Exception.GatewayException;
import com.aafes.sgpos.sgposservices.Gateway.*;
import com.aafes.sgpos.sgposservices.Repository.FacilityRepo;
import com.aafes.sgpos.sgposservices.Config.EncryptorConfig;
import com.aafes.sgpos.sgposservices.Config.WalkerResponse;
import com.aafes.sgpos.sgposservices.Control.SGPOSRequestType;
import com.aafes.sgpos.sgposservices.Control.SGPOSResponseType;
import com.aafes.sgpos.sgposservices.Control.customerType;
import com.aafes.sgpos.sgposservices.Entity.fac_fmf;
import com.aafes.sgpos.sgposservices.Control.tranCode;
import com.aafes.sgpos.sgposservices.Repository.storeOpenCloseMessagesRepository;
import com.aafes.sgpos.sgposservices.generated.Control.Response;
import com.aafes.sgpos.sgposservices.generated.Control.SGPOSServices;
import com.aafes.sgpos.sgposservices.util.BuildErrorResponseUtil;
import com.aafes.sgpos.sgposservices.walkerinterface.*;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.xml.soap.SOAPException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;

@Service
public class SGPOSServicesservice {

    private static final Logger LOG = (Logger) LoggerFactory.getLogger(SGPOSServicesservice.class);
    @Autowired
    private FacilityRepo facilityrepo;

    @Autowired
    BuildErrorResponseUtil buildErrorResponseUtil;


    @Value("${APPROVED}")
    private String approved;
    @Value("${jsonPath.reasonCode}")
    private String reasonCode;
    @Value("${jsonPath.reasonCodeIGLAS}")
    private String reasonCodeIGLAS;
    @Value("${jsonPath.reasonCodeIDCHECK}")
    private String reasonCodeIDCHECK;
    @Autowired
    private storeOpenCloseMessagesRepository resaQueueRepository;

    @Autowired
    private MQService mqConnection;

    @Autowired
    private ccdVerificationIGLAS ccdVerIGLAS;

    @Autowired
    orisVerification OrisVerification;
    @Autowired
    private ccdVerificationCVS ccdVerCVS;
    @Autowired
    private ccdVerificationIDCHECK ccdVerIDCHECK;
    @Autowired
    EncryptorConfig encryptorConfig;

    @Autowired
    ResaMessages resaGatewayBean;
    ConnectToWalkerResponse walkerResponse;
    LogOffWalkerResponse logOffWalkerResponse;
    ApplyTXNResponse applyTXNResponse;
    @Autowired
    private WalkerResponse walkerresponse;
    @Autowired
    OrisValidation orisValidation;



    public SGPOSServices Response(SGPOSServices sgposservices) throws InterruptedException, IOException, SOAPException, ParseException {
        List<fac_fmf> facility;
        String customerName = null;
        String LQ1SplitTender = null;
        String LQ0InvoiceNbr = null;
        boolean dateTime = tryParse(sgposservices.getHeader().getLocalDateTime());
        if (!dateTime) {
            LOG.info("Validation of localDateTime has failed. Error:  please enter correct localDateTime formate yymmddhhmmss " );
            sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "INVALID_REQUEST");

        }


        if (sgposservices.getHeader().getFacilityNumber().trim().isEmpty()) {
            LOG.info("Validation of Facility Number has failed. Error:  Facility Number Cannot Be Empty ");
            sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "INVALID_REQUEST");
        }
        //oris fields validation for preauth and final auth
        if (null != sgposservices.getORISRequest()) {
            sgposservices = orisValidation.emptyCheck(sgposservices);
        }
        if (null == sgposservices.getResponse()) {
            facility = facilityrepo.findByFacility(sgposservices.getHeader().getFacilityNumber());
/// Facility check for all requests (store open and close, oris, cvs, iglas)
            if (null != facility && !facility.isEmpty()) {
                LOG.info("Facility found: ");
                if (null != sgposservices.getCVSRequest() || null != sgposservices.getIGLASRequest()) {
                    sgposservices = this.CvsIglasResponse(sgposservices);
                   // LOG.info("Received response from IGLAS");
                } else if (null != sgposservices.getIDCheckRequest()){
                    sgposservices = this.IdCheckResponse(sgposservices);
                }
                else if (null != sgposservices.getStoreOpenCloseRequest()) {
                    if (sgposservices.getStoreOpenCloseRequest().getRequestType().equalsIgnoreCase(SGPOSRequestType.STOREOPEN)) {
                        this.posResponse(sgposservices, facility, customerName, LQ1SplitTender, LQ0InvoiceNbr);
                        LOG.info("Sending request to resaQ: " );
                        resaGatewayBean.bookToResa(sgposservices);
                       // sgposservices.setStoreOpenCloseRequest(null);
                    } else if (sgposservices.getStoreOpenCloseRequest().getRequestType().equalsIgnoreCase(SGPOSRequestType.STORECLOSE)) {
                        //if wanted to remove the soap call(EOD transaction) from store close uncomment next line
                        // this.posResponse(sgposservices, facility, customerName, LQ1SplitTender, LQ0InvoiceNbr);
                        //if wanted to remove the soap call(EOD transaction) from store close comment next line
                        LOG.info("Sending request to resaQ: " );
                        resaGatewayBean.bookToResa(sgposservices);
                        LOG.info("Sending request to ORIS EOD Message: " );
                        sgposservices = this.socOris(sgposservices, facility);

                       // sgposservices.setStoreOpenCloseRequest(null);
                    } else {
                        LOG.info("Validation of request type has failed. Error->  Request type not found -> " + sgposservices.getStoreOpenCloseRequest().getRequestType());
                        sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "INVALID_REQUEST");
                    }
                } else if (null != sgposservices.getORISRequest()) {
                    if (sgposservices.getORISRequest().getRequestType().equalsIgnoreCase(SGPOSRequestType.PREAUTH)
                            || sgposservices.getORISRequest().getRequestType().equalsIgnoreCase(SGPOSRequestType.FINALAUTH)) {
                        LOG.info("Sending request to ORIS" );
                        sgposservices = this.socOris(sgposservices, facility);
                    } else {
                        LOG.info("Validation of request type has failed. Error->  Request type not found -> " + sgposservices.getStoreOpenCloseRequest().getRequestType());
                        sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "INVALID_REQUEST");
                    }
                }
            } else {
                LOG.info("Validation of Facility Number has failed. Error->  Facility Number not found -> " + sgposservices.getHeader().getFacilityNumber()  );
                sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "FACILITY_NOT_FOUND");

            }
        }
        //  LOG.info("SGPOS services Response :" +String.valueOf(sgposservices));
        return sgposservices;
    }

    public SGPOSServices socOris(SGPOSServices sgposservices, List<fac_fmf> facility) throws JsonProcessingException {
        String customerName = null;
        String LQ1SplitTender = null;
        String LQ0InvoiceNbr = null;
        //sign in oris(soap call)
        walkerResponse = OrisVerification.login(sgposservices);
        //ApplyTXN request oris(soap call)
        if (null == sgposservices.getResponse()) {
            if (null != walkerResponse && walkerResponse.getConnectToWalkerResult().getStatus().equalsIgnoreCase("OK")) {
                applyTXNResponse = OrisVerification.applyTXN(walkerResponse, sgposservices, facility);

                if (null != applyTXNResponse) {
                    String encodedHtmlResponse = new String(applyTXNResponse.getApplyTXNResult().getEncodedHtmlResponse());
               //  LOG.info("encodedHtmlResponse"+encodedHtmlResponse);
                    LOG.debug("encodedHtmlResponse"+encodedHtmlResponse);

                    String decodedString = encodedHtmlResponse;
                    // LOG.info("decodedString"+decodedString);
                    //getting values from encoded string oris(soap call)
                    if (null != applyTXNResponse && applyTXNResponse.getApplyTXNResult().getStatus().equalsIgnoreCase("OK")) {
                        if (null != sgposservices.getORISRequest() && (sgposservices.getORISRequest().getRequestType().equalsIgnoreCase(SGPOSRequestType.PREAUTH))) {
                            String arrCN[] = decodedString.split("LQ1CustName");
                            String arrCN1[] = arrCN[1].split("\"");
                            customerName = arrCN1[1];
                            LOG.info("Customer name:" + customerName);
                            String LQ1SplitTenderarr[] = decodedString.split("LQ1SplitTender");
                            String LQ1SplitTenderarr1[] = LQ1SplitTenderarr[1].split("\"");
                            LQ1SplitTender = LQ1SplitTenderarr1[1];
                            LOG.info("SplitTender: " + LQ1SplitTender+": " );
                        } else if (null != sgposservices.getORISRequest() && (sgposservices.getORISRequest().getRequestType().equalsIgnoreCase(SGPOSRequestType.FINALAUTH))) {
                            String arrIN[] = decodedString.split("LQ0InvoiceNbr ");
                            String arrIN1[] = arrIN[1].split("\"");
                            LQ0InvoiceNbr = arrIN1[1];
                            LOG.info("Invoice Number: " + LQ0InvoiceNbr);
                        }
                    } else if (null == applyTXNResponse) {
                        if (null != sgposservices.getStoreOpenCloseRequest()) {
                            LOG.info("Store Close Connection time out" );
                            sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "SOC_TIME_OUT");
                        } else if (null != sgposservices.getORISRequest()) {
                            LOG.info("ORIS Connection time out " );
                            sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "ORIS_TIME_OUT");
                        }
                }else {
                        String arrIN[] = decodedString.split("javascript:wfErrMsg");
                        String arrIN1[] = arrIN[2].split(">");
                        String arrIN4[] = arrIN1[1].split("<");
                        String errorDesc = arrIN4[0];
                    if(errorDesc.trim().equalsIgnoreCase("MUST BE")){
                        errorDesc=errorDesc+" > 0";
                        }
                        //  LOG.info("Invoice Number: " + errorDesc);
                        String arrIN2[] = decodedString.split("\"javascript:wfErrHelp");
                        String arrIN3[] = arrIN2[1].split("\'");
                        String reasonCode = "P" + arrIN3[1].substring(arrIN3[1].length() - 3).trim();
                        LOG.info("Reason Code: " + reasonCode);
                        LOG.info("Received response from ORIS: Soap Request Failed with  -> " + errorDesc );
                        sgposservices = buildErrorResponseUtil.buildErrorResponseOris(sgposservices, errorDesc, reasonCode);

                    }
                } else {
                    if (null != sgposservices.getStoreOpenCloseRequest()) {
                        LOG.info("Store Close Failed " );
                        sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "SOC_SERVER_ERROR");
                    } else if (null != sgposservices.getORISRequest()) {
                        LOG.info("ORIS Connection Failed " );
                        sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "ORIS_SERVER_ERROR");
                    }
                }
            }else{
                if (null != sgposservices.getStoreOpenCloseRequest()) {
                    LOG.info("Store Close Connection time out ");
                    sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "SOC_TIME_OUT");
                } else if (null != sgposservices.getORISRequest()) {
                    LOG.info("ORIS Connection time out " );
                    sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "ORIS_TIME_OUT");
                }
            }
        }
        if (null == sgposservices.getResponse()) {
            if (null != applyTXNResponse && applyTXNResponse.getApplyTXNResult().getStatus().equalsIgnoreCase("OK")) {
                //Log off oris(soap call)
                logOffWalkerResponse = OrisVerification.loggOff(applyTXNResponse, sgposservices);
            }
        }
        if (null == sgposservices.getResponse()) {
            if (null != logOffWalkerResponse && logOffWalkerResponse.getLogOffWalkerResult().getStatus().equalsIgnoreCase("OK")) {
                //response send back to pos
                this.posResponse(sgposservices, facility, customerName, LQ1SplitTender, LQ0InvoiceNbr);
               // sgposservices.setStoreOpenCloseRequest(null);
            }else{
                if (null != sgposservices.getStoreOpenCloseRequest()) {
                    LOG.info("Store Close Connection time out " );
                    sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "SOC_TIME_OUT");
                } else if (null != sgposservices.getORISRequest()) {
                    LOG.info("ORIS Connection time out " );
                    sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "ORIS_TIME_OUT");
                }
            }
        }
        LOG.info(" Received response from ORIS " );
        return sgposservices;
    }


    //response send back to POS
    public SGPOSServices posResponse(SGPOSServices sgposservices, List<fac_fmf> facility, String customerName, String LQ1SplitTender, String LQ0InvoiceNbr) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        Response response = new Response();
        if (null != sgposservices.getORISRequest() && sgposservices.getORISRequest().getRequestType().equalsIgnoreCase(SGPOSRequestType.PREAUTH)) {
            response.setRequestType(sgposservices.getORISRequest().getRequestType());
            response.setBusinessDateTime(sgposservices.getORISRequest().getBusinessDate());
            response.setCashierID(sgposservices.getORISRequest().getCashierID());
            response.setCustomerID(sgposservices.getORISRequest().getCustomerID());
            response.setAmount(sgposservices.getORISRequest().getAmount().trim());
            response.setFacilityNumber(facility.get(0).getFAC_NUM10());
            response.setCustomerName(customerName);
            response.setSplitTenderInd(LQ1SplitTender);
            response.setFacManagerName(facility.get(0).getFAC_MGR());
            response.setFacPhoneNum(facility.get(0).getPHONE_NUM());
        }
        if (null != sgposservices.getORISRequest() && sgposservices.getORISRequest().getRequestType().equalsIgnoreCase(SGPOSRequestType.FINALAUTH)) {
            response.setInvoiceNumber(LQ0InvoiceNbr);
        }
        response.setReasonCode(approved);
        response.setReasonDescription("Approved");
        response.setResponse(SGPOSResponseType.APPROVED);
        sgposservices.setResponse(response);
        sgposservices.setHeader(sgposservices.getHeader());
        //sgposservices.setStoreOpenCloseRequest(null);
        sgposservices.setORISRequest(null);
        // LOG.info("SGPOS services Response" + sgposservices.getHeader() + response);
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        String json = mapper.writeValueAsString(sgposservices);
        LOG.debug("SGPOS services Response" + json);
    //    LOG.info("Received response from SGPOS services, Trace Id:" + sgposservices.getHeader().getTraceID());
        //sgposservices.setStoreOpenCloseRequest(null);
        sgposservices.setORISRequest(null);
        return sgposservices;
    }

    //trafficCOP request and response
    public SGPOSServices CvsIglasResponse(SGPOSServices sgposservices) throws IOException, ParseException, ParseException {
        ObjectMapper mapper = new ObjectMapper();
        String request = null;
        String functionCode = null;
        String cashBackRequestedAmount = null;
        String customerID = null;
        String swipeKey = null;
        String requestAdditional = null;
        //  MQConnection mqConnection = new MQConnection();

        if (null != sgposservices.getCVSRequest()) {
            Boolean customerTypeSSN = false;
            if (sgposservices.getCVSRequest().getCustomerType().toString().equalsIgnoreCase(customerType.SSN)) {
                if (sgposservices.getCVSRequest().getCustomerID().length() == 9) {
                    customerTypeSSN = true;
                } else {
                    customerTypeSSN = false;
                }
            } else {
                customerTypeSSN = true;
            }
            if (customerTypeSSN == true) {
                //  ccdVerificationCVS ccdVer = new ccdVerificationCVS();
                JSONObject ccdRes = new JSONObject();
                try {
                    if (sgposservices.getCVSRequest().getCustomerType().toString().equalsIgnoreCase(customerType.SSN)) {
                        try {
                            ccdRes = ccdVerCVS.CCDCall(sgposservices);

                        } catch (GatewayException | ResourceAccessException | IOException | HttpClientErrorException e) {
                            LOG.error(e.getMessage());
                            LOG.info("CCD Down  " );

                            ccdRes.put("ccdCall", true);
                            ccdRes.put("ssn", sgposservices.getCVSRequest().getCustomerID());

                        }
                    } else {
                        ccdRes = ccdVerCVS.CCDCall(sgposservices);

                    }
                    JSONParser jsonParser = new JSONParser();
                    FileReader reader = new FileReader(reasonCode);
                    JSONArray obj = (JSONArray) jsonParser.parse(reader);
                    if (ccdRes.get("ccdCall").equals(true)) {
                        if (String.valueOf(sgposservices.getCVSRequest().getRequestType()).equalsIgnoreCase(SGPOSRequestType.OVERRIDE)) {
                            functionCode = "O";
                        } else if (String.valueOf(sgposservices.getCVSRequest().getRequestType()).equalsIgnoreCase(SGPOSRequestType.TRN_CANCEL)) {
                            functionCode = "V";
                        } else {
                            functionCode = "I";
                        }
                        if (sgposservices.getCVSRequest().getCashbackRequestedAmount().trim().isEmpty()) {
                            cashBackRequestedAmount = "0";
                        } else {
                            cashBackRequestedAmount = sgposservices.getCVSRequest().getCashbackRequestedAmount();
                        }
                        if (String.valueOf(sgposservices.getCVSRequest().getCustomerType()).equalsIgnoreCase(customerType.SSN)) {
                            customerID = (String) ccdRes.get("ssn");
                            if (null != customerID) {
                                int customerIDSSN = Integer.parseInt(customerID);
                                if (customerID.length() < 9) {
                                    customerID = String.format("%09d", customerIDSSN);
                                }
                            } else {
                                customerID = sgposservices.getCVSRequest().getCustomerID();
                            }
                        } else {
                            customerID = (String) ccdRes.get("ssn");
                            int customerIDSSN = Integer.parseInt(customerID);
                            if (customerID.length() < 9) {
                                customerID = String.format("%09d", customerIDSSN);
                            }
                        }
                        request = "  4" + customerID + ":" + cashBackRequestedAmount
                                + ":" + functionCode + "/\u0003";
                        StringBuilder A = new StringBuilder(request);
                        A.replace(3, request.indexOf(":") - 4, "xxxxxxx");
                        StringBuilder CVSIglasRequest = new StringBuilder(request);
                        CVSIglasRequest.replace(3, request.indexOf(":") - 3, "xxxxxxx");
                        LOG.info(("CVSIglas Request:" +String.valueOf(CVSIglasRequest)));
                        String responseCVS = null;

                        try {
                            responseCVS = mqConnection.mqConnection(request, sgposservices);
                            // System.out.println( sgposservices.getCVSRequest().getCustomerID() );
                            // responseCVS = "  -4:000000:Z";
                            if (null != responseCVS && !responseCVS.isEmpty()) {
                                String arrIN[] = responseCVS.split(":");
                                String reasonCode = arrIN[0].trim();
                                Response response = new Response();

                                for (Object o : obj) {
                                    JSONObject perf = (JSONObject) o;
                                    JSONObject res = (JSONObject) perf.get(reasonCode);
                                    if (null != res) {
                                        response.setReasonCode((String) res.get("reasonCode"));
                                        response.setReasonDescription((String) res.get("shortDescription"));
                                        response.setResponse((String) res.get("response"));
                                        response.setReasonLongDescription((String) res.get("longDescription"));
                                        response.setAuthNumberRequired((String) res.get("authNumberReq"));
                                        response.setAuthLevel((String) res.get("authLevel"));
                                    }
                                }

                                response.setTotalCashBackAvailed(arrIN[1].trim());
                                if (null != arrIN && arrIN.length > 2) {
                                    response.setMultiReferralFlag("Yes");
                                    response.setMultiReferralReason("OVER DAILY CASH LIMIT");
                                } else {
                                    response.setMultiReferralFlag("No");
                                }
                                sgposservices.setResponse(response);
                                sgposservices.setHeader(sgposservices.getHeader());
                                sgposservices.setCVSRequest(null);
                                mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
                                String json = mapper.writeValueAsString(sgposservices);
                                LOG.debug("SGPOS services Response" + json);
                             //   LOG.info("Received response from IGLAS Trace Id:" + sgposservices.getHeader().getTraceID());
                            }
                        } catch (GatewayException | ResourceAccessException | IOException | HttpClientErrorException e) {
                            LOG.error("CVS Connection time out ",e.getMessage());
                            LOG.info("CVS Connection time out " );
                            sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "CVS_TIME_OUT");
                        } catch (Exception e) {
                            LOG.error("Invalid data ",e.getMessage());
                            LOG.info("Invalid data " + e.getMessage());
                            sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "INVALID_REQUEST");
                        }
                    } else {
                        Response response = new Response();
                        for (Object o : obj) {
                            JSONObject perf = (JSONObject) o;
                            JSONObject res = (JSONObject) perf.get(ccdRes.get("reasonCode").toString().trim());
                            if (null != res) {
                                response.setReasonCode((String) res.get("reasonCode"));
                                response.setReasonDescription((String) res.get("shortDescription"));
                                response.setResponse((String) res.get("response"));
                                response.setReasonLongDescription((String) res.get("longDescription"));
                                response.setAuthNumberRequired((String) res.get("authNumberReq"));
                                response.setAuthLevel((String) res.get("authLevel"));
                            }
                        }
                        response.setMultiReferralFlag("No");
                        response.setTotalCashBackAvailed(sgposservices.getCVSRequest().getCashbackRequestedAmount().trim());
                        sgposservices.setResponse(response);
                        sgposservices.setHeader(sgposservices.getHeader());
                        sgposservices.setCVSRequest(null);
                        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
                        String json = mapper.writeValueAsString(sgposservices);
                        LOG.debug("SGPOS services Response" + json);
                      //  LOG.info("Received response from SGPOS services, Trace Id:" + sgposservices.getHeader().getTraceID());

                    }

                } catch (GatewayException | ResourceAccessException | IOException | HttpClientErrorException e) {
                    LOG.error("CCD Connection time out for CVS ",e.getMessage());
                    sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "SOA_TIME_OUT");
                } catch (Exception e) {
                    LOG.error("Invalid data."+ e.getMessage() );
                    sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "INVALID_REQUEST");
                }
            } else {
                LOG.info("Since the Customer type SSN the CustomerId should be 9 digit ");
                sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "INVALID_REQUEST");

            }
        } else if (null != sgposservices.getIGLASRequest()) {
            request = "G" + sgposservices.getIGLASRequest().getCbn() + sgposservices.getIGLASRequest().getFunctionCode().charAt(0)
                    + sgposservices.getHeader().getInputType().toString().charAt(0)
                    + " "
                    + sgposservices.getHeader().getLocalDateTime().substring(2, 6)
                    + sgposservices.getHeader().getTransactionID() + sgposservices.getHeader().getTermID()
                    + sgposservices.getIGLASRequest().getCashierNumber().substring(0, 3)
                    + sgposservices.getHeader().getLocalDateTime() + sgposservices.getIGLASRequest().getExpiryDate()
                    + sgposservices.getIGLASRequest().getAccount() + sgposservices.getIGLASRequest().getAmount()
                    + sgposservices.getIGLASRequest().getTranCode() + sgposservices.getIGLASRequest().getTransF1()
                    + sgposservices.getIGLASRequest().getAuthLevel() + sgposservices.getIGLASRequest().getAuthKey()
                    + sgposservices.getIGLASRequest().getAuthSupervisor() + sgposservices.getIGLASRequest().getReasonCode()
                    + sgposservices.getIGLASRequest().getReasonDescription() + sgposservices.getIGLASRequest().getLen();

            if (null != sgposservices.getIGLASRequest().getGLAcct() && !sgposservices.getIGLASRequest().getGLAcct().isEmpty()) {
                if (null != sgposservices.getIGLASRequest().getGLIdentifier() && !sgposservices.getIGLASRequest().getGLIdentifier().isEmpty() && null != sgposservices.getIGLASRequest().getRecordSeperator1() && !sgposservices.getIGLASRequest().getRecordSeperator1().isEmpty()) {
                    request = request + sgposservices.getIGLASRequest().getGLIdentifier() + sgposservices.getIGLASRequest().getGLAcct() + sgposservices.getIGLASRequest().getRecordSeperator1();
                } else {
                    LOG.info("Validation of GLIdentifier and  RecordSeperator1 has failed. Error->  please enter correct GLIdentifier and getRecordSeperator1 " );
                    sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "INVALID_REQUEST");
                }
            }
            if (null != sgposservices.getIGLASRequest().getFacilityNumber() && !sgposservices.getIGLASRequest().getFacilityNumber().isEmpty()) {

                if (null != sgposservices.getIGLASRequest().getFacIdentifier() && !sgposservices.getIGLASRequest().getFacIdentifier().isEmpty() && null != sgposservices.getIGLASRequest().getRecordSeperator2() && !sgposservices.getIGLASRequest().getRecordSeperator2().isEmpty()) {
                    request = request + sgposservices.getIGLASRequest().getFacIdentifier() + sgposservices.getIGLASRequest().getFacilityNumber() + sgposservices.getIGLASRequest().getRecordSeperator2();
                } else {
                    LOG.info("Validation of FacIdentifier and  RecordSeperator2 has failed. Error->  please enter correct FacIdentifier and getRecordSeperator2" );
                    sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "INVALID_REQUEST");
                }
            }
            if (null != sgposservices.getIGLASRequest().getSsn() && !sgposservices.getIGLASRequest().getSsn().isEmpty()) {

                if (null != sgposservices.getIGLASRequest().getSSNIdentifier() && !sgposservices.getIGLASRequest().getSSNIdentifier().isEmpty() && null != sgposservices.getIGLASRequest().getRecordSeperator3() && !sgposservices.getIGLASRequest().getRecordSeperator3().isEmpty()) {
                    request = request + sgposservices.getIGLASRequest().getSSNIdentifier() + sgposservices.getIGLASRequest().getSsn() + sgposservices.getIGLASRequest().getRecordSeperator3();
                } else {
                    LOG.info("Validation of SSNIdentifier and  RecordSeperator3 has failed. Error->  please enter correct SSNIdentifier and getRecordSeperator3 " );
                    sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "INVALID_REQUEST");
                }

            }
            if (null != sgposservices.getIGLASRequest().getRef1() && !sgposservices.getIGLASRequest().getRef1().isEmpty()) {

                if (null != sgposservices.getIGLASRequest().getRef1Identifier() && !sgposservices.getIGLASRequest().getRef1Identifier().isEmpty() && null != sgposservices.getIGLASRequest().getRecordSeperator4() && !sgposservices.getIGLASRequest().getRecordSeperator4().isEmpty()) {
                    request = request + sgposservices.getIGLASRequest().getRef1Identifier() + sgposservices.getIGLASRequest().getRef1() + sgposservices.getIGLASRequest().getRecordSeperator4();
                } else {
                    LOG.info("Validation of getRef1Identifier and  RecordSeperator4 has failed. Error->  please enter correct Ref1Identifier and getRecordSeperator4 " );
                    sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "INVALID_REQUEST");
                }
            }
            if (null != sgposservices.getIGLASRequest().getRef2() && !sgposservices.getIGLASRequest().getRef2().isEmpty()) {

                if (null != sgposservices.getIGLASRequest().getRef2Identifier() && !sgposservices.getIGLASRequest().getRef2Identifier().isEmpty() && null != sgposservices.getIGLASRequest().getRecordSeperator5() && !sgposservices.getIGLASRequest().getRecordSeperator5().isEmpty()) {
                    request = request + sgposservices.getIGLASRequest().getRef2Identifier() + sgposservices.getIGLASRequest().getRef2() + sgposservices.getIGLASRequest().getRecordSeperator5();
                } else {
                    LOG.info("Validation of getRef2Identifier and  RecordSeperator5 has failed. Error->  please enter correct getRef2Identifier and getRecordSeperator5 " );
                    sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "INVALID_REQUEST");
                }
            }
            request = request + sgposservices.getIGLASRequest().getEtx() + "/\u0003";
           // LOG.info("IGLASRequest ETX:");
            LOG.info("Sending request to MQConnection IGLAS: " +request );

            if (null == sgposservices.getResponse()) {
                //  ccdVerificationIGLAS ccdVer = new ccdVerificationIGLAS();
                JSONObject ccdRes = new JSONObject();
                try {
                    boolean iGlasCCDCall = false;
                    if (null != sgposservices.getIGLASRequest().getSsn() && !sgposservices.getIGLASRequest().getSsn().isEmpty()) {
                        try {
                            ccdRes = ccdVerIGLAS.CCDCall(sgposservices);
                        } catch (GatewayException | ResourceAccessException | IOException | HttpClientErrorException  ex) {
                            LOG.error(ex.getMessage()+"  " );
                            if (sgposservices.getIGLASRequest().getTranCode().equalsIgnoreCase(tranCode.MC2)) {
                            LOG.error("CCD Connection timeout " );

                                iGlasCCDCall = true;
                            } else {
                                LOG.error("IGLAS CCD Connection time out " );
                                sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "SOA_TIME_OUT");
                                return sgposservices;
                            }
                        }
                        if (null != ccdRes && !ccdRes.isEmpty()) {
                            if (ccdRes.get("ccdCall").equals(true)) {
                                iGlasCCDCall = true;
                            }
                        }
                    } else {
                        iGlasCCDCall = true;
                    }

                    JSONParser jsonParser = new JSONParser();
                    FileReader reader = new FileReader(reasonCodeIGLAS);
                    JSONArray obj = (JSONArray) jsonParser.parse(reader);
                    if (iGlasCCDCall) {

                        String responseIglas = mqConnection.mqConnection(request, sgposservices);
                        //String responseIglas = "GeAK 321012710101523032113151228                        0000000N12     0NN000BAD FAC # 8F1:04910 F2:3730000000 F3:999887765 F4:test F5:rrrw N12  ";
                        if (null != responseIglas && !responseIglas.isEmpty()) {
                            // JSONParser jsonParser = new JSONParser();
                            String reasonDescription = responseIglas.substring(76, 86);
                            Response response = new Response();
                            String resDes = reasonDescription.trim();
                            String reason = String.valueOf(responseIglas.charAt(2));
            if (reason.equalsIgnoreCase("A")) {
                response.setReasonCode("000");
                response.setResponse("Approved");
                response.setReasonDescription("Approved");
            } else {
                            Boolean resd = false;
                            for (Object o : obj) {
                                JSONObject perf = (JSONObject) o;
                                JSONObject res = (JSONObject) perf.get(resDes);
                                if (null != res) {
                                    response.setReasonCode((String) res.get("reasonCode"));
                                    response.setResponse((String) res.get("response"));
                                    response.setReasonDescription((String) res.get("reasonDescription"));
                                    resd = true;
                                }
                            }
                            if (!resd) {
                                response.setReasonCode("G210");
                                response.setResponse("Declined");
                                response.setReasonDescription("OTHER");
                            }
                            }
                            response.setFunctionCode(sgposservices.getIGLASRequest().getFunctionCode());
                            response.setCashierNumber(sgposservices.getIGLASRequest().getCashierNumber());
                            response.setAmount(responseIglas.substring(55, 62).trim());
                            response.setTranCode(sgposservices.getIGLASRequest().getTranCode());
                            response.setAuthLevel(String.valueOf(responseIglas.charAt(71)));
                            response.setAuthKey(String.valueOf(responseIglas.charAt(72)));
                            response.setAuthSupervisor(String.valueOf(responseIglas.charAt(73)));
                            sgposservices.setResponse(response);
                            sgposservices.setHeader(sgposservices.getHeader());
                            sgposservices.setIGLASRequest(null);
                            mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
                            String json = mapper.writeValueAsString(sgposservices);
                            LOG.debug("SGPOS services Response" + json);
                         //   LOG.info("Received response from IGLAS, Trace Id:" + sgposservices.getHeader().getTraceID());
                        }
                    } else {
                        LOG.info("No response received from MQConnection " );
                        Response response = new Response();
                        for (Object o : obj) {
                            JSONObject perf = (JSONObject) o;
                            JSONObject res = (JSONObject) perf.get(ccdRes.get("reasonCode"));
                            if (null != res) {
                                response.setReasonCode((String) res.get("reasonCode"));
                                response.setResponse((String) res.get("response"));
                                response.setReasonDescription((String) res.get("reasonDescription"));

                            }
                        }
                        response.setFunctionCode(sgposservices.getIGLASRequest().getFunctionCode());
                        response.setCashierNumber(sgposservices.getIGLASRequest().getCashierNumber());
                        //   response.setAmount(responseIglas.substring(55, 63));
                        response.setTranCode(sgposservices.getIGLASRequest().getTranCode());
//                    response.setAuthLevel(String.valueOf(responseIglas.charAt(71)));
//                    response.setAuthKey(String.valueOf(responseIglas.charAt(72)));
//                    response.setAuthSupervisor(String.valueOf(responseIglas.charAt(73)));
                        sgposservices.setResponse(response);
                        sgposservices.setHeader(sgposservices.getHeader());
                        sgposservices.setIGLASRequest(null);
                        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
                        String json = mapper.writeValueAsString(sgposservices);
                        LOG.debug("SGPOS services Response" + json);
                        LOG.info("Received response from IGLAS" );

                    }
                } catch (GatewayException | ResourceAccessException | IOException | HttpClientErrorException e) {
                    LOG.error("IGLAS Connection time out ",e.getMessage());
                    sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "IGLAS_TIME_OUT");
                } catch (Exception e) {
                    LOG.error("Invalid data."+ e.getMessage());
                    sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "INVALID_REQUEST");
                }
            }
        }
        sgposservices.setCVSRequest(null);
        sgposservices.setIGLASRequest(null);
        return sgposservices;
    }

    public SGPOSServices IdCheckResponse(SGPOSServices sgposservices) throws IOException, ParseException, ParseException {
        ObjectMapper mapper = new ObjectMapper();
        String request = null;
        String functionCode = null;
        String cashBackRequestedAmount = null;
        String customerID = null;
        String swipeKey = null;
        String requestAdditional = null;
        if (null != sgposservices.getIDCheckRequest()) {
            JSONObject ccdRes = new JSONObject();
            try {
                if (sgposservices.getIDCheckRequest().getCustomerType().toString().equalsIgnoreCase(customerType.EDIPI)) {
                    ccdRes = ccdVerIDCHECK.CCDCall(sgposservices);
                } else {
                    throw new Exception("Invalid customer type");
                }
                JSONParser jsonParser = new JSONParser();
                FileReader reader = new FileReader(reasonCodeIDCHECK);
                JSONArray obj = (JSONArray) jsonParser.parse(reader);
                Response response = new Response();
                for (Object o : obj) {
                    JSONObject perf = (JSONObject) o;
                    JSONObject res = (JSONObject) perf.get(ccdRes.get("reasonCode").toString().trim());
                    if (null != res) {
                        response.setReasonCode((String) res.get("reasonCode"));
                        response.setReasonDescription((String) res.get("reasonDescription"));
                        response.setResponse((String) res.get("response"));
                        if( ccdRes.get("CID") != null && !((String) ccdRes.get("CID")).isEmpty()){
                            response.setCid((String) ccdRes.get("CID"));
                        }
                    }
                }

                sgposservices.setResponse(response);
                sgposservices.setHeader(sgposservices.getHeader());
                sgposservices.setIDCheckRequest(null);
                mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
                String json = mapper.writeValueAsString(sgposservices);
                LOG.debug("SGPOS services Response" + json);
                LOG.info("Received response from SGPOS services" );

            } catch (GatewayException | ResourceAccessException | IOException | HttpClientErrorException e) {
                LOG.error(e.getMessage());
                LOG.info("IdCheck Connection time out ");
                sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "SOA_TIME_OUT");
            } catch (Exception e) {
                LOG.error(e.getMessage());
                LOG.info("Invalid request." + e.getMessage());
                sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "INVALID_REQUEST");
            }
        }
        sgposservices.setIDCheckRequest(null);
        return sgposservices;
    }


    public Boolean tryParse(String s) {
        SimpleDateFormat df = new SimpleDateFormat("yyMMddHHmmss");
        df.setLenient(false);
        Boolean valid = false;
        try {
            Date dateToParse = df.parse(s);
            valid = true;
        } catch (java.text.ParseException e) {
            valid = false;
        }
        return valid;
    }


    public Boolean tryParseBusinessDate(String s) {
        SimpleDateFormat df = new SimpleDateFormat("ddMMyyHHmmss");
        df.setLenient(false);
        Boolean valid = false;
        try {
            Date dateToParse = df.parse(s);
            valid = true;
        } catch (java.text.ParseException e) {
            valid = false;
        }
        return valid;
    }

}
