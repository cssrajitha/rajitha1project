/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.aafes.sgpos.sgposservices.util;

import ch.qos.logback.classic.PatternLayout;
import ch.qos.logback.classic.spi.ILoggingEvent;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import ch.qos.logback.classic.PatternLayout;

import ch.qos.logback.classic.spi.ILoggingEvent;
 
import java.util.regex.Matcher;

import java.util.regex.Pattern;
 
public class MaskingPatternLayout extends PatternLayout {
 
    // Match patterns like: "SSN":"165588032" or "CID":"123456789"

    private static final Pattern JSON_MASKING_PATTERN = Pattern.compile(

        "\"(SSN|CID|customerID)\"\\s*:\\s*\"(\\d{5,6})(\\d{3})\""

    );
@Override
    public String doLayout(ILoggingEvent event) {
        String message = super.doLayout(event);
 
        // Mask all specified fields, showing only last 3 characters (regardless of value type)
        Pattern allFieldsPattern = Pattern.compile(
            "\"(SSN|CID|customerID|CustomerID|DODEDIPersonalId)\"\\s*:\\s*\"([^\"]{3,})\"",
            Pattern.CASE_INSENSITIVE
        );
        Matcher matcher = allFieldsPattern.matcher(message);
        StringBuffer maskedMessage = new StringBuffer();
        while (matcher.find()) {
            String fieldName = matcher.group(1);
            String value = matcher.group(2);
            String lastThree = value.substring(value.length() - 3);
            String replacement = "\"" + fieldName + "\":\"*****" + lastThree + "\"";
            matcher.appendReplacement(maskedMessage, replacement);
        }
        matcher.appendTail(maskedMessage);
        return maskedMessage.toString();
    }

}

 