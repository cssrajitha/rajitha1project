package com.aafes.sgpos.sgposservices.Control;

public class SGPOSRequestType {

    //ORIS Request Typr or Fucntion Code
    public static final String PREAUTH = "Validation";
    public static final String FINALAUTH = "Completion";
    //Store Open or Close Request Typre
    public static final String STOREOPEN = "StoreOpen";
    public static final String STORECLOSE = "StoreClose";

    //CVS Request Type or Fucntion Code
    public static final String INQUIRY = "Inquiry";
    public static final String OVERRIDE = "Override";
    public static final String TRN_CANCEL = "TrnCancel";
    //IGLAS Request Type or Fucntion Code
    public static final String SALE = "Sale";
    public static final String PAYMENT = "Payment";
}



