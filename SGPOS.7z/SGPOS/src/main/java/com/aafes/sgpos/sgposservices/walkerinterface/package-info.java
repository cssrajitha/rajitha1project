/**
 * A Web Service that provides Access to the Walker
 *         Self Serve.
 *     
 * 
 */
@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://cput.aafes.com:8050/widwcna/cwba/widw000/ONLCTL", elementFormDefault = jakarta.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.aafes.sgpos.sgposservices.walkerinterface;
