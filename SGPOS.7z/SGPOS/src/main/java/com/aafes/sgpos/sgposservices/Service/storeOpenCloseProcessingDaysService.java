package com.aafes.sgpos.sgposservices.Service;

import com.aafes.sgpos.sgposservices.Control.storeOpenCloseMessagesStatus;
import com.aafes.sgpos.sgposservices.Entity.fac_fmf;
import com.aafes.sgpos.sgposservices.Entity.storeOpenCloseMessages;
import com.aafes.sgpos.sgposservices.Gateway.ResaMessages;
import com.aafes.sgpos.sgposservices.Gateway.orisVerification;
import com.aafes.sgpos.sgposservices.Repository.storeOpenCloseMessagesRepository;
import com.aafes.sgpos.sgposservices.walkerinterface.ApplyTXNResponse;
import com.aafes.sgpos.sgposservices.walkerinterface.ConnectToWalkerResponse;
import com.aafes.sgpos.sgposservices.walkerinterface.LogOffWalkerResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import com.aafes.sgpos.sgposservices.generated.Control.SGPOSServices;
import com.aafes.sgpos.sgposservices.generated.Control.Header;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
@Service
public class storeOpenCloseProcessingDaysService {
    private static final Logger LOG
            = LoggerFactory.getLogger(storeOpenCloseProcessingDaysService.class.getSimpleName());

    @Autowired
    SGPOSServicesservice sgposServicesservice;
    @Autowired
    ResaMessages resaMessages;
    ApplyTXNResponse applyTXNResponse;
    ConnectToWalkerResponse walkerResponse;
    LogOffWalkerResponse logOffWalkerResponse;
    @Autowired
    private storeOpenCloseMessagesRepository resaQueueRepository;
    @Autowired
    orisVerification OrisVerification;
    public String socOris(SGPOSServices sgposservices) throws JsonProcessingException {
        LOG.info("Sending request to ORIS " );

        String customerName = null;
        String LQ1SplitTender = null;
        String LQ0InvoiceNbr = null;
        List<fac_fmf> facility = null;
        String response="";
        //sign in oris(soap call)
        walkerResponse = OrisVerification.login(sgposservices);
        //ApplyTXN request oris(soap call)
        if (null == sgposservices.getResponse()) {
            if (null != walkerResponse && walkerResponse.getConnectToWalkerResult().getStatus().equalsIgnoreCase("OK")) {
                applyTXNResponse = OrisVerification.applyTXN(walkerResponse, sgposservices, facility);

                if (null != applyTXNResponse) {
                    String encodedHtmlResponse = new String(applyTXNResponse.getApplyTXNResult().getEncodedHtmlResponse());
                    //  LOG.info("encodedHtmlResponse"+encodedHtmlResponse);
                    LOG.debug("encodedHtmlResponse"+encodedHtmlResponse);

                    String decodedString = encodedHtmlResponse;
                    // LOG.info("decodedString"+decodedString);
                    //getting values from encoded string oris(soap call)
                    if (null != applyTXNResponse && applyTXNResponse.getApplyTXNResult().getStatus().equalsIgnoreCase("OK")) {
                        response="success";
                    } else if (null == applyTXNResponse) {
                        response="FAILED";
                        // if (null != sgposservices.getStoreOpenCloseRequest()) {
                        LOG.info("Store Close Connection time out " );
                        LOG.info("Store Close Connection time out " );
                        //    sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "SOC_TIME_OUT");
                        // } else if (null != sgposservices.getORISRequest()) {
                        LOG.info("ORIS Connection time out ");
                        // sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "ORIS_TIME_OUT");
                        // }
                    }else {
                        response="FAILED";
//                        LOG.info("Reason Code: " + reasonCode+ ": TraceID " +sgposservices.getHeader().getTraceID());
//                        LOG.info("Received response from ORIS: Soap Request Failed with  -> " + errorDesc+ ": TraceID " +sgposservices.getHeader().getTraceID());
//                      //  sgposservices = buildErrorResponseUtil.buildErrorResponseOris(sgposservices, errorDesc, reasonCode);

                    }
                } else {
                    //  if (null != sgposservices.getStoreOpenCloseRequest()) {
                    LOG.info("Store Close Failed " );
                    //  sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "SOC_SERVER_ERROR");
                    //   } else if (null != sgposservices.getORISRequest()) {
                    LOG.info("ORIS Connection Failed " );
                    //   sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "ORIS_SERVER_ERROR");
                    // }
                }
            }else{
                response="FAILED";
                // if (null != sgposservices.getStoreOpenCloseRequest()) {
                LOG.info("Store Close Connection time out " );
                //  sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "SOC_TIME_OUT");
                //  } else if (null != sgposservices.getORISRequest()) {
                LOG.info("ORIS Connection time out " );
                //   sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "ORIS_TIME_OUT");
                // }
            }
        }
        if (null == sgposservices.getResponse()) {
            if (null != applyTXNResponse && applyTXNResponse.getApplyTXNResult().getStatus().equalsIgnoreCase("OK")) {
                //Log off oris(soap call)
                logOffWalkerResponse = OrisVerification.loggOff(applyTXNResponse, sgposservices);
                response="success";
            }
        }

        LOG.info(" Received response from ORIS " );
        return response;
    }
    @Async
    public List<String> bookToResa(List<storeOpenCloseMessages> resaQueue, List<String> sC, SGPOSServices sgposservices ) throws JsonProcessingException {
        SGPOSServices sgposServices= new SGPOSServices();
//        if (onlineApproved(t) && t.getFacility7() != null
        DateFormat dateFormat = new SimpleDateFormat("yyMMddHHmmss");
        Date date = new Date();
        //SGPOSServicesservice sgposServicesservice = new SGPOSServicesservice();
        if(null!=resaQueue && !resaQueue.isEmpty()) {
            for (storeOpenCloseMessages resa : resaQueue) {
                MDC.put("TraceID", resa.getTraceid());
                storeOpenCloseMessagesStatus booking = new storeOpenCloseMessagesStatus();
                booking.setMsgSendDateTime(dateFormat.format(date));
                booking.setFacilityNumber(resa.getFacility());
                booking.setStoreStatus(resa.getRequesttype());
                booking.setDateAndTimeStamp(resa.getReqdateandtime());
                String response ="";
                String rec = resaMessages.formatRecord(booking);
                if("oris".equals(resa.getGateway())){
                    Header header= new Header();
                    header.setTraceID(resa.getTraceid());
                    header.setFacilityNumber(resa.getFacility());
                    sgposServices.setHeader(header);
                    this.socOris(sgposServices);
                }else {
                    response = resaMessages.sendMessage(rec, sgposServices);
                }
                if(response.equals("FAILED")){
                    sC.add("FAILED");
                    LOG.info("Failed from IIB service" + resa.getFacility() );
                }else {
                    if("resa".equals(resa.getGateway())) {
                        LOG.info("Got response from IIB service" + resa.getFacility() );
                    }
                    resaQueueRepository.deletebyDFT(resa.getReceiveddate(), resa.getGateway(), resa.getFacility(), resa.getTraceid());
                    sC.add("SUCCESS");
                }MDC.clear();
            }
        }
        sC.add("NO_RECORDS");
        //        }

        return sC;
    }
}
