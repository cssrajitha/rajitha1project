package com.aafes.sgpos.sgposservices.Config;




import com.ibm.mq.jakarta.jms.MQQueueConnectionFactory;
import com.ibm.msg.client.jakarta.wmq.WMQConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.connection.UserCredentialsConnectionFactoryAdapter;
import org.springframework.jms.core.JmsTemplate;

@Configuration
public class JmsConfig {
    private static final Logger LOG = (Logger) LoggerFactory.getLogger(JmsConfig.class);

    @Value("${spring.jms.ibm.mq.queue-manager-2.queue-manager}")
    private String qManagerName2;
    @Value("${spring.jms.ibm.mq.queue-manager-2.host}")
    private String mqHostName2;
    @Value("${spring.jms.ibm.mq.queue-manager-2.channel}")
    private String qChannelName2;
    @Value("${spring.jms.ibm.mq.queue-manager-2.port}")
    private String qPort2;
    @Value("${spring.jms.ibm.mq.queue-manager-2.requestQ}")
    private String requestQ2;

    @Value("${spring.jms.ibm.mq.queue-manager-1.qManagerName}")
    private String qManagerName1;
    @Value("${spring.jms.ibm.mq.queue-manager-1.mqHostName}")
    private String mqHostName1;
    @Value("${spring.jms.ibm.mq.queue-manager-1.qChannelName}")
    private String qChannelName1;
    @Value("${spring.jms.ibm.mq.queue-manager-1.qPort}")
    private String qPort1;
    @Value("${spring.jms.ibm.mq.queue-manager-1.requestQ}")
    private String requestQ1;
    @Value("${spring.jms.ibm.mq.queue-manager-1.cicsUserName}")
    private String cicsUserName;
    @Value("${spring.jms.ibm.mq.queue-manager-1.cicsPassword}")
    private String cicsPassword;

    @Autowired
    EncryptorConfig encryptorConfig;

    @Bean
    @Primary
    public UserCredentialsConnectionFactoryAdapter connectionFactoryQM1() throws Exception {
        MQQueueConnectionFactory factory = new MQQueueConnectionFactory();
        factory.setHostName(mqHostName1);
        factory.setPort(Integer.parseInt(qPort1));
        factory.setQueueManager(qManagerName1);
        factory.setChannel(qChannelName1);
        factory.setTransportType(WMQConstants.WMQ_CM_CLIENT);

        UserCredentialsConnectionFactoryAdapter adapter = new UserCredentialsConnectionFactoryAdapter();
        adapter.setTargetConnectionFactory(factory);
        adapter.setUsername(cicsUserName);
        adapter.setPassword(encryptorConfig.decrypt(cicsPassword));
        LOG.info(encryptorConfig.decrypt(cicsPassword));
        return adapter;
    }
    @Bean
    @Primary
    public JmsTemplate jmsTemplateQM1() throws Exception {
        return new JmsTemplate(connectionFactoryQM1());
    }

    @Bean("SGposCachingConnectionFactoryAdapter")
    public UserCredentialsConnectionFactoryAdapter connectionFactoryQM2() throws Exception {
        MQQueueConnectionFactory factory = new MQQueueConnectionFactory();
        factory.setHostName(mqHostName2);
        factory.setPort(Integer.parseInt(qPort2));
        factory.setQueueManager(qManagerName2);
        factory.setChannel(qChannelName2);
        factory.setTransportType(WMQConstants.WMQ_CM_CLIENT);
        factory.setTargetClientMatching(true);
        //factory.setTargetClient(MQQueueConnectionFactory.MQJMS_CLIENT_NONJMS_MQ);
        String uniqueClientId = "myClientId-" + System.currentTimeMillis();
        factory.setClientID(uniqueClientId);
        UserCredentialsConnectionFactoryAdapter adapter = new UserCredentialsConnectionFactoryAdapter();
        adapter.setTargetConnectionFactory(factory);
//        adapter.setUsername("QM1_USER");
//        adapter.setPassword("QM1_PASSWORD");
        return adapter;
    }

    @Bean("SGposCachingConnectionFactory")
    public CachingConnectionFactory cachingConnectionFactory(UserCredentialsConnectionFactoryAdapter SGposCachingConnectionFactoryAdapter) {
        CachingConnectionFactory cachingConnectionFactory = new CachingConnectionFactory();
        cachingConnectionFactory.setTargetConnectionFactory(SGposCachingConnectionFactoryAdapter);
        cachingConnectionFactory.setSessionCacheSize(500);
        cachingConnectionFactory.setReconnectOnException(true);
        return cachingConnectionFactory;
    }
    @Bean("SocJmsOperations")
    public JmsTemplate jmsTemplateQM2() throws Exception {
        return new JmsTemplate(connectionFactoryQM2());
    }


}