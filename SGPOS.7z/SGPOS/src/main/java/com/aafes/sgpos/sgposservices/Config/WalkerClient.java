package com.aafes.sgpos.sgposservices.Config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.client.core.SoapActionCallback;

public class WalkerClient extends WebServiceGatewaySupport{
    private static final Logger log = LoggerFactory.getLogger(WalkerClient.class);

    public Object callWebService(String url, Object request,String reqUrl){
           return getWebServiceTemplate().marshalSendAndReceive(request,new SoapActionCallback(reqUrl));

      }

}
