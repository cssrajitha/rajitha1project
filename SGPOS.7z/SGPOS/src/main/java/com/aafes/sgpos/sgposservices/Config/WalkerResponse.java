package com.aafes.sgpos.sgposservices.Config;


import com.aafes.sgpos.sgposservices.walkerinterface.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class WalkerResponse {
    private static final Logger LOG = (Logger) LoggerFactory.getLogger(WalkerResponse.class);

    @Value("${oris.url}")
    private String url;
    @Value("${oris.applyTXNUrl}")
    private String applyTXNUrl;
    @Value("${oris.loginUrl}")
    private String loginUrl;
    @Value("${oris.logOffUrl}")
    private String logOffUrl;
    @Autowired
    private WalkerClient walkerclient;

    public ConnectToWalkerResponse signIn(ConnectToWalker request) {
        ConnectToWalkerResponse acknowledgement = (ConnectToWalkerResponse) walkerclient.callWebService(url, request, loginUrl);
                // walkerclient.callWebService("https://hqws02.aafes.com/WalkerInterface/WalkerInterface.asmx", request, "http://cput.aafes.com:8050/widwcna/cwba/widw000/ONLCTL/ConnectToWalker");

        return acknowledgement;
    }

    public ApplyTXNResponse applytxn(ApplyTXN request) {
        ApplyTXNResponse acknowledgement = (ApplyTXNResponse) walkerclient.callWebService(url, request, applyTXNUrl);
                //walkerclient.callWebService("https://hqws02.aafes.com/WalkerInterface/WalkerInterface.asmx", request, "http://cput.aafes.com:8050/widwcna/cwba/widw000/ONLCTL/ConnectToWalker");

        return acknowledgement;
    }

    public LogOffWalkerResponse logoff(LogOffWalker request) {
        LogOffWalkerResponse acknowledgement = (LogOffWalkerResponse) walkerclient.callWebService(url, request, logOffUrl);
                // walkerclient.callWebService("https://hqws02.aafes.com/WalkerInterface/WalkerInterface.asmx", request, "http://cput.aafes.com:8050/widwcna/cwba/widw000/ONLCTL/ConnectToWalker");

        return acknowledgement;
    }

}
