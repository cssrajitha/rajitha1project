
package com.aafes.sgpos.sgposservices.walkerinterface;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ServerAccessProperties complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ServerAccessProperties"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="EncodedHtmlErrorData" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/&gt;
 *         &lt;element name="FieldsInError" type="{http://cput.aafes.com:8050/widwcna/cwba/widw000/ONLCTL}ArrayOfAnyType" minOccurs="0"/&gt;
 *         &lt;element name="EncodedHtmlResponse" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/&gt;
 *         &lt;element name="PostData" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Status" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="StatusDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ErrorDescription" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="DetailedError" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="Token" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ServerAccessProperties", propOrder = {
    "encodedHtmlErrorData",
    "fieldsInError",
    "encodedHtmlResponse",
    "postData",
    "status",
    "statusDescription",
    "errorDescription",
    "detailedError",
    "token"
})
public class ServerAccessProperties {

    @XmlElement(name = "EncodedHtmlErrorData")
    protected byte[] encodedHtmlErrorData;
    @XmlElement(name = "FieldsInError")
    protected ArrayOfAnyType fieldsInError;
    @XmlElement(name = "EncodedHtmlResponse")
    protected byte[] encodedHtmlResponse;
    @XmlElement(name = "PostData")
    protected String postData;
    @XmlElement(name = "Status")
    protected String status;
    @XmlElement(name = "StatusDescription")
    protected String statusDescription;
    @XmlElement(name = "ErrorDescription")
    protected String errorDescription;
    @XmlElement(name = "DetailedError")
    protected String detailedError;
    @XmlElement(name = "Token")
    protected String token;

    /**
     * Gets the value of the encodedHtmlErrorData property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getEncodedHtmlErrorData() {
        return encodedHtmlErrorData;
    }

    /**
     * Sets the value of the encodedHtmlErrorData property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setEncodedHtmlErrorData(byte[] value) {
        this.encodedHtmlErrorData = value;
    }

    /**
     * Gets the value of the fieldsInError property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfAnyType }
     *     
     */
    public ArrayOfAnyType getFieldsInError() {
        return fieldsInError;
    }

    /**
     * Sets the value of the fieldsInError property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfAnyType }
     *     
     */
    public void setFieldsInError(ArrayOfAnyType value) {
        this.fieldsInError = value;
    }

    /**
     * Gets the value of the encodedHtmlResponse property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getEncodedHtmlResponse() {
        return encodedHtmlResponse;
    }

    /**
     * Sets the value of the encodedHtmlResponse property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setEncodedHtmlResponse(byte[] value) {
        this.encodedHtmlResponse = value;
    }

    /**
     * Gets the value of the postData property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPostData() {
        return postData;
    }

    /**
     * Sets the value of the postData property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPostData(String value) {
        this.postData = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

    /**
     * Gets the value of the statusDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatusDescription() {
        return statusDescription;
    }

    /**
     * Sets the value of the statusDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatusDescription(String value) {
        this.statusDescription = value;
    }

    /**
     * Gets the value of the errorDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrorDescription() {
        return errorDescription;
    }

    /**
     * Sets the value of the errorDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrorDescription(String value) {
        this.errorDescription = value;
    }

    /**
     * Gets the value of the detailedError property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDetailedError() {
        return detailedError;
    }

    /**
     * Sets the value of the detailedError property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDetailedError(String value) {
        this.detailedError = value;
    }

    /**
     * Gets the value of the token property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getToken() {
        return token;
    }

    /**
     * Sets the value of the token property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setToken(String value) {
        this.token = value;
    }

}
