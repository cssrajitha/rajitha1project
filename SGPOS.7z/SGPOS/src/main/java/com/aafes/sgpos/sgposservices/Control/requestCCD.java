package com.aafes.sgpos.sgposservices.Control;

public class requestCCD {
    private String SSN;
    private String CID;
    private String DODEDIPersonalId;

    public String getSSN() {
        return SSN;
    }

    public void setSSN(String SSN) {
        this.SSN = SSN;
    }

    public String getCID() {
        return CID;
    }

    public void setCID(String CID) {
        this.CID = CID;
    }

    public String getDODEDIPersonalId() {
        return DODEDIPersonalId;
    }

    public void setDODEDIPersonalId(String DODEDIPersonalId) {
        this.DODEDIPersonalId = DODEDIPersonalId;
    }

    @Override
    public String toString() {
        return "request{" +
                "SSN='" + SSN + '\'' +
                ", CID='" + CID + '\'' +
                ", DODEDIPersonalId='" + DODEDIPersonalId + '\'' +
                '}';
    }

}
