package com.aafes.sgpos.sgposservices.Gateway;

import com.aafes.sgpos.sgposservices.Config.EncryptorConfig;
import com.aafes.sgpos.sgposservices.Config.WalkerResponse;
import com.aafes.sgpos.sgposservices.Control.SGPOSRequestType;
import com.aafes.sgpos.sgposservices.Entity.fac_fmf;
import com.aafes.sgpos.sgposservices.Repository.storeOpenCloseMessagesRepository;
import com.aafes.sgpos.sgposservices.Service.SGPOSServicesservice;
import com.aafes.sgpos.sgposservices.util.BuildErrorResponseUtil;
import com.aafes.sgpos.sgposservices.walkerinterface.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import com.aafes.sgpos.sgposservices.generated.Control.Response;
import com.aafes.sgpos.sgposservices.generated.Control.SGPOSServices;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Component
public class orisVerification {
    private static final Logger LOG = (Logger) LoggerFactory.getLogger(orisVerification.class);

    @Value("${oris.strUrl}")
    private String strUrl;
    @Value("${oris.loginUrl}")
    private String loginUrl;
    @Value("${oris.loginUserName}")
    private String loginUserName;
    @Value("${oris.loginPassword}")
    private String loginPassword;
    @Value("${oris.applyTXNUrl}")
    private String applyTXNUrl;
    @Value("${oris.applyTXNSC}")
    private String applyTXNSC;
    @Value("${oris.applyTXNCE}")
    private String applyTXNCE;
    @Value("${oris.logOffUrl}")
    private String logOffUrl;
    @Autowired
    EncryptorConfig encryptorConfig;
    ApplyTXNResponse applyTXNResponse;
    ConnectToWalkerResponse walkerResponse;
    LogOffWalkerResponse logOffWalkerResponse;
    @Autowired
    private WalkerResponse walkerresponse;
    @Autowired
    BuildErrorResponseUtil buildErrorResponseUtil;
    @Autowired
    private storeOpenCloseMessagesRepository resaQueueRepository;


    public ConnectToWalkerResponse login(SGPOSServices sgposservices) {
        ConnectToWalkerResponse walkerResponse = new ConnectToWalkerResponse();
        ConnectToWalker walker = new ConnectToWalker();
        walker.setStrURL(strUrl);
        walker.setStrZuser(loginUserName);
        walker.setStrZpass(encryptorConfig.decrypt(loginPassword));
        try {
            walkerResponse = walkerresponse.signIn(walker);
        }catch (Exception ex){
            LOG.error("connect to Oris Walker login ",ex);
            LOG.info(ex.getMessage());
            if (null != sgposservices.getStoreOpenCloseRequest()) {
                DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                Date date = new Date();
                DateFormat dateFormatMsg = new SimpleDateFormat("yyMMddHHmmss");
                Date dateMsg = new Date();
                com.aafes.sgpos.sgposservices.Entity.storeOpenCloseMessages storeOpenCloseMessages=new com.aafes.sgpos.sgposservices.Entity.storeOpenCloseMessages();
                if(null != sgposservices) {
                    storeOpenCloseMessages.setReceiveddate(dateFormat.format(date));
                    storeOpenCloseMessages.setTraceid(sgposservices.getHeader().getTraceID());
                    storeOpenCloseMessages.setGateway("oris");
                    storeOpenCloseMessages.setFacility(sgposservices.getHeader().getFacilityNumber());
                    storeOpenCloseMessages.setReqdateandtime(sgposservices.getStoreOpenCloseRequest().getBusinessDate());
                    storeOpenCloseMessages.setMsgsenddatetime(dateFormatMsg.format(dateMsg));
                    storeOpenCloseMessages.setRequesttype(sgposservices.getStoreOpenCloseRequest().getRequestType());
                    storeOpenCloseMessages.setStatus(ex.getMessage());
                    resaQueueRepository.save(storeOpenCloseMessages);
                }
                LOG.error("Store Close Connection time out {}",ex);
                LOG.info("Store Close Connection time out " );
                sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "PARTIAL_APPROVED");
            } else if (null != sgposservices.getORISRequest()) {
                LOG.info("ORIS Connection time out ");
                LOG.error("ORIS Connection time out {}",ex);
                sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "ORIS_TIME_OUT");
            }else  {
                LOG.info("ORIS Connection time out " );
                LOG.error("ORIS Connection time out",ex);
                sgposservices = buildErrorResponseUtil.buildErrorResponseAdd(sgposservices, "ORIS_TIME_OUT");
            }

        }
        //   LOG.info(String.valueOf(walkerResponse.getConnectToWalkerResult()));
        return walkerResponse;
    }


    //soap call for oris ApplyTXN
    public ApplyTXNResponse applyTXN(ConnectToWalkerResponse walkerResponse, SGPOSServices sgposServices, List<fac_fmf> facility) {
        ApplyTXN applyTXN = new ApplyTXN();
        if (null != sgposServices.getORISRequest() && sgposServices.getORISRequest().getRequestType().equalsIgnoreCase(SGPOSRequestType.PREAUTH)) {
            String customerId = sgposServices.getORISRequest().getCustomerID().trim();
            String facNumber = sgposServices.getHeader().getFacilityNumber().trim();
            String rcvblType = sgposServices.getORISRequest().getReceivableType().substring(0, 3).trim();
            String billingTo = sgposServices.getORISRequest().getBillingToOffice().trim();
            String calcCode = sgposServices.getORISRequest().getReceivableType().substring(sgposServices.getORISRequest().getReceivableType().length() - 2).trim();
            applyTXN.setStrPostData("LQ1CustomerID%3D" + customerId + "%26LQ1SellingFac%3D" + facNumber + "%26LQ1RcvblType%3D" + rcvblType + "%26LQ1CalcCode%3D" + calcCode + "%26LQ1BillTo%3D" + billingTo + "%26LQ1AprvBy%3DLevel%205%20FA%20PROD");
            applyTXN.setStrTxn("LQ1");
        } else if (null != sgposServices.getORISRequest() && sgposServices.getORISRequest().getRequestType().equalsIgnoreCase(SGPOSRequestType.FINALAUTH)) {
            String customerId = sgposServices.getORISRequest().getCustomerID().trim();
            String facNumber = sgposServices.getHeader().getFacilityNumber().trim();
            String rcvblType = sgposServices.getORISRequest().getReceivableType().substring(0, 3).trim();
            String billingTo = sgposServices.getORISRequest().getBillingToOffice().trim();
            String calcCode = sgposServices.getORISRequest().getReceivableType().substring(sgposServices.getORISRequest().getReceivableType().length() - 2).trim();
            String salesDate = this.parseSalesDate(sgposServices.getORISRequest().getBusinessDate().trim());
            //String salesDate = sgposServices.getORISRequest().getBusinessDate().trim();
            String cost = sgposServices.getORISRequest().getAmount().trim();
            String aprvBy = facility.get(0).getFAC_MGR();
            String facPhoneNumber = sgposServices.getORISRequest().getFacPhoneNum().trim();
            String prepBy = sgposServices.getORISRequest().getCashierNameTag();
            String recvBY = sgposServices.getORISRequest().getReceivedBy();
            String PODONum = null;
            if (null != sgposServices.getORISRequest().getPODONbr()) {
                PODONum = sgposServices.getORISRequest().getPODONbr().trim();
            }
            String quantity = sgposServices.getORISRequest().getInvoiceQuantity();
            String desc = sgposServices.getHeader().getTraceID();
            String remarks1 = null;
            if (null != sgposServices.getORISRequest().getRemarks()) {
                remarks1 = sgposServices.getORISRequest().getRemarks();
            }
            String account = sgposServices.getORISRequest().getGLAccountNumber().trim();
            StringBuilder postData = new StringBuilder("LQ0CustomerID%3D" + customerId + "%26LQ0SalesDate%3D" + salesDate + "%26LQ0ActualCost%3D" + cost + "%26LQ0SellingFac%3D" + facNumber + "%26LQ0AprvBy%3D" + aprvBy + "%26LQ0FacPhone%3D"
                    + facPhoneNumber + "%26LQ0RcvblType%3D" + rcvblType + "%26LQ0CalcCode%3D" + calcCode + "%26LQ0BillTo%3D" + billingTo + "%26LQ0PrepBy%3D" + prepBy + "%26LQ0RecvBy%3D" + recvBY);
            //String postdata=;
            if (null != sgposServices.getORISRequest().getPODONbr()) {
                postData.append("%26LQ0PODONbr%3D" + PODONum);
            }
            postData.append("%26LQ0Quantity%3D" + quantity + "%26LQ0Desc%3D" + desc);
            if (null != sgposServices.getORISRequest().getRemarks()) {
                postData.append("%26LQ0Remarks1%3D" + remarks1);
            }
            postData.append("%26LQ0Account%3D" + account + "");
            applyTXN.setStrPostData(postData.toString());
            applyTXN.setStrTxn("LQ0");
        } else {
            applyTXN.setStrPostData("LQ2SellingFac%3D" + sgposServices.getHeader().getFacilityNumber());
            applyTXN.setStrTxn("LQ2");
        }
        applyTXN.setEncodedHtml(walkerResponse.getConnectToWalkerResult().getEncodedHtmlResponse());
        applyTXN.setStrURL(strUrl);
        applyTXN.setStrCC(applyTXNSC);
        applyTXN.setStrCntlEntity(applyTXNCE);
        try {
            applyTXNResponse = walkerresponse.applytxn(applyTXN);
        }catch (Exception ex){
            LOG.info(ex.getMessage());
            if (null != sgposServices.getStoreOpenCloseRequest()) {
                DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                Date date = new Date();
                DateFormat dateFormatMsg = new SimpleDateFormat("yyMMddHHmmss");
                Date dateMsg = new Date();
                com.aafes.sgpos.sgposservices.Entity.storeOpenCloseMessages storeOpenCloseMessages=new com.aafes.sgpos.sgposservices.Entity.storeOpenCloseMessages();
                if(null != sgposServices) {
                    storeOpenCloseMessages.setReceiveddate(dateFormat.format(date));
                    storeOpenCloseMessages.setTraceid(sgposServices.getHeader().getTraceID());
                    storeOpenCloseMessages.setGateway("oris");
                    storeOpenCloseMessages.setFacility(sgposServices.getHeader().getFacilityNumber());
                    storeOpenCloseMessages.setReqdateandtime(sgposServices.getStoreOpenCloseRequest().getBusinessDate());
                    storeOpenCloseMessages.setMsgsenddatetime(dateFormatMsg.format(dateMsg));
                    storeOpenCloseMessages.setRequesttype(sgposServices.getStoreOpenCloseRequest().getRequestType());
                    storeOpenCloseMessages.setStatus(ex.getMessage());
                    resaQueueRepository.save(storeOpenCloseMessages);
                }
                LOG.error("Store Close Connection time out",ex);
                LOG.info("Store Close Connection time out.");
                sgposServices = buildErrorResponseUtil.buildErrorResponseAdd(sgposServices, "PARTIAL_APPROVED");
            } else if (null != sgposServices.getORISRequest()) {
                LOG.error("ORIS Connection time out",ex);
                LOG.info("ORIS Connection time out.");
                sgposServices = buildErrorResponseUtil.buildErrorResponseAdd(sgposServices, "ORIS_TIME_OUT");
            }else  {
                LOG.error("ORIS Connection time out",ex);
                LOG.info("ORIS Connection time out: " );
                sgposServices = buildErrorResponseUtil.buildErrorResponseAdd(sgposServices, "ORIS_TIME_OUT");
            }
        }

        //   LOG.info(String.valueOf(applyTXNResponse));
        return applyTXNResponse;
    }

    //soap call for oris LogOff
    public LogOffWalkerResponse loggOff(ApplyTXNResponse applyTXNResponse, SGPOSServices sgposServices) {
        LogOffWalker logOffWalker = new LogOffWalker();
        logOffWalker.setStrURL(strUrl);
        logOffWalker.setToken(applyTXNResponse.getApplyTXNResult().getToken());
        LogOffWalkerResponse logOffWalkerResponse = new LogOffWalkerResponse();
        try {
            logOffWalkerResponse = walkerresponse.logoff(logOffWalker);
        }catch (Exception ex){
            LOG.error(ex.getMessage());
            if (null != sgposServices.getStoreOpenCloseRequest()) {
                LOG.error("Store Close Connection time out",ex);
                LOG.info("Store Close Connection time out.");
                sgposServices = buildErrorResponseUtil.buildErrorResponseAdd(sgposServices, "SOC_TIME_OUT");
            } else if (null != sgposServices.getORISRequest()) {
                LOG.error("ORIS Connection time out",ex);
                LOG.info("ORIS Connection time out.");
                sgposServices = buildErrorResponseUtil.buildErrorResponseAdd(sgposServices, "ORIS_TIME_OUT");
            }
        }
        return logOffWalkerResponse;
    }

    public String parseSalesDate(String s) {
        SimpleDateFormat df = new SimpleDateFormat("ddMMyyHHmmss");
        df.setLenient(false);
        Boolean valid = false;
        Date dateToParse = null;
        try {
            dateToParse = df.parse(s);
            valid = true;
        } catch (java.text.ParseException e) {
            valid = false;
        }
        return new SimpleDateFormat("ddMMyy").format(dateToParse);
    }
}
