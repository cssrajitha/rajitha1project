package com.aafes.sgpos.sgposservices.Config;

import ch.qos.logback.classic.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.web.ServerProperties;
import org.springframework.boot.web.server.Ssl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

/**
 *
 * @author sriramm
 */
@Component
public class KeystoreInit {
    @Value("${server.ssl.key-store-password}")
    private String keystorePass;
    private final Environment environment;

    private static final Logger LOG = (Logger) LoggerFactory.getLogger(KeystoreInit.class);
    @Autowired
    EncryptorConfig encryptorConfig;
    @Autowired
    public KeystoreInit(Environment environment) {
        this.environment = environment;
    }

    @Bean(name="serverProperties")
    @Primary
    public ServerProperties serverProperties() {
        final ServerProperties serverProperties = new ServerProperties();
        final Ssl ssl = new Ssl();
        final String keystorePassword = getKeystorePassword();
        ssl.setKeyPassword(keystorePassword);
        System.setProperty("server.ssl.key-store-password", keystorePassword);
        serverProperties.setSsl(ssl);
        return serverProperties;
    }
    private String getKeystorePassword() {

        try {
            LOG.info("decryption of keystore password details ::::::::::"+ keystorePass);
            keystorePass = encryptorConfig.decrypt(keystorePass);
        } catch (Exception e) {
            LOG.error("Exception occurred during decryption of keystore password details");
        }
        return keystorePass;
    }

}