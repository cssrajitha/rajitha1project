package com.aafes.sgpos.sgposservices.Entity;


import lombok.Data;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table(value = "storeopenclosemessages")
@Data
public class storeOpenCloseMessages {

    @PrimaryKeyColumn(name = "receiveddate", type = PrimaryKeyType.PARTITIONED)
    String receiveddate;
    @PrimaryKeyColumn(name = "gateway", type = PrimaryKeyType.CLUSTERED)
    String gateway;
    @PrimaryKeyColumn(name = "traceid", type = PrimaryKeyType.CLUSTERED)
    String traceid;

    @PrimaryKeyColumn(name = "facility", type = PrimaryKeyType.CLUSTERED)
    String facility;

    String reqdateandtime;
    String msgsenddatetime;
    String requesttype;
    String status;

    public String getGateway() {
        return gateway;
    }

    public void setGateway(String gateway) {
        this.gateway = gateway;
    }

    public String getReceiveddate() {
        return receiveddate;
    }

    public void setReceiveddate(String receiveddate) {
        this.receiveddate = receiveddate;
    }

    public String getTraceid() {
        return traceid;
    }

    public void setTraceid(String traceid) {
        this.traceid = traceid;
    }

    public String getFacility() {
        return facility;
    }

    public void setFacility(String facility) {
        this.facility = facility;
    }



    public String getMsgsenddatetime() {
        return msgsenddatetime;
    }

    public void setMsgsenddatetime(String msgsenddatetime) {
        this.msgsenddatetime = msgsenddatetime;
    }

    public String getRequesttype() {
        return requesttype;
    }

    public void setRequesttype(String requesttype) {
        this.requesttype = requesttype;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getReqdateandtime() {
        return reqdateandtime;
    }

    public void setReqdateandtime(String reqdateandtime) {
        this.reqdateandtime = reqdateandtime;
    }

    @Override
    public String toString() {
        return "storeOpenCloseMessages{" +
                "receiveddate='" + receiveddate + '\'' +
                ", gateway='" + gateway + '\'' +
                ", traceid='" + traceid + '\'' +
                ", facility='" + facility + '\'' +
                ", reqdateandtime='" + reqdateandtime + '\'' +
                ", msgsenddatetime='" + msgsenddatetime + '\'' +
                ", requesttype='" + requesttype + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
