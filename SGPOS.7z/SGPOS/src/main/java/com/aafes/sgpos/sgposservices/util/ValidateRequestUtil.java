package com.aafes.sgpos.sgposservices.util;



import com.aafes.sgpos.sgposservices.generated.Control.CVSRequest;
import com.aafes.sgpos.sgposservices.generated.Control.SGPOSServices;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;
import java.util.regex.Pattern;

public class ValidateRequestUtil {
    private static Pattern p = Pattern.compile("^[0-9]+$");
    private static final Logger LOG = (Logger) LoggerFactory.getLogger(ValidateRequestUtil.class);

    public String validateFieldsAdd(SGPOSServices request) throws ParseException {
        if (null != request.getCVSRequest()) {
            String cid = request.getCVSRequest().getCashbackRequestedAmount();
            String account = request.getCVSRequest().getCustomerID();
            if(request.getCVSRequest().getCustomerType().equals(CVSRequest.CustomerType.SSN)){
               try{
                                int ssn= Integer.parseInt(account);

             }
             catch(NumberFormatException ex){
                 return "INVALID_REQUEST";
             }

               
            }

//            if (request.getCVSRequest().getRequestType().()) {
//            request.getCVSRequest().setRequestType("inquiry");
//            }
        }
        else if  (null != request.getIGLASRequest()){
            String account = request.getIGLASRequest().getSsn();
            if (null != request.getIGLASRequest().getSsn()) {
                try {
                    int ssn = Integer.parseInt(account);

                } catch (NumberFormatException ex) {
                    return "INVALID_REQUEST";
                }
            }
               
            

//            String accountIglas = request.getIGLASRequest().getAccount();
//            if (null !=request.getIGLASRequest().getGLAcct() && !request.getIGLASRequest().getGLAcct().isEmpty()) {
//                request.getIGLASRequest().setGLIdentifier("F1:");
//                request.getIGLASRequest().setRecordSeperator1("\u001E");
//            }
//            if (null !=request.getIGLASRequest().getFacilityNumber() && !request.getIGLASRequest().getFacilityNumber().isEmpty()) {
//                request.getIGLASRequest().setFacIdentifier("F2:");
//                request.getIGLASRequest().setRecordSeperator2("\u001E");
//            }
//            if (null !=request.getIGLASRequest().getSsn() && !request.getIGLASRequest().getSsn().isEmpty()) {
//                request.getIGLASRequest().setSSNIdentifier("F3:");
//                request.getIGLASRequest().setRecordSeperator3("\u001E");
//            }
//            if (null !=request.getIGLASRequest().getRef1() && !request.getIGLASRequest().getRef1().isEmpty()) {
//                request.getIGLASRequest().setRef1Identifier("F4:");
//                request.getIGLASRequest().setRecordSeperator4("\u001E");
//            }
//            if (null !=request.getIGLASRequest().getRef2() && !request.getIGLASRequest().getRef2().isEmpty()) {
//                request.getIGLASRequest().setRef2Identifier("F5:");
//                request.getIGLASRequest().setRecordSeperator5("\u001E");
//            }
        }else if  (null != request.getORISRequest()){
            String requestTypeOris= String.valueOf(request.getORISRequest().getRequestType());
        } else if  (null != request.getStoreOpenCloseRequest()){
            String requestTypeStore=request.getStoreOpenCloseRequest().getRequestType();
        }


        return "";
    }
    
        }
