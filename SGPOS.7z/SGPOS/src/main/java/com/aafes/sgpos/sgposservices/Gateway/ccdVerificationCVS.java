package com.aafes.sgpos.sgposservices.Gateway;


import com.aafes.sgpos.sgposservices.Config.EncryptorConfig;
import com.aafes.sgpos.sgposservices.Control.customerType;
import com.aafes.sgpos.sgposservices.generated.Control.SGPOSServices;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;


@Service
public class ccdVerificationCVS {
    private static final Logger LOG = (Logger) LoggerFactory.getLogger(ccdVerificationCVS.class);

    //    @Autowired
//    private MQConnection mqConnection;
    @Value("${ccd.CCDUserName}")
    private String CCDUserName;
    @Value("${ccd.CCDPassword}")
    private String CCDPassword;
    @Value("${ccd.CCDClientID}")
    private String CCDClientID;
    @Value("${ccd.CCDURL}")
    private String CCDURL;
    @Autowired
    private RestTemplate restTemplate;
    @Value("${timeOut.ccdCallTimeout}")
    private String ccdCallTimeout;
    @Value("${timeOut.ccdCallReadTimeout}")
    private String ccdCallReadTimeout;
    @Autowired
    EncryptorConfig encryptorConfig;

    private SimpleClientHttpRequestFactory getClientHttpRequestFactory() {

        SimpleClientHttpRequestFactory clientHttpRequestFactory = new SimpleClientHttpRequestFactory();
        clientHttpRequestFactory.setConnectTimeout(Integer.parseInt(ccdCallTimeout));
        clientHttpRequestFactory.setReadTimeout(Integer.parseInt(ccdCallReadTimeout));
        return clientHttpRequestFactory;
    }

    public JSONObject CCDCall(SGPOSServices sgposservices) throws JsonProcessingException {
        Boolean res = false;
        JSONObject ccdRes = new JSONObject();
        ObjectMapper mapper = new ObjectMapper();
        HttpHeaders headers = new HttpHeaders();
        headers.setBasicAuth(CCDUserName, encryptorConfig.decrypt(CCDPassword));
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("ClientId", CCDClientID);
        JSONObject personJsonObject = new JSONObject();
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        if (String.valueOf(sgposservices.getCVSRequest().getCustomerType()).equalsIgnoreCase(customerType.EDIPI)) {
            personJsonObject.put("DODEDIPersonalId", sgposservices.getCVSRequest().getCustomerID());
        } else {
            personJsonObject.put(sgposservices.getCVSRequest().getCustomerType(), sgposservices.getCVSRequest().getCustomerID());
        }
        //LOG.info("CCD Request :");
        String personJsonString = personJsonObject.toString();
      //  LOG.info("CCD Request: " +personJsonObject.toString()+ ":TraceID " +sgposservices.getHeader().getTraceID());
      //  LOG.info(("CCD Request:" +personJsonString.substring(0,8)+ "*".repeat(Math.max(0, personJsonString.length()-11))+ personJsonString.substring(personJsonString.length()-5)) );
              LOG.info("CCD Request:{}",personJsonString  );

        // LOG.info(personJsonObject.toString()+":TraceID " +sgposservices.getHeader().getTraceID());
        HttpEntity<String> requestCCD = new HttpEntity<String>(personJsonObject.toString(), headers);

        // TimeOut timeoutCCD=new TimeOut();
        restTemplate = new RestTemplate(this.getClientHttpRequestFactory());//timeoutCCD.getClientHttpRequestFactoryCVS());
        ResponseEntity<Object> response = restTemplate.exchange(CCDURL, HttpMethod.POST,
                requestCCD, Object.class);
       // LOG.info("CCD Response:TraceID " +sgposservices.getHeader().getTraceID());
        JSONObject obj;
        if (response.hasBody()) {
            obj = mapper.convertValue(response.getBody(), JSONObject.class);
            LOG.info("CCD Response: "+ obj.toString() );
            switch (obj.get("respStatus").toString()) {
                
                case "000" -> {
                    if (String.valueOf(sgposservices.getCVSRequest().getCustomerType()).equalsIgnoreCase(customerType.SSN)) {
                        ccdRes.put("ccdCall", true);
                    } else {
                        JSONObject c = mapper.convertValue(obj.get("Customer"), JSONObject.class);
                        ccdRes.put("ccdCall", true);
                        ccdRes.put("ssn", c.get("SSN").toString());
                        //  ccdRes.put("ssn", responseCCDJson.getJSONObject("customer").optString("ssn"));
                    }
                }
                case "100" -> {
                    if (String.valueOf(sgposservices.getCVSRequest().getCustomerType()).equalsIgnoreCase(customerType.SSN)) {
                        ccdRes.put("ccdCall", true);
                        ccdRes.put("reasonCode", obj.get("respStatus").toString());
                    } else {
                        ccdRes.put("ccdCall", false);
                        ccdRes.put("reasonCode", obj.get("respStatus").toString());
                    }
                }
                case "101" -> {
                    if (String.valueOf(sgposservices.getCVSRequest().getCustomerType()).equalsIgnoreCase(customerType.SSN)) {
                        ccdRes.put("ccdCall", true);
                        ccdRes.put("reasonCode", obj.get("respStatus").toString());
                        //    if(null!=c && null!=c.get("SSN").toString()) {
                        ccdRes.put("ssn", sgposservices.getCVSRequest().getCustomerID());
                        // }
                    } else {
                        ccdRes.put("ccdCall", false);
                        ccdRes.put("reasonCode", obj.get("respStatus").toString());
                    }
                }
                case "102" -> {
                    ccdRes.put("ccdCall", false);
                    ccdRes.put("reasonCode", obj.get("respStatus").toString());
                }
                case "901" -> {
                    ccdRes.put("ccdCall", false);
                    ccdRes.put("reasonCode", obj.get("respStatus").toString());
                }
                default -> {
                    ccdRes.put("ccdCall", false);
                    ccdRes.put("reasonCode", "902");
                }

            }
        }
        return ccdRes;
    }

}
