package com.aafes.sgpos.sgposservices.Entity;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="fac_fmf")
public class fac_fmf {
    @Id
    private String FAC_NUM10;
    private String FAC_MGR;
    private String PHONE_NUM;

    public String getFAC_MGR() {
        return FAC_MGR;
    }

    public void setFAC_MGR(String FAC_MGR) {
        this.FAC_MGR = FAC_MGR;
    }

    public String getPHONE_NUM() {
        return PHONE_NUM;
    }

    public void setPHONE_NUM(String PHONE_NUM) {
        this.PHONE_NUM = PHONE_NUM;
    }

    public String getFAC_NUM10() {
        return FAC_NUM10;
    }

    public void setFAC_NUM10(String FAC_NUM10) {
        this.FAC_NUM10 = FAC_NUM10;
    }

    @Override
    public String toString() {
        return "fac_fmf{" +
                "FAC_NUM10='" + FAC_NUM10 + '\'' +
                ", FAC_MGR='" + FAC_MGR + '\'' +
                ", PHONE_NUM='" + PHONE_NUM + '\'' +
                '}';
    }
}
