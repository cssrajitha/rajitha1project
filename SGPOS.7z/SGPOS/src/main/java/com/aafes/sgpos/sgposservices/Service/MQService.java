package com.aafes.sgpos.sgposservices.Service;

import com.aafes.sgpos.sgposservices.Exception.GatewayException;
import com.aafes.sgpos.sgposservices.Config.EncryptorConfig;
import com.aafes.sgpos.sgposservices.Config.CorrelationId;
import com.aafes.sgpos.sgposservices.Gateway.MQMessage;
import com.aafes.sgpos.sgposservices.generated.Control.SGPOSServices;
import com.aafes.sgpos.sgposservices.util.BuildErrorResponseUtil;
import com.ibm.msg.client.jakarta.wmq.WMQConstants;
import jakarta.jms.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;


import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.UUID;

@Service
public class MQService {
    private static final Logger LOG = (Logger) LoggerFactory.getLogger(MQService.class);

    static final DecimalFormat TIME_FORMAT = new DecimalFormat("0000;0000");
    private static final Charset ASCII = Charset.forName("ISO-8859-1");
    @Autowired
    BuildErrorResponseUtil buildErrorResponseUtil;
    @Autowired
    EncryptorConfig encryptorConfig;
    @Autowired
    @Qualifier("sgposmq")
    private MQMessage mqMessage;

    @Value("${spring.jms.ibm.mq.queue-manager-1.responseQ}")
    private String replyToQ;

    //MQ Connection for trafficCop
    public String mqConnection(String payload, SGPOSServices sgposServices) {
        String textStringAS = null;
        try {
            Message message = null;
            byte[] responsePayload = null;
            CorrelationId cvsIglasCorrelationId = new CorrelationId();
            String correlationId = new String(cvsIglasCorrelationId.getCorrelationIDWithCalendar());
          //  String correlationId = new String(getCorrelationIDWithCalendar());
            LOG.debug(payload +"a--------------"+correlationId);
            LOG.info("Sending message to MQConnection " );
            message = mqMessage.sendMessageQue(payload, correlationId, sgposServices);
            if (message == null) {
                LOG.info("No message was received.");
            } else if (!message.toString().isEmpty()) {

                if (message instanceof BytesMessage) {

                   // System.out.println("We have a ByteMessage response Payload so process it accordingly: TraceID " +sgposServices.getHeader().getTraceID());

                    BytesMessage bm1 = (BytesMessage) message;
                    responsePayload = new byte[(int) bm1.getBodyLength()];
                    bm1.readBytes(responsePayload);
                    byte[] FormattedData = Arrays.copyOfRange(responsePayload, 195, responsePayload.length - 1);

                    String codePage = message.getStringProperty(WMQConstants.JMS_IBM_CHARACTER_SET);
                    String textString = new String(responsePayload, codePage);
                    //                 String textString1 = new String(responsePayload, Charset.forName("IBM037"));
//                System.out.println("RESPONSE: IBM037 "+textString1);

                    textStringAS = new String(FormattedData, StandardCharsets.US_ASCII);
                     if (null != sgposServices.getCVSRequest()) {
                         LOG.info("Response received from MQConnection CVS: " +textStringAS);
                         LOG.debug("Response received from MQConnection CVS:  " + textStringAS);
                         } else if (null != sgposServices.getIGLASRequest()) {
                         LOG.info("Response received from MQConnection IGLAS: " +textStringAS);
                         LOG.debug("Response received from MQConnection IGLAS:  " + textStringAS);
                     }

//               String AschiString= new String(FormattedData, Charset.forName("ISO-8859-1"));
//
//                System.out.println("RESPONSE: "+AschiString);
                } else if (message instanceof TextMessage) {

                  //  System.out.println("We have a TextMessage response Payload so processing it accordingly");

                    TextMessage tm = (TextMessage) message;
                    responsePayload = tm.getText().getBytes();
                }  else {
                    LOG.info("The message received was of an unknown type.");
                }
            } else {
                if (null != sgposServices.getCVSRequest()) {
                    LOG.info("CVS Connection time out" );
                    sgposServices = buildErrorResponseUtil.buildErrorResponseAdd(sgposServices, "CVS_TIME_OUT");
                } else if (null != sgposServices.getIGLASRequest()) {
                    LOG.info("IGLAS Connection time out ");
                    sgposServices = buildErrorResponseUtil.buildErrorResponseAdd(sgposServices, "IGLAS_TIME_OUT");
                }
            }
           // LOG.info(textStringAS +"a--------------"+correlationId);

        } catch (GatewayException e) {
            if (null != sgposServices.getCVSRequest()) {
                LOG.error("CVS Connection time out "+e );
                sgposServices = buildErrorResponseUtil.buildErrorResponseAdd(sgposServices, "CVS_TIME_OUT");
                e.printStackTrace();
            } else if (null != sgposServices.getIGLASRequest()) {
                LOG.error("IGLAS Connection time out ");
                sgposServices = buildErrorResponseUtil.buildErrorResponseAdd(sgposServices, "IGLAS_TIME_OUT");
            }
        } catch (Exception e) {
            if (null != sgposServices.getCVSRequest()) {
                LOG.error("Exception#CVS Connection time out ",e );
                sgposServices = buildErrorResponseUtil.buildErrorResponseAdd(sgposServices, "CVS_TIME_OUT");
                e.printStackTrace();
            } else if (null != sgposServices.getIGLASRequest()) {
                LOG.error("IGLAS Connection time out " ,e);
                sgposServices = buildErrorResponseUtil.buildErrorResponseAdd(sgposServices, "IGLAS_TIME_OUT");
            }
        } finally {

        }
        return textStringAS;
    }
//    @JmsListener(destination = "${spring.jms.ibm.mq.queue-manager-1.responseQ}")
//    public void receiveMessageFromQM1(Message message) {
//        LOG.info("a-------------------------------------"+String.valueOf(message));
//    }

    private static byte[] getCorrelationIDWithCalendar() {
        Calendar cal = Calendar.getInstance();
        String val = String.valueOf(cal.get(Calendar.YEAR));
        val += TIME_FORMAT.format(cal.get(Calendar.DAY_OF_YEAR));
        val += UUID.randomUUID().toString().replaceAll("-", "");
        return val.substring(0, 24).getBytes();
    }
}
