package com.ews.wallet.util;

import com.ews.wallet.entity.WalletResponseType;
import com.ews.walletservice.generated.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

@Service
public class BuildErrorResponseUtil {
    @Autowired
    private Environment env;

//    public EnterpriseWalletVault buildErrorResponse(EnterpriseWalletVault enterpriseWalletVault, String reason, String requestId, String applicationId, String uuid, String userId) {
//        //Error response mapping
//        Header header = new Header();
//        header.setApplicationid(applicationId);
//        header.setUuid(uuid);
//        header.setUserid(userId);
//        Response response = new Response();
//        response.setResponsecode(env.getProperty(reason));
//        response.setRequestid(requestId);
//        response.setResponsedescription(reason);
//        response.setResponsetype(WalletResponseType.DECLINED);
//        response.setBankcardaccount(null);
//        response.setMilstaraccount(null);
//        enterpriseWalletVault.setResponse(response);
//        enterpriseWalletVault.setHeader(header);
//        enterpriseWalletVault.setRequest(null);
//        return enterpriseWalletVault;
//    }

    public VaultAddCard buildErrorResponseAdd(VaultAddCard vaultAddCard, String reason, String requestId, String applicationId, String uuid, String userId) {
        //Error response mapping
        Header header = new Header();
        header.setApplicationid(applicationId);
        header.setUuid(uuid);
        header.setUserid(userId);
        Response response = new Response();
        response.setResponsecode(env.getProperty(reason));
        response.setRequestid(requestId);
        response.setResponsedescription(reason);
        response.setResponsetype(WalletResponseType.DECLINED);
        response.setBankcardaccount(null);
        response.setMilstaraccount(null);
        vaultAddCard.setResponse(response);
        vaultAddCard.setHeader(header);
        vaultAddCard.setRequest(null);
        return vaultAddCard;
    }

    public VaultUpdateCard buildErrorResponseUpdate(VaultUpdateCard vaultUpdateCard, String reason, String requestId, String applicationId, String uuid, String userId) {
        //Error response mapping
        Header__3 header = new Header__3();
        header.setApplicationid(applicationId);
        header.setUuid(uuid);
        header.setUserid(userId);
        Response__3 response = new Response__3();
        response.setResponsecode(env.getProperty(reason));
        response.setRequestid(requestId);
        response.setResponsedescription(reason);
        response.setResponsetype(WalletResponseType.DECLINED);
//        response.setBankcardaccount(null);
//        response.setMilstaraccount(null);
        vaultUpdateCard.setResponse(response);
        vaultUpdateCard.setHeader(header);
        vaultUpdateCard.setRequest(null);
        return vaultUpdateCard;
    }

    public VaultDeleteCard buildErrorResponseDelete(VaultDeleteCard vaultDeleteCard, String reason, String requestId, String applicationId, String uuid, String userId) {
        //Error response mapping
        Header__1 header = new Header__1();
        header.setApplicationid(applicationId);
        header.setUuid(uuid);
        header.setUserid(userId);
        Response__1 response = new Response__1();
        response.setResponsecode(env.getProperty(reason));
        response.setRequestid(requestId);
        response.setResponsedescription(reason);
        response.setResponsetype(WalletResponseType.DECLINED);
//        response.setBankcardaccount(null);
//        response.setMilstaraccount(null);
        vaultDeleteCard.setResponse(response);
        vaultDeleteCard.setHeader(header);
        vaultDeleteCard.setRequest(null);
        return vaultDeleteCard;
    }

    public VaultGetCard buildErrorResponseGet(VaultGetCard vaultGetCard, String reason, String requestId, String applicationId, String uuid, String userId) {
        //Error response mapping
        //Header header = new Header();
       Header__2 header = new Header__2();
        header.setApplicationid(applicationId);
        header.setUuid(uuid);
        header.setUserid(userId);
        Response__2 response = new Response__2();
        response.setResponsecode(env.getProperty(reason));
        response.setRequestid(requestId);
        response.setResponsedescription(reason);
        response.setResponsetype(WalletResponseType.DECLINED);
        response.setBankcardaccount(null);
        response.setMilstaraccount(null);
        vaultGetCard.setResponse(response);
        vaultGetCard.setHeader(header);
        vaultGetCard.setRequest(null);
        return vaultGetCard;
    }

    public VaultUpdateCard buildTimeoutResponse(VaultUpdateCard vaultUpdateCard, String reason, String requestId, String applicationId, String uuid, String userId) {
        // Error response mapping
        Header__3 header = new Header__3();
        header.setApplicationid(applicationId);
        header.setUuid(uuid);
        header.setUserid(userId);
        Response__3 response = new Response__3();
        response.setResponsecode(env.getProperty(reason));
        response.setRequestid(requestId);
        response.setResponsedescription(reason);
        response.setResponsetype(WalletResponseType.TIMEOUT);
        vaultUpdateCard.setResponse(response);
        vaultUpdateCard.setHeader(header);
        vaultUpdateCard.setRequest(null);
        return vaultUpdateCard;
    }

    public VaultGetCard buildTimeoutResponse(VaultGetCard vaultGetCard, String reason, String requestId, String applicationId, String uuid, String userId) {
        // Error response mapping
        Header__2 header = new Header__2();
        header.setApplicationid(applicationId);
        header.setUuid(uuid);
        header.setUserid(userId);
        Response__2 response = new Response__2();
        response.setResponsecode(env.getProperty(reason));
        response.setRequestid(requestId);
        response.setResponsedescription(reason);
        response.setResponsetype(WalletResponseType.TIMEOUT);
        response.setBankcardaccount(null);
        response.setMilstaraccount(null);
        vaultGetCard.setResponse(response);
        vaultGetCard.setHeader(header);
        vaultGetCard.setRequest(null);
        return vaultGetCard;
    }

    public VaultAddCard buildTimeoutResponse(VaultAddCard vaultAddCard, String reason, String requestId, String applicationId, String uuid, String userId) {
        // Error response mapping
        Header header = new Header();
        header.setApplicationid(applicationId);
        header.setUuid(uuid);
        header.setUserid(userId);
        Response response = new Response();
        response.setResponsecode(env.getProperty(reason));
        response.setRequestid(requestId);
        response.setResponsedescription(reason);
        response.setResponsetype(WalletResponseType.TIMEOUT);
        response.setBankcardaccount(null);
        response.setMilstaraccount(null);
        vaultAddCard.setResponse(response);
        vaultAddCard.setHeader(header);
        vaultAddCard.setRequest(null);
        return vaultAddCard;
    }
    public VaultDeleteCard buildTimeoutResponse(VaultDeleteCard vaultDeleteCard, String reason, String requestId, String applicationId, String uuid, String userId) {
        // Error response mapping
        Header__1 header = new Header__1();
        header.setApplicationid(applicationId);
        header.setUuid(uuid);
        header.setUserid(userId);
        Response__1 response = new Response__1();
        response.setResponsecode(env.getProperty(reason));
        response.setRequestid(requestId);
        response.setResponsedescription(reason);
        response.setResponsetype(WalletResponseType.TIMEOUT);
        vaultDeleteCard.setResponse(response);
        vaultDeleteCard.setHeader(header);
        vaultDeleteCard.setRequest(null);
        return vaultDeleteCard;
    }



    public void setEnv(Environment env) {
        this.env = env;
    }
}
