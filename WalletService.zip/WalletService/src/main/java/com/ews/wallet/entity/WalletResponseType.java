package com.ews.wallet.entity;

final public class WalletResponseType {
    public static final String APPROVED = "Approved";
    public static final String DECLINED = "Decline";
    public static final String TIMEOUT = "TIMEOUT";
}
