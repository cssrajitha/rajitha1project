package com.ews.wallet.configuration.feign;

import com.ews.walletservice.generated.entity.VaultGetCard;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(name = "GETCARD-SERVICE", url = "${microservice.endpoints.getcard-service}" , configuration = FeignCustomConfig.class)
public interface FeignClientConfigGetCard {
    @RequestMapping(value = "/card/get", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    public VaultGetCard getcardResponse(@RequestBody VaultGetCard gatewayRequest);

}
