package com.ews.wallet.configuration;

import org.keyczar.Crypter;
import org.keyczar.exceptions.KeyczarException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EncryptorConfig {

    private final String keysPath;

    private static final Logger LOG = (Logger) LoggerFactory.getLogger(EncryptorConfig.class);

    public EncryptorConfig(String keysPath, String logConfigPath) {
        this.keysPath = keysPath;
        System.setProperty("log4j.configuration", logConfigPath);
        LOG.info("Encryptor-> Encryptor-> System.getProperty(\"log4j.configuration\"): " + System.getProperty("log4j.configuration"));
    }

    public String decrypt(String ciphertext) {
        LOG.debug("Encryptor-> decrypt-> keysPath: " + keysPath);
        String plaintext = null;
        try {
            Crypter crypter = new Crypter(keysPath);
            LOG.debug("Encryptor-> decrypt-> Before crypter.decrypt-> ciphertext " + ciphertext);
            plaintext = crypter.decrypt(ciphertext);
            LOG.debug("Encryptor-> decrypt-> After crypter.decrypt-> plaintext " + plaintext);
        } catch (KeyczarException ex) {
            log("Keyczar is having trouble decrypting.");
            log(ex.toString());
        } catch (Exception e) {
            log("Exception in Keyczar decrypting.");
            log(e.toString());
        }
        return plaintext;
    }

    public String encrypt(String plaintext) {
        String ciphertext = null;
        try {
            Crypter crypter = new Crypter(keysPath);
            ciphertext = crypter.encrypt(plaintext);
        } catch (KeyczarException ex) {
            LOG.error("Keyczar is having trouble encrypting.");
            LOG.error(ex.toString());
        }
        return ciphertext;
    }

    public byte[] decrypt(byte[] cipherBytes) {
        byte[] plainBytes = null;
        try {
            Crypter crypter = new Crypter(keysPath);
            plainBytes = crypter.decrypt(cipherBytes);
        } catch (KeyczarException ex) {
            LOG.error("Keyczar is having trouble decrypting a byte array.");
            LOG.error(ex.toString());
        }
        return plainBytes;
    }

    public byte[] encrypt(byte[] plainBytes) {
        byte[] cipherBytes = null;
        try {
            Crypter crypter = new Crypter(keysPath);
            cipherBytes = crypter.encrypt(plainBytes);
        } catch (KeyczarException ex) {
            LOG.error("Keyczar is having trouble encrypting a byte array.");
            LOG.error(ex.toString());
        }
        return cipherBytes;
    }

    private void log(String s) {
        System.err.println(s);
    }

}

