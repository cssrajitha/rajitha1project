package com.ews.wallet.controller;

import com.ews.wallet.configuration.OauthValidation;
import com.ews.wallet.configuration.feign.FeignClientConfigAddCard;
import com.ews.wallet.configuration.feign.FeignClientConfigDeleteCard;
import com.ews.wallet.configuration.feign.FeignClientConfigGetCard;
import com.ews.wallet.configuration.feign.FeignClientConfigUpdateCard;
import com.ews.wallet.entity.OauthResponse;
import com.ews.wallet.entity.WalletResponseType;
import com.ews.wallet.util.BuildErrorResponseUtil;
import com.ews.wallet.util.ValidateRequestUtil;
import com.ews.wallet.util.ValidateSchemaUtil;
import com.ews.walletservice.generated.entity.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.networknt.schema.JsonSchema;
import com.networknt.schema.JsonSchemaFactory;
import com.networknt.schema.SpecVersion;
import feign.FeignException;

import jakarta.annotation.PostConstruct;

import jakarta.servlet.http.HttpServletResponse;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.apache.http.impl.client.HttpClientBuilder;


import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.text.ParseException;
import java.util.List;

@RestController
@RequestMapping("/enterprisewalletservice")
public class WalletController {

    private static final ObjectMapper OBJECT_MAPPER;
    private JsonSchema schema;
    private static JsonSchemaFactory schemaFactory;
    private JsonSchema schemaAdd;
    private JsonSchema schemaGet;
    private JsonSchema schemaUpdate;
    private JsonSchema schemaDelete;
    private InputStream schemaStreamAdd;
    private InputStream schemaStreamGet;
    private InputStream schemaStreamDelete;
    private InputStream schemaStreamUpdate;

    private  String serviceType = "WalletService";

    @Autowired
    private Environment env;

    @Autowired
    OauthValidation oauthValidation;

    static {
        OBJECT_MAPPER = new ObjectMapper();
        OBJECT_MAPPER.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, false);
        OBJECT_MAPPER.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    @PostConstruct
    public void schemaInit() throws IOException {
        LOG.info("INSIDE schemainit");
        try {
            String pathadd = env.getProperty("jsonPath.add");
            String pathget = env.getProperty("jsonPath.get");
            String pathdelete = env.getProperty("jsonPath.delete");
            String pathupdate = env.getProperty("jsonPath.update");
            schemaFactory = JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V7);

            schemaStreamAdd = new BufferedInputStream(new FileInputStream(pathadd));
            schemaStreamGet = new BufferedInputStream(new FileInputStream(pathget));
            schemaStreamUpdate = new BufferedInputStream(new FileInputStream(pathupdate));
            schemaStreamDelete = new BufferedInputStream(new FileInputStream(pathdelete));

            schemaAdd = schemaFactory.getSchema(schemaStreamAdd);
            schemaGet = schemaFactory.getSchema(schemaStreamGet);
            schemaUpdate = schemaFactory.getSchema(schemaStreamUpdate);
            schemaDelete = schemaFactory.getSchema(schemaStreamDelete);

            LOG.info("EXITING schemainit");
        } catch (Exception e) {
            LOG.info("Exception occured: " + e);
        } finally {
            schemaStreamAdd.close();
            schemaStreamGet.close();
            schemaStreamUpdate.close();
            schemaStreamDelete.close();
        }

    }

    private static final Logger LOG = (Logger) LoggerFactory.getLogger(WalletController.class);
    @Value("${microservice.endpoints.addcard-service}")
    private String addCardEndpointUrl;
    @Value("${microservice.endpoints.getcard-service}")
    private String getCardEndpointUrl;
    @Value("${microservice.endpoints.updatecard-service}")
    private String updateCardEndpointUrl;
    @Value("${microservice.endpoints.deletecard-service}")
    private String deleteCardEndpointUrl;
    ValidateSchemaUtil validateSchemaUtil = new ValidateSchemaUtil();
    @Autowired
    ValidateRequestUtil validateRequestUtil;
    @Autowired
    BuildErrorResponseUtil buildErrorResponseUtil;

    @Autowired
    private FeignClientConfigAddCard feignClientConfigAddCard;
    @Autowired
    private FeignClientConfigUpdateCard feignClientConfigUpdateCard;
    @Autowired
    private FeignClientConfigGetCard feignClientConfigGetCard;
    @Autowired
    private FeignClientConfigDeleteCard feignClientConfigDeleteCard;
    @Autowired
    DiscoveryClient discoveryClient;
    @Value("${feign.retry}")
    private String retryFeign;

    @PutMapping
    public VaultAddCard addService(@RequestBody String gatewayRequest, @RequestHeader(value = "Authorization") String autherization, HttpServletResponse responseClient) throws ParseException, JsonProcessingException {
// /       LOG.info("Inside Wallet Service controller to call Add card");
        String responseToClient = "";
        String requestId = "";
        String applicationId = "";
        String uuid = "";
        String userId = "";
        String requestType = "";
        String cardType = "";
        LOG.info("Request received from client-> " + maskSensitiveRequestData(gatewayRequest));
        JSONObject request = new JSONObject(gatewayRequest);
        if (!request.isNull("request")) {
            requestType = request.getJSONObject("request").optString("requesttype");
            requestId = request.getJSONObject("request").optString("requestid");
            cardType = request.getJSONObject("request").optString("cardtype");
        }
        MDC.put("requestId", requestId);
        MDC.put("serviceType", serviceType);
        if (!request.isNull("header")) {
            JSONObject header = request.getJSONObject("header");
            if (!header.isNull("applicationid")) {
                applicationId = header.optString("applicationid");
            }
            if (!header.isNull("userid")) {
                userId = header.optString("userid");
            }
            if (!header.isNull("uuid")) {
                uuid = header.optString("uuid");
            }
        }
        LOG.info("Token received from client-> RequestId : " +requestId+" Token : "+ autherization);
        String authToken = null;
        if (null != autherization 
                && (autherization.contains("Bearer")
                     || autherization.contains("bearer")) ) {
            authToken = autherization.split(" ").length==2?autherization.split(" ")[1]:"";
        }else {
               authToken = autherization;
        }
        OauthResponse oauthResponse = new OauthResponse();
        oauthResponse = oauthValidation.oauthTokenValidation(authToken,requestId,requestType,applicationId);
         VaultAddCard vaultAddCard = new VaultAddCard();
         long starTime = System.nanoTime();
         StringBuilder tempString = new StringBuilder();
        
       // LOG.info("response from oauth-> " + oauthResponse.getActive()+ oauthResponse.getReasonCode());
        if(null !=oauthResponse.getActive() && oauthResponse.getActive().equalsIgnoreCase("true")) {
       
        
       
        try {
//            LOG.info("Performing Request Validation");
            vaultAddCard = walletServiceAdd(gatewayRequest, request ,  requestId , applicationId , userId , uuid );
            //requestType = vaultAddCard.getRequest().getRequesttype().value();
            //cardType = vaultAddCard.getRequest().getCardtype().value();
            if (null == vaultAddCard.getResponse() || !WalletResponseType.DECLINED.equalsIgnoreCase(vaultAddCard.getResponse().getResponsetype())) {
//                LOG.info("Request received from client-> " + maskSensitiveRequestData(gatewayRequest));
                if (Request.Requesttype.ADDCARD.value().equalsIgnoreCase(vaultAddCard.getRequest().getRequesttype().value())) {
                    LOG.info("RequestId : "+requestId+" Call to add-card : " + addCardEndpointUrl);
//                    enterpriseWalletVault = restTemplate.postForObject(addCardEndpointUrl, enterpriseWalletVault, EnterpriseWalletVault.class);
                    try {
                        LOG.info("RequestId : "+requestId+" 1st Call from feign");
                        vaultAddCard = feignClientConfigAddCard.addcardResponse(vaultAddCard);
                        }catch (FeignException e) {
                            String errorMessage = e.getMessage();
                            int status = e.status();
                            if (status == -1 && errorMessage.contains("timed out") ||
                                    errorMessage.contains("Connection refused")) {
                                LOG.info("RequestId:{}, Exception caught during 1st feign call -> {}",requestId, e.getLocalizedMessage());
                                if("true".equals(retryFeign)){
                                    if (e.getLocalizedMessage().contains("Load balancer does not have available server for client")) {
                                        // throw new ClientException(e);
                                    }
                                    String url = "";
                                    List<ServiceInstance> list = discoveryClient.getInstances("ADDCARD-SERVICE");
                                    URI chosenServer = null;
                                    if (list != null && list.size() > 0) {
                                        LOG.info(" RequestId:{}, list of url from discovery client get instance -> {} ",requestId, list);
                                        chosenServer = list.get(0).getUri();
                                        String convertedURL = chosenServer.toString();
                                        if (!this.isAlive(convertedURL)) {
                                            for (ServiceInstance nextServer : list) {
                                                if (!nextServer.getUri().toString().equalsIgnoreCase(chosenServer.toString()) && this.isAlive(nextServer.getUri().toString())) {
                                                    chosenServer = nextServer.getUri();
                                                    LOG.info(" RequestId:{} , list of url from discovery client get instance -> {}",requestId, list);
                                                }
                                            }
                                        }
                                    }
                                    if (null != chosenServer) {
                                        url = chosenServer.toString();
                                        LOG.info(" RequestId : {}, Sending request to final chosen URL -> {} for 2nd  ",requestId, url);
                                        RestTemplate restTemplate = new RestTemplate();
                                        vaultAddCard = restTemplate.postForObject(url + "/card/add", vaultAddCard, VaultAddCard.class);
                                    }
                                }
                                LOG.info(" RequestId: {},Timeout occurred:  {}",requestId, errorMessage);
                                vaultAddCard = buildErrorResponseUtil.buildTimeoutResponse(vaultAddCard, "SERVICE_TIMEOUT", requestId, applicationId, uuid, userId);
                            }else{
                                LOG.error("RequestId : "+requestId+" Error from call to add-card: " + e);
                                vaultAddCard = buildErrorResponseUtil.buildErrorResponseAdd(vaultAddCard, "INTERNAL_SERVER_ERROR", requestId, applicationId, uuid, userId);

                            }
                        }  catch (Exception ex) {
                            LOG.error("RequestId : "+requestId+" Error from call to add-card: " + ex);
                            vaultAddCard = buildErrorResponseUtil.buildErrorResponseAdd(vaultAddCard, "INTERNAL_SERVER_ERROR", requestId, applicationId, uuid, userId);

                        }
                } else {
                    LOG.info("RequestId : "+requestId+" PUT mapping used for ADD CARD "+requestId);
                    vaultAddCard = buildErrorResponseUtil.buildErrorResponseAdd(vaultAddCard, "INVALID_REQUEST", requestId, applicationId, uuid, userId);
                    //enterpriseWalletVault.setRequest(null);
                }
            } else {
                LOG.info("RequestId : "+requestId+" Request Validation Failed. Not processing further ");
            }
        } catch (Exception ex) {
            LOG.error("Error from call to add-card: " + ex);
            // enterpriseWalletVault.setRequest(gatewayRequest.getRequest());
            vaultAddCard = buildErrorResponseUtil.buildErrorResponseAdd(vaultAddCard, "INTERNAL_SERVER_ERROR", requestId, applicationId, uuid, userId);
            //enterpriseWalletVault.setRequest(null);
        }
        if (null != vaultAddCard) {
            if (null == vaultAddCard.getResponse().getBankcardaccount() || vaultAddCard.getResponse().getBankcardaccount().isEmpty()) {
                vaultAddCard.getResponse().setBankcardaccount(null);
            }
            if (null == vaultAddCard.getResponse().getMilstaraccount() || vaultAddCard.getResponse().getMilstaraccount().isEmpty()) {
                vaultAddCard.getResponse().setMilstaraccount(null);
            }
        } else {
            vaultAddCard = buildErrorResponseUtil.buildErrorResponseAdd(vaultAddCard, "INTERNAL_SERVER_ERROR", requestId, applicationId, uuid, userId);
        }
        vaultAddCard.setRequest(null);
        responseToClient = OBJECT_MAPPER.writeValueAsString(vaultAddCard);
        LOG.info("Response sent to client-> " + responseToClient);
        long endTime = System.nanoTime();

        long timeElapsed = (endTime - starTime) / 1000000;

        LOG.info(tempString.append("Elapsed_Time_Wallet|")
                .append(applicationId)
                .append("|")
                .append(uuid)
                .append("|")
                .append(userId)
                .append("|")
                .append(requestId)
                .append("|")
                .append(requestType)
                .append("|")
                .append(cardType)
                .append("|")
                .append(vaultAddCard.getResponse().getResponsecode())
                .append("|")
                .append(vaultAddCard.getResponse().getResponsedescription())
                .append("|")
                .append(vaultAddCard.getResponse().getResponsetype())
                .append("|")
                .append(timeElapsed)
                .append(" ms")
                .toString());
        tempString.setLength(0);
        }else {
        long endTime = System.nanoTime();

        long timeElapsed = (endTime - starTime) / 1000000;
        vaultAddCard.setAdditionalProperty("error_description", "The access token provided is invalid.");
        vaultAddCard.setAdditionalProperty("error", "invalid_token");
        LOG.info(tempString.append("Elapsed_Time_Wallet|")
                .append(requestType)
                .append("|")
                .append(requestId)
                .append("|")
                .append("invalid_token")
                .append("|")
                .append("The access token provided is invalid.")
                .append("|")
                .append(timeElapsed)
                .append(" ms")
                .toString());
        tempString.setLength(0);
        responseClient.setStatus(401);
        }
        MDC.remove("requestId");
        return vaultAddCard;
    }

    @PostMapping
    public VaultGetCard cardService(@RequestBody String gatewayRequest, @RequestHeader(value = "Authorization") String autherization, HttpServletResponse responseClient) throws ParseException, JsonProcessingException {
//        LOG.info("Inside Wallet Service Controller to call get card");
        String responseToClient = "";
        String requestId = "";
        String applicationId = "";
        String uuid = "";
        String userId = "";
        String requestType = "";
        String cardType = "";
        LOG.info("Request received from client-> " + maskSensitiveRequestData(gatewayRequest));
        JSONObject request = new JSONObject(gatewayRequest);
        if (!request.isNull("request")) {
            requestType = request.getJSONObject("request").optString("requesttype");
            requestId = request.getJSONObject("request").optString("requestid");
        }
        MDC.put("requestId", requestId);
        MDC.put("serviceType", serviceType);
        if (!request.isNull("header")) {
            JSONObject header = request.getJSONObject("header");
            if (!header.isNull("applicationid")) {
                applicationId = header.optString("applicationid");
            }
            if (!header.isNull("userid")) {
                userId = header.optString("userid");
            }
            if (!header.isNull("uuid")) {
                uuid = header.optString("uuid");
            }
        }
        LOG.info("Token received from client-> RequestId : " +requestId+" Token : "+ autherization);
        String authToken = null;
       if (null != autherization 
                && (autherization.contains("Bearer")
                     || autherization.contains("bearer")) ) {

         authToken = autherization.split(" ").length==2?autherization.split(" ")[1]:"";
        }else {
               authToken = autherization;
    }
        VaultGetCard vaultGetCard = new VaultGetCard();
        StringBuilder tempString = new StringBuilder();
      
        long starTime = System.nanoTime();
        OauthResponse oauthResponse = new OauthResponse();
        oauthResponse = oauthValidation.oauthTokenValidation(authToken,requestId,requestType,applicationId);
       // LOG.info("response from oauth-> " + oauthResponse.getActive()+ oauthResponse.getReasonCode());
        if(null !=oauthResponse.getActive() && oauthResponse.getActive().equalsIgnoreCase("true")) {
       
        try {
//            LOG.info("Performing Request Validation");
            vaultGetCard = walletServiceGet(gatewayRequest, request ,requestId , applicationId , userId , uuid );
            if (null == vaultGetCard.getResponse() || !WalletResponseType.DECLINED.equalsIgnoreCase(vaultGetCard.getResponse().getResponsetype())) {
                if (Request__2.Requesttype.GETCARD.value().equalsIgnoreCase(vaultGetCard.getRequest().getRequesttype().value())) {
                    LOG.info("RequestId: "+requestId+" Call to get-card : " + getCardEndpointUrl);
//                    vaultGetCard = restTemplate.postForObject(getCardEndpointUrl, vaultGetCard, VaultGetCard.class);
                    try {
                        LOG.info("RequestId : "+requestId+"1st Call from feign");
                        vaultGetCard = feignClientConfigGetCard.getcardResponse(vaultGetCard);
                        }catch (FeignException e) {
                            String errorMessage = e.getMessage();
                            int status = e.status();
                            if (status == -1 && errorMessage.contains("timed out") ||
                                    errorMessage.contains("Connection refused")) {
                                LOG.info("RequestId : {},Exception caught during 1st feign call -> {}",requestId, e.getLocalizedMessage());
                                if ("true".equals(retryFeign)) {
                                    if (e.getLocalizedMessage().contains("Load balancer does not have available server for client")) {
                                        //throw new ClientException(e);
                                    }
                                    String url = "";
                                    List<ServiceInstance> list = discoveryClient.getInstances("GETCARD-SERVICE");
                                    URI chosenServer = null;
                                    if (list != null && list.size() > 0) {
                                        LOG.info("RequestId : {}, list of url from discovery client get instance -> {}",requestId, list);
                                        chosenServer = list.get(0).getUri();
                                        String convertedURL = chosenServer.toString();
                                        if (!this.isAlive(convertedURL)) {
                                            for (ServiceInstance nextServer : list) {
                                                if (!nextServer.getUri().toString().equalsIgnoreCase(chosenServer.toString()) && this.isAlive(nextServer.getUri().toString())) {
                                                    chosenServer = nextServer.getUri();
                                                }
                                            }
                                        }
                                    }
                                    if (null != chosenServer) {
                                        url = chosenServer.toString();
                                        LOG.info("RequestId : {},Sending request to final chosen URL -> {} for 2nd call",requestId, url);
                                        RestTemplate restTemplate = new RestTemplate();
                                        vaultGetCard = restTemplate.postForObject(url + "/card/get", vaultGetCard, VaultGetCard.class);
                                    }

                                }
                                LOG.info("RequestId : {}, Timeout occurred: {}", requestId,errorMessage);
                                vaultGetCard = buildErrorResponseUtil.buildTimeoutResponse(vaultGetCard, "SERVICE_TIMEOUT", requestId, applicationId, uuid, userId);
                            }else{
                                LOG.error("RequestId : "+requestId+" Error from call to get-card: " + e);
                                vaultGetCard = buildErrorResponseUtil.buildErrorResponseGet(vaultGetCard, "INTERNAL_SERVER_ERROR", requestId, applicationId, uuid, userId);
                            }
                        }  catch (Exception ex) {
                            LOG.error("RequestId : "+requestId+" Error from call to get-card: " + ex);
                            vaultGetCard = buildErrorResponseUtil.buildErrorResponseGet(vaultGetCard, "INTERNAL_SERVER_ERROR", requestId, applicationId, uuid, userId);

                        }
                    } else {
                    LOG.info("RequestId : "+requestId+" POST mapping used for GET CARD");
                    vaultGetCard = buildErrorResponseUtil.buildErrorResponseGet(vaultGetCard, "INVALID_REQUEST", requestId, applicationId, uuid, userId);
                    //vaultGetCard.setRequest(null);
                }
            } else {
                LOG.info("Request Validation Failed. Not processing further");
            }

        } catch (Exception ex) {
            LOG.error("RequestId : "+requestId+" Error from call to get-card: " + ex);
            // vaultGetCard.setRequest(gatewayRequest.getRequest());
            vaultGetCard = buildErrorResponseUtil.buildErrorResponseGet(vaultGetCard, "INTERNAL_SERVER_ERROR", requestId, applicationId, uuid, userId);
            //vaultGetCard.setRequest(null);
        }
        if (null != vaultGetCard) {
            if (null == vaultGetCard.getResponse().getBankcardaccount() || vaultGetCard.getResponse().getBankcardaccount().isEmpty()) {
                vaultGetCard.getResponse().setBankcardaccount(null);
            }
            if (null == vaultGetCard.getResponse().getMilstaraccount() || vaultGetCard.getResponse().getMilstaraccount().isEmpty()) {
                vaultGetCard.getResponse().setMilstaraccount(null);
            }
        } else {
            vaultGetCard = buildErrorResponseUtil.buildErrorResponseGet(vaultGetCard, "INTERNAL_SERVER_ERROR", requestId, applicationId, uuid, userId);
        }
        vaultGetCard.setRequest(null);
        responseToClient = OBJECT_MAPPER.writeValueAsString(vaultGetCard);
        LOG.info("Response sent to client-> " + responseToClient);
        long endTime = System.nanoTime();

        long timeElapsed = (endTime - starTime) / 1000000;

        LOG.info(tempString.append("Elapsed_Time_Wallet|")
                .append(applicationId)
                .append("|")
                .append(uuid)
                .append("|")
                .append(userId)
                .append("|")
                .append(requestId)
                .append("|")
                .append(requestType)
                .append("|")
                .append("")
                .append("|")
                .append(vaultGetCard.getResponse().getResponsecode())
                .append("|")
                .append(vaultGetCard.getResponse().getResponsedescription())
                .append("|")
                .append(vaultGetCard.getResponse().getResponsetype())
                .append("|")
                .append(timeElapsed)
                .append(" ms")
                .toString());
        tempString.setLength(0);
    }else {
        long endTime = System.nanoTime();

        long timeElapsed = (endTime - starTime) / 1000000;
        vaultGetCard.setAdditionalProperty("error_description", "The access token provided is invalid.");
        vaultGetCard.setAdditionalProperty("error", "invalid_token");
        LOG.info(tempString.append("Elapsed_Time_Wallet|")
                .append(requestType)
                .append("|")
                .append(requestId)
                .append("|")
                .append("invalid_token")
                .append("|")
                .append("The access token provided is invalid.")
                .append("|")
                .append(timeElapsed)
                .append(" ms")
                .toString());
        tempString.setLength(0);
        responseClient.setStatus(401);
        }
        MDC.remove("requestId");
        return vaultGetCard;
    }

    @PatchMapping
    public VaultUpdateCard updateService(@RequestBody String gatewayRequest, @RequestHeader(value = "Authorization") String autherization, HttpServletResponse responseClient) throws ParseException, JsonProcessingException {
        String responseToClient = "";
        String requestId = "";
        String applicationId = "";
        String uuid = "";
        String userId = "";
        String requestType = "";
        String cardType = "";
//        LOG.info("Inside Wallet Service Controller to call update card");
        LOG.info("Request received from client-> " + maskSensitiveRequestData(gatewayRequest));
        JSONObject request = new JSONObject(gatewayRequest);
        if (!request.isNull("request")) {
            requestType = request.getJSONObject("request").optString("requesttype");
            requestId = request.getJSONObject("request").optString("requestid");
            cardType = request.getJSONObject("request").optString("cardtype");
        }
        MDC.put("requestId", requestId);
        MDC.put("serviceType", serviceType);
        if (!request.isNull("header")) {
            JSONObject header = request.getJSONObject("header");
            if (!header.isNull("applicationid")) {
                applicationId = header.optString("applicationid");
            }
            if (!header.isNull("userid")) {
                userId = header.optString("userid");
            }
            if (!header.isNull("uuid")) {
                uuid = header.optString("uuid");
            }
        }
        LOG.info("Token received from client-> RequestId : " +requestId+" Token : "+ autherization);
        String authToken = null;
       if (null != autherization 
                && (autherization.contains("Bearer")
                     || autherization.contains("bearer")) ) {

            authToken = autherization.split(" ").length==2?autherization.split(" ")[1]:"";
        }else {
               authToken = autherization;
    }
        long starTime = System.nanoTime();
        VaultUpdateCard vaultUpdateCard = new VaultUpdateCard();
        StringBuilder tempString = new StringBuilder();
        OauthResponse oauthResponse = new OauthResponse();
        oauthResponse = oauthValidation.oauthTokenValidation(authToken,requestId,requestType,applicationId);
       
       // LOG.info("response from oauth-> " + oauthResponse.getActive()+ oauthResponse.getReasonCode());
        if(null !=oauthResponse.getActive() && oauthResponse.getActive().equalsIgnoreCase("true")) {
       
        try {
//            LOG.info("Performing Request Validation");
            vaultUpdateCard = walletServiceUpdate(gatewayRequest, request ,requestId , applicationId , userId , uuid );
//            requestType=vaultUpdateCard.getRequest().getRequesttype().value();
//            cardType=vaultUpdateCard.getRequest().getCardtype().value();
            if (null == vaultUpdateCard.getResponse() || !WalletResponseType.DECLINED.equalsIgnoreCase(vaultUpdateCard.getResponse().getResponsetype())) {
                if (Request__3.Requesttype.UPDATECARD.value().equalsIgnoreCase(vaultUpdateCard.getRequest().getRequesttype().value())) {
                    LOG.info("RequestId : "+requestId+" Call to update-card : " + updateCardEndpointUrl);
//                    vaultUpdateCard = restTemplate.postForObject(updateCardEndpointUrl, vaultUpdateCard, vaultUpdateCard.class);
                    try {
                        LOG.info("RequestId : "+requestId+" 1st Call from feign");
                        vaultUpdateCard = feignClientConfigUpdateCard.updatecardResponse(vaultUpdateCard);
                        }catch (FeignException e) {
                            String errorMessage = e.getMessage();
                            int status = e.status();
                            if (status == -1 && errorMessage.contains("timed out") ||
                                    errorMessage.contains("Connection refused")) {
                                LOG.info(" RequestId : {},Exception caught during 1st feign call -> {}",requestId, e.getLocalizedMessage());
                                if ("true".equals(retryFeign)) {
                                    if (e.getLocalizedMessage().contains("Load balancer does not have available server for client")) {
                                        //throw new ClientException(e);
                                    }
                                    String url = "";
                                    List<ServiceInstance> list = discoveryClient.getInstances("UPDATECARD-SERVICE");
                                    URI chosenServer = null;
                                    if (list != null && list.size() > 0) {
                                        LOG.info("RequestId : {},list of url from discovery client get instance -> {}",requestId, list);
                                        chosenServer = list.get(0).getUri();
                                        String convertedURL = chosenServer.toString();
                                        if (!this.isAlive(convertedURL)) {
                                            for (ServiceInstance nextServer : list) {
                                                if (!nextServer.getUri().toString().equalsIgnoreCase(chosenServer.toString()) && this.isAlive(nextServer.getUri().toString())) {
                                                    chosenServer = nextServer.getUri();
                                                }
                                            }
                                        }
                                    }
                                    if (null != chosenServer) {
                                        url = chosenServer.toString();
                                        LOG.info("RequestId : {},Sending request to final chosen URL -> {} for 2nd call", requestId,url);
                                        RestTemplate restTemplate = new RestTemplate();
                                        vaultUpdateCard = restTemplate.postForObject(url + "/card/update", vaultUpdateCard, VaultUpdateCard.class);
                                    }

                                }
                                LOG.info("RequestId : "+requestId+" Timeout occurred: {}", errorMessage);
                                vaultUpdateCard = buildErrorResponseUtil.buildTimeoutResponse(vaultUpdateCard, "SERVICE_TIMEOUT", requestId, applicationId, uuid, userId);
                            }else{
                                LOG.error("RequestId : "+requestId+" Error from call to update-card: " + e);
                                vaultUpdateCard = buildErrorResponseUtil.buildErrorResponseUpdate(vaultUpdateCard, "INTERNAL_SERVER_ERROR", requestId, applicationId, uuid, userId);
                            }
                        }  catch (Exception ex) {
                            LOG.error("RequestId : "+requestId+" Error from call to update-card: " + ex);
                            vaultUpdateCard = buildErrorResponseUtil.buildErrorResponseUpdate(vaultUpdateCard, "INTERNAL_SERVER_ERROR", requestId, applicationId, uuid, userId);

                        }
                    } else {
                    LOG.info("RequestId : "+requestId+" PATCH mapping used for UPDATE CARD");
                    vaultUpdateCard = buildErrorResponseUtil.buildErrorResponseUpdate(vaultUpdateCard, "INVALID_REQUEST", requestId, applicationId, uuid, userId);
                    //vaultUpdateCard.setRequest(null);
                }
            } else {
                LOG.info("RequestId : "+requestId+" Request Validation Failed. Not processing further");
            }
        } catch (Exception ex) {
            LOG.error("RequestId : "+requestId+" Error from call to update-card: " + ex);
            // vaultUpdateCard.setRequest(gatewayRequest.getRequest());
            vaultUpdateCard = buildErrorResponseUtil.buildErrorResponseUpdate(vaultUpdateCard, "INTERNAL_SERVER_ERROR", requestId, applicationId, uuid, userId);
            //vaultUpdateCard.setRequest(null);
        }
        if (null == vaultUpdateCard) {
//            if (null == vaultUpdateCard.getResponse().getBankcardaccount() || vaultUpdateCard.getResponse().getBankcardaccount().isEmpty()) {
//                vaultUpdateCard.getResponse().setBankcardaccount(null);
//            }
//            if (null == vaultUpdateCard.getResponse().getMilstaraccount() || vaultUpdateCard.getResponse().getMilstaraccount().isEmpty()) {
//                vaultUpdateCard.getResponse().setMilstaraccount(null);
//            }

            vaultUpdateCard = buildErrorResponseUtil.buildErrorResponseUpdate(vaultUpdateCard, "INTERNAL_SERVER_ERROR", requestId, applicationId, uuid, userId);
        }
        vaultUpdateCard.setRequest(null);
        responseToClient = OBJECT_MAPPER.writeValueAsString(vaultUpdateCard);
        LOG.info("Response sent to client-> " + responseToClient);
        long endTime = System.nanoTime();

        long timeElapsed = (endTime - starTime) / 1000000;

        LOG.info(tempString.append("Elapsed_Time_Wallet|")
                .append(applicationId)
                .append("|")
                .append(uuid)
                .append("|")
                .append(userId)
                .append("|")
                .append(requestId)
                .append("|")
                .append(requestType)
                .append("|")
                .append(cardType)
                .append("|")
                .append(vaultUpdateCard.getResponse().getResponsecode())
                .append("|")
                .append(vaultUpdateCard.getResponse().getResponsedescription())
                .append("|")
                .append(vaultUpdateCard.getResponse().getResponsetype())
                .append("|")
                .append(timeElapsed)
                .append(" ms")
                .toString());
        tempString.setLength(0);
    }else {
        long endTime = System.nanoTime();

        long timeElapsed = (endTime - starTime) / 1000000;

        vaultUpdateCard.setAdditionalProperty("error_description", "The access token provided is invalid.");
        vaultUpdateCard.setAdditionalProperty("error", "invalid_token");
        LOG.info(tempString.append("Elapsed_Time_Wallet|")
                .append(requestType)
                .append("|")
                .append(requestId)
                .append("|")
                .append("invalid_token")
                .append("|")
                .append("The access token provided is invalid.")
                .append("|")
                .append(timeElapsed)
                .append(" ms")
                .toString());
        tempString.setLength(0);
        responseClient.setStatus(401);
        }
        MDC.remove("requestId");
        return vaultUpdateCard;
    }

    @DeleteMapping
    public VaultDeleteCard deleteService(@RequestBody String gatewayRequest, @RequestHeader(value = "Authorization") String autherization, HttpServletResponse responseClient) throws ParseException, JsonProcessingException {
//        LOG.info("Inside Wallet Service Controller to call delete card");
        String responseToClient = "";
        String requestId = "";
        String applicationId = "";
        String uuid = "";
        String userId = "";
        String requestType = "";
        String cardType = "";
        LOG.info("Request received from client-> " + maskSensitiveRequestData(gatewayRequest));
        JSONObject request = new JSONObject(gatewayRequest);
        if (!request.isNull("request")) {
            requestType = request.getJSONObject("request").optString("requesttype");
            requestId = request.getJSONObject("request").optString("requestid");
            cardType = request.getJSONObject("request").optString("cardtype");
        }
        MDC.put("requestId", requestId);
        MDC.put("serviceType", serviceType);
        if (!request.isNull("header")) {
            JSONObject header = request.getJSONObject("header");
            if (!header.isNull("applicationid")) {
                applicationId = header.optString("applicationid");
            }
            if (!header.isNull("userid")) {
                userId = header.optString("userid");
            }
            if (!header.isNull("uuid")) {
                uuid = header.optString("uuid");
            }
        }
        LOG.info("Token received from client-> RequestId : " +requestId+" Token : "+ autherization);
        String authToken = null;
                if (null != autherization 
                && (autherization.contains("Bearer")
                     || autherization.contains("bearer")) ) {
                   authToken = autherization.split(" ").length==2?autherization.split(" ")[1]:"";
        }else {
               authToken = autherization;
    }
        long starTime = System.nanoTime();
        VaultDeleteCard vaultDeleteCard = new VaultDeleteCard();
        StringBuilder tempString = new StringBuilder();
        OauthResponse oauthResponse = new OauthResponse();
        oauthResponse = oauthValidation.oauthTokenValidation(authToken,requestId,requestType,applicationId);
       
        if(null !=oauthResponse.getActive() && oauthResponse.getActive().equalsIgnoreCase("true")) {
       
        try {
//            LOG.info("Performing Request Validation");
            vaultDeleteCard = walletServiceDelete(gatewayRequest, request ,requestId , applicationId , userId , uuid );
//            requestType=vaultDeleteCard.getRequest().getRequesttype().value();
//            cardType=vaultDeleteCard.getRequest().getCardtype().value();
            if (null == vaultDeleteCard.getResponse() || !WalletResponseType.DECLINED.equalsIgnoreCase(vaultDeleteCard.getResponse().getResponsetype())) {
                if (Request__1.Requesttype.DELETECARD.value().equalsIgnoreCase(vaultDeleteCard.getRequest().getRequesttype().value())) {
                    LOG.info("RequestId : "+requestId+" Call to delete-card : " + deleteCardEndpointUrl);
//                    vaultDeleteCard = restTemplate.postForObject(deleteCardEndpointUrl, vaultDeleteCard, vaultDeleteCard.class);
                    try {
                        LOG.info("RequestId : "+requestId+" 1st Call from feign");
                        vaultDeleteCard = feignClientConfigDeleteCard.deletecardResponse(vaultDeleteCard);
                        }catch (FeignException e) {
                            String errorMessage = e.getMessage();
                            int status = e.status();
                            if (status == -1 && errorMessage.contains("timed out") ||
                                    errorMessage.contains("Connection refused")) {
                                LOG.info("RequestId : {},Exception caught during 1st feign call -> {}",requestId, e.getLocalizedMessage());
                                if ("true".equals(retryFeign)) {
                                    if (e.getLocalizedMessage().contains("Load balancer does not have available server for client")) {
                                        // throw new ClientException(e);
                                    }
                                    String url = "";
                                    List<ServiceInstance> list = discoveryClient.getInstances("DELETECARD-SERVICE");
                                    URI chosenServer = null;
                                    if (list != null && list.size() > 0) {
                                        LOG.info("RequestId : {},list of url from discovery client get instance -> {}",requestId, list);
                                        chosenServer = list.get(0).getUri();
                                        String convertedURL = chosenServer.toString();
                                        if (!this.isAlive(convertedURL)) {
                                            for (ServiceInstance nextServer : list) {
                                                if (!nextServer.getUri().toString().equalsIgnoreCase(chosenServer.toString()) && this.isAlive(nextServer.getUri().toString())) {
                                                    chosenServer = nextServer.getUri();
                                                }
                                            }
                                        }
                                    }
                                    if (null != chosenServer) {
                                        url = chosenServer.toString();
                                        LOG.info("RequestId : {},Sending request to final chosen URL -> {} for 2nd call",requestId, url);
                                        RestTemplate restTemplate = new RestTemplate();
                                        vaultDeleteCard = restTemplate.postForObject(url + "/card/delete", vaultDeleteCard, VaultDeleteCard.class);
                                    }

                                }
                                LOG.info("RequestId : "+requestId+" Timeout occurred: {}", errorMessage);
                                vaultDeleteCard = buildErrorResponseUtil.buildTimeoutResponse(vaultDeleteCard, "SERVICE_TIMEOUT", requestId, applicationId, uuid, userId);
                            }else{
                                LOG.error("RequestId : "+requestId+" Error from call to delete-card: " + e);
                                // vaultDeleteCard.setRequest(gatewayRequest.getRequest());
                                vaultDeleteCard = buildErrorResponseUtil.buildErrorResponseDelete(vaultDeleteCard, "INTERNAL_SERVER_ERROR", requestId, applicationId, uuid, userId);
                            }
                        }  catch (Exception ex) {
                            LOG.error("RequestId : "+requestId+" Error from call to delete-card: " + ex);
                            // vaultDeleteCard.setRequest(gatewayRequest.getRequest());
                            vaultDeleteCard = buildErrorResponseUtil.buildErrorResponseDelete(vaultDeleteCard, "INTERNAL_SERVER_ERROR", requestId, applicationId, uuid, userId);
                        }
                    } else {
                    LOG.info("RequestId : "+requestId+" DELETE mapping used for DELETE CARD");
                    vaultDeleteCard = buildErrorResponseUtil.buildErrorResponseDelete(vaultDeleteCard, "INVALID_REQUEST", requestId, applicationId, uuid, userId);
                    //vaultDeleteCard.setRequest(null);
                }
            } else {
                LOG.info("RequestId : "+requestId+" Request Validation Failed. Not processing further");
            }
        } catch (Exception ex) {
            LOG.error("RequestId : "+requestId+" Error from call to delete-card: " + ex);
            // vaultDeleteCard.setRequest(gatewayRequest.getRequest());
            vaultDeleteCard = buildErrorResponseUtil.buildErrorResponseDelete(vaultDeleteCard, "INTERNAL_SERVER_ERROR", requestId, applicationId, uuid, userId);
            //vaultDeleteCard.setRequest(null);
        }
        if (null == vaultDeleteCard) {
//            if (null == vaultDeleteCard.getResponse().getBankcardaccount() || vaultDeleteCard.getResponse().getBankcardaccount().isEmpty()) {
//                vaultDeleteCard.getResponse().setBankcardaccount(null);
//            }
//            if (null == vaultDeleteCard.getResponse().getMilstaraccount() || vaultDeleteCard.getResponse().getMilstaraccount().isEmpty()) {
//                vaultDeleteCard.getResponse().setMilstaraccount(null);
//            }

            vaultDeleteCard = buildErrorResponseUtil.buildErrorResponseDelete(vaultDeleteCard, "INTERNAL_SERVER_ERROR", requestId, applicationId, uuid, userId);
        }
        vaultDeleteCard.setRequest(null);
        responseToClient = OBJECT_MAPPER.writeValueAsString(vaultDeleteCard);
        LOG.info("Response sent to client-> " + responseToClient);
        long endTime = System.nanoTime();

        long timeElapsed = (endTime - starTime) / 1000000;

        LOG.info(tempString.append("Elapsed_Time_Wallet|")
                .append(applicationId)
                .append("|")
                .append(uuid)
                .append("|")
                .append(userId)
                .append("|")
                .append(requestId)
                .append("|")
                .append(requestType)
                .append("|")
                .append(cardType)
                .append("|")
                .append(vaultDeleteCard.getResponse().getResponsecode())
                .append("|")
                .append(vaultDeleteCard.getResponse().getResponsedescription())
                .append("|")
                .append(vaultDeleteCard.getResponse().getResponsetype())
                .append("|")
                .append(timeElapsed)
                .append(" ms")
                .toString());
            tempString.setLength(0);
    }else {
        long endTime = System.nanoTime();

        long timeElapsed = (endTime - starTime) / 1000000;

        vaultDeleteCard.setAdditionalProperty("error_description", "The access token provided is invalid.");
        vaultDeleteCard.setAdditionalProperty("error", "invalid_token");
        LOG.info(tempString.append("Elapsed_Time_Wallet|")
                .append(requestType)
                .append("|")
                .append(requestId)
                .append("|")
                .append("invalid_token")
                .append("|")
                .append("The access token provided is invalid.")
                .append("|")
                .append(timeElapsed)
                .append(" ms")
                .toString());
        tempString.setLength(0);
        responseClient.setStatus(401);
        }
        MDC.remove("requestId");
        return vaultDeleteCard;
    }

    public VaultAddCard walletServiceAdd(String gatewayRequest, JSONObject request , String requestId , String applicationId , String userId , String uuid ) throws JsonProcessingException, ParseException {
        String validationResponse = "";
        String requestValidationError = "";
        VaultAddCard vaultAddCard = new VaultAddCard();

        //JSONObject request = new JSONObject(gatewayRequest);
        if (!request.isNull("request")) {
            if (!request.getJSONObject("request").isNull("requestid")) {
                requestId = request.getJSONObject("request").optString("requestid");
            }
        }
        if (!request.isNull("header")) {
            JSONObject header = request.getJSONObject("header");
            if (!header.isNull("applicationid")) {
                applicationId = header.optString("applicationid");
            }
            if (!header.isNull("userid")) {
                userId = header.optString("userid");
            }
            if (!header.isNull("uuid")) {
                uuid = header.optString("uuid");
            }
        }
        try {
            vaultAddCard = OBJECT_MAPPER.readValue(gatewayRequest, VaultAddCard.class);
            if (null != vaultAddCard) {
                validationResponse = validateSchemaUtil.validateJsonRequest(gatewayRequest, schemaAdd);
            } else {
                validationResponse = "Failed to process request";
            }
        } catch (Exception e) {
            LOG.error("Exception in JSON request validation-> " + e.getMessage());
            requestId = StringUtils.substringBetween(gatewayRequest.replaceAll(" ", ""), "\"" + "requestid".trim() + "\":\"", "\",");
            validationResponse = "Failed to process request";
        }
        if (validationResponse == null || validationResponse.isEmpty()) {
            requestValidationError = validateRequestUtil.validateFieldsAdd(vaultAddCard);
            if (requestValidationError.isEmpty()) {
                LOG.info("RequestId : "+requestId+" No field validation errors");
                //EnterpriseWalletVault tempVault = OBJECT_MAPPER.readValue(gatewayRequest, EnterpriseWalletVault.class);
            } else {
                LOG.info("RequestId : "+requestId+" RequestValidationError -> " + requestValidationError);
                vaultAddCard = buildErrorResponseUtil.buildErrorResponseAdd(vaultAddCard, requestValidationError, requestId, applicationId, uuid, userId);
            }
        } else {
            LOG.info("Schema Validation of request from client has failed. Error-> " + validationResponse + " for request id -> " + requestId);
            vaultAddCard = buildErrorResponseUtil.buildErrorResponseAdd(vaultAddCard, "INVALID_REQUEST", requestId, applicationId, uuid, userId);
        }
        return vaultAddCard;
    }

    public VaultUpdateCard walletServiceUpdate(String gatewayRequest, JSONObject request , String requestId , String applicationId , String userId , String uuid ) throws JsonProcessingException, ParseException {
        String validationResponse = "";
        String requestValidationError = "";
        VaultUpdateCard vaultUpdateCard = new VaultUpdateCard();

        //JSONObject request = new JSONObject(gatewayRequest);
        if (!request.isNull("request")) {
            if (!request.getJSONObject("request").isNull("requestid")) {
                requestId = request.getJSONObject("request").optString("requestid");
            }
        }
        if (!request.isNull("header")) {
            JSONObject header = request.getJSONObject("header");
            if (!header.isNull("applicationid")) {
                applicationId = header.optString("applicationid");
            }
            if (!header.isNull("userid")) {
                userId = header.optString("userid");
            }
            if (!header.isNull("uuid")) {
                uuid = header.optString("uuid");
            }
        }
        try {
            vaultUpdateCard = OBJECT_MAPPER.readValue(gatewayRequest, VaultUpdateCard.class);
            if (null != vaultUpdateCard) {
                validationResponse = validateSchemaUtil.validateJsonRequest(gatewayRequest, schemaUpdate);
            } else {
                validationResponse = "Failed to process request";
            }
        } catch (Exception e) {
            LOG.error("RequestId : "+requestId+" Exception in JSON request validation-> " + e.getMessage());
            requestId = StringUtils.substringBetween(gatewayRequest.replaceAll(" ", ""), "\"" + "requestid".trim() + "\":\"", "\",");
            validationResponse = "Failed to process request";
        }
        if (validationResponse == null || validationResponse.isEmpty()) {
            requestValidationError = validateRequestUtil.validateFieldsUpdate(vaultUpdateCard);
            if (requestValidationError.isEmpty()) {
                LOG.info("RequestId : "+requestId+" No field validation errors");
                //EnterpriseWalletVault tempVault = OBJECT_MAPPER.readValue(gatewayRequest, EnterpriseWalletVault.class);
            } else {
                LOG.info("RequestId : "+requestId+" RequestValidationError -> " + requestValidationError);
                vaultUpdateCard = buildErrorResponseUtil.buildErrorResponseUpdate(vaultUpdateCard, requestValidationError, requestId, applicationId, uuid, userId);
            }
        } else {
            LOG.info("Schema Validation of request from client has failed. Error-> " + validationResponse + " for request id -> " + requestId);
            vaultUpdateCard = buildErrorResponseUtil.buildErrorResponseUpdate(vaultUpdateCard, "INVALID_REQUEST", requestId, applicationId, uuid, userId);
        }
        return vaultUpdateCard;
    }

    public VaultGetCard walletServiceGet(String gatewayRequest, JSONObject request , String requestId , String applicationId , String userId , String uuid ) throws JsonProcessingException, ParseException {
        String validationResponse = "";
        String requestValidationError = "";
        VaultGetCard vaultGetCard = new VaultGetCard();

        //JSONObject request = new JSONObject(gatewayRequest);
        if (!request.isNull("request")) {
            if (!request.getJSONObject("request").isNull("requestid")) {
                requestId = request.getJSONObject("request").optString("requestid");
            }
        }
        if (!request.isNull("header")) {
            JSONObject header = request.getJSONObject("header");
            if (!header.isNull("applicationid")) {
                applicationId = header.optString("applicationid");
            }
            if (!header.isNull("userid")) {
                userId = header.optString("userid");
            }
            if (!header.isNull("uuid")) {
                uuid = header.optString("uuid");
            }
        }
        try {
            vaultGetCard = OBJECT_MAPPER.readValue(gatewayRequest, VaultGetCard.class);
            if (null != vaultGetCard) {
                validationResponse = validateSchemaUtil.validateJsonRequest(gatewayRequest, schemaGet);
            } else {
                validationResponse = "Failed to process request";
            }
        } catch (Exception e) {
            LOG.error("RequestId : "+requestId+" Exception in JSON request validation-> " + e.getMessage());
            requestId = StringUtils.substringBetween(gatewayRequest.replaceAll(" ", ""), "\"" + "requestid".trim() + "\":\"", "\",");
            validationResponse = "Failed to process request";
        }
//        if (validationResponse == null || validationResponse.isEmpty()) {
//            requestValidationError = validateRequestUtil.validateFieldsAdd(vaultGetCard);
//            if (requestValidationError.isEmpty()) {
//                LOG.info("No field validation errors");
//                //EnterpriseWalletVault tempVault = OBJECT_MAPPER.readValue(gatewayRequest, EnterpriseWalletVault.class);
//            } else {
//                LOG.info("RequestValidationError -> " + requestValidationError);
//                vaultGetCard = buildErrorResponseUtil.buildErrorResponseGet(vaultGetCard, requestValidationError, requestId, applicationId, uuid, userId);
//            }
//        }
        if (validationResponse != null) {
            LOG.info("Schema Validation of request from client has failed. Error-> " + validationResponse + " for request id -> " + requestId);
            vaultGetCard = buildErrorResponseUtil.buildErrorResponseGet(vaultGetCard, "INVALID_REQUEST", requestId, applicationId, uuid, userId);
        }
        return vaultGetCard;
    }

    public VaultDeleteCard walletServiceDelete(String gatewayRequest, JSONObject request , String requestId , String applicationId , String userId , String uuid ) throws JsonProcessingException, ParseException {
        String validationResponse = "";
        String requestValidationError = "";
        VaultDeleteCard vaultDeleteCard = new VaultDeleteCard();

        //JSONObject request = new JSONObject(gatewayRequest);
        if (!request.isNull("request")) {
            if (!request.getJSONObject("request").isNull("requestid")) {
                requestId = request.getJSONObject("request").optString("requestid");
            }
        }
        if (!request.isNull("header")) {
            JSONObject header = request.getJSONObject("header");
            if (!header.isNull("applicationid")) {
                applicationId = header.optString("applicationid");
            }
            if (!header.isNull("userid")) {
                userId = header.optString("userid");
            }
            if (!header.isNull("uuid")) {
                uuid = header.optString("uuid");
            }
        }
        try {
            vaultDeleteCard = OBJECT_MAPPER.readValue(gatewayRequest, VaultDeleteCard.class);
            if (null != vaultDeleteCard) {
                validationResponse = validateSchemaUtil.validateJsonRequest(gatewayRequest, schemaDelete);
            } else {
                validationResponse = "Failed to process request";
            }
        } catch (Exception e) {
            LOG.error("RequestId : "+requestId+" Exception in JSON request validation-> " + e.getMessage());
            requestId = StringUtils.substringBetween(gatewayRequest.replaceAll(" ", ""), "\"" + "requestid".trim() + "\":\"", "\",");
            validationResponse = "Failed to process request";
        }
//        if (validationResponse == null || validationResponse.isEmpty()) {
//            requestValidationError = validateRequestUtil.validateFieldsAdd(vaultGetCard);
//            if (requestValidationError.isEmpty()) {
//                LOG.info("No field validation errors");
//                //EnterpriseWalletVault tempVault = OBJECT_MAPPER.readValue(gatewayRequest, EnterpriseWalletVault.class);
//            } else {
//                LOG.info("RequestValidationError -> " + requestValidationError);
//                vaultGetCard = buildErrorResponseUtil.buildErrorResponseGet(vaultGetCard, requestValidationError, requestId, applicationId, uuid, userId);
//            }
//        }
        if (validationResponse != null) {
            LOG.info("Schema Validation of request from client has failed. Error-> " + validationResponse + " for request id -> " + requestId);
            vaultDeleteCard = buildErrorResponseUtil.buildErrorResponseDelete(vaultDeleteCard, "INVALID_REQUEST", requestId, applicationId, uuid, userId);
        }
        return vaultDeleteCard;
    }

//    public void walletService(String gatewayRequest) throws JsonProcessingException, ParseException {
//        //This controller consumes the json request received from DGMA
//        //LOG.info("Inside Wallet Service validation");
//        String validationResponse = "";
//        String requestValidationError = "";
//        //  String jsonPath = "";
//        //EnterpriseWalletVault enterpriseWalletVault = new EnterpriseWalletVault();
//
//        JSONObject request = new JSONObject(gatewayRequest);
//        if (!request.isNull("request")) {
//            if (!request.getJSONObject("request").isNull("requestid")) {
//                requestId = request.getJSONObject("request").optString("requestid");
//            }
//        }
//        if (!request.isNull("header")) {
//            JSONObject header = request.getJSONObject("header");
//            if (!header.isNull("applicationid")) {
//                applicationId = header.optString("applicationid");
//            }
//            if (!header.isNull("userid")) {
//                userId = header.optString("userid");
//            }
//            if (!header.isNull("uuid")) {
//                uuid = header.optString("uuid");
//            }
//        }
//        try {
////            LOG.info("jsonRequest received from client -> " + gatewayRequest);
//           // enterpriseWalletVault = OBJECT_MAPPER.readValue(gatewayRequest, EnterpriseWalletVault.class);
////            LOG.info("EnterpriseWalletVault object -> " + enterpriseWalletVault.toString());
//            String requestType = request.getJSONObject("request").optString("requesttype");
//            if (null != gatewayRequest) {
//                if ("addcard".equalsIgnoreCase(requestType)) {
//                    VaultAddCard tempVault = OBJECT_MAPPER.readValue(gatewayRequest,VaultAddCard.class);
//                    validationResponse = validateSchemaUtil.validateJsonRequest(gatewayRequest, schemaAdd);
//                } else if ("getcard".equalsIgnoreCase(requestType)) {
//                    VaultGetCard tempVault = OBJECT_MAPPER.readValue(gatewayRequest,VaultGetCard.class);
//                    validationResponse = validateSchemaUtil.validateJsonRequest(gatewayRequest, schemaGet);
//                } else if ("updatecard".equalsIgnoreCase(requestType)) {
//                    VaultUpdateCard tempVault = OBJECT_MAPPER.readValue(gatewayRequest,VaultUpdateCard.class);
//                    validationResponse = validateSchemaUtil.validateJsonRequest(gatewayRequest, schemaUpdate);
//                } else if ("deletecard".equalsIgnoreCase(requestType)) {
//                    VaultDeleteCard tempVault = OBJECT_MAPPER.readValue(gatewayRequest,VaultDeleteCard.class);
//                    validationResponse = validateSchemaUtil.validateJsonRequest(gatewayRequest, schemaDelete);
//                }
//            }
////            if (null != enterpriseWalletVault && validationResponse.isEmpty()) {
////                //LOG.info("JSON schema: " + jsonPath);
////                validationResponse = validateSchemaUtil.validateJsonRequest(gatewayRequest, schema);
////            }
//            else {
//                validationResponse = "Failed to process request";
//            }
//        } catch (Exception e) {
//            LOG.error("Exception in JSON request validation-> " + e.getMessage());
//            requestId = StringUtils.substringBetween(gatewayRequest.replaceAll(" ", ""), "\"" + "requestid".trim() + "\":\"", "\",");
//            validationResponse = "Failed to process request";
//        }
//        if (validationResponse == null || validationResponse.isEmpty()) {
//            requestValidationError = validateRequestUtil.validateFields(enterpriseWalletVault);
//            if (requestValidationError.isEmpty()) {
//                LOG.info("No field validation errors");
//                EnterpriseWalletVault tempVault = OBJECT_MAPPER.readValue(gatewayRequest, EnterpriseWalletVault.class);
//            } else {
//                LOG.info("RequestValidationError -> " + requestValidationError);
//                enterpriseWalletVault = buildErrorResponseUtil.buildErrorResponse(enterpriseWalletVault, requestValidationError, requestId, applicationId, uuid, userId);
//
//            }
//        } else {
//            LOG.info("Schema Validation of request from client has failed. Error-> " + validationResponse + " for request id -> " + requestId);
//            enterpriseWalletVault = buildErrorResponseUtil.buildErrorResponse(enterpriseWalletVault, "INVALID_REQUEST", requestId, applicationId, uuid, userId);
//        }
//        return enterpriseWalletVault;
//    }
    public String maskSensitiveRequestData(String jsonRequest) {
        JSONObject request = new JSONObject(jsonRequest);
        String fieldsToMask = env.getProperty("mask.requestFields");
        if (null != fieldsToMask) {
            String[] fieldsToMaskArr = fieldsToMask.replaceAll("\\s", "").split(",");
            //LOG.info(Arrays.toString(fieldsToMaskArr));
            String maskString = "";
            for (String temp : fieldsToMaskArr) {
                String field = "";
                if (!request.isNull("request")) {
                    if (request.getJSONObject("request").has(temp)) {
                        field = request.getJSONObject("request").optString(temp);
                    }
                    if (null != field && !field.isEmpty()) {
                        if (temp.trim().equalsIgnoreCase("pan")) {
                            maskString = field.replaceAll("\\w(?=\\w{4})", "*");
                        } else {
                            maskString = field.replaceAll("\\w(?=\\w{0})", "*");
                        }
                        request.getJSONObject("request").put(temp, maskString);
                    }
                }
            }
        } else {
            LOG.info("mask.requestFields not found in application.yml");
        }
        return request.toString();
    }

    private boolean isAlive(String url) {
        url += env.getProperty("pingUrl");
        boolean isAlive = false;
        HttpClient httpClient = HttpClientBuilder.create().build();
        HttpUriRequest getRequest = new HttpGet(url);
        String content = null;

        try {
            HttpResponse response = httpClient.execute(getRequest);
            isAlive = response.getStatusLine().getStatusCode() == 200;
            LOG.info("does chosen server {} ping back ? {}", url, isAlive);
        } catch (IOException e) {
            LOG.info("Exception caught while custom health check for url {}", url);
        } finally {
            getRequest.abort();
        }
        return isAlive;
    }

    public Environment getEnv() {
        return env;
    }

    public void setEnv(Environment env) {
        this.env = env;
    }

    public String getAddCardEndpointUrl() {
        return addCardEndpointUrl;
    }

    public void setAddCardEndpointUrl(String addCardEndpointUrl) {
        this.addCardEndpointUrl = addCardEndpointUrl;
    }

    public String getGetCardEndpointUrl() {
        return getCardEndpointUrl;
    }

    public void setGetCardEndpointUrl(String getCardEndpointUrl) {
        this.getCardEndpointUrl = getCardEndpointUrl;
    }

    public String getUpdateCardEndpointUrl() {
        return updateCardEndpointUrl;
    }

    public void setUpdateCardEndpointUrl(String updateCardEndpointUrl) {
        this.updateCardEndpointUrl = updateCardEndpointUrl;
    }

    public String getDeleteCardEndpointUrl() {
        return deleteCardEndpointUrl;
    }

    public void setDeleteCardEndpointUrl(String deleteCardEndpointUrl) {
        this.deleteCardEndpointUrl = deleteCardEndpointUrl;
    }

    public BuildErrorResponseUtil getBuildErrorResponseUtil() {
        return buildErrorResponseUtil;
    }

    public void setBuildErrorResponseUtil(BuildErrorResponseUtil buildErrorResponseUtil) {
        this.buildErrorResponseUtil = buildErrorResponseUtil;
    }

    public void setValidateSchemaUtil(ValidateSchemaUtil validateSchemaUtil) {
        this.validateSchemaUtil = validateSchemaUtil;
    }

    public void setValidateRequestUtil(ValidateRequestUtil validateRequestUtil) {
        this.validateRequestUtil = validateRequestUtil;
    }

    public FeignClientConfigAddCard getFeignClientConfigAddCard() {
        return feignClientConfigAddCard;
    }

    public void setFeignClientConfigAddCard(FeignClientConfigAddCard feignClientConfigAddCard) {
        this.feignClientConfigAddCard = feignClientConfigAddCard;
    }

    public FeignClientConfigUpdateCard getFeignClientConfigUpdateCard() {
        return feignClientConfigUpdateCard;
    }

    public void setFeignClientConfigUpdateCard(FeignClientConfigUpdateCard feignClientConfigUpdateCard) {
        this.feignClientConfigUpdateCard = feignClientConfigUpdateCard;
    }

    public FeignClientConfigGetCard getFeignClientConfigGetCard() {
        return feignClientConfigGetCard;
    }

    public void setFeignClientConfigGetCard(FeignClientConfigGetCard feignClientConfigGetCard) {
        this.feignClientConfigGetCard = feignClientConfigGetCard;
    }

    public FeignClientConfigDeleteCard getFeignClientConfigDeleteCard() {
        return feignClientConfigDeleteCard;
    }

    public void setFeignClientConfigDeleteCard(FeignClientConfigDeleteCard feignClientConfigDeleteCard) {
        this.feignClientConfigDeleteCard = feignClientConfigDeleteCard;
    }

    public void setSchemaAdd(JsonSchema schemaAdd) {
        this.schemaAdd = schemaAdd;
    }

    public void setSchemaGet(JsonSchema schemaGet) {
        this.schemaGet = schemaGet;
    }

    public void setSchemaUpdate(JsonSchema schemaUpdate) {
        this.schemaUpdate = schemaUpdate;
    }

    public void setSchemaDelete(JsonSchema schemaDelete) {
        this.schemaDelete = schemaDelete;
    }
    public void setOauthValidation(OauthValidation oauthValidation) {
        this.oauthValidation = oauthValidation;
    }
}