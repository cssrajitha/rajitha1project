package com.ews.wallet.configuration.feign;

import com.ews.walletservice.generated.entity.VaultUpdateCard;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(name = "UPDATECARD-SERVICE", url = "${microservice.endpoints.updatecard-service}" , configuration = FeignCustomConfig.class)
public interface FeignClientConfigUpdateCard {
    @RequestMapping(value = "/card/update", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    public VaultUpdateCard updatecardResponse(@RequestBody VaultUpdateCard gatewayRequest);

}
