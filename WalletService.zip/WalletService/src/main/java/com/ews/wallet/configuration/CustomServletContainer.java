package com.ews.wallet.configuration;

import ch.qos.logback.classic.Logger;
import org.apache.catalina.connector.Connector;
import org.apache.coyote.http11.Http11NioProtocol;
import org.apache.tomcat.util.net.SSLHostConfig;
import org.apache.tomcat.util.net.SSLHostConfigCertificate;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.embedded.tomcat.TomcatConnectorCustomizer;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import java.io.File;

@Component
public class CustomServletContainer implements
        WebServerFactoryCustomizer<TomcatServletWebServerFactory> {

    private static final Logger LOG = (Logger) LoggerFactory.getLogger(CustomServletContainer.class);
    @Value("${keystore.path}")
    private String keystoreFile;
    @Value("${keystore.alias}")
    private String keystoreAlias;
    @Value("${keystore.type}")
    private String keystoreType;
    @Value("${keystore.password}")
    private String keystorePass;
    @Value("${server.port}")
    private int port;
    @Value("${cryptoKeysDir}")
    protected String baseDir;

    public void customize(TomcatServletWebServerFactory factory) {

        factory.addConnectorCustomizers(new TomcatConnectorCustomizer() {

            @Override
            public void customize(Connector connector) {
                connector.setPort(port);
                connector.setSecure(true);
                connector.setScheme("https");
                Http11NioProtocol proto = (Http11NioProtocol) connector.getProtocolHandler();
                proto.setSSLEnabled(true);
                LOG.info("keystore pass -> " + keystorePass);
                decryptValues();
                SSLHostConfig sslHostConfig = new SSLHostConfig();
                SSLHostConfigCertificate sslHostConfigCertificate = new SSLHostConfigCertificate(sslHostConfig, SSLHostConfigCertificate.Type.UNDEFINED);
                sslHostConfigCertificate.setCertificateKeystoreFile(keystoreFile);
                sslHostConfigCertificate.setCertificateKeystoreType(keystoreType);
                sslHostConfigCertificate.setCertificateKeystorePassword(keystorePass);
                sslHostConfigCertificate.setCertificateKeyAlias(keystoreAlias);
                sslHostConfig.addCertificate(sslHostConfigCertificate);
                proto.addSslHostConfig(sslHostConfig);
            }
        });
    }

    public void decryptValues() {
        LOG.info("Values from properties file : baseDir " + baseDir);
        String keysPath = baseDir + File.separator + "crypto" + File.separator + "keys";
        String logPath = baseDir + File.separator + "crypto.log4j.properties";

        EncryptorConfig encryptor = new EncryptorConfig(keysPath, logPath);
        try {
            keystorePass = encryptor.decrypt(keystorePass);
        } catch (Exception e) {
            LOG.error("Exception occurred during decryption of keystore password details");
        }
    }

//    public static void main(String args[]) {
//        String baseDir = "D:/configServer";
//        LOG.info("Values from properties file : baseDir " + baseDir);
//        String keysPath = baseDir + File.separator + "crypto" + File.separator + "keys";
//        String logPath = baseDir + File.separator + "crypto.log4j.properties";
//
//        EncryptorConfig encryptor = new EncryptorConfig(keysPath, logPath);
//        try {
//            String password = "ews2021";
//            password = encryptor.encrypt(password);
//            System.out.println("Encrypted password is -> " + password);
//        } catch (Exception e) {
//            LOG.error("Exception occurred during decryption of keystore password details");
//        }
//    }


}

