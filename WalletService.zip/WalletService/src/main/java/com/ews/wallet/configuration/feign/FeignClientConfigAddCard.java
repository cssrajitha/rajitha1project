package com.ews.wallet.configuration.feign;

import com.ews.walletservice.generated.entity.VaultAddCard;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(name = "ADDCARD-SERVICE", url = "${microservice.endpoints.addcard-service}" , configuration = FeignCustomConfig.class)
public interface FeignClientConfigAddCard {
    @RequestMapping(value = "/card/add", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    public VaultAddCard addcardResponse(@RequestBody VaultAddCard gatewayRequest);

}
