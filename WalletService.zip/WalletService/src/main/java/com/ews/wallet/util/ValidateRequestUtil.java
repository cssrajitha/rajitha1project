package com.ews.wallet.util;

import com.ews.walletservice.generated.entity.VaultAddCard;
import com.ews.walletservice.generated.entity.VaultUpdateCard;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;
import java.util.Calendar;
import java.util.regex.Pattern;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ValidateRequestUtil {
    private static Pattern p = Pattern.compile("^[0-9]+$");
    private static final Logger LOG = (Logger) LoggerFactory.getLogger(ValidateRequestUtil.class);
    
    @Value("${milstarplus.min-range}")
    private String minRangeMilstarPlus;
    @Value("${milstarplus.max-range}")
    private String maxRangeMilstarPlus;

    public String validateFieldsAdd(VaultAddCard request) throws ParseException {
        String cid = request.getRequest().getCid();
        String account = request.getRequest().getPan();
        String token = request.getRequest().getToken();
        String expiryDate = request.getRequest().getExpirydate();
        String cvv = request.getRequest().getCardsecuritycode();
        String state = request.getRequest().getState();
        String country = request.getRequest().getCountry();
        String zipCode = request.getRequest().getZipcode();
        String billingAddress1 = request.getRequest().getBillingaddress1();
        String billingAddress2 = request.getRequest().getBillingaddress2();
        String cardholderName = request.getRequest().getCardholdername();
        String cardholderFirstName = request.getRequest().getCardholderfirstname();
        String cardholderMiddleName = request.getRequest().getCardholdermiddleinitial();
        String cardholderLastName = request.getRequest().getCardholderlastname();
        String city = request.getRequest().getCity();
        String preferredcard = request.getRequest().getPreferredcard();
        String nickName=request.getRequest().getNickname();

        if ( (null == cardholderLastName || cardholderLastName.trim().isEmpty() ) && (null == cardholderName || cardholderName.trim().isEmpty()) ) {
            LOG.info("Invalid or missing cardholdername  for AddCard request type." + " [cardholderName or cardholderLastName] are mandatory for add card request");
            return "INVALID_REQUEST";
        }
        if ((null == state || state.trim().isEmpty()) || (null == country || country.trim().isEmpty()) || (null == zipCode || zipCode.trim().isEmpty()) || (null == billingAddress1 || billingAddress1.trim().isEmpty()) || (null == city || city.trim().isEmpty())) {
            LOG.info("Invalid or missing Address fields for AddCard request type." + " [state,country,city,zipcode,billingAddress1] are mandatory for add card request");
            return "INVALID_REQUEST";
        }
//            if (null != country && country.trim().length() > 2) {
//                LOG.info("Invalid Country Code. Please enter country code with maximum 2 characters");
//                return "INVALID_REQUEST";
//            }

        if (null != account) {
            account = account.trim();
            boolean isAccountValid = p.matcher(account).matches();
            if (!isAccountValid) {
                return "INVALID_PAN";
            }
        }
                    LOG.info("Milstar Plus ValidateRequestUtil");
          if (null != account && !account.isEmpty()) {
            double minRange = Double.parseDouble(minRangeMilstarPlus);
            double maxRange = Double.parseDouble(maxRangeMilstarPlus);
            double accountnum = Double.parseDouble(account);
            if (("MilstarPlus".equalsIgnoreCase(request.getRequest().getCardtype().value()))) {

                if (!(minRange <= accountnum && accountnum <= maxRange)) {
                    return "INVALID_PAN";
                }
            } else if (("Discover".equalsIgnoreCase(request.getRequest().getCardtype().value()))
                    && (null != account && !account.isEmpty())) {
                if ((minRange <= accountnum && accountnum <= maxRange)) {
                    return "INVALID_PAN";
                }
            }
        }
                            LOG.info("Milstar Plus ValidateRequestUtil PAN ");

         
        if (null != cvv && !cvv.isEmpty()) {
            cvv = cvv.trim();
            boolean isCvvValid = p.matcher(cvv).matches();
            if (!isCvvValid) {
                return "INVALID_CVV";
            }
        }
        
        if (null != expiryDate && !expiryDate.isEmpty()) {
            expiryDate = expiryDate.trim();
            boolean isExpiryDateValid = p.matcher(expiryDate).matches();
            if (isExpiryDateValid) {
                int expMonth = Integer.parseInt(expiryDate.substring(2, 4));
                int expYear = Integer.parseInt("20" + expiryDate.substring(0, 2));
                Calendar current = Calendar.getInstance();
                int currentYear = current.get(Calendar.YEAR);
                int currentMonth = current.get(Calendar.MONTH) + 1;
                if (expYear < currentYear) {
                    return "INVALID_EXPIRYDATE";
                } else if (expYear == currentYear) {
                    if (expMonth < currentMonth) {
                        return "INVALID_EXPIRYDATE";
                    }
                }
            } else {
                return "INVALID_EXPIRYDATE";
            }
        }
        return "";
    }

    public String validateFieldsUpdate(VaultUpdateCard request) throws ParseException {
        String cid = request.getRequest().getCid();
        String expiryDate = request.getRequest().getExpirydate();
        String cvv = request.getRequest().getCardsecuritycode();
        String state = request.getRequest().getState();
        String country = request.getRequest().getCountry();
        String zipCode = request.getRequest().getZipcode();
        String billingAddress1 = request.getRequest().getBillingaddress1();
        String billingAddress2 = request.getRequest().getBillingaddress2();
        String cardholderName = request.getRequest().getCardholdername();
        String cardholderFirstName = request.getRequest().getCardholderfirstname();
        String cardholderMiddleName = request.getRequest().getCardholdermiddleinitial();
        String cardholderLastName = request.getRequest().getCardholderlastname();
        String city = request.getRequest().getCity();
        String preferredcard = request.getRequest().getPreferredcard();
        String nickName=request.getRequest().getNickname();

        if (null != cvv && !cvv.isEmpty()) {
            cvv = cvv.trim();
            boolean isCvvValid = p.matcher(cvv).matches();
            if (!isCvvValid) {
                return "INVALID_CVV";
            }
        }
        if (null != expiryDate && !expiryDate.isEmpty()) {
            expiryDate = expiryDate.trim();
            boolean isExpiryDateValid = p.matcher(expiryDate).matches();
            if (isExpiryDateValid) {
                int expMonth = Integer.parseInt(expiryDate.substring(2, 4));
                int expYear = Integer.parseInt("20" + expiryDate.substring(0, 2));
                Calendar current = Calendar.getInstance();
                int currentYear = current.get(Calendar.YEAR);
                int currentMonth = current.get(Calendar.MONTH) + 1;
                if (expYear < currentYear) {
                    return "INVALID_EXPIRYDATE";
                } else if (expYear == currentYear) {
                    if (expMonth < currentMonth) {
                        return "INVALID_EXPIRYDATE";
                    }
                }
            } else {
                return "INVALID_EXPIRYDATE";
            }
        }
//        if (((null == cardholderName || cardholderName.trim().isEmpty())) || ((null == cardholderFirstName || cardholderFirstName.trim().isEmpty()) || (null == cardholderMiddleName || cardholderMiddleName.trim().isEmpty()) || (null == cardholderLastName || cardholderLastName.trim().isEmpty()) )) {
//            LOG.info("Invalid or missing cardholdername  for AddCard request type." + " [cardholderName or cardholderFirstName, cardholderMiddleName, cardholderLastName] are mandatory for add card request");
//            return "INVALID_REQUEST";
//        }
            if ((null != cardholderLastName && cardholderLastName.isBlank()) || (null != cardholderName && cardholderName.isBlank()) ||
        (null != expiryDate && expiryDate.isBlank()) ||
                    (null != state && state.isBlank()) ||
                    (null != country && country.isBlank()) ||
                    (null != zipCode && zipCode.isBlank()) ||
                    (null != billingAddress1 && billingAddress1.isBlank()) ||
                    (null != city && city.isBlank()) ||
                    (null != preferredcard && preferredcard.isBlank())||(null!=nickName&&nickName.isBlank())) {
                LOG.info("[cardholderName, cardholderLastName, preferredcard, expiryDate, state, country, zip, billingAddress1, city,nickName] Fields cannot be empty");
                return "INVALID_REQUEST";
            }
            if  (((null != cardholderName && !cardholderName.isBlank()) ||
                    (null != cardholderLastName && !cardholderLastName.isBlank()) ||
                    (null != expiryDate && !expiryDate.isBlank())
                    || (null != state && !state.isBlank())
                    || (null != country && !country.isBlank())
                    || (null != zipCode && !zipCode.isBlank())
                    || (null != billingAddress1 && !billingAddress1.isBlank())
                    || (null != billingAddress2 && !billingAddress2.isBlank())
                    || (null != city && !city.isBlank()))
                    && (null == cvv || cvv.isEmpty())) {
                LOG.info("CVV mandatory for updating [cardholderName, cardholderLastName, expiryDate, state, country, zip, billingAddress1, " +
                        "billingAddress2, city]");
                return "INVALID_REQUEST";
            }
//            if (null != country && country.trim().length() > 2) {
//                LOG.info("Invalid Country Code. Please enter country code with maximum 2 characters");
//                return "INVALID_REQUEST";
//            }
            if (null != cid) {
                LOG.info("CID cannot be updated");
                return "INVALID_REQUEST";
            }

        return "";
     }



//    public String validateFields(EnterpriseWalletVault request) throws ParseException {
//        String cid = request.getRequest().getCid();
//        String account = request.getRequest().getPan();
//        String expiryDate = request.getRequest().getExpirydate();
//        String cvv = request.getRequest().getCardsecuritycode();
//        String state = request.getRequest().getState();
//        String country = request.getRequest().getCountry();
//        String zipCode = request.getRequest().getZipcode();
//        String billingAddress1 = request.getRequest().getBillingaddress1();
//        String billingAddress2 = request.getRequest().getBillingaddress2();
//        String cardholderName = request.getRequest().getCardholdername();
//        String city = request.getRequest().getCity();
//        String preferredcard = request.getRequest().getPreferredcard();
//        if (Request.Requesttype.ADDCARD.equals(request.getRequest().getRequesttype())) {
//            if (Request.Cardtype.MILSTAR.equals(request.getRequest().getCardtype())) {
//                if (null != cid) {
//                    boolean isCidValid = p.matcher(cid).matches();
//                    if (!isCidValid) {
//                        LOG.info("CID provided is not valid Milstar card");
//                        return "INVALID_CID";
//                    } else {
//                        long cidValue = Long.parseLong(cid);
//                        if ((cidValue < 10000000000l) || (cidValue > 99999999999l)) {
//                            LOG.info("CID not matching in range -> minimum: 10000000000, maximum: 99999999999");
//                            return "INVALID_CID";
//                        }
//                    }
//                } else {
//                    LOG.info("CID missing for Milstar card");
//                    return "INVALID_CID";
//                }
//            } else {
//                Pattern pcid = Pattern.compile("^$|[0-9]+");
//                if (null != cid && !pcid.matcher(cid).matches()) {
//                    LOG.info("CID should be numeric or empty");
//                    return "INVALID_CID";
//                }
//            }
//            if ((null == state || state.trim().isEmpty())
//                    || (null == country || country.trim().isEmpty())
//                    || (null == zipCode || zipCode.trim().isEmpty())
//                    || (null == billingAddress1 || billingAddress1.trim().isEmpty())
//                    || (null == city || city.trim().isEmpty())) {
//                LOG.info("Invalid or missing Address fields for AddCard request type." +
//                        " [state,country,city,zipcode,billingAddress1] are mandatory for add card request");
//                return "INVALID_REQUEST";
//            }
////            if (null != country && country.trim().length() > 2) {
////                LOG.info("Invalid Country Code. Please enter country code with maximum 2 characters");
////                return "INVALID_REQUEST";
////            }
//        }
//        if (null != account) {
//            account = account.trim();
//            boolean isAccountValid = p.matcher(account).matches();
//            if (!isAccountValid) {
//                return "INVALID_PAN";
//            }
//        }
//        if (null != cvv && !cvv.isEmpty()) {
//            cvv = cvv.trim();
//            boolean isCvvValid = p.matcher(cvv).matches();
//            if (!isCvvValid) {
//                return "INVALID_CVV";
//            }
//        }
//        if (null != expiryDate && !expiryDate.isEmpty()) {
//            expiryDate = expiryDate.trim();
//            boolean isExpiryDateValid = p.matcher(expiryDate).matches();
//            if (isExpiryDateValid) {
//                int expMonth = Integer.parseInt(expiryDate.substring(2, 4));
//                int expYear = Integer.parseInt("20" + expiryDate.substring(0, 2));
//                Calendar current = Calendar.getInstance();
//                int currentYear = current.get(Calendar.YEAR);
//                int currentMonth = current.get(Calendar.MONTH) + 1;
//                if (expYear < currentYear) {
//                    return "INVALID_EXPIRYDATE";
//                } else if (expYear == currentYear) {
//                    if (expMonth < currentMonth) {
//                        return "INVALID_EXPIRYDATE";
//                    }
//                }
//            } else {
//                return "INVALID_EXPIRYDATE";
//            }
//        }
//        if (Request.Requesttype.UPDATECARD.equals(request.getRequest().getRequesttype())) {
//            if ((null != cardholderName && cardholderName.isBlank()) ||
//                    (null != expiryDate && expiryDate.isBlank()) ||
//                    (null != state && state.isBlank()) ||
//                    (null != country && country.isBlank()) ||
//                    (null != zipCode && zipCode.isBlank()) ||
//                    (null != billingAddress1 && billingAddress1.isBlank()) ||
//                    (null != city && city.isBlank()) ||
//                    (null != preferredcard && preferredcard.isBlank())) {
//                LOG.info("[cardholderName, preferredcard, expiryDate, state, country, zip, billingAddress1, city] Fields cannot be empty");
//                return "INVALID_REQUEST";
//            }
//            if (((null != cardholderName && !cardholderName.isBlank())
//                    || (null != expiryDate && !expiryDate.isBlank())
//                    || (null != state && !state.isBlank())
//                    || (null != country && !country.isBlank())
//                    || (null != zipCode && !zipCode.isBlank())
//                    || (null != billingAddress1 && !billingAddress1.isBlank())
//                    || (null != billingAddress2 && !billingAddress2.isBlank())
//                    || (null != city && !city.isBlank()))
//                    && (null == cvv || cvv.isEmpty())) {
//                LOG.info("CVV mandatory for updating [cardholderName, expiryDate, state, country, zip, billingAddress1, " +
//                        "billingAddress2, city]");
//                return "INVALID_REQUEST";
//            }
////            if (null != country && country.trim().length() > 2) {
////                LOG.info("Invalid Country Code. Please enter country code with maximum 2 characters");
////                return "INVALID_REQUEST";
////            }
//            if (null != cid) {
//                LOG.info("CID cannot be updated");
//                return "INVALID_REQUEST";
//            }
//        }
//        return "";
//    }
    public void setMinRangeMilstarPlus(String minRangeMilstarPlus) {
        this.minRangeMilstarPlus = minRangeMilstarPlus;
    }

    public void setMaxRangeMilstarPlus(String maxRangeMilstarPlus) {
        this.maxRangeMilstarPlus = maxRangeMilstarPlus;
    }
}
