package com.ews.wallet.configuration.feign;

import feign.Request;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FeignCustomConfig {

    @Value("${feign.connectTimeout}")
    private int connectTimeout;

    @Value("${feign.readTimeout}")
    private int readTimeout;

    @Bean
    public Request.Options requestOptions() {
        return new Request.Options(connectTimeout, readTimeout);
    }
}
