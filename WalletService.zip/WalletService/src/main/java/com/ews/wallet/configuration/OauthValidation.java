package com.ews.wallet.configuration;

import java.util.Base64;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
	import org.springframework.http.HttpEntity;
	import org.springframework.http.HttpHeaders;
	import org.springframework.http.HttpMethod;
    import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

import com.ews.wallet.controller.WalletController;
import com.ews.wallet.entity.OauthResponse;
import com.ews.walletservice.generated.entity.Response;

@Configuration
public class OauthValidation {

    @Autowired
    private Environment env;
    private static final Logger LOG = (Logger) LoggerFactory.getLogger(OauthValidation.class);

    public OauthResponse oauthTokenValidation(String token, String requestId, String requestType,String applicationId) {
        long starTime = System.nanoTime();
        StringBuilder tempString = new StringBuilder();
        OauthResponse response = new OauthResponse();
        if (null != token && !token.isEmpty()) {
            String oauth2ClientID = env.getProperty("oauth2.client.client-id");
            String oauth2ClientSecret = env.getProperty("oauth2.client.client-secret");
            String oauth2url = env.getProperty("oauth2.resource.token-info-uri");

            var headers = new HttpHeaders();
            RestTemplate restTemplate = new RestTemplate(getClientHttpRequestFactory());
            String userCredentials = oauth2ClientID + ":" + oauth2ClientSecret;
            String ClientAuthorization = Base64.getEncoder().encodeToString(userCredentials.getBytes());
            headers.set("Authorization", "Basic " + ClientAuthorization);
            headers.setContentType(MediaType.MULTIPART_FORM_DATA);
            MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();
            //map.add("token", token);

            HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<MultiValueMap<String, String>>(map, headers);

            try {
                response = restTemplate.exchange(oauth2url + token, HttpMethod.POST, request, OauthResponse.class).getBody();
                LOG.info("Response Received from OAUTH -> "+"RequestId: "+requestId+" Response: " + response.toString());
                if (null != response.getActive() && response.getActive().equalsIgnoreCase("true")) {
                    response.setReasonCode("APPROVED");
                } else {
                    response.setReasonCode("OA_INVALID_TOK");
                    response.setResponseDescription("TOKEN_WAS_NOT_RECOGNISED");
                }

            } catch (Exception e) {
                if ((e.getMessage().contains("Read timed out"))) {
                    response.setActive("true");
                    response.setReasonCode("OA_SRVR_TIMEOUT");
                    response.setResponseDescription("OAUTH_SERVER_TIMEOUT");
                } else if (e.getMessage() != null && e.getMessage().contains("400") || e.getMessage().contains("401")) {

                    response.setReasonCode("OA_UNAUTHORIZED");
                    response.setResponseDescription("OAUTH_SERVER_UNAUTHORIZED");
                } else if (e.getMessage() != null && e.getMessage().contains("404") && e.getMessage().contains("500")) {
                    response.setActive("true");
                    response.setReasonCode("OA_SRVR_DOWN");
                    response.setResponseDescription("OAUTH_SERVER_DOWN");
                } else {
                    response.setActive("true");
                    response.setReasonCode("OA_SRVR_DOWN");
                    response.setResponseDescription("OAUTH_SERVER_DOWN");
                }
            }
        } else {
            String envAppIds = env.getProperty("oauth2.client.oauth-req-app-ids");
            LOG.info("OAuth token validation  -> RequestId : " +requestId+" envAppIds : "+ envAppIds+" ApplicationId : "+ applicationId);
            boolean appIdValidation = oauthAppIdValidation(envAppIds,applicationId);
            if(appIdValidation){
                LOG.info("OAuth token is mandatory for the ApplicationId -> RequestId : " +requestId+" ApplicationId : "+ applicationId);
                response.setActive("false");
            }else{
                response.setActive("true");
            }
            response.setReasonCode("OA_TOK_MISSIN");
            response.setResponseDescription("OAUTH_TOKEN_MISSING");
        }
        long endTime = System.nanoTime();

        long timeElapsed = (endTime - starTime) / 1000000;

        Response responsevault = new Response();
        LOG.info(tempString.append("Elapsed_Time_OAuth|")
                .append(requestId)
                .append("|")
                .append(requestType)
                .append("|")
                .append(response.getReasonCode())
                .append("|")
                .append(response.getResponseDescription())
                .append("|")
                .append(timeElapsed)
                .append(" ms")
                .toString());

        return response;
    }

    private ClientHttpRequestFactory getClientHttpRequestFactory() {
        HttpComponentsClientHttpRequestFactory clientHttpRequestFactory
                = new HttpComponentsClientHttpRequestFactory();
        clientHttpRequestFactory.setConnectTimeout(Integer.parseInt(env.getProperty("oauth2.client.connectTimeout")));
       // clientHttpRequestFactory.setReadTimeout(Integer.parseInt(env.getProperty("oauth2.client.readTimeout")));
        clientHttpRequestFactory.setConnectionRequestTimeout(Integer.parseInt(env.getProperty("oauth2.client.connectTimeout")));
        return clientHttpRequestFactory;
    }

    private boolean oauthAppIdValidation(String envAppIds, String reqAppId) {
        if (envAppIds != null) {
            String appIds[] = envAppIds.split(",");
            for (String appId : appIds) {
                if (reqAppId.equalsIgnoreCase(appId)) {
                    return true;
                }
            }
        }
        return false;
    }
}
