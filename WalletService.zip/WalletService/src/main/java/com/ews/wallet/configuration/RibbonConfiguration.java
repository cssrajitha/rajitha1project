//package com.ews.wallet.configuration;
//
//import com.netflix.client.config.IClientConfig;
//import com.netflix.loadbalancer.IPing;
//import com.netflix.loadbalancer.PingUrl;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.annotation.Bean;
//import org.springframework.core.env.Environment;
//
//public class RibbonConfiguration {
//
//    @Autowired
//    IClientConfig ribbonClient;
//    @Value("${isSecure}")
//    boolean isSecure;
//    @Value("${pingUrl}")
//    String pingUrl;
//
//    //    @Bean
////    public IPing ping(IClientConfig ribbonClient) {
////        return new PingUrl();
////    }
//    @Bean
//    public IPing ping(IClientConfig ribbonClient) {
//        return new PingUrl(isSecure, pingUrl);
//    }
//
//
////    @Bean
////    public IRule rule(IClientConfig ribbonClient) {
////        return new AvailabilityBasedServerSelectionRule();
////    }
//}
