package com.ews.wallet;

import static org.junit.Assert.assertEquals;
import org.junit.Test;
import org.apache.log4j.Logger;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.client.RestTemplate;

@SpringBootTest
class WalletServiceApplicationTests {

    private Logger log = Logger.getLogger(this.getClass());

    @BeforeAll
    static void initAll() {
    }

    @BeforeEach
    void init() {
    }

    @Test
    @DisplayName("main")
    public void main() {
        try {
            log.info("Starting execution of main");
            String[] args = null;

            WalletServiceApplication.main(args);
            Assertions.assertTrue(true);
        } catch (Exception exception) {
            log.error("Exception in execution ofmain-" + exception, exception);
            exception.printStackTrace();
            Assertions.assertFalse(false);
        }
    }

    @Test
    @DisplayName("rest Template")
    public void restTemplate() {
        try {
            log.info("Starting execution of restTemplate");
            WalletServiceApplication walletserviceapplication = Mockito.mock(WalletServiceApplication.class);
            RestTemplate expectedValue = new RestTemplate();

          //  WalletServiceApplication walletserviceapplication = new WalletServiceApplication();
            when(walletserviceapplication.restTemplate()).thenReturn(expectedValue);
            RestTemplate restTemplate  = walletserviceapplication.restTemplate();
            Assertions.assertEquals(expectedValue, restTemplate);
        } catch (Exception exception) {
            log.error("Exception in execution of execute1GetAllLogFromFirstMovF-" + exception, exception);
            exception.printStackTrace();
            Assertions.assertFalse(false);
        }
    }

    @AfterEach
    void tearDown() {
    }

    @AfterAll
    static void tearDownAll() {
    }

}
