package com.ews.wallet.util;

import com.fasterxml.jackson.core.type.TypeReference;
import com.networknt.schema.JsonSchema;
import com.networknt.schema.JsonSchemaFactory;
import com.networknt.schema.SpecVersion;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.BufferedInputStream;
import java.io.InputStream;

public class ValidateSchemaUtilTest {
    private ValidateSchemaUtil validateSchemaUtil;
    private JsonSchema schemaAdd;
    private JsonSchema schemaGet;
    private JsonSchema schemaUpdate;
    private JsonSchema schemaDelete;
    private InputStream schemaStreamAdd;
    private InputStream schemaStreamGet;
    private InputStream schemaStreamDelete;
    private InputStream schemaStreamUpdate;

    @Before
    public void setUp() {
        validateSchemaUtil = new ValidateSchemaUtil();
        JsonSchemaFactory schemaFactory = JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V7);
//        String pathadd = env.getProperty("jsonPath.add");
//        String pathget = env.getProperty("jsonPath.get");
//        String pathdelete = env.getProperty("jsonPath.delete");
//        String pathupdate = env.getProperty("jsonPath.update");
        schemaStreamAdd = new BufferedInputStream(TypeReference.class.getResourceAsStream("/json/Vault_AddCard.json"));
        schemaStreamGet = new BufferedInputStream(TypeReference.class.getResourceAsStream("/json/Vault_GetCard.json"));
        schemaStreamUpdate = new BufferedInputStream(TypeReference.class.getResourceAsStream("/json/Vault_UpdateCard.json"));
        schemaStreamDelete = new BufferedInputStream(TypeReference.class.getResourceAsStream("/json/Vault_DeleteCard.json"));
        schemaAdd = schemaFactory.getSchema(schemaStreamAdd);
        schemaGet = schemaFactory.getSchema(schemaStreamGet);
        schemaUpdate = schemaFactory.getSchema(schemaStreamUpdate);
        schemaDelete = schemaFactory.getSchema(schemaStreamDelete);
    }

    @Test
    public void testValidSchema() {
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"userid\": \"nilotpal@test\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"getcard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\"\n" +
                "    }\n" +
                "}";
        try {
            String response = validateSchemaUtil.validateJsonRequest(inputRequest,schemaGet);
            Assert.assertEquals(null, response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testInvalidSchema() {
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1asdasdasdasd\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"userid\": \"nilotpal@test\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"getcard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\"\n" +
                "    }\n" +
                "}";
        try {
            String response = validateSchemaUtil.validateJsonRequest(inputRequest,schemaGet);
            Assert.assertNotEquals(null, response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testInvalidSchemaException() {
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\"\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"userid\": \"nilotpal@test\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"addcard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\"\n" +
                "    }\n" +
                "}";
        try {
            String response = validateSchemaUtil.validateJsonRequest(inputRequest,schemaGet);
            Assert.assertNotEquals(null, response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }
}
