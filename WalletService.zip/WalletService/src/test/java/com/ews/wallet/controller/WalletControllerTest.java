/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ews.wallet.controller;

//import com.ews.wallet.configuration.EncryptorConfig;
import com.ews.wallet.configuration.OauthValidation;
import com.ews.wallet.configuration.feign.FeignClientConfigAddCard;
import com.ews.wallet.configuration.feign.FeignClientConfigDeleteCard;
import com.ews.wallet.configuration.feign.FeignClientConfigGetCard;
import com.ews.wallet.configuration.feign.FeignClientConfigUpdateCard;
import com.ews.wallet.entity.OauthResponse;
import com.ews.wallet.entity.WalletResponseType;
import com.ews.wallet.util.BuildErrorResponseUtil;
import com.ews.wallet.util.ValidateRequestUtil;
import com.ews.wallet.util.ValidateSchemaUtil;
import com.ews.walletservice.generated.entity.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.networknt.schema.JsonSchema;
import com.networknt.schema.JsonSchemaFactory;
import com.networknt.schema.SpecVersion;
import feign.FeignException;
import jakarta.servlet.http.HttpServletResponse;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.core.env.Environment;
import org.springframework.web.client.RestTemplate;

import java.io.*;
import java.lang.reflect.Field;
import java.net.URI;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;


/**
 * @author prernar
 */
public class WalletControllerTest {
    private RestTemplate restTemplate;
    private WalletController walletController;
    private Environment env;
    private BuildErrorResponseUtil buildErrorResponseUtil;
    private FeignClientConfigDeleteCard feignClientConfigDeleteCard;
    private FeignClientConfigGetCard feignClientConfigGetCard;
    private FeignClientConfigUpdateCard feignClientConfigUpdateCard;
    private FeignClientConfigAddCard feignClientConfigAddCard;
    private JsonSchema schemaAdd;
    private JsonSchema schemaGet;
    private JsonSchema schemaUpdate;
    private JsonSchema schemaDelete;
    private InputStream schemaStreamAdd;
    private InputStream schemaStreamGet;
    private InputStream schemaStreamDelete;
    private InputStream schemaStreamUpdate;
    private String path = "/json";
    private OauthValidation oauthValidation;

    private DiscoveryClient discoveryClient;

    private ValidateRequestUtil validateRequestUtil;

    public WalletControllerTest() {
    }

    //    @BeforeAll
    @Before
    public void setUpClass() throws FileNotFoundException {
        oauthValidation= mock(OauthValidation.class);
        restTemplate = mock(RestTemplate.class);
        walletController = new WalletController();
        env = mock(Environment.class);
        buildErrorResponseUtil = mock(BuildErrorResponseUtil.class);
        feignClientConfigAddCard = mock(FeignClientConfigAddCard.class);
        feignClientConfigUpdateCard = mock(FeignClientConfigUpdateCard.class);
        feignClientConfigGetCard = mock(FeignClientConfigGetCard.class);
        feignClientConfigDeleteCard = mock(FeignClientConfigDeleteCard.class);
//        walletController.setRestTemplate(restTemplate);
        walletController.setOauthValidation(oauthValidation);
        OauthResponse oauthResponse = new OauthResponse();
        oauthResponse.setActive("true");
        when(oauthValidation.oauthTokenValidation(any(),any(),any(),any())).thenReturn(oauthResponse);
        walletController.setBuildErrorResponseUtil(buildErrorResponseUtil);
        walletController.setEnv(env);
        walletController.setFeignClientConfigAddCard(feignClientConfigAddCard);
        walletController.setFeignClientConfigGetCard(feignClientConfigGetCard);
        walletController.setFeignClientConfigDeleteCard(feignClientConfigDeleteCard);
        walletController.setFeignClientConfigUpdateCard(feignClientConfigUpdateCard);
        walletController.getBuildErrorResponseUtil();
        walletController.getEnv();
        walletController.getAddCardEndpointUrl();
        walletController.getGetCardEndpointUrl();
        walletController.getUpdateCardEndpointUrl();
        walletController.getDeleteCardEndpointUrl();
//        walletController.getRestTemplate();
        walletController.getFeignClientConfigAddCard();
        walletController.getFeignClientConfigGetCard();
        walletController.getFeignClientConfigDeleteCard();
        walletController.getFeignClientConfigUpdateCard();
        when(env.getProperty("mask.requestFields")).thenReturn("cid");
        when(env.getProperty("jsonPath.add")).thenReturn("/json/Vault_AddCard.json");
        when(env.getProperty("jsonPath.get")).thenReturn("/json/Vault_GetCard.json");
        when(env.getProperty("jsonPath.update")).thenReturn("/json/Vault_UpdateCard.json");
        when(env.getProperty("jsonPath.delete")).thenReturn("/json/Vault_DeleteCard.json");
        walletController.setAddCardEndpointUrl("add");
        walletController.setGetCardEndpointUrl("get");
        walletController.setUpdateCardEndpointUrl("update");
        walletController.setDeleteCardEndpointUrl("delete");
        JsonSchemaFactory schemaFactory = JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V7);
//        String pathadd = env.getProperty("jsonPath.add");
//        String pathget = env.getProperty("jsonPath.get");
//        String pathdelete = env.getProperty("jsonPath.delete");
//        String pathupdate = env.getProperty("jsonPath.update");
        schemaStreamAdd = new BufferedInputStream(TypeReference.class.getResourceAsStream("/json/Vault_AddCard.json"));
        schemaStreamGet = new BufferedInputStream(TypeReference.class.getResourceAsStream("/json/Vault_GetCard.json"));
        schemaStreamUpdate = new BufferedInputStream(TypeReference.class.getResourceAsStream("/json/Vault_UpdateCard.json"));
        schemaStreamDelete = new BufferedInputStream(TypeReference.class.getResourceAsStream("/json/Vault_DeleteCard.json"));
        schemaAdd = schemaFactory.getSchema(schemaStreamAdd);
        schemaGet = schemaFactory.getSchema(schemaStreamGet);
        schemaUpdate = schemaFactory.getSchema(schemaStreamUpdate);
        schemaDelete = schemaFactory.getSchema(schemaStreamDelete);
        walletController.setSchemaAdd(schemaAdd);
        walletController.setSchemaDelete(schemaDelete);
        walletController.setSchemaGet(schemaGet);
        walletController.setSchemaUpdate(schemaUpdate);
        discoveryClient = mock(DiscoveryClient.class);
        validateRequestUtil = new ValidateRequestUtil();
        validateRequestUtil.setMaxRangeMilstarPlus("9999999999");
        validateRequestUtil.setMinRangeMilstarPlus("1111111111");
        walletController.setValidateRequestUtil(validateRequestUtil);

    }

    @Test
    public void schemaInitTest() {

        try {
//            Mockito.when(restTemplate.postForObject("get", vaultRequest, VaultGetCard.class)).thenReturn(vaultResponse);
            WalletController walletController = Mockito.mock(WalletController.class);
            doNothing().when(walletController).schemaInit();
            walletController.schemaInit();
            verify(walletController).schemaInit();
           // Assert.assertEquals(true, true);
            doThrow(new RuntimeException(" exception")).when(walletController).schemaInit();
            assertThrows(RuntimeException.class, () -> walletController.schemaInit());
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }
       // Assert.assertEquals(true, true);

    }
    @Test
    public void getCardSuccessTest11() {
        VaultGetCard vaultRequest = new VaultGetCard();
        getCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"userid\": \"nilotpal@test\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"getcard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\"\n" +
                "    }\n" +
                "}";
        //HttpServletResponse httpresponse= null;
        HttpServletResponse httpresponse = mock(HttpServletResponse.class);
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultGetCard vaultResponse = new VaultGetCard();
        buildDummyResponseGet(vaultResponse);
        VaultGetCard response = new VaultGetCard();
        //buildDummyResponseGet(response);
        buildDummyResponseOauthInvalid(response);
        VaultGetCard successVaultResponse = new VaultGetCard();
        try {
//            Mockito.when(restTemplate.postForObject("get", vaultRequest, VaultGetCard.class)).thenReturn(vaultResponse);
            when(feignClientConfigGetCard.getcardResponse(vaultRequest)).thenReturn(vaultResponse);
            when(buildErrorResponseUtil.buildErrorResponseGet(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            OauthResponse oauthResponse = new OauthResponse();
            oauthResponse.setActive("false");
            when(oauthValidation.oauthTokenValidation(any(), any(), any(),any())).thenReturn(oauthResponse);
            successVaultResponse = walletController.cardService(inputRequest, header, httpresponse);
            Assert.assertEquals(response, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }


    @Test
    public void invalidRequestTypeGetCardTest() {

        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"userid\": \"nilotpal@test\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"123\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\"\n" +
                "    }\n" +
                "}";
        //HttpServletResponse httpresponse= null;
        HttpServletResponse httpresponse = mock(HttpServletResponse.class);
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";

        VaultGetCard getresponse = new VaultGetCard();
        buildDummyResponseGet(getresponse);

        VaultGetCard successVaultResponse = new VaultGetCard();
        try {

            OauthResponse oauthResponse = new OauthResponse();
            oauthResponse.setActive("true");
            when(oauthValidation.oauthTokenValidation(any(), any(), any(),any())).thenReturn(oauthResponse);

            when(buildErrorResponseUtil.buildErrorResponseGet(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(getresponse);

            successVaultResponse = walletController.cardService(inputRequest, header, httpresponse);
            Assert.assertEquals(getresponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void invalidRequestTypeAddCardTest() {

        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"userid\": \"nilotpal@test\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"123\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\"\n" +
                "    }\n" +
                "}";
        //HttpServletResponse httpresponse= null;
        HttpServletResponse httpresponse = mock(HttpServletResponse.class);
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";

        VaultAddCard response = new VaultAddCard();
        buildDummyResponseAdd(response);
        VaultAddCard successVaultResponse = new VaultAddCard();
        try {

            OauthResponse oauthResponse = new OauthResponse();
            oauthResponse.setActive("true");
            when(oauthValidation.oauthTokenValidation(any(), any(), any(),any())).thenReturn(oauthResponse);
            when(buildErrorResponseUtil.buildErrorResponseAdd(Mockito.any(), anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(response);

            successVaultResponse = walletController.addService(inputRequest, header, httpresponse);
            Assert.assertEquals(response, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void invalidRequestTypeUpdateCardTest() {

        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"userid\": \"nilotpal@test\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"123\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\"\n" +
                "    }\n" +
                "}";
        //HttpServletResponse httpresponse= null;
        HttpServletResponse httpresponse = mock(HttpServletResponse.class);
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";

        VaultUpdateCard response = new VaultUpdateCard();
        buildDummyResponseUpdate(response);
        VaultUpdateCard successVaultResponse = new VaultUpdateCard();
        try {

            OauthResponse oauthResponse = new OauthResponse();
            oauthResponse.setActive("true");
            when(oauthValidation.oauthTokenValidation(any(), any(), any(),any())).thenReturn(oauthResponse);

            when(buildErrorResponseUtil.buildErrorResponseUpdate(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);

            successVaultResponse = walletController.updateService(inputRequest, header, httpresponse);
            Assert.assertEquals(response, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void invalidRequestTypeDeleteCardTest() {

        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"userid\": \"nilotpal@test\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"123\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\"\n" +
                "    }\n" +
                "}";
        //HttpServletResponse httpresponse= null;
        HttpServletResponse httpresponse = mock(HttpServletResponse.class);
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";

        VaultDeleteCard response = new VaultDeleteCard();
        buildDummyResponseDelete(response);
        VaultDeleteCard successVaultResponse = new VaultDeleteCard();
        try {

            OauthResponse oauthResponse = new OauthResponse();
            oauthResponse.setActive("true");
            when(oauthValidation.oauthTokenValidation(any(), any(), any(),any())).thenReturn(oauthResponse);

            when(buildErrorResponseUtil.buildErrorResponseDelete(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);

            successVaultResponse = walletController.deleteService(inputRequest, header, httpresponse);
            Assert.assertEquals(response, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }
    @Test
    public void getCardSuccessTest() {
        VaultGetCard vaultRequest = new VaultGetCard();
        getCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"userid\": \"nilotpal@test\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"getcard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse = mock(HttpServletResponse.class);
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";

        VaultGetCard response = new VaultGetCard();
        buildDummyResponseGet(response);
        VaultGetCard successVaultResponse = new VaultGetCard();
        try {
//
            when(buildErrorResponseUtil.buildErrorResponseGet(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.cardService(inputRequest, header, httpresponse);
            Assert.assertEquals(response, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }


    @Test
    public void getCardFailureTest() {
        VaultGetCard vaultRequest = new VaultGetCard();
        getCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"userid\": \"nilotpal@test\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"deletecard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\",\n" +
                "        \"token\": \"908T4NLJTLYDVXH0010\",\n" +
                "        \"cardtype\": \"Milstar\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultGetCard vaultResponse = new VaultGetCard();
        getCardFailResponse(vaultResponse);
        VaultGetCard response = new VaultGetCard();
        buildDummyResponseGet(response);

        VaultGetCard failVaultResponse = new VaultGetCard();
        try {
//            Mockito.when(restTemplate.postForObject("get", vaultRequest, EnterpriseWalletVault.class)).thenReturn(vaultResponse);
            when(feignClientConfigGetCard.getcardResponse(vaultRequest)).thenReturn(vaultResponse);
            when(buildErrorResponseUtil.buildErrorResponseGet(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            failVaultResponse = walletController.cardService(inputRequest, header, httpresponse);
            Assert.assertNotEquals(vaultResponse, failVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }


    @Test
    public void getCardFeignExceptionTest() {
        VaultGetCard vaultRequest = new VaultGetCard();
        getCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"userid\": \"nilotpal@test\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"getcard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultGetCard vaultResponse = new VaultGetCard();
        buildDummyResponseGet(vaultResponse);
        VaultGetCard response = new VaultGetCard();
        buildDummyResponseGet(response);
        VaultGetCard successVaultResponse = new VaultGetCard();
        try {

            Field field = walletController.getClass().getDeclaredField("retryFeign");
            field.setAccessible(true);
            field.set(walletController, "true");

            Field discoveryClientfield = walletController.getClass().getDeclaredField("discoveryClient");
            discoveryClientfield.setAccessible(true);
            discoveryClientfield.set(walletController, discoveryClient);

            FeignException feignException1 = mock(FeignException.class);
            when(feignException1.status()).thenReturn(-1);
            when(feignException1.getMessage()).thenReturn("timed out");
            when(feignException1.getLocalizedMessage()).thenReturn("Load balancer does not have available server for client");

            when(feignClientConfigGetCard.getcardResponse(any(VaultGetCard.class))).thenThrow(feignException1);

            // Mock Feign client to throw RuntimeException to trigger fallback logic
            // when(feignClientConfigAddCard.getcardResponse(any(VaultGetCard.class))).thenThrow(new RuntimeException("Load balancer error"));

            // Mock discovery client to provide a fallback service instance URI
            ServiceInstance instance = mock(ServiceInstance.class);
            when(instance.getUri()).thenReturn(new URI("http://fallback-server"));
            when(discoveryClient.getInstances("GETCARD-SERVICE")).thenReturn(List.of(instance));

            when(buildErrorResponseUtil.buildErrorResponseGet(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            // assertThrows(FeignException.class, () -> feignClientConfigGetCard.getcardResponse(vaultRequest) );

            successVaultResponse = walletController.cardService(inputRequest, header, httpresponse);
            Assert.assertEquals(vaultResponse, successVaultResponse);

            FeignException feignException2 = mock(FeignException.class);
            when(feignException2.status()).thenReturn(200);
            when(feignException2.getMessage()).thenReturn("otherexecption");
            when(feignException2.getLocalizedMessage()).thenReturn("otherexecption");

            when(feignClientConfigGetCard.getcardResponse(any(VaultGetCard.class))).thenThrow(feignException2);

            successVaultResponse = walletController.cardService(inputRequest, header, httpresponse);
            Assert.assertEquals(vaultResponse, successVaultResponse);

            when(feignClientConfigGetCard.getcardResponse(any(VaultGetCard.class))).thenThrow(NullPointerException.class);

            successVaultResponse = walletController.cardService(inputRequest, header, httpresponse);
            Assert.assertEquals(vaultResponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void addCardFeignExceptionTest() {
        VaultAddCard vaultRequest = new VaultAddCard();
        addCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"userid\": \"nilotpal@test\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41f\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"cid\": \"11122233342\",\n" +
                "        \"crmid\": \"999\",\n" +
                "        \"requesttype\": \"addcard\",\n" +
                "        \"requestid\": \"nilotpal0001\",\n" +
                "        \"pan\": \"2222420000001113\",\n" +
                "        \"cardholdername\": \"John Doe\",\n" +
                "        \"nickname\": \"jd\",\n" +
                "        \"expirydate\": \"2512\",\n" +
                "        \"cardtype\": \"Milstar\",\n" +
                "        \"preferredcard\": \"y\",\n" +
                "        \"cardsecuritycode\": \"677\",\n" +
                "        \"state\": \"sample state\",\n" +
                "        \"country\": \"us\",\n" +
                "        \"zipcode\": \"455-556\",\n" +
                "        \"billingaddress1\": \"sample ad1\",\n" +
                "        \"billingaddress2\": \"sample ad2\",\n" +
                "        \"city\": \"testcity\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultAddCard vaultResponse = new VaultAddCard();
        addCardFailResponse(vaultResponse);
        VaultAddCard response = new VaultAddCard();
        buildDummyResponseAdd(response);
        VaultAddCard successVaultResponse = new VaultAddCard();

        try {

            Field field = walletController.getClass().getDeclaredField("retryFeign");
            field.setAccessible(true);
            field.set(walletController, "true");

            Field discoveryClientfield = walletController.getClass().getDeclaredField("discoveryClient");
            discoveryClientfield.setAccessible(true);
            discoveryClientfield.set(walletController, discoveryClient);

            FeignException feignException1 = mock(FeignException.class);
            when(feignException1.status()).thenReturn(-1);
            when(feignException1.getMessage()).thenReturn("timed out");
            when(feignException1.getLocalizedMessage()).thenReturn("Load balancer does not have available server for client");

            when(feignClientConfigAddCard.addcardResponse(any(VaultAddCard.class))).thenThrow(feignException1);

            // Mock Feign client to throw RuntimeException to trigger fallback logic
            // when(feignClientConfigAddCard.getcardResponse(any(VaultGetCard.class))).thenThrow(new RuntimeException("Load balancer error"));

            // Mock discovery client to provide a fallback service instance URI
            ServiceInstance instance = mock(ServiceInstance.class);
            when(instance.getUri()).thenReturn(new URI("http://fallback-server"));
            when(discoveryClient.getInstances("ADDCARD-SERVICE")).thenReturn(List.of(instance));

            when(buildErrorResponseUtil.buildErrorResponseAdd(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            // assertThrows(FeignException.class, () -> feignClientConfigGetCard.getcardResponse(vaultRequest) );

            successVaultResponse = walletController.addService(inputRequest, header, httpresponse);
            Assert.assertEquals(vaultResponse, successVaultResponse);

            FeignException feignException2 = mock(FeignException.class);
            when(feignException2.status()).thenReturn(200);
            when(feignException2.getMessage()).thenReturn("otherexecption");
            when(feignException2.getLocalizedMessage()).thenReturn("otherexecption");

            when(feignClientConfigAddCard.addcardResponse(any(VaultAddCard.class))).thenThrow(feignException2);
            successVaultResponse = walletController.addService(inputRequest, header, httpresponse);
            Assert.assertEquals(vaultResponse, successVaultResponse);

            when(feignClientConfigAddCard.addcardResponse(any(VaultAddCard.class))).thenThrow(NullPointerException.class);

            successVaultResponse = walletController.addService(inputRequest, header, httpresponse);
            Assert.assertEquals(vaultResponse, successVaultResponse);


        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void updateCardFeignExceptionTest() {
        VaultUpdateCard vaultRequest = new VaultUpdateCard();
        updateCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"userid\": \"nilotpal@test\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41f\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"updatecard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\",\n" +
                "        \"token\": \"93GMM1NG3P6STR28599\",\n" +
                "        \"cardholdername\": \"John wood\",\n" +
                "        \"nickname\": \"NIlotpal\",\n" +
                "        \"expirydate\": \"2512\",\n" +
                "        \"cardtype\": \"Discover\",\n" +
                "        \"preferredcard\": \"y\",\n" +
                "        \"cardsecuritycode\": \"456\",\n" +
                "        \"billingaddress1\": \"88\",\n" +
                "        \"billingaddress2\": \"\",\n" +
                "        \"city\": \"Dallas\",\n" +
                "        \"state\": \"TX\",\n" +
                "        \"zipcode\": \"75038\",\n" +
                "        \"country\": \"US\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultUpdateCard vaultResponse = new VaultUpdateCard();
        updateCardSuccessResponse(vaultResponse);
        VaultUpdateCard response = new VaultUpdateCard();
        buildDummyResponseUpdate(response);
        VaultUpdateCard successVaultResponse = new VaultUpdateCard();
        try {

            Field field = walletController.getClass().getDeclaredField("retryFeign");
            field.setAccessible(true);
            field.set(walletController, "true");

            Field discoveryClientfield = walletController.getClass().getDeclaredField("discoveryClient");
            discoveryClientfield.setAccessible(true);
            discoveryClientfield.set(walletController, discoveryClient);

            FeignException feignException1 = mock(FeignException.class);
            when(feignException1.status()).thenReturn(-1);
            when(feignException1.getMessage()).thenReturn("timed out");
            when(feignException1.getLocalizedMessage()).thenReturn("Load balancer does not have available server for client");

            when(feignClientConfigUpdateCard.updatecardResponse(any(VaultUpdateCard.class))).thenThrow(feignException1);

            // Mock Feign client to throw RuntimeException to trigger fallback logic
            // when(feignClientConfigAddCard.getcardResponse(any(VaultGetCard.class))).thenThrow(new RuntimeException("Load balancer error"));

            // Mock discovery client to provide a fallback service instance URI
            ServiceInstance instance = mock(ServiceInstance.class);
            when(instance.getUri()).thenReturn(new URI("http://fallback-server"));
            when(discoveryClient.getInstances("UPDATECARD-SERVICE")).thenReturn(List.of(instance));

            when(buildErrorResponseUtil.buildErrorResponseUpdate(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            // assertThrows(FeignException.class, () -> feignClientConfigGetCard.getcardResponse(vaultRequest) );

            successVaultResponse = walletController.updateService(inputRequest, header, httpresponse);
            Assert.assertEquals(vaultResponse, successVaultResponse);


            FeignException feignException2 = mock(FeignException.class);
            when(feignException2.status()).thenReturn(200);
            when(feignException2.getMessage()).thenReturn("otherexecption");
            when(feignException2.getLocalizedMessage()).thenReturn("otherexecption");

            when(feignClientConfigUpdateCard.updatecardResponse(any(VaultUpdateCard.class))).thenThrow(feignException2);

            successVaultResponse = walletController.updateService(inputRequest, header, httpresponse);
            Assert.assertEquals(vaultResponse, successVaultResponse);

            when(feignClientConfigUpdateCard.updatecardResponse(any(VaultUpdateCard.class))).thenThrow(NullPointerException.class);

            successVaultResponse = walletController.updateService(inputRequest, header, httpresponse);
            Assert.assertEquals(vaultResponse, successVaultResponse);



        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void deletedCardFeignExceptionTest() {
        VaultDeleteCard vaultRequest = new VaultDeleteCard();
        deleteCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"userid\": \"nilotpal@test\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"deletecard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\",\n" +
                "        \"token\": \"908T4NLJTLYDVXH0010\",\n" +
                "        \"cardtype\": \"Milstar\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultDeleteCard vaultResponse = new VaultDeleteCard();
        deleteCardSuccessResponse(vaultResponse);
        VaultDeleteCard response = new VaultDeleteCard();
        buildDummyResponseDelete(response);
        VaultDeleteCard successVaultResponse = new VaultDeleteCard();
        try {

            Field field = walletController.getClass().getDeclaredField("retryFeign");
            field.setAccessible(true);
            field.set(walletController, "true");

            Field discoveryClientfield = walletController.getClass().getDeclaredField("discoveryClient");
            discoveryClientfield.setAccessible(true);
            discoveryClientfield.set(walletController, discoveryClient);

            FeignException feignException1 = mock(FeignException.class);
            when(feignException1.status()).thenReturn(-1);
            when(feignException1.getMessage()).thenReturn("timed out");
            when(feignException1.getLocalizedMessage()).thenReturn("Load balancer does not have available server for client");

            when(feignClientConfigDeleteCard.deletecardResponse(any(VaultDeleteCard.class))).thenThrow(feignException1);

            // Mock Feign client to throw RuntimeException to trigger fallback logic
            // when(feignClientConfigAddCard.getcardResponse(any(VaultGetCard.class))).thenThrow(new RuntimeException("Load balancer error"));

            // Mock discovery client to provide a fallback service instance URI
            ServiceInstance instance = mock(ServiceInstance.class);
            when(instance.getUri()).thenReturn(new URI("http://fallback-server"));
            when(discoveryClient.getInstances("DELETECARD-SERVICE")).thenReturn(List.of(instance));

            when(buildErrorResponseUtil.buildErrorResponseDelete(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            // assertThrows(FeignException.class, () -> feignClientConfigGetCard.getcardResponse(vaultRequest) );

            successVaultResponse = walletController.deleteService(inputRequest, header, httpresponse);
            Assert.assertEquals(vaultResponse, successVaultResponse);

            FeignException feignException2 = mock(FeignException.class);
            when(feignException2.status()).thenReturn(200);
            when(feignException2.getMessage()).thenReturn("otherexecption");
            when(feignException2.getLocalizedMessage()).thenReturn("otherexecption");

            when(feignClientConfigDeleteCard.deletecardResponse(any(VaultDeleteCard.class))).thenThrow(feignException1);

            successVaultResponse = walletController.deleteService(inputRequest, header, httpresponse);
            Assert.assertEquals(vaultResponse, successVaultResponse);

            when(feignClientConfigDeleteCard.deletecardResponse(any(VaultDeleteCard.class))).thenThrow(NullPointerException.class);

            successVaultResponse = walletController.deleteService(inputRequest, header, httpresponse);
            Assert.assertEquals(vaultResponse, successVaultResponse);

        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void addCardSuccessTest() {
        VaultAddCard vaultRequest = new VaultAddCard();
        addCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"userid\": \"nilotpal@test\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41f\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"cid\": \"11122233342\",\n" +
                "        \"crmid\": \"999\",\n" +
                "        \"requesttype\": \"addcard\",\n" +
                "        \"requestid\": \"nilotpal0001\",\n" +
                "        \"pan\": \"2222420000001113\",\n" +
                "        \"cardholdername\": \"John Doe\",\n" +
                "        \"nickname\": \"jd\",\n" +
                "        \"expirydate\": \"2512\",\n" +
                "        \"cardtype\": \"Milstar\",\n" +
                "        \"preferredcard\": \"y\",\n" +
                "        \"cardsecuritycode\": \"677\",\n" +
                "        \"state\": \"sample state\",\n" +
                "        \"country\": \"us\",\n" +
                "        \"zipcode\": \"455-556\",\n" +
                "        \"billingaddress1\": \"sample ad1\",\n" +
                "        \"billingaddress2\": \"sample ad2\",\n" +
                "        \"city\": \"testcity\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultAddCard vaultResponse = new VaultAddCard();
        addCardFailResponse(vaultResponse);
        VaultAddCard response = new VaultAddCard();
        buildDummyResponseAdd(response);
        VaultAddCard successVaultResponse = new VaultAddCard();
        try {
            when(env.getProperty("mask.requestFields")).thenReturn("pan, crmid, cid, expirydate, cardsecuritycode");
//            Mockito.when(restTemplate.postForObject("add", vaultRequest, EnterpriseWalletVault.class)).thenReturn(vaultResponse);
            when(feignClientConfigAddCard.addcardResponse(vaultRequest)).thenReturn(vaultResponse);
            when(buildErrorResponseUtil.buildErrorResponseAdd(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.addService(inputRequest, header, httpresponse);
            Assert.assertEquals(vaultResponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void addCardInvaliidauthTest() {
        VaultAddCard vaultRequest = new VaultAddCard();
        addCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"userid\": \"nilotpal@test\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41f\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"cid\": \"11122233342\",\n" +
                "        \"crmid\": \"999\",\n" +
                "        \"requesttype\": \"addcard\",\n" +
                "        \"requestid\": \"nilotpal0001\",\n" +
                "        \"pan\": \"2222420000001113\",\n" +
                "        \"cardholdername\": \"John Doe\",\n" +
                "        \"nickname\": \"jd\",\n" +
                "        \"expirydate\": \"2512\",\n" +
                "        \"cardtype\": \"Milstar\",\n" +
                "        \"preferredcard\": \"y\",\n" +
                "        \"cardsecuritycode\": \"677\",\n" +
                "        \"state\": \"sample state\",\n" +
                "        \"country\": \"us\",\n" +
                "        \"zipcode\": \"455-556\",\n" +
                "        \"billingaddress1\": \"sample ad1\",\n" +
                "        \"billingaddress2\": \"sample ad2\",\n" +
                "        \"city\": \"testcity\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse = mock(HttpServletResponse.class);
        String header="{\n" +
                "        \"Autherization\": \"Invalid\",\n" +
                "    },\n";
        VaultAddCard vaultResponse = new VaultAddCard();
        addCardFailResponse(vaultResponse);
        VaultAddCard response = new VaultAddCard();
        buildDummyResponseAdd(response);

        VaultAddCard oauthresponse = new VaultAddCard();
        buildDummyResponseOauthInvalid(oauthresponse);

        VaultAddCard successVaultResponse = new VaultAddCard();
        try {
            when(env.getProperty("mask.requestFields")).thenReturn("pan, crmid, cid, expirydate, cardsecuritycode");
//            Mockito.when(restTemplate.postForObject("add", vaultRequest, EnterpriseWalletVault.class)).thenReturn(vaultResponse);
            when(feignClientConfigAddCard.addcardResponse(vaultRequest)).thenReturn(vaultResponse);
            when(buildErrorResponseUtil.buildErrorResponseAdd(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.addService(inputRequest, header, httpresponse);
            Assert.assertEquals(vaultResponse, successVaultResponse);

            OauthResponse inactiveResponse = new OauthResponse();
            inactiveResponse.setActive("false");
            when(oauthValidation.oauthTokenValidation(anyString(), anyString(), anyString(),anyString())).thenReturn(inactiveResponse);

            successVaultResponse = walletController.addService(inputRequest, "Bearer validToken", httpresponse);
            Assert.assertEquals(oauthresponse, successVaultResponse);


            OauthResponse activeResponse = new OauthResponse();
            activeResponse.setActive("true");
            when(oauthValidation.oauthTokenValidation(anyString(), anyString(), anyString(),anyString())).thenReturn(activeResponse);

            ValidateRequestUtil validateRequestUtil = mock(ValidateRequestUtil.class);
            walletController.setValidateRequestUtil(validateRequestUtil);
            when(validateRequestUtil.validateFieldsAdd(vaultRequest)).thenReturn("");

            // Mock Feign client to throw FeignException with timeout error
            FeignException feignException = mock(FeignException.class);
            when(feignException.getMessage()).thenReturn("Connection refused");
            when(feignException.status()).thenReturn(-1);
            when(feignClientConfigAddCard.addcardResponse(any(VaultAddCard.class))).thenThrow(feignException);

            successVaultResponse = walletController.addService(inputRequest, "Bearer validToken", httpresponse);
            Assert.assertEquals(vaultResponse, successVaultResponse);



            activeResponse = new OauthResponse();
            activeResponse.setActive("true");
            when(oauthValidation.oauthTokenValidation(anyString(), anyString(), anyString(),anyString())).thenReturn(activeResponse);

            // Mock Feign client to throw RuntimeException to trigger fallback logic
            when(feignClientConfigAddCard.addcardResponse(any(VaultAddCard.class))).thenThrow(new RuntimeException("Load balancer error"));

            // Mock discovery client to provide a fallback service instance URI
            ServiceInstance instance = mock(ServiceInstance.class);
            when(instance.getUri()).thenReturn(new URI("http://fallback-server"));
//            when(discoveryClient.getInstances("ADDCARD-SERVICE")).thenReturn(List.of(instance));

            // Mock RestTemplate behavior for fallback call
            VaultAddCard fallbackResponse = new VaultAddCard();
            when(buildErrorResponseUtil.buildErrorResponseAdd(any(VaultAddCard.class), anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(fallbackResponse);

            successVaultResponse = walletController.addService(inputRequest, "Bearer validToken", httpresponse);
            Assert.assertEquals(vaultResponse, successVaultResponse);



            activeResponse.setActive("true");
            when(oauthValidation.oauthTokenValidation(anyString(), anyString(), anyString(),anyString())).thenReturn(activeResponse);

            // Mock the service call to return VaultAddCard with declined response type
            VaultAddCard declinedResponse = new VaultAddCard();
            response = new VaultAddCard();
            buildDummyResponseAdd(response);
            when(buildErrorResponseUtil.buildErrorResponseAdd(any(VaultAddCard.class), anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(response);

            successVaultResponse = walletController.addService(inputRequest, "Bearer validToken", httpresponse);
            Assert.assertEquals(vaultResponse, successVaultResponse);


        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void addCardFailureTest() {
        VaultAddCard vaultRequest = new VaultAddCard();
        addCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"userid\": \"nilotpal@test\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41f\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"cid\": \"11122233342\",\n" +
                "        \"crmid\": \"999\",\n" +
                "        \"requesttype\": \"getcard\",\n" +
                "        \"requestid\": \"nilotpal0001\",\n" +
                "        \"pan\": \"2222420000001113\",\n" +
                "        \"cardholdername\": \"John Doe\",\n" +
                "        \"nickname\": \"jd\",\n" +
                "        \"expirydate\": \"2512\",\n" +
                "        \"cardtype\": \"Milstar\",\n" +
                "        \"preferredcard\": \"y\",\n" +
                "        \"cardsecuritycode\": \"677\",\n" +
                "        \"state\": \"sample state\",\n" +
                "        \"country\": \"us\",\n" +
                "        \"zipcode\": \"455-556\",\n" +
                "        \"billingaddress1\": \"sample ad1\",\n" +
                "        \"billingaddress2\": \"sample ad2\",\n" +
                "        \"city\": \"testcity\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultAddCard vaultResponse = new VaultAddCard();
        addCardFailResponse(vaultResponse);
        VaultAddCard response = new VaultAddCard();
        buildDummyResponseAdd(response);
        response.getResponse().setResponsedescription("INVALID_REQUEST");

        VaultAddCard successVaultResponse = new VaultAddCard();
        try {
            when(buildErrorResponseUtil.buildErrorResponseAdd(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.addService(inputRequest, header, httpresponse);
            Assert.assertNotEquals(vaultResponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void updateCardSuccessTest() {
        VaultUpdateCard vaultRequest = new VaultUpdateCard();
        updateCardVaultRequest(vaultRequest);
        //vaultRequest.getRequest().setRequesttype(Request.Requesttype.UPDATECARD);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"userid\": \"nilotpal@test\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41f\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"updatecard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\",\n" +
                "        \"token\": \"93GMM1NG3P6STR28599\",\n" +
                "        \"cardholdername\": \"John wood\",\n" +
                "        \"nickname\": \"NIlotpal\",\n" +
                "        \"expirydate\": \"2109\",\n" +
                "        \"cardtype\": \"Discover\",\n" +
                "        \"preferredcard\": \"y\",\n" +
                "        \"cardsecuritycode\": \"456\",\n" +
                "        \"billingaddress1\": \"88\",\n" +
                "        \"billingaddress2\": \"\",\n" +
                "        \"city\": \"Dallas\",\n" +
                "        \"state\": \"TX\",\n" +
                "        \"zipcode\": \"75038\",\n" +
                "        \"country\": \"US\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultUpdateCard vaultResponse = new VaultUpdateCard();
        updateCardSuccessResponse(vaultResponse);
        VaultUpdateCard response = new VaultUpdateCard();
        buildDummyResponseUpdate(response);
        VaultUpdateCard successVaultResponse = new VaultUpdateCard();
        try {
//            Mockito.when(restTemplate.postForObject("update", vaultRequest, EnterpriseWalletVault.class)).thenReturn(vaultResponse);
            when(feignClientConfigUpdateCard.updatecardResponse(vaultRequest)).thenReturn(vaultResponse);
            ValidateSchemaUtil validateSchemaUtil = mock(ValidateSchemaUtil.class);
            walletController.setValidateSchemaUtil(validateSchemaUtil);
            when(validateSchemaUtil.validateJsonRequest(any(),any())).thenReturn("success");
            when(buildErrorResponseUtil.buildErrorResponseUpdate(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.updateService(inputRequest, header, httpresponse);
            Assert.assertEquals(vaultResponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void updateCardSuccess1Test() {
        VaultUpdateCard vaultRequest = new VaultUpdateCard();
        updateCardVaultRequest(vaultRequest);
        //vaultRequest.getRequest().setRequesttype(Request.Requesttype.UPDATECARD);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"userid\": \"nilotpal@test\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41f\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"updatecard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\",\n" +
                "        \"token\": \"93GMM1NG3P6STR28599\",\n" +
                "        \"cardholdername\": \"John wood\",\n" +
                "        \"nickname\": \"NIlotpal\",\n" +
                "        \"expirydate\": \"2109\",\n" +
                "        \"cardtype\": \"Discover\",\n" +
                "        \"preferredcard\": \"y\",\n" +
                "        \"cardsecuritycode\": \"456\",\n" +
                "        \"billingaddress1\": \"88\",\n" +
                "        \"billingaddress2\": \"\",\n" +
                "        \"city\": \"Dallas\",\n" +
                "        \"state\": \"TX\",\n" +
                "        \"zipcode\": \"75038\",\n" +
                "        \"country\": \"US\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultUpdateCard vaultResponse = new VaultUpdateCard();
        updateCardSuccessResponse(vaultResponse);
        VaultUpdateCard response = new VaultUpdateCard();
        buildDummyResponseUpdate(response);
        VaultUpdateCard successVaultResponse = new VaultUpdateCard();
        try {
//            Mockito.when(restTemplate.postForObject("update", vaultRequest, EnterpriseWalletVault.class)).thenReturn(vaultResponse);
            when(feignClientConfigUpdateCard.updatecardResponse(vaultRequest)).thenReturn(vaultResponse);
            OauthResponse oauthResponse = new OauthResponse();
            oauthResponse.setActive("false");
            when(oauthValidation.oauthTokenValidation(any(), any(), any(),any())).thenReturn(oauthResponse);
            ValidateSchemaUtil validateSchemaUtil = mock(ValidateSchemaUtil.class);
            walletController.setValidateSchemaUtil(validateSchemaUtil);
            when(validateSchemaUtil.validateJsonRequest(any(),any())).thenReturn("success");
            when(buildErrorResponseUtil.buildErrorResponseUpdate(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.updateService(inputRequest, header, httpresponse);
            Assert.assertEquals(vaultResponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

//    @Test
//    public void updateCardFailureTest() {
//        VaultUpdateCard vaultRequest = new VaultUpdateCard();
//        updateCardVaultRequest(vaultRequest);
//        String inputRequest = "{\n" +
//                "    \"header\": {\n" +
//                "        \"applicationid\": \"DGMA1\",\n" +
//                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
//                "        \"userid\": \"nilotpal@test\"\n" +
//                "    },\n" +
//                "    \"request\": {\n" +
//                "        \"requesttype\": \"getcard\",\n" +
//                "        \"requestid\": \"ABCDEFGHIJKL\"\n" +
//                "    }\n" +
//                "}";
//        VaultUpdateCard vaultResponse = new VaultUpdateCard();
//        updateCardFailResponse(vaultResponse);
//        VaultUpdateCard response = new VaultUpdateCard();
//        buildDummyResponseUpdate(response);
//
//        VaultUpdateCard failVaultResponse = new VaultUpdateCard();
//        try {
////            Mockito.when(restTemplate.postForObject("update", vaultRequest, EnterpriseWalletVault.class)).thenReturn(vaultResponse);
//            Mockito.when(feignClientConfigUpdateCard.updatecardResponse(vaultRequest)).thenReturn(vaultResponse);
//            Mockito.when(buildErrorResponseUtil.buildErrorResponseUpdate(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
//            failVaultResponse = walletController.updateService(inputRequest);
//            Assert.assertNotEquals(vaultResponse, failVaultResponse);
//        } catch (Exception e) {
//            System.out.println("Exception occured -> " + e);
//        }
//
//    }

    @Test
    public void deleteCardSuccesTest1() {
        VaultDeleteCard vaultRequest = new VaultDeleteCard();
        deleteCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"userid\": \"nilotpal@test\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"deletecard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\",\n" +
                "        \"token\": \"908T4NLJTLYDVXH0010\",\n" +
                "        \"cardtype\": \"Milstar\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultDeleteCard vaultResponse = new VaultDeleteCard();
        deleteCardSuccessResponse(vaultResponse);
        VaultDeleteCard response = new VaultDeleteCard();
        buildDummyResponseDelete(response);
        VaultDeleteCard successVaultResponse = new VaultDeleteCard();
        try {
//            Mockito.when(restTemplate.postForObject("delete", vaultRequest, EnterpriseWalletVault.class)).thenReturn(vaultResponse);
            when(feignClientConfigDeleteCard.deletecardResponse(vaultRequest)).thenReturn(vaultResponse);
            when(buildErrorResponseUtil.buildErrorResponseDelete(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            OauthResponse oauthResponse = new OauthResponse();
            oauthResponse.setActive(null);
            walletController.setOauthValidation(oauthValidation);
            when(oauthValidation.oauthTokenValidation(any(),any(),any(),any())).thenReturn(oauthResponse);
            successVaultResponse = walletController.deleteService(inputRequest, header, httpresponse);

            Assert.assertEquals(vaultResponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void deleteCardSuccessTest() {
        VaultDeleteCard vaultRequest = new VaultDeleteCard();
        deleteCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"userid\": \"nilotpal@test\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"deletecard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\",\n" +
                "        \"token\": \"908T4NLJTLYDVXH0010\",\n" +
                "        \"cardtype\": \"Milstar\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultDeleteCard vaultResponse = new VaultDeleteCard();
        deleteCardSuccessResponse(vaultResponse);
        VaultDeleteCard response = new VaultDeleteCard();
        buildDummyResponseDelete(response);
        VaultDeleteCard successVaultResponse = new VaultDeleteCard();
        try {
//            Mockito.when(restTemplate.postForObject("delete", vaultRequest, EnterpriseWalletVault.class)).thenReturn(vaultResponse);
            when(feignClientConfigDeleteCard.deletecardResponse(vaultRequest)).thenReturn(vaultResponse);
            when(buildErrorResponseUtil.buildErrorResponseDelete(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.deleteService(inputRequest, header, httpresponse);
            Assert.assertEquals(vaultResponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

//    @Test
//    public void deleteCardFailureTest() {
//        VaultDeleteCard vaultRequest = new VaultDeleteCard();
//        deleteCardVaultRequest(vaultRequest);
//        String inputRequest = "{\n" +
//                "    \"header\": {\n" +
//                "        \"applicationid\": \"DGMA1\",\n" +
//                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
//                "        \"userid\": \"nilotpal@test\"\n" +
//                "    },\n" +
//                "    \"request\": {\n" +
//                "        \"requesttype\": \"getcard\",\n" +
//                "        \"requestid\": \"ABCDEFGHIJKL\"\n" +
//                "    }\n" +
//                "}";
//        VaultDeleteCard vaultResponse = new VaultDeleteCard();
//        deleteCardFailResponse(vaultResponse);
//        VaultDeleteCard response = new VaultDeleteCard();
//        buildDummyResponseDelete(response);
//
//        VaultDeleteCard failVaultResponse = new VaultDeleteCard();
//        try {
////            Mockito.when(restTemplate.postForObject("delete", vaultRequest, EnterpriseWalletVault.class)).thenReturn(vaultResponse);
//            Mockito.when(feignClientConfigDeleteCard.deletecardResponse(vaultRequest)).thenReturn(vaultResponse);
//            Mockito.when(buildErrorResponseUtil.buildErrorResponseDelete(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
//            failVaultResponse = walletController.deleteService(inputRequest);
//            Assert.assertNotEquals(vaultResponse, failVaultResponse);
//        } catch (Exception e) {
//            System.out.println("Exception occured -> " + e);
//        }
//
//    }


    @Test
    public void getCardTestException() {
        VaultGetCard vaultRequest = new VaultGetCard();
        getCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"userid\": \"nilotpal@test\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"getcard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultGetCard vaultResponse = new VaultGetCard();
        buildDummyResponseGet(vaultResponse);
        VaultGetCard response = new VaultGetCard();
        buildDummyResponseGet(response);
        VaultGetCard successVaultResponse = new VaultGetCard();
        try {
//            Mockito.when(restTemplate.postForObject(Mockito.anyString(), Mockito.any(), Mockito.any())).thenThrow(new RuntimeException());
            when(feignClientConfigGetCard.getcardResponse(Mockito.any())).thenThrow(new RuntimeException());
            when(buildErrorResponseUtil.buildErrorResponseGet(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.cardService(inputRequest, header, httpresponse);
            Assert.assertEquals(vaultResponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void addCardTestException() {
        VaultAddCard vaultRequest = new VaultAddCard();
        addCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"userid\": \"nilotpal@test\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41f\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"cid\": \"11122233342\",\n" +
                "        \"crmid\": \"999\",\n" +
                "        \"requesttype\": \"addcard\",\n" +
                "        \"requestid\": \"nilotpal0001\",\n" +
                "        \"pan\": \"2222420000001113\",\n" +
                "        \"cardholdername\": \"John Doe\",\n" +
                "        \"nickname\": \"jd\",\n" +
                "        \"expirydate\": \"2512\",\n" +
                "        \"cardtype\": \"Milstar\",\n" +
                "        \"preferredcard\": \"y\",\n" +
                "        \"cardsecuritycode\": \"677\",\n" +
                "        \"state\": \"sample state\",\n" +
                "        \"country\": \"us\",\n" +
                "        \"zipcode\": \"455-556\",\n" +
                "        \"billingaddress1\": \"sample ad1\",\n" +
                "        \"billingaddress2\": \"sample ad2\",\n" +
                "        \"city\": \"testcity\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultAddCard vaultResponse = new VaultAddCard();
        addCardFailResponse(vaultResponse);
        VaultAddCard response = new VaultAddCard();
        buildDummyResponseAdd(response);
        VaultAddCard successVaultResponse = new VaultAddCard();
        try {
            when(env.getProperty("mask.requestFields")).thenReturn("pan, crmid, cid, expirydate, cardsecuritycode");
//            Mockito.when(restTemplate.postForObject(Mockito.anyString(), Mockito.any(), Mockito.any())).thenThrow(new RuntimeException());
            when(feignClientConfigAddCard.addcardResponse(Mockito.any())).thenThrow(new RuntimeException());
            when(buildErrorResponseUtil.buildErrorResponseAdd(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.addService(inputRequest, header, httpresponse);
            Assert.assertEquals(vaultResponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void updateCardTestException() {
        VaultUpdateCard vaultRequest = new VaultUpdateCard();
        updateCardVaultRequest(vaultRequest);
        //vaultRequest.getRequest().setRequesttype(Request.Requesttype.UPDATECARD);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"userid\": \"nilotpal@test\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41f\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"updatecard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\",\n" +
                "        \"token\": \"93GMM1NG3P6STR28599\",\n" +
                "        \"cardholdername\": \"John wood\",\n" +
                "        \"nickname\": \"NIlotpal\",\n" +
                "        \"expirydate\": \"2109\",\n" +
                "        \"cardtype\": \"Discover\",\n" +
                "        \"preferredcard\": \"y\",\n" +
                "        \"cardsecuritycode\": \"456\",\n" +
                "        \"billingaddress1\": \"88\",\n" +
                "        \"billingaddress2\": \"\",\n" +
                "        \"city\": \"Dallas\",\n" +
                "        \"state\": \"TX\",\n" +
                "        \"zipcode\": \"75038\",\n" +
                "        \"country\": \"US\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultUpdateCard vaultResponse = new VaultUpdateCard();
        updateCardSuccessResponse(vaultResponse);
        VaultUpdateCard response = new VaultUpdateCard();
        buildDummyResponseUpdate(response);
        VaultUpdateCard successVaultResponse = new VaultUpdateCard();
        try {
//            Mockito.when(restTemplate.postForObject(Mockito.anyString(), Mockito.any(), Mockito.any())).thenThrow(new RuntimeException());
            when(feignClientConfigUpdateCard.updatecardResponse(Mockito.any())).thenThrow(new RuntimeException());
            when(buildErrorResponseUtil.buildErrorResponseUpdate(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.updateService(inputRequest, header, httpresponse);
            Assert.assertEquals(vaultResponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void deleteCardTestException() {
        VaultDeleteCard vaultRequest = new VaultDeleteCard();
        deleteCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"userid\": \"nilotpal@test\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"deletecard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\",\n" +
                "        \"token\": \"908T4NLJTLYDVXH0010\",\n" +
                "        \"cardtype\": \"Milstar\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultDeleteCard vaultResponse = new VaultDeleteCard();
        deleteCardSuccessResponse(vaultResponse);
        VaultDeleteCard response = new VaultDeleteCard();
        buildDummyResponseDelete(response);
        VaultDeleteCard successVaultResponse = new VaultDeleteCard();
        try {
//            Mockito.when(restTemplate.postForObject(Mockito.anyString(), Mockito.any(), Mockito.any())).thenThrow(new RuntimeException());
            when(feignClientConfigDeleteCard.deletecardResponse(Mockito.any())).thenThrow(new RuntimeException());
            when(buildErrorResponseUtil.buildErrorResponseDelete(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.deleteService(inputRequest, header, httpresponse);
            Assert.assertEquals(vaultResponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void testWalletService() throws JSONException {
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"userid\": \"nilotpal@test\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"deletecard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKLdd\",\n" +
                "        \"token\": \"908T4NLJTLYDVXH0010\",\n" +
                "        \"cardtype\": \"Milstar\"\n" +
                "    }\n" +
                "}";
        VaultDeleteCard request = new VaultDeleteCard();
        JSONObject jsonrequest = new JSONObject(inputRequest);
        VaultDeleteCard response = new VaultDeleteCard();
        try {
            String requestId= "";
            String applicationId= "";
            String userId = "";
            String uuid= "";

            response = walletController.walletServiceDelete(inputRequest,jsonrequest, requestId, applicationId, userId , uuid);
            Assert.assertNotEquals(request, response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testWalletService1() throws JSONException {
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"userid\": \"nilotpal@test\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41f\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"cid\": \"11122233342\",\n" +
                "        \"crmid\": \"999\",\n" +
                "        \"requesttype\": \"addcard\",\n" +
                "        \"requestid\": \"nilotpal0001\",\n" +
                "        \"pan\": \"2a222420000001113\",\n" +
                "        \"cardholdername\": \"John Doe\",\n" +
                "        \"nickname\": \"jd\",\n" +
                "        \"expirydate\": \"2512\",\n" +
                "        \"cardtype\": \"Milstar\",\n" +
                "        \"preferredcard\": \"y\",\n" +
                "        \"cardsecuritycode\": \"677\",\n" +
                "        \"state\": \"sample state\",\n" +
                "        \"country\": \"us\",\n" +
                "        \"zipcode\": \"455-556\",\n" +
                "        \"billingaddress1\": \"sample ad1\",\n" +
                "        \"billingaddress2\": \"sample ad2\",\n" +
                "        \"city\": \"testcity\"\n" +
                "    }\n" +
                "}";
        VaultAddCard request = new VaultAddCard();
        VaultAddCard response = new VaultAddCard();
        JSONObject jsonrequest = new JSONObject(inputRequest);
        try {
            String requestId= "";
            String applicationId= "";
            String userId = "";
            String uuid= "";

            response = walletController.walletServiceAdd(inputRequest,jsonrequest, requestId, applicationId, userId , uuid);
            Assert.assertNotEquals(request, response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testWalletService2() throws JSONException {
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"uuid\": null,\n" +
                "        \"userid\": \"nilotpal@test\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"deletecard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\",\n" +
                "        \"token\": \"908T4NLJTLYDVXH0010\",\n" +
                "        \"cardtype\": \"Milstar\"\n" +
                "    }\n" +
                "}";
        VaultDeleteCard request = new VaultDeleteCard();
        VaultDeleteCard response = new VaultDeleteCard();
        JSONObject jsonrequest = new JSONObject(inputRequest);
        try {
            ValidateSchemaUtil validateSchemaUtil = mock(ValidateSchemaUtil.class);
            walletController.setValidateSchemaUtil(validateSchemaUtil);
            when(validateSchemaUtil.validateJsonRequest(anyString(), schemaDelete)).thenReturn("");

            String requestId= "";
            String applicationId= "";
            String userId = "";
            String uuid= "";

            response = walletController.walletServiceDelete(inputRequest,jsonrequest, requestId, applicationId, userId , uuid);
            Assert.assertNotEquals(request, response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testWalletService3() throws JSONException {
        String inputRequest = "{\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"deletecard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\",\n" +
                "        \"token\": \"908T4NLJTLYDVXH0010\",\n" +
                "        \"cardtype\": \"Milstar\"\n" +
                "    }\n" +
                "}";
        VaultDeleteCard request = new VaultDeleteCard();
        VaultDeleteCard response = new VaultDeleteCard();
        JSONObject jsonrequest = new JSONObject(inputRequest);
        try {
            ValidateSchemaUtil validateSchemaUtil = mock(ValidateSchemaUtil.class);
            walletController.setValidateSchemaUtil(validateSchemaUtil);
            when(validateSchemaUtil.validateJsonRequest(anyString(), schemaDelete)).thenReturn("");
            String requestId= "";
            String applicationId= "";
            String userId = "";
            String uuid= "";

            response = walletController.walletServiceDelete(inputRequest,jsonrequest, requestId, applicationId, userId , uuid);
            Assert.assertNotEquals(request, response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testWalletService4() throws JSONException {
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": null,\n" +
                "        \"uuid\": null,\n" +
                "        \"userid\": null\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"deletecard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\",\n" +
                "        \"token\": \"908T4NLJTLYDVXH0010\",\n" +
                "        \"cardtype\": \"Milstar\"\n" +
                "    }\n" +
                "}";
        VaultDeleteCard request = new VaultDeleteCard();
        VaultDeleteCard response = new VaultDeleteCard();
        JSONObject jsonrequest = new JSONObject(inputRequest);
        try {
            ValidateSchemaUtil validateSchemaUtil = mock(ValidateSchemaUtil.class);
            walletController.setValidateSchemaUtil(validateSchemaUtil);
            when(validateSchemaUtil.validateJsonRequest(anyString(), schemaDelete)).thenReturn("");
            String requestId= "";
            String applicationId= "";
            String userId = "";
            String uuid= "";

            response = walletController.walletServiceDelete(inputRequest,jsonrequest, requestId, applicationId, userId , uuid);
            Assert.assertNotEquals(request, response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testWalletService5() throws JSONException {
        String inputRequest = "{\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"deletecard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\",\n" +
                "        \"token\": \"908T4NLJTLYDVXH0010\",\n" +
                "        \"cardtype\": \"Milstar\"\n" +
                "    }\n" +
                "}";
        VaultDeleteCard request = new VaultDeleteCard();
        VaultDeleteCard response = new VaultDeleteCard();
        JSONObject jsonrequest = new JSONObject(inputRequest);
        try {
            ValidateSchemaUtil validateSchemaUtil = mock(ValidateSchemaUtil.class);
            walletController.setValidateSchemaUtil(validateSchemaUtil);
            when(validateSchemaUtil.validateJsonRequest(anyString(), schemaDelete)).thenReturn("");
            String requestId= "";
            String applicationId= "";
            String userId = "";
            String uuid= "";

            response = walletController.walletServiceDelete(inputRequest,jsonrequest, requestId, applicationId, userId , uuid);
            Assert.assertNotEquals(request, response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testWalletService6() throws JSONException {
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": null,\n" +
                "        \"uuid\": null,\n" +
                "        \"userid\": null\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"deletecard\",\n" +
                "        \"requestid\": null,\n" +
                "        \"token\": \"908T4NLJTLYDVXH0010\",\n" +
                "        \"cardtype\": \"Milstar\"\n" +
                "    }\n" +
                "}";
        VaultDeleteCard request = new VaultDeleteCard();
        VaultDeleteCard response = new VaultDeleteCard();
        JSONObject jsonrequest = new JSONObject(inputRequest);
        try {
            ValidateSchemaUtil validateSchemaUtil = mock(ValidateSchemaUtil.class);
            walletController.setValidateSchemaUtil(validateSchemaUtil);
            when(validateSchemaUtil.validateJsonRequest(anyString(), schemaDelete)).thenReturn("");
            String requestId= "";
            String applicationId= "";
            String userId = "";
            String uuid= "";

            response = walletController.walletServiceDelete(inputRequest, jsonrequest, requestId, applicationId, userId , uuid);
            Assert.assertNotEquals(request, response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testWalletService7() throws JSONException {
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": null,\n" +
                "        \"uuid\": null,\n" +
                "        \"userid\": null\n" +
                "    }\n" +
                "}";
        VaultDeleteCard request = new VaultDeleteCard();
        VaultDeleteCard response = new VaultDeleteCard();
        JSONObject jsonrequest = new JSONObject(inputRequest);
        try {
            ValidateSchemaUtil validateSchemaUtil = mock(ValidateSchemaUtil.class);
            walletController.setValidateSchemaUtil(validateSchemaUtil);
            when(validateSchemaUtil.validateJsonRequest(anyString(), schemaDelete)).thenReturn("");
            String requestId= "";
            String applicationId= "";
            String userId = "";
            String uuid= "";

            response = walletController.walletServiceDelete(inputRequest, jsonrequest, requestId, applicationId, userId , uuid);
            Assert.assertNotEquals(request, response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testMaskRequestSensetiveData() {
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"userid\": \"nilotpal@test\",\n" +
                "        \"applicationid\": \"DGMA1\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"deletecard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\",\n" +
                "        \"token\": \"908T4NLJTLYDVXH0010\",\n" +
                "        \"cardtype\": \"Milstar\"\n" +
                "    }\n" +
                "}";
        VaultDeleteCard request = new VaultDeleteCard();
        String maskedRequest = "";
        try {
            when(env.getProperty("mask.requestFields")).thenReturn(null);
            maskedRequest = walletController.maskSensitiveRequestData(inputRequest);
            Assert.assertNotEquals(inputRequest, maskedRequest);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testMaskRequestSensetiveData1() {
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"userid\": \"nilotpal@test\",\n" +
                "        \"applicationid\": \"DGMA1\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"deletecard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\",\n" +
                "        \"token\": \"908T4NLJTLYDVXH0010\",\n" +
                "        \"cardtype\": \"Milstar\"\n" +
                "    }\n" +
                "}";
        VaultDeleteCard request = new VaultDeleteCard();
        String maskedRequest = "";
        try {
            when(env.getProperty("mask.requestFields")).thenReturn("x");
            maskedRequest = walletController.maskSensitiveRequestData(inputRequest);
            Assert.assertNotEquals(inputRequest, maskedRequest);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testMaskRequestSensetiveData2() {
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"userid\": \"nilotpal@test\",\n" +
                "        \"applicationid\": \"DGMA1\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"deletecard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\",\n" +
                "        \"token\": \"\",\n" +
                "        \"cardtype\": \"Milstar\"\n" +
                "    }\n" +
                "}";
        VaultDeleteCard request = new VaultDeleteCard();
        String maskedRequest = "";
        try {
            ValidateRequestUtil validateRequestUtil = mock(ValidateRequestUtil.class);
            walletController.setValidateRequestUtil(validateRequestUtil);
            when(env.getProperty("mask.requestFields")).thenReturn("token");
            maskedRequest = walletController.maskSensitiveRequestData(inputRequest);
            Assert.assertNotEquals(inputRequest, maskedRequest);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void addCardnullResponse() {
        VaultAddCard vaultRequest = new VaultAddCard();
        addCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"userid\": \"nilotpal@test\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41f\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"cid\": \"11122233342\",\n" +
                "        \"crmid\": \"999\",\n" +
                "        \"requesttype\": \"addcard\",\n" +
                "        \"requestid\": \"nilotpal0001\",\n" +
                "        \"pan\": \"2222420000001113\",\n" +
                "        \"cardholdername\": \"John Doe\",\n" +
                "        \"nickname\": \"jd\",\n" +
                "        \"expirydate\": \"2512\",\n" +
                "        \"cardtype\": \"Milstar\",\n" +
                "        \"preferredcard\": \"y\",\n" +
                "        \"cardsecuritycode\": \"677\",\n" +
                "        \"state\": \"sample state\",\n" +
                "        \"country\": \"us\",\n" +
                "        \"zipcode\": \"455-556\",\n" +
                "        \"billingaddress1\": \"sample ad1\",\n" +
                "        \"billingaddress2\": \"sample ad2\",\n" +
                "        \"city\": \"testcity\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultAddCard vaultResponse = new VaultAddCard();
        addCardFailResponse(vaultResponse);
        VaultAddCard response = new VaultAddCard();
        buildDummyResponseAdd(response);
        response.getResponse().setResponsedescription("TIMEOUT");
        VaultAddCard successVaultResponse = new VaultAddCard();
        try {
            ValidateSchemaUtil validateSchemaUtil = mock(ValidateSchemaUtil.class);
            walletController.setValidateSchemaUtil(validateSchemaUtil);
            when(validateSchemaUtil.validateJsonRequest(anyString(), schemaAdd)).thenThrow(new RuntimeException());
            when(env.getProperty("mask.requestFields")).thenReturn("pan, crmid, cid, expirydate, cardsecuritycode");
//            Mockito.when(restTemplate.postForObject("add", vaultRequest, VaultDeleteCard.class)).thenReturn(vaultResponse);
            when(feignClientConfigAddCard.addcardResponse(vaultRequest)).thenReturn(vaultResponse);
            when(buildErrorResponseUtil.buildErrorResponseAdd(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.addService(inputRequest,header,httpresponse);
            Assert.assertNotEquals(vaultResponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void addCardnullResponse1() {
        VaultAddCard vaultRequest = new VaultAddCard();
        addCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"userid\": \"nilotpal@test\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41f\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"cid\": \"11122233342\",\n" +
                "        \"crmid\": \"999\",\n" +
                "        \"requesttype\": \"addcard\",\n" +
                "        \"requestid\": \"nilotpal0001\",\n" +
                "        \"pan\": \"2222420000001113\",\n" +
                "        \"cardholdername\": \"John Doe\",\n" +
                "        \"nickname\": \"jd\",\n" +
                "        \"expirydate\": \"2512\",\n" +
                "        \"cardtype\": \"Milstar\",\n" +
                "        \"preferredcard\": \"y\",\n" +
                "        \"cardsecuritycode\": \"677\",\n" +
                "        \"state\": \"sample state\",\n" +
                "        \"country\": \"us\",\n" +
                "        \"zipcode\": \"455-556\",\n" +
                "        \"billingaddress1\": \"sample ad1\",\n" +
                "        \"billingaddress2\": \"sample ad2\",\n" +
                "        \"city\": \"testcity\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultAddCard vaultResponse = new VaultAddCard();
        addCardFailResponse(vaultResponse);
        VaultAddCard response = new VaultAddCard();
        buildDummyResponseAdd(response);
        response.getResponse().setResponsedescription("DECLINED");
        VaultAddCard successVaultResponse = new VaultAddCard();
        try {
            ValidateSchemaUtil validateSchemaUtil = mock(ValidateSchemaUtil.class);
            walletController.setValidateSchemaUtil(validateSchemaUtil);
            when(validateSchemaUtil.validateJsonRequest(anyString(), schemaAdd)).thenThrow(new RuntimeException());
            when(env.getProperty("mask.requestFields")).thenReturn("pan, crmid, cid, expirydate, cardsecuritycode");
//            Mockito.when(restTemplate.postForObject("add", vaultRequest, VaultDeleteCard.class)).thenReturn(vaultResponse);
            when(feignClientConfigAddCard.addcardResponse(vaultRequest)).thenReturn(vaultResponse);
            when(buildErrorResponseUtil.buildErrorResponseAdd(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.addService(inputRequest, header, httpresponse);
            Assert.assertNotEquals(vaultResponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void addCardnullResponse2() {
        VaultAddCard vaultRequest = new VaultAddCard();
        addCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"userid\": \"nilotpal@test\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41f\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"cid\": \"11122233342\",\n" +
                "        \"crmid\": \"999\",\n" +
                "        \"requesttype\": \"addcard\",\n" +
                "        \"requestid\": \"nilotpal0001\",\n" +
                "        \"pan\": \"2222420000001113\",\n" +
                "        \"cardholdername\": \"John Doe\",\n" +
                "        \"nickname\": \"jd\",\n" +
                "        \"expirydate\": \"2512\",\n" +
                "        \"cardtype\": \"Milstar\",\n" +
                "        \"preferredcard\": \"y\",\n" +
                "        \"cardsecuritycode\": \"677\",\n" +
                "        \"state\": \"sample state\",\n" +
                "        \"country\": \"us\",\n" +
                "        \"zipcode\": \"455-556\",\n" +
                "        \"billingaddress1\": \"sample ad1\",\n" +
                "        \"billingaddress2\": \"sample ad2\",\n" +
                "        \"city\": \"testcity\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultAddCard vaultResponse = new VaultAddCard();
        addCardFailResponse(vaultResponse);
        VaultAddCard response = new VaultAddCard();
        buildDummyResponseAdd(response);
        response.getResponse().setResponsedescription("DECLINED");
        Bankcardaccount bankcardaccount = new Bankcardaccount();
        List<Bankcardaccount> bankcardaccountList = new ArrayList<>();
        Milstaraccount milstaraccount = new Milstaraccount();
        List<Milstaraccount> milstaraccountList = new ArrayList<>();
        response.getResponse().setBankcardaccount(bankcardaccountList);
        response.getResponse().setMilstaraccount(milstaraccountList);
        VaultAddCard successVaultResponse = new VaultAddCard();
        try {
            ValidateSchemaUtil validateSchemaUtil = mock(ValidateSchemaUtil.class);
            walletController.setValidateSchemaUtil(validateSchemaUtil);
            when(validateSchemaUtil.validateJsonRequest(anyString(), schemaAdd)).thenThrow(new RuntimeException());
            when(env.getProperty("mask.requestFields")).thenReturn("pan, crmid, cid, expirydate, cardsecuritycode");
//            Mockito.when(restTemplate.postForObject("add", vaultRequest, EnterpriseWalletVault.class)).thenReturn(vaultResponse);
            when(feignClientConfigAddCard.addcardResponse(vaultRequest)).thenReturn(vaultResponse);
            when(buildErrorResponseUtil.buildErrorResponseAdd(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.addService(inputRequest, header, httpresponse);
            Assert.assertNotEquals(vaultResponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void addCardnullResponse3() {
        VaultAddCard vaultRequest = new VaultAddCard();
        addCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"userid\": \"nilotpal@test\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41f\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"cid\": \"11122233342\",\n" +
                "        \"crmid\": \"999\",\n" +
                "        \"requesttype\": \"addcard\",\n" +
                "        \"requestid\": \"nilotpal0001\",\n" +
                "        \"pan\": \"2222420000001113\",\n" +
                "        \"cardholdername\": \"John Doe\",\n" +
                "        \"nickname\": \"jd\",\n" +
                "        \"expirydate\": \"2512\",\n" +
                "        \"cardtype\": \"Milstar\",\n" +
                "        \"preferredcard\": \"y\",\n" +
                "        \"cardsecuritycode\": \"677\",\n" +
                "        \"state\": \"sample state\",\n" +
                "        \"country\": \"us\",\n" +
                "        \"zipcode\": \"455-556\",\n" +
                "        \"billingaddress1\": \"sample ad1\",\n" +
                "        \"billingaddress2\": \"sample ad2\",\n" +
                "        \"city\": \"testcity\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultAddCard vaultResponse = new VaultAddCard();
        addCardFailResponse(vaultResponse);
        VaultAddCard response = new VaultAddCard();
        buildDummyResponseAdd(response);
        response.getResponse().setResponsedescription("DECLINED");
        Bankcardaccount bankcardaccount = new Bankcardaccount();
        List<Bankcardaccount> bankcardaccountList = new ArrayList<>();
        bankcardaccountList.add(bankcardaccount);
        Milstaraccount milstaraccount = new Milstaraccount();
        List<Milstaraccount> milstaraccountList = new ArrayList<>();
        milstaraccountList.add(milstaraccount);
        response.getResponse().setBankcardaccount(bankcardaccountList);
        response.getResponse().setMilstaraccount(milstaraccountList);
        VaultAddCard successVaultResponse = new VaultAddCard();
        try {
            ValidateSchemaUtil validateSchemaUtil = mock(ValidateSchemaUtil.class);
            walletController.setValidateSchemaUtil(validateSchemaUtil);
            when(validateSchemaUtil.validateJsonRequest(anyString(), schemaAdd)).thenThrow(new RuntimeException());
            when(env.getProperty("mask.requestFields")).thenReturn("pan, crmid, cid, expirydate, cardsecuritycode");
//            Mockito.when(restTemplate.postForObject("add", vaultRequest, EnterpriseWalletVault.class)).thenReturn(vaultResponse);
            when(feignClientConfigAddCard.addcardResponse(vaultRequest)).thenReturn(vaultResponse);
            when(buildErrorResponseUtil.buildErrorResponseAdd(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.addService(inputRequest, header, httpresponse);
            Assert.assertNotEquals(vaultResponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void getCardnullResponse() {
        VaultGetCard vaultRequest = new VaultGetCard();
        getCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"userid\": \"nilotpal@test\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"getcard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultGetCard vaultResponse = new VaultGetCard();
        getCardFailResponse(vaultResponse);
        VaultGetCard response = new VaultGetCard();
        buildDummyResponseGet(response);
        response.getResponse().setResponsedescription("TIMEOUT");
        VaultGetCard successVaultResponse = new VaultGetCard();
        try {
            ValidateSchemaUtil validateSchemaUtil = mock(ValidateSchemaUtil.class);
            walletController.setValidateSchemaUtil(validateSchemaUtil);
            when(validateSchemaUtil.validateJsonRequest(anyString(), schemaGet)).thenThrow(new RuntimeException());
            when(env.getProperty("mask.requestFields")).thenReturn("pan, crmid, cid, expirydate, cardsecuritycode");
//            Mockito.when(restTemplate.postForObject("add", vaultRequest, VaultGetCard.class)).thenReturn(vaultResponse);
            when(feignClientConfigGetCard.getcardResponse(vaultRequest)).thenReturn(vaultResponse);
            when(buildErrorResponseUtil.buildErrorResponseGet(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.cardService(inputRequest,header, httpresponse);
            Assert.assertNotEquals(vaultResponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void getCardnullResponse1() {
        VaultGetCard vaultRequest = new VaultGetCard();
        getCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"userid\": \"nilotpal@test\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"getcard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultGetCard vaultResponse = new VaultGetCard();
        getCardFailResponse(vaultResponse);
        VaultGetCard response = new VaultGetCard();
        buildDummyResponseGet(response);
        response.getResponse().setResponsedescription("DECLINED");
        VaultGetCard successVaultResponse = new VaultGetCard();
        try {
            ValidateSchemaUtil validateSchemaUtil = mock(ValidateSchemaUtil.class);
            walletController.setValidateSchemaUtil(validateSchemaUtil);
            when(validateSchemaUtil.validateJsonRequest(anyString(), schemaGet)).thenThrow(new RuntimeException());
            when(env.getProperty("mask.requestFields")).thenReturn("pan, crmid, cid, expirydate, cardsecuritycode");
//            Mockito.when(restTemplate.postForObject("add", vaultRequest, EnterpriseWalletVault.class)).thenReturn(vaultResponse);
            when(feignClientConfigGetCard.getcardResponse(vaultRequest)).thenReturn(vaultResponse);
            when(buildErrorResponseUtil.buildErrorResponseGet(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.cardService(inputRequest, header, httpresponse);
            Assert.assertNotEquals(vaultResponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void getCardnullResponse2() {
        VaultGetCard vaultRequest = new VaultGetCard();
        getCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"userid\": \"nilotpal@test\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"getcard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultGetCard vaultResponse = new VaultGetCard();
        getCardFailResponse(vaultResponse);
        VaultGetCard response = new VaultGetCard();
        buildDummyResponseGet(response);
        response.getResponse().setResponsedescription("DECLINED");
        Bankcardaccount__1 bankcardaccount = new Bankcardaccount__1();
        List<Bankcardaccount__1> bankcardaccountList = new ArrayList<>();
        Milstaraccount__1 milstaraccount = new Milstaraccount__1();
        List<Milstaraccount__1> milstaraccountList = new ArrayList<>();
        response.getResponse().setBankcardaccount(bankcardaccountList);
        response.getResponse().setMilstaraccount(milstaraccountList);
        VaultGetCard successVaultResponse = new VaultGetCard();
        try {
            ValidateSchemaUtil validateSchemaUtil = mock(ValidateSchemaUtil.class);
            walletController.setValidateSchemaUtil(validateSchemaUtil);
            when(validateSchemaUtil.validateJsonRequest(anyString(), schemaGet)).thenThrow(new RuntimeException());
            when(env.getProperty("mask.requestFields")).thenReturn("pan, crmid, cid, expirydate, cardsecuritycode");
//            Mockito.when(restTemplate.postForObject("add", vaultRequest, EnterpriseWalletVault.class)).thenReturn(vaultResponse);
            when(feignClientConfigGetCard.getcardResponse(vaultRequest)).thenReturn(vaultResponse);
            when(buildErrorResponseUtil.buildErrorResponseGet(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.cardService(inputRequest, header, httpresponse);
            Assert.assertNotEquals(vaultResponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void getCardnullResponse3() {
        VaultGetCard vaultRequest = new VaultGetCard();
        getCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"userid\": \"nilotpal@test\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"getcard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultGetCard vaultResponse = new VaultGetCard();
        getCardFailResponse(vaultResponse);
        VaultGetCard response = new VaultGetCard();
        buildDummyResponseGet(response);
        response.getResponse().setResponsedescription("DECLINED");
        Bankcardaccount__1 bankcardaccount = new Bankcardaccount__1();
        List<Bankcardaccount__1> bankcardaccountList = new ArrayList<>();
        bankcardaccountList.add(bankcardaccount);
        Milstaraccount__1 milstaraccount = new Milstaraccount__1();
        List<Milstaraccount__1> milstaraccountList = new ArrayList<>();
        milstaraccountList.add(milstaraccount);
        response.getResponse().setBankcardaccount(bankcardaccountList);
        response.getResponse().setMilstaraccount(milstaraccountList);
        VaultGetCard successVaultResponse = new VaultGetCard();
        try {
            ValidateSchemaUtil validateSchemaUtil = mock(ValidateSchemaUtil.class);
            walletController.setValidateSchemaUtil(validateSchemaUtil);
            when(validateSchemaUtil.validateJsonRequest(anyString(), schemaGet)).thenThrow(new RuntimeException());
            when(env.getProperty("mask.requestFields")).thenReturn("pan, crmid, cid, expirydate, cardsecuritycode");
//            Mockito.when(restTemplate.postForObject("add", vaultRequest, EnterpriseWalletVault.class)).thenReturn(vaultResponse);
            when(feignClientConfigGetCard.getcardResponse(vaultRequest)).thenReturn(vaultResponse);
            when(buildErrorResponseUtil.buildErrorResponseGet(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.cardService(inputRequest, header, httpresponse);
            Assert.assertNotEquals(vaultResponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void updateCardnullResponse() {
        VaultUpdateCard vaultRequest = new VaultUpdateCard();
        updateCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"userid\": \"nilotpal@test\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41f\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"updatecard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\",\n" +
                "        \"token\": \"93GMM1NG3P6STR28599\",\n" +
                "        \"cardholdername\": \"John wood\",\n" +
                "        \"nickname\": \"NIlotpal\",\n" +
                "        \"expirydate\": \"2109\",\n" +
                "        \"cardtype\": \"Discover\",\n" +
                "        \"preferredcard\": \"y\",\n" +
                "        \"cardsecuritycode\": \"456\",\n" +
                "        \"billingaddress1\": \"88\",\n" +
                "        \"billingaddress2\": \"\",\n" +
                "        \"city\": \"Dallas\",\n" +
                "        \"state\": \"TX\",\n" +
                "        \"zipcode\": \"75038\",\n" +
                "        \"country\": \"US\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultUpdateCard vaultResponse = new VaultUpdateCard();
        updateCardFailResponse(vaultResponse);
        VaultUpdateCard response = new VaultUpdateCard();
        buildDummyResponseUpdate(response);
        response.getResponse().setResponsedescription("TIMEOUT");
        VaultUpdateCard successVaultResponse = new VaultUpdateCard();
        try {
            ValidateSchemaUtil validateSchemaUtil = mock(ValidateSchemaUtil.class);
            walletController.setValidateSchemaUtil(validateSchemaUtil);
            when(validateSchemaUtil.validateJsonRequest(anyString(), schemaUpdate)).thenThrow(new RuntimeException());
            when(env.getProperty("mask.requestFields")).thenReturn("pan, crmid, cid, expirydate, cardsecuritycode");
//            Mockito.when(restTemplate.postForObject("add", vaultRequest, EnterpriseWalletVault.class)).thenReturn(vaultResponse);
            when(feignClientConfigUpdateCard.updatecardResponse(vaultRequest)).thenReturn(vaultResponse);
            when(buildErrorResponseUtil.buildErrorResponseUpdate(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.updateService(inputRequest, header, httpresponse);
            Assert.assertNotEquals(vaultResponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void updateCardnillResponse1() {
        VaultUpdateCard vaultRequest = new VaultUpdateCard();
        updateCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"userid\": \"nilotpal@test\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41f\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"updatecard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\",\n" +
                "        \"token\": \"93GMM1NG3P6STR28599\",\n" +
                "        \"cardholdername\": \"John wood\",\n" +
                "        \"nickname\": \"NIlotpal\",\n" +
                "        \"expirydate\": \"2109\",\n" +
                "        \"cardtype\": \"Discover\",\n" +
                "        \"preferredcard\": \"y\",\n" +
                "        \"cardsecuritycode\": \"456\",\n" +
                "        \"billingaddress1\": \"88\",\n" +
                "        \"billingaddress2\": \"\",\n" +
                "        \"city\": \"Dallas\",\n" +
                "        \"state\": \"TX\",\n" +
                "        \"zipcode\": \"75038\",\n" +
                "        \"country\": \"US\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultUpdateCard vaultResponse = new VaultUpdateCard();
        updateCardFailResponse(vaultResponse);
        VaultUpdateCard response = new VaultUpdateCard();
        buildDummyResponseUpdate(response);
        response.getResponse().setResponsedescription("TIMEOUT");
        VaultUpdateCard successVaultResponse = new VaultUpdateCard();
        try {
            ValidateSchemaUtil validateSchemaUtil = mock(ValidateSchemaUtil.class);
            walletController.setValidateSchemaUtil(validateSchemaUtil);
//            Mockito.when(validateSchemaUtil.validateJsonRequest(any(), any())).thenReturn(null);
            when(env.getProperty("mask.requestFields")).thenReturn("pan, crmid, cid, expirydate, cardsecuritycode");
//            Mockito.when(restTemplate.postForObject("add", vaultRequest, EnterpriseWalletVault.class)).thenReturn(vaultResponse);
            when(feignClientConfigUpdateCard.updatecardResponse(vaultRequest)).thenReturn(vaultResponse);
            when(buildErrorResponseUtil.buildErrorResponseUpdate(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.updateService(inputRequest, header, httpresponse);
            Assert.assertEquals(response, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void updateCardnullResponse1() {
        VaultUpdateCard vaultRequest = new VaultUpdateCard();
        updateCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"userid\": \"nilotpal@test\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41f\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"updatecard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\",\n" +
                "        \"token\": \"93GMM1NG3P6STR28599\",\n" +
                "        \"cardholdername\": \"John wood\",\n" +
                "        \"nickname\": \"NIlotpal\",\n" +
                "        \"expirydate\": \"2109\",\n" +
                "        \"cardtype\": \"Discover\",\n" +
                "        \"preferredcard\": \"y\",\n" +
                "        \"cardsecuritycode\": \"456\",\n" +
                "        \"billingaddress1\": \"88\",\n" +
                "        \"billingaddress2\": \"\",\n" +
                "        \"city\": \"Dallas\",\n" +
                "        \"state\": \"TX\",\n" +
                "        \"zipcode\": \"75038\",\n" +
                "        \"country\": \"US\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultUpdateCard vaultResponse = new VaultUpdateCard();
        updateCardFailResponse(vaultResponse);
        VaultUpdateCard response = new VaultUpdateCard();
        buildDummyResponseUpdate(response);
        response.getResponse().setResponsedescription("DECLINED");
        VaultUpdateCard successVaultResponse = new VaultUpdateCard();
        try {
            ValidateSchemaUtil validateSchemaUtil = mock(ValidateSchemaUtil.class);
            walletController.setValidateSchemaUtil(validateSchemaUtil);
            when(validateSchemaUtil.validateJsonRequest(anyString(), schemaUpdate)).thenThrow(new RuntimeException());
            when(env.getProperty("mask.requestFields")).thenReturn("pan, crmid, cid, expirydate, cardsecuritycode");
//            Mockito.when(restTemplate.postForObject("add", vaultRequest, EnterpriseWalletVault.class)).thenReturn(vaultResponse);
            when(feignClientConfigUpdateCard.updatecardResponse(vaultRequest)).thenReturn(vaultResponse);
            when(buildErrorResponseUtil.buildErrorResponseUpdate(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.updateService(inputRequest, header, httpresponse);
            Assert.assertNotEquals(vaultResponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void updateCardnullResponse2() {
        VaultUpdateCard vaultRequest = new VaultUpdateCard();
        updateCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"userid\": \"nilotpal@test\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41f\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"updatecard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\",\n" +
                "        \"token\": \"93GMM1NG3P6STR28599\",\n" +
                "        \"cardholdername\": \"John wood\",\n" +
                "        \"nickname\": \"NIlotpal\",\n" +
                "        \"expirydate\": \"2109\",\n" +
                "        \"cardtype\": \"Discover\",\n" +
                "        \"preferredcard\": \"y\",\n" +
                "        \"cardsecuritycode\": \"456\",\n" +
                "        \"billingaddress1\": \"88\",\n" +
                "        \"billingaddress2\": \"\",\n" +
                "        \"city\": \"Dallas\",\n" +
                "        \"state\": \"TX\",\n" +
                "        \"zipcode\": \"75038\",\n" +
                "        \"country\": \"US\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultUpdateCard vaultResponse = new VaultUpdateCard();
        updateCardFailResponse(vaultResponse);
        VaultUpdateCard response = new VaultUpdateCard();
        buildDummyResponseUpdate(response);
        response.getResponse().setResponsedescription("DECLINED");
        VaultUpdateCard successVaultResponse = new VaultUpdateCard();
        try {
            ValidateSchemaUtil validateSchemaUtil = mock(ValidateSchemaUtil.class);
            walletController.setValidateSchemaUtil(validateSchemaUtil);
            when(validateSchemaUtil.validateJsonRequest(anyString(), schemaUpdate)).thenThrow(new RuntimeException());
            when(env.getProperty("mask.requestFields")).thenReturn("pan, crmid, cid, expirydate, cardsecuritycode");
//            Mockito.when(restTemplate.postForObject("add", vaultRequest, EnterpriseWalletVault.class)).thenReturn(vaultResponse);
            when(feignClientConfigUpdateCard.updatecardResponse(vaultRequest)).thenReturn(vaultResponse);
            when(buildErrorResponseUtil.buildErrorResponseUpdate(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.updateService(inputRequest, header, httpresponse);
            Assert.assertNotEquals(vaultResponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void updateCardnullResponse3() {
        VaultUpdateCard vaultRequest = new VaultUpdateCard();
        updateCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"userid\": \"nilotpal@test\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41f\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"updatecard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\",\n" +
                "        \"token\": \"93GMM1NG3P6STR28599\",\n" +
                "        \"cardholdername\": \"John wood\",\n" +
                "        \"nickname\": \"NIlotpal\",\n" +
                "        \"expirydate\": \"2109\",\n" +
                "        \"cardtype\": \"Discover\",\n" +
                "        \"preferredcard\": \"y\",\n" +
                "        \"cardsecuritycode\": \"456\",\n" +
                "        \"billingaddress1\": \"88\",\n" +
                "        \"billingaddress2\": \"\",\n" +
                "        \"city\": \"Dallas\",\n" +
                "        \"state\": \"TX\",\n" +
                "        \"zipcode\": \"75038\",\n" +
                "        \"country\": \"US\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultUpdateCard vaultResponse = new VaultUpdateCard();
        updateCardFailResponse(vaultResponse);
        VaultUpdateCard response = new VaultUpdateCard();
        buildDummyResponseUpdate(response);
        response.getResponse().setResponsedescription("DECLINED");
        VaultUpdateCard successVaultResponse = new VaultUpdateCard();
        try {
            ValidateSchemaUtil validateSchemaUtil = mock(ValidateSchemaUtil.class);
            walletController.setValidateSchemaUtil(validateSchemaUtil);
            when(validateSchemaUtil.validateJsonRequest(anyString(), schemaUpdate)).thenThrow(new RuntimeException());
            when(env.getProperty("mask.requestFields")).thenReturn("pan, crmid, cid, expirydate, cardsecuritycode");
//            Mockito.when(restTemplate.postForObject("add", vaultRequest, EnterpriseWalletVault.class)).thenReturn(vaultResponse);
            when(feignClientConfigUpdateCard.updatecardResponse(vaultRequest)).thenReturn(vaultResponse);
            when(buildErrorResponseUtil.buildErrorResponseUpdate(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.updateService(inputRequest, header, httpresponse);
            Assert.assertNotEquals(vaultResponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void deleteCardnullResponse() {
        VaultDeleteCard vaultRequest = new VaultDeleteCard();
        deleteCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"userid\": \"nilotpal@test\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"deletecard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\",\n" +
                "        \"token\": \"908T4NLJTLYDVXH0010\",\n" +
                "        \"cardtype\": \"Milstar\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultDeleteCard vaultResponse = new VaultDeleteCard();
        deleteCardFailResponse(vaultResponse);
        VaultDeleteCard response = new VaultDeleteCard();
        buildDummyResponseDelete(response);
        response.getResponse().setResponsedescription("TIMEOUT");
        VaultDeleteCard successVaultResponse = new VaultDeleteCard();
        try {
            ValidateSchemaUtil validateSchemaUtil = mock(ValidateSchemaUtil.class);
            walletController.setValidateSchemaUtil(validateSchemaUtil);
            when(validateSchemaUtil.validateJsonRequest(anyString(), schemaDelete)).thenThrow(new RuntimeException());
            when(env.getProperty("mask.requestFields")).thenReturn("pan, crmid, cid, expirydate, cardsecuritycode");
//            Mockito.when(restTemplate.postForObject("add", vaultRequest, EnterpriseWalletVault.class)).thenReturn(vaultResponse);
            when(feignClientConfigDeleteCard.deletecardResponse(vaultRequest)).thenReturn(vaultResponse);
            when(buildErrorResponseUtil.buildErrorResponseDelete(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.deleteService(inputRequest, header, httpresponse);
            Assert.assertNotEquals(vaultResponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void deleteCardnullResponse1() {
        VaultDeleteCard vaultRequest = new VaultDeleteCard();
        deleteCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"userid\": \"nilotpal@test\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"deletecard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\",\n" +
                "        \"token\": \"908T4NLJTLYDVXH0010\",\n" +
                "        \"cardtype\": \"Milstar\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultDeleteCard vaultResponse = new VaultDeleteCard();
        deleteCardFailResponse(vaultResponse);
        VaultDeleteCard response = new VaultDeleteCard();
        buildDummyResponseDelete(response);
        response.getResponse().setResponsedescription("DECLINED");
        VaultDeleteCard successVaultResponse = new VaultDeleteCard();
        try {
            ValidateSchemaUtil validateSchemaUtil = mock(ValidateSchemaUtil.class);
            walletController.setValidateSchemaUtil(validateSchemaUtil);
            when(validateSchemaUtil.validateJsonRequest(anyString(), schemaDelete)).thenThrow(new RuntimeException());
            when(env.getProperty("mask.requestFields")).thenReturn("pan, crmid, cid, expirydate, cardsecuritycode");
//            Mockito.when(restTemplate.postForObject("add", vaultRequest, EnterpriseWalletVault.class)).thenReturn(vaultResponse);
            when(feignClientConfigDeleteCard.deletecardResponse(vaultRequest)).thenReturn(vaultResponse);
            when(buildErrorResponseUtil.buildErrorResponseDelete(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.deleteService(inputRequest, header, httpresponse);
            Assert.assertNotEquals(vaultResponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void deleteCardnullResponse2() {
        VaultDeleteCard vaultRequest = new VaultDeleteCard();
        deleteCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"userid\": \"nilotpal@test\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"deletecard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\",\n" +
                "        \"token\": \"908T4NLJTLYDVXH0010\",\n" +
                "        \"cardtype\": \"Milstar\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultDeleteCard vaultResponse = new VaultDeleteCard();
        deleteCardFailResponse(vaultResponse);
        VaultDeleteCard response = new VaultDeleteCard();
        buildDummyResponseDelete(response);
        response.getResponse().setResponsedescription("DECLINED");
        VaultDeleteCard successVaultResponse = new VaultDeleteCard();
        try {
            ValidateSchemaUtil validateSchemaUtil = mock(ValidateSchemaUtil.class);
            walletController.setValidateSchemaUtil(validateSchemaUtil);
            when(validateSchemaUtil.validateJsonRequest(anyString(), schemaDelete)).thenThrow(new RuntimeException());
            when(env.getProperty("mask.requestFields")).thenReturn("pan, crmid, cid, expirydate, cardsecuritycode");
//            Mockito.when(restTemplate.postForObject("add", vaultRequest, EnterpriseWalletVault.class)).thenReturn(vaultResponse);
            when(feignClientConfigDeleteCard.deletecardResponse(vaultRequest)).thenReturn(vaultResponse);
            when(buildErrorResponseUtil.buildErrorResponseDelete(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.deleteService(inputRequest, header, httpresponse);
            Assert.assertNotEquals(vaultResponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void deleteCardnullResponse3() {
        VaultDeleteCard vaultRequest = new VaultDeleteCard();
        deleteCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"userid\": \"nilotpal@test\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"deletecard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\",\n" +
                "        \"token\": \"908T4NLJTLYDVXH0010\",\n" +
                "        \"cardtype\": \"Milstar\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultDeleteCard vaultResponse = new VaultDeleteCard();
        deleteCardFailResponse(vaultResponse);
        VaultDeleteCard response = new VaultDeleteCard();
        buildDummyResponseDelete(response);
        response.getResponse().setResponsedescription("DECLINED");
//        Bankcardaccount bankcardaccount = new Bankcardaccount();
//        List<Bankcardaccount> bankcardaccountList = new ArrayList<>();
//        bankcardaccountList.add(bankcardaccount);
//        Milstaraccount milstaraccount = new Milstaraccount();
//        List<Milstaraccount> milstaraccountList = new ArrayList<>();
//        milstaraccountList.add(milstaraccount);
//        response.getResponse().setBankcardaccount(bankcardaccountList);
//        response.getResponse().setMilstaraccount(milstaraccountList);
        VaultDeleteCard successVaultResponse = new VaultDeleteCard();

        try {
            ValidateSchemaUtil validateSchemaUtil = mock(ValidateSchemaUtil.class);
            walletController.setValidateSchemaUtil(validateSchemaUtil);
            when(validateSchemaUtil.validateJsonRequest(anyString(), schemaDelete)).thenThrow(new RuntimeException());
            when(env.getProperty("mask.requestFields")).thenReturn("pan, crmid, cid, expirydate, cardsecuritycode");
//            Mockito.when(restTemplate.postForObject("add", vaultRequest, EnterpriseWalletVault.class)).thenReturn(vaultResponse);
            when(feignClientConfigDeleteCard.deletecardResponse(vaultRequest)).thenReturn(vaultResponse);
            when(buildErrorResponseUtil.buildErrorResponseDelete(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.deleteService(inputRequest, header, httpresponse);
            Assert.assertNotEquals(vaultResponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }
    }

    @Test
    public void testWalletService8() throws JSONException {
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"userid\": \"nilotpal@test\"\n" +
                "    }\n" +
                "}";
        VaultAddCard request = new VaultAddCard();
        VaultAddCard response = new VaultAddCard();
        JSONObject jsonrequest = new JSONObject(inputRequest);
        try {
            String requestId= "";
            String applicationId= "";
            String userId = "";
            String uuid= "";

            response = walletController.walletServiceAdd(inputRequest,jsonrequest, requestId, applicationId, userId , uuid);
            Assert.assertNotEquals(request, response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testWalletService9() throws JSONException {
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"x\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"z\": \"nilotpal@test\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"deletecard\",\n" +
                "        \"token\": \"908T4NLJTLYDVXH0010\",\n" +
                "        \"cardtype\": \"Milstar\"\n" +
                "    }\n" +
                "}";
        VaultDeleteCard request = new VaultDeleteCard();
        JSONObject jsonrequest = new JSONObject(inputRequest);
        VaultDeleteCard response = new VaultDeleteCard();
        try {
            String requestId= "";
            String applicationId= "";
            String userId = "";
            String uuid= "";

            response = walletController.walletServiceDelete(inputRequest,jsonrequest, requestId, applicationId, userId , uuid);
            Assert.assertNotEquals(request, response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testWalletService10() throws JSONException {
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"x\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"z\": \"nilotpal@test\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"x\",\n" +
                "        \"token\": \"908T4NLJTLYDVXH0010\",\n" +
                "        \"cardtype\": \"Milstar\"\n" +
                "    }\n" +
                "}";
        VaultGetCard request = new VaultGetCard();
        VaultGetCard response = new VaultGetCard();
        JSONObject jsonrequest = new JSONObject(inputRequest);
        try {
            String requestId= "";
            String applicationId= "";
            String userId = "";
            String uuid= "";

            response = walletController.walletServiceGet(inputRequest,jsonrequest, requestId, applicationId, userId , uuid);
            Assert.assertNotEquals(request, response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void getCardSuccessTest1() {
        VaultGetCard vaultRequest = new VaultGetCard();
        getCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"userid\": \"nilotpal@test\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"getcard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultGetCard vaultResponse = new VaultGetCard();
        buildDummyResponseGet(vaultResponse);
        List<Milstaraccount__1> milstaraccountList = new ArrayList<>();
        Milstaraccount__1 milstaraccount = new Milstaraccount__1();
        milstaraccount.setToken("asdasd223");
        milstaraccountList.add(milstaraccount);
        List<Bankcardaccount__1> bankcardaccountList = new ArrayList<>();
        Bankcardaccount__1 bankcardaccount = new Bankcardaccount__1();
        bankcardaccount.setToken("123423ewsd");
        bankcardaccountList.add(bankcardaccount);
        vaultResponse.getResponse().setMilstaraccount(milstaraccountList);
        vaultResponse.getResponse().setBankcardaccount(bankcardaccountList);
        VaultGetCard response = new VaultGetCard();
        buildDummyResponseGet(response);
        VaultGetCard successVaultResponse = new VaultGetCard();
        try {
//            Mockito.when(restTemplate.postForObject("get", vaultRequest, EnterpriseWalletVault.class)).thenReturn(vaultResponse);
            when(feignClientConfigGetCard.getcardResponse(Mockito.any())).thenReturn(vaultResponse);
            when(buildErrorResponseUtil.buildErrorResponseGet(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.cardService(inputRequest, header, httpresponse);
            Assert.assertEquals(vaultResponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void deleteCardSuccessTest1() {
        VaultDeleteCard vaultRequest = new VaultDeleteCard();
        deleteCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "        \"userid\": \"nilotpal@test\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"deletecard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\",\n" +
                "        \"token\": \"908T4NLJTLYDVXH0010\",\n" +
                "        \"cardtype\": \"Milstar\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultDeleteCard vaultResponse = new VaultDeleteCard();
        deleteCardSuccessResponse(vaultResponse);
//        List<Milstaraccount> milstaraccountList = new ArrayList<>();
//        Milstaraccount milstaraccount = new Milstaraccount();
//        milstaraccount.setToken("asdasd223");
//        milstaraccountList.add(milstaraccount);
//        List<Bankcardaccount> bankcardaccountList = new ArrayList<>();
//        Bankcardaccount bankcardaccount = new Bankcardaccount();
//        bankcardaccount.setToken("123423ewsd");
//        bankcardaccountList.add(bankcardaccount);
//        vaultResponse.getResponse().setMilstaraccount(milstaraccountList);
//        vaultResponse.getResponse().setBankcardaccount(bankcardaccountList);
        VaultDeleteCard response = new VaultDeleteCard();
        buildDummyResponseDelete(response);
        VaultDeleteCard successVaultResponse = new VaultDeleteCard();
        try {
//            Mockito.when(restTemplate.postForObject("delete", vaultRequest, VaultDeleteCard.class)).thenReturn(vaultResponse);
            when(feignClientConfigDeleteCard.deletecardResponse(Mockito.any())).thenReturn(vaultResponse);
            when(buildErrorResponseUtil.buildErrorResponseDelete(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.deleteService(inputRequest, header, httpresponse);
            Assert.assertEquals(vaultResponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void updateCardSuccessTest1() {
        VaultUpdateCard vaultRequest = new VaultUpdateCard();
        updateCardVaultRequest(vaultRequest);
        //vaultRequest.getRequest().setRequesttype(Request__3.Requesttype.UPDATECARD);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"userid\": \"nilotpal@test\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41f\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"requesttype\": \"updatecard\",\n" +
                "        \"requestid\": \"ABCDEFGHIJKL\",\n" +
                "        \"token\": \"93GMM1NG3P6STR28599\",\n" +
                "        \"cardholdername\": \"John wood\",\n" +
                "        \"nickname\": \"NIlotpal\",\n" +
                "        \"expirydate\": \"2109\",\n" +
                "        \"cardtype\": \"Discover\",\n" +
                "        \"preferredcard\": \"y\",\n" +
                "        \"cardsecuritycode\": \"456\",\n" +
                "        \"billingaddress1\": \"88\",\n" +
                "        \"billingaddress2\": \"\",\n" +
                "        \"city\": \"Dallas\",\n" +
                "        \"state\": \"TX\",\n" +
                "        \"zipcode\": \"75038\",\n" +
                "        \"country\": \"US\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultUpdateCard vaultResponse = new VaultUpdateCard();
        updateCardSuccessResponse(vaultResponse);
//        List<Milstaraccount> milstaraccountList = new ArrayList<>();
//        Milstaraccount milstaraccount = new Milstaraccount();
//        milstaraccount.setToken("asdasd223");
//        milstaraccountList.add(milstaraccount);
//        List<Bankcardaccount> bankcardaccountList = new ArrayList<>();
//        Bankcardaccount bankcardaccount = new Bankcardaccount();
//        bankcardaccount.setToken("123423ewsd");
//        bankcardaccountList.add(bankcardaccount);
//        vaultResponse.getResponse().setMilstaraccount(milstaraccountList);
//        vaultResponse.getResponse().setBankcardaccount(bankcardaccountList);
        VaultUpdateCard response = new VaultUpdateCard();
        buildDummyResponseUpdate(response);
        VaultUpdateCard successVaultResponse = new VaultUpdateCard();
        try {
//            Mockito.when(restTemplate.postForObject("update", vaultRequest, VaultUpdateCard.class)).thenReturn(vaultResponse);
            when(feignClientConfigUpdateCard.updatecardResponse(Mockito.any())).thenReturn(vaultResponse);
            when(buildErrorResponseUtil.buildErrorResponseUpdate(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.updateService(inputRequest, header, httpresponse);
            Assert.assertEquals(vaultResponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

    @Test
    public void addCardSuccessTest1() {
        VaultAddCard vaultRequest = new VaultAddCard();
        addCardVaultRequest(vaultRequest);
        String inputRequest = "{\n" +
                "    \"header\": {\n" +
                "        \"applicationid\": \"DGMA1\",\n" +
                "        \"userid\": \"nilotpal@test\",\n" +
                "        \"uuid\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41f\"\n" +
                "    },\n" +
                "    \"request\": {\n" +
                "        \"cid\": \"11122233342\",\n" +
                "        \"crmid\": \"999\",\n" +
                "        \"requesttype\": \"addcard\",\n" +
                "        \"requestid\": \"nilotpal0001\",\n" +
                "        \"pan\": \"2222420000001113\",\n" +
                "        \"cardholdername\": \"John Doe\",\n" +
                "        \"nickname\": \"jd\",\n" +
                "        \"expirydate\": \"2512\",\n" +
                "        \"cardtype\": \"Milstar\",\n" +
                "        \"preferredcard\": \"y\",\n" +
                "        \"cardsecuritycode\": \"677\",\n" +
                "        \"state\": \"sample state\",\n" +
                "        \"country\": \"us\",\n" +
                "        \"zipcode\": \"455-556\",\n" +
                "        \"billingaddress1\": \"sample ad1\",\n" +
                "        \"billingaddress2\": \"sample ad2\",\n" +
                "        \"city\": \"testcity\"\n" +
                "    }\n" +
                "}";
        HttpServletResponse httpresponse=null;
        String header="{\n" +
                "        \"Autherization\": \"ABC01a6d-7b07-473b-b1aa-72fe79d7c41x\",\n" +
                "    },\n";
        VaultAddCard vaultResponse = new VaultAddCard();
        addCardFailResponse(vaultResponse);
        List<Milstaraccount> milstaraccountList = new ArrayList<>();
        Milstaraccount milstaraccount = new Milstaraccount();
        milstaraccount.setToken("asdasd223");
        milstaraccountList.add(milstaraccount);
        List<Bankcardaccount> bankcardaccountList = new ArrayList<>();
        Bankcardaccount bankcardaccount = new Bankcardaccount();
        bankcardaccount.setToken("123423ewsd");
        bankcardaccountList.add(bankcardaccount);
        vaultResponse.getResponse().setMilstaraccount(milstaraccountList);
        vaultResponse.getResponse().setBankcardaccount(bankcardaccountList);
        VaultAddCard response = new VaultAddCard();
        buildDummyResponseAdd(response);
        VaultAddCard successVaultResponse = new VaultAddCard();
        try {
            when(env.getProperty("mask.requestFields")).thenReturn("pan, crmid, cid, expirydate, cardsecuritycode");
//            Mockito.when(restTemplate.postForObject("add", vaultRequest, EnterpriseWalletVault.class)).thenReturn(vaultResponse);
            when(feignClientConfigAddCard.addcardResponse(Mockito.any())).thenReturn(vaultResponse);
            when(buildErrorResponseUtil.buildErrorResponseAdd(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(response);
            successVaultResponse = walletController.addService(inputRequest, header, httpresponse);
            Assert.assertEquals(vaultResponse, successVaultResponse);
        } catch (Exception e) {
            System.out.println("Exception occured -> " + e);
        }

    }

//    @Test
//    public void testEncryptor(){
////        LOG.info("Values from properties file : baseDir " + baseDir);
//        String baseDir = "D:/configServer";
//        String keysPath = baseDir + File.separator + "crypto" + File.separator + "keys";
//        String logPath = baseDir + File.separator + "crypto.log4j.properties";
//
//        EncryptorConfig encryptor = new EncryptorConfig(keysPath, logPath);
//        try {
//            String pass = encryptor.decrypt("AEbCC6gLuoSqbrAXZlixa3I1eooPha1GP78Q9TDrO6fzJeREh5wNDzsKhB9tGiD1g2Zu4CQ3H2CAsP3zTlV37j3xHXZlBvPb3FE6bw8sxCQ5aSjFiaemCY849KXPTSsOUwLK-gmN88zuBgbzvLjnS-a0x19kVTHk85ay6fyij9FP67FAvgI6m10krjFKSLhkAMe8yHnjrSDTztDiBfcMIPBPO4JR6PoumMOeUEAY_jRpQP8JFHqs90CFeJmx6dnnyioJAkWxxBcPRdZ-qocUs_hcZGLLULIAw3AvldA1ViMuUrGbd65-AJ2GExrnLj5A87giIteXIDR0JnhghwEadyfCtHwy");
//            System.out.println(pass);
//        } catch (Exception e) {
////            LOG.error("Exception occurred during decryption of keystore password details");
//        }
//    }

    private void addCardSuccessResponse(VaultAddCard vaultResponse) {
        Header vaultRequestHeader = new Header();
        vaultRequestHeader.setApplicationid("DGMA00012345");
        vaultRequestHeader.setUuid("ABC01a6d-7b07-473b-b1aa-72fe79d7c41f");
        vaultRequestHeader.setUserid("test@test.com");
        vaultResponse.setHeader(vaultRequestHeader);
        Response vaultResponseBody = new Response();
        vaultResponseBody.setRequestid("000012345678");
        vaultResponseBody.setResponsecode("W100");
        vaultResponseBody.setResponsetype("Approved");
        vaultResponseBody.setResponsedescription("Approved");
        Milstaraccount responseAccounts = new Milstaraccount();
        responseAccounts.setToken("901ICRFOTPDDI5R2250");
        List<Milstaraccount> responseAccountList = new ArrayList<>();
        responseAccountList.add(responseAccounts);
        vaultResponseBody.setMilstaraccount(responseAccountList);
        vaultResponse.setResponse(vaultResponseBody);
        vaultResponse.setRequest(null);
    }

    private void addCardFailResponse(VaultAddCard vaultResponse) {
        Header vaultRequestHeader = new Header();
        vaultRequestHeader.setApplicationid("DGMA1");
        vaultRequestHeader.setUuid("ABC01a6d-7b07-473b-b1aa-72fe79d7c41f");
        vaultRequestHeader.setUserid("nilotpal@test");
        vaultResponse.setHeader(vaultRequestHeader);
        Response vaultResponseBody = new Response();
        vaultResponseBody.setRequestid("nilotpal0001");
        vaultResponseBody.setResponsecode("W800");
        vaultResponseBody.setResponsetype("Decline");
        vaultResponseBody.setResponsedescription("INTERNAL_SERVER_ERROR");
        vaultResponseBody.setMilstaraccount(null);
        vaultResponseBody.setBankcardaccount(null);
        vaultResponse.setResponse(vaultResponseBody);
        vaultResponse.setRequest(null);
    }

    private void updateCardFailResponse(VaultUpdateCard vaultResponse) {
        Header__3 vaultRequestHeader = new Header__3();
        vaultRequestHeader.setApplicationid("DGMA1");
        vaultRequestHeader.setUuid("ABC01a6d-7b07-473b-b1aa-72fe79d7c41f");
        vaultRequestHeader.setUserid("nilotpal@test");
        vaultResponse.setHeader(vaultRequestHeader);
        Response__3 vaultResponseBody = new Response__3();
        vaultResponseBody.setRequestid("nilotpal0001");
        vaultResponseBody.setResponsecode("W800");
        vaultResponseBody.setResponsetype("Decline");
        vaultResponseBody.setResponsedescription("INTERNAL_SERVER_ERROR");
        vaultResponse.setResponse(vaultResponseBody);
        vaultResponse.setRequest(null);
    }

    private void deleteCardFailResponse(VaultDeleteCard vaultResponse) {
        Header__1 vaultRequestHeader = new Header__1();
        vaultRequestHeader.setApplicationid("DGMA1");
        vaultRequestHeader.setUuid("ABC01a6d-7b07-473b-b1aa-72fe79d7c41f");
        vaultRequestHeader.setUserid("nilotpal@test");
        vaultResponse.setHeader(vaultRequestHeader);
        Response__1 vaultResponseBody = new Response__1();
        vaultResponseBody.setRequestid("nilotpal0001");
        vaultResponseBody.setResponsecode("W800");
        vaultResponseBody.setResponsetype("Decline");
        vaultResponseBody.setResponsedescription("INTERNAL_SERVER_ERROR");
//        vaultResponseBody.setMilstaraccount(null);
//        vaultResponseBody.setBankcardaccount(null);
        vaultResponse.setResponse(vaultResponseBody);
        vaultResponse.setRequest(null);
    }

    private void addCardVaultRequest(VaultAddCard vaultRequest) {
        Header vaultRequestHeader = new Header();
        Request vaultRequestBody = new Request();
        vaultRequestHeader.setApplicationid("DGMA1");
        vaultRequestHeader.setUuid("ABC01a6d-7b07-473b-b1aa-72fe79d7c41f");
        vaultRequestHeader.setUserid("nilotpal@test");
        vaultRequest.setHeader(vaultRequestHeader);
        vaultRequestBody.setCid("11122233342");
        vaultRequestBody.setCrmid("999");
        vaultRequestBody.setRequesttype(Request.Requesttype.ADDCARD);
        vaultRequestBody.setRequestid("nilotpal0001");
        vaultRequestBody.setPan("2222420000001113");
        vaultRequestBody.setCardholdername("John Doe");
        vaultRequestBody.setNickname("jd");
        vaultRequestBody.setExpirydate("2512");
        vaultRequestBody.setCardtype(Request.Cardtype.MILSTAR);
        vaultRequestBody.setPreferredcard("Y");
        vaultRequestBody.setCardsecuritycode("677");
        vaultRequestBody.setState("sample state");
        vaultRequestBody.setCountry("us");
        vaultRequestBody.setZipcode("455-556");
        vaultRequestBody.setBillingaddress1("sample ad1");
        vaultRequestBody.setBillingaddress2("sample ad2");
        vaultRequestBody.setCity("testcity");
        vaultRequest.setRequest(vaultRequestBody);
    }

    private void getCardVaultRequest(VaultGetCard vaultRequest) {
        Header__2 vaultRequestHeader = new Header__2();
        Request__2 vaultRequestBody = new Request__2();
        vaultRequestHeader.setApplicationid("DGMA1");
        vaultRequestHeader.setUuid("ABC01a6d-7b07-473b-b1aa-72fe79d7c41f");
        vaultRequestHeader.setUserid("nilotpal@test");
        vaultRequest.setHeader(vaultRequestHeader);
        vaultRequestBody.setRequesttype(Request__2.Requesttype.GETCARD);
        vaultRequestBody.setRequestid("ABCDEFGHIJKL");
        vaultRequest.setRequest(vaultRequestBody);
    }

    private void deleteCardVaultRequest(VaultDeleteCard vaultRequest) {
        Header__1 vaultRequestHeader = new Header__1();
        Request__1 vaultRequestBody = new Request__1();
        vaultRequestHeader.setApplicationid("DGMA1");
        vaultRequestHeader.setUuid("ABC01a6d-7b07-473b-b1aa-72fe79d7c41f");
        vaultRequestHeader.setUserid("nilotpal@test");
        vaultRequest.setHeader(vaultRequestHeader);
        vaultRequestBody.setRequesttype(Request__1.Requesttype.DELETECARD);
        vaultRequestBody.setRequestid("ABCDEFGHIJKL");
        vaultRequest.setRequest(vaultRequestBody);
    }

    private void updateCardVaultRequest(VaultUpdateCard vaultRequest) {
        Header__3 vaultRequestHeader = new Header__3();
        Request__3 vaultRequestBody = new Request__3();
        vaultRequestHeader.setApplicationid("DGMA1");
        vaultRequestHeader.setUuid("ABC01a6d-7b07-473b-b1aa-72fe79d7c41f");
        vaultRequestHeader.setUserid("nilotpal@test");
        vaultRequest.setHeader(vaultRequestHeader);
        vaultRequestBody.setRequesttype(Request__3.Requesttype.UPDATECARD);
        vaultRequestBody.setRequestid("ABCDEFGHIJKL");
        vaultRequest.setRequest(vaultRequestBody);
    }

    private void getCardSuccessResponse(VaultGetCard vaultResponse) {
        Header__2 vaultResponseHeader = new Header__2();
        vaultResponseHeader.setApplicationid("DGMA00123456");
        vaultResponseHeader.setUuid("ABC01a6d-7b07-473b-b1aa-72fe79d7c41f");
        vaultResponse.setHeader(vaultResponseHeader);
        Response__2 vaultResponseBody = new Response__2();
        vaultResponseBody.setRequestid("002000000000");
        vaultResponseBody.setResponsecode("W100");
        vaultResponseBody.setResponsetype("Approved");
        vaultResponseBody.setResponsedescription("Accepted");
        List<Milstaraccount__1> responseAccountsList = new ArrayList<>();
        Milstaraccount__1 responseAccount1 = new Milstaraccount__1();
        responseAccount1.setToken("80RZTIM3BJXXCCO9002");
        responseAccount1.setCardholdername("test");
        responseAccount1.setExpirydate("2512");
        responseAccount1.setPreferredcard("N");
        responseAccount1.setState("abc");
        responseAccount1.setCity("abc");
        responseAccount1.setBillingaddress1("abc");
        responseAccount1.setCountry("abc");
        responseAccount1.setZipcode("778777");
        responseAccountsList.add(responseAccount1);
        vaultResponseBody.setMilstaraccount(responseAccountsList);
        vaultResponse.setResponse(vaultResponseBody);
        vaultResponse.setRequest(null);
    }

    private void getCardFailResponse(VaultGetCard vaultResponse) {
        Header__2 vaultResponseHeader = new Header__2();
        vaultResponseHeader.setApplicationid("DGMA00123456");
        vaultResponseHeader.setUuid("ABC01a6d-7b07-473b-b1aa-72fe79d7c41f");
        vaultResponse.setHeader(vaultResponseHeader);
        Response__2 vaultResponseBody = new Response__2();
        vaultResponseBody.setRequestid("002000000000");
        vaultResponseBody.setResponsecode("W802");
        vaultResponseBody.setResponsetype("Decline");
        vaultResponseBody.setResponsedescription("DATABASE_ERROR");
        vaultResponseBody.setBankcardaccount(null);
        vaultResponseBody.setMilstaraccount(null);
        vaultResponse.setResponse(vaultResponseBody);
        vaultResponse.setRequest(null);
    }

    public void buildDummyResponseAdd(VaultAddCard enterpriseWalletVault) {
        Header header = new Header();
        header.setApplicationid("DGMA1");
        header.setUuid("ABC01a6d-7b07-473b-b1aa-72fe79d7c41f");
        header.setUserid("nilotpal@test");
        Response response = new Response();
        response.setResponsecode(null);
        response.setRequestid("nilotpal0001");
        response.setResponsedescription("INTERNAL_SERVER_ERROR");
        response.setResponsecode("W800");
        response.setResponsetype(WalletResponseType.DECLINED);
        response.setBankcardaccount(null);
        response.setMilstaraccount(null);
        enterpriseWalletVault.setResponse(response);
        enterpriseWalletVault.setHeader(header);
        enterpriseWalletVault.setRequest(null);
    }

    public void buildDummyResponseGet(VaultGetCard enterpriseWalletVault) {
        Header__2 header = new Header__2();
        header.setApplicationid("DGMA1");
        header.setUuid("ABC01a6d-7b07-473b-b1aa-72fe79d7c41f");
        header.setUserid("nilotpal@test");
        Response__2 response = new Response__2();
        response.setResponsecode(null);
        response.setRequestid("nilotpal0001");
        response.setResponsedescription("INTERNAL_SERVER_ERROR");
        response.setResponsecode("W800");
        response.setResponsetype(WalletResponseType.DECLINED);
        response.setBankcardaccount(null);
        response.setMilstaraccount(null);
        enterpriseWalletVault.setResponse(response);
        enterpriseWalletVault.setHeader(header);
        enterpriseWalletVault.setRequest(null);
    }

    public void buildDummyResponseUpdate(VaultUpdateCard enterpriseWalletVault) {
        Header__3 header = new Header__3();
        header.setApplicationid("DGMA1");
        header.setUuid("ABC01a6d-7b07-473b-b1aa-72fe79d7c41f");
        header.setUserid("nilotpal@test");
        Response__3 response = new Response__3();
        response.setResponsecode(null);
        response.setRequestid("nilotpal0001");
        response.setResponsedescription("INTERNAL_SERVER_ERROR");
        response.setResponsecode("W800");
        response.setResponsetype(WalletResponseType.DECLINED);
//        response.setBankcardaccount(null);
//        response.setMilstaraccount(null);
        enterpriseWalletVault.setResponse(response);
        enterpriseWalletVault.setHeader(header);
        enterpriseWalletVault.setRequest(null);
    }

    public void buildDummyResponseDelete(VaultDeleteCard enterpriseWalletVault) {
        Header__1 header = new Header__1();
        header.setApplicationid("DGMA1");
        header.setUuid("ABC01a6d-7b07-473b-b1aa-72fe79d7c41f");
        header.setUserid("nilotpal@test");
        Response__1 response = new Response__1();
        response.setResponsecode(null);
        response.setRequestid("nilotpal0001");
        response.setResponsedescription("INTERNAL_SERVER_ERROR");
        response.setResponsecode("W800");
        response.setResponsetype(WalletResponseType.DECLINED);
//        response.setBankcardaccount(null);
//        response.setMilstaraccount(null);
        enterpriseWalletVault.setResponse(response);
        enterpriseWalletVault.setHeader(header);
        enterpriseWalletVault.setRequest(null);
    }

    public void updateCardSuccessResponse(VaultUpdateCard enterpriseWalletVault) {
        Header__3 header = new Header__3();
        header.setApplicationid("DGMA1");
        header.setUuid("ABC01a6d-7b07-473b-b1aa-72fe79d7c41f");
        header.setUserid("nilotpal@test");
        Response__3 response = new Response__3();
        response.setRequestid("nilotpal0001");
        response.setResponsedescription("INTERNAL_SERVER_ERROR");
        response.setResponsecode("W800");
        response.setResponsetype(WalletResponseType.DECLINED);
//        response.setBankcardaccount(null);
//        response.setMilstaraccount(null);
        enterpriseWalletVault.setResponse(response);
        enterpriseWalletVault.setHeader(header);
        enterpriseWalletVault.setRequest(null);
    }

    public void deleteCardSuccessResponse(VaultDeleteCard enterpriseWalletVault) {
        Header__1 header = new Header__1();
        header.setApplicationid("DGMA1");
        header.setUuid("ABC01a6d-7b07-473b-b1aa-72fe79d7c41f");
        header.setUserid("nilotpal@test");
        Response__1 response = new Response__1();
        response.setRequestid("nilotpal0001");
        response.setResponsedescription("INTERNAL_SERVER_ERROR");
        response.setResponsecode("W800");
        response.setResponsetype(WalletResponseType.DECLINED);
//        response.setBankcardaccount(null);
//        response.setMilstaraccount(null);
        enterpriseWalletVault.setResponse(response);
        enterpriseWalletVault.setHeader(header);
        enterpriseWalletVault.setRequest(null);
    }


    public void buildDummyResponseOauthInvalid(VaultGetCard enterpriseWalletVault) {

        enterpriseWalletVault.setResponse(null);
        enterpriseWalletVault.setHeader(null);
        enterpriseWalletVault.setRequest(null);
        enterpriseWalletVault.setAdditionalProperty("error_description", "The access token provided is invalid.");
        enterpriseWalletVault.setAdditionalProperty("error", "invalid_token");
    }

    public void buildDummyResponseOauthInvalid(VaultAddCard enterpriseWalletVault) {

        enterpriseWalletVault.setResponse(null);
        enterpriseWalletVault.setHeader(null);
        enterpriseWalletVault.setRequest(null);
        enterpriseWalletVault.setAdditionalProperty("error_description", "The access token provided is invalid.");
        enterpriseWalletVault.setAdditionalProperty("error", "invalid_token");
    }

    public void buildDummyResponseOauthInvalid(VaultUpdateCard enterpriseWalletVault) {

        enterpriseWalletVault.setResponse(null);
        enterpriseWalletVault.setHeader(null);
        enterpriseWalletVault.setRequest(null);
        enterpriseWalletVault.setAdditionalProperty("error_description", "The access token provided is invalid.");
        enterpriseWalletVault.setAdditionalProperty("error", "invalid_token");
    }

    public void buildDummyResponseOauthInvalid(VaultDeleteCard enterpriseWalletVault) {

        enterpriseWalletVault.setResponse(null);
        enterpriseWalletVault.setHeader(null);
        enterpriseWalletVault.setRequest(null);
        enterpriseWalletVault.setAdditionalProperty("error_description", "The access token provided is invalid.");
        enterpriseWalletVault.setAdditionalProperty("error", "invalid_token");
    }



}
