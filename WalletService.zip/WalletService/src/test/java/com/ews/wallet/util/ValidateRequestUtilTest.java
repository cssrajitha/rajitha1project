package com.ews.wallet.util;

import com.ews.walletservice.generated.entity.*;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ValidateRequestUtilTest {
    private ValidateRequestUtil validateRequestUtil;

    @Before
    public void setUp() {
        validateRequestUtil = new ValidateRequestUtil();
        validateRequestUtil.setMaxRangeMilstarPlus("4999999999999999");
        validateRequestUtil.setMinRangeMilstarPlus("4000000000000000");
    }

    @Test
    public void testValidateRequestFields() {
        VaultAddCard enterpriseWalletVault = new VaultAddCard();
        addCardVaultRequest(enterpriseWalletVault);
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsAdd(enterpriseWalletVault);
            Assert.assertEquals("", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    //@Test
    public void testInvalidCid() {
        VaultAddCard enterpriseWalletVault = new VaultAddCard();
        addCardVaultRequest(enterpriseWalletVault);
        enterpriseWalletVault.getRequest().setCid("a566666");
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsAdd(enterpriseWalletVault);
            Assert.assertEquals("INVALID_CID", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

   // @Test
    public void testInvalidCid1() {
        VaultAddCard enterpriseWalletVault = new VaultAddCard();
        addCardVaultRequest(enterpriseWalletVault);
        enterpriseWalletVault.getRequest().setCid("566666");
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsAdd(enterpriseWalletVault);
            Assert.assertEquals("INVALID_CID", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

  //  @Test
    public void testInvalidCid2() {
        VaultAddCard enterpriseWalletVault = new VaultAddCard();
        addCardVaultRequest(enterpriseWalletVault);
        enterpriseWalletVault.getRequest().setCid("999999999990");
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsAdd(enterpriseWalletVault);
            Assert.assertEquals("INVALID_CID", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

  //  @Test
    public void testInvalidCid3() {
        VaultAddCard enterpriseWalletVault = new VaultAddCard();
        addCardVaultRequest(enterpriseWalletVault);
        enterpriseWalletVault.getRequest().setCid(null);
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsAdd(enterpriseWalletVault);
            Assert.assertEquals("INVALID_CID", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

   // @Test
    public void testInvalidCid4() {
        VaultAddCard enterpriseWalletVault = new VaultAddCard();
        addCardVaultRequest(enterpriseWalletVault);
        enterpriseWalletVault.getRequest().setCardtype(Request.Cardtype.MASTERCARD);
        enterpriseWalletVault.getRequest().setCid("a a");
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsAdd(enterpriseWalletVault);
            Assert.assertEquals("INVALID_CID", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testInvalidCid5() {
        VaultAddCard enterpriseWalletVault = new VaultAddCard();
        addCardVaultRequest(enterpriseWalletVault);
        enterpriseWalletVault.getRequest().setCardtype(Request.Cardtype.MASTERCARD);
        enterpriseWalletVault.getRequest().setCid(null);
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsAdd(enterpriseWalletVault);
            Assert.assertNotEquals("INVALID_CID", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testInvalidCid6() {
        VaultAddCard enterpriseWalletVault = new VaultAddCard();
        addCardVaultRequest(enterpriseWalletVault);
        enterpriseWalletVault.getRequest().setCardtype(Request.Cardtype.MASTERCARD);
        enterpriseWalletVault.getRequest().setCid("233");
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsAdd(enterpriseWalletVault);
            Assert.assertNotEquals("INVALID_CID", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testInvalidPan() {
        VaultAddCard enterpriseWalletVault = new VaultAddCard();
        addCardVaultRequest(enterpriseWalletVault);
        enterpriseWalletVault.getRequest().setPan("678575765675ss23");
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsAdd(enterpriseWalletVault);
            Assert.assertEquals("INVALID_PAN", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testInvalidCvv() {
        VaultAddCard enterpriseWalletVault = new VaultAddCard();
        addCardVaultRequest(enterpriseWalletVault);
        enterpriseWalletVault.getRequest().setCardsecuritycode("522a");
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsAdd(enterpriseWalletVault);
            Assert.assertEquals("INVALID_CVV", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testInvalidExpiry() {
        VaultAddCard enterpriseWalletVault = new VaultAddCard();
        addCardVaultRequest(enterpriseWalletVault);
        enterpriseWalletVault.getRequest().setExpirydate("23sa");
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsAdd(enterpriseWalletVault);
            Assert.assertEquals("INVALID_EXPIRYDATE", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testInvalidExpiry1() {
        VaultAddCard enterpriseWalletVault = new VaultAddCard();
        addCardVaultRequest(enterpriseWalletVault);
        enterpriseWalletVault.getRequest().setExpirydate("1006");
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsAdd(enterpriseWalletVault);
            Assert.assertEquals("INVALID_EXPIRYDATE", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testInvalidExpiry2() {
        VaultAddCard enterpriseWalletVault = new VaultAddCard();
        addCardVaultRequest(enterpriseWalletVault);
        enterpriseWalletVault.getRequest().setExpirydate("2106");
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsAdd(enterpriseWalletVault);
            Assert.assertEquals("INVALID_EXPIRYDATE", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testInvalidState() {
        VaultAddCard enterpriseWalletVault = new VaultAddCard();
        addCardVaultRequest(enterpriseWalletVault);
        enterpriseWalletVault.getRequest().setState(null);
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsAdd(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testInvalidState1() {
        VaultAddCard enterpriseWalletVault = new VaultAddCard();
        addCardVaultRequest(enterpriseWalletVault);
        enterpriseWalletVault.getRequest().setState("");
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsAdd(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testInvalidCountry() {
        VaultAddCard enterpriseWalletVault = new VaultAddCard();
        addCardVaultRequest(enterpriseWalletVault);
        enterpriseWalletVault.getRequest().setCountry(null);
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsAdd(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testInvalidCountry1() {
        VaultAddCard enterpriseWalletVault = new VaultAddCard();
        addCardVaultRequest(enterpriseWalletVault);
        enterpriseWalletVault.getRequest().setCountry("");
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsAdd(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testInvalidCountry2() {
        VaultAddCard enterpriseWalletVault = new VaultAddCard();
        addCardVaultRequest(enterpriseWalletVault);
        enterpriseWalletVault.getRequest().setCountry("india");
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsAdd(enterpriseWalletVault);
            Assert.assertNotEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testInvalidZipCode() {
        VaultAddCard enterpriseWalletVault = new VaultAddCard();
        addCardVaultRequest(enterpriseWalletVault);
        enterpriseWalletVault.getRequest().setZipcode(null);
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsAdd(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testInvalidZipCode1() {
        VaultAddCard enterpriseWalletVault = new VaultAddCard();
        addCardVaultRequest(enterpriseWalletVault);
        enterpriseWalletVault.getRequest().setZipcode("");
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsAdd(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testInvalidBillingAddress1() {
        VaultAddCard enterpriseWalletVault = new VaultAddCard();
        addCardVaultRequest(enterpriseWalletVault);
        enterpriseWalletVault.getRequest().setBillingaddress1(null);
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsAdd(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testInvalidBillingAddress11() {
        VaultAddCard enterpriseWalletVault = new VaultAddCard();
        addCardVaultRequest(enterpriseWalletVault);
        enterpriseWalletVault.getRequest().setBillingaddress1("");
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsAdd(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testInvalidCity() {
        VaultAddCard enterpriseWalletVault = new VaultAddCard();
        addCardVaultRequest(enterpriseWalletVault);
        enterpriseWalletVault.getRequest().setCity(null);
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsAdd(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testInvalidCity1() {
        VaultAddCard enterpriseWalletVault = new VaultAddCard();
        addCardVaultRequest(enterpriseWalletVault);
        enterpriseWalletVault.getRequest().setCity("");
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsAdd(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testUpdateCard() {
        VaultUpdateCard enterpriseWalletVault = new VaultUpdateCard();
        updateCardVaultRequest(enterpriseWalletVault);
        enterpriseWalletVault.getRequest().setCid(null);

        String response = "";
        try {
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testUpdateCardInvalidCid() {
        VaultUpdateCard enterpriseWalletVault = new VaultUpdateCard();
        updateCardVaultRequest(enterpriseWalletVault);
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testUpdateCardInvalidCvv() {
        VaultUpdateCard enterpriseWalletVault = new VaultUpdateCard();
        updateCardVaultRequest(enterpriseWalletVault);
        enterpriseWalletVault.getRequest().setCardsecuritycode(null);
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testUpdateCardInvalidCvv1() {
        VaultUpdateCard enterpriseWalletVault = new VaultUpdateCard();
        updateCardVaultRequest(enterpriseWalletVault);
        //enterpriseWalletVault.getRequest().setRequesttype(Request.Requesttype.UPDATECARD);
        enterpriseWalletVault.getRequest().setCardsecuritycode(null);
        enterpriseWalletVault.getRequest().setCardholdername(null);
        enterpriseWalletVault.getRequest().setExpirydate(null);
        enterpriseWalletVault.getRequest().setState(null);
        enterpriseWalletVault.getRequest().setCountry(null);
        enterpriseWalletVault.getRequest().setZipcode(null);
        enterpriseWalletVault.getRequest().setBillingaddress1(null);
        enterpriseWalletVault.getRequest().setBillingaddress2(null);
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testUpdateCardInvalidCvv2() {
        VaultUpdateCard enterpriseWalletVault = new VaultUpdateCard();
        updateCardVaultRequest(enterpriseWalletVault);
        //enterpriseWalletVault.getRequest().setRequesttype(Request.Requesttype.UPDATECARD);
        enterpriseWalletVault.getRequest().setCardsecuritycode(null);
        enterpriseWalletVault.getRequest().setCardholdername(null);
        enterpriseWalletVault.getRequest().setExpirydate(null);
        enterpriseWalletVault.getRequest().setState(null);
        enterpriseWalletVault.getRequest().setCountry(null);
        enterpriseWalletVault.getRequest().setZipcode(null);
        enterpriseWalletVault.getRequest().setBillingaddress1(null);
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testUpdateCardInvalidCvv3() {
        VaultUpdateCard enterpriseWalletVault = new VaultUpdateCard();
        updateCardVaultRequest(enterpriseWalletVault);
        //enterpriseWalletVault.getRequest().setRequesttype(Request.Requesttype.UPDATECARD);
        enterpriseWalletVault.getRequest().setCardsecuritycode(null);
        enterpriseWalletVault.getRequest().setCardholdername(null);
        enterpriseWalletVault.getRequest().setExpirydate(null);
        enterpriseWalletVault.getRequest().setState(null);
        enterpriseWalletVault.getRequest().setCountry(null);
        enterpriseWalletVault.getRequest().setZipcode(null);
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testUpdateCardInvalidCvv4() {
        VaultUpdateCard enterpriseWalletVault = new VaultUpdateCard();
        updateCardVaultRequest(enterpriseWalletVault);
        //enterpriseWalletVault.getRequest().setRequesttype(Request.Requesttype.UPDATECARD);
        enterpriseWalletVault.getRequest().setCardsecuritycode(null);
        enterpriseWalletVault.getRequest().setCardholdername(null);
        enterpriseWalletVault.getRequest().setExpirydate(null);
        enterpriseWalletVault.getRequest().setCountry(null);
        enterpriseWalletVault.getRequest().setZipcode(null);
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testUpdateCardInvalidCvv5() {
        VaultUpdateCard enterpriseWalletVault = new VaultUpdateCard();
        updateCardVaultRequest(enterpriseWalletVault);
        //enterpriseWalletVault.getRequest().setRequesttype(Request.Requesttype.UPDATECARD);
        enterpriseWalletVault.getRequest().setCardsecuritycode(null);
        enterpriseWalletVault.getRequest().setCardholdername(null);
        enterpriseWalletVault.getRequest().setExpirydate(null);
        enterpriseWalletVault.getRequest().setZipcode(null);
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testUpdateCardInvalidCvv6() {
        VaultUpdateCard enterpriseWalletVault = new VaultUpdateCard();
        updateCardVaultRequest(enterpriseWalletVault);
        //enterpriseWalletVault.getRequest().setRequesttype(Request.Requesttype.UPDATECARD);
        enterpriseWalletVault.getRequest().setCardsecuritycode(null);
        enterpriseWalletVault.getRequest().setCardholdername(null);
        enterpriseWalletVault.getRequest().setExpirydate(null);
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testUpdateCardInvalidCvv7() {
        VaultUpdateCard enterpriseWalletVault = new VaultUpdateCard();
        updateCardVaultRequest(enterpriseWalletVault);
        //enterpriseWalletVault.getRequest().setRequesttype(Request.Requesttype.UPDATECARD);
        enterpriseWalletVault.getRequest().setCardsecuritycode(null);
        enterpriseWalletVault.getRequest().setCardholdername(null);
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testUpdateCardInvalidCvv8() {
        VaultUpdateCard enterpriseWalletVault = new VaultUpdateCard();
        updateCardVaultRequest(enterpriseWalletVault);
        //enterpriseWalletVault.getRequest().setRequesttype(Request.Requesttype.UPDATECARD);
        enterpriseWalletVault.getRequest().setCardsecuritycode(null);
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testUpdateCardInvalidCvv9() {
        VaultUpdateCard enterpriseWalletVault = new VaultUpdateCard();
        updateCardVaultRequest(enterpriseWalletVault);
        //enterpriseWalletVault.getRequest().setRequesttype(Request.Requesttype.UPDATECARD);
        enterpriseWalletVault.getRequest().setCardsecuritycode("777");
        enterpriseWalletVault.getRequest().setCardholdername(null);
        enterpriseWalletVault.getRequest().setExpirydate(null);
        enterpriseWalletVault.getRequest().setState(null);
        enterpriseWalletVault.getRequest().setCountry(null);
        enterpriseWalletVault.getRequest().setZipcode(null);
        enterpriseWalletVault.getRequest().setBillingaddress1(null);
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testUpdateCardInvalidCvv10() {
        VaultUpdateCard enterpriseWalletVault = new VaultUpdateCard();
        updateCardVaultRequest(enterpriseWalletVault);
        //enterpriseWalletVault.getRequest().setRequesttype(Request.Requesttype.UPDATECARD);
        enterpriseWalletVault.getRequest().setCardsecuritycode("777");
        enterpriseWalletVault.getRequest().setCardholdername(null);
        enterpriseWalletVault.getRequest().setExpirydate(null);
        enterpriseWalletVault.getRequest().setState(null);
        enterpriseWalletVault.getRequest().setCountry(null);
        enterpriseWalletVault.getRequest().setZipcode(null);
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testUpdateCardInvalidCvv11() {
        VaultUpdateCard enterpriseWalletVault = new VaultUpdateCard();
        updateCardVaultRequest(enterpriseWalletVault);
        //enterpriseWalletVault.getRequest().setRequesttype(Request.Requesttype.UPDATECARD);
        enterpriseWalletVault.getRequest().setCardsecuritycode("777");
        enterpriseWalletVault.getRequest().setCardholdername(null);
        enterpriseWalletVault.getRequest().setExpirydate(null);
        enterpriseWalletVault.getRequest().setCountry(null);
        enterpriseWalletVault.getRequest().setZipcode(null);
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testUpdateCardInvalidCvv12() {
        VaultUpdateCard enterpriseWalletVault = new VaultUpdateCard();
        updateCardVaultRequest(enterpriseWalletVault);
        //enterpriseWalletVault.getRequest().setRequesttype(Request.Requesttype.UPDATECARD);
        enterpriseWalletVault.getRequest().setCardsecuritycode("777");
        enterpriseWalletVault.getRequest().setCardholdername(null);
        enterpriseWalletVault.getRequest().setExpirydate(null);
        enterpriseWalletVault.getRequest().setZipcode(null);
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testUpdateCardInvalidCvv13() {
        VaultUpdateCard enterpriseWalletVault = new VaultUpdateCard();
        updateCardVaultRequest(enterpriseWalletVault);
        //enterpriseWalletVault.getRequest().setRequesttype(Request.Requesttype.UPDATECARD);
        enterpriseWalletVault.getRequest().setCardsecuritycode("777");
        enterpriseWalletVault.getRequest().setCardholdername(null);
        enterpriseWalletVault.getRequest().setExpirydate(null);
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testUpdateCardInvalidCvv14() {
        VaultUpdateCard enterpriseWalletVault = new VaultUpdateCard();
        updateCardVaultRequest(enterpriseWalletVault);
        //enterpriseWalletVault.getRequest().setRequesttype(Request.Requesttype.UPDATECARD);
        enterpriseWalletVault.getRequest().setCardsecuritycode("777");
        enterpriseWalletVault.getRequest().setCardholdername(null);
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testUpdateCardInvalidCvv15() {
        VaultUpdateCard enterpriseWalletVault = new VaultUpdateCard();
        updateCardVaultRequest(enterpriseWalletVault);
        //enterpriseWalletVault.getRequest().setRequesttype(Request.Requesttype.UPDATECARD);
        enterpriseWalletVault.getRequest().setCardsecuritycode("777");
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testUpdateCardInvalidAddress() {
        VaultUpdateCard enterpriseWalletVault = new VaultUpdateCard();
        updateCardVaultRequest(enterpriseWalletVault);
        //enterpriseWalletVault.getRequest().setRequesttype(Request.Requesttype.UPDATECARD);
        enterpriseWalletVault.getRequest().setCardsecuritycode("777");
        enterpriseWalletVault.getRequest().setCardholdername("");
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testUpdateCardInvalidAddress1() {
        VaultUpdateCard enterpriseWalletVault = new VaultUpdateCard();
        updateCardVaultRequest(enterpriseWalletVault);
        //enterpriseWalletVault.getRequest().setRequesttype(Request.Requesttype.UPDATECARD);
        enterpriseWalletVault.getRequest().setCardsecuritycode("777");
        enterpriseWalletVault.getRequest().setExpirydate("");
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testUpdateCardInvalidAddress2() {
        VaultUpdateCard enterpriseWalletVault = new VaultUpdateCard();
        updateCardVaultRequest(enterpriseWalletVault);
        //enterpriseWalletVault.getRequest().setRequesttype(Request.Requesttype.UPDATECARD);
        enterpriseWalletVault.getRequest().setCardsecuritycode("777");
        enterpriseWalletVault.getRequest().setState("");
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testUpdateCardInvalidAddress3() {
        VaultUpdateCard enterpriseWalletVault = new VaultUpdateCard();
        updateCardVaultRequest(enterpriseWalletVault);
        //enterpriseWalletVault.getRequest().setRequesttype(Request.Requesttype.UPDATECARD);
        enterpriseWalletVault.getRequest().setCardsecuritycode("777");
        enterpriseWalletVault.getRequest().setCountry("");
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testUpdateCardInvalidAddress4() {
        VaultUpdateCard enterpriseWalletVault = new VaultUpdateCard();
        updateCardVaultRequest(enterpriseWalletVault);
        //enterpriseWalletVault.getRequest().setRequesttype(Request.Requesttype.UPDATECARD);
        enterpriseWalletVault.getRequest().setCardsecuritycode("777");
        enterpriseWalletVault.getRequest().setZipcode("");
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testUpdateCardInvalidAddress5() {
        VaultUpdateCard enterpriseWalletVault = new VaultUpdateCard();
        updateCardVaultRequest(enterpriseWalletVault);
        //enterpriseWalletVault.getRequest().setRequesttype(Request.Requesttype.UPDATECARD);
        enterpriseWalletVault.getRequest().setCardsecuritycode("777");
        enterpriseWalletVault.getRequest().setBillingaddress1("");
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testUpdateCardInvalidAddress6() {
        VaultUpdateCard enterpriseWalletVault = new VaultUpdateCard();
        updateCardVaultRequest(enterpriseWalletVault);
        //enterpriseWalletVault.getRequest().setRequesttype(Request.Requesttype.UPDATECARD);
        enterpriseWalletVault.getRequest().setCardsecuritycode("777");
        enterpriseWalletVault.getRequest().setCity("");
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testUpdateCardInvalidAddress7() {
        VaultUpdateCard enterpriseWalletVault = new VaultUpdateCard();
        updateCardVaultRequest(enterpriseWalletVault);
        //enterpriseWalletVault.getRequest().setRequesttype(Request.Requesttype.UPDATECARD);
        enterpriseWalletVault.getRequest().setCountry("india");
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testUpdateCardInvalidAddress8() {
        VaultUpdateCard enterpriseWalletVault = new VaultUpdateCard();
        updateCardVaultRequest(enterpriseWalletVault);
        //enterpriseWalletVault.getRequest().setRequesttype(Request.Requesttype.UPDATECARD);
        enterpriseWalletVault.getRequest().setCountry("india");
        //enterpriseWalletVault.getRequest().setPan(null);
        enterpriseWalletVault.getRequest().setCardsecuritycode("");
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }


    @Test
    public void testAddCardCardholderNameValidate() {
        VaultAddCard enterpriseWalletVault = new VaultAddCard();
        addCardVaultRequest(enterpriseWalletVault);
        enterpriseWalletVault.getRequest().setCardholderlastname(null);
        enterpriseWalletVault.getRequest().setCardholdername(null);
        String response = "";
        try {
            response = validateRequestUtil.validateFieldsAdd(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testUpdateCardCVVValidation() {
        VaultUpdateCard enterpriseWalletVault = new VaultUpdateCard();
        updateCardVaultRequest(enterpriseWalletVault);

        String response = "";
        try {
            enterpriseWalletVault.getRequest().setCardsecuritycode("abc");
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_CVV", response);

            enterpriseWalletVault.getRequest().setCountry("us");
            enterpriseWalletVault.getRequest().setZipcode("455-556");
            enterpriseWalletVault.getRequest().setCardsecuritycode("");
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);

            enterpriseWalletVault.getRequest().setCountry("");
            enterpriseWalletVault.getRequest().setBillingaddress1("");
            enterpriseWalletVault.getRequest().setCity("");
            enterpriseWalletVault.getRequest().setPreferredcard("");
            enterpriseWalletVault.getRequest().setPreferredcard("");
           // enterpriseWalletVault.getRequest().setCardholderLastName("");
            enterpriseWalletVault.getRequest().setCardholdername("");

            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_REQUEST", response);


        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testUpdateCardExpDateValidation() {
        VaultUpdateCard enterpriseWalletVault = new VaultUpdateCard();
        updateCardVaultRequest(enterpriseWalletVault);

        String response = "";
        try {
            enterpriseWalletVault.getRequest().setExpirydate("2402");
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_EXPIRYDATE", response);

            enterpriseWalletVault.getRequest().setExpirydate("2501");
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_EXPIRYDATE", response);

            enterpriseWalletVault.getRequest().setExpirydate("abc");
            response = validateRequestUtil.validateFieldsUpdate(enterpriseWalletVault);
            Assert.assertEquals("INVALID_EXPIRYDATE", response);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testAddCardExpDateValidation() {
        VaultAddCard enterpriseWalletVault = new VaultAddCard();
        addCardVaultRequest(enterpriseWalletVault);

        String response = "";
        try {
            enterpriseWalletVault.getRequest().setExpirydate("2402");
            response = validateRequestUtil.validateFieldsAdd(enterpriseWalletVault);
            Assert.assertEquals("INVALID_EXPIRYDATE", response);

            enterpriseWalletVault.getRequest().setExpirydate("2501");
            response = validateRequestUtil.validateFieldsAdd(enterpriseWalletVault);
            Assert.assertEquals("INVALID_EXPIRYDATE", response);

            enterpriseWalletVault.getRequest().setExpirydate("abc");
            response = validateRequestUtil.validateFieldsAdd(enterpriseWalletVault);
            Assert.assertEquals("INVALID_EXPIRYDATE", response);

            enterpriseWalletVault.getRequest().setPan("abc");
            response = validateRequestUtil.validateFieldsAdd(enterpriseWalletVault);
            Assert.assertEquals("INVALID_PAN", response);

            enterpriseWalletVault.getRequest().setPan("5000000000000001");
            enterpriseWalletVault.getRequest().setExpirydate("2610");
            response = validateRequestUtil.validateFieldsAdd(enterpriseWalletVault);
            //Assert.assertEquals("INVALID_PAN", response);

            enterpriseWalletVault.getRequest().setCardtype(Request.Cardtype.DISCOVER);
            enterpriseWalletVault.getRequest().setExpirydate("2610");
            response = validateRequestUtil.validateFieldsAdd(enterpriseWalletVault);
           // Assert.assertEquals("INVALID_PAN", response);


        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }
    private void addCardVaultRequest(VaultAddCard vaultRequest) {
        Header vaultRequestHeader = new Header();
        Request vaultRequestBody = new Request();
        vaultRequestHeader.setApplicationid("DGMA1");
        vaultRequestHeader.setUuid("ABC01a6d-7b07-473b-b1aa-72fe79d7c41f");
        vaultRequestHeader.setUserid("nilotpal@test");
        vaultRequest.setHeader(vaultRequestHeader);
        vaultRequestBody.setCid("11122233342");
        vaultRequestBody.setCrmid("999");
        vaultRequestBody.setRequesttype(Request.Requesttype.ADDCARD);
        vaultRequestBody.setRequestid("nilotpal0001");
        vaultRequestBody.setPan("2222420000001113");
        vaultRequestBody.setCardholdername("John Doe");
        vaultRequestBody.setNickname("jd");
        vaultRequestBody.setExpirydate("2512");
        vaultRequestBody.setCardtype(Request.Cardtype.MILSTAR);
        vaultRequestBody.setPreferredcard("Y");
        vaultRequestBody.setCardsecuritycode("677");
        vaultRequestBody.setState("sample state");
        vaultRequestBody.setCountry("us");
        vaultRequestBody.setZipcode("455-556");
        vaultRequestBody.setBillingaddress1("sample ad1");
        vaultRequestBody.setBillingaddress2("sample ad2");
        vaultRequestBody.setCity("testcity");
        vaultRequest.setRequest(vaultRequestBody);
    }

    private void updateCardVaultRequest(VaultUpdateCard vaultRequest) {
        Header__3 vaultRequestHeader = new Header__3();
        Request__3 vaultRequestBody = new Request__3();
        vaultRequestHeader.setApplicationid("DGMA1");
        vaultRequestHeader.setUuid("ABC01a6d-7b07-473b-b1aa-72fe79d7c41f");
        vaultRequestHeader.setUserid("nilotpal@test");
        vaultRequest.setHeader(vaultRequestHeader);
        vaultRequestBody.setCid("11122233342");
        //vaultRequestBody.setCrmid("999");
        vaultRequestBody.setRequesttype(Request__3.Requesttype.UPDATECARD);
        vaultRequestBody.setRequestid("nilotpal0001");
       // vaultRequestBody.setPan("2222420000001113");
        vaultRequestBody.setCardholdername("John Doe");
        vaultRequestBody.setNickname("jd");
        vaultRequestBody.setExpirydate("2512");
        vaultRequestBody.setCardtype(Request__3.Cardtype.MILSTAR);
        vaultRequestBody.setPreferredcard("Y");
        vaultRequestBody.setCardsecuritycode("677");
        vaultRequestBody.setState("sample state");
        vaultRequestBody.setCountry("us");
        vaultRequestBody.setZipcode("455-556");
        vaultRequestBody.setBillingaddress1("sample ad1");
        vaultRequestBody.setBillingaddress2("sample ad2");
        vaultRequestBody.setCity("testcity");
        vaultRequest.setRequest(vaultRequestBody);
    }
}
