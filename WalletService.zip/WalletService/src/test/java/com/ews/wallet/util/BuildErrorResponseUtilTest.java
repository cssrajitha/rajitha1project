package com.ews.wallet.util;

import com.ews.wallet.entity.WalletResponseType;
import com.ews.walletservice.generated.entity.*;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.core.env.Environment;

public class BuildErrorResponseUtilTest {
    private Environment env;
    private BuildErrorResponseUtil buildErrorResponseUtil;

    @Before
    public void setUp() {
        env = Mockito.mock(Environment.class);
        buildErrorResponseUtil = new BuildErrorResponseUtil();
        buildErrorResponseUtil.setEnv(env);
    }

    @Test
    public void testBuildResponseAdd() {
        VaultAddCard enterpriseWalletVault = new VaultAddCard();
        VaultAddCard response = new VaultAddCard();
        buildResponseAdd(response);
        try {
            enterpriseWalletVault = buildErrorResponseUtil.buildErrorResponseAdd(enterpriseWalletVault, "f", "e", "a", "b", "c");
            Assert.assertEquals(response, enterpriseWalletVault);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testBuildTimeoutResponseAdd() {
        VaultAddCard enterpriseWalletVault = new VaultAddCard();
        VaultAddCard response = new VaultAddCard();
        buildResponseAdd(response);
        response.getResponse().setResponsetype(WalletResponseType.TIMEOUT);
        try {
            enterpriseWalletVault = buildErrorResponseUtil.buildTimeoutResponse(enterpriseWalletVault, "f", "e", "a", "b", "c");
            Assert.assertEquals(response, enterpriseWalletVault);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testBuildResponseGet() {
        VaultGetCard enterpriseWalletVault = new VaultGetCard();
        VaultGetCard response = new VaultGetCard();
        buildResponseGet(response);
        try {
            enterpriseWalletVault = buildErrorResponseUtil.buildErrorResponseGet(enterpriseWalletVault, "f", "e", "a", "b", "c");
            Assert.assertEquals(response, enterpriseWalletVault);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testBuildTimeoutResponseGet() {
        VaultGetCard enterpriseWalletVault = new VaultGetCard();
        VaultGetCard response = new VaultGetCard();
        buildResponseGet(response);
        response.getResponse().setResponsetype(WalletResponseType.TIMEOUT);
        try {
            enterpriseWalletVault = buildErrorResponseUtil.buildTimeoutResponse(enterpriseWalletVault, "f", "e", "a", "b", "c");
            Assert.assertEquals(response, enterpriseWalletVault);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testBuildResponseUpdate() {
        VaultUpdateCard enterpriseWalletVault = new VaultUpdateCard();
        VaultUpdateCard response = new VaultUpdateCard();
        buildResponseUpdate(response);
        try {
            enterpriseWalletVault = buildErrorResponseUtil.buildErrorResponseUpdate(enterpriseWalletVault, "f", "e", "a", "b", "c");
            Assert.assertEquals(response, enterpriseWalletVault);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testBuildTimeoutResponseUpdate() {
        VaultUpdateCard enterpriseWalletVault = new VaultUpdateCard();
        VaultUpdateCard response = new VaultUpdateCard();
        buildResponseUpdate(response);
        response.getResponse().setResponsetype(WalletResponseType.TIMEOUT);
        try {
            enterpriseWalletVault = buildErrorResponseUtil.buildTimeoutResponse(enterpriseWalletVault, "f", "e", "a", "b", "c");
            Assert.assertEquals(response, enterpriseWalletVault);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testBuildResponseDelete() {
        VaultDeleteCard enterpriseWalletVault = new VaultDeleteCard();
        VaultDeleteCard response = new VaultDeleteCard();
        buildResponseDelete(response);
        try {
            enterpriseWalletVault = buildErrorResponseUtil.buildErrorResponseDelete(enterpriseWalletVault, "f", "e", "a", "b", "c");
            Assert.assertEquals(response, enterpriseWalletVault);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    @Test
    public void testBuildTimeoutResponseDelete() {
        VaultDeleteCard enterpriseWalletVault = new VaultDeleteCard();
        VaultDeleteCard response = new VaultDeleteCard();
        buildResponseDelete(response);
        response.getResponse().setResponsetype(WalletResponseType.TIMEOUT);
        try {
            enterpriseWalletVault = buildErrorResponseUtil.buildTimeoutResponse(enterpriseWalletVault, "f", "e", "a", "b", "c");
            Assert.assertEquals(response, enterpriseWalletVault);
        } catch (Exception e) {
            System.out.println("Exception occurred : " + e);
        }
    }

    public void buildResponseAdd(VaultAddCard enterpriseWalletVault){
        Header header = new Header();
        header.setApplicationid("a");
        header.setUuid("b");
        header.setUserid("c");
        Response response = new Response();
        response.setResponsecode(null);
        response.setRequestid("e");
        response.setResponsedescription("f");
        response.setResponsetype(WalletResponseType.DECLINED);
        response.setBankcardaccount(null);
        response.setMilstaraccount(null);
        enterpriseWalletVault.setResponse(response);
        enterpriseWalletVault.setHeader(header);
        enterpriseWalletVault.setRequest(null);
    }

    public void buildResponseDelete(VaultDeleteCard enterpriseWalletVault){
        Header__1 header = new Header__1();
        header.setApplicationid("a");
        header.setUuid("b");
        header.setUserid("c");
        Response__1 response = new Response__1();
        response.setResponsecode(null);
        response.setRequestid("e");
        response.setResponsedescription("f");
        response.setResponsetype(WalletResponseType.DECLINED);
        enterpriseWalletVault.setResponse(response);
        enterpriseWalletVault.setHeader(header);
        enterpriseWalletVault.setRequest(null);
    }

    public void buildResponseGet(VaultGetCard enterpriseWalletVault){
        Header__2 header = new Header__2();
        header.setApplicationid("a");
        header.setUuid("b");
        header.setUserid("c");
        Response__2 response = new Response__2();
        response.setResponsecode(null);
        response.setRequestid("e");
        response.setResponsedescription("f");
        response.setResponsetype(WalletResponseType.DECLINED);
        response.setBankcardaccount(null);
        response.setMilstaraccount(null);
        enterpriseWalletVault.setResponse(response);
        enterpriseWalletVault.setHeader(header);
        enterpriseWalletVault.setRequest(null);
    }
    public void buildResponseUpdate(VaultUpdateCard enterpriseWalletVault){
        Header__3 header = new Header__3();
        header.setApplicationid("a");
        header.setUuid("b");
        header.setUserid("c");
        Response__3 response = new Response__3();
        response.setResponsecode(null);
        response.setRequestid("e");
        response.setResponsedescription("f");
        response.setResponsetype(WalletResponseType.DECLINED);
        enterpriseWalletVault.setResponse(response);
        enterpriseWalletVault.setHeader(header);
        enterpriseWalletVault.setRequest(null);
    }

}
