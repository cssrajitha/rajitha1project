#!/bin/sh

devName=$(git config --global user.name)
devEmail=$(git config --global user.email)
gitUserCheckPassed=default
ex="$(date) ### Exception"

if [[ -z "$devName" || -z "$devEmail" ]]; then
    echo "$ex - Your GIT user name and user email details are not updated. Please execute below steps to update...\n\n\tgit config --global user.name \"firstname lastname\"\n\tgit config --global user.email \"xxxxx.xxxx@one.verizon.com\"\n\nPlease replace \"firstname lastname\" with your actual names\nPlease replace \"xxxxx.xxxx@one.verizon.com\" with your actual verizon email address.\n\n"
    gitUserCheckPassed=false
fi

if [[ $gitUserCheckPassed == false ]]; then
 echo "$ex - Failed!"
 git config core.gitusercheckstatus FAIL
 echo "FAIL" >> hooks/GIT_USER_CHECK_STATUS.txt 
 exit 1
 else
 echo "$(date) - Success!"
 git config core.gitusercheckstatus PASS
 echo "PASS" >> hooks/GIT_USER_CHECK_STATUS.txt
fi