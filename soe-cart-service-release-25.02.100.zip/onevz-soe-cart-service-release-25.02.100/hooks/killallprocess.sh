#!/bin/sh

if [[ "$ostype" != "msys" ]]; then
    ps -A | grep *hooks* | awk '{print $1}' | xargs kill -9 $1
# else
#     # TODO: Windows compatible command to be found out
fi