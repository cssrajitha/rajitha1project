@echo off
SETLOCAL EnableDelayedExpansion
SET /A BuildId=%RANDOM% * 100000 / 32768 + 1
SET "BuildId=!BuildId:-=!"
set SCA_SCAN=sourceanalyzer -b %BuildId% -autoheap 
SET currentpath="echo %cd%"
set FilesToBeAnalyzed=

echo Generate temp folder to move all the files staged and to be analyzed
if not exist "temp" mkdir temp
if not exist "FortifyReport" mkdir FortifyReport

echo Checks whether fortify is installed
sourceanalyzer -clean || set "checkFortify=false"
if "%checkFortify%"=="false" (
  echo FAIL > temp\\SCA_STATUS.txt
) else (
  call :initAnalyze
)
EXIT /B 0

:initAnalyze
FOR /F "tokens=*" %%f IN ('git diff --name-only --cached') DO (
  set backwardSlashFilename=%%f
  set "backwardSlashFilename=!backwardSlashFilename:/=\\!"
  set FilesToBeAnalyzed=!FilesToBeAnalyzed! !backwardSlashFilename!
)
%commandtoexecute%

set SCA_SCAN=!SCA_SCAN! !FilesToBeAnalyzed!
echo Initiating Fortify Static Code Analyzer ..................
echo ==============================================================
echo %SCA_SCAN%
%SCA_SCAN%

echo Generating FPR file.............
set SCA_FPR=sourceanalyzer -b %BuildId% -autoheap -scan -f FortifyReport/%BuildId%.fpr
echo %SCA_FPR%
%SCA_FPR%

powershell -executionpolicy remotesigned -File hooks/analyzer/analyzer.ps1 %BuildId%

FOR /F "tokens=* delims=" %%f IN (temp\\SCA_STATUS.txt) DO (
  set "val=%%f"
)
if "%val%"=="FAIL" (
  if exist "temp" rmdir /s /q temp
  if exist "FortifyReport" rmdir /s /q FortifyReport
  exit
)

echo Fortify SCA is complete.....

EXIT /B %ERRORLEVEL%

