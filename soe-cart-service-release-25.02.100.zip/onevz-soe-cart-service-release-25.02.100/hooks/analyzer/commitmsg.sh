FortifyStatus="$(eval git config core.fortifystatus)"
dlpStatus="$(eval git config core.dlpstatus)"
coverageStatus="$(eval git config core.coveragestatus)"
docStatus="$(eval git config core.docstatus)"
sizeStatus="$(eval git config core.sizestatus)"
gitUserCheckStatus="$(eval git config core.gitusercheckstatus)"
if [[ "$FortifyStatus" == "PASS" ]]; then
  sca="[SCA]"
fi
if [[ "$dlpStatus" == "PASS" ]]; then
  dlp="[DLP]"
fi
if [[ "$coverageStatus" == "PASS" ]]; then
  test="[TEST]"
fi
if [[ "$docStatus" == "PASS" ]]; then
  doc="[DOC]"
fi
if [[ "$sizeStatus" == "PASS" ]]; then
  size="[LL]"
fi
if [[ "$gitUserCheckStatus" == "PASS" ]]; then
  gitc="[GIT]"
fi
val="$(eval cat .git/COMMIT_EDITMSG)";
echo $val" [PASS]$sca$dlp$test$doc$size$gitc" > .git/COMMIT_EDITMSG
git config --unset core.fortifystatus
git config --unset core.dlpstatus
git config --unset core.coveragestatus
git config --unset core.docstatus
git config --unset core.sizestatus
git config --unset core.gitusercheckstatus