$BuildId = $args[0]
Write-Output "Generating XML Report from FPR file........"
Write-Output "ReportGenerator $BuildId -format xml -f FortifyReport/$BuildId.xml -source FortifyReport/$BuildId.fpr"
ReportGenerator $BuildId -format xml -f FortifyReport/$BuildId.xml -source FortifyReport/$BuildId.fpr
$result = Select-Xml FortifyReport/$BuildId.xml -XPath "//Issue" | Select-Object -ExpandProperty "node"
if ($result.Friority) {
    Write-Output "Priority: $($result.Friority)"
    Write-Output "Description: $($result.Abstract)"
    Write-Output "Category: $($result.Category)"
    Write-Output $result.primary
    New-Item temp\SCA_STATUS.txt
    Set-Content temp\SCA_STATUS.txt "FAIL"
    throw "Fortify Analysis reports errors. Please resolve above errors."
    exit
} else {
    New-Item temp\SCA_STATUS.txt
    Set-Content temp\SCA_STATUS.txt "PASS"
    Write-Output "Fortify Analysis is successful."
}
