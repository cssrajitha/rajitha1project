@echo off
FOR /F "tokens=* delims=" %%a IN (temp\\SCA_STATUS.txt) DO (
  set "status=%%a"
)
if "%status%" == "PASS" (
  FOR /F "tokens=*" %%b IN (.git\\COMMIT_EDITMSG) DO (
    echo %%b [PASS][SCA] > .git\\COMMIT_EDITMSG
  )
)