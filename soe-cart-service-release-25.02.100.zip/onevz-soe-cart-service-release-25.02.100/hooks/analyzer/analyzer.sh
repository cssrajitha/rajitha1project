currentpath="$(eval pwd)"
randomBuildId="$((1000 + RANDOM % 9999))"
if [[ "$OSTYPE" == "darwin"* ]]; then
  fortifyPath="$(eval find /Applications/Fortify -type d -name \"Fortify_*\")"
  if [[ ! -z "$fortifyPath" ]]; then
    export PATH=$PATH:$fortifyPath/bin
  fi
fi
gitcommand="git diff --name-only --cached"
FilesToBeMoved=$(eval $gitcommand)
printf "\nChecks whether fortify is installed\n"
sourceanalyzer -clean || analyzerCheck="false"

initAnalyze() {
  if [[ ! -d "FortifyReport" ]]; then
    mkdir FortifyReport
  fi
  analyzer="sourceanalyzer -b $randomBuildId -autoheap $FilesToBeMoved -exclude $currentpath/src/test"
  printf "\nInitiating Fortify Static Code Analyzer .................. \n"
  printf "\n============================================================== \n"
  echo $analyzer
  $analyzer
  printf "\nGenerating FPR file.............\n"
  generateFPR="sourceanalyzer -b $randomBuildId -autoheap -scan -f FortifyReport/$randomBuildId.fpr"
  echo $generateFPR
  $generateFPR
  printf "\nGenerating XML Report from FPR file........\n"
  generateXML="ReportGenerator $randomBuildId -format xml -f FortifyReport/$randomBuildId.xml -source FortifyReport/$randomBuildId.fpr"
  echo $generateXML
  $generateXML
  cleanBuild="sourceanalyzer -b $randomBuildId -clean"
  echo $cleanBuild
  $cleanBuild
  ## fortifyErrorCheck.js
  ## Opens XML report
  ## Converts XML into JSON format
  ## Looks for fortify errors in the JSON variable
  ## Throw error and break the hook if errors are identifiednode soe-digital/scripts/fortifyErrorCheck.js $randomBuildId
  ## node soe-digital/scripts/fortifyErrorCheck.js $randomBuildId
  Priority="$(xmllint FortifyReport/$randomBuildId.xml --xpath 'string(/ReportDefinition/ReportSection/SubSection/IssueListing/Chart/GroupingSection/Issue/Friority)')"
  if [[ ! -z "$Priority" ]]; then
    Category="$(xmllint FortifyReport/$randomBuildId.xml --xpath 'string(/ReportDefinition/ReportSection/SubSection/IssueListing/Chart/GroupingSection/Issue/Category)')"
    Abstract="$(xmllint FortifyReport/$randomBuildId.xml --xpath 'string(/ReportDefinition/ReportSection/SubSection/IssueListing/Chart/GroupingSection/Issue/Abstract)')"
    FileName="$(xmllint FortifyReport/$randomBuildId.xml --xpath 'string(/ReportDefinition/ReportSection/SubSection/IssueListing/Chart/GroupingSection/Issue/Primary/FileName)')"
    LineStart="$(xmllint FortifyReport/$randomBuildId.xml --xpath 'string(/ReportDefinition/ReportSection/SubSection/IssueListing/Chart/GroupingSection/Issue/Primary/LineStart)')"
    Snippet="$(xmllint FortifyReport/$randomBuildId.xml --xpath 'string(/ReportDefinition/ReportSection/SubSection/IssueListing/Chart/GroupingSection/Issue/Primary/Snippet)')"
    ErrorMessage="\nFortify analysis reports errors. Please resolve below errors. \n\n"
    ErrorMessage=$ErrorMessage"Priority: \t$Priority\n"
    ErrorMessage=$ErrorMessage"Category: \t$Category\n"
    ErrorMessage=$ErrorMessage"Description: \t$Abstract\n"
    ErrorMessage=$ErrorMessage"FileName: \t$FileName\n"
    ErrorMessage=$ErrorMessage"Line Start: \t$LineStart\n"
    ErrorMessage=$ErrorMessage"Code Snippet: \t$Snippet\n"
    echo "$ErrorMessage"
  fi
  if [[ ! -z "$ErrorMessage" ]]; then
    git config core.fortifystatus FAIL
    echo "FAIL" > temp/SCA_STATUS.txt
    rm -rf FortifyReport
    exit 1
  fi
  rm -rf FortifyReport
  git config core.fortifystatus PASS
  echo "PASS" > temp/SCA_STATUS.txt
}

if [[ "$analyzerCheck" == "false" ]]; then
  printf "\nIgnores fortify scan\n"
  git config core.fortifystatus FAIL
  echo "FAIL" > temp/SCA_STATUS.txt
else
  initAnalyze
fi

