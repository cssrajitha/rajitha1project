#!/bin/bash

Color_Off='\033[0m' 
BRed="\033[1;31m"         # Red
BGreen="\033[1;32m"       # Green
BYellow="\033[1;33m"      # Yellow
BBlue="\033[1;34m"        # Blue

documentationThreshold=60
ex="$(date) ### Exception"

#Documentation analysis code
stagedFilesCombined=$(IFS=  ; echo "${files[*]}")
#printf "${BGreen}Running documentation analysis for these files: ${Color_Off}"
echo -e "Running documentation analysis for these files: \n"
echo -e $stagedFilesCombined
java -jar ./Utils/documentationAnalyzer.jar "$rootPath" ${files[@]}
result=$?
mvnOutput=''
if [[ "$result" -eq "200" ]]; then
	#printf "${BGreen}No eligible files found for documentation scan.${Color_Off}"
	echo -e "No eligible files found for documentation scan.\n"
	echo "PASS" >> hooks/DOC_STATUS.txt
	git config core.docstatus PASS
	exit 1
elif  [[ "$result" -lt "$documentationThreshold" ]]; then
	printf "${BRed}Documentation thresholds is $documentationThreshold%. Please update the documentation to continue with the commit. ${Color_Off}\n"
	echo -e "$ex Documentation thresholds is $documentationThreshold%. Please update the documentation to continue with the commit. \n"
	git config core.docstatus FAIL
	echo "FAIL" >> hooks/DOC_STATUS.txt
	exit 1
else
	#printf "${BGreen}Documentation covered percentage is: $result%%.${Color_Off}\n"
	echo -e "Documentation covered percentage is: $result%%. \n "
	git config core.docstatus PASS
	echo "PASS" >> hooks/DOC_STATUS.txt
fi
#echo -e "#------------------------------------------------------------------------#\n"  >> hooks/coverage.log