#!/bin/sh

Color_Off='\033[0m' 
BRed="\033[1;31m"         # Red
BGreen="\033[1;32m"       # Green
BYellow="\033[1;33m"      # Yellow
BBlue="\033[1;34m"        # Blue

# CI_MERGE_REQUEST_SOURCE_BRANCH_NAME=release/23.03.300
# CI_MERGE_REQUEST_TARGET_BRANCH_Name=develop-23.03.300-SDK1

ARG=$1;
leakagePassed=false
ex="$(date) ### Exception"
 
get_stop_words () {
    STOP_WORDS=$(curl -silent "https://vzwqa1.sdc.vzwcorp.com/content/wcms/SearchContent/jcr:content/basepagepar/contentsearch.json")
    STOP_WORDS="$(echo $STOP_WORDS | grep -o '"searchKey":"[^"]*' | grep -o '[^"]*$')"
    IFS='|' read -r -a STOP_WORDS <<< "$STOP_WORDS"
}

ci_run () {
    echo "Executes CI... \n"
    git checkout $CI_MERGE_REQUEST_SOURCE_BRANCH_NAME
    DIVERGE=$(git merge-base origin/$CI_MERGE_REQUEST_TARGET_BRANCH_Name $CI_MERGE_REQUEST_SOURCE_BRANCH_NAME)
    FILES_CHANGED=$(git diff --name-only $CI_MERGE_REQUEST_SOURCE_BRANCH_NAME $DIVERGE | tr '\n' ' ')
    IFS=' ' read -r -a FILES_CHANGED <<< "$FILES_CHANGED"

    for file in "${FILES_CHANGED[@]}"
        do
            if [[ $file != *"src/test/"* && $file == *"src/"* && -e "$file" ]]; then
                FILES_CHANGED="$FILES_CHANGED $file"
            fi
        done

    SINGLE_QUOTE=$(git diff $CI_MERGE_REQUEST_SOURCE_BRANCH_NAME $DIVERGE $FILES_CHANGED | tr '[:upper:]' '[:lower:]' | grep -o "\'[^\']\\+\'")
    DOUBLE_QUOTE=$(git diff $CI_MERGE_REQUEST_SOURCE_BRANCH_NAME $DIVERGE $FILES_CHANGED | tr '[:upper:]' '[:lower:]' | grep -o "\"[^\"]\\+\"")
    TILDE_QUOTE=$(git diff $CI_MERGE_REQUEST_SOURCE_BRANCH_NAME $DIVERGE $FILES_CHANGED | tr '[:upper:]' '[:lower:]' | grep -o "\`[^\`]\\+\`")

    MODIFIED_LINES="$SINGLE_QUOTE $DOUBLE_QUOTE $TILDE_QUOTE"
}

hook_run () {
    echo "Execute hooks.... "
    FILES_CHANGED=$(git diff --name-only --cached | tr '\n' ' ')
    IFS=' ' read -r -a FILES_CHANGED <<< "$FILES_CHANGED"
    for file in "${FILES_CHANGED[@]}"
        do
            if [[ $file != *"src/test/"* && $file == *"src/"* && -e "$file" ]]; then
                FILES_CHANGED="$FILES_CHANGED $file"
            fi
        done    
    SINGLE_QUOTE=$(git diff -U0 --cached $FILES_CHANGED | tr '[:upper:]' '[:lower:]' | grep -o "\'[^\']\\+\'")
    DOUBLE_QUOTE=$(git diff -U0 --cached $FILES_CHANGED | tr '[:upper:]' '[:lower:]' | grep -o "\"[^\"]\\+\"")
    TILDE_QUOTE=$(git diff -U0 --cached $FILES_CHANGED | tr '[:upper:]' '[:lower:]' | grep -o "\`[^\`]\\+\`")

    MODIFIED_LINES="$SINGLE_QUOTE $DOUBLE_QUOTE $TILDE_QUOTE"
}

all_run () {
    echo "Execute all files.... \n"
    git checkout $CI_MERGE_REQUEST_SOURCE_BRANCH_NAME
    #ROOT_DIR=soe-digital-next
    ROOT_DIR="$(pwd)"
    echo $ROOT_DIR 
    #ROOT_DIR=/c/Users/dsu6r3m/ZVERIZON/23_03_100_enable360/onevz-soe-shipping-handling-service
    get_stop_words
    get_all_files () {
        for filePath in "$1"/*
        do
            if [[ -d "$filePath" && $filePath != *"node_modules"* && $filePath != *"server"* && $filePath != *"test"* ]]; then
                get_all_files "$filePath"/*
            else
                CONTENT=$(cat $filePath)
                SINGLE_QUOTE=$(echo $CONTENT | tr '[:upper:]' '[:lower:]' | grep -o "\'[^\']\\+\'")
                DOUBLE_QUOTE=$(echo $CONTENT | tr '[:upper:]' '[:lower:]' | grep -o "\"[^\"]\\+\"")
                TILDE_QUOTE=$(echo $CONTENT | tr '[:upper:]' '[:lower:]' | grep -o "\`[^\`]\\+\`")

                MODIFIED_LINES="$SINGLE_QUOTE $DOUBLE_QUOTE $TILDE_QUOTE"
                
                for word in "${STOP_WORDS[@]}"
                do
                    word="$(echo $word | tr '[:upper:]' '[:lower:]' | sed -e 's/^[[:space:]]*//')"
                    BREAKLOOP="$(echo "$MODIFIED_LINES" | grep -o "$word")"
                    if [[ "$BREAKLOOP" != "" ]]; then
                    
                        FILES="$FILES\n$filePath --> $word"
                        
                        break
                    fi
                done

            fi
            
        done
    }
    get_all_files "$ROOT_DIR"
    if [[ "$FILES" != "" ]]; then
    	printf "${BRed} Your commit has been blocked by DATA LEAK PREVENTION mechanism. The following files have one of the leak contents. ${Color_Off}\n"
    	echo "$ex -# Your commit has been blocked by DATA LEAK PREVENTION mechanism. The following files have one of the leak contents.\n"
        echo $FILES
        leakagePassed=true
        break
    fi
}

if [[ "$ARG" == "CI" ]]; then
    ci_run
fi

if [[ "$ARG" == "HOOKS" ]]; then
    hook_run
fi

if [[ "$ARG" == "ALL" ]]; then
    all_run
fi

# TODO
# all_run - Handle to skin through all the files excluding test and server folders

if [[ "$ARG" != "ALL" ]]; then
    get_stop_words
    MODIFIED_LINES=$(echo -e ${MODIFIED_LINES/\n/' '})
    for word in "${STOP_WORDS[@]}"
        do
            word="$(echo $word | tr '[:upper:]' '[:lower:]' | sed -e 's/^[[:space:]]*//')"
            BREAKLOOP="$(echo "$MODIFIED_LINES" | grep -o "$word")"
            if [[ "$BREAKLOOP" != "" ]]
            then
                break
            fi
        done
    if [[ "$BREAKLOOP" != "" ]]
    then
        printf "${BRed} Your commit has been blocked by DATA LEAK PREVENTION mechanism. The leak content ${BREAKLOOP} has been identified in your staged files. ${Color_Off}\n"
        echo "$ex - Your commit has been blocked by DATA LEAK PREVENTION mechanism. The leak content ${BREAKLOOP} has been identified in your staged files."
        leakagePassed=true
        break
    fi
fi

if [[ $leakagePassed == true ]]; then 
    git config core.dlpstatus FAIL
 echo "FAIL" >> hooks/LEAKAGE_STATUS.txt 
 exit 1
 else
    git config core.dlpstatus PASS
 echo "PASS" >> hooks/LEAKAGE_STATUS.txt 
 exit 1
fi