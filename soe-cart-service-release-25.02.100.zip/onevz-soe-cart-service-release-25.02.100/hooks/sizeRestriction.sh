#!/bin/sh

Color_Off='\033[0m' 
BRed="\033[1;31m"         # Red
BGreen="\033[1;32m"       # Green

linesLimit=2000
ex="$(date) ### Exception"
#printf "${BGreen}[Pre-Commit] File size analysis in progress.... ${Color_Off}\n"
echo -e "File size analysis in progress.... \n"
newFile="$(git diff --name-only --cached \*.java)"

while IFS=' ' read -ra ADDR; do

for i in "${ADDR[@]}"
    do
    	#if [[ $i != *"/test/"* ]] && [[ $i == *".java"* ]]; then
		if [[ $i == *".java"* ]]; then
    			#echo $i
    			lines="$(eval wc -l $i | grep -v grep | awk '{print $1}')"
    			if [[ $lines -gt $linesLimit ]]; then
                echo -e "$ex - This staged file $i has lines greater than $linesLimit lines. \nPlease optimize your code or split into multiple files."
                #printf "${BRed}This staged file $i has lines greater than $linesLimit lines. Please optimize your code or split into multiple files. ${Color_Off}\n"
                echo "FAIL" >> hooks/FILESIZE_STATUS.txt
                git config core.sizestatus FAIL
                exit 1;
            fi
    	fi
    done

done <<< "$newFile"
echo "PASS" >> hooks/FILESIZE_STATUS.txt
git config core.sizestatus PASS