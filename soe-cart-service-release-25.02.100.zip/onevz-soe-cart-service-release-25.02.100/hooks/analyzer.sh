#!/bin/sh

# printf '\nFortify Analyzing...\n'
set -e
./hooks/security.sh > hooks/security.log
exit $?