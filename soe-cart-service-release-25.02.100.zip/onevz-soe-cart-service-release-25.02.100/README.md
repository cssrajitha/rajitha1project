# onevz-soe-cart-service  

# Developer Guidelines

## Developer Workflow
* To work on this service, fork the repo to your gitlab profile. E.g. If you fork https://gitlab.verizon.com/HIVV_SOE/onevz-soe-cart-service, a new repo will be created in your VZID profile called https://gitlab.verizon.com/**your-vz-id**/onevz-soe-cart-service.
* Setup mirroring on your forked repo to ensure other's changes are pushed to your forked repo.
* Clone the forked repo to your local machine.
* Write code.
* Manually mirror your remote fork with main remote by going to Your-Fork >>> Settings >>> Repository >>> Mirroring Repositories >>> Update Now.
* Git pull to your local machine.
* Commit your changes to the local machine's release branch.
* Push your changes from your local machine's release branch to the remote release branch on YOUR FORKED repo.
* Create a merge request from your forked repo to the main repo. Changes will be merged after review and approval.
* Follow the same steps for https://gitlab.verizon.com/HIVV_SOE/onevz-soe-framework and import onevz-soe-cart from core modules in local.

## Workspace Setup

* Clone: https://gitlab.verizon.com/HIVV_SOE/onevz-soe-cart-pojos.
* Update version in POM.xml by replacing `24.89.100-SNAPSHOT` with the desired fix version, eg: 22.09.100.
* Do `mvn clean install` on this repo and let it build.
* Clone https://gitlab.verizon.com/HIVV_SOE/onevz-soe-cart-service.
* Update version in POM.xml by replacing `24.89.100-SNAPSHOT` with the desired fix version, eg: 22.09.100 (Same as the POJOS).
* Do an `mvn clean install` on this repo. Do not skip test case execution as it is mandatory for Sonar coverage execution.
* Import the project in the IDE of your choice.
* Copy `helm/onevz-soe-cart-service/containers/onevz-soe-cart-service/config-map/props/src/main/resources/application.properties` and paste in `/onevz-soe-cart-service/src/main/resources/`.
* Run the jar (ending with exec) from the newly created `target` folder.

## Coding Standards
* All code must have JUnit Test Cases. Coverage should be greater than 70%.

## Recommended IDE
* Use **IntelliJ** for best performance and development experience.

## Swagger
* To access swagger, once the application is up on a port, say 8082, use the url: http://localhost:8082/cart/swagger to access the API documentation.
* Implementation Guide:
   * Add depedency: `<dependency>
     <groupId>org.springdoc</groupId>
     <artifactId>springdoc-openapi-ui</artifactId>
     <version>1.2.32</version>
     </dependency>`
   * To define custom URL add these properties in application.properties: `springdoc.api-docs.path=/cart/swagger/swagger.json` &
     `springdoc.swagger-ui.path=/cart/swagger`

