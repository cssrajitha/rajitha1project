package onevz.soe.cart.controller;

import onevz.soe.cart.helper.UpdateCreditAppFraudStatusHelper;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.UpdateCreditAppFraudStatusRequest;
import onevz.soe.cart.ui.responses.UpdateCreditAppFraudStatusMainResponse;
import onevz.soe.cart.ui.responses.UpdateCreditAppFraudStatusResponse;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {CartServiceTestConfig.class})
public class UpdateCreditAppControllerTest {

    @InjectMocks
    private UpdateCreditAppController updateCreditAppController;

    @Mock
    private UpdateCreditAppFraudStatusHelper updateCreditAppFraudStatusHelper;

    @Test
    public void updateCreditAppFraudStatus(){
        UpdateCreditAppFraudStatusRequest request=new UpdateCreditAppFraudStatusRequest();
        request.setCcaAppNum("21321321");
        UpdateCreditAppFraudStatusMainResponse response=new UpdateCreditAppFraudStatusMainResponse();
        UpdateCreditAppFraudStatusMainResponse.UpdateCreditAppFraudStatusData resp=new UpdateCreditAppFraudStatusMainResponse.UpdateCreditAppFraudStatusData();
        resp.setStatus(1);
        resp.setUpdateCreditAppFraudStatusResponse(new UpdateCreditAppFraudStatusResponse());
        response.setData(resp);
        Mockito.when(updateCreditAppFraudStatusHelper.updateCreditAppFraudStatus(Mockito.any())).thenReturn(Mono.just(response));
        Mono<UpdateCreditAppFraudStatusMainResponse> monoResp=updateCreditAppController.updateCreditAppFraudStatus(request);
        StepVerifier.create(monoResp).assertNext(res ->{
            Assert.assertNotNull(res.getData());
            Assert.assertNotNull(res.getData().getUpdateCreditAppFraudStatusResponse());
        }).expectComplete().verify();
    }

    @Test
    public void updateCreditAppFraudStatusInvalid(){
        UpdateCreditAppFraudStatusRequest request=new UpdateCreditAppFraudStatusRequest();
        Mono<UpdateCreditAppFraudStatusMainResponse> monoResp=updateCreditAppController.updateCreditAppFraudStatus(request);
        StepVerifier.create(monoResp).assertNext(res ->{
            Assert.assertNotNull(res.getErrors());
        }).expectComplete().verify();
    }

}
