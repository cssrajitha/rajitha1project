package onevz.soe.cart.service.test.cases;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import onevz.cxp.feature.util.FeatureFlag;
import onevz.soe.cradle.CradleAllocator;
import onevz.soe.cradle.constant.Constants;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.cradle.vo.CradleResponse;

import onevz.soe.cart.helper.CradleHelper;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.requests.RetrieveBundleAccRequest;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(CradleHelper.class)
public class CradleHelperTest {
	
	@Autowired
	CradleHelper helper;
	
	@Autowired
	private ObjectMapper mapper;
	
	@MockBean
	private RedisHelper redisHelper;

	@MockBean
	private FeatureFlag featureFlag;

	@MockBean
	private CradleAllocator cradleAllocator;

	@Test
	public void isInFlowCartFeatureDisabled() {
		when(featureFlag.isFeatureEnabled(anyString(), anyString(), anyString(), anyBoolean())).thenReturn(Mono.just(false));
		Mono<Boolean> result = helper.isInFlowCart(null, null);
		StepVerifier.create(result).expectNext(Boolean.FALSE).expectComplete().verify();
	}

	@Test
	public void isInFlowCartFeatureEnabledNoDataInRedis() {
		when(featureFlag.isFeatureEnabled(anyString(), anyString(), anyString(), anyBoolean())).thenReturn(Mono.just(true));
		when(redisHelper.getRequiredDataFromRedis(anyList())).thenReturn(Mono.just(Collections.emptyMap()));
		when(cradleAllocator.invokeReactiveCradle(any(), any(), anyMap())).thenReturn(Mono.just(new CradleResponse()));
		Mono<Boolean> result = helper.isInFlowCart(null, null);
		StepVerifier.create(result).expectNext(Boolean.FALSE).expectComplete().verify();
	}

	@Test
	public void isInFlowCartFeatureEnabledDataInRedis() {
		when(featureFlag.isFeatureEnabled(anyString(), anyString(), anyString(), anyBoolean())).thenReturn(Mono.just(true));
		Map<String, String> dataMap = new HashMap<>();
		dataMap.put(Constants.CRADLE_DATAMAP_KEY, "{\"throttleList\":\"INFLOW_CART\"}");
		when(redisHelper.getRequiredDataFromRedis(anyList())).thenReturn(Mono.just(dataMap));
		Mono<Boolean> result = helper.isInFlowCart(null, null);
		StepVerifier.create(result).expectNext(Boolean.TRUE).expectComplete().verify();
	}

	@Test
	public void isInFlowCartFeatureEnabledJacksonError() {
		when(featureFlag.isFeatureEnabled(anyString(), anyString(), anyString(), anyBoolean())).thenReturn(Mono.just(true));
		Map<String, String> dataMap = new HashMap<>();
		dataMap.put(Constants.CRADLE_DATAMAP_KEY, "{\"throttleList\":\"\"INFLOW_CART\"}");
		when(redisHelper.getRequiredDataFromRedis(anyList())).thenReturn(Mono.just(dataMap));
		Mono<Boolean> result = helper.isInFlowCart(null, null);
		StepVerifier.create(result).expectNext(Boolean.TRUE).expectComplete().verify();
	}

	@Test
	public void isInFlowCartFeatureEnabledCradleResponseEmpty() {
		when(featureFlag.isFeatureEnabled(anyString(), anyString(), anyString(), anyBoolean())).thenReturn(Mono.just(true));
		when(redisHelper.getRequiredDataFromRedis(anyList())).thenReturn(Mono.just(Collections.emptyMap()));
		when(cradleAllocator.invokeReactiveCradle(any(), any(), anyMap())).thenReturn(Mono.empty());
		Mono<Boolean> result = helper.isInFlowCart(null, null);
		StepVerifier.create(result).expectNext(Boolean.FALSE).expectComplete().verify();
	}

	@Test
	public void isInFlowCartFeatureEnabledCradleResponseWithOutput() {
		when(featureFlag.isFeatureEnabled(anyString(), anyString(), anyString(), anyBoolean())).thenReturn(Mono.just(true));
		when(redisHelper.getRequiredDataFromRedis(anyList())).thenReturn(Mono.just(Collections.emptyMap()));
		CradleResponse cradleResponse = new CradleResponse();
		cradleResponse.setOutPut("{\"throttleList\":\"INFLOW_CART\"}");
		when(cradleAllocator.invokeReactiveCradle(any(), any(), anyMap())).thenReturn(Mono.just(cradleResponse));
		Mono<Boolean> result = helper.isInFlowCart(null, null);
		StepVerifier.create(result).expectNext(Boolean.TRUE).expectComplete().verify();
	}
	@Test
	public void defaultCradleResponseTest() {
		Mono<CradleResponse> response = helper.defaultCradleResponse();
		StepVerifier.create(response).assertNext(resp -> Assert.assertNull(resp.getOutPut())).expectComplete().verify();
	}
	
	@Test
	public void getCradleOutputTest() throws JsonMappingException, JsonProcessingException {
//		String cradleResponseString = "";
		CradleResponse cradleResponse = new CradleResponse(); //mapper.readValue(cradleResponseString, CradleResponse.class);
		cradleResponse.setOutPut("");
		Mono<String> response = helper.getCradleOutput(cradleResponse);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getThrottlingListTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"data\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartCreator\":\"\",\"processingMTN\":null,\"processAction\":\"getAccessoryRecommendationsBundle\",\"processStep\":\"AccessoryInterestial\",\"intendType\":\"\",\"pageId\":\"acc--bundle\"}}";
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"bbpImei\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		RetrieveBundleAccRequest request = mapper.readValue(requestString, RetrieveBundleAccRequest.class);
		ServerHttpRequest httpHeader = null;
		ServerHttpResponse httpResponse = null;
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		CradleResponse cradleResponse = new CradleResponse();
		cradleResponse.setOutPut("{\"throttleList\":\"INFLOW_CART\"}");
		when(cradleAllocator.invokeReactiveCradle(any(), any(), anyMap())).thenReturn(Mono.just(cradleResponse));
		Mono<String> response = helper.getThrottlingList(request, httpHeader, httpResponse);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getThrottlingListJsonErrorTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"data\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartCreator\":\"\",\"processingMTN\":null,\"processAction\":\"getAccessoryRecommendationsBundle\",\"processStep\":\"AccessoryInterestial\",\"intendType\":\"\",\"pageId\":\"acc--bundle\"}}";
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"bbpImei\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		RetrieveBundleAccRequest request = mapper.readValue(requestString, RetrieveBundleAccRequest.class);
		ServerHttpRequest httpHeader = null;
		ServerHttpResponse httpResponse = null;
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		CradleResponse cradleResponse = new CradleResponse();
		cradleResponse.setOutPut("{\"throttleList\":\"\"INFLOW_CART\"}");
		when(cradleAllocator.invokeReactiveCradle(any(), any(), anyMap())).thenReturn(Mono.just(cradleResponse));
		Mono<String> response = helper.getThrottlingList(request, httpHeader, httpResponse);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getThrottlingListCradleNull() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"data\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartCreator\":\"\",\"processingMTN\":null,\"processAction\":\"getAccessoryRecommendationsBundle\",\"processStep\":\"AccessoryInterestial\",\"intendType\":\"\",\"pageId\":\"acc--bundle\"}}";
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"bbpImei\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		RetrieveBundleAccRequest request = mapper.readValue(requestString, RetrieveBundleAccRequest.class);
		ServerHttpRequest httpHeader = null;
		ServerHttpResponse httpResponse = null;
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cradleAllocator.invokeReactiveCradle(any(), any(), anyMap())).thenReturn(null);
		Mono<String> response = helper.getThrottlingList(request, httpHeader, httpResponse);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void getThrottlingListTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"data\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartCreator\":\"\",\"processingMTN\":null,\"processAction\":\"getAccessoryRecommendationsBundle\",\"processStep\":\"AccessoryInterestial\",\"intendType\":\"\",\"pageId\":\"acc-gridwall-bundle\"}}";
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"bbpImei\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		RetrieveBundleAccRequest request = mapper.readValue(requestString, RetrieveBundleAccRequest.class);
		ServerHttpRequest httpHeader = null;
		ServerHttpResponse httpResponse = null;
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cradleAllocator.invokeReactiveCradle(any(), any(), anyMap())).thenReturn(Mono.just(new CradleResponse()));
		Mono<String> response = helper.getThrottlingList(request, httpHeader, httpResponse);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void getThrottlingListTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"data\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartCreator\":\"\",\"processingMTN\":null,\"processAction\":\"getAccessoryRecommendationsBundle\",\"processStep\":\"AccessoryInterestial\",\"intendType\":\"NSE\",\"pageId\":\"acc--bundle\"}}";
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"bbpImei\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		RetrieveBundleAccRequest request = mapper.readValue(requestString, RetrieveBundleAccRequest.class);
		ServerHttpRequest httpHeader = null;
		ServerHttpResponse httpResponse = null;
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cradleAllocator.invokeReactiveCradle(any(), any(), anyMap())).thenReturn(Mono.just(new CradleResponse()));
		Mono<String> response = helper.getThrottlingList(request, httpHeader, httpResponse);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void getThrottlingListWithDataMapTest() throws JsonMappingException, JsonProcessingException {
		Map<String, String> dataMap = new HashMap<>();
		dataMap.put("isProspect", "false");
		dataMap.put("channel", "VZW-DOTCOM");
		dataMap.put("pageName", "acc-interestial-bundle");
		ServerHttpRequest httpHeader = null;
		ServerHttpResponse httpResponse = null;
		Mono<String> response = helper.getThrottlingList(dataMap, httpHeader, httpResponse);
		StepVerifier.create(response).assertNext(resp -> {Assert.assertNotNull(resp);
															Assert.assertEquals("", resp);})
															.expectComplete().verify();
	}

	@Test
	public void getThrottlingListWithDataMap1Test() throws JsonMappingException, JsonProcessingException {
		Map<String, String> dataMap = new HashMap<>();
		ServerHttpRequest httpHeader = null;
		ServerHttpResponse httpResponse = null;
		when(cradleAllocator.invokeReactiveCradle(any(), any(), anyMap())).thenReturn(Mono.just(new CradleResponse()));
		Mono<String> response = helper.getThrottlingList(dataMap, httpHeader, httpResponse);
		StepVerifier.create(response).assertNext(resp -> {Assert.assertNotNull(resp);
			Assert.assertEquals("", resp);})
				.expectComplete().verify();
	}

	@Test
	public void getThrottlingListTest4() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"data\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processAction\":\"getAccessoryRecommendationsBundle\",\"processStep\":\"AccessoryInterestial\",\"intendType\":\"NSE\",\"pageId\":\"acc--bundle\",\"enabledFlow\":\"BYOD\"},\"channelId\":\"VZW-ECOM\"}";
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"bbpImei\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		RetrieveBundleAccRequest request = mapper.readValue(requestString, RetrieveBundleAccRequest.class);
		ServerHttpRequest httpHeader = null;
		ServerHttpResponse httpResponse = null;
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cradleAllocator.invokeReactiveCradle(any(), any(), anyMap())).thenReturn(Mono.just(new CradleResponse()));
		Mono<String> response = helper.getThrottlingList(request, httpHeader, httpResponse);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getThrottlingListTest5() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"data\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartCreator\":\"\",\"processingMTN\":\"9597456322\",\"processAction\":\"getAccessoryRecommendationsBundle\",\"processStep\":\"AccessoryInterestial\",\"pageId\":\"\",\"intent\":\"NSE\",\"enabledFlow\":\"NAO\"}}";
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"bbpImei\": \"8436667390\", \"intendType\": \"NSE\", \"intent\": \"NSE\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		RetrieveBundleAccRequest request = mapper.readValue(requestString, RetrieveBundleAccRequest.class);
		ServerHttpRequest httpHeader = null;
		ServerHttpResponse httpResponse = null;
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cradleAllocator.invokeReactiveCradle(any(), any(), anyMap())).thenReturn(Mono.just(new CradleResponse()));
		Mono<String> response = helper.getThrottlingList(request, httpHeader, httpResponse);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getCradleOutput1Test() throws JsonMappingException, JsonProcessingException {
		CradleResponse cradleResponse = new CradleResponse();
		//cradleResponse.setOutPut("");
		Mono<String> response = helper.getCradleOutput(cradleResponse);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getCradleOutput2Test() throws JsonMappingException, JsonProcessingException {
		CradleResponse cradleResponse = null;
		//cradleResponse.setOutPut("");
		Mono<String> response = helper.getCradleOutput(cradleResponse);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void getThrottlingListTest6() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"data\":null}";
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"bbpImei\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		RetrieveBundleAccRequest request = mapper.readValue(requestString, RetrieveBundleAccRequest.class);
		ServerHttpRequest httpHeader = null;
		ServerHttpResponse httpResponse = null;
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cradleAllocator.invokeReactiveCradle(any(), any(), anyMap())).thenReturn(Mono.just(new CradleResponse()));
		Mono<String> response = helper.getThrottlingList(request, httpHeader, httpResponse);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void getThrottlingListTest7() throws JsonMappingException, JsonProcessingException {
		
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"bbpImei\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		RetrieveBundleAccRequest request = null;
		ServerHttpRequest httpHeader = null;
		ServerHttpResponse httpResponse = null;
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cradleAllocator.invokeReactiveCradle(any(), any(), anyMap())).thenReturn(Mono.just(new CradleResponse()));
		Mono<String> response = helper.getThrottlingList(request, httpHeader, httpResponse);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	

	@Test
	public void getThrottlingListTest8() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"data\":{\"intent\":\"AAL\",\"processingMTN\":\"6942468985\",\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartCreator\":\"\",\"processAction\":\"getAccessoryRecommendationsBundle\",\"processStep\":\"AccessoryInterestial\",\"intendType\":\"\",\"pageId\":\"acc--bundle\"}}";
		String redisDataString = "{ \"intendType\":\"AAL\",\"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"bbpImei\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		RetrieveBundleAccRequest request = mapper.readValue(requestString, RetrieveBundleAccRequest.class);
		ServerHttpRequest httpHeader = null;
		ServerHttpResponse httpResponse = null;
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cradleAllocator.invokeReactiveCradle(any(), any(), anyMap())).thenReturn(Mono.just(new CradleResponse()));
		Mono<String> response = helper.getThrottlingList(request, httpHeader, httpResponse);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void getThrottlingListTest9() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"data\":{\"intent\":\"AAL\",\"processingMTN\":\"6942468985\",\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartCreator\":\"\",\"processAction\":\"getAccessoryRecommendationsBundle\",\"processStep\":\"AccessoryInterestial\",\"intendType\":\"\",\"pageId\":\"acc--bundle\"}}";
		String redisDataString = "{ \"intent\":\"AAL\",\"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"bbpImei\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		RetrieveBundleAccRequest request = mapper.readValue(requestString, RetrieveBundleAccRequest.class);
		ServerHttpRequest httpHeader = null;
		ServerHttpResponse httpResponse = null;
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cradleAllocator.invokeReactiveCradle(any(), any(), anyMap())).thenReturn(Mono.just(new CradleResponse()));
		Mono<String> response = helper.getThrottlingList(request, httpHeader, httpResponse);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
}
