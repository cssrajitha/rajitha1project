package onevz.soe.cart.bpm.helper;

import static org.mockito.Mockito.when;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.helper.ScanIdLookUpInfoHelper;
import onevz.soe.cart.requests.ScanIdLookUpInfoRequest;
import onevz.soe.cart.responses.ScanIdLookUpInfoResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.orderprocess.response.cxp.ScanIdLookUpInfoCXPResponse;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { CartServiceTestConfig.class })
public class ScanIdLookUpInfoHelperTest {

	@Autowired
	ObjectMapper mapper;

	@InjectMocks
	ScanIdLookUpInfoHelper helper;

	@Mock
	CartServiceCXPServices cxpServices;

	@Test
	public void scanIdLookUpInfoTest() throws JsonMappingException, JsonProcessingException {
		ScanIdLookUpInfoRequest request = new ScanIdLookUpInfoRequest();
		ScanIdLookUpInfoCXPResponse response = new ScanIdLookUpInfoCXPResponse();
		request.setGemaltoSessionid("5f3450a6-8887-4290-9695-40f534282266");

		String respString = "{ \"errors\": null, \"data\": { \"firstName\": \"SUKHVINDER\", \"lastName\": \"MATHAROO\", \"addressLine1\": \"131 WINDSOR CT\", \"city\": \"EWING\", \"state\": \"NJ\", \"zip\": \"08638-1846\", \"dob\": \"1988-09-28\", \"gemaltoStatus\": \"NoFailedChecks\", \"docNum\": \"M08077268209882\", \"docTypeName\": \"New Jersey (NJ) Auto Driver License - Not For Federal ID 2020\", \"statusCode\": \"00\" }  }";
		response = mapper.readValue(respString, ScanIdLookUpInfoCXPResponse.class);

		when(cxpServices.scanIdLookupInfo(Mockito.any())).thenReturn(Mono.just(response));
		Mono<ScanIdLookUpInfoResponse> serviceResp = helper.scanIdLookUp(request);
		StepVerifier.create(serviceResp).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete()
				.verify();

	}

	@Test
	public void scanIdLookUpInfoEmptyRequestTest() throws JsonMappingException, JsonProcessingException {
		ScanIdLookUpInfoRequest request = new ScanIdLookUpInfoRequest();
		ScanIdLookUpInfoCXPResponse response = new ScanIdLookUpInfoCXPResponse();
		request.setGemaltoSessionid("");

		String respString = "{ \"errors\": [ { \"name\": \"Bad Request\", \"id\": \"1000\", \"message\": \"GemaltoSessionId is empty\", \"msgType\": \"D\", \"cfeMsg\": false } ], \"data\": { \"status\": -1 } }";
		response = mapper.readValue(respString, ScanIdLookUpInfoCXPResponse.class);

		Mono<ScanIdLookUpInfoResponse> serviceResp = helper.scanIdLookUp(request);
		StepVerifier.create(serviceResp).assertNext(resp -> Assert.assertNotNull(resp.getErrors())).expectComplete()
				.verify();

	}

	@Test
	public void scanIdLookUpInfoErrorTest() throws JsonMappingException, JsonProcessingException {
		ScanIdLookUpInfoRequest request = new ScanIdLookUpInfoRequest();
		ScanIdLookUpInfoCXPResponse response = new ScanIdLookUpInfoCXPResponse();
		request.setGemaltoSessionid("5f3450a6-8887-4290-9695-40f534282266");

		String respString = "{ \"errors\": [ { \"name\": \"Bad Request\", \"id\": \"1000\", \"message\": \"GemaltoSessionId is empty\", \"msgType\": \"D\", \"cfeMsg\": false } ], \"data\": { \"status\": -1 } }";
		response = mapper.readValue(respString, ScanIdLookUpInfoCXPResponse.class);

		when(cxpServices.scanIdLookupInfo(Mockito.any())).thenReturn(Mono.just(response));
		Mono<ScanIdLookUpInfoResponse> serviceResp = helper.scanIdLookUp(request);
		StepVerifier.create(serviceResp).assertNext(resp -> Assert.assertNotNull(resp.getErrors())).expectComplete()
				.verify();

	}

	@Test
	public void scanIdLookUpInfoExceptionTest() throws JsonMappingException, JsonProcessingException {
		ScanIdLookUpInfoRequest request = new ScanIdLookUpInfoRequest();
		ScanIdLookUpInfoCXPResponse response = new ScanIdLookUpInfoCXPResponse();
		request.setGemaltoSessionid("5f3450a6-8887-4290-9695-40f534282266");

		String respString = "{\"errors\":[{\"debug_id\":\"2022-04-26T06:46:24.+0000:0b97b391-4ec2-4ded-bf3b-fc21134583b3:cxp-shopping-services-qa-ev6v-sit1e-nscxp-d4cffc75c-6jjcc:nssit1\",\"namespace\":\"cxp-document-services\",\"name\":\"API_ERROR\",\"id\":\"3998\",\"message\":\"502 BAD_GATEWAY [catalog-domain/catalogRefData] url: verizon.com/b6vv-cxp-nsqa/b6vv/nssit1/catalog/catalogRefData\",\"category\":\"API_ERR\"}]}";
		response = mapper.readValue(respString, ScanIdLookUpInfoCXPResponse.class);

		when(cxpServices.scanIdLookupInfo(Mockito.any())).thenReturn(Mono.just(response));
		Mono<ScanIdLookUpInfoResponse> serviceResp = helper.scanIdLookUp(request);
		StepVerifier.create(serviceResp).assertNext(resp -> Assert.assertNotNull(resp.getErrors())).expectComplete()
				.verify();

	}
}
