package onevz.soe.cart.service.test.util;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import onevz.soe.cart.model.common.CartServiceCartInfo;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.util.PlanChangeWarningUtil;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(PlanChangeWarningUtil.class)
public class PlanChangeWarningUtilTest {
	
	@Autowired
	private ObjectMapper mapper;

	@Test
	public void setFiveGPlanChangeWarningTest() throws JsonMappingException, JsonProcessingException {
		String cartInfoString = "{}"; 
		CartServiceCartInfo cartInfo = mapper.readValue(cartInfoString, CartServiceCartInfo.class);
		PlanChangeWarningUtil.setFiveGPlanChangeWarning(cartInfo, "");
		Assert.assertNull(cartInfo.getPlanChangeWarningMessages());
	}
	
	@Test
	public void setFiveGPlanChangeWarningTest2() throws JsonMappingException, JsonProcessingException {
		String cartInfoString = "{\"lines\": []}"; 
		CartServiceCartInfo cartInfo = mapper.readValue(cartInfoString, CartServiceCartInfo.class);
		PlanChangeWarningUtil.setFiveGPlanChangeWarning(cartInfo, "");
		Assert.assertNull(cartInfo.getPlanChangeWarningMessages());
	}
	
	@Test
	public void setFiveGPlanChangeWarningTest3() throws JsonMappingException, JsonProcessingException {
		String cartInfoString = "{\"lines\": [{\"featureMessages\": [{\"name\": \"5GUWBBOLT\",\"action\": \"DROP\"},{\"name\": \"5GUWBBOLT\",\"action\": \"REMOVE\"}]}]}"; 
		CartServiceCartInfo cartInfo = mapper.readValue(cartInfoString, CartServiceCartInfo.class);
		PlanChangeWarningUtil.setFiveGPlanChangeWarning(cartInfo, "");
		Assert.assertEquals("FIVEG_PLAN_CHANGE_WARNING", cartInfo.getPlanChangeWarningMessages().get(0).getMessageKey());
	}
}
