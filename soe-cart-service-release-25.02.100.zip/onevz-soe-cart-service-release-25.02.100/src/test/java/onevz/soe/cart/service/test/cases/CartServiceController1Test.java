package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import junit.framework.Assert;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.controller.CartUpdateOperationsController;
import onevz.soe.cart.controller.CartUpdateOperationsController2;
import onevz.soe.cart.controller.CartUpdateOperationsController3;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.elasticsearch.Brands;
import onevz.soe.cart.requests.IndirectExCustRemoveLinePEGARes;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.omnidl.util.DLUtilityService;
import onevz.soe.security.TokenProcessor;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.*;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpResponse;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.WebDataBinder;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@WebFluxTest(CartUpdateOperationsController.class)
public class CartServiceController1Test {
    @MockBean
    private UpdateCartHelper cartHelper;
    @Autowired
    private CartUpdateOperationsController cartController;
    @Autowired
    private CartUpdateOperationsController2 cartController2;
    @Autowired
    private CartUpdateOperationsController3 cartController3;
    @MockBean
    private CartServiceCxpHelper cartServiceCXPHelper;
    @Autowired
    private ObjectMapper mapper;
    @MockBean
    private RedisHelper redisHelper;
    @MockBean
    private OmniDLHelper omniDLHelper;
    @MockBean
    private FeatureFlagHelper featureFlagHelper;
    @MockBean
    private RedisHelper2 redisHelper2;
    @MockBean
    private RedisHelper3 redisHelper3;
    @MockBean
    private DLUtilityService dlUtilityService;
    @MockBean
    private TokenProcessor tokenProcessor;
    @MockBean
    private CartAddDeviceHelper devHelper;
    @MockBean
    private CartAccessoryHelper accHelper;
    @MockBean
    private TradeInHelper tradeInHelper;

    @Test
    public void updateSalesRepAndLocationCodeTest() throws IOException {
        String requestString = "{        \"cartInfo\": {                \"clientAppName\": \"VZW-NETACE\",                \"cartId\": \"f61a7954-4300-4e97-9478-f001475bdf9b\",                \"caseId\": \"SOP-508208-E01\",                \"accountNumber\": \"0420194063-00001\",                \"cartCreator\": \"4235342870\",                \"processingMTN\": \"4235344191\",                \"processStep\": \"MTNSelectionPage\",                \"intendType\": \"AAL\"        },        \"data\": {                \"orderLocationCode\": \"E319201\",                \"salesRepId\": \"ENC\"        }}";
        String responseString = "{\"serviceHeader\": {\"clientId\": \"VZW-NETACE\",\"statusMsg\": \"SUCCESS\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \"SOP-521102-E01\",\"customerInfo\": {\"accountNumber\": \"0100003375-00001\",\"cartCreator\": \"2515813861\",\"processingMTN\": \"2515813860\"},\"cartInfo\": {\"cartId\": \"69a66ef4d-7e344dfb-2db299209-ea8333\",\"statusCode\": \"1\",\"statusMsg\": \"Sales Rep and Location Code updated successfully.\"},\"contextInfo\": {\"processStep\": \"MTNSelectionPage\",\"availablePaths\": [{\"path\": \"MTNSelectionPage\"}],\"callReason\": \"SalesOrderPurchase\"}}}}}";
        SalesRepAndLocationCodeUIRequest request = mapper.readValue(requestString,
                SalesRepAndLocationCodeUIRequest.class);
        SalesRepAndLocationCodeUIResponse response = mapper.readValue(responseString,
                SalesRepAndLocationCodeUIResponse.class);
        URI url = URI.create("http://localhost/salesRep");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.updateSalesRepAndLocationCode(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController
                .updateSalesRepAndLocationCode(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateSalesRepAndLocationBadRequestCodeTest() throws IOException {
        String requestString = "{        \"cartInfo\": {                \"clientAppName\": \"VZW-NETACE\",                \"cartId\": \"\",                \"caseId\": \"SOP-508208-E01\",                \"accountNumber\": \"0420194063-00001\",                \"cartCreator\": \"4235342870\",                \"processingMTN\": \"4235344191\",                \"processStep\": \"MTNSelectionPage\",                \"intendType\": \"AAL\"        },        \"data\": {                \"orderLocationCode\": \"E319201\",                \"salesRepId\": \"ENC\"        }}";
        SalesRepAndLocationCodeUIRequest request = mapper.readValue(requestString,
                SalesRepAndLocationCodeUIRequest.class);
        URI url = URI.create("http://localhost/salesRep");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController
                .updateSalesRepAndLocationCode(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateSalesRepAndLocationCodeErrorTest() throws IOException {
        String requestString = "{        \"cartInfo\": {                \"clientAppName\": \"VZW-NETACE\",                \"cartId\": \"f61a7954-4300-4e97-9478-f001475bdf9b\",                \"caseId\": \"SOP-508208-E01\",                \"accountNumber\": \"0420194063-00001\",                \"cartCreator\": \"4235342870\",                \"processingMTN\": \"4235344191\",                \"processStep\": \"MTNSelectionPage\",                \"intendType\": \"AAL\"        },        \"data\": {                \"orderLocationCode\": \"E319201\",                \"salesRepId\": \"ENC\"        }}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        SalesRepAndLocationCodeUIRequest request = mapper.readValue(requestString,
                SalesRepAndLocationCodeUIRequest.class);
        SalesRepAndLocationCodeUIResponse response = mapper.readValue(responseString,
                SalesRepAndLocationCodeUIResponse.class);
        URI url = URI.create("http://localhost/salesRep");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.updateSalesRepAndLocationCode(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController
                .updateSalesRepAndLocationCode(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void addNickNameTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"697e59e4-e177-4289-89cb-0bbbe0bc3154\",\"caseId\":\"SOP-18159-E01\",\"accountNumber\":\"0280219648-00001\",\"cartCreator\":\"5858313708\",\"processingMTN\":\"5852699368\",\"intendType\":\"EUP\",\"processStep\":\"ComparePlan/PlanSelection\"},\"data\":{\"lines\":[{\"mtn\":\"5852699368\",\"nickName\":\"James\"}]}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"PEGA generated message\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\" SAP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\",\"ShoppingCart\",\"CreditPage\"]},{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}],\"CartInfo\":{\"cartId\":\"bea202a6-42cb-40d4-ac87-d3f1db2b3f13\",\"statusCode\":\"1\",\"statusMsg\":\"Nick Name Updated Successfully\"},\"contextInfo\":{\"processAction\":\"\",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ComparePlan/PlanSelection\",\"availablePaths\":[{\"path\":\"ComparePlan/PlanSelection\"}]}}}}}";
        AddNickNameUIRequest request = mapper.readValue(requestString, AddNickNameUIRequest.class);
        AddNickNameUIResponse response = mapper.readValue(responseString, AddNickNameUIResponse.class);
        URI url = URI.create("http://localhost/addNickName");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.addNickName(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addNickName(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addNickNameErrorTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        AddNickNameUIRequest request = mapper.readValue(requestString, AddNickNameUIRequest.class);
        AddNickNameUIResponse response = mapper.readValue(responseString, AddNickNameUIResponse.class);
        URI url = URI.create("http://localhost/addNickName");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.addNickName(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addNickName(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }
    @Test
    public void addNickNameErrorTest2() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        AddNickNameUIRequest request = mapper.readValue(requestString, AddNickNameUIRequest.class);
        AddNickNameUIResponse response = mapper.readValue(responseString, AddNickNameUIResponse.class);
        URI url = URI.create("http://localhost/addNickName");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.valueOf(500));
        when(cartHelper.addNickName(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addNickName(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addBarcodeTest() throws IOException {
        String requestString = "{\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\": \"4c4a9307-ebc1-4f51-a350-a6438b825dcb\",\"caseId\": \"SOP-659808-E01\",\"accountNumber\": \"0285560011-00001\",\"cartCreator\": \"2018702013\",\"processingMTN\": \"2018702013\",\"processStep\": \"ShoppingCart\",\"intendType\": \"AAL\"},\"data\": {\"barCodeIds\": [{\"barCodeId\": \"ACC10OFF03212\"},{\"barCodeId\": \"ACC10OFF03213\"}],\"includeExpiryBarcodeStatus\": \"Y\",\"lines\": [{\"mtn\": \"2158806687\"},{\"mtn\": \"3025451824\"}]},\"validateCartRequest\": {\"pageId\": \"CART\",\"retrieveCurrentFeatures\": true}}";
        String responseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \" SOP-1583186-DEV3\",\"customerInfo\": {\"accountNumber\": \"07893451230-00001\",\"cartCreator\": \"2515813861\",\"processingMTN\": \"2515813860\"},\"processMTNList\": [{\"mtn\": \"2515813860\",\"completedprocessSteps\": [\"MTNSelectionPage\",\"GridWallPDP\"]},{\"mtn\": \"2515813861\",\"completedprocessSteps\": []}],\"cartInfo\": {\"cartId\": \"8c5fa64a-9811-4eb8-85cd-b5939cae298b\",\"statusCode\": \"1\",\"statusMsg\": \"Barcode validated successfully\",\"lines\": [{\"mtn\": \"3014674968\",\"status\": 1,\"errors\": null}]},\"contextInfo\": {\"processAction\": \"\",\"processStep\": \"ShoppingCart\"}}}}}";
        UpdateBarcodeUIRequest request = mapper.readValue(requestString, UpdateBarcodeUIRequest.class);
        UpdateBarcodeUIResponse response = mapper.readValue(responseString, UpdateBarcodeUIResponse.class);
        URI url = URI.create("http://localhost/updateBarcode");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.updateBarcode(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.updateBarcode(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addBarcodeErrorTest() throws IOException {
        String requestString = "{\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\": \"4c4a9307-ebc1-4f51-a350-a6438b825dcb\",\"caseId\": \"SOP-659808-E01\",\"accountNumber\": \"0285560011-00001\",\"cartCreator\": \"2018702013\",\"processingMTN\": \"2018702013\",\"processStep\": \"ShoppingCart\",\"intendType\": \"AAL\"},\"data\": {\"barCodeIds\": [{\"barCodeId\": \"ACC10OFF03212\"},{\"barCodeId\": \"ACC10OFF03213\"}],\"includeExpiryBarcodeStatus\": \"Y\",\"lines\": [{\"mtn\": \"2158806687\"},{\"mtn\": \"3025451824\"}]},\"validateCartRequest\": {\"pageId\": \"CART\",\"retrieveCurrentFeatures\": true}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        UpdateBarcodeUIRequest request = mapper.readValue(requestString, UpdateBarcodeUIRequest.class);
        UpdateBarcodeUIResponse response = mapper.readValue(responseString, UpdateBarcodeUIResponse.class);
        URI url = URI.create("http://localhost/updateBarcode");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.updateBarcode(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.updateBarcode(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void updateMacAddressTest() throws IOException {
        String requestString = "{\"cartId\":\"bea202a6 - 42 cb - 40 d4 - ac87 - d3f1db2b3f13\",\"intendType\":\"EUP\",\"data\":{\"cartId\":\"bea202a6-42cb-40d4-ac87-d3f1db2b3f14\",\"intendType\":\"EUP\",\"lines\":[{\"mtn\":\"5467851254\",\"macAddress\":\"FC6257934C18\"}]}}";
        String responseString = "{\"meta\":{\"timestamp \":1574781308905,\"cxpCorrelationId\":\"2019 - 11 - 26 T09: 15: 08. - 0600: 8e448008 - 8983 - 445 c - 96 f6 - d2717ab03feb: WTX0109ALDITAUX: cxp - cart - domain: nsd2 \"},\"data\":{\"cartId\":\"79 dd4325 - b728 - 4 f03 - 9908 - 9e0 f9dc82f2a\",\"statusCode\":1,\"statusMsg\":\"uccess \",\"preAuthSuccess \":false}}";
        MacAddressUIRequest request = mapper.readValue(requestString, MacAddressUIRequest.class);
        MacAddressUIResponse response = mapper.readValue(responseString, MacAddressUIResponse.class);
        URI url = URI.create("http://localhost/mac-address");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.updateMacAddress(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.updateMacAddress(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateMacAddressBadRequestTest() throws IOException {
        String requestString = "{\"cartId\":\"\",\"intendType\":\"EUP\",\"data\":{\"cartId\":\"bea202a6-42cb-40d4-ac87-d3f1db2b3f14\",\"intendType\":\"EUP\",\"lines\":[{\"mtn\":\"5467851254\",\"macAddress\":\"FC6257934C18\"}]}}";
        MacAddressUIRequest request = mapper.readValue(requestString, MacAddressUIRequest.class);
        URI url = URI.create("http://localhost/mac-address");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.updateMacAddress(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateMacAddressErrorTest() throws IOException {
        String requestString = "{\"cartId\":\"bea202a6 - 42 cb - 40 d4 - ac87 - d3f1db2b3f13\",\"intendType\":\"EUP\",\"data\":{\"cartId\":\"bea202a6-42cb-40d4-ac87-d3f1db2b3f14\",\"intendType\":\"EUP\",\"lines\":[{\"mtn\":\"5467851254\",\"macAddress\":\"FC6257934C18\"}]}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        MacAddressUIRequest request = mapper.readValue(requestString, MacAddressUIRequest.class);
        MacAddressUIResponse response = mapper.readValue(responseString, MacAddressUIResponse.class);
        URI url = URI.create("http://localhost/mac-address");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.updateMacAddress(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.updateMacAddress(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void updateMacAddressErrorTest2() throws IOException {
        String requestString = "{\"cartId\":\"bea202a6 - 42 cb - 40 d4 - ac87 - d3f1db2b3f13\",\"intendType\":\"EUP\",\"data\":{\"cartId\":\"bea202a6-42cb-40d4-ac87-d3f1db2b3f14\",\"intendType\":\"EUP\",\"lines\":[{\"mtn\":\"5467851254\",\"macAddress\":\"FC6257934C18\"}]}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        MacAddressUIRequest request = mapper.readValue(requestString, MacAddressUIRequest.class);
        MacAddressUIResponse response = mapper.readValue(responseString, MacAddressUIResponse.class);
        URI url = URI.create("http://localhost/mac-address");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.valueOf(500));
        when(cartHelper.updateMacAddress(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.updateMacAddress(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }
    @Test
    public void assignMtnTest() throws IOException {
        String requestString = "{\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"accountNumber\": \"0222965595-00001\",\"cartCreator\": \"8437371091\",\"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"caseId\": \"SOP-538499-E01\",\"processingMTN\": \"8436667390\",\"processStep\": \"InterimPage\"},\"data\": {\"lines\": [{\"mtn\": \"newLine1\",\"npaNxx\": \"678-708\"}]}}";
        String responseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \" SOP-1583186-DEV3\",\"customerInfo\": {\"accountNumber\": \"07893451230-00001\",\"cartCreator\": \"2515813861\",\"processingMTN\": \"2515813860\"},\"cartInfo\": {\"cartId\": \"69a66ef4d-7e344dfb-2db299209-ea8333\",\"statusCode\": 1,\"statusMsg\": \"Success\",\"lines\": [{\"mtn\": \"6186979119\",\"lineNumber\": \"newLine1\",\"status\": 1,\"planValidationFailed\": false,\"lineActivityType\": \"AAL\",\"currentPlanType\": \"LLP\",\"devicePlanCompatible\": false}],\"preAuthSuccess\": false}},\"contextInfo\": {\"processAction\": \"\",\"processStep\": \"InterimPage\",\"callReason\": \" SalesOrderPurchase \"}}}}";
        AssignMtnUIRequest request = mapper.readValue(requestString, AssignMtnUIRequest.class);
        AssignMtnUIResponse response = mapper.readValue(responseString, AssignMtnUIResponse.class);
        URI url = URI.create("http://localhost/assign-mtn");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.assignMtn(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.assignMtn(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void assignMtnBadRequestTest() throws IOException {
        String requestString = "{\"cartInfo\": {},\"data\": {\"lines\": [{\"mtn\": \"newLine1\",\"npaNxx\": \"678-708\"}]}}";
        AssignMtnUIRequest request = mapper.readValue(requestString, AssignMtnUIRequest.class);
        URI url = URI.create("http://localhost/assign-mtn");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.assignMtn(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void assignMtnErrorTest() throws IOException {
        String requestString = "{\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"accountNumber\": \"0222965595-00001\",\"cartCreator\": \"8437371091\",\"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"caseId\": \"SOP-538499-E01\",\"processingMTN\": \"8436667390\",\"processStep\": \"InterimPage\"},\"data\": {\"lines\": [{\"mtn\": \"newLine1\",\"npaNxx\": \"678-708\"}]}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        AssignMtnUIRequest request = mapper.readValue(requestString, AssignMtnUIRequest.class);
        AssignMtnUIResponse response = mapper.readValue(responseString, AssignMtnUIResponse.class);
        URI url = URI.create("http://localhost/assign-mtn");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.assignMtn(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.assignMtn(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertEquals(HttpStatus.BAD_REQUEST,resp.getStatusCode())).expectComplete()
                .verify();
    }

    @Test
    public void deassignMtnTest() throws IOException {
        String requestString = "{\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"accountNumber\": \"0222965595-00001\",\"cartCreator\": \"8437371091\",\"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"caseId\": \"SOP-538499-E01\",\"processingMTN\": \"8436667390\",\"processStep\": \"InterimPage\"},\"data\": {\"lines\": [{\"mtn\": \"newLine1\"}]}}";
        String responseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \" SOP-1583186-DEV3\",\"customerInfo\": {\"accountNumber\": \"07893451230-00001\",\"cartCreator\": \"2515813861\",\"processingMTN\": \"2515813860\"},\"cartInfo\": {\"cartId\": \"69a66ef4d-7e344dfb-2db299209-ea8333\",\"statusCode\": 1,\"statusMsg\": \"Success\",\"preAuthSuccess\": false}},\"contextInfo\": {\"processAction\": \"\",\"processStep\": \"InterimPage\",\"callReason\": \" SalesOrderPurchase \"}}}}";
        DeassignMtnUIRequest request = mapper.readValue(requestString, DeassignMtnUIRequest.class);
        DeassignMtnUIResponse response = mapper.readValue(responseString, DeassignMtnUIResponse.class);
        URI url = URI.create("http://localhost/deassign-mtn");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.deassignMtn(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.deassignMtn(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void deassignMtnBadRequestTest() throws IOException {
        String requestString = "{\"cartInfo\": {},\"data\": {\"lines\": [{\"mtn\": \"newLine1\"}]}}";
        DeassignMtnUIRequest request = mapper.readValue(requestString, DeassignMtnUIRequest.class);
        URI url = URI.create("http://localhost/deassign-mtn");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.deassignMtn(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void deassignMtnErrorTest() throws IOException {
        String requestString = "{\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"accountNumber\": \"0222965595-00001\",\"cartCreator\": \"8437371091\",\"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"caseId\": \"SOP-538499-E01\",\"processingMTN\": \"8436667390\",\"processStep\": \"InterimPage\"},\"data\": {\"lines\": [{\"mtn\": \"newLine1\"}]}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        DeassignMtnUIRequest request = mapper.readValue(requestString, DeassignMtnUIRequest.class);
        DeassignMtnUIResponse response = mapper.readValue(responseString, DeassignMtnUIResponse.class);
        URI url = URI.create("http://localhost/deassign-mtn");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.deassignMtn(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.deassignMtn(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }
    @Test
    public void deassignMtnErrorTest2() throws IOException {
        String requestString = "{\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"accountNumber\": \"0222965595-00001\",\"cartCreator\": \"8437371091\",\"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"caseId\": \"SOP-538499-E01\",\"processingMTN\": \"8436667390\",\"processStep\": \"InterimPage\"},\"data\": {\"lines\": [{\"mtn\": \"newLine1\"}]}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        DeassignMtnUIRequest request = mapper.readValue(requestString, DeassignMtnUIRequest.class);
        DeassignMtnUIResponse response = mapper.readValue(responseString, DeassignMtnUIResponse.class);
        URI url = URI.create("http://localhost/deassign-mtn");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.valueOf(500));
        when(cartHelper.deassignMtn(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.deassignMtn(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updatePurchaseOrderTest() throws IOException {
        String requestString = "{\"client\": \"CXP\",\"cartId\": \"\",\"intendType\": \"EUP\",\"itemType\": \"SAVECART\" ,\"purchaseOrderNumber\": \"545566826384\"}";
        String responseString = "{\"data\":{\"cartId\": \"\",\"statusCode\": 1,\"statusMsg\": \"Purchase Order Number Updated successfully\"}}";
        UpdatePurchaseOrderUIRequest request = mapper.readValue(requestString, UpdatePurchaseOrderUIRequest.class);
        UpdatePurchaseOrderUIResponse response = mapper.readValue(responseString, UpdatePurchaseOrderUIResponse.class);
        URI url = URI.create("http://localhost/updatePurchaseOrder");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.updatePurchaseOrder(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.updatePurchaseOrder(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updatePurchaseOrderErrorTest() throws IOException {
        String requestString = "{\"client\": \"CXP\",\"cartId\": \"\",\"intendType\": \"EUP\",\"itemType\": \"SAVECART\" ,\"purchaseOrderNumber\": \"545566826384\"}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        UpdatePurchaseOrderUIRequest request = mapper.readValue(requestString, UpdatePurchaseOrderUIRequest.class);
        UpdatePurchaseOrderUIResponse response = mapper.readValue(responseString, UpdatePurchaseOrderUIResponse.class);
        URI url = URI.create("http://localhost/updatePurchaseOrder");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.updatePurchaseOrder(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.updatePurchaseOrder(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void add5GBulkOrderTest() throws IOException {
        String requestString = "{\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"accountNumber\": \"0222965595-00001\",\"cartCreator\": \"8437371091\",\"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"caseId\": \"SOP-538499-E01\",\"processingMTN\": \"8436667390\",\"processStep\": \"MTNSelectionPage/ShoppingCart/GridWallPDP\",\"processAction\": \"Yet To Receive From PEGA\"},\"data\": {\"lines\": [{\"mtn\": \"newLine1\",\"device\": {\"id\": \"MN382LL/A\",\"contractTerm\": \"VERIZON_EDGE\",\"dppMonths\": 24,\"npaNxx\": \"678708\"},\"ispuFlow\": true,\"depletionType\": \"L\",\"depletionLocationCode\": \"0026301\",\"sddZipCode\": \"30022\",\"newLineOrAAL\": false,\"isKeepingExistingEqProtection\": true}]}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        Add5GBulkOrderUIRequest request = mapper.readValue(requestString, Add5GBulkOrderUIRequest.class);
        Add5GBulkOrderUIResponse response = mapper.readValue(responseString, Add5GBulkOrderUIResponse.class);
        URI url = URI.create("http://localhost/add-fiveGBulkOrder");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.add5GBulkOrder(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.add5GBulkOrder(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void add5GBulkOrderBadRequestTest() throws IOException {
        String requestString = "{\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"accountNumber\": \"0222965595-00001\",\"cartCreator\": \"8437371091\",\"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"caseId\": \"SOP-538499-E01\",\"processingMTN\": \"8436667390\",\"processStep\": \"MTNSelectionPage/ShoppingCart/GridWallPDP\",\"processAction\": \"Yet To Receive From PEGA\"},\"data\": {\"lines\": [{\"mtn\": \"newLine1\",\"device\": {\"id\": \"MN382LL/A\",\"contractTerm\": \"VERIZON_EDGE\",\"dppMonths\": 24,\"npaNxx\": \"678708\"},\"ispuFlow\": true,\"depletionType\": \"\",\"depletionLocationCode\": \"0026301\",\"sddZipCode\": \"30022\",\"newLineOrAAL\": false,\"isKeepingExistingEqProtection\": true}]}}";
        Add5GBulkOrderUIRequest request = mapper.readValue(requestString, Add5GBulkOrderUIRequest.class);
        URI url = URI.create("http://localhost/add-fiveGBulkOrder");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.add5GBulkOrder(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void add5GBulkOrderErrorTest() throws IOException {
        String requestString = "{\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"accountNumber\": \"0222965595-00001\",\"cartCreator\": \"8437371091\",\"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"caseId\": \"SOP-538499-E01\",\"processingMTN\": \"8436667390\",\"processStep\": \"MTNSelectionPage/ShoppingCart/GridWallPDP\",\"processAction\": \"Yet To Receive From PEGA\"},\"data\": {\"lines\": [{\"mtn\": \"newLine1\",\"device\": {\"id\": \"MN382LL/A\",\"contractTerm\": \"VERIZON_EDGE\",\"dppMonths\": 24,\"npaNxx\": \"678708\"},\"ispuFlow\": true,\"depletionType\": \"L\",\"depletionLocationCode\": \"0026301\",\"sddZipCode\": \"30022\",\"newLineOrAAL\": false,\"isKeepingExistingEqProtection\": true}]}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        Add5GBulkOrderUIRequest request = mapper.readValue(requestString, Add5GBulkOrderUIRequest.class);
        Add5GBulkOrderUIResponse response = mapper.readValue(responseString, Add5GBulkOrderUIResponse.class);
        URI url = URI.create("http://localhost/add-fiveGBulkOrder");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.add5GBulkOrder(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.add5GBulkOrder(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void add5GBulkOrderErrorTest2() throws IOException {
        String requestString = "{\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"accountNumber\": \"0222965595-00001\",\"cartCreator\": \"8437371091\",\"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"caseId\": \"SOP-538499-E01\",\"processingMTN\": \"8436667390\",\"processStep\": \"MTNSelectionPage/ShoppingCart/GridWallPDP\",\"processAction\": \"Yet To Receive From PEGA\"},\"data\": {\"lines\": [{\"mtn\": \"newLine1\",\"device\": {\"id\": \"MN382LL/A\",\"contractTerm\": \"VERIZON_EDGE\",\"dppMonths\": 24,\"npaNxx\": \"678708\"},\"ispuFlow\": true,\"depletionType\": \"L\",\"depletionLocationCode\": \"0026301\",\"sddZipCode\": \"30022\",\"newLineOrAAL\": false,\"isKeepingExistingEqProtection\": true}]}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        Add5GBulkOrderUIRequest request = mapper.readValue(requestString, Add5GBulkOrderUIRequest.class);
        Add5GBulkOrderUIResponse response = mapper.readValue(responseString, Add5GBulkOrderUIResponse.class);
        URI url = URI.create("http://localhost/add-fiveGBulkOrder");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-TELESALES").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.valueOf(500));
        when(cartHelper.add5GBulkOrder(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.add5GBulkOrder(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void giftPurchaseTest() throws IOException {
        String requestString = "{\"cartId\": \"3d90b022-30c1-4964-a323-eed35b59e113\",\"intendType\": \"EUP\",\"action\": \"UPDATE\",\"giftPurchaseFlag\": true}";
        String responseString = "{\"meta\": {\"timestamp\": \"2019-08-05T13:27:07Z\",\"cxpCorrelationId\": \"3d5f3c15-aa3b-4a42-9245-5cb4177468e4\"},\"data\": {\"cartId\": \"3d90b022-30c1-4964-a323-eed35b59e113\",\"statusMsg\": \"GiftPurchase updated successfully.\"}}";
        GiftPurchaseUIRequest request = mapper.readValue(requestString, GiftPurchaseUIRequest.class);
        GiftPurchaseUIResponse response = mapper.readValue(responseString, GiftPurchaseUIResponse.class);
        URI url = URI.create("http://localhost/enroll-giftPurchase");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.giftPurchase(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.giftPurchase(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void giftPurchaseErrorTest() throws IOException {
        String requestString = "{\"cartId\": \"3d90b022-30c1-4964-a323-eed35b59e113\",\"intendType\": \"EUP\",\"action\": \"UPDATE\",\"giftPurchaseFlag\": true}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        GiftPurchaseUIRequest request = mapper.readValue(requestString, GiftPurchaseUIRequest.class);
        GiftPurchaseUIResponse response = mapper.readValue(responseString, GiftPurchaseUIResponse.class);
        URI url = URI.create("http://localhost/enroll-giftPurchase");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.giftPurchase(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.giftPurchase(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void revokeRebatesTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"accountNumber\":\"0813238791-00001\",\"cartCreator\":\"9199063857\",\"cartId\":\"96fe593a-523b-4cf2-8dbf-a4a130a15d5e\",\"caseId\":\"SOP-620071-E01\",\"processingMTN\":\"9199063857\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"EUP\"},\"data\":{\"lines\":[{\"mtn\":\"2515813860\",\"rebateUpdate\":{\"id\":\"MN382LL/A\",\"rebateRevoked\":false}}]}}";
        String responseString = "{\"serviceHeader\": {\"clientId\": \"VZW-NETACE\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \" SAP-1583186-DEV3\",\"customerInfo\": {\"accountNumber\": \"07893451230-00001\",\"cartCreator\": \"2515813861\",\"processingMTN\": \"2515813860\"},\"cartInfo\": {\"cartId\": \"69a66ef4d-7e344dfb-2db299209-ea8333\",\"statusCode\": \"1\",\"statusMsg\": \"Updated my offers details successfully\"},\"contextInfo\": {\"processAction\": \"\",\"processStep\": \"OrderReview-Shipping\",\"availablePaths\": [{\"path\": \"OrderReview-Shipping\"}],\"callReason\": \" SalesOrderPurchase \"}}}}}";
        RevokeRebatesUIRequest request = mapper.readValue(requestString, RevokeRebatesUIRequest.class);
        RevokeRebatesUIResponse response = mapper.readValue(responseString, RevokeRebatesUIResponse.class);
        URI url = URI.create("http://localhost/revokeRebates");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.revokeRebates(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.revokeRebates(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void revokeRebatesErrorTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"accountNumber\":\"0813238791-00001\",\"cartCreator\":\"9199063857\",\"cartId\":\"96fe593a-523b-4cf2-8dbf-a4a130a15d5e\",\"caseId\":\"SOP-620071-E01\",\"processingMTN\":\"9199063857\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"EUP\"},\"data\":{\"lines\":[{\"mtn\":\"2515813860\",\"rebateUpdate\":{\"id\":\"MN382LL/A\",\"rebateRevoked\":false}}]}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        RevokeRebatesUIRequest request = mapper.readValue(requestString, RevokeRebatesUIRequest.class);
        RevokeRebatesUIResponse response = mapper.readValue(responseString, RevokeRebatesUIResponse.class);
        URI url = URI.create("http://localhost/revokeRebates");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.revokeRebates(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.revokeRebates(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void revokeRebatesErrorTest2() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"accountNumber\":\"0813238791-00001\",\"cartCreator\":\"9199063857\",\"cartId\":\"96fe593a-523b-4cf2-8dbf-a4a130a15d5e\",\"caseId\":\"SOP-620071-E01\",\"processingMTN\":\"9199063857\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"EUP\"},\"data\":{\"lines\":[{\"mtn\":\"2515813860\",\"rebateUpdate\":{\"id\":\"MN382LL/A\",\"rebateRevoked\":false}}]}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        RevokeRebatesUIRequest request = mapper.readValue(requestString, RevokeRebatesUIRequest.class);
        RevokeRebatesUIResponse response = mapper.readValue(responseString, RevokeRebatesUIResponse.class);
        URI url = URI.create("http://localhost/revokeRebates");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.valueOf(500));
        when(cartHelper.revokeRebates(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.revokeRebates(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updatePortInLaterTest() throws IOException {
        String requestString = "{\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\": \"f2462562-4ebe-455a-9e42-10b1a4e09c9e\",\"caseId\": \"SOP-657002-E01\",\"accountNumber\": \"0200696208-00001\",\"cartCreator\": \"2158800661\",\"processingMTN\": \"2158800661\",\"intendType\": \"BYOD\",\"processStep\": \"InterimPage\"},\"data\": {\"lines\": [{\"mtn\": \"2158801049\",\"portInLater\": true}]}}";
        String responseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \" SOP-1583186-DEV3\",\"customerInfo\": {\"accountNumber\": \"07893451230-00001\",\"cartCreator\": \"2515813861\",\"processingMTN\": \"2515813860\"},\"cartInfo\": {\"cartId\": \"69a66ef4d-7e344dfb-2db299209-ea8333\",\"statusMsg\": \"PortInLater updated successfully.\"},\"contextInfo\": {\"processAction\": \"\",\"processStep\": \"InterimPage\",\"callReason\": \" SalesOrderPurchase \"}}}}}";
        PortinLaterUIRequest request = mapper.readValue(requestString, PortinLaterUIRequest.class);
        PortinLaterUIResponse response = mapper.readValue(responseString, PortinLaterUIResponse.class);
        URI url = URI.create("http://localhost/portInLater");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.updatePortInLater(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.updatePortInLater(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updatePortInLaterErrorTest() throws IOException {
        String requestString = "{\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\": \"f2462562-4ebe-455a-9e42-10b1a4e09c9e\",\"caseId\": \"SOP-657002-E01\",\"accountNumber\": \"0200696208-00001\",\"cartCreator\": \"2158800661\",\"processingMTN\": \"2158800661\",\"intendType\": \"BYOD\",\"processStep\": \"InterimPage\"},\"data\": {\"lines\": [{\"mtn\": \"2158801049\",\"portInLater\": true}]}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        PortinLaterUIRequest request = mapper.readValue(requestString, PortinLaterUIRequest.class);
        PortinLaterUIResponse response = mapper.readValue(responseString, PortinLaterUIResponse.class);
        URI url = URI.create("http://localhost/portInLater");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.updatePortInLater(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.updatePortInLater(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }
    @Test
    public void voidOrderErrorTest2() throws IOException {
        String requestString = "{\"data\": {   \"isIspuItemsInCarts\": true,   \"isDfillItemsInCart\": false,   \"isLocalItemsInCart\": true}}{\"topKey\":\"write1\",\"subKey\":\"demo4\",\"cartId\":\"\",\"caseId\":\"\",\"mtn\":\"\",\"accountNumber\":\"0486105182-00001\",\"device\":{\"id\":\"SMN976VZSV\",\"contractTerm\":\"MONTH_TO_MONTH\",\"dppMonths\":\"\"}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        VoidOrderUIRequest request = mapper.readValue(requestString, VoidOrderUIRequest.class);
        VoidOrderUIResponse response = mapper.readValue(responseString, VoidOrderUIResponse.class);
        URI url = URI.create("http://localhost/voidOrder");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-TELESALES").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.valueOf(500));
        when(cartHelper.voidOrder(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.voidOrder(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updatePortInLaterErrorTest2() throws IOException {
        String requestString = "{\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\": \"f2462562-4ebe-455a-9e42-10b1a4e09c9e\",\"caseId\": \"SOP-657002-E01\",\"accountNumber\": \"0200696208-00001\",\"cartCreator\": \"2158800661\",\"processingMTN\": \"2158800661\",\"intendType\": \"BYOD\",\"processStep\": \"InterimPage\"},\"data\": {\"lines\": [{\"mtn\": \"2158801049\",\"portInLater\": true}]}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        PortinLaterUIRequest request = mapper.readValue(requestString, PortinLaterUIRequest.class);
        PortinLaterUIResponse response = mapper.readValue(responseString, PortinLaterUIResponse.class);
        URI url = URI.create("http://localhost/portInLater");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-TELESALES").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.valueOf(500));
        when(cartHelper.updatePortInLater(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.updatePortInLater(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void voidOrderTest() throws IOException {
        String requestString = "{\"data\": {   \"isIspuItemsInCarts\": true,   \"isDfillItemsInCart\": false,   \"isLocalItemsInCart\": true}}{\"topKey\":\"write1\",\"subKey\":\"demo4\",\"cartId\":\"\",\"caseId\":\"\",\"mtn\":\"\",\"accountNumber\":\"0486105182-00001\",\"device\":{\"id\":\"SMN976VZSV\",\"contractTerm\":\"MONTH_TO_MONTH\",\"dppMonths\":\"\"}}";
        String responseString = "{\"data\": {   \"isIspuItemsInCarts\": true,   \"isDfillItemsInCart\": false,   \"isLocalItemsInCart\": true}}{\"topKey\":\"write1\",\"subKey\":\"demo4\",\"cartId\":\"\",\"caseId\":\"\",\"mtn\":\"\",\"accountNumber\":\"0486105182-00001\",\"device\":{\"id\":\"SMN976VZSV\",\"contractTerm\":\"MONTH_TO_MONTH\",\"dppMonths\":\"\"}}";
        VoidOrderUIRequest request = mapper.readValue(requestString, VoidOrderUIRequest.class);
        VoidOrderUIResponse response = mapper.readValue(responseString, VoidOrderUIResponse.class);
        URI url = URI.create("http://localhost/voidOrder");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.voidOrder(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.voidOrder(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void voidOrderErrorTest() throws IOException {
        String requestString = "{\"data\": {   \"isIspuItemsInCarts\": true,   \"isDfillItemsInCart\": false,   \"isLocalItemsInCart\": true}}{\"topKey\":\"write1\",\"subKey\":\"demo4\",\"cartId\":\"\",\"caseId\":\"\",\"mtn\":\"\",\"accountNumber\":\"0486105182-00001\",\"device\":{\"id\":\"SMN976VZSV\",\"contractTerm\":\"MONTH_TO_MONTH\",\"dppMonths\":\"\"}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        VoidOrderUIRequest request = mapper.readValue(requestString, VoidOrderUIRequest.class);
        VoidOrderUIResponse response = mapper.readValue(responseString, VoidOrderUIResponse.class);
        URI url = URI.create("http://localhost/voidOrder");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.voidOrder(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.voidOrder(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void ispuToDfillTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f2462562-4ebe-455a-9e42-10b1a4e09c9e\",\"caseId\":\"SOP-657002-E01\",\"accountNumber\":\"0200696208-00001\",\"cartCreator\":\"2158800661\",\"processingMTN\":\"2158800661\",\"intendType\":\"EUP\",\"processStep\":\"GridWallPDP\"},\"data\":{\"lines\":[{\"mtn\":\"2158801049\"}]}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"PEGA generated message\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\" SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\"]},{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}],\"cartInfo\":{\"cartId\":\"3ef39561-697e-486c-befc-4996c8a6921f\",\"statusCode\":1,\"statusMsg\":\"Success\",\"preAuthSuccess\":false,\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"financeLimitExceeded\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":0,\"agreementNumber\":0},\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"GridWallPDP\",\"availablePaths\":[{\"path\":\"ShoppingCart`\"},{\"path\":\"addDevice\"},{\"path\":\"addFeatures`\"},{\"path\":\"showFeatures\"},{\"path\":\"showDevice`\"},{\"path\":\"showAccessory\"},{\"path\":\"addAccessory\"},{\"path\":\"TradeIn\"}],\"callReason\":\" SalesOrderPurchase \"}}}}}";
        IspuToDfillUIRequest request = mapper.readValue(requestString, IspuToDfillUIRequest.class);
        IspuToDfillUIResponse response = mapper.readValue(responseString, IspuToDfillUIResponse.class);
        URI url = URI.create("http://localhost/ispuToDfill");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.ispuToDfill(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.ispuToDfill(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void ispuToDfillErrorTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f2462562-4ebe-455a-9e42-10b1a4e09c9e\",\"caseId\":\"SOP-657002-E01\",\"accountNumber\":\"0200696208-00001\",\"cartCreator\":\"2158800661\",\"processingMTN\":\"2158800661\",\"intendType\":\"EUP\",\"processStep\":\"GridWallPDP\"},\"data\":{\"lines\":[{\"mtn\":\"2158801049\"}]}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        IspuToDfillUIRequest request = mapper.readValue(requestString, IspuToDfillUIRequest.class);
        IspuToDfillUIResponse response = mapper.readValue(responseString, IspuToDfillUIResponse.class);
        URI url = URI.create("http://localhost/ispuToDfill");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.ispuToDfill(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.ispuToDfill(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void ispuToDfillErrorTest2() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f2462562-4ebe-455a-9e42-10b1a4e09c9e\",\"caseId\":\"SOP-657002-E01\",\"accountNumber\":\"0200696208-00001\",\"cartCreator\":\"2158800661\",\"processingMTN\":\"2158800661\",\"intendType\":\"EUP\",\"processStep\":\"GridWallPDP\"},\"data\":{\"lines\":[{\"mtn\":\"2158801049\"}]}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        IspuToDfillUIRequest request = mapper.readValue(requestString, IspuToDfillUIRequest.class);
        IspuToDfillUIResponse response = mapper.readValue(responseString, IspuToDfillUIResponse.class);
        URI url = URI.create("http://localhost/ispuToDfill");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-TELESALES").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.valueOf(500));
        when(cartHelper.ispuToDfill(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.ispuToDfill(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }


    @Test
    public void manualPairingTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f2462562-4ebe-455a-9e42-10b1a4e09c9e\",\"caseId\":\"SOP-657002-E01\",\"accountNumber\":\"0200696208-00001\",\"cartCreator\":\"2158800661\",\"processingMTN\":\"2158800661\",\"intendType\":\"EUP\",\"processStep\":\"GridWallPDP\"},\"data\":{\"lines\":[{\"mtn\":\"2158801049\"}]}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"PEGA generated message\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\" SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\"]},{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}],\"cartInfo\":{\"cartId\":\"3ef39561-697e-486c-befc-4996c8a6921f\",\"statusCode\":1,\"statusMsg\":\"Success\",\"preAuthSuccess\":false,\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"financeLimitExceeded\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":0,\"agreementNumber\":0},\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"GridWallPDP\",\"availablePaths\":[{\"path\":\"ShoppingCart`\"},{\"path\":\"addDevice\"},{\"path\":\"addFeatures`\"},{\"path\":\"showFeatures\"},{\"path\":\"showDevice`\"},{\"path\":\"showAccessory\"},{\"path\":\"addAccessory\"},{\"path\":\"TradeIn\"}],\"callReason\":\" SalesOrderPurchase \"}}}}}";
        ManualPairingUIRequest request = mapper.readValue(requestString, ManualPairingUIRequest.class);
        ManualPairingUIResponse response = mapper.readValue(responseString, ManualPairingUIResponse.class);
        URI url = URI.create("http://localhost/manual-pairing");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.manualPairing(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.manualPairing(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void manualPairingErrorTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f2462562-4ebe-455a-9e42-10b1a4e09c9e\",\"caseId\":\"SOP-657002-E01\",\"accountNumber\":\"0200696208-00001\",\"cartCreator\":\"2158800661\",\"processingMTN\":\"2158800661\",\"intendType\":\"EUP\",\"processStep\":\"GridWallPDP\"},\"data\":{\"lines\":[{\"mtn\":\"2158801049\"}]}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        ManualPairingUIRequest request = mapper.readValue(requestString, ManualPairingUIRequest.class);
        ManualPairingUIResponse response = mapper.readValue(responseString, ManualPairingUIResponse.class);
        URI url = URI.create("http://localhost/manual-pairing");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.manualPairing(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.manualPairing(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void splitExceededAmountTest() throws IOException {
        String requestString = "{ \"cartInfo\": { \"clientAppName\": \"VZW-NETACE\", \"cartId\": \"f61a7954-4300-4e97-9478-f001475bdf9b\", \"caseId\": \"SOP-508208-E01\", \"accountNumber\": \"0420194063-00001\", \"cartCreator\": \"4235342870\", \"processingMTN\": \"4235344191\", \"processStep\": \"DownPayment\", \"intendType\": \"AAL/EUP\" } }";
        String responseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-ECOM\", \"statusMsg\": \"PEGA generated message\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"sessionId\": \"\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"0\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \" SOP-1583186-DEV3\", \"customerInfo\": { \"accountNumber\": \"07893451230-00001\", \"cartCreator\": \"2515813861\", \"processingMTN\": \"2515813860\" }, \"processMTNList\": [{ \"mtn\": \"2515813860\", \"completedprocessSteps\": [\"MTNSelectionPage\", \"GridWallPDP\"] }, { \"mtn\": \"2515813861\", \"completedprocessSteps\": [] }], \"cartInfo\": { \"cartId\": \"a705f835-c61a-4e20-b616-0c9839202a15\", \"statusCode\": \"1\", \"statusMsg\": \"\"  }, \"contextInfo\": { \"processAction\": \"\", \"processStep\": \"DownPayment\", \"availablePaths\": [{ \"path\": \" DownPayment `\" }], \"callReason\": \" SalesOrderPurchase \" } } } } }";
        SplitExceededAmountUIRequest request = mapper.readValue(requestString, SplitExceededAmountUIRequest.class);
        SplitExceededAmountUIResponse response = mapper.readValue(responseString, SplitExceededAmountUIResponse.class);
        URI url = URI.create("http://localhost/splitExceededAmount");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.splitExceededAmount(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.splitExceededAmount(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void splitExceededAmountErrorTest() throws IOException {
        String requestString = "{ \"cartInfo\": { \"clientAppName\": \"VZW-NETACE\", \"cartId\": \"f61a7954-4300-4e97-9478-f001475bdf9b\", \"caseId\": \"SOP-508208-E01\", \"accountNumber\": \"0420194063-00001\", \"cartCreator\": \"4235342870\", \"processingMTN\": \"4235344191\", \"processStep\": \"DownPayment\", \"intendType\": \"AAL/EUP\" } }";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        SplitExceededAmountUIRequest request = mapper.readValue(requestString, SplitExceededAmountUIRequest.class);
        SplitExceededAmountUIResponse response = mapper.readValue(responseString, SplitExceededAmountUIResponse.class);
        URI url = URI.create("http://localhost/splitExceededAmount");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.splitExceededAmount(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.splitExceededAmount(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void cancelCaseTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE/VZW-ECOM\",\"caseId\":\"SOP-329-E01\",\"accountNumber\":\"0820215913-00001\",\"cartCreator\":\"6154839959\",\"processStep\":\"cancel\"}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"processStep\":\"Close\",\"callReason\":\"SalesOrderPurchase\"},\"caseId\":\"SOP-521102-E01\",\"customerInfo\":{\"accountNumber\":\"0100003375-00001\"}}}}}";
        CancelCaseUIRequest request = mapper.readValue(requestString, CancelCaseUIRequest.class);
        CancelCaseUIResponse response = mapper.readValue(responseString, CancelCaseUIResponse.class);
        URI url = URI.create("http://localhost/cancelCase");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.cancelCase(any())).thenReturn(Mono.just(response));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.cancelCase(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void cancelCaseErrorTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE/VZW-ECOM\",\"caseId\":\"SOP-329-E01\",\"accountNumber\":\"0820215913-00001\",\"cartCreator\":\"6154839959\",\"processStep\":\"cancel\"}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        CancelCaseUIRequest request = mapper.readValue(requestString, CancelCaseUIRequest.class);
        CancelCaseUIResponse response = mapper.readValue(responseString, CancelCaseUIResponse.class);
        URI url = URI.create("http://localhost/cancelCase");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.cancelCase(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.cancelCase(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void calculateMultiLineTaxForCartTest() throws IOException {
        String requestString = "{\"cartId\":\"fbcda2fc-41a4-41d7-a8fa-037fb4144de4\",\"zipCode\":\"08831\"}";
        String responseString = "{\"meta\":{\"timestamp\":1579894455409,\"cxpCorrelationId\":\"2020-01-24T14:34:15.-0500:d8d8d761-9f80-4b1e-afa7-e3de05a95a8b:WNJ10002LDVSLAW:'cxp-application':local\"},\"data\":{\"retrieveURCforCart\":{\"mtnUpgradeReasonCodes\":[{\"mtn\":\"9892934876\",\"upgradeReasonCodes\":[{\"code\":\"MN\",\"description\":\"Managerapproval-m2m\",\"defaultReasonCode\":false,\"contractTermDetails\":{\"contractTerm\":\"MONTH_TO_MONTH\",\"contractTermId\":48,\"monthToMonth\":true,\"oneYear\":false,\"twoYear\":false,\"devicePayment\":false}},{\"code\":\"UN\",\"description\":\"Upgrade,Nodiscount\",\"defaultReasonCode\":false,\"contractTermDetails\":{\"contractTerm\":\"MONTH_TO_MONTH\",\"contractTermId\":48,\"monthToMonth\":true,\"oneYear\":false,\"twoYear\":false,\"devicePayment\":false}},{\"code\":\"EA\",\"description\":\"DevicePaymentUpgrade\",\"defaultReasonCode\":false,\"contractTermDetails\":{\"contractTerm\":\"VERIZON_EDGE\",\"contractTermId\":48,\"monthToMonth\":false,\"oneYear\":false,\"twoYear\":false,\"devicePayment\":true}},{\"code\":\"CE\",\"description\":\"CUSTOMERPROVIDEDEQUIPMENT\",\"defaultReasonCode\":false,\"contractTermDetails\":{\"contractTerm\":\"MONTH_TO_MONTH\",\"contractTermId\":48,\"monthToMonth\":true,\"oneYear\":false,\"twoYear\":false,\"devicePayment\":false}}]}]}}}";
        CalculateMultilineTaxUIRequest request = mapper.readValue(requestString, CalculateMultilineTaxUIRequest.class);
        CalculateMultilineTaxUIResponse response = mapper.readValue(responseString,
                CalculateMultilineTaxUIResponse.class);
        URI url = URI.create("http://localhost/calculateMultiLineTaxForCart");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.calculateMultiLineTaxForCart(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2
                .calculateMultiLineTaxForCart(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void calculateMultiLineTaxForCartErrorTest() throws IOException {
        String requestString = "{\"cartId\":\"fbcda2fc-41a4-41d7-a8fa-037fb4144de4\",\"zipCode\":\"08831\"}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        CalculateMultilineTaxUIRequest request = mapper.readValue(requestString, CalculateMultilineTaxUIRequest.class);
        CalculateMultilineTaxUIResponse response = mapper.readValue(responseString,
                CalculateMultilineTaxUIResponse.class);
        URI url = URI.create("http://localhost/calculateMultiLineTaxForCart");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.calculateMultiLineTaxForCart(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2
                .calculateMultiLineTaxForCart(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void calculateMultiLineTaxForCartNSETest() throws IOException {
        String requestString = "{\"cartId\":\"fbcda2fc-41a4-41d7-a8fa-037fb4144de4\",\"zipCode\":\"08831\"}";
        String responseString = "{\"meta\":{\"timestamp\":1579894455409,\"cxpCorrelationId\":\"2020-01-24T14:34:15.-0500:d8d8d761-9f80-4b1e-afa7-e3de05a95a8b:WNJ10002LDVSLAW:'cxp-application':local\"},\"data\":{\"retrieveURCforCart\":{\"mtnUpgradeReasonCodes\":[{\"mtn\":\"9892934876\",\"upgradeReasonCodes\":[{\"code\":\"MN\",\"description\":\"Managerapproval-m2m\",\"defaultReasonCode\":false,\"contractTermDetails\":{\"contractTerm\":\"MONTH_TO_MONTH\",\"contractTermId\":48,\"monthToMonth\":true,\"oneYear\":false,\"twoYear\":false,\"devicePayment\":false}},{\"code\":\"UN\",\"description\":\"Upgrade,Nodiscount\",\"defaultReasonCode\":false,\"contractTermDetails\":{\"contractTerm\":\"MONTH_TO_MONTH\",\"contractTermId\":48,\"monthToMonth\":true,\"oneYear\":false,\"twoYear\":false,\"devicePayment\":false}},{\"code\":\"EA\",\"description\":\"DevicePaymentUpgrade\",\"defaultReasonCode\":false,\"contractTermDetails\":{\"contractTerm\":\"VERIZON_EDGE\",\"contractTermId\":48,\"monthToMonth\":false,\"oneYear\":false,\"twoYear\":false,\"devicePayment\":true}},{\"code\":\"CE\",\"description\":\"CUSTOMERPROVIDEDEQUIPMENT\",\"defaultReasonCode\":false,\"contractTermDetails\":{\"contractTerm\":\"MONTH_TO_MONTH\",\"contractTermId\":48,\"monthToMonth\":true,\"oneYear\":false,\"twoYear\":false,\"devicePayment\":false}}]}]}}}";
        CalculateMultilineTaxUIRequest request = mapper.readValue(requestString, CalculateMultilineTaxUIRequest.class);
        CalculateMultilineTaxUIResponse response = mapper.readValue(responseString,
                CalculateMultilineTaxUIResponse.class);
        URI url = URI.create("http://localhost/nse/calculateMultiLineTaxForCart");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.calculateMultiLineTaxForCart(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2
                .calculateMultiLineTaxForCart(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceWithEdgeupTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\",\"caseId\":\"SOP-329-E01\",\"accountNumber\":\"0820215913-00001\",\"cartCreator\":\"6154839959\",\"processingMTN\":\"6154839959\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"intendType\":\"EUP\",\"mtnFlow\":\"G\"},\"data\":{\"lines\":[{\"mtn\":\"2059376950\",\"isEdgeBuyOut\":true,\"edgeup\":{\"deviceId\":\"353338070105553\"},\"tradeInPromoSelected\":\"promo123\"}]}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/addDeviceWithEdgeup");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController2,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addDeviceWithEdgeup(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceWithEdgeupTwoMDNTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"2565085920\",\"processStep\":\"DPPSummary\",\"buyOutFlag\":\"Y\",\"intendType\":\"EUP\",\"buyOutSelected\":\"N\",\"edgeUpSelected\":\"Y\",\"FMITurnedoff\":\"Y\",\"deviceMisMatched\":\"N\",\"processAction\":\"addEdgeUpAmtAndDevice\",\"mtnFlow\":\"G\"},\"data\":{\"lines\":[{\"mtn\":\"2565085920\",\"isEdgeBuyOut\":true,\"edgeup\":{\"deviceId\":\"350577192117748\",\"edgeupAmount\":\"$111.06\"},\"secondNumber\":{\"isSecondNumber\":true,\"primaryMtn\":\"2565085920\",\"secondMtn\":\"2568199318\"}}],\"effectiveDate\":\"\"}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2024.08.01.13.31.10-832.0825250463138\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-15262189-C01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"DeviceConfigurator\"},{\"path\":\"AccessoryInterestial\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"DeviceConfigurator\",\"processAction\":\"addEdgeUpAmtAndDevice\"},\"customerInfo\":{\"nocByod\":false,\"accountNumber\":\"0283148327-00001\",\"cartCreator\":\"2566564067\",\"processingMTN\":\"2565085920\",\"registerNumber\":0,\"noc\":false,\"myvPage\":false},\"cartInfo\":{\"financeLimitExceeded\":\"false\",\"cartItemCount\":2,\"totalDueToday\":111.06,\"totalDueMonthly\":0.0,\"cartId\":\"8baa501c-4a36-43cb-8ee5-94c45305e5c7\",\"statusMsg\":\"Transaction processed successfully\",\"statusCode\":\"1\",\"lines\":[{\"status\":1,\"spos\":[{\"id\":\"1958\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"3039\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]}],\"sfos\":[{\"id\":\"86905\",\"conflict\":\"SFO dropped because of requal - ESN chg\",\"actionIndicator\":\"D\",\"displayHumWiFi\":false}],\"firstMonthInstallment\":25.94,\"monthlyInstallment\":25.83,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"BIC\",\"eupNoPromoFlow\":false,\"lineSubscriptionInfos\":[],\"mtn\":\"2565085920\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MTM43LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"929.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 15\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0,\"isNonVZDeviceSku\":false,\"skuId\":\"sku6004567\",\"skuDisplayName\":\"Apple iPhone 15 256 GB in Black\",\"isDfoSelected\":false},\"sim\":{\"id\":\"UNIVESIM5G-SAB-D\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"EUP\",\"currentPlanType\":\"LLP\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false,\"skipPromoChoiceOffer\":false},{\"status\":1,\"spos\":[{\"id\":\"1958\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]}],\"sfos\":[{\"id\":\"86905\",\"conflict\":\"SFO dropped because of requal - ESN chg\",\"actionIndicator\":\"D\",\"displayHumWiFi\":false}],\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"BIC\",\"eupNoPromoFlow\":false,\"lineSubscriptionInfos\":[],\"mtn\":\"2568199318\",\"device\":{\"upgradeReasonCode\":\"CE\",\"id\":\"MTM43LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"0.0\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 15\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0,\"isNonVZDeviceSku\":false,\"skuId\":\"sku6004567\",\"skuDisplayName\":\"Apple iPhone 15 256 GB in Black\",\"isDfoSelected\":false},\"sim\":{\"id\":\"UNIVESIM5G-SAB-D\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"EUPBYOD\",\"currentPlanType\":\"LLP\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false,\"skipPromoChoiceOffer\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"1780085662\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":true,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"5108368\",\"protectionNotRequired\":false,\"fmiCheck\":false,\"lineDevices\":[{\"mtn\":\"2565085920\",\"deviceCategory\":\"Smartphones\",\"lineActivityType\":\"EUP\",\"multiLineSeqNumber\":1},{\"mtn\":\"2568199318\",\"deviceCategory\":\"Smartphones\",\"lineActivityType\":\"EUPBYOD\",\"multiLineSeqNumber\":2}],\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false,\"instantCreditAmount\":0,\"ngdFlow\":false},\"processMTNList\":[{\"mtn\":\"2565085920\",\"completedprocessSteps\":[\"GridWallPDP\",\"MTNSelectionPage\",\"DPPSummary\",\"MTNSelectionPage\",\"PromoHub\",\"Initiate\",\"GridWallPDP\",\"GridWallPDP\",\"DPPSummary\",\"DPPSummary\"]}]}}}}";
        String redisDataString = "{\"cartId\":\"8baa501c-4a36-43cb-8ee5-94c45305e5c7\",\"caseId\":\"SOP-15262189-C01\",\"accountNumber\":\"0283148327-00001\",\"mtn\":\"2566564067\",\"processingMTN\":\"2565085920\",\"vzwRoles\":\"accountManager\",\"sessionId\":\"00243e5f-1950-4895-bd6b-f27f9eb40140\",\"intendType\":\"EUP\",\"cartCreator\":\"2566564067\",\"lines\":[{\"restricted\":\"\",\"selectedSedOfferId\":\"554871\",\"purchasePath\":\"EUP\",\"selectedPromoType\":\"BIC\",\"selectedPromoId\":\"promo3730541\",\"eupNoPromoFlow\":false,\"mtn\":\"2565085920\",\"portInNumber\":\"\",\"device\":{\"category\":\"Smartphones\",\"id\":\"MTM43LL/A\",\"dppMonths\":36,\"contractTerm\":\"VERIZON_EDGE\",\"qty\":1,\"productId\":\"dev21410694\",\"iconicPhone\":true,\"preconfigure\":\"false\",\"skipImei1Call\":false,\"amount\":0.0,\"isNonVZDeviceSku\":false,\"isDfoSelected\":false},\"sim\":{\"id\":\"UNIVESIM5G-SAB-D\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"newLineOrAAL\":false,\"isNewLine\":false,\"isStrategicOffer\":false,\"estimatedReadyByDate\":\"\",\"promoRejectionIndicator\":true,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"isCommonPDP\":true,\"isTradeInIntentSelected\":false,\"isByod\":false,\"skipPromoChoiceOffer\":false},{\"restricted\":\"\",\"selectedSedOfferId\":\"\",\"purchasePath\":\"EUPBYOD\",\"selectedPromoType\":\"NOPROMO\",\"selectedPromoId\":\"\",\"eupNoPromoFlow\":false,\"secondNumber\":{\"isSecondNumber\":true,\"primaryMtn\":\"2565085920\",\"secondMtn\":\"2568199318\"},\"mtn\":\"2568199318\",\"portInNumber\":\"\",\"device\":{\"category\":\"Smartphones\",\"id\":\"MTM43LL/A\",\"dppMonths\":36,\"contractTerm\":\"VERIZON_EDGE\",\"qty\":1,\"productId\":\"dev21410694\",\"iconicPhone\":true,\"preconfigure\":\"false\",\"skipImei1Call\":false,\"amount\":0.0,\"isNonVZDeviceSku\":false,\"isDfoSelected\":false},\"sim\":{\"id\":\"UNIVESIM5G-SAB-D\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"newLineOrAAL\":false,\"isNewLine\":false,\"estimatedReadyByDate\":\"\",\"promoRejectionIndicator\":true,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"isCommonPDP\":true,\"isTradeInIntentSelected\":false,\"isByod\":false,\"skipPromoChoiceOffer\":false}],\"mtnFlow\":\"M\",\"cartCount\":\"2\",\"cartOrderFlowType\":\"eup\",\"isSmartphone\":false,\"isAppleDevice\":false,\"safeTechSessionId\":\"8d59362dbdd14e60b5ef2cb8\",\"creditCheckFailedCount\":0,\"isCommonPDP\":true,\"jointTransactionMobileCartId\":\"8baa501c-4a36-43cb-8ee5-94c45305e5c7\",\"jointTransactionMobileCaseId\":\"SOP-15262189-C01\",\"cradleFlowJourney\":\"NEXTGEN_EC\",\"uid\":\"2566564067regTool\",\"isfiveGUpSellSelected\":false,\"existingCase\":\"false\",\"isDirectApply\":false}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/addDeviceWithEdgeup");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController2,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addDeviceWithEdgeup(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceWithEdgeupErrorTest() throws IOException {
        String requestString = "{ \"cartInfo\": { \"clientAppName\": \"VZW-NETACE\", \"cartId\": \"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\", \"caseId\": \"SOP-329-E01\", \"accountNumber\": \"0820215913-00001\", \"cartCreator\": \"6154839959\", \"processingMTN\": \"6154839959\", \"processStep\": \"MTNSelectionPage/ShoppingCart\", \"intendType\": \"EUP\", \"mtnFlow\":\"G\" }, \"data\": { \"lines\": [ { \"mtn\": \"2059376950\", \"isEdgeBuyOut\":true, \"edgeup\":{ \"deviceId\":\"353338070105553\" } } ] } }";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/addDeviceWithEdgeup");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController2,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addDeviceWithEdgeup(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void activateLaterTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"34dcd4a0-b22c-4230-b060-bb7e74350722\",\"caseId\":\"SOP-1220327-E01\",\"accountNumber\":\"0302866881-00001\",\"cartCreator\":\"4102418760\",\"processStep\":\"OrderReview-Shipping\",\"processingMTN\":\"4346324850\",\"processAction\":\"SetUpLater\",\"intendType\":\"AAL\"},\"data\":{\"lines\":[{\"mtn\":\"4346324850\",\"activateLater\":true,\"setUpLater\":true}]}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"processStep\":\"Close\",\"callReason\":\"SalesOrderPurchase\"},\"caseId\":\"SOP-521102-E01\",\"customerInfo\":{\"accountNumber\":\"0100003375-00001\"}}}}}";
        ActivateLaterUIRequest request = mapper.readValue(requestString, ActivateLaterUIRequest.class);
        ActivateLaterUIResponse response = mapper.readValue(responseString, ActivateLaterUIResponse.class);
        URI url = URI.create("http://localhost/activateOrSetupLater");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.activateOrSetupLater(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.activateOrSetupLater(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void activateLaterErrorTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"34dcd4a0-b22c-4230-b060-bb7e74350722\",\"caseId\":\"SOP-1220327-E01\",\"accountNumber\":\"0302866881-00001\",\"cartCreator\":\"4102418760\",\"processStep\":\"OrderReview-Shipping\",\"processingMTN\":\"4346324850\",\"processAction\":\"SetUpLater\",\"intendType\":\"AAL\"},\"data\":{\"lines\":[{\"mtn\":\"4346324850\",\"activateLater\":true,\"setUpLater\":true}]}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        ActivateLaterUIRequest request = mapper.readValue(requestString, ActivateLaterUIRequest.class);
        ActivateLaterUIResponse response = mapper.readValue(responseString, ActivateLaterUIResponse.class);
        URI url = URI.create("http://localhost/activateOrSetupLater");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.activateOrSetupLater(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.activateOrSetupLater(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void addDeviceWithBuyOutTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\",\"caseId\":\"SOP-329-E01\",\"accountNumber\":\"0820215913-00001\",\"cartCreator\":\"6154839959\",\"processingMTN\":\"6154839959\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"intendType\":\"EUP\",\"mtnFlow\":\"G\"},\"data\":{\"lines\":[{\"mtn\":\"2059376950\",\"isEdgeBuyOut\":true,\"tradeInPromoSelected\":\"promo123\"}]}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/addDeviceWithBuyout");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        when(featureFlagHelper.isTradeInPromoCheckFflagEnabled()).thenReturn(Mono.just(Boolean.TRUE));
        when(featureFlagHelper.isSkipResumeCaseFFlagEnabled()).thenReturn(Mono.just(Boolean.TRUE));
        ReflectionTestUtils.setField(cartController2,"domains",List.of(".verizon.com",".verizonwireless.com"));
          Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addDeviceWithBuyout(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceWithBuyOutErrorTest() throws IOException {
        String requestString = "{ \"cartInfo\": { \"clientAppName\": \"VZW-NETACE\", \"cartId\": \"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\", \"caseId\": \"SOP-329-E01\", \"accountNumber\": \"0820215913-00001\", \"cartCreator\": \"6154839959\", \"processingMTN\": \"6154839959\", \"processStep\": \"MTNSelectionPage/ShoppingCart\", \"intendType\": \"EUP\", \"mtnFlow\":\"G\" }, \"data\": { \"lines\": [ { \"mtn\": \"2059376950\", \"isEdgeBuyOut\":true} ] } }";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/addDeviceWithBuyout");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse =  new MockServerHttpResponse();
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        when(featureFlagHelper.isTradeInPromoCheckFflagEnabled()).thenReturn(Mono.just(Boolean.FALSE));
        when(featureFlagHelper.isSkipResumeCaseFFlagEnabled()).thenReturn(Mono.just(Boolean.FALSE));
        ReflectionTestUtils.setField(cartController2,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addDeviceWithBuyout(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void addTransferUpgradeTest() throws IOException {
        String requestString = "{        \"cartInfo\": {                \"clientAppName\": \"VZW-NETACE\",                \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",                \"cartId\": \"4c4a9307-ebc1-4f51-a350-a6438b825dcb\",                \"caseId\": \"SOP-659808-E01\",                \"accountNumber\": \"0285560011-00001\",                \"cartCreator\": \"2018702013\",                \"processingMTN\": \"2018702013\",                \"processStep\": \"TransferUpgrade\",                \"intendType\": \"EUP\"        },        \"data\": {                \"lines\": [{                        \"mtn\": \"2018702013\",                        \"donorMtn\": \"2018702013\"                }]        }}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        UpdateTransferUpgradeUIRequest request = mapper.readValue(requestString, UpdateTransferUpgradeUIRequest.class);
        UpdateTransferUpgradeUIResponse response = mapper.readValue(responseString,
                UpdateTransferUpgradeUIResponse.class);
        URI url = URI.create("http://localhost/addTransferUpgrade");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(redisHelper.upsertAlternateUpgradeDataIntoRedis(any())).thenReturn(Mono.just(true));
        when(cartHelper.addTransferUpgrade(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addTransferUpgrade(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addTransferUpgradeErrorTest() throws IOException {
        String requestString = "{        \"cartInfo\": {                \"clientAppName\": \"VZW-NETACE\",                \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",                \"cartId\": \"4c4a9307-ebc1-4f51-a350-a6438b825dcb\",                \"caseId\": \"SOP-659808-E01\",                \"accountNumber\": \"0285560011-00001\",                \"cartCreator\": \"2018702013\",                \"processingMTN\": \"2018702013\",                \"processStep\": \"TransferUpgrade\",                \"intendType\": \"EUP\"        },        \"data\": {                \"lines\": [{                        \"mtn\": \"2018702013\",                        \"donorMtn\": \"2018702013\"                }]        }}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        UpdateTransferUpgradeUIRequest request = mapper.readValue(requestString, UpdateTransferUpgradeUIRequest.class);
        UpdateTransferUpgradeUIResponse response = mapper.readValue(responseString,
                UpdateTransferUpgradeUIResponse.class);
        URI url = URI.create("http://localhost/addTransferUpgrade");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(redisHelper.upsertAlternateUpgradeDataIntoRedis(any())).thenReturn(Mono.just(true));
        when(cartHelper.addTransferUpgrade(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addTransferUpgrade(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void removeTransferUpgradeTest() throws IOException {
        String requestString = "{        \"cartInfo\": {                \"clientAppName\": \"VZW-NETACE\",                \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",                \"cartId\": \"4c4a9307-ebc1-4f51-a350-a6438b825dcb\",                \"caseId\": \"SOP-659808-E01\",                \"accountNumber\": \"0285560011-00001\",                \"cartCreator\": \"2018702013\",                \"processingMTN\": \"2018702013\",                \"processStep\": \"TransferUpgrade\",                \"intendType\": \"EUP\"        },        \"data\": {                \"lines\": [{                        \"mtn\": \"2018702013\"    }]        }}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        UpdateTransferUpgradeUIRequest request = mapper.readValue(requestString, UpdateTransferUpgradeUIRequest.class);
        UpdateTransferUpgradeUIResponse response = mapper.readValue(responseString,
                UpdateTransferUpgradeUIResponse.class);
        URI url = URI.create("http://localhost/removeTransferUpgrade");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(redisHelper.deleteAlternateUpgradeDataIntoRedis(any())).thenReturn(Mono.just(1L));
        when(cartHelper.removeTransferUpgrade(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.removeTransferUpgrade(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void removeTransferUpgradeErrorTest() throws IOException {
        String requestString = "{        \"cartInfo\": {                \"clientAppName\": \"VZW-NETACE\",                \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",                \"cartId\": \"4c4a9307-ebc1-4f51-a350-a6438b825dcb\",                \"caseId\": \"SOP-659808-E01\",                \"accountNumber\": \"0285560011-00001\",                \"cartCreator\": \"2018702013\",                \"processingMTN\": \"2018702013\",                \"processStep\": \"TransferUpgrade\",                \"intendType\": \"EUP\"        },        \"data\": {                \"lines\": [{                        \"mtn\": \"2018702013\",                        \"donorMtn\": \"2018702013\"                }]        }}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        UpdateTransferUpgradeUIRequest request = mapper.readValue(requestString, UpdateTransferUpgradeUIRequest.class);
        UpdateTransferUpgradeUIResponse response = mapper.readValue(responseString,
                UpdateTransferUpgradeUIResponse.class);
        URI url = URI.create("http://localhost/addTransferUpgrade");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(redisHelper.deleteAlternateUpgradeDataIntoRedis(any())).thenReturn(Mono.just(1L));
        when(cartHelper.addTransferUpgrade(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addTransferUpgrade(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void updateVZCCAppStatusTest() throws IOException {
        String requestString = "{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"status\":\"apply\"}";
        String responseString = "{\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"statusMsg\":\"Success\"}}";
        VZCCAppStatusUIRequest request = mapper.readValue(requestString, VZCCAppStatusUIRequest.class);
        VZCCAppStatusUIResponse response = mapper.readValue(responseString, VZCCAppStatusUIResponse.class);
        URI url = URI.create("http://localhost/vzccAppStatus");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.updateVZCCAppStatus(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.updateVZCCAppStatus(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateVZCCAppStatusErrorTest() throws IOException {
        String requestString = "{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"status\":\"apply\"}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        VZCCAppStatusUIRequest request = mapper.readValue(requestString, VZCCAppStatusUIRequest.class);
        VZCCAppStatusUIResponse response = mapper.readValue(responseString, VZCCAppStatusUIResponse.class);
        URI url = URI.create("http://localhost/vzccAppStatus");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.updateVZCCAppStatus(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.updateVZCCAppStatus(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void getBrandsTest() throws IOException {
        URI url = URI.create("http://localhost/getBrands");
        when(cartServiceCXPHelper.getBrands(new GetBrandsRequest())).thenReturn(Mono.just(new Brands()));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.getBrands(new GetBrandsRequest());
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateChatIdControllerTest() throws IOException {
        String requestString = "{\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\": \"4c4a9307-ebc1-4f51-a350-a6438b825dcb\",\"caseId\": \"SOP-659808-E01\",\"accountNumber\": \"0285560011-00001\",\"cartCreator\": \"2018702013\",\"processingMTN\": \"2018702013\",\"processStep\": \"TransferUpgrade\",\"intendType\": \"EUP\"},\"chatId\": \"2018702013\"}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        UpdateChatIdUIRequest request = mapper.readValue(requestString, UpdateChatIdUIRequest.class);
        UpdateChatIdUIResponse response = mapper.readValue(responseString, UpdateChatIdUIResponse.class);
        URI url = URI.create("http://localhost/updateChatId");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(redisHelper2.updateChatId(any())).thenReturn(Mono.just(true));
        when(cartHelper.updateChatId(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.updateChatId(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateChatIdControllerErrorTest() throws IOException {
        String requestString = "{\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\": \"4c4a9307-ebc1-4f51-a350-a6438b825dcb\",\"caseId\": \"SOP-659808-E01\",\"accountNumber\": \"0285560011-00001\",\"cartCreator\": \"2018702013\",\"processingMTN\": \"2018702013\",\"processStep\": \"TransferUpgrade\",\"intendType\": \"EUP\"},\"chatId\": \"2018702013\"}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        UpdateChatIdUIRequest request = mapper.readValue(requestString, UpdateChatIdUIRequest.class);
        UpdateChatIdUIResponse response = mapper.readValue(responseString, UpdateChatIdUIResponse.class);
        URI url = URI.create("http://localhost/updateChatId");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(redisHelper2.updateChatId(any())).thenReturn(Mono.just(true));
        when(cartHelper.updateChatId(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.updateChatId(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void clearCartTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-514162-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"GridWallPDP\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addBuyOutAmt\"},\"customerInfo\":{\"accountNumber\":\"0100007530-00001\",\"cartCreator\":\"4125102507\"},\"cartInfo\":{\"cartId\":\"8ab56dcb-4268-4ea8-99f2-99955effe2cd\",\"statusCode\":\"0\",\"statusMsg\":\"Success\"}}}}}";
        ClearCartUIRequest request = mapper.readValue(requestString, ClearCartUIRequest.class);
        ClearCartUIResponse response = mapper.readValue(responseString, ClearCartUIResponse.class);
        URI url = URI.create("http://localhost/clearCart");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(redisHelper.deleteAddDeviceDataFromRedis(any())).thenReturn(Mono.just(1L));
        when(redisHelper.deleteProcessingMtnFromRedis(any())).thenReturn(Mono.just(1L));
        when(cartHelper.clearCart(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.clearCart(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void clearCartErrorTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        ClearCartUIRequest request = mapper.readValue(requestString, ClearCartUIRequest.class);
        ClearCartUIResponse response = mapper.readValue(responseString, ClearCartUIResponse.class);
        URI url = URI.create("http://localhost/clearCart");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(redisHelper.deleteAddDeviceDataFromRedis(any())).thenReturn(Mono.just(1L));
        when(redisHelper.deleteProcessingMtnFromRedis(any())).thenReturn(Mono.just(1L));
        when(cartHelper.clearCart(any())).thenReturn((Mono<ClearCartUIResponse>) Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.clearCart(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void applyMyOffersErrorTest() throws IOException {
        ApplyOfferRequest request = new ApplyOfferRequest();
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        ValidateOffersResponse response = mapper.readValue(responseString, ValidateOffersResponse.class);
        String planRespStr = "{ \"serviceHeader\": { \"clientId\": \"VZW-NETACE\", \"statusMsg\": \"PEGA generated message\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"sessionId\": \"\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"0\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \" SOP-1583186-DEV3\", \"customerInfo\": { \"accountNumber\": \"07893451230-00001\", \"cartCreator\": \"2515813861\", \"processingMTN\": \"2515813860\" }, \"processMTNList\": [ { \"mtn\": \"2515813860\", \"completedprocessSteps\": [ \"MTNSelectionPage\", \"GridWallPDP\" ] }, { \"mtn\": \"2515813861\", \"completedprocessSteps\": [] } ], \"cartInfo\": { \"expressCheckout\": true, \"effectiveDateDetails\": { \"suggestedBackDate\": \"\", \"suggestedFutureDate\": \"10/08/2019\", \"currentBillCycleBeginDate\": \"09/08/2019\", \"nextBillCycleBeginDate\": \"10/08/2019\", \"onDemandDate\": \"09/10/2019\", \"onDemandRangeInDays\": \"45\", \"isOnDemandAllowed\": true, \"isBackDateAllowed\": false, \"isFutureDateAllowed\": true }, \"autoPayEnrollmentDetails\": { \"isAutoPayEnrolled\": \"Y\", \"isPaperLessEnrolled\": \"Y\", \"isAutoPayPaperLessDiscountEligible\": \"Y\", \"totalEligibleAutoPayPaperLessDiscount\": 10 }, \"cartId\": \"03927707-5fa1-4239-8ceb-eafae5138dba\", \"statusCode\": 1, \"statusMsg\": null, \"lines\": [ { \"mtn\": \"3025451823\", \"pairingInfo\": { \"newPairedPhone\": \"5512704531\", \"currentPairedPhone\": \"5512704532\", \"benefitPairType\": \"ACD\" }, \"status\": 1, \"planValidationFailed\": false, \"errors\": [], \"isFreeAppleMusicLoss\": \"Y\", \"plan\": { \"id\": \"73425\", \"price\": \"9.99\", \"discountsResponse\": null, \"discountedPrice\": \"10.00\", \"promos\": [ { \"id\": \"\", \"percentageOff\": \"\", \"amountOff\": \"\", \"description\": \"\", \"type\": \"\" } ] }, \"sfos\": [ { \"id\": \"73502\", \"actionIndicator\": \"A\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"UNL PICTURE/VIDEO MSG\", \"price\": \"0.00\" }, { \"id\": \"75622\", \"actionIndicator\": \"A\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"4G DATA TRANSPORT\", \"price\": \"0.00\" }, { \"id\": \"75632\", \"actionIndicator\": \"A\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"INTL TRVL USCAN VOICEDATA PAYG\", \"price\": \"0.00\" }, { \"id\": \"75691\", \"actionIndicator\": \"A\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"REAL TIME USAGE REPORTING\", \"price\": \"0.00\" }, { \"id\": \"76152\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"PICTURE MESSAGING\", \"price\": \"0.00\" }, { \"id\": \"76286\", \"actionIndicator\": \"A\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"CONSUMER PDA\", \"price\": \"0.00\" }, { \"id\": \"76375\", \"actionIndicator\": \"A\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"DATA PACKAGE/2GB\", \"price\": \"30.00\" }, { \"id\": \"76404\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"MOBILE HOTSPOT\", \"price\": \"0.00\" }, { \"id\": \"77249\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"MOBILE HOT SPOT TRIGGER\", \"price\": \"0.00\" }, { \"id\": \"77556\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"4G PROVISIONING\", \"price\": \"0.00\" }, { \"id\": \"77568\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"EMAIL ACCESS\", \"price\": \"0.00\" }, { \"id\": \"77581\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"EMAIL TRIGGER ALP\", \"price\": \"0.00\" }, { \"id\": \"77583\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"DATA PROVISION ALP\", \"price\": \"0.00\" }, { \"id\": \"80148\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"INTL MESSAGES WHILE IN US $0\", \"price\": \"0.00\" }, { \"id\": \"84856\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"VERIZON PLAN UNL ENTITLEMENT\", \"price\": \"0.00\" }, { \"id\": \"84860\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"SMARTPHONE LINE ACCESS\", \"price\": \"20.00\" }, { \"id\": \"84876\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"INCLUDE CANADA/MEXICO\", \"price\": \"0.00\" }, { \"id\": \"84881\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"RTR/UC TRIGGER VP UNL\", \"price\": \"0.00\" }, { \"id\": \"84882\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"RTR FOR UNLIMITED\", \"price\": \"0.00\" } ], \"spos\": [ {} ] } ] }, \"contextInfo\": { \"processAction\": \"\", \"processStep\": \"ShoppingCart/PlanSelection\", \"availablePaths\": [ { \"path\": \"\" } ], \"callReason\": \"SalesOrderPurchase\" } } } } }";
        AddPlanUIResponse planResp = mapper.readValue(planRespStr, AddPlanUIResponse.class);
        when(cartHelper.addPlan(any())).thenReturn(Mono.just(planResp));
        when(cartHelper.addPlan(any())).thenReturn(Mono.just(planResp));
        String featureRespStr = "{ \"serviceHeader\": { \"clientId\": \"VZW-ECOM\", \"statusMsg\": \"PEGA generated message\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"sessionId\": \"\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"0\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \" SOP-1583186-DEV3\", \"customerInfo\": { \"accountNumber\": \"07893451230-00001\", \"cartCreator\": \"2515813861\", \"processingMTN\": \"2515813860\" }, \"processMTNList\": [ { \"mtn\": \"2515813860\", \"completedprocessSteps\": [ \"MTNSelectionPage\", \"GridWallPDP\" ] }, { \"mtn\": \"2515813861\", \"completedprocessSteps\": [] } ], \"cartInfo\": { \"cartId\": \"25ed2544-790c-4316-937b-84b49ebbaa9c\", \"lines\": [ { \"mtn\": \"3025451823\", \"status\": 1, \"planValidationFailed\": false, \"lineActivityType\": \"EUP\", \"currentPlanType\": \"ALP\", \"devicePlanCompatible\": false, \"cpcPromoIntercept\": true, \"spos\": [ { \"id\": \"12345\", \"conflict\": \"This will be empty if there's no conflict\" }, { \"id\": 12345, \"success\": false, \"description\": \"\", \"is5GBoltEligible\": true, \"actionIndicator\": \"A\" } ], \"sfos\": [ { \"id\": \"12345\", \"conflict\": \"This will be empty if there's no conflict\" } ] } ] }, \"contextInfo\": { \"processAction\": \"\", \"processStep\": \"AccessoryPDP\", \"availablePaths\": [ { \"path\": \"AccessoryPDP\" } ], \"callReason\": \" SalesOrderPurchase \" } } } } }";
        AddFeaturesUIResponse featureResp = mapper.readValue(featureRespStr, AddFeaturesUIResponse.class);
        when(cartHelper.addFeatures(any())).thenReturn(Mono.just(featureResp));
        URI url = URI.create("http://localhost/startRPSFlow");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        String etrString = "{\"cartId\": \"\",\"atenaSessionId\": \"\",\"lines\": [{\"mtn\": \"5079937563\",\"offers\": [{\"complianceType\": \"ACC\",\"sku\": \"200350\",\"description\": \"UAT_73 SL: Get 50% off of Any Phone Case\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_73\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"},{\"complianceType\": \"EQP\",\"sku\": \"202617\",\"description\": \"Get $300 Recurring BIC on Smartphone Upgrade (Multi Line)\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"EA\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_85\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"}]}]}";
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        Mono<ResponseEntity<ValidateOffersResponse>> controllerResponse = cartController.applyMyOffers(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
        etrData.setLines(null);
        controllerResponse = cartController.applyMyOffers(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void applyMyOffersTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"7c875d28-9d68-41c0-bad8-63e0d0885200\",\"caseId\":\"SOP-7586552-C01\",\"accountNumber\":\"0380002527-00001\",\"processingMTN\":\"3166403923\",\"cartCreator\":\"3166403923\",\"processStep\":\"PlanSelection\",\"intendType\":\"NSE\", \"isEquipmentOffer\":true}}\t";
        ApplyOfferRequest request = mapper.readValue(requestString, ApplyOfferRequest.class);
        String responseString = "{\"statusMessage\":\"No offers applied!\"}";
        ValidateOffersResponse response = mapper.readValue(responseString, ValidateOffersResponse.class);
        String planRespStr = "{ \"serviceHeader\": { \"clientId\": \"VZW-NETACE\", \"statusMsg\": \"PEGA generated message\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"sessionId\": \"\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"0\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \" SOP-1583186-DEV3\", \"customerInfo\": { \"accountNumber\": \"07893451230-00001\", \"cartCreator\": \"2515813861\", \"processingMTN\": \"2515813860\" }, \"processMTNList\": [ { \"mtn\": \"2515813860\", \"completedprocessSteps\": [ \"MTNSelectionPage\", \"GridWallPDP\" ] }, { \"mtn\": \"2515813861\", \"completedprocessSteps\": [] } ], \"cartInfo\": { \"expressCheckout\": true, \"effectiveDateDetails\": { \"suggestedBackDate\": \"\", \"suggestedFutureDate\": \"10/08/2019\", \"currentBillCycleBeginDate\": \"09/08/2019\", \"nextBillCycleBeginDate\": \"10/08/2019\", \"onDemandDate\": \"09/10/2019\", \"onDemandRangeInDays\": \"45\", \"isOnDemandAllowed\": true, \"isBackDateAllowed\": false, \"isFutureDateAllowed\": true }, \"autoPayEnrollmentDetails\": { \"isAutoPayEnrolled\": \"Y\", \"isPaperLessEnrolled\": \"Y\", \"isAutoPayPaperLessDiscountEligible\": \"Y\", \"totalEligibleAutoPayPaperLessDiscount\": 10 }, \"cartId\": \"03927707-5fa1-4239-8ceb-eafae5138dba\", \"statusCode\": 1, \"statusMsg\": null, \"lines\": [ { \"mtn\": \"3025451823\", \"pairingInfo\": { \"newPairedPhone\": \"5512704531\", \"currentPairedPhone\": \"5512704532\", \"benefitPairType\": \"ACD\" }, \"status\": 1, \"planValidationFailed\": false, \"errors\": [], \"isFreeAppleMusicLoss\": \"Y\", \"plan\": { \"id\": \"73425\", \"price\": \"9.99\", \"discountsResponse\": null, \"discountedPrice\": \"10.00\", \"promos\": [ { \"id\": \"\", \"percentageOff\": \"\", \"amountOff\": \"\", \"description\": \"\", \"type\": \"\" } ] }, \"sfos\": [ { \"id\": \"73502\", \"actionIndicator\": \"A\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"UNL PICTURE/VIDEO MSG\", \"price\": \"0.00\" }, { \"id\": \"75622\", \"actionIndicator\": \"A\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"4G DATA TRANSPORT\", \"price\": \"0.00\" }, { \"id\": \"75632\", \"actionIndicator\": \"A\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"INTL TRVL USCAN VOICEDATA PAYG\", \"price\": \"0.00\" }, { \"id\": \"75691\", \"actionIndicator\": \"A\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"REAL TIME USAGE REPORTING\", \"price\": \"0.00\" }, { \"id\": \"76152\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"PICTURE MESSAGING\", \"price\": \"0.00\" }, { \"id\": \"76286\", \"actionIndicator\": \"A\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"CONSUMER PDA\", \"price\": \"0.00\" }, { \"id\": \"76375\", \"actionIndicator\": \"A\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"DATA PACKAGE/2GB\", \"price\": \"30.00\" }, { \"id\": \"76404\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"MOBILE HOTSPOT\", \"price\": \"0.00\" }, { \"id\": \"77249\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"MOBILE HOT SPOT TRIGGER\", \"price\": \"0.00\" }, { \"id\": \"77556\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"4G PROVISIONING\", \"price\": \"0.00\" }, { \"id\": \"77568\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"EMAIL ACCESS\", \"price\": \"0.00\" }, { \"id\": \"77581\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"EMAIL TRIGGER ALP\", \"price\": \"0.00\" }, { \"id\": \"77583\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"DATA PROVISION ALP\", \"price\": \"0.00\" }, { \"id\": \"80148\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"INTL MESSAGES WHILE IN US $0\", \"price\": \"0.00\" }, { \"id\": \"84856\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"VERIZON PLAN UNL ENTITLEMENT\", \"price\": \"0.00\" }, { \"id\": \"84860\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"SMARTPHONE LINE ACCESS\", \"price\": \"20.00\" }, { \"id\": \"84876\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"INCLUDE CANADA/MEXICO\", \"price\": \"0.00\" }, { \"id\": \"84881\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"RTR/UC TRIGGER VP UNL\", \"price\": \"0.00\" }, { \"id\": \"84882\", \"actionIndicator\": \"D\", \"customerAddedInd\": \"\", \"currentDeviceCompatibilityInd\": null, \"description\": \"RTR FOR UNLIMITED\", \"price\": \"0.00\" } ], \"spos\": [ {} ] } ] }, \"contextInfo\": { \"processAction\": \"\", \"processStep\": \"ShoppingCart/PlanSelection\", \"availablePaths\": [ { \"path\": \"\" } ], \"callReason\": \"SalesOrderPurchase\" } } } } }";
        AddPlanUIResponse planResp = mapper.readValue(planRespStr, AddPlanUIResponse.class);
        when(cartHelper.addPlan(any())).thenReturn(Mono.just(planResp));
        String featureRespStr = "{ \"serviceHeader\": { \"clientId\": \"VZW-ECOM\", \"statusMsg\": \"PEGA generated message\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"sessionId\": \"\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"0\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \" SOP-1583186-DEV3\", \"customerInfo\": { \"accountNumber\": \"07893451230-00001\", \"cartCreator\": \"2515813861\", \"processingMTN\": \"2515813860\" }, \"processMTNList\": [ { \"mtn\": \"2515813860\", \"completedprocessSteps\": [ \"MTNSelectionPage\", \"GridWallPDP\" ] }, { \"mtn\": \"2515813861\", \"completedprocessSteps\": [] } ], \"cartInfo\": { \"cartId\": \"25ed2544-790c-4316-937b-84b49ebbaa9c\", \"lines\": [ { \"mtn\": \"3025451823\", \"status\": 1, \"planValidationFailed\": false, \"lineActivityType\": \"EUP\", \"currentPlanType\": \"ALP\", \"devicePlanCompatible\": false, \"cpcPromoIntercept\": true, \"spos\": [ { \"id\": \"12345\", \"conflict\": \"This will be empty if there's no conflict\" }, { \"id\": 12345, \"success\": false, \"description\": \"\", \"is5GBoltEligible\": true, \"actionIndicator\": \"A\" } ], \"sfos\": [ { \"id\": \"12345\", \"conflict\": \"This will be empty if there's no conflict\" } ] } ] }, \"contextInfo\": { \"processAction\": \"\", \"processStep\": \"AccessoryPDP\", \"availablePaths\": [ { \"path\": \"AccessoryPDP\" } ], \"callReason\": \" SalesOrderPurchase \" } } } } }";
        AddFeaturesUIResponse featureResp = mapper.readValue(featureRespStr, AddFeaturesUIResponse.class);
        when(cartHelper.addFeatures(any())).thenReturn(Mono.just(featureResp));
        String validateOffersResponseString = "{\"meta\":{\"timestamp \":1574781308905,\"cxpCorrelationId\":\"2019 - 11 - 26 T09: 15: 08. - 0600: 8e448008 - 8983 - 445 c - 96 f6 - d2717ab03feb: WTX0109ALDITAUX: cxp - cart - domain: nsd2 \"},\"data\":{\"cartId\":\"79 dd4325 - b728 - 4 f03 - 9908 - 9e0 f9dc82f2a\",\"statusCode\":1,\"statusMsg\":\"uccess \",\"preAuthSuccess \":false}}";
        MyOffersCXPResponse myOffersCXPResponse = mapper.readValue(validateOffersResponseString, MyOffersCXPResponse.class);
        when(cartHelper.updateMyOffers(any())).thenReturn(Mono.just(myOffersCXPResponse));
        URI url = URI.create("http://localhost/applyMyOffers");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        String etrString = "{\"cartId\": \"\",\"atenaSessionId\": \"\",\"lines\": [{\"mtn\": \"5079937563\",\"offers\": [{\"complianceType\": \"ACC\",\"sku\": \"200350\",\"description\": \"UAT_73 SL: Get 50% off of Any Phone Case\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_73\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"},{\"complianceType\": \"EQP\",\"sku\": \"202617\",\"description\": \"Get $300 Recurring BIC on Smartphone Upgrade (Multi Line)\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"EA\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_85\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"}]}]}";
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        when(cartHelper.validateOffers(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<ValidateOffersResponse>> controllerResponse = cartController.applyMyOffers(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void switchFulfillmentTest() throws JsonProcessingException {
        String requestString = "{\"context\":{\"customerInfo\":{\"cartCreator\":\"2158509131\",\"processingMTN\":\"2158509131\"},\"cartInfo\":{\"cartId\":\"24b81919-d9f5-4bb9-a629-ac21a585bca7\",\"itemType\":\"SWITCH-FULFILLMENT\",\"chatId\":\"\",\"intendType\":\"EUP\",\"switchFulfillmentType\":\"F\"},\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"intent\":\"Upgrade\",\"processStep\":\"ShoppingCart\",\"processAction\":\"switchFulfillment\"}}}\t";
        ExCustIndirectRemoveLinesServiceUIRequest request = mapper.readValue(requestString, ExCustIndirectRemoveLinesServiceUIRequest.class);
        String responseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-INDIRECT\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.06.08.12.58.08-985.9833000351526\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-7582762-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"ShoppingCart\"}]},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"254089143\",\"processingMTN\":\"2817537391\",\"registerNumber\":0,\"customerType\":\"N\"},\"cartInfo\":{\"cartId\":\"4903d8c7-4f01-4187-87ed-b431ce9b8100\",\"statusMsg\":\"Success\",\"switchFulfillmentType\":\"F\",\"statusCode\":1},\"processMTNList\":[{\"mtn\":\"2817537391\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"InterimPage\",\"ShoppingCart\"]}]}}}}\t";
        IndirectExCustRemoveLinePEGARes response = mapper.readValue(responseString, IndirectExCustRemoveLinePEGARes.class);
        URI url = URI.create("http://localhost/applyMyOffers");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(cartHelper.exCustremoveLines(request)).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.switchFulfillment(httpHeader, null, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void switchFulfillmentErrorTest() throws JsonProcessingException {
        String requestString = "{\"context\":{\"customerInfo\":{\"cartCreator\":\"2158509131\"},\"cartInfo\":{\"cartId\":\"24b81919-d9f5-4bb9-a629-ac21a585bca7\",\"itemType\":\"SWITCH-FULFILLMENT\",\"chatId\":\"\",\"intendType\":\"EUP\",\"switchFulfillmentType\":\"F\"},\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"intent\":\"Upgrade\",\"processStep\":\"ShoppingCart\",\"processAction\":\"switchFulfillment\"}}}\t";
        ExCustIndirectRemoveLinesServiceUIRequest request = mapper.readValue(requestString, ExCustIndirectRemoveLinesServiceUIRequest.class);
        String responseString = "{\"errors\":[{\"namespace\":\"cxp-pega-update-cart\",\"name\":\"Down stream error\",\"id\":\"1009\",\"message\":\"Down stream error occured on Cart System with message the HTTP response code of 503 indicated a server error. The response data may contain a reason. // The service response contained insufficient data for mapping: The following header(s) were not populated: [routeType].\"}]}\t";
        IndirectExCustRemoveLinePEGARes response = mapper.readValue(responseString, IndirectExCustRemoveLinePEGARes.class);
        URI url = URI.create("http://localhost/witch-fulfillment");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(cartHelper.exCustremoveLines(request)).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.switchFulfillment(httpHeader, null, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void typeAheadFromESTest() throws IOException {
        String requestString = "{\"deviceCategory\":\"Smartphone\",\"model\":\"iphone\"}";
        String responseString = "{ \"data\": [ { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 11\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 11\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 11-E NON VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"IPHONE 11-E NON VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE 11-E NON VZW\", \"carrierName\": \"TMOBILE\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 11 PRO\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 11 PRO\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 11 PRO-E NON VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"IPHONE 11 PRO-E NON VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE 11 PRO-E NON VZW\", \"carrierName\": \"TMOBILE\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 11 PRO MAX\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 11 PRO MAX\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 11 PRO MAX-E NON VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"IPHONE 11 PRO MAX-E NON VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE 11 PRO MAX-E NON VZW\", \"carrierName\": \"TMOBILE\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 12\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 12\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 12 eSIM\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 12 GEN W\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 12 GEN W\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 12 GEN-E NVZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"IPHONE 12 GEN-E NVZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"IPHONE 12 GEN-E NVZW\", \"carrierName\": \"SPRINT\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 12 MINI\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 12 MINI\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 12 MINI SO eSIM\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 12 PRO\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 12 PRO\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 12 PRO eSIM\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 12 PRO MAX\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 12 PRO MAX\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 12 PRO MAX SO eSIM\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 13\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 13\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 13 NVZ\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"iPhone 13 NVZ\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 13 NVZ\", \"carrierName\": \"TMOBILE\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 13 mini\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 13 mini\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 13 mini-2\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 13 Pro\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 13 Pro\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 13 Pro SO\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 13 Pro Max\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 13 Pro Max\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 13 Pro Max\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 4\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 4\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 4\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 4S\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 4S\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 4S\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 5\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 5\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 5\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 5C\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 5C\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 5C\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 5S\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 5S\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 5S\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 6\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 6\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 6\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"IPHONE 6 SPRINT\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 6 - Non VZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 6 - Non VZW\", \"carrierName\": \"ATT\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 6 Plus\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 6 Plus\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 6 Plus - Non VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"iPhone 6 Plus - Non VZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 6 Plus - Non VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 6 Plus\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 6S\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 6S\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 6S\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"iPhone 6S Non VZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 6S Non VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 6S Non VZW\", \"carrierName\": \"ATT\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 6S Plus\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 6S Plus\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 6S Plus\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"iPhone 6S Plus Non VZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 6S Plus Non VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 6S Plus Non VZW\", \"carrierName\": \"ATT\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 7\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 7\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 7\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"iPhone 7 - Non VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 7 - Non VZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 7 - Non VZW\", \"carrierName\": \"ATT\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 7 Plus\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 7 Plus\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 7 Plus\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"iPhone 7 Plus - Non VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 7 Plus - Non VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"iPhone 7 Plus - Non VZW\", \"carrierName\": \"TMOBILE\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 8\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 8\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 8 Non Verizon\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 8 Non Verizon\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 8 Non Verizon\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"iPhone 8\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 8 Plus\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 8 Plus\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 8 Plus\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"iPhone 8 Plus Non Verizon\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 8 Plus Non Verizon\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 8 Plus Non Verizon\", \"carrierName\": \"ATT\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone SE\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone SE\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone SE\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"iPhone SE Non VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone SE Non VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"iPhone SE Non VZW\", \"carrierName\": \"TMOBILE\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone SE 2020\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone SE 2020\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone SE 22\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone SE 22\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE SE 22 SO\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPHONE SE GENERIC\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPHONE SE GENERIC\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPHONE SE GENERIC NON VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPHONE SE GENERIC NON VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"iPHONE SE GENERIC NON VZW\", \"carrierName\": \"TMOBILE\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone SE2020\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone SE2020\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE SE SO 2020\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone X\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone X\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE X NON VERIZON\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"IPHONE X NON VERIZON\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE X NON VERIZON\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"IPHONE X\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone XR\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone XR\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone XR eSIM\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone XS\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone XS\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone XS\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"IPHONE XS NVZ\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"IPHONE XS NVZ\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE XS NVZ\", \"carrierName\": \"TMOBILE\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone XS Max\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone XS Max\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone XS Max\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"IPHONE XS MAX\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"IPHONE XS MAX\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE XS MAX\", \"carrierName\": \"TMOBILE\" } ] }, { \"carrier\": [ \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone12 MINI GEN W\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone12 MINI GEN W\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE12 MINI GEN-E NVZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE12 MINI GEN-E NVZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"IPHONE12 MINI GEN-E NVZW\", \"carrierName\": \"TMOBILE\" } ] }, { \"carrier\": [ \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone12 PRO GEN W\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone12 PRO GEN W\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE12 PRO GEN-E NVZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"IPHONE12 PRO GEN-E NVZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE12 PRO GEN-E NVZW\", \"carrierName\": \"ATT\" } ] }, { \"carrier\": [ \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone12 PROMAX GEN W\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone12 PROMAX GEN W\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE12 PROMAX GEN-E NVZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"IPHONE12 PROMAX GEN-E NVZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE12 PROMAX GEN-E NVZW\", \"carrierName\": \"ATT\" } ] } ] }";
        SmartImeiTypeAheadSearchRequest request = mapper.readValue(requestString,
                SmartImeiTypeAheadSearchRequest.class);
        SmartImeiTypeAheadSearchResponse response = mapper.readValue(responseString,
                SmartImeiTypeAheadSearchResponse.class);
        when( cartServiceCXPHelper.getSmartImeiTypeAheadResponse(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.typeAhead(request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void initBinderbyNameTest() {
        WebDataBinder binder = new WebDataBinder(null);
        cartController.initBinderByName(binder);
        assertNotNull(binder.getDisallowedFields());
    }

    @Test
    public void addManualDiscountTest() throws IOException {
        String requestString = "{ \"cartInfo\": { \"clientAppName\": \"VZW-NETACE\", \"cartId\": \"f61a7954-4300-4e97-9478-f001475bdf9b\", \"caseId\": \"SOP-508208-E01\", \"accountNumber\": \"0420194063-00001\", \"cartCreator\": \"4235342870\", \"processingMTN\": \"4235344191\", \"intendType\": \"AAL\", \"action\": \"ADD\"}, \"data\":{\"lines\": [{ \"mtn\": \"6098791208\", \"manualDiscount\": [{ \"skuId\": \"VPC24LGHT-M1\", \"discountReasonCode\": \"1\", \"discountPercent\": 0.0, \"discountAmount\": 1.0 }] }], \"callReason\": \"SalesOrderPurchase\", \"intent\" : \"AAL\", \"processStep\": \"OrderReview-Shipping\", \"processAction\": \"addManualDiscount\" } }";
        String responseString = "{\"serviceHeader\": { \"clientId\": \"VZW-NETACE\", \"statusMsg\": \"PEGA generated message\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"sessionId\": \"\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"0\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \" SOP-1583186-DEV3\", \"customerInfo\" : { \"accountNumber\": \"07893451230-00001\", \"cartCreator\":\"2515813861\", \"processingMTN\": \"2515813860\" }, \"processMTNList\": [ { \"mtn\":\"2515813860\", \"completedprocessSteps\": [\"MTNSelectionPage\",\"GridWallPDP\"] }, { \"mtn\":\"2515813861\", \"completedprocessSteps\": [] } ], \"cartInfo\": { \"cartId\": \"4f306cb7-27ae-4c53-98d8-c42b2276ff05\", \"statusCode\": 1, \"statusMsg\": \"ManualDiscount Updated Successfully.\" },  \"contextInfo\": { \"processAction\": \"\", \"processStep\": \"OrderReview-Shipping\", \"availablePaths\":[ { \"path\":\"OrderReview-Shipping\" }], \"callReason\": \" SalesOrderPurchase \" } } } } }";
        UpdateManualDiscountUIRequest request = mapper.readValue(requestString, UpdateManualDiscountUIRequest.class);
        UpdateManualDiscountUIResponse response = mapper.readValue(responseString, UpdateManualDiscountUIResponse.class);
        URI url = URI.create("http://localhost/updateManualDiscount");
        HttpHeaders headers = new HttpHeaders();
        headers.add("channelId", "channelId");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.addManualDiscount(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addManualDiscount(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addManualDiscountFailureTest() throws IOException {
        String requestString = "{ \"cartInfo\": { \"clientAppName\": \"VZW-NETACE\", \"cartId\": \"f61a7954-4300-4e97-9478-f001475bdf9b\", \"caseId\": \"SOP-508208-E01\", \"accountNumber\": \"0420194063-00001\", \"cartCreator\": \"4235342870\", \"processingMTN\": \"4235344191\", \"intendType\": \"AAL\", \"action\": \"ADD\"},\"data\": { \"lines\": [{ \"mtn\": \"6098791208\", \"manualDiscount\": [{ \"skuId\": \"VPC24LGHT-M1\", \"discountReasonCode\": \"1\", \"discountPercent\": 0.0, \"discountAmount\": 1.0 }] }], \"callReason\": \"SalesOrderPurchase\", \"intent\" : \"AAL\", \"processStep\": \"OrderReview-Shipping\", \"processAction\": \"addManualDiscount\" } }";
        UpdateManualDiscountUIRequest request = mapper.readValue(requestString, UpdateManualDiscountUIRequest.class);
        request.getCartInfo().setAction(null);
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        UpdateManualDiscountUIResponse response = mapper.readValue(responseString, UpdateManualDiscountUIResponse.class);
        URI url = URI.create("http://localhost/manual-discount");
        CartError error = new CartError();
        List<CartError> errorList = new ArrayList<>();
        error.setCode("code");
        error.setErrorCategory("error category");
        error.setId("id");
        errorList.add(error);
        response.setErrors(errorList);
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.addManualDiscount(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addManualDiscount(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(val-> org.junit.Assert.assertNotNull(val));
    }

    @Test
    public void addManualDiscountErrorTest() throws IOException {
        String requestString = "{ \"cartInfo\": { \"clientAppName\": \"VZW-NETACE\", \"cartId\": \"f61a7954-4300-4e97-9478-f001475bdf9b\", \"caseId\": \"SOP-508208-E01\", \"accountNumber\": \"0420194063-00001\", \"cartCreator\": \"4235342870\", \"processingMTN\": \"4235344191\", \"intendType\": \"AAL\", \"action\": \"ADD\"},\"data\": { \"lines\": [{ \"mtn\": \"6098791208\", \"manualDiscount\": [{ \"skuId\": \"VPC24LGHT-M1\", \"discountReasonCode\": \"1\", \"discountPercent\": 0.0, \"discountAmount\": 1.0 }] }], \"callReason\": \"SalesOrderPurchase\", \"intent\" : \"AAL\", \"processStep\": \"OrderReview-Shipping\", \"processAction\": \"addManualDiscount\" } }";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        UpdateManualDiscountUIRequest request = mapper.readValue(requestString, UpdateManualDiscountUIRequest.class);
        UpdateManualDiscountUIResponse response = mapper.readValue(responseString, UpdateManualDiscountUIResponse.class);
        URI url = URI.create("http://localhost/manual-discount");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.addManualDiscount(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addManualDiscount(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }


    @Test
    public void updateEffectiveDateTest() throws IOException {
        String requestString = "{ \"cartInfo\": { \"clientAppName\": \"VZW-NETACE\", \"cartId\": \"f61a7954-4300-4e97-9478-f001475bdf9b\", \"caseId\": \"SOP-508208-E01\", \"accountNumber\": \"0420194063-00001\", \"cartCreator\": \"4235342870\", \"processingMTN\": \"4235344191\", \"effectiveDate\": \"04/10/2021\", \"intendType\": \"AAL\", \"callReason\": \"SalesOrderPurchase\", \"intent\" : \"AAL\", \"processStep\": \"ShoppingCart\", \"processAction\": \"addEffectiveDate\" } }";
        String responseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-NETACE\", \"statusMsg\": \"PEGA generated message\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"sessionId\": \"\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"0\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \" SOP-1583186-DEV3\", \"customerInfo\" : { \"accountNumber\": \"07893451230-00001\", \"cartCreator\":\"2515813861\", \"processingMTN\": \"2515813860\" }, \"processMTNList\": [ { \"mtn\":\"2515813860\", \"completedprocessSteps\": [\"MTNSelectionPage\",\"GridWallPDP\"] }, { \"mtn\":\"2515813861\", \"completedprocessSteps\": [] } ], \"cartInfo\": { \"cartId\": \"4f306cb7-27ae-4c53-98d8-c42b2276ff05\", \"statusCode\": \"1\", \"statusMsg\": \"Success\", \"effectiveDateDetails\": { \"suggestedBackDate\": \"04/10/2021\", \"suggestedFutureDate\": \"05/10/2021\", \"currentBillCycleBeginDate\": \"04/10/2021\", \"nextBillCycleBeginDate\": \"05/10/2021\", \"onDemandRangeInDays\": \"45\", \"selectedDate\": \"04/10/2021\", \"isOnDemandAllowed\": false, \"isBackDateAllowed\": true, \"isFutureDateAllowed\": true } }, \"contextInfo\": { \"processAction\": \"\", \"processStep\": \"ShoppingCart\", \"availablePaths\":[ { \"path\":\"ShoppingCart`\" }, { \"path\":\"addDevice\" }, { \"path\":\"addFeatures`\" }, { \"path\":\"showFeatures\" }, { \"path\":\"showDevice`\" }, { \"path\":\"showAccessory\" }, { \"path\":\"addAccessory\" }, { \"path\":\"TradeIn\" }  ], \"callReason\": \" SalesOrderPurchase \" } } } } }     ";
        UpdateEffectiveDateUIRequest request = mapper.readValue(requestString, UpdateEffectiveDateUIRequest.class);
        UpdateEffectiveDateUIResponse response = mapper.readValue(responseString, UpdateEffectiveDateUIResponse.class);
        URI url = URI.create("http://localhost/updateEffectiveDate");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.updateEffectiveDate(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.updateEffectiveDate(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateEffectiveDateErrorTest() throws IOException {
        String requestString =" { \"cartInfo\": { \"clientAppName\": \"VZW-NETACE\", \"cartId\": \"f61a7954-4300-4e97-9478-f001475bdf9b\", \"caseId\": \"SOP-508208-E01\", \"accountNumber\": \"0420194063-00001\", \"cartCreator\": \"4235342870\", \"processingMTN\": \"4235344191\", \"effectiveDate\": \"04/10/2021\", \"intendType\": \"AAL\", \"callReason\": \"SalesOrderPurchase\", \"intent\" : \"AAL\", \"processStep\": \"ShoppingCart\", \"processAction\": \"addEffectiveDate\" } }";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        UpdateEffectiveDateUIRequest request = mapper.readValue(requestString, UpdateEffectiveDateUIRequest.class);
        UpdateEffectiveDateUIResponse response = mapper.readValue(responseString, UpdateEffectiveDateUIResponse.class);
        URI url = URI.create("http://localhost/updateEffectiveDate");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.updateEffectiveDate(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.updateEffectiveDate(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void updateAccountPinTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"itemType\":\"ACCOUNTPIN\",\"intendType\":\"NSE\",\"action\":\"UPDATE\",\"customerType\":\"N\",\"accountPin\":\"_v0YjA cb69b5e1 0 PSS\",\"processAction\":\"addAccountPIN\",\"processStep\":\"AccountInfo\"},\"data\":{\"bucketAllocator\":\"BAU\",\"throttleList\":\"|SPLIT_FULFILLMENT|\",\"cradleFlowJourney\":\"\"}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2021.10.13.04.57.11-781.2277817000021\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"availablePaths\":[{\"path\":\"Shipment\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Shipment\",\"processAction\":\"\"},\"customerInfo\":{\"customerType\":\"N\",\"originalCreditApprovalNumber\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-0931a896-c123-4bd6-a61b-8887b8a69719\",\"processingMTN\":\"\",\"registerNumber\":0,\"mtnFlow\":\"D\",\"globalId\":\"POE-D-0931a896-c123-4bd6-a61b-8887b8a69719\"},\"cartInfo\":{\"cartItemCount\":0,\"statusMsg\":\"Account Pin updated successfully\",\"statusCode\":\"1\",\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[\"DeviceCustomization\",\"PlanSelection\",\"GlobalChoiceOffer\",\"ContactInfo\",\"EligibilityReview\",\"AccountInfo\",\"AccountInfo\"]}]}}}}";
        AccountPinUIRequest request = mapper.readValue(requestString, AccountPinUIRequest.class);
        AccountPinUIResponse response = mapper.readValue(responseString, AccountPinUIResponse.class);
        URI url = URI.create("http://localhost/nse/updateAccountPin");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.updateAccountPin(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.updateAccountpin(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateGiftItemTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"\",\"cartId\":\"\",\"caseId\":\"\",\"processingMTN\":\"\",\"processStep\":\"PromoHub\",\"intendType\":\"Upgrade/AAL\",\"processAction\":\"addGiftSelection\",\"mtnFlow\":\"G\"},\"data\":{\"lines\":[{\"mtn\":\"9592820193\",\"device\":{\"productId\":\"dev16280006\",\"qty\":\"1\",\"id\":\"SMF926UZKV\",\"category\":\"Smartphone\",\"isSelectedAsGift\":true}}]}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2021.10.25.12.22.18-297.09835087112305\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-3516558-C01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"PromoHub\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PromoHub\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"0281509823-00001\",\"cartCreator\":\"2039277922\",\"processingMTN\":\"9592820193\",\"registerNumber\":0},\"cartInfo\":{\"financeLimitExceeded\":\"false\",\"cartItemCount\":0,\"totalDueToday\":0.0,\"totalDueMonthly\":0.0,\"cartId\":\"1d2769ae-69d4-4353-9fd5-4b581a1bc28d\",\"statusMsg\":\"GIFTITEM is Updated Successfully\",\"statusCode\":\"1\",\"lines\":[],\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"protectionNotRequired\":false},\"processMTNList\":[{\"mtn\":\"9592820193\",\"completedprocessSteps\":[\"GridWallPDP\",\"MTNSelectionPage\",\"DPPSummary\",\"AccessoryInterestial\",\"PromoHub\",\"PromoHub\"]}]}}}}";
        UpdateGiftItemUIRequest request = mapper.readValue(requestString, UpdateGiftItemUIRequest.class);
        UpdateGiftItemUIResponse response = mapper.readValue(responseString, UpdateGiftItemUIResponse.class);
        URI url = URI.create("http://localhost/update-giftItem");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.updateGiftItem(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.updateGiftItem(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateGiftItemErrorTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"\",\"cartId\":\"\",\"caseId\":\"\",\"processingMTN\":\"\",\"processStep\":\"PromoHub\",\"intendType\":\"Upgrade/AAL\",\"processAction\":\"addGiftSelection\",\"mtnFlow\":\"G\"},\"data\":{}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2021.10.25.12.22.18-297.09835087112305\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-3516558-C01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"PromoHub\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PromoHub\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"0281509823-00001\",\"cartCreator\":\"2039277922\",\"processingMTN\":\"9592820193\",\"registerNumber\":0},\"cartInfo\":{\"financeLimitExceeded\":\"false\",\"cartItemCount\":0,\"totalDueToday\":0.0,\"totalDueMonthly\":0.0,\"cartId\":\"1d2769ae-69d4-4353-9fd5-4b581a1bc28d\",\"statusMsg\":\"GIFTITEM is Updated Successfully\",\"statusCode\":\"1\",\"lines\":[],\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"protectionNotRequired\":false},\"processMTNList\":[{\"mtn\":\"9592820193\",\"completedprocessSteps\":[\"GridWallPDP\",\"MTNSelectionPage\",\"DPPSummary\",\"AccessoryInterestial\",\"PromoHub\",\"PromoHub\"]}]}}}}";
        UpdateGiftItemUIRequest request = mapper.readValue(requestString, UpdateGiftItemUIRequest.class);
        UpdateGiftItemUIResponse response = mapper.readValue(responseString, UpdateGiftItemUIResponse.class);
        URI url = URI.create("http://localhost/update-giftItem");
        HttpHeaders headers = new HttpHeaders();
        headers.add("channelId", "channelId");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.updateGiftItem(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.updateGiftItem(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateGiftItemInvalidRequestTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"\",\"cartId\":\"\",\"caseId\":\"\",\"processingMTN\":\"\",\"processStep\":\"PromoHub\",\"intendType\":\"Upgrade/AAL\",\"processAction\":\"addGiftSelection\",\"mtnFlow\":\"G\"},\"data\":{}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2021.10.25.12.22.18-297.09835087112305\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-3516558-C01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"PromoHub\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PromoHub\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"0281509823-00001\",\"cartCreator\":\"2039277922\",\"processingMTN\":\"9592820193\",\"registerNumber\":0},\"cartInfo\":{\"financeLimitExceeded\":\"false\",\"cartItemCount\":0,\"totalDueToday\":0.0,\"totalDueMonthly\":0.0,\"cartId\":\"1d2769ae-69d4-4353-9fd5-4b581a1bc28d\",\"statusMsg\":\"GIFTITEM is Updated Successfully\",\"statusCode\":\"1\",\"lines\":[],\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"protectionNotRequired\":false},\"processMTNList\":[{\"mtn\":\"9592820193\",\"completedprocessSteps\":[\"GridWallPDP\",\"MTNSelectionPage\",\"DPPSummary\",\"AccessoryInterestial\",\"PromoHub\",\"PromoHub\"]}]}}}}";
        UpdateGiftItemUIRequest request = mapper.readValue(requestString, UpdateGiftItemUIRequest.class);
        UpdateGiftItemUIResponse response = mapper.readValue(responseString, UpdateGiftItemUIResponse.class);
        URI url = URI.create("http://localhost/update-giftItem");
        HttpHeaders headers = new HttpHeaders();
        headers.add("channelId", "channelId");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.updateGiftItem(any())).thenReturn(Mono.just(response));
        request.getData().setLines(null);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.updateGiftItem(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateGiftItemFailureTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"\",\"cartId\":\"\",\"caseId\":\"\",\"processingMTN\":\"\",\"processStep\":\"PromoHub\",\"intendType\":\"Upgrade/AAL\",\"processAction\":\"addGiftSelection\",\"mtnFlow\":\"G\"},\"data\":{}}";
        UpdateGiftItemUIRequest request = mapper.readValue(requestString, UpdateGiftItemUIRequest.class);
        UpdateGiftItemUIResponse response = new UpdateGiftItemUIResponse();
        CartError error = new CartError();
        List<CartError> errorList = new ArrayList<>();
        error.setCode("code");
        error.setErrorCategory("error category");
        error.setId("id");
        errorList.add(error);
        response.setErrors(errorList);
        URI url = URI.create("http://localhost/update-giftItem");
        HttpHeaders headers = new HttpHeaders();
        headers.add("channelId", "channelId");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.updateGiftItem(any())).thenReturn(Mono.just(response));
        request.getData().setLines(null);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.updateGiftItem(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateVzccNBXInfoTest() throws IOException {
        String sampleRequest = "{\"cartId\":\"576aadfe-2c79-40f3-bcf8-7c7eb86fd97b\",\"vzccStatus\":{\"feedbackStatus\":\"Applied\"},\"isPreQualifiedNBX\":false,\"syfOfferId\":\"\",\"promotionalSPOCode\":\"SOBTRIGGER\",\"propositionMessage\":\"Thank you for your interest! Sign up and receive: $100 sign up bonus and more\",\"propositionName\":\"Pre-Qualified - Transaction Flow\",\"propositionId\":\"GC_02\",\"isVZCCHolder\":false,\"sessionId\":\"-2884516544863823367\",\"offerIdFromSYF\":\"N\"}\t";
        String sampleResponse = "{\"meta\":{\"timestamp\":1654696306531,\"cxpCorrelationId\":\"2022-06-08T13:51:46.+0000:ca3b4e37-d401-4a03-bb04-390dfc9924bb:cxp-shopping-services-qa-ev6v-sit1e-nscxp-7d477798b8-gc26c:nssit1\"},\"data\":{\"cartId\":\"576aadfe-2c79-40f3-bcf8-7c7eb86fd97b\",\"statusCode\":1,\"statusMsg\":\"Nbx Info updated successfully\"}}\t";
        UpdateVzccNBXInfoUIRequest request = mapper.readValue(sampleRequest, UpdateVzccNBXInfoUIRequest.class);
        UpdateVzccNBXInfoUIResponse response = mapper.readValue(sampleRequest, UpdateVzccNBXInfoUIResponse.class);
        when(cartHelper.updateVzccNBXInfo(request)).thenReturn(Mono.just(response));
        URI url = URI.create("http://localhost/updateVzccNBXInfo");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.updateVzccNBXInfo(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateVzccNBXInfoErrorTest() throws IOException {
        String sampleRequest = "{\"cartId\":\"f662c471-300b-41f5-96a0-23acfdb1f90b\",\"vzccStatus\":{\"feedbackStatus\":\"Applied\"},\"isPreQualifiedNBX\":false,\"syfOfferId\":\"8803070241\",\"promotionalSPOCode\":\"SOBTRIGGER\",\"propositionMessage\":\"Thank you for your interest! Sign up and receive: $100 sign up bonus and more\",\"propositionName\":\"Pre-Qualified - Transaction Flow\",\"propositionId\":\"GC_02\",\"isVZCCHolder\":false,\"sessionId\":\"6436323129744530860\",\"offerIdFromSYF\":\"N\"}\t";
        String sampleResponse = "{\"errors\":[{\"namespace\":\"cxp-shoppingcart-domain\",\"name\":\"SERVER_ERROR\",\"id\":\"4110\",\"debug_id\":\"2022-05-24T08:56:31.108351Z|2022-05-24T08:56:21.+0000:267c5c12-efcd-4206-8d11-35e23a9764ae:cxp-shopping-services-qa-ev6v-sit3e-nscxp-7db6dfb8c4-wfgzl:nssit3|null\",\"message\":\"Could Not Process Your Request..\"}]}\t";
        UpdateVzccNBXInfoUIRequest request = mapper.readValue(sampleRequest, UpdateVzccNBXInfoUIRequest.class);
        UpdateVzccNBXInfoUIResponse response = mapper.readValue(sampleRequest, UpdateVzccNBXInfoUIResponse.class);
        when(cartHelper.updateVzccNBXInfo(request)).thenReturn(Mono.just(response));
        URI url = URI.create("http://localhost/updateVzccNBXInfo");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.updateVzccNBXInfo(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateVzccNBXInfoInvalidRequestTest() throws IOException {
        String sampleRequest = "{\"cartId\":\"f662c471-300b-41f5-96a0-23acfdb1f90b\",\"vzccStatus\":{\"feedbackStatus\":\"Applied\"},\"isPreQualifiedNBX\":false,\"syfOfferId\":\"8803070241\",\"promotionalSPOCode\":\"SOBTRIGGER\",\"propositionMessage\":\"Thank you for your interest! Sign up and receive: $100 sign up bonus and more\",\"propositionName\":\"Pre-Qualified - Transaction Flow\",\"propositionId\":\"GC_02\",\"isVZCCHolder\":false,\"sessionId\":\"6436323129744530860\",\"offerIdFromSYF\":\"N\"}\t";
        String sampleResponse = "{\"errors\":[{\"namespace\":\"cxp-shoppingcart-domain\",\"name\":\"SERVER_ERROR\",\"id\":\"4110\",\"debug_id\":\"2022-05-24T08:56:31.108351Z|2022-05-24T08:56:21.+0000:267c5c12-efcd-4206-8d11-35e23a9764ae:cxp-shopping-services-qa-ev6v-sit3e-nscxp-7db6dfb8c4-wfgzl:nssit3|null\",\"message\":\"Could Not Process Your Request..\"}]}\t";
        UpdateVzccNBXInfoUIRequest request = mapper.readValue(sampleRequest, UpdateVzccNBXInfoUIRequest.class);
        UpdateVzccNBXInfoUIResponse response = mapper.readValue(sampleRequest, UpdateVzccNBXInfoUIResponse.class);
        request.getVzccStatus().setApplicationStatus(null);
        request.getVzccStatus().setFeedbackStatus(null);
        when(cartHelper.updateVzccNBXInfo(request)).thenReturn(Mono.just(response));
        URI url = URI.create("http://localhost/updateVzccNBXInfo");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.updateVzccNBXInfo(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateVzccNBXInfoErrorResponseTest() throws IOException {
        String sampleRequest = "{\"cartId\":\"f662c471-300b-41f5-96a0-23acfdb1f90b\",\"vzccStatus\":{\"feedbackStatus\":\"Applied\"},\"isPreQualifiedNBX\":false,\"syfOfferId\":\"8803070241\",\"promotionalSPOCode\":\"SOBTRIGGER\",\"propositionMessage\":\"Thank you for your interest! Sign up and receive: $100 sign up bonus and more\",\"propositionName\":\"Pre-Qualified - Transaction Flow\",\"propositionId\":\"GC_02\",\"isVZCCHolder\":false,\"sessionId\":\"6436323129744530860\",\"offerIdFromSYF\":\"N\"}\t";
        String sampleResponse = "{\"errors\":[{\"namespace\":\"cxp-shoppingcart-domain\",\"name\":\"SERVER_ERROR\",\"id\":\"4110\",\"debug_id\":\"2022-05-24T08:56:31.108351Z|2022-05-24T08:56:21.+0000:267c5c12-efcd-4206-8d11-35e23a9764ae:cxp-shopping-services-qa-ev6v-sit3e-nscxp-7db6dfb8c4-wfgzl:nssit3|null\",\"message\":\"Could Not Process Your Request..\"}]}\t";
        UpdateVzccNBXInfoUIRequest request = mapper.readValue(sampleRequest, UpdateVzccNBXInfoUIRequest.class);
        UpdateVzccNBXInfoUIResponse response = mapper.readValue(sampleRequest, UpdateVzccNBXInfoUIResponse.class);
        CartError error = new CartError();
        List<CartError> errorList = new ArrayList<>();
        error.setCode("code");
        error.setErrorCategory("error category");
        error.setId("id");
        errorList.add(error);
        response.setErrors(errorList);
        when(cartHelper.updateVzccNBXInfo(request)).thenReturn(Mono.just(response));
        URI url = URI.create("http://localhost/updateVzccNBXInfo");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.updateVzccNBXInfo(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void postMyLinkAgentCookiesTest() throws IOException {
        URI url = URI.create("http://localhost/myLinkAgent/indirect/12345");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        StepVerifier.create(cartController2.postMyLinkAgentCookies(httpHeader, new MockServerHttpResponse(), "12345")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }
    @Test
    public void postMyLinkAgentCookiesTest1() throws IOException {
        URI url = URI.create("http://localhost/myLinkAgent/indirect/CSKNX");
        HttpCookie cookie1 = new HttpCookie("MyLinkAgentSiteId", "ABDER");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("MyLinkAgentSiteId", cookie1);
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookies(bodyMap).build();
        StepVerifier.create(cartController2.postMyLinkAgentCookies(httpHeader, new MockServerHttpResponse(), "CSKNX")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void postMyLinkAgentSSOCookiesTest() throws IOException {
        URI url = URI.create("http://localhost/myLinkAgent/indirect/ABCDE/12345");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        StepVerifier.create(cartController2.postMyLinkAgentSSOCookies(httpHeader, new MockServerHttpResponse(), "ABCDE", "12345")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }
    @Test
    public void postMyLinkAgentSSOCookiesTest1() throws IOException {
        URI url = URI.create("http://localhost/myLinkAgent/indirect/ABCDE/12345");
        HttpCookie cookie1 = new HttpCookie("MyLinkAgentSiteId", "ABDER");
        HttpCookie cookie2 = new HttpCookie("MyLinkAgentOutletId", "54321");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("MyLinkAgentSiteId", cookie1);
        bodyMap.add("MyLinkAgentOutletId", cookie2);
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookies(bodyMap).build();
        StepVerifier.create(cartController2.postMyLinkAgentSSOCookies(httpHeader, new MockServerHttpResponse(), "ABDER","12345")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }
    @Test
    public void updateWFMInfoTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"processingMTN\":\"8604634931\",\"processStep\":\"ShoppingCart\",\"intendType\":\"EUP\",\"intent\":\"EUP\"},\"data\":{\"wfmOrderInfo\":{\"wfmId\":\"994521288118421\",\"wfmOrderId\":\"142004005\",\"wfmUserId\":\"kumni5j\",\"wfmOrderType\":\"C\"}}}\t";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-CARE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.05.26.11.25.47-945.1017659367217\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4050336-C01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"updateWFM\"},\"customerInfo\":{\"customerType\":\"\",\"accountNumber\":\"0281351635-00001\",\"cartCreator\":\"8604634931\",\"processingMTN\":\"8604634931\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"c21abbdc-eb09-464c-a825-984a7693e760\",\"statusMsg\":\"WfmOrderInfo details updated successfully\",\"statusCode\":\"1\",\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false},\"processMTNList\":[{\"mtn\":\"8604634931\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\",\"PromoHub\",\"OrderReview-Shipping-Payment-Agreement\",\"ReadOrderPage\",\"ShoppingCart\"]}]}}}}";
        UpdateWFMInfoUIRequest request = mapper.readValue(requestString, UpdateWFMInfoUIRequest.class);
        UpdateWFMInfoUIResponse response = mapper.readValue(responseString, UpdateWFMInfoUIResponse.class);
        when(cartHelper.updateWFMInfo(request)).thenReturn(Mono.just(response));
        URI url = URI.create("http://localhost/updateWFMInfo");
        HttpHeaders headers = new HttpHeaders();
        headers.add("channelId", "channelIdx");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.updateWFMInfo(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateWFMInfoErrorTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"processingMTN\":\"8604634931\",\"processStep\":\"ShoppingCart\",\"intendType\":\"EUP\"},\"data\":{\"wfmOrderInfo\":{\"wfmId\":\"994521288118421\",\"wfmOrderId\":\"142004005\",\"wfmUserId\":\"kumni5j\",\"wfmOrderType\":\"C\"}}}\t";
        String responseString = "{\"errors\":[{\"details\":[{\"field\":\"INTENT\",\"value\":\"null/blank\",\"issue\":\"INTENT is/are missing.\",\"location\":\"request\",\"lockedChannelID\":\"\"}],\"id\":\"1008\",\"message\":\"Invalid Case Id\",\"debug_id\":\"20220603T141706.968 GMT||e3efab0b-8ba4-4dac-8378-3b9ead15d619-1863978|soe-cart-2022.06.03.14.17.06-160.68892028606697\",\"name\":\"Provided Case Id is not valid.\"}]}";
        UpdateWFMInfoUIRequest request = mapper.readValue(requestString, UpdateWFMInfoUIRequest.class);
        UpdateWFMInfoUIResponse response = mapper.readValue(responseString, UpdateWFMInfoUIResponse.class);
        when(cartHelper.updateWFMInfo(request)).thenReturn(Mono.just(response));
        URI url = URI.create("http://localhost/updateWFMInfo");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.updateWFMInfo(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateTradeInOfferTest() throws IOException {
        String requestString ="{\"cartId\":\"test-test\",\"tradeInOfferSelected\":true,\"chatId\":\"123\",\"channelId\":\"TEST\"}";
        String responseString ="{\"meta\":{\"timestamp\":\"1654617660311\",\"cxpCorrelationId\":\"2022-06-07T16:01:00.+0000:8ba95229-4770-4652-bebe-8d78d5d08fe7:cxp-customerprofile-se-qa-ev6v-sit1e-nscxp-846c776964-c74vs:nssit1\"},\"data\":{\"cartId\":\"test-test\",\"tradeInOfferSelected\":true,\"chatId\":\"123\",\"intendType\":\"TEST\"}}}\t";
        UpdateTradeInOfferUIRequest request = mapper.readValue(requestString, UpdateTradeInOfferUIRequest.class);
        UpdateTradeInOfferUIResponse response = mapper.readValue(responseString, UpdateTradeInOfferUIResponse.class);
        when(cartHelper.updateTradeInOffer(request)).thenReturn(Mono.just(response));
        URI url = URI.create("http://localhost/updateTradeInOffer");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.updateTradeInOffer(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void bbpAddZipCodeTest() throws IOException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-MOB\",\"intendType\":\"NSEBYOD\",\"zipCode\":\"92620\",\"itemType\":\"USERCONTACTINFO\"}\t";
        String responseString = "{\"status\":\"success\",\"meta\":{\"timestamp \":\"1574781308905\",\"cxpCorrelationId\":\"2019 - 11 - 26 T09: 15: 08. - 0600: 8e448008 - 8983 - 445 c - 96 f6 - d2717ab03feb: WTX0109ALDITAUX: cxp - cart - domain: nsd2 \"}}";
        AddZipCodeUIRequest request = mapper.readValue(requestString, AddZipCodeUIRequest.class);
        AddZipcodeRedisData response = mapper.readValue(responseString, AddZipcodeRedisData.class);
        when(cartHelper.addZipcode(request)).thenReturn(Mono.just(response));
        when(redisHelper2.upsertBBPFlowZipCodeDataIntoRedis(any())).thenReturn(Mono.just(true));
        URI url = URI.create("http://localhost/addZipcode");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<AddZipcodeRedisData>> controllerResponse = cartController2.bbpAddZipCode(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void bbpAddZipCodeErrorTest() throws IOException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-MOB\",\"intendType\":\"NSEBYOD\",\"zipCode\":\"92620\",\"itemType\":\"USERCONTACTINFO\"}\t";
        String responseString = "{\"status\":\"success\",\"meta\":{\"timestamp \":\"1574781308905\",\"cxpCorrelationId\":\"2019 - 11 - 26 T09: 15: 08. - 0600: 8e448008 - 8983 - 445 c - 96 f6 - d2717ab03feb: WTX0109ALDITAUX: cxp - cart - domain: nsd2 \"}}";
        AddZipCodeUIRequest request = mapper.readValue(requestString, AddZipCodeUIRequest.class);
        AddZipcodeRedisData response = mapper.readValue(responseString, AddZipcodeRedisData.class);
        when(cartHelper.addZipcode(request)).thenReturn(Mono.just(response));
        when(redisHelper2.upsertBBPFlowZipCodeDataIntoRedis(any())).thenReturn(Mono.just(false));
        URI url = URI.create("http://localhost/addZipcode");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<AddZipcodeRedisData>> controllerResponse = cartController2.bbpAddZipCode(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void bbpAddZipCodeNSETest() throws IOException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM-MOB\",\"intendType\":\"NSEBYOD\",\"itemType\":\"USERCONTACTINFO\"}\t";
        String responseString = "{\"status\":\"success\",\"meta\":{\"timestamp \":\"1574781308905\",\"cxpCorrelationId\":\"2019 - 11 - 26 T09: 15: 08. - 0600: 8e448008 - 8983 - 445 c - 96 f6 - d2717ab03feb: WTX0109ALDITAUX: cxp - cart - domain: nsd2 \"}}";
        AddZipCodeUIRequest request = mapper.readValue(requestString, AddZipCodeUIRequest.class);
        AddZipcodeRedisData response = mapper.readValue(responseString, AddZipcodeRedisData.class);
        when(cartHelper.addZipcode(request)).thenReturn(Mono.just(response));
        URI url = URI.create("http://localhost/nse/addZipcode");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<AddZipcodeRedisData>> controllerResponse = cartController2.bbpAddZipCode(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceWithPlanTest() throws IOException {
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);
        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper2.getDeviceId()).thenReturn(Mono.just("1234"));
        when(redisHelper2.getSimId()).thenReturn(Mono.just("1234"));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        when(redisHelper2.updatePromoFirstOfferData(Mockito.any())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        String requestString = "{ \"cartInfo\": { \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"processStep\": \"GridWallPDP\", \"processingMTN\": \"6205464780\", \"processAction\": \"addDevice\", \"intendType\": \"EUP\", \"number_share_capable\": \"Y\", \"creditAppNum\": null, \"isQuoteCart\": false, \"bogoEnabled\": \"True\", \"mtnFlow\" : \"PromoBundle\" }, \"data\": { \"lines\": [{ \"mtn\": \"6205464780\", \"lineDeviceDollar\": 0, \"upgradeReasonCode\": \"\", \"currentDeviceID\":\"359171071924399\", \"device\": { \"category\": \"Smartphones\", \"deviceId\": \"\", \"id\": \"SMG781VZBV\", \"contractTerm\": \"MONTH_TO_MONTH\", \"dppMonths\": \"\", \"isCustomerProvidedEquipment\": false }, \"sim\": { \"id\": \"EMBDSIM5G\", \"iccid\": \"\", \"isCustomerProvidedSIM\": false }, \"selectedOffers\": [{ \"id\": \"204600\", \"subType\": \"Trade\", \"description\": \"GET $800 OFF SELECT ANDROID DEVICES WITH TRADE IN ON DPP (24 or 30) OR FULL RETAIL WITH PREMIUM UNLIMITED PLAN. UPGRADES only. Consumer or Business. BIC - NO. All Channels. Good Condition Required.\"  }], \"plan\": { \"id\": \"26907\", \"isRecommendedPlan\": false }, \"isKeepingExistingEqProtection\": \"\", \"ispuFlow\": false, \"newLineOrAAL\": false, \"isNewLine\": false, \"depletionLocationCode\": \"\", \"depletionType\": \"F\", \"sddZipCode\": \"\", \"preBackOrderDate\": \"\", \"triggerPricingValidation\": true }], \"selectedMtn\": \"\", \"totalDeviceDollar\": 0 } }";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/addDeviceAndPlan");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.customerProfileDigital(Mockito.anyString()))
                .thenReturn(Mono.just(new CustomerProfileCXPResponse()));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDeviceAndPlan(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceWithPlanWithHeadersTest() throws IOException {
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);
        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper2.getDeviceId()).thenReturn(Mono.just("1234"));
        when(redisHelper2.getSimId()).thenReturn(Mono.just("1234"));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        when(redisHelper2.updatePromoFirstOfferData(Mockito.any())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        String requestString = "{ \"cartInfo\": { \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"processStep\": \"GridWallPDP\", \"processingMTN\": \"6205464780\", \"processAction\": \"addDevice\", \"intendType\": \"EUP\", \"number_share_capable\": \"Y\", \"creditAppNum\": null, \"isQuoteCart\": false, \"bogoEnabled\": \"True\", \"mtnFlow\" : \"PromoBundle\" }, \"data\": { \"lines\": [{ \"mtn\": \"6205464780\", \"lineDeviceDollar\": 0, \"upgradeReasonCode\": \"\", \"currentDeviceID\":\"359171071924399\", \"device\": { \"category\": \"Smartphones\", \"deviceId\": \"\", \"id\": \"SMG781VZBV\", \"contractTerm\": \"MONTH_TO_MONTH\", \"dppMonths\": \"\", \"isCustomerProvidedEquipment\": false }, \"sim\": { \"id\": \"EMBDSIM5G\", \"iccid\": \"\", \"isCustomerProvidedSIM\": false }, \"selectedOffers\": [{ \"id\": \"204600\", \"subType\": \"Trade\", \"description\": \"GET $800 OFF SELECT ANDROID DEVICES WITH TRADE IN ON DPP (24 or 30) OR FULL RETAIL WITH PREMIUM UNLIMITED PLAN. UPGRADES only. Consumer or Business. BIC - NO. All Channels. Good Condition Required.\"  }], \"plan\": { \"id\": \"26907\", \"isRecommendedPlan\": false }, \"isKeepingExistingEqProtection\": \"\", \"ispuFlow\": false, \"newLineOrAAL\": false, \"isNewLine\": false, \"depletionLocationCode\": \"\", \"depletionType\": \"F\", \"sddZipCode\": \"\", \"preBackOrderDate\": \"\", \"triggerPricingValidation\": true }], \"selectedMtn\": \"\", \"totalDeviceDollar\": 0 } }";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/addDeviceAndPlan");
        HttpHeaders headers = new HttpHeaders();
        headers.add("channelId", "OMNI-RETAIL");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).
                headers(headers).cookie(new HttpCookie("assisted_ig_session", "assisted_ig_session")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.customerProfileDigital(Mockito.anyString()))
                .thenReturn(Mono.just(new CustomerProfileCXPResponse()));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        when(tradeInHelper.validateAndAddTrade(any(),any())).thenReturn(Mono.just(response));
        request.getCartInfo().setBuyOutSelected("N");
        request.getCartInfo().setCustomerConsent(null);
        request.getCartInfo().setSkipTradeIn(false);
        response.setIsBuyOutAdded(null);
        response.setIsConsentUpdated(null);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDeviceAndPlan(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceWithPlanErrorResponseTest() throws IOException {
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);
        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper2.getDeviceId()).thenReturn(Mono.just("1234"));
        when(redisHelper2.getSimId()).thenReturn(Mono.just("1234"));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        String requestString = "{ \"cartInfo\": { \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"processStep\": \"GridWallPDP\", \"processingMTN\": \"6205464780\", \"processAction\": \"addDevice\", \"intendType\": \"EUP\", \"number_share_capable\": \"Y\", \"creditAppNum\": null, \"isQuoteCart\": false, \"bogoEnabled\": \"True\", \"mtnFlow\" : \"PromoBundle\" }, \"data\": {\"selectedMtn\": \"\", \"totalDeviceDollar\": 0 } }";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        URI url = URI.create("http://localhost/addDeviceAndPlan");
        HttpHeaders headers = new HttpHeaders();
        headers.add("channelId", "VZW-DOTCOM");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDeviceAndPlan(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void createLineDigitalTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"processStep\":\"LineSelection\",\"intendType\":\"NSE\",\"mtnFlow\":\"P\",\"customerType\":\"N\",\"cartCreatorSalesRepId\":\"ENC\",\"cartCreatorOrderLocationCode\":\"D463801\"},\"data\":{\"zipCode\":\"07920\",\"numOfLines\":1,\"lines\":[{\"mtn\":\"\",\"deviceTypeSelected\":\"\"}]}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.05.13.14.11.06-127.06731644231873\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-7242794-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"PlanSelection\"}]},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-2f3f50b1-3c2f-46ab-9e22-88d793741519\",\"processingMTN\":\"\",\"registerNumber\":0,\"mtnFlow\":\"D\",\"globalId\":\"POE-D-2f3f50b1-3c2f-46ab-9e22-88d793741519\"},\"cartInfo\":{\"financeLimitExceeded\":\"false\",\"lineNumbers\":[\"newLine1\"],\"cartItemCount\":0,\"cartId\":\"bcbfe931-c214-42e1-b240-70bb8961593a\",\"statusMsg\":\"Lines created successfully\",\"userId\":\"\",\"mtn\":\"newLine1\",\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"zipCode\":\"\",\"ecpdProfileId\":\"\",\"protectionNotRequired\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}],\"homeSalesAddress\":{}}}}}";
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLineUIResponse response = mapper.readValue(responseString, CreateLineUIResponse.class);
        URI url = URI.create("http://localhost/nse/new-line");
        HttpCookie targetPricingOffer = new HttpCookie("targetPricingOffer", "true");
        HttpCookie salesRepId = new HttpCookie("RepIdCookieText", "cookietext");
        HttpCookie ecpdToken = new HttpCookie("ecpdcookie", "cookie1:cookie2:cookie3:cookie4");
        HttpCookie ecpdDomain = new HttpCookie("domainCookie", "domain");
        HttpCookie referralVendorId = new HttpCookie("AFFILIATE", "aff");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("targetPricingOffer", targetPricingOffer);
        bodyMap.add("salesRepId", salesRepId);
        bodyMap.add("ecpdToken", ecpdToken);
        bodyMap.add("ecpdDomain", ecpdDomain);
        bodyMap.add("referralVendorId", referralVendorId);
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookies(bodyMap).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.createLine(any())).thenReturn(Mono.just(response));
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.createLine(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete();
    }

    @Test
    public void addDeviceNSETest() throws IOException {
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);
        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper2.getDeviceId()).thenReturn(Mono.just("1234"));
        when(redisHelper2.getSimId()).thenReturn(Mono.just("1234"));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"30004\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"MWGF2LL/A\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":36,\"productId\":\"dev12400034\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}],\"rtm\":{\"url\":\"https://vzwqa3.verizonwireless.com/smartphones/apple-iphone-11-pro-max/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/iphone-11-pro-max-space-gray?fmt=pjpg\",\"name\":\"iPhone 11 Pro Max\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://vzwqa3.verizonwireless.com/smartphones/apple-iphone-11-pro-max/\"}}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanPromoRecommendation\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/cart/nse/add-device");
        HttpCookie targetPricingOffer = new HttpCookie("targetPricingOffer", "true");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("targetPricingOffer", targetPricingOffer);
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-DOTCOM").cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.customerProfileDigital(Mockito.anyString()))
                .thenReturn(Mono.just(new CustomerProfileCXPResponse()));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        when(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }
    @Test
    public void addDeviceWithBuyAndPlanTest() throws IOException {

        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);
        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper2.getDeviceId()).thenReturn(Mono.just("1234"));
        when(redisHelper2.getSimId()).thenReturn(Mono.just("1234"));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        String requestString = "{ \"cartInfo\": { \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"processStep\": \"GridWallPDP\", \"processingMTN\": \"4023041959\", \"processAction\": \"addDevice\", \"intendType\": \"EUP\", \"number_share_capable\": \"Y\", \"creditAppNum\": null, \"isQuoteCart\": false, \"bogoEnabled\": \"True\", \"buyOutSelected\": \"Y\", \"customerConsent\": true, \"mtnFlow\": \"PromoBundle\", \"cartId\": \"29c32ba3-d12a-469f-b557-41f77be5d19e\", \"caseId\": \"SOP-7280909-E01\" }, \"data\": { \"lines\": [{ \"mtn\": \"4023041959\", \"lineDeviceDollar\": 0, \"upgradeReasonCode\": \"\", \"device\": { \"category\": \"Smartphones\", \"deviceId\": \"\", \"id\": \"MNF23LL/A\", \"contractTerm\": \"VERIZON_EDGE\", \"dppMonths\": 36, \"isCustomerProvidedEquipment\": false }, \"sim\": { \"id\": \"EMBDSIM5G\", \"iccid\": \"\", \"isCustomerProvidedSIM\": false }, \"downPayment\": { \"amount\": 0 }, \"isKeepingExistingEqProtection\": \"\", \"ispuFlow\": false, \"newLineOrAAL\": false, \"isNewLine\": false, \"depletionLocationCode\": \"\", \"depletionType\": \"F\", \"sddZipCode\": \"\", \"preBackOrderDate\": \"\", \"triggerPricingValidation\": true }], \"selectedMtn\": \"\", \"totalDeviceDollar\": 0 } }";
        String errorResponseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        String buoyoutResponseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-ECOM\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"Cases\": [], \"caseId\": \"SOP-329-E01\", \"contextInfo\": { \"pendingOrderAccountLevel\": \" \", \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"MTNSelectionPage/ShoppingCart\", \"processAction\": \"\" }, \"customerInfo\": { \"lookupMTN\": \" \", \"accountNumber\": \"0820215913-00001\" } } } }, \"isBuyOutAdded\": true, \"isConsentUpdated\": true }";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(buoyoutResponseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/addDeviceAndPlan");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.customerProfileDigital(Mockito.anyString())).thenReturn(Mono.just(new CustomerProfileCXPResponse()));
        when(cartHelper.addBuyoutAndConsent(Mockito.any())).thenReturn(Mono.just(response));
        when(devHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDeviceAndPlan(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

    }

    @Test
    public void addDeviceTest_Accountgrowth() throws IOException {
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);
        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper2.getDeviceId()).thenReturn(Mono.just("1234"));
        when(redisHelper2.getSimId()).thenReturn(Mono.just("1234"));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"AccountGrowth\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"mtnFlow\":\"G\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"AccountGrowth\",\"eupNoPromoFlow\":false,\"device\":{\"id\":\"MNDH3LL/A\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":true,\"dppMonths\":36,\"productId\":\"dev16720003\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":true}],\"rtm\":{\"url\":\"https://www.verizon.com/smartphones/apple-iphone-13-pro/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-green-2022?fmt=pjpg\",\"name\":\"iPhone 13 Pro\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://www.verizon.com/smartphones/apple-iphone-13-pro/\"}}}\t";
        String responseString = "{ \t\"serviceHeader\": {\t\"statusMsg\": \"SUCCESS\",\t\"serviceName\": \"SalesOrderPurchase\",\t\"userId\": \"\",\t\"statusCode\": \"00\",\t\"sessionId\": \"\",\t\"correlationId\": \"soe-cart-2022.06.24.00.44.22-226.59688110618103\" \t}, \t\"serviceBody\": {\t\"serviceResponse\": {\t\"context\": {\t\"contextInfo\": {\t\"availablePaths\": [\t{\t\"path\": \"MTNSelectionPage\"\t},\t{\t\"path\": \"ExistingCasePage\"\t}\t],\t\"callReason\": \"SalesOrderPurchase\",\t\"processStep\": \"MTNSelectionPage\",\t\"processAction\": \"\"\t},\t\"customerInfo\": {\t\"accountNumber\": \"0280800385-00001\",\t\"cartCreator\": \"6162953345\",\t\"processingMTN\": \"newLine1\",\t\"registerNumber\": 0,\t\"number_share_capable\": \"\",\t\"e911_addr_ind\": \"false\",\t\"existingCase\": \"\"\t},\t\"cartInfo\": {\t\"cartItemCount\": 0,\t\"discountPromoTotal\": 0.0,\t\"registerNumber\": 0,\t\"protectionNotRequired\": false\t},\t\"processMTNList\": [\t{\t\"mtn\": \"newLine1\",\t\"completedprocessSteps\": [\t\"GridWallPDP\",\t\"GridWallPDP\",\t\"MTNSelectionPage\",\t\"MTNSelectionPage\",\t\"PromoHub\",\t\"GridWallPDP\",\t\"GridWallPDP\",\t\"MTNSelectionPage\",\t\"DPPSummary\",\t\"GridWallPDP\",\t\"MTNSelectionPage\",\t\"TradeIn\",\t\"PromoHub\",\t\"GridWallPDP\",\t\"MTNSelectionPage\",\t\"GridWallPDP\",\t\"MTNSelectionPage\",\t\"PromoHub\",\t\"GridWallPDP\"\t]\t}\t]\t}\t} \t} }";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/add-device");
        HttpCookie targetPricingOffer = new HttpCookie("targetPricingOffer", "true");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("targetPricingOffer", targetPricingOffer);
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.customerProfileDigital(Mockito.anyString()))
                .thenReturn(Mono.just(new CustomerProfileCXPResponse()));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        when(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceTest1() throws IOException {
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);
        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper2.getDeviceId()).thenReturn(Mono.just("1234"));
        when(redisHelper2.getSimId()).thenReturn(Mono.just("1234"));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        String requestString = "{\"channelId\":\"VZW-DOTCOM\",\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"AccountGrowth\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"mtnFlow\":\"G\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"AccountGrowth\",\"eupNoPromoFlow\":false,\"device\":{\"id\":\"MNDH3LL/A\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":true,\"dppMonths\":36,\"productId\":\"dev16720003\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":true}],\"rtm\":{\"url\":\"https://www.verizon.com/smartphones/apple-iphone-13-pro/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-green-2022?fmt=pjpg\",\"name\":\"iPhone 13 Pro\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://www.verizon.com/smartphones/apple-iphone-13-pro/\"}}}\t";
        String responseString = "{ \t\"serviceBody\": {\t\"serviceResponse\": {\t\"context\": {\t\"contextInfo\": {\t\"availablePaths\": [\t{\t\"path\": \"MTNSelectionPage\"\t},\t{\t\"path\": \"ExistingCasePage\"\t}\t],\t\"callReason\": \"SalesOrderPurchase\",\t\"processStep\": \"MTNSelectionPage\",\t\"processAction\": \"\"\t},\t\"customerInfo\": {\t\"accountNumber\": \"0280800385-00001\",\t\"cartCreator\": \"6162953345\",\t\"processingMTN\": \"newLine1\",\t\"registerNumber\": 0,\t\"number_share_capable\": \"\",\t\"e911_addr_ind\": \"false\",\t\"existingCase\": \"\"\t},\t\"cartInfo\": {\t\"cartItemCount\": 0,\t\"discountPromoTotal\": 0.0,\t\"registerNumber\": 0,\t\"protectionNotRequired\": false\t},\t\"processMTNList\": [\t{\t\"mtn\": \"newLine1\",\t\"completedprocessSteps\": [\t\"GridWallPDP\",\t\"GridWallPDP\",\t\"MTNSelectionPage\",\t\"MTNSelectionPage\",\t\"PromoHub\",\t\"GridWallPDP\",\t\"GridWallPDP\",\t\"MTNSelectionPage\",\t\"DPPSummary\",\t\"GridWallPDP\",\t\"MTNSelectionPage\",\t\"TradeIn\",\t\"PromoHub\",\t\"GridWallPDP\",\t\"MTNSelectionPage\",\t\"GridWallPDP\",\t\"MTNSelectionPage\",\t\"PromoHub\",\t\"GridWallPDP\"\t]\t}\t]\t}\t} \t} }";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/add-device");
        HttpCookie targetPricingOffer = new HttpCookie("targetPricingOffer", "true");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("targetPricingOffer", targetPricingOffer);
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.customerProfileDigital(Mockito.anyString()))
                .thenReturn(Mono.just(new CustomerProfileCXPResponse()));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        when(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceNSESHubProspectCartTest() throws IOException {
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);
        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper2.getDeviceId()).thenReturn(Mono.just("1234"));
        when(redisHelper2.getSimId()).thenReturn(Mono.just("1234"));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"30004\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"device\":{\"id\":\"MWGF2LL/A\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":36,\"productId\":\"dev12400034\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false}],\"rtm\":{\"url\":\"https://vzwqa3.verizonwireless.com/smartphones/apple-iphone-11-pro-max/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/iphone-11-pro-max-space-gray?fmt=pjpg\",\"name\":\"iPhone 11 Pro Max\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://vzwqa3.verizonwireless.com/smartphones/apple-iphone-11-pro-max/\"}}}";
        String responseString = "{\"serviceHeader\": {\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\" },\"serviceBody\": {\"serviceResponse\": {\"context\": {\"Cases\": [],\"caseId\":\"SOP-329-E01\",\"contextInfo\": {\"pendingOrderAccountLevel\":\"\",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"NewRecommendedPlanSelection\",\"processAction\":\"\"},\"customerInfo\": {\"lookupMTN\":\"\",\"accountNumber\":\"0820215913-00001\"}}} } }";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/cart/nse/add-device");
        HttpCookie targetPricingOffer = new HttpCookie("targetPricingOffer", "true");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("targetPricingOffer", targetPricingOffer);
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-DOTCOM").cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.customerProfileDigital(Mockito.anyString()))
                .thenReturn(Mono.just(new CustomerProfileCXPResponse()));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        when(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateWFMInfoTest1() throws IOException {
        String requestString = "{\"cartInfo\":{\"processingMTN\":\"8604634931\",\"processStep\":\"ShoppingCart\",\"intendType\":\"EUP\",\"intent\":\"EUP\"},\"data\":{\"wfmOrderInfo\":{\"wfmId\":\"994521288118421\",\"wfmOrderId\":\"142004005\",\"wfmUserId\":\"kumni5j\",\"wfmOrderType\":\"C\"}}}\t";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-CARE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.05.26.11.25.47-945.1017659367217\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4050336-C01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"updateWFM\"},\"customerInfo\":{\"customerType\":\"\",\"accountNumber\":\"0281351635-00001\",\"cartCreator\":\"8604634931\",\"processingMTN\":\"8604634931\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"c21abbdc-eb09-464c-a825-984a7693e760\",\"statusMsg\":\"WfmOrderInfo details updated successfully\",\"statusCode\":\"1\",\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false},\"processMTNList\":[{\"mtn\":\"8604634931\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\",\"PromoHub\",\"OrderReview-Shipping-Payment-Agreement\",\"ReadOrderPage\",\"ShoppingCart\"]}]}}}}";
        UpdateWFMInfoUIRequest request = mapper.readValue(requestString, UpdateWFMInfoUIRequest.class);
        UpdateWFMInfoUIResponse response = mapper.readValue(responseString, UpdateWFMInfoUIResponse.class);
        when(cartHelper.updateWFMInfo(request)).thenThrow(new RuntimeException());
        URI url = URI.create("http://localhost/updateWFMInfo");
        HttpHeaders headers = new HttpHeaders();
        headers.add("channelId", "channelIdx");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.updateWFMInfo(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).expectError();
    }

    @Test
    public void clearAndContinueTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"mtnFlow\":\"M\",\"recommendationSelection\":\"BYOD\",\"inWithVerizonOpted\":true}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1324635-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryPDP\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryPDP\",\"processAction\":\"\"},\"customerInfo\":{\"registerNumber\":0,\"accountNumber\":\"0388697212-00001\",\"cartCreator\":\"8609316888\",\"processingMTN\":\"8609316888\"},\"cartInfo\":{\"cartId\":\"a3abdc6a-3359-402a-8ed4-2663f123f132\",\"statusCode\":\"1\",\"statusMsg\":\"Success\",\"lines\":[{\"accessories\":{},\"mtn\":\"8609316888\"}],\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"8609316888\",\"completedprocessSteps\":[\"pastDuePage\",\"AccessoryPDP\"]}]}}}}";
        ClearAndContinueUIRequest request = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
        ClearAndContinueUIResponse response = mapper.readValue(responseString, ClearAndContinueUIResponse.class);
        String getDataFromRedisAsString = "{\"cartId\":\"5d11107a-9df0-40d4-b4c2-1e9baf89ff4a\",\"caseId\":\"SOP-1075631-E01\",\"accountNumber\":\"0280882722-00001\",\"mtn\":\"3175174243\",\"processingMTN\":\"3175174243\",\"cartCreator\":\"3175174243\"}";
        String getItemTypeFromRedisString = "device";
        CartRedisData sampleRedisData = mapper.readValue(getDataFromRedisAsString, CartRedisData.class);
        URI url = URI.create("http://localhost/clearAndContinue");
        HttpCookie cookie = new HttpCookie(CartConstants.FROM_FREE_PHONES_QV, "true");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add(CartConstants.FROM_FREE_PHONES_QV, cookie);
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.valueOf(200));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just(getItemTypeFromRedisString));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getAccessoryDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(true));
        when(cartHelper.clearAndContinue(any())).thenReturn(Mono.just(response));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.clearAndContinue(httpHeader,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }
}
