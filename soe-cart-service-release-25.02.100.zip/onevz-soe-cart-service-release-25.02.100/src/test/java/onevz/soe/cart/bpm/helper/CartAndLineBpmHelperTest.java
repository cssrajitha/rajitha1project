package onevz.soe.cart.bpm.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.SneakyThrows;
import onevz.soe.cart.bpm.service.CartServiceBPMServices;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.casemgmt.CaseMgmtCustomerInfo;
import onevz.soe.cart.model.common.CartServiceCartInfo;
import onevz.soe.cart.model.common.CartServiceCustomerInfo;
import onevz.soe.cart.model.createCartAndLine.CreateCartAndLineServiceBody;
import onevz.soe.cart.model.createCase2.CreateCaseNewCustomerPEGAResponse;
import onevz.soe.cart.requests.CommonCartPEGARequest;
import onevz.soe.cart.requests.CreateCaseUIRequest;
import onevz.soe.cart.responses.CommonCartPEGAResponse;
import onevz.soe.cart.responses.CreateCartAndLinePEGAResponse;
import onevz.soe.cart.responses.CreateCaseUIResponse;
import onevz.soe.cart.responses.ResumeCaseBPMResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.common.CartInfo;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.CommonCartCustomerInfo;
import onevz.soe.cart.ui.requests.CommonCartUIRequest;
import onevz.soe.cart.ui.requests.ResumeCaseUIRequest;
import onevz.soe.cart.ui.responses.CartAndLineUIResponse;
import onevz.soe.cart.ui.responses.CommonCartUIResponse;
import onevz.soe.cart.ui.responses.ResumeCaseUIResponse;
import onevz.soe.spring.web.filter.RequestAccessContext;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.apache.commons.io.IOUtils;
import org.assertj.core.api.Assertions;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpCookie;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.nio.charset.Charset;
import java.util.Objects;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.eq;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {CartServiceTestConfig.class})
public class CartAndLineBpmHelperTest {

    @Mock
    CartServiceBPMServices bpmServices;

    @InjectMocks
    CartAndLineBpmHelper cartAndLineBpmHelper;

    @Autowired
    ObjectMapper mapper;
    @Mock
    ObjectMapper objectMapper;
    
    @Before
    public void setUp() {
        RequestAccessContext.RequestAccess requestAccess = new RequestAccessContext.RequestAccess();
        requestAccess.getCookies().add(CartConstants.DVM_CONVERSION_FLAG, new HttpCookie("dvmConversion", "true"));
        RequestAccessContext.updateRequestData(requestAccess);
    }

    @Test
    public void test_createCartAndLine_success() throws SOEHTTPException {
        CommonCartUIRequest request = getCommonCartUIRequest();
        request.getCartInfo().setFlowType("");

        CreateCartAndLinePEGAResponse pegaResponse = new CreateCartAndLinePEGAResponse();
        pegaResponse.setServiceBody(new CreateCartAndLineServiceBody());

        Mockito.when(bpmServices.createCartAndLine(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mono<CartAndLineUIResponse> response = cartAndLineBpmHelper.createCartAndLine(request, "clientId");
        StepVerifier.create(response).assertNext(r -> {
            Assert.assertNotNull(r);
        }).verifyComplete();
    }

    @Test
    public void test_createCartAndLine_success_registerNumberNull() throws SOEHTTPException {
        CommonCartUIRequest request = getCommonCartUIRequest();
        request.getCartInfo().setRegisterNumber(null);
        request.getCartInfo().setFlowType("");
        CreateCartAndLinePEGAResponse pegaResponse = new CreateCartAndLinePEGAResponse();
        pegaResponse.setServiceBody(new CreateCartAndLineServiceBody());

        Mockito.when(bpmServices.createCartAndLine(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mono<CartAndLineUIResponse> response = cartAndLineBpmHelper.createCartAndLine(request, "clientId");
        StepVerifier.create(response).assertNext(r -> {
            Assert.assertNotNull(r);
        }).verifyComplete();
    }

    @Test
    public void test_createCartAndLine_success_withplanBuilderFlowType() throws SOEHTTPException {
        CommonCartUIRequest request = getCommonCartUIRequest();
        CreateCartAndLinePEGAResponse pegaResponse = new CreateCartAndLinePEGAResponse();
        pegaResponse.setServiceBody(new CreateCartAndLineServiceBody());

        Mockito.when(bpmServices.createCartAndLine(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mono<CartAndLineUIResponse> response = cartAndLineBpmHelper.createCartAndLine(request, "PLAN_BUILDER");
        StepVerifier.create(response).assertNext(r -> {
            Assert.assertNotNull(r);
        }).verifyComplete();
    }

    @Test
    public void test_createCartAndLine_success_withLineSelectionProsessStep() throws SOEHTTPException {
        CommonCartUIRequest request = getCommonCartUIRequest();
        request.getCartInfo().setProcessStep("LineSelection");
        CreateCartAndLinePEGAResponse pegaResponse = new CreateCartAndLinePEGAResponse();

        pegaResponse.setServiceBody(new CreateCartAndLineServiceBody());

        Mockito.when(bpmServices.createCartAndLine(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mono<CartAndLineUIResponse> response = cartAndLineBpmHelper.createCartAndLine(request, "PLAN_BUILDER");
        StepVerifier.create(response).assertNext(r -> {
            Assert.assertNotNull(r);
        }).verifyComplete();
    }

    private CommonCartUIRequest getCommonCartUIRequest() {
        CommonCartUIRequest request = new CommonCartUIRequest();
        request.setCartInfo(new CartInfo());
        request.setData(new CommonCartCustomerInfo());
        request.getCartInfo().setFlowType("PLAN_BUILDER");
        request.getCartInfo().setRegisterNumber(0);
        return request;
    }

    @Test
    public void test_createCartAndLine_success_withLines_inPayload() throws SOEHTTPException {
        CommonCartUIRequest request = getCommonCartUIRequest();
        Lines line = new Lines();
        line.setDeviceTypeSelected("Smartphones");
        Lines[] lines = new Lines[1];
        lines[0] = line;
        request.getData().setLines(lines);

        CreateCartAndLinePEGAResponse pegaResponse = new CreateCartAndLinePEGAResponse();
        pegaResponse.setServiceBody(new CreateCartAndLineServiceBody());

        Mockito.when(bpmServices.createCartAndLine(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mono<CartAndLineUIResponse> response = cartAndLineBpmHelper.createCartAndLine(request, "PLAN_BUILDER");
        StepVerifier.create(response).assertNext(r -> {
            Assert.assertNotNull(r);
        }).verifyComplete();
    }

    @Test
    public void test_createCartAndLine_error() throws SOEHTTPException {
        CommonCartUIRequest request = getCommonCartUIRequest();

        CreateCartAndLinePEGAResponse pegaResponse = new CreateCartAndLinePEGAResponse();
        pegaResponse.setServiceBody(new CreateCartAndLineServiceBody());

        Mockito.when(bpmServices.createCartAndLine(Mockito.any())).thenReturn(Mono.error(new RuntimeException()));
        Mono<CartAndLineUIResponse> response = cartAndLineBpmHelper.createCartAndLine(request, "");
        StepVerifier.create(response).verifyError();
    }

    @Test
    public void test_createCartAndLine_exceptionByPEGA() throws SOEHTTPException {
        CommonCartUIRequest request = getCommonCartUIRequest();

        CreateCartAndLinePEGAResponse pegaResponse = new CreateCartAndLinePEGAResponse();
        pegaResponse.setServiceBody(new CreateCartAndLineServiceBody());

        Mockito.when(bpmServices.createCartAndLine(Mockito.any())).thenThrow(new SOEHTTPException(500, "error"));
        Mono<CartAndLineUIResponse> response = cartAndLineBpmHelper.createCartAndLine(request, "");
        StepVerifier.create(response).assertNext(r -> {
            Assert.assertNotNull(r);
            Assert.assertNotNull(r.getErrors());
        }).verifyComplete();
    }


	@Test
	public void test_buildLine_success_withLines_inPayload() throws JsonProcessingException, SOEHTTPException {
		String pagerequest = "{\"serviceHeader\":{\"clientId\":\"VZW-OMNI-RETAIL\",\"statusMsg\":\"PEGA generated message\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"\",\"processingMTN\":\"newLine2\",\"cartCreator\":\"110322253028\",\"customerType\":\"N\",\"mtnFlow\":\"P\",\"chatId\":\"\",\"globalId\":\"110322253028\",\"originalCreditApprovalNumber \":\"\",\"flowType\":\"PLAN_BUILDER\"},\"cartInfo\":{\"cartId\":\"bea202a6-42cb-40d4-ac87-d3f1db2b3f13\"},\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"intent\":\"NSE\",\"processStep\":\"ShoppingCart\",\"processAction\":\"buildLine\"}}}}}";
		String pagerespone = "{\"serviceHeader\":{\"clientId\":\"VZW-OMNI-RETAIL\",\"statusMsg\":\"PEGA generated message\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\" SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"\",\"processingMTN\":\"newLine2\",\"cartCreator\":\"110322253028\",\"customerType\":\"N\",\"originalCreditApprovalNumber \":\"\",\"globalId\":\"110322253028\",\"flowType\":\"PLAN_BUILDER\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[\"LineSelection\",\"NewRecommendedPlanSelection\"]}],\"cartInfo\":{\"cartId\":\"bea202a6-42cb-40d4-ac87-d3f1db2b3f13\"},\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"PlanSelection\",\"availablePaths\":[{\"path\":\"PlanSelection\"}],\"callReason\":\"SalesOrderPurchase\"}}}}}";
		String uirequest = "{\"data\":{\"accountNumber\":\"\",\"processingMTN\":\"newLine2\",\"cartCreator\":\"110322253028\",\"customerType\":\"N\",\"mtnFlow\":\"P\",\"chatId\":\"\",\"globalId\":\"110322253028\",\"originalCreditApprovalNumber \":\"\",\"flowType\":\"PLAN_BUILDER\"},\"cartInfo\":{\"caseId\":\"SOP-1583186-DEV3\",\"cartId\":\"bea202a6-42cb-40d4-ac87-d3f1db2b3f13\"}}";
		CommonCartPEGARequest pegarequest = new CommonCartPEGARequest();
		pegarequest =  mapper.readValue(pagerequest, CommonCartPEGARequest.class);
		
		CommonCartPEGAResponse pegaResponse = new CommonCartPEGAResponse();
		pegaResponse = mapper.readValue(pagerespone, CommonCartPEGAResponse.class);
		
		CommonCartUIRequest request = getCommonCartUIRequest();
		Mockito.when(bpmServices.buildLine(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        String planbuilder = "PLAN_BUILDER";
        Mockito.when(objectMapper.writeValueAsString(Mockito.any())).thenReturn("");
        Mockito.when(objectMapper.readValue(Mockito.anyString(),eq(CartServiceCustomerInfo.class))).thenReturn(Mockito.mock(CartServiceCustomerInfo.class));
        Mono<CommonCartUIResponse> response = cartAndLineBpmHelper.buildLine(request,planbuilder);
		StepVerifier.create(response).assertNext(r -> {
			Assert.assertNotNull(r);
		}).verifyComplete();
	}

    @Test
    public void test_buildLine_Exception() throws JsonProcessingException, SOEHTTPException {
        String planbuilder = "PLAN_BUILDER";


        CommonCartUIRequest request = getCommonCartUIRequest();

        Mockito.when(objectMapper.writeValueAsString(Mockito.any())).thenReturn("");
        Mockito.when(bpmServices.buildLine(Mockito.any())).thenThrow(new SOEHTTPException(500, "error"));
        Mono<CommonCartUIResponse> response= cartAndLineBpmHelper.buildLine(request,planbuilder);
        StepVerifier.create(response).assertNext(Assert::assertNotNull).verifyComplete();

    }
	
	@Test
	public void test_deleteCart_success_withLines_inPayload() throws JsonProcessingException, SOEHTTPException {
		String pagerequest = "{\"serviceHeader\":{\"clientId\":\"VZW-OMNI-RETAIL\",\"statusMsg\":\"PEGA generated message\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"\",\"processingMTN\":\"newLine1\",\"cartCreator\":\"110322253028\",\"globalId\":\"110322253028\",\"originalCreditApprovalNumber \":\"\",\"customerType\":\"N\",\"mtnFlow\":\"P\",\"accountLevelPlan\":\"\",\"flowType\":\"PLAN_BUILDER\"},\"cartInfo\":{\"cartId\":\"614b25e2-56bb-40e5-85f8-024542aa9a66\"},\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"intent\":\"NSE\",\"processStep\":\"ExitPage\",\"processAction\":\"Cancel\"}}}}}";
		String pagerespone = "{\"serviceHeader\":{\"clientId\":\"VZW-OMNI-RETAIL\",\"statusMsg\":\"PEGA generated message\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\" SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"110322253028\",\"originalCreditApprovalNumber \":\"\",\"globalId\":\"110322253028\",\"customerType\":\"N\",\"processingMTN\":\"newLine1\",\"flowType\":\"PLAN_BUILDER\"},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"GridWallPDP\"]}],\"cartInfo\":{\"cartId\":\"614b25e2-56bb-40e5-85f8-024542aa9a66\",\"statusCode\":\"200\",\"statusMsg\":\"Cart delete is Success\"},\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"ExitPage\",\"availablePaths\":[{\"path\":\"ExitPage\"}],\"callReason\":\" SalesOrderPurchase \"}}}}}";
		String uirequest = "{\"data\":{\"accountNumber\":\"\",\"processingMTN\":\"newLine1\",\"cartCreator\":\"110322253028\",\"globalId\":\"110322253028\",\"customerType\":\"N\",\"mtnFlow\":\"P\",\"accountLevelPlan\":\"\",\"flowType\":\"PLAN_BUILDER\"},\"cartInfo\":{\"caseId\":\"SOP-1583186-DEV3\",\"cartId\":\"614b25e2-56bb-40e5-85f8-024542aa9a66\"}}";
		CommonCartPEGARequest pegarequest = new CommonCartPEGARequest();
		pegarequest =  mapper.readValue(pagerequest, CommonCartPEGARequest.class);
		
		CommonCartPEGAResponse pegaResponse = new CommonCartPEGAResponse();
		pegaResponse = mapper.readValue(pagerespone, CommonCartPEGAResponse.class);
		
		CommonCartUIRequest request = getCommonCartUIRequest();
		Mockito.when(bpmServices.deleteCart(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        String planbuilder = "PLAN_BUILDER";
        Mockito.when(objectMapper.writeValueAsString(Mockito.any())).thenReturn("");
        Mockito.when(objectMapper.readValue(Mockito.anyString(),eq(CartServiceCustomerInfo.class))).thenReturn(Mockito.mock(CartServiceCustomerInfo.class));
        Mono<CommonCartUIResponse> response = cartAndLineBpmHelper.deleteCart(request,planbuilder);
		StepVerifier.create(response).assertNext(r -> {
			Assert.assertNotNull(r);
		}).verifyComplete();
	}
    @Test
    public void test_deleteCart_exceptionByPega() throws SOEHTTPException, JsonProcessingException {

        String planbuilder = "PLAN_BUILDER";
        CommonCartUIRequest request = getCommonCartUIRequest();

        Mockito.when(objectMapper.writeValueAsString(Mockito.any())).thenReturn("");
        Mockito.when(bpmServices.deleteCart(Mockito.any())).thenThrow(new SOEHTTPException(500, "error"));
        Mono<CommonCartUIResponse> response= cartAndLineBpmHelper.deleteCart(request,planbuilder);
        StepVerifier.create(response).assertNext(Assert::assertNotNull).verifyComplete();
    }

	@Test
    public void test_resumecase_success() throws SOEHTTPException, JsonProcessingException {
        String planbuilder = "PLAN_BUILDER";
        ResumeCaseUIRequest uiRequest = new ResumeCaseUIRequest();
        uiRequest.setCartInfo(new CartInfo());
        uiRequest.getCartInfo().setCartId("ituwq12354iu-51435341hj-asmncds8");
        uiRequest.getCartInfo().setCaseId("SOP-1736484");
        uiRequest.setData(new ResumeCaseUIRequest.ResumeCartData());
        ResumeCaseBPMResponse pegaResponse = new ResumeCaseBPMResponse();
        Mockito.when(objectMapper.writeValueAsString(Mockito.any())).thenReturn("");
        Mockito.when(bpmServices.resumeCase(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mono<ResumeCaseUIResponse> response= cartAndLineBpmHelper.resumeCase(uiRequest,"OMNI-RETAIL-TAB");
        StepVerifier.create(response).assertNext(Assert::assertNotNull).verifyComplete();
    }

    @Test
    public void test_resumecase_exceptionByPega() throws SOEHTTPException, JsonProcessingException {
        String planbuilder = "PLAN_BUILDER";
        ResumeCaseUIRequest uiRequest = new ResumeCaseUIRequest();
        uiRequest.setCartInfo(new CartInfo());
        uiRequest.getCartInfo().setCartId("ituwq12354iu-51435341hj-asmncds8");
        uiRequest.getCartInfo().setCaseId("SOP-1736484");
        uiRequest.setData(new ResumeCaseUIRequest.ResumeCartData());
        ResumeCaseBPMResponse pegaResponse = new ResumeCaseBPMResponse();
        Mockito.when(objectMapper.writeValueAsString(Mockito.any())).thenReturn("");
        Mockito.when(bpmServices.resumeCase(Mockito.any())).thenThrow(new SOEHTTPException(500, "error"));
        Mono<ResumeCaseUIResponse> response= cartAndLineBpmHelper.resumeCase(uiRequest,"OMNI-RETAIL-TAB");
        StepVerifier.create(response).assertNext(Assert::assertNotNull).verifyComplete();
    }

    @Test
    public void test_createCase_exception() throws SOEHTTPException, JsonProcessingException {
        String planbuilder = "PLAN_BUILDER";
        CreateCaseUIRequest uiRequest = new CreateCaseUIRequest();
        uiRequest.setCartInfo(new CartInfo());
        uiRequest.setData(new CreateCaseUIRequest.CreateCartData());

        Mockito.when(objectMapper.writeValueAsString(Mockito.any())).thenReturn("");
        Mockito.when(bpmServices.createCasePlanBuilder(Mockito.any())).thenThrow(new SOEHTTPException(500, "error"));
        Mono<CreateCaseUIResponse> response= cartAndLineBpmHelper.createCase(uiRequest,"OMNI-RETAIL-TAB");
        StepVerifier.create(response).assertNext(Assert::assertNotNull).verifyComplete();
    }

    @Test
    public void test_createCase_success() throws SOEHTTPException, JsonProcessingException {
        String planbuilder = "PLAN_BUILDER";
        CreateCaseUIRequest uiRequest = new CreateCaseUIRequest();
        uiRequest.setCartInfo(new CartInfo());
        uiRequest.setData(new CreateCaseUIRequest.CreateCartData());

        CreateCaseNewCustomerPEGAResponse pegaResponse = new CreateCaseNewCustomerPEGAResponse();
        Mockito.when(objectMapper.writeValueAsString(Mockito.any())).thenReturn("");
        Mockito.when(bpmServices.createCasePlanBuilder(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mono<CreateCaseUIResponse> response= cartAndLineBpmHelper.createCase(uiRequest,"OMNI-RETAIL-TAB");
        StepVerifier.create(response).assertNext(Assert::assertNotNull).verifyComplete();
    }
    
    @Test
    @SneakyThrows
    public void resumeCase_populateResumeCaseCustomerInfo_CodeCoverageTest(){
        var uiRequest = new ResumeCaseUIRequest();
        var cartInfo = new CartInfo();
        var uuid = UUID.randomUUID().toString();
        cartInfo.setCartId(uuid);
        cartInfo.setCaseId(uuid);
        cartInfo.setQuoteWithoutCredit(true);
        cartInfo.setChatId("CHAT-10239");
        uiRequest.setCartInfo(cartInfo);
        ResumeCaseUIRequest.ResumeCartData data = new ResumeCaseUIRequest.ResumeCartData();
        data.setErtrep(true);
        data.setNoc(true);
        data.setOriginalCreditApprovalNumber(102);
        data.setStandAloneTradein(true);
        data.setSkipMissedProfileEmailValidation(true);
        uiRequest.setData(data);
        RequestAccessContext.RequestAccess requestAccess = new RequestAccessContext.RequestAccess();
        requestAccess.getCookies().add(CartConstants.DVM_CONVERSION_FLAG, new HttpCookie("dvmConversion", "false"));
        RequestAccessContext.updateRequestData(requestAccess);
        CaseMgmtCustomerInfo caseMgmtCustomerInfo = ReflectionTestUtils.invokeMethod(cartAndLineBpmHelper, "populateResumeCaseCustomerInfo", uiRequest);
        Assertions.assertThat(caseMgmtCustomerInfo).isNotNull();
        Assertions.assertThat(caseMgmtCustomerInfo.getChatId()).isNotNull();
    }
    
    @Test
    @SneakyThrows
    public void createCase_populateCreateCaseCartInfo_CodeCoverageTest() {
        var json = IOUtils.toString(Objects.requireNonNull(this.getClass().getResourceAsStream("/AddDeviceUIRequestDPP.json")), Charset.defaultCharset());
        var createCaseUIRequest = mapper.readValue(json, CreateCaseUIRequest.class);
        createCaseUIRequest.getCartInfo().setRegisterNumber(39733);
        CartServiceCartInfo caseCartInfo = ReflectionTestUtils.invokeMethod(cartAndLineBpmHelper, "populateCreateCaseCartInfo", createCaseUIRequest);
        Assertions.assertThat(caseCartInfo).isNotNull();
        Assertions.assertThat(caseCartInfo.getLines()).isNotEmpty().hasSize(1);
        Assertions.assertThat(caseCartInfo.getRegisterNumber()).isEqualTo(39733);
    }

}

