package onevz.soe.cart.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.cxp.feature.Flag;
import onevz.soe.cart.constants.FeatureFlagConstants;
import onevz.soe.cart.requests.AddPlanPEGARequest;
import onevz.soe.cart.ui.requests.AddPlanUIRequest;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertNotNull;

public class CartPegaRequestUtil2Test {

    @InjectMocks
    private CartPegaRequestUtil2 cartPegaRequestUtil2;

    private static final ObjectMapper MAPPER = new ObjectMapper();

    @Before
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    private Flag getFeatureFlag() {
        Flag flag = new Flag();
        flag.setName(FeatureFlagConstants.FLAG_NAME_ACTIVATION_FEE_WAIVER_FFAG);
        flag.setEnabled(true);
        flag.setFound(true);

        flag.setAttributes(Map.of("offerCode", List.of("DP2PM")));
        return flag;
    }

    private void executeFormatAddPlanRequestTest(
            String sampleUIReq,
            boolean enableWHWSPOMode,
            boolean isFwaChoiceOfferFeatureFlag,
            boolean isOppConfiguratorFlag
    ) throws Exception {
        AddPlanPEGARequest addPlanPEGARequest = new AddPlanPEGARequest();
        AddPlanUIRequest addPlanUIRequest = MAPPER.readValue(sampleUIReq, AddPlanUIRequest.class);

        AddPlanPEGARequest result = CartPegaRequestUtil2.formatAddPlanRequest(
                addPlanPEGARequest,
                addPlanUIRequest,
                enableWHWSPOMode,
                isFwaChoiceOfferFeatureFlag,
                getFeatureFlag(),
                isOppConfiguratorFlag
        );

        assertNotNull(result);
    }

    @Test
    public void formatAddPlanRequestTest_unifiedNbsFlag() throws Exception {
        String sampleUIReq = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM-BBP\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"cartId\":\"\",\"caseId\":\"\",\"editPlanClick\":false,\"expressCheckout\":false,\"isSmartLocator\":false,\"processingMTN\":\"newLine1\",\"intendType\":\"BYOD\",\"processStep\":\"AccountPlanPage\",\"processAction\":\"addPlan\"},\"data\":{\"lines\":[{\"mtn\":\"newLine1\",\"plan\":{\"id\":\"47315\"}}],\"effectiveDate\":\"08/12/2024\",\"checkAutoPayDiscountEligible\":\"Y\"},\"unifiedNbsFlag\":true}";
        executeFormatAddPlanRequestTest(sampleUIReq, true, false, true);
    }

    @Test
    public void formatAddPlanRequestTest_withoutUnifiedNbsFlag() throws Exception {
        String sampleUIReq = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM-BBP\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"cartId\":\"\",\"caseId\":\"\",\"editPlanClick\":false,\"expressCheckout\":false,\"isSmartLocator\":false,\"processingMTN\":\"newLine1\",\"intendType\":\"BYOD\",\"processStep\":\"AccountPlanPage\",\"processAction\":\"addPlan\"},\"data\":{\"lines\":[{\"mtn\":\"newLine1\",\"plan\":{\"id\":\"47315\"}}],\"effectiveDate\":\"08/12/2024\",\"checkAutoPayDiscountEligible\":\"Y\"}}";
        executeFormatAddPlanRequestTest(sampleUIReq, true, false, false);
    }

    @Test
    public void formatAddPlanRequestTest_withPromoIntent() throws Exception {
        String sampleUIReq = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM-BBP\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"cartId\":\"\",\"caseId\":\"\",\"editPlanClick\":false,\"expressCheckout\":false,\"isSmartLocator\":false,\"processingMTN\":\"newLine1\",\"intendType\":\"BYOD\",\"processStep\":\"AccountPlanPage\",\"processAction\":\"addPlan\"},\"data\":{\"lines\":[{\"mtn\":\"newLine1\",\"plan\":{\"id\":\"47315\"},\"promoIntent\":[{\"promotionId\":\"promo4380283\",\"offerId\":\"601231\",\"promoType\":\"Simple\",\"isStrategicOffer\":\"true\",\"choiceOffer\":\"true\"}]}],\"effectiveDate\":\"08/12/2024\",\"checkAutoPayDiscountEligible\":\"Y\"},\"unifiedNbsFlag\":true}";
        executeFormatAddPlanRequestTest(sampleUIReq, true, true, true);
    }

    @Test
    public void formatAddPlanRequestTest_withWifiBackup() throws Exception {
        String sampleUIReq = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM-BBP\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"cartId\":\"\",\"caseId\":\"\",\"editPlanClick\":false,\"expressCheckout\":false,\"isSmartLocator\":false,\"processingMTN\":\"newLine1\",\"intendType\":\"BYOD\",\"processStep\":\"AccountPlanPage\",\"processAction\":\"addPlan\",\"isWifiBackup\":true},\"data\":{\"lines\":[{\"mtn\":\"newLine1\",\"plan\":{\"id\":\"47315\"},\"promoIntent\":[{\"promotionId\":\"promo4380283\",\"offerId\":\"601231\",\"promoType\":\"Simple\",\"isStrategicOffer\":\"true\",\"choiceOffer\":\"true\"}]}],\"effectiveDate\":\"08/12/2024\",\"checkAutoPayDiscountEligible\":\"Y\"},\"unifiedNbsFlag\":true}";
        executeFormatAddPlanRequestTest(sampleUIReq, true, false, true);
    }
}
