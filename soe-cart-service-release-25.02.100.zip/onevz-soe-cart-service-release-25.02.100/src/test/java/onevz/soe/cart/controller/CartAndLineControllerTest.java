package onevz.soe.cart.controller;

import onevz.soe.cart.bpm.helper.CartAndLineBpmHelper;
import onevz.soe.cart.model.commonCart.CommonCartPegaServiceBody;
import onevz.soe.cart.model.createCartAndLine.CreateCartAndLineServiceBody;
import onevz.soe.cart.requests.CreateCaseUIRequest;
import onevz.soe.cart.responses.CommonCartPEGAResponse;
import onevz.soe.cart.responses.CreateCartAndLinePEGAResponse;
import onevz.soe.cart.responses.CreateCaseUIResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.common.CartInfo;
import onevz.soe.cart.ui.requests.CommonCartCustomerInfo;
import onevz.soe.cart.ui.requests.CommonCartUIRequest;
import onevz.soe.cart.ui.requests.ResumeCaseUIRequest;
import onevz.soe.cart.ui.responses.CartAndLineUIResponse;
import onevz.soe.cart.ui.responses.CommonCartUIResponse;
import onevz.soe.cart.ui.responses.ResumeCaseUIResponse;
import onevz.soe.session.constants.SessionBuilder;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpMethod;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpResponse;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.bind.WebDataBinder;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.net.URI;

import static org.junit.Assert.assertNotNull;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {CartServiceTestConfig.class})
public class CartAndLineControllerTest {

    @Mock
    private CartAndLineBpmHelper cartAndLineBpmHelper;

    @Mock
    SessionBuilder.SessionAccessor accessor ;

    @Mock
    SessionBuilder.SessionLookup sessionLookup;


    @InjectMocks
    private CartAndLineController controller;

    @Test
    public void test_createCartAndLine_success(){
        URI url = URI.create("http://localhost/nse/createCartAndLine");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();

        CommonCartUIRequest request = getCommonCartUIRequest();

        CreateCartAndLinePEGAResponse pegaResponse = new CreateCartAndLinePEGAResponse();
        CreateCartAndLineServiceBody pegaServiceBody = new CreateCartAndLineServiceBody();
        pegaResponse.setServiceBody(pegaServiceBody);
        CartAndLineUIResponse uiResponse = new CartAndLineUIResponse();
        uiResponse.setServiceBody(pegaServiceBody);
        Mockito.when(cartAndLineBpmHelper.createCartAndLine(Mockito.any(), Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<CartAndLineUIResponse> response = controller.createCartAndLine(httpRequest, httpResponse,request);
        StepVerifier.create(response).assertNext(Assert::assertNotNull).verifyComplete();
    }

    private CommonCartUIRequest getCommonCartUIRequest() {
        CommonCartUIRequest request = new CommonCartUIRequest();
        request.setCartInfo(new CartInfo());
        request.setData(new CommonCartCustomerInfo());
        request.getCartInfo().setFlowType("PLAN_BUILDER");
        return request;
    }

    @Test
    public void test_createCartAndLine_success_withHeader(){
        URI url = URI.create("http://localhost/nse/createCartAndLine");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("clientId","PLAN_BUILDER").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        CommonCartUIRequest request = getCommonCartUIRequest();

        CreateCartAndLinePEGAResponse pegaResponse = new CreateCartAndLinePEGAResponse();
        CreateCartAndLineServiceBody pegaServiceBody = new CreateCartAndLineServiceBody();
        pegaResponse.setServiceBody(pegaServiceBody);
        CartAndLineUIResponse uiResponse = new CartAndLineUIResponse();
        uiResponse.setServiceBody(pegaServiceBody);
        Mockito.when(cartAndLineBpmHelper.createCartAndLine(Mockito.any(), Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<CartAndLineUIResponse> response = controller.createCartAndLine(httpRequest, httpResponse, request);
        StepVerifier.create(response).assertNext(Assert::assertNotNull).verifyComplete();
    }

    @Test
    public void initBinderByNameTest() {
        WebDataBinder binder = new WebDataBinder(null);
        controller.initBinderByName(binder);
        assertNotNull(binder.getDisallowedFields());
    }
    
    @Test
    public void test_buildLine_success(){
        URI url = URI.create("http://localhost/nse/bulidLine");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        CommonCartUIRequest request = getCommonCartUIRequest();

        CommonCartPEGAResponse pegaResponse = new CommonCartPEGAResponse();
        CommonCartPegaServiceBody pegaServiceBody = new CommonCartPegaServiceBody();

        pegaResponse.setServiceBody(pegaServiceBody);
        CommonCartUIResponse uiResponse = new CommonCartUIResponse();
        uiResponse.setServiceBody(pegaServiceBody);
        Mockito.when(cartAndLineBpmHelper.buildLine(Mockito.any(), Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<CommonCartUIResponse> response = controller.buildLine(httpRequest, request);
        StepVerifier.create(response).assertNext(Assert::assertNotNull).verifyComplete();
    }

    @Test
    public void test_buildLine_success_with_clientIdHeader(){
        URI url = URI.create("http://localhost/nse/bulidLine");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("clientId","OMNI-RETAIL-TAB").build();
        CommonCartUIRequest request = getCommonCartUIRequest();
        CommonCartPEGAResponse pegaResponse = new CommonCartPEGAResponse();
        CommonCartPegaServiceBody pegaServiceBody = new CommonCartPegaServiceBody();
        pegaResponse.setServiceBody(pegaServiceBody);
        CommonCartUIResponse uiResponse = new CommonCartUIResponse();
        uiResponse.setServiceBody(pegaServiceBody);
        Mockito.when(cartAndLineBpmHelper.buildLine(Mockito.any(), Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<CommonCartUIResponse> response = controller.buildLine(httpRequest, request);
        StepVerifier.create(response).assertNext(Assert::assertNotNull).verifyComplete();
    }
    
    @Test
    public void test_deleteCart_success(){
        URI url = URI.create("http://localhost/nse/deleteCart");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        CommonCartUIRequest request = getCommonCartUIRequest();
        CommonCartPEGAResponse pegaResponse = new CommonCartPEGAResponse();
        CommonCartPegaServiceBody pegaServiceBody = new CommonCartPegaServiceBody();
        pegaResponse.setServiceBody(pegaServiceBody);
        CommonCartUIResponse uiResponse = new CommonCartUIResponse();
        uiResponse.setServiceBody(pegaServiceBody);
        Mockito.when(cartAndLineBpmHelper.deleteCart(Mockito.any(), Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<CommonCartUIResponse> response = controller.deleteCart(httpRequest, request);
        StepVerifier.create(response).assertNext(Assert::assertNotNull).verifyComplete();
    }

    @Test
    public void test_deleteCart_success_with_clientId(){
        URI url = URI.create("http://localhost/nse/deleteCart");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("clientId","OMNI-RETAIL-TAB").build();
        CommonCartUIRequest request = getCommonCartUIRequest();
        CommonCartPEGAResponse pegaResponse = new CommonCartPEGAResponse();
        CommonCartPegaServiceBody pegaServiceBody = new CommonCartPegaServiceBody();
        pegaResponse.setServiceBody(pegaServiceBody);
        CommonCartUIResponse uiResponse = new CommonCartUIResponse();
        uiResponse.setServiceBody(pegaServiceBody);
        Mockito.when(cartAndLineBpmHelper.deleteCart(Mockito.any(), Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<CommonCartUIResponse> response = controller.deleteCart(httpRequest, request);
        StepVerifier.create(response).assertNext(Assert::assertNotNull).verifyComplete();
    }

    @Test
    public void test_resumeCase_success(){
        URI url = URI.create("http://localhost/nse/deleteCart");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ResumeCaseUIRequest resumeCaseUIRequest = new ResumeCaseUIRequest();
        ResumeCaseUIResponse uiResponse = new ResumeCaseUIResponse();
        Mockito.when(cartAndLineBpmHelper.resumeCase(Mockito.any(), Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResumeCaseUIResponse> response = controller.resumeCase(httpRequest, resumeCaseUIRequest);
        StepVerifier.create(response).assertNext(Assert::assertNotNull).verifyComplete();
    }

    @Test
    public void test_resumeCase_success_with_clientIdHeader(){
        URI url = URI.create("http://localhost/nse/deleteCart");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("clientId","OMNI-RETAIL-TAB").build();
        ResumeCaseUIRequest resumeCaseUIRequest = new ResumeCaseUIRequest();
        ResumeCaseUIResponse uiResponse = new ResumeCaseUIResponse();
        Mockito.when(cartAndLineBpmHelper.resumeCase(Mockito.any(), Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResumeCaseUIResponse> response = controller.resumeCase(httpRequest, resumeCaseUIRequest);
        StepVerifier.create(response).assertNext(Assert::assertNotNull).verifyComplete();
    }

    @Test
    public void test_createCase_success(){
        URI url = URI.create("http://localhost/nse/deleteCart");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("clientId","OMNI-RETAIL-TAB").build();
        CreateCaseUIRequest createCaseUIRequest = new CreateCaseUIRequest();
        CreateCaseUIResponse uiResponse = new CreateCaseUIResponse();
        Mockito.when(cartAndLineBpmHelper.createCase(Mockito.any(), Mockito.anyString())).thenReturn(Mono.just(uiResponse));
        Mono<CreateCaseUIResponse> response = controller.createCase(httpRequest, createCaseUIRequest);
        StepVerifier.create(response).assertNext(Assert::assertNotNull).verifyComplete();
    }
}
