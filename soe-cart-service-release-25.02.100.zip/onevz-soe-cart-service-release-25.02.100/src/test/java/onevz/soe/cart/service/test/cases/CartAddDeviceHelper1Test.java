package onevz.soe.cart.service.test.cases;

import java.net.URI;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.cradle.vo.CradleResponse;
import lombok.SneakyThrows;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper2;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.handler.PreHandleAddDevice;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.retrieveCart.CXPCartVO;
import onevz.soe.cart.nbx.NBXFeedbackService;
import onevz.soe.cart.requests.ValidateCartCXPRequest;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.ui.common.AddDeviceData;
import onevz.soe.cart.ui.common.DeviceCartInfo;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.common.UpdateEdgeupData;
import onevz.soe.cart.ui.requests.AddDeviceUIRequest;
import onevz.soe.cart.ui.responses.AddDeviceUIResponse;
import onevz.soe.cart.ui.responses.ValidateCartUIResponse;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.cradle.CradleAllocator;
import onevz.soe.omnidl.service.OmniDLService;
import onevz.soe.omnidl.util.DLUtilityService;
import onevz.soe.spring.web.filter.RequestAccessContext;
import onevz.soe.wsclient.bpm.model.CartInfo;
import onevz.soe.wsclient.bpm.model.Context;
import onevz.soe.wsclient.bpm.model.ServiceBody;
import onevz.soe.wsclient.bpm.model.response.ServiceResponse;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import java.io.IOException;
import java.util.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;


@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(CartAddDeviceHelper1.class)
public class CartAddDeviceHelper1Test {
	
	@Autowired
	private CartAddDeviceHelper1 accDevHelper1;

    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;

    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;
	
	@Autowired
	private ObjectMapper mapper;

    @MockBean
    private CradleAllocator cradleAllocator;

    @Autowired
    private CartAddDeviceHelper accDevHelper;

    @MockBean
    private RedisHelper redisHelper;

    @MockBean
    private RedisHelper2 redisHelper2;

    @MockBean
    private RedisHelper3 redisHelper3;

    @MockBean
    private NBXFeedbackService nbxService;

    @MockBean
    private CartServiceCxpHelper cxpHelper;

    @MockBean
    private CartServiceBpmHelper2 bpmHelper;

    @MockBean
    private DLUtilityService dlUtilityService;

    @MockBean
    private OmniDLService dlService;

    @MockBean
    CradleResponse  cradleResponse;

    @MockBean
    PreHandleAddDevice preHandleAddDevice;

    @MockBean
    FeatureFlagHelper featureFlagHelper;

    @Before
    public void setUp(){
        ReflectionTestUtils.setField(preHandleAddDevice,"restrictMultiLine",false);
        final LinkedMultiValueMap<String, HttpCookie> cookies = new LinkedMultiValueMap<>();
        HttpCookie migrationCookie = new HttpCookie(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, "false");
        HttpCookie prospectCartCount = new HttpCookie(CartConstants.PROSPECT_CART_COUNT, "0");
        cookies.add(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, migrationCookie);
        cookies.add(CartConstants.PROSPECT_CART_COUNT, prospectCartCount);
        RequestAccessContext.RequestAccess requestAccess = new RequestAccessContext.RequestAccess(cookies, new HttpHeaders());
        RequestAccessContext.updateRequestData(requestAccess);
        when(redisHelper2.getEdgeBuyoutDetails()).thenReturn(Mono.just(new HashMap()));
        when(featureFlagHelper.isRouterUpgradeFlagEnabled()).thenReturn(Boolean.TRUE);
        when(featureFlagHelper.isOneclkTaggingFFlagEnabled()).thenReturn(true);
        when(featureFlagHelper.fetchMonoElvisFeatureFlag(anyBoolean())).thenReturn(Mono.just(Boolean.TRUE));
    }


    @Test
	public void isCategoryEnabledForExpressCheckoutTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"reqfrompromopdp\": true},\"data\": {\"lines\": [{\"device\": {\"category\": \"\"}}]}}";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		boolean response = accDevHelper1.isCategoryEnabledForExpressCheckout(request);
		Assert.assertTrue(response);
	}

	@Test
	public void isCategoryEnabledForExpressCheckoutTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {},\"data\": {\"lines\": [{\"device\": {\"category\": \"\"}}]}}";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		boolean response = accDevHelper1.isCategoryEnabledForExpressCheckout(request);
		Assert.assertFalse(response);
	}

	@Test
	public void isCategoryEnabledForExpressCheckoutTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"reqfrompromopdp\": false},\"data\": {\"lines\": [{\"device\": {\"category\": \"\"}}]}}";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		boolean response = accDevHelper1.isCategoryEnabledForExpressCheckout(request);
		Assert.assertFalse(response);
	}

	@Test
	public void isCategoryEnabledForExpressCheckoutTest4() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"reqfrompromopdp\": true},\"data\": {\"lines\": [{\"device\": {\"category\": \"Smartphone\"}}]}}";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		boolean response = accDevHelper1.isCategoryEnabledForExpressCheckout(request);
		Assert.assertTrue(response);
	}
	
	@Test
	public void settingValidateCartCXPRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\", \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-DOTCOM-BBP\", \"editDevice\":false , \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": { \"esimFlowType\":\"LostICCIDProfile\",  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		String expectedResponseString = "{\"cartId\":null,\"retrieveCurrentFeatures\":true,\"mtn\":null,\"mtnList\":null}";
		ValidateCartCXPRequest expectedResponse = mapper.readValue(expectedResponseString, ValidateCartCXPRequest.class);
		ValidateCartCXPRequest response = accDevHelper1.settingValidateCartCXPRequest(request, sampleRedisData);
		Assert.assertEquals(expectedResponse, response);
	}

	@Test
	public void settingValidateCartCXPRequestTest1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\", \"data\": { \"esimFlowType\":\"LostICCIDProfile\",  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		String expectedResponseString = "{\"cartId\":null,\"retrieveCurrentFeatures\":true,\"mtn\":null,\"mtnList\":null}";
		ValidateCartCXPRequest expectedResponse = mapper.readValue(expectedResponseString, ValidateCartCXPRequest.class);
		ValidateCartCXPRequest response = accDevHelper1.settingValidateCartCXPRequest(request, sampleRedisData);
		Assert.assertEquals(expectedResponse, response);
	}

    @Test
    public void settingValidateCartCXPRequestTest2() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"channelId\":\"DIGITAL\", \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"DIGITAL\", \"editDevice\":false , \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": { \"esimFlowType\":\"LostICCIDProfile\",  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"vzwRoles\":\"accountMember\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String expectedResponseString = "{\"cartId\":null,\"retrieveCurrentFeatures\":true,\"mtn\":null,\"mtnList\":[\"7169849755\"]}";
        ValidateCartCXPRequest expectedResponse = mapper.readValue(expectedResponseString, ValidateCartCXPRequest.class);
        ValidateCartCXPRequest response = accDevHelper1.settingValidateCartCXPRequest(request, sampleRedisData);
        Assert.assertEquals(expectedResponse, response);
    }

    @Test
    public void settingValidateCartCXPRequestTest3() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"channelId\":\"DIGITAL\", \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"DIGITAL\", \"editDevice\":false , \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": { \"esimFlowType\":\"LostICCIDProfile\",  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"vzwRoles\":\"mobileSecure\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String expectedResponseString = "{\"cartId\":null,\"retrieveCurrentFeatures\":true,\"mtn\":null,\"mtnList\":[\"7169849755\"]}";
        ValidateCartCXPRequest expectedResponse = mapper.readValue(expectedResponseString, ValidateCartCXPRequest.class);
        ValidateCartCXPRequest response = accDevHelper1.settingValidateCartCXPRequest(request, sampleRedisData);
        Assert.assertEquals(expectedResponse, response);
    }

    @Test
    public void settingValidateCartCXPRequestTest4() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"channelId\":\"DIGITAL\", \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"DIGITAL\", \"editDevice\":false , \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": { \"esimFlowType\":\"LostICCIDProfile\",  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"vzwRoles\":\"mobile\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String expectedResponseString = "{\"cartId\":null,\"retrieveCurrentFeatures\":true,\"mtn\":null,\"mtnList\":null}";
        ValidateCartCXPRequest expectedResponse = mapper.readValue(expectedResponseString, ValidateCartCXPRequest.class);
        ValidateCartCXPRequest response = accDevHelper1.settingValidateCartCXPRequest(request, sampleRedisData);
        Assert.assertEquals(expectedResponse, response);
    }

    @Test
    public void settingValidateCartCXPRequestTest5() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"channelId\":\"DIGITAL\", \"cartInfo\": {  \"clientAppName\": \"DIGITAL\", \"editDevice\":false , \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": { \"esimFlowType\":\"LostICCIDProfile\",  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"vzwRoles\":\"mobileSecure\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String expectedResponseString = "{\"cartId\":null,\"retrieveCurrentFeatures\":true,\"mtn\":null,\"mtnList\":[\"8436667390\"]}";
        ValidateCartCXPRequest expectedResponse = mapper.readValue(expectedResponseString, ValidateCartCXPRequest.class);
        ValidateCartCXPRequest response = accDevHelper1.settingValidateCartCXPRequest(request, sampleRedisData);
        Assert.assertEquals(expectedResponse, response);
    }

    @Test
    public void settingValidateCartCXPRequestTest6() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"channelId\":\"DIGITAL\", \"cartInfo\": {\"cartCreator\": \"7169849755\",  \"clientAppName\": \"DIGITAL\", \"editDevice\":false , \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": { \"esimFlowType\":\"LostICCIDProfile\",  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"vzwRoles\":\"mobileSecure\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String expectedResponseString = "{\"cartId\":null,\"retrieveCurrentFeatures\":true,\"mtn\":null,\"mtnList\":[\"7169849755\"]}";
        ValidateCartCXPRequest expectedResponse = mapper.readValue(expectedResponseString, ValidateCartCXPRequest.class);
        ValidateCartCXPRequest response = accDevHelper1.settingValidateCartCXPRequest(request, sampleRedisData);
        Assert.assertEquals(expectedResponse, response);
    }

    @Test
    public void settingValidateCartCXPRequestTest7() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"channelId\":\"DIGITAL\", \"cartInfo\": {\"cartCreator\": \"7169849755\",  \"clientAppName\": \"DIGITAL\", \"editDevice\":false , \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": { \"esimFlowType\":\"LostICCIDProfile\",  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\":\"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String expectedResponseString = "{\"cartId\":null,\"retrieveCurrentFeatures\":true,\"mtn\":null,\"mtnList\":null}";
        ValidateCartCXPRequest expectedResponse = mapper.readValue(expectedResponseString, ValidateCartCXPRequest.class);
        ValidateCartCXPRequest response = accDevHelper1.settingValidateCartCXPRequest(request, sampleRedisData);
        Assert.assertEquals(expectedResponse, response);
    }

    @Test
    public void settingValidateCartCXPRequestTest8() throws JsonMappingException, JsonProcessingException {
        String requestString = "{ \"cartInfo\": {\"cartCreator\": \"7169849755\",  \"clientAppName\": \"DIGITAL\", \"editDevice\":false , \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": { \"esimFlowType\":\"LostICCIDProfile\",  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\":\"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String expectedResponseString = "{\"cartId\":null,\"retrieveCurrentFeatures\":true,\"mtn\":null,\"mtnList\":null}";
        ValidateCartCXPRequest expectedResponse = mapper.readValue(expectedResponseString, ValidateCartCXPRequest.class);
        ValidateCartCXPRequest response = accDevHelper1.settingValidateCartCXPRequest(request, sampleRedisData);
        Assert.assertEquals(expectedResponse, response);
    }

    @Test
    public void settingValidateCartCXPResponseTest() throws JsonMappingException, JsonProcessingException {
    	String responseString = "{\"errors\":[{\"namespace\":\"CartService\",\"details\":[{\"field\":\"cartId\",\"value\":\"null/blank\",\"issue\":\"cartId is/are missing.\",\"location\":\"request\"},{\"field\":\"caseId\",\"value\":\"null/blank\",\"issue\":\"caseId is/are missing.\",\"location\":\"request\"}],\"id\":\"701\",\"message\":\"This session has ended. Please reprocess to proceed\",\"name\":\" REQUEST VALIDATION ERROR\"}]}\n";
        ValidateCartUIResponse response =  mapper.readValue(responseString, ValidateCartUIResponse.class);
        String expectedResponseString = "{\"cartId\":null,\"retrieveCurrentFeatures\":true,\"mtn\":null,\"mtnList\":null}";
        ValidateCartCXPRequest expectedResponse = mapper.readValue(expectedResponseString, ValidateCartCXPRequest.class);
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\", \"data\": { \"esimFlowType\":\"LostICCIDProfile\",  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
        AddDeviceUIResponse request = mapper.readValue(requestString, AddDeviceUIResponse.class);
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        accDevHelper1.settingValidateCartCXPResponse(response, request,expectedResponse,sampleRedisData);
        Assert.assertNotNull(response.getErrors());
    }

    @Test
    public void settingValidateCartCXPResponseTest1() throws JsonMappingException, JsonProcessingException {
    	String responseString = "{\"data\":{}}";
        ValidateCartUIResponse response =  mapper.readValue(responseString, ValidateCartUIResponse.class);
        String expectedResponseString = "{\"cartId\":null,\"retrieveCurrentFeatures\":true,\"mtn\":null,\"mtnList\":null}";
        ValidateCartCXPRequest expectedResponse = mapper.readValue(expectedResponseString, ValidateCartCXPRequest.class);
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\", \"data\": { \"esimFlowType\":\"LostICCIDProfile\",  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
        AddDeviceUIResponse request = mapper.readValue(requestString, AddDeviceUIResponse.class);
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        accDevHelper1.settingValidateCartCXPResponse(response, request,expectedResponse,sampleRedisData);
        Assert.assertNotNull(response.getData());
    }
    @Test
    public void settingValidateCartCXPResponseTest3() throws JsonMappingException, JsonProcessingException {
        String responseString = "{\"data\":{}}";
        ValidateCartUIResponse response =  mapper.readValue(responseString, ValidateCartUIResponse.class);
        String expectedResponseString = "{\"cartId\":null,\"retrieveCurrentFeatures\":true,\"mtn\":null,\"mtnList\":null}";
        ValidateCartCXPRequest expectedResponse = mapper.readValue(expectedResponseString, ValidateCartCXPRequest.class);
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\", \"data\": { \"esimFlowType\":\"LostICCIDProfile\",  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
        AddDeviceUIResponse request = mapper.readValue(requestString, AddDeviceUIResponse.class);
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        CXPCartVO cart1 = new CXPCartVO();
        response.getData().setValidateCartAndUpdate(cart1);
        accDevHelper1.settingValidateCartCXPResponse(response, request,expectedResponse,sampleRedisData);
        Assert.assertNotNull(response.getData());

        accDevHelper1.settingValidateCartCXPResponse(null, request,expectedResponse,sampleRedisData);
        Assert.assertNotNull(response.getData());
    }

    @Test
    public void invokeCradleForPccThrottleListTest() throws JsonMappingException, JsonProcessingException {
    	String sampleRequestString = "{\"channelId\":\"OMNI-TELESALES\", \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-DOTCOM-BBP\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        Boolean response = accDevHelper1.invokeCradleForPccThrottleList(UIRequest, "");
        Assert.assertFalse(response);
    }
    
	@Test
    public void invokeCradleForPccThrottleListTest1() throws JsonMappingException, JsonProcessingException {
    	String sampleRequestString = "{\"channelId\":\"OMNI-TELESALES\", \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-DOTCOM-BBP\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\",\"category\":\"Smartphone\" },   \"depletionType\": \"F\"  }] }}";
		AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        Boolean response = accDevHelper1.invokeCradleForPccThrottleList(UIRequest, "EUP");
        Assert.assertFalse(response);
    }
	
	@Test
    public void invokeCradleForPccThrottleListTest2() throws JsonMappingException, JsonProcessingException {
    	String sampleRequestString = "{\"channelId\":\"OMNI-TELESALES\", \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-DOTCOM-BBP\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": []}}";
		AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        Boolean response = accDevHelper1.invokeCradleForPccThrottleList(UIRequest, "EUP");
        Assert.assertFalse(response);
    }
	
	@Test
    public void invokeCradleForPccThrottleListTest3() throws JsonMappingException, JsonProcessingException {
    	String sampleRequestString = "{\"channelId\":\"OMNI-TELESALES\", \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-DOTCOM-BBP\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": null}}";
		AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        Boolean response = accDevHelper1.invokeCradleForPccThrottleList(UIRequest, "EUP");
        Assert.assertFalse(response);
    }
	
	@Test
    public void invokeCradleForPccThrottleListTest4() throws JsonMappingException, JsonProcessingException {
    	String sampleRequestString = "{\"channelId\":\"OMNI-TELESALES\", \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-DOTCOM-BBP\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\":null}";
		AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        Boolean response = accDevHelper1.invokeCradleForPccThrottleList(UIRequest, "EUP");
        Assert.assertFalse(response);
    }
    @Test
    public void invokeCradleForPccThrottleListTest5() throws JsonMappingException, JsonProcessingException {
        String sampleRequestString = "{\"channelId\":\"OMNI-TELESALES\", \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-DOTCOM-BBP\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\",\"category\":\"Smartphone\" },   \"depletionType\": \"F\"  }] }}";
        AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        UIRequest.getData().getLines().get(0).setDevice(null);
        Boolean response = accDevHelper1.invokeCradleForPccThrottleList(UIRequest, "EUP");
        Assert.assertFalse(response);

        UIRequest.getData().getLines().set(0,null);
        response = accDevHelper1.invokeCradleForPccThrottleList(UIRequest, "EUP");
        Assert.assertFalse(response);
    }
	
	@Test
	public void settingValidateCartCXPRequestTest9() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\":\"digital\", \"cartInfo\": { \"cartId\":\"f44d72b8-6b49-40f1-8019-05f6f8fb1963\", \"cartCreator\": \"\",  \"clientAppName\": \"VZW-DOTCOM-BBP\", \"editDevice\":false , \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": { \"esimFlowType\":\"LostICCIDProfile\",  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": null }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		String expectedResponseString = "{\"cartId\":\"f44d72b8-6b49-40f1-8019-05f6f8fb1963\",\"retrieveCurrentFeatures\":true,\"mtn\":null,\"mtnList\":null}";
		ValidateCartCXPRequest expectedResponse = mapper.readValue(expectedResponseString, ValidateCartCXPRequest.class);
		ValidateCartCXPRequest response = accDevHelper1.settingValidateCartCXPRequest(request, sampleRedisData);
		Assert.assertEquals(expectedResponse, response);
	}
	
	@Test
	public void settingValidateCartCXPRequestTest10() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\":\"digital\", \"cartInfo\": null, \"data\": { \"esimFlowType\":\"LostICCIDProfile\",  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
		String redisDataString = "{\"vzwRoles\":\"mobileSecure\", \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": null }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		String expectedResponseString = "{\"cartId\":null,\"retrieveCurrentFeatures\":true,\"mtn\":null,\"mtnList\":null}";
		ValidateCartCXPRequest expectedResponse = mapper.readValue(expectedResponseString, ValidateCartCXPRequest.class);
		ValidateCartCXPRequest response = accDevHelper1.settingValidateCartCXPRequest(request, sampleRedisData);
		Assert.assertEquals(expectedResponse, response);
	}
	
	@Test
    public void settingValidateCartCXPResponseTest2() throws JsonMappingException, JsonProcessingException {
    	String responseString = "{\"data\":null}";
        ValidateCartUIResponse response =  mapper.readValue(responseString, ValidateCartUIResponse.class);
        String expectedResponseString = "{\"cartId\":null,\"retrieveCurrentFeatures\":true,\"mtn\":null,\"mtnList\":null}";
        ValidateCartCXPRequest expectedResponse = mapper.readValue(expectedResponseString, ValidateCartCXPRequest.class);
        String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\", \"data\": { \"esimFlowType\":\"LostICCIDProfile\",  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
        AddDeviceUIResponse request = mapper.readValue(requestString, AddDeviceUIResponse.class);
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        accDevHelper1.settingValidateCartCXPResponse(response, request,expectedResponse,sampleRedisData);
        Assert.assertNotNull(response);
    }
	
	@Test
	@SneakyThrows
    public void setPccDataMapTest() throws JsonMappingException, JsonProcessingException {
        final var setPccData = accDevHelper1.getClass().getDeclaredMethod("setPccDataMap", AddDeviceUIRequest.class,ServerHttpRequest.class,Map.class,String.class);
		//Fixed Fotify Issue AccessModifier Modified
        org.springframework.util.ReflectionUtils.makeAccessible(setPccData);
        String sampleRequestString = "{\"channelId\":\"VZW-DOTCOM\", \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-DOTCOM-BBP\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\":null }, \"data\":null}";
		AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
		URI url = URI.create("http://localhost/add-device");
		ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
		Map<String, String> dataMap = new HashMap<>();
		setPccData.invoke(accDevHelper1,UIRequest,httpRequest,dataMap,"EUP");
		 Assert.assertNotNull(setPccData);
    }
	
	@Test
	@SneakyThrows
    public void setPccDataMapTest1() throws JsonMappingException, JsonProcessingException {
		final var setPccData = accDevHelper1.getClass().getDeclaredMethod("setPccDataMap", AddDeviceUIRequest.class,ServerHttpRequest.class,Map.class,String.class);
        org.springframework.util.ReflectionUtils.makeAccessible(setPccData);
		String sampleRequestString = "{\"channelId\":\"VZW-DOTCOM\", \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-DOTCOM-BBP\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\":null }, \"data\":null}";
		AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
		URI url = URI.create("http://localhost/add-device");
		ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		Map<String, String> dataMap = new HashMap<>();
		setPccData.invoke(accDevHelper1,UIRequest,httpRequest,dataMap,"EUP");
		 Assert.assertNotNull(setPccData);
    }
	
	@Test
	@SneakyThrows
    public void setPccDataMapTest2() throws JsonMappingException, JsonProcessingException {
		final var setPccData = accDevHelper1.getClass().getDeclaredMethod("setPccDataMap", AddDeviceUIRequest.class,ServerHttpRequest.class,Map.class,String.class);
        org.springframework.util.ReflectionUtils.makeAccessible(setPccData);
		String sampleRequestString = "{\"channelId\":\"VZW-DOTCOM\", \"cartInfo\": {  \"cartCreator\": \"7169849755\",\"intendType\": \"NSE\",  \"clientAppName\": \"VZW-DOTCOM-BBP\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\":null }, \"data\":null}";
		AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
		Map<String, String> dataMap = new HashMap<>();
		setPccData.invoke(accDevHelper1,UIRequest,null,dataMap,"EUP");
		Assert.assertNotNull(setPccData);
    }
	
	@Test
	@SneakyThrows
    public void setPccDataMapTest3() throws JsonMappingException, JsonProcessingException {
		final var setPccData = accDevHelper1.getClass().getDeclaredMethod("setPccDataMap", AddDeviceUIRequest.class,ServerHttpRequest.class,Map.class,String.class);
        org.springframework.util.ReflectionUtils.makeAccessible(setPccData);
		String sampleRequestString = "{\"channelId\":\"VZW-DOTCOM\", \"cartInfo\":null, \"data\":null}";
		AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        URI url = URI.create("http://localhost/add-device");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("", "").build();
        Map<String, String> dataMap = new HashMap<>();
        setPccData.invoke(accDevHelper1,UIRequest,httpRequest,dataMap,"EUP");
        Assert.assertNotNull(setPccData);
		setPccData.invoke(accDevHelper1,UIRequest,null,dataMap,"EUP");
        Assert.assertNotNull(setPccData);
    }
    @Test
    @SneakyThrows
    public void setPccDataMapTest4() throws JsonMappingException, JsonProcessingException {
        final var setPccData = accDevHelper1.getClass().getDeclaredMethod("setPccDataMap", AddDeviceUIRequest.class,ServerHttpRequest.class,Map.class,String.class);
        //Fixed Fotify Issue AccessModifier Modified
        org.springframework.util.ReflectionUtils.makeAccessible(setPccData);
        String sampleRequestString = "{\"channelId\":\"VZW-DOTCOM\", \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-DOTCOM-BBP\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\":\"NSE\" }, \"data\":null}";
        AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        URI url = URI.create("http://localhost/add-device");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header(CartConstants.ORIGINATING_CLIENT_IP,"22414").build();
        Map<String, String> dataMap = new HashMap<>();
        setPccData.invoke(accDevHelper1,UIRequest,httpRequest,dataMap,"EUP");
        Assert.assertNotNull(setPccData);
        ServerHttpRequest httpRequest1 = MockServerHttpRequest.method(HttpMethod.POST, url).header(CartConstants.ORIGINATING_CLIENT_IP,"").build();
        Map<String, String> dataMap1 = new HashMap<>();
        setPccData.invoke(accDevHelper1,UIRequest,httpRequest1,dataMap1,"EUP");
        Assert.assertNotNull(setPccData);
    }

    @Test
    public void updateSubFLowTagging_Subflow_contains_NEXTGENAndCradleFLowJourney_NOTNextGen() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"reqfrompromopdp\":true,\"intendType\":\"NSEBYOD\"},\"data\":{\"lines\":[{\"device\":{\"category\":\"\"}}]}}";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse pegaResponse  = new  AddDeviceUIResponse();
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1858878952-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryInterestial\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryInterestial\",\"processAction\":\"\",\"cradleFlowJourney\":\"ACCESSORYINterstitial\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\"},\"cartInfo\":{\"financeLimitExceeded\":\"true\",\"cartItemCount\":1,\"totalDueToday\":54.25,\"totalDueMonthly\":0.0,\"cartId\":\"a144d317-de87-468e-88ee-a5e223fdf152\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":19.59,\"monthlyInstallment\":19.44,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MLA23LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"699.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 13\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC|nxtgen"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));

        Mono<Boolean> res= accDevHelper1.updateSubFlowInTaggingForNextgen(cdlThrottlist, response, request);
        StepVerifier.create(res).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateSubFLowTagging_Subflow_InTaggingForQuickViewTest() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"reqfrompromopdp\":true,\"intendType\":\"NSEBYOD\"},\"data\":{\"lines\":[{\"device\":{\"category\":\"\"}}]}}";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse pegaResponse  = new  AddDeviceUIResponse();
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1858878952-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryInterestial\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryInterestial\",\"processAction\":\"\",\"cradleFlowJourney\":\"ACCESSORYINterstitial\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\"},\"cartInfo\":{\"financeLimitExceeded\":\"true\",\"cartItemCount\":1,\"totalDueToday\":54.25,\"totalDueMonthly\":0.0,\"cartId\":\"a144d317-de87-468e-88ee-a5e223fdf152\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":19.59,\"monthlyInstallment\":19.44,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MLA23LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"699.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 13\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC|nxtgen"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        request.getCartInfo().setFromFreePhoneQV(true);
        Mono<Boolean> res= accDevHelper1.updateSubFlowInTaggingForNextgen(cdlThrottlist, response, request);
        StepVerifier.create(res).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();

        String cdlThrottlist1 = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_C_VIEW|";
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        request.getCartInfo().setFromFreePhoneQV(true);
        Mono<Boolean> res1= accDevHelper1.updateSubFlowInTaggingForNextgen(cdlThrottlist1, response, request);
        StepVerifier.create(res1).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();

        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC|nxtgen|QUICK_C_VIEW"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        request.getCartInfo().setFromFreePhoneQV(false);
        Mono<Boolean> res2= accDevHelper1.updateSubFlowInTaggingForNextgen(cdlThrottlist1, response, request);
        StepVerifier.create(res2).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();

        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC|nxtgen"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        request.getCartInfo().setFromFreePhoneQV(false);
        Mono<Boolean> res3= accDevHelper1.updateSubFlowInTaggingForNextgen(cdlThrottlist1, response, request);
        StepVerifier.create(res3).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();

    }

    @Test
    public void updateSubFLowTagging_Upgrade_Subflow_contains_NEXTGEN_ECAndCradleFLowJourney_NOT_NEXTGEN_EC() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"EUP\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"noPendingOfferExists\":false,\"isPromoPDP\":false,\"mtnFlow\":\"G\"},\"data\":{\"lines\":[{\"isCommonPDP\":true,\"mtn\":\"\",\"purchasePath\":\"EUP\",\"portInNumber\":\"\",\"eupNoPromoFlow\":false,\"device\":{\"id\":\"MTM23LL/A\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":true,\"dppMonths\":36,\"productId\":\"dev21410694\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"UNIVESIM5G-SAB-D\"},\"ispuFlow\":false,\"estimatedReadyByDate\":\"\",\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"newLineOrAAL\":false,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":false,\"isIconicPhone\":true,\"selectedSedOfferId\":\"\",\"selectedSpoId\":\"\",\"isStrategicOffer\":false,\"restricted\":\"\",\"isTradeInIntentSelected\":false}],\"rtm\":{\"url\":\"https://www.verizon.com/smartphones/apple-iphone-15/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-128gb-green-mtm23ll-a-a\",\"name\":\"iPhone 15\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://www.verizon.com/smartphones/apple-iphone-15/\"}}}\t";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.10.11.08.03.27-10.213047892394854\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"availablePaths\":[{\"path\":\"MTNSelectionPage\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\",\"cradleFlowJourney\":\"AccessoryInterestial\"},\"customerInfo\":{\"cartCreator\":\"2149185272\",\"processingMTN\":\"\",\"registerNumber\":0,\"existingCase\":\"\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NEXTGEN_EC"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<Boolean> res= accDevHelper1.updateSubFlowInTaggingForNextgen(cdlThrottlist,response, request);
        StepVerifier.create(res).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateSubFLowTagging_Upgrade_Subflow_contains_EmptyAndCradleFLowJourney_AccessoryInterestial_AAL() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"AAL\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"noPendingOfferExists\":false,\"isPromoPDP\":false,\"mtnFlow\":\"M\"},\"data\":{\"lines\":[{\"isCommonPDP\":true,\"mtn\":\"\",\"purchasePath\":\"AAL\",\"portInNumber\":\"\",\"eupNoPromoFlow\":false,\"device\":{\"id\":\"MQ923LL/A\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":true,\"dppMonths\":36,\"productId\":\"dev19920006\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"UNIVESIM5G-SA-A\"},\"ispuFlow\":false,\"estimatedReadyByDate\":\"\",\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"newLineOrAAL\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":false,\"isIconicPhone\":true,\"selectedSedOfferId\":\"\",\"selectedSpoId\":\"\",\"isStrategicOffer\":false,\"restricted\":\"\",\"isTradeInIntentSelected\":false}],\"rtm\":{\"url\":\"https://www.verizon.com/smartphones/apple-iphone-14-pro-max/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-pro-max-space-black-fall22-a\",\"name\":\"iPhone 14 Pro Max\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://www.verizon.com/smartphones/apple-iphone-14-pro-max/\"}}}\n";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.11.08.20.53.38-957.8754599383298\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"availablePaths\":[{\"path\":\"PromoHub\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryInterestial\",\"processAction\":\"\",\"cradleFlowJourney\":\"AccessoryInterestial\"},\"customerInfo\":{\"cartCreator\":\"2132478174\",\"processingMTN\":\"2132478170\",\"registerNumber\":0,\"number_share_capable\":\"\",\"e911_addr_ind\":\"false\",\"existingCase\":\"\",\"noc\":false},\"cartInfo\":{\"financeLimitExceeded\":\"false\",\"cartItemCount\":1,\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"status\":1,\"firstMonthInstallment\":41.89,\"monthlyInstallment\":41.66,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MQ923LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"1499.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 14 Pro Max\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0,\"isNonVZDeviceSku\":false},\"sim\":{\"id\":\"UNIVESIM5G-SA-A\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"AAL\",\"currentPlanType\":\"LLP\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false},\"processMTNList\":[{\"mtn\":\"2132478170\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"Initiate\",\"GridWallPDP\"]}]}}}}";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just(""));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<Boolean> res= accDevHelper1.updateSubFlowInTaggingForNextgen(cdlThrottlist ,response, request);
        StepVerifier.create(res).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateSubFLowTagging_Upgrade_Subflow_contains_EmptyAndCradleFLowJourney_AccessoryInterestial_EUP() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"EUP\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"noPendingOfferExists\":false,\"isPromoPDP\":false,\"mtnFlow\":\"G\"},\"data\":{\"lines\":[{\"isCommonPDP\":true,\"mtn\":\"\",\"purchasePath\":\"EUP\",\"portInNumber\":\"\",\"eupNoPromoFlow\":false,\"device\":{\"id\":\"MLAA3LL/A\",\"contractTerm\":\"MONTH_TO_MONTH\",\"iconicPhone\":true,\"dppMonths\":\"\",\"productId\":\"dev16720001\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBDSIM5G\"},\"ispuFlow\":false,\"estimatedReadyByDate\":\"\",\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"newLineOrAAL\":false,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":false,\"isIconicPhone\":true,\"selectedSedOfferId\":\"\",\"selectedSpoId\":\"\",\"isStrategicOffer\":false,\"restricted\":\"\",\"isTradeInIntentSelected\":false}],\"rtm\":{\"url\":\"https://www.verizon.com/smartphones/apple-iphone-13/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-productred-09142021\",\"name\":\"iPhone 13\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://www.verizon.com/smartphones/apple-iphone-13/\"}}}\n";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.11.08.20.58.33-81.69377107993236\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"availablePaths\":[{\"path\":\"MTNSelectionPage\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\",\"cradleFlowJourney\":\"AccessoryInterestial\"},\"customerInfo\":{\"cartCreator\":\"2132478174\",\"processingMTN\":\"2132478170\",\"registerNumber\":0,\"existingCase\":\"\",\"noc\":false},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false},\"processMTNList\":[{\"mtn\":\"2132478170\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"Initiate\",\"GridWallPDP\",\"AccessoryInterestial\",\"PromoHub\",\"GridWallPDP\"]}]}}}}\n";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just(""));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<Boolean> res= accDevHelper1.updateSubFlowInTaggingForNextgen(cdlThrottlist, response, request);
        StepVerifier.create(res).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateSubFLowTagging_Upgrade_Subflow_EMPTYAndCradleFLowJourney_NEXTGEN_EC() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"EUP\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"noPendingOfferExists\":false,\"isPromoPDP\":false,\"mtnFlow\":\"G\"},\"data\":{\"lines\":[{\"isCommonPDP\":true,\"mtn\":\"\",\"purchasePath\":\"EUP\",\"portInNumber\":\"\",\"eupNoPromoFlow\":false,\"device\":{\"id\":\"MTM23LL/A\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":true,\"dppMonths\":36,\"productId\":\"dev21410694\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"UNIVESIM5G-SAB-D\"},\"ispuFlow\":false,\"estimatedReadyByDate\":\"\",\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"newLineOrAAL\":false,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":false,\"isIconicPhone\":true,\"selectedSedOfferId\":\"\",\"selectedSpoId\":\"\",\"isStrategicOffer\":false,\"restricted\":\"\",\"isTradeInIntentSelected\":false}],\"rtm\":{\"url\":\"https://www.verizon.com/smartphones/apple-iphone-15/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-128gb-green-mtm23ll-a-a\",\"name\":\"iPhone 15\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://www.verizon.com/smartphones/apple-iphone-15/\"}}}\t";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.10.11.08.03.27-10.213047892394854\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"availablePaths\":[{\"path\":\"MTNSelectionPage\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\",\"cradleFlowJourney\":\"NEXTGEN_EC\"},\"customerInfo\":{\"cartCreator\":\"2149185272\",\"processingMTN\":\"\",\"registerNumber\":0,\"existingCase\":\"\"},\"cartInfo\":{\"cartItemCount\":0,\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just(""));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<Boolean> res= accDevHelper1.updateSubFlowInTaggingForNextgen(cdlThrottlist,response, request);
        StepVerifier.create(res).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateSubFLowTagging_NSE_Subflow_NEXTGENAndCradleFLowJourney_PROMOHUB() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"newLine1\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"noPendingOfferExists\":false,\"isPromoPDP\":false,\"mtnFlow\":\"P\",\"customerType\":\"N\",\"zipCode\":\"93907\"},\"data\":{\"lines\":[{\"isCommonPDP\":true,\"mtn\":\"newLine1\",\"purchasePath\":\"NSE\",\"portInNumber\":\"\",\"eupNoPromoFlow\":false,\"device\":{\"id\":\"SMS916UZEEV\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":36,\"productId\":\"dev20760281\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBDSIM5GSA\"},\"ispuFlow\":false,\"estimatedReadyByDate\":\"\",\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"newLineOrAAL\":false,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false,\"selectedSedOfferId\":\"\",\"isStrategicOffer\":\"\",\"restricted\":\"\",\"isTradeInIntentSelected\":false}],\"rtm\":{\"url\":\"https://www.verizon.com/smartphones/samsung-galaxy-s23-plus/?&line=newLine1&mtnFlow=P\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/samsung-galaxy-diamond-2-beige-cream\",\"name\":\"Galaxy S23+\",\"make\":\"Samsung\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://www.verizon.com/smartphones/samsung-galaxy-s23-plus/\"}}}";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        String responseString = "{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.10.11.08.03.27-23.733068720216632\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"availablePaths\":[{\"path\":\"PromoBundleBuilder\"},{\"path\":\"OfferInterstitial\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"OfferInterstitial\",\"processAction\":\"\",\"cradleFlowJourney\":\"PROMOHUB\"},\"customerInfo\":{\"customerType\":\"N\",\"cartCreator\":\"POW-M-7cefd7a9-d9da-47c8-9bf8-0a62ec8640ab\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"globalId\":\"POW-M-7cefd7a9-d9da-47c8-9bf8-0a62ec8640ab\"},\"cartInfo\":{\"financeLimitExceeded\":\"true\",\"cartItemCount\":1,\"totalDueToday\":0,\"totalDueMonthly\":91.26,\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"couponCode\":\"\",\"lines\":[{\"plan\":{\"id\":\"63215\",\"price\":\"75.00\",\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"spos\":[{\"id\":\"2640\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"732\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"1256\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"1692\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"1801\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"1958\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"2606\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"2607\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]}],\"sfos\":[{\"id\":\"48526\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"48553\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68869\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68870\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68871\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68872\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68873\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68874\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68876\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"73502\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"73503\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"74774\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"75622\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"75706\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"75802\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"75836\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"75837\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"77568\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78485\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78706\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78707\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78732\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"80148\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"81158\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"83856\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"84094\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"85553\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86189\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86209\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86225\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86848\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"89668\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"89670\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"89671\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"89673\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false}],\"firstMonthInstallment\":31.14,\"monthlyInstallment\":31.11,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"lineSubscriptionInfos\":[],\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"SMS916UZEEV\",\"installmentTerm\":\"0\",\"itemPrice\":\"1119.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"Galaxy S23+\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0,\"isNonVZDeviceSku\":false},\"sim\":{\"id\":\"EMBDSIM5GSA\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"currentPlanType\":\"LLP\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"10/11/2023\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false,\"lineDevices\":[{\"mtn\":\"newLine1\",\"deviceCategory\":\"Smartphones\",\"lineActivityType\":\"NSE\",\"multiLineSeqNumber\":1}],\"isFlexV2\":false},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"NewRecommendedPlanSelection\",\"GridWallPDP\"]}]}}}}";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("nxtgen"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<Boolean> res= accDevHelper1.updateSubFlowInTaggingForNextgen(cdlThrottlist ,response, request);
        StepVerifier.create(res).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateSubFLowTagging_Subflow_contains_NEXTGENAndCrdleFlowJournyNEXTGen() throws JsonProcessingException {
        String requestString = "{\"cartInfo\": {\"reqfrompromopdp\": true},\"data\": {\"lines\": [{\"device\": {\"category\": \"\"}}]}}";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse pegaResponse  = new  AddDeviceUIResponse();
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1858878952-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryInterestial\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryInterestial\",\"processAction\":\"\",\"cradleFlowJourney\":\"NextGen\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\"},\"cartInfo\":{\"financeLimitExceeded\":\"true\",\"cartItemCount\":1,\"totalDueToday\":54.25,\"totalDueMonthly\":0.0,\"cartId\":\"a144d317-de87-468e-88ee-a5e223fdf152\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":19.59,\"monthlyInstallment\":19.44,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MLA23LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"699.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 13\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC|nxtgen"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<Boolean> res= accDevHelper1.updateSubFlowInTaggingForNextgen(cdlThrottlist, response, request);
        StepVerifier.create(res).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateSubFLowTagging_Subflow_EMPTY_NEXTGENAndCrdleFlowJournyNEXTGen() throws JsonProcessingException {
        String requestString = "{\"cartInfo\": {\"reqfrompromopdp\": true},\"data\": {\"subFlow\":\"nextgen_byod_bau\",\"lines\": [{\"device\": {\"category\": \"\"}}]}}";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse pegaResponse  = new  AddDeviceUIResponse();
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1858878952-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryInterestial\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryInterestial\",\"processAction\":\"\",\"cradleFlowJourney\":\"NextGen\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\"},\"cartInfo\":{\"financeLimitExceeded\":\"true\",\"cartItemCount\":1,\"totalDueToday\":54.25,\"totalDueMonthly\":0.0,\"cartId\":\"a144d317-de87-468e-88ee-a5e223fdf152\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":19.59,\"monthlyInstallment\":19.44,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MLA23LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"699.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 13\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just(""));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<Boolean> res= accDevHelper1.updateSubFlowInTaggingForNextgen(cdlThrottlist ,response, request);
        StepVerifier.create(res).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateSubFLowTagging_Subflow_contains_NEXTGENAndCradleFLowJourney_EmptyCradleFlowJorny() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"reqfrompromopdp\":true,\"intendType\":\"NSE\"},\"data\":{\"lines\":[{\"device\":{\"category\":\"\"}}]}}";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse pegaResponse  = new  AddDeviceUIResponse();
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1858878952-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryInterestial\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryInterestial\",\"processAction\":\"\",\"cradleFlowJourney\":\"\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\"},\"cartInfo\":{\"financeLimitExceeded\":\"true\",\"cartItemCount\":1,\"totalDueToday\":54.25,\"totalDueMonthly\":0.0,\"cartId\":\"a144d317-de87-468e-88ee-a5e223fdf152\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":19.59,\"monthlyInstallment\":19.44,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MLA23LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"699.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 13\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);

        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC|nxtgen"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<Boolean> res= accDevHelper1.updateSubFlowInTaggingForNextgen(cdlThrottlist ,response, request);
        StepVerifier.create(res).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
    }
    @Test
    public void updateSubFLowTagging_Subflow_contains_NEXTGENBYODAnd_DeviceCategorytablet() throws JsonProcessingException {
        String requestString = "{\"cartInfo\": {\"reqfrompromopdp\": true},\"data\": {\"subFlow\":\"Nxtgen-BYOD-C\",\"lines\": [{\"device\": {\"category\": \"\"}}]}}";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1858878952-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryInterestial\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryInterestial\",\"processAction\":\"\",\"cradleFlowJourney\":\"ACCESSORYINterstitial\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\"},\"cartInfo\":{\"financeLimitExceeded\":\"true\",\"cartItemCount\":2,\"totalDueToday\":54.25,\"totalDueMonthly\":0.0,\"cartId\":\"a144d317-de87-468e-88ee-a5e223fdf152\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":19.59,\"monthlyInstallment\":19.44,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MLA23LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"699.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 13\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"lineDevices\":[{\"mtn\":\"newLine1\",\"deviceCategory\":\"Tablets\",\"lineActivityType\":\"NSEBYOD\",\"multiLineSeqNumber\":1}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        ArrayList<String> subFlowList = new ArrayList<>();
        subFlowList.add(CartConstants.NXT_GEN_BYOD);
        //when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC|nextgen_byod"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<Boolean> res= accDevHelper1.updateSubFlowInTaggingForNextgenBYOD(response, request, subFlowList);
        StepVerifier.create(res).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateSubFLowTagging_Subflow_contains_C_NEXTGENBYODAnd_DeviceCategory() throws JsonProcessingException {
        String requestString = "{\"cartInfo\": {\"reqfrompromopdp\": true},\"data\": {\"subFlow\":\"Nxtgen-BYOD-C\",\"lines\": [{\"device\": {\"category\": \"\"}}]}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1858878952-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryInterestial\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryInterestial\",\"processAction\":\"\",\"cradleFlowJourney\":\"ACCESSORYINterstitial\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\"},\"cartInfo\":{\"financeLimitExceeded\":\"true\",\"cartItemCount\":2,\"totalDueToday\":54.25,\"totalDueMonthly\":0.0,\"cartId\":\"a144d317-de87-468e-88ee-a5e223fdf152\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":19.59,\"monthlyInstallment\":19.44,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MLA23LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"699.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 13\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"lineDevices\":[{\"mtn\":\"newLine1\",\"deviceCategory\":\"Smartphone\",\"lineActivityType\":\"NSE\",\"multiLineSeqNumber\":1}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        ArrayList<String> subFlowList = new ArrayList<>();
        subFlowList.add(CartConstants.NXT_GEN_BYOD_BAU);
        //when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC|nextgen_byod"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<Boolean> res= accDevHelper1.updateSubFlowInTaggingForNextgenBYOD(response, request, subFlowList);
        StepVerifier.create(res).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
    }
    @Test
    public void updateSubFLowTagging_Subflow_contains_C_NEXTGENBYODAnd_DeviceCategoryNSE() throws JsonProcessingException {
        String requestString = "{\"cartInfo\": {\"reqfrompromopdp\": true,\"intendType\":\"NSE\"},\"data\": {\"subFlow\":\"Nxtgen-BYOD-C\",\"lines\": [{\"device\": {\"category\": \"\"}}]}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1858878952-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryInterestial\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryInterestial\",\"processAction\":\"\",\"cradleFlowJourney\":\"ACCESSORYINterstitial\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\"},\"cartInfo\":{\"financeLimitExceeded\":\"true\",\"cartItemCount\":2,\"totalDueToday\":54.25,\"totalDueMonthly\":0.0,\"cartId\":\"a144d317-de87-468e-88ee-a5e223fdf152\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":19.59,\"monthlyInstallment\":19.44,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MLA23LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"699.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 13\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"lineDevices\":[{\"mtn\":\"newLine1\",\"deviceCategory\":\"Smartphones\",\"lineActivityType\":\"NSEBYOD\",\"multiLineSeqNumber\":1}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        ArrayList<String> subFlowList = new ArrayList<>();
        subFlowList.add(CartConstants.NXT_GEN_BYOD_BAU);
        //when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC|nextgen_byod"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<Boolean> res= accDevHelper1.updateSubFlowInTaggingForNextgenBYOD(response, request, subFlowList);
        StepVerifier.create(res).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
    }
    @Test
    public void updateSubFLowTagging_Subflow_contains_NEXTGENBYODAnd_DeviceCount0() throws JsonProcessingException {
        String requestString = "{\"cartInfo\": {\"reqfrompromopdp\": true},\"data\": {\"subFlow\":\"Nxtgen-BYOD-C\",\"lines\": [{\"device\": {\"category\": \"\"}}]}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1858878952-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryInterestial\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryInterestial\",\"processAction\":\"\",\"cradleFlowJourney\":\"ACCESSORYINterstitial\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\"},\"cartInfo\":{\"financeLimitExceeded\":\"true\",\"cartItemCount\":0,\"totalDueToday\":54.25,\"totalDueMonthly\":0.0,\"cartId\":\"a144d317-de87-468e-88ee-a5e223fdf152\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":19.59,\"monthlyInstallment\":19.44,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MLA23LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"699.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 13\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        String responseString2 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1858878952-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryInterestial\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryInterestial\",\"processAction\":\"\",\"cradleFlowJourney\":\"NEXTGEN\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\"},\"cartInfo\":{\"financeLimitExceeded\":\"true\",\"cartItemCount\":0,\"totalDueToday\":54.25,\"totalDueMonthly\":0.0,\"cartId\":\"a144d317-de87-468e-88ee-a5e223fdf152\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":19.59,\"monthlyInstallment\":19.44,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MLA23LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"699.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 13\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
        AddDeviceUIResponse response2 = mapper.readValue(responseString2, AddDeviceUIResponse.class);
        ArrayList<String> subFlowList = new ArrayList<>();
        subFlowList.add(CartConstants.NXT_GEN_BYOD);
        // when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC|nextgen_byod"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));

        Mono<Boolean> res= accDevHelper1.updateSubFlowInTaggingForNextgenBYOD(response, request, subFlowList);
        StepVerifier.create(res).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("Nxtgen-BYOD-C"));
        Mono<Boolean> res1= accDevHelper1.updateSubFlowForNextgenSales(response, request);
        StepVerifier.create(res1).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("Nxtgen-BYOD-C"));
        Mono<Boolean> res3= accDevHelper1.updateSubFlowForNextgenSales(response2, request);
        StepVerifier.create(res3).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("Nxtgen-BYOD-Treat"));
        Mono<Boolean> res4= accDevHelper1.updateSubFlowForNextgenSales(response2, request);
        StepVerifier.create(res4).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
        when(dlUtilityService.getSubFlowVal()).thenThrow(new NullPointerException());
        Mono<Boolean> res2= accDevHelper1.updateSubFlowForNextgenSales(response, request);
        StepVerifier.create(res2).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();

        request.getData().getLines().get(0).getDevice().setDfoSelected(true);
        Mono<Boolean> res5= accDevHelper1.updateSubFlowForVVC(request);
        StepVerifier.create(res5).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();

        request.getData().getLines().get(0).getDevice().setDfoSelected(false);
        Mono<Boolean> res6= accDevHelper1.updateSubFlowForVVC(request);
        StepVerifier.create(res6).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();

        List<Lines> lines = new ArrayList<>();
        request.getData().setLines(lines);
        Mono<Boolean> res7= accDevHelper1.updateSubFlowForVVC(request);
        StepVerifier.create(res7).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();

        request.setData(null);
        Mono<Boolean> res8= accDevHelper1.updateSubFlowForVVC(request);
        StepVerifier.create(res8).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
    }
    @Test
    public void updateSubFLowTagging_Subflow_notcontains_NEXTGENBYODAnd_DeviceCount0() throws JsonProcessingException {
        String requestString = "{\"cartInfo\": {\"reqfrompromopdp\": true},\"data\": {\"subFlow\":\"Nxtgen-BYOD-Treat\",\"lines\": [{\"device\": {\"category\": \"\"}}]}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1858878952-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryInterestial\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryInterestial\",\"processAction\":\"\",\"cradleFlowJourney\":\"ACCESSORYINterstitial\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\"},\"cartInfo\":{\"financeLimitExceeded\":\"true\",\"cartItemCount\":2,\"totalDueToday\":54.25,\"totalDueMonthly\":0.0,\"cartId\":\"a144d317-de87-468e-88ee-a5e223fdf152\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":19.59,\"monthlyInstallment\":19.44,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MLA23LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"699.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 13\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"lineDevices\":[{\"mtn\":\"newLine1\",\"deviceCategory\":\"Smartphones\",\"lineActivityType\":\"NSE\",\"multiLineSeqNumber\":1}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        ArrayList<String> subFlowList = new ArrayList<>();
        subFlowList.add("nextgen");
        //when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC|"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<Boolean> res= accDevHelper1.updateSubFlowInTaggingForNextgenBYOD(response, request, subFlowList);
        StepVerifier.create(res).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
    }
    @Test
    public void updateSubFLowTagging_Subflow_contains_NEXTGENBYODAnd_UIInputEmpty() throws JsonProcessingException {
        String requestString = "{\"cartInfo\": {\"reqfrompromopdp\": true},\"data\": {\"lines\": [{\"device\": {\"category\": \"\"}}]}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1858878952-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryInterestial\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryInterestial\",\"processAction\":\"\",\"cradleFlowJourney\":\"ACCESSORYINterstitial\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\"},\"cartInfo\":{\"financeLimitExceeded\":\"true\",\"totalDueToday\":54.25,\"totalDueMonthly\":0.0,\"cartId\":\"a144d317-de87-468e-88ee-a5e223fdf152\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":19.59,\"monthlyInstallment\":19.44,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MLA23LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"699.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 13\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        ArrayList<String> subFlowList = new ArrayList<>();
        subFlowList.add(CartConstants.NXT_GEN_BYOD);
        //when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC|nextgen_byod"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<Boolean> res= accDevHelper1.updateSubFlowInTaggingForNextgenBYOD(response, request, subFlowList);
        StepVerifier.create(res).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
    }

    @Test
    public void setCradleFlowJourneyTest1() throws JsonProcessingException {
        String sampleUIRequestString = "{\"validateCartRequest\":null,\"preConfigured\":null,\"externalId\":null,\"vzId\":null,\"path\":null,\"cartInfo\":{\"editDeviceConfiguratorClick\":null,\"editPlanClick\":null,\"specialItemType\":null,\"salesRepId\":null,\"flowType\":null,\"rpsIntent\":null,\"sessionId\":null,\"customerType\":null,\"accountType\":null,\"globalId\":null,\"bbpIntent\":null,\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"15eccfe3-574e-402a-91b4-11c669769d2b\",\"caseId\":\"SOP-7676963-C01\",\"accountNumber\":\"0219838656-00001\",\"cartCreator\":\"5126807507\",\"processingMTN\":\"5126808210\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"Y\",\"edgeUpSelected\":\"N\",\"processStep\":\"DPPSummary\",\"intendType\":\"NSEBYOD\",\"isQuoteCart\":null,\"processAction\":\"addBuyoutAmtAndDevice\",\"mtnFlow\":\"G\",\"fetchDataFromRedis\":null,\"editDevice\":null,\"showICPage\":null,\"isSmartLocator\":null,\"triggerPricingValidation\":null,\"barCodeIds\":[],\"isGemini\":null,\"isTradeInSelected\":null,\"expressCheckout\":null,\"replaceDevice\":null,\"amRole\":\"accountManager\",\"cradleFlowJourney\":null,\"activateSwitchFlow\":null,\"adobeId\":null,\"referralVendorId\":null,\"ecpdToken\":null,\"rylEcpdUrl\":null,\"referralSaleRepId\":null,\"zipCode\":null,\"disableMyLink\":null,\"authorizedUser\":null,\"cartCreatorSalesRepId\":null,\"fiveGMUCEligible\":null,\"customerConsent\":null},\"data\":{\"recommDevId\":null,\"recommSkuId\":null,\"rtm\":null,\"nextGenByodMvaFlow\":true,\"lines\":[{\"preBackOrderDate\":null,\"preBackOrderDisplayType\":null,\"rebateUpdate\":null,\"instantcredit\":null,\"mldTrunkMtn\":null,\"rtdOfferId\":null,\"restricted\":null,\"restrictedProductType\":null,\"selectedSedOfferId\":null,\"selectedSpoId\":null,\"reasonCode\":null,\"lineActivityType\":null,\"currentPlanType\":null,\"barCodeId\":null,\"inEligibleReason\":null,\"sellerPrice\":null,\"nickName\":null,\"purchasePath\":\"AccountGrowth\",\"donorMtn\":null,\"selectedPromoType\":\"NOPROMO\",\"selectedPromoId\":\"\",\"giftBox\":null,\"idu\":null,\"eupNoPromoFlow\":false,\"accountOwner\":null,\"mtn\":\"5126808210\",\"trialSelected\":null,\"subscriptionSelected\":null,\"trialAllowance\":null,\"trialValidityPeriod\":null,\"device\":{\"cartItemType\":null,\"quantityOnHand\":null,\"upgradeReasonCode\":null,\"warningMessage\":null,\"connectedCarMobile\":null,\"connectedCarColor\":null,\"category\":\"Smartphone\",\"giftbox\":null,\"connectedCarDetails\":null,\"refundType\":null,\"id\":\"MLAR3LL/A\",\"dppMonths\":36,\"contractTerm\":\"VERIZON_EDGE\",\"qty\":1,\"fiveGToFourGDownGrade\":null,\"productId\":\"dev16720001\",\"iconicPhone\":true,\"preconfigure\":\"false\",\"token\":null},\"sim\":{\"id\":\"EMBD4GSIM-N\",\"imei2\":null},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"isEdgeBuyOut\":true,\"triggerPricingValidation\":null,\"tabletJetPackDiscountIncluded\":null,\"fiveGUpSell\":null,\"is5GBoltEligible\":null,\"devicePlanCompatible\":null,\"activateLater\":null,\"setUpLater\":null,\"selectedEUPDeviceForBYOD\":null,\"promoRejectionIndicator\":true,\"unpairDevice\":null,\"tradeInInfo\":null,\"editSim\":null,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false}],\"mtnSOIRecommendation\":null,\"totalDeviceDollar\":null,\"selectedMtn\":null},\"channelId\":\"VZW-MFA-ANDROID\"}";
        AddDeviceUIRequest request = mapper.readValue(sampleUIRequestString,AddDeviceUIRequest.class);
        Map<String,String> cradleDatmap=new HashMap<>();
        ReflectionTestUtils.setField(accDevHelper1, "deviceCategoriesForNextGenByodMva",Arrays.asList(new String[]{"Smartphone"}));
        cradleDatmap.put(CartConstants.ACCOUNT_NUMBER,"1234567890");
        when(cradleAllocator.getDataMap()).thenReturn(Mono.just(cradleDatmap));
        Mono<AddDeviceUIRequest> res= accDevHelper1.setCradleFlowJourneyForByodNextGenMVA(request);
        StepVerifier.create(res).assertNext(Assert::assertNotNull).expectComplete()
                .verify();
        cradleDatmap.put(CartConstants.THROTTLE_LIST,CartConstants.NEXTGEN_C_BYOD_MVA_CDL_VALUE);
        when(cradleAllocator.getDataMap()).thenReturn(Mono.just(cradleDatmap));
        res= accDevHelper1.setCradleFlowJourneyForByodNextGenMVA(request);
        StepVerifier.create(res).assertNext(Assert::assertNotNull).expectComplete()
                .verify();
        cradleDatmap.put(CartConstants.THROTTLE_LIST,CartConstants.NEXT_GEN);
        when(cradleAllocator.getDataMap()).thenReturn(Mono.just(cradleDatmap));
        res= accDevHelper1.setCradleFlowJourneyForByodNextGenMVA(request);
        StepVerifier.create(res).assertNext(Assert::assertNotNull).expectComplete()
                .verify();
        cradleDatmap.put(CartConstants.THROTTLE_LIST,"");
        when(cradleAllocator.getDataMap()).thenReturn(Mono.just(cradleDatmap));
        res= accDevHelper1.setCradleFlowJourneyForByodNextGenMVA(request);
        StepVerifier.create(res).assertNext(Assert::assertNotNull).expectComplete().verify();
        when(cradleAllocator.getDataMap()).thenReturn(Mono.just(new HashMap<>()));
        res= accDevHelper1.setCradleFlowJourneyForByodNextGenMVA(request);
        StepVerifier.create(res).assertNext(Assert::assertNotNull).expectComplete().verify();
        request.getData().setNextGenByodMvaFlow(Boolean.FALSE);
        res= accDevHelper1.setCradleFlowJourneyForByodNextGenMVA(request);
        StepVerifier.create(res).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void setCradleFlowJourneyTest2() throws JsonProcessingException {
        String sampleUIRequestString = "{\"validateCartRequest\":null,\"preConfigured\":null,\"externalId\":null,\"vzId\":null,\"path\":null,\"cartInfo\":{\"editDeviceConfiguratorClick\":null,\"editPlanClick\":null,\"specialItemType\":null,\"salesRepId\":null,\"flowType\":null,\"rpsIntent\":null,\"sessionId\":null,\"customerType\":null,\"accountType\":null,\"globalId\":null,\"bbpIntent\":null,\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"15eccfe3-574e-402a-91b4-11c669769d2b\",\"caseId\":\"SOP-7676963-C01\",\"accountNumber\":\"0219838656-00001\",\"cartCreator\":\"5126807507\",\"processingMTN\":\"5126808210\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"Y\",\"edgeUpSelected\":\"N\",\"processStep\":\"DPPSummary\",\"intendType\":\"NSEBYOD\",\"isQuoteCart\":null,\"processAction\":\"addBuyoutAmtAndDevice\",\"mtnFlow\":\"G\",\"fetchDataFromRedis\":null,\"editDevice\":null,\"showICPage\":null,\"isSmartLocator\":null,\"triggerPricingValidation\":null,\"barCodeIds\":[],\"isGemini\":null,\"isTradeInSelected\":null,\"expressCheckout\":null,\"replaceDevice\":null,\"amRole\":\"accountManager\",\"cradleFlowJourney\":null,\"activateSwitchFlow\":null,\"adobeId\":null,\"referralVendorId\":null,\"ecpdToken\":null,\"rylEcpdUrl\":null,\"referralSaleRepId\":null,\"zipCode\":null,\"disableMyLink\":null,\"authorizedUser\":null,\"cartCreatorSalesRepId\":null,\"fiveGMUCEligible\":null,\"customerConsent\":null},\"data\":{\"recommDevId\":null,\"recommSkuId\":null,\"rtm\":null,\"lines\":[{\"preBackOrderDate\":null,\"preBackOrderDisplayType\":null,\"rebateUpdate\":null,\"instantcredit\":null,\"mldTrunkMtn\":null,\"rtdOfferId\":null,\"restricted\":null,\"restrictedProductType\":null,\"selectedSedOfferId\":null,\"selectedSpoId\":null,\"reasonCode\":null,\"lineActivityType\":null,\"currentPlanType\":null,\"barCodeId\":null,\"inEligibleReason\":null,\"sellerPrice\":null,\"nickName\":null,\"purchasePath\":\"AccountGrowth\",\"donorMtn\":null,\"selectedPromoType\":\"NOPROMO\",\"selectedPromoId\":\"\",\"giftBox\":null,\"idu\":null,\"eupNoPromoFlow\":false,\"accountOwner\":null,\"mtn\":\"5126808210\",\"trialSelected\":null,\"subscriptionSelected\":null,\"trialAllowance\":null,\"trialValidityPeriod\":null,\"device\":{\"cartItemType\":null,\"quantityOnHand\":null,\"upgradeReasonCode\":null,\"warningMessage\":null,\"connectedCarMobile\":null,\"connectedCarColor\":null,\"category\":\"Tablet\",\"giftbox\":null,\"connectedCarDetails\":null,\"refundType\":null,\"id\":\"MLAR3LL/A\",\"dppMonths\":36,\"contractTerm\":\"VERIZON_EDGE\",\"qty\":1,\"fiveGToFourGDownGrade\":null,\"productId\":\"dev16720001\",\"iconicPhone\":true,\"preconfigure\":\"false\",\"token\":null},\"sim\":{\"id\":\"EMBD4GSIM-N\",\"imei2\":null},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"isEdgeBuyOut\":true,\"triggerPricingValidation\":null,\"tabletJetPackDiscountIncluded\":null,\"fiveGUpSell\":null,\"is5GBoltEligible\":null,\"devicePlanCompatible\":null,\"activateLater\":null,\"setUpLater\":null,\"selectedEUPDeviceForBYOD\":null,\"promoRejectionIndicator\":true,\"unpairDevice\":null,\"tradeInInfo\":null,\"editSim\":null,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false}],\"mtnSOIRecommendation\":null,\"totalDeviceDollar\":null,\"selectedMtn\":null},\"channelId\":\"VZW-MFA-ANDROID\"}";
        AddDeviceUIRequest request = mapper.readValue(sampleUIRequestString,AddDeviceUIRequest.class);
        Map<String,String> cradleDatmap=new HashMap<>();
        cradleDatmap.put(CartConstants.THROTTLE_LIST,"");
        when(cradleAllocator.getDataMap()).thenReturn(Mono.just(cradleDatmap));
        ReflectionTestUtils.setField(accDevHelper1, "deviceCategoriesForNextGenByodMva",Arrays.asList(new String[]{"Tablet"}));
        Mono<AddDeviceUIRequest> res= accDevHelper1.setCradleFlowJourneyForByodNextGenMVA(request);
        StepVerifier.create(res).assertNext(Assert::assertNotNull).expectComplete().verify();
        request.getData().getLines().get(0).setDevice(null);
        res= accDevHelper1.setCradleFlowJourneyForByodNextGenMVA(request);
        StepVerifier.create(res).assertNext(Assert::assertNotNull).expectComplete().verify();
        request.getData().setLines(null);
        res= accDevHelper1.setCradleFlowJourneyForByodNextGenMVA(request);
        StepVerifier.create(res).assertNext(Assert::assertNotNull).expectComplete().verify();
        request.setData(null);
        res= accDevHelper1.setCradleFlowJourneyForByodNextGenMVA(request);
        StepVerifier.create(res).assertNext(Assert::assertNotNull).expectComplete().verify();
        request.setChannelId("VZW-DOTCOM");
        res= accDevHelper1.setCradleFlowJourneyForByodNextGenMVA(request);
        StepVerifier.create(res).assertNext(Assert::assertNotNull).expectComplete().verify();
        request.getCartInfo().setIntendType("AAL");
        res= accDevHelper1.setCradleFlowJourneyForByodNextGenMVA(request);
        StepVerifier.create(res).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void addDeviceHelperUidTest() throws IOException, SOEHTTPException {
        String sampleRequestString = "{\"channelId\":\"CHAT-STORE\", \"cartInfo\": {  \"cartCreator\": \"\", \"deviceType\": \"PHONE\", \"clientAppName\": \"CHAT-STORE\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"REX\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\", \"networkBandwidthType\": \"LTE\" ,  \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        AddDeviceUIResponse responseServiceMono = new AddDeviceUIResponse();
        AddDeviceUIRequest UIRequest = new AddDeviceUIRequest();
        ServerHttpResponse httpResponse = Mockito.mock(ServerHttpResponse.class);
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"muc\": \"5GH05\" ,\"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"vzwRoles\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"rpsIntent\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"bogoMtn\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"spoMtn\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"universalId\":\"3532442413\",\"uId\": \"sreevardhan.korem@verizon.com\"}";
        String rfexShopDetails = "{\"mtn\":\"5016173815\",\"returnItemSeq\":\"1\"}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setRfexExchangeShopDetails(rfexShopDetails);
        sampleRedisData.setUId("sreevardhan.korem@verizon.com");
        UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        responseServiceMono = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        Mono<AddDeviceUIResponse> sampleResponseMono = Mono.just(responseServiceMono);
        List<String> ss = new ArrayList<>();
        ss.add("EUP");
        MyOfferRedisData offer = new MyOfferRedisData();
        offer.setIsMyOfferAccepted(true);
        offer.setRestricted("Y");
        offer.setRtdOfferId("PR_602");
        offer.setRestrictedProductType("EQP");
        String etrString = "{\"cartId\": \"\",\"atenaSessionId\": \"\",\"lines\": [{\"mtn\": \"5079937563\",\"offers\": [{\"complianceType\": \"ACC\",\"sku\": \"200350\",\"description\": \"UAT_73 SL: Get 50% off of Any Phone Case\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_73\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"},{\"complianceType\": \"EQP\",\"sku\": \"202617\",\"description\": \"Get $300 Recurring BIC on Smartphone Upgrade (Multi Line)\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"EA\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_85\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"}]}]}";
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        String nbxString = "{\"service\": {\"serviceHeader\": {\"clientId\": \"NETACE\",\"clientTransactionId\": \"NETACE-28023137-TXN\",\"clientSessionId\": \"NETACE-32a6993a-SESSION\",\"timestamp\": \"2020-05-06 07:50:30 GMT\",\"serviceName\": \"NBX\"},\"serviceBody\": {\"serviceRequest\": {\"contextInfo\": {\"callReason\": \"Recommendation\",\"category\": \"Offers\",\"subServiceName\": \"CaptureResponse\",\"sessionId\": \"-2233353673817713409\",\"rtdSessionID\": \"\"},\"customerInfo\": {\"mtn\": \"7573285016\",\"accountNo\": \"0420914396-00001\"},\"customerResponse\": {\"responseList\": [{\"rank\": \"1\",\"propositionId\": \"RO_01\",\"dispositionOptionId\": \"82\",\"soiEngagementId\": \"501002648\",\"timeStamp\": \"2020-05-06 07:50:30 GMT\",\"dynamicAttrList\": [{\"attrId\": \"skuid\",\"value\": \"MWAR2LL/A\"},{\"attrId\": \"Offer\",\"value\": \"RS_131\"}]}],\"externalResponseList\": [{\"rank\": null,\"propositionId\": \"RS_131\",\"dispositionOptionId\": \"82\",\"dynamicAttrList\": [{\"attrId\": \"isRtdOffer\",\"value\": \"N\"}],\"externalId\": null}]}}}}}";
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = "{\"lines\": [{\"mtn\": \"5079937563\",\"getBestValuePromotions\": {  \"clientId\": \"NETACE\",  \"sessionId\": \"4352144075584082252\",  \"rtdSessionId\": \"NBA-85771580-SQA1\",  \"clientSessionId\": \"0\",  \"clientTransactionId\": \"\",  \"bestValueOffers\": [{  \"id\": \"203040\",  \"rank\": \"1\",  \"dispositionOptionId\": null,  \"myOffer\": true,  \"verizonUp\": false,  \"barcode\": null,  \"myOfferAccepted\": false,  \"verizonUpAccepted\": false,  \"name\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"description\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"redemptionIds\": null,  \"contractTypes\": [\"2YR\",\"FR\",\"DPP\"  ],  \"compatiblePlanIds\": [\"36571\",\"36569\",\"36565\",\"36496\",\"36310\",\"36184\"  ],  \"deviceSku\": \"SMN976VZWV\"}  ],  \"totalDeviceDollarsBalance\": \"0.0\",  \"deviceDollarDisplayName\": \"\",  \"isVerizonUpAvailable\": false,  \"isDeviceDollarManuallyAccepted\": false,  \"rank\": \"1\",  \"propositionId\": \"RO_01\",  \"dispositionId\": \"10\",  \"soiEngagementId\": \"501002648\"}}]}";
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        InEligibleLinesRedisData ie = new InEligibleLinesRedisData();
        ie.setMtn("7169849755");
        ie.setReason("");
        List<InEligibleLinesRedisData> ieData = new ArrayList<>();
        ieData.add(ie);
        String ineligibleData = "[{\"mtn\":\"7169849755\", \"reason\":\"Crisis\"}]";
        try {
            ieData = mapper.readValue(ineligibleData, new TypeReference<List<InEligibleLinesRedisData>>(){});
        } catch (JsonProcessingException e) {
            System.out.println(CartConstants.JSON_PRCSSNG_EXCPTN_STRNG + e);
        }
        when(redisHelper.getInEligibleUpgradeLinesFromRedis()).thenReturn(Mono.just(ieData));
        when(featureFlagHelper.fetchD2DFeatureFlag()).thenReturn(Mono.just(true));
        when(featureFlagHelper.trade3POChoiceOfferFFlag()).thenReturn(Boolean.TRUE);
        FiveGAddressRedisData fiveGAddress = mapper.readValue("{  \"cartId\" : \"448f5443-5564-4f10-bd18-c2620b0c317b\",  \"addressRequest\" : {    \"addressLine1\" : \"1 VERIZON WAY\",    \"city\" : \"BASKING RIDGE\",    \"state\" : \"NJ\",    \"zipCode\" : \"07920\",    \"channel\" : \"digital\",    \"type\" : \"all\",    \"enableDebug\" : false,    \"enableCustomGQL\" : false,    \"launchType\" : \"FCL\",    \"eventCorrelationId\" : \"07920_1591463732951_243\",    \"floor\" : \"2\",    \"descriptorInfo\" : \"North Maple Avenue\"  }}", FiveGAddressRedisData.class);
        when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(fiveGAddress));
        String cartId="20ae6bcb-1150-4d16-99dd-14b7d9f128c7";
        String vcResStr = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
        ValidateCartUIResponse sampleResponse = mapper.readValue(vcResStr, ValidateCartUIResponse.class);
        Mono<ValidateCartUIResponse> vcMono = Mono.just(sampleResponse);
        when(cxpHelper.validateCart(any(),Mockito.any())).thenReturn(vcMono);
        when(cradleAllocator.invokeCradle(any())).thenReturn(new CradleResponse());
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        when(redisHelper.getMyOfferDataFromRedis()).thenReturn(Mono.just(offer));
        when(bpmHelper.addDevice(any(), any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        when(redisHelper.getMtnToPlanIdMap()).thenReturn(Mono.just("{\"8436667390\":\"94171\"}"));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just(""));
        when(redisHelper2.getRole()).thenReturn(Mono.just(""));
        when(redisHelper2.getEdgeBuyoutRedisData()).thenReturn(Mono.just(new HashMap()));
        when(redisHelper2.updateDeviceCartCount("1", Boolean.FALSE)).thenReturn(Mono.just(true));
        when(redisHelper2.updateCartOrderFlowType("eup")).thenReturn(Mono.just(true));
        when(redisHelper.upsertOneClickCheckoutFlag(Mockito.anyString())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(cxpHelper.getDeviceCartMap(cartId)).thenReturn(Mono.empty());
        when(redisHelper2.getDeviceCartMap()).thenReturn(Mono.just(new HashMap()));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just(""));
        when(redisHelper3.getHashCodeMtn(UIRequest)).thenReturn(Mono.just(""));
        when(preHandleAddDevice.execute(UIRequest, sampleRedisData)).thenReturn(Mono.just(Boolean.TRUE));
        AddDeviceUIResponse expectedResponse = responseServiceMono;
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(cradleResponse));
        Mono<AddDeviceUIResponse> response = accDevHelper.addDevice(UIRequest,httpResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addDeviceHelperUidNotMatchedTest() throws IOException, SOEHTTPException {
        String sampleRequestString = "{\"channelId\":\"CHAT-STORE\", \"cartInfo\": {  \"cartCreator\": \"\", \"deviceType\": \"PHONE\", \"clientAppName\": \"CHAT-STORE\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"REX\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\", \"networkBandwidthType\": \"LTE\" ,  \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        AddDeviceUIResponse responseServiceMono = new AddDeviceUIResponse();
        AddDeviceUIRequest UIRequest = new AddDeviceUIRequest();
        ServerHttpResponse httpResponse = Mockito.mock(ServerHttpResponse.class);
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"muc\": \"5GH05\" ,\"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"vzwRoles\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"rpsIntent\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"bogoMtn\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"spoMtn\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"universalId\":\"3532442413\",\"uId\": \"sreevardhan.korem@verizon.com\"}";
        String rfexShopDetails = "{\"mtn\":\"5016173815\",\"returnItemSeq\":\"1\"}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setRfexExchangeShopDetails(rfexShopDetails);
        sampleRedisData.setUId("sreevardhan.korem@gmail.com");
        UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        responseServiceMono = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        Mono<AddDeviceUIResponse> sampleResponseMono = Mono.just(responseServiceMono);
        List<String> ss = new ArrayList<>();
        ss.add("EUP");
        MyOfferRedisData offer = new MyOfferRedisData();
        offer.setIsMyOfferAccepted(true);
        offer.setRestricted("Y");
        offer.setRtdOfferId("PR_602");
        offer.setRestrictedProductType("EQP");
        String etrString = "{\"cartId\": \"\",\"atenaSessionId\": \"\",\"lines\": [{\"mtn\": \"5079937563\",\"offers\": [{\"complianceType\": \"ACC\",\"sku\": \"200350\",\"description\": \"UAT_73 SL: Get 50% off of Any Phone Case\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_73\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"},{\"complianceType\": \"EQP\",\"sku\": \"202617\",\"description\": \"Get $300 Recurring BIC on Smartphone Upgrade (Multi Line)\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"EA\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_85\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"}]}]}";
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        String nbxString = "{\"service\": {\"serviceHeader\": {\"clientId\": \"NETACE\",\"clientTransactionId\": \"NETACE-28023137-TXN\",\"clientSessionId\": \"NETACE-32a6993a-SESSION\",\"timestamp\": \"2020-05-06 07:50:30 GMT\",\"serviceName\": \"NBX\"},\"serviceBody\": {\"serviceRequest\": {\"contextInfo\": {\"callReason\": \"Recommendation\",\"category\": \"Offers\",\"subServiceName\": \"CaptureResponse\",\"sessionId\": \"-2233353673817713409\",\"rtdSessionID\": \"\"},\"customerInfo\": {\"mtn\": \"7573285016\",\"accountNo\": \"0420914396-00001\"},\"customerResponse\": {\"responseList\": [{\"rank\": \"1\",\"propositionId\": \"RO_01\",\"dispositionOptionId\": \"82\",\"soiEngagementId\": \"501002648\",\"timeStamp\": \"2020-05-06 07:50:30 GMT\",\"dynamicAttrList\": [{\"attrId\": \"skuid\",\"value\": \"MWAR2LL/A\"},{\"attrId\": \"Offer\",\"value\": \"RS_131\"}]}],\"externalResponseList\": [{\"rank\": null,\"propositionId\": \"RS_131\",\"dispositionOptionId\": \"82\",\"dynamicAttrList\": [{\"attrId\": \"isRtdOffer\",\"value\": \"N\"}],\"externalId\": null}]}}}}}";
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = "{\"lines\": [{\"mtn\": \"5079937563\",\"getBestValuePromotions\": {  \"clientId\": \"NETACE\",  \"sessionId\": \"4352144075584082252\",  \"rtdSessionId\": \"NBA-85771580-SQA1\",  \"clientSessionId\": \"0\",  \"clientTransactionId\": \"\",  \"bestValueOffers\": [{  \"id\": \"203040\",  \"rank\": \"1\",  \"dispositionOptionId\": null,  \"myOffer\": true,  \"verizonUp\": false,  \"barcode\": null,  \"myOfferAccepted\": false,  \"verizonUpAccepted\": false,  \"name\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"description\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"redemptionIds\": null,  \"contractTypes\": [\"2YR\",\"FR\",\"DPP\"  ],  \"compatiblePlanIds\": [\"36571\",\"36569\",\"36565\",\"36496\",\"36310\",\"36184\"  ],  \"deviceSku\": \"SMN976VZWV\"}  ],  \"totalDeviceDollarsBalance\": \"0.0\",  \"deviceDollarDisplayName\": \"\",  \"isVerizonUpAvailable\": false,  \"isDeviceDollarManuallyAccepted\": false,  \"rank\": \"1\",  \"propositionId\": \"RO_01\",  \"dispositionId\": \"10\",  \"soiEngagementId\": \"501002648\"}}]}";
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        InEligibleLinesRedisData ie = new InEligibleLinesRedisData();
        ie.setMtn("7169849755");
        ie.setReason("");
        List<InEligibleLinesRedisData> ieData = new ArrayList<>();
        ieData.add(ie);
        String ineligibleData = "[{\"mtn\":\"7169849755\", \"reason\":\"Crisis\"}]";
        try {
            ieData = mapper.readValue(ineligibleData, new TypeReference<List<InEligibleLinesRedisData>>(){});
        } catch (JsonProcessingException e) {
            System.out.println(CartConstants.JSON_PRCSSNG_EXCPTN_STRNG + e);
        }
        when(redisHelper.getInEligibleUpgradeLinesFromRedis()).thenReturn(Mono.just(ieData));
        when(featureFlagHelper.fetchD2DFeatureFlag()).thenReturn(Mono.just(true));
        when(featureFlagHelper.trade3POChoiceOfferFFlag()).thenReturn(Boolean.TRUE);
        FiveGAddressRedisData fiveGAddress = mapper.readValue("{  \"cartId\" : \"448f5443-5564-4f10-bd18-c2620b0c317b\",  \"addressRequest\" : {    \"addressLine1\" : \"1 VERIZON WAY\",    \"city\" : \"BASKING RIDGE\",    \"state\" : \"NJ\",    \"zipCode\" : \"07920\",    \"channel\" : \"digital\",    \"type\" : \"all\",    \"enableDebug\" : false,    \"enableCustomGQL\" : false,    \"launchType\" : \"FCL\",    \"eventCorrelationId\" : \"07920_1591463732951_243\",    \"floor\" : \"2\",    \"descriptorInfo\" : \"North Maple Avenue\"  }}", FiveGAddressRedisData.class);
        when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(fiveGAddress));
        String cartId="20ae6bcb-1150-4d16-99dd-14b7d9f128c7";
        String vcResStr = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
        ValidateCartUIResponse sampleResponse = mapper.readValue(vcResStr, ValidateCartUIResponse.class);
        Mono<ValidateCartUIResponse> vcMono = Mono.just(sampleResponse);
        when(cxpHelper.validateCart(any(),Mockito.any())).thenReturn(vcMono);
        when(cradleAllocator.invokeCradle(any())).thenReturn(new CradleResponse());
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        when(redisHelper.getMyOfferDataFromRedis()).thenReturn(Mono.just(offer));
        when(bpmHelper.addDevice(any(), any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        when(redisHelper.getMtnToPlanIdMap()).thenReturn(Mono.just("{\"8436667390\":\"94171\"}"));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just(""));
        when(redisHelper2.getRole()).thenReturn(Mono.just(""));
        when(redisHelper2.getEdgeBuyoutRedisData()).thenReturn(Mono.just(new HashMap()));
        when(redisHelper2.updateDeviceCartCount("1", Boolean.FALSE)).thenReturn(Mono.just(true));
        when(redisHelper2.updateCartOrderFlowType("eup")).thenReturn(Mono.just(true));
        when(redisHelper.upsertOneClickCheckoutFlag(Mockito.anyString())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(cxpHelper.getDeviceCartMap(cartId)).thenReturn(Mono.empty());
        when(redisHelper2.getDeviceCartMap()).thenReturn(Mono.just(new HashMap()));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just(""));
        when(redisHelper3.getHashCodeMtn(UIRequest)).thenReturn(Mono.just(""));
        when(preHandleAddDevice.execute(UIRequest, sampleRedisData)).thenReturn(Mono.just(Boolean.TRUE));
        AddDeviceUIResponse expectedResponse = responseServiceMono;
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(cradleResponse));
        Mono<AddDeviceUIResponse> response = accDevHelper.addDevice(UIRequest,httpResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addDeviceHelperEmptyUniversalIdTest() throws IOException, SOEHTTPException {
        String sampleRequestString = "{\"channelId\":\"CHAT-STORE\", \"cartInfo\": {  \"cartCreator\": \"\", \"deviceType\": \"PHONE\", \"clientAppName\": \"CHAT-STORE\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"REX\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\", \"networkBandwidthType\": \"LTE\" ,  \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        AddDeviceUIResponse responseServiceMono = new AddDeviceUIResponse();
        AddDeviceUIRequest UIRequest = new AddDeviceUIRequest();
        ServerHttpResponse httpResponse = Mockito.mock(ServerHttpResponse.class);
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"muc\": \"5GH05\" ,\"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"vzwRoles\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"rpsIntent\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"bogoMtn\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"spoMtn\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"universalId\":\"\",\"uId\": \"sreevardhan.korem@verizon.com\"}";
        String rfexShopDetails = "{\"mtn\":\"5016173815\",\"returnItemSeq\":\"1\"}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setRfexExchangeShopDetails(rfexShopDetails);
        sampleRedisData.setUId("sreevardhan.korem@gmail.com");
        UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        responseServiceMono = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        Mono<AddDeviceUIResponse> sampleResponseMono = Mono.just(responseServiceMono);
        List<String> ss = new ArrayList<>();
        ss.add("EUP");
        MyOfferRedisData offer = new MyOfferRedisData();
        offer.setIsMyOfferAccepted(true);
        offer.setRestricted("Y");
        offer.setRtdOfferId("PR_602");
        offer.setRestrictedProductType("EQP");
        String etrString = "{\"cartId\": \"\",\"atenaSessionId\": \"\",\"lines\": [{\"mtn\": \"5079937563\",\"offers\": [{\"complianceType\": \"ACC\",\"sku\": \"200350\",\"description\": \"UAT_73 SL: Get 50% off of Any Phone Case\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_73\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"},{\"complianceType\": \"EQP\",\"sku\": \"202617\",\"description\": \"Get $300 Recurring BIC on Smartphone Upgrade (Multi Line)\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"EA\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_85\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"}]}]}";
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        String nbxString = "{\"service\": {\"serviceHeader\": {\"clientId\": \"NETACE\",\"clientTransactionId\": \"NETACE-28023137-TXN\",\"clientSessionId\": \"NETACE-32a6993a-SESSION\",\"timestamp\": \"2020-05-06 07:50:30 GMT\",\"serviceName\": \"NBX\"},\"serviceBody\": {\"serviceRequest\": {\"contextInfo\": {\"callReason\": \"Recommendation\",\"category\": \"Offers\",\"subServiceName\": \"CaptureResponse\",\"sessionId\": \"-2233353673817713409\",\"rtdSessionID\": \"\"},\"customerInfo\": {\"mtn\": \"7573285016\",\"accountNo\": \"0420914396-00001\"},\"customerResponse\": {\"responseList\": [{\"rank\": \"1\",\"propositionId\": \"RO_01\",\"dispositionOptionId\": \"82\",\"soiEngagementId\": \"501002648\",\"timeStamp\": \"2020-05-06 07:50:30 GMT\",\"dynamicAttrList\": [{\"attrId\": \"skuid\",\"value\": \"MWAR2LL/A\"},{\"attrId\": \"Offer\",\"value\": \"RS_131\"}]}],\"externalResponseList\": [{\"rank\": null,\"propositionId\": \"RS_131\",\"dispositionOptionId\": \"82\",\"dynamicAttrList\": [{\"attrId\": \"isRtdOffer\",\"value\": \"N\"}],\"externalId\": null}]}}}}}";
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = "{\"lines\": [{\"mtn\": \"5079937563\",\"getBestValuePromotions\": {  \"clientId\": \"NETACE\",  \"sessionId\": \"4352144075584082252\",  \"rtdSessionId\": \"NBA-85771580-SQA1\",  \"clientSessionId\": \"0\",  \"clientTransactionId\": \"\",  \"bestValueOffers\": [{  \"id\": \"203040\",  \"rank\": \"1\",  \"dispositionOptionId\": null,  \"myOffer\": true,  \"verizonUp\": false,  \"barcode\": null,  \"myOfferAccepted\": false,  \"verizonUpAccepted\": false,  \"name\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"description\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"redemptionIds\": null,  \"contractTypes\": [\"2YR\",\"FR\",\"DPP\"  ],  \"compatiblePlanIds\": [\"36571\",\"36569\",\"36565\",\"36496\",\"36310\",\"36184\"  ],  \"deviceSku\": \"SMN976VZWV\"}  ],  \"totalDeviceDollarsBalance\": \"0.0\",  \"deviceDollarDisplayName\": \"\",  \"isVerizonUpAvailable\": false,  \"isDeviceDollarManuallyAccepted\": false,  \"rank\": \"1\",  \"propositionId\": \"RO_01\",  \"dispositionId\": \"10\",  \"soiEngagementId\": \"501002648\"}}]}";
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        InEligibleLinesRedisData ie = new InEligibleLinesRedisData();
        ie.setMtn("7169849755");
        ie.setReason("");
        List<InEligibleLinesRedisData> ieData = new ArrayList<>();
        ieData.add(ie);
        String ineligibleData = "[{\"mtn\":\"7169849755\", \"reason\":\"Crisis\"}]";
        try {
            ieData = mapper.readValue(ineligibleData, new TypeReference<List<InEligibleLinesRedisData>>(){});
        } catch (JsonProcessingException e) {
            System.out.println(CartConstants.JSON_PRCSSNG_EXCPTN_STRNG + e);
        }
        when(redisHelper.getInEligibleUpgradeLinesFromRedis()).thenReturn(Mono.just(ieData));
        when(featureFlagHelper.fetchD2DFeatureFlag()).thenReturn(Mono.just(true));
        when(featureFlagHelper.trade3POChoiceOfferFFlag()).thenReturn(Boolean.TRUE);
        FiveGAddressRedisData fiveGAddress = mapper.readValue("{  \"cartId\" : \"448f5443-5564-4f10-bd18-c2620b0c317b\",  \"addressRequest\" : {    \"addressLine1\" : \"1 VERIZON WAY\",    \"city\" : \"BASKING RIDGE\",    \"state\" : \"NJ\",    \"zipCode\" : \"07920\",    \"channel\" : \"digital\",    \"type\" : \"all\",    \"enableDebug\" : false,    \"enableCustomGQL\" : false,    \"launchType\" : \"FCL\",    \"eventCorrelationId\" : \"07920_1591463732951_243\",    \"floor\" : \"2\",    \"descriptorInfo\" : \"North Maple Avenue\"  }}", FiveGAddressRedisData.class);
        when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(fiveGAddress));
        String cartId="20ae6bcb-1150-4d16-99dd-14b7d9f128c7";
        String vcResStr = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
        ValidateCartUIResponse sampleResponse = mapper.readValue(vcResStr, ValidateCartUIResponse.class);
        Mono<ValidateCartUIResponse> vcMono = Mono.just(sampleResponse);
        when(cxpHelper.validateCart(any(),Mockito.any())).thenReturn(vcMono);
        when(cradleAllocator.invokeCradle(any())).thenReturn(new CradleResponse());
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        when(redisHelper.getMyOfferDataFromRedis()).thenReturn(Mono.just(offer));
        when(bpmHelper.addDevice(any(), any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        when(redisHelper.getMtnToPlanIdMap()).thenReturn(Mono.just("{\"8436667390\":\"94171\"}"));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just(""));
        when(redisHelper2.getRole()).thenReturn(Mono.just(""));
        when(redisHelper2.getEdgeBuyoutRedisData()).thenReturn(Mono.just(new HashMap()));
        when(redisHelper2.updateDeviceCartCount("1", Boolean.FALSE)).thenReturn(Mono.just(true));
        when(redisHelper2.updateCartOrderFlowType("eup")).thenReturn(Mono.just(true));
        when(redisHelper.upsertOneClickCheckoutFlag(Mockito.anyString())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(cxpHelper.getDeviceCartMap(cartId)).thenReturn(Mono.empty());
        when(redisHelper2.getDeviceCartMap()).thenReturn(Mono.just(new HashMap()));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just(""));
        when(redisHelper3.getHashCodeMtn(UIRequest)).thenReturn(Mono.just(""));
        when(preHandleAddDevice.execute(UIRequest, sampleRedisData)).thenReturn(Mono.just(Boolean.TRUE));
        AddDeviceUIResponse expectedResponse = responseServiceMono;
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(cradleResponse));
        Mono<AddDeviceUIResponse> response = accDevHelper.addDevice(UIRequest,httpResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceHelperDisableUidMatchedTest() throws IOException, SOEHTTPException {
        String sampleRequestString = "{\"channelId\":\"CHAT-STORE\", \"cartInfo\": {  \"cartCreator\": \"\", \"deviceType\": \"PHONE\", \"clientAppName\": \"CHAT-STORE\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"REX\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\", \"networkBandwidthType\": \"LTE\" ,  \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        AddDeviceUIResponse responseServiceMono = new AddDeviceUIResponse();
        AddDeviceUIRequest UIRequest = new AddDeviceUIRequest();
        ServerHttpResponse httpResponse = Mockito.mock(ServerHttpResponse.class);
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"muc\": \"5GH05\" ,\"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"vzwRoles\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"rpsIntent\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"bogoMtn\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"spoMtn\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"universalId\":\"3532442413\",\"uId\": \"sreevardhan.korem@verizon.com\"}";
        String rfexShopDetails = "{\"mtn\":\"5016173815\",\"returnItemSeq\":\"1\"}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setRfexExchangeShopDetails(rfexShopDetails);
        sampleRedisData.setUId("sreevardhan.korem@gmail.com");
        UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        responseServiceMono = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        Mono<AddDeviceUIResponse> sampleResponseMono = Mono.just(responseServiceMono);
        List<String> ss = new ArrayList<>();
        ss.add("EUP");
        MyOfferRedisData offer = new MyOfferRedisData();
        offer.setIsMyOfferAccepted(true);
        offer.setRestricted("Y");
        offer.setRtdOfferId("PR_602");
        offer.setRestrictedProductType("EQP");
        String etrString = "{\"cartId\": \"\",\"atenaSessionId\": \"\",\"lines\": [{\"mtn\": \"5079937563\",\"offers\": [{\"complianceType\": \"ACC\",\"sku\": \"200350\",\"description\": \"UAT_73 SL: Get 50% off of Any Phone Case\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_73\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"},{\"complianceType\": \"EQP\",\"sku\": \"202617\",\"description\": \"Get $300 Recurring BIC on Smartphone Upgrade (Multi Line)\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"EA\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_85\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"}]}]}";
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        String nbxString = "{\"service\": {\"serviceHeader\": {\"clientId\": \"NETACE\",\"clientTransactionId\": \"NETACE-28023137-TXN\",\"clientSessionId\": \"NETACE-32a6993a-SESSION\",\"timestamp\": \"2020-05-06 07:50:30 GMT\",\"serviceName\": \"NBX\"},\"serviceBody\": {\"serviceRequest\": {\"contextInfo\": {\"callReason\": \"Recommendation\",\"category\": \"Offers\",\"subServiceName\": \"CaptureResponse\",\"sessionId\": \"-2233353673817713409\",\"rtdSessionID\": \"\"},\"customerInfo\": {\"mtn\": \"7573285016\",\"accountNo\": \"0420914396-00001\"},\"customerResponse\": {\"responseList\": [{\"rank\": \"1\",\"propositionId\": \"RO_01\",\"dispositionOptionId\": \"82\",\"soiEngagementId\": \"501002648\",\"timeStamp\": \"2020-05-06 07:50:30 GMT\",\"dynamicAttrList\": [{\"attrId\": \"skuid\",\"value\": \"MWAR2LL/A\"},{\"attrId\": \"Offer\",\"value\": \"RS_131\"}]}],\"externalResponseList\": [{\"rank\": null,\"propositionId\": \"RS_131\",\"dispositionOptionId\": \"82\",\"dynamicAttrList\": [{\"attrId\": \"isRtdOffer\",\"value\": \"N\"}],\"externalId\": null}]}}}}}";
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = "{\"lines\": [{\"mtn\": \"5079937563\",\"getBestValuePromotions\": {  \"clientId\": \"NETACE\",  \"sessionId\": \"4352144075584082252\",  \"rtdSessionId\": \"NBA-85771580-SQA1\",  \"clientSessionId\": \"0\",  \"clientTransactionId\": \"\",  \"bestValueOffers\": [{  \"id\": \"203040\",  \"rank\": \"1\",  \"dispositionOptionId\": null,  \"myOffer\": true,  \"verizonUp\": false,  \"barcode\": null,  \"myOfferAccepted\": false,  \"verizonUpAccepted\": false,  \"name\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"description\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"redemptionIds\": null,  \"contractTypes\": [\"2YR\",\"FR\",\"DPP\"  ],  \"compatiblePlanIds\": [\"36571\",\"36569\",\"36565\",\"36496\",\"36310\",\"36184\"  ],  \"deviceSku\": \"SMN976VZWV\"}  ],  \"totalDeviceDollarsBalance\": \"0.0\",  \"deviceDollarDisplayName\": \"\",  \"isVerizonUpAvailable\": false,  \"isDeviceDollarManuallyAccepted\": false,  \"rank\": \"1\",  \"propositionId\": \"RO_01\",  \"dispositionId\": \"10\",  \"soiEngagementId\": \"501002648\"}}]}";
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        InEligibleLinesRedisData ie = new InEligibleLinesRedisData();
        ie.setMtn("7169849755");
        ie.setReason("");
        List<InEligibleLinesRedisData> ieData = new ArrayList<>();
        ieData.add(ie);
        String ineligibleData = "[{\"mtn\":\"7169849755\", \"reason\":\"Crisis\"}]";
        try {
            ieData = mapper.readValue(ineligibleData, new TypeReference<List<InEligibleLinesRedisData>>(){});
        } catch (JsonProcessingException e) {
            System.out.println(CartConstants.JSON_PRCSSNG_EXCPTN_STRNG + e);
        }
        when(redisHelper.getInEligibleUpgradeLinesFromRedis()).thenReturn(Mono.just(ieData));
        FiveGAddressRedisData fiveGAddress = mapper.readValue("{  \"cartId\" : \"448f5443-5564-4f10-bd18-c2620b0c317b\",  \"addressRequest\" : {    \"addressLine1\" : \"1 VERIZON WAY\",    \"city\" : \"BASKING RIDGE\",    \"state\" : \"NJ\",    \"zipCode\" : \"07920\",    \"channel\" : \"digital\",    \"type\" : \"all\",    \"enableDebug\" : false,    \"enableCustomGQL\" : false,    \"launchType\" : \"FCL\",    \"eventCorrelationId\" : \"07920_1591463732951_243\",    \"floor\" : \"2\",    \"descriptorInfo\" : \"North Maple Avenue\"  }}", FiveGAddressRedisData.class);
        when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(fiveGAddress));
        String cartId="20ae6bcb-1150-4d16-99dd-14b7d9f128c7";
        String vcResStr = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
        ValidateCartUIResponse sampleResponse = mapper.readValue(vcResStr, ValidateCartUIResponse.class);
        Mono<ValidateCartUIResponse> vcMono = Mono.just(sampleResponse);
        when(featureFlagHelper.fetchD2DFeatureFlag()).thenReturn(Mono.just(true));
        when(featureFlagHelper.trade3POChoiceOfferFFlag()).thenReturn(Boolean.TRUE);
        when(cxpHelper.validateCart(any(),Mockito.any())).thenReturn(vcMono);
        when(cradleAllocator.invokeCradle(any())).thenReturn(new CradleResponse());
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        when(redisHelper.getMyOfferDataFromRedis()).thenReturn(Mono.just(offer));
        when(bpmHelper.addDevice(any(), any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        when(redisHelper.getMtnToPlanIdMap()).thenReturn(Mono.just("{\"8436667390\":\"94171\"}"));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just(""));
        when(redisHelper2.getRole()).thenReturn(Mono.just(""));
        when(redisHelper2.getEdgeBuyoutRedisData()).thenReturn(Mono.just(new HashMap()));
        when(redisHelper2.updateDeviceCartCount("1", Boolean.FALSE)).thenReturn(Mono.just(true));
        when(redisHelper2.updateCartOrderFlowType("eup")).thenReturn(Mono.just(true));
        when(redisHelper.upsertOneClickCheckoutFlag(Mockito.anyString())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(cxpHelper.getDeviceCartMap(cartId)).thenReturn(Mono.empty());
        when(redisHelper2.getDeviceCartMap()).thenReturn(Mono.just(new HashMap()));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just(""));
        when(redisHelper3.getHashCodeMtn(UIRequest)).thenReturn(Mono.just(""));
        when(preHandleAddDevice.execute(UIRequest, sampleRedisData)).thenReturn(Mono.just(Boolean.TRUE));
        AddDeviceUIResponse expectedResponse = responseServiceMono;
        accDevHelper.enableUidDomainFilter =false;
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(cradleResponse));
        Mono<AddDeviceUIResponse> response = accDevHelper.addDevice(UIRequest,httpResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceHelperTestCombo1() throws IOException, SOEHTTPException {
        String sampleRequestString = "{\"channelId\": \"OMNI-D2D\",\"cartInfo\": {\"mtnFlow\": \"M\",\"processStep\": \"promo\",\"authorizedUser\": null,\"cartCreator\": \"\",\"clientAppName\": \"VZW-ECOM\",\"editDevice\": false,\"cartId\": \"cart\",\"caseId\": \"case\",\"processingMTN\": \"\",\"accountNumber\": \"0280106868-00001\",\"intendType\": \"AAL_5G\"},\"data\": {\"externalId\": \"id\",\"newLineOrAAL\": false,\"lines\": [{},{\"mtn\": \"mtn\"}]}}";
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-D2D\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        AddDeviceUIResponse responseServiceMono = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        String redisDataString = "{\"deviceId\": \"device\", \"cartId\": \"\",\"verifiedName\":\" name 1 2\", \"caseId\": \"\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"\",\"creditAppNum\":\"54453277834\", \"accountNumber\": \"\", \"mtn\": \"8436667390\",\"fiosAuthenticated\":true}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
       // sampleRedisData.getDeviceImeiSimDetails().setDeviceId("222");
        String offerString = "{\"isMyOfferAccepted\": true,\"restricted\": \"Y\",\"rtdOfferId\": \"PR_602\",\"restrictedProductType\": \"EQP\"}";
        MyOfferRedisData offer = mapper.readValue(offerString, MyOfferRedisData.class);
        String etrString = "{\"cartId\": \"\",\"atenaSessionId\": \"\",\"lines\": [{\"mtn\": \"5079937563\",\"offers\": [{\"complianceType\": \"ACC\",\"sku\": \"200350\",\"description\": \"UAT_73 SL: Get 50% off of Any Phone Case\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_73\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"},{\"complianceType\": \"EQP\",\"sku\": \"202617\",\"description\": \"Get $300 Recurring BIC on Smartphone Upgrade (Multi Line)\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"EA\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_85\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"}]}]}";
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        String nbxString = "{\"service\": {\"serviceHeader\": {\"clientId\": \"NETACE\",\"clientTransactionId\": \"NETACE-28023137-TXN\",\"clientSessionId\": \"NETACE-32a6993a-SESSION\",\"timestamp\": \"2020-05-06 07:50:30 GMT\",\"serviceName\": \"NBX\"},\"serviceBody\": {\"serviceRequest\": {\"contextInfo\": {\"callReason\": \"Recommendation\",\"category\": \"Offers\",\"subServiceName\": \"CaptureResponse\",\"sessionId\": \"-2233353673817713409\",\"rtdSessionID\": \"\"},\"customerInfo\": {\"mtn\": \"7573285016\",\"accountNo\": \"0420914396-00001\"},\"customerResponse\": {\"responseList\": [{\"rank\": \"1\",\"propositionId\": \"RO_01\",\"dispositionOptionId\": \"82\",\"soiEngagementId\": \"501002648\",\"timeStamp\": \"2020-05-06 07:50:30 GMT\",\"dynamicAttrList\": [{\"attrId\": \"skuid\",\"value\": \"MWAR2LL/A\"},{\"attrId\": \"Offer\",\"value\": \"RS_131\"}]}],\"externalResponseList\": [{\"rank\": null,\"propositionId\": \"RS_131\",\"dispositionOptionId\": \"82\",\"dynamicAttrList\": [{\"attrId\": \"isRtdOffer\",\"value\": \"N\"}],\"externalId\": null}]}}}}}";
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = "{\"lines\": [{\"mtn\": \"5079937563\",\"getBestValuePromotions\": {  \"clientId\": \"NETACE\",  \"sessionId\": \"4352144075584082252\",  \"rtdSessionId\": \"NBA-85771580-SQA1\",  \"clientSessionId\": \"0\",  \"clientTransactionId\": \"\",  \"bestValueOffers\": [{  \"id\": \"203040\",  \"rank\": \"1\",  \"dispositionOptionId\": null,  \"myOffer\": true,  \"verizonUp\": false,  \"barcode\": null,  \"myOfferAccepted\": false,  \"verizonUpAccepted\": false,  \"name\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"description\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"redemptionIds\": null,  \"contractTypes\": [\"2YR\",\"FR\",\"DPP\"  ],  \"compatiblePlanIds\": [\"36571\",\"36569\",\"36565\",\"36496\",\"36310\",\"36184\"  ],  \"deviceSku\": \"SMN976VZWV\"}  ],  \"totalDeviceDollarsBalance\": \"0.0\",  \"deviceDollarDisplayName\": \"\",  \"isVerizonUpAvailable\": false,  \"isDeviceDollarManuallyAccepted\": false,  \"rank\": \"1\",  \"propositionId\": \"RO_01\",  \"dispositionId\": \"10\",  \"soiEngagementId\": \"501002648\"}}]}";
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        String ineligibleData = "[{\"mtn\":\"7169849755\", \"reason\":\"Crisis\"}]";
        when(featureFlagHelper.fetchD2DFeatureFlag()).thenReturn(Mono.just(true));
        when(featureFlagHelper.trade3POChoiceOfferFFlag()).thenReturn(Boolean.TRUE);
        List<InEligibleLinesRedisData> ieData = mapper.readValue(ineligibleData, new TypeReference<List<InEligibleLinesRedisData>>(){});
        when(redisHelper.getInEligibleUpgradeLinesFromRedis()).thenReturn(Mono.just(ieData));
        FiveGAddressRedisData fiveGAddress = mapper.readValue("{\"cartId\": \"448f5443-5564-4f10-bd18-c2620b0c317b\"}", FiveGAddressRedisData.class);
        when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(fiveGAddress));
        String vcResStr = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
        ValidateCartUIResponse sampleResponse = mapper.readValue(vcResStr, ValidateCartUIResponse.class);
        ServerHttpResponse httpResponse = Mockito.mock(ServerHttpResponse.class);
        when(cxpHelper.validateCart(any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(cradleAllocator.invokeCradle(any())).thenReturn(new CradleResponse());
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        when(redisHelper.getMyOfferDataFromRedis()).thenReturn(Mono.just(offer));
        when(bpmHelper.addDevice(any(), any())).thenReturn(Mono.just(responseServiceMono));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        when(redisHelper.getMtnToPlanIdMap()).thenReturn(Mono.just(""));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just(""));
        when(redisHelper2.getRole()).thenReturn(Mono.just(""));
        when(redisHelper2.getEdgeBuyoutRedisData()).thenReturn(Mono.just(new HashMap()));
        when(redisHelper2.updateDeviceCartCount(any(), any())).thenReturn(Mono.just(true));
        when((redisHelper2.updateBByOrderDetails(any(),any()))).thenReturn(Mono.just(true));
        when(redisHelper2.updateCartOrderFlowType(any())).thenReturn(Mono.just(true));
        when(redisHelper.upsertOneClickCheckoutFlag(Mockito.anyString())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(cxpHelper.getDeviceCartMap(any())).thenReturn(Mono.empty());
        Map<String, String> cartMap = new HashMap<>();
        cartMap.put("deviceCount", "2");
        when(redisHelper2.getDeviceCartMap()).thenReturn(Mono.just(cartMap));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just(""));
        when(redisHelper3.getHashCodeMtn(any())).thenReturn(Mono.just(""));
        when(preHandleAddDevice.execute(UIRequest, sampleRedisData)).thenReturn(Mono.just(Boolean.TRUE));
        String outPut = "{\n" +
                "  \"throttleList\": \"|ComboOrderD2D|\"\n" +
                "}";
        final var cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(outPut);
        Mockito.when(cradleAllocator.invokeReactiveCradle(any(ServerHttpRequest.class),
                        any(ServerHttpResponse.class), anyMap()))
                .thenReturn(Mono.just(cradleResponse));
        when(accDevHelper1.invokeCradleForComboExistingCustomer(UIRequest))
                .thenReturn(Mono.just(cradleResponse));
        Mono<Boolean> checkCradleResp = accDevHelper1.checkCradleResponseForComboOrderExistingCustomer(UIRequest);
        Mono<AddDeviceUIResponse> response = null;/*accDevHelper.addDevice(UIRequest,httpResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();*/
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"BYODSimIDPage\",\"processAction\":\"addDeviceSim\",\"intendType\":\"NSEBYOD\",\"zipCode\":\"\",\"addressLine1\":\"\",\"city\":\"\",\"state\":\"\"},\"data\":{\"subFlow\":\"\",\"imeiFromSession\":true,\"lines\":[{\"mtn\":\"newLine1\",\"device\":{\"id\":\"MLAE3LL/A-2\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"\",\"contractTerm\":\"MONTH_TO_MONTH\",\"deviceId\":\"eee\",\"smartIMEI\":false,\"category\":\"Smartphone\",\"rawCategory\":\"5G Smartphone\",\"prodType\":\"5GSmartphone\",\"byodESimPhone\":true},\"sim\":{\"id\":\"SOFTSIM5G-SA-D\",\"isCustomerProvidedSIM\":false,\"iccid\":\"\",\"eSIM\":\"\"},\"isNewLine\":true,\"ispuFlow\":false,\"depletionType\":\"F\",\"depletionLocationCode\":\"\",\"isKeepingExistingEqProtection\":true}],\"enableFcc\":true}}";

        UIRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
        UIRequest.setChannelId("VZW-DOTCOM");
        DeviceImeiSimDetails deviceImeiSimDetails = new DeviceImeiSimDetails();
        deviceImeiSimDetails.setIccid("00000");
        deviceImeiSimDetails.setImei2("1234");
        deviceImeiSimDetails.setImei1("5678");
        deviceImeiSimDetails.setEID("9087645");
        deviceImeiSimDetails.setDeviceId("111");
        sampleRedisData.setDeviceImeiSimDetails(deviceImeiSimDetails);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(accDevHelper1.invokeCradleForComboExistingCustomer(UIRequest)).thenReturn(Mono.just(cradleResponse));
        when(preHandleAddDevice.execute(UIRequest, sampleRedisData)).thenReturn(Mono.just(Boolean.TRUE));
        response = accDevHelper.addDevice(UIRequest,httpResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        deviceImeiSimDetails.setImei2("");
        deviceImeiSimDetails.setImei1("");
        sampleRedisData.setDeviceImeiSimDetails(deviceImeiSimDetails);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(preHandleAddDevice.execute(UIRequest, sampleRedisData)).thenReturn(Mono.just(Boolean.TRUE));
        response = accDevHelper.addDevice(UIRequest,httpResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        sampleRedisData.setDeviceImeiSimDetails(null);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(preHandleAddDevice.execute(UIRequest, sampleRedisData)).thenReturn(Mono.just(Boolean.TRUE));
        response = accDevHelper.addDevice(UIRequest,httpResponse);
        StepVerifier.create(response)
                .expectError().verify();
        UIRequest.getData().getLines().get(0).getDevice().setSmartIMEI(true);
        response = accDevHelper.addDevice(UIRequest,httpResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        UIRequest.getData().getLines().get(0).getDevice().setSmartIMEI(null);
        response = accDevHelper.addDevice(UIRequest,httpResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        UIRequest.getData().getLines().get(0).setSim(null);
        response = accDevHelper.addDevice(UIRequest,httpResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        UIRequest.getData().getLines().get(0).setDevice(null);
        response = accDevHelper.addDevice(UIRequest,httpResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        UIRequest.getData().setImeiFromSession(false);
        response = accDevHelper.addDevice(UIRequest,httpResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addDeviceHelperTestCombo4() throws IOException, SOEHTTPException {
        String sampleRequestString = "{\"channelId\": \"OMNI-D2D-TAB\",\"cartInfo\": {\"mtnFlow\": \"M\",\"processStep\": \"promo\",\"authorizedUser\": null,\"cartCreator\": \"\",\"clientAppName\": \"VZW-ECOM\",\"editDevice\": false,\"cartId\": \"cart\",\"caseId\": \"case\",\"processingMTN\": \"\",\"accountNumber\": \"0280106868-00001\",\"intendType\": \"AAL_5G\"},\"data\": {\"externalId\": \"id\",\"newLineOrAAL\": false,\"lines\": [{},{\"mtn\": \"mtn\"}]}}";
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-D2D-TAB\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        AddDeviceUIResponse responseServiceMono = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        String redisDataString = "{\"deviceId\": \"device\", \"cartId\": \"\",\"verifiedName\":\" name 1 2\", \"caseId\": \"\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"\",\"creditAppNum\":\"54453277834\", \"accountNumber\": \"\", \"mtn\": \"8436667390\",\"fiosAuthenticated\":true}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String offerString = "{\"isMyOfferAccepted\": true,\"restricted\": \"Y\",\"rtdOfferId\": \"PR_602\",\"restrictedProductType\": \"EQP\"}";
        MyOfferRedisData offer = mapper.readValue(offerString, MyOfferRedisData.class);
        String etrString = "{\"cartId\": \"\",\"atenaSessionId\": \"\",\"lines\": [{\"mtn\": \"5079937563\",\"offers\": [{\"complianceType\": \"ACC\",\"sku\": \"200350\",\"description\": \"UAT_73 SL: Get 50% off of Any Phone Case\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_73\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"},{\"complianceType\": \"EQP\",\"sku\": \"202617\",\"description\": \"Get $300 Recurring BIC on Smartphone Upgrade (Multi Line)\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"EA\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_85\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"}]}]}";
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        String nbxString = "{\"service\": {\"serviceHeader\": {\"clientId\": \"NETACE\",\"clientTransactionId\": \"NETACE-28023137-TXN\",\"clientSessionId\": \"NETACE-32a6993a-SESSION\",\"timestamp\": \"2020-05-06 07:50:30 GMT\",\"serviceName\": \"NBX\"},\"serviceBody\": {\"serviceRequest\": {\"contextInfo\": {\"callReason\": \"Recommendation\",\"category\": \"Offers\",\"subServiceName\": \"CaptureResponse\",\"sessionId\": \"-2233353673817713409\",\"rtdSessionID\": \"\"},\"customerInfo\": {\"mtn\": \"7573285016\",\"accountNo\": \"0420914396-00001\"},\"customerResponse\": {\"responseList\": [{\"rank\": \"1\",\"propositionId\": \"RO_01\",\"dispositionOptionId\": \"82\",\"soiEngagementId\": \"501002648\",\"timeStamp\": \"2020-05-06 07:50:30 GMT\",\"dynamicAttrList\": [{\"attrId\": \"skuid\",\"value\": \"MWAR2LL/A\"},{\"attrId\": \"Offer\",\"value\": \"RS_131\"}]}],\"externalResponseList\": [{\"rank\": null,\"propositionId\": \"RS_131\",\"dispositionOptionId\": \"82\",\"dynamicAttrList\": [{\"attrId\": \"isRtdOffer\",\"value\": \"N\"}],\"externalId\": null}]}}}}}";
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = "{\"lines\": [{\"mtn\": \"5079937563\",\"getBestValuePromotions\": {  \"clientId\": \"NETACE\",  \"sessionId\": \"4352144075584082252\",  \"rtdSessionId\": \"NBA-85771580-SQA1\",  \"clientSessionId\": \"0\",  \"clientTransactionId\": \"\",  \"bestValueOffers\": [{  \"id\": \"203040\",  \"rank\": \"1\",  \"dispositionOptionId\": null,  \"myOffer\": true,  \"verizonUp\": false,  \"barcode\": null,  \"myOfferAccepted\": false,  \"verizonUpAccepted\": false,  \"name\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"description\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"redemptionIds\": null,  \"contractTypes\": [\"2YR\",\"FR\",\"DPP\"  ],  \"compatiblePlanIds\": [\"36571\",\"36569\",\"36565\",\"36496\",\"36310\",\"36184\"  ],  \"deviceSku\": \"SMN976VZWV\"}  ],  \"totalDeviceDollarsBalance\": \"0.0\",  \"deviceDollarDisplayName\": \"\",  \"isVerizonUpAvailable\": false,  \"isDeviceDollarManuallyAccepted\": false,  \"rank\": \"1\",  \"propositionId\": \"RO_01\",  \"dispositionId\": \"10\",  \"soiEngagementId\": \"501002648\"}}]}";
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        String ineligibleData = "[{\"mtn\":\"7169849755\", \"reason\":\"Crisis\"}]";
        when(featureFlagHelper.fetchD2DFeatureFlag()).thenReturn(Mono.just(true));
        when(featureFlagHelper.trade3POChoiceOfferFFlag()).thenReturn(Boolean.TRUE);
        List<InEligibleLinesRedisData> ieData = mapper.readValue(ineligibleData, new TypeReference<List<InEligibleLinesRedisData>>(){});
        when(redisHelper.getInEligibleUpgradeLinesFromRedis()).thenReturn(Mono.just(ieData));
        FiveGAddressRedisData fiveGAddress = mapper.readValue("{\"cartId\": \"448f5443-5564-4f10-bd18-c2620b0c317b\"}", FiveGAddressRedisData.class);
        when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(fiveGAddress));
        String vcResStr = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
        ValidateCartUIResponse sampleResponse = mapper.readValue(vcResStr, ValidateCartUIResponse.class);
        ServerHttpResponse httpResponse = Mockito.mock(ServerHttpResponse.class);
        when(cxpHelper.validateCart(any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(cradleAllocator.invokeCradle(any())).thenReturn(new CradleResponse());
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        when(redisHelper.getMyOfferDataFromRedis()).thenReturn(Mono.just(offer));
        when(bpmHelper.addDevice(any(), any())).thenReturn(Mono.just(responseServiceMono));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        when(redisHelper.getMtnToPlanIdMap()).thenReturn(Mono.just(""));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just(""));
        when(redisHelper2.getRole()).thenReturn(Mono.just(""));
        when(redisHelper2.getEdgeBuyoutRedisData()).thenReturn(Mono.just(new HashMap()));
        when(redisHelper2.updateDeviceCartCount(any(), any())).thenReturn(Mono.just(true));
        when((redisHelper2.updateBByOrderDetails(any(),any()))).thenReturn(Mono.just(true));
        when(redisHelper2.updateCartOrderFlowType(any())).thenReturn(Mono.just(true));
        when(redisHelper.upsertOneClickCheckoutFlag(Mockito.anyString())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(cxpHelper.getDeviceCartMap(any())).thenReturn(Mono.empty());
        Map<String, String> cartMap = new HashMap<>();
        cartMap.put("deviceCount", "2");
        when(redisHelper2.getDeviceCartMap()).thenReturn(Mono.just(cartMap));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just(""));
        when(redisHelper3.getHashCodeMtn(any())).thenReturn(Mono.just(""));
        when(preHandleAddDevice.execute(UIRequest, sampleRedisData)).thenReturn(Mono.just(Boolean.TRUE));
        String outPut = "{\n" +
                "  \"throttleList\": \"|ComboOrderD2D|\"\n" +
                "}";
        UIRequest.setChannelId(CartConstants.D2D_IPAD);
        final var cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(outPut);
        Mockito.when(cradleAllocator.invokeReactiveCradle(any(ServerHttpRequest.class),
                        any(ServerHttpResponse.class), anyMap()))
                .thenReturn(Mono.just(cradleResponse));
        when(accDevHelper1.invokeCradleForComboExistingCustomer(UIRequest)).thenReturn(Mono.just(cradleResponse));
        Mono<Boolean> checkCradleResp = accDevHelper1.checkCradleResponseForComboOrderExistingCustomer(UIRequest);
        Mono<AddDeviceUIResponse> response = accDevHelper.addDevice(UIRequest,httpResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addDeviceHelperTestCombo2() throws IOException, SOEHTTPException {
        String sampleRequestString = "{\"channelId\": \"OMNI-TELESALES\",\"cartInfo\": {\"mtnFlow\": \"M\",\"processStep\": \"promo\",\"authorizedUser\": null,\"cartCreator\": \"\",\"clientAppName\": \"VZW-ECOM\",\"editDevice\": false,\"cartId\": \"cart\",\"caseId\": \"case\",\"processingMTN\": \"\",\"accountNumber\": \"0280106868-00001\",\"intendType\": \"AAL_5G\"},\"data\": {\"externalId\": \"id\",\"newLineOrAAL\": false,\"lines\": [{},{\"mtn\": \"mtn\"}]}}";
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-TELESALES\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        AddDeviceUIResponse responseServiceMono = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        String redisDataString = "{\"deviceId\": \"device\", \"cartId\": \"\",\"verifiedName\":\" name 1 2\", \"caseId\": \"\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"\",\"creditAppNum\":\"54453277834\", \"accountNumber\": \"\", \"mtn\": \"8436667390\",\"fiosAuthenticated\":true}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String offerString = "{\"isMyOfferAccepted\": true,\"restricted\": \"Y\",\"rtdOfferId\": \"PR_602\",\"restrictedProductType\": \"EQP\"}";
        MyOfferRedisData offer = mapper.readValue(offerString, MyOfferRedisData.class);
        String etrString = "{\"cartId\": \"\",\"atenaSessionId\": \"\",\"lines\": [{\"mtn\": \"5079937563\",\"offers\": [{\"complianceType\": \"ACC\",\"sku\": \"200350\",\"description\": \"UAT_73 SL: Get 50% off of Any Phone Case\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_73\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"},{\"complianceType\": \"EQP\",\"sku\": \"202617\",\"description\": \"Get $300 Recurring BIC on Smartphone Upgrade (Multi Line)\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"EA\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_85\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"}]}]}";
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        String nbxString = "{\"service\": {\"serviceHeader\": {\"clientId\": \"NETACE\",\"clientTransactionId\": \"NETACE-28023137-TXN\",\"clientSessionId\": \"NETACE-32a6993a-SESSION\",\"timestamp\": \"2020-05-06 07:50:30 GMT\",\"serviceName\": \"NBX\"},\"serviceBody\": {\"serviceRequest\": {\"contextInfo\": {\"callReason\": \"Recommendation\",\"category\": \"Offers\",\"subServiceName\": \"CaptureResponse\",\"sessionId\": \"-2233353673817713409\",\"rtdSessionID\": \"\"},\"customerInfo\": {\"mtn\": \"7573285016\",\"accountNo\": \"0420914396-00001\"},\"customerResponse\": {\"responseList\": [{\"rank\": \"1\",\"propositionId\": \"RO_01\",\"dispositionOptionId\": \"82\",\"soiEngagementId\": \"501002648\",\"timeStamp\": \"2020-05-06 07:50:30 GMT\",\"dynamicAttrList\": [{\"attrId\": \"skuid\",\"value\": \"MWAR2LL/A\"},{\"attrId\": \"Offer\",\"value\": \"RS_131\"}]}],\"externalResponseList\": [{\"rank\": null,\"propositionId\": \"RS_131\",\"dispositionOptionId\": \"82\",\"dynamicAttrList\": [{\"attrId\": \"isRtdOffer\",\"value\": \"N\"}],\"externalId\": null}]}}}}}";
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = "{\"lines\": [{\"mtn\": \"5079937563\",\"getBestValuePromotions\": {  \"clientId\": \"NETACE\",  \"sessionId\": \"4352144075584082252\",  \"rtdSessionId\": \"NBA-85771580-SQA1\",  \"clientSessionId\": \"0\",  \"clientTransactionId\": \"\",  \"bestValueOffers\": [{  \"id\": \"203040\",  \"rank\": \"1\",  \"dispositionOptionId\": null,  \"myOffer\": true,  \"verizonUp\": false,  \"barcode\": null,  \"myOfferAccepted\": false,  \"verizonUpAccepted\": false,  \"name\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"description\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"redemptionIds\": null,  \"contractTypes\": [\"2YR\",\"FR\",\"DPP\"  ],  \"compatiblePlanIds\": [\"36571\",\"36569\",\"36565\",\"36496\",\"36310\",\"36184\"  ],  \"deviceSku\": \"SMN976VZWV\"}  ],  \"totalDeviceDollarsBalance\": \"0.0\",  \"deviceDollarDisplayName\": \"\",  \"isVerizonUpAvailable\": false,  \"isDeviceDollarManuallyAccepted\": false,  \"rank\": \"1\",  \"propositionId\": \"RO_01\",  \"dispositionId\": \"10\",  \"soiEngagementId\": \"501002648\"}}]}";
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        String ineligibleData = "[{\"mtn\":\"7169849755\", \"reason\":\"Crisis\"}]";
        when(featureFlagHelper.fetchD2DFeatureFlag()).thenReturn(Mono.just(true));
        when(featureFlagHelper.trade3POChoiceOfferFFlag()).thenReturn(Boolean.TRUE);
        List<InEligibleLinesRedisData> ieData = mapper.readValue(ineligibleData, new TypeReference<List<InEligibleLinesRedisData>>(){});
        when(redisHelper.getInEligibleUpgradeLinesFromRedis()).thenReturn(Mono.just(ieData));
        FiveGAddressRedisData fiveGAddress = mapper.readValue("{\"cartId\": \"448f5443-5564-4f10-bd18-c2620b0c317b\"}", FiveGAddressRedisData.class);
        when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(fiveGAddress));
        String vcResStr = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
        ValidateCartUIResponse sampleResponse = mapper.readValue(vcResStr, ValidateCartUIResponse.class);
        ServerHttpResponse httpResponse = Mockito.mock(ServerHttpResponse.class);
        when(cxpHelper.validateCart(any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(cradleAllocator.invokeCradle(any())).thenReturn(new CradleResponse());
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        when(redisHelper.getMyOfferDataFromRedis()).thenReturn(Mono.just(offer));
        when(bpmHelper.addDevice(any(), any())).thenReturn(Mono.just(responseServiceMono));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        when(redisHelper.getMtnToPlanIdMap()).thenReturn(Mono.just(""));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just(""));
        when(redisHelper2.getRole()).thenReturn(Mono.just(""));
        when(redisHelper2.getEdgeBuyoutRedisData()).thenReturn(Mono.just(new HashMap()));
        when(redisHelper2.updateDeviceCartCount(any(), any())).thenReturn(Mono.just(true));
        when((redisHelper2.updateBByOrderDetails(any(),any()))).thenReturn(Mono.just(true));
        when(redisHelper2.updateCartOrderFlowType(any())).thenReturn(Mono.just(true));
        when(redisHelper.upsertOneClickCheckoutFlag(Mockito.anyString())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(cxpHelper.getDeviceCartMap(any())).thenReturn(Mono.empty());
        Map<String, String> cartMap = new HashMap<>();
        cartMap.put("deviceCount", "2");
        when(redisHelper2.getDeviceCartMap()).thenReturn(Mono.just(cartMap));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just(""));
        when(redisHelper3.getHashCodeMtn(any())).thenReturn(Mono.just(""));
        when(preHandleAddDevice.execute(UIRequest, sampleRedisData)).thenReturn(Mono.just(Boolean.TRUE));
        String outPut = "{\n" +
                "  \"throttleList\": \"|ComboOrderTelesales|\"\n" +
                "}";
        final var cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(outPut);
        UIRequest.setChannelId(CartConstants.OMNI_TELESALES);
        Mockito.when(cradleAllocator.invokeReactiveCradle(any(ServerHttpRequest.class),
                        any(ServerHttpResponse.class), anyMap()))
                .thenReturn(Mono.just(cradleResponse));
        when(accDevHelper1.invokeCradleForComboExistingCustomer(UIRequest)).thenReturn(Mono.just(cradleResponse));
        Mono<Boolean> checkCradleResp = accDevHelper1.checkCradleResponseForComboOrderExistingCustomer(UIRequest);
        Mono<AddDeviceUIResponse> response = accDevHelper.addDevice(UIRequest,httpResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addDeviceHelperTestCombo3() throws IOException, SOEHTTPException {
        String sampleRequestString = "{\"channelId\": \"OMNI-RETAIL\",\"cartInfo\": {\"mtnFlow\": \"M\",\"processStep\": \"promo\",\"authorizedUser\": null,\"cartCreator\": \"\",\"clientAppName\": \"VZW-ECOM\",\"editDevice\": false,\"cartId\": \"cart\",\"caseId\": \"case\",\"processingMTN\": \"\",\"accountNumber\": \"0280106868-00001\",\"intendType\": \"AAL_5G\"},\"data\": {\"externalId\": \"id\",\"newLineOrAAL\": false,\"lines\": [{},{\"mtn\": \"mtn\"}]}}";
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-RETAIL\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        AddDeviceUIResponse responseServiceMono = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        String redisDataString = "{\"deviceId\": \"device\", \"cartId\": \"\",\"verifiedName\":\" name 1 2\", \"caseId\": \"\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"\",\"creditAppNum\":\"54453277834\", \"accountNumber\": \"\", \"mtn\": \"8436667390\",\"fiosAuthenticated\":true}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String offerString = "{\"isMyOfferAccepted\": true,\"restricted\": \"Y\",\"rtdOfferId\": \"PR_602\",\"restrictedProductType\": \"EQP\"}";
        MyOfferRedisData offer = mapper.readValue(offerString, MyOfferRedisData.class);
        String etrString = "{\"cartId\": \"\",\"atenaSessionId\": \"\",\"lines\": [{\"mtn\": \"5079937563\",\"offers\": [{\"complianceType\": \"ACC\",\"sku\": \"200350\",\"description\": \"UAT_73 SL: Get 50% off of Any Phone Case\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_73\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"},{\"complianceType\": \"EQP\",\"sku\": \"202617\",\"description\": \"Get $300 Recurring BIC on Smartphone Upgrade (Multi Line)\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"EA\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_85\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"}]}]}";
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        String nbxString = "{\"service\": {\"serviceHeader\": {\"clientId\": \"NETACE\",\"clientTransactionId\": \"NETACE-28023137-TXN\",\"clientSessionId\": \"NETACE-32a6993a-SESSION\",\"timestamp\": \"2020-05-06 07:50:30 GMT\",\"serviceName\": \"NBX\"},\"serviceBody\": {\"serviceRequest\": {\"contextInfo\": {\"callReason\": \"Recommendation\",\"category\": \"Offers\",\"subServiceName\": \"CaptureResponse\",\"sessionId\": \"-2233353673817713409\",\"rtdSessionID\": \"\"},\"customerInfo\": {\"mtn\": \"7573285016\",\"accountNo\": \"0420914396-00001\"},\"customerResponse\": {\"responseList\": [{\"rank\": \"1\",\"propositionId\": \"RO_01\",\"dispositionOptionId\": \"82\",\"soiEngagementId\": \"501002648\",\"timeStamp\": \"2020-05-06 07:50:30 GMT\",\"dynamicAttrList\": [{\"attrId\": \"skuid\",\"value\": \"MWAR2LL/A\"},{\"attrId\": \"Offer\",\"value\": \"RS_131\"}]}],\"externalResponseList\": [{\"rank\": null,\"propositionId\": \"RS_131\",\"dispositionOptionId\": \"82\",\"dynamicAttrList\": [{\"attrId\": \"isRtdOffer\",\"value\": \"N\"}],\"externalId\": null}]}}}}}";
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = "{\"lines\": [{\"mtn\": \"5079937563\",\"getBestValuePromotions\": {  \"clientId\": \"NETACE\",  \"sessionId\": \"4352144075584082252\",  \"rtdSessionId\": \"NBA-85771580-SQA1\",  \"clientSessionId\": \"0\",  \"clientTransactionId\": \"\",  \"bestValueOffers\": [{  \"id\": \"203040\",  \"rank\": \"1\",  \"dispositionOptionId\": null,  \"myOffer\": true,  \"verizonUp\": false,  \"barcode\": null,  \"myOfferAccepted\": false,  \"verizonUpAccepted\": false,  \"name\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"description\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"redemptionIds\": null,  \"contractTypes\": [\"2YR\",\"FR\",\"DPP\"  ],  \"compatiblePlanIds\": [\"36571\",\"36569\",\"36565\",\"36496\",\"36310\",\"36184\"  ],  \"deviceSku\": \"SMN976VZWV\"}  ],  \"totalDeviceDollarsBalance\": \"0.0\",  \"deviceDollarDisplayName\": \"\",  \"isVerizonUpAvailable\": false,  \"isDeviceDollarManuallyAccepted\": false,  \"rank\": \"1\",  \"propositionId\": \"RO_01\",  \"dispositionId\": \"10\",  \"soiEngagementId\": \"501002648\"}}]}";
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        String ineligibleData = "[{\"mtn\":\"7169849755\", \"reason\":\"Crisis\"}]";
        when(featureFlagHelper.fetchD2DFeatureFlag()).thenReturn(Mono.just(true));
        when(featureFlagHelper.trade3POChoiceOfferFFlag()).thenReturn(Boolean.TRUE);
        List<InEligibleLinesRedisData> ieData = mapper.readValue(ineligibleData, new TypeReference<List<InEligibleLinesRedisData>>(){});
        when(redisHelper.getInEligibleUpgradeLinesFromRedis()).thenReturn(Mono.just(ieData));
        FiveGAddressRedisData fiveGAddress = mapper.readValue("{\"cartId\": \"448f5443-5564-4f10-bd18-c2620b0c317b\"}", FiveGAddressRedisData.class);
        when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(fiveGAddress));
        String vcResStr = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
        ValidateCartUIResponse sampleResponse = mapper.readValue(vcResStr, ValidateCartUIResponse.class);
        ServerHttpResponse httpResponse = Mockito.mock(ServerHttpResponse.class);
        when(cxpHelper.validateCart(any(),any())).thenReturn(Mono.just(sampleResponse));
        when(cradleAllocator.invokeCradle(any())).thenReturn(new CradleResponse());
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        when(redisHelper.getMyOfferDataFromRedis()).thenReturn(Mono.just(offer));
        when(bpmHelper.addDevice(any(), any())).thenReturn(Mono.just(responseServiceMono));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        when(redisHelper.getMtnToPlanIdMap()).thenReturn(Mono.just(""));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just(""));
        when(redisHelper2.getRole()).thenReturn(Mono.just(""));
        when(redisHelper2.getEdgeBuyoutRedisData()).thenReturn(Mono.just(new HashMap()));
        when(redisHelper2.updateDeviceCartCount(any(), any())).thenReturn(Mono.just(true));
        when((redisHelper2.updateBByOrderDetails(any(),any()))).thenReturn(Mono.just(true));
        when(redisHelper2.updateCartOrderFlowType(any())).thenReturn(Mono.just(true));
        when(redisHelper.upsertOneClickCheckoutFlag(Mockito.anyString())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(cxpHelper.getDeviceCartMap(any())).thenReturn(Mono.empty());
        Map<String, String> cartMap = new HashMap<>();
        cartMap.put("deviceCount", "2");
        when(redisHelper2.getDeviceCartMap()).thenReturn(Mono.just(cartMap));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just(""));
        when(redisHelper3.getHashCodeMtn(any())).thenReturn(Mono.just(""));
        when(preHandleAddDevice.execute(UIRequest, sampleRedisData)).thenReturn(Mono.just(Boolean.TRUE));
        String outPut = "{\n" +
                "  \"throttleList\": \"|ComboOrderRetail|\"\n" +
                "}";
        final var cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(outPut);
        UIRequest.setChannelId(CartConstants.RETAIL);
        Mockito.when(cradleAllocator.invokeReactiveCradle(any(ServerHttpRequest.class),
                        any(ServerHttpResponse.class), anyMap()))
                .thenReturn(Mono.just(cradleResponse));
        when(accDevHelper1.invokeCradleForComboExistingCustomer(UIRequest))
                .thenReturn(Mono.just(cradleResponse));
        Mono<Boolean> checkCradleResp = accDevHelper1.checkCradleResponseForComboOrderExistingCustomer(UIRequest);
        Mono<AddDeviceUIResponse> response = accDevHelper.addDevice(UIRequest,httpResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addDeviceHelperTestCombo5() throws IOException, SOEHTTPException {
        String sampleRequestString = "{\"channelId\": \"OMNI-RETAIL-TAB\",\"cartInfo\": {\"mtnFlow\": \"M\",\"processStep\": \"promo\",\"authorizedUser\": null,\"cartCreator\": \"\",\"clientAppName\": \"VZW-ECOM\",\"editDevice\": false,\"cartId\": \"cart\",\"caseId\": \"case\",\"processingMTN\": \"\",\"accountNumber\": \"0280106868-00001\",\"intendType\": \"EUP\"},\"data\": {\"externalId\": \"id\",\"newLineOrAAL\": false,\"lines\": [{},{\"mtn\": \"mtn\"}]}}";
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-RETAIL-TAB\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        AddDeviceUIResponse responseServiceMono = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        String redisDataString = "{\"deviceId\": \"device\", \"cartId\": \"\",\"verifiedName\":\" name 1 2\", \"caseId\": \"\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"\",\"creditAppNum\":\"54453277834\", \"accountNumber\": \"\", \"mtn\": \"8436667390\",\"fiosAuthenticated\":true}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setLocationCode("P333201");
        sampleRedisData.setLoggedInUser("tabmgr");
        String offerString = "{\"isMyOfferAccepted\": true,\"restricted\": \"Y\",\"rtdOfferId\": \"PR_602\",\"restrictedProductType\": \"EQP\"}";
        MyOfferRedisData offer = mapper.readValue(offerString, MyOfferRedisData.class);
        String etrString = "{\"cartId\": \"\",\"atenaSessionId\": \"\",\"lines\": [{\"mtn\": \"5079937563\",\"offers\": [{\"complianceType\": \"ACC\",\"sku\": \"200350\",\"description\": \"UAT_73 SL: Get 50% off of Any Phone Case\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_73\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"},{\"complianceType\": \"EQP\",\"sku\": \"202617\",\"description\": \"Get $300 Recurring BIC on Smartphone Upgrade (Multi Line)\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"EA\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_85\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"}]}]}";
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        String nbxString = "{\"service\": {\"serviceHeader\": {\"clientId\": \"NETACE\",\"clientTransactionId\": \"NETACE-28023137-TXN\",\"clientSessionId\": \"NETACE-32a6993a-SESSION\",\"timestamp\": \"2020-05-06 07:50:30 GMT\",\"serviceName\": \"NBX\"},\"serviceBody\": {\"serviceRequest\": {\"contextInfo\": {\"callReason\": \"Recommendation\",\"category\": \"Offers\",\"subServiceName\": \"CaptureResponse\",\"sessionId\": \"-2233353673817713409\",\"rtdSessionID\": \"\"},\"customerInfo\": {\"mtn\": \"7573285016\",\"accountNo\": \"0420914396-00001\"},\"customerResponse\": {\"responseList\": [{\"rank\": \"1\",\"propositionId\": \"RO_01\",\"dispositionOptionId\": \"82\",\"soiEngagementId\": \"501002648\",\"timeStamp\": \"2020-05-06 07:50:30 GMT\",\"dynamicAttrList\": [{\"attrId\": \"skuid\",\"value\": \"MWAR2LL/A\"},{\"attrId\": \"Offer\",\"value\": \"RS_131\"}]}],\"externalResponseList\": [{\"rank\": null,\"propositionId\": \"RS_131\",\"dispositionOptionId\": \"82\",\"dynamicAttrList\": [{\"attrId\": \"isRtdOffer\",\"value\": \"N\"}],\"externalId\": null}]}}}}}";
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = "{\"lines\": [{\"mtn\": \"5079937563\",\"getBestValuePromotions\": {  \"clientId\": \"NETACE\",  \"sessionId\": \"4352144075584082252\",  \"rtdSessionId\": \"NBA-85771580-SQA1\",  \"clientSessionId\": \"0\",  \"clientTransactionId\": \"\",  \"bestValueOffers\": [{  \"id\": \"203040\",  \"rank\": \"1\",  \"dispositionOptionId\": null,  \"myOffer\": true,  \"verizonUp\": false,  \"barcode\": null,  \"myOfferAccepted\": false,  \"verizonUpAccepted\": false,  \"name\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"description\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"redemptionIds\": null,  \"contractTypes\": [\"2YR\",\"FR\",\"DPP\"  ],  \"compatiblePlanIds\": [\"36571\",\"36569\",\"36565\",\"36496\",\"36310\",\"36184\"  ],  \"deviceSku\": \"SMN976VZWV\"}  ],  \"totalDeviceDollarsBalance\": \"0.0\",  \"deviceDollarDisplayName\": \"\",  \"isVerizonUpAvailable\": false,  \"isDeviceDollarManuallyAccepted\": false,  \"rank\": \"1\",  \"propositionId\": \"RO_01\",  \"dispositionId\": \"10\",  \"soiEngagementId\": \"501002648\"}}]}";
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        String ineligibleData = "[{\"mtn\":\"7169849755\", \"reason\":\"Crisis\"}]";
        when(featureFlagHelper.fetchD2DFeatureFlag()).thenReturn(Mono.just(true));
        when(featureFlagHelper.trade3POChoiceOfferFFlag()).thenReturn(Boolean.TRUE);
        List<InEligibleLinesRedisData> ieData = mapper.readValue(ineligibleData, new TypeReference<List<InEligibleLinesRedisData>>(){});
        when(redisHelper.getInEligibleUpgradeLinesFromRedis()).thenReturn(Mono.just(ieData));
        FiveGAddressRedisData fiveGAddress = mapper.readValue("{\"cartId\": \"448f5443-5564-4f10-bd18-c2620b0c317b\"}", FiveGAddressRedisData.class);
        when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(fiveGAddress));
        String vcResStr = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
        ValidateCartUIResponse sampleResponse = mapper.readValue(vcResStr, ValidateCartUIResponse.class);
        ServerHttpResponse httpResponse = Mockito.mock(ServerHttpResponse.class);
        when(cxpHelper.validateCart(any(),any())).thenReturn(Mono.just(sampleResponse));
        when(cradleAllocator.invokeCradle(any())).thenReturn(new CradleResponse());
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        when(redisHelper.getMyOfferDataFromRedis()).thenReturn(Mono.just(offer));
        when(bpmHelper.addDevice(any(), any())).thenReturn(Mono.just(responseServiceMono));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        when(redisHelper.getMtnToPlanIdMap()).thenReturn(Mono.just(""));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just(""));
        when(redisHelper2.getRole()).thenReturn(Mono.just(""));
        when(redisHelper2.getEdgeBuyoutRedisData()).thenReturn(Mono.just(new HashMap()));
        when(redisHelper2.updateDeviceCartCount(any(),any())).thenReturn(Mono.just(true));
        when(redisHelper2.updateCartOrderFlowType(any())).thenReturn(Mono.just(true));
        when(redisHelper.upsertOneClickCheckoutFlag(Mockito.anyString())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(cxpHelper.getDeviceCartMap(any())).thenReturn(Mono.empty());
        Map<String, String> cartMap = new HashMap<>();
        cartMap.put("deviceCount", "2");
        when(redisHelper2.getDeviceCartMap()).thenReturn(Mono.just(cartMap));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just(""));
        when(redisHelper3.getHashCodeMtn(any())).thenReturn(Mono.just(""));
        when(preHandleAddDevice.execute(UIRequest, sampleRedisData)).thenReturn(Mono.just(Boolean.TRUE));
        String outPut = "{\n" +
                "  \"throttleList\": \"|ComboOrderRetail|\"\n" +
                "}";
        UIRequest.setChannelId(CartConstants.RETAIL_IPAD);
        final var cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(outPut);
        UIRequest.setChannelId(CartConstants.RETAIL);
        Mockito.when(cradleAllocator.invokeReactiveCradle(any(ServerHttpRequest.class),
                        any(ServerHttpResponse.class), anyMap()))
                .thenReturn(Mono.just(cradleResponse));
        when(accDevHelper1.invokeCradleForComboExistingCustomer(UIRequest)).thenReturn(Mono.just(cradleResponse));
        Mono<Boolean> checkCradleResp = accDevHelper1.checkCradleResponseForComboOrderExistingCustomer(UIRequest);
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(cradleResponse));
        Mono<AddDeviceUIResponse> response = accDevHelper.addDevice(UIRequest,httpResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

    }
    @Test
    public void updateSubFLowTagging_Subflow_no_ServiceBody() throws JsonProcessingException {
        String requestString = "{\"cartInfo\": {\"reqfrompromopdp\": true},\"data\": {\"lines\": [{\"device\": {\"category\": \"\"}}]}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse pegaResponse  = new  AddDeviceUIResponse();
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":null}";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC|nxtgen"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<Boolean> res= accDevHelper1.updateSubFlowInTaggingForNextgen(cdlThrottlist ,response, request);
        StepVerifier.create(res).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateSubFLowTagging_Subflow_no_ServiceResponse() throws JsonProcessingException {
        String requestString = "{\"cartInfo\": {\"reqfrompromopdp\": true},\"data\": {\"lines\": [{\"device\": {\"category\": \"\"}}]}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse pegaResponse  = new  AddDeviceUIResponse();
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":null}}";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC|nxtgen"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<Boolean> res= accDevHelper1.updateSubFlowInTaggingForNextgen(cdlThrottlist, response, request);
        StepVerifier.create(res).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateSubFLowTagging_Subflow_no_ServiceResponse_Context() throws JsonProcessingException {
        String requestString = "{\"cartInfo\": {\"reqfrompromopdp\": true},\"data\": {\"lines\": [{\"device\": {\"category\": \"\"}}]}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse pegaResponse  = new  AddDeviceUIResponse();
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":null}}}";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC|nxtgen"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<Boolean> res= accDevHelper1.updateSubFlowInTaggingForNextgen(cdlThrottlist, response, request);
        StepVerifier.create(res).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateSubFLowTagging_Subflow_no_ServiceResponse_ContextInfo() throws JsonProcessingException {
        String requestString = "{\"cartInfo\": {\"reqfrompromopdp\": true},\"data\": {\"lines\": [{\"device\": {\"category\": \"\"}}]}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse pegaResponse  = new  AddDeviceUIResponse();
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1858878952-E01\",\"contextInfo\":null,\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\"},\"cartInfo\":{\"financeLimitExceeded\":\"true\",\"cartItemCount\":1,\"totalDueToday\":54.25,\"totalDueMonthly\":0.0,\"cartId\":\"a144d317-de87-468e-88ee-a5e223fdf152\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":19.59,\"monthlyInstallment\":19.44,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MLA23LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"699.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 13\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC|nxtgen"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<Boolean> res= accDevHelper1.updateSubFlowInTaggingForNextgen(cdlThrottlist, response, request);
        StepVerifier.create(res).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
    }
    @Test
    public void updateSubFLowTagging_Subflow_no_ServiceResponse_ContextInfo_CradleFlowJourney() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"reqfrompromopdp\":true,\"intendType\":\"NSE\"},\"data\":{\"lines\":[{\"device\":{\"category\":\"\"}}]}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse pegaResponse  = new  AddDeviceUIResponse();
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1858878952-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryInterestial\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryInterestial\",\"processAction\":\"\",\"cradleFlowJourney\":null},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\"},\"cartInfo\":{\"financeLimitExceeded\":\"true\",\"cartItemCount\":1,\"totalDueToday\":54.25,\"totalDueMonthly\":0.0,\"cartId\":\"a144d317-de87-468e-88ee-a5e223fdf152\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":19.59,\"monthlyInstallment\":19.44,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MLA23LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"699.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 13\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC|nxtgen"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<Boolean> res= accDevHelper1.updateSubFlowInTaggingForNextgen(cdlThrottlist,response, request);
        StepVerifier.create(res).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
    }
    @Test
    public void updateSubFLowTagging_Subflow_no_ServiceBodybyod() throws JsonProcessingException {
        String requestString = "{\"cartInfo\": {\"reqfrompromopdp\": true},\"data\": {\"lines\": [{\"device\": {\"category\": \"\"}}]}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse pegaResponse  = new  AddDeviceUIResponse();
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":null}";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("Nxtgen-BYOD-Treat"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<Boolean> res= accDevHelper1.updateSubFlowInTaggingForNextgen(cdlThrottlist, response, request);
        StepVerifier.create(res).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateSubFLowTagging_Subflow_no_ServiceResponsebyod() throws JsonProcessingException {
        String requestString = "{\"cartInfo\": {\"reqfrompromopdp\": true},\"data\": {\"lines\": [{\"device\": {\"category\": \"\"}}]}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse pegaResponse  = new  AddDeviceUIResponse();
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":null}}";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("Nxtgen-BYOD-Treat"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<Boolean> res= accDevHelper1.updateSubFlowInTaggingForNextgen(cdlThrottlist ,response, request);
        StepVerifier.create(res).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateSubFLowTagging_Subflow_no_ServiceResponse_Context_byod() throws JsonProcessingException {
        String requestString = "{\"cartInfo\": {\"reqfrompromopdp\": true},\"data\": {\"lines\": [{\"device\": {\"category\": \"\"}}]}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse pegaResponse  = new  AddDeviceUIResponse();
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":null}}}";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("Nxtgen-BYOD-Treat"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<Boolean> res= accDevHelper1.updateSubFlowInTaggingForNextgen(cdlThrottlist , response, request);
        StepVerifier.create(res).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateSubFLowTagging_Subflow_no_ServiceResponse_ContextInfobyod() throws JsonProcessingException {
        String requestString = "{\"cartInfo\": {\"reqfrompromopdp\": true},\"data\": {\"lines\": [{\"device\": {\"category\": \"\"}}]}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse pegaResponse  = new  AddDeviceUIResponse();
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1858878952-E01\",\"contextInfo\":null,\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\"},\"cartInfo\":{\"financeLimitExceeded\":\"true\",\"cartItemCount\":1,\"totalDueToday\":54.25,\"totalDueMonthly\":0.0,\"cartId\":\"a144d317-de87-468e-88ee-a5e223fdf152\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":19.59,\"monthlyInstallment\":19.44,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MLA23LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"699.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 13\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("Nxtgen-BYOD-Treat"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<Boolean> res= accDevHelper1.updateSubFlowInTaggingForNextgen(cdlThrottlist, response, request);
        StepVerifier.create(res).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete().verify();
    }
    @Test
    public void updateSubFLowTagging_Subflow_no_ServiceResponse_ContextInfo_CradleFlowJourneybyod() throws JsonProcessingException {
        String requestString = "{\"cartInfo\": {\"reqfrompromopdp\": true},\"data\": {\"lines\": [{\"device\": {\"category\": \"\"}}]}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse pegaResponse  = new  AddDeviceUIResponse();
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1858878952-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryInterestial\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryInterestial\",\"processAction\":\"\",\"cradleFlowJourney\":null},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\"},\"cartInfo\":{\"financeLimitExceeded\":\"true\",\"cartItemCount\":1,\"totalDueToday\":54.25,\"totalDueMonthly\":0.0,\"cartId\":\"a144d317-de87-468e-88ee-a5e223fdf152\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":19.59,\"monthlyInstallment\":19.44,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MLA23LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"699.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 13\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("Nxtgen-BYOD-Treat"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<Boolean> res= accDevHelper1.updateSubFlowInTaggingForNextgen(cdlThrottlist,response, request);
        StepVerifier.create(res).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceHelperTestCombo7() throws IOException, SOEHTTPException {
        String sampleRequestString = "{\"channelId\": \"OMNI-CARE\",\"cartInfo\": {\"mtnFlow\": \"M\",\"processStep\": \"promo\",\"authorizedUser\": null,\"cartCreator\": \"\",\"clientAppName\": \"VZW-ECOM\",\"editDevice\": false,\"cartId\": \"cart\",\"caseId\": \"case\",\"processingMTN\": \"\",\"accountNumber\": \"0280106868-00001\",\"intendType\": \"BYOD\"},\"data\": {\"externalId\": \"id\",\"newLineOrAAL\": false,\"lines\": [{},{\"mtn\": \"mtn\"}]}}";
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-CARE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        AddDeviceUIResponse responseServiceMono = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        String redisDataString = "{\"deviceId\": \"device\", \"cartId\": \"\",\"verifiedName\":\" name 1 2\", \"caseId\": \"\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"\",\"creditAppNum\":\"54453277834\", \"accountNumber\": \"\", \"mtn\": \"8436667390\",\"fiosAuthenticated\":true}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setLocationCode("P333201");
        sampleRedisData.setLoggedInUser("tabmgr");
        String offerString = "{\"isMyOfferAccepted\": true,\"restricted\": \"Y\",\"rtdOfferId\": \"PR_602\",\"restrictedProductType\": \"EQP\"}";
        MyOfferRedisData offer = mapper.readValue(offerString, MyOfferRedisData.class);
        String etrString = "{\"cartId\": \"\",\"atenaSessionId\": \"\",\"lines\": [{\"mtn\": \"5079937563\",\"offers\": [{\"complianceType\": \"ACC\",\"sku\": \"200350\",\"description\": \"UAT_73 SL: Get 50% off of Any Phone Case\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_73\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"},{\"complianceType\": \"EQP\",\"sku\": \"202617\",\"description\": \"Get $300 Recurring BIC on Smartphone Upgrade (Multi Line)\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"EA\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_85\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"}]}]}";
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        String nbxString = "{\"service\": {\"serviceHeader\": {\"clientId\": \"NETACE\",\"clientTransactionId\": \"NETACE-28023137-TXN\",\"clientSessionId\": \"NETACE-32a6993a-SESSION\",\"timestamp\": \"2020-05-06 07:50:30 GMT\",\"serviceName\": \"NBX\"},\"serviceBody\": {\"serviceRequest\": {\"contextInfo\": {\"callReason\": \"Recommendation\",\"category\": \"Offers\",\"subServiceName\": \"CaptureResponse\",\"sessionId\": \"-2233353673817713409\",\"rtdSessionID\": \"\"},\"customerInfo\": {\"mtn\": \"7573285016\",\"accountNo\": \"0420914396-00001\"},\"customerResponse\": {\"responseList\": [{\"rank\": \"1\",\"propositionId\": \"RO_01\",\"dispositionOptionId\": \"82\",\"soiEngagementId\": \"501002648\",\"timeStamp\": \"2020-05-06 07:50:30 GMT\",\"dynamicAttrList\": [{\"attrId\": \"skuid\",\"value\": \"MWAR2LL/A\"},{\"attrId\": \"Offer\",\"value\": \"RS_131\"}]}],\"externalResponseList\": [{\"rank\": null,\"propositionId\": \"RS_131\",\"dispositionOptionId\": \"82\",\"dynamicAttrList\": [{\"attrId\": \"isRtdOffer\",\"value\": \"N\"}],\"externalId\": null}]}}}}}";
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = "{\"lines\": [{\"mtn\": \"5079937563\",\"getBestValuePromotions\": {  \"clientId\": \"NETACE\",  \"sessionId\": \"4352144075584082252\",  \"rtdSessionId\": \"NBA-85771580-SQA1\",  \"clientSessionId\": \"0\",  \"clientTransactionId\": \"\",  \"bestValueOffers\": [{  \"id\": \"203040\",  \"rank\": \"1\",  \"dispositionOptionId\": null,  \"myOffer\": true,  \"verizonUp\": false,  \"barcode\": null,  \"myOfferAccepted\": false,  \"verizonUpAccepted\": false,  \"name\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"description\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"redemptionIds\": null,  \"contractTypes\": [\"2YR\",\"FR\",\"DPP\"  ],  \"compatiblePlanIds\": [\"36571\",\"36569\",\"36565\",\"36496\",\"36310\",\"36184\"  ],  \"deviceSku\": \"SMN976VZWV\"}  ],  \"totalDeviceDollarsBalance\": \"0.0\",  \"deviceDollarDisplayName\": \"\",  \"isVerizonUpAvailable\": false,  \"isDeviceDollarManuallyAccepted\": false,  \"rank\": \"1\",  \"propositionId\": \"RO_01\",  \"dispositionId\": \"10\",  \"soiEngagementId\": \"501002648\"}}]}";
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        String ineligibleData = "[{\"mtn\":\"7169849755\", \"reason\":\"Crisis\"}]";
        when(featureFlagHelper.fetchD2DFeatureFlag()).thenReturn(Mono.just(true));
        when(featureFlagHelper.trade3POChoiceOfferFFlag()).thenReturn(Boolean.TRUE);
        List<InEligibleLinesRedisData> ieData = mapper.readValue(ineligibleData, new TypeReference<List<InEligibleLinesRedisData>>(){});
        when(redisHelper.getInEligibleUpgradeLinesFromRedis()).thenReturn(Mono.just(ieData));
        FiveGAddressRedisData fiveGAddress = mapper.readValue("{\"cartId\": \"448f5443-5564-4f10-bd18-c2620b0c317b\"}", FiveGAddressRedisData.class);
        when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(fiveGAddress));
        String vcResStr = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
        ValidateCartUIResponse sampleResponse = mapper.readValue(vcResStr, ValidateCartUIResponse.class);
        ServerHttpResponse httpResponse = Mockito.mock(ServerHttpResponse.class);
        when(cxpHelper.validateCart(any(),any())).thenReturn(Mono.just(sampleResponse));
        when(cradleAllocator.invokeCradle(any())).thenReturn(new CradleResponse());
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        when(redisHelper.getMyOfferDataFromRedis()).thenReturn(Mono.just(offer));
        when(bpmHelper.addDevice(any(), any())).thenReturn(Mono.just(responseServiceMono));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        when(redisHelper.getMtnToPlanIdMap()).thenReturn(Mono.just(""));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just(""));
        when(redisHelper2.getRole()).thenReturn(Mono.just(""));
        when(redisHelper2.getEdgeBuyoutRedisData()).thenReturn(Mono.just(new HashMap()));
        when(redisHelper2.updateDeviceCartCount(any(),any())).thenReturn(Mono.just(true));
        when((redisHelper2.updateBByOrderDetails(any(),any()))).thenReturn(Mono.just(true));
        when(redisHelper2.updateCartOrderFlowType(any())).thenReturn(Mono.just(true));
        when(redisHelper.upsertOneClickCheckoutFlag(Mockito.anyString())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(cxpHelper.getDeviceCartMap(any())).thenReturn(Mono.empty());
        Map<String, String> cartMap = new HashMap<>();
        cartMap.put("deviceCount", "2");
        when(redisHelper2.getDeviceCartMap()).thenReturn(Mono.just(cartMap));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just(""));
        when(redisHelper3.getHashCodeMtn(any())).thenReturn(Mono.just(""));
        when(preHandleAddDevice.execute(UIRequest, sampleRedisData)).thenReturn(Mono.just(Boolean.TRUE));
        String outPut = "{\n" +
                "  \"throttleList\": \"|ComboOrderCare|\"\n" +
                "}";
        UIRequest.setChannelId(CartConstants.OMNI_CARE);
        final var cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(outPut);
        UIRequest.setChannelId(CartConstants.RETAIL);
        Mockito.when(cradleAllocator.invokeReactiveCradle(any(ServerHttpRequest.class),
                        any(ServerHttpResponse.class), anyMap()))
                .thenReturn(Mono.just(cradleResponse));
        when(accDevHelper1.invokeCradleForComboExistingCustomer(UIRequest)).thenReturn(Mono.just(cradleResponse));
        Mono<Boolean> checkCradleResp = accDevHelper1.checkCradleResponseForComboOrderExistingCustomer(UIRequest);
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(cradleResponse));
        Mono<AddDeviceUIResponse> response = accDevHelper.addDevice(UIRequest,httpResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addDeviceHelperTestCombo8() throws IOException, SOEHTTPException {
        String sampleRequestString = "{\"channelId\": \"OMNI-CARE\",\"cartInfo\": {\"mtnFlow\": \"M\",\"processStep\": \"promo\",\"authorizedUser\": null,\"cartCreator\": \"\",\"clientAppName\": \"VZW-ECOM\",\"editDevice\": false,\"cartId\": \"cart\",\"caseId\": \"case\",\"processingMTN\": \"\",\"accountNumber\": \"0280106868-00001\",\"intendType\": \"AAL_BYOD\"},\"data\": {\"externalId\": \"id\",\"newLineOrAAL\": false,\"lines\": [{},{\"mtn\": \"mtn\"}]}}";
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-CARE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        AddDeviceUIResponse responseServiceMono = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        String redisDataString = "{\"deviceId\": \"device\", \"cartId\": \"\",\"verifiedName\":\" name 1 2\", \"caseId\": \"\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"\",\"creditAppNum\":\"54453277834\", \"accountNumber\": \"\", \"mtn\": \"8436667390\",\"fiosAuthenticated\":true}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setLocationCode("P333201");
        sampleRedisData.setLoggedInUser("tabmgr");
        String offerString = "{\"isMyOfferAccepted\": true,\"restricted\": \"Y\",\"rtdOfferId\": \"PR_602\",\"restrictedProductType\": \"EQP\"}";
        MyOfferRedisData offer = mapper.readValue(offerString, MyOfferRedisData.class);
        String etrString = "{\"cartId\": \"\",\"atenaSessionId\": \"\",\"lines\": [{\"mtn\": \"5079937563\",\"offers\": [{\"complianceType\": \"ACC\",\"sku\": \"200350\",\"description\": \"UAT_73 SL: Get 50% off of Any Phone Case\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_73\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"},{\"complianceType\": \"EQP\",\"sku\": \"202617\",\"description\": \"Get $300 Recurring BIC on Smartphone Upgrade (Multi Line)\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"EA\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_85\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"}]}]}";
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        String nbxString = "{\"service\": {\"serviceHeader\": {\"clientId\": \"NETACE\",\"clientTransactionId\": \"NETACE-28023137-TXN\",\"clientSessionId\": \"NETACE-32a6993a-SESSION\",\"timestamp\": \"2020-05-06 07:50:30 GMT\",\"serviceName\": \"NBX\"},\"serviceBody\": {\"serviceRequest\": {\"contextInfo\": {\"callReason\": \"Recommendation\",\"category\": \"Offers\",\"subServiceName\": \"CaptureResponse\",\"sessionId\": \"-2233353673817713409\",\"rtdSessionID\": \"\"},\"customerInfo\": {\"mtn\": \"7573285016\",\"accountNo\": \"0420914396-00001\"},\"customerResponse\": {\"responseList\": [{\"rank\": \"1\",\"propositionId\": \"RO_01\",\"dispositionOptionId\": \"82\",\"soiEngagementId\": \"501002648\",\"timeStamp\": \"2020-05-06 07:50:30 GMT\",\"dynamicAttrList\": [{\"attrId\": \"skuid\",\"value\": \"MWAR2LL/A\"},{\"attrId\": \"Offer\",\"value\": \"RS_131\"}]}],\"externalResponseList\": [{\"rank\": null,\"propositionId\": \"RS_131\",\"dispositionOptionId\": \"82\",\"dynamicAttrList\": [{\"attrId\": \"isRtdOffer\",\"value\": \"N\"}],\"externalId\": null}]}}}}}";
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = "{\"lines\": [{\"mtn\": \"5079937563\",\"getBestValuePromotions\": {  \"clientId\": \"NETACE\",  \"sessionId\": \"4352144075584082252\",  \"rtdSessionId\": \"NBA-85771580-SQA1\",  \"clientSessionId\": \"0\",  \"clientTransactionId\": \"\",  \"bestValueOffers\": [{  \"id\": \"203040\",  \"rank\": \"1\",  \"dispositionOptionId\": null,  \"myOffer\": true,  \"verizonUp\": false,  \"barcode\": null,  \"myOfferAccepted\": false,  \"verizonUpAccepted\": false,  \"name\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"description\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"redemptionIds\": null,  \"contractTypes\": [\"2YR\",\"FR\",\"DPP\"  ],  \"compatiblePlanIds\": [\"36571\",\"36569\",\"36565\",\"36496\",\"36310\",\"36184\"  ],  \"deviceSku\": \"SMN976VZWV\"}  ],  \"totalDeviceDollarsBalance\": \"0.0\",  \"deviceDollarDisplayName\": \"\",  \"isVerizonUpAvailable\": false,  \"isDeviceDollarManuallyAccepted\": false,  \"rank\": \"1\",  \"propositionId\": \"RO_01\",  \"dispositionId\": \"10\",  \"soiEngagementId\": \"501002648\"}}]}";
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        String ineligibleData = "[{\"mtn\":\"7169849755\", \"reason\":\"Crisis\"}]";
        when(featureFlagHelper.fetchD2DFeatureFlag()).thenReturn(Mono.just(true));
        when(featureFlagHelper.trade3POChoiceOfferFFlag()).thenReturn(Boolean.TRUE);
        List<InEligibleLinesRedisData> ieData = mapper.readValue(ineligibleData, new TypeReference<List<InEligibleLinesRedisData>>(){});
        when(redisHelper.getInEligibleUpgradeLinesFromRedis()).thenReturn(Mono.just(ieData));
        FiveGAddressRedisData fiveGAddress = mapper.readValue("{\"cartId\": \"448f5443-5564-4f10-bd18-c2620b0c317b\"}", FiveGAddressRedisData.class);
        when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(fiveGAddress));
        String vcResStr = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
        ValidateCartUIResponse sampleResponse = mapper.readValue(vcResStr, ValidateCartUIResponse.class);
        ServerHttpResponse httpResponse = Mockito.mock(ServerHttpResponse.class);
        when(cxpHelper.validateCart(any(),any())).thenReturn(Mono.just(sampleResponse));
        when(cradleAllocator.invokeCradle(any())).thenReturn(new CradleResponse());
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        when(redisHelper.getMyOfferDataFromRedis()).thenReturn(Mono.just(offer));
        when(bpmHelper.addDevice(any(), any())).thenReturn(Mono.just(responseServiceMono));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        when(redisHelper.getMtnToPlanIdMap()).thenReturn(Mono.just(""));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just(""));
        when(redisHelper2.getRole()).thenReturn(Mono.just(""));
        when(redisHelper2.getEdgeBuyoutRedisData()).thenReturn(Mono.just(new HashMap()));
        when(redisHelper2.updateDeviceCartCount(any(),any())).thenReturn(Mono.just(true));
        when((redisHelper2.updateBByOrderDetails(any(),any()))).thenReturn(Mono.just(true));
        when(redisHelper2.updateCartOrderFlowType(any())).thenReturn(Mono.just(true));
        when(redisHelper.upsertOneClickCheckoutFlag(Mockito.anyString())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(cxpHelper.getDeviceCartMap(any())).thenReturn(Mono.empty());
        Map<String, String> cartMap = new HashMap<>();
        cartMap.put("deviceCount", "2");
        when(redisHelper2.getDeviceCartMap()).thenReturn(Mono.just(cartMap));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just(""));
        when(redisHelper3.getHashCodeMtn(any())).thenReturn(Mono.just(""));
        when(preHandleAddDevice.execute(UIRequest, sampleRedisData)).thenReturn(Mono.just(Boolean.TRUE));
        String outPut = "{\n" +
                "  \"throttleList\": \"|ComboOrderCare|\"\n" +
                "}";
        UIRequest.setChannelId(CartConstants.OMNI_CARE);
        final var cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(outPut);
        UIRequest.setChannelId(CartConstants.RETAIL);
        Mockito.when(cradleAllocator.invokeReactiveCradle(any(ServerHttpRequest.class),
                        any(ServerHttpResponse.class), anyMap()))
                .thenReturn(Mono.just(cradleResponse));
        when(accDevHelper1.invokeCradleForComboExistingCustomer(UIRequest)).thenReturn(Mono.just(cradleResponse));
        Mono<Boolean> checkCradleResp = accDevHelper1.checkCradleResponseForComboOrderExistingCustomer(UIRequest);
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(cradleResponse));
        Mono<AddDeviceUIResponse> response = accDevHelper.addDevice(UIRequest,httpResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addDeviceHelperTestCombo_CHATSTORE() throws IOException, SOEHTTPException {
        String sampleRequestString = "{\"channelId\": \"CHAT-STORE\",\"cartInfo\": {\"mtnFlow\": \"M\",\"processStep\": \"promo\",\"authorizedUser\": null,\"cartCreator\": \"\",\"clientAppName\": \"VZW-ECOM\",\"editDevice\": false,\"cartId\": \"cart\",\"caseId\": \"case\",\"processingMTN\": \"\",\"accountNumber\": \"0280106868-00001\",\"intendType\": \"AAL_BYOD\"},\"data\": {\"externalId\": \"id\",\"newLineOrAAL\": false,\"lines\": [{},{\"mtn\": \"mtn\"}]}}";
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"CHAT-STORE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        AddDeviceUIResponse responseServiceMono = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        String redisDataString = "{\"deviceId\": \"device\", \"cartId\": \"\",\"verifiedName\":\" name 1 2\", \"caseId\": \"\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"\",\"creditAppNum\":\"54453277834\", \"accountNumber\": \"\", \"mtn\": \"8436667390\",\"fiosAuthenticated\":true}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setLocationCode("P333201");
        sampleRedisData.setLoggedInUser("tabmgr");
        String offerString = "{\"isMyOfferAccepted\": true,\"restricted\": \"Y\",\"rtdOfferId\": \"PR_602\",\"restrictedProductType\": \"EQP\"}";
        MyOfferRedisData offer = mapper.readValue(offerString, MyOfferRedisData.class);
        String etrString = "{\"cartId\": \"\",\"atenaSessionId\": \"\",\"lines\": [{\"mtn\": \"5079937563\",\"offers\": [{\"complianceType\": \"ACC\",\"sku\": \"200350\",\"description\": \"UAT_73 SL: Get 50% off of Any Phone Case\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_73\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"},{\"complianceType\": \"EQP\",\"sku\": \"202617\",\"description\": \"Get $300 Recurring BIC on Smartphone Upgrade (Multi Line)\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"EA\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_85\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"}]}]}";
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        String nbxString = "{\"service\": {\"serviceHeader\": {\"clientId\": \"NETACE\",\"clientTransactionId\": \"NETACE-28023137-TXN\",\"clientSessionId\": \"NETACE-32a6993a-SESSION\",\"timestamp\": \"2020-05-06 07:50:30 GMT\",\"serviceName\": \"NBX\"},\"serviceBody\": {\"serviceRequest\": {\"contextInfo\": {\"callReason\": \"Recommendation\",\"category\": \"Offers\",\"subServiceName\": \"CaptureResponse\",\"sessionId\": \"-2233353673817713409\",\"rtdSessionID\": \"\"},\"customerInfo\": {\"mtn\": \"7573285016\",\"accountNo\": \"0420914396-00001\"},\"customerResponse\": {\"responseList\": [{\"rank\": \"1\",\"propositionId\": \"RO_01\",\"dispositionOptionId\": \"82\",\"soiEngagementId\": \"501002648\",\"timeStamp\": \"2020-05-06 07:50:30 GMT\",\"dynamicAttrList\": [{\"attrId\": \"skuid\",\"value\": \"MWAR2LL/A\"},{\"attrId\": \"Offer\",\"value\": \"RS_131\"}]}],\"externalResponseList\": [{\"rank\": null,\"propositionId\": \"RS_131\",\"dispositionOptionId\": \"82\",\"dynamicAttrList\": [{\"attrId\": \"isRtdOffer\",\"value\": \"N\"}],\"externalId\": null}]}}}}}";
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = "{\"lines\": [{\"mtn\": \"5079937563\",\"getBestValuePromotions\": {  \"clientId\": \"NETACE\",  \"sessionId\": \"4352144075584082252\",  \"rtdSessionId\": \"NBA-85771580-SQA1\",  \"clientSessionId\": \"0\",  \"clientTransactionId\": \"\",  \"bestValueOffers\": [{  \"id\": \"203040\",  \"rank\": \"1\",  \"dispositionOptionId\": null,  \"myOffer\": true,  \"verizonUp\": false,  \"barcode\": null,  \"myOfferAccepted\": false,  \"verizonUpAccepted\": false,  \"name\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"description\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"redemptionIds\": null,  \"contractTypes\": [\"2YR\",\"FR\",\"DPP\"  ],  \"compatiblePlanIds\": [\"36571\",\"36569\",\"36565\",\"36496\",\"36310\",\"36184\"  ],  \"deviceSku\": \"SMN976VZWV\"}  ],  \"totalDeviceDollarsBalance\": \"0.0\",  \"deviceDollarDisplayName\": \"\",  \"isVerizonUpAvailable\": false,  \"isDeviceDollarManuallyAccepted\": false,  \"rank\": \"1\",  \"propositionId\": \"RO_01\",  \"dispositionId\": \"10\",  \"soiEngagementId\": \"501002648\"}}]}";
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        String ineligibleData = "[{\"mtn\":\"7169849755\", \"reason\":\"Crisis\"}]";
        when(featureFlagHelper.fetchD2DFeatureFlag()).thenReturn(Mono.just(true));
        when(featureFlagHelper.trade3POChoiceOfferFFlag()).thenReturn(Boolean.TRUE);
        List<InEligibleLinesRedisData> ieData = mapper.readValue(ineligibleData, new TypeReference<List<InEligibleLinesRedisData>>(){});
        when(redisHelper.getInEligibleUpgradeLinesFromRedis()).thenReturn(Mono.just(ieData));
        FiveGAddressRedisData fiveGAddress = mapper.readValue("{\"cartId\": \"448f5443-5564-4f10-bd18-c2620b0c317b\"}", FiveGAddressRedisData.class);
        when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(fiveGAddress));
        String vcResStr = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
        ValidateCartUIResponse sampleResponse = mapper.readValue(vcResStr, ValidateCartUIResponse.class);
        ServerHttpResponse httpResponse = Mockito.mock(ServerHttpResponse.class);
        when(cxpHelper.validateCart(any(),any())).thenReturn(Mono.just(sampleResponse));
        when(cradleAllocator.invokeCradle(any())).thenReturn(new CradleResponse());
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        when(redisHelper.getMyOfferDataFromRedis()).thenReturn(Mono.just(offer));
        when(bpmHelper.addDevice(any(), any())).thenReturn(Mono.just(responseServiceMono));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        when(redisHelper.getMtnToPlanIdMap()).thenReturn(Mono.just(""));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just(""));
        when(redisHelper2.getRole()).thenReturn(Mono.just(""));
        when(redisHelper2.getEdgeBuyoutRedisData()).thenReturn(Mono.just(new HashMap()));
        when(redisHelper2.updateDeviceCartCount(any(),any())).thenReturn(Mono.just(true));
        when((redisHelper2.updateBByOrderDetails(any(),any()))).thenReturn(Mono.just(true));
        when(redisHelper2.updateCartOrderFlowType(any())).thenReturn(Mono.just(true));
        when(redisHelper.upsertOneClickCheckoutFlag(Mockito.anyString())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(cxpHelper.getDeviceCartMap(any())).thenReturn(Mono.empty());
        Map<String, String> cartMap = new HashMap<>();
        cartMap.put("deviceCount", "2");
        when(redisHelper2.getDeviceCartMap()).thenReturn(Mono.just(cartMap));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just(""));
        when(redisHelper3.getHashCodeMtn(any())).thenReturn(Mono.just(""));
        when(preHandleAddDevice.execute(UIRequest, sampleRedisData)).thenReturn(Mono.just(Boolean.TRUE));
        String outPut = "{\n" +
                "  \"throttleList\": \"|ComboOrderChatStore|\"\n" +
                "}";
        UIRequest.setChannelId(CartConstants.CHAT_STORE);
        final var cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(outPut);
        UIRequest.setChannelId(CartConstants.CHAT_STORE);
        Mockito.when(cradleAllocator.invokeReactiveCradle(any(ServerHttpRequest.class),
                        any(ServerHttpResponse.class), anyMap()))
                .thenReturn(Mono.just(cradleResponse));
        when(accDevHelper1.invokeCradleForComboExistingCustomer(UIRequest)).thenReturn(Mono.just(cradleResponse));
        Mono<Boolean> checkCradleResp = accDevHelper1.checkCradleResponseForComboOrderExistingCustomer(UIRequest);
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(cradleResponse));
        Mono<AddDeviceUIResponse> response = accDevHelper.addDevice(UIRequest,httpResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addDeviceHelperTestCombo_INDIRECT() throws IOException, SOEHTTPException {
        String sampleRequestString = "{\"channelId\": \"OMNI-INDIRECT\",\"cartInfo\": {\"mtnFlow\": \"M\",\"processStep\": \"promo\",\"authorizedUser\": null,\"cartCreator\": \"\",\"clientAppName\": \"VZW-ECOM\",\"editDevice\": false,\"cartId\": \"cart\",\"caseId\": \"case\",\"processingMTN\": \"\",\"accountNumber\": \"0280106868-00001\",\"intendType\": \"AAL_BYOD\"},\"data\": {\"externalId\": \"id\",\"newLineOrAAL\": false,\"lines\": [{},{\"mtn\": \"mtn\"}]}}";
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-INDIRECT\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        AddDeviceUIResponse responseServiceMono = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        String redisDataString = "{\"deviceId\": \"device\", \"cartId\": \"\",\"verifiedName\":\" name 1 2\", \"caseId\": \"\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"\",\"creditAppNum\":\"54453277834\", \"accountNumber\": \"\", \"mtn\": \"8436667390\",\"fiosAuthenticated\":true}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setLocationCode("P333201");
        sampleRedisData.setLoggedInUser("tabmgr");
        String offerString = "{\"isMyOfferAccepted\": true,\"restricted\": \"Y\",\"rtdOfferId\": \"PR_602\",\"restrictedProductType\": \"EQP\"}";
        MyOfferRedisData offer = mapper.readValue(offerString, MyOfferRedisData.class);
        String etrString = "{\"cartId\": \"\",\"atenaSessionId\": \"\",\"lines\": [{\"mtn\": \"5079937563\",\"offers\": [{\"complianceType\": \"ACC\",\"sku\": \"200350\",\"description\": \"UAT_73 SL: Get 50% off of Any Phone Case\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_73\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"},{\"complianceType\": \"EQP\",\"sku\": \"202617\",\"description\": \"Get $300 Recurring BIC on Smartphone Upgrade (Multi Line)\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"EA\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_85\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"}]}]}";
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        String nbxString = "{\"service\": {\"serviceHeader\": {\"clientId\": \"NETACE\",\"clientTransactionId\": \"NETACE-28023137-TXN\",\"clientSessionId\": \"NETACE-32a6993a-SESSION\",\"timestamp\": \"2020-05-06 07:50:30 GMT\",\"serviceName\": \"NBX\"},\"serviceBody\": {\"serviceRequest\": {\"contextInfo\": {\"callReason\": \"Recommendation\",\"category\": \"Offers\",\"subServiceName\": \"CaptureResponse\",\"sessionId\": \"-2233353673817713409\",\"rtdSessionID\": \"\"},\"customerInfo\": {\"mtn\": \"7573285016\",\"accountNo\": \"0420914396-00001\"},\"customerResponse\": {\"responseList\": [{\"rank\": \"1\",\"propositionId\": \"RO_01\",\"dispositionOptionId\": \"82\",\"soiEngagementId\": \"501002648\",\"timeStamp\": \"2020-05-06 07:50:30 GMT\",\"dynamicAttrList\": [{\"attrId\": \"skuid\",\"value\": \"MWAR2LL/A\"},{\"attrId\": \"Offer\",\"value\": \"RS_131\"}]}],\"externalResponseList\": [{\"rank\": null,\"propositionId\": \"RS_131\",\"dispositionOptionId\": \"82\",\"dynamicAttrList\": [{\"attrId\": \"isRtdOffer\",\"value\": \"N\"}],\"externalId\": null}]}}}}}";
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = "{\"lines\": [{\"mtn\": \"5079937563\",\"getBestValuePromotions\": {  \"clientId\": \"NETACE\",  \"sessionId\": \"4352144075584082252\",  \"rtdSessionId\": \"NBA-85771580-SQA1\",  \"clientSessionId\": \"0\",  \"clientTransactionId\": \"\",  \"bestValueOffers\": [{  \"id\": \"203040\",  \"rank\": \"1\",  \"dispositionOptionId\": null,  \"myOffer\": true,  \"verizonUp\": false,  \"barcode\": null,  \"myOfferAccepted\": false,  \"verizonUpAccepted\": false,  \"name\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"description\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"redemptionIds\": null,  \"contractTypes\": [\"2YR\",\"FR\",\"DPP\"  ],  \"compatiblePlanIds\": [\"36571\",\"36569\",\"36565\",\"36496\",\"36310\",\"36184\"  ],  \"deviceSku\": \"SMN976VZWV\"}  ],  \"totalDeviceDollarsBalance\": \"0.0\",  \"deviceDollarDisplayName\": \"\",  \"isVerizonUpAvailable\": false,  \"isDeviceDollarManuallyAccepted\": false,  \"rank\": \"1\",  \"propositionId\": \"RO_01\",  \"dispositionId\": \"10\",  \"soiEngagementId\": \"501002648\"}}]}";
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        String ineligibleData = "[{\"mtn\":\"7169849755\", \"reason\":\"Crisis\"}]";
        List<InEligibleLinesRedisData> ieData = mapper.readValue(ineligibleData, new TypeReference<List<InEligibleLinesRedisData>>(){});
        when(redisHelper.getInEligibleUpgradeLinesFromRedis()).thenReturn(Mono.just(ieData));
        FiveGAddressRedisData fiveGAddress = mapper.readValue("{\"cartId\": \"448f5443-5564-4f10-bd18-c2620b0c317b\"}", FiveGAddressRedisData.class);
        when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(fiveGAddress));
        String vcResStr = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
        ValidateCartUIResponse sampleResponse = mapper.readValue(vcResStr, ValidateCartUIResponse.class);
        ServerHttpResponse httpResponse = Mockito.mock(ServerHttpResponse.class);
        when(featureFlagHelper.fetchD2DFeatureFlag()).thenReturn(Mono.just(true));
        when(featureFlagHelper.trade3POChoiceOfferFFlag()).thenReturn(Boolean.TRUE);
        when(cxpHelper.validateCart(any(),any())).thenReturn(Mono.just(sampleResponse));
        when(cradleAllocator.invokeCradle(any())).thenReturn(new CradleResponse());
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        when(redisHelper.getMyOfferDataFromRedis()).thenReturn(Mono.just(offer));
        when(bpmHelper.addDevice(any(), any())).thenReturn(Mono.just(responseServiceMono));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        when(redisHelper.getMtnToPlanIdMap()).thenReturn(Mono.just(""));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just(""));
        when(redisHelper2.getRole()).thenReturn(Mono.just(""));
        when(redisHelper2.getEdgeBuyoutRedisData()).thenReturn(Mono.just(new HashMap()));
        when(redisHelper2.updateDeviceCartCount(any(),any())).thenReturn(Mono.just(true));
        when((redisHelper2.updateBByOrderDetails(any(),any()))).thenReturn(Mono.just(true));
        when(redisHelper2.updateCartOrderFlowType(any())).thenReturn(Mono.just(true));
        when(redisHelper.upsertOneClickCheckoutFlag(Mockito.anyString())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(cxpHelper.getDeviceCartMap(any())).thenReturn(Mono.empty());
        Map<String, String> cartMap = new HashMap<>();
        cartMap.put("deviceCount", "2");
        when(redisHelper2.getDeviceCartMap()).thenReturn(Mono.just(cartMap));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just(""));
        when(redisHelper3.getHashCodeMtn(any())).thenReturn(Mono.just(""));
        when(preHandleAddDevice.execute(UIRequest, sampleRedisData)).thenReturn(Mono.just(Boolean.TRUE));
        String outPut = "{\n" +
                "  \"throttleList\": \"|ComboOrderIndirect|\"\n" +
                "}";
        UIRequest.setChannelId(CartConstants.OMNI_INDIRECT);
        final var cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(outPut);
        UIRequest.setChannelId(CartConstants.OMNI_INDIRECT);
        Mockito.when(cradleAllocator.invokeReactiveCradle(any(ServerHttpRequest.class),
                        any(ServerHttpResponse.class), anyMap()))
                .thenReturn(Mono.just(cradleResponse));
        when(accDevHelper1.invokeCradleForComboExistingCustomer(UIRequest)).thenReturn(Mono.just(cradleResponse));
        Mono<Boolean> checkCradleResp = accDevHelper1.checkCradleResponseForComboOrderExistingCustomer(UIRequest);
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(cradleResponse));
        Mono<AddDeviceUIResponse> response = accDevHelper.addDevice(UIRequest,httpResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addDeviceHelperTestCombo_INDIRECT_TAB() throws IOException, SOEHTTPException {
        String sampleRequestString = "{\"channelId\": \"OMNI-INDIRECT-TAB\",\"cartInfo\": {\"mtnFlow\": \"M\",\"processStep\": \"promo\",\"authorizedUser\": null,\"cartCreator\": \"\",\"clientAppName\": \"VZW-ECOM\",\"editDevice\": false,\"cartId\": \"cart\",\"caseId\": \"case\",\"processingMTN\": \"\",\"accountNumber\": \"0280106868-00001\",\"intendType\": \"AAL_BYOD\"},\"data\": {\"externalId\": \"id\",\"newLineOrAAL\": false,\"lines\": [{},{\"mtn\": \"mtn\",\"highDecileIndicator\": \"P1\"}]}}";
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-INDIRECT-TAB\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        AddDeviceUIResponse responseServiceMono = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        String redisDataString = "{\"deviceId\": \"device\", \"cartId\": \"\",\"verifiedName\":\" name 1 2\", \"caseId\": \"\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"\",\"creditAppNum\":\"54453277834\", \"accountNumber\": \"\", \"mtn\": \"8436667390\",\"fiosAuthenticated\":true}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setLocationCode("P333201");
        sampleRedisData.setLoggedInUser("tabmgr");
        String offerString = "{\"isMyOfferAccepted\": true,\"restricted\": \"Y\",\"rtdOfferId\": \"PR_602\",\"restrictedProductType\": \"EQP\"}";
        MyOfferRedisData offer = mapper.readValue(offerString, MyOfferRedisData.class);
        String etrString = "{\"cartId\": \"\",\"atenaSessionId\": \"\",\"lines\": [{\"mtn\": \"5079937563\",\"offers\": [{\"complianceType\": \"ACC\",\"sku\": \"200350\",\"description\": \"UAT_73 SL: Get 50% off of Any Phone Case\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_73\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"},{\"complianceType\": \"EQP\",\"sku\": \"202617\",\"description\": \"Get $300 Recurring BIC on Smartphone Upgrade (Multi Line)\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"EA\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_85\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"}]}]}";
        MyOfferETRRedisData etrData = mapper.readValue(etrString, MyOfferETRRedisData.class);
        String nbxString = "{\"service\": {\"serviceHeader\": {\"clientId\": \"NETACE\",\"clientTransactionId\": \"NETACE-28023137-TXN\",\"clientSessionId\": \"NETACE-32a6993a-SESSION\",\"timestamp\": \"2020-05-06 07:50:30 GMT\",\"serviceName\": \"NBX\"},\"serviceBody\": {\"serviceRequest\": {\"contextInfo\": {\"callReason\": \"Recommendation\",\"category\": \"Offers\",\"subServiceName\": \"CaptureResponse\",\"sessionId\": \"-2233353673817713409\",\"rtdSessionID\": \"\"},\"customerInfo\": {\"mtn\": \"7573285016\",\"accountNo\": \"0420914396-00001\"},\"customerResponse\": {\"responseList\": [{\"rank\": \"1\",\"propositionId\": \"RO_01\",\"dispositionOptionId\": \"82\",\"soiEngagementId\": \"501002648\",\"timeStamp\": \"2020-05-06 07:50:30 GMT\",\"dynamicAttrList\": [{\"attrId\": \"skuid\",\"value\": \"MWAR2LL/A\"},{\"attrId\": \"Offer\",\"value\": \"RS_131\"}]}],\"externalResponseList\": [{\"rank\": null,\"propositionId\": \"RS_131\",\"dispositionOptionId\": \"82\",\"dynamicAttrList\": [{\"attrId\": \"isRtdOffer\",\"value\": \"N\"}],\"externalId\": null}]}}}}}";
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        when(nbxService.nbxFeedbackCall(any())).thenReturn(Mono.just(nbxRes));
        String bvpStr = "{\"lines\": [{\"mtn\": \"5079937563\",\"getBestValuePromotions\": {  \"clientId\": \"NETACE\",  \"sessionId\": \"4352144075584082252\",  \"rtdSessionId\": \"NBA-85771580-SQA1\",  \"clientSessionId\": \"0\",  \"clientTransactionId\": \"\",  \"bestValueOffers\": [{  \"id\": \"203040\",  \"rank\": \"1\",  \"dispositionOptionId\": null,  \"myOffer\": true,  \"verizonUp\": false,  \"barcode\": null,  \"myOfferAccepted\": false,  \"verizonUpAccepted\": false,  \"name\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"description\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"redemptionIds\": null,  \"contractTypes\": [\"2YR\",\"FR\",\"DPP\"  ],  \"compatiblePlanIds\": [\"36571\",\"36569\",\"36565\",\"36496\",\"36310\",\"36184\"  ],  \"deviceSku\": \"SMN976VZWV\"}  ],  \"totalDeviceDollarsBalance\": \"0.0\",  \"deviceDollarDisplayName\": \"\",  \"isVerizonUpAvailable\": false,  \"isDeviceDollarManuallyAccepted\": false,  \"rank\": \"1\",  \"propositionId\": \"RO_01\",  \"dispositionId\": \"10\",  \"soiEngagementId\": \"501002648\"}}]}";
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        String ineligibleData = "[{\"mtn\":\"7169849755\", \"reason\":\"Crisis\"}]";
        List<InEligibleLinesRedisData> ieData = mapper.readValue(ineligibleData, new TypeReference<List<InEligibleLinesRedisData>>(){});
        when(redisHelper.getInEligibleUpgradeLinesFromRedis()).thenReturn(Mono.just(ieData));
        FiveGAddressRedisData fiveGAddress = mapper.readValue("{\"cartId\": \"448f5443-5564-4f10-bd18-c2620b0c317b\"}", FiveGAddressRedisData.class);
        when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(fiveGAddress));
        String vcResStr = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
        ValidateCartUIResponse sampleResponse = mapper.readValue(vcResStr, ValidateCartUIResponse.class);
        ServerHttpResponse httpResponse = Mockito.mock(ServerHttpResponse.class);
        when(featureFlagHelper.fetchD2DFeatureFlag()).thenReturn(Mono.just(true));
        when(featureFlagHelper.trade3POChoiceOfferFFlag()).thenReturn(Boolean.TRUE);
        when(cxpHelper.validateCart(any(),any())).thenReturn(Mono.just(sampleResponse));
        when(cradleAllocator.invokeCradle(any())).thenReturn(new CradleResponse());
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        when(redisHelper.getMyOfferDataFromRedis()).thenReturn(Mono.just(offer));
        when(bpmHelper.addDevice(any(), any())).thenReturn(Mono.just(responseServiceMono));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(etrData));
        when(redisHelper.getMtnToPlanIdMap()).thenReturn(Mono.just(""));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just(""));
        when(redisHelper2.getRole()).thenReturn(Mono.just(""));
        when(redisHelper2.getEdgeBuyoutRedisData()).thenReturn(Mono.just(new HashMap()));
        when(redisHelper2.updateDeviceCartCount(any(),any())).thenReturn(Mono.just(true));
        when((redisHelper2.updateBByOrderDetails(any(),any()))).thenReturn(Mono.just(true));
        when(redisHelper2.updateCartOrderFlowType(any())).thenReturn(Mono.just(true));
        when(redisHelper.upsertOneClickCheckoutFlag(Mockito.anyString())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(cxpHelper.getDeviceCartMap(any())).thenReturn(Mono.empty());
        Map<String, String> cartMap = new HashMap<>();
        cartMap.put("deviceCount", "2");
        when(redisHelper2.getDeviceCartMap()).thenReturn(Mono.just(cartMap));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just(""));
        when(redisHelper3.getHashCodeMtn(any())).thenReturn(Mono.just(""));
        when(preHandleAddDevice.execute(UIRequest, sampleRedisData)).thenReturn(Mono.just(Boolean.TRUE));
        String outPut = "{\n" +
                "  \"throttleList\": \"|ComboOrderIndirect|\"\n" +
                "}";
        UIRequest.setChannelId(CartConstants.OMNI_INDIRECT_TAB);
        final var cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(outPut);
        UIRequest.setChannelId(CartConstants.OMNI_INDIRECT_TAB);
        Mockito.when(cradleAllocator.invokeReactiveCradle(any(ServerHttpRequest.class),
                        any(ServerHttpResponse.class), anyMap()))
                .thenReturn(Mono.just(cradleResponse));
        when(accDevHelper1.invokeCradleForComboExistingCustomer(UIRequest))
                .thenReturn(Mono.just(cradleResponse));
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(cradleResponse));
        Mono<Boolean> checkCradleResp = accDevHelper1.checkCradleResponseForComboOrderExistingCustomer(UIRequest);
        Mono<AddDeviceUIResponse> response = accDevHelper.addDevice(UIRequest,httpResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateDLDataForAssistedTest() {
        Vzdl vzdl = new Vzdl();
        vzdl.setProduct(new Product());
        vzdl.setTxn(new HashMap<>());
        vzdl.setPage(new Page());
        vzdl.setUser(new User());
        accDevHelper.updateDLDataForAssisted(vzdl);
        Mockito.verify(dlService, Mockito.times(1)).buildDLData(any());
    }

    @Test
    public void updateMtnInUiRequestTest() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"noPendingOfferExists\":false,\"isPromoPDP\":false,\"mtnFlow\":\"G\"},\"data\":{\"lines\":[{\"isCommonPDP\":true,\"mtn\":\"\",\"purchasePath\":\"EUP\",\"portInNumber\":\"\",\"eupNoPromoFlow\":false,\"device\":{\"id\":\"MTM23LL/A\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":true,\"dppMonths\":36,\"productId\":\"dev21410694\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"UNIVESIM5G-SAB-D\"},\"ispuFlow\":false,\"estimatedReadyByDate\":\"\",\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"newLineOrAAL\":false,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":false,\"isIconicPhone\":true,\"selectedSedOfferId\":\"\",\"selectedSpoId\":\"\",\"isStrategicOffer\":false,\"restricted\":\"\",\"isTradeInIntentSelected\":false}],\"rtm\":{\"url\":\"https://www.verizon.com/smartphones/apple-iphone-15/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-128gb-green-mtm23ll-a-a\",\"name\":\"iPhone 15\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://www.verizon.com/smartphones/apple-iphone-15/\"}}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"cradleFlowJourney\": \"NEXT_GEN\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<AddDeviceUIRequest> res= accDevHelper1.updateMtnInUiRequest(request,sampleRedisData);
        StepVerifier.create(res).assertNext( resp-> junit.framework.Assert.assertNotNull(resp)).expectComplete()
                .verify();

        String requestString1 = "{\"cartInfo\":{\"correlationId\":\"\",\"processStep\":\"GridWallPDP\",\"flowType\": \"FWA_UPGRADE\",\"cartCreator\":\"9858484858\",\"processingMTN\":\"9858484858\",\"processAction\":\"addDevice\",\"intendType\":\"EUP_5G\",\"number_share_capable\":\"\",\"creditAppNum\":null,\"isQuoteCart\":false,\"enableDefaultedShipToHome\":false,\"bogoEnabled\":\"\", \"isReturnRequired\": \"\"},\"data\":{\"lines\":[{\"multiLineSeqNumber\":\"1\",\"mtn\":\"9858484858\",\"purchasePath\":\"EUP_5G\",\"lineDeviceDollar\":0,\"upgradeReasonCode\":\"\",\"device\":{\"category\":\"\",\"deviceId\":\"\",\"id\":\"ASK-NCQ1338FA\",\"isNonVZDeviceSku\":false,\"sorType\":\"\",\"contractTerm\":\"MONTH_TO_MONTH\",\"dppMonths\":\"\",\"isCustomerProvidedEquipment\":false,\"networkBandwidthType\":\"LTE\"},\"fiveG\":{\"selfInstallDate\":\"\",\"address\":{\"streetNumber\":\"\",\"streetName\":\"\",\"streetType\":\"\",\"streetDirection\":\"\",\"addressLine1\":\"\",\"addressLine2\":\"\",\"apartmentNo\":\"\",\"city\":\"\",\"state\":\"\",\"zipCode\":\"\",\"zipCode4\":\"\",\"eventCorrelationId\":\"\"}},\"isKeepingExistingEqProtection\":false,\"ispuFlow\":false,\"newLineOrAAL\":true,\"isNewLine\":true,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"sddZipCode\":\"\",\"preBackOrderDate\":\"\",\"triggerPricingValidation\":false}],\"selectedMtn\":\"\",\"totalDeviceDollar\":null}}";
        request = mapper.readValue(requestString1,AddDeviceUIRequest.class);
        String redisDataString1 = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"isReturnRequired\": \"false\" }";
        CartRedisData sampleRedisData1 = mapper.readValue(redisDataString1, CartRedisData.class);
        Mono<AddDeviceUIRequest> res1= accDevHelper1.updateMtnInUiRequest(request,sampleRedisData1);
        StepVerifier.create(res1).assertNext(junit.framework.Assert::assertNotNull).expectComplete()
                .verify();

        String requestString2 = "{\"cartInfo\":{\"correlationId\":\"\",\"processStep\":\"GridWallPDP\",\"flowType\": \"FWA_UPGRADE\",\"cartCreator\":\"9858484858\",\"processingMTN\":\"9858484858\",\"processAction\":\"addDevice\",\"intendType\":\"EUP_5G\",\"number_share_capable\":\"\",\"creditAppNum\":null,\"isQuoteCart\":false,\"enableDefaultedShipToHome\":false,\"bogoEnabled\":\"\", \"isReturnRequired\": \"\"},\"data\":{\"lines\":[{\"multiLineSeqNumber\":\"1\",\"mtn\":\"9858484858\",\"purchasePath\":\"EUP_5G\",\"lineDeviceDollar\":0,\"upgradeReasonCode\":\"\",\"device\":{\"category\":\"\",\"deviceId\":\"\",\"id\":\"ASK-NCQ1338FA\",\"isNonVZDeviceSku\":false,\"sorType\":\"\",\"contractTerm\":\"MONTH_TO_MONTH\",\"dppMonths\":\"\",\"isCustomerProvidedEquipment\":false,\"networkBandwidthType\":\"LTE\"},\"fiveG\":{\"selfInstallDate\":\"\",\"address\":{\"streetNumber\":\"\",\"streetName\":\"\",\"streetType\":\"\",\"streetDirection\":\"\",\"addressLine1\":\"\",\"addressLine2\":\"\",\"apartmentNo\":\"\",\"city\":\"\",\"state\":\"\",\"zipCode\":\"\",\"zipCode4\":\"\",\"eventCorrelationId\":\"\"}},\"isKeepingExistingEqProtection\":false,\"ispuFlow\":false,\"newLineOrAAL\":true,\"isNewLine\":true,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"sddZipCode\":\"\",\"preBackOrderDate\":\"\",\"triggerPricingValidation\":false}],\"selectedMtn\":\"\",\"totalDeviceDollar\":null}}";
        AddDeviceUIRequest request1 = mapper.readValue(requestString2,AddDeviceUIRequest.class);
        String redisDataString2 = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"\", \"processingMTN\": \"\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"\", \"isReturnRequired\": \"\" }";
        CartRedisData sampleRedisData2 = mapper.readValue(redisDataString2, CartRedisData.class);
        Mono<AddDeviceUIRequest> res2= accDevHelper1.updateMtnInUiRequest(request1,sampleRedisData2);
        StepVerifier.create(res2).assertNext(junit.framework.Assert::assertNotNull).expectComplete()
                .verify();

        when(featureFlagHelper.isRouterUpgradeFlagEnabled()).thenReturn(Boolean.FALSE);
        res1= accDevHelper1.updateMtnInUiRequest(request,sampleRedisData1);
        StepVerifier.create(res1).assertNext(junit.framework.Assert::assertNotNull).expectComplete()
                .verify();

        res1= accDevHelper1.updateMtnInUiRequest(request,null);
        StepVerifier.create(res1).assertNext(junit.framework.Assert::assertNotNull).expectComplete()
                .verify();

    }
//    @Test
//    public void updateMtnInUiRequestTest1() throws JsonProcessingException {
//        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"noPendingOfferExists\":false,\"isPromoPDP\":false,\"mtnFlow\":\"G\"},\"data\":{\"lines\":[{\"isCommonPDP\":true,\"mtn\":\"\",\"purchasePath\":\"EUP\",\"portInNumber\":\"\",\"eupNoPromoFlow\":false,\"device\":{\"id\":\"MTM23LL/A\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":true,\"dppMonths\":36,\"productId\":\"dev21410694\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"UNIVESIM5G-SAB-D\"},\"ispuFlow\":false,\"estimatedReadyByDate\":\"\",\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"newLineOrAAL\":false,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":false,\"isIconicPhone\":true,\"selectedSedOfferId\":\"\",\"selectedSpoId\":\"\",\"isStrategicOffer\":false,\"restricted\":\"\",\"isTradeInIntentSelected\":false}],\"rtm\":{\"url\":\"https://www.verizon.com/smartphones/apple-iphone-15/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-128gb-green-mtm23ll-a-a\",\"name\":\"iPhone 15\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://www.verizon.com/smartphones/apple-iphone-15/\"}}}";
//        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
//        String sampleResponseString = "{\"data\":{\"cart\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"status\":\"A\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"cartCreator\":\"4434541510\",\"cartCreatorOrderLocationCode\":\"E248201\",\"cartCreatorSalesRepId\":\"ENC\",\"creditApplicationNum\":\"388936130\",\"secondaryCreditApplicationNum\":0},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"customerType\":\"U\",\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"totalTaxAmount\":\"38.75\",\"spocs\":{\"notificationOptions\":{\"contactPhoneNumber\":\"1196120299\",\"primaryEmailId\":\"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"instantCreditAmount\":0.0,\"instantCreditAmountRemaining\":0.0,\"instantCreditEligible\":false,\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":388936130,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\":\"true\",\"creditAdvisory\":\"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\":\"0\",\"serviceClass\":\"B\",\"lineCreditClass\":\"\"},\"orderActivityType\":\"EUP\",\"orderNumber\":\"1112\"}],\"orderNumber\":0,\"outletId\":\"124632\",\"registerNumber\":0,\"saleType\":\"P\",\"salesRepId\":\"ENC\",\"totalInstantCreditAmount\":0.0,\"totalInstantCreditAmountUsed\":0.0,\"fiosAccountInfo\":{\"upSpeedInfo\":\"1024M\"}},\"lineDetails\":{\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"newPricePlanInfo\":{\"categoryCode\":\"87\"},\"mldTrunkMTN\":0,\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"zipCode4\":\"7848\"},\"isValidAddress\":true},\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"currentDevice\":{\"oldLteVoraEquipInfo\":{\"iccid\":\"89148000004671963398\",\"lteVoraDeviceInfo\":{\"deviceId\":\"352530085081859\",\"deviceType\":\"4GE\"}}},\"isSharePlanAdded\":false,\"edgeLine\":false,\"vlcLine\":false,\"isE911AddressValidated\":false,\"oldPlanFlag\":\"L\",\"orderDevice\":{\"lteVoraEquipInfo\":{\"lteEqpt\":{},\"lteVoraDeviceInfo\":{}}}},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"shippingCost\":\"0.0\",\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"isUseUnVerifiedAddress\":false,\"isValidAddress\":false},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"mobileNumber\":\"4434541510\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"groupDiscInd\":0,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-thumb$\"},\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"color\":{\"color\":\"#cfbea9\",\"colorDisplayName\":\"GOLD/PINKSAND\"},\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"discounts\":[],\"availableReasonCode\":[],\"inventory\":{\"isAvailable\":true,\"isBackorder\":false,\"isPreOrder\":false,\"qtyAvailable\":39437.0},\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"numberShareEligible\":\"true\",\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0}]},\"isPromoSelected\":false,\"isTradeInSelected\":false}],\"lineIdentifier\":0,\"itemSeqNum5GL\":0,\"itemSeqNum4GR\":0,\"lineExchangeTotal\":0.0,\"lineRefundTotal\":0.0,\"isCpe\":false,\"isDevicePlanCompatible\":false,\"portinMtnAssignment\":false,\"impactedLine\":false,\"preOrBackOrder\":false,\"ispuItem\":true,\"ispuItemBYOD\":false}],\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"numofLinesAAL\":0,\"numofLinesEUP\":0,\"validationMessages\":[],\"payments\":[],\"lineSeq\":0,\"vlcactivePhoneCount\":0,\"fivegOrderind\":false,\"aceOrderCreated\":false,\"serviceLinesCreated\":false,\"aceItemsModified\":false,\"clnrOrderFlag\":false,\"broadbandInd\":false,\"isPaperLessBilling\":\"false\"}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
//        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"cradleFlowJourney\": \"NEXT_GEN\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
//        RetrieveCartUIResponse sampleResponse = null;
//        sampleResponse = mapper.readValue(sampleResponseString, RetrieveCartUIResponse.class);
//        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
//        sampleRedisData.setCradleFlowJourney(CartConstants.NEXT_GEN);
//        String samplecxpResponseString = "{\"data\":{\"cart\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"status\":\"A\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"cartCreator\":\"4434541510\",\"cartCreatorOrderLocationCode\":\"E248201\",\"cartCreatorSalesRepId\":\"ENC\",\"creditApplicationNum\":\"388936130\",\"secondaryCreditApplicationNum\":0},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"customerType\":\"U\",\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"totalTaxAmount\":\"38.75\",\"spocs\":{\"notificationOptions\":{\"contactPhoneNumber\":\"1196120299\",\"primaryEmailId\":\"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"instantCreditAmount\":0.0,\"instantCreditAmountRemaining\":0.0,\"instantCreditEligible\":false,\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":388936130,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\":\"true\",\"creditAdvisory\":\"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\":\"0\",\"serviceClass\":\"B\",\"lineCreditClass\":\"\"},\"orderActivityType\":\"EUP\",\"orderNumber\":\"1112\"}],\"orderNumber\":0,\"outletId\":\"124632\",\"registerNumber\":0,\"saleType\":\"P\",\"salesRepId\":\"ENC\",\"totalInstantCreditAmount\":0.0,\"totalInstantCreditAmountUsed\":0.0},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"numofLinesAAL\":0,\"numofLinesEUP\":0,\"validationMessages\":[],\"payments\":[],\"lineSeq\":0,\"vlcactivePhoneCount\":0,\"fivegOrderind\":false,\"aceOrderCreated\":false,\"serviceLinesCreated\":false,\"aceItemsModified\":false,\"clnrOrderFlag\":false,\"broadbandInd\":false,\"isPaperLessBilling\":\"false\"}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
//        RetrieveCartCXPResponse sampleCXPResponse = mapper.readValue(sampleResponseString, RetrieveCartCXPResponse.class);
//        Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
//        Mono<RetrieveCartUIResponse> sampleResponseMono = Mono.just(sampleResponse);
//        when(cxpHelper.retrieveCart(Mockito.any())).thenReturn(sampleResponseMono);
//        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
//        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.anyString())).thenReturn(Mono.just(Boolean.TRUE));
//        when(redisHelper3.getConflictsStatusFromSession()).thenReturn(Mono.just(true));
//        when(cxpService.retrieveCart(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
//        Mono<AddDeviceUIRequest> res= accDevHelper1.updateMtnInUiRequest(request,sampleRedisData);
//        StepVerifier.create(res).assertNext( resp-> junit.framework.Assert.assertNotNull(resp)).expectComplete()
//                .verify();
//
//    }

    @Test
    public void checkCradleResponseForComboOrderOmniIndrect() throws IOException, SOEHTTPException {
        String sampleRequestString = "{\"channelId\": \"OMNI-INDIRECT-TAB\",\"cartInfo\": {\"mtnFlow\": \"M\",\"processStep\": \"promo\",\"authorizedUser\": null,\"cartCreator\": \"\",\"clientAppName\": \"VZW-ECOM\",\"editDevice\": false,\"cartId\": \"cart\",\"caseId\": \"case\",\"processingMTN\": \"\",\"accountNumber\": \"0280106868-00001\",\"intendType\": \"AAL_BYOD\"},\"data\": {\"externalId\": \"id\",\"newLineOrAAL\": false,\"lines\": [{},{\"mtn\": \"mtn\"}]}}";
        AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        String outPut = "{\n" +
                "  \"throttleList\": \"|ComboOrderIndirect|\"\n" +
                "}";
        UIRequest.setChannelId(CartConstants.OMNI_INDIRECT_TAB);
        final var cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(outPut);
        Mockito.when(cradleAllocator.invokeReactiveCradle(any(ServerHttpRequest.class),
                        any(ServerHttpResponse.class), anyMap()))
                .thenReturn(Mono.just(cradleResponse));
        when(accDevHelper1.invokeCradleForComboExistingCustomer(UIRequest))
                .thenReturn(Mono.just(cradleResponse));
        Mono<Boolean> checkCradleResp = accDevHelper1.checkCradleResponseForComboOrderExistingCustomer(UIRequest);
        StepVerifier.create(checkCradleResp).assertNext(resp -> Assert.assertTrue(resp)).expectComplete().verify();
    }

    @Test
    public void checkCradleResponseForComboOrderChatStore() throws IOException, SOEHTTPException {
        String sampleRequestString = "{\"channelId\": \"CHAT-STORE\",\"cartInfo\": {\"mtnFlow\": \"M\",\"processStep\": \"promo\",\"authorizedUser\": null,\"cartCreator\": \"\",\"clientAppName\": \"VZW-ECOM\",\"editDevice\": false,\"cartId\": \"cart\",\"caseId\": \"case\",\"processingMTN\": \"\",\"accountNumber\": \"0280106868-00001\",\"intendType\": \"EUPBYOD\"},\"data\": {\"externalId\": \"id\",\"newLineOrAAL\": false,\"lines\": [{},{\"mtn\": \"mtn\"}]}}";
        AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        String outPut = "{\n" +
                "  \"throttleList\": \"|ComboOrderChatStore|\"\n" +
                "}";
        UIRequest.setChannelId(CartConstants.CHAT_STORE);
        final var cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(outPut);
        Mockito.when(cradleAllocator.invokeReactiveCradle(any(ServerHttpRequest.class),
                        any(ServerHttpResponse.class), anyMap()))
                .thenReturn(Mono.just(cradleResponse));
        when(accDevHelper1.invokeCradleForComboExistingCustomer(UIRequest))
                .thenReturn(Mono.just(cradleResponse));
        Mono<Boolean> checkCradleResp = accDevHelper1.checkCradleResponseForComboOrderExistingCustomer(UIRequest);
        StepVerifier.create(checkCradleResp).assertNext(resp -> Assert.assertTrue(resp)).expectComplete().verify();
    }
    @Test
    public void checkCradleResponseForComboOrderExistingCustomerTest() throws IOException, SOEHTTPException {
        String sampleRequestString = "{\"channelId\": \"OMNI-INDIRECT-TAB\",\"cartInfo\": {\"mtnFlow\": \"M\",\"processStep\": \"promo\",\"authorizedUser\": null,\"cartCreator\": \"\",\"clientAppName\": \"VZW-ECOM\",\"editDevice\": false,\"cartId\": \"cart\",\"caseId\": \"case\",\"processingMTN\": \"\",\"accountNumber\": \"0280106868-00001\",\"intendType\": \"AAL_BYOD\"},\"data\": {\"externalId\": \"id\",\"newLineOrAAL\": false,\"lines\": [{},{\"mtn\": \"mtn\"}]}}";
        AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        String outPut = "{\n" +
                "  \"throttleList\": \"|ComboOrderD2D|\"\n" +
                "}";
        UIRequest.setChannelId(CartConstants.OMNI_D2D);
        final var cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(outPut);
        Mockito.when(cradleAllocator.invokeReactiveCradle(any(ServerHttpRequest.class),
                        any(ServerHttpResponse.class), anyMap()))
                .thenReturn(Mono.just(cradleResponse));
        when(accDevHelper1.invokeCradleForComboExistingCustomer(UIRequest))
                .thenReturn(Mono.just(cradleResponse));
        Mono<Boolean> checkCradleResp = accDevHelper1.checkCradleResponseForComboOrderExistingCustomer(UIRequest);
        StepVerifier.create(checkCradleResp).assertNext(resp -> Assert.assertTrue(resp)).expectComplete().verify();

        UIRequest.setChannelId(CartConstants.OMNI_TELESALES);
        Mockito.when(cradleAllocator.invokeReactiveCradle(any(ServerHttpRequest.class),
                        any(ServerHttpResponse.class), anyMap()))
                .thenReturn(Mono.just(cradleResponse));
        when(accDevHelper1.invokeCradleForComboExistingCustomer(UIRequest))
                .thenReturn(Mono.just(cradleResponse));
        Mono<Boolean> checkCradleResp11 = accDevHelper1.checkCradleResponseForComboOrderExistingCustomer(UIRequest);
        StepVerifier.create(checkCradleResp11).assertNext(resp -> Assert.assertFalse(resp)).expectComplete().verify();

        UIRequest.setChannelId(CartConstants.OMNI_CARE);
        Mockito.when(cradleAllocator.invokeReactiveCradle(any(ServerHttpRequest.class),
                        any(ServerHttpResponse.class), anyMap()))
                .thenReturn(Mono.just(cradleResponse));
        when(accDevHelper1.invokeCradleForComboExistingCustomer(UIRequest))
                .thenReturn(Mono.just(cradleResponse));
        Mono<Boolean> checkCradleResp12 = accDevHelper1.checkCradleResponseForComboOrderExistingCustomer(UIRequest);
        StepVerifier.create(checkCradleResp12).assertNext(resp -> Assert.assertFalse(resp)).expectComplete().verify();

        UIRequest.setChannelId(CartConstants.CHAT_STORE);
        Mockito.when(cradleAllocator.invokeReactiveCradle(any(ServerHttpRequest.class),
                        any(ServerHttpResponse.class), anyMap()))
                .thenReturn(Mono.just(cradleResponse));
        when(accDevHelper1.invokeCradleForComboExistingCustomer(UIRequest))
                .thenReturn(Mono.just(cradleResponse));
        Mono<Boolean> checkCradleResp13 = accDevHelper1.checkCradleResponseForComboOrderExistingCustomer(UIRequest);
        StepVerifier.create(checkCradleResp13).assertNext(resp -> Assert.assertFalse(resp)).expectComplete().verify();


        UIRequest.setChannelId(CartConstants.OMNI_INDIRECT);
        Mockito.when(cradleAllocator.invokeReactiveCradle(any(ServerHttpRequest.class),
                        any(ServerHttpResponse.class), anyMap()))
                .thenReturn(Mono.just(cradleResponse));
        when(accDevHelper1.invokeCradleForComboExistingCustomer(UIRequest))
                .thenReturn(Mono.just(cradleResponse));
        Mono<Boolean> checkCradleResp14 = accDevHelper1.checkCradleResponseForComboOrderExistingCustomer(UIRequest);
        StepVerifier.create(checkCradleResp14).assertNext(resp -> Assert.assertFalse(resp)).expectComplete().verify();

        UIRequest.setChannelId(CartConstants.OMNI_INDIRECT_TAB);
        Mockito.when(cradleAllocator.invokeReactiveCradle(any(ServerHttpRequest.class),
                        any(ServerHttpResponse.class), anyMap()))
                .thenReturn(Mono.just(cradleResponse));
        when(accDevHelper1.invokeCradleForComboExistingCustomer(UIRequest))
                .thenReturn(Mono.just(cradleResponse));
        Mono<Boolean> checkCradleResp15 = accDevHelper1.checkCradleResponseForComboOrderExistingCustomer(UIRequest);
        StepVerifier.create(checkCradleResp15).assertNext(resp -> Assert.assertFalse(resp)).expectComplete().verify();

        UIRequest.setChannelId(CartConstants.D2D_IPAD);
        Mockito.when(cradleAllocator.invokeReactiveCradle(any(ServerHttpRequest.class),
                        any(ServerHttpResponse.class), anyMap()))
                .thenReturn(Mono.just(cradleResponse));
        when(accDevHelper1.invokeCradleForComboExistingCustomer(UIRequest))
                .thenReturn(Mono.just(cradleResponse));
        Mono<Boolean> checkCradleResp1 = accDevHelper1.checkCradleResponseForComboOrderExistingCustomer(UIRequest);
        StepVerifier.create(checkCradleResp1).assertNext(resp -> Assert.assertTrue(resp)).expectComplete().verify();

    }

    @Test
    public void checkCradleResponseForComboOrderExistingCustomerTest1() throws IOException, SOEHTTPException {
        String sampleRequestString = "{\"channelId\": \"OMNI-INDIRECT-TAB\",\"cartInfo\": {\"mtnFlow\": \"M\",\"processStep\": \"promo\",\"authorizedUser\": null,\"cartCreator\": \"\",\"clientAppName\": \"VZW-ECOM\",\"editDevice\": false,\"cartId\": \"cart\",\"caseId\": \"case\",\"processingMTN\": \"\",\"accountNumber\": \"0280106868-00001\",\"intendType\": \"AAL_BYOD\"},\"data\": {\"externalId\": \"id\",\"newLineOrAAL\": false,\"lines\": [{},{\"mtn\": \"mtn\"}]}}";
        AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        String outPut1 = "{\n" +
                "  \"throttleList\": \"|ComboOrderRetail|\"\n" +
                "}";
        final var cradleResponse1 = new CradleResponse();
        cradleResponse1.setOutPut(outPut1);
        UIRequest.setChannelId(CartConstants.D2D_IPAD);
        Mockito.when(cradleAllocator.invokeReactiveCradle(any(ServerHttpRequest.class),
                        any(ServerHttpResponse.class), anyMap()))
                .thenReturn(Mono.just(cradleResponse1));
        when(accDevHelper1.invokeCradleForComboExistingCustomer(UIRequest))
                .thenReturn(Mono.just(cradleResponse1));
        Mono<Boolean> checkCradleResp2 = accDevHelper1.checkCradleResponseForComboOrderExistingCustomer(UIRequest);
        StepVerifier.create(checkCradleResp2).assertNext(resp -> Assert.assertFalse(resp)).expectComplete().verify();

        UIRequest.setChannelId(CartConstants.RETAIL);
        Mockito.when(cradleAllocator.invokeReactiveCradle(any(ServerHttpRequest.class),
                        any(ServerHttpResponse.class), anyMap()))
                .thenReturn(Mono.just(cradleResponse1));
        when(accDevHelper1.invokeCradleForComboExistingCustomer(UIRequest))
                .thenReturn(Mono.just(cradleResponse1));
        Mono<Boolean> checkCradleResp3 = accDevHelper1.checkCradleResponseForComboOrderExistingCustomer(UIRequest);
        StepVerifier.create(checkCradleResp3).assertNext(resp -> Assert.assertTrue(resp)).expectComplete().verify();

        UIRequest.setChannelId(CartConstants.RETAIL_IPAD);
        Mockito.when(cradleAllocator.invokeReactiveCradle(any(ServerHttpRequest.class),
                        any(ServerHttpResponse.class), anyMap()))
                .thenReturn(Mono.just(cradleResponse1));
        when(accDevHelper1.invokeCradleForComboExistingCustomer(UIRequest))
                .thenReturn(Mono.just(cradleResponse1));
        Mono<Boolean> checkCradleResp4 = accDevHelper1.checkCradleResponseForComboOrderExistingCustomer(UIRequest);
        StepVerifier.create(checkCradleResp4).assertNext(resp -> Assert.assertTrue(resp)).expectComplete().verify();

        String outPut2 = "{\n" +
                "  \"throttleList\": \"|ComboOrderTelesales|\"\n" +
                "}";
        final var cradleResponse2 = new CradleResponse();
        cradleResponse2.setOutPut(outPut2);
        Mockito.when(cradleAllocator.invokeReactiveCradle(any(ServerHttpRequest.class),
                        any(ServerHttpResponse.class), anyMap()))
                .thenReturn(Mono.just(cradleResponse2));
        when(accDevHelper1.invokeCradleForComboExistingCustomer(UIRequest))
                .thenReturn(Mono.just(cradleResponse2));
        Mono<Boolean> checkCradleResp5 = accDevHelper1.checkCradleResponseForComboOrderExistingCustomer(UIRequest);
        StepVerifier.create(checkCradleResp5).assertNext(resp -> Assert.assertFalse(resp)).expectComplete().verify();

        UIRequest.setChannelId(CartConstants.OMNI_TELESALES);
        Mockito.when(cradleAllocator.invokeReactiveCradle(any(ServerHttpRequest.class),
                        any(ServerHttpResponse.class), anyMap()))
                .thenReturn(Mono.just(cradleResponse2));
        when(accDevHelper1.invokeCradleForComboExistingCustomer(UIRequest))
                .thenReturn(Mono.just(cradleResponse2));
        Mono<Boolean> checkCradleResp6 = accDevHelper1.checkCradleResponseForComboOrderExistingCustomer(UIRequest);
        StepVerifier.create(checkCradleResp6).assertNext(resp -> Assert.assertTrue(resp)).expectComplete().verify();

        String outPut3 = "{\n" +
                "  \"throttleList\": \"|ComboOrderCare|\"\n" +
                "}";
        final var cradleResponse3 = new CradleResponse();
        cradleResponse3.setOutPut(outPut3);
        Mockito.when(cradleAllocator.invokeReactiveCradle(any(ServerHttpRequest.class),
                        any(ServerHttpResponse.class), anyMap()))
                .thenReturn(Mono.just(cradleResponse3));
        when(accDevHelper1.invokeCradleForComboExistingCustomer(UIRequest))
                .thenReturn(Mono.just(cradleResponse3));
        Mono<Boolean> checkCradleResp7 = accDevHelper1.checkCradleResponseForComboOrderExistingCustomer(UIRequest);
        StepVerifier.create(checkCradleResp7).assertNext(resp -> Assert.assertFalse(resp)).expectComplete().verify();

        UIRequest.setChannelId(CartConstants.OMNI_CARE);
        Mockito.when(cradleAllocator.invokeReactiveCradle(any(ServerHttpRequest.class),
                        any(ServerHttpResponse.class), anyMap()))
                .thenReturn(Mono.just(cradleResponse3));
        when(accDevHelper1.invokeCradleForComboExistingCustomer(UIRequest))
                .thenReturn(Mono.just(cradleResponse3));
        Mono<Boolean> checkCradleResp8 = accDevHelper1.checkCradleResponseForComboOrderExistingCustomer(UIRequest);
        StepVerifier.create(checkCradleResp8).assertNext(resp -> Assert.assertTrue(resp)).expectComplete().verify();

        String outPut4 = "{\n" +
                "  \"throttleList\": \"|ComboOrderD2D|ComboOrderRetail|ComboOrderTelesales|ComboOrderCare|ComboOrderChatStore|ComboOrderIndirect|\"\n" +
                "}";
        final var cradleResponse4 = new CradleResponse();
        cradleResponse4.setOutPut(outPut4);
        UIRequest.setChannelId(CartConstants.DIGITAL);
        Mockito.when(cradleAllocator.invokeReactiveCradle(any(ServerHttpRequest.class),
                        any(ServerHttpResponse.class), anyMap()))
                .thenReturn(Mono.just(cradleResponse4));
        when(accDevHelper1.invokeCradleForComboExistingCustomer(UIRequest))
                .thenReturn(Mono.just(cradleResponse4));
        Mono<Boolean> checkCradleResp9 = accDevHelper1.checkCradleResponseForComboOrderExistingCustomer(UIRequest);
        StepVerifier.create(checkCradleResp9).assertNext(resp -> Assert.assertFalse(resp)).expectComplete().verify();
    }

    @Test
    public void updateSubFLowTaggingAndUserDataHum() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"AAL\",\"mtnFlow\":\"G\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"device\":{\"id\":\"VZ-0410-001-US\",\"contractTerm\":\"VERIZON_EDGE\",\"dppMonths\":\"36\",\"make\":\"Audi\",\"model\":\"A5\",\"year\":\"2023\",\"emailAddress\":\"TQLMVH3951@VZW.COM\",\"category\":\"HumX\"},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"newLineOrAAL\":true,\"isNewLine\":true}]}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2024.01.08.18.03.41-936.9237003420745\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-13831566-C01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Numberselection\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"NumberSelection\",\"processAction\":\"\",\"cradleFlowJourney\":\"NEXTGEN_EC\"},\"customerInfo\":{\"accountNumber\":\"0219769429-00001\",\"cartCreator\":\"4433862164\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"number_share_capable\":\"\",\"e911_addr_ind\":\"\",\"existingCase\":\"false\",\"noc\":false,\"myvPage\":false},\"cartInfo\":{\"financeLimitExceeded\":\"false\",\"cartItemCount\":1,\"cartId\":\"6473b90a-9f5c-4cc6-884f-f6177325b6fb\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"status\":1,\"spos\":[{\"id\":\"732\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"877\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]},{\"id\":\"1087\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false,\"parentProductsSorIds\":[]}],\"sfos\":[{\"id\":\"48526\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"48553\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"54307\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"66332\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68872\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"73733\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"75802\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"76019\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"77249\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"77553\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"77556\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"77581\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"77583\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"79614\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"80148\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"81143\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"81158\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"82611\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"83856\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"84071\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"84076\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"84077\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"84616\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"84622\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"85484\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86168\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86171\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"89412\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false}],\"firstMonthInstallment\":2.75,\"monthlyInstallment\":2.75,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"eupNoPromoFlow\":false,\"lineSubscriptionInfos\":[],\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"VZ-0410-001-US\",\"installmentTerm\":\"0\",\"itemPrice\":\"99.0\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"Hum+ Gen 2\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0,\"isNonVZDeviceSku\":false},\"sim\":{\"id\":\"EMBDSIMTRI\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"AAL\",\"currentPlanType\":\"ALP\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]}]}}}}";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
//        String responseString2 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1858878952-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryInterestial\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryInterestial\",\"processAction\":\"\",\"cradleFlowJourney\":\"NEXTGEN\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\"},\"cartInfo\":{\"financeLimitExceeded\":\"true\",\"cartItemCount\":0,\"totalDueToday\":54.25,\"totalDueMonthly\":0.0,\"cartId\":\"a144d317-de87-468e-88ee-a5e223fdf152\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":19.59,\"monthlyInstallment\":19.44,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MLA23LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"699.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 13\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
//        AddDeviceUIResponse response2 = mapper.readValue(responseString2, AddDeviceUIResponse.class);
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just(""));
        Mono<Boolean> res= accDevHelper1.updateSubFlowForNextgenSales(response, request);
        StepVerifier.create(res).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
        String requestString1 = "{\"data\":{\"lines\":[]}}";
        AddDeviceUIRequest request1 = mapper.readValue(requestString1, AddDeviceUIRequest.class);
        Mono<Boolean> res1= accDevHelper1.updateSubFlowForNextgenSales(response, request1);
        StepVerifier.create(res1).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
    }

    @Test
    public void removeCaseAndCartIdResponseTest(){
        ServiceBody serviceBody = new ServiceBody();
        ServiceResponse response = new ServiceResponse();
        Context context = new Context();
        context.setCaseId("Test");
        CartInfo info=new CartInfo();
        info.setCartId("TEST-CART");
        context.setCartInfo(info);
        response.setContext(context);
        serviceBody.setServiceResponse(response);
        accDevHelper.removeCaseAndCartIdResponse(serviceBody,"VZW-DOTCOM");
        Assert.assertNotNull(serviceBody);
        accDevHelper.removeCaseAndCartIdResponse(null,"VZW-DOTCOM");
        accDevHelper.removeCaseAndCartIdResponse(serviceBody,"");
        accDevHelper.removeCaseAndCartIdResponse(serviceBody,"VZW-ACSS");
        serviceBody.getServiceResponse().getContext().setCartInfo(null);
        accDevHelper.removeCaseAndCartIdResponse(serviceBody,"VZW-DOTCOM");
        serviceBody.getServiceResponse().setContext(null);
        accDevHelper.removeCaseAndCartIdResponse(serviceBody,"VZW-DOTCOM");
        serviceBody.setServiceResponse(null);
        accDevHelper.removeCaseAndCartIdResponse(serviceBody,"VZW-DOTCOM");
        Assert.assertNotNull(serviceBody);
        accDevHelper.removeCaseAndCartIdResponse(serviceBody,"EXPRESS");
        Assert.assertNotNull(serviceBody);
    }

    @Test
    public void addUpgradeDetailsHelperTest() throws IOException, SOEHTTPException {
        String requestFile ="{ \"cartInfo\": { \"cartId\": \"\", \"caseId\": \"\", \"accountNumber\": \"\", \"cartCreator\": \"\", \"processingMTN\": \"2513678339\", \"processStep\": \"GridWallPDP\", \"processAction\": \"ExpressUpgrade\", \"intendType\": \"EUP\", \"isTradeInSelected\": false, \"disableMyLink\": false, \"editDevice\": false, \"expressCheckout\": null, \"noPendingOfferExists\": false, \"isPromoPDP\": false, \"mtnFlow\": \"M\", \"myvPage\": true }, \"data\": { \"lines\": [ { \"isCommonPDP\": true, \"mtn\": \"2513678339\", \"purchasePath\": \"EUP\", \"portInNumber\": \"\", \"eupNoPromoFlow\": false, \"editSim\":false, \"device\": { \"id\": \"SMS926UZAV\", \"contractTerm\": \"VERIZON_EDGE\", \"iconicPhone\": false, \"dppMonths\": 36, \"productId\": \"dev21411193\", \"category\": \"Smartphones\", \"preconfigure\": false }, \"sim\": { \"id\": \"DFILLUNIV5G-SA-A\" }, \"ispuFlow\": false, \"estimatedReadyByDate\": \"\", \"depletionLocationCode\": \"\", \"depletionType\": \"F\", \"isKeepingExistingEqProtection\": true, \"newLineOrAAL\": false, \"isNewLine\": false, \"selectedPromoId\": \"promo4393822\", \"selectedPromoType\": \"TRADEIN_PROMO\", \"promoRejectionIndicator\": false, \"isIconicPhone\": false, \"selectedSedOfferId\": \"\", \"selectedSpoId\": \"\", \"isStrategicOffer\": false, \"restricted\": \"\", \"isTradeInIntentSelected\": true, \"tradeInInfo\": { \"deviceBrand\": \"\", \"deviceModel\": \"\", \"aemOfferIds\": [], \"tradeinMarketingId\": \"\" } } ], \"rtm\": { \"url\": \"https://vzwqa30.verizonwireless.com/smartphones/samsung-galaxy-s24-plus/\", \"img\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e2-marblegray\", \"name\": \"Galaxy S24+\", \"make\": \"Samsung\", \"categoryId\": \"Smartphones\", \"pageURL\": \"https://vzwqa30.verizonwireless.com/smartphones/samsung-galaxy-s24-plus/\" }, \"enableFcc\": true } }";
        String responseFile = "{ \"serviceHeader\": { \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\", \"correlationId\": \"soe-cart-2024.09.03.19.10.54-632.8554115171785\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"contextInfo\": { \"availablePaths\": [ { \"path\": \"PromoHub\" } ], \"skipCheckoutCall\": false, \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"PromoHub\", \"processAction\": \"\" }, \"customerInfo\": { \"nocByod\": false, \"cartCreator\": \"2185562351\", \"processingMTN\": \"2185562351\", \"registerNumber\": 0, \"number_share_capable\": \"\", \"e911_addr_ind\": \"\", \"existingCase\": \"false\", \"noc\": false, \"myvPage\": false }, \"cartInfo\": { \"financeLimitExceeded\": \"false\", \"cartItemCount\": 1, \"statusMsg\": \"Success\", \"statusCode\": \"1\", \"lines\": [ { \"status\": 1, \"spos\": [ { \"id\": \"384\", \"actionIndicator\": \"D\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] }, { \"id\": \"1255\", \"conflict\": \"SPO1 Did Not Requalify\", \"actionIndicator\": \"D\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] }, { \"id\": \"732\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] }, { \"id\": \"1256\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] }, { \"id\": \"1692\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] }, { \"id\": \"1801\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] }, { \"id\": \"1958\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] }, { \"id\": \"2107\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] }, { \"id\": \"2719\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] }, { \"id\": \"2740\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] }, { \"id\": \"2743\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] }, { \"id\": \"2780\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] }, { \"id\": \"2826\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] }, { \"id\": \"2884\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] } ], \"sfos\": [ { \"id\": \"76404\", \"conflict\": \"Add SFO due to missing required parent\", \"actionIndicator\": \"A\", \"displayHumWiFi\": false }, { \"id\": \"78485\", \"conflict\": \"Drop SFO due to mandatory feat conflict\", \"actionIndicator\": \"D\", \"displayHumWiFi\": false }, { \"id\": \"83856\", \"conflict\": \"Add SFO due to missing DACC SFO Sequence\", \"actionIndicator\": \"A\", \"displayHumWiFi\": false }, { \"id\": \"86848\", \"conflict\": \"Add SFO due to missing DACC SFO Sequence\", \"actionIndicator\": \"A\", \"displayHumWiFi\": false }, { \"id\": \"88888\", \"actionIndicator\": \"A\", \"displayHumWiFi\": false }, { \"id\": \"88984\", \"actionIndicator\": \"A\", \"displayHumWiFi\": false }, { \"id\": \"89405\", \"actionIndicator\": \"A\", \"displayHumWiFi\": false }, { \"id\": \"89671\", \"conflict\": \"SFO dropped because of requal - PPlan ch\", \"actionIndicator\": \"D\", \"displayHumWiFi\": false }, { \"id\": \"89673\", \"conflict\": \"SFO dropped because of requal - PPlan ch\", \"actionIndicator\": \"D\", \"displayHumWiFi\": false }, { \"id\": \"90051\", \"actionIndicator\": \"A\", \"displayHumWiFi\": false }, { \"id\": \"90052\", \"conflict\": \"Add SFO due to missing required parent\", \"actionIndicator\": \"A\", \"displayHumWiFi\": false } ], \"firstMonthInstallment\": 22.29, \"monthlyInstallment\": 22.22, \"reasonCode\": \"PLAN_DEVICE_COMPATIBLE\", \"selectedPromoType\": \"TRADEIN_PROMO\", \"eupNoPromoFlow\": false, \"lineSubscriptionInfos\": [], \"featureMessages\": [ { \"name\": \"5GUWBBOLT\", \"action\": \"ADD\" }, { \"name\": \"5GCOREPROV\", \"action\": \"ADD\" } ], \"mtn\": \"2185562351\", \"device\": { \"upgradeReasonCode\": \"EA\", \"id\": \"SMS921UZYV\", \"installmentTerm\": \"0\", \"itemPrice\": \"799.99\", \"finalPrice\": \"0.0\", \"discountAmount\": \"0.0\", \"qty\": 1, \"edgeUpEnabled\": false, \"numberShareEnabled\": false, \"existingDeviceName\": \"Galaxy S24\", \"fiveGToFourGDownGrade\": false, \"byodESimPhone\": false, \"skipImei1Call\": false, \"amount\": 0.0, \"isNonVZDeviceSku\": false, \"skuId\": \"sku6010127\", \"skuDisplayName\": \"Samsung Galaxy S24 128GB in Amber Yellow\", \"isDfoSelected\": false }, \"sim\": { \"id\": \"DFILLUNIV5G-SA-A\" }, \"warranty\": { \"itemPrice\": \"0.0\" }, \"upgradeFee\": { \"qty\": 1, \"itemPrice\": \"35\" }, \"devicePlanCompatible\": true, \"planValidationFailed\": false, \"lineActivityType\": \"EUP\", \"currentPlanType\": \"LLP\", \"planQualifiedForPromotion\": false, \"fiveGUpSell\": false, \"is5GBoltEligible\": false, \"fiveGPlanAdded\": false, \"editSim\": false, \"lineWithSkipMDN\": false, \"inWithVerizonOpted\": false, \"protectionNotRequired\": false, \"skipPromoChoiceOffer\": false } ], \"expressCheckout\": false, \"effectiveDateDetails\": { \"suggestedBackDate\": \"\", \"suggestedFutureDate\": \"\", \"currentBillCycleBeginDate\": \"\", \"nextBillCycleBeginDate\": \"\", \"onDemandDate\": \"\", \"onDemandRangeInDays\": \"\", \"selectedDate\": \"\" }, \"preAuthSuccess\": false, \"promoLossIndicator\": false, \"monthlyCreditAmount\": \"0.0\", \"agreementNumber\": \"0\", \"vztDiscountGain\": false, \"vztDiscountLoss\": false, \"discountPromoTotal\": 0.0, \"registerNumber\": 0, \"hasMixAndMatchPlan\": false, \"oneBillEnrolled\": false, \"protectionNotRequired\": false, \"fmiCheck\": false, \"isFlexV2\": false, \"isPrepaidToPostpaidMigration\": false, \"instantCreditAmount\": 0, \"ngdFlow\": false }, \"processMTNList\": [ { \"mtn\": \"2185562351\", \"completedprocessSteps\": [] } ] } } }, \"featureConfigurationProfileData\": { \"expressUpgradeFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"eupPromoRestructureFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"oneClkDppSummaryFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"offerFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"bauUpgradeFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"enableGiftingFeature\": [ \"true\" ], \"enableAccMemberMigration\": [ \"true\" ], \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"oneUnlimitedFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } } } }";
        String redisDataFile = "{ \"cartId\": \"gsf5g-uhdye9-rhe7fh-jfufhe8\", \"caseId\": \"SOP-6849878-E01\", \"accountNumber\": \"0216897840-00001\", \"mtn\": \"5402305402\", \"cartCreator\": \"5402305402\", \"cartCount\": \"1\", \"cartOrderFlowType\": \"eup\", \"locationCode\": \"0026301\", \"storeLocationState\": \"NJ\", \"customerAddressState\": \"VA\", \"isSmartphone\": false, \"isAppleDevice\": false, \"safeTechSessionId\": \"xkaTw8nHlJPyfp3761fL00uB\", \"verifiedName\": \"RYAN CANU\", \"creditCheckFailedCount\": 0, \"autoPayEnrolled\": \"false\", \"repId\": \"ENC\", \"storeName\": \"ATLANTIC CITY COMM STORE\", \"loggedInUser\": \"chamasi\", \"isfiveGUpSellSelected\": false, \"processingMTN\": \"5402305402\", \"isDirectApply\": true, \"locationSubType\":\"RX\", \"rfexExchangeShopDetails\":\"{\\\"mtn\\\":\\\"4023600673\\\",\\\"returnItemSeq\\\":\\\"1\\\"}\" }";
        AddDeviceUIRequest UIRequest = mapper.readValue(requestFile, AddDeviceUIRequest.class);
        AddDeviceUIResponse responseServiceMono = mapper.readValue(responseFile, AddDeviceUIResponse.class);
        CartRedisData sampleRedisData = mapper.readValue(redisDataFile, CartRedisData.class);
        ServerHttpResponse httpResponse = Mockito.mock(ServerHttpResponse.class);
        URI url = URI.create("https://localhost/");
        MultiValueMap<String, HttpCookie> cookieMap = new LinkedMultiValueMap<>();
        List<HttpCookie> cookieList = new ArrayList<HttpCookie>();
        cookieList.add(new HttpCookie("name", "value"));
        cookieMap.put("iconicTestIntent", cookieList);
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).cookies(cookieMap).build();
        UIRequest.setHttpRequest(httpRequest);
        when(redisHelper2.getRole()).thenReturn(Mono.just("role"));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.getEdgeBuyoutRedisData()).thenReturn(Mono.just(new HashMap()));
        when(bpmHelper.addUpgradeDetails(Mockito.any())).thenReturn(Mono.just(responseServiceMono));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(preHandleAddDevice.execute(UIRequest, sampleRedisData)).thenReturn(Mono.just(Boolean.TRUE));
        Mono<AddDeviceUIResponse> response = accDevHelper1.addUpgradeDetails(UIRequest,httpResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addUpgradeDetailsHelperDeviceIdMissingTest() throws IOException, SOEHTTPException {
        String requestFile = "addUpgradeDetailsRequest.json";
        String responseFile = "addUpgradeDetailsResponse.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse responseServiceMono = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        ServerHttpResponse httpResponse = Mockito.mock(ServerHttpResponse.class);
        URI url = URI.create("https://localhost/");
        MultiValueMap<String, HttpCookie> cookieMap = new LinkedMultiValueMap<>();
        List<HttpCookie> cookieList = new ArrayList<HttpCookie>();
        cookieList.add(new HttpCookie("name", "value"));
        cookieMap.put("iconicTestIntent", cookieList);
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).cookies(cookieMap).build();
        UIRequest.setHttpRequest(httpRequest);
        String redisDataString = "{\"cartInfo\": {},\"edgeUpData\": {\"lines\": [{}]},\"buyOutData\":{},\"deviceId\": \"device\", \"cartId\": \"\",\"verifiedName\":\" name 1 2\", \"caseId\": \"\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"\",\"creditAppNum\":\"54453277834\", \"accountNumber\": \"\", \"mtn\": \"8436667390\",\"fiosAuthenticated\":true}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(redisHelper2.getRole()).thenReturn(Mono.just("role"));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.getEdgeBuyoutRedisData()).thenReturn(Mono.just(new HashMap()));
        when(bpmHelper.addUpgradeDetails(Mockito.any())).thenReturn(Mono.just(responseServiceMono));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(preHandleAddDevice.execute(UIRequest, sampleRedisData)).thenReturn(Mono.just(Boolean.TRUE));
        Mono<AddDeviceUIResponse> response = accDevHelper1.addUpgradeDetails(UIRequest,httpResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void setByodDataFromRedisTest(){
        Device device = new Device();
        SoftSKUItem sim = new SoftSKUItem();
        DeviceImeiSimDetails deviceImeiSimDetails = new DeviceImeiSimDetails();
        accDevHelper.setByodDataFromRedis(deviceImeiSimDetails,device,sim);
        Assert.assertNull(device.getDeviceId());
        Assert.assertNull(sim.getIccid());
        deviceImeiSimDetails.setDeviceId("358643090227948");
        device.setSmartIMEI(false);
        accDevHelper.setByodDataFromRedis(deviceImeiSimDetails,device,sim);
        Assert.assertEquals(device.getDeviceId(),deviceImeiSimDetails.getDeviceId());
        deviceImeiSimDetails.setImei1("1234");
        deviceImeiSimDetails.setImei2("358643090227948");
        deviceImeiSimDetails.setEID("890212");
        deviceImeiSimDetails.setIccid("123400");
        accDevHelper.setByodDataFromRedis(deviceImeiSimDetails,device,sim);
        Assert.assertEquals(device.getDeviceId(),deviceImeiSimDetails.getDeviceId());
        Assert.assertNotNull(sim.getIccid());
        device.setByodESimPhone(true);
        sim.setIsCustomerProvidedSIM(true);
        accDevHelper.setByodDataFromRedis(deviceImeiSimDetails,device,sim);
       // Assert.assertEquals(device.getDeviceId(),deviceImeiSimDetails.getImei2());
        Assert.assertEquals(sim.getIccid(),deviceImeiSimDetails.getIccid());
        device.setImei2(null);
        accDevHelper.setByodDataFromRedis(deviceImeiSimDetails,device,sim);
        device.setByodESimPhone(false);
        accDevHelper.setByodDataFromRedis(deviceImeiSimDetails,device,sim);
        deviceImeiSimDetails.setEsimOnly(true);
        accDevHelper.setByodDataFromRedis(deviceImeiSimDetails,device,sim);
        device.setByodESimPhone(true);
        deviceImeiSimDetails.setEsimOnly(false);
        device.setImei2("358643090227948");
        deviceImeiSimDetails.setEID("890212");
        accDevHelper.setByodDataFromRedis(deviceImeiSimDetails,device,sim);
        Assert.assertEquals(device.getDeviceId(),deviceImeiSimDetails.getImei2());
        device.setImei2(null);
        accDevHelper.setByodDataFromRedis(deviceImeiSimDetails,device,sim);
        Assert.assertEquals(device.getDeviceId(),deviceImeiSimDetails.getImei2());
        deviceImeiSimDetails.setEsimOnly(true);
        accDevHelper.setByodDataFromRedis(deviceImeiSimDetails,device,sim);
        Assert.assertEquals(sim.getESIM(),deviceImeiSimDetails.getEID());
        device.setByodESimPhone(false);
        Assert.assertEquals(sim.getESIM(),deviceImeiSimDetails.getEID());
        sim.setIsCustomerProvidedSIM(false);
        accDevHelper.setByodDataFromRedis(deviceImeiSimDetails,device,sim);
    }

    @Test
    public void addUpgradeDetailsTest1() throws JsonProcessingException {
        String requestFile = "AddUpgradeDetailsUIRequest1.json";
        String responseFile = "addUpgradeDetailsResponse.json";
        String redisDataFile = "AddUpgradeDetailsRedisData.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile(redisDataFile, testFileLocation);
        AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse UIResponse = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        ServerHttpResponse httpResponse = Mockito.mock(ServerHttpResponse.class);

        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        UpdateEdgeupData edgeupData = new UpdateEdgeupData();
        Lines line = new Lines();
        line.setMtn("8109313693");
        Lines[] lines = {line};
        edgeupData.setLines(lines);
        sampleRedisData.setEdgeUpData(edgeupData);
        when(redisHelper2.getRole()).thenReturn(Mono.just("role"));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));

        HashMap<String,CartRedisData> ebData = new HashMap();
        ebData.put("8109313693",sampleRedisData);
        when(redisHelper2.getEdgeBuyoutRedisData()).thenReturn(Mono.just(ebData));
        when(preHandleAddDevice.execute(UIRequest, sampleRedisData)).thenReturn(Mono.just(Boolean.TRUE));
        when(bpmHelper.addUpgradeDetails(Mockito.any())).thenReturn(Mono.just(UIResponse));
        Mono<AddDeviceUIResponse> response2 = accDevHelper1.addUpgradeDetails(UIRequest,httpResponse);
        StepVerifier.create(response2).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest.getCartInfo().setBuyOutFlag("Y");
        Mono<AddDeviceUIResponse> response1 = accDevHelper1.addUpgradeDetails(UIRequest,httpResponse);
        StepVerifier.create(response1).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest.getCartInfo().setBuyOutFlag("N");
        UIRequest.getData().getLines().get(0).getEdgeup().setDeviceId("");
        Mono<AddDeviceUIResponse> response3 = accDevHelper1.addUpgradeDetails(UIRequest,httpResponse);
        StepVerifier.create(response3).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest.getCartInfo().setBuyOutFlag("N");
        UIRequest.getData().getLines().get(0).setEdgeup(null);
        response3 = accDevHelper1.addUpgradeDetails(UIRequest,httpResponse);
        StepVerifier.create(response3).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

    }


    @Test
    public void addUpgradeDetailsTest2() throws JsonProcessingException {
        String requestFile = "AddUpgradeDetailsUIRequest1.json";
        String responseFile = "addUpgradeDetailsResponse.json";
        String redisDataFile = "AddUpgradeDetailsRedisData.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile(redisDataFile, testFileLocation);
        AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse UIResponse = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        ServerHttpResponse httpResponse = Mockito.mock(ServerHttpResponse.class);

        when(featureFlagHelper.isSafeCheckForBuyOutFFlag()).thenReturn(true);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        UpdateEdgeupData edgeupData = new UpdateEdgeupData();
        Lines line = new Lines();
        line.setMtn("8109313693");
        Lines[] lines = {line};
        edgeupData.setLines(lines);
        sampleRedisData.setEdgeUpData(edgeupData);
        when(redisHelper2.getRole()).thenReturn(Mono.just("role"));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));

        HashMap<String,CartRedisData> ebData = new HashMap();
        ebData.put("8109313693",sampleRedisData);
        when(redisHelper2.getEdgeBuyoutRedisData()).thenReturn(Mono.just(ebData));
        when(preHandleAddDevice.execute(UIRequest, sampleRedisData)).thenReturn(Mono.just(Boolean.TRUE));
        when(bpmHelper.addUpgradeDetails(Mockito.any())).thenReturn(Mono.just(UIResponse));
        Mono<AddDeviceUIResponse> response2 = accDevHelper1.addUpgradeDetails(UIRequest,httpResponse);
        StepVerifier.create(response2).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest.getCartInfo().setBuyOutFlag("Y");
        Mono<AddDeviceUIResponse> response1 = accDevHelper1.addUpgradeDetails(UIRequest,httpResponse);
        StepVerifier.create(response1).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest.getCartInfo().setBuyOutFlag("N");
        UIRequest.getData().getLines().get(0).getEdgeup().setDeviceId("");
        Mono<AddDeviceUIResponse> response3 = accDevHelper1.addUpgradeDetails(UIRequest,httpResponse);
        StepVerifier.create(response3).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest.getCartInfo().setBuyOutFlag("N");
        UIRequest.getData().getLines().get(0).setEdgeup(null);
        response3 = accDevHelper1.addUpgradeDetails(UIRequest,httpResponse);
        StepVerifier.create(response3).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

    }

    @Test
    public void addUpgradeDetailsHelperCategoryRestrictionTest() throws IOException, SOEHTTPException {
        String requestFile = "addUpgradeDetailsRequest.json";
        String responseFile = "addUpgradeDetailsResponse.json";
        String redisDataFile = "addUpgradeDetailsRedisData.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile(redisDataFile, testFileLocation);
        AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse responseServiceMono = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        ServerHttpResponse httpResponse = Mockito.mock(ServerHttpResponse.class);
        URI url = URI.create("https://localhost/");
        MultiValueMap<String, HttpCookie> cookieMap = new LinkedMultiValueMap<>();
        List<HttpCookie> cookieList = new ArrayList<HttpCookie>();
        cookieList.add(new HttpCookie("name", "value"));
        cookieMap.put("iconicTestIntent", cookieList);
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).cookies(cookieMap).build();
        UIRequest.setHttpRequest(httpRequest);
        UIRequest.setChannelId("VZW-DOTCOM");
        when(redisHelper2.getRole()).thenReturn(Mono.just("role"));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.getEdgeBuyoutRedisData()).thenReturn(Mono.just(new HashMap()));
        when(bpmHelper.addUpgradeDetails(Mockito.any())).thenReturn(Mono.just(responseServiceMono));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(preHandleAddDevice.execute(UIRequest, sampleRedisData)).thenReturn(Mono.just(Boolean.TRUE));

        UIRequest.getCartInfo().setFlexV2(true);
        Mono<AddDeviceUIResponse> response1 = accDevHelper1.addUpgradeDetails(UIRequest,httpResponse);
        StepVerifier.create(response1).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest.getData().getLines().get(0).getDevice().setId(null);
        Mono<AddDeviceUIResponse> response2 = accDevHelper1.addUpgradeDetails(UIRequest,httpResponse);
        StepVerifier.create(response2).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest.getData().getLines().get(0).getDevice().setCategory("SmartWatch");
        when(redisHelper2.getRole()).thenReturn(Mono.just("accountMember"));

        Mono<AddDeviceUIResponse> response = accDevHelper1.addUpgradeDetails(UIRequest,httpResponse);
        StepVerifier.create(response).verifyError();

    }

    @Test
    public void addUpgradeDetailsHelperZipCodeTest() throws IOException, SOEHTTPException {
        String requestFile = "addUpgradeDetailsRequest.json";
        String responseFile = "addUpgradeDetailsResponse.json";
        String redisDataFile = "addUpgradeDetailsRedisData.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile(redisDataFile, testFileLocation);
        AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse responseServiceMono = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        ServerHttpResponse httpResponse = Mockito.mock(ServerHttpResponse.class);
        URI url = URI.create("https://localhost/");
        MultiValueMap<String, HttpCookie> cookieMap = new LinkedMultiValueMap<>();
        List<HttpCookie> cookieList = new ArrayList<HttpCookie>();
        cookieList.add(new HttpCookie("name", "value"));
        cookieMap.put("iconicTestIntent", cookieList);
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).cookies(cookieMap).build();
        UIRequest.setHttpRequest(httpRequest);
        UIRequest.setChannelId("VZW-DOTCOM");
        UIRequest.getCartInfo().setZipCode("123456");
        when(redisHelper2.getRole()).thenReturn(Mono.just("role"));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(bpmHelper.addUpgradeDetails(Mockito.any())).thenReturn(Mono.just(responseServiceMono));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(redisHelper2.getEdgeBuyoutRedisData()).thenReturn(Mono.just(new HashMap()));
        when(preHandleAddDevice.execute(UIRequest, sampleRedisData)).thenReturn(Mono.just(Boolean.TRUE));
        Mono<AddDeviceUIResponse> response = accDevHelper1.addUpgradeDetails(UIRequest,httpResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest.getCartInfo().setIntendType(null);
        sampleRedisData.setIntendType("EUP");
        Mono<AddDeviceUIResponse> response1 = accDevHelper1.addUpgradeDetails(UIRequest,httpResponse);
        StepVerifier.create(response1).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest.getCartInfo().setIntendType("EUP");
        UIRequest.getCartInfo().setCaseId("SOF-12345");
        UIRequest.getCartInfo().setOneClick(true);
        UIRequest.getCartInfo().setDeviceType("CONNECTED_CAR");
        sampleRedisData.setImei("1234");
        UIRequest.getCartInfo().setCartCreator(null);
        sampleRedisData.setCartCreator("1234567890");
        sampleRedisData.setVzwRoles("accountmanager");
        sampleRedisData.setVzId("sample");
        sampleRedisData.setIsCommonPDP(true);
        Mono<AddDeviceUIResponse> response2 = accDevHelper1.addUpgradeDetails(UIRequest,httpResponse);
        StepVerifier.create(response2).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

    }

    @Test
    public void updateSubFLowTagging_Subflow_no_ServiceResponsebyodTest() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"reqfrompromopdp\":true,\"intendType\":\"NSEBYOD\"},\"data\":{\"subFlow\":\"Nxtgen\",\"lines\":[{\"device\":{\"category\":\"\"}}]}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse pegaResponse  = new  AddDeviceUIResponse();
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":null}}";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("Nxtgen-BYOD-Treat"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<Boolean> res= accDevHelper1.updateSubFlowInTaggingForNextgen(cdlThrottlist ,response, request);
        StepVerifier.create(res).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();

        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("Nxtgen|Nxtgen-BYOD-Treat"));
        request.setData(null);
        Mono<Boolean> res1= accDevHelper1.updateSubFlowInTaggingForNextgen(cdlThrottlist ,response, request);
        StepVerifier.create(res1).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();

        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("Nxtgen-BYOD-C"));
        Mono<Boolean> res2= accDevHelper1.updateSubFlowInTaggingForNextgen(cdlThrottlist ,response, request);
        StepVerifier.create(res2).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateSubFLowTagging_Subflow_no_ServiceResponsebyod1Test() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"reqfrompromopdp\":true,\"intendType\":\"NSEBYOD\"},\"data\":{\"subFlow\":\"instant\",\"lines\":[{\"device\":{\"category\":\"\"}}]}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse pegaResponse = new AddDeviceUIResponse();
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":null}}";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("Nxtgen-BYOD-Treat"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(), anyBoolean(), anyString())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<Boolean> res = accDevHelper1.updateSubFlowInTaggingForNextgen(cdlThrottlist, response, request);
        StepVerifier.create(res).assertNext(resp -> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateSubFLowTagging2Test() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"reqfrompromopdp\":true,\"intendType\":\"BYOD\"},\"data\":{\"lines\":[{\"device\":{\"category\":\"\"}}]}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse pegaResponse = new AddDeviceUIResponse();
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":null}}";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("instant"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(), anyBoolean(), anyString())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<Boolean> res = accDevHelper1.updateSubFlowInTaggingForNextgen(cdlThrottlist, response, request);
        StepVerifier.create(res).assertNext(resp -> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateSubFLowTagging3Test() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"reqfrompromopdp\":true,\"intendType\":\"NSEBYOD\"},\"data\":{\"subFlow\":\"instant\",\"lines\":[{\"device\":{\"category\":\"\"}}]}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse pegaResponse = new AddDeviceUIResponse();
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":null}}";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("instant"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(), anyBoolean(), anyString())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<Boolean> res = accDevHelper1.updateSubFlowInTaggingForNextgen(cdlThrottlist, response, request);
        StepVerifier.create(res).assertNext(resp -> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();
    }

    @Test
    public void setRestrictedFromRedisToRequestTest() throws IOException, SOEHTTPException {
        String requestFile = "{ \"cartInfo\": { \"cartId\": \"\", \"caseId\": \"\", \"accountNumber\": \"\", \"cartCreator\": \"\", \"processingMTN\": \"2513678339\", \"processStep\": \"GridWallPDP\", \"processAction\": \"ExpressUpgrade\", \"intendType\": \"EUP\", \"isTradeInSelected\": false, \"disableMyLink\": false, \"editDevice\": false, \"expressCheckout\": null, \"noPendingOfferExists\": false, \"isPromoPDP\": false, \"mtnFlow\": \"M\", \"myvPage\": true }, \"data\": { \"lines\": [ { \"isCommonPDP\": true, \"mtn\": \"2513678339\", \"purchasePath\": \"EUP\", \"portInNumber\": \"\", \"eupNoPromoFlow\": false, \"editSim\":false, \"device\": { \"id\": \"SMS926UZAV\", \"contractTerm\": \"VERIZON_EDGE\", \"iconicPhone\": false, \"dppMonths\": 36, \"productId\": \"dev21411193\", \"category\": \"Smartphones\", \"preconfigure\": false }, \"sim\": { \"id\": \"DFILLUNIV5G-SA-A\" }, \"ispuFlow\": false, \"estimatedReadyByDate\": \"\", \"depletionLocationCode\": \"\", \"depletionType\": \"F\", \"isKeepingExistingEqProtection\": true, \"newLineOrAAL\": false, \"isNewLine\": false, \"selectedPromoId\": \"promo4393822\", \"selectedPromoType\": \"TRADEIN_PROMO\", \"promoRejectionIndicator\": false, \"isIconicPhone\": false, \"selectedSedOfferId\": \"\", \"selectedSpoId\": \"\", \"isStrategicOffer\": false, \"restricted\": \"\", \"isTradeInIntentSelected\": true, \"tradeInInfo\": { \"deviceBrand\": \"\", \"deviceModel\": \"\", \"aemOfferIds\": [], \"tradeinMarketingId\": \"\" } } ], \"rtm\": { \"url\": \"https://vzwqa30.verizonwireless.com/smartphones/samsung-galaxy-s24-plus/\", \"img\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e2-marblegray\", \"name\": \"Galaxy S24+\", \"make\": \"Samsung\", \"categoryId\": \"Smartphones\", \"pageURL\": \"https://vzwqa30.verizonwireless.com/smartphones/samsung-galaxy-s24-plus/\" }, \"enableFcc\": true } }";
        String redisDataFile = "{ \"cartId\": \"gsf5g-uhdye9-rhe7fh-jfufhe8\", \"caseId\": \"SOP-6849878-E01\", \"accountNumber\": \"0216897840-00001\", \"mtn\": \"5402305402\", \"cartCreator\": \"5402305402\", \"cartCount\": \"1\", \"cartOrderFlowType\": \"eup\", \"locationCode\": \"0026301\", \"storeLocationState\": \"NJ\", \"customerAddressState\": \"VA\", \"isSmartphone\": false, \"isAppleDevice\": false, \"safeTechSessionId\": \"xkaTw8nHlJPyfp3761fL00uB\", \"verifiedName\": \"RYAN CANU\", \"creditCheckFailedCount\": 0, \"autoPayEnrolled\": \"false\", \"repId\": \"ENC\", \"storeName\": \"ATLANTIC CITY COMM STORE\", \"loggedInUser\": \"chamasi\", \"isfiveGUpSellSelected\": false, \"processingMTN\": \"5402305402\", \"isDirectApply\": true, \"locationSubType\":\"RX\", \"rfexExchangeShopDetails\":\"{\\\"mtn\\\":\\\"4023600673\\\",\\\"returnItemSeq\\\":\\\"1\\\"}\" }";
        AddDeviceUIRequest UIRequest = mapper.readValue(requestFile, AddDeviceUIRequest.class);
        CartRedisData sampleRedisData = mapper.readValue(redisDataFile, CartRedisData.class);
        ServerHttpResponse httpResponse = Mockito.mock(ServerHttpResponse.class);
        URI url = URI.create("https://localhost/");
        MultiValueMap<String, HttpCookie> cookieMap = new LinkedMultiValueMap<>();
        List<HttpCookie> cookieList = new ArrayList<HttpCookie>();
        cookieList.add(new HttpCookie("name", "value"));
        cookieMap.put("iconicTestIntent", cookieList);
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).cookies(cookieMap).build();
        UIRequest.setHttpRequest(httpRequest);
        UIRequest.setChannelId("VZW-DOTCOM");
        UIRequest.getCartInfo().setZipCode("123456");
        UIRequest.getCartInfo().setIntendType("EUP");
        UIRequest.getCartInfo().setCaseId("SOF-12345");
        UIRequest.getCartInfo().setOneClick(true);
        UIRequest.getCartInfo().setDeviceType("CONNECTED_CAR");
        sampleRedisData.setIntendType("EUP");
        List<Lines> deviceLines=new ArrayList<Lines>();
        Lines l1=new Lines();
        l1.setRestricted("Restricted");
        deviceLines.add(l1);
        sampleRedisData.setDeviceLines(deviceLines);
        accDevHelper1.setRestrictedFromRedisToRequest(sampleRedisData,UIRequest);
        accDevHelper1.setRestrictedFromRedisToRequest(null,UIRequest);
        sampleRedisData.setDeviceLines(null);
        accDevHelper1.setRestrictedFromRedisToRequest(sampleRedisData,UIRequest);
        deviceLines.add(null);
        sampleRedisData.setDeviceLines(deviceLines);
        accDevHelper1.setRestrictedFromRedisToRequest(sampleRedisData,UIRequest);
        l1.setRestricted("");
        deviceLines.add(l1);
        sampleRedisData.setDeviceLines(deviceLines);
        accDevHelper1.setRestrictedFromRedisToRequest(sampleRedisData,UIRequest);

        UIRequest.getData().setLines(null);
        accDevHelper1.setRestrictedFromRedisToRequest(sampleRedisData,UIRequest);
        List<Lines> lines = new ArrayList<>();
        Lines l=new Lines();
        l.setRestricted("");
        lines.add(l1);
        UIRequest.getData().setLines(lines);
        accDevHelper1.setRestrictedFromRedisToRequest(sampleRedisData,UIRequest);
        l.setRestricted(null);
        lines.add(l1);
        UIRequest.getData().setLines(lines);
        accDevHelper1.setRestrictedFromRedisToRequest(sampleRedisData,UIRequest);
        lines.add(null);
        UIRequest.getData().setLines(lines);
        accDevHelper1.setRestrictedFromRedisToRequest(sampleRedisData,UIRequest);
        accDevHelper1.setRestrictedFromRedisToRequest(sampleRedisData,null);
    }

    @Test
    public void setRestrictedFromRedisToRequestNegativeTest() throws IOException, SOEHTTPException {
        String requestFile = "{ \"cartInfo\": { \"cartId\": \"\", \"caseId\": \"\", \"accountNumber\": \"\", \"cartCreator\": \"\", \"processingMTN\": \"2513678339\", \"processStep\": \"GridWallPDP\", \"processAction\": \"ExpressUpgrade\", \"intendType\": \"EUP\", \"isTradeInSelected\": false, \"disableMyLink\": false, \"editDevice\": false, \"expressCheckout\": null, \"noPendingOfferExists\": false, \"isPromoPDP\": false, \"mtnFlow\": \"M\", \"myvPage\": true }, \"data\": { \"lines\": [ { \"isCommonPDP\": true, \"mtn\": \"2513678339\", \"purchasePath\": \"EUP\", \"portInNumber\": \"\", \"eupNoPromoFlow\": false, \"editSim\":false, \"device\": { \"id\": \"SMS926UZAV\", \"contractTerm\": \"VERIZON_EDGE\", \"iconicPhone\": false, \"dppMonths\": 36, \"productId\": \"dev21411193\", \"category\": \"Smartphones\", \"preconfigure\": false }, \"sim\": { \"id\": \"DFILLUNIV5G-SA-A\" }, \"ispuFlow\": false, \"estimatedReadyByDate\": \"\", \"depletionLocationCode\": \"\", \"depletionType\": \"F\", \"isKeepingExistingEqProtection\": true, \"newLineOrAAL\": false, \"isNewLine\": false, \"selectedPromoId\": \"promo4393822\", \"selectedPromoType\": \"TRADEIN_PROMO\", \"promoRejectionIndicator\": false, \"isIconicPhone\": false, \"selectedSedOfferId\": \"\", \"selectedSpoId\": \"\", \"isStrategicOffer\": false, \"restricted\": \"\", \"isTradeInIntentSelected\": true, \"tradeInInfo\": { \"deviceBrand\": \"\", \"deviceModel\": \"\", \"aemOfferIds\": [], \"tradeinMarketingId\": \"\" } } ], \"rtm\": { \"url\": \"https://vzwqa30.verizonwireless.com/smartphones/samsung-galaxy-s24-plus/\", \"img\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e2-marblegray\", \"name\": \"Galaxy S24+\", \"make\": \"Samsung\", \"categoryId\": \"Smartphones\", \"pageURL\": \"https://vzwqa30.verizonwireless.com/smartphones/samsung-galaxy-s24-plus/\" }, \"enableFcc\": true } }";
        String redisDataFile = "{ \"cartId\": \"gsf5g-uhdye9-rhe7fh-jfufhe8\", \"caseId\": \"SOP-6849878-E01\", \"accountNumber\": \"0216897840-00001\", \"mtn\": \"5402305402\", \"cartCreator\": \"5402305402\", \"cartCount\": \"1\", \"cartOrderFlowType\": \"eup\", \"locationCode\": \"0026301\", \"storeLocationState\": \"NJ\", \"customerAddressState\": \"VA\", \"isSmartphone\": false, \"isAppleDevice\": false, \"safeTechSessionId\": \"xkaTw8nHlJPyfp3761fL00uB\", \"verifiedName\": \"RYAN CANU\", \"creditCheckFailedCount\": 0, \"autoPayEnrolled\": \"false\", \"repId\": \"ENC\", \"storeName\": \"ATLANTIC CITY COMM STORE\", \"loggedInUser\": \"chamasi\", \"isfiveGUpSellSelected\": false, \"processingMTN\": \"5402305402\", \"isDirectApply\": true, \"locationSubType\":\"RX\", \"rfexExchangeShopDetails\":\"{\\\"mtn\\\":\\\"4023600673\\\",\\\"returnItemSeq\\\":\\\"1\\\"}\" }";
        AddDeviceUIRequest UIRequest = mapper.readValue(requestFile, AddDeviceUIRequest.class);
        CartRedisData sampleRedisData = mapper.readValue(redisDataFile, CartRedisData.class);
        ServerHttpResponse httpResponse = Mockito.mock(ServerHttpResponse.class);
        URI url = URI.create("https://localhost/");
        MultiValueMap<String, HttpCookie> cookieMap = new LinkedMultiValueMap<>();
        List<HttpCookie> cookieList = new ArrayList<HttpCookie>();
        cookieList.add(new HttpCookie("name", "value"));
        cookieMap.put("iconicTestIntent", cookieList);
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).cookies(cookieMap).build();
        UIRequest.setHttpRequest(httpRequest);
        UIRequest.setChannelId("VZW-DOTCOM");
        UIRequest.getCartInfo().setZipCode("123456");
        UIRequest.getCartInfo().setIntendType("EUP");
        UIRequest.getCartInfo().setCaseId("SOF-12345");
        UIRequest.getCartInfo().setOneClick(true);
        UIRequest.getCartInfo().setDeviceType("CONNECTED_CAR");
        sampleRedisData.setIntendType("EUP");
        List<Lines> deviceLines=new ArrayList<Lines>();
        Lines l1=new Lines();
        l1.setRestricted("Restricted");
        deviceLines.add(l1);
        sampleRedisData.setDeviceLines(deviceLines);
        UIRequest.getData().setLines(null);
        accDevHelper1.setRestrictedFromRedisToRequest(sampleRedisData,UIRequest);

        //UIRequest.getData().getLines().get(0).setRestricted();

    }

    @Test
    public void addUpgradeDetailsHelperExistingCaseTest() throws IOException, SOEHTTPException {
        String requestFile ="{ \"cartInfo\": { \"cartId\": \"\", \"caseId\": \"\", \"accountNumber\": \"\", \"cartCreator\": \"\", \"processingMTN\": \"2513678339\", \"processStep\": \"GridWallPDP\", \"processAction\": \"ExpressUpgrade\", \"intendType\": \"EUP\", \"isTradeInSelected\": false, \"disableMyLink\": false, \"editDevice\": false, \"expressCheckout\": null, \"noPendingOfferExists\": false, \"isPromoPDP\": false, \"mtnFlow\": \"M\", \"myvPage\": true }, \"data\": { \"lines\": [ { \"isCommonPDP\": true, \"mtn\": \"2513678339\", \"purchasePath\": \"EUP\", \"portInNumber\": \"\", \"eupNoPromoFlow\": false, \"editSim\":false, \"device\": { \"id\": \"SMS926UZAV\", \"contractTerm\": \"VERIZON_EDGE\", \"iconicPhone\": false, \"dppMonths\": 36, \"productId\": \"dev21411193\", \"category\": \"Smartphones\", \"preconfigure\": false }, \"sim\": { \"id\": \"DFILLUNIV5G-SA-A\" }, \"ispuFlow\": false, \"estimatedReadyByDate\": \"\", \"depletionLocationCode\": \"\", \"depletionType\": \"F\", \"isKeepingExistingEqProtection\": true, \"newLineOrAAL\": false, \"isNewLine\": false, \"selectedPromoId\": \"promo4393822\", \"selectedPromoType\": \"TRADEIN_PROMO\", \"promoRejectionIndicator\": false, \"isIconicPhone\": false, \"selectedSedOfferId\": \"\", \"selectedSpoId\": \"\", \"isStrategicOffer\": false, \"restricted\": \"\", \"isTradeInIntentSelected\": true, \"tradeInInfo\": { \"deviceBrand\": \"\", \"deviceModel\": \"\", \"aemOfferIds\": [], \"tradeinMarketingId\": \"\" } } ], \"rtm\": { \"url\": \"https://vzwqa30.verizonwireless.com/smartphones/samsung-galaxy-s24-plus/\", \"img\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e2-marblegray\", \"name\": \"Galaxy S24+\", \"make\": \"Samsung\", \"categoryId\": \"Smartphones\", \"pageURL\": \"https://vzwqa30.verizonwireless.com/smartphones/samsung-galaxy-s24-plus/\" }, \"enableFcc\": true } }";
        String responseFile = "{ \"serviceHeader\": { \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\", \"correlationId\": \"soe-cart-2024.09.03.19.10.54-632.8554115171785\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"contextInfo\": { \"availablePaths\": [ { \"path\": \"PromoHub\" } ], \"skipCheckoutCall\": false, \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"PromoHub\", \"processAction\": \"\" }, \"customerInfo\": { \"nocByod\": false, \"cartCreator\": \"2185562351\", \"processingMTN\": \"2185562351\", \"registerNumber\": 0, \"number_share_capable\": \"\", \"e911_addr_ind\": \"\", \"existingCase\": \"false\", \"noc\": false, \"myvPage\": false }, \"cartInfo\": { \"financeLimitExceeded\": \"false\", \"cartItemCount\": 1, \"statusMsg\": \"Success\", \"statusCode\": \"1\", \"lines\": [ { \"status\": 1, \"spos\": [ { \"id\": \"384\", \"actionIndicator\": \"D\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] }, { \"id\": \"1255\", \"conflict\": \"SPO1 Did Not Requalify\", \"actionIndicator\": \"D\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] }, { \"id\": \"732\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] }, { \"id\": \"1256\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] }, { \"id\": \"1692\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] }, { \"id\": \"1801\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] }, { \"id\": \"1958\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] }, { \"id\": \"2107\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] }, { \"id\": \"2719\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] }, { \"id\": \"2740\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] }, { \"id\": \"2743\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] }, { \"id\": \"2780\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] }, { \"id\": \"2826\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] }, { \"id\": \"2884\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] } ], \"sfos\": [ { \"id\": \"76404\", \"conflict\": \"Add SFO due to missing required parent\", \"actionIndicator\": \"A\", \"displayHumWiFi\": false }, { \"id\": \"78485\", \"conflict\": \"Drop SFO due to mandatory feat conflict\", \"actionIndicator\": \"D\", \"displayHumWiFi\": false }, { \"id\": \"83856\", \"conflict\": \"Add SFO due to missing DACC SFO Sequence\", \"actionIndicator\": \"A\", \"displayHumWiFi\": false }, { \"id\": \"86848\", \"conflict\": \"Add SFO due to missing DACC SFO Sequence\", \"actionIndicator\": \"A\", \"displayHumWiFi\": false }, { \"id\": \"88888\", \"actionIndicator\": \"A\", \"displayHumWiFi\": false }, { \"id\": \"88984\", \"actionIndicator\": \"A\", \"displayHumWiFi\": false }, { \"id\": \"89405\", \"actionIndicator\": \"A\", \"displayHumWiFi\": false }, { \"id\": \"89671\", \"conflict\": \"SFO dropped because of requal - PPlan ch\", \"actionIndicator\": \"D\", \"displayHumWiFi\": false }, { \"id\": \"89673\", \"conflict\": \"SFO dropped because of requal - PPlan ch\", \"actionIndicator\": \"D\", \"displayHumWiFi\": false }, { \"id\": \"90051\", \"actionIndicator\": \"A\", \"displayHumWiFi\": false }, { \"id\": \"90052\", \"conflict\": \"Add SFO due to missing required parent\", \"actionIndicator\": \"A\", \"displayHumWiFi\": false } ], \"firstMonthInstallment\": 22.29, \"monthlyInstallment\": 22.22, \"reasonCode\": \"PLAN_DEVICE_COMPATIBLE\", \"selectedPromoType\": \"TRADEIN_PROMO\", \"eupNoPromoFlow\": false, \"lineSubscriptionInfos\": [], \"featureMessages\": [ { \"name\": \"5GUWBBOLT\", \"action\": \"ADD\" }, { \"name\": \"5GCOREPROV\", \"action\": \"ADD\" } ], \"mtn\": \"2185562351\", \"device\": { \"upgradeReasonCode\": \"EA\", \"id\": \"SMS921UZYV\", \"installmentTerm\": \"0\", \"itemPrice\": \"799.99\", \"finalPrice\": \"0.0\", \"discountAmount\": \"0.0\", \"qty\": 1, \"edgeUpEnabled\": false, \"numberShareEnabled\": false, \"existingDeviceName\": \"Galaxy S24\", \"fiveGToFourGDownGrade\": false, \"byodESimPhone\": false, \"skipImei1Call\": false, \"amount\": 0.0, \"isNonVZDeviceSku\": false, \"skuId\": \"sku6010127\", \"skuDisplayName\": \"Samsung Galaxy S24 128GB in Amber Yellow\", \"isDfoSelected\": false }, \"sim\": { \"id\": \"DFILLUNIV5G-SA-A\" }, \"warranty\": { \"itemPrice\": \"0.0\" }, \"upgradeFee\": { \"qty\": 1, \"itemPrice\": \"35\" }, \"devicePlanCompatible\": true, \"planValidationFailed\": false, \"lineActivityType\": \"EUP\", \"currentPlanType\": \"LLP\", \"planQualifiedForPromotion\": false, \"fiveGUpSell\": false, \"is5GBoltEligible\": false, \"fiveGPlanAdded\": false, \"editSim\": false, \"lineWithSkipMDN\": false, \"inWithVerizonOpted\": false, \"protectionNotRequired\": false, \"skipPromoChoiceOffer\": false } ], \"expressCheckout\": false, \"effectiveDateDetails\": { \"suggestedBackDate\": \"\", \"suggestedFutureDate\": \"\", \"currentBillCycleBeginDate\": \"\", \"nextBillCycleBeginDate\": \"\", \"onDemandDate\": \"\", \"onDemandRangeInDays\": \"\", \"selectedDate\": \"\" }, \"preAuthSuccess\": false, \"promoLossIndicator\": false, \"monthlyCreditAmount\": \"0.0\", \"agreementNumber\": \"0\", \"vztDiscountGain\": false, \"vztDiscountLoss\": false, \"discountPromoTotal\": 0.0, \"registerNumber\": 0, \"hasMixAndMatchPlan\": false, \"oneBillEnrolled\": false, \"protectionNotRequired\": false, \"fmiCheck\": false, \"isFlexV2\": false, \"isPrepaidToPostpaidMigration\": false, \"instantCreditAmount\": 0, \"ngdFlow\": false }, \"processMTNList\": [ { \"mtn\": \"2185562351\", \"completedprocessSteps\": [] } ] } } }, \"featureConfigurationProfileData\": { \"expressUpgradeFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"eupPromoRestructureFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"oneClkDppSummaryFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"offerFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"bauUpgradeFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"enableGiftingFeature\": [ \"true\" ], \"enableAccMemberMigration\": [ \"true\" ], \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"oneUnlimitedFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } } } }";
        String redisDataFile = "{ \"cartId\": \"gsf5g-uhdye9-rhe7fh-jfufhe8\", \"caseId\": \"SOP-6849878-E01\", \"accountNumber\": \"0216897840-00001\", \"mtn\": \"5402305402\", \"cartCreator\": \"5402305402\", \"cartCount\": \"1\", \"cartOrderFlowType\": \"eup\", \"locationCode\": \"0026301\", \"storeLocationState\": \"NJ\", \"customerAddressState\": \"VA\", \"isSmartphone\": false, \"isAppleDevice\": false, \"safeTechSessionId\": \"xkaTw8nHlJPyfp3761fL00uB\", \"verifiedName\": \"RYAN CANU\", \"creditCheckFailedCount\": 0, \"autoPayEnrolled\": \"false\", \"repId\": \"ENC\", \"storeName\": \"ATLANTIC CITY COMM STORE\", \"loggedInUser\": \"chamasi\", \"isfiveGUpSellSelected\": false, \"processingMTN\": \"5402305402\", \"isDirectApply\": true, \"locationSubType\":\"RX\", \"rfexExchangeShopDetails\":\"{\\\"mtn\\\":\\\"4023600673\\\",\\\"returnItemSeq\\\":\\\"1\\\"}\" }";
        AddDeviceUIRequest UIRequest = mapper.readValue(requestFile, AddDeviceUIRequest.class);
        AddDeviceUIResponse responseServiceMono = mapper.readValue(responseFile, AddDeviceUIResponse.class);
        CartRedisData sampleRedisData = mapper.readValue(redisDataFile, CartRedisData.class);
        ServerHttpResponse httpResponse = Mockito.mock(ServerHttpResponse.class);
        URI url = URI.create("https://localhost/");
        MultiValueMap<String, HttpCookie> cookieMap = new LinkedMultiValueMap<>();
        List<HttpCookie> cookieList = new ArrayList<HttpCookie>();
        cookieList.add(new HttpCookie("name", "value"));
        cookieMap.put("iconicTestIntent", cookieList);
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).cookies(cookieMap).build();
        UIRequest.setHttpRequest(httpRequest);
        UIRequest.setChannelId("VZW-DOTCOM");
        when(redisHelper2.getRole()).thenReturn(Mono.just("role"));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.getEdgeBuyoutRedisData()).thenReturn(Mono.just(new HashMap()));

        when(bpmHelper.addUpgradeDetails(Mockito.any())).thenReturn(Mono.just(responseServiceMono));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(preHandleAddDevice.execute(UIRequest, sampleRedisData)).thenReturn(Mono.just(Boolean.TRUE));

        UIRequest.getCartInfo().setProcessingMTN("");
        sampleRedisData.setProcessingMTN("123456789");
        Mono<AddDeviceUIResponse> response0 = accDevHelper1.addUpgradeDetails(UIRequest,sampleRedisData,httpResponse);
        StepVerifier.create(response0).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest.getCartInfo().setProcessingMTN("");
        sampleRedisData.setProcessingMTN("");
        Mono<AddDeviceUIResponse> response00 = accDevHelper1.addUpgradeDetails(UIRequest,sampleRedisData,httpResponse);
        StepVerifier.create(response00).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest.getCartInfo().setProcessingMTN("123456789");
        sampleRedisData.setProcessingMTN("123456789");
        Mono<AddDeviceUIResponse> response000 = accDevHelper1.addUpgradeDetails(UIRequest,sampleRedisData,httpResponse);
        StepVerifier.create(response000).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest.getCartInfo().setMtnFlow("");
        sampleRedisData.setMtnFlow("M");
        Mono<AddDeviceUIResponse> response11 = accDevHelper1.addUpgradeDetails(UIRequest,sampleRedisData,httpResponse);
        StepVerifier.create(response11).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest.getCartInfo().setMtnFlow("");
        sampleRedisData.setMtnFlow("");
        Mono<AddDeviceUIResponse> response12 = accDevHelper1.addUpgradeDetails(UIRequest,sampleRedisData,httpResponse);
        StepVerifier.create(response12).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest.getCartInfo().setMtnFlow("M");
        sampleRedisData.setMtnFlow("M");
        Mono<AddDeviceUIResponse> response13 = accDevHelper1.addUpgradeDetails(UIRequest,sampleRedisData,httpResponse);
        StepVerifier.create(response13).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        sampleRedisData.setVzwRoles("");
        Mono<AddDeviceUIResponse> response21 = accDevHelper1.addUpgradeDetails(UIRequest,sampleRedisData,httpResponse);
        StepVerifier.create(response21).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        sampleRedisData.setVzwRoles("AH");
        Mono<AddDeviceUIResponse> response22 = accDevHelper1.addUpgradeDetails(UIRequest,sampleRedisData,httpResponse);
        StepVerifier.create(response22).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest.getCartInfo().setIntendType("");
        sampleRedisData.setIntendType("EUP");
        Mono<AddDeviceUIResponse> response31 = accDevHelper1.addUpgradeDetails(UIRequest,sampleRedisData,httpResponse);
        StepVerifier.create(response31).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest.getCartInfo().setIntendType("");
        sampleRedisData.setIntendType("");
        Mono<AddDeviceUIResponse> response32 = accDevHelper1.addUpgradeDetails(UIRequest,sampleRedisData,httpResponse);
        StepVerifier.create(response32).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest.getCartInfo().setIntendType("EUP");
        sampleRedisData.setIntendType("EUP");
        Mono<AddDeviceUIResponse> response33 = accDevHelper1.addUpgradeDetails(UIRequest,sampleRedisData,httpResponse);
        StepVerifier.create(response33).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        sampleRedisData.setVzId("");
        Mono<AddDeviceUIResponse> response41 = accDevHelper1.addUpgradeDetails(UIRequest,sampleRedisData,httpResponse);
        StepVerifier.create(response41).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        sampleRedisData.setVzId("SAMPLE");
        Mono<AddDeviceUIResponse> response42 = accDevHelper1.addUpgradeDetails(UIRequest,sampleRedisData,httpResponse);
        StepVerifier.create(response42).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest.getCartInfo().setIsComboOrderAllowed(null);
        sampleRedisData.setIsComboOrderAllowed("true");
        Mono<AddDeviceUIResponse> response51 = accDevHelper1.addUpgradeDetails(UIRequest,sampleRedisData,httpResponse);
        StepVerifier.create(response51).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest.getCartInfo().setIsComboOrderAllowed(null);
        sampleRedisData.setIsComboOrderAllowed(null);
        Mono<AddDeviceUIResponse> response52 = accDevHelper1.addUpgradeDetails(UIRequest,sampleRedisData,httpResponse);
        StepVerifier.create(response52).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest.getCartInfo().setIsComboOrderAllowed(null);
        sampleRedisData.setIsComboOrderAllowed("true");
        Mono<AddDeviceUIResponse> response53 = accDevHelper1.addUpgradeDetails(UIRequest,sampleRedisData,httpResponse);
        StepVerifier.create(response53).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        UIRequest.getCartInfo().setIsComboOrderAllowed(null);
        sampleRedisData.setIsComboOrderAllowed("false");
        Mono<AddDeviceUIResponse> response54 = accDevHelper1.addUpgradeDetails(UIRequest,sampleRedisData,httpResponse);
        StepVerifier.create(response54).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        sampleRedisData.setExistingCase("true");
        Mono<AddDeviceUIResponse> response1 = accDevHelper1.addUpgradeDetails(UIRequest,sampleRedisData,httpResponse);
        StepVerifier.create(response1).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        List<Lines> lines = new ArrayList<>();
        Lines line = new Lines();
        line.setRestricted("Y");
        line.setRestrictedProductType("EQP");
        lines.add(line);
        sampleRedisData.setDeviceLines(lines);
        UIRequest.getData().getLines().get(0).setRestrictedProductType(null);
        UIRequest.getData().getLines().get(0).setRestricted(null);
        Mono<AddDeviceUIResponse> response2 = accDevHelper1.addUpgradeDetails(UIRequest,sampleRedisData,httpResponse);
        StepVerifier.create(response2).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }


    @Test
    public void setIconicTestIntentInRequestTest() throws IOException, SOEHTTPException{
        String requestFile = "addUpgradeDetailsRequest.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        MultiValueMap<String, HttpCookie> cookieMap = new LinkedMultiValueMap<>();
        List<HttpCookie> cookieList = new ArrayList<HttpCookie>();
        cookieList.add(new HttpCookie("name", "value"));
        cookieMap.put("iconicTestIntent", cookieList);
        AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        URI url = URI.create("https://localhost/");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).cookies(cookieMap).build();
        UIRequest.setHttpRequest(httpRequest);
        UIRequest.setChannelId("VZW-DOTCOM");
        String newString = "{\"throttleList\": \"cowtowncoder|test\"}";
        JsonNode cradleOutputJsonNode = mapper.readTree(newString);
        accDevHelper1.setIconicTestIntentInRequest(UIRequest,cradleOutputJsonNode,"test");
        accDevHelper1.setIconicTestIntentInRequest(UIRequest,cradleOutputJsonNode,"test1");
    }

    @Test
    public void setIconicTestIntentInRequestTest1() throws IOException, SOEHTTPException{
        String requestFile = "addUpgradeDetailsRequest.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        MultiValueMap<String, HttpCookie> cookieMap = new LinkedMultiValueMap<>();
        List<HttpCookie> cookieList = new ArrayList<HttpCookie>();
        cookieList.add(new HttpCookie("name", "value"));
        cookieMap.put("iconicTestIntent", cookieList);
        AddDeviceUIRequest UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        URI url = URI.create("https://localhost/");
        MockServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).cookies(cookieMap).build();
        UIRequest.setHttpRequest(httpRequest);
        UIRequest.setChannelId("VZW-DOTCOM");
        String newString = "{\"throttleList\": \"\"}";
        JsonNode cradleOutputJsonNode = mapper.readTree(newString);
        accDevHelper1.setIconicTestIntentInRequest(UIRequest,cradleOutputJsonNode,"test");

        accDevHelper1.setIconicTestIntentInRequest(UIRequest,null,"test");

        Assert.assertNotNull(UIRequest.getData());
    }


    @Test
    public void updateSubFLowTagging_Subflow_contains_NEXTGENAndCradleFLowJourney_NOTNextGenTest() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"reqfrompromopdp\":true,\"intendType\":\"NSEBYOD\"},\"data\":{\"subFlow\":\"Nxtgen-BYOD-C\",\"lines\":[{\"device\":{\"category\":\"\"}}]}}";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse pegaResponse  = new  AddDeviceUIResponse();
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1858878952-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryInterestial\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryInterestial\",\"processAction\":\"\",\"cradleFlowJourney\":\"ACCESSORYINterstitial\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\"},\"cartInfo\":{\"financeLimitExceeded\":\"true\",\"cartItemCount\":1,\"totalDueToday\":54.25,\"totalDueMonthly\":0.0,\"cartId\":\"a144d317-de87-468e-88ee-a5e223fdf152\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":19.59,\"monthlyInstallment\":19.44,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MLA23LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"699.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 13\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC|nxtgen"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));

        Mono<Boolean> res= accDevHelper1.updateSubFlowInTaggingForNextgen(cdlThrottlist, response, request);
        StepVerifier.create(res).assertNext( resp-> junit.framework.Assert.assertTrue(resp)).expectComplete()
                .verify();

    }@Test
    public void updateSubFlowInTaggingForByodRecTest() throws JsonProcessingException {
        String requestString = "{\"cartInfo\": {\"reqfrompromopdp\": true},\"data\": {\"lines\": [{\"device\": {\"category\": \"\"}}]}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        request.getData().setIsByodRecFlow(true);
        request.getCartInfo().setIntendType("NSE");
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1858878952-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryInterestial\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryInterestial\",\"processAction\":\"\",\"cradleFlowJourney\":\"ACCESSORYINterstitial\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\"},\"cartInfo\":{\"financeLimitExceeded\":\"true\",\"totalDueToday\":54.25,\"totalDueMonthly\":0.0,\"cartId\":\"a144d317-de87-468e-88ee-a5e223fdf152\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":19.59,\"monthlyInstallment\":19.44,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MLA23LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"699.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 13\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}";
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        ArrayList<String> subFlowList = new ArrayList<>();
        subFlowList.add(CartConstants.NXT_GEN_BYOD);
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<Boolean> res= accDevHelper1.updateSubFlowInTaggingForNextgenBYOD(response, request, subFlowList);
        StepVerifier.create(res).assertNext(Assert::assertNotNull).expectComplete()
                .verify();
        request.getCartInfo().setIntendType("AAL");
        res= accDevHelper1.updateSubFlowInTaggingForNextgenBYOD(response, request, subFlowList);
        StepVerifier.create(res).assertNext(Assert::assertNotNull).expectComplete()
                .verify();
        request.getData().setIsByodRecFlow(false);
        res= accDevHelper1.updateSubFlowInTaggingForNextgenBYOD(response, request, subFlowList);
        StepVerifier.create(res).assertNext(Assert::assertNotNull).expectComplete()
                .verify();
        request.getData().setIsByodRecFlow(null);
        res= accDevHelper1.updateSubFlowInTaggingForNextgenBYOD(response, request, subFlowList);
        StepVerifier.create(res).assertNext(Assert::assertNotNull).expectComplete()
                .verify();
        request.setData(null);
        res= accDevHelper1.updateSubFlowInTaggingForNextgenBYOD(response, request, subFlowList);
        StepVerifier.create(res).assertNext(Assert::assertNotNull).expectComplete()
                .verify();
    }

    @Test
    public void updateSubFlowForOneClickExpressUpgradeTest()
    {
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        Mono<Boolean> response = accDevHelper1.updateSubFlowForOneClickExpressUpgrade(request);
        StepVerifier.create(response).assertNext(Assert::assertNotNull).expectComplete()
                .verify();
    }
    @Test
    public void logDataInfoTest()
    {
        String input = "test";
        accDevHelper1.logDataInfo(input,null);
        Assertions.assertEquals(input,"test");
    }
    @Test
    public void setCradleFlagForComboTest()
    {
        Mono<Boolean> cradleResponse = mock(Mono.class);
        AddDeviceUIRequest request = new AddDeviceUIRequest();

        DeviceCartInfo deviceCartInfo = new DeviceCartInfo();
        deviceCartInfo.setIntendType("test");
        request.setCartInfo(deviceCartInfo);
        accDevHelper1.setCradleFlagForCombo(cradleResponse,request);

        deviceCartInfo.setIntendType("AAL_BYOD");
        accDevHelper1.setCradleFlagForCombo(cradleResponse,request);

        deviceCartInfo.setIntendType("EUPBYOD");
        accDevHelper1.setCradleFlagForCombo(cradleResponse,request);

        deviceCartInfo.setIntendType("BYOD");
        accDevHelper1.setCradleFlagForCombo(cradleResponse,request);

        deviceCartInfo.setIntendType("EUP");
        accDevHelper1.setCradleFlagForCombo(cradleResponse,request);

        deviceCartInfo.setIntendType("AAL");
        accDevHelper1.setCradleFlagForCombo(cradleResponse,request);

        deviceCartInfo.setIntendType("AAL_LTE");
        accDevHelper1.setCradleFlagForCombo(cradleResponse,request);

        deviceCartInfo.setIntendType("AAL_5G");
        Mono<AddDeviceUIRequest> resp = accDevHelper1.setCradleFlagForCombo(cradleResponse,request);
        StepVerifier.create(resp).assertNext(Assertions::assertNotNull);

    }

    @Test
    public void updateFinalSubFlowWithTradeInPromoTest() {
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        AddDeviceData addDeviceData = new AddDeviceData();
        addDeviceData.setEntryFlow("mf");
        addDeviceData.setEntryPoint("PDP");
        request.setData(addDeviceData);

        List<String> finalSubFlowList = new ArrayList<>();
        List<String> subFlowList = new ArrayList<>();


        when(featureFlagHelper.isOneclkTaggingFFlagEnabled())
                .thenReturn(false);

        accDevHelper1.updateFinalSubFlow(finalSubFlowList, subFlowList, "TRADEIN_PROMO", true, true, request);
        Assert.assertEquals(finalSubFlowList.size(), 1);
    }


    @Test
    public void updateFinalSubFlowWithBICPromoTest() {
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        AddDeviceData addDeviceData = new AddDeviceData();
        addDeviceData.setEntryFlow("mf");
        addDeviceData.setEntryPoint("PDP");
        request.setData(addDeviceData);

        List<String> finalSubFlowList = new ArrayList<>();
        List<String> subFlowList = new ArrayList<>();


        when(featureFlagHelper.isOneclkTaggingFFlagEnabled())
                .thenReturn(false);

        accDevHelper1.updateFinalSubFlow(finalSubFlowList, subFlowList, "BIC", true, true, request);
        Assert.assertEquals(finalSubFlowList.size(), 1);
    }

    @Test
    public void updateFinalSubFlowIclickCTest() {
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        AddDeviceData addDeviceData = new AddDeviceData();
        addDeviceData.setEntryFlow("df");
        addDeviceData.setEntryPoint("PDP");
        request.setData(addDeviceData);
        DeviceCartInfo deviceCartInfo = new DeviceCartInfo();
        deviceCartInfo.setProcessAction("addDeviceWithTradeIn");
        request.setCartInfo(deviceCartInfo);
        List<String> finalSubFlowList = new ArrayList<>();
        List<String> subFlowList = new ArrayList<>();

        accDevHelper1.updateFinalSubFlow(finalSubFlowList, subFlowList, "BIC", true, true, request);
        Assert.assertEquals(finalSubFlowList.size(), 3);
    }

    @Test
    public void updateFinalSubFlowIclickTTest() {
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        AddDeviceData addDeviceData = new AddDeviceData();
        addDeviceData.setEntryFlow("mf");
        addDeviceData.setEntryPoint("PDP");
        request.setData(addDeviceData);
        DeviceCartInfo deviceCartInfo = new DeviceCartInfo();
        deviceCartInfo.setProcessAction("ExpressUpgrade");
        request.setCartInfo(deviceCartInfo);
        List<String> finalSubFlowList = new ArrayList<>();
        List<String> subFlowList = new ArrayList<>();

        accDevHelper1.updateFinalSubFlow(finalSubFlowList, subFlowList, "BIC", true, true, request);
        Assert.assertEquals(finalSubFlowList.size(), 3);
        deviceCartInfo.setProcessAction("ExpressUpgrade1");
        finalSubFlowList.clear();
        accDevHelper1.updateFinalSubFlow(finalSubFlowList, subFlowList, "BIC", true, true, request);
        Assert.assertEquals(finalSubFlowList.size(), 3);
    }
}

