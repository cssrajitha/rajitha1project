package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import onevz.aem.errorhandling.aem.model.CreditErrorContent;
import onevz.aem.errorhandling.service.CreditExceptionDatastoreClient;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.gql.schema.WFMOrderInfo;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.helper.RedisHelper2;
import onevz.soe.cart.helper.RedisHelper3;
import onevz.soe.cart.initiatecart.CpcFeatureResponse;
import onevz.soe.cart.model.addDevice.FiveGAddress;
import onevz.soe.cart.model.addDevice.ShowAALPromoIntercept;
import onevz.soe.cart.model.common.Address;
import onevz.soe.cart.model.common.ConflictedSFOs;
import onevz.soe.cart.model.common.ConflictedSPOs;
import onevz.soe.cart.model.common.FiveG.FiveGLTEAddressRedis;
import onevz.soe.cart.model.createLine.HomeSalesAddress;
import onevz.soe.cart.model.deviceIdValidation.DeviceInfo;
import onevz.soe.cart.model.deviceIdValidation.SimInfo;
import onevz.soe.cart.model.deviceSimValidation.DeviceSimValidationUIResponseData;
import onevz.soe.cart.model.initiateCbandCheck.InitiateCbandCheckResponseData;
import onevz.soe.cart.model.initiateCbandCheck.VmasBootUpInfo;
import onevz.soe.cart.model.initiateDeviceSimActivation.IntiateDeviceSimActivationUIRequest;
import onevz.soe.cart.model.initiateESimActivation.InitiateESimActivationUIResponse;
import onevz.soe.cart.model.retrieveCart.*;
import onevz.soe.cart.model.validateCart.CXPValidateCartDataVO;
import onevz.soe.cart.requests.DualNumberRedisInfo;
import onevz.soe.cart.requests.MvoRequest;
import onevz.soe.cart.requests.RetrieveCartCXPRequest;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.common.AddDeviceData;
import onevz.soe.cart.ui.common.DeviceCartInfo;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.InitiateCheckoutUIResponse;
import onevz.soe.cart.ui.responses.RetrieveCartUIResponse;
import onevz.soe.cart.ui.responses.ValidateCartUIResponse;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.fraud.client.SOEMtnExpireClient;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.session.client.model.AccountInfoEligible;
import onevz.soe.session.constants.SessionConstants;
import org.junit.Assert;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.util.*;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { CartServiceTestConfig.class })
//@WebFluxTest(RedisHelper.class)
public class RedisHelperTest {
	@MockBean
	SOELoginSessionBean sessionBean;
	@Mock
	CreditExceptionDatastoreClient creditDatastoreClient;
	@Mock
	SOEMtnExpireClient soeMtnExpireClient;
	@Autowired
	RedisHelper redisHelper;
	@Autowired
	RedisHelper2 redisHelper2;
	@Autowired
	RedisHelper3 redisHelper3;
	@Autowired
	ObjectMapper mapper;
	@Autowired
	SourceFileReaderUtil sourceFileReaderUtil;
	@Value("${onevz.soe.cart.test.fileLocation}")
	private String testFileLocation;

	String requestString = "{\"cartId\":\"df962b52-8d77-4f79-b73f-d8777d44b276\",\"caseId\":\"SOP-1023325-E01\",\"intendType\":\"EUP\",\"lines\":[{\"preBackOrderDate\":\"04-30-2020\",\"preBackOrderDisplayType\":\"Shipsby\",\"mtn\":\"8473096013\",\"device\":{\"id\":\"OPIN20190BKLR\",\"dppMonths\":24,\"contractTerm\":\"VERIZON_EDGE\",\"qty\":1},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false}],\"deviceCartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"df962b52-8d77-4f79-b73f-d8777d44b276\",\"caseId\":\"SOP-1023325-E01\",\"accountNumber\":\"0280363949-00001\",\"cartCreator\":\"8472046549\",\"processingMTN\":\"8473096013\",\"processStep\":\"GridWallPDP\",\"intendType\":\"EUP\",\"processAction\":\"addDevice\",\"editDevice\":false,\"intent\":\"NLG\"}}";


	public Map getSessionData() {
		String requestString = "{\"cartId\":\"df962b52-8d77-4f79-b73f-d8777d44b276\",\"caseId\":\"SOP-1023325-E01\",\"intendType\":\"EUP\",\"lines\":[{\"preBackOrderDate\":\"04-30-2020\",\"preBackOrderDisplayType\":\"Shipsby\",\"mtn\":\"8473096013\",\"device\":{\"id\":\"OPIN20190BKLR\",\"dppMonths\":24,\"contractTerm\":\"VERIZON_EDGE\",\"qty\":1},\"sim\":{\"id\":\"EMBD4GSIM-N\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false}],\"deviceCartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"df962b52-8d77-4f79-b73f-d8777d44b276\",\"caseId\":\"SOP-1023325-E01\",\"accountNumber\":\"0280363949-00001\",\"cartCreator\":\"8472046549\",\"processingMTN\":\"8473096013\",\"processStep\":\"GridWallPDP\",\"intendType\":\"EUP\",\"processAction\":\"addDevice\",\"editDevice\":false,\"intent\":\"NLG\"}}";
		String rfexExchangeShopDetailsString = "{\"mtn\" : \"654892298\",\"returnItemSeq\" : \"1\"}";

		Map intentTokenResponse = new HashMap<Object,Object>();
		Map sessionData = new HashMap<Object,Object>();
		sessionData.put(SessionConstants.ACCOUNT_NUMBER_KEY, "0480298581-00001");
		sessionData.put(SessionConstants.MTN_KEY, "9205726029");
		sessionData.put(CartConstants.CART_ID, "c4d4360d-3d96-4b37-95b8-dd12881b2fff");
		sessionData.put(CartConstants.CASE_ID, "SOP-119933-2");
		sessionData.put(CartConstants.PROCESSING_MTN, "9205726029");
		sessionData.put(CartConstants.CART_CREATOR, "9205726029");
		sessionData.put(CartConstants.FIVEG_UPSELL, "true");
		sessionData.put(CartConstants.ADD_DEVICE_REQUEST, requestString);
		sessionData.put(CartConstants.ADD_ACCESSORY_REQUEST, requestString);
		sessionData.put(CartConstants.RESTRICTED_PRODUCT_TYPE, "EQP");
		sessionData.put(CartConstants.IS_SMARTPHONE,"true");
		sessionData.put(CartConstants.BBP_ICCID,"89148000000835900458");
		sessionData.put(CartConstants.BBP_IMEI,"352898071702915");
		sessionData.put(CartConstants.RFEX_EXCHANGE_SHOP_DETAILS, rfexExchangeShopDetailsString);
		sessionData.put(CartConstants.INTENT_REDIS,"NLG");
		sessionData.put(CartConstants.IMEI,"33619_1655467826843_729");
		sessionData.put(CartConstants.Z1_OFFER_CODE,"33619_1655467826843_729");
		sessionData.put(CartConstants.SW_COUPON_CODE,"33619_1655467826843_729");
		sessionData.put(CartConstants.ROLE,"33619_1655467826843_729");
		sessionData.put(CartConstants.IS_VALID_CUSTOMER,"33619_1655467826843_729");
		sessionData.put(CartConstants.SAFETECH_SESSION_ID,"33619_1655467826843_729");
		sessionData.put(CartConstants.VZPH_REMOVED,"33619_1655467826843_729");
		sessionData.put(CartConstants.COMPLETED_CARTID_CONST,"33619_1655467826843_729");
		sessionData.put(CartConstants.COMPLETED_CASEID_CONST,"33619_1655467826843_729");
		sessionData.put(CartConstants.VERIFIED_NAME, "verifiedName");
		sessionData.put(CartConstants.RPS_INTENT, "rpsIntent");
		sessionData.put(CartConstants.INTEND_TYPE, "EUP");
		sessionData.put(CartConstants.INTENT_TYPE, "EUP");
		sessionData.put(CartConstants.FIOS_AUTHENTICATED, "");
		sessionData.put(SessionConstants.MTN_KEY, "8473096013");
		sessionData.put(SessionConstants.ACCOUNT_NUMBER_KEY, "8473096013");
		sessionData.put(CartConstants.CREDIT_APP_NUM, "");
		sessionData.put(CartConstants.AUTO_PAY_ENROLLED, "");
		sessionData.put(CartConstants.MTN_FLOW, "G");
		sessionData.put(CartConstants.CART_COUNT, "1");
		sessionData.put(CartConstants.CART_ORDER_FLOW_TYPE, "eup");
		sessionData.put(CartConstants.LOCATION_CODE, "0026301");
		sessionData.put(CartConstants.VZW_ROLES, "dre");
		sessionData.put(CartConstants.STORE_LOCATION_STATE, "NJ");
		sessionData.put(CartConstants.BILLING_STATE, "abc");
		sessionData.put(CartConstants.CUSTOMER_ADDRESS_STATE, "VA");
		sessionData.put(CartConstants.LINELEVEL_DIGITALSECURE_SUBSCRIPTION_COUNT, "");
		sessionData.put(CartConstants.DEVICETYPE_BBP, "");
		sessionData.put(CartConstants.BBP_IMEI2, "");
		sessionData.put(CartConstants.DEVID, "OPIN20190BKLR");
		sessionData.put(CartConstants.EID, "1234");
		sessionData.put(CartConstants.IS_PRE_QUALIFIED_NBX, "false");
		sessionData.put(CartConstants.CREDIT_CHECK_FAILURE_COUNTER, "0");
		sessionData.put(CartConstants.DEVICEID, "OPIN20190BKLR");
		sessionData.put(CartConstants.SUCCESS_URL, "randomValue");
		sessionData.put(CartConstants.EXTERNALID, "randomValue");
		sessionData.put(CartConstants.VZID, "randomValue");
		sessionData.put(SessionConstants.UNIVERSALID, "");
		sessionData.put(CartConstants.PROMO_MAX_COUNT, "randomValue");
		sessionData.put(CartConstants.PROMO_VALID_MAX_COUNT, "randomValue");
		sessionData.put(CartConstants.IS_DIRECT_APPLY, "true");
		sessionData.put(CartConstants.REP_ID, "ENC");
		sessionData.put(CartConstants.STORE_NAME, "ATLANTIC CITY COMM STORE");
		sessionData.put(CartConstants.LOGGEDINUSER, "chamasi");
		sessionData.put(CartConstants.MUC, "randomValue");
		sessionData.put(CartConstants.IMSI, "randomValue");
		sessionData.put(CartConstants.PROSPECT_CARTID, "randomValue");
		sessionData.put(CartConstants.PLAN_SIZE, "randomValue");
		sessionData.put(CartConstants.MARKET, "randomValue");
		sessionData.put(CartConstants.PREORDERINSERVICEDATE, "04-30-2020");
		sessionData.put(CartConstants.IS_PREPAY_CART, "true");
		sessionData.put(CartConstants.IS_MYLINK_AVAILABLE_FLAG, "true");
		sessionData.put(CartConstants.HIGH_RISK_MTN_LIST, new HashMap<>());
		/* intentTokenResponse
		intentTokenResponse.put(CartConstants.EID, "randomValue");
		intentTokenResponse.put(CartConstants.ICCID, "randomValue");
		intentTokenResponse.put(CartConstants.HAND_OFF_TOKEN, "randomValue");
		intentTokenResponse.put(CartConstants.IMEI2, "randomValue");
		intentTokenResponse.put(CartConstants.IMEI, "randomValue");
		intentTokenResponse.put(CartConstants.IMSI, "VZWCS-17115");
		intentTokenResponse.put(CartConstants.GIG, "randomValue");
		intentTokenResponse.put(CartConstants.INTENT_REDIS, "randomValue");*/
		String intentResponseString = "{\"imei2\":\"randomValue\",\"eid\":\"randomValue\",\"iccid\":\"randomValue\",\"gig\":\"randomValue\",\"imei\":\"randomValue\",\"imsi\":\"VZWCS-17115\",\"intent\":\"randomValue\",\"handOffToken\":\"randomValue\"}";
		sessionData.put(CartConstants.INTENT_TOKEN_RESPONSE,intentResponseString);

		sessionData.put(CartConstants.DIGITAL_IG_SESSION, "xkaTw8nHlJPyfp3761fL00uB");
		sessionData.put(CartConstants.BOGO_MTN, "randomValue");
		sessionData.put(CartConstants.SPO_MTN, "randomValue");
		sessionData.put(CartConstants.PREPAY_CUSTOMER_TYPE, "U");
		sessionData.put(CartConstants.FLOW, CartConstants.REFUND_EXC);
		sessionData.put(CartConstants.SOR_ID, "ARC-XCI55AX");
		sessionData.put(CartConstants.RECOMMENDATIONS_ACCESSORY_SOR_ID, "ACC-TEST");
		sessionData.put(CartConstants.RECOMMENDATIONS_DEVICE_SOR_ID, "DEV-TEST");
		sessionData.put(CartConstants.ADDRESS_QUALIFICATION_BY_MTN,"{\"data\":[{\"mtn\":\"6156305152\",\"netWorkBandwidthType\":\"CBD\",\"cBandQualified\":true},{\"mtn\":\"9142041798\",\"netWorkBandwidthType\":\"CBD\",\"cBandQualified\":true}]}");

		sessionData.put(CartConstants.COMBO_MOBILITY_CART_ID,"6820405a-b51e-40df-b823-7ae427ad8d16");
		sessionData.put(CartConstants.COMBO_MOBILITY_LOCATION_CODE,"0862001");
		sessionData.put(CartConstants.COMBO_MOBILITY_ORDER_ID,"993075714537472");
		sessionData.put(CartConstants.JOINT_TRANSACTION_MOBILE_CART_ID,"6820405a-b51e-40df-b823-7ae427ad8d16");
		sessionData.put(CartConstants.JOINT_TRANSACTION_MOBILE_CASE_ID,"SOP-14778113-C01");
		sessionData.put(CartConstants.BYOD_IMEI_DETAILS,"{\"imei1\":\"6156305152\",\"imei2\":\"1234\",\"iccid\":\"000\",\"eID\":\"1234\"}");
		sessionData.put(CartConstants.SAVE_CART_EMAILID,"test.tester@mail.com");
		sessionData.put(CartConstants.CART_ORDER_FLOW_TYPE,"eup");
		sessionData.put(CartConstants.CUST_TYPE,"EPP");
		sessionData.put(CartConstants.MAID,"maid");
		sessionData.put(CartConstants.UPC,"upc");
		sessionData.put(CartConstants.PRICE_ID,"priceId");
		sessionData.put(CartConstants.PAST_DUE, "{\"pastDueAccepted\":\"Y\",\"amount\":\"100\"}");
		return sessionData;
	}

	public String[] getSessionDataArr(){
		String[] sessionDataArr = new String[] { SessionConstants.MTN_KEY,
				SessionConstants.ACCOUNT_NUMBER_KEY, CartConstants.CART_ID, CartConstants.CASE_ID,
				CartConstants.PROCESSING_MTN, CartConstants.CART_CREATOR, CartConstants.FIVEG_UPSELL,
				CartConstants.ADD_DEVICE_REQUEST, CartConstants.ADD_ACCESSORY_REQUEST,
				CartConstants.RESTRICTED_PRODUCT_TYPE, CartConstants.MTN_FLOW, CartConstants.CART_COUNT,
				CartConstants.CART_ORDER_FLOW_TYPE, CartConstants.LOCATION_CODE, CartConstants.VZW_ROLES,
				CartConstants.RPS_INTENT, CartConstants.INTEND_TYPE, CartConstants.STORE_LOCATION_STATE,
				CartConstants.BILLING_STATE, CartConstants.CUSTOMER_ADDRESS_STATE,
				CartConstants.LINELEVEL_DIGITALSECURE_SUBSCRIPTION_COUNT,
				CartConstants.BBP_ICCID,CartConstants.BBP_IMEI,CartConstants.IS_SMARTPHONE ,
				CartConstants.CREDIT_APP_NUM,CartConstants.DEVICETYPE_BBP,CartConstants.BBP_IMEI2,CartConstants.DEVID,CartConstants.EID,CartConstants.IS_PRE_QUALIFIED_NBX,
				CartConstants.COMPLETED_CARTID_CONST,CartConstants.COMPLETED_CASEID_CONST,CartConstants.INTENT_TOKEN_RESPONSE,CartConstants.VERIFIED_NAME,
				CartConstants.Z1_OFFER_CODE,CartConstants.SW_COUPON_CODE,CartConstants.DIGITAL_IG_SESSION,CartConstants.DEVICEID,CartConstants.SUCCESS_URL,CartConstants.VZPH_REMOVED,
				CartConstants.AUTO_PAY_ENROLLED,CartConstants.EXTERNALID,CartConstants.PROMO_MAX_COUNT, CartConstants.PROMO_VALID_MAX_COUNT,CartConstants.SAFETECH_SESSION_ID , CartConstants.IS_DIRECT_APPLY, CartConstants.REP_ID, CartConstants.STORE_NAME, CartConstants.LOGGEDINUSER,CartConstants.PROSPECT_CARTID,CartConstants.INTENT_TYPE
				,CartConstants.BOGO_MTN,CartConstants.PLAN_SIZE,CartConstants.IMEI,CartConstants.MUC,
				CartConstants.RFEX_EXCHANGE_SHOP_DETAILS,CartConstants.INTENT_REDIS,CartConstants.MARKET,
				CartConstants.PREORDERINSERVICEDATE,CartConstants.VZID,CartConstants.SPO_MTN,CartConstants.FIOS_AUTHENTICATED,
				CartConstants.EVENTCORRELATIONID,CartConstants.IS_VALID_CUSTOMER,CartConstants.ROLE,CartConstants.IS_PREPAY_CART,SessionConstants.UNIVERSALID,CartConstants.PREPAY_CUSTOMER_TYPE,CartConstants.FLOW, CartConstants.ADDRESS_QUALIFICATION_BY_MTN,
				CartConstants.JOINT_TRANSACTION_MOBILE_CART_ID,CartConstants.MAID,CartConstants.REAL_AGENT_CODE, CartConstants.UPC ,CartConstants.JOINT_TRANSACTION_MOBILE_CASE_ID,CartConstants.BYOD_IMEI_DETAILS};

		return sessionDataArr;
	}

	@Test
	public void getDataFromRedisTest(){
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(getSessionData()));
		StepVerifier.create(redisHelper.getDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.getSessionData(Arrays.asList(getSessionDataArr()))).thenReturn(Mono.just(new HashMap()));
		StepVerifier.create(redisHelper.getDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		getSessionData().put(CartConstants.VZPH_REMOVED,null);
		getSessionData().put(CartConstants.COMPLETED_CARTID_CONST,null);
		getSessionData().put(CartConstants.COMPLETED_CASEID_CONST,null);
		getSessionData().put(CartConstants.CART_CREATOR,null);
		getSessionData().put(CartConstants.ADD_DEVICE_REQUEST,null);
		getSessionData().put(CartConstants.EID,null);
		getSessionData().put(CartConstants.IMSI,null);
		getSessionData().put(CartConstants.INTENT_TOKEN_RESPONSE,null);
		getSessionData().put(CartConstants.INTENT_REDIS,null);
		getSessionData().put(CartConstants.EID, null);
		getSessionData().put(CartConstants.ICCID, null);
		getSessionData().put(CartConstants.HAND_OFF_TOKEN, null);
		getSessionData().put(CartConstants.IMEI2, null);
		getSessionData().put(CartConstants.IMEI, null);
		getSessionData().put(CartConstants.IMSI, null);
		getSessionData().put(CartConstants.GIG, null);
		getSessionData().put(CartConstants.INTENT_REDIS, null);
		getSessionData().put(CartConstants.ADD_DEVICE_REQUEST, null);
		getSessionData().put(CartConstants.CCAR_WIFI_STATE,null);
		getSessionData().put(CartConstants.BRAND_NAME,null);
		getSessionData().put(CartConstants.PREPAY_CUSTOMER_TYPE, "U");
		getSessionData().put(CartConstants.FWA_CUSTOMERID_HASH,"TEST");
		getSessionData().put(CartConstants.FWA_CUSTOMERMTN_HASH, "TEST");
		getSessionData().put(CartConstants.FWA_ACCOUNTTYPE, "TEST");
		getSessionData().put(CartConstants.FLOW_NAME,null);
		when(sessionBean.getSessionData(Arrays.asList(getSessionDataArr()))).thenReturn(Mono.just(getSessionData()));
		StepVerifier.create(redisHelper.getDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		CartRedisData addDeviceRequest = new CartRedisData();
		when(sessionBean.getSessionData(Arrays.asList(getSessionDataArr()))).thenReturn(Mono.just(getSessionData()));
		StepVerifier.create(redisHelper.getDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		addDeviceRequest.setLines(Arrays.asList(new Lines(), new Lines(), new Lines()));
		addDeviceRequest.setJointTransactionMobileCartId("6820405a-b51e-40df-b823-7ae427ad8d16");
		addDeviceRequest.setJointTransactionMobileCaseId("SOP-14778113-C01");
		getSessionData().put(CartConstants.ADD_DEVICE_REQUEST,addDeviceRequest);
		getSessionData().put(CartConstants.CART_CREATOR,null);
		getSessionData().put(SessionConstants.MTN_KEY,null);
		getSessionData().put(CartConstants.IMSI,"");
		getSessionData().put(CartConstants.INTENT_REDIS,"nlg");
		getSessionData().put(CartConstants.EID, "");
		getSessionData().put(CartConstants.ICCID, "");
		getSessionData().put(CartConstants.HAND_OFF_TOKEN, "");
		getSessionData().put(CartConstants.IMEI2, "");
		getSessionData().put(CartConstants.IMEI, "");
		getSessionData().put(CartConstants.IMSI, "");
		getSessionData().put(CartConstants.GIG, "");
		getSessionData().put(CartConstants.COMBO_MOBILITY_CART_ID,"6820405a-b51e-40df-b823-7ae427ad8d16");
		getSessionData().put(CartConstants.COMBO_MOBILITY_LOCATION_CODE,"0862001");
		getSessionData().put(CartConstants.COMBO_MOBILITY_ORDER_ID,"993075714537472");
		getSessionData().put(CartConstants.JOINT_TRANSACTION_MOBILE_CART_ID,"6820405a-b51e-40df-b823-7ae427ad8d16");
		getSessionData().put(CartConstants.JOINT_TRANSACTION_MOBILE_CASE_ID,"SOP-14778113-C01");
		getSessionData().put(CartConstants.FLOW_NAME,"");
		when(sessionBean.getSessionData(Arrays.asList(getSessionDataArr()))).thenReturn(Mono.just(getSessionData()));
		StepVerifier.create(redisHelper.getDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getDataFromRedisNpnNxxErrorTest() throws JsonProcessingException {
		Map<String,String> redisMap = new HashMap<>();
		redisMap.put(CartConstants.NPANXX_LIST,"{{}");
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(redisMap));
		StepVerifier.create(redisHelper.getDataFromRedis()).expectError().verify();

	}
	@Test
	public void getMaidTest() throws JsonProcessingException {
		Map<String,String> redisMap = new HashMap<>();
		redisMap.put(CartConstants.REAL_AGENT_CODE,"realAgentCode");
		redisMap.put(CartConstants.MAID,"BBX");
		redisMap.put(CartConstants.UPC,"upc");
		redisMap.put(CartConstants.PRICE_ID,"priceId");
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(redisMap));
		StepVerifier.create(redisHelper.getDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}



	@Test
	public void getDataFromRedisNpnNxxTest() throws JsonProcessingException {
		Map<String,String> redisMap = new HashMap<>();
		redisMap.put(CartConstants.NPANXX_LIST,mapper.writeValueAsString(List.of("1234")));
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(redisMap));
		StepVerifier.create(redisHelper.getDataFromRedis()).expectError().verify();
	}


	@Test
	public void upsertDataIntoRedisAsStringForDeviceTest() throws JsonProcessingException{
		String redisFile = "MockAddDeviceHelperTestRedisData.json";
		String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
		CartRedisData cartRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		cartRedisData.setLines(Arrays.asList(new Lines(), new Lines(),new Lines(), new Lines()));
		cartRedisData.getLines().get(0).setRestrictedProductType("EQP");
		cartRedisData.setShowAALPromoIntercept(new ShowAALPromoIntercept());
		cartRedisData.setDeviceCartInfo(new DeviceCartInfo());
		cartRedisData.getDeviceCartInfo().setMtnFlow("G");
		cartRedisData.setDeviceSorId("OPIN20190BKLR");
		cartRedisData.setExistingCase("randomValue");
		cartRedisData.setRpsIntent("randomValue");
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper.upsertDataIntoRedisAsString(cartRedisData, "DEVICE")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(redisHelper.upsertDataIntoRedisAsString(new CartRedisData(), "accessory")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		cartRedisData.getDeviceCartInfo().setMtnFlow(null);
		cartRedisData.setDeviceSorId(null);
		StepVerifier.create(redisHelper.upsertDataIntoRedisAsString(cartRedisData, "DEVICE")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		cartRedisData.setDeviceCartInfo(null);
		StepVerifier.create(redisHelper.upsertDataIntoRedisAsString(cartRedisData, "DEVICE")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateDataIntoRedisAsStringTest() throws JsonProcessingException{
		CartRedisData cartRedisData = mapper.readValue(requestString, CartRedisData.class);
		cartRedisData.setLines(Arrays.asList(new Lines(), new Lines(),new Lines(), new Lines()));
		cartRedisData.getLines().get(0).setRestrictedProductType("EQP");
		cartRedisData.setShowAALPromoIntercept(new ShowAALPromoIntercept());
		cartRedisData.setDeviceCartInfo(new DeviceCartInfo());
		cartRedisData.getDeviceCartInfo().setMtnFlow("G");
		cartRedisData.setEcpdId("randomValue");
		cartRedisData.setProcessingMTN("8473096013");
		cartRedisData.setExistingCase("randomValue");
		cartRedisData.setIconicTestIntent("AAL_CBD_TECH");
		cartRedisData.setOneClickCheckout("radomValue");
		cartRedisData.setCartId("27a75fed-e393-46bf-a42c-87345a0a0536");
		cartRedisData.setOneClickCheckout("true");
		cartRedisData.setIntendType("EUP");
		cartRedisData.setDeviceSorIdForRecommendations("DEV-TEST");
		cartRedisData.setAccessorySorIdForRecommendations("ACC-TEST");
		cartRedisData.setDeviceCount("1");
		cartRedisData.setCartOrderFlowType("eup");
		cartRedisData.setMaid("BBX");


		Map map = new HashMap<String, String>();
		map.put("cartId", "123456789009876543211");
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper.updateDataIntoRedisAsString(cartRedisData, "DEVICE")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		cartRedisData.getLines().get(0).setRestrictedProductType(null);
		cartRedisData.setShowAALPromoIntercept(null);
		cartRedisData.getDeviceCartInfo().setMtnFlow(null);
		cartRedisData.setEcpdId(null);
		cartRedisData.setProcessingMTN(null);
		cartRedisData.setExistingCase(null);
		cartRedisData.setIconicTestIntent(null);
		cartRedisData.setOneClickCheckout(null);
		cartRedisData.setIntendType("NSEACC");
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper.updateDataIntoRedisAsString(cartRedisData, "DEVICE")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		cartRedisData.setLines(null);
		cartRedisData.setDeviceCartInfo(null);
		cartRedisData.setOneClickCheckout("false");
		cartRedisData.setIntendType("NSEACC");
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper.updateDataIntoRedisAsString(cartRedisData, "accessory")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(redisHelper.updateDataIntoRedisAsString(cartRedisData, "DEVICE")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		cartRedisData.setFiosAuthenticated(CartConstants.AUTHENTICATED);
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper.updateDataIntoRedisAsString(cartRedisData, "DEVICE")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		cartRedisData.setFiosAuthenticated(CartConstants.FALSE);
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper.updateDataIntoRedisAsString(cartRedisData, "DEVICE")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		cartRedisData.setIntendType(null);
		cartRedisData.setDeviceCount(null);
		when(sessionBean.setSessionData(any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper.updateDataIntoRedisAsString(cartRedisData, "")).verifyError();

	}
	@Test
	public void updateDataIntoRedisAsStringMASTest() throws JsonProcessingException {
		CartRedisData cartRedisData = mapper.readValue(requestString, CartRedisData.class);
		cartRedisData.setLines(Arrays.asList(new Lines(), new Lines(), new Lines(), new Lines()));
		cartRedisData.getLines().get(0).setRestrictedProductType("EQP");
		cartRedisData.getLines().get(0).setIsCommonPDP(true);
		cartRedisData.setShowAALPromoIntercept(new ShowAALPromoIntercept());
		cartRedisData.setDeviceCartInfo(new DeviceCartInfo());
		cartRedisData.getDeviceCartInfo().setMtnFlow("G");
		cartRedisData.setEcpdId("randomValue");
		cartRedisData.setProcessingMTN("8473096013");
		cartRedisData.setExistingCase("randomValue");
		cartRedisData.setIconicTestIntent("AAL_CBD_TECH");
		cartRedisData.setOneClickCheckout("radomValue");
		cartRedisData.setCartId("27a75fed-e393-46bf-a42c-87345a0a0536");
		cartRedisData.setOneClickCheckout("true");
		cartRedisData.setIntendType("EUP");
		cartRedisData.setDeviceSorIdForRecommendations("DEV-TEST");
		cartRedisData.setAccessorySorIdForRecommendations("ACC-TEST");
		cartRedisData.setDeviceCount("1");
		cartRedisData.setCartOrderFlowType("eup");
		cartRedisData.setMaid("BBX");


		Map map = new HashMap<String, String>();
		map.put("cartId", "123456789009876543211");
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper.updateDataIntoRedisAsString(cartRedisData, "DEVICE")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

		@Test
	public void updateCartIdAndCaseIdIntoRedisTest() throws JsonProcessingException{
		CartRedisData cartRedisData = mapper.readValue(requestString, CartRedisData.class);
		cartRedisData.setEcpdId("randomValue");
		cartRedisData.setExistingCase("randomValue");
		cartRedisData.setOneClickCheckout("radomValue");
		cartRedisData.setCartId("27a75fed-e393-46bf-a42c-87345a0a0536");
		cartRedisData.setDeviceCount("1");
		cartRedisData.setDualNumber(new DualNumber());
		cartRedisData.setTanglewoodSelected("newLine1");
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper.updateCartIdAndCaseIdIntoRedis(cartRedisData)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		Map map = new HashMap<String, String>();
		map.put("cartId", "123456789009876543211");
		map.put("caseId", "123456789009876543211");
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper.updateCartIdAndCaseIdIntoRedis(new CartRedisData())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		
		cartRedisData.setFiosAuthenticated(CartConstants.AUTHENTICATED);
		cartRedisData.setTanglewoodSelected("");
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper.updateCartIdAndCaseIdIntoRedis(new CartRedisData())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		cartRedisData.setFiosAuthenticated("TEST");
		cartRedisData.setTanglewoodSelected(null);
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper.updateCartIdAndCaseIdIntoRedis(new CartRedisData())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		
	}
	@Test
	public void updateCartIdAndCaseIdIntoRedisMASTest() throws JsonProcessingException {
		CartRedisData cartRedisData = mapper.readValue(requestString, CartRedisData.class);
		cartRedisData.setEcpdId("randomValue");
		cartRedisData.setExistingCase("randomValue");
		cartRedisData.setOneClickCheckout("radomValue");
		cartRedisData.setCartId("27a75fed-e393-46bf-a42c-87345a0a0536");
		cartRedisData.setDeviceCount("1");
		cartRedisData.setDualNumber(new DualNumber());
		cartRedisData.setTanglewoodSelected("newLine1");
		cartRedisData.setFiosAuthenticated("authenticated");
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper.updateCartIdAndCaseIdIntoRedis(cartRedisData)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void upsertAccountInfoEligibleInRedisTest() throws JsonMappingException, JsonProcessingException{
		String requestString = "{  \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",  \"caseId\" : \"SOP-1023325-E01\",  \"intendType\" : \"EUP\",  \"lines\" : [ {    \"preBackOrderDate\" : \"04-30-2020\",    \"preBackOrderDisplayType\" : \"Ships by\",    \"mtn\" : \"8473096013\",    \"device\" : {      \"id\" : \"OPIN20190BKLR\",      \"dppMonths\" : 24,      \"contractTerm\" : \"VERIZON_EDGE\",      \"qty\" : 1    },    \"sim\" : {      \"id\" : \"EMBD4GSIM-N\"    },    \"ispuFlow\" : false,    \"depletionLocationCode\" : \"\",    \"depletionType\" : \"F\",    \"isKeepingExistingEqProtection\" : true,    \"isNewLine\" : false  } ],  \"deviceCartInfo\" : {    \"clientAppName\" : \"VZW-ECOM\",    \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",    \"caseId\" : \"SOP-1023325-E01\",    \"accountNumber\" : \"0280363949-00001\",    \"cartCreator\" : \"8472046549\",    \"processingMTN\" : \"8473096013\",    \"processStep\" : \"GridWallPDP\",    \"intendType\" : \"EUP\",    \"processAction\" : \"addDevice\",    \"editDevice\" : false  }}";
		AccountInfoEligible accountInfoEligible = mapper.readValue(requestString, AccountInfoEligible.class);
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.upsertAccountInfoEligibleInRedis(accountInfoEligible, "123456789009876543211","123456789009876543211")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(redisHelper2.upsertAccountInfoEligibleInRedis(new AccountInfoEligible(), "123456789009876543211","123456789009876543211")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void upsertAccountInfoEligibleInRedisTest1() throws JsonMappingException, JsonProcessingException{
		String requestString = "{  \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",  \"caseId\" : \"SOP-1023325-E01\",  \"intendType\" : \"EUP\",  \"lines\" : [ {    \"preBackOrderDate\" : \"04-30-2020\",    \"preBackOrderDisplayType\" : \"Ships by\",    \"mtn\" : \"8473096013\",    \"device\" : {      \"id\" : \"OPIN20190BKLR\",      \"dppMonths\" : 24,      \"contractTerm\" : \"VERIZON_EDGE\",      \"qty\" : 1    },    \"sim\" : {      \"id\" : \"EMBD4GSIM-N\"    },    \"ispuFlow\" : false,    \"depletionLocationCode\" : \"\",    \"depletionType\" : \"F\",    \"isKeepingExistingEqProtection\" : true,    \"isNewLine\" : false  } ],  \"deviceCartInfo\" : {    \"clientAppName\" : \"VZW-ECOM\",    \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",    \"caseId\" : \"SOP-1023325-E01\",    \"accountNumber\" : \"0280363949-00001\",    \"cartCreator\" : \"8472046549\",    \"processingMTN\" : \"8473096013\",    \"processStep\" : \"GridWallPDP\",    \"intendType\" : \"EUP\",    \"processAction\" : \"addDevice\",    \"editDevice\" : false  }}";
		AccountInfoEligible accountInfoEligible = mapper.readValue(requestString, AccountInfoEligible.class);
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.upsertAccountInfoEligibleInRedis(accountInfoEligible)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(redisHelper2.upsertAccountInfoEligibleInRedis(new AccountInfoEligible())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void getDataFromRedisAsStringTest(){
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(new CartRedisData()));
		StepVerifier.create(redisHelper.getDataFromRedisAsString()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getMyOfferDataFromRedisTest(){
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(new MyOfferRedisData()));
		StepVerifier.create(redisHelper.getMyOfferDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getMyOfferETRDataFromRedisTest() {
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(new MyOfferETRRedisData()));
		StepVerifier.create(redisHelper.getMyOfferETRDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getItemTypeFromRedisTest(){
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(""));
		StepVerifier.create(redisHelper.getItemTypeFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getAccessoryDataFromRedisAsStringTest(){
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(new CartRedisData()));
		StepVerifier.create(redisHelper.getAccessoryDataFromRedisAsString()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(new HashMap()));
		StepVerifier.create(redisHelper2.getEdgeBuyoutRedisData()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(new HashMap()));
		StepVerifier.create(redisHelper2.getEdgeBuyoutDetails()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getAddFeaturesRequestTest(){
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(new AddFeaturesUIRequest()));
		StepVerifier.create(redisHelper.getAddFeaturesRequest()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getMtnToPlanIdMapTest(){
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(""));
		StepVerifier.create(redisHelper.getMtnToPlanIdMap()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getBVPDataFromRedisTest(){
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(new BVPRedisData()));
		StepVerifier.create(redisHelper.getBVPDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void isDigitalHomeFlowTest() throws JsonMappingException, JsonProcessingException{
		Map newMap = new HashMap();
		newMap.put("intentType","NSE_5G");
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(newMap));
		when(sessionBean.getChannelType()).thenReturn("Digital");
		StepVerifier.create(redisHelper.isDigitalHomeFlow()).assertNext(resp -> Assert.assertTrue(resp)).expectComplete().verify();

		when(sessionBean.getChannelType()).thenReturn("DigitalRandom");
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(getSessionData()));
		StepVerifier.create(redisHelper.isDigitalHomeFlow()).assertNext(resp -> Assert.assertFalse(resp)).expectComplete().verify();

		when(sessionBean.getChannelType()).thenReturn("Digital");
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(getSessionData()));
		StepVerifier.create(redisHelper.isDigitalHomeFlow()).assertNext(resp -> Assert.assertFalse(resp)).expectComplete().verify();

		when(sessionBean.getSessionData(any())).thenReturn(Mono.empty());
		StepVerifier.create(redisHelper.isDigitalHomeFlow()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void upsertDataIntoRedisAsStringForAccessoryTest() throws JsonMappingException, JsonProcessingException{
		String requestString = "{  \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",  \"caseId\" : \"SOP-1023325-E01\",  \"intendType\" : \"EUP\",  \"lines\" : [ {    \"preBackOrderDate\" : \"04-30-2020\",    \"preBackOrderDisplayType\" : \"Ships by\",    \"mtn\" : \"8473096013\",    \"device\" : {      \"id\" : \"OPIN20190BKLR\",      \"dppMonths\" : 24,      \"contractTerm\" : \"VERIZON_EDGE\",      \"qty\" : 1    },    \"sim\" : {      \"id\" : \"EMBD4GSIM-N\"    },    \"ispuFlow\" : false,    \"depletionLocationCode\" : \"\",    \"depletionType\" : \"F\",    \"isKeepingExistingEqProtection\" : true,    \"isNewLine\" : false  } ],  \"deviceCartInfo\" : {    \"clientAppName\" : \"VZW-ECOM\",    \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",    \"caseId\" : \"SOP-1023325-E01\",    \"accountNumber\" : \"0280363949-00001\",    \"cartCreator\" : \"8472046549\",    \"processingMTN\" : \"8473096013\",    \"processStep\" : \"GridWallPDP\",    \"intendType\" : \"EUP\",    \"processAction\" : \"addDevice\",    \"editDevice\" : false  }}";
		CartRedisData rr = mapper.readValue(requestString, CartRedisData.class);
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper.upsertDataIntoRedisAsString(rr, "ACCESSORY")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper.upsertDataIntoRedisAsString(rr, "ACCESSORYDevices")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void upsertRetrieveCartDataIntoRedisTest() throws JsonMappingException, JsonProcessingException{

		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper.upsertRetrieveCartDataIntoRedis(new RetrieveCartRedisData())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateSPOsIntoRedisTest() throws JsonMappingException, JsonProcessingException{

		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper.updateSPOsIntoRedis(new ConflictedSPOs())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper.updateSPOsIntoRedis(new ConflictedSPOs())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateSFOsIntoRedisTest() throws JsonMappingException, JsonProcessingException{

		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper.updateSFOsIntoRedis(new ConflictedSFOs())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper.updateSFOsIntoRedis(null)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper.updateSFOsIntoRedis(new ConflictedSFOs())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateProtectionVersionInRedisTest() throws JsonMappingException, JsonProcessingException{

		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper.updateProtectionVersionInRedis("")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper.updateProtectionVersionInRedis("")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}



	@Test
	public void deleteProcessingMtnFromRedisTest() throws JsonMappingException, JsonProcessingException{

		when(sessionBean.deleteSessionData(any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper.deleteProcessingMtnFromRedis("list")).verifyError();

		when(sessionBean.deleteSessionData(any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper2.deleteEdgeBuyoutDataFromRedis()).verifyError();
	}

	@Test
	public void deleteCartIdAndCaseIdAndExistingCaseFromRedisTest() throws JsonMappingException, JsonProcessingException{
		when(sessionBean.deleteSessionData(any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper.deleteCartIdAndCaseIdAndExistingCaseFromRedis()).verifyError();
	}

	@Test
	public void readCreditExceptionTest(){
		when(sessionBean.getChannelType()).thenReturn("Digital");
		Map newMap = new HashMap();
		newMap.put("intentType","NSE_5G");
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(newMap));
		when(creditDatastoreClient.readCreditException(any(), any())).thenReturn(Mono.just(new CreditErrorContent()));
		StepVerifier.create(redisHelper.readCreditException()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.getChannelType()).thenReturn("DigitalRandomValue");
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(getSessionData()));
		when(creditDatastoreClient.readCreditException(any(), any())).thenReturn(Mono.just(new CreditErrorContent()));
		StepVerifier.create(redisHelper.readCreditException()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.getSessionData(any())).thenReturn(Mono.error(Exception::new));
		when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.empty());
		when(creditDatastoreClient.readCreditException(any(), any())).thenReturn(Mono.error((Exception::new)));
		StepVerifier.create(redisHelper.readCreditException()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(new HashMap()));
		when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.error((Exception::new)));
		StepVerifier.create(redisHelper.readCreditException()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateChatIdTest(){

		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.updateChatId("1234567")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void upsertAlternateUpgradeDataIntoRedisTest() throws JsonMappingException, JsonProcessingException{
		Map map = new HashMap<String, String>();
		map.put("cartId", "123456789009876543211");
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper.upsertAlternateUpgradeDataIntoRedis(map)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateLinelevelDigitalSecureSubscriptionCountintoRedisTest() throws JsonMappingException, JsonProcessingException{

		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.updateLinelevelDigitalSecureSubscriptionCountintoRedis(1)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper2.updateLinelevelDigitalSecureSubscriptionCountintoRedis(1)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}



	@Test
	public void upsertRTDRedisDataIntoRedisTest() throws JsonMappingException, JsonProcessingException{
		String requestString = "{  \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",  \"caseId\" : \"SOP-1023325-E01\",  \"intendType\" : \"EUP\",  \"lines\" : [ {    \"preBackOrderDate\" : \"04-30-2020\",    \"preBackOrderDisplayType\" : \"Ships by\",    \"mtn\" : \"8473096013\",    \"device\" : {      \"id\" : \"OPIN20190BKLR\",      \"dppMonths\" : 24,      \"contractTerm\" : \"VERIZON_EDGE\",      \"qty\" : 1    },    \"sim\" : {      \"id\" : \"EMBD4GSIM-N\"    },    \"ispuFlow\" : false,    \"depletionLocationCode\" : \"\",    \"depletionType\" : \"F\",    \"isKeepingExistingEqProtection\" : true,    \"isNewLine\" : false  } ],  \"deviceCartInfo\" : {    \"clientAppName\" : \"VZW-ECOM\",    \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",    \"caseId\" : \"SOP-1023325-E01\",    \"accountNumber\" : \"0280363949-00001\",    \"cartCreator\" : \"8472046549\",    \"processingMTN\" : \"8473096013\",    \"processStep\" : \"GridWallPDP\",    \"intendType\" : \"EUP\",    \"processAction\" : \"addDevice\",    \"editDevice\" : false  }}";
		RTDRedisData  rr = mapper.readValue(requestString, RTDRedisData .class);
		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.upsertRTDRedisDataIntoRedis(rr)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void upsertValueInRedisTest() throws JsonMappingException, JsonProcessingException{
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.upsertValueInRedis(" "," ")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper2.upsertValueInRedis(" "," ")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void upsertRPSFlowDataIntoRedisTest() throws JsonMappingException, JsonProcessingException{
		String requestString = "{  \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",  \"caseId\" : \"SOP-1023325-E01\",  \"intendType\" : \"EUP\",  \"lines\" : [ {    \"preBackOrderDate\" : \"04-30-2020\",    \"preBackOrderDisplayType\" : \"Ships by\",    \"mtn\" : \"8473096013\",    \"device\" : {      \"id\" : \"OPIN20190BKLR\",      \"dppMonths\" : 24,      \"contractTerm\" : \"VERIZON_EDGE\",      \"qty\" : 1    },    \"sim\" : {      \"id\" : \"EMBD4GSIM-N\"    },    \"ispuFlow\" : false,    \"depletionLocationCode\" : \"\",    \"depletionType\" : \"F\",    \"isKeepingExistingEqProtection\" : true,    \"isNewLine\" : false  } ],  \"deviceCartInfo\" : {    \"clientAppName\" : \"VZW-ECOM\",    \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",    \"caseId\" : \"SOP-1023325-E01\",    \"accountNumber\" : \"0280363949-00001\",    \"cartCreator\" : \"8472046549\",    \"processingMTN\" : \"8473096013\",    \"processStep\" : \"GridWallPDP\",    \"intendType\" : \"EUP\",    \"processAction\" : \"addDevice\",    \"editDevice\" : false  }}";
		RPSRedisData  rr = mapper.readValue(requestString, RPSRedisData .class);
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.upsertRPSFlowDataIntoRedis(rr)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(false));
		StepVerifier.create(redisHelper2.upsertRPSFlowDataIntoRedis(rr)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void upsertRPSFlowDataIntoRedisTest1() throws JsonMappingException, JsonProcessingException{
		String requestString = "{  \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",  \"caseId\" : \"SOP-1023325-E01\",  \"intendType\" : \"EUP\",  \"lines\" : [ {    \"preBackOrderDate\" : \"04-30-2020\",    \"preBackOrderDisplayType\" : \"Ships by\",    \"mtn\" : \"8473096013\",    \"device\" : {      \"id\" : \"OPIN20190BKLR\",      \"dppMonths\" : 24,      \"contractTerm\" : \"VERIZON_EDGE\",      \"qty\" : 1    },    \"sim\" : {      \"id\" : \"EMBD4GSIM-N\"    },    \"ispuFlow\" : false,    \"depletionLocationCode\" : \"\",    \"depletionType\" : \"F\",    \"isKeepingExistingEqProtection\" : true,    \"isNewLine\" : false  } ],  \"deviceCartInfo\" : {    \"clientAppName\" : \"VZW-ECOM\",    \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",    \"caseId\" : \"SOP-1023325-E01\",    \"accountNumber\" : \"0280363949-00001\",    \"cartCreator\" : \"8472046549\",    \"processingMTN\" : \"8473096013\",    \"processStep\" : \"GridWallPDP\",    \"intendType\" : \"EUP\",    \"processAction\" : \"addDevice\",    \"editDevice\" : false  }}";
		RPSFlowRedisData  rr = mapper.readValue(requestString, RPSFlowRedisData .class);
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.upsertRPSFlowDataIntoRedis(rr)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(false));
		StepVerifier.create(redisHelper2.upsertRPSFlowDataIntoRedis(rr)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void upsertAddDeviceDataIntoRedisTest() throws JsonMappingException, JsonProcessingException{
		String requestString = "{  \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",  \"caseId\" : \"SOP-1023325-E01\",  \"intendType\" : \"EUP\",  \"lines\" : [ {    \"preBackOrderDate\" : \"04-30-2020\",    \"preBackOrderDisplayType\" : \"Ships by\",    \"mtn\" : \"8473096013\",    \"device\" : {      \"id\" : \"OPIN20190BKLR\",      \"dppMonths\" : 24,      \"contractTerm\" : \"VERIZON_EDGE\",      \"qty\" : 1    },    \"sim\" : {      \"id\" : \"EMBD4GSIM-N\"    },    \"ispuFlow\" : false,    \"depletionLocationCode\" : \"\",    \"depletionType\" : \"F\",    \"isKeepingExistingEqProtection\" : true,    \"isNewLine\" : false  } ],  \"deviceCartInfo\" : {    \"clientAppName\" : \"VZW-ECOM\",    \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",    \"caseId\" : \"SOP-1023325-E01\",    \"accountNumber\" : \"0280363949-00001\",    \"cartCreator\" : \"8472046549\",    \"processingMTN\" : \"8473096013\",    \"processStep\" : \"GridWallPDP\",    \"intendType\" : \"EUP\",    \"processAction\" : \"addDevice\",    \"editDevice\" : false  }}";
		CartRedisData rr = mapper.readValue(requestString, CartRedisData.class);
		rr.setDeviceType("EUP");
		rr.setRpsIntent("randomValue");
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.upsertAddDeviceDataIntoRedis(rr)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		CartRedisData cartRedisData = new CartRedisData();
		cartRedisData.setRpsIntent(" ");
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.upsertAddDeviceDataIntoRedis(cartRedisData)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void upsertAddDeviceDataIntoRedisRPSTest() throws JsonMappingException, JsonProcessingException{
		String requestString = "{  \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",  \"caseId\" : \"SOP-1023325-E01\",  \"intendType\" : \"EUP\",  \"lines\" : [ {    \"preBackOrderDate\" : \"04-30-2020\",    \"preBackOrderDisplayType\" : \"Ships by\",    \"mtn\" : \"8473096013\",    \"device\" : {      \"id\" : \"OPIN20190BKLR\",      \"dppMonths\" : 24,      \"contractTerm\" : \"VERIZON_EDGE\",      \"qty\" : 1    },    \"sim\" : {      \"id\" : \"EMBD4GSIM-N\"    },    \"ispuFlow\" : false,    \"depletionLocationCode\" : \"\",    \"depletionType\" : \"F\",    \"isKeepingExistingEqProtection\" : true,    \"isNewLine\" : false  } ],  \"deviceCartInfo\" : {    \"clientAppName\" : \"VZW-ECOM\",    \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",    \"caseId\" : \"SOP-1023325-E01\",    \"accountNumber\" : \"0280363949-00001\",    \"cartCreator\" : \"8472046549\",    \"processingMTN\" : \"8473096013\",    \"processStep\" : \"GridWallPDP\",    \"intendType\" : \"EUP\",    \"processAction\" : \"addDevice\",    \"editDevice\" : false  }}";
		CartRedisData rr = mapper.readValue(requestString, CartRedisData.class);
		rr.setRpsIntent("randomValue");
		String rpsFlowData = "{  \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",  \"caseId\" : \"SOP-1023325-E01\",  \"intendType\" : \"EUP\",  \"lines\" : [ {    \"preBackOrderDate\" : \"04-30-2020\",    \"preBackOrderDisplayType\" : \"Ships by\",    \"mtn\" : \"8473096013\",    \"device\" : {      \"id\" : \"OPIN20190BKLR\",      \"dppMonths\" : 24,      \"contractTerm\" : \"VERIZON_EDGE\",      \"qty\" : 1    },    \"sim\" : {      \"id\" : \"EMBD4GSIM-N\"    },    \"ispuFlow\" : false,    \"depletionLocationCode\" : \"\",    \"depletionType\" : \"F\",    \"isKeepingExistingEqProtection\" : true,    \"isNewLine\" : false  } ],  \"deviceCartInfo\" : {    \"clientAppName\" : \"VZW-ECOM\",    \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",    \"caseId\" : \"SOP-1023325-E01\",    \"accountNumber\" : \"0280363949-00001\",    \"cartCreator\" : \"8472046549\",    \"processingMTN\" : \"8473096013\",    \"processStep\" : \"GridWallPDP\",    \"intendType\" : \"EUP\",    \"processAction\" : \"addDevice\",    \"editDevice\" : false  }}";
		RPSFlowRedisData  rpsf = mapper.readValue(rpsFlowData, RPSFlowRedisData.class);
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.upsertAddDeviceDataIntoRedis(rr,rpsf)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		rr.setRpsIntent(null);
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.upsertAddDeviceDataIntoRedis(rr,rpsf)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void getRTDOfferDataFromRedisTest() throws JsonMappingException, JsonProcessingException{
		String requestString = "{  \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",  \"caseId\" : \"SOP-1023325-E01\",  \"intendType\" : \"EUP\",  \"lines\" : [ {    \"preBackOrderDate\" : \"04-30-2020\",    \"preBackOrderDisplayType\" : \"Ships by\",    \"mtn\" : \"8473096013\",    \"device\" : {      \"id\" : \"OPIN20190BKLR\",      \"dppMonths\" : 24,      \"contractTerm\" : \"VERIZON_EDGE\",      \"qty\" : 1    },    \"sim\" : {      \"id\" : \"EMBD4GSIM-N\"    },    \"ispuFlow\" : false,    \"depletionLocationCode\" : \"\",    \"depletionType\" : \"F\",    \"isKeepingExistingEqProtection\" : true,    \"isNewLine\" : false  } ],  \"deviceCartInfo\" : {    \"clientAppName\" : \"VZW-ECOM\",    \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",    \"caseId\" : \"SOP-1023325-E01\",    \"accountNumber\" : \"0280363949-00001\",    \"cartCreator\" : \"8472046549\",    \"processingMTN\" : \"8473096013\",    \"processStep\" : \"GridWallPDP\",    \"intendType\" : \"EUP\",    \"processAction\" : \"addDevice\",    \"editDevice\" : false, \\\"intent\\\" : \\\"NLG\\\"  }}";
		String rfexExchangeShopDetailsString = "{\"mtn\" : \"654892298\",\"returnItemSeq\" : \"1\"}";
		Map sessionData = new HashMap<Object,Object>();

		sessionData.put(CartConstants.CART_ID, "c4d4360d-3d96-4b37-95b8-dd12881b2fff");
		sessionData.put(CartConstants.INTEND_TYPE, "EUP");
		sessionData.put(CartConstants.RTD_KEY, "9205726029");

		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(sessionData));
		StepVerifier.create(redisHelper2.getRTDOfferDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		String RTDRedisDataString = "{  \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",  \"caseId\" : \"SOP-1023325-E01\",  \"intendType\" : \"EUP\",  \"lines\" : [ {    \"preBackOrderDate\" : \"04-30-2020\",    \"preBackOrderDisplayType\" : \"Ships by\",    \"mtn\" : \"8473096013\",    \"device\" : {      \"id\" : \"OPIN20190BKLR\",      \"dppMonths\" : 24,      \"contractTerm\" : \"VERIZON_EDGE\",      \"qty\" : 1    },    \"sim\" : {      \"id\" : \"EMBD4GSIM-N\"    },    \"ispuFlow\" : false,    \"depletionLocationCode\" : \"\",    \"depletionType\" : \"F\",    \"isKeepingExistingEqProtection\" : true,    \"isNewLine\" : false  } ],  \"deviceCartInfo\" : {    \"clientAppName\" : \"VZW-ECOM\",    \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",    \"caseId\" : \"SOP-1023325-E01\",    \"accountNumber\" : \"0280363949-00001\",    \"cartCreator\" : \"8472046549\",    \"processingMTN\" : \"8473096013\",    \"processStep\" : \"GridWallPDP\",    \"intendType\" : \"EUP\",    \"processAction\" : \"addDevice\",    \"editDevice\" : false  }}";
		sessionData.put(CartConstants.RTD_KEY, RTDRedisDataString);
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(sessionData));
		StepVerifier.create(redisHelper2.getRTDOfferDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		sessionData.put(CartConstants.RTD_KEY, null);
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(sessionData));
		StepVerifier.create(redisHelper2.getRTDOfferDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(new HashMap()));
		StepVerifier.create(redisHelper2.getRTDOfferDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updatePromoFirstOfferDataTest() {
		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.updatePromoFirstOfferData(new MyOfferETRRedisData())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.just(false));
		StepVerifier.create(redisHelper2.updatePromoFirstOfferData(new MyOfferETRRedisData())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper2.updatePromoFirstOfferData(new MyOfferETRRedisData())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void updateFiveGOrderNowDataIntoRedisAsStringTest() throws JsonMappingException, JsonProcessingException{
		String requestString = "{  \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",  \"caseId\" : \"SOP-1023325-E01\",  \"intendType\" : \"EUP\",  \"lines\" : [ {    \"preBackOrderDate\" : \"04-30-2020\",    \"preBackOrderDisplayType\" : \"Ships by\",    \"mtn\" : \"8473096013\",    \"device\" : {      \"id\" : \"OPIN20190BKLR\",      \"dppMonths\" : 24,      \"contractTerm\" : \"VERIZON_EDGE\",      \"qty\" : 1    },    \"sim\" : {      \"id\" : \"EMBD4GSIM-N\"    },    \"ispuFlow\" : false,    \"depletionLocationCode\" : \"\",    \"depletionType\" : \"F\",    \"isKeepingExistingEqProtection\" : true,    \"isNewLine\" : false  } ],  \"deviceCartInfo\" : {    \"clientAppName\" : \"VZW-ECOM\",    \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",    \"caseId\" : \"SOP-1023325-E01\",    \"accountNumber\" : \"0280363949-00001\",    \"cartCreator\" : \"8472046549\",    \"processingMTN\" : \"8473096013\",    \"processStep\" : \"GridWallPDP\",    \"intendType\" : \"EUP\",    \"processAction\" : \"addDevice\",    \"editDevice\" : false  }, \"midnight\":\"Y\"}";
		CartRedisData rr = mapper.readValue(requestString, CartRedisData.class);
		rr.setEcpdId("randomValue");
		rr.setIntendType("EPU");
		rr.setMidnight("Y");
		rr.setTransactionType("repairGen2ToGen3");
		rr.setProcessingMTN("randomValue");
		DeviceCartInfo deviceCartInfo = new DeviceCartInfo();
		deviceCartInfo.setMtnFlow("G");
		rr.setDeviceCartInfo(deviceCartInfo);
		rr.setShowAALPromoIntercept(new ShowAALPromoIntercept());
		rr.getLines().get(0).setRestrictedProductType("randomValue");

		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(rr,"accessory")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(rr,"device")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		rr.setTransactionType("cBand_Technician");
		rr.getLines().get(0).setRestrictedProductType(null);
		deviceCartInfo.setMtnFlow(null);
		rr.setDeviceCartInfo(deviceCartInfo);
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(false));
		StepVerifier.create(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(rr,"device")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(rr,"accessory")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		rr.setShowAALPromoIntercept(null);
		rr.setDeviceCartInfo(null);
		rr.setLines(null);
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(false));
		StepVerifier.create(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(rr,"device")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(rr,"accessory")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();


		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(false));
		StepVerifier.create(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(rr,"device")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(rr,"accessory")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(new CartRedisData(),"accessorydevice")).verifyError();

		rr.setMidnight("N");
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(rr,"accessory")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		rr.setMidnight(null);
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(rr,"device")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();


		rr.setMidnight("");
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(rr,"device")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void fwaRedisKeysTest() throws JsonProcessingException {
		String requestString = "{  \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",  \"caseId\" : \"SOP-1023325-E01\",  \"intendType\" : \"EUP\",  \"lines\" : [ {    \"preBackOrderDate\" : \"04-30-2020\",    \"preBackOrderDisplayType\" : \"Ships by\",    \"mtn\" : \"8473096013\",    \"device\" : {      \"id\" : \"OPIN20190BKLR\",      \"dppMonths\" : 24,      \"contractTerm\" : \"VERIZON_EDGE\",      \"qty\" : 1    },    \"sim\" : {      \"id\" : \"EMBD4GSIM-N\"    },    \"ispuFlow\" : false,    \"depletionLocationCode\" : \"\",    \"depletionType\" : \"F\",    \"isKeepingExistingEqProtection\" : true,    \"isNewLine\" : false  } ],  \"deviceCartInfo\" : {    \"clientAppName\" : \"VZW-ECOM\",    \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",    \"caseId\" : \"SOP-1023325-E01\",    \"accountNumber\" : \"0280363949-00001\",    \"cartCreator\" : \"8472046549\",    \"processingMTN\" : \"8473096013\",    \"processStep\" : \"GridWallPDP\",    \"intendType\" : \"EUP\",    \"processAction\" : \"addDevice\",    \"editDevice\" : false  }}";
		CartRedisData rr = mapper.readValue(requestString, CartRedisData.class);
		ReflectionTestUtils.setField(redisHelper3,"fwaRedisKeysEnabled",true);
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		when(sessionBean.isFWADigitalFlow()).thenReturn(true);
		StepVerifier.create(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(rr,"accessory")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(rr,"device")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void fwaRedisKeysDisableTest() throws JsonProcessingException {
		String requestString = "{  \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",  \"caseId\" : \"SOP-1023325-E01\",  \"intendType\" : \"EUP\",  \"lines\" : [ {    \"preBackOrderDate\" : \"04-30-2020\",    \"preBackOrderDisplayType\" : \"Ships by\",    \"mtn\" : \"8473096013\",    \"device\" : {      \"id\" : \"OPIN20190BKLR\",      \"dppMonths\" : 24,      \"contractTerm\" : \"VERIZON_EDGE\",      \"qty\" : 1    },    \"sim\" : {      \"id\" : \"EMBD4GSIM-N\"    },    \"ispuFlow\" : false,    \"depletionLocationCode\" : \"\",    \"depletionType\" : \"F\",    \"isKeepingExistingEqProtection\" : true,    \"isNewLine\" : false  } ],  \"deviceCartInfo\" : {    \"clientAppName\" : \"VZW-ECOM\",    \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",    \"caseId\" : \"SOP-1023325-E01\",    \"accountNumber\" : \"0280363949-00001\",    \"cartCreator\" : \"8472046549\",    \"processingMTN\" : \"8473096013\",    \"processStep\" : \"GridWallPDP\",    \"intendType\" : \"EUP\",    \"processAction\" : \"addDevice\",    \"editDevice\" : false  }}";
		CartRedisData rr = mapper.readValue(requestString, CartRedisData.class);
		ReflectionTestUtils.setField(redisHelper3,"fwaRedisKeysEnabled",false);
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		when(sessionBean.isFWADigitalFlow()).thenReturn(false);
		StepVerifier.create(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(rr,"accessory")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(rr,"device")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void updateCrmResumeDataIntoRedisAsStringTest() throws JsonMappingException, JsonProcessingException{
		String requestString =  "{\"cartId\":\"852a8e01-a83a-4c38-b082-bf90edd6e838\",\"customerType\":\"N\",\"accountNumber\":\"\",\"lqData\":{\"networkBandwidthType\":\"MMW\",\"lineActivityType\":\"NSE_5G\",\"eligible5GHomeBundle\":[{\"bundleName\":\"5GHomeGeminiSelfSetup\",\"id\":\"16900001\"},{\"bundleName\":\"5GHomeGeminiProfSetup\",\"id\":\"16900002\"}],\"cart5GAddress\":{\"addressLine1\":\"800 S OGDEN ST\",\"city\":\"DENVER\",\"state\":\"CO\",\"zipCode\":\"80209\",\"zipCode4\":\"\",\"county\":\"\",\"countryCode\":\"\",\"fipsCode\":\"0803120000\",\"emailId\":\"\"}}}";
		CrmResumeCartUIRequest request = mapper.readValue(requestString, CrmResumeCartUIRequest.class);
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		when(sessionBean.isFWADigitalFlow()).thenReturn(true);
		StepVerifier.create(redisHelper3.updateCrmResumeDataIntoRedisAsString(request)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		CrmResumeCartUIRequest crmResumeCartUIRequest = new CrmResumeCartUIRequest();
		crmResumeCartUIRequest.setLqData(new FiveGLqData());
		crmResumeCartUIRequest.getLqData().setEligible5GHomeBundle(Arrays.asList(new Eligible5GHomeBundle(), new Eligible5GHomeBundle(), new Eligible5GHomeBundle()));
		Address address = new Address();
		address.setFloor(3);
		crmResumeCartUIRequest.getLqData().setCart5GAddress(address);
		crmResumeCartUIRequest.setProcessingMTN("randomValue");
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper3.updateCrmResumeDataIntoRedisAsString(crmResumeCartUIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		crmResumeCartUIRequest.setLqData(new FiveGLqData());
		crmResumeCartUIRequest.getLqData().setEligible5GHomeBundle(Collections.emptyList());
		crmResumeCartUIRequest.getLqData().setCart5GAddress(null);
		crmResumeCartUIRequest.setProcessingMTN("randomValue");
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper3.updateCrmResumeDataIntoRedisAsString(crmResumeCartUIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		crmResumeCartUIRequest.setLqData(null);
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper3.updateCrmResumeDataIntoRedisAsString(crmResumeCartUIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper3.updateCrmResumeDataIntoRedisAsString(new CrmResumeCartUIRequest())).verifyError();
	}
	@Test
	public void updateCrmResumeDataIntoRedisAsStringTest1() throws JsonMappingException, JsonProcessingException{
		String requestString1 = "{  \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",  \"caseId\" : \"SOP-1023325-E01\",  \"intendType\" : \"EUP\",  \"lines\" : [ {    \"preBackOrderDate\" : \"04-30-2020\",    \"preBackOrderDisplayType\" : \"Ships by\",    \"mtn\" : \"8473096013\",    \"device\" : {      \"id\" : \"OPIN20190BKLR\",      \"dppMonths\" : 24,      \"contractTerm\" : \"VERIZON_EDGE\",      \"qty\" : 1    },    \"sim\" : {      \"id\" : \"EMBD4GSIM-N\"    },    \"ispuFlow\" : false,    \"depletionLocationCode\" : \"\",    \"depletionType\" : \"F\",    \"isKeepingExistingEqProtection\" : true,    \"isNewLine\" : false  } ],  \"deviceCartInfo\" : {    \"clientAppName\" : \"VZW-ECOM\",    \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",    \"caseId\" : \"SOP-1023325-E01\",    \"accountNumber\" : \"0280363949-00001\",    \"cartCreator\" : \"8472046549\",    \"processingMTN\" : \"8473096013\",    \"processStep\" : \"GridWallPDP\",    \"intendType\" : \"EUP\",    \"processAction\" : \"addDevice\",    \"editDevice\" : false  }}";
		CartRedisData rr = mapper.readValue(requestString1, CartRedisData.class);
		ReflectionTestUtils.setField(redisHelper3,"fwaRedisKeysEnabled",true);
		String requestString =  "{\"cartId\":\"852a8e01-a83a-4c38-b082-bf90edd6e838\",\"customerType\":\"N\",\"accountNumber\":\"\",\"lqData\":{\"networkBandwidthType\":\"MMW\",\"lineActivityType\":\"NSE_5G\",\"eligible5GHomeBundle\":[{\"bundleName\":\"5GHomeGeminiSelfSetup\",\"id\":\"16900001\"},{\"bundleName\":\"5GHomeGeminiProfSetup\",\"id\":\"16900002\"}],\"cart5GAddress\":{\"addressLine1\":\"800 S OGDEN ST\",\"city\":\"DENVER\",\"state\":\"CO\",\"zipCode\":\"80209\",\"zipCode4\":\"\",\"county\":\"\",\"countryCode\":\"\",\"fipsCode\":\"0803120000\",\"emailId\":\"\"}}}";
		CrmResumeCartUIRequest request = mapper.readValue(requestString, CrmResumeCartUIRequest.class);
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		when(sessionBean.isFWADigitalFlow()).thenReturn(true);
		StepVerifier.create(redisHelper3.updateCrmResumeDataIntoRedisAsString(request)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		CrmResumeCartUIRequest crmResumeCartUIRequest = new CrmResumeCartUIRequest();
		crmResumeCartUIRequest.setLqData(new FiveGLqData());
		crmResumeCartUIRequest.getLqData().setEligible5GHomeBundle(Arrays.asList(new Eligible5GHomeBundle(), new Eligible5GHomeBundle(), new Eligible5GHomeBundle()));
		Address address = new Address();
		address.setFloor(3);
		crmResumeCartUIRequest.getLqData().setCart5GAddress(address);
		crmResumeCartUIRequest.setProcessingMTN("randomValue");
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper3.updateCrmResumeDataIntoRedisAsString(crmResumeCartUIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		crmResumeCartUIRequest.setLqData(new FiveGLqData());
		crmResumeCartUIRequest.getLqData().setEligible5GHomeBundle(Collections.emptyList());
		crmResumeCartUIRequest.getLqData().setCart5GAddress(null);
		crmResumeCartUIRequest.setProcessingMTN("randomValue");
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper3.updateCrmResumeDataIntoRedisAsString(crmResumeCartUIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		crmResumeCartUIRequest.setLqData(null);
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper3.updateCrmResumeDataIntoRedisAsString(crmResumeCartUIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper3.updateCrmResumeDataIntoRedisAsString(new CrmResumeCartUIRequest())).verifyError();
	}
	@Test
	public void updateCrmResumeDataIntoRedisAsStringTest2() throws JsonMappingException, JsonProcessingException{
		String requestString1 = "{  \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",  \"caseId\" : \"SOP-1023325-E01\",  \"intendType\" : \"EUP\",  \"lines\" : [ {    \"preBackOrderDate\" : \"04-30-2020\",    \"preBackOrderDisplayType\" : \"Ships by\",    \"mtn\" : \"8473096013\",    \"device\" : {      \"id\" : \"OPIN20190BKLR\",      \"dppMonths\" : 24,      \"contractTerm\" : \"VERIZON_EDGE\",      \"qty\" : 1    },    \"sim\" : {      \"id\" : \"EMBD4GSIM-N\"    },    \"ispuFlow\" : false,    \"depletionLocationCode\" : \"\",    \"depletionType\" : \"F\",    \"isKeepingExistingEqProtection\" : true,    \"isNewLine\" : false  } ],  \"deviceCartInfo\" : {    \"clientAppName\" : \"VZW-ECOM\",    \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",    \"caseId\" : \"SOP-1023325-E01\",    \"accountNumber\" : \"0280363949-00001\",    \"cartCreator\" : \"8472046549\",    \"processingMTN\" : \"8473096013\",    \"processStep\" : \"GridWallPDP\",    \"intendType\" : \"EUP\",    \"processAction\" : \"addDevice\",    \"editDevice\" : false  }}";
		CartRedisData rr = mapper.readValue(requestString1, CartRedisData.class);
		ReflectionTestUtils.setField(redisHelper3,"fwaRedisKeysEnabled",false);
		String requestString =  "{\"cartId\":\"852a8e01-a83a-4c38-b082-bf90edd6e838\",\"customerType\":\"N\",\"accountNumber\":\"\",\"lqData\":{\"networkBandwidthType\":\"MMW\",\"lineActivityType\":\"NSE_5G\",\"eligible5GHomeBundle\":[{\"bundleName\":\"5GHomeGeminiSelfSetup\",\"id\":\"16900001\"},{\"bundleName\":\"5GHomeGeminiProfSetup\",\"id\":\"16900002\"}],\"cart5GAddress\":{\"addressLine1\":\"800 S OGDEN ST\",\"city\":\"DENVER\",\"state\":\"CO\",\"zipCode\":\"80209\",\"zipCode4\":\"\",\"county\":\"\",\"countryCode\":\"\",\"fipsCode\":\"0803120000\",\"emailId\":\"\"}}}";
		CrmResumeCartUIRequest request = mapper.readValue(requestString, CrmResumeCartUIRequest.class);
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		when(sessionBean.isFWADigitalFlow()).thenReturn(true);
		StepVerifier.create(redisHelper3.updateCrmResumeDataIntoRedisAsString(request)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		CrmResumeCartUIRequest crmResumeCartUIRequest = new CrmResumeCartUIRequest();
		crmResumeCartUIRequest.setLqData(new FiveGLqData());
		crmResumeCartUIRequest.getLqData().setEligible5GHomeBundle(Arrays.asList(new Eligible5GHomeBundle(), new Eligible5GHomeBundle(), new Eligible5GHomeBundle()));
		Address address = new Address();
		address.setFloor(3);
		crmResumeCartUIRequest.getLqData().setCart5GAddress(address);
		crmResumeCartUIRequest.setProcessingMTN("randomValue");
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper3.updateCrmResumeDataIntoRedisAsString(crmResumeCartUIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		crmResumeCartUIRequest.setLqData(new FiveGLqData());
		crmResumeCartUIRequest.getLqData().setEligible5GHomeBundle(Collections.emptyList());
		crmResumeCartUIRequest.getLqData().setCart5GAddress(null);
		crmResumeCartUIRequest.setProcessingMTN("randomValue");
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper3.updateCrmResumeDataIntoRedisAsString(crmResumeCartUIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		crmResumeCartUIRequest.setLqData(null);
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper3.updateCrmResumeDataIntoRedisAsString(crmResumeCartUIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper3.updateCrmResumeDataIntoRedisAsString(new CrmResumeCartUIRequest())).verifyError();
	}
	@Test
	public void upsertInitiateDeviceSimActivationDataIntoRedisTest(){
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		IntiateDeviceSimActivationUIRequest intiateDeviceSimActivationUIRequest= new IntiateDeviceSimActivationUIRequest();
		intiateDeviceSimActivationUIRequest.setIccid("randomValues");
		intiateDeviceSimActivationUIRequest.setImei("randomValue");
		StepVerifier.create(redisHelper3.upsertInitiateDeviceSimActivationDataIntoRedis(intiateDeviceSimActivationUIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(redisHelper3.upsertInitiateDeviceSimActivationDataIntoRedis(new IntiateDeviceSimActivationUIRequest())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void upsertDeviceSimValidationRequestDataIntoRedisTest() {
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		DeviceSimValidationUIRequest deviceSimValidationUIRequest = new DeviceSimValidationUIRequest();
		deviceSimValidationUIRequest.setIsSmartphone(true);
		deviceSimValidationUIRequest.setIccid("randomValue");
		deviceSimValidationUIRequest.setImei("randomValues");
		deviceSimValidationUIRequest.setImei2("randomeValue");
		deviceSimValidationUIRequest.setDevid("randomValue");
		deviceSimValidationUIRequest.setEid("randomValue");
		StepVerifier.create(redisHelper3.upsertDeviceSimValidationRequestDataIntoRedis(deviceSimValidationUIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		StepVerifier.create(redisHelper3.upsertDeviceSimValidationRequestDataIntoRedis(new DeviceSimValidationUIRequest())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper3.upsertDeviceSimValidationRequestDataIntoRedis(null)).verifyError();
	}
	@Test
	public void getFlowTypeFromRedisTest() {
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(""));
		StepVerifier.create(redisHelper3.getFlowTypeFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void getHomeSalesAddressFromRedisTest() throws JsonProcessingException {
		HomeSalesAddress rr = mapper.readValue(requestString, HomeSalesAddress.class);
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(rr));
		StepVerifier.create(redisHelper3.getHomeSalesAddressFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper3.getHomeSalesAddressFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void getDataFromSessionTest() throws JsonMappingException, JsonProcessingException{
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(getSessionData()));
		StepVerifier.create(redisHelper3.getDataFromSession(getSessionDataArr())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		getSessionData().values().stream().forEach(e->e=null);
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(getSessionData()));
		StepVerifier.create(redisHelper3.getDataFromSession(new String[]{})).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(new HashMap()));
		StepVerifier.create(redisHelper3.getDataFromSession(new String[]{})).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.getSessionData(any())).thenReturn(Mono.empty());
		StepVerifier.create(redisHelper3.getDataFromSession(new String[]{})).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void upsertNewCustFlowRedisTest() throws JsonMappingException, JsonProcessingException{

		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.upsertNewCustFlowRedis("PE")).verifyComplete();
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.upsertNewCustFlowRedis("BE")).verifyComplete();
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.upsertNewCustFlowRedis("ME")).verifyComplete();
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(false));
		StepVerifier.create(redisHelper2.upsertNewCustFlowRedis("")).verifyComplete();
		when(sessionBean.setSessionData(any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper2.upsertNewCustFlowRedis("ME")).verifyComplete();
	}
	@Test
	public void deleteAlternateUpgradeDataIntoRedisTest() throws JsonMappingException, JsonProcessingException{
		List list = new ArrayList<String>();
		list.add("addDeviceRequest");
		when(sessionBean.deleteSessionData(any())).thenReturn(Mono.just(1L));
		StepVerifier.create(redisHelper.deleteAlternateUpgradeDataIntoRedis(list)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deleteAlternateUpgradeDataIntoRedisErrorTest() throws JsonMappingException, JsonProcessingException{
		List list = new ArrayList<String>();
		list.add("randomBoy");
		when(sessionBean.deleteSessionData(any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper.deleteAlternateUpgradeDataIntoRedis(list)).verifyError();
	}
	@Test
	public void upsertEdgeBuyoutDataIntoRedisTest() throws JsonMappingException, JsonProcessingException{
		String requestString = "{  \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",  \"caseId\" : \"SOP-1023325-E01\",  \"intendType\" : \"EUP\",  \"lines\" : [ {    \"preBackOrderDate\" : \"04-30-2020\",    \"preBackOrderDisplayType\" : \"Ships by\",    \"mtn\" : \"8473096013\",    \"device\" : {      \"id\" : \"OPIN20190BKLR\",      \"dppMonths\" : 24,      \"contractTerm\" : \"VERIZON_EDGE\",      \"qty\" : 1    },    \"sim\" : {      \"id\" : \"EMBD4GSIM-N\"    },    \"ispuFlow\" : false,    \"depletionLocationCode\" : \"\",    \"depletionType\" : \"F\",    \"isKeepingExistingEqProtection\" : true,    \"isNewLine\" : false  } ],  \"deviceCartInfo\" : {    \"clientAppName\" : \"VZW-ECOM\",    \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",    \"caseId\" : \"SOP-1023325-E01\",    \"accountNumber\" : \"0280363949-00001\",    \"cartCreator\" : \"8472046549\",    \"processingMTN\" : \"8473096013\",    \"processStep\" : \"GridWallPDP\",    \"intendType\" : \"EUP\",    \"processAction\" : \"addDevice\",    \"editDevice\" : false  }}";
		CartRedisData rr = mapper.readValue(requestString, CartRedisData.class);
		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.upsertEdgeBuyoutDataIntoRedis("8473096013",rr)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper2.upsertEdgeBuyoutDataIntoRedis("8473096013",rr)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void upsertBVPTradeInOFferIntoRedisTest() throws JsonMappingException, JsonProcessingException{
		String requestString = "{  \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",  \"caseId\" : \"SOP-1023325-E01\",  \"intendType\" : \"EUP\",  \"lines\" : [ {    \"preBackOrderDate\" : \"04-30-2020\",    \"preBackOrderDisplayType\" : \"Ships by\",    \"mtn\" : \"8473096013\",    \"device\" : {      \"id\" : \"OPIN20190BKLR\",      \"dppMonths\" : 24,      \"contractTerm\" : \"VERIZON_EDGE\",      \"qty\" : 1    },    \"sim\" : {      \"id\" : \"EMBD4GSIM-N\"    },    \"ispuFlow\" : false,    \"depletionLocationCode\" : \"\",    \"depletionType\" : \"F\",    \"isKeepingExistingEqProtection\" : true,    \"isNewLine\" : false  } ],  \"deviceCartInfo\" : {    \"clientAppName\" : \"VZW-ECOM\",    \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",    \"caseId\" : \"SOP-1023325-E01\",    \"accountNumber\" : \"0280363949-00001\",    \"cartCreator\" : \"8472046549\",    \"processingMTN\" : \"8473096013\",    \"processStep\" : \"GridWallPDP\",    \"intendType\" : \"EUP\",    \"processAction\" : \"addDevice\",    \"editDevice\" : false  }}";
		BVPRedisData  rr = mapper.readValue(requestString, BVPRedisData .class);
		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.upsertBVPTradeInOFferIntoRedis(rr)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void getQuotePricingRedisDataTest() throws JsonProcessingException {
		QuotePricingRedisData rr = mapper.readValue(requestString, QuotePricingRedisData.class);
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(rr));
		StepVerifier.create(redisHelper2.getQuotePricingRedisData()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		RPSRedisData rrr = mapper.readValue(requestString, RPSRedisData.class);
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(rrr));
		StepVerifier.create(redisHelper2.getRPSDataFromRedisAsString()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void upsertQuotePriceIntoRedisTest(){
		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.upsertQuotePriceIntoRedis(new QuotePricingRedisData())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deleteAddDeviceDataFromRedisTest() throws JsonMappingException, JsonProcessingException{
		when(sessionBean.deleteSessionData(any())).thenReturn(Mono.just(1L));
		StepVerifier.create(redisHelper.deleteAddDeviceDataFromRedis("randomBoy")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.deleteSessionData(any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper.deleteAddDeviceDataFromRedis("randomBoy")).verifyError();

		when(sessionBean.deleteSessionData(any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper.deleteSessionDataFromRedis(new ArrayList<>())).verifyError();
	}

	@Test
	public void getInEligibleUpgradeLinesFromRedisTest(){
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just("[{\"mtn\":\"1234567890\", \"reason\":\"Crisis\"}]"));
		StepVerifier.create(redisHelper.getInEligibleUpgradeLinesFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(""));
		StepVerifier.create(redisHelper.getInEligibleUpgradeLinesFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(""));
		StepVerifier.create(redisHelper.getInEligibleUpgradeLinesFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getPromoHubSpokeJourneyTest(){
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(""));
		StepVerifier.create(redisHelper.getPromoHubSpokeJourney()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void upsertAddPlanUIRequestIntoRedisforHexUnlimitedPlanOfferTest() throws JsonMappingException, JsonProcessingException{
		Map map = new HashMap<String, String>();
		map.put("cartId", "123456789009876543211");
		map.put("caseId", "123456789009876543211");
		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper.upsertAddPlanUIRequestIntoRedisforHexUnlimitedPlanOffer(map)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper.upsertAddPlanUIRequestIntoRedisforHexUnlimitedPlanOffer(map)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}


	@Test
	public void deleteHexPlanOfferInfoIntoRedisTest() throws JsonMappingException, JsonProcessingException{
		List list = new ArrayList<String>();
		list.add("addDeviceRequest");
		when(sessionBean.deleteSessionData(any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper.deleteHexPlanOfferInfoIntoRedis(list)).verifyError();
	}

	@Test
	public void upsertOneClickCheckoutFlagTest() throws JsonMappingException, JsonProcessingException{
		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper.upsertOneClickCheckoutFlag("spiderMonkey")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper.upsertOneClickCheckoutFlag("spiderMonkey")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deleteCartIdAndCaseIdFromRedisTest() throws JsonMappingException, JsonProcessingException{
		when(sessionBean.deleteSessionData(any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper.deleteCartIdAndCaseIdFromRedis()).verifyError();
	}

	@Test
	public void getFiveGAddressFromRedisTest() throws JsonMappingException, JsonProcessingException{
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(new FiveGAddressRedisData()));
		StepVerifier.create(redisHelper.getFiveGAddressFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		FiveGAddressRedisData fiveGAddressRedisData = new FiveGAddressRedisData();
		fiveGAddressRedisData.setAddressRequest(null);
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(fiveGAddressRedisData));
		StepVerifier.create(redisHelper.getFiveGAddressFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		fiveGAddressRedisData.setAddressRequest(new FiveGAddress());
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(fiveGAddressRedisData));
		StepVerifier.create(redisHelper.getFiveGAddressFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void upsertFiveGAddressIntoRedisTest() throws JsonMappingException, JsonProcessingException{
		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.upsertFiveGAddressIntoRedis(new FiveGAddressRedisData())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void upsertRemoveOfferDataIntoRedisTest() throws JsonMappingException, JsonProcessingException{
		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.upsertRemoveOfferDataIntoRedis(new RemoveOfferRedisData())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper2.upsertRemoveOfferDataIntoRedis(new RemoveOfferRedisData())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

	}

	@Test
	public void getRemoveOfferDataIntoRedisTest() throws JsonMappingException, JsonProcessingException{
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(new RemoveOfferRedisData()));
		StepVerifier.create(redisHelper2.getRemoveOfferDataIntoRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deleteRemoveOfferDataFromRedisTest() throws JsonMappingException, JsonProcessingException{
		when(sessionBean.deleteSessionData(any())).thenReturn(Mono.just(1L));
		StepVerifier.create(redisHelper2.deleteRemoveOfferDataFromRedis("randomBoy")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.deleteSessionData(any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper2.deleteRemoveOfferDataFromRedis("randomBoy")).verifyError();
	}

	@Test
	public void getLoggedInUserTest() throws JsonMappingException, JsonProcessingException{
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(""));
		StepVerifier.create(redisHelper2.getLoggedInUser()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void getLVSoftSkuTest() throws JsonMappingException, JsonProcessingException{
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just("LOCNOTE"));
		StepVerifier.create(redisHelper2.getLVSoftsku()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateDeviceCartCountTest() throws JsonMappingException, JsonProcessingException{
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.updateDeviceCartCount("1", Boolean.FALSE)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void updateDeviceCartCountTest2() throws JsonMappingException, JsonProcessingException{
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.updateDeviceCartCount("1", Boolean.TRUE)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateCartOrderFlowTypeTest() throws JsonMappingException, JsonProcessingException{
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.updateCartOrderFlowType("eup")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any())).thenReturn(Mono.empty());
		StepVerifier.create(redisHelper2.updateCartOrderFlowType("eup")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(false));
		StepVerifier.create(redisHelper2.updateCartOrderFlowType(null)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateDeviceIdTest() throws JsonMappingException, JsonProcessingException{
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.updateDeviceId("1234")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateSimIdTest() throws JsonMappingException, JsonProcessingException{
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.updateSimId("1234")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getCartOrderFlowTypeTest() throws JsonMappingException, JsonProcessingException{
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(""));
		StepVerifier.create(redisHelper2.getCartOrderFlowType()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getOneClickCheckoutFlagTest() throws JsonMappingException, JsonProcessingException{
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(""));
		StepVerifier.create(redisHelper.getOneClickCheckoutFlag()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getRoleTest() throws JsonMappingException, JsonProcessingException{
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(""));
		StepVerifier.create(redisHelper2.getRole()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getDeviceIdTest() throws JsonMappingException, JsonProcessingException{
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(""));
		StepVerifier.create(redisHelper2.getDeviceId()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getSimIdTest() throws JsonMappingException, JsonProcessingException{
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(""));
		StepVerifier.create(redisHelper2.getSimId()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(""));
		StepVerifier.create(redisHelper3.getDeviceSorDisplayNameFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(""));
		StepVerifier.create(redisHelper3.getPsimSKUFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(new HashMap<>()));
		StepVerifier.create(redisHelper2.getEsimSKUFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(""));
		StepVerifier.create(redisHelper2.getDeviceCartMap()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.upsertDeviceCartMapInRedis(getSessionData())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.upsertDeviceCartMapInRedis(new HashMap())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper2.upsertDeviceCartMapInRedis(getSessionData())).verifyError();

		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(""));
		StepVerifier.create(redisHelper2.getCartIdFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void upsertBBPFlowDataIntoRedisTest(){
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		BBPFlowRedisData bbpFlowRedisData = new BBPFlowRedisData();
		bbpFlowRedisData.setBbpiccid("89148000000835900458");
		bbpFlowRedisData.setBbpimei("352898071702915");
		bbpFlowRedisData.setIsSmartphone(Boolean.TRUE);
		bbpFlowRedisData.setIsEsimDevice(Boolean.TRUE);
		bbpFlowRedisData.setBbpimei2("2345678909");
		bbpFlowRedisData.setDevid("1234321234");
		bbpFlowRedisData.setEid("34567890987654321234567890987654321");
		StepVerifier.create(redisHelper2.upsertBBPFlowDataIntoRedis(bbpFlowRedisData)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void upsertBBPFlowZipCodeDataIntoRedisTest(){
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		AddZipcodeRedisData bbpFlowRedisData = new AddZipcodeRedisData();
		bbpFlowRedisData.setZipCode("75038");
		StepVerifier.create(redisHelper2.upsertBBPFlowZipCodeDataIntoRedis(bbpFlowRedisData)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}


	@Test
	public void upsertInitiateESimActivationTest(){
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		InitiateESimActivationUIResponse initiateESimActivationUIResponse = new InitiateESimActivationUIResponse();
		initiateESimActivationUIResponse.setData(new InitiateESimActivationResponseData());
		initiateESimActivationUIResponse.getData().setDeviceId("353486970731141");
		initiateESimActivationUIResponse.getData().setEid("89049032007008882600084725572587");
		initiateESimActivationUIResponse.getData().setIccId("89049032007008882600084725572587");
		StepVerifier.create(redisHelper2.upsertInitiateESimActivation(initiateESimActivationUIResponse)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		StepVerifier.create(redisHelper2.upsertInitiateESimActivation(new InitiateESimActivationUIResponse())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		InitiateESimActivationUIResponse initiateESimActivationUIResponseNull = new InitiateESimActivationUIResponse();
		initiateESimActivationUIResponseNull.setData(new InitiateESimActivationResponseData());
		initiateESimActivationUIResponseNull.getData().setDeviceId(null);
		initiateESimActivationUIResponseNull.getData().setEid(null);
		StepVerifier.create(redisHelper2.upsertInitiateESimActivation(initiateESimActivationUIResponseNull)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper2.upsertInitiateESimActivation(null)).verifyError();
	}

	@Test
	public void updateByodDeviceDetailRedisTest(){
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper3.updateByodDeviceDetailRedis("randomValue","randomValue","randomValue")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(false));
		StepVerifier.create(redisHelper3.updateByodDeviceDetailRedis("","","")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		when(sessionBean.setSessionData(any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper3.updateByodDeviceDetailRedis("","","")).verifyError();
	}

	@Test
	public void getFiveGAddressFromRedisFromFiveGFlowTest(){
		Map map=new HashMap<String,String>();
		map.put("addressLine1","address_Line1");
		map.put("longitude","longitude");
		map.put("eventCorrelationId","9625488");
		map.put("addressLine2","address_Line2");
		map.put("state","state");
		map.put("zipCode","852147");
		map.put("city","city");
		map.put("latitude","latitude");
		map.put("floor",1);
		map.put("buildingId","32547");
		map.put("bundleId","624585");
		map.put("fipsCode","address_Line1");
		map.put("streetName","streetName");
		map.put("streetNumber","9517452");
		map.put("streetType","streetType");
		map.put("aqCaseId","96524");
		map.put("launchType","streetName");
		map.put("LTEQualified","streetName");
		map.put("LTEHomeSku","streetName");
		map.put("prEmailId","streetName");
		map.put("fiveGHomeQualified","fiveGHomeQualified");
		map.put("cbr","cbr");
		map.put("locationId","locationId");
		map.put("addressId","addressId");
		map.put("addressLocationId","addressLocationId");
		map.put("isD2DFlow","isD2DFlow");
		map.put("d2dPosAgentID","d2dPosAgentID");
		map.put("fiveGMUCEligible","fiveGMUCEligible");
		map.put("networkBandwidthType","networkBandwidthType");
		map.put("CBAND_SKU","CBAND_SKU");
		map.put("crmResumeCartFlow","crmResumeCartFlow");
		map.put("cBandSku","cBandSku");
		map.put("bundleId","bundleId");
		map.put("bundleName","bundleName");
		map.put("crmResumeCartFlow","crmResumeCartFlow");
		map.put(CartConstants.OUTLET_ID, "randomValue");
		map.put(CartConstants.VENDOR_ID, "randomValue");
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(map));
		FiveGLTEAddressRedis address = new FiveGLTEAddressRedis();
		StepVerifier.create(redisHelper3.getFiveGAddressFromRedisFromFiveGFlow()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		Map mapNull=new HashMap<String,String>();
		mapNull.put("addressLine1","randomValue");
		mapNull.put("longitude",null);
		mapNull.put("eventCorrelationId",null);
		mapNull.put("addressLine2",null);
		mapNull.put("state",null);
		mapNull.put("zipCode",null);
		mapNull.put("city",null);
		mapNull.put("latitude",null);
		mapNull.put("floor",null);
		mapNull.put("buildingId",null);
		mapNull.put("bundleId",null);
		mapNull.put("fipsCode",null);
		mapNull.put("streetName",null);
		mapNull.put("streetNumber",null);
		mapNull.put("streetType",null);
		mapNull.put("aqCaseId",null);
		mapNull.put("launchType",null);
		mapNull.put("LTEQualified",null);
		mapNull.put("LTEHomeSku",null);
		mapNull.put("prEmailId",null);
		mapNull.put("fiveGHomeQualified",null);
		mapNull.put("cbr",null);
		mapNull.put("locationId",null);
		mapNull.put("isD2DFlow",null);
		mapNull.put("d2dPosAgentID",null);
		mapNull.put("fiveGMUCEligible",null);
		mapNull.put("networkBandwidthType",null);
		mapNull.put("CBAND_SKU",null);
		mapNull.put("crmResumeCartFlow",null);
		mapNull.put("cBandSku",null);
		mapNull.put("bundleId",null);
		mapNull.put("bundleName",null);
		mapNull.put("crmResumeCartFlow",null);
		map.put("addressId",null);
		map.put("addressLocationId",null);
		mapNull.put(CartConstants.OUTLET_ID, null);
		mapNull.put(CartConstants.VENDOR_ID, null);
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(mapNull));
		StepVerifier.create(redisHelper3.getFiveGAddressFromRedisFromFiveGFlow()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		Map mapEmpty=new HashMap<String,String>();
		mapEmpty.put("addressLine1","randomValue");
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(mapEmpty));
		StepVerifier.create(redisHelper3.getFiveGAddressFromRedisFromFiveGFlow()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		mapEmpty.put("addressLine1","randomValue");
		mapEmpty.put("bundleId","NA");
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(mapEmpty));
		StepVerifier.create(redisHelper3.getFiveGAddressFromRedisFromFiveGFlow()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		Map mapEmpty1=new HashMap<String,String>();
		mapEmpty1.put("addressLine1","randomValue");
		mapEmpty1.put("bundleName","NA");
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(mapEmpty1));
		StepVerifier.create(redisHelper3.getFiveGAddressFromRedisFromFiveGFlow()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		mapEmpty1.put("addressLine1",null);
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(mapEmpty1));
		StepVerifier.create(redisHelper3.getFiveGAddressFromRedisFromFiveGFlow()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		Map mapEmpty2=new HashMap<String,String>();
		mapEmpty2.put("addressLine1","randomValue");
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(mapEmpty2));
		StepVerifier.create(redisHelper3.getFiveGAddressFromRedisFromFiveGFlow()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(new HashMap()));
		StepVerifier.create(redisHelper3.getFiveGAddressFromRedisFromFiveGFlow()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        map.put("networkBandwidthType","cbd");
        map.put("bundleId","bundleId");
        map.put("bundleName","bundleName");
        map.put("addressLine1","address_Line1");
        when(sessionBean.getSessionData(any())).thenReturn(Mono.just(map));
        StepVerifier.create(redisHelper3.getFiveGAddressFromRedisFromFiveGFlow()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();


        map.put("networkBandwidthType",null);
        when(sessionBean.getSessionData(any())).thenReturn(Mono.just(map));
        StepVerifier.create(redisHelper3.getFiveGAddressFromRedisFromFiveGFlow()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        map.put("networkBandwidthType","cbd");
        map.put("cBandSku",null);
        when(sessionBean.getSessionData(any())).thenReturn(Mono.just(map));
        StepVerifier.create(redisHelper3.getFiveGAddressFromRedisFromFiveGFlow()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        map.put("cBandSku","cbandsku");
        when(sessionBean.getSessionData(any())).thenReturn(Mono.just(map));
        StepVerifier.create(redisHelper3.getFiveGAddressFromRedisFromFiveGFlow()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void setRedesignFlaginRedisTest(){
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		Mono<Boolean> controllerResponse = redisHelper3.setRedesignFlaginRedis( );
		StepVerifier.create( redisHelper3.setRedesignFlaginRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}


	@Test
	public void fetchCustomerAddressFromRedisTest()throws IOException {
		Map map=new HashMap<Object,Object>();
		String customerProfileAddressGQLResponse = "{\"meta\":{\"timestamp\":\"1634555184356\",\"cxpCorrelationId\":\"2021-10-18T11:06:24.+0000:e46a3fe3-aeb0-45b0-bd12-24a64451b5d9:cxp-customerprofile-se-qa-ev6v-sit1e-nscxp-578d8f44f-462f4:nssit1\"},\"data\":{\"customerByMtn\":{\"address\":{\"addressId\":\"430568040994904361\",\"addressLine1\":\"5618 FAIRDALE LN\",\"area\":\"South|Houston, TX\",\"city\":\"HOUSTON\",\"countryCode\":\"USA\",\"countryName\":\"UNITED STATES OF AMERICA\",\"county\":\"201\",\"fipsCode\":\"4820135000\",\"geoCode\":\"USA48201350000\",\"state\":\"TX\",\"stateName\":\"TEXAS\",\"validAddress\":\"true\",\"zipCode\":\"77057\",\"zipCodePlus4\":\"6302\",\"scrubbedAddress\":{\"city\":\"HOUSTON\",\"state\":\"TX\",\"streetName\":\"FAIRDALE\",\"streetNumber\":\"5618\",\"streetType\":\"LN\",\"zipCode\":\"77057\",\"zipCodePlus4\":\"6302\"}},\"billAccounts\":[{\"billAccountNo\":\"1\"}],\"customerId\":\"430568040\"}}}";
		CustomerProfileAddressResponse customerProfileAddressResponse = mapper.readValue(customerProfileAddressGQLResponse, CustomerProfileAddressResponse.class);
		map.put("CustomerProfileAddressGQLResponse",customerProfileAddressGQLResponse);
		map.put("accountNumber","6564785214663");
		map.put("intentType","intentType");
		map.put("bundleId","bundleId");
		map.put("bundleName","bundleName");
		map.put("crmResumeCartFlow","crmResumeCartFlow");
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(map));
		FiveGLTEAddressRedis address = new FiveGLTEAddressRedis();
		StepVerifier.create(redisHelper3.fetchCustomerAddressFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		Map mapNull1=new HashMap<Object,Object>();
		mapNull1.put(CartConstants.EUP_5G_CUSTOMER_PROFILE_ADDRESS,"randomValue");
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(mapNull1));
		StepVerifier.create(redisHelper3.fetchCustomerAddressFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		Map mapNull=new HashMap<Object,Object>();
		mapNull.put(CartConstants.EUP_5G_CUSTOMER_PROFILE_ADDRESS,"randomValue");
		mapNull.put(CartConstants.BUNDLEID,null);
		mapNull.put(CartConstants.BUNDLENAME,null);
		mapNull.put(CartConstants.ACCOUNT_NUMBER,null);
		mapNull.put(CartConstants.INTENT_TYPE,null);
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(mapNull));
		StepVerifier.create(redisHelper3.fetchCustomerAddressFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		Map mapNull2=new HashMap<Object,Object>();
		mapNull2.put(CartConstants.EUP_5G_CUSTOMER_PROFILE_ADDRESS,"randomValue");
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(mapNull2));
		StepVerifier.create(redisHelper3.fetchCustomerAddressFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(new HashMap()));
		StepVerifier.create(redisHelper3.fetchCustomerAddressFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void upsertCRMDataIntoRedisAsStringTest() {
		Map map=new HashMap<Object,Object>();
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper3.upsertCRMDataIntoRedisAsString(map)).expectSubscription( ).verifyComplete();

	}
	@Test
	public void fetchTechnicianDataFromRedisTest(){
		Map sessionData = new HashMap<Object,Object>();
		sessionData.put("VPMLocationCode", "WEST");
		sessionData.put("VPMOrderNumber", "9205726029");
		sessionData.put("aud", "9205726029");
		sessionData.put("exp", "10-10-2021");
		sessionData.put("iat", "565656561");
		sessionData.put("intentType", "NSE_5G");
		sessionData.put("iss", "10-10-2021");
		sessionData.put("mtn", "965684855");
		sessionData.put("sales_id", "965541");
		sessionData.put("sub", "TRUE");
		sessionData.put("cBandSku", "TRUE");
		sessionData.put("cBandRepId", "TRUE");
		sessionData.put("cBandOutletId", "TRUE");
		sessionData.put("fiveGPlan", "TRUE");
		sessionData.put("fiveGPlan", "TRUE");
		sessionData.put("cBandAuthMTN", "TRUE");
		sessionData.put("eup_5G_acc_number", "99599994");
		sessionData.put(CartConstants.CUSTOMER_EMAILID,"emailId");
		sessionData.put(CartConstants.CPC_ORDER_TYPE,"preorder");
		sessionData.put(CartConstants.CPC_PLAN_ID,"123456");
		sessionData.put(CartConstants.CART_ID,"732846g78-44t-435424-252452-325436rg");
		sessionData.put(CartConstants.CASE_ID,"SOP-86868-OE");

		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(sessionData));
		StepVerifier.create(redisHelper3.fetchTechnicianDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(new HashMap()));
		StepVerifier.create(redisHelper3.fetchTechnicianDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		Map sessionDataNull = new HashMap<Object,Object>();
		sessionDataNull.put("VPMLocationCode", null);
		sessionDataNull.put("VPMOrderNumber", null);
		sessionDataNull.put("aud", null);
		sessionDataNull.put("exp", null);
		sessionDataNull.put("iat", null);
		sessionDataNull.put("intentType", null);
		sessionDataNull.put("iss", null);
		sessionDataNull.put("mtn", null);
		sessionDataNull.put("sales_id", null);
		sessionDataNull.put("sub", null);
		sessionDataNull.put("cBandSku", null);
		sessionDataNull.put("cBandRepId", null);
		sessionDataNull.put("cBandOutletId", null);
		sessionDataNull.put("fiveGPlan", null);
		sessionDataNull.put("fiveGPlan", null);
		sessionDataNull.put("cBandAuthMTN", null);
		sessionDataNull.put("eup_5G_acc_number", null);
		sessionDataNull.put("basicToBasicCpc", null);
		sessionDataNull.put(CartConstants.CUSTOMER_EMAILID,null);
		sessionDataNull.put(CartConstants.CPC_ORDER_TYPE,null);
		sessionDataNull.put(CartConstants.CPC_PLAN_ID,null);
		sessionDataNull.put(CartConstants.CART_ID,null);
		sessionDataNull.put(CartConstants.CASE_ID,null);
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(sessionDataNull));
		StepVerifier.create(redisHelper3.fetchTechnicianDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		sessionDataNull.put(CartConstants.EUP_5G_ACCOUNT_NUMBER,null);
		sessionDataNull.put(CartConstants.ACCOUNT_NUMBER,null);
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(sessionDataNull));
		StepVerifier.create(redisHelper3.fetchTechnicianDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		Map emptyCheck = new HashMap();
		emptyCheck.put(CartConstants.EUP_5G_ACCOUNT_NUMBER,null);
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(emptyCheck));
		StepVerifier.create(redisHelper3.fetchTechnicianDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

	}
	@Test
	public void fetchTechFlowAuditDetailsTest(){
		Map sessionData = new HashMap<Object,Object>();
		sessionData.put("VPMLocationCode", "NHC1234");
		sessionData.put("VPMOrderNumber", "1234545");
		sessionData.put("serviceAddress", "WEST STREET AVENUE CHICAHO IL 202345");
		sessionData.put("fiveGPlan", "123345");
		sessionData.put("intentType", "AAL_CPC_CBD_TECH");
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(sessionData));
		StepVerifier.create(redisHelper3.fetchTechFlowAuditDetails()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void fetchTechFlowAuditDetailsNullTest(){
		Map sessionData = new HashMap<Object,Object>();
		sessionData.put("VPMLocationCode", null);
		sessionData.put("VPMOrderNumber", null);
		sessionData.put("serviceAddress", null);
		sessionData.put("fiveGPlan", null);
		sessionData.put("intentType", null);
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(sessionData));
		StepVerifier.create(redisHelper3.fetchTechFlowAuditDetails()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void fetchTechFlowAuditDetailsEmptyTest(){
		Map sessionData = new HashMap<Object,Object>();
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(sessionData));
		StepVerifier.create(redisHelper3.fetchTechFlowAuditDetails()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void fetchTechnicianDataFromRedisAccountNumberTest(){
		Map sessionData = new HashMap<Object,Object>();
		sessionData.put("VPMLocationCode", "WEST");
		sessionData.put("VPMOrderNumber", "9205726029");
		sessionData.put("aud", "9205726029");
		sessionData.put("exp", "10-10-2021");
		sessionData.put("iat", "565656561");
		sessionData.put("intentType", "NSE_5G");
		sessionData.put("iss", "10-10-2021");
		sessionData.put("mtn", "965684855");
		sessionData.put("sales_id", "965541");
		sessionData.put("sub", "TRUE");
		sessionData.put("cBandSku", "TRUE");
		sessionData.put("cBandRepId", "TRUE");
		sessionData.put("cBandOutletId", "TRUE");
		sessionData.put("fiveGPlan", "TRUE");
		sessionData.put("fiveGPlan", "TRUE");
		sessionData.put("cBandAuthMTN", "TRUE");
		sessionData.put("accountNumber", "99599994");
		sessionData.put("basicToBasicCpc", "Y");
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(sessionData));
		StepVerifier.create(redisHelper3.fetchTechnicianDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void getCartDataFromRedisForFiveGFlowTest(){
		Map sessionData = new HashMap<Object,Object>();
		sessionData.put(CartConstants.CHANNEL_ID, "00001");
		sessionData.put(CartConstants.CART_ID, "056640046564601");
		sessionData.put(CartConstants.INTENTTYPE, "NSE_5G");
		sessionData.put(CartConstants.IS_REDESIGN_FLOW, "TRUE");
		sessionData.put(CartConstants.NETWORK_BANDWIDTH_TYPE, "5G");
		sessionData.put(CartConstants.CRM_RESUME_CART_FLOW, "TRUE");
		sessionData.put(CartConstants.ADDRESSLINE1, "800S OGDEN STREET");
		sessionData.put(CartConstants.COMPLETED_CARTID_CONST,"68s65865a57475c65a");
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(sessionData));
		StepVerifier.create(redisHelper3.getCartDataFromRedisForFiveGFlow()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(new HashMap()));
		StepVerifier.create(redisHelper3.getCartDataFromRedisForFiveGFlow()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();


		Map sessionDataNull = new HashMap<Object,Object>();
		sessionDataNull.put(CartConstants.CHANNEL_ID, null);
		sessionDataNull.put(CartConstants.CART_ID, null);
		sessionDataNull.put(CartConstants.INTENTTYPE, null);
		sessionDataNull.put(CartConstants.IS_REDESIGN_FLOW, null);
		sessionDataNull.put(CartConstants.NETWORK_BANDWIDTH_TYPE, null);
		sessionDataNull.put(CartConstants.CRM_RESUME_CART_FLOW, null);
		sessionDataNull.put(CartConstants.ADDRESSLINE1, null);
		sessionData.put(CartConstants.SAFETECH_SESSION_ID, null);
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(sessionDataNull));
		StepVerifier.create(redisHelper3.getCartDataFromRedisForFiveGFlow()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void setIntendTypeInRedisTest(){
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper3.setIntendTypeInRedis("NSE_5G")).expectSubscription( ).verifyComplete();
	}
	@Test
	public void getCartDataFromRedisForFiveGFlowNonRedesignTest(){
		Map sessionData = new HashMap<Object,Object>();
		sessionData.put(CartConstants.CHANNEL_ID, "00001");
		sessionData.put(CartConstants.CART_ID, "056640046564601");
		sessionData.put(CartConstants.INTENTTYPE, "NSE_5G");
		sessionData.put(CartConstants.NETWORK_BANDWIDTH_TYPE, "5G");
		sessionData.put(CartConstants.CRM_RESUME_CART_FLOW, "TRUE");
		sessionData.put(CartConstants.ADDRESSLINE1, "800S OGDEN STREET");
		sessionData.put(CartConstants.SAFETECH_SESSION_ID, "0229cd48-af4d-4615-b35e-b81322f26569");
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(sessionData));
		StepVerifier.create(redisHelper3.getCartDataFromRedisForFiveGFlow()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void upsertDeviceSimValidationDataIntoRedisTest(){
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		DeviceSimValidationUIResponseData Data = new DeviceSimValidationUIResponseData();
		Data.setIccid("12345678");
		Data.setImei("64676466473");
		Data.setIsSmartphone(true);
		Data.setBbpDefaultZipcodeForTabletFlow("7920");
		Data.setIsEsimDevice(true);
		Data.setIsValidationSuccess(true);
		Data.setDevid("1234");
		Data.setESimType("esim");
		Data.setFlowType("NSE");
		Data.setEid("12345");
		Data.setPhoneNumber("123456789");
		Data.setEmail("asdfghjkl");
		Data.setDevid("12345");
		Data.setLastName("mha");
		Data.setFirstName("lak");
		Data.setZipcode("520002");
		Data.setImei2("1234");
		StepVerifier.create(redisHelper2.upsertDeviceSimValidationDataIntoRedis(Data)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		DeviceSimValidationUIResponseData deviceSimValidationUIResponseData = new DeviceSimValidationUIResponseData();
		deviceSimValidationUIResponseData.setIsEsimDevice(null);
		deviceSimValidationUIResponseData.setIsSmartphone(null);
		deviceSimValidationUIResponseData.setIsSDKDevice(null);
		deviceSimValidationUIResponseData.setIsValidationSuccess(null);
		StepVerifier.create(redisHelper2.upsertDeviceSimValidationDataIntoRedis(deviceSimValidationUIResponseData)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void upsertDeviceSimValidationDataIntoRedisTest1(){
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		DeviceSimValidationUIResponseData Data = new DeviceSimValidationUIResponseData();
		Data.setIccid("12345678");
		Data.setImei("64676466473");
		Data.setIsSmartphone(true);
		Data.setBbpDefaultZipcodeForTabletFlow("7920");
		Data.setIsEsimDevice(true);
		Data.setIsValidationSuccess(true);
		Data.setDevid("1234");
		Data.setESimType("esim");
		Data.setFlowType("NSE");
		Data.setEid("12345");
		Data.setPhoneNumber("123456789");
		Data.setEmail("asdfghjkl");
		Data.setDevid("12345");
		Data.setLastName("mha");
		Data.setFirstName("lak");
		Data.setZipcode("520002");
		Data.setImei2("1234");
		StepVerifier.create(redisHelper2.upsertDeviceSimValidationDataIntoRedis(Data)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		Data.setIsSmartphone(false);
		StepVerifier.create(redisHelper2.upsertDeviceSimValidationDataIntoRedis(Data)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		Data.setIsEsimDevice(null);
		StepVerifier.create(redisHelper2.upsertDeviceSimValidationDataIntoRedis(Data)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		Data.setIsValidationSuccess(null);
		StepVerifier.create(redisHelper2.upsertDeviceSimValidationDataIntoRedis(Data)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		Data.setEsimFlowType("BYOD");
		Data.setPendingMdn("1234");
		StepVerifier.create(redisHelper2.upsertDeviceSimValidationDataIntoRedis(Data)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void checkIfAnyLinesAreEUPOrBYODTest(){
		ValidateCartUIResponse validateCartUIResponse= new ValidateCartUIResponse();
		CXPValidateCartDataVO cXPValidateCartDataVO = new CXPValidateCartDataVO();
		CXPCartVO cXPCartVO = new CXPCartVO();
		CXPLineDetailsVO cXPLineDetailsVO = new CXPLineDetailsVO();
		CXPLineInfo cXPLineInfo = new CXPLineInfo();
		cXPLineInfo.setLineActivityType("EUP");
		CXPLineInfo[] cXPLineInfoArr = new CXPLineInfo[2];
		cXPLineInfoArr[0] = cXPLineInfo;
		cXPLineDetailsVO.setLineInfo(cXPLineInfoArr);
		cXPCartVO.setLineDetails(cXPLineDetailsVO);
		cXPValidateCartDataVO.setValidateCartAndUpdate(cXPCartVO);
		validateCartUIResponse.setData(cXPValidateCartDataVO);
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(getSessionData()));
		Assert.assertFalse(redisHelper2.checkIfAnyLinesAreEUPOrBYOD(validateCartUIResponse));

		cXPLineInfo.setLineActivityType("BYOD");
		cXPLineInfoArr[0] = cXPLineInfo;
		cXPLineDetailsVO.setLineInfo(cXPLineInfoArr);
		cXPCartVO.setLineDetails(cXPLineDetailsVO);
		cXPValidateCartDataVO.setValidateCartAndUpdate(cXPCartVO);
		validateCartUIResponse.setData(cXPValidateCartDataVO);
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(getSessionData()));
		Assert.assertFalse(redisHelper2.checkIfAnyLinesAreEUPOrBYOD(validateCartUIResponse));

		/*cXPLineInfo.setLineActivityType("BYODDD");
		cXPLineInfoArr[0] = cXPLineInfo;
		cXPLineDetailsVO.setLineInfo(cXPLineInfoArr);
		cXPCartVO.setLineDetails(cXPLineDetailsVO);
		cXPValidateCartDataVO.setValidateCartAndUpdate(cXPCartVO);
		validateCartUIResponse.setData(cXPValidateCartDataVO);
		when(sessionBean.getSessionData(Mockito.any())).thenReturn(Mono.just(getSessionData()));
		Assert.assertFalse(redisHelper.checkIfAnyLinesAreEUPOrBYOD(validateCartUIResponse));*/

		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(getSessionData()));
		Assert.assertFalse(redisHelper2.checkIfAnyLinesAreEUPOrBYOD(new ValidateCartUIResponse()));
	}
	@Test
	public void upsertOrderEligibilityInRedisTest() {
		ValidateCartUIResponse validateCartUIResponse = new ValidateCartUIResponse();
		CXPValidateCartDataVO cXPValidateCartDataVO = new CXPValidateCartDataVO();
		CXPCartVO cXPCartVO = new CXPCartVO();
		RetrieveCartHeader retrieveCartHeader = new RetrieveCartHeader();
		retrieveCartHeader.setFullAccountNumber("");
		cXPCartVO.setCartHeader(retrieveCartHeader);
		CXPLineDetailsVO cXPLineDetailsVO = new CXPLineDetailsVO();
		CXPLineInfo cXPLineInfo = new CXPLineInfo();
		cXPLineInfo.setLineActivityType("EUP");
		cXPLineInfo.setLineNumber("1");
		CXPLineInfo[] cXPLineInfoArr = new CXPLineInfo[2];
		cXPLineInfoArr[0] = cXPLineInfo;
		cXPLineInfoArr[1] = cXPLineInfo;
		cXPLineDetailsVO.setLineInfo(cXPLineInfoArr);
		cXPCartVO.setLineDetails(cXPLineDetailsVO);
		cXPValidateCartDataVO.setValidateCartAndUpdate(cXPCartVO);
		validateCartUIResponse.setData(cXPValidateCartDataVO);

		when(sessionBean.getChannelType()).thenReturn("Digital");
		Map newMap = new HashMap();
		newMap.put("intentType","NSE_5G");
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(newMap));
		when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(true));
		when(sessionBean.setSessionData("accountInfoValidate", true)).thenReturn(Mono.just(true));
//		when(redisHelper2.checkIfAnyLinesAreEUPOrBYOD(Mockito.any())).thenReturn(Boolean.TRUE);
		StepVerifier.create(redisHelper2.upsertOrderEligibilityInRedis("randomValue", validateCartUIResponse)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.getChannelType()).thenReturn("Digital");
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(new HashMap()));
//		when(redisHelper.checkIfAnyLinesAreEUPOrBYOD(new ValidateCartUIResponse())).thenReturn(false);
		StepVerifier.create(redisHelper2.upsertOrderEligibilityInRedis("randomValue", validateCartUIResponse)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.getChannelType()).thenReturn("DigitalRandomValue");
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(new HashMap()));
		StepVerifier.create(redisHelper2.upsertOrderEligibilityInRedis("randomValue", validateCartUIResponse)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void inFlightOrderCheckTest() {
		ValidateCartUIResponse validateCartUIResponse = new ValidateCartUIResponse();
		CXPValidateCartDataVO cXPValidateCartDataVO = new CXPValidateCartDataVO();
		CXPCartVO cXPCartVO = new CXPCartVO();
		RetrieveCartHeader retrieveCartHeader = new RetrieveCartHeader();
		retrieveCartHeader.setFullAccountNumber("randomvalues");
		cXPCartVO.setCartHeader(retrieveCartHeader);
		CXPLineDetailsVO cXPLineDetailsVO = new CXPLineDetailsVO();
		CXPLineInfo cXPLineInfo = new CXPLineInfo();
		cXPLineInfo.setLineActivityType("EUP");
		cXPLineInfo.setLineNumber("1");
		CXPLineInfo[] cXPLineInfoArr = new CXPLineInfo[3];
		cXPLineInfoArr[0] = cXPLineInfo;
		cXPLineInfoArr[1] = cXPLineInfo;
		cXPLineInfoArr[2] = cXPLineInfo;
		cXPLineDetailsVO.setLineInfo(cXPLineInfoArr);
		cXPCartVO.setLineDetails(cXPLineDetailsVO);
		cXPValidateCartDataVO.setValidateCartAndUpdate(cXPCartVO);
		validateCartUIResponse.setData(cXPValidateCartDataVO);
		when(sessionBean.getChannelType()).thenReturn("Digital");
		Map newMap = new HashMap();
		newMap.put("intentType","NSE_5G");
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(newMap));
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(true));
		when(soeMtnExpireClient.multiReadSessionValues(any(), any())).thenReturn(Mono.just(Arrays.asList("1","2","3")));
		StepVerifier.create(redisHelper2.inFlightOrderCheck(validateCartUIResponse)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(soeMtnExpireClient.multiReadSessionValues(any(), any())).thenReturn(Mono.empty());
		StepVerifier.create(redisHelper2.inFlightOrderCheck(validateCartUIResponse)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		Arrays.stream(cXPLineDetailsVO.getLineInfo()).forEach(e -> e.setLineActivityType("Intend"));
		cXPCartVO.setLineDetails(cXPLineDetailsVO);
		cXPValidateCartDataVO.setValidateCartAndUpdate(cXPCartVO);
		validateCartUIResponse.setData(cXPValidateCartDataVO);
		when(soeMtnExpireClient.multiReadSessionValues(any(), any())).thenReturn(Mono.just(Arrays.asList("1","2","3")));
		StepVerifier.create(redisHelper2.inFlightOrderCheck(validateCartUIResponse)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(soeMtnExpireClient.multiReadSessionValues(any(), any())).thenReturn(Mono.just(Arrays.asList(null, null, null)));
		StepVerifier.create(redisHelper2.inFlightOrderCheck(validateCartUIResponse)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		when(sessionBean.getChannelType()).thenReturn("DigitalRA");
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(new HashMap()));
		StepVerifier.create(redisHelper2.inFlightOrderCheck(validateCartUIResponse)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void getRPSDataFromRedisTest() throws JsonMappingException, JsonProcessingException{
		Map sessionData = new HashMap();
		sessionData.put(CartConstants.RPS_FLOW_PAIRING_MODE,"randomValue");
		sessionData.put(CartConstants.RPS_FLOW_PHONE_MTN,"randomValue");
		sessionData.put(CartConstants.RPS_FLOW_IMEI,"randomValue");
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(sessionData));
		StepVerifier.create(redisHelper2.getRPSDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(new HashMap()));
		StepVerifier.create(redisHelper2.getRPSDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	/**@Test
	public void pullUpgradeLinesFromResponseTest() {
	ValidateCartUIResponse validateCartUIResponse = new ValidateCartUIResponse();
	CXPValidateCartDataVO cXPValidateCartDataVO = new CXPValidateCartDataVO();
	CXPCartVO cXPCartVO = new CXPCartVO();
	CXPLineDetailsVO cXPLineDetailsVO = new CXPLineDetailsVO();
	CXPLineInfo cXPLineInfo = new CXPLineInfo();
	cXPLineInfo.setLineActivityType("EUP");
	CXPLineInfo cXPLineInfoArr[] = new CXPLineInfo[2];
	cXPLineInfoArr[0] = cXPLineInfo;
	cXPLineDetailsVO.setLineInfo(cXPLineInfoArr);
	cXPCartVO.setLineDetails(cXPLineDetailsVO);
	cXPValidateCartDataVO.setValidateCartAndUpdate(cXPCartVO);
	validateCartUIResponse.setData(cXPValidateCartDataVO);
	StepVerifier.create(redisHelper.pullUpgradeLinesFromResponse(validateCartUIResponse)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}**/
	@Test
	public void getAccountInfoEligibleFlagFromRedisTest() throws JsonMappingException, JsonProcessingException{
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(new AccountInfoEligible()));
		StepVerifier.create(redisHelper2.getAccountInfoEligibleFlagFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void upsertInitiateCbandCheckDataIntoRedisTest() throws JsonMappingException, JsonProcessingException{
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		InitiateCbandCheckResponseData initiateCbandCheckResponseData=new InitiateCbandCheckResponseData();
		VmasBootUpInfo vmasBootUpInfo = new VmasBootUpInfo();
		vmasBootUpInfo.setDeviceReachable("radomDevice");
		vmasBootUpInfo.setMtn("radomDevice");
		vmasBootUpInfo.setSnr5G("radomDevice");
		vmasBootUpInfo.setNetworkType("radomDevice");
		vmasBootUpInfo.setSetupReason("radomDevice");
		vmasBootUpInfo.setPostMount5GSignal("radomDevice");
		initiateCbandCheckResponseData.setVmasBootUpInfo(vmasBootUpInfo);
		initiateCbandCheckResponseData.setBillAccountNo("1234");
		initiateCbandCheckResponseData.setCustomerId("0001");
		StepVerifier.create(redisHelper2.upsertInitiateCbandCheckDataIntoRedis(initiateCbandCheckResponseData)).assertNext(resp -> Assert.assertNotNull(resp)).expectError();

		vmasBootUpInfo.setDeviceReachable(null);
		vmasBootUpInfo.setMtn(null);
		vmasBootUpInfo.setSnr5G(null);
		vmasBootUpInfo.setNetworkType(null);
		vmasBootUpInfo.setSetupReason(null);
		vmasBootUpInfo.setPostMount5GSignal(null);
		initiateCbandCheckResponseData.getVmasBootUpInfo().setPostMount5GSignal(null);
		initiateCbandCheckResponseData.setBillAccountNo(null);
		initiateCbandCheckResponseData.setCustomerId(null);
		StepVerifier.create(redisHelper2.upsertInitiateCbandCheckDataIntoRedis(initiateCbandCheckResponseData)).assertNext(resp -> Assert.assertNotNull(resp)).expectError();
	}

	@Test
	public void upsertCreditCheckFailureCountIntoRedisTest() throws JsonMappingException, JsonProcessingException{
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		String responseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-NETACE\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \"SOP-20647-E01\", \"contextInfo\": { \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"OrderReview-Shipping-Payment-Agreement\", \"processAction\": \"\", \"availablePaths\": [ { \"path\": \"AvailablePaths\" } ] }, \"cartInfo\": { \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"method\": \"addtoCart\" }, \"customerInfo\": { \"registerNumber\": 0, \"accountNumber\": \"0224065213-00001\", \"cartCreator\": \"2402169848\", \"processingMTN\": \"2402169848\" }, \"processMTNList\": [ { \"mtn\": \"2402169848\", \"completedprocessSteps\": [ \"MTNSelectionPage\", \"GridWallPDP\", \"ShoppingCart\" ] } ], \"validateOrder\": { \"orderDetails\": [ { \"systemId\": \"\", \"creditApplicationNum\": \"382938499\", \"orderStatus\": \"SUCCESS\", \"shipmentAddressValidated\": true, \"userId\": \"\", \"statusMsg\": \"\", \"creditApprovalStatus\": \"AP\", \"creditStatusReason\": \"CA CVAS AUTOMATIC APPROVAL\", \"securityDepositAmount\": \"0\", \"loveligibility\": false, \"statusCode\": \"\" } ], \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"locationCode\": \"E247201\" } } } }, \"cartReadyForCheckout\": true }";
		InitiateCheckoutUIResponse response = mapper.readValue(responseString, InitiateCheckoutUIResponse.class);
		StepVerifier.create(redisHelper2.upsertCreditCheckFailureCountIntoRedis(1,response)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.upsertCreditCheckFailureCountIntoRedis(5,response)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.upsertCreditCheckFailureCountIntoRedis(0,response)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getDataFromRedisTest2(){
		String requestString = "{  \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",  \"caseId\" : \"SOP-1023325-E01\",  \"intendType\" : \"EUP\",  \"lines\" : [ {    \"preBackOrderDate\" : \"04-30-2020\",    \"preBackOrderDisplayType\" : \"Ships by\",    \"mtn\" : \"8473096013\",    \"device\" : {      \"id\" : \"OPIN20190BKLR\",      \"dppMonths\" : 24,      \"contractTerm\" : \"VERIZON_EDGE\",      \"qty\" : 1    },    \"sim\" : {      \"id\" : \"EMBD4GSIM-N\"    },    \"ispuFlow\" : false,    \"depletionLocationCode\" : \"\",    \"depletionType\" : \"F\",    \"isKeepingExistingEqProtection\" : true,    \"isNewLine\" : false  } ],  \"deviceCartInfo\" : {    \"clientAppName\" : \"VZW-ECOM\",    \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",    \"caseId\" : \"SOP-1023325-E01\",    \"accountNumber\" : \"0280363949-00001\",    \"cartCreator\" : \"8472046549\",    \"processingMTN\" : \"8473096013\",    \"processStep\" : \"GridWallPDP\",    \"intendType\" : \"EUP\",    \"processAction\" : \"addDevice\",    \"editDevice\" : false, \\\"intent\\\" : \\\"NLG\\\"  }}";
		String rfexExchangeShopDetailsString = "{\"mtn\" : \"654892298\",\"returnItemSeq\" : \"1\"}";
		Map sessionData = new HashMap<Object,Object>();
		sessionData.put(SessionConstants.ACCOUNT_NUMBER_KEY, "0480298581-00001");
		sessionData.put(CartConstants.REP_ROLE, "0480298581-00001");
		sessionData.put(CartConstants.PENDING_ICCID, "0480298581-00001");
		sessionData.put(CartConstants.ESIMTYPE, "0480298581-00001");
		sessionData.put(CartConstants.ESIMFLOWTYPE, "0480298581-00001");
		sessionData.put(CartConstants.PENDING_MDN, "0480298581-00001");
		sessionData.put(SessionConstants.MTN_KEY, "9205726029");
		sessionData.put(CartConstants.CART_ID, "c4d4360d-3d96-4b37-95b8-dd12881b2fff");
		sessionData.put(CartConstants.CASE_ID, "SOP-119933-2");
		sessionData.put(CartConstants.PROCESSING_MTN, "9205726029");
		sessionData.put(CartConstants.CART_CREATOR, "9205726029");
		sessionData.put(CartConstants.FIVEG_UPSELL, "true");
		sessionData.put(CartConstants.CCAR_WIFI_STATE,"");
		sessionData.put(CartConstants.BRAND_NAME,"");
		CartRedisData addDeviceRequest = new CartRedisData();
		addDeviceRequest.setLines(Arrays.asList(new Lines(), new Lines(), new Lines()));
		sessionData.put(CartConstants.ADD_DEVICE_REQUEST, String.valueOf(addDeviceRequest));
		CartRedisData addAccessoryRequest = new CartRedisData();
		addDeviceRequest.setLines(Arrays.asList(new Lines(), new Lines(), new Lines()));
		sessionData.put(CartConstants.ADD_ACCESSORY_REQUEST, String.valueOf(addAccessoryRequest));
		sessionData.put(CartConstants.RESTRICTED_PRODUCT_TYPE, "EQP");
		sessionData.put(CartConstants.IS_SMARTPHONE,"true");
		sessionData.put(CartConstants.BBP_ICCID,"89148000000835900458");
		sessionData.put(CartConstants.BBP_IMEI,"352898071702915");
		sessionData.put(CartConstants.RFEX_EXCHANGE_SHOP_DETAILS, rfexExchangeShopDetailsString);
		sessionData.put(CartConstants.INTENT_REDIS,"NLG");
		sessionData.put(CartConstants.IMEI,"33619_1655467826843_729");
		sessionData.put(CartConstants.Z1_OFFER_CODE,"33619_1655467826843_729");
		sessionData.put(CartConstants.SW_COUPON_CODE,"33619_1655467826843_729");
		sessionData.put(CartConstants.IS_VALID_CUSTOMER,null);
		sessionData.put(CartConstants.SAFETECH_SESSION_ID,"33619_1655467826843_729");
		sessionData.put(CartConstants.VZPH_REMOVED,"33619_1655467826843_729");
		sessionData.put(CartConstants.COMPLETED_CARTID_CONST,"33619_1655467826843_729");
		sessionData.put(CartConstants.COMPLETED_CASEID_CONST,"33619_1655467826843_729");
		sessionData.put(CartConstants.FLOW_NAME,"EUP");
		sessionData.put(CartConstants.PLAN_TAGGING_DETAILS,"123");
		Map intentTokenResponse = new HashMap();
		// intentTokenResponse
		intentTokenResponse.put(CartConstants.EID, "randomValue");
		intentTokenResponse.put(CartConstants.ICCID, "randomValue");
		intentTokenResponse.put(CartConstants.HAND_OFF_TOKEN, "randomValue");
		intentTokenResponse.put(CartConstants.IMEI2, "randomValue");
		intentTokenResponse.put(CartConstants.IMEI, "randomValue");
		intentTokenResponse.put(CartConstants.IMSI, "VZWCS-17115");
		intentTokenResponse.put(CartConstants.GIG, "randomValue");
		intentTokenResponse.put(CartConstants.INTENT_REDIS, "randomValue");
		sessionData.put(CartConstants.INTENT_TOKEN_RESPONSE, String.valueOf(intentTokenResponse));
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(sessionData));
		sessionData.put(CartConstants.BYOD_IMEI_DETAILS,"1234");
		sessionData.put(CartConstants.PAST_DUE, "1234");
		StepVerifier.create(redisHelper.getDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		sessionData.put(CartConstants.VZPH_REMOVED,null);
		sessionData.put(CartConstants.COMPLETED_CARTID_CONST,null);
		sessionData.put(CartConstants.COMPLETED_CASEID_CONST,null);
		sessionData.put(CartConstants.CART_CREATOR,null);
		sessionData.put(CartConstants.ADD_ACCESSORY_REQUEST,null);
		sessionData.put(CartConstants.EID,null);
		sessionData.put(CartConstants.IMSI,null);
		sessionData.put(CartConstants.INTENT_TOKEN_RESPONSE,null);
		sessionData.put(CartConstants.INTENT_REDIS,null);
		sessionData.put(CartConstants.BYOD_IMEI_DETAILS,null);
		sessionData.put(CartConstants.FLOW_NAME,null);
		sessionData.put(CartConstants.PLAN_TAGGING_DETAILS,null);
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(sessionData));
		StepVerifier.create(redisHelper.getDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		sessionData.put(CartConstants.INTENT_REDIS,"nlg");
		sessionData.put(CartConstants.IMSI,"null");
		sessionData.put(SessionConstants.MTN_KEY,null);
		sessionData.put(CartConstants.FLOW_NAME,"");
		sessionData.put(CartConstants.PLAN_TAGGING_DETAILS,"");
		sessionData.put(CartConstants.DUAL_NUMBER,"1234");
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(sessionData));
		StepVerifier.create(redisHelper.getDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		sessionData.put(CartConstants.INTENT_REDIS,"nla");
		String group= "[{\"mtn\":\"123\",\"action\":\"action\",\"group\":1,\"path\":\"path\"}]";
		sessionData.put(CartConstants.PLAN_TAGGING_DETAILS, group);
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(sessionData));
		StepVerifier.create(redisHelper.getDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		sessionData.put(SessionConstants.UID,"1234567890");
		sessionData.put(CartConstants.USER_ROLE,"testUserRole");
		sessionData.put(SessionConstants.LINE_ACTIVITY_TYPE,"NSEBYOD");
		sessionData.put(CartConstants.RELINQUISH_ACCOUNT_NUMBER,"1234567890");
		sessionData.put(SessionConstants.LINE_ACTIVITY_TYPE,"NSEBYOD");
		sessionData.put(CartConstants.TYS_LINES_COUNT,"1");
		sessionData.put(CartConstants.LOCATION_SUB_TYPE,"locationSubType");

		sessionData.put(CartConstants.REASON_FOR_VISIT,"customer");
		sessionData.put(CartConstants.IS_HOME_SALES,"true");
		sessionData.put(CartConstants.HOME_SALES_ADDRESS,"");
		sessionData.put(CartConstants.ISCOMBOORDERALLOWED,"true");

		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(sessionData));
		StepVerifier.create(redisHelper.getDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

	}

	@Test
	public void getDataFromRedisTest3(){
		String requestString = "{  \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",  \"caseId\" : \"SOP-1023325-E01\",  \"intendType\" : \"EUP\",  \"lines\" : [ {    \"preBackOrderDate\" : \"04-30-2020\",    \"preBackOrderDisplayType\" : \"Ships by\",    \"mtn\" : \"8473096013\",    \"device\" : {      \"id\" : \"OPIN20190BKLR\",      \"dppMonths\" : 24,      \"contractTerm\" : \"VERIZON_EDGE\",      \"qty\" : 1    },    \"sim\" : {      \"id\" : \"EMBD4GSIM-N\"    },    \"ispuFlow\" : false,    \"depletionLocationCode\" : \"\",    \"depletionType\" : \"F\",    \"isKeepingExistingEqProtection\" : true,    \"isNewLine\" : false  } ],  \"deviceCartInfo\" : {    \"clientAppName\" : \"VZW-ECOM\",    \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",    \"caseId\" : \"SOP-1023325-E01\",    \"accountNumber\" : \"0280363949-00001\",    \"cartCreator\" : \"8472046549\",    \"processingMTN\" : \"8473096013\",    \"processStep\" : \"GridWallPDP\",    \"intendType\" : \"EUP\",    \"processAction\" : \"addDevice\",    \"editDevice\" : false, \\\"intent\\\" : \\\"NLG\\\"  }}";
		String rfexExchangeShopDetailsString = "{\"mtn\" : \"654892298\",\"returnItemSeq\" : \"1\"}";
		Map sessionData = new HashMap<Object,Object>();
		sessionData.put(SessionConstants.ACCOUNT_NUMBER_KEY, "0480298581-00001");
		sessionData.put(SessionConstants.MTN_KEY, "9205726029");
		sessionData.put(CartConstants.CART_ID, "c4d4360d-3d96-4b37-95b8-dd12881b2fff");
		sessionData.put(CartConstants.CASE_ID, "SOP-119933-2");
		sessionData.put(CartConstants.PROCESSING_MTN, "9205726029");
		sessionData.put(CartConstants.CART_CREATOR, "9205726029");
		sessionData.put(CartConstants.FIVEG_UPSELL, "true");
		sessionData.put(CartConstants.ADD_DEVICE_REQUEST, requestString);
		sessionData.put(CartConstants.ADD_ACCESSORY_REQUEST, requestString);
		sessionData.put(CartConstants.RESTRICTED_PRODUCT_TYPE, "EQP");
		sessionData.put(CartConstants.IS_SMARTPHONE,"true");
		sessionData.put(CartConstants.BBP_ICCID,"89148000000835900458");
		sessionData.put(CartConstants.BBP_IMEI,"352898071702915");
		sessionData.put(CartConstants.RFEX_EXCHANGE_SHOP_DETAILS, rfexExchangeShopDetailsString);
		sessionData.put(CartConstants.INTENT_REDIS,"NLG");
		sessionData.put(CartConstants.IMEI,"33619_1655467826843_729");
		sessionData.put(CartConstants.Z1_OFFER_CODE,"33619_1655467826843_729");
		sessionData.put(CartConstants.SW_COUPON_CODE,"33619_1655467826843_729");
		sessionData.put(CartConstants.SAFETECH_SESSION_ID,"33619_1655467826843_729");
		sessionData.put(CartConstants.VZPH_REMOVED,"33619_1655467826843_729");
		sessionData.put(CartConstants.COMPLETED_CARTID_CONST,"33619_1655467826843_729");
		sessionData.put(CartConstants.COMPLETED_CASEID_CONST,"33619_1655467826843_729");
		sessionData.put(CartConstants.QUOTE_PRICING, requestString);
		sessionData.put(CartConstants.LV_SOFTSKU,"LOCNOTE");
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(sessionData));
		StepVerifier.create(redisHelper.getDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getDataFromRedisTest4(){
		String requestString = "{  \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",  \"caseId\" : \"SOP-1023325-E01\",  \"intendType\" : \"EUP\",  \"lines\" : [ {    \"preBackOrderDate\" : \"04-30-2020\",    \"preBackOrderDisplayType\" : \"Ships by\",    \"mtn\" : \"8473096013\",    \"device\" : {      \"id\" : \"OPIN20190BKLR\",      \"dppMonths\" : 24,      \"contractTerm\" : \"VERIZON_EDGE\",      \"qty\" : 1    },    \"sim\" : {      \"id\" : \"EMBD4GSIM-N\"    },    \"ispuFlow\" : false,    \"depletionLocationCode\" : \"\",    \"depletionType\" : \"F\",    \"isKeepingExistingEqProtection\" : true,    \"isNewLine\" : false  } ],  \"deviceCartInfo\" : {    \"clientAppName\" : \"VZW-ECOM\",    \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",    \"caseId\" : \"SOP-1023325-E01\",    \"accountNumber\" : \"0280363949-00001\",    \"cartCreator\" : \"8472046549\",    \"processingMTN\" : \"8473096013\",    \"processStep\" : \"GridWallPDP\",    \"intendType\" : \"EUP\",    \"processAction\" : \"addDevice\",    \"editDevice\" : false, \\\"intent\\\" : \\\"NLG\\\"  }}";
		String rfexExchangeShopDetailsString = "{\"mtn\" : \"654892298\",\"returnItemSeq\" : \"1\"}";
		Map sessionData = new HashMap<Object,Object>();
		sessionData.put(SessionConstants.ACCOUNT_NUMBER_KEY, "0480298581-00001");
		sessionData.put(SessionConstants.MTN_KEY, "9205726029");
		sessionData.put(CartConstants.CART_ID, "c4d4360d-3d96-4b37-95b8-dd12881b2fff");
		sessionData.put(CartConstants.CASE_ID, "SOP-119933-2");
		sessionData.put(CartConstants.PROCESSING_MTN, "9205726029");
		sessionData.put(CartConstants.CART_CREATOR, "9205726029");
		sessionData.put(CartConstants.FIVEG_UPSELL, "true");
		sessionData.put(CartConstants.ADD_DEVICE_REQUEST, requestString);
		sessionData.put(CartConstants.ADD_ACCESSORY_REQUEST, requestString);
		sessionData.put(CartConstants.RESTRICTED_PRODUCT_TYPE, "EQP");
		sessionData.put(CartConstants.IS_SMARTPHONE,"true");
		sessionData.put(CartConstants.BBP_ICCID,"89148000000835900458");
		sessionData.put(CartConstants.BBP_IMEI,"352898071702915");
		sessionData.put(CartConstants.RFEX_EXCHANGE_SHOP_DETAILS, rfexExchangeShopDetailsString);
		sessionData.put(CartConstants.INTENT_REDIS,"NLG");
		sessionData.put(CartConstants.IMEI,"33619_1655467826843_729");
		sessionData.put(CartConstants.Z1_OFFER_CODE,"33619_1655467826843_729");
		sessionData.put(CartConstants.SW_COUPON_CODE,"33619_1655467826843_729");
		sessionData.put(CartConstants.SAFETECH_SESSION_ID,"33619_1655467826843_729");
		sessionData.put(CartConstants.VZPH_REMOVED,"33619_1655467826843_729");
		sessionData.put(CartConstants.EVENTCORRELATIONID, "33619_1655467826843_729");
		sessionData.put(CartConstants.COMPLETED_CARTID_CONST,"33619_1655467826843_729");
		sessionData.put(CartConstants.COMPLETED_CASEID_CONST,"33619_1655467826843_729");
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(sessionData));
		StepVerifier.create(redisHelper.getDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getDataFromRedisTest6(){
		String requestString = "{  \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",  \"caseId\" : \"SOP-1023325-E01\",  \"intendType\" : \"EUP\",  \"lines\" : [ {    \"preBackOrderDate\" : \"04-30-2020\",    \"preBackOrderDisplayType\" : \"Ships by\",    \"mtn\" : \"8473096013\",    \"device\" : {      \"id\" : \"OPIN20190BKLR\",      \"dppMonths\" : 24,      \"contractTerm\" : \"VERIZON_EDGE\",      \"qty\" : 1    },    \"sim\" : {      \"id\" : \"EMBD4GSIM-N\"    },    \"ispuFlow\" : false,    \"depletionLocationCode\" : \"\",    \"depletionType\" : \"F\",    \"isKeepingExistingEqProtection\" : true,    \"isNewLine\" : false  } ],  \"deviceCartInfo\" : {    \"clientAppName\" : \"VZW-ECOM\",    \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",    \"caseId\" : \"SOP-1023325-E01\",    \"accountNumber\" : \"0280363949-00001\",    \"cartCreator\" : \"8472046549\",    \"processingMTN\" : \"8473096013\",    \"processStep\" : \"GridWallPDP\",    \"intendType\" : \"EUP\",    \"processAction\" : \"addDevice\",    \"editDevice\" : false, \\\"intent\\\" : \\\"NLG\\\"  }}";
		String rfexExchangeShopDetailsString = "{\"mtn\" : \"654892298\",\"returnItemSeq\" : \"1\"}";
		Map sessionData = new HashMap<Object,Object>();
		sessionData.put(CartConstants.ADD_DEVICE_REQUEST, requestString);
		sessionData.put(CartConstants.ADD_ACCESSORY_REQUEST, requestString);
		sessionData.put(CartConstants.RESTRICTED_PRODUCT_TYPE, "EQP");
		sessionData.put(CartConstants.RFEX_EXCHANGE_SHOP_DETAILS, rfexExchangeShopDetailsString);
		sessionData.put(CartConstants.INTENT_REDIS,"NLG");
		sessionData.put(CartConstants.IMEI,"33619_1655467826843_729");
		sessionData.put(CartConstants.Z1_OFFER_CODE,"33619_1655467826843_729");
		sessionData.put(CartConstants.SW_COUPON_CODE,"33619_1655467826843_729");
		sessionData.put(CartConstants.VZPH_REMOVED,"33619_1655467826843_729");
		sessionData.put(CartConstants.EVENTCORRELATIONID, "33619_1655467826843_729");
		sessionData.put(CartConstants.COMPLETED_CARTID_CONST,"33619_1655467826843_729");
		sessionData.put(CartConstants.COMPLETED_CASEID_CONST,"33619_1655467826843_729");
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(sessionData));
		StepVerifier.create(redisHelper.getDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getDataFromRedisTest7(){
		String requestString = "{  \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",  \"caseId\" : \"SOP-1023325-E01\",  \"intendType\" : \"EUP\",  \"lines\" : [ {    \"preBackOrderDate\" : \"04-30-2020\",    \"preBackOrderDisplayType\" : \"Ships by\",    \"mtn\" : \"8473096013\",    \"device\" : {      \"id\" : \"OPIN20190BKLR\",      \"dppMonths\" : 24,      \"contractTerm\" : \"VERIZON_EDGE\",      \"qty\" : 1    },    \"sim\" : {      \"id\" : \"EMBD4GSIM-N\"    },    \"ispuFlow\" : false,    \"depletionLocationCode\" : \"\",    \"depletionType\" : \"F\",    \"isKeepingExistingEqProtection\" : true,    \"isNewLine\" : false  } ],  \"deviceCartInfo\" : {    \"clientAppName\" : \"VZW-ECOM\",    \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",    \"caseId\" : \"SOP-1023325-E01\",    \"accountNumber\" : \"0280363949-00001\",    \"cartCreator\" : \"8472046549\",    \"processingMTN\" : \"8473096013\",    \"processStep\" : \"GridWallPDP\",    \"intendType\" : \"EUP\",    \"processAction\" : \"addDevice\",    \"editDevice\" : false, \\\"intent\\\" : \\\"NLG\\\"  }}";
		String selectedLinePromoList = "[{\"mtn\":\"7164323058\",\"pricePlanInfo\":{\"planId\":\"18056\"},\"sedOfferInfoList\":[{\"currentOfferID\":\"152394\",\"offerTypeCd\":\"SR\",\"originalOrderNumber\":\"4909086\",\"originalLocationCode\":\"X473901\",\"priorDQ\":\"N\",\"wfgStatus\":\"N\",\"bicOccurencesApplied\":\"13\",\"recurringCreditAmount\":\"-18.41\",\"bicOccurencesRemaining\":\"11\",\"creditsEndDate\":\"12/23/2023\",\"dbTimestamp\":\"2022-01-06-21.00.52.838406\",\"offerProdId\":\"44519\",\"offerDescription\":\"NON TRADE-IN DEVICE PROMO CREDIT\",\"totalBicOccurences\":\"11\"}]}]}";

		Map sessionData = new HashMap<Object,Object>();
		sessionData.put(CartConstants.ADD_DEVICE_REQUEST, requestString);
		sessionData.put(CartConstants.ADD_ACCESSORY_REQUEST, requestString);
		sessionData.put(CartConstants.SELECTED_LINE_PROMOLIST , selectedLinePromoList);
		sessionData.put(CartConstants.RESTRICTED_PRODUCT_TYPE, "EQP");
		sessionData.put(CartConstants.INTENT_REDIS,"NLG");
		sessionData.put(CartConstants.IMEI,"33619_1655467826843_729");
		sessionData.put(CartConstants.Z1_OFFER_CODE,"33619_1655467826843_729");
		sessionData.put(CartConstants.SW_COUPON_CODE,"33619_1655467826843_729");
		sessionData.put(CartConstants.VZPH_REMOVED,"33619_1655467826843_729");
		sessionData.put(CartConstants.EVENTCORRELATIONID, "33619_1655467826843_729");
		sessionData.put(CartConstants.COMPLETED_CARTID_CONST,"33619_1655467826843_729");
		sessionData.put(CartConstants.COMPLETED_CASEID_CONST,"33619_1655467826843_729");
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(sessionData));
		StepVerifier.create(redisHelper.getDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updatespoMtnTest(){
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper3.updatespoMtn("randomValue")).verifyComplete();
		//when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.error(Exception::new));
		//StepVerifier.create(redisHelper.updatespoMtn("randomValue")).verifyError();

		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper3.updateBOGOMtn("randomValue")).verifyComplete();
		//when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.error(Exception::new));
		//StepVerifier.create(redisHelper.updateBOGOMtn("randomValue")).verifyError();

		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.upsertDataInRedis(new HashMap())).verifyComplete();
		when(sessionBean.setSessionData(any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper2.upsertDataInRedis(new HashMap())).verifyComplete();

	}

	@Test
	public void getMTNFromRedisTest(){
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(getSessionData()));
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper3.getMTNFromRedis(new String[]{})).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(false));
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(new HashMap()));
		StepVerifier.create(redisHelper3.getMTNFromRedis(new String[]{})).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(false));
		when(sessionBean.getSessionData(any())).thenReturn(Mono.empty());
		StepVerifier.create(redisHelper3.getMTNFromRedis(new String[]{})).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateCartCreatorInRedisTest(){
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper3.updateCartCreatorInRedis("randomValue")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void upsertMvoDataIntoRedisTest(){
		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.upsertMvoDataIntoRedis(new MvoRequest())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateCRSPInRedisTest(){
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper3.upsertCRSP("randomValue")).verifyComplete();
	}

	@Test
	public void updateWFMFlowDataInRedisTest(){
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper3.updateWFMFlowDataInRedis("randomValue", "randomValue","NSE","randomValue")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper3.updateWFMFlowDataInRedis("randomValue", "","RANDOM","")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper3.updateWFMFlowDataInRedis("", "randomValue","RANDOM","")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper3.updateWFMFlowDataInRedis("", "","","")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void upsertCartCreatorTest(){
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		RetrieveCartUIResponse retrieveCartUIResponse = new RetrieveCartUIResponse();
		CXPRetrieveCartDataVO cXPRetrieveCartDataVO = new CXPRetrieveCartDataVO();
		CXPCartVO cXPCartVO = new CXPCartVO();
		CXPOrderDetails cXPOrderDetails = new CXPOrderDetails();
		cXPOrderDetails.setWfmOrderInfo(new WFMOrderInfo());
		RetrieveCartHeader retrieveCartHeader = new RetrieveCartHeader();
		retrieveCartHeader.setCartCreator("randomValues");
		cXPCartVO.setOrderDetails(cXPOrderDetails);
		cXPCartVO.setCartHeader(retrieveCartHeader);
		cXPRetrieveCartDataVO.setCart(cXPCartVO);
		retrieveCartUIResponse.setData(cXPRetrieveCartDataVO);
		StepVerifier.create(redisHelper3.upsertCartCreator(retrieveCartUIResponse)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		retrieveCartHeader.setCartCreator(null);
		cXPCartVO.setOrderDetails(cXPOrderDetails);
		cXPCartVO.setCartHeader(retrieveCartHeader);
		cXPRetrieveCartDataVO.setCart(cXPCartVO);
		retrieveCartUIResponse.setData(cXPRetrieveCartDataVO);
		StepVerifier.create(redisHelper3.upsertCartCreator(retrieveCartUIResponse)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(false));
		cXPOrderDetails.setWfmOrderInfo(null);
		cXPCartVO.setOrderDetails(cXPOrderDetails);
		cXPRetrieveCartDataVO.setCart(cXPCartVO);
		retrieveCartUIResponse.setData(cXPRetrieveCartDataVO);
		StepVerifier.create(redisHelper3.upsertCartCreator(retrieveCartUIResponse)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper3.upsertCartCreator(retrieveCartUIResponse)).verifyError();
	}

	@Test
	public void getAccountNumberFromRedisTest() {
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(""));
		CrmResumeCartUIRequest crmResumeCartUIRequest = new CrmResumeCartUIRequest();
		crmResumeCartUIRequest.setCustomerType("randomValue");
		StepVerifier.create(redisHelper3.getAccountNumberFromRedis(crmResumeCartUIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		//crmResumeCartUIRequest.setCustomerType("");
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(""));
		StepVerifier.create(redisHelper3.getAccountNumberFromRedis(new CrmResumeCartUIRequest())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getHashCodeMtnTest() {
		AddDeviceUIRequest dddDeviceUIRequest = new AddDeviceUIRequest();
		AddDeviceData addDeviceData = new AddDeviceData();
		addDeviceData.setSelectedMtn("EQP");
		dddDeviceUIRequest.setData(addDeviceData);
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(getSessionData()));
		StepVerifier.create(redisHelper3.getHashCodeMtn(dddDeviceUIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		addDeviceData.setSelectedMtn("randomValueVVV");
		dddDeviceUIRequest.setData(addDeviceData);
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(getSessionData()));
		StepVerifier.create(redisHelper3.getHashCodeMtn(dddDeviceUIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		addDeviceData.setSelectedMtn(null);
		dddDeviceUIRequest.setData(addDeviceData);
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(getSessionData()));
		StepVerifier.create(redisHelper3.getHashCodeMtn(dddDeviceUIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		dddDeviceUIRequest.setData(null);
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(getSessionData()));
		StepVerifier.create(redisHelper3.getHashCodeMtn(dddDeviceUIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(getSessionData()));
		StepVerifier.create(redisHelper3.getHashCodeMtn(new AddDeviceUIRequest())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void isWFMFlowTest(){
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(""));
		StepVerifier.create(redisHelper3.isWFMFlow()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just("Y"));
		StepVerifier.create(redisHelper3.isWFMFlow()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void testgetFiveGAddressFromRedisForMovers(){
		Map map = new HashMap();
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(map));
		StepVerifier.create(redisHelper3.getFiveGAddressFromRedisForMovers()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void testgetMoversQualPegaResponse() throws JsonProcessingException {
		String moversQualResponse = "{\"launchType\":\"FCL\",\"addressType\":\"SFU\",\"installType\":\"EITHER\",\"additionalInfoRequired\":\"false\",\"returnCode\":\"0\",\"returnMessage\":\"Eligible\",\"eventCorrelationId\":\"80209_1665891283917_554\",\"addressInfo\":{\"addressId\":\"\",\"streetType\":\"ST\",\"streetNumber\":\"800\",\"streetName\":\"S OGDEN\",\"city\":\"DENVER\",\"state\":\"CO\",\"zipCode\":\"80209\",\"buildingId\":\"\",\"latitude\":\"\",\"longitude\":\"\",\"addressLine1\":\"800 S OGDEN ST\",\"addressLine2\":\"\",\"floor\":\"\",\"zipCodePlus4\":\"4424\",\"locationId\":\"300011493216\",\"baselocationId\":\"300011493216\"},\"eligibilities\":{\"fiveGHomebundle\":[{\"bundleName\":\"5GHomeGeminiSelfSetup\",\"id\":\"16900001\",\"type\":\"s\"},{\"bundleName\":\"5GHomeGeminiProfSetup\",\"id\":\"16900002\",\"type\":\"p\"}]},\"priorQualification\":{\"fiveGHomeQualified\":true,\"LTEQualified\":false,\"cbandQualified\":false},\"market\":\"Denver\",\"preOrderInServiceDate\":\"\",\"moveQualified\":true,\"fiveGHomeQualified\":true,\"LTEQualified\":false,\"cBandQualified\":false}";
		Map map = new HashMap();
		map.put("moversAddressQualRes",moversQualResponse);
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(map));
		//Assert.assertNotNull(redisHelper.getMoversQualPegaResponse(map));
	}

	@Test
	public void fiveGRedisCartDataTest() throws JsonProcessingException {
		Map sessionData = new HashMap<Object,Object>();
		sessionData.put("cartId","8a765vc6353s3425gds082");
		sessionData.put("caseId","2a32434-3c");
		sessionData.put("mtn","862735372");
		sessionData.put("moversNextProcessStep","DateSelection");
		sessionData.put(CartConstants.NETWORK_BANDWIDTH_TYPE,"DateSelection");
		sessionData.put(CartConstants.PREV_NETWORK_BANDWIDTH_TYPE,"CBD");
		sessionData.put(CartConstants.AQ_CASE_ID,"AQ-64654-01");
		sessionData.put(CartConstants.ACCOUNT_NUMBER,"12345678890-00001");
		sessionData.put(CartConstants.MOVERS_MTN,"1234");
		sessionData.put(CartConstants.FWA_SAFE_TECH_SESSION_ID_KEY,"b8a2f0f427d14dc2a8731ac5");
		Map<String,String> map = new HashMap<>();
		map.put("862735372","planName,CBD");
		sessionData.put(CartConstants.MOVERS_ACC_INFO_KEY,mapper.writeValueAsString(map));
		Map<String,String> map2 = new HashMap<>();
		map2.put("67584","45");
		sessionData.put(CartConstants.FINAL_PLAN_PRICE, mapper.writeValueAsString(map2));
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(sessionData));
		StepVerifier.create(redisHelper3.fiveGRedisMoversData()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void fiveGRedisCartDataEmptyTest() throws JsonProcessingException {
		Map sessionData = new HashMap<Object,Object>();
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(sessionData));
		StepVerifier.create(redisHelper3.fiveGRedisMoversData()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void fiveGRedisCartDataEmptyValuesTest() throws JsonProcessingException {
		Map sessionData = new HashMap<Object,Object>();
		sessionData.put("cartId",null);
		sessionData.put("caseId",null);
		sessionData.put("mtn",null);
		sessionData.put("moversNextProcessStep",null);
		sessionData.put(CartConstants.NETWORK_BANDWIDTH_TYPE,null);
		sessionData.put(CartConstants.PREV_NETWORK_BANDWIDTH_TYPE,null);
		sessionData.put(CartConstants.AQ_CASE_ID,null);
		sessionData.put(CartConstants.ACCOUNT_NUMBER,null);
		sessionData.put(CartConstants.MOVERS_MTN,null);
		sessionData.put(CartConstants.MOVERS_ACC_INFO_KEY,null);
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(sessionData));
		StepVerifier.create(redisHelper3.fiveGRedisMoversData()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void fiveGRedisCartDataExceptionTest() throws JsonProcessingException {
		Map sessionData = new HashMap<Object,Object>();
		Map<String,String> map = new HashMap<>();
		map.put("862735372","planName,CBD");
		sessionData.put(CartConstants.MOVERS_ACC_INFO_KEY,map.toString());
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(sessionData));
		StepVerifier.create(redisHelper3.fiveGRedisMoversData()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updatePastDueDataInRedisTest() throws JsonMappingException, JsonProcessingException{

		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper3.updatePastDueDataInRedis(new PastDueRedisData())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper3.updatePastDueDataInRedis(new PastDueRedisData())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deleteSessionDataKeyFromRedisTest() throws JsonMappingException, JsonProcessingException{

		when(sessionBean.deleteSessionData(any())).thenReturn(Mono.just(1L));
		StepVerifier.create(redisHelper2.deleteSessionDataKeyFromRedis("prospectCartId")).verifyComplete();

		when(sessionBean.deleteSessionData(any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper2.deleteSessionDataKeyFromRedis("prospectCartId")).verifyComplete();
	}

	@Test
	public void getDataFromRedisTest5(){
		String requestString = "{  \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",  \"caseId\" : \"SOP-1023325-E01\",  \"intendType\" : \"EUP\",  \"lines\" : [ {    \"preBackOrderDate\" : \"04-30-2020\",    \"preBackOrderDisplayType\" : \"Ships by\",    \"mtn\" : \"8473096013\",    \"device\" : {      \"id\" : \"OPIN20190BKLR\",      \"dppMonths\" : 24,      \"contractTerm\" : \"VERIZON_EDGE\",      \"qty\" : 1    },    \"sim\" : {      \"id\" : \"EMBD4GSIM-N\"    },    \"ispuFlow\" : false,    \"depletionLocationCode\" : \"\",    \"depletionType\" : \"F\",    \"isKeepingExistingEqProtection\" : true,    \"isNewLine\" : false  } ],  \"deviceCartInfo\" : {    \"clientAppName\" : \"VZW-ECOM\",    \"cartId\" : \"df962b52-8d77-4f79-b73f-d8777d44b276\",    \"caseId\" : \"SOP-1023325-E01\",    \"accountNumber\" : \"0280363949-00001\",    \"cartCreator\" : \"8472046549\",    \"processingMTN\" : \"8473096013\",    \"processStep\" : \"GridWallPDP\",    \"intendType\" : \"EUP\",    \"processAction\" : \"addDevice\",    \"editDevice\" : false, \\\"intent\\\" : \\\"NLG\\\"  }}";
		String rfexExchangeShopDetailsString = "{\"mtn\" : \"654892298\",\"returnItemSeq\" : \"1\"}";
		Map sessionData = new HashMap<Object,Object>();
		sessionData.put(SessionConstants.ACCOUNT_NUMBER_KEY, "0480298581-00001");
		sessionData.put(SessionConstants.MTN_KEY, "9205726029");
		sessionData.put(CartConstants.CART_ID, "c4d4360d-3d96-4b37-95b8-dd12881b2fff");
		sessionData.put(CartConstants.CASE_ID, "SOP-119933-2");
		sessionData.put(CartConstants.PROCESSING_MTN, "9205726029");
		sessionData.put(CartConstants.CART_CREATOR, "9205726029");
		sessionData.put(CartConstants.FIVEG_UPSELL, "true");
		sessionData.put(CartConstants.ADD_DEVICE_REQUEST, requestString);
		sessionData.put(CartConstants.ADD_ACCESSORY_REQUEST, requestString);
		sessionData.put(CartConstants.RESTRICTED_PRODUCT_TYPE, "EQP");
		sessionData.put(CartConstants.IS_SMARTPHONE,"true");
		sessionData.put(CartConstants.BBP_ICCID,"89148000000835900458");
		sessionData.put(CartConstants.BBP_IMEI,"352898071702915");
		sessionData.put(CartConstants.RFEX_EXCHANGE_SHOP_DETAILS, rfexExchangeShopDetailsString);
		sessionData.put(CartConstants.INTENT_REDIS,"NLG");
		sessionData.put(CartConstants.CCAR_WIFI_STATE,"POST_TRIAL");
		sessionData.put(CartConstants.BRAND_NAME,"Mazda");
		sessionData.put(CartConstants.SAFETECH_SESSION_ID,"33619_1655467826843_729");
		sessionData.put(CartConstants.VZPH_REMOVED,"33619_1655467826843_729");
		sessionData.put(CartConstants.COMPLETED_CARTID_CONST,"33619_1655467826843_729");
		sessionData.put(CartConstants.COMPLETED_CASEID_CONST,"33619_1655467826843_729");
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(sessionData));
		StepVerifier.create(redisHelper.getDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updatePlanDetailsInRedisTest() {
		Map<String, Map<String, String>> planDetails = new HashMap<>();
		planDetails.put("67890",new HashMap<>());
		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper2.updatePlanPathInRedis(planDetails)).expectComplete().verify();

		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.just(false));
		StepVerifier.create(redisHelper2.updatePlanPathInRedis(planDetails)).expectComplete().verify();

		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper2.updatePlanPathInRedis(planDetails)).expectComplete().verify();

	}

	@Test
	public void getPlanDetailsTest() {
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(String.valueOf(new HashMap())));
		StepVerifier.create(redisHelper2.getPlanPathDetails()).assertNext(Assert::assertNotNull).expectComplete().verify();

		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(String.valueOf(Collections.emptyMap())));
		StepVerifier.create(redisHelper2.getPlanPathDetails()).assertNext(Assert::assertNotNull).expectComplete().verify();

		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper2.getPlanPathDetails()).assertNext(Assert::assertNotNull).expectComplete().verify();
	}
	@Test
	public void upsertCartResponseToSessionTest() throws JsonMappingException, JsonProcessingException{

		RetrieveCartCXPRequest request = new RetrieveCartCXPRequest();
		request.setChannelId("OMNI-RETAIL");
		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper.upsertCartResponseToSession(new CXPRetrieveCartDataVO(), request)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		request.setChannelId("OMNI-RETAIL");
		StepVerifier.create(redisHelper.upsertCartResponseToSession(new CXPRetrieveCartDataVO(), request)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		request.setChannelId("OMNI-INDIRECT");
		StepVerifier.create(redisHelper.upsertCartResponseToSession(new CXPRetrieveCartDataVO(), request)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		request.setChannelId("OMNI-INDIRECT-TAB");
		StepVerifier.create(redisHelper.upsertCartResponseToSession(new CXPRetrieveCartDataVO(), request)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		request.setChannelId("XYZ");
		StepVerifier.create(redisHelper.upsertCartResponseToSession(new CXPRetrieveCartDataVO(), request)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		request.setChannelId("");
		StepVerifier.create(redisHelper.upsertCartResponseToSession(new CXPRetrieveCartDataVO(), request)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		request.setChannelId(null);
		StepVerifier.create(redisHelper.upsertCartResponseToSession(new CXPRetrieveCartDataVO(), request)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper.upsertCartResponseToSession(new CXPRetrieveCartDataVO(),new RetrieveCartCXPRequest())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void clearMyLinkDataFromRedisTest() {
		when(sessionBean.deleteSessionData(any())).thenReturn(Mono.just(1L));
		StepVerifier.create(redisHelper.clearMyLinkDataFromRedis("random")).assertNext(Assert::assertNotNull).expectComplete().verify();

		when(sessionBean.deleteSessionData(any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper.clearMyLinkDataFromRedis("random")).verifyError();
	}

	@Test
	public void setByodDataToRedisTest(){
		DeviceInfo deviceInfo = new DeviceInfo();
		deviceInfo.setImei1("0000");
		deviceInfo.setImei2("0001");
		when(sessionBean.setSessionData(any(), any())).thenReturn(Mono.empty());
		StepVerifier.create(redisHelper.setByodDataToRedis(deviceInfo)).expectComplete().verify();
		SimInfo simInfo = new SimInfo();
		simInfo.setIccid("12345");
		simInfo.setEID("8900000");
		deviceInfo.setSimInfo(simInfo);
		StepVerifier.create(redisHelper.setByodDataToRedis(deviceInfo)).expectComplete().verify();
		deviceInfo.setDeviceId("358643090227948");
		deviceInfo.setESIMOnly(Boolean.TRUE);
		StepVerifier.create(redisHelper.setByodDataToRedis(deviceInfo)).expectComplete().verify();
	}

	@Test
	public void dualNumRedisTest(){
		Map sessionData = new HashMap<Object,Object>();
		GsonBuilder gsonBuilder = new GsonBuilder();
		Gson gsonObject = gsonBuilder.create();
		sessionData.put(CartConstants.COMPLETED_CASEID_CONST,"33619_1655467826843_729");
		sessionData.put(CartConstants.DUAL_NUMBER,gsonObject.toJson(new DualNumber()));
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(sessionData));
		StepVerifier.create(redisHelper.getDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp.getDualNumber())).expectComplete().verify();

		sessionData.put(CartConstants.DUAL_NUMBER,gsonObject.toJson(new DeviceInfo()));
		when(sessionBean.getSessionData(any())).thenReturn(Mono.just(sessionData));
		StepVerifier.create(redisHelper.getDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void saveInitiateCartInfoTest() throws JsonProcessingException {

		String respString="{ \"serviceHeader\": { \"clientId\": \"VZW-DOTCOM\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"CPC\", \"statusCode\": \"00\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \"CPC-12401688-E01\", \"contextInfo\": { \"callReason\": \"CPC\", \"processStep\": \"planSelection\", \"availablePaths\": [ { \"path\": \"planSelection\" }, { \"path\": \"featureSelection\" } ], \"pastDueBalance\": \"false\", \"pendingOrderAccountLevel\": \"false\" }, \"customerInfo\": { \"accountNumber\": \"0326564274-00001\", \"cartCreator\": \"5619384700\", \"registerNumber\": 0 }, \"cartInfo\": { \"cartId\": \"5bad495f-b32f-4bc3-8293-c0064cb7750f\" } } } } }";
		CpcFeatureResponse pegaResponse = mapper.readValue(respString, CpcFeatureResponse.class);
		when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
		StepVerifier.create(redisHelper.saveFeatureInitiateCartInfo(pegaResponse)).expectNext(true)
				.expectComplete()
				.verify();

		pegaResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartId(null);
		StepVerifier.create(redisHelper.saveFeatureInitiateCartInfo(pegaResponse)).expectNext(true)
				.expectComplete()
				.verify();
		pegaResponse.getServiceBody().getServiceResponse().getContext().setCartInfo(null);
		StepVerifier.create(redisHelper.saveFeatureInitiateCartInfo(pegaResponse)).expectNext(true).expectComplete().verify();

		pegaResponse.getServiceBody().getServiceResponse().getContext().setCaseId(null);
		StepVerifier.create(redisHelper.saveFeatureInitiateCartInfo(pegaResponse)).expectNext(true).expectComplete().verify();
		pegaResponse.getServiceBody().getServiceResponse().setContext(null);
		StepVerifier.create(redisHelper.saveFeatureInitiateCartInfo(pegaResponse)).expectNext(true).expectComplete().verify();

		pegaResponse.getServiceBody().setServiceResponse(null);
		StepVerifier.create(redisHelper.saveFeatureInitiateCartInfo(pegaResponse)).expectNext(true).expectComplete().verify();

		pegaResponse.setServiceBody(null);
		StepVerifier.create(redisHelper.saveFeatureInitiateCartInfo(pegaResponse)).expectNext(true).expectComplete().verify();

		pegaResponse=null;
		StepVerifier.create(redisHelper.saveFeatureInitiateCartInfo(pegaResponse)).expectNext(true).expectComplete().verify();

	}

	@Test
	public void deleteDualNumberInfoFromRedis() throws JsonMappingException, JsonProcessingException{
		DualNumberRedisInfo dualNumberInfo = new DualNumberRedisInfo();
		dualNumberInfo.setIsDualNumberFlow(true);
		when(sessionBean.deleteSessionData(any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(redisHelper.deletDualNumberDetailsFromRedis(dualNumberInfo)).verifyError();
	}
	@Test
	public void deletDualNumberDetailsFromRedisTest()
	{
		RedisHelper redisHelper1 = new RedisHelper();

		Mono<Long> resp = redisHelper1.deletDualNumberDetailsFromRedis(null);
		StepVerifier.create(resp).assertNext(Assert::assertNull);
	}

	@Test
	public void getAIQuoteFlagFromRedis() {
		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(""));
		StepVerifier.create(redisHelper3.getAIQuoteFlagFromRedis()).assertNext(Assert::assertNotNull).expectComplete().verify();
	}

	@Test
	public void getCartAndCaseIdFromRedisTest()
	{
		RedisHelper redisHelper1 = new RedisHelper();

		when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(new PastDueRedisData()));
		ReflectionTestUtils.setField(redisHelper1,"sessionBean",sessionBean);
		Assertions.assertThrows(NullPointerException.class,()->{
			redisHelper1.getCartAndCaseIdFromRedis();
		});
	}
	@Test
	public void updateCartIdAndCaseIdIntoRedisForNGDTest()
	{
		RedisHelper redisHelper1 = new RedisHelper();
		CartRedisData request = new CartRedisData();

		SOELoginSessionBean sessionBean = new SOELoginSessionBean();
		ReflectionTestUtils.setField(redisHelper1,"sessionBean",sessionBean);
		Assertions.assertThrows(NullPointerException.class,()->{
			redisHelper1.updateCartIdAndCaseIdIntoRedisForNGD(request);
		});
	}
}
