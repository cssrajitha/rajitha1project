package onevz.soe.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import junit.framework.Assert;
import onevz.soe.cart.bpm.service.CartServiceBPMServices;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.model.bulkcartupdate.*;
import onevz.soe.cart.model.bulkcartupdate.Line;
import onevz.soe.cart.model.bulkcartupdate.gql.request.*;
import onevz.soe.cart.model.bulkcartupdate.gql.response.CartDetailsData;
import onevz.soe.cart.model.bulkcartupdate.gql.response.RetrieveTradeinGQLResponse;
import onevz.soe.cart.model.bulkcartupdate.tradein.session.Shipping;

import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.common.Address;
import onevz.soe.cart.model.tradeIn.appraiseDevice.BaseDeviceOutInfo2;
import onevz.soe.cart.model.tradeIn.appraiseDevice.DeviceOutInfo;
import onevz.soe.cart.model.tradeIn.appraiseDevice.RecycleDeviceOffer;
import onevz.soe.cart.model.tradeIn.appraiseDevice.TriageInfo;
import onevz.soe.cart.model.updateBarcode.UpdateBarcodeBarcodeId;

import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.ui.requests.RfexExchangeShopDetails;
import onevz.soe.cart.util.BulkQuoteUpdatePegaRequestUtil;
import onevz.soe.exception.SOEError;
import onevz.soe.exception.SOEErrorHolder;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.tradein.session.model.TradeinSessionData;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.exceptions.base.MockitoException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.ResourceUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.*;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;


@RunWith(SpringJUnit4ClassRunner.class)
@WebFluxTest(BulkUpdateAIQuoteHelperTest.class)
public class BulkUpdateAIQuoteHelperTest {

    @InjectMocks
    BulkUpdateAIQuoteHelper bulkUpdateAIQuoteHelper;

    @Mock
    CartServiceBPMServices cartServiceBPMServices;

    @Mock
    ObjectMapper mockMapper;

    @Mock
    BulkQuoteUpdatePegaRequestUtil bulkQuoteUpdatePegaRequestUtil;

    @Autowired
    ObjectMapper objectMapper;

    @Mock
    SOELoginSessionBean sessionBean;

    @Mock
    TradeInHelper tradeInHelper;

    @Mock
    BulkQuoteUIRequest bulkQuoteUIRequest;

    @Mock
    TradeinSessionData tradeinSessionData;

    @Mock
    CartServiceCXPServices cxpService;

    @Mock
    RedisHelper redisHelper;
    @Mock
    FeatureFlagHelper featureFlagHelper;

    @Mock
    BulkUpdateAIQuoteHelper1 bulkUpdateHelper;

    @Mock
    CartAddDeviceHelper deviceHelper;

    @Before
    public void setBulkUpdateAIQuoteHelper(){
        Map<String, String> data = new HashMap<>();
        data.put(CartConstants.QUOTE_E911_ADDR, "");
        when(sessionBean.getSessionData(Mockito.any())).thenReturn(Mono.just(data));

        when(tradeinSessionData.getTradeinData()).thenReturn(Collections.singletonMap("Test", Mockito.mock(DeviceOutInfo.class)));
        Mockito.when(tradeInHelper.readTradeinSessionData(anyString())).thenReturn(Mono.just(tradeinSessionData));
        Mockito.when(tradeInHelper.updateTradeinSessionData(anyString(),any())).thenReturn(Mono.just(true));
        Mockito.when(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
    }

    @Test
    public void testProcessBulkQuoteUpdate() throws Exception{
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
        CreateBulkQuotePegaResponse pegaResponse = new CreateBulkQuotePegaResponse();
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        header.setSessionId("SESSIONID");
        pegaResponse.setServiceHeader(header);
        Map<String,String> sessionData = new HashMap<>();
        String val ="{\"addressLine1\":\"1123 STATE ROUTE 380 APT# H\",\"city\":\"APOLLO\",\"state\":\"PA\",\"zipCode\":\"15613\",\"fipsCode\":\"4212900000\"}";
        sessionData.put(CartConstants.QUOTE_E911_ADDR,val);
        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
        CreateBulkQuoteServiceResponse serviceResponse = new CreateBulkQuoteServiceResponse();
        serviceBody.setServiceResponse(serviceResponse);
        pegaResponse.setServiceBody(serviceBody);
        CreateBulkQuotePegaRequest pegaRequest = new CreateBulkQuotePegaRequest();
        pegaRequest.setServiceBody(serviceBody);
        Mockito.when(sessionBean.getSessionData(Mockito.any())).thenReturn(Mono.just(sessionData));
        Mockito.when(cartServiceBPMServices.createBulkQuote(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        Mono<BulkQuoteUIResponse> response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request,"SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        CartRedisData redisData = new CartRedisData();
        Vzdl vzdl = new Vzdl();
        vzdl.setPage(new Page());
        Mockito.when(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(true));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(redisData));
        Mockito.when(bulkUpdateHelper.getFlowName(any(),any())).thenReturn(null);
        Mockito.when(redisHelper.addFlowNameToRedis(anyString())).thenReturn(Mono.just(true));
        Mockito.when(bulkUpdateHelper.getVzdlDataForBulkUpdate(any(), any(), any())).thenReturn(vzdl);
        doNothing().when(deviceHelper).updateDLDataForAssisted(any());
        Mono<BulkQuoteUIResponse> response1 = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request,"SESSIONID");
        StepVerifier.create(response1).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        redisData.setFlowName("EUP");
        Mockito.when(bulkUpdateHelper.getFlowName(any(),any())).thenReturn(null);
        Mono<BulkQuoteUIResponse> response2 = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request,"SESSIONID");
        StepVerifier.create(response2).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        redisData.setFlowName(null);
        Mockito.when(bulkUpdateHelper.getFlowName(any(),any())).thenReturn(CartConstants.EUP_CPC);
        vzdl.setPage(null);
        Mockito.when(bulkUpdateHelper.getVzdlDataForBulkUpdate(any(), any(), any())).thenReturn(vzdl);
        response2 = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request,"SESSIONID");
        StepVerifier.create(response2).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        redisData.setFlowName("EUP");
        Mockito.when(bulkUpdateHelper.getFlowName(any(),any())).thenReturn(CartConstants.EUP_CPC);
        Mockito.when(bulkUpdateHelper.getVzdlDataForBulkUpdate(any(), any(), any())).thenReturn(null);
        Mono<BulkQuoteUIResponse> response3 = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request,"SESSIONID");
        StepVerifier.create(response3).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        Mockito.when(redisHelper.addFlowNameToRedis(anyString())).thenReturn(Mono.error(new RuntimeException()));
        Mono<BulkQuoteUIResponse> response4 = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request,"SESSIONID");
        StepVerifier.create(response4).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

    }

    @Test
    public void testProcessBulkQuoteUpdate1() throws Exception{
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest1.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
        CreateBulkQuotePegaResponse pegaResponse = new CreateBulkQuotePegaResponse();
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        header.setSessionId("SESSIONID");
        pegaResponse.setServiceHeader(header);
        Map<String,String> sessionData = new HashMap<>();
        String val ="{\"addressLine1\":\"1123 STATE ROUTE 380 APT# H\",\"city\":\"APOLLO\",\"state\":\"PA\",\"zipCode\":\"15613\",\"fipsCode\":\"4212900000\"}";
        sessionData.put(CartConstants.QUOTE_E911_ADDR,val);
        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
        CreateBulkQuoteServiceResponse serviceResponse = new CreateBulkQuoteServiceResponse();
        serviceBody.setServiceResponse(serviceResponse);
        pegaResponse.setServiceBody(serviceBody);
        CreateBulkQuotePegaRequest pegaRequest = new CreateBulkQuotePegaRequest();
        pegaRequest.setServiceBody(serviceBody);
        Mockito.when(sessionBean.getSessionData(Mockito.any())).thenReturn(Mono.just(sessionData));
        Mockito.when(cartServiceBPMServices.createBulkQuote(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        Mono<BulkQuoteUIResponse> response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request,"SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void testProcessBulkQuoteUpdate_channelIdChecks() throws Exception{
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil,"enableCradleForProspect",true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil,"enableCradleForExistingCustomer",true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil,"enableCradleFlowJourney",true);
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
        CreateBulkQuotePegaResponse pegaResponse = new CreateBulkQuotePegaResponse();
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        header.setSessionId("SESSIONID");
        pegaResponse.setServiceHeader(header);
        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
        CreateBulkQuoteServiceResponse serviceResponse = new CreateBulkQuoteServiceResponse();
        serviceBody.setServiceResponse(serviceResponse);
        pegaResponse.setServiceBody(serviceBody);
        CreateBulkQuotePegaRequest pegaRequest = new CreateBulkQuotePegaRequest();
        pegaRequest.setServiceBody(serviceBody);
        Mockito.when(cartServiceBPMServices.createBulkQuote(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));

        // channel id = VZW_BBP
        request.setChannelId("VZW-DOTCOM-BBP");
        request.getCartInfo().setIntendType("NSE");
        request.getCartInfo().setIsPromoPDP(false);
        request.getCartInfo().setFlowType("SCAN_AND_GO");
        request.getData().setEsimType("SIMTYPE");
        request.getCartInfo().setNoPendingOfferExists(false);
        request.getCartInfo().setCustomerType("U");
        request.getCartInfo().setIsPrepayCart("Y");
        request.getCartInfo().setProcessStep("AIQuote");
        request.getCartInfo().setProcessAction("DEVICE-AND-SERVICES");
        request.getCartInfo().setIntent("");
        Mono<BulkQuoteUIResponse> response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request,"SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        // intendtype - AAL
        request.getCartInfo().setIntendType("AAL");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request,"SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();


        //channel id = OMNI-RETAIL
        request.setChannelId("OMNI-RETAIL");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request,"SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        //channel id = digital
        request.setChannelId("digital");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request,"SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        //channel id = VZW-CHATBOT
        request.setChannelId("VZW-CHATBOT");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request,"SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        // channel id = "OMNI-TELESALES"
        request.setChannelId("OMNI-TELESALES");
        request.getCartInfo().setCaseId("SOF");
//        request.getCartInfo().setOneClick(false);
        request.getData().getLines().get(0).getDevice().setIsCustomerProvidedEquipment(true);
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request,"SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        //lines test
//        request.getData().getLines().get(0).setIdVerifyStatus("Y");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request,"SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        //lines test verifystatus=""
//        request.getData().getLines().get(0).setIdVerifyStatus("");
//        request.getData().getLines().get(0).setHighRiskSimswapDelayActivation(true);
//        request.getData().getLines().get(0).setIsCustConsentAcceptedSMSBlast(true);
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request,"SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        request= new BulkQuoteUIRequest();
        StepVerifier.create(bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request,"SESSIONID")).expectError().verify();

        CartInfo cartInfo= new CartInfo();
        request.setCartInfo(cartInfo);
        StepVerifier.create(bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request,"SESSIONID")).expectError().verify();

        cartInfo.setCartId(null);
        request.setCartInfo(cartInfo);
        StepVerifier.create(bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request,"SESSIONID")).expectError().verify();

    }

    @Test
    public void testProcessBulkQuoteUpdate_IntendChecks() throws Exception {
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForProspect", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForExistingCustomer", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleFlowJourney", true);
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest_Intend.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
        CreateBulkQuotePegaResponse pegaResponse = new CreateBulkQuotePegaResponse();
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        header.setSessionId("SESSIONID");
        pegaResponse.setServiceHeader(header);
        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
        CreateBulkQuoteServiceResponse serviceResponse = new CreateBulkQuoteServiceResponse();
        serviceBody.setServiceResponse(serviceResponse);
        pegaResponse.setServiceBody(serviceBody);
        CreateBulkQuotePegaRequest pegaRequest = new CreateBulkQuotePegaRequest();
        pegaRequest.setServiceBody(serviceBody);
        request.getCartInfo().setIntendType("CLNR");
        Mockito.when(cartServiceBPMServices.createBulkQuote(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        Mono<BulkQuoteUIResponse> response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        // intend type = refund exchange
        request.getCartInfo().setIntendType("REX");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        // intend type = ""
        request.getCartInfo().setIntendType("");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        //intendtype = NSEBYOD
        request.getCartInfo().setIntendType("NSEBYOD");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        //intendtype = DEO
        request.getCartInfo().setIntendType("DEO");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        //intendtype = NSEACC
        request.getCartInfo().setIntendType("NSEACC");
//        request.getData().setZipCode("0026301");
//        request.getCartInfo().setPrepaidToPostpaidMigration(true);
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        // clientappname
        request.getCartInfo().setClientAppName("VZW-DOTCOM-BBP");
//        request.getCartInfo().setIsConnectedCarRequired(false);
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void testProcessBulkQuoteUpdate_PropertyCheck() throws Exception {
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForProspect", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForExistingCustomer", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleFlowJourney", true);
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest_Intend.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
        CreateBulkQuotePegaResponse pegaResponse = new CreateBulkQuotePegaResponse();
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        header.setSessionId("SESSIONID");
        pegaResponse.setServiceHeader(header);
        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
        CreateBulkQuoteServiceResponse serviceResponse = new CreateBulkQuoteServiceResponse();
        serviceBody.setServiceResponse(serviceResponse);
        pegaResponse.setServiceBody(serviceBody);
        CreateBulkQuotePegaRequest pegaRequest = new CreateBulkQuotePegaRequest();
        pegaRequest.setServiceBody(serviceBody);
        request.getCartInfo().setIntendType("NSE");
//        request.getCartInfo().setEditPlanClick(false);
//        request.getCartInfo().setExpressCheckout(false);
        request.getCartInfo().setEditDeviceConfiguratorClick(false);
        Mockito.when(cartServiceBPMServices.createBulkQuote(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        Mono<BulkQuoteUIResponse> response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        //intend type = NSEBYOD
        request.getCartInfo().setIntendType("NSEBYOD");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        //intendtype =""
        request.getCartInfo().setIntendType("");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void testProcessBulkQuoteUpdate_Check1() throws Exception {
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForProspect", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForExistingCustomer", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleFlowJourney", true);
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest_Intend.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
        CreateBulkQuotePegaResponse pegaResponse = new CreateBulkQuotePegaResponse();
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        header.setSessionId("SESSIONID");
        pegaResponse.setServiceHeader(header);
        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
        CreateBulkQuoteServiceResponse serviceResponse = new CreateBulkQuoteServiceResponse();
        serviceBody.setServiceResponse(serviceResponse);
        pegaResponse.setServiceBody(serviceBody);
        CreateBulkQuotePegaRequest pegaRequest = new CreateBulkQuotePegaRequest();
        pegaRequest.setServiceBody(serviceBody);
        request.getCartInfo().setFlexV2(true);
        request.getCartInfo().setSubscriptionType("ANNUAL");
        request.getCartInfo().setGamingGiftCard("BOGOGAMING");
        request.getCartInfo().setIntendType("");
        request.getCartInfo().setLineActivityType("TSE");
        request.getData().setParentMtn("1234567890");
        request.getData().setRetrieveFeatureLossReferenceData("N");
        request.getCartInfo().setRelinquishAccountNumber("ACC-0001");
        request.getCartInfo().setTysLinesCount("2");
        request.getData().setEffectiveDate("02/18/2024");
        request.getData().setCheckAutoPayDiscountEligible("");
        request.getCartInfo().setCaseId("SOFID");
        request.getCartInfo().setOneClick(true);
        request.getCartInfo().setRpsIntent("RPSINTENT");
        Mockito.when(cartServiceBPMServices.createBulkQuote(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        Mono<BulkQuoteUIResponse> response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        //other checks
        request.getData().setCheckAutoPayDiscountEligible("Y");
        request.getCartInfo().setFlowType("PLAN_BUILDER");
        request.getCartInfo().setPrepaidToPostpaidMigration(true);
        request.getData().setPrepaidMtn("0123456789");
        request.getData().setTotalDeviceDollar(12.98);
        request.getData().setSedBarCode("BARCODE");
        request.getCartInfo().setClientAppName("VZW-NUMBERLINK");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void testProcessBulkQuoteUpdate_TradeInInfoEmpty() throws Exception {
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForProspect", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForExistingCustomer", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleFlowJourney", true);
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest_Tradein.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
        CreateBulkQuotePegaResponse pegaResponse = new CreateBulkQuotePegaResponse();
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        header.setSessionId("SESSIONID");
        pegaResponse.setServiceHeader(header);
        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
        CreateBulkQuoteServiceResponse serviceResponse = new CreateBulkQuoteServiceResponse();
        serviceBody.setServiceResponse(serviceResponse);
        pegaResponse.setServiceBody(serviceBody);
        CreateBulkQuotePegaRequest pegaRequest = new CreateBulkQuotePegaRequest();
        pegaRequest.setServiceBody(serviceBody);
        Mockito.when(cartServiceBPMServices.createBulkQuote(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        Mono<BulkQuoteUIResponse> response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

//        request.getData().setTradeInDetails(null);
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void testProcessBulkQuoteUpdate_AccessoriesCheck() throws Exception {
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForProspect", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForExistingCustomer", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleFlowJourney", true);
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
        CreateBulkQuotePegaResponse pegaResponse = new CreateBulkQuotePegaResponse();
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        header.setSessionId("SESSIONID");
        pegaResponse.setServiceHeader(header);
        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
        CreateBulkQuoteServiceResponse serviceResponse = new CreateBulkQuoteServiceResponse();
        serviceBody.setServiceResponse(serviceResponse);
        pegaResponse.setServiceBody(serviceBody);
        CreateBulkQuotePegaRequest pegaRequest = new CreateBulkQuotePegaRequest();
        pegaRequest.setServiceBody(serviceBody);
        request.setChannelId("digital");
        request.getCartInfo().setIntendType("REX");
        RfexExchangeShopDetails rfexExchangeShopDetails = new RfexExchangeShopDetails();
        rfexExchangeShopDetails.setMtn("0123456789");
//        request.setRfexExchangeShopDetails(rfexExchangeShopDetails);
//        request.getRfexExchangeShopDetails().setMtn("01234657");
        Mockito.when(cartServiceBPMServices.createBulkQuote(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        Mono<BulkQuoteUIResponse> response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        //
        request.getCartInfo().setIntendType("NSE");
        request.getData().getLines().get(0).getDevice().setNetworkBandwidthType("LTE");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();


        //processindicator G
        request.getCartInfo().setIntendType("AAL");
        request.getCartInfo().setMtnFlow("G");
        request.getData().getLines().get(0).getDevice().setNetworkBandwidthType("");
        request.getCartInfo().setProcessingMTN("");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void testProcessBulkQuoteUpdate_Accessories() throws Exception {
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForProspect", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForExistingCustomer", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleFlowJourney", true);
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
        CreateBulkQuotePegaResponse pegaResponse = new CreateBulkQuotePegaResponse();
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        header.setSessionId("SESSIONID");
        pegaResponse.setServiceHeader(header);
        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
        CreateBulkQuoteServiceResponse serviceResponse = new CreateBulkQuoteServiceResponse();
        serviceBody.setServiceResponse(serviceResponse);
        pegaResponse.setServiceBody(serviceBody);
        CreateBulkQuotePegaRequest pegaRequest = new CreateBulkQuotePegaRequest();
        pegaRequest.setServiceBody(serviceBody);
        RfexExchangeShopDetails rfexExchangeShopDetails = new RfexExchangeShopDetails();
        rfexExchangeShopDetails.setMtn("0123456789");
        // addsim
        request.getCartInfo().setIntendType("EUPBYOD");
        request.getCartInfo().setProcessAction("addSim");
        request.getCartInfo().setClientAppName("VZW-ECOM");
        request.setChannelId("OMNI-RETAIL-TAB");
//        request.setRfexExchangeShopDetails(rfexExchangeShopDetails);
        Mockito.when(cartServiceBPMServices.createBulkQuote(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        Mono<BulkQuoteUIResponse> response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void testProcessBulkQuoteUpdate_digitalCheck() throws Exception {
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForProspect", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForExistingCustomer", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleFlowJourney", true);
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
        CreateBulkQuotePegaResponse pegaResponse = new CreateBulkQuotePegaResponse();
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        header.setSessionId("SESSIONID");
        pegaResponse.setServiceHeader(header);
        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
        CreateBulkQuoteServiceResponse serviceResponse = new CreateBulkQuoteServiceResponse();
        serviceBody.setServiceResponse(serviceResponse);
        pegaResponse.setServiceBody(serviceBody);
        CreateBulkQuotePegaRequest pegaRequest = new CreateBulkQuotePegaRequest();
        pegaRequest.setServiceBody(serviceBody);

        //processindicator M
        request.getCartInfo().setIntendType("AAL");
        request.getCartInfo().setMtnFlow("M");
        request.getData().getLines().get(0).getDevice().setNetworkBandwidthType("");
        request.getCartInfo().setProcessingMTN("");
        Mockito.when(cartServiceBPMServices.createBulkQuote(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        Mono<BulkQuoteUIResponse> response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        // AccountGrowth
        request.getCartInfo().setIntendType("AccountGrowth");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        // AAL_5G
        request.setChannelId("digital");
        request.getCartInfo().setIntendType("AAL_5G");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        // AAL_5G
        request.getCartInfo().setIntendType("NSE_5G");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        // AAL_LTE
        request.getCartInfo().setIntendType("AAL_LTE");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        //NSE_LTE
        request.getCartInfo().setIntendType("NSE_LTE");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void testProcessBulkQuoteUpdate_simcheck() throws Exception {
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForProspect", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForExistingCustomer", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleFlowJourney", true);
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
        CreateBulkQuotePegaResponse pegaResponse = new CreateBulkQuotePegaResponse();
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        header.setSessionId("SESSIONID");
        pegaResponse.setServiceHeader(header);
        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
        CreateBulkQuoteServiceResponse serviceResponse = new CreateBulkQuoteServiceResponse();
        serviceBody.setServiceResponse(serviceResponse);
        pegaResponse.setServiceBody(serviceBody);
        CreateBulkQuotePegaRequest pegaRequest = new CreateBulkQuotePegaRequest();
        pegaRequest.setServiceBody(serviceBody);
        request.getCartInfo().setIntendType("EUPBYOD");
        request.getCartInfo().setProcessAction("addSim");
        request.getCartInfo().setClientAppName("VZW-ECOM");
        request.setChannelId("OMNI-RETAIL-TAB");
        request.getData().getLines().get(0).getDevice().setNetworkBandwidthType("");
        Mockito.when(cartServiceBPMServices.createBulkQuote(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        Mono<BulkQuoteUIResponse> response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        //processaction=""
        request.getCartInfo().setProcessAction("AIQUOTE");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        //intent check
//        request.getCartInfo().setIntent("");
        request.getCartInfo().setIntendType("AAL");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        //intent check
//        request.getCartInfo().setIntent("");
        request.getCartInfo().setIntendType("EUP");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        //processstep=""
        request.getCartInfo().setProcessStep("");
        request.getCartInfo().setProcessAction("");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        //flag false
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForProspect", false);
        request.getCartInfo().setIntendType("NSE");
//        request.getCartInfo().setFiveGMUCEligible("NA");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void testProcessBulkQuoteUpdate_pegaresponseerror() throws Exception {
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForProspect", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForExistingCustomer", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleFlowJourney", true);
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
        CreateBulkQuotePegaResponse pegaResponse = new CreateBulkQuotePegaResponse();
        List<onevz.soe.wsclient.bpm.model.response.Error> errorList = new ArrayList<>();
        onevz.soe.wsclient.bpm.model.response.Error error = new onevz.soe.wsclient.bpm.model.response.Error();
        error.setMessage("ERROR");
        errorList.add(error);
        pegaResponse.setErrors(errorList);
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        header.setSessionId("SESSIONID");
        CreateBulkQuotePegaRequest pegaRequest = new CreateBulkQuotePegaRequest();
        Mockito.when(cartServiceBPMServices.createBulkQuote(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        Mono<BulkQuoteUIResponse> response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void testProcessBulkQuoteUpdate_pegaresponsetradeinerror() throws Exception {
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForProspect", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForExistingCustomer", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleFlowJourney", true);
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
        CreateBulkQuotePegaResponse pegaResponse = new CreateBulkQuotePegaResponse();
        List<CartError> errorList = new ArrayList<>();
        CartError error = new CartError();
        error.setMessage("ERROR");
        errorList.add(error);
        pegaResponse.setTradeinCartErrorData(errorList);
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        header.setSessionId("SESSIONID");
        CreateBulkQuotePegaRequest pegaRequest = new CreateBulkQuotePegaRequest();
        Mockito.when(cartServiceBPMServices.createBulkQuote(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.empty());
        Mono<BulkQuoteUIResponse> response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void testProcessCustomerInfoForAddDeviceNullChecks() throws Exception{
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForProspect", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForExistingCustomer", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleFlowJourney", true);
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
        CreateBulkQuotePegaResponse pegaResponse = new CreateBulkQuotePegaResponse();
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        header.setSessionId("SESSIONID");
        pegaResponse.setServiceHeader(header);
        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
        CreateBulkQuoteServiceResponse serviceResponse = new CreateBulkQuoteServiceResponse();
        serviceBody.setServiceResponse(serviceResponse);
        pegaResponse.setServiceBody(serviceBody);
        request.getCartInfo().setByodESim(null);
        request.setExternalId(null);
        request.setVzId(null);
        request.setUniversalId(null);
        request.getCartInfo().setAccountNumber(null);
        request.getCartInfo().setActivateSwitchFlow(null);
        request.getCartInfo().setNumberShareCapable(null);
        request.getCartInfo().setENineAddrIndicator("true");
        request.getCartInfo().setTwoYearUpgrade(null);
        request.getCartInfo().setMtnFlow(null);
        request.getCartInfo().setSpecialItemType(null);
        request.getCartInfo().setEditDeviceConfiguratorClick(null);
        request.getCartInfo().setShowICPage(null);
        request.getCartInfo().setEditDevice(null);
        request.getCartInfo().setIsSmartLocator(null);
        request.getCartInfo().setBuyOutFlag("");
        request.getCartInfo().setIsGemini(null);
        request.getCartInfo().setIsTradeInSelected(null);
        request.getCartInfo().setSalesRepId("");
        request.getCartInfo().setFlowType("");
        request.getCartInfo().setReplaceDevice(null);
        request.getData().getLines().get(0).getDevice().setProductId(null);
        request.getData().getLines().get(0).getDevice().setCategory(null);
        request.getData().setEsimType(null);
        request.getCartInfo().setEditFromPage(null);
        request.getCartInfo().setRedemptionCode("");
        request.getCartInfo().setIsPromoPDP(null);
        request.getCartInfo().setNoPendingOfferExists(null);

        Mockito.when(cartServiceBPMServices.createBulkQuote(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        Mono<BulkQuoteUIResponse> response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        // device is null
        request.getData().getLines().get(0).setDevice(null);
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void testProcessCustomerInfoForAddAccessories() throws Exception{
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForProspect", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForExistingCustomer", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleFlowJourney", true);
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
        CreateBulkQuotePegaResponse pegaResponse = new CreateBulkQuotePegaResponse();
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        header.setSessionId("SESSIONID");
        pegaResponse.setServiceHeader(header);
        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
        CreateBulkQuoteServiceResponse serviceResponse = new CreateBulkQuoteServiceResponse();
        serviceBody.setServiceResponse(serviceResponse);
        pegaResponse.setServiceBody(serviceBody);
        request.getCartInfo().setMtnFlow("");
        request.getCartInfo().setPageId(null);
        request.getData().setMultiAccBogoOffer(null);
        request.setChannelId("digital");
        ServerHttpRequest serverHttpRequest = MockServerHttpRequest.get("http://localhost/nse/").header("channelId", "digital").build();
        request.setHttpRequest(serverHttpRequest);
        Mockito.when(cartServiceBPMServices.createBulkQuote(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        Mono<BulkQuoteUIResponse> response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleFlowJourney", false);
        request.setChannelId("OMNI-RETAIL");
        request.setHttpRequest(null);
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void testProcessContextInfoForAddFeatures() throws Exception{
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForProspect", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForExistingCustomer", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleFlowJourney", true);
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
        CreateBulkQuotePegaResponse pegaResponse = new CreateBulkQuotePegaResponse();
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        header.setSessionId("SESSIONID");
        pegaResponse.setServiceHeader(header);
        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
        CreateBulkQuoteServiceResponse serviceResponse = new CreateBulkQuoteServiceResponse();
        serviceBody.setServiceResponse(serviceResponse);
        pegaResponse.setServiceBody(serviceBody);
        request.getCartInfo().setExpressCheckout(null);
        request.getCartInfo().setEditDeviceConfiguratorClick(null);
        request.getCartInfo().setEditPlanClick(null);
        request.getCartInfo().setPromoHubJourney(null);
        request.getCartInfo().setCradleFlowJourney(null);
        request.getCartInfo().setIntendType("NSE");
        Mockito.when(cartServiceBPMServices.createBulkQuote(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        Mono<BulkQuoteUIResponse> response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        request.getCartInfo().setPromoHubJourney(true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForProspect", false);
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();


        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForProspect", false);
        request.getCartInfo().setExpressCheckout(true);
        request.getCartInfo().setEditDeviceConfiguratorClick(true);
        request.getCartInfo().setEditPlanClick(true);
        request.getCartInfo().setIntendType("NSE");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();


        request.getCartInfo().setPromoHubJourney(true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForExistingCustomer", false);
        request.getCartInfo().setIntendType("");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        request.getCartInfo().setProcessStep("5GBOLT");
        request.getCartInfo().setClientAppName("VZW-NUMBERLINK");
        request.getCartInfo().setIntent(null);
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        request.getCartInfo().setIntendType("AAL_5G");
        request.setChannelId("digital");
        Account account = new Account();
        McsSubscriptionAction mcsSubscriptionAction = new McsSubscriptionAction();
        List<McsSubscription> mcsSubscriptions = new ArrayList<>();
        McsSubscription mcsSubscription = new McsSubscription();
        mcsSubscription.setName("NAME1");
        mcsSubscriptions.add(mcsSubscription);
        mcsSubscriptionAction.setAdd(mcsSubscriptions);
        mcsSubscriptionAction.setRemove(mcsSubscriptions);
        account.setMcsSubscription(mcsSubscriptionAction);
        request.getData().setAccount(account);
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        mcsSubscriptionAction.setRemove(mcsSubscriptions);
        request.getData().getAccount().getMcsSubscription().setAdd(null);
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        mcsSubscriptionAction.setAdd(mcsSubscriptions);
        request.getData().getAccount().getMcsSubscription().setRemove(null);
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        request.getData().getAccount().setMcsSubscription(null);
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        request.getData().setAccount(null);
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void testProcessContextInfoForAddPlanAndPerks() throws Exception{
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
        CreateBulkQuotePegaResponse pegaResponse = new CreateBulkQuotePegaResponse();
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        header.setSessionId("SESSIONID");
        pegaResponse.setServiceHeader(header);
        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
        CreateBulkQuoteServiceResponse serviceResponse = new CreateBulkQuoteServiceResponse();
        serviceBody.setServiceResponse(serviceResponse);
        pegaResponse.setServiceBody(serviceBody);
        request.getCartInfo().setClientAppName("VZW-DOTCOM-BBP");
        request.getCartInfo().setIntent(null);
        request.getCartInfo().setIntendType("AAL_5G");
        request.getCartInfo().setProcessStep("AI");
        request.setChannelId("digital");
        Mockito.when(cartServiceBPMServices.createBulkQuote(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        Mono<BulkQuoteUIResponse> response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void testProcessCustomerInfoForAddPlanAndPerks() throws Exception{
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForProspect", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForExistingCustomer", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleFlowJourney", true);
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
        CreateBulkQuotePegaResponse pegaResponse = new CreateBulkQuotePegaResponse();
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        header.setSessionId("SESSIONID");
        pegaResponse.setServiceHeader(header);
        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
        CreateBulkQuoteServiceResponse serviceResponse = new CreateBulkQuoteServiceResponse();
        serviceBody.setServiceResponse(serviceResponse);
        pegaResponse.setServiceBody(serviceBody);
        request.getCartInfo().setAccountLevelPlan(null);
        request.getCartInfo().setRegisterNumber(null);
        request.getCartInfo().setQuoteWithoutCredit(null);
        request.getCartInfo().setIsUpgradePlan(null);
        request.getCartInfo().setCartCreator(null);
        request.getCartInfo().setIsfiveGUpSellSelected(null);
        request.getCartInfo().setAccountLevelProtection(null);
        request.getCartInfo().setDeviceType(null);
        Mockito.when(cartServiceBPMServices.createBulkQuote(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        Mono<BulkQuoteUIResponse> response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void testProcessContextInfoForAddDevice() throws Exception{
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForProspect", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForExistingCustomer", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleFlowJourney", true);
        CartServiceCustomerInfo cartInfo = new CartServiceCustomerInfo();
        cartInfo.setGlobalId("GLOBALID");
        cartInfo.setAccountNumber("ACCT");
        cartInfo.setCartCreator("AI");
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest_Tradein.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
        CreateBulkQuotePegaResponse pegaResponse = new CreateBulkQuotePegaResponse();
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        header.setSessionId("SESSIONID");
        pegaResponse.setServiceHeader(header);
        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
        CreateBulkQuoteServiceResponse serviceResponse = new CreateBulkQuoteServiceResponse();
        serviceBody.setServiceResponse(serviceResponse);
        pegaResponse.setServiceBody(serviceBody);
        request.getCartInfo().setIsPrepayCart(null);
        request.getCartInfo().setCustomerType(null);
        Mockito.when(cartServiceBPMServices.createBulkQuote(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        Mono<BulkQuoteUIResponse> response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        request.getCartInfo().setIntendType("AAL");
        request.getCartInfo().setCustomerType("U");
        request.getCartInfo().setIsPrepayCart("Y");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        request.getCartInfo().setCaseId("SOF");
        request.setChannelId("OMNI-TELESALES");
        request.getData().getLines().get(0).getDevice().setIsCustomerProvidedEquipment(null);
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        request.getCartInfo().setCaseId("SOF");
        request.setChannelId("OMNI-TELESALES");
        request.getData().getLines().get(0).getDevice().setIsCustomerProvidedEquipment(false);
        request.getCartInfo().setIntendType("AAL");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        request.getCartInfo().setCaseId("SOF");
        request.setChannelId("OMNI-TELESALES");
        request.getData().getLines().get(0).getDevice().setIsCustomerProvidedEquipment(false);
        request.getCartInfo().setIntendType("BYOD");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        request.getCartInfo().setCaseId("SOF");
        request.setChannelId("OMNI-TELESALES");
        request.getData().getLines().get(0).setDevice(null);
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        request.getCartInfo().setCaseId("SOF");
        request.setChannelId(null);
        request.getData().getLines().get(0).setDevice(null);
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        request.getCartInfo().setCaseId(null);
        request.setChannelId(null);
        request.getData().getLines().get(0).setDevice(null);
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        request.getCartInfo().setCaseId("SOF");
        request.setChannelId("VZW-DOTCOM-BBP");
        request.getData().setEsimFlowType("LostICCIdProfile");
        request.getCartInfo().setIntendType("NSEBYOD");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        request.getCartInfo().setCaseId("SOF");
        request.setChannelId("VZW-DOTCOM-BBP");
        request.getData().setEsimFlowType("LostICCId");
        request.getCartInfo().setIntendType("NSEBYOD");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        request.getCartInfo().setCaseId(null);
        request.setChannelId("VZW-DOTCOM-BBP");
        request.getData().setEsimFlowType(null);
        request.getCartInfo().setIntendType("");
        request.getData().getLines().get(0).setCurrentDeviceID(null);
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();


        request.setChannelId("VZW-DOTCOM-BBP");
        request.getCartInfo().setFlowType("PLAN_BUILDER");
        request.getCartInfo().setIntent(null);
        request.getCartInfo().setSubscriptionType(null);
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }


    @Test
    public void testProcessContextInfoForAddAccessories() throws Exception{
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForProspect", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForExistingCustomer", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleFlowJourney", true);
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
        CreateBulkQuotePegaResponse pegaResponse = new CreateBulkQuotePegaResponse();
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        header.setSessionId("SESSIONID");
        pegaResponse.setServiceHeader(header);
        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
        CreateBulkQuoteServiceResponse serviceResponse = new CreateBulkQuoteServiceResponse();
        serviceBody.setServiceResponse(serviceResponse);
        pegaResponse.setServiceBody(serviceBody);

        request.getCartInfo().setIntent(null);
        request.getCartInfo().setProcessAction("");
        request.getCartInfo().setIntendType("AAL");
        Mockito.when(cartServiceBPMServices.createBulkQuote(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        Mono<BulkQuoteUIResponse> response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        request.getCartInfo().setIntent(null);
        request.getCartInfo().setProcessAction(null);
        request.setRequestApiName("add-step");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        request.setRequestApiName(null);
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        request.setRequestApiName("OTHER");
        List<UpdateBarcodeBarcodeId> updateBarcodeBarcodeIds = new ArrayList<>();
        UpdateBarcodeBarcodeId updateBarcodeBarcodeId = new UpdateBarcodeBarcodeId();
        updateBarcodeBarcodeId.setBarCodeId("BARCODEID");
        updateBarcodeBarcodeIds.add(updateBarcodeBarcodeId);
        request.getCartInfo().setBarCodeIds(updateBarcodeBarcodeIds);
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        request.getCartInfo().setBarCodeIds(null);
        request.getCartInfo().setIsQuoteCart(null);
        request.getCartInfo().setIntendType("BYOD");
        request.getCartInfo().setProcessingMTN("");
        request.getCartInfo().setClientAppName("VZW-RPS");
        request.getCartInfo().setTriggerPricingValidation(true);
        request.setChannelId("OMNI-RETAIL-TAB");
        request.getCartInfo().setMtnFlow("PromoBundle");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        request.getCartInfo().setIntendType("NSEBYOD");
        request.getCartInfo().setMtnFlow(null);
        request.getData().getLines().get(0).setEditSim(null);
        request.getData().getLines().get(0).getDevice().setNetworkBandwidthType("LTE");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        request.getData().getLines().get(0).setEditSim(true);
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        request.getData().getLines().get(0).setDevice(null);
        request.getCartInfo().setIntendType("CCH");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        request.getCartInfo().setIntendType("EXC");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        request.getCartInfo().setIntendType("EXCBYOD");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        request.getCartInfo().setIntendType("PAD");
        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

//    @Test
//    public void testLinesCartPegaRequestUtil2() throws Exception {
//        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForProspect", true);
//        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForExistingCustomer", true);
//        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleFlowJourney", true);
////        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest_Lines.json");
//        File file = ResourceUtils.getFile("classpath:data/BulkUpdateUIToSOERequestNew.json");
//        String expectedJson = new String(Files.readAllBytes(file.toPath()));
//        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
//        CreateBulkQuotePegaResponse pegaResponse = new CreateBulkQuotePegaResponse();
//        CartServiceServiceHeader header = new CartServiceServiceHeader();
//        header.setSessionId("SESSIONID");
//        pegaResponse.setServiceHeader(header);
//        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
//        CreateBulkQuoteServiceResponse serviceResponse = new CreateBulkQuoteServiceResponse();
//        serviceBody.setServiceResponse(serviceResponse);
//        pegaResponse.setServiceBody(serviceBody);
//        Mockito.when(cartServiceBPMServices.createBulkQuote(Mockito.any())).thenReturn(Mono.just(pegaResponse));
//        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
//        Mono<BulkQuoteUIResponse> response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
//        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
//
//        request.setChannelId("OMNI-INDIRECT");
//        response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
//        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
//
//    }

    @Test
    public void testLinesCartPegaRequestUtil2NullChecks() throws Exception {
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForProspect", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForExistingCustomer", true);
        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleFlowJourney", true);
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest_LinesNull.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
        CreateBulkQuotePegaResponse pegaResponse = new CreateBulkQuotePegaResponse();
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        header.setSessionId("SESSIONID");
        pegaResponse.setServiceHeader(header);
        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
        CreateBulkQuoteServiceResponse serviceResponse = new CreateBulkQuoteServiceResponse();
        serviceBody.setServiceResponse(serviceResponse);
        pegaResponse.setServiceBody(serviceBody);
        Mockito.when(cartServiceBPMServices.createBulkQuote(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        Mono<BulkQuoteUIResponse> response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

//    @Test
//    public void testLinesCartPegaRequestUtil2NullChecks2() throws Exception {
//        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForProspect", true);
//        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleForExistingCustomer", true);
//        ReflectionTestUtils.setField(bulkQuoteUpdatePegaRequestUtil, "enableCradleFlowJourney", true);
////        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest_PlanIndD.json");
//        File file = ResourceUtils.getFile("classpath:data/BulkUpdateUIToSOERequestNew.json");
//        String expectedJson = new String(Files.readAllBytes(file.toPath()));
//        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
//        CreateBulkQuotePegaResponse pegaResponse = new CreateBulkQuotePegaResponse();
//        CartServiceServiceHeader header = new CartServiceServiceHeader();
//        header.setSessionId("SESSIONID");
//        pegaResponse.setServiceHeader(header);
//        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
//        CreateBulkQuoteServiceResponse serviceResponse = new CreateBulkQuoteServiceResponse();
//        serviceBody.setServiceResponse(serviceResponse);
//        pegaResponse.setServiceBody(serviceBody);
//        Mockito.when(cartServiceBPMServices.createBulkQuote(Mockito.any())).thenReturn(Mono.just(pegaResponse));
//        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
//        Mono<BulkQuoteUIResponse> response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request, "SESSIONID");
//        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
//    }

    @Test
    public void testProcessBulkQuoteUpdate_SessionFailure() throws Exception{
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
        CreateBulkQuotePegaResponse pegaResponse = new CreateBulkQuotePegaResponse();
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        header.setSessionId("SESSIONID");
        pegaResponse.setServiceHeader(header);
        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
        CreateBulkQuoteServiceResponse serviceResponse = new CreateBulkQuoteServiceResponse();
        serviceBody.setServiceResponse(serviceResponse);
        pegaResponse.setServiceBody(serviceBody);
        CreateBulkQuotePegaRequest pegaRequest = new CreateBulkQuotePegaRequest();
        pegaRequest.setServiceBody(serviceBody);
        Mockito.when(cartServiceBPMServices.createBulkQuote(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        SOEError error = new SOEError();
        error.setMessage("Exception Occurred");
        List<SOEError> errors = new ArrayList<SOEError>();
        errors.add(error);
        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.error(new SOEHTTPException(0, new SOEErrorHolder(errors))));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        Mono<BulkQuoteUIResponse> response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request,"SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void testmapPlanForSFO() throws Exception{
        Lines reqLine = new Lines();
        Plan plan = new Plan();
        List<Sfo> sfoList = new ArrayList<>();
        Sfo sfo = new Sfo();
        sfo.setActionindicator("A");
        sfo.setBundlename("BUNDLE");
        sfoList.add(sfo);
        plan.setSFO(sfoList);
        reqLine.setPlan(plan);
        Line newLine = new Line();
        bulkQuoteUpdatePegaRequestUtil.mapPlanForSFO(reqLine, newLine);
        org.junit.Assert.assertNotNull(newLine);

        //actionIndicator D
        reqLine.getPlan().getSFO().get(0).setActionindicator("D");
        bulkQuoteUpdatePegaRequestUtil.mapPlanForSFO(reqLine, newLine);
        org.junit.Assert.assertNotNull(newLine);
    }

    @Test
    public void testmapPlanForSPO() throws Exception{
        Lines reqLine = new Lines();
        Plan plan = new Plan();
        List<PlanPromoSpo> planPromoSpoList = new ArrayList<>();
        PlanPromoSpo planPromoSpo = new PlanPromoSpo();
        planPromoSpo.setAction("ADD");
        planPromoSpoList.add(planPromoSpo);
        plan.setPlanPromoSpo(planPromoSpoList);
        reqLine.setPlan(plan);
        Line newLine = new Line();
        bulkQuoteUpdatePegaRequestUtil.mapPlanForSPO(reqLine, newLine);
        org.junit.Assert.assertNotNull(newLine);

        //action REMOVE
        reqLine.getPlan().getPlanPromoSpo().get(0).setAction("REMOVE");
        bulkQuoteUpdatePegaRequestUtil.mapPlanForSPO(reqLine, newLine);
        org.junit.Assert.assertNotNull(newLine);
    }

    @Test
    public void addFeaturesToBulkCartLineTest() throws Exception{
        onevz.soe.cart.model.bulkcartupdate.Line newLine = new Line();
        onevz.soe.cart.model.bulkcartupdate.Lines reqLine = new Lines();
        List<Feature> addFeaturesList = new ArrayList<>();
        Feature feature = new Feature();
        feature.setId("ID");
        addFeaturesList.add(feature);
        reqLine.setAddFeatures(addFeaturesList);
        List<Feature> removeFeaturesList = new ArrayList<>();
        Feature feature1 = new Feature();
        feature1.setId("ID1");
        removeFeaturesList.add(feature1);
        reqLine.setRemoveFeatures(removeFeaturesList);
        CartServiceBulkCartInfo cartInfo = new CartServiceBulkCartInfo();
        bulkQuoteUpdatePegaRequestUtil.addFeaturesToBulkCartLine(newLine, reqLine, cartInfo);
        org.junit.Assert.assertNotNull(newLine);
    }

    @Test
    public void testformatCustomerInfoForPegaRequest() throws Exception{
        CartServiceCustomerInfo customerInfo = new CartServiceCustomerInfo();
        BulkQuoteUIRequest request = new BulkQuoteUIRequest();
        request.setChannelId("OMNI-RETAIL");
        CartInfo cartInfo = new CartInfo();
        cartInfo.setCreditAppNum("CREDITAPPNUM");
        request.setCartInfo(cartInfo);
        bulkQuoteUpdatePegaRequestUtil.formatCustomerInfoForPegaRequest( customerInfo,  request);
        org.junit.Assert.assertNotNull(request);

        // creditappnum empty
        request.getCartInfo().setCreditAppNum("");
        bulkQuoteUpdatePegaRequestUtil.formatCustomerInfoForPegaRequest( customerInfo,  request);
        org.junit.Assert.assertNotNull(request);
    }

    @Test
    public void testMapperError() throws Exception {
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest1.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
        // Invalid addr data
        String addr = "invalid json";

        // Mocking the behavior of objectMapper.readValue to throw an exception
        when(mockMapper.readValue(addr, Address.class)).thenThrow(new RuntimeException());

        // Creating a mock Req
        CartServiceBulkCartInfo cartInfo1 = new CartServiceBulkCartInfo();
        List<DeviceOutInfo> tradeInItems = null;
        Map<String, String> data = new HashMap<>();
        data.put(CartConstants.QUOTE_E911_ADDR,addr);

        onevz.soe.cart.model.bulkcartupdate.Line[] resp = ReflectionTestUtils.invokeMethod(bulkQuoteUpdatePegaRequestUtil, "populateLinesFromUiBulkRequestToPegaObject",  cartInfo1,request,tradeInItems,data);

        //response is not null--> only one attribute in resp
        org.junit.Assert.assertNotNull(resp);

    }

    @Test
    public void formatContextInfoTest() throws Exception{
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest1.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
        CartServiceBulkCartInfo cartInfo = new CartServiceBulkCartInfo();
        CartServiceContextInfo context = new CartServiceContextInfo();

        ReflectionTestUtils.invokeMethod(bulkQuoteUpdatePegaRequestUtil, "formatContextInfoForPegaRequest",  context,cartInfo,request);
        org.junit.Assert.assertNotNull(context);

        request.getCartInfo().setIntendType("AAL");
        ReflectionTestUtils.invokeMethod(bulkQuoteUpdatePegaRequestUtil, "formatContextInfoForPegaRequest",  context,cartInfo,request);
        org.junit.Assert.assertNotNull(context);

        request.getCartInfo().setIntendType("BYOD");
        ReflectionTestUtils.invokeMethod(bulkQuoteUpdatePegaRequestUtil, "formatContextInfoForPegaRequest",  context,cartInfo,request);
        org.junit.Assert.assertNotNull(context);

        request.getCartInfo().setIntendType("NSE");
        ReflectionTestUtils.invokeMethod(bulkQuoteUpdatePegaRequestUtil, "formatContextInfoForPegaRequest",  context,cartInfo,request);
        org.junit.Assert.assertNotNull(context);

        request.getCartInfo().setProcessAction("");
        request.getCartInfo().setIntendType("AAL");
        ReflectionTestUtils.invokeMethod(bulkQuoteUpdatePegaRequestUtil, "formatContextInfoForPegaRequest",  context,cartInfo,request);
        org.junit.Assert.assertNotNull(context);

        request.getCartInfo().setProcessAction("");
        request.getCartInfo().setIntendType("EUP");
        ReflectionTestUtils.invokeMethod(bulkQuoteUpdatePegaRequestUtil, "formatContextInfoForPegaRequest",  context,cartInfo,request);
        org.junit.Assert.assertNotNull(context);

    }

    @Test
    public void populateLinesFromUiBulkReqTest() throws Exception {
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest1.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);


        // Creating a mock Req
        CartServiceBulkCartInfo cartInfo1 = new CartServiceBulkCartInfo();
        List<DeviceOutInfo> tradeInItems = null;
        Map<String, String> data = new HashMap<>();
        data.put(CartConstants.QUOTE_E911_ADDR,"");

        when(sessionBean.getSessionData(Mockito.any())).thenReturn(Mono.just(data));
        onevz.soe.cart.model.bulkcartupdate.Line[] resp = ReflectionTestUtils.invokeMethod(bulkQuoteUpdatePegaRequestUtil, "populateLinesFromUiBulkRequestToPegaObject",  cartInfo1,request,tradeInItems,data);
        org.junit.Assert.assertNotNull(resp);

        data.put(CartConstants.MTN,"473637678");
        when(sessionBean.getSessionData(Mockito.any())).thenReturn(Mono.just(data));
        onevz.soe.cart.model.bulkcartupdate.Line[] resp1 = ReflectionTestUtils.invokeMethod(bulkQuoteUpdatePegaRequestUtil, "populateLinesFromUiBulkRequestToPegaObject",  cartInfo1,request,tradeInItems,data);
        org.junit.Assert.assertNotNull(resp1);
    }

    @Test
    public void populateLinesFromUiBulkReqTest1() throws Exception {
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest2.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);

        // Creating a mock Req
        CartServiceBulkCartInfo cartInfo1 = new CartServiceBulkCartInfo();
        List<DeviceOutInfo> tradeInItems = null;
        Map<String, String> data = new HashMap<>();
        data.put(CartConstants.QUOTE_E911_ADDR,"");

        when(sessionBean.getSessionData(Mockito.any())).thenReturn(Mono.just(data));
        onevz.soe.cart.model.bulkcartupdate.Line[] resp = ReflectionTestUtils.invokeMethod(bulkQuoteUpdatePegaRequestUtil, "populateLinesFromUiBulkRequestToPegaObject",  cartInfo1,request,tradeInItems,data);
        org.junit.Assert.assertNotNull(resp);

        request.getData().setLines(null);
        onevz.soe.cart.model.bulkcartupdate.Line[] resp1 = ReflectionTestUtils.invokeMethod(bulkQuoteUpdatePegaRequestUtil, "populateLinesFromUiBulkRequestToPegaObject",  cartInfo1,request,tradeInItems,data);
        org.junit.Assert.assertNotNull(resp1);

        request.setData(null);
        onevz.soe.cart.model.bulkcartupdate.Line[] resp2 = ReflectionTestUtils.invokeMethod(bulkQuoteUpdatePegaRequestUtil, "populateLinesFromUiBulkRequestToPegaObject",  cartInfo1,request,tradeInItems,data);
        org.junit.Assert.assertNotNull(resp2);

        request.setCartInfo(null);
        onevz.soe.cart.model.bulkcartupdate.Line[] resp3 = ReflectionTestUtils.invokeMethod(bulkQuoteUpdatePegaRequestUtil, "populateLinesFromUiBulkRequestToPegaObject",  cartInfo1,request,tradeInItems,data);
        org.junit.Assert.assertNotNull(resp3);

    }

    @Test
    public void testProcessBulkQuoteUpdateErrors() throws Exception{
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest1.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        header.setSessionId("SESSIONID");
        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
        CreateBulkQuotePegaRequest pegaRequest = new CreateBulkQuotePegaRequest();
        pegaRequest.setServiceBody(serviceBody);
        Mockito.when(sessionBean.getSessionData(Mockito.any())).thenReturn(Mono.empty());
        Mockito.when(cartServiceBPMServices.createBulkQuote(Mockito.any())).thenThrow(new SOEHTTPException(400,"Failed call"));
        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        Mono<BulkQuoteUIResponse> response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request,"SESSIONID");
        StepVerifier.create(response).expectNextCount(1).verifyComplete();
    }

    @Test
    public void testProcessBulkQuoteUpdate2() throws Exception{
        //service body null for pegaresponse
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest1.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
        CreateBulkQuotePegaResponse pegaResponse = new CreateBulkQuotePegaResponse();
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        header.setSessionId("SESSIONID");
        pegaResponse.setServiceHeader(header);
        Map<String,String> sessionData = new HashMap<>();
        String val ="{\"addressLine1\":\"1123 STATE ROUTE 380 APT# H\",\"city\":\"APOLLO\",\"state\":\"PA\",\"zipCode\":\"15613\",\"fipsCode\":\"4212900000\"}";
        sessionData.put(CartConstants.QUOTE_E911_ADDR,val);
        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
        CreateBulkQuotePegaRequest pegaRequest = new CreateBulkQuotePegaRequest();
        pegaRequest.setServiceBody(serviceBody);
        Mockito.when(sessionBean.getSessionData(Mockito.any())).thenReturn(Mono.just(sessionData));
        Mockito.when(cartServiceBPMServices.createBulkQuote(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        Mono<BulkQuoteUIResponse> response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request,"SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void isTradeInFlowTrue() {
        CartData cartData = Mockito.mock(CartData.class);
        Lines lines = Mockito.mock(Lines.class);
        when(lines.getTradeInItems()).thenReturn(Collections.singletonList(Mockito.mock(DeviceOutInfo.class)));
        when(cartData.getLines()).thenReturn(Collections.singletonList(lines));
        when(bulkQuoteUIRequest.getData()).thenReturn(cartData);
        boolean result = bulkUpdateAIQuoteHelper.isTradeInFlow(bulkQuoteUIRequest);
        Assert.assertTrue(result);
    }

    @Test
    public void isTradeInFlowFalse() {
        CartData cartData = Mockito.mock(CartData.class);
        Lines lines = Mockito.mock(Lines.class);
        when(lines.getTradeInItems()).thenReturn(Collections.emptyList());
        when(cartData.getLines()).thenReturn(Collections.singletonList(lines));
        when(bulkQuoteUIRequest.getData()).thenReturn(cartData);
        boolean result = bulkUpdateAIQuoteHelper.isTradeInFlow(bulkQuoteUIRequest);
        Assert.assertFalse(result);
    }

    @Test
    public void getTradeinNodeFromUIReq() {
        CartData cartData = Mockito.mock(CartData.class);
        Lines lines = Mockito.mock(Lines.class);
        when(lines.getTradeInItems()).thenReturn(Collections.emptyList());
        when(cartData.getLines()).thenReturn(Collections.singletonList(lines));
        when(bulkQuoteUIRequest.getData()).thenReturn(cartData);
        DeviceOutInfo result = bulkUpdateAIQuoteHelper.getTradeinNodeFromUIReq(bulkQuoteUIRequest);
        Assert.assertNull(result);

        when(lines.getTradeInItems()).thenReturn(null);
        DeviceOutInfo result1 = bulkUpdateAIQuoteHelper.getTradeinNodeFromUIReq(bulkQuoteUIRequest);
        Assert.assertNull(result1);
    }

    @Test
    public void getTradeinNodeFromUIReq_success() {
        CartData cartData = Mockito.mock(CartData.class);
        Lines lines = Mockito.mock(Lines.class);
        when(lines.getTradeInItems()).thenReturn(Collections.singletonList(Mockito.mock(DeviceOutInfo.class)));
        when(cartData.getLines()).thenReturn(Collections.singletonList(lines));
        when(bulkQuoteUIRequest.getData()).thenReturn(cartData);
        DeviceOutInfo result = bulkUpdateAIQuoteHelper.getTradeinNodeFromUIReq(bulkQuoteUIRequest);
        Assert.assertNotNull(result);
    }

    @Test
    public void setErroIdAndErrorMessage() {
        SOEHTTPException exception = bulkUpdateAIQuoteHelper.setErroIdAndErrorMessage("testErrorMessage", "101");
        Assert.assertEquals("testErrorMessage", exception.getErrorHolder().getErrors().get(0).getMessage());
        Assert.assertEquals("101", exception.getErrorHolder().getErrors().get(0).getId());
    }

    @Test
    public void isStoreInfoPresent_true() {
        LineDetail lineDetail = Mockito.mock(LineDetail.class);
        LineInfo lineInfo = Mockito.mock(LineInfo.class);
        ItemsInfoLite itemsInfoLite = Mockito.mock(ItemsInfoLite.class);
        when(lineDetail.getLineInfo()).thenReturn(Collections.singletonList(lineInfo));
        when(lineInfo.getItemsInfo()).thenReturn(Collections.singletonList(itemsInfoLite));
        when(itemsInfoLite.getShipping()).thenReturn(Mockito.mock(Shipping.class));
        Assert.assertTrue(bulkUpdateAIQuoteHelper.isStoreInfoPresent(lineDetail));
    }

    @Test
    public void isStoreInfoPresent_false() {
        LineDetail lineDetail = Mockito.mock(LineDetail.class);
        LineInfo lineInfo = Mockito.mock(LineInfo.class);
        ItemsInfoLite itemsInfoLite = Mockito.mock(ItemsInfoLite.class);

        Assert.assertFalse(bulkUpdateAIQuoteHelper.isStoreInfoPresent(null));

        when(lineDetail.getLineInfo()).thenReturn(null);
        Assert.assertFalse(bulkUpdateAIQuoteHelper.isStoreInfoPresent(lineDetail));

        when(lineDetail.getLineInfo()).thenReturn(Collections.emptyList());
        Assert.assertFalse(bulkUpdateAIQuoteHelper.isStoreInfoPresent(lineDetail));

        when(lineDetail.getLineInfo()).thenReturn(Collections.singletonList(lineInfo));
        when(lineInfo.getItemsInfo()).thenReturn(null);
        Assert.assertFalse(bulkUpdateAIQuoteHelper.isStoreInfoPresent(lineDetail));

        when(lineInfo.getItemsInfo()).thenReturn(Collections.emptyList());
        Assert.assertFalse(bulkUpdateAIQuoteHelper.isStoreInfoPresent(lineDetail));

        when(lineInfo.getItemsInfo()).thenReturn(Collections.singletonList(itemsInfoLite));
        when(itemsInfoLite.getShipping()).thenReturn(null);
        Assert.assertFalse(bulkUpdateAIQuoteHelper.isStoreInfoPresent(lineDetail));

    }

    @Test
    public void testProcessBulkQuoteUpdateWithTradeInSessionData() throws Exception{
        RetrieveTradeinGQLResponse tradeinGQLResponse= new RetrieveTradeinGQLResponse();
        CartDetailsData cartDetailsData= new CartDetailsData();
        onevz.soe.cart.model.bulkcartupdate.gql.response.CartInfo cartInfo = new onevz.soe.cart.model.bulkcartupdate.gql.response.CartInfo();
        LineDetail lineDetail= new LineDetail();
        TradeinDetail tradeinDetail= new TradeinDetail();
        tradeinDetail.setTradeInItems(Collections.singletonList(new BaseDeviceOutInfo2()));
        lineDetail.setTradeInDetail(tradeinDetail);
        cartInfo.setOrderDetails(new OrderDetails());
        cartInfo.setLineDetails(lineDetail);
        cartDetailsData.setCart(cartInfo);
        tradeinGQLResponse.setData(cartDetailsData);
        when(tradeinSessionData.getTradeinData()).thenReturn(Collections.emptyMap());
        Mockito.when(tradeInHelper.readTradeinSessionData(anyString())).thenReturn(Mono.just(tradeinSessionData));
        Mockito.when(cxpService.retrieveCartTradeinInfo(anyString())).thenReturn(Mono.just(tradeinGQLResponse));
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
        CreateBulkQuotePegaResponse pegaResponse = new CreateBulkQuotePegaResponse();
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        header.setSessionId("SESSIONID");
        pegaResponse.setServiceHeader(header);
        Map<String,String> sessionData = new HashMap<>();
        String val ="{\"addressLine1\":\"1123 STATE ROUTE 380 APT# H\",\"city\":\"APOLLO\",\"state\":\"PA\",\"zipCode\":\"15613\",\"fipsCode\":\"4212900000\"}";
        sessionData.put(CartConstants.QUOTE_E911_ADDR,val);
        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
        CreateBulkQuoteServiceResponse serviceResponse = new CreateBulkQuoteServiceResponse();
        serviceBody.setServiceResponse(serviceResponse);
        pegaResponse.setServiceBody(serviceBody);
        CreateBulkQuotePegaRequest pegaRequest = new CreateBulkQuotePegaRequest();
        pegaRequest.setServiceBody(serviceBody);
        Mockito.when(sessionBean.getSessionData(Mockito.any())).thenReturn(Mono.just(sessionData));
        Mockito.when(cartServiceBPMServices.createBulkQuote(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        Mono<BulkQuoteUIResponse> response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request,"SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

    }

    @Test
    public void testProcessBulkQuoteUpdateWithProperTradeInSessionData() throws Exception{
        RetrieveTradeinGQLResponse tradeinGQLResponse= new RetrieveTradeinGQLResponse();
        CartDetailsData cartDetailsData= new CartDetailsData();
        onevz.soe.cart.model.bulkcartupdate.gql.response.CartInfo cartInfo = new onevz.soe.cart.model.bulkcartupdate.gql.response.CartInfo();
        LineDetail lineDetail= new LineDetail();
        TradeinDetail tradeinDetail= new TradeinDetail();
        tradeinDetail.setTradeInItems(Collections.singletonList(new BaseDeviceOutInfo2()));
        lineDetail.setTradeInDetail(tradeinDetail);
        cartInfo.setOrderDetails(new OrderDetails());
        cartInfo.setLineDetails(lineDetail);
        cartDetailsData.setCart(cartInfo);
        tradeinGQLResponse.setData(cartDetailsData);
        DeviceOutInfo deviceOutInfo= new DeviceOutInfo();
        deviceOutInfo.setTriageInfo(new TriageInfo());
        deviceOutInfo.setRecycleDeviceOffer(new RecycleDeviceOffer());
        deviceOutInfo.setSubmissionId("1314");
        deviceOutInfo.setDeviceId("354840090504284");
        TradeinSessionData tradeinSessionData1 = new TradeinSessionData();
        Map<String, DeviceOutInfo> tradeDataMap= new HashMap<>();
        tradeDataMap.put("354840090504284", deviceOutInfo);
        tradeinSessionData1.setTradeinData(tradeDataMap);
        when(tradeinSessionData.getTradeinData()).thenReturn(tradeDataMap);
        Mockito.when(tradeInHelper.readTradeinSessionData(anyString())).thenReturn(Mono.just(tradeinSessionData1));
        Mockito.when(cxpService.retrieveCartTradeinInfo(anyString())).thenReturn(Mono.just(tradeinGQLResponse));
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
        CreateBulkQuotePegaResponse pegaResponse = new CreateBulkQuotePegaResponse();
        Vzdl vzdl = new Vzdl();
        Event event = new Event();
        event.setValue("event");
        vzdl.setEvent(event);
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        header.setSessionId("SESSIONID");
        pegaResponse.setServiceHeader(header);
        Map<String,String> sessionData = new HashMap<>();
        String val ="{\"addressLine1\":\"1123 STATE ROUTE 380 APT# H\",\"city\":\"APOLLO\",\"state\":\"PA\",\"zipCode\":\"15613\",\"fipsCode\":\"4212900000\"}";
        sessionData.put(CartConstants.QUOTE_E911_ADDR,val);
        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
        CreateBulkQuoteServiceResponse serviceResponse = new CreateBulkQuoteServiceResponse();
        serviceBody.setServiceResponse(serviceResponse);
        pegaResponse.setServiceBody(serviceBody);
        CreateBulkQuotePegaRequest pegaRequest = new CreateBulkQuotePegaRequest();
        pegaRequest.setServiceBody(serviceBody);
        Mockito.when(sessionBean.getSessionData(Mockito.any())).thenReturn(Mono.just(sessionData));
        Mockito.when(cartServiceBPMServices.createBulkQuote(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        Mockito.when(bulkUpdateHelper.getVzdlDataForBulkUpdate(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(vzdl);
        Mockito.doNothing().when(deviceHelper).updateDLDataForAssisted(vzdl);
        Mono<BulkQuoteUIResponse> response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request,"SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

    }

    @Test
    public void testProcessBulkQuoteUpdateTaggingError() throws Exception{
        RetrieveTradeinGQLResponse tradeinGQLResponse= new RetrieveTradeinGQLResponse();
        CartDetailsData cartDetailsData= new CartDetailsData();
        onevz.soe.cart.model.bulkcartupdate.gql.response.CartInfo cartInfo = new onevz.soe.cart.model.bulkcartupdate.gql.response.CartInfo();
        LineDetail lineDetail= new LineDetail();
        TradeinDetail tradeinDetail= new TradeinDetail();
        tradeinDetail.setTradeInItems(Collections.singletonList(new BaseDeviceOutInfo2()));
        lineDetail.setTradeInDetail(tradeinDetail);
        cartInfo.setOrderDetails(new OrderDetails());
        cartInfo.setLineDetails(lineDetail);
        cartDetailsData.setCart(cartInfo);
        tradeinGQLResponse.setData(cartDetailsData);
        when(tradeinSessionData.getTradeinData()).thenReturn(Collections.emptyMap());
        Mockito.when(tradeInHelper.readTradeinSessionData(anyString())).thenReturn(Mono.just(tradeinSessionData));
        Mockito.when(cxpService.retrieveCartTradeinInfo(anyString())).thenReturn(Mono.just(tradeinGQLResponse));
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
        CreateBulkQuotePegaResponse pegaResponse = new CreateBulkQuotePegaResponse();
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        Vzdl vzdl = new Vzdl();
        Event event = new Event();
        event.setValue("event");
        vzdl.setEvent(event);
        header.setSessionId("SESSIONID");
        pegaResponse.setServiceHeader(header);
        Map<String,String> sessionData = new HashMap<>();
        String val ="{\"addressLine1\":\"1123 STATE ROUTE 380 APT# H\",\"city\":\"APOLLO\",\"state\":\"PA\",\"zipCode\":\"15613\",\"fipsCode\":\"4212900000\"}";
        sessionData.put(CartConstants.QUOTE_E911_ADDR,val);
        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
        CreateBulkQuoteServiceResponse serviceResponse = new CreateBulkQuoteServiceResponse();
        serviceBody.setServiceResponse(serviceResponse);
        pegaResponse.setServiceBody(serviceBody);
        CreateBulkQuotePegaRequest pegaRequest = new CreateBulkQuotePegaRequest();
        pegaRequest.setServiceBody(serviceBody);
        String error = "Error on tagging";
        Mockito.when(sessionBean.getSessionData(Mockito.any())).thenReturn(Mono.just(sessionData));
        Mockito.when(cartServiceBPMServices.createBulkQuote(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        Mockito.doThrow(new MockitoException(error)).when(bulkUpdateHelper).getVzdlDataForBulkUpdate(Mockito.any(), Mockito.any(), Mockito.any());
        Mockito.doNothing().when(deviceHelper).updateDLDataForAssisted(null);
        Mono<BulkQuoteUIResponse> response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request,"SESSIONID");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }
    
    @Test
    public void testUpdateTradeInRequest() throws IOException {
        DeviceOutInfo deviceOutInfo= Mockito.mock(DeviceOutInfo.class);
        RecycleDeviceOffer recycleDeviceOffer= Mockito.mock(RecycleDeviceOffer.class);
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
        when(tradeinSessionData.getTradeinData()).thenReturn(Collections.singletonMap("352048883399605",deviceOutInfo));
        when(deviceOutInfo.getSubmissionId()).thenReturn("Test");
        BulkUpdateAIQuoteHelper.updateTradeInRequest(request,tradeinSessionData);
        Assert.assertEquals("Test",request.getData().getLines().get(0).getTradeInItems().get(0).getSubmissionId());

        when(deviceOutInfo.getSubmissionId()).thenReturn(null);
        when(deviceOutInfo.getRecycleDeviceOffer()).thenReturn(recycleDeviceOffer);
        BulkUpdateAIQuoteHelper.updateTradeInRequest(request,tradeinSessionData);
        Assert.assertEquals(recycleDeviceOffer,request.getData().getLines().get(0).getTradeInItems().get(0).getRecycleDeviceOffer());
    }

    @Test
    public void testProcessBulkQuoteUpdateWithTradeInSessionDataError() throws Exception{
        RetrieveTradeinGQLResponse tradeinGQLResponse= new RetrieveTradeinGQLResponse();
        CartDetailsData cartDetailsData= new CartDetailsData();
        onevz.soe.cart.model.bulkcartupdate.gql.response.CartInfo cartInfo = new onevz.soe.cart.model.bulkcartupdate.gql.response.CartInfo();
        TradeinDetail tradeinDetail= new TradeinDetail();
        tradeinDetail.setTradeInItems(Collections.singletonList(new BaseDeviceOutInfo2()));
        cartDetailsData.setCart(cartInfo);
        tradeinGQLResponse.setData(cartDetailsData);
        when(tradeinSessionData.getTradeinData()).thenReturn(Collections.emptyMap());
        Mockito.when(tradeInHelper.readTradeinSessionData(anyString())).thenReturn(Mono.just(tradeinSessionData));
        Mockito.when(cxpService.retrieveCartTradeinInfo(anyString())).thenReturn(Mono.just(tradeinGQLResponse));
        File file = ResourceUtils.getFile("classpath:data/BulkCartUpdateRequest.json");
        String expectedJson = new String(Files.readAllBytes(file.toPath()));
        BulkQuoteUIRequest request = objectMapper.readValue(expectedJson, BulkQuoteUIRequest.class);
        CreateBulkQuotePegaResponse pegaResponse = new CreateBulkQuotePegaResponse();
        CartServiceServiceHeader header = new CartServiceServiceHeader();
        header.setSessionId("SESSIONID");
        pegaResponse.setServiceHeader(header);
        Map<String,String> sessionData = new HashMap<>();
        String val ="{\"addressLine1\":\"1123 STATE ROUTE 380 APT# H\",\"city\":\"APOLLO\",\"state\":\"PA\",\"zipCode\":\"15613\",\"fipsCode\":\"4212900000\"}";
        sessionData.put(CartConstants.QUOTE_E911_ADDR,val);
        CreateBulkQuoteServiceBody serviceBody = new CreateBulkQuoteServiceBody();
        CreateBulkQuoteServiceResponse serviceResponse = new CreateBulkQuoteServiceResponse();
        serviceBody.setServiceResponse(serviceResponse);
        pegaResponse.setServiceBody(serviceBody);
        CreateBulkQuotePegaRequest pegaRequest = new CreateBulkQuotePegaRequest();
        pegaRequest.setServiceBody(serviceBody);
        Mockito.when(sessionBean.getSessionData(Mockito.any())).thenReturn(Mono.just(sessionData));
        Mockito.when(cartServiceBPMServices.createBulkQuote(Mockito.any())).thenReturn(Mono.just(pegaResponse));
        Mockito.when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        Mono<BulkQuoteUIResponse> response = bulkUpdateAIQuoteHelper.processBulkQuoteUpdate(request,"SESSIONID");
        StepVerifier.create(response).expectError(SOEHTTPException.class).verify();

    }

}

