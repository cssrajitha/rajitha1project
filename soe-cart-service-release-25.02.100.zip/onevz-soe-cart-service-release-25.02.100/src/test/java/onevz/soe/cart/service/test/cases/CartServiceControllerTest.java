package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.net.URI;
import java.util.*;

import junit.framework.Assert;
import onevz.cxp.feature.ConfigurationProfile;
import onevz.cxp.feature.Flag;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.controller.CartUpdateOperationsController;
import onevz.soe.cart.controller.CartUpdateOperationsController2;
import onevz.soe.cart.controller.CartUpdateOperationsController3;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.helper.CartAccessoryHelper;
import onevz.soe.cart.helper.CartAddDeviceHelper;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.helper.TradeInHelper;
import onevz.soe.cart.helper.UpdateCartHelper;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.model.common.CartServiceCartInfo;
import onevz.soe.cart.model.common.PastDue;
import onevz.soe.cart.model.createLine.CreateLineContext;
import onevz.soe.cart.model.createLine.CreateLineServiceBody;
import onevz.soe.cart.model.createLine.CreateLineServiceResponse;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.CustomerProfileCXPResponse;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.responses.PastDueRedisData;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.common.PastDuesData;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.omnidl.util.DLUtilityService;
import onevz.soe.security.TokenProcessor;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import onevz.soe.session.bean.SOELoginSessionBean;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.*;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpResponse;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(CartUpdateOperationsController.class)
public class CartServiceControllerTest {

    @MockBean
    private UpdateCartHelper cartHelper;

    @Autowired
    private CartUpdateOperationsController cartController;

    @Autowired
    private CartUpdateOperationsController2 cartController2;

    @Autowired
    private CartUpdateOperationsController3 cartController3;

    @MockBean
    private CartServiceCxpHelper cartServiceCXPHelper;

    @Autowired
    private ObjectMapper mapper;

    @MockBean
    private RedisHelper redisHelper;
    
    @MockBean
    private RedisHelper2 redisHelper2;
    
    @MockBean
    private RedisHelper3 redisHelper3;

    @MockBean
    private DLUtilityService dlUtilityService;

    @MockBean
    private TokenProcessor tokenProcessor;

    @MockBean
    private CartAddDeviceHelper devHelper;

    @MockBean
    private CartAccessoryHelper accHelper;

    @MockBean
    private TradeInHelper tradeInHelper;

    @Value("${enableClearAndAddItem:false}")
    private boolean enableClearAndAddItem;

    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;

    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;

    @MockBean
    private SOELoginSessionBean soeLoginSessionBean;
    @MockBean
    private OmniDLHelper omniDLHelper;
    @MockBean
    private FeatureFlagHelper featureFlagHelper;
    @Test
    public void typeAheadTest() throws IOException {
        String requestString = "{\"deviceCategory\":\"Smartphone\",\"model\":\"iphone\"}";
        String responseString = "{ \"data\": [ { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 11\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 11\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 11\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"IPHONE 11 NON VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"IPHONE 11 NON VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE 11 NON VZW\", \"carrierName\": \"TMOBILE\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 11 PRO\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 11 PRO\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 11 PRO\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"IPHONE 11 PRO NON VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"IPHONE 11 PRO NON VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE 11 PRO NON VZW\", \"carrierName\": \"TMOBILE\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 11 PRO MAX\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 11 PRO MAX\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 11 PRO MAX NON VZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"IPHONE 11 PRO MAX NON VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"IPHONE 11 PRO MAX NON VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE 11 PRO MAX\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 12\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 12\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 12\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"IPHONE 12 GEN NVZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"IPHONE 12 GEN NVZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE 12 GEN NVZW\", \"carrierName\": \"ATT\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 12 MINI\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 12 MINI\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 12 MINI\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 12 PRO\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 12 PRO\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 12 PRO\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 12 PRO MAX\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 12 PRO MAX\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 12 PRO MAX\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 13\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 13\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 13 NVZ\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"iPhone 13 NVZ\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 13 NVZ\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 13\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 13 mini\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 13 mini\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 13 mini\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"iPhone 13 mini NVZ\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 13 mini NVZ\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 13 mini NVZ\", \"carrierName\": \"ATT\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 13 Pro\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 13 Pro\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 13 Pro NVZ\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 13 Pro NVZ\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 13 Pro NVZ\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"iPhone 13 Pro\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 13 Pro Max\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 13 Pro Max\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 13 Pro Max\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"iPhone 13 Pro Max NVZ\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"iPhone 13 Pro Max NVZ\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 13 Pro Max NVZ\", \"carrierName\": \"TMOBILE\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 4\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 4\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 4\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 4S\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 4S\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 4S\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 5\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 5\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 5\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 5C\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 5C\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 5C\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 5S\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 5S\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 5S\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 6\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 6\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 6\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"IPHONE 6 SPRINT\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 6 - Non VZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 6 - Non VZW\", \"carrierName\": \"ATT\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 6 Plus\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 6 Plus\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 6 Plus - Non VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"iPhone 6 Plus - Non VZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 6 Plus - Non VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 6 Plus\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 6S\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 6S\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 6S\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"iPhone 6S Non VZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 6S Non VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 6S Non VZW\", \"carrierName\": \"ATT\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 6S Plus\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 6S Plus\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 6S Plus\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"iPhone 6S Plus Non VZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 6S Plus Non VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 6S Plus Non VZW\", \"carrierName\": \"ATT\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 7\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 7\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 7\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"iPhone 7 - Non VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 7 - Non VZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 7 - Non VZW\", \"carrierName\": \"ATT\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 7 Plus\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 7 Plus\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 7 Plus\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"iPhone 7 Plus - Non VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 7 Plus - Non VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"iPhone 7 Plus - Non VZW\", \"carrierName\": \"TMOBILE\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 8\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 8\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 8 Non Verizon\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 8 Non Verizon\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 8 Non Verizon\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"iPhone 8\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 8 Plus\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 8 Plus\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 8 Plus\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"iPhone 8 Plus Non Verizon\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 8 Plus Non Verizon\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 8 Plus Non Verizon\", \"carrierName\": \"ATT\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone SE\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone SE\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone SE\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"iPhone SE Non VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone SE Non VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"iPhone SE Non VZW\", \"carrierName\": \"TMOBILE\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone SE 2020\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone SE 2020\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE SE 2020\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPHONE SE GENERIC\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPHONE SE GENERIC\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPHONE SE GENERIC NON VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPHONE SE GENERIC NON VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"iPHONE SE GENERIC NON VZW\", \"carrierName\": \"TMOBILE\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone X\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone X\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE X NON VERIZON\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"IPHONE X NON VERIZON\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE X NON VERIZON\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"IPHONE X\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone XR\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone XR\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE XR NVZ\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"IPHONE XR NVZ\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE XR NVZ\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone XR\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone XS\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone XS\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone XS\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"IPHONE XS NVZ\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"IPHONE XS NVZ\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE XS NVZ\", \"carrierName\": \"TMOBILE\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone XS Max\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone XS Max\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone XS Max\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"IPHONE XS MAX\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"IPHONE XS MAX\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE XS MAX\", \"carrierName\": \"TMOBILE\" } ] }, { \"carrier\": [ \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone12 MINI\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone12 MINI\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE12 MINI GEN NVZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"IPHONE12 MINI GEN NVZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"IPHONE12 MINI GEN NVZW\", \"carrierName\": \"SPRINT\" } ] }, { \"carrier\": [ \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone12 PRO\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone12 PRO\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE12 PRO GEN NVZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"IPHONE12 PRO GEN NVZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE12 PRO GEN NVZW\", \"carrierName\": \"ATT\" } ] }, { \"carrier\": [ \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone12 PROMAX\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone12 PROMAX\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE12 PROMAX GEN NVZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"IPHONE12 PROMAX GEN NVZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE12 PROMAX GEN NVZW\", \"carrierName\": \"ATT\" } ] } ] }";
        SmartImeiTypeAheadSearchRequest request = mapper.readValue(requestString,
                SmartImeiTypeAheadSearchRequest.class);
        SmartImeiTypeAheadSearchResponse response = mapper.readValue(responseString,
                SmartImeiTypeAheadSearchResponse.class);

        when(cartServiceCXPHelper.getSmartImeiTypeAheadResponse(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.typeAhead(request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void typeAheadTestSamsung() throws IOException {
        String requestString = "{\"deviceCategory\":\"Smartphone\",\"model\":\"samsung\"}";
        String responseString = "{ \"data\": [ { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"BEYONDX PREORDER\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"BEYONDX PREORDER\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"BEYONDX PREORDER\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"GALAXY A42 5G\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"GALAXY A42 5G\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"GALAXY A42 5G\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"GALAXY A51 5G UW\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"GALAXY A51 5G UW\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"GALAXY A51 5G UW\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"GALAXY A71 5G UW\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"GALAXY A71 5G UW\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"GALAXY A71 5G UW\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Galaxy Note9\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Galaxy Note9\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Galaxy Note9\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"GALAXY S10 5G\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"GALAXY S10 5G\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"GALAXY S10 5G\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"GALAXY S20 5G UW\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"GALAXY S20 5G UW\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"GALAXY S20 5G UW\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"GALAXY S20 PLUS 5G\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"GALAXY S20 PLUS 5G\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"GALAXY S20 PLUS 5G\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"GALAXY S20 ULTRA 5G\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"GALAXY S20 ULTRA 5G\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"GALAXY S20 ULTRA 5G\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"GALAXY S21 5G\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"GALAXY S21 5G\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"GALAXY S21 5G\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"GALAXY S21 FE 5G\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"GALAXY S21 FE 5G\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"GALAXY S21 FE 5G\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"GALAXY S21 PLUS 5G\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"GALAXY S21 PLUS 5G\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"GALAXY S21 PLUS 5G\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"GALAXY S21 U 5G\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"GALAXY S21 U 5G\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"GALAXY S21 U 5G\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"GALAXY S22 PLUS\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"GALAXY S22 PLUS\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"GALAXY S22 PLUS\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"GALAXY S22 ULTRA\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"GALAXY S22 ULTRA\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"GALAXY S22 ULTRA\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Galaxy S9 Plus\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Galaxy S9 Plus\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Galaxy S9 Plus\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"GALAXY Z FLIP3 5G\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"GALAXY Z FLIP3 5G\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"GALAXY Z FLIP3 5G\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"GALAXY Z FOLD2\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"GALAXY Z FOLD2\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"GALAXY Z FOLD2\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"GALAXY Z FOLD3 5G\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"GALAXY Z FOLD3 5G\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"GALAXY Z FOLD3 5G\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"NOTE20 5G\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"NOTE20 5G\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"NOTE20 5G\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"NOTE20 ULTRA 5G\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"NOTE20 ULTRA 5G\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"NOTE20 ULTRA 5G\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"SAM GALAXY J7 V 2ND GENERATION\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"SAM GALAXY J7 V 2ND GENERATION\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"SAM GALAXY J7 V 2ND GENERATION\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung A50\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung A50\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"SAMSUNG A50\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung ATIV\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung ATIV\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Samsung ATIV\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung ATIV Odyssey\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung ATIV Odyssey\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Samsung ATIV Odyssey\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung Continuum SCH-i400\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung Continuum SCH-i400\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Samsung Continuum SCH-i400\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung Fascinate\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung Fascinate\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Samsung Fascinate\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung GALAXY A01\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung GALAXY A01\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"SAMSUNG GALAXY A01\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung GALAXY A02\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung GALAXY A02\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"SAMSUNG GALAXY A02\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung GALAXY A03S\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung GALAXY A03S\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"SAMSUNG GALAXY A03S\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung GALAXY A10E\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung GALAXY A10E\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"SAMSUNG GALAXY A10E\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung GALAXY A11 BLK\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung GALAXY A11 BLK\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"SAMSUNG GALAXY A11 BLK\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung GALAXY A12\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung GALAXY A12\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"SAMSUNG GALAXY A12\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung GALAXY A20\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung GALAXY A20\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"SAMSUNG GALAXY A20\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung GALAXY A21\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung GALAXY A21\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"SAMSUNG GALAXY A21\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung GALAXY A51\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung GALAXY A51\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"SAMSUNG GALAXY A51\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung GALAXY J3 ECLIPSE\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung GALAXY J3 ECLIPSE\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"SAMSUNG GALAXY J3 ECLIPSE\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung Galaxy J3 V\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung Galaxy J3 V\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Samsung Galaxy J3 V\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung GALAXY J3 V 3RD GEN\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung GALAXY J3 V 3RD GEN\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"SAMSUNG GALAXY J3 V 3RD GEN\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung Galaxy J7 V\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung Galaxy J7 V\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Samsung Galaxy J7 V\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung Galaxy Nexus\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung Galaxy Nexus\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Samsung Galaxy Nexus\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung Galaxy Note 3\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung Galaxy Note 3\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Samsung Galaxy Note 3\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung Galaxy Note 4\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung Galaxy Note 4\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Samsung Galaxy Note 4\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung Galaxy Note Edge\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung Galaxy Note Edge\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Samsung Galaxy Note Edge\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung Galaxy Note II\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung Galaxy Note II\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Samsung Galaxy Note II\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung GALAXY NOTE10\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung GALAXY NOTE10\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"SAMSUNG GALAXY NOTE10\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung GALAXY NOTE10 PLUS\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung GALAXY NOTE10 PLUS\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"SAMSUNG GALAXY NOTE10 PLUS\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung GALAXY NOTE10 PLUS 5G\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung GALAXY NOTE10 PLUS 5G\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"SAMSUNG GALAXY NOTE10 PLUS 5G\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung Galaxy Note5\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung Galaxy Note5\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Samsung Galaxy Note5\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung Galaxy Note7\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung Galaxy Note7\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"SAMSUNG Galaxy Note7\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung Galaxy S 4\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung Galaxy S 4\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Samsung Galaxy S 4\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung Galaxy S 4 Mini\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung Galaxy S 4 Mini\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Samsung Galaxy S 4 Mini\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung Galaxy S 5\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung Galaxy S 5\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Samsung Galaxy S 5\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung Galaxy S III\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung Galaxy S III\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Samsung Galaxy S III\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung Galaxy S III Mini\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung Galaxy S III Mini\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Samsung Galaxy S III Mini\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung GALAXY S10\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung GALAXY S10\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"SAMSUNG GALAXY S10\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung GALAXY S10 PLUS\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung GALAXY S10 PLUS\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"SAMSUNG GALAXY S10 PLUS\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung GALAXY S10e\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung GALAXY S10e\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"SAMSUNG GALAXY S10e\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung GALAXY S20 FE 5G\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung GALAXY S20 FE 5G\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"SAMSUNG GALAXY S20 FE 5G\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung GALAXY S22\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung GALAXY S22\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"SAMSUNG GALAXY S22\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung Galaxy S6\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung Galaxy S6\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Samsung Galaxy S6\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung Galaxy S6 Edge\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung Galaxy S6 Edge\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Samsung Galaxy S6 Edge\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung GALAXY S6 EDGE PLUS\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung GALAXY S6 EDGE PLUS\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"SAMSUNG GALAXY S6 EDGE PLUS\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung Galaxy S7\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung Galaxy S7\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Samsung Galaxy S7\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung Galaxy S7 edge\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung Galaxy S7 edge\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Samsung Galaxy S7 edge\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung Galaxy S8\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung Galaxy S8\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Samsung Galaxy S8\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung Galaxy S8 Plus\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung Galaxy S8 Plus\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Samsung Galaxy S8 Plus\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung Galaxy S9\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung Galaxy S9\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Samsung Galaxy S9\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung Galaxy Stellar\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung Galaxy Stellar\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Samsung Galaxy Stellar\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung Galaxy Stratosphere II\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung Galaxy Stratosphere II\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Samsung Galaxy Stratosphere II\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung Gem\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung Gem\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Samsung Gem\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung Illusion\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung Illusion\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Samsung Illusion\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung NOTE 8\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung NOTE 8\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"SAMSUNG NOTE 8\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung Saga SCH-i770\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung Saga SCH-i770\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Samsung Saga SCH-i770\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"Samsung Stratosphere\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"Samsung Stratosphere\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"Samsung Stratosphere\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"SCH-I510\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"SCH-I510\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"SCH-I510\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"SCH-i760\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"SCH-i760\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"SCH-i760\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"SCH-i770\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"SCH-i770\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"SCH-i770\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"SCH-i830\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"SCH-i830\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"SCH-i830\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"SCH-i910\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"SCH-i910\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"SCH-i910\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"SCH-i920\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Samsung\", \"modifiedName\": \"SCH-i920\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"SCH-i920\", \"carrierName\": \"VERIZON\" } ] } ] }";
        SmartImeiTypeAheadSearchRequest request = mapper.readValue(requestString,
                SmartImeiTypeAheadSearchRequest.class);
        SmartImeiTypeAheadSearchResponse response = mapper.readValue(responseString,
                SmartImeiTypeAheadSearchResponse.class);

        when(cartServiceCXPHelper.getSmartImeiTypeAheadResponse(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.typeAhead(request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void typeAheadTestiPhone13() throws IOException {
        String requestString = "{\"deviceCategory\":\"Smartphone\",\"model\":\"iphone 13\"}";
        String responseString = "{ \"data\": [ { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 13\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 13\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 13 NVZ\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"iPhone 13 NVZ\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 13 NVZ\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 13\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 13 mini\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 13 mini\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 13 mini\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"iPhone 13 mini NVZ\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 13 mini NVZ\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 13 mini NVZ\", \"carrierName\": \"ATT\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 13 Pro\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 13 Pro\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 13 Pro NVZ\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 13 Pro NVZ\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 13 Pro NVZ\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"iPhone 13 Pro\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 13 Pro Max\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 13 Pro Max\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 13 Pro Max\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"iPhone 13 Pro Max NVZ\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"iPhone 13 Pro Max NVZ\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 13 Pro Max NVZ\", \"carrierName\": \"TMOBILE\" } ] } ] }";
        SmartImeiTypeAheadSearchRequest request = mapper.readValue(requestString,
                SmartImeiTypeAheadSearchRequest.class);
        SmartImeiTypeAheadSearchResponse response = mapper.readValue(responseString,
                SmartImeiTypeAheadSearchResponse.class);
        when(cartServiceCXPHelper.getSmartImeiTypeAheadResponse(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.typeAhead(request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void typeAheadTestiPhone11() throws IOException {
        String requestString = "{\"deviceCategory\":\"Smartphone\",\"model\":\"iphone 11\"}";
        String responseString = "{ \"data\": [ { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 11\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 11\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 11\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"IPHONE 11 NON VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"IPHONE 11 NON VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE 11 NON VZW\", \"carrierName\": \"TMOBILE\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 11 PRO\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 11 PRO\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 11 PRO\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"IPHONE 11 PRO NON VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"IPHONE 11 PRO NON VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE 11 PRO NON VZW\", \"carrierName\": \"TMOBILE\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 11 PRO MAX\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 11 PRO MAX\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 11 PRO MAX NON VZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"IPHONE 11 PRO MAX NON VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"IPHONE 11 PRO MAX NON VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE 11 PRO MAX\", \"carrierName\": \"VERIZON\" } ] } ] }";
        SmartImeiTypeAheadSearchRequest request = mapper.readValue(requestString,
                SmartImeiTypeAheadSearchRequest.class);
        SmartImeiTypeAheadSearchResponse response = mapper.readValue(responseString,
                SmartImeiTypeAheadSearchResponse.class);
        when(cartServiceCXPHelper.getSmartImeiTypeAheadResponse(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.typeAhead(request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void typeAheadTestApple() throws IOException {
        String requestString = "{\"deviceCategory\":\"Smartphone\",\"model\":\"apple\"}";
        String responseString = "{ \"data\": [ { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 11\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 11\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 11 NON VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"IPHONE 11 NON VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE 11 NON VZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"IPHONE 11\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 11 PRO\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 11 PRO\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 11 PRO\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"IPHONE 11 PRO NON VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"IPHONE 11 PRO NON VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE 11 PRO NON VZW\", \"carrierName\": \"TMOBILE\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 11 PRO MAX\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 11 PRO MAX\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 11 PRO MAX\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"IPHONE 11 PRO MAX NON VZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"IPHONE 11 PRO MAX NON VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"IPHONE 11 PRO MAX NON VZW\", \"carrierName\": \"SPRINT\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 12\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 12\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 12\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"IPHONE 12 GEN NVZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"IPHONE 12 GEN NVZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE 12 GEN NVZW\", \"carrierName\": \"ATT\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 12 MINI\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 12 MINI\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 12 MINI\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 12 PRO\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 12 PRO\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 12 PRO\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 12 PRO MAX\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 12 PRO MAX\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 12 PRO MAX\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 13\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 13\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 13-2 NVZ\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"iPhone 13-2 NVZ\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 13-2 NVZ\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 13\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 13 mini\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 13 mini\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 13 mini\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"iPhone 13 mini NVZ\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 13 mini NVZ\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 13 mini NVZ\", \"carrierName\": \"ATT\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 13 Pro\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 13 Pro\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 13 Pro\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"iPhone 13 Pro-2 NVZ\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 13 Pro-2 NVZ\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"iPhone 13 Pro-2 NVZ\", \"carrierName\": \"SPRINT\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 13 Pro Max\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 13 Pro Max\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 13 Pro Max-2 NVZ\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"iPhone 13 Pro Max-2 NVZ\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 13 Pro Max-2 NVZ\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 13 Pro Max-2\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 4\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 4\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 4\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 4S\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 4S\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 4S\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 5\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 5\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 5\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 5C\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 5C\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 5C\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 5S\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 5S\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 5S\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 6\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 6\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 6 - Non VZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 6 - Non VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 6 - Non VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"iPhone 6\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 6 Plus\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 6 Plus\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 6 Plus\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"iPhone 6 Plus - Non VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"iPhone 6 Plus - Non VZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 6 Plus - Non VZW\", \"carrierName\": \"SPRINT\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 6S\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 6S\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 6S Non VZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 6S Non VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 6S Non VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"iPhone 6S\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 6S Plus\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 6S Plus\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 6S Plus Non VZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 6S Plus Non VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 6S Plus Non VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"iPhone 6S Plus\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 7\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 7\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 7\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"iPhone 7 - Non VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 7 - Non VZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 7 - Non VZW\", \"carrierName\": \"ATT\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 7 Plus\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 7 Plus\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 7 Plus\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"iPhone 7 Plus - Non VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 7 Plus - Non VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"iPhone 7 Plus - Non VZW\", \"carrierName\": \"TMOBILE\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 8\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 8\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 8\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"iPhone 8 Non Verizon\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 8 Non Verizon\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 8 Non Verizon\", \"carrierName\": \"ATT\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 8 Plus\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 8 Plus\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 8 Plus Non Verizon\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 8 Plus Non Verizon\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 8 Plus Non Verizon\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"iPhone 8 Plus\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone SE\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone SE\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone SE Non VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone SE Non VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"iPhone SE Non VZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone SE\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone SE 2020\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone SE 2020\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE SE 2020\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPHONE SE GENERIC\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPHONE SE GENERIC\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPHONE SE GENERIC NON VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPHONE SE GENERIC NON VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"iPHONE SE GENERIC NON VZW\", \"carrierName\": \"TMOBILE\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone X\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone X\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE X\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"IPHONE X NON VERIZON\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"IPHONE X NON VERIZON\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE X NON VERIZON\", \"carrierName\": \"ATT\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone XR\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone XR\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone XR\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"IPHONE XR NVZ\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"IPHONE XR NVZ\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE XR NVZ\", \"carrierName\": \"TMOBILE\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone XS\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone XS\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE XS NVZ\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"IPHONE XS NVZ\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE XS NVZ\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone XS\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone XS Max\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone XS Max\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone XS Max\", \"carrierName\": \"VERIZON\" }, { \"deviceName\": \"IPHONE XS MAX NON VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"IPHONE XS MAX NON VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE XS MAX NON VZW\", \"carrierName\": \"TMOBILE\" } ] }, { \"carrier\": [ \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone12 MINI\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone12 MINI\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE12 MINI GEN NVZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"IPHONE12 MINI GEN NVZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"IPHONE12 MINI GEN NVZW\", \"carrierName\": \"SPRINT\" } ] }, { \"carrier\": [ \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone12 PRO\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone12 PRO\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE12 PRO GEN NVZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"IPHONE12 PRO GEN NVZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE12 PRO GEN NVZW\", \"carrierName\": \"ATT\" } ] }, { \"carrier\": [ \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone12 PROMAX\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone12 PROMAX\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE12 PROMAX GEN NVZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"IPHONE12 PROMAX GEN NVZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE12 PROMAX GEN NVZW\", \"carrierName\": \"ATT\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"LSBD\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"LSBD\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"LSBD\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"SSB1D\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"SSB1D\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"SSB1D-2\", \"carrierName\": \"VERIZON\" } ] } ] }";
        SmartImeiTypeAheadSearchRequest request = mapper.readValue(requestString,
                SmartImeiTypeAheadSearchRequest.class);
        SmartImeiTypeAheadSearchResponse response = mapper.readValue(responseString,
                SmartImeiTypeAheadSearchResponse.class);

        when(cartServiceCXPHelper.getSmartImeiTypeAheadResponse(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.typeAhead(request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void typeAheadTestNoResult() throws IOException {
        String requestString = "{\"deviceCategory\":\"Smartphone\",\"model\":\"iphone11\"}";
        String responseString = "{ \"data\": [] }";
        SmartImeiTypeAheadSearchRequest request = mapper.readValue(requestString,
                SmartImeiTypeAheadSearchRequest.class);
        SmartImeiTypeAheadSearchResponse response = mapper.readValue(responseString,
                SmartImeiTypeAheadSearchResponse.class);

        when(cartServiceCXPHelper.getSmartImeiTypeAheadResponse(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.typeAhead(request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void typeAheadESTest() throws IOException {
        String requestString = "{\"deviceCategory\":\"Smartphone\",\"model\":\"app\"}";
        String responseString = "{ \"data\": [ { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 11\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 11\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 11-E NON VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"IPHONE 11-E NON VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE 11-E NON VZW\", \"carrierName\": \"TMOBILE\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 11 PRO\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 11 PRO\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 11 PRO-E NON VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"IPHONE 11 PRO-E NON VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE 11 PRO-E NON VZW\", \"carrierName\": \"TMOBILE\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 11 PRO MAX\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 11 PRO MAX\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 12\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 12\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 12 eSIM\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 12 GEN W\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 12 GEN W\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 12 GEN-E NVZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"IPHONE 12 GEN-E NVZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"IPHONE 12 GEN-E NVZW\", \"carrierName\": \"SPRINT\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 12 MINI\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 12 MINI\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 12 MINI SO eSIM\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 12 PRO\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 12 PRO\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 12 PRO eSIM\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 12 PRO MAX\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 12 PRO MAX\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 12 PRO MAX SO eSIM\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 13\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 13\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 13 NVZ\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"iPhone 13 NVZ\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 13 NVZ\", \"carrierName\": \"TMOBILE\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 13 mini\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 13 mini\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 13 mini-2\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 13 Pro\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 13 Pro\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 13 Pro SO\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 13 Pro Max\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 13 Pro Max\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 13 Pro Max\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 4\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 4\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 4\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 4S\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 4S\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 4S\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 5\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 5\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE 5\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 5C\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 5C\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 5C\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 5S\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 5S\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 5S\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 6\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 6\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 6\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 6 Plus\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 6 Plus\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 6 Plus - Non VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"iPhone 6 Plus - Non VZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 6 Plus - Non VZW\", \"carrierName\": \"SPRINT\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 6S\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 6S\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 6S\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 6S Plus\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 6S Plus\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 6S Plus\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 7\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 7\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 7\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 7 Plus\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 7 Plus\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 7 Plus\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 8\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 8\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 8 Non Verizon\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"iPhone 8 Non Verizon\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPhone 8 Non Verizon\", \"carrierName\": \"ATT\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone 8 Plus\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone 8 Plus\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone 8 Plus\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone SE\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone SE\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone SE\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone SE 2020\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone SE 2020\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone SE 22\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone SE 22\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE SE 22 SO\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPHONE SE GENERIC\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPHONE SE GENERIC\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPHONE SE GENERIC NON VZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"iPHONE SE GENERIC NON VZW\", \"carrierName\": \"ATT\" }, { \"deviceName\": \"iPHONE SE GENERIC NON VZW\", \"carrierName\": \"TMOBILE\" } ] }, { \"carrier\": [ \"VERIZON\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone SE2020\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone SE2020\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE SE SO 2020\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone X\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone X\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE X NON VERIZON\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"IPHONE X NON VERIZON\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE X NON VERIZON\", \"carrierName\": \"ATT\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone XR\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone XR\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone XR eSIM\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone XS\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone XS\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone XS\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"VERIZON\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone XS Max\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone XS Max\", \"euiccCapable\": false, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"iPhone XS Max\", \"carrierName\": \"VERIZON\" } ] }, { \"carrier\": [ \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone12 MINI GEN W\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone12 MINI GEN W\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE12 MINI GEN-E NVZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"IPHONE12 MINI GEN-E NVZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE12 MINI GEN-E NVZW\", \"carrierName\": \"ATT\" } ] }, { \"carrier\": [ \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone12 PRO GEN W\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone12 PRO GEN W\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE12 PRO GEN-E NVZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"IPHONE12 PRO GEN-E NVZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE12 PRO GEN-E NVZW\", \"carrierName\": \"ATT\" } ] }, { \"carrier\": [ \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"lastupdate_es\": null, \"model_name_typeahead\": \"iPhone12 PROMAX GEN W\", \"device_category_typeahead\": null, \"devprod_id\": null, \"originating_system\": null, \"make_typeahead\": \"Apple\", \"modifiedName\": \"iPhone12 PROMAX GEN W\", \"euiccCapable\": true, \"autoCorrectPhrase\": null, \"deviceAndCarrier\": [ { \"deviceName\": \"IPHONE12 PROMAX GEN-E NVZW\", \"carrierName\": \"TMOBILE\" }, { \"deviceName\": \"IPHONE12 PROMAX GEN-E NVZW\", \"carrierName\": \"SPRINT\" }, { \"deviceName\": \"IPHONE12 PROMAX GEN-E NVZW\", \"carrierName\": \"ATT\" } ] } ] }";
        SmartImeiTypeAheadSearchRequest request = mapper.readValue(requestString,
                SmartImeiTypeAheadSearchRequest.class);
        SmartImeiTypeAheadSearchResponse response = mapper.readValue(responseString,
                SmartImeiTypeAheadSearchResponse.class);

        when(cartServiceCXPHelper.getSmartImeiTypeAheadResponse(any())).thenReturn(Mono.just(new SmartImeiTypeAheadSearchResponse()));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.typeAhead(request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateUserInfoTest() throws IOException {
        String requestString = "{\"client\": \"CXP\",\"cartId\": \"09cfa680-f331-4c03-b83f-e27322882457\",\"lines\":[{\"mtn\": \"1234567890\",\"firstName\": \"Jane\",\"lastName\": \"Doe\",\"email\":\"xyz@vzcorp.com\"}]}";
        String responseString = "{\"meta\":{\"timestamp\":\"2019-08-05T13:27:07Z\",\"cxpCorrelationId\":\"3d5f3c15-aa3b-4a42-9245-5cb4177468e4\"},\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"}}";
        UpdateUserInfoUIRequest request = mapper.readValue(requestString, UpdateUserInfoUIRequest.class);
        UpdateUserInfoUIResponse response = mapper.readValue(responseString, UpdateUserInfoUIResponse.class);
        URI url = URI.create("http://localhost/userInfo");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.updateUserInfo(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.updateUserInfo(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateUserInfoFlexV2Test() throws IOException {
        String requestString = "{\"client\": \"CXP\",\"cartId\": \"09cfa680-f331-4c03-b83f-e27322882457\",\"lines\":[{\"mtn\": \"1234567890\",\"firstName\": \"Jane\",\"lastName\": \"Doe\",\"email\":\"xyz@vzcorp.com\"}]}";
        String responseString = "{\"meta\":{\"timestamp\":\"2019-08-05T13:27:07Z\",\"cxpCorrelationId\":\"3d5f3c15-aa3b-4a42-9245-5cb4177468e4\"},\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"}}";
        UpdateUserInfoUIRequest request = mapper.readValue(requestString, UpdateUserInfoUIRequest.class);
        UpdateUserInfoUIResponse response = mapper.readValue(responseString, UpdateUserInfoUIResponse.class);
        URI url = URI.create("http://localhost/flexV2/userInfo");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.updateUserInfo(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.updateUserInfo(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateUserInfoErrorTest() throws IOException {
        String requestString = "{\"client\": \"CXP\",\"cartId\": \"09cfa680-f331-4c03-b83f-e27322882457\",\"lines\":[{\"mtn\": \"1234567890\",\"firstName\": \"Jane\",\"lastName\": \"Doe\",\"email\":\"xyz@vzcorp.com\"}]}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        UpdateUserInfoUIRequest request = mapper.readValue(requestString, UpdateUserInfoUIRequest.class);
        UpdateUserInfoUIResponse response = mapper.readValue(responseString, UpdateUserInfoUIResponse.class);
        URI url = URI.create("http://localhost/userInfo");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.valueOf(500));
        when(cartHelper.updateUserInfo(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.updateUserInfo(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void paperlessBillingTest() throws IOException {
        String requestString = "{    \"meta\": {        \"timestamp\": \"2019-08-05T13:27:07Z\",        \"cxpCorrelationId\": \"3d5f3c15-aa3b-4a42-9245-5cb4177468e4\"    },        \"data\": {        \"cartId\": \"03019841-59b2-44a4-9b41-88eafb43b4c6\",        \"statusMsg\": \"Paperless billing updated successfully.\"    }}";
        String responseString = "{\"client\": \"CXP\",\"cartId\": \"bea202a6-42cb-40d4-ac87-d3f1db2b3f13\",\"intendType\": \"AAL\",\"paperlessbilling\": true}";
        PaperlessBillingUIRequest request = mapper.readValue(requestString, PaperlessBillingUIRequest.class);
        PaperlessBillingUIResponse response = mapper.readValue(responseString, PaperlessBillingUIResponse.class);
        URI url = URI.create("http://localhost/enroll-paperlessBilling");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.paperlessBilling(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.enrollPaperlessBilling(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void paperlessBillingErrorTest() throws IOException {
        String requestString = "{    \"meta\": {        \"timestamp\": \"2019-08-05T13:27:07Z\",        \"cxpCorrelationId\": \"3d5f3c15-aa3b-4a42-9245-5cb4177468e4\"    },        \"data\": {        \"cartId\": \"03019841-59b2-44a4-9b41-88eafb43b4c6\",        \"statusMsg\": \"Paperless billing updated successfully.\"    }}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        PaperlessBillingUIRequest request = mapper.readValue(requestString, PaperlessBillingUIRequest.class);
        PaperlessBillingUIResponse response = mapper.readValue(responseString, PaperlessBillingUIResponse.class);
        URI url = URI.create("http://localhost/enroll-paperlessBilling");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.paperlessBilling(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.enrollPaperlessBilling(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void paperlessBillingErrorTest2() throws IOException {
        String requestString = "{    \"meta\": {        \"timestamp\": \"2019-08-05T13:27:07Z\",        \"cxpCorrelationId\": \"3d5f3c15-aa3b-4a42-9245-5cb4177468e4\"    },        \"data\": {        \"cartId\": \"03019841-59b2-44a4-9b41-88eafb43b4c6\",        \"statusMsg\": \"Paperless billing updated successfully.\"    }}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        PaperlessBillingUIRequest request = mapper.readValue(requestString, PaperlessBillingUIRequest.class);
        PaperlessBillingUIResponse response = mapper.readValue(responseString, PaperlessBillingUIResponse.class);
        URI url = URI.create("http://localhost/enroll-paperlessBilling");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.valueOf(500));
        when(cartHelper.paperlessBilling(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.enrollPaperlessBilling(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateTradeinTypeTest() throws IOException {
        String requestString = "{    \"meta\": {        \"timestamp\": \"2019-08-05T13:27:07Z\",        \"cxpCorrelationId\": \"3d5f3c15-aa3b-4a42-9245-5cb4177468e4\"    },    \"errors\": [],    \"warnings\": [],    \"data\": {        \"cartId\": \"03019841-59b2-44a4-9b41-88eafb43b4c6\",        \"statusMsg\": \"Trade-in type updated successfully.\"    }}";
        String responseString = "{                        \"client\": \"CXP\",                       \"cartId\": \"bea202a6-42cb-40d4-ac87-d3f1db2b3f13\",                                \"intendType\": \"AAL\",                                \"tradeInType\": \"HOME\"        }";
        UpdateTradeinTypeUIRequest request = mapper.readValue(requestString, UpdateTradeinTypeUIRequest.class);
        UpdateTradeinTypeUIResponse response = mapper.readValue(responseString, UpdateTradeinTypeUIResponse.class);
        URI url = URI.create("http://localhost/tradeinType");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.updateTradeinType(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.updateTradeinType(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateTradeinTypeErrorTest() throws IOException {
        String requestString = "{    \"meta\": {        \"timestamp\": \"2019-08-05T13:27:07Z\",        \"cxpCorrelationId\": \"3d5f3c15-aa3b-4a42-9245-5cb4177468e4\"    },    \"errors\": [],    \"warnings\": [],    \"data\": {        \"cartId\": \"03019841-59b2-44a4-9b41-88eafb43b4c6\",        \"statusMsg\": \"Trade-in type updated successfully.\"    }}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        UpdateTradeinTypeUIRequest request = mapper.readValue(requestString, UpdateTradeinTypeUIRequest.class);
        UpdateTradeinTypeUIResponse response = mapper.readValue(responseString, UpdateTradeinTypeUIResponse.class);
        URI url = URI.create("http://localhost/tradeinType");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.valueOf(500));
        when(cartHelper.updateTradeinType(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.updateTradeinType(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateSellerPriceNewTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"processingMTN\": \"4235344191\",\"intendTpye\": \"XXX\"},\"data\": {\"itemType\": \"SELLERPRICE\",\"action\": \"UPDATE\",\"lines\": [{\"mtn\": \"4699199099\",\"sellerPrice\":\"4699199099\",\"mtn\": \"4699199098\",\"sellerPrice\":\"4699199099\"}]}}";
        String responseString ="{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"processAction\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"availablePaths\":[ { \"path\": \"AccessoryPDP\" } ]},\"customerInfo\":{\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\",\"accountNumber\":\"0820215913-00001\"},\"cartInfo\":{\"cartId\":\"2515813861\",\"statusCode\":\"0\",\"statusMsg\":\"Success\"},\"processMTNList\": [ { \"mtn\": \"2515813860\", \"completedprocessSteps\": [ \"MTNSelectionPage\", \"GridWallPDP\" ] },{ \"mtn\": \"2515813861\", \"completedprocessSteps\": [] } ]}}}}";
        UpdateSellerPriceUIRequestNew request = mapper.readValue(requestString, UpdateSellerPriceUIRequestNew.class);
        UpdateSellerPriceUIResponseNew response = mapper.readValue(responseString, UpdateSellerPriceUIResponseNew.class);
        URI url = URI.create("http://localhost/sellerPrice");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.updateSellerPriceNew(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.updateSellerPriceNew(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateSellerPriceNewForDigitalTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"processingMTN\":\"4235344191\",\"intendType\":\"NSE\"},\"data\":{\"itemType\":\"SELLERPRICE\",\"action\":\"UPDATE\"}}";
        String responseString ="{\"errors\":[{\"namespace\":\"CartService\",\"details\":[{\"field\":\"lineDetails\",\"value\":\"null/blank\",\"issue\":\"lineDetails is/are missing.\",\"location\":\"request\"}],\"id\":\"701\",\"name\":\" REQUEST VALIDATION ERROR\"}]}";
        UpdateSellerPriceUIRequestNew request = mapper.readValue(requestString, UpdateSellerPriceUIRequestNew.class);
        UpdateSellerPriceUIResponseNew response = mapper.readValue(responseString, UpdateSellerPriceUIResponseNew.class);
        URI url = URI.create("http://localhost/sellerPrice");
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("channelId", "Digital");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(httpHeaders).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.updateSellerPriceNew(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.updateSellerPriceNew(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateSellerPriceNewForNSEErrorTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"processingMTN\":\"4235344191\",\"intendType\":\"NSE\"},\"data\":{\"itemType\":\"SELLERPRICE\",\"action\":\"UPDATE\"}}";
        String responseString ="{\"errors\":[{\"namespace\":\"CartService\",\"details\":[{\"field\":\"lineDetails\",\"value\":\"null/blank\",\"issue\":\"lineDetails is/are missing.\",\"location\":\"request\"}],\"id\":\"701\",\"name\":\" REQUEST VALIDATION ERROR\"}]}";
        UpdateSellerPriceUIRequestNew request = mapper.readValue(requestString, UpdateSellerPriceUIRequestNew.class);
        UpdateSellerPriceUIResponseNew response = mapper.readValue(responseString, UpdateSellerPriceUIResponseNew.class);
        URI url = URI.create("http://localhost/sellerPrice");
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("channelId", "Digital");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(httpHeaders).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.valueOf(500));
        when(cartHelper.updateSellerPriceNew(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.updateSellerPriceNew(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceTest() throws IOException {
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);

        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper2.getDeviceId()).thenReturn(Mono.just("1234"));
        when(redisHelper2.getSimId()).thenReturn(Mono.just("1234"));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        String requestString = "{ \"cartInfo\": {\"fetchDataFromRedis\": false,  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\",  \"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/add-device");
        HttpCookie targetPricingOffer = new HttpCookie("targetPricingOffer", "true");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("targetPricingOffer", targetPricingOffer);
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.customerProfileDigital(Mockito.anyString()))
                .thenReturn(Mono.just(new CustomerProfileCXPResponse()));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceWithCookieTest() throws IOException {
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);

        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");

        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper2.getDeviceId()).thenReturn(Mono.just("1234"));
        when(redisHelper2.getSimId()).thenReturn(Mono.just("1234"));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));

        String requestString = "{ \"channelId\":\"VZW-DOTCOM\",\"cartInfo\": {\"fetchDataFromRedis\": false,  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\",  \"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": { \"rtm\":{\"url\":\"https://url.com\", \"image\":\"image.jpg\"}, \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/add-device");
        HttpCookie targetPricingOffer = new HttpCookie("targetPricingOffer", "true");
        HttpCookie cdlThrottleList = new HttpCookie("cdlThrottleList", "abandonCart");
        HttpCookie cdlCartInfo = new HttpCookie("cdlCartInfo", "cdlCartInfo");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("targetPricingOffer", targetPricingOffer);
        bodyMap.add("cdlThrottleList", cdlThrottleList);
        bodyMap.add("cdlCartInfo", cdlCartInfo);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("channelId", "VZW-DOTCOM");
        httpHeaders.add("digital_ig_session", "digital_ig_session");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookies(bodyMap).headers(httpHeaders).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        httpResponse.addCookie(ResponseCookie.from("cdlCartInfo","cdlCartInfo").build());
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","cdlThrottleList").build());
        when(cartHelper.customerProfileDigital(Mockito.anyString()))
                .thenReturn(Mono.just(new CustomerProfileCXPResponse()));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        httpResponse.setStatusCode(HttpStatus.PARTIAL_CONTENT);
        responseString = "{\"serviceHeader\": {\"clientId\": \"VZW-DOTCOM\",\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"Cases\": [],\"caseId\": \"SOP-329-E01\",\"contextInfo\": {\"pendingOrderAccountLevel\": \" \",\"callReason\": \"SalesOrderPurchase\",\"processStep\": \"MTNSelectionPage/ShoppingCart\",\"processAction\": \"\"},\"customerInfo\": {\"lookupMTN\": \" \",\"accountNumber\": \"0820215913-00001\"}}}},\"errors\": [{\"name\": \"CART_E911ADDRESS_BUSINESS_EXCEPTION\",\"id\": \"3226\",\"message\": \"Please enter a valid E911 service address\",\"severity\": \"High\",\"errorCategory\": \"BUSINESSERR\",\"category\": \"BUSINESS_ERR\"}]}";
        response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceWithCookieErrorTest() throws IOException {
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);

        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");

        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper2.getDeviceId()).thenReturn(Mono.just("1234"));
        when(redisHelper2.getSimId()).thenReturn(Mono.just("1234"));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));

        String requestString = "{ \"cartInfo\": {\"fetchDataFromRedis\": false,  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\",  \"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/add-device");
        HttpCookie targetPricingOffer = new HttpCookie("targetPricingOffer", "true");
        HttpCookie cdlThrottleList = new HttpCookie("cdlThrottleList", "abandonCart");
        HttpCookie cdlCartInfo = new HttpCookie("cdlCartInfo", "cdlCartInfo");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("targetPricingOffer", targetPricingOffer);
        bodyMap.add("cdlThrottleList", cdlThrottleList);
        bodyMap.add("cdlCartInfo", cdlCartInfo);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("channelId", "VZW-DOTCOM");
        httpHeaders.add("digital_ig_session", "digital_ig_session");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookies(bodyMap).headers(httpHeaders).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.customerProfileDigital(Mockito.anyString()))
                .thenReturn(Mono.just(new CustomerProfileCXPResponse()));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceWithoutProcessStepTest() throws IOException {
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);

        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");

        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper2.getDeviceId()).thenReturn(Mono.just("1234"));
        when(redisHelper2.getSimId()).thenReturn(Mono.just("1234"));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        doNothing().when(dlUtilityService).updateDlData("eup");
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));

        String requestString = "{ \"cartInfo\": {\"fetchDataFromRedis\": false,  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\",\"ecpdProfileId\":\"123\",  \"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/add-device");
        HttpCookie targetPricingOffer = new HttpCookie("targetPricingOffer", "true");
        HttpCookie cdlThrottleList = new HttpCookie("cdlThrottleList", "abandonCart");
        HttpCookie cdlCartInfo = new HttpCookie("cdlCartInfo", "cdlCartInfo");
        HttpCookie digital_ig_session = new HttpCookie("digital_ig_session", "digital_ig_session");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("targetPricingOffer", targetPricingOffer);
        bodyMap.add("cdlThrottleList", cdlThrottleList);
        bodyMap.add("cdlCartInfo", cdlCartInfo);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("channelId", "VZW-DOTCOM");
        httpHeaders.add("digital_ig_session", "digital_ig_session");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookies(bodyMap).headers(httpHeaders).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.customerProfileDigital(Mockito.anyString()))
                .thenReturn(Mono.just(new CustomerProfileCXPResponse()));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceBadRequestTest() throws IOException {
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);

        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        String requestString = "{ \"cartInfo\": { \"clientAppName\": \"VZW-NETACE\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"cartId\": \"4c4a9307-ebc1-4f51-a350-a6438b825dcb\", \"caseId\": \"SOP-659808-E01\", \"accountNumber\": \"0285560011-00001\", \"cartCreator\": \"2018702013\", \"processingMTN\": \"2018702013\", \"processStep\": \"MTNSelectionPage\", \"processAction\": \"AddDevice\", \"intendType\": \"EUP\", \"mtnFlow\": \"G/M\", \"fetchDataFromRedis\": true }, \"data\": { \"lines\": [ { \"mtn\": \"\", \"upgradeReasonCode\": \"EA\", \"device\": { \"id\": \"MQ732LL/A\", \"dppMonths\": 24 }, \"sim\": { \"id\": \"EMBD4GSIM-N\" }, \"addFeatures\": [ { \"id\": \"66332\", \"quantity\": 1, \"actionIndicator\": \"A\", \"type\": \"SFO\" } ], \"isKeepingExistingEqProtection\": \"\", \"ispuFlow\": false, \"newLineOrAAL\": false, \"isNewLine\": false, \"depletionLocationCode\": \"\", \"depletionType\": \"F\", \"sddZipCode\": \"\", \"sorId\": \"66332\", \"triggerPricingValidation\": true, \"preBackOrderDate\": \"01/30/2020\", \"preBackOrderDisplayType\": \"Ship by\" } ], \"clearCart\": true } }";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"200\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/add-device");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceConditionTest() throws IOException {
        String requestString = "{ \"cartInfo\": {\"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\",  \"cartId\": \"\",  \"caseId\": \"\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" ,\"mtnFlow\":\"G\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}, \"cartInfo\":{\"cartId\":\"4c4a9307-ebc1-4f51-a350-a6438b825dcb\"}}}}}";

        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("2059376950");
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);

        cartRedisData.setCartId("f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed");
        cartRedisData.setCaseId("SOP-TEST");
        cartRedisData.setLines(linesList);

        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/add-device");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        doNothing().when(dlUtilityService).updateDlData("eup");
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void removeBvoOffersTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"processingMTN\": \"4235344191\",\"intendTpye\": \"XXX\"},\"data\": {\"lines\": [{\"mtn\": \"4699199099\",\"removeOffers\":[{\"id\": \"2500009\",\"subType\": \"Multi Line BOGO\"}]},{\"mtn\": \"4699199098\",\"removeOffers\":[{\"id\": \"2580005\",\"subType\": \"Trade\"}]}]}}";
        String responseString ="{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"processAction\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"availablePaths\":[ { \"path\": \"AccessoryPDP\" } ]},\"customerInfo\":{\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\",\"accountNumber\":\"0820215913-00001\"},\"cartInfo\":{\"cartId\":\"2515813861\",\"statusCode\":\"0\",\"statusMsg\":\"Success\"},\"processMTNList\": [ { \"mtn\": \"2515813860\", \"completedprocessSteps\": [ \"MTNSelectionPage\", \"GridWallPDP\" ] },{ \"mtn\": \"2515813861\", \"completedprocessSteps\": [] } ]}}}}";
        UpdateBvoOffersUIRequest request = mapper.readValue(requestString, UpdateBvoOffersUIRequest.class);
        UpdateBvoOffersUIResponse response = mapper.readValue(responseString,
                UpdateBvoOffersUIResponse.class);
        URI url = URI.create("http://localhost/removeOffers");
        HttpHeaders headers = new HttpHeaders();
        headers.add("channelId", "channelId");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.removeBvoOffers(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.removeBvoOffers(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void removeBvoOffersErrorTest() throws IOException {
        String requestString ="{\"cartInfo\":{\"processingMTN\": \"4235344191\",\"intendTpye\": \"XXX\"},\"data\": {\"lines\": [{\"mtn\": \"4699199099\",\"removeOffers\":[{\"id\": \"2500009\",\"subType\": \"Multi Line BOGO\"}]},{\"mtn\": \"4699199098\",\"removeOffers\":[{\"id\": \"2580005\",\"subType\": \"Trade\"}]}]}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        UpdateBvoOffersUIRequest request = mapper.readValue(requestString, UpdateBvoOffersUIRequest.class);
        UpdateBvoOffersUIResponse response = mapper.readValue(responseString,
                UpdateBvoOffersUIResponse.class);
        URI url = URI.create("http://localhost/removeOffers");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.removeBvoOffers(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.removeBvoOffers(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void removeBvoOffersErrorTest2() throws IOException {
        String requestString ="{\"cartInfo\":{\"processingMTN\": \"4235344191\",\"intendTpye\": \"XXX\"},\"data\": {\"lines\": [{\"mtn\": \"4699199099\",\"removeOffers\":[{\"id\": \"2500009\",\"subType\": \"Multi Line BOGO\"}]},{\"mtn\": \"4699199098\",\"removeOffers\":[{\"id\": \"2580005\",\"subType\": \"Trade\"}]}]}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        UpdateBvoOffersUIRequest request = mapper.readValue(requestString, UpdateBvoOffersUIRequest.class);
        UpdateBvoOffersUIResponse response = mapper.readValue(responseString,
                UpdateBvoOffersUIResponse.class);
        URI url = URI.create("http://localhost/removeOffers");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.valueOf(500));
        when(cartHelper.removeBvoOffers(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.removeBvoOffers(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }



    @Test
    public void addDeviceErrorTest() throws IOException {
        String requestString = "{ \"cartInfo\": { \"fetchDataFromRedis\": false, \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-ECOM\",  \"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"7169849755\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": {  \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/add-device");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void addAccessoryTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"0087b843-916e-496b-a527-2eef5c214145\",\"caseId\":\"SOP-771202-E01\",\"accountNumber\":\"0224658054-00001\",\"cartCreator\":\"5079514037\",\"processingMTN\":\"7154310985\",\"processAction\":\"\",\"processStep\":\"AccessoryPDP\",\"intendType\":\"EUP\",\"pageId\":\"PROTECTION\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"5079514037\",\"mdnFilterValue\":\"7154310985\",\"addAccessories\":[],\"ispuFlow\":false,\"depletionLocation\":null}]}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGAgeneratedmessage\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}],\"cartInfo\":{\"cartId\":\"69a66ef4d-7e344dfb-2db299209-ea8333\",\"lines\":[{\"mtn\":\"3014674968\",\"status\":1,\"errors\":null,\"addAccessories\":[{\"id\":\"CM031409\",\"finalPrice\":\"7.49\",\"itemPrice\":\"9.99\",\"discountAmount\":\"2.50\",\"qty\":1,\"status\":0,\"depletionType\":\"F\",\"discounts\":[]}]}]},\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"ShoppingCart\",\"availablePaths\":[{\"path\":\"ShoppingCart`\"}],\"callReason\":\"SalesOrderPurchase\"}}}}}";
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/add-accessories");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","cdlThrottleList").build());
        when(accHelper.addAccessory(any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put("cartCount","1");
        redisData.put("cartOrderFlowType","eup");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(true);
        Mono<ResponseEntity<GenericResponse>> controllerResponse1 = cartController3.addAccessory(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse1).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addAccessoryTest1() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"0087b843-916e-496b-a527-2eef5c214145\",\"caseId\":\"SOP-771202-E01\",\"accountNumber\":\"0224658054-00001\",\"cartCreator\":\"5079514037\",\"processingMTN\":\"7154310985\",\"processAction\":\"\",\"processStep\":\"AccessoryPDP\",\"intendType\":\"EUP\",\"pageId\":\"PROTECTION\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"5079514037\",\"mdnFilterValue\":\"7154310985\",\"addAccessories\":[],\"ispuFlow\":false,\"depletionLocation\":null}]}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGAgeneratedmessage\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}],\"cartInfo\":{\"cartId\":\"69a66ef4d-7e344dfb-2db299209-ea8333\",\"lines\":[{\"mtn\":\"3014674968\",\"status\":1,\"errors\":null,\"addAccessories\":[{\"id\":\"CM031409\",\"finalPrice\":\"7.49\",\"itemPrice\":\"9.99\",\"discountAmount\":\"2.50\",\"qty\":1,\"status\":0,\"depletionType\":\"F\",\"discounts\":[]}]}]},\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"ShoppingCart\",\"availablePaths\":[{\"path\":\"ShoppingCart`\"}],\"callReason\":\"SalesOrderPurchase\"}}}}}";
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/add-accessories");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","cdlThrottleList").build());
        when(accHelper.addAccessory(any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put("cartCount","1");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(true);
        Mono<ResponseEntity<GenericResponse>> controllerResponse1 = cartController3.addAccessory(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse1).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addAccessoryTest2() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"0087b843-916e-496b-a527-2eef5c214145\",\"caseId\":\"SOP-771202-E01\",\"accountNumber\":\"0224658054-00001\",\"cartCreator\":\"5079514037\",\"processingMTN\":\"7154310985\",\"processAction\":\"\",\"processStep\":\"AccessoryPDP\",\"intendType\":\"EUP\",\"pageId\":\"PROTECTION\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"5079514037\",\"mdnFilterValue\":\"7154310985\",\"addAccessories\":[],\"ispuFlow\":false,\"depletionLocation\":null}]}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGAgeneratedmessage\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}],\"cartInfo\":{\"cartId\":\"69a66ef4d-7e344dfb-2db299209-ea8333\",\"lines\":[{\"mtn\":\"3014674968\",\"status\":1,\"errors\":null,\"addAccessories\":[{\"id\":\"CM031409\",\"finalPrice\":\"7.49\",\"itemPrice\":\"9.99\",\"discountAmount\":\"2.50\",\"qty\":1,\"status\":0,\"depletionType\":\"F\",\"discounts\":[]}]}]},\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"ShoppingCart\",\"availablePaths\":[{\"path\":\"ShoppingCart`\"}],\"callReason\":\"SalesOrderPurchase\"}}}}}";
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/add-accessories");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","cdlThrottleList").build());
        when(accHelper.addAccessory(any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(true);
        Mono<ResponseEntity<GenericResponse>> controllerResponse1 = cartController3.addAccessory(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse1).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addAccessoryTest3() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"0087b843-916e-496b-a527-2eef5c214145\",\"caseId\":\"SOP-771202-E01\",\"accountNumber\":\"0224658054-00001\",\"cartCreator\":\"5079514037\",\"processingMTN\":\"7154310985\",\"processAction\":\"\",\"processStep\":\"AccessoryPDP\",\"intendType\":\"EUP\",\"pageId\":\"PROTECTION\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"5079514037\",\"mdnFilterValue\":\"7154310985\",\"addAccessories\":[],\"ispuFlow\":false,\"depletionLocation\":null}]}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGAgeneratedmessage\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}],\"cartInfo\":{\"cartId\":\"69a66ef4d-7e344dfb-2db299209-ea8333\",\"lines\":[{\"mtn\":\"3014674968\",\"status\":1,\"errors\":null,\"addAccessories\":[{\"id\":\"CM031409\",\"finalPrice\":\"7.49\",\"itemPrice\":\"9.99\",\"discountAmount\":\"2.50\",\"qty\":1,\"status\":0,\"depletionType\":\"F\",\"discounts\":[]}]}]},\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"ShoppingCart\",\"availablePaths\":[{\"path\":\"ShoppingCart`\"}],\"callReason\":\"SalesOrderPurchase\"}}}}}";
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/add-accessories");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","cdlThrottleList").build());
        when(accHelper.addAccessory(any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put("cartCount","1");
        redisData.put("cartOrderFlowType","");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(true);
        Mono<ResponseEntity<GenericResponse>> controllerResponse1 = cartController3.addAccessory(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse1).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addAccessoryTest4() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"0087b843-916e-496b-a527-2eef5c214145\",\"caseId\":\"SOP-771202-E01\",\"accountNumber\":\"0224658054-00001\",\"cartCreator\":\"5079514037\",\"processingMTN\":\"7154310985\",\"processAction\":\"\",\"processStep\":\"AccessoryPDP\",\"intendType\":\"EUP\",\"pageId\":\"PROTECTION\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"5079514037\",\"mdnFilterValue\":\"7154310985\",\"addAccessories\":[],\"ispuFlow\":false,\"depletionLocation\":null}]}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGAgeneratedmessage\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}],\"cartInfo\":{\"cartId\":\"69a66ef4d-7e344dfb-2db299209-ea8333\",\"lines\":[{\"mtn\":\"3014674968\",\"status\":1,\"errors\":null,\"addAccessories\":[{\"id\":\"CM031409\",\"finalPrice\":\"7.49\",\"itemPrice\":\"9.99\",\"discountAmount\":\"2.50\",\"qty\":1,\"status\":0,\"depletionType\":\"F\",\"discounts\":[]}]}]},\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"ShoppingCart\",\"availablePaths\":[{\"path\":\"ShoppingCart`\"}],\"callReason\":\"SalesOrderPurchase\"}}}}}";
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/add-accessories");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","cdlThrottleList").build());
        when(accHelper.addAccessory(any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put("cartCount","1");
        redisData.put("cartOrderFlowType",null);
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(true);
        Mono<ResponseEntity<GenericResponse>> controllerResponse1 = cartController3.addAccessory(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse1).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void isNAOExistInCartFlowTypeTest(){
        String cartOrderFlowType ="";
        boolean val = cartController3.isNAOExistInCartFlowType(cartOrderFlowType);
        assertFalse(val);
    }

    @Test
    public void addAccessoryTestForNSE() throws IOException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM\",\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"accountNumber\":\"\",\"cartId\":\"\",\"caseId\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"9999999999\",\"processAction\":\"addAccessoryRecommendations\",\"processStep\":\"AccessoryPDP\",\"intendType\":\"NSEACC\",\"pageId\":\"GW\",\"intent\":\"StandAloneAccessory\",\"cradleFlowJourney\":\"AccessoryInterestialProspect\"},\"data\":{\"rtm\":{\"url\":\"https://vzwqa3.verizonwireless.com/smartphones/apple-iphone-11-pro-max/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/iphone-11-pro-max-space-gray?fmt=pjpg\",\"name\":\"iPhone 11 Pro Max\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://vzwqa3.verizonwireless.com/smartphones/apple-iphone-11-pro-max/\"},\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"9999999999\",\"mdnFilterValue\":\"9999999999\",\"addAccessories\":[{\"id\":\"77-62812\",\"qty\":1,\"isSoftSku\":false,\"accessoryBundle\":false,\"accessorySkuID\":\"sku3611092\",\"displayName\":\"OtterBox Symmetry Clear Series Case for iPhone 11\",\"imgUrl\":\"https://ss72.vzw.com/is/image/VerizonWireless/otterbox-symmetry-clear-series-case-butter-stardust-silver-flake-clear-77-62812-iset\",\"color\":\"Stardust\",\"price\":\"49.99\"}],\"ispuFlow\":false,\"depletionLocationCode\":null}]}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.05.16.06.36.40-295.69766922148386\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-efb5ec9d-0fbd-4053-9ce0-2ef984d66080\",\"processingMTN\":\"9999999999\",\"registerNumber\":0,\"existingCase\":\"\",\"globalId\":\"POE-D-efb5ec9d-0fbd-4053-9ce0-2ef984d66080\"},\"cartInfo\":{\"cartItemCount\":1,\"cartId\":\"e8567a49-223d-45fc-b155-8f9c24f81d69\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"accessories\":{},\"status\":1,\"mtn\":\"9999999999\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false},\"processMTNList\":[{\"mtn\":\"9999999999\",\"completedprocessSteps\":[]}]}}}}";
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/nse/add-accessories");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","cdlThrottleList").build());
        when(accHelper.addAccessory(any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(any(),eq( "accessory"))).thenReturn(Mono.just(true));
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        doNothing().when(dlUtilityService).updateDlData("nao");
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put("cartCount","1");
        redisData.put("cartOrderFlowType","eup");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addAccessoryErrorTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"0087b843-916e-496b-a527-2eef5c214145\",\"caseId\":\"SOP-771202-E01\",\"accountNumber\":\"0224658054-00001\",\"cartCreator\":\"5079514037\",\"processingMTN\":\"7154310985\",\"processAction\":\"\",\"processStep\":\"AccessoryPDP\",\"intendType\":\"EUP\",\"pageId\":\"PROTECTION\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"5079514037\",\"mdnFilterValue\":\"7154310985\",\"addAccessories\":[],\"ispuFlow\":false,\"depletionLocation\":null}]}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/add-accessories");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(accHelper.addAccessory(any())).thenReturn(Mono.just(response));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put("cartCount","1");
        redisData.put("cartOrderFlowType","eup");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void addPlanTest() throws IOException {
        String requestString = "{\"channelId\":\"OMNI-TELESALES\",\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"4aa9765a-917b-4804-bcf5-75f7c2d49620\",\"caseId\":\"SOP-607536-E01\",\"accountNumber\":\"0825637535-00001\",\"cartCreator\":\"9106517716\",\"processingMTN\":\"9106517716\",\"processStep\":\"PlanSelection\",\"intendType\":\"CPC\"},\"data\":{\"lines\":[{\"mtn\":\"9106359416\",\"plan\":{\"id\":\"18045\"}}]}}";
        String responseString = "{\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \"SOP-334914702-W01\",\"contextInfo\": {\"callReason\": \"SalesOrderPurchase\",\"processStep\": \"ShoppingCart\",\"processAction\": \"\",\"availablePaths\": [{\"path\": \"ShoppingCart\"}]},\"customerInfo\": {\"accountNumber\": \"0789166749-00001\",\"cartCreator\": \"8125825035\",\"processingMTN\": \"8125825035\",\"registerNumber\": 0},\"cartInfo\": {\"tabletJetpackDiscountMultiLineLoss\": \"N\",\"cartItemCount\": 0,\"cartId\": \"ff70cbb7-096d-4580-8f9c-8206250ab95a\",\"statusMsg\": \"Success\",\"statusCode\": \"1\",\"lines\": [{\"plan\": {\"id\": \"39385\",\"price\": \"80.00\",\"isRecommendedPlan\": false},\"status\": 1,\"isFreeAppleMusicLoss\": \"N\",\"spos\": [{\"id\": \"671\",\"actionIndicator\": \"D\",\"success\": true,\"description\": \"Carryover Data\",\"is5GBolt\": false},{\"id\": \"672\",\"actionIndicator\": \"D\",\"success\": true,\"description\": \"Safety Mode\",\"is5GBolt\": false},{\"id\": \"975\",\"actionIndicator\": \"D\",\"success\": true,\"description\": \"AutoPay and Paper-Free Discount\",\"is5GBolt\": false},{\"id\": \"1708\",\"actionIndicator\": \"Z\",\"success\": true,\"description\": \"COVID IMPACTED INDICATOR\",\"is5GBolt\": false},{\"id\": \"1247\",\"actionIndicator\": \"A\",\"success\": true,\"description\": \"Auto Pay / Paper-free Discount Included\",\"is5GBolt\": false},{\"id\": \"1678\",\"actionIndicator\": \"A\",\"success\": true,\"description\": \"$10 Teachers Discount\",\"is5GBolt\": false},{\"id\": \"1747\",\"actionIndicator\": \"A\",\"success\": true,\"description\": \"Disney Bundle Included with Plan\",\"is5GBolt\": false},{\"id\": \"1802\",\"actionIndicator\": \"D\",\"success\": true,\"description\": \"Metered Plan Indicator\",\"is5GBolt\": false},{\"id\": \"1692\",\"actionIndicator\": \"Z\",\"success\": true,\"description\": \"5G Dynamic Spectrum Sharing\",\"is5GBolt\": false},{\"id\": \"732\",\"actionIndicator\": \"A\",\"success\": true,\"description\": \"CDMA-LESS ROAM TIER OVERRIDE\",\"is5GBolt\": false},{\"id\": \"1256\",\"actionIndicator\": \"A\",\"success\": true,\"description\": \"Includes Mexico & Canada with your domestic plan\",\"is5GBolt\": false},{\"id\": \"1552\",\"actionIndicator\": \"A\",\"success\": true,\"description\": \"5G Ultra Wideband Access\",\"is5GBolt\": false},{\"id\": \"1578\",\"actionIndicator\": \"A\",\"success\": true,\"description\": \"5G Ultra Wideband Trigger\",\"is5GBolt\": false},{\"id\": \"1741\",\"actionIndicator\": \"A\",\"success\": true,\"description\": \"5G Ultra Wideband Provisioning\",\"is5GBolt\": false},{\"id\": \"1801\",\"actionIndicator\": \"A\",\"success\": true,\"description\": \"Unlimited Plan Indicator\",\"is5GBolt\": false},{\"id\": \"1958\",\"actionIndicator\": \"A\",\"success\": true,\"description\": \"Device Set-Up Support 60 Days\",\"is5GBolt\": false}],\"sfos\": [{\"id\": \"48526\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Text Messaging Pay Per Message\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"48553\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Streamlined Billing\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"66332\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"Y\",\"description\": \"Decline Device Protection\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"68869\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Caller ID\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"68870\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"BUSY TRANSFER\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"68871\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Conference Calling\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"68872\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"CALL DELIVERY\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"68873\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Call Waiting\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"68874\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"No Answer / Busy Transfer\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"68876\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Call Forwarding\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"73502\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"Unlimited Picture and Video Messaging\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"73503\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"Unlimited Text Messages\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"74774\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"SDM REMOTE QUERY ENABLED\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"75440\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Block Web Purchases\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"75632\",\"actionIndicator\": \"D\",\"customerAddedInd\": \"N\",\"description\": \"Data Usage USA & Canada\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"75706\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Pay Per Message\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"75802\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Dynamic-Private IP\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"75836\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"4G INTERNET ACCESS\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"75837\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"4G APPLICATION ACCESS\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"76152\",\"actionIndicator\": \"D\",\"customerAddedInd\": \"N\",\"description\": \"PICTURE MESSAGE PROVISIONING\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"76404\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"4G Mobile Hotspot Provisioning\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"76600\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"SHARE NAME ID\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"77249\",\"actionIndicator\": \"D\",\"customerAddedInd\": \"N\",\"description\": \"MOBILE HOT SPOT TRIGGER $0\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"77556\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"4G PROVISIONING $0\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"77568\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"EMAIL ACCESS PDA $0\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"77581\",\"actionIndicator\": \"D\",\"customerAddedInd\": \"N\",\"description\": \"EMAIL TRIGGER ALP $0\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"77583\",\"actionIndicator\": \"D\",\"customerAddedInd\": \"N\",\"description\": \"DATA PROVISION ALP\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"77885\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Integrated Messaging\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"78706\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"ENHANCED ADDRESS BOOK\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"78707\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Video Calling\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"78734\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Premium Visual Voice Mail with Voice Mail to Text\",\"price\": \"2.99\",\"displayHumWiFi\": false},{\"id\": \"80148\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"International Messages While in US\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"81158\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"HD Voice\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"82417\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Integrated Calling\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"82419\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Access Wi-fi Calling\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"83439\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Call Filter Plus\",\"price\": \"2.99\",\"displayHumWiFi\": false},{\"id\": \"83856\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"CDMA-LESS DEVICE PROVISIONING\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"84015\",\"actionIndicator\": \"D\",\"customerAddedInd\": \"N\",\"description\": \"Smartphone - Line Access\",\"price\": \"20.00\",\"displayHumWiFi\": false},{\"id\": \"84071\",\"actionIndicator\": \"D\",\"customerAddedInd\": \"N\",\"description\": \"RTR for Carryover Data\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"84076\",\"actionIndicator\": \"D\",\"customerAddedInd\": \"N\",\"description\": \"Provision Entitlement Services\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"84077\",\"actionIndicator\": \"D\",\"customerAddedInd\": \"N\",\"description\": \"RTR Service Trigger\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"84094\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"International Services Enabled Lite\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"85405\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"Entitlement for Unlimited\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"85553\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"Verizon Cloud Eligible\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"86189\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"Email and Web\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"86198\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"Mobile Hotspot 15GB\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"86209\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"Include Mexico & Canada in your domestic plan\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"86225\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"AUTO CONFIGURATION $0\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"86848\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"4G SERVICE ON 5G DEVICE\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"86905\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"GSM Roaming Priority\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"87953\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"RTR / UC Trigger Play More\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"87956\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"RTR Play More Unlimited\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"87959\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"Entitlement Trigger\",\"price\": \"0.00\",\"displayHumWiFi\": false}],\"pairingInfo\": {},\"featureMessages\": [{\"name\": \"VERIZON_CLOUD_DISCOUNT\",\"action\": \"ADD\"},{\"name\": \"5GUWBBOLT\",\"action\": \"ADD\"}],\"firstMonthInstallment\": 40.28,\"monthlyInstallment\": 39.99,\"tabletJetpackDiscountLoss\": \"N\",\"reasonCode\": \"PLAN_DEVICE_COMPATIBLE\",\"mtn\": \"8125825035\",\"devicePlanCompatible\": true,\"planValidationFailed\": false,\"currentPlanType\": \"LLP\",\"planQualifiedForPromotion\": false,\"fiveGUpSell\": false,\"is5GBoltEligible\": false,\"disqualifiedPropositions\": [],\"qualifiedPropositions\": [],\"fiveGPlanAdded\": true,\"editSim\": false,\"lineWithSkipMDN\": false,\"inWithVerizonOpted\": false,\"protectionNotRequired\": false}],\"expressCheckout\": false,\"effectiveDateDetails\": {\"isOnDemandAllowed\": false,\"isBackDateAllowed\": true,\"isFutureDateAllowed\": true,\"suggestedBackDate\": \"11/12/2021\",\"suggestedFutureDate\": \"12/12/2021\",\"currentBillCycleBeginDate\": \"11/12/2021\",\"nextBillCycleBeginDate\": \"12/12/2021\",\"onDemandDate\": \"\",\"onDemandRangeInDays\": \"45\"},\"autoPayEnrollmentDetails\": {\"isAutoPayEnrolled\": \"Y\",\"isPaperLessEnrolled\": \"Y\",\"isAutoPayPaperLessDiscountEligible\": \"N\"},\"planChangeWarningMessages\": [{\"warningMessageCode\": \"ECPD_DISCOUNT_NOT_CARRY_OVER_KEY\"},{\"warningMessageCode\": \"FIVEG_PLAN_CHANGE_WARNING\",\"warningMessage\": \"WARNING - This change will disconnect active voice and data sessions. Before processing, ensure that you address all concerns first. Advise the customer to power cycle their device(s) after the change to enjoy the benefits of their new plan.\"}],\"discountPromoTotal\": 0.0,\"registerNumber\": 0,\"protectionNotRequired\": false},\"processMTNList\": [{\"mtn\": \"8125825035\",\"completedprocessSteps\": [\"MTNSelectionPage\",\"GridWallPDP\",\"PlanSelection\"]}]}}},\"serviceHeader\": {\"clientId\": \"CHAT-STORE\",\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"soe-cart-2021.11.12.05.37.20-328.4184785081927\"}}";
        AddPlanUIRequest request = mapper.readValue(requestString, AddPlanUIRequest.class);
        AddPlanUIResponse response = mapper.readValue(responseString, AddPlanUIResponse.class);
        URI url = URI.create("http://localhost/add-plan");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-TELESALES").build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.addPlan(any())).thenReturn(Mono.just(response));
        when(redisHelper2.updateCartOrderFlowType("cpc")).thenReturn(Mono.just(true));
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just("eup"));
        when(redisHelper2.getPlanPathDetails()).thenReturn(Mono.just(new HashMap()));
        when(redisHelper.updateSPOsIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addPlan(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addPlanBadRequestTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"4aa9765a-917b-4804-bcf5-75f7c2d49620\",\"caseId\":\"SOP-607536-E01\",\"accountNumber\":\"0825637535-00001\",\"cartCreator\":\"9106517716\",\"processingMTN\":\"9106517716\",\"processStep\":\"PlanSelection\",\"intendType\":\"CPC\"},\"data\":{\"lines\":[{}]}}";
        AddPlanUIRequest request = mapper.readValue(requestString, AddPlanUIRequest.class);
        URI url = URI.create("http://localhost/add-plan");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addPlan(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addPlanErrorTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f8618cba-1cad-4cc2-890a-61ea617b632a\",\"caseId\":\"SOP-8132-E01\",\"accountNumber\":\"0222082898-00001\",\"cartCreator\":\"9793190402\",\"processingMTN\":\"newLine1\",\"processStep\":\"PlanSelection\",\"intendType\":\"AAL\"},\"data\":{\"lines\":[{\"mtn\":\"newLine1\",\"plan\":{\"id\":\"18045\"}}]}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        AddPlanUIRequest request = mapper.readValue(requestString, AddPlanUIRequest.class);
        AddPlanUIResponse response = mapper.readValue(responseString, AddPlanUIResponse.class);
        URI url = URI.create("http://localhost/add-plan");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        when(cartHelper.addPlan(any())).thenReturn(Mono.just(response));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addPlan(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void pastDuesTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"pastDueAccepted\":\"Y\",\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"pastdue\":{\"amount\":\"140.25\"},\"effectiveDate\":\"09/26/2019\",\"Cart\":\"cart\"}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGA generated message\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"exceptions\":[{\"system\":\"CXP\",\"service\":\"validateCart\",\"type\":\"Error\",\"code\":\"E1223\",\"message\":\"Account validation failed\"},{\"system\":\"CXP\",\"service\":\"addToCartService\",\"type\":\"Warning\",\"code\":\"E1223\",\"message\":\"Account validation failed\"}],\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SAP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2324223422\"},\"cartInfo\":{\"cartId\":\"a705f835-c61a-4e20-b616-0c9839202a15\",\"statusCode\":\"1\",\"statusMsg\":\"\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[]},{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}],\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"MTNSelectionPage\",\"availablePaths\":[{\"path\":\"MTNSelectionPage\"},{\"path\":\"PendingOrder\"}],\"callReason\":\"SalesOrderPurchase\",\"pastDueBalance\":false,\"pendingOrderAccountLevel\":true,\"pendingOrderMTNList\":[{\"mtn\":\"8282899487\"},{\"mtn\":\"8282899487\"}]}}}}}";
        PastDuesUIRequest request = mapper.readValue(requestString, PastDuesUIRequest.class);
        PastDuesUIResponse response = mapper.readValue(responseString, PastDuesUIResponse.class);
        URI url = URI.create("http://localhost/past-dues");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.pastDues(any())).thenReturn(Mono.just(response));
        when(redisHelper3.updatePastDueDataInRedis(any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.pastDues(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void pastDuesTest1() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"pastdue\":{},\"effectiveDate\":\"09/26/2019\",\"Cart\":\"cart\"}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGA generated message\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SAP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2324223422\"},\"cartInfo\":{\"cartId\":\"a705f835-c61a-4e20-b616-0c9839202a15\",\"statusCode\":\"1\",\"statusMsg\":\"\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[]},{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}],\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"MTNSelectionPage\",\"availablePaths\":[{\"path\":\"MTNSelectionPage\"},{\"path\":\"PendingOrder\"}],\"callReason\":\"SalesOrderPurchase\",\"pastDueBalance\":false,\"pendingOrderAccountLevel\":true,\"pendingOrderMTNList\":[{\"mtn\":\"8282899487\"},{\"mtn\":\"8282899487\"}]}}}}}";
        PastDuesUIRequest request = mapper.readValue(requestString, PastDuesUIRequest.class);
        PastDuesUIResponse response = mapper.readValue(responseString, PastDuesUIResponse.class);
        URI url = URI.create("http://localhost/past-dues");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.pastDues(any())).thenReturn(Mono.just(response));
        when(redisHelper3.updatePastDueDataInRedis(any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.pastDues(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void pastDuesTest2() throws IOException {
        String requestString = "{\"data\":{\"effectiveDate\":\"09/26/2019\",\"Cart\":\"cart\"}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGA generated message\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"exceptions\":[{\"system\":\"CXP\",\"service\":\"validateCart\",\"type\":\"Error\",\"code\":\"E1223\",\"message\":\"Account validation failed\"},{\"system\":\"CXP\",\"service\":\"addToCartService\",\"type\":\"Warning\",\"code\":\"E1223\",\"message\":\"Account validation failed\"}],\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SAP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2324223422\"},\"cartInfo\":{\"cartId\":\"a705f835-c61a-4e20-b616-0c9839202a15\",\"statusCode\":\"1\",\"statusMsg\":\"\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[]},{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}],\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"MTNSelectionPage\",\"availablePaths\":[{\"path\":\"MTNSelectionPage\"},{\"path\":\"PendingOrder\"}],\"callReason\":\"SalesOrderPurchase\",\"pastDueBalance\":false,\"pendingOrderAccountLevel\":true,\"pendingOrderMTNList\":[{\"mtn\":\"8282899487\"},{\"mtn\":\"8282899487\"}]}}}}}";
        PastDuesUIRequest request = mapper.readValue(requestString, PastDuesUIRequest.class);
        PastDuesUIResponse response = mapper.readValue(responseString, PastDuesUIResponse.class);
        URI url = URI.create("http://localhost/past-dues");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.pastDues(any())).thenReturn(Mono.just(response));
        when(redisHelper3.updatePastDueDataInRedis(any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.pastDues(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void pastDuesTest3() throws IOException {
        String requestString = "{\"data\":{\"effectiveDate\":\"09/26/2019\",\"Cart\":\"cart\"}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGA generated message\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"exceptions\":[{\"system\":\"CXP\",\"service\":\"validateCart\",\"type\":\"Error\",\"code\":\"E1223\",\"message\":\"Account validation failed\"},{\"system\":\"CXP\",\"service\":\"addToCartService\",\"type\":\"Warning\",\"code\":\"E1223\",\"message\":\"Account validation failed\"}],\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SAP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2324223422\"},\"cartInfo\":{\"cartId\":\"a705f835-c61a-4e20-b616-0c9839202a15\",\"statusCode\":\"1\",\"statusMsg\":\"\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[]},{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}],\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"MTNSelectionPage\",\"availablePaths\":[{\"path\":\"MTNSelectionPage\"},{\"path\":\"PendingOrder\"}],\"callReason\":\"SalesOrderPurchase\",\"pastDueBalance\":false,\"pendingOrderAccountLevel\":true,\"pendingOrderMTNList\":[{\"mtn\":\"8282899487\"},{\"mtn\":\"8282899487\"}]}}}}}";
        PastDuesUIRequest request = mapper.readValue(requestString, PastDuesUIRequest.class);
        PastDuesUIResponse response = mapper.readValue(responseString, PastDuesUIResponse.class);
        URI url = URI.create("http://localhost/past-dues");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.pastDues(any())).thenReturn(Mono.just(response));
        when(redisHelper3.updatePastDueDataInRedis(any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.pastDues(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void pastDuesTest4() throws IOException {
        String requestString = "{\"cartInfo\":{\"pastDueAccepted\":\"Y\",\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"pastdue\":{\"amount\":\"140.25\"},\"effectiveDate\":\"09/26/2019\",\"Cart\":\"cart\"}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGA generated message\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"exceptions\":[{\"system\":\"CXP\",\"service\":\"validateCart\",\"type\":\"Error\",\"code\":\"E1223\",\"message\":\"Account validation failed\"},{\"system\":\"CXP\",\"service\":\"addToCartService\",\"type\":\"Warning\",\"code\":\"E1223\",\"message\":\"Account validation failed\"}],\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SAP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2324223422\"},\"cartInfo\":{\"cartId\":\"a705f835-c61a-4e20-b616-0c9839202a15\",\"statusCode\":\"1\",\"statusMsg\":\"\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[]},{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}],\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"MTNSelectionPage\",\"availablePaths\":[{\"path\":\"MTNSelectionPage\"},{\"path\":\"PendingOrder\"}],\"callReason\":\"SalesOrderPurchase\",\"pastDueBalance\":false,\"pendingOrderAccountLevel\":true,\"pendingOrderMTNList\":[{\"mtn\":\"8282899487\"},{\"mtn\":\"8282899487\"}]}}}}}";
        PastDuesUIRequest request = mapper.readValue(requestString, PastDuesUIRequest.class);
        PastDuesUIResponse response = mapper.readValue(responseString, PastDuesUIResponse.class);
        URI url = URI.create("http://localhost/past-dues");
        MockServerHttpRequest hr = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZWs").build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.pastDues(any())).thenReturn(Mono.just(response));
        when(cartHelper.checkForBYODANDPastDueFlag(request)).thenReturn(true);
        PastDueRedisData data = new PastDueRedisData();
        data.setAmount("100");
        request.getCartInfo().setIntendType(CartConstants.BYOD);
        when(featureFlagHelper.isPastDueBYODFFlag()).thenReturn(Boolean.TRUE);
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setPastDueRedisData(new PastDueRedisData());
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper3.updatePastDueDataInRedis(any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> cr = cartController3.pastDues(hr, null,
                request);
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-DOTCOM").build();
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.pastDues(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(Assert::assertNotNull).expectComplete()
                .verify();
        when(cartHelper.checkForBYODANDPastDueFlag(request)).thenReturn(false);
        cartController3.pastDues(httpHeader, null,
                request);
        when(cartHelper.checkForBYODANDPastDueFlag(request)).thenReturn(true);
        request.setData(null);
        cartController3.pastDues(httpHeader, null,
                request);
        request.setData(new PastDuesData());
        cartController3.pastDues(httpHeader, null,
                request);
        request.getData().setPastdue(new PastDue());
        cartController3.pastDues(httpHeader, null,
                request);
        request.getData().getPastdue().setAmount(null);
        cartController3.pastDues(httpHeader, null,
                request);
        request.getData().getPastdue().setAmount("250");
        cartController3.pastDues(httpHeader, null,
                request);

    }

    @Test
    public void pastDuesBadRequestTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"pastdue\":{},\"effectiveDate\":\"09/26/2019\",\"Cart\":\"cart\"}}";
        PastDuesUIRequest request = mapper.readValue(requestString, PastDuesUIRequest.class);
        URI url = URI.create("http://localhost/past-dues");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.pastDues(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void pastDuesErrorTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"pastdue\":{\"amount\":140.25},\"effectiveDate\":\"09/26/2019\",\"Cart\":\"cart\"}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        PastDuesUIRequest request = mapper.readValue(requestString, PastDuesUIRequest.class);
        PastDuesUIResponse response = mapper.readValue(responseString, PastDuesUIResponse.class);
        URI url = URI.create("http://localhost/past-dues");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.valueOf(500));
        when(cartHelper.pastDues(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.pastDues(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addFeaturesTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"ca7608de-6c65-4b6b-85e1-a2904fdb86a2\",\"caseId\":\"SOP-639240-E01\",\"accountNumber\":\"0322638103-00001\",\"cartCreator\":\"8643319007\",\"processingMTN\":\"8643858663\",\"intendType\":\"EUP\",\"processStep\":\"FeaturesPDP\"},\"data\":{\"account\":null,\"lines\":[{\"mtn\":\"8643858663\",\"features\":{\"add\":[{\"id\":\"66332\",\"actionIndicator\":\"A\",\"type\":\"SFO\",\"quantity\":1}]}}]}}";
        String responseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-ECOM\", \"statusMsg\": \"PEGA generated message\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"sessionId\": \"\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"0\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \" SOP-1583186-DEV3\", \"customerInfo\": { \"accountNumber\": \"07893451230-00001\", \"cartCreator\": \"2515813861\", \"processingMTN\": \"2515813860\" }, \"processMTNList\": [ { \"mtn\": \"2515813860\", \"completedprocessSteps\": [ \"MTNSelectionPage\", \"GridWallPDP\" ] }, { \"mtn\": \"2515813861\", \"completedprocessSteps\": [] } ], \"cartInfo\": { \"cartId\": \"25ed2544-790c-4316-937b-84b49ebbaa9c\", \"lines\": [ { \"mtn\": \"3025451823\", \"status\": 1, \"planValidationFailed\": false, \"lineActivityType\": \"EUP\", \"currentPlanType\": \"ALP\", \"devicePlanCompatible\": false, \"cpcPromoIntercept\": true, \"spos\": [ { \"id\": \"12345\", \"conflict\": \"This will be empty if there's no conflict\" }, { \"id\": 12345, \"success\": false, \"description\": \"\", \"is5GBoltEligible\": true, \"actionIndicator\": \"A\" } ], \"sfos\": [ { \"id\": \"12345\", \"conflict\": \"This will be empty if there's no conflict\" } ] } ] }, \"contextInfo\": { \"processAction\": \"\", \"processStep\": \"AccessoryPDP\", \"availablePaths\": [ { \"path\": \"AccessoryPDP\" } ], \"callReason\": \" SalesOrderPurchase \" } } } } }";
        AddFeaturesUIRequest request = mapper.readValue(requestString, AddFeaturesUIRequest.class);
        AddFeaturesUIResponse response = mapper.readValue(responseString, AddFeaturesUIResponse.class);
        when(redisHelper.getAddFeaturesRequest()).thenReturn(Mono.just(request));
        URI url = URI.create("http://localhost/add-features");
        when(cartHelper.populateSPOsFor5GBolt(any(), any())).thenReturn(Mono.just(ResponseEntity.status(200).body(response)));
        when(cartHelper.populateHumWifiConflictedSFos(any(), any())).thenReturn(Mono.just(ResponseEntity.status(200).body(response)));
        when(cartHelper.populateProtectionVersion(any(), any())).thenReturn(Mono.just(ResponseEntity.status(200).body(response)));
        when(cartHelper.updateFlowNameForAssisted(Mockito.any(),Mockito.any())).thenReturn(
                Mono.just(ResponseEntity.status(200).body(response)));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        when(cartHelper.addFeatures(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addFeatures(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addFeaturesErrorTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"ca7608de-6c65-4b6b-85e1-a2904fdb86a2\",\"caseId\":\"SOP-639240-E01\",\"accountNumber\":\"0322638103-00001\",\"cartCreator\":\"8643319007\",\"processingMTN\":\"8643858663\",\"intendType\":\"EUP\",\"processStep\":\"FeaturesPDP\"},\"data\":{\"account\":null,\"lines\":[{\"mtn\":\"8643858663\",\"features\":{\"add\":[{\"id\":\"66332\",\"actionIndicator\":\"A\",\"type\":\"SFO\",\"quantity\":1}]}}]}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        AddFeaturesUIRequest request = mapper.readValue(requestString, AddFeaturesUIRequest.class);
        AddFeaturesUIResponse response = mapper.readValue(responseString, AddFeaturesUIResponse.class);
        when(redisHelper.getAddFeaturesRequest()).thenReturn(Mono.just(request));
        URI url = URI.create("http://localhost/add-features");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        when(cartHelper.addFeatures(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addFeatures(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void removeLinesTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"467e2a19-c2cb-4d79-b042-22e75c16bb39\",\"caseId\":\"SOP-507867-E01\",\"accountNumber\":\"0517953243-00001\",\"cartCreator\":\"3013513888\",\"processingMTN\":\"3013513888\"},\"data\":{\"lines\":[{\"mtn\":\"3013513888\"},{\"mtn\":\"3013513834\"}]}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"MOTRN1\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-277-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"\",\"processAction\":\"\"},\"cartInfo\":{\"cartId\":\"69a66ef4d-7e344dfb-2db299209-ea8333\"},\"customerInfo\":{\"accountNumber\":\"0220335087-00001\",\"cartCreator\":\"8643804638\",\"processingMTN\":\"8643804638\"},\"processMTNList\":[{\"mtn\":\"8643804638\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\"]}],\"removeItem\":{\"lines\":[{\"mtn\":\"2564409659\",\"lineId\":\"null\",\"status\":1}]}}}}}";
        RemoveLinesUIRequest request = mapper.readValue(requestString, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse response = mapper.readValue(responseString, RemoveLinesUIResponse.class);
        URI url = URI.create("http://localhost/remove-lines");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(redisHelper.deleteAddDeviceDataFromRedis(any())).thenReturn(Mono.just(1L));
        when(redisHelper.deleteProcessingMtnFromRedis(any())).thenReturn(Mono.just(1L));
        when(redisHelper2.deleteEdgeBuyoutDataFromRedis()).thenReturn(Mono.just(1L));
        when(redisHelper2.updateDeviceCartCount(any(), any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just(""));
        when(redisHelper2.getRole()).thenReturn(Mono.just(""));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just(""));
        when(cartHelper.removeLines(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.removeLines(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void removeLinesBadRequestTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"467e2a19-c2cb-4d79-b042-22e75c16bb39\",\"caseId\":\"SOP-507867-E01\",\"accountNumber\":\"0517953243-00001\",\"cartCreator\":\"3013513888\",\"processingMTN\":\"3013513888\"},\"data\":{\"lines\":[{}]}}";
        RemoveLinesUIRequest request = mapper.readValue(requestString, RemoveLinesUIRequest.class);
        URI url = URI.create("http://localhost/remove-lines");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(redisHelper.deleteAddDeviceDataFromRedis(any())).thenReturn(Mono.just(1L));
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.removeLines(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void removeLinesErrorTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"467e2a19-c2cb-4d79-b042-22e75c16bb39\",\"caseId\":\"SOP-507867-E01\",\"accountNumber\":\"0517953243-00001\",\"cartCreator\":\"3013513888\",\"processingMTN\":\"3013513888\"},\"data\":{\"lines\":[{\"mtn\":\"3013513888\"},{\"mtn\":\"3013513834\"}]}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        RemoveLinesUIRequest request = mapper.readValue(requestString, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse response = mapper.readValue(responseString, RemoveLinesUIResponse.class);
        URI url = URI.create("http://localhost/remove-lines");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(redisHelper.deleteAddDeviceDataFromRedis(any())).thenReturn(Mono.just(1L));
        when(cartHelper.removeLines(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.removeLines(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void addBuyoutTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"buyOutFlag\": \"Y\", \"buyOutSelected\": \"Y\",\"edgeUpSelected\": \"N\"},\"data\":{\"lines\":[{\"mtn\":\"11111111111\",\"buyoutAmt\":350.00},{\"mtn\":\"222222222222\",\"buyoutAmt\":350.00}],\"effectiveDate\": \"\"}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"PEGA generated message\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"exceptions\":[{\"system\":\"CXP\",\"service\":\"validateCart\",\"type\":\"Error\",\"code\":\"E1223\",\"message\":\"Account validation failed\"},{\"system\":\"CXP\",\"service\":\"addToCartService\",\"type\":\"Warning\",\"code\":\"E1223\",\"message\":\"Account validation failed\"}],\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\" SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"BuyOut\"]},{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}],\"cartInfo\":{\"cartId\":\"a705f835-c61a-4e20-b616-0c9839202a15\"},\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"GridWallPDP\",\"availablePaths\":[{\"path\":\" GridWallPDP `\"}],\"callReason\":\" SalesOrderPurchase \"}}}}}";
        AddBuyoutUIRequest request = mapper.readValue(requestString, AddBuyoutUIRequest.class);
        AddBuyoutUIResponse response = mapper.readValue(responseString, AddBuyoutUIResponse.class);
        URI url = URI.create("http://localhost/add-buyout");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.CONTINUE);
        when(cartHelper.addBuyout(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addBuyout(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }
    @Test
    public void addBuyoutTest2() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"buyOutFlag\": \"Y\", \"buyOutSelected\": \"Y\",\"edgeUpSelected\": \"N\"},\"data\":{\"lines\":[{\"mtn\":\"11111111111\",\"buyoutAmt\":350.00},{\"mtn\":\"222222222222\",\"buyoutAmt\":350.00}],\"effectiveDate\": \"\"}}";
        String responseString = "{\"errors\": [{ \"namespace\": \"abcdedf\", \"id\":\"abcdef\"}],\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"PEGA generated message\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"exceptions\":[{\"system\":\"CXP\",\"service\":\"validateCart\",\"type\":\"Error\",\"code\":\"E1223\",\"message\":\"Account validation failed\"},{\"system\":\"CXP\",\"service\":\"addToCartService\",\"type\":\"Warning\",\"code\":\"E1223\",\"message\":\"Account validation failed\"}],\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\" SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"BuyOut\"]},{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}],\"cartInfo\":{\"cartId\":\"a705f835-c61a-4e20-b616-0c9839202a15\"},\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"GridWallPDP\",\"availablePaths\":[{\"path\":\" GridWallPDP `\"}],\"callReason\":\" SalesOrderPurchase \"}}}}}";
        AddBuyoutUIRequest request = mapper.readValue(requestString, AddBuyoutUIRequest.class);
        AddBuyoutUIResponse response = mapper.readValue(responseString, AddBuyoutUIResponse.class);
        URI url = URI.create("http://localhost/add-buyout");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM-TAB").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.valueOf(500));
        when(cartHelper.addBuyout(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addBuyout(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }
    @Test
    public void addBuyoutTest3() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"mtnFlow\":\"M\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"buyOutFlag\": \"Y\", \"buyOutSelected\": \"Y\",\"edgeUpSelected\": \"N\"},\"data\":{\"lines\":[{\"mtn\":\"11111111111\",\"buyoutAmt\":350.00},{\"mtn\":\"222222222222\",\"buyoutAmt\":350.00}],\"effectiveDate\": \"\"}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"PEGA generated message\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"exceptions\":[{\"system\":\"CXP\",\"service\":\"validateCart\",\"type\":\"Error\",\"code\":\"E1223\",\"message\":\"Account validation failed\"},{\"system\":\"CXP\",\"service\":\"addToCartService\",\"type\":\"Warning\",\"code\":\"E1223\",\"message\":\"Account validation failed\"}],\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\" SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"BuyOut\"]},{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}],\"cartInfo\":{\"cartId\":\"a705f835-c61a-4e20-b616-0c9839202a15\"},\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"GridWallPDP\",\"availablePaths\":[{\"path\":\" GridWallPDP `\"}],\"callReason\":\" SalesOrderPurchase \"}}}}}";
        AddBuyoutUIRequest request = mapper.readValue(requestString, AddBuyoutUIRequest.class);
        AddBuyoutUIResponse response = mapper.readValue(responseString, AddBuyoutUIResponse.class);
        URI url = URI.create("http://localhost/add-buyout");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.CONTINUE);
        when(cartHelper.addBuyout(any())).thenReturn(Mono.just(response));
        when(redisHelper2.upsertEdgeBuyoutDataIntoRedis(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addBuyout(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addBuyoutBadRequestTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"buyOutFlag\": \"\", \"buyOutSelected\": \"Y\",\"edgeUpSelected\": \"N\"},\"data\":{\"lines\":[{\"mtn\":\"11111111111\",\"buyoutAmt\":350.00},{\"mtn\":\"222222222222\",\"buyoutAmt\":350.00}],\"effectiveDate\": \"\"}}";
        AddBuyoutUIRequest request = mapper.readValue(requestString, AddBuyoutUIRequest.class);
        URI url = URI.create("http://localhost/add-buyout");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addBuyout(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addBuyoutErrorTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"buyOutFlag\": \"Y\", \"buyOutSelected\": \"Y\",\"edgeUpSelected\": \"N\"},\"data\":{\"lines\":[{\"mtn\":\"11111111111\",\"buyoutAmt\":350.00},{\"mtn\":\"222222222222\",\"buyoutAmt\":350.00}],\"effectiveDate\": \"\"}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        AddBuyoutUIRequest request = mapper.readValue(requestString, AddBuyoutUIRequest.class);
        AddBuyoutUIResponse response = mapper.readValue(responseString, AddBuyoutUIResponse.class);
        URI url = URI.create("http://localhost/add-buyout");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.valueOf(200));
        when(cartHelper.addBuyout(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addBuyout(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void clearAndContinueTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"mtnFlow\":\"m\",\"locationCode\":\"E319201\"}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1324635-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryPDP\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryPDP\",\"processAction\":\"\"},\"customerInfo\":{\"registerNumber\":0,\"accountNumber\":\"0388697212-00001\",\"cartCreator\":\"8609316888\",\"processingMTN\":\"8609316888\"},\"cartInfo\":{\"cartId\":\"a3abdc6a-3359-402a-8ed4-2663f123f132\",\"statusCode\":\"1\",\"statusMsg\":\"Success\",\"lines\":[{\"accessories\":{},\"mtn\":\"8609316888\"}],\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"8609316888\",\"completedprocessSteps\":[\"pastDuePage\",\"AccessoryPDP\"]}]}}}}";
        ClearAndContinueUIRequest request = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
        ClearAndContinueUIResponse response = mapper.readValue(responseString, ClearAndContinueUIResponse.class);
        String getDataFromRedisAsString = "{\"cartId\":\"5d11107a-9df0-40d4-b4c2-1e9baf89ff4a\",\"caseId\":\"SOP-1075631-E01\",\"accountNumber\":\"0280882722-00001\",\"mtn\":\"3175174243\",\"processingMTN\":\"3175174243\",\"cartCreator\":\"3175174243\"}";
        String getItemTypeFromRedisString = "device";
        CartRedisData sampleRedisData = mapper.readValue(getDataFromRedisAsString, CartRedisData.class);
        URI url = URI.create("http://localhost/clearAndContinue");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just(getItemTypeFromRedisString));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getAccessoryDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(true));
        when(cartHelper.clearAndContinue(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.clearAndContinue(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }


    @Test
    public void clearAndContinueTest2() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"mtnFlow\":\"m\",\"locationCode\":\"E319201\"}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1324635-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryPDP\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryPDP\",\"processAction\":\"\"},\"customerInfo\":{\"registerNumber\":0,\"accountNumber\":\"0388697212-00001\",\"cartCreator\":\"8609316888\",\"processingMTN\":\"8609316888\"},\"cartInfo\":{\"cartId\":\"a3abdc6a-3359-402a-8ed4-2663f123f132\",\"statusCode\":\"1\",\"statusMsg\":\"Success\",\"lines\":[{\"accessories\":{},\"mtn\":\"8609316888\"}],\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"8609316888\",\"completedprocessSteps\":[\"pastDuePage\",\"AccessoryPDP\"]}]}}}}";
        String getDataFromRedisAsString = "{\"cartId\":\"5d11107a-9df0-40d4-b4c2-1e9baf89ff4a\",\"caseId\":\"SOP-1075631-E01\",\"accountNumber\":\"0280882722-00001\",\"mtn\":\"3175174243\",\"processingMTN\":\"3175174243\",\"cartCreator\":\"3175174243\",\"accessoryCartInfo\":{\"correlationId\":\"soe-cart-2022.06.13.13.24.06-362.4279557048584\",\"cartId\":\"da905865-e386-49a3-adcf-e3cd1850d84c\",\"intendType\":\"AbCC\"}}";
        ClearAndContinueUIRequest request = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
        ClearAndContinueUIResponse response = mapper.readValue(responseString, ClearAndContinueUIResponse.class);
        String getItemTypeFromRedisString = "accessory";
        CartRedisData sampleRedisData = mapper.readValue(getDataFromRedisAsString, CartRedisData.class);
        URI url = URI.create("http://localhost/clearAndContinue");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just(getItemTypeFromRedisString));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getAccessoryDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(true));
        when(cartHelper.clearAndContinue(any())).thenReturn(Mono.just(response));
        if(!enableClearAndAddItem)
            cartController.setEnableClearAndAddItem(true);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.clearAndContinue(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void clearAndContinueTest3() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"locationCode\":\"E319201\"}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1324635-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryPDP\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryPDP\",\"processAction\":\"\"},\"customerInfo\":{\"registerNumber\":0,\"accountNumber\":\"0388697212-00001\",\"cartCreator\":\"8609316888\",\"processingMTN\":\"8609316888\"},\"cartInfo\":{\"cartId\":\"a3abdc6a-3359-402a-8ed4-2663f123f132\",\"statusCode\":\"1\",\"statusMsg\":\"Success\",\"lines\":[{\"accessories\":{},\"mtn\":\"8609316888\"}],\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"8609316888\",\"completedprocessSteps\":[\"pastDuePage\",\"AccessoryPDP\"]}]}}}}";
        String getDataFromRedisAsString = "{\"cartId\":\"5d11107a-9df0-40d4-b4c2-1e9baf89ff4a\",\"caseId\":\"SOP-1075631-E01\",\"accountNumber\":\"0280882722-00001\",\"mtn\":\"3175174243\",\"processingMTN\":\"3175174243\",\"cartCreator\":\"3175174243\",\"accessoryCartInfo\":{\"correlationId\":\"soe-cart-2022.06.13.13.24.06-362.4279557048584\",\"cartId\":\"da905865-e386-49a3-adcf-e3cd1850d84c\",\"intendType\":\"AbCC\"}}";
        ClearAndContinueUIRequest request = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
        ClearAndContinueUIResponse response = mapper.readValue(responseString, ClearAndContinueUIResponse.class);
        String getItemTypeFromRedisString = "accessory";
        CartRedisData sampleRedisData = mapper.readValue(getDataFromRedisAsString, CartRedisData.class);
        URI url = URI.create("http://localhost/clearAndContinue");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just(getItemTypeFromRedisString));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getAccessoryDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(true));
        when(cartHelper.clearAndContinue(any())).thenReturn(Mono.just(response));
        if(!enableClearAndAddItem)
            cartController.setEnableClearAndAddItem(true);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.clearAndContinue(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void clearAndContinueIntentTypeTest4() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"locationCode\":\"E319201\"}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1324635-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryPDP\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryPDP\",\"processAction\":\"\"},\"customerInfo\":{\"registerNumber\":0,\"accountNumber\":\"0388697212-00001\",\"cartCreator\":\"8609316888\",\"processingMTN\":\"8609316888\"},\"cartInfo\":{\"cartId\":\"a3abdc6a-3359-402a-8ed4-2663f123f132\",\"statusCode\":\"1\",\"statusMsg\":\"Success\",\"lines\":[{\"accessories\":{},\"mtn\":\"8609316888\"}],\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"8609316888\",\"completedprocessSteps\":[\"pastDuePage\",\"AccessoryPDP\"]}]}}}}";
        String getDataFromRedisAsString = "{\"cartId\":\"5d11107a-9df0-40d4-b4c2-1e9baf89ff4a\",\"caseId\":\"SOP-1075631-E01\",\"accountNumber\":\"0280882722-00001\",\"mtn\":\"3175174243\",\"processingMTN\":\"3175174243\",\"cartCreator\":\"3175174243\",\"accessoryCartInfo\":{\"correlationId\":\"soe-cart-2022.06.13.13.24.06-362.4279557048584\",\"cartId\":\"da905865-e386-49a3-adcf-e3cd1850d84c\",\"intendType\":\"ACC\"}}";
        ClearAndContinueUIRequest request = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
        ClearAndContinueUIResponse response = mapper.readValue(responseString, ClearAndContinueUIResponse.class);
        String getItemTypeFromRedisString = "accessory";
        CartRedisData sampleRedisData = mapper.readValue(getDataFromRedisAsString, CartRedisData.class);
        URI url = URI.create("http://localhost/clearAndContinue");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just(getItemTypeFromRedisString));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getAccessoryDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(true));
        when(cartHelper.clearAndContinue(any())).thenReturn(Mono.just(response));
        when(cartHelper.addAccessoryClearAndContinue(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(new AddAccessoriesUIResponse()));
        if(!enableClearAndAddItem)
            cartController.setEnableClearAndAddItem(true);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.clearAndContinue(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void clearAndContinuedeviceErrorsTest5() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"locationCode\":\"E319201\"}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1324635-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryPDP\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryPDP\",\"processAction\":\"\"},\"customerInfo\":{\"registerNumber\":0,\"accountNumber\":\"0388697212-00001\",\"cartCreator\":\"8609316888\",\"processingMTN\":\"8609316888\"},\"cartInfo\":{\"cartId\":\"a3abdc6a-3359-402a-8ed4-2663f123f132\",\"statusCode\":\"1\",\"statusMsg\":\"Success\",\"lines\":[{\"accessories\":{},\"mtn\":\"8609316888\"}],\"discountPromoTotal\":0.0,\"registerNumber\":0},\"errors\":[{\"namespace\":\"8609316888\",\"id\":\"abcd\"}]}}}}";
        String getDataFromRedisAsString = "{\"cartId\":\"5d11107a-9df0-40d4-b4c2-1e9baf89ff4a\",\"caseId\":\"SOP-1075631-E01\",\"accountNumber\":\"0280882722-00001\",\"mtn\":\"3175174243\",\"processingMTN\":\"3175174243\",\"cartCreator\":\"3175174243\",\"deviceCartInfo\":{\"correlationId\":\"soe-cart-2022.06.13.13.24.06-362.4279557048584\",\"cartId\":\"da905865-e386-49a3-adcf-e3cd1850d84c\",\"intendType\":\"ACbc\"}}";
        ClearAndContinueUIRequest request = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
        ClearAndContinueUIResponse response = mapper.readValue(responseString, ClearAndContinueUIResponse.class);
        String getItemTypeFromRedisString = "device";
        CartRedisData sampleRedisData = mapper.readValue(getDataFromRedisAsString, CartRedisData.class);
        URI url = URI.create("http://localhost/clearAndContinue");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just(getItemTypeFromRedisString));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getAccessoryDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(true));
        when(cartHelper.clearAndContinue(any())).thenReturn(Mono.just(response));
        when(cartHelper.addAccessoryClearAndContinue(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(new AddAccessoriesUIResponse()));
        if(!enableClearAndAddItem)
            cartController.setEnableClearAndAddItem(true);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.clearAndContinue(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }



    @Test
    public void clearAndContinueGTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"mtnFlow\":\"G\",\"locationCode\":\"E319201\"}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1324635-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryPDP\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryPDP\",\"processAction\":\"\"},\"customerInfo\":{\"registerNumber\":0,\"accountNumber\":\"0388697212-00001\",\"cartCreator\":\"8609316888\",\"processingMTN\":\"8609316888\"},\"cartInfo\":{\"cartId\":\"a3abdc6a-3359-402a-8ed4-2663f123f132\",\"statusCode\":\"1\",\"statusMsg\":\"Success\",\"lines\":[{\"accessories\":{},\"mtn\":\"8609316888\"}],\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"8609316888\",\"completedprocessSteps\":[\"pastDuePage\",\"AccessoryPDP\"]}]}}}}";
        ClearAndContinueUIRequest request = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
        ClearAndContinueUIResponse response = mapper.readValue(responseString, ClearAndContinueUIResponse.class);
        String getDataFromRedisAsString = "{\"cartId\":\"5d11107a-9df0-40d4-b4c2-1e9baf89ff4a\",\"caseId\":\"SOP-1075631-E01\",\"accountNumber\":\"0280882722-00001\",\"mtn\":\"3175174243\",\"processingMTN\":\"3175174243\",\"cartCreator\":\"3175174243\"}";
        String getItemTypeFromRedisString = "device";
        CartRedisData sampleRedisData = mapper.readValue(getDataFromRedisAsString, CartRedisData.class);
        URI url = URI.create("http://localhost/clearAndContinue");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just(getItemTypeFromRedisString));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getAccessoryDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(true));
        when(cartHelper.clearAndContinue(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.clearAndContinue(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceWithBuyoutTest() throws IOException {
        String requestString = "{ \"cartInfo\": { \"clientAppName\": \"VZW-NETACE\", \"cartId\": \"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\", \"caseId\": \"SOP-329-E01\", \"accountNumber\": \"0820215913-00001\", \"cartCreator\": \"6154839959\", \"processingMTN\": \"6154839959\", \"processStep\": \"MTNSelectionPage/ShoppingCart\", \"intendType\": \"EUP\", \"mtnFlow\":\"G\" }, \"data\": { \"lines\": [ { \"mtn\": \"2059376950\", \"isEdgeBuyOut\":true, \"edgeup\":{ \"deviceId\":\"353338070105553\" } } ] } }";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/addDeviceWithBuyout");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController2,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addDeviceWithBuyout(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceWithBuyoutTest6() throws IOException {
        String requestString = "{ \"cartInfo\": { \"clientAppName\": \"VZW-NETACE\", \"cartId\": \"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\", \"caseId\": \"SOP-329-E01\", \"accountNumber\": \"0820215913-00001\", \"cartCreator\": \"6154839959\", \"processingMTN\": \"6154839959\", \"processStep\": \"MTNSelectionPage/ShoppingCart\", \"intendType\": \"EUP\", \"mtnFlow\":\"G\" }, \"data\": { \"lines\": [ { \"mtn\": \"2059376950\", \"isEdgeBuyOut\":true, \"edgeup\":{ \"deviceId\":\"353338070105553\" } } ] } }";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\",\"deviceCartInfo\":{\"number_share_capable\":\"VZWECOM\",\"e911_addr_ind\":\"ninabcd\"}}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/addDeviceWithBuyout");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController2,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addDeviceWithBuyout(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceWithBuyoutErrorTest() throws IOException {
        String requestString = "{ \"cartInfo\": { \"clientAppName\": \"VZW-NETACE\", \"cartId\": \"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\", \"caseId\": \"SOP-329-E01\", \"accountNumber\": \"0820215913-00001\", \"cartCreator\": \"6154839959\", \"processingMTN\": \"6154839959\", \"processStep\": \"MTNSelectionPage/ShoppingCart\", \"intendType\": \"EUP\", \"mtnFlow\":\"G\" }, \"data\": { \"lines\": [ { \"mtn\": \"2059376950\", \"isEdgeBuyOut\":true, \"edgeup\":{ \"deviceId\":\"353338070105553\" } } ] } }";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/addDeviceWithBuyout");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController2,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addDeviceWithBuyout(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }
    @Test
    public void addDeviceWithBuyoutErrorTest2() throws IOException {
        String requestString = "{ \"cartInfo\": { \"clientAppName\": \"VZW-NETACE\", \"cartId\": \"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\", \"caseId\": \"SOP-329-E01\", \"accountNumber\": \"0820215913-00001\", \"cartCreator\": \"6154839959\", \"processingMTN\": \"6154839959\", \"processStep\": \"MTNSelectionPage/ShoppingCart\", \"intendType\": \"EUP\", \"mtnFlow\":\"G\" }, \"data\": { \"lines\": [ { \"mtn\": \"2059376950\", \"isEdgeBuyOut\":true, \"edgeup\":{ \"deviceId\":\"353338070105553\" } } ] } }";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/addDeviceWithBuyout");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.valueOf(500));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController2,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addDeviceWithBuyout(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }
    @Test
    public void addDeviceWithBuyoutErrorDeviceConfig() throws IOException {
        String requestString = "{ \"cartInfo\": { \"clientAppName\": \"VZW-NETACE\", \"cartId\": \"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\", \"caseId\": \"SOP-329-E01\", \"accountNumber\": \"0820215913-00001\", \"cartCreator\": \"6154839959\", \"processingMTN\": \"6154839959\", \"processStep\": \"MTNSelectionPage/ShoppingCart\", \"intendType\": \"EUP\", \"mtnFlow\":\"G\" }, \"data\": { \"lines\": [ { \"mtn\": \"2059376950\", \"isEdgeBuyOut\":true, \"edgeup\":{ \"deviceId\":\"353338070105553\" } } ] } }";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\",\"deviceCartInfo\":{\"number_share_capable\":\"VZWECOM\",\"e911_addr_ind\":\"ninabcd\"} }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/addDeviceWithBuyout");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.valueOf(500));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController2,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addDeviceWithBuyout(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }
    @Test
    public void addDeviceWithBuyoutEmptyNumbershabel() throws IOException {
        String requestString = "{ \"cartInfo\": { \"clientAppName\": \"VZW-NETACE\", \"cartId\": \"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\", \"caseId\": \"SOP-329-E01\", \"accountNumber\": \"0820215913-00001\", \"cartCreator\": \"6154839959\", \"processingMTN\": \"6154839959\", \"processStep\": \"MTNSelectionPage/ShoppingCart\", \"intendType\": \"EUP\", \"mtnFlow\":\"G\" }, \"data\": { \"lines\": [ { \"mtn\": \"2059376950\", \"isEdgeBuyOut\":true, \"edgeup\":{ \"deviceId\":\"353338070105553\" } } ] } }";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\",\"deviceCartInfo\":{\"number_share_capable\":\"VZWECOM\",\"e911_addr_ind\":\"ninabcd\"} }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/addDeviceWithBuyout");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.valueOf(500));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController2,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addDeviceWithBuyout(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addEdgeUpTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"N\",\"edgeUpSelected\":\"Y\",\"FMITurnedoff\":\"Y\",\"deviceMisMatched\":\"N\"},\"data\":{\"lines\":[{\"mtn\":\"2158806687\",\"edgeup\":{\"deviceId\":\"356110090934891\",\"edgeupAmount\":140.25}}],\"effectiveDate\":\"09/26/2019\"}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\" SOP-1583186-DEV3\",\"contextInfo\":{\"availablePaths\":[{\"path\":\" GridWallPDP `\"}],\"callReason\":\" SalesOrderPurchase \",\"processStep\":\"GridWallPDP\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"cartInfo\":{\"cartId\":\"a705f835-c61a-4e20-b616-0c9839202a15\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"BuyOut\"]},{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}]}}},\"exceptions\":[{\"system\":\"CXP\",\"service\":\"validateCart\",\"type\":\"Error\",\"code\":\"E1223\",\"message\":\"Account validation failed\"},{\"system\":\"CXP\",\"service\":\"addToCartService\",\"type\":\"Warning\",\"code\":\"E1223\",\"message\":\"Account validation failed\"}]}";
        UpdateEdgeupUIRequest request = mapper.readValue(requestString, UpdateEdgeupUIRequest.class);
        UpdateEdgeupUIResponse response = mapper.readValue(responseString, UpdateEdgeupUIResponse.class);
        URI url = URI.create("http://localhost/add-edgeup");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.CONTINUE);
        when(cartHelper.addEdgeup(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addEdgeUp(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addEdgeUpBadRequestTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"edgeUpSelected\":\"Y\",\"FMITurnedoff\":\"Y\",\"deviceMisMatched\":\"N\"},\"data\":{\"lines\":[{\"mtn\":\"2158806687\",\"edgeup\":{\"deviceId\":\"356110090934891\"}}],\"effectiveDate\":\"09/26/2019\"}}";
        UpdateEdgeupUIRequest request = mapper.readValue(requestString, UpdateEdgeupUIRequest.class);
        URI url = URI.create("http://localhost/add-edgeup");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addEdgeUp(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addEdgeUpErrorTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"N\",\"edgeUpSelected\":\"Y\",\"FMITurnedoff\":\"Y\",\"deviceMisMatched\":\"N\"},\"data\":{\"lines\":[{\"mtn\":\"2158806687\",\"edgeup\":{\"deviceId\":\"356110090934891\",\"edgeupAmount\":140.25}}],\"effectiveDate\":\"09/26/2019\"}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        UpdateEdgeupUIRequest request = mapper.readValue(requestString, UpdateEdgeupUIRequest.class);
        UpdateEdgeupUIResponse response = mapper.readValue(responseString, UpdateEdgeupUIResponse.class);
        URI url = URI.create("http://localhost/add-edgeup");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.valueOf(200));
        when(cartHelper.addEdgeup(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addEdgeUp(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }



    @Test
    public void addEdgeUpTest2() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"N\",\"edgeUpSelected\":\"Y\",\"FMITurnedoff\":\"Y\",\"deviceMisMatched\":\"N\"},\"data\":{\"lines\":[{\"mtn\":\"2158806687\",\"edgeup\":{\"deviceId\":\"356110090934891\",\"edgeupAmount\":140.25}}],\"effectiveDate\":\"09/26/2019\"}}";
        String responseString = "{\"errors\": [{ \"namespace\": \"abcdedf\", \"id\":\"abcdef\"}],\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\" SOP-1583186-DEV3\",\"contextInfo\":{\"availablePaths\":[{\"path\":\" GridWallPDP `\"}],\"callReason\":\" SalesOrderPurchase \",\"processStep\":\"GridWallPDP\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"cartInfo\":{\"cartId\":\"a705f835-c61a-4e20-b616-0c9839202a15\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"BuyOut\"]},{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}]}}},\"exceptions\":[{\"system\":\"CXP\",\"service\":\"validateCart\",\"type\":\"Error\",\"code\":\"E1223\",\"message\":\"Account validation failed\"},{\"system\":\"CXP\",\"service\":\"addToCartService\",\"type\":\"Warning\",\"code\":\"E1223\",\"message\":\"Account validation failed\"}]}";
        UpdateEdgeupUIRequest request = mapper.readValue(requestString, UpdateEdgeupUIRequest.class);
        UpdateEdgeupUIResponse response = mapper.readValue(responseString, UpdateEdgeupUIResponse.class);
        URI url = URI.create("http://localhost/add-edgeup");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.valueOf(500));
        when(cartHelper.addEdgeup(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addEdgeUp(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }
    @Test
    public void addEdgeUpTest3() throws IOException {
        String requestString = "{\"cartInfo\":{\"mtnFlow\":\"M\",\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"N\",\"edgeUpSelected\":\"Y\",\"FMITurnedoff\":\"Y\",\"deviceMisMatched\":\"N\"},\"data\":{\"lines\":[{\"mtn\":\"2158806687\",\"edgeup\":{\"deviceId\":\"356110090934891\",\"edgeupAmount\":140.25}}],\"effectiveDate\":\"09/26/2019\"}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\" SOP-1583186-DEV3\",\"contextInfo\":{\"availablePaths\":[{\"path\":\" GridWallPDP `\"}],\"callReason\":\" SalesOrderPurchase \",\"processStep\":\"GridWallPDP\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"cartInfo\":{\"cartId\":\"a705f835-c61a-4e20-b616-0c9839202a15\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"BuyOut\"]},{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}]}}},\"exceptions\":[{\"system\":\"CXP\",\"service\":\"validateCart\",\"type\":\"Error\",\"code\":\"E1223\",\"message\":\"Account validation failed\"},{\"system\":\"CXP\",\"service\":\"addToCartService\",\"type\":\"Warning\",\"code\":\"E1223\",\"message\":\"Account validation failed\"}]}";
        UpdateEdgeupUIRequest request = mapper.readValue(requestString, UpdateEdgeupUIRequest.class);
        UpdateEdgeupUIResponse response = mapper.readValue(responseString, UpdateEdgeupUIResponse.class);
        URI url = URI.create("http://localhost/add-edgeup");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM-TAB").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.addEdgeup(any())).thenReturn(Mono.just(response));
        when(redisHelper2.upsertEdgeBuyoutDataIntoRedis(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addEdgeUp(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }
    @Test
    public void removeEdgeUpTest() throws IOException {
        String requestString = "{ \"cartInfo\": {\"clientAppName\": \"VZW-NETACE\", \"cartId\": \"f61a7954-4300-4e97-9478-f001475bdf9b\", \"caseId\": \"SOP-508208-E01\", \"accountNumber\": \"0420194063-00001\", \"cartCreator\": \"4235342870\", \"processingMTN\": \"4235344191\", \"processStep\": \"MTNSelectionPage\", \"intendType\": \"EUP\" }, \"data\": { \"lines\": [{\"mtn\": \"2158806687\"}]}}";
        String responseString = "{\"serviceHeader\": {\"clientId\": \"VZW-NETACE\", \"statusMsg\": \"PEGA generated message\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"sessionId\": \"\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\",\"statusCode\": \"0\"}, \"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \" SAP-1583186-DEV3\", \"cartInfo\" :{\"isEmptyLines\": true}, \"customerInfo\" :{\"accountNumber\": \"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\": \"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\",\"ShoppingCart\",\"CreditPage\"]},{\"mtn\":\"2515813861\",\"completedprocessSteps\": []}],\"CartInfo\": {\"cartId\":\"bea202a6-42cb-40d4-ac87-d3f1db2b3f13\",\"statusCode\": 1,\"statusMsg\": \"Edge Up cancelled successfully.\"},\"contextInfo\": {\"processAction\": \"\", \"callReason\": \"SalesOrderPurchase\",\"processStep\": \"MTNSelectionPage\",\"availablePaths\":[{\"path\":\"MTNSelectionPage\"}]}}}}}";
        String requestStringForRemoveLines = "{ \"cartInfo\": {\"clientAppName\": \"VZW-NETACE\", \"cartId\": \"f61a7954-4300-4e97-9478-f001475bdf9b\", \"caseId\": \"SOP-508208-E01\", \"accountNumber\": \"0420194063-00001\", \"cartCreator\": \"4235342870\", \"processingMTN\": \"4235344191\", \"processStep\": \"ShoppingCart\", \"intendType\": \"EUP\", \"processAction\":\"removeItem\" }, \"data\": { \"lines\": [{\"mtn\": \"2158806687\"}]}}";
        UpdateEdgeupUIRequest request = mapper.readValue(requestString, UpdateEdgeupUIRequest.class);
        UpdateEdgeupUIResponse response = mapper.readValue(responseString, UpdateEdgeupUIResponse.class);
        RemoveLinesUIRequest removeLinesRequest = mapper.readValue(requestStringForRemoveLines, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse removeLinesResponse = mapper.readValue(responseString, RemoveLinesUIResponse.class);
        URI url = URI.create("http://localhost/removeEdgeUp");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.removeEdgeup(any())).thenReturn(Mono.just(response));
        when(cartHelper.removeLines(removeLinesRequest)).thenReturn(Mono.just(removeLinesResponse));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.removeEdgeUp(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void removeEdgeUpBadRequestTest() throws IOException {
        String requestString = "{ \"cartInfo\": {\"clientAppName\": \"VZW-NETACE\", \"cartId\": \"f61a7954-4300-4e97-9478-f001475bdf9b\", \"caseId\": \"SOP-508208-E01\", \"accountNumber\": \"0420194063-00001\", \"cartCreator\": \"4235342870\", \"processingMTN\": \"4235344191\", \"processStep\": \"MTNSelectionPage\", \"intendType\": \"EUP\" }, \"data\": { \"lines\": [{\"mtn\": \"\"}]}}";
        UpdateEdgeupUIRequest request = mapper.readValue(requestString, UpdateEdgeupUIRequest.class);
        URI url = URI.create("http://localhost/removeEdgeUp");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.removeEdgeUp(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void removeEdgeUpErrorTest() throws IOException {
        String requestString = "{ \"cartInfo\": {\"clientAppName\": \"VZW-NETACE\", \"cartId\": \"f61a7954-4300-4e97-9478-f001475bdf9b\", \"caseId\": \"SOP-508208-E01\", \"accountNumber\": \"0420194063-00001\", \"cartCreator\": \"4235342870\", \"processingMTN\": \"4235344191\", \"processStep\": \"MTNSelectionPage\", \"intendType\": \"EUP\" }, \"data\": { \"lines\": [{\"mtn\": \"2158806687\"}]}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        UpdateEdgeupUIRequest request = mapper.readValue(requestString, UpdateEdgeupUIRequest.class);
        UpdateEdgeupUIResponse response = mapper.readValue(responseString, UpdateEdgeupUIResponse.class);
        URI url = URI.create("http://localhost/removeEdgeUp");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.removeEdgeup(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.removeEdgeUp(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void addDownPaymentTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\"},\"data\":{\"lines\":[{\"mtn\":\"11111111111\",\"downPayment\":{\"amount\":0,\"percentage\":10}},{\"mtn\":\"222222222222\",\"downPayment\":{\"amount\":0,\"percentage\":10}}]}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGA generated message\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"exceptions\":[{\"system\":\"CXP\",\"service\":\"addToCartService\",\"type\":\"Warning\",\"code\":\"E1223\",\"message\":\"Account validation failed\"}],\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\" SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}],\"cartInfo\":{\"cartId\":\"69a66ef4d-7e344dfb-2db299209-ea8333\",\"lines\":[{\"mtn\":\"11111111111\",\"downPayment\":{\"amount\":0,\"percentage\":10}},{\"mtn\":\"222222222222\",\"downPayment\":{\"amount\":0,\"percentage\":10}}]},\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"ShoppingCart\",\"availablePaths\":[{\"path\":\"ShoppingCart`\"}],\"callReason\":\" SalesOrderPurchase \"}}}}}";
        DownPaymentUIRequest request = mapper.readValue(requestString, DownPaymentUIRequest.class);
        AddDownPaymentUIResponse response = mapper.readValue(responseString, AddDownPaymentUIResponse.class);
        URI url = URI.create("http://localhost/add-downpayment");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.addDownPayment(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDownPayment(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDownPaymentTest1() throws IOException {
        String requestString = "{\"channelId\":\"OMNI-INDIRECT\",\"cartInfo\":{\"clientAppName\":\"OMNI-INDIRECT\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\"},\"data\":{\"lines\":[{\"mtn\":\"11111111111\",\"downPayment\":{\"percentage\":10,\"amount\":null}},{\"mtn\":\"222222222222\",\"downPayment\":{\"percentage\":10,\"amount\":null}}]}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGA generated message\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"exceptions\":[{\"system\":\"CXP\",\"service\":\"addToCartService\",\"type\":\"Warning\",\"code\":\"E1223\",\"message\":\"Account validation failed\"}],\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\" SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}],\"cartInfo\":{\"cartId\":\"69a66ef4d-7e344dfb-2db299209-ea8333\",\"lines\":[{\"mtn\":\"11111111111\",\"downPayment\":{\"amount\":0,\"percentage\":10}},{\"mtn\":\"222222222222\",\"downPayment\":{\"amount\":0,\"percentage\":10}}]},\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"ShoppingCart\",\"availablePaths\":[{\"path\":\"ShoppingCart`\"}],\"callReason\":\" SalesOrderPurchase \"}}}}}";
        DownPaymentUIRequest request = mapper.readValue(requestString, DownPaymentUIRequest.class);
        AddDownPaymentUIResponse response = mapper.readValue(responseString, AddDownPaymentUIResponse.class);
        URI url = URI.create("http://localhost/add-downpayment");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","OMNI-INDIRECT").build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.addDownPayment(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDownPayment(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDownPaymentTest2() throws IOException {
        String requestString = "{\"channelId\":\"OMNI-INDIRECT\",\"cartInfo\":{\"clientAppName\":\"OMNI-INDIRECT\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\"},\"data\":{\"lines\":[{\"mtn\":\"11111111111\",\"sellerPrice\":null},{\"mtn\":\"222222222222\",\"sellerPrice\":null}]}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGA generated message\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"exceptions\":[{\"system\":\"CXP\",\"service\":\"addToCartService\",\"type\":\"Warning\",\"code\":\"E1223\",\"message\":\"Account validation failed\"}],\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\" SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}],\"cartInfo\":{\"cartId\":\"69a66ef4d-7e344dfb-2db299209-ea8333\",\"lines\":[{\"mtn\":\"11111111111\",\"downPayment\":{\"userSelectedAmount\":0,\"percentage\":10}},{\"mtn\":\"222222222222\",\"downPayment\":{\"userSelectedAmount\":0,\"percentage\":10}}]},\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"ShoppingCart\",\"availablePaths\":[{\"path\":\"ShoppingCart`\"}],\"callReason\":\" SalesOrderPurchase \"}}}}}";
        DownPaymentUIRequest request = mapper.readValue(requestString, DownPaymentUIRequest.class);
        AddDownPaymentUIResponse response = mapper.readValue(responseString, AddDownPaymentUIResponse.class);
        URI url = URI.create("http://localhost/add-downpayment");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","OMNI-INDIRECT").build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.addDownPayment(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDownPayment(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDownPaymentBadRequestTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\"},\"data\":{\"lines\":[{\"mtn\":\"11111111111\",\"downPayment\":{\"amount\":0,\"percentage\":10}},{\"mtn\":\"222222222222\",\"downPayment\":{\"amount\":0,\"percentage\":10}}]}}";
        DownPaymentUIRequest request = mapper.readValue(requestString, DownPaymentUIRequest.class);
        URI url = URI.create("http://localhost/add-downpayment");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDownPayment(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDownPaymentBadRequestTestForSellerPrice() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"EROES\",\"cartId\":\"103556cc-c428-4c0c-9f64-8b58e1c8e1a5\",\"caseId\":\"SOP-11175717-C01\",\"accountNumber\":\"0213203078-00001\",\"cartCreator\":\"8503814318\",\"processStep\":\"DownPayment\",\"intendType\":\"EUP\"},\"data\":{\"lines\":[{\"mtn\":\"8508141431\",\"lineDeviceDollar\":0,\"downPayment\":{\"amount\":\"0.0\",\"percentage\":0,\"sellerPrice\":0.3},\"sellerPrice\":0.3}]}}";
        DownPaymentUIRequest request = mapper.readValue(requestString, DownPaymentUIRequest.class);
        URI url = URI.create("http://localhost/add-downpayment");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-INDIRECT").build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDownPayment(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDownPaymentErrorTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\"},\"data\":{\"lines\":[{\"mtn\":\"11111111111\",\"downPayment\":{\"amount\":0,\"percentage\":10}},{\"mtn\":\"222222222222\",\"downPayment\":{\"userSelectedDownPayment\":0,\"percentage\":10}}]}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        DownPaymentUIRequest request = mapper.readValue(requestString, DownPaymentUIRequest.class);
        AddDownPaymentUIResponse response = mapper.readValue(responseString, AddDownPaymentUIResponse.class);
        URI url = URI.create("http://localhost/add-downpayment");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.addDownPayment(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDownPayment(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void createLineTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"lines\":[{\"mtn\":\"3025451823\"}]}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-543157-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"showDevices\"},{\"path\":\"showAccessory\"},{\"path\":\"TradeIn\"},{\"path\":\"showFeatures\"},{\"path\":\"addDevice\"}]},\"customerInfo\":{\"registerNumber\":0,\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"cartInfo\":{\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\"},\"processMTNList\":[{\"mtn\":\"4235344191\",\"completedprocessSteps\":[\"\"]}]}}}}";
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLineUIResponse response = mapper.readValue(responseString, CreateLineUIResponse.class);
        URI url = URI.create("http://localhost/new-line");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.createLine(any())).thenReturn(Mono.just(response));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.createLine(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }


    @Test
    public void createLineBadRequestTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{}}";
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        URI url = URI.create("http://localhost/new-line");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.createLine(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void createLineErrorTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"lines\":[{\"mtn\":\"3025451823\"}]}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLineUIResponse response = mapper.readValue(responseString, CreateLineUIResponse.class);
        URI url = URI.create("http://localhost/new-line");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(cartHelper.createLine(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.createLine(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void updateDeviceSIMIdTest() throws IOException {
        String requestString = "{\"channelId\":\"123\",\"customerId\":\"123\",\"mtn\":\"6154839959\",\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\",\"caseId\":\"SOP-329-E01\",\"accountNumber\":\"0820215913-00001\",\"cartCreator\":\"6154839959\",\"processingMTN\":\"6154839959\"},\"data\":{\"lines\":[{\"mtn\":\"2059376950\",\"contractTerm\":\"12345\",\"device\":{\"id\":\"MN382LLA\",\"deviceId\":\"354441080447376\"},\"sim\":{\"id\":\"EMBD4GSIM-N\",\"simId\":\"89148000003715813858\",\"qty\":\"100000\",\"finalPrice\":\"50000\",\"itemPrice\":\"30000\",\"discountAmount\":\"20000\",\"iccid\":\"12321\"},\"plan\":{\"sorId\":\"1234\",\"price\":\"123\"}}]}}";
        String responseString = "{\"meta\": {\"timestamp\": \"2019-08-05T13:27:07Z\",\"cxpCorrelationId\": \"3d5f3c15-aa3b-4a42-9245-5cb4177468e4\"},\"data\": {\"cartId\": \"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\": \"Device Id and Sim ID updated successfully.\"}}";
        UpdateDeviceSIMIdUIRequest request = mapper.readValue(requestString, UpdateDeviceSIMIdUIRequest.class);
        UpdateDeviceSIMIdUIResponse response = mapper.readValue(responseString, UpdateDeviceSIMIdUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimId");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.updateDeviceSIMId(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.updateDeviceSIMId(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateDeviceSIMIdBadRequestTest() throws IOException {
        String requestString = "{\"channelId\":\"123\",\"customerId\":\"123\",\"mtn\":\"6154839959\",\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\",\"caseId\":\"SOP-329-E01\",\"accountNumber\":\"0820215913-00001\",\"cartCreator\":\"6154839959\",\"processingMTN\":\"6154839959\"},\"data\":{\"lines\":[{}]}}";
        UpdateDeviceSIMIdUIRequest request = mapper.readValue(requestString, UpdateDeviceSIMIdUIRequest.class);
        URI url = URI.create("http://localhost/deviceSimId");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.updateDeviceSIMId(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateDeviceSIMIdErrorTest() throws IOException {
        String requestString = "{\"channelId\":\"123\",\"customerId\":\"123\",\"mtn\":\"6154839959\",\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\",\"caseId\":\"SOP-329-E01\",\"accountNumber\":\"0820215913-00001\",\"cartCreator\":\"6154839959\",\"processingMTN\":\"6154839959\"},\"data\":{\"lines\":[{\"mtn\":\"2059376950\",\"contractTerm\":\"12345\",\"device\":{\"id\":\"MN382LLA\",\"deviceId\":\"354441080447376\"},\"sim\":{\"id\":\"EMBD4GSIM-N\",\"simId\":\"89148000003715813858\",\"qty\":\"100000\",\"finalPrice\":\"50000\",\"itemPrice\":\"30000\",\"discountAmount\":\"20000\",\"iccid\":\"12321\"},\"plan\":{\"sorId\":\"1234\",\"price\":\"123\"}}]}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        UpdateDeviceSIMIdUIRequest request = mapper.readValue(requestString, UpdateDeviceSIMIdUIRequest.class);
        UpdateDeviceSIMIdUIResponse response = mapper.readValue(responseString, UpdateDeviceSIMIdUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimId");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.updateDeviceSIMId(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.updateDeviceSIMId(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void numberShareTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"lines\":[{\"mtn\":\"3025451823\",\"trunkMtn\":\"5304529854\"}]}}";
        String responseString = "{\"serviceHeader\":    {\"clientId\": \"VZW-NETACE\",\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\"},\"serviceBody\": {\"serviceResponse\": {\"context\":    {}}}}";
        NumberShareUIRequest request = mapper.readValue(requestString, NumberShareUIRequest.class);
        NumberShareUIResponse response = mapper.readValue(responseString, NumberShareUIResponse.class);
        URI url = URI.create("http://localhost/number-share");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.numberShare(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.numberShare(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void numberShareBadRequestTest() throws IOException {
        String requestString = "{ \"cartInfo\": {}, \"data\": {  } }";
        NumberShareUIRequest request = mapper.readValue(requestString, NumberShareUIRequest.class);
        URI url = URI.create("http://localhost/number-share");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.numberShare(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();

    }

    @Test
    public void numberShareErrorTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"lines\":[{\"mtn\":\"3025451823\",\"trunkMtn\":\"5304529854\"}]}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        NumberShareUIRequest request = mapper.readValue(requestString, NumberShareUIRequest.class);
        NumberShareUIResponse response = mapper.readValue(responseString, NumberShareUIResponse.class);
        URI url = URI.create("http://localhost/number-share");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.numberShare(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.numberShare(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void addServiceAddressTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"8c9c03c9-016b-4145-93ad-3485872e46e4\",\"caseId\":\"SOP-644864-E01\",\"accountNumber\":\"0280000052-00001\",\"cartCreator\":\"3166481257\",\"processingMTN\":\"3166481257\",     \"processStep\": \"OrderReview-Shipping-Payment-Agreement\",     \"intendType\": \"EUP\"   },   \"data\": {     \"lines\": [       {         \"mtn\": \"3166481257\",         \"serviceAddress\": {           \"address\": {             \"aptNum\": \"214A\",             \"streetNum\": \"5701\",             \"streetName\": \"DURHAM CASTLE\",             \"type\": \"R\",             \"addressLine1\":\"8710 Bash Street\",             \"addressLine2\": \"Rambo Street\",             \"pobox\": \"\",             \"ruralDel\": \"\",             \"city\": \"INDIANAPOLIS\",             \"state\": \"IN\",             \"zipCode\": \"46250\",             \"zipCode4\": \"5627\",             \"country\": \"USA\",             \"fipsCode\": \"\",             \"firmName\": \"ABC EnterPrise\",             \"firstName\": \"Alex\",             \"lastName\": \"John\",             \"phoneNumber\": \"3166481257\",             \"emailId\": \"Alex.john@verizon.com\",             \"attention\": \"Service Manager\"           }         }       }     ]   } }";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-543157-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"showDevices\"},{\"path\":\"showAccessory\"},{\"path\":\"TradeIn\"},{\"path\":\"showFeatures\"},{\"path\":\"addDevice\"}]},\"customerInfo\":{\"registerNumber\":0,\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"cartInfo\":{\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\"},\"processMTNList\":[{\"mtn\":\"4235344191\",\"completedprocessSteps\":[\"\"]}]}}}}";
        ServiceAddressUIRequest request = mapper.readValue(requestString, ServiceAddressUIRequest.class);
        ServiceAddressUIResponse response = mapper.readValue(responseString, ServiceAddressUIResponse.class);
        URI url = URI.create("http://localhost/service-address");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.addServiceAddress(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addServiceAddress(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addServiceAddressBadRequestTest() throws IOException {
        String requestString = "{\"cartInfo\":{ },   \"data\": {     \"lines\": [       {         \"mtn\": \"3166481257\"       }     ]   } }";
        ServiceAddressUIRequest request = mapper.readValue(requestString, ServiceAddressUIRequest.class);
        URI url = URI.create("http://localhost/service-address");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addServiceAddress(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addServiceAddressErrorTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"8c9c03c9-016b-4145-93ad-3485872e46e4\",\"caseId\":\"SOP-644864-E01\",\"accountNumber\":\"0280000052-00001\",\"cartCreator\":\"3166481257\",\"processingMTN\":\"3166481257\",     \"processStep\": \"OrderReview-Shipping-Payment-Agreement\",     \"intendType\": \"EUP\"   },   \"data\": {     \"lines\": [       {         \"mtn\": \"3166481257\",         \"serviceAddress\": {           \"address\": {             \"aptNum\": \"214A\",             \"streetNum\": \"5701\",             \"streetName\": \"DURHAM CASTLE\",             \"type\": \"R\",             \"addressLine1\":\"8710 Bash Street\",             \"addressLine2\": \"Rambo Street\",             \"pobox\": \"\",             \"ruralDel\": \"\",             \"city\": \"INDIANAPOLIS\",             \"state\": \"IN\",             \"zipCode\": \"46250\",             \"zipCode4\": \"5627\",             \"country\": \"USA\",             \"fipsCode\": \"\",             \"firmName\": \"ABC EnterPrise\",             \"firstName\": \"Alex\",             \"lastName\": \"John\",             \"phoneNumber\": \"3166481257\",             \"emailId\": \"Alex.john@verizon.com\",             \"attention\": \"Service Manager\"           }         }       }     ]   } }";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        ServiceAddressUIRequest request = mapper.readValue(requestString, ServiceAddressUIRequest.class);
        ServiceAddressUIResponse response = mapper.readValue(responseString, ServiceAddressUIResponse.class);
        URI url = URI.create("http://localhost/service-address");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.addServiceAddress(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addServiceAddress(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void addBillingAddressTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"8c9c03c9-016b-4145-93ad-3485872e46e4\",\"caseId\":\"SOP-644864-E01\",\"accountNumber\":\"0280000052-00001\",\"cartCreator\":\"3166481257\",\"processingMTN\":\"3166481257\",     \"processStep\": \"OrderReview-Shipping-Payment-Agreement\",     \"intendType\": \"EUP\"   },   \"data\": {     \"lines\": [       {         \"mtn\": \"3166481257\",         \"billingAddress\": {           \"address\": {             \"aptNum\": \"214A\",             \"streetNum\": \"5701\",             \"streetName\": \"DURHAM CASTLE\",             \"type\": \"R\",             \"addressLine1\":\"8710 Bash Street\",             \"addressLine2\": \"Rambo Street\",             \"pobox\": \"\",             \"ruralDel\": \"\",             \"city\": \"INDIANAPOLIS\",             \"state\": \"IN\",             \"zipCode\": \"46250\",             \"zipCode4\": \"5627\",             \"country\": \"USA\",             \"fipsCode\": \"\",             \"firmName\": \"ABC EnterPrise\",             \"firstName\": \"Alex\",             \"lastName\": \"John\",             \"phoneNumber\": \"3166481257\",             \"emailId\": \"Alex.john@verizon.com\",             \"attention\": \"Service Manager\"           }         }       }     ]   } }";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-543157-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"showDevices\"},{\"path\":\"showAccessory\"},{\"path\":\"TradeIn\"},{\"path\":\"showFeatures\"},{\"path\":\"addDevice\"}]},\"customerInfo\":{\"registerNumber\":0,\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"cartInfo\":{\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\"},\"processMTNList\":[{\"mtn\":\"4235344191\",\"completedprocessSteps\":[\"\"]}]}}}}";
        BillingAddressUIRequest request = mapper.readValue(requestString, BillingAddressUIRequest.class);
        BillingAddressUIResponse response = mapper.readValue(responseString, BillingAddressUIResponse.class);
        URI url = URI.create("http://localhost/service-address");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.addBillingAddress(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addBillingAddress(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addBillingAddressBadRequestTest() throws IOException {
        String requestString = "{\"cartInfo\":{ },   \"data\": {     \"lines\": [       {         \"mtn\": \"3166481257\"       }     ]   } }";
        BillingAddressUIRequest request = mapper.readValue(requestString, BillingAddressUIRequest.class);
        URI url = URI.create("http://localhost/service-address");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addBillingAddress(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addBillingAddressErrorTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"8c9c03c9-016b-4145-93ad-3485872e46e4\",\"caseId\":\"SOP-644864-E01\",\"accountNumber\":\"0280000052-00001\",\"cartCreator\":\"3166481257\",\"processingMTN\":\"3166481257\",     \"processStep\": \"OrderReview-Shipping-Payment-Agreement\",     \"intendType\": \"EUP\"   },   \"data\": {     \"lines\": [       {         \"mtn\": \"3166481257\",         \"billingAddress\": {           \"address\": {             \"aptNum\": \"214A\",             \"streetNum\": \"5701\",             \"streetName\": \"DURHAM CASTLE\",             \"type\": \"R\",             \"addressLine1\":\"8710 Bash Street\",             \"addressLine2\": \"Rambo Street\",             \"pobox\": \"\",             \"ruralDel\": \"\",             \"city\": \"INDIANAPOLIS\",             \"state\": \"IN\",             \"zipCode\": \"46250\",             \"zipCode4\": \"5627\",             \"country\": \"USA\",             \"fipsCode\": \"\",             \"firmName\": \"ABC EnterPrise\",             \"firstName\": \"Alex\",             \"lastName\": \"John\",             \"phoneNumber\": \"3166481257\",             \"emailId\": \"Alex.john@verizon.com\",             \"attention\": \"Service Manager\"           }         }       }     ]   } }";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        BillingAddressUIRequest request = mapper.readValue(requestString, BillingAddressUIRequest.class);
        BillingAddressUIResponse response = mapper.readValue(responseString, BillingAddressUIResponse.class);
        URI url = URI.create("http://localhost/service-address");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.addBillingAddress(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addBillingAddress(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void addE911AddressTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"bf46b575-fc97-4d46-bd8b-da25031ceb6c\",\"caseId\":\"SOP-566674-E01\",\"accountNumber\":\"0689121143-00001\",\"cartCreator\":\"7657450260\",\"processingMTN\":\"7655706413\",\"processStep\":\"E911\",\"intendType\":\"EUP\"},\"data\":{\"lines\":[{\"mtn\":\"7657450260\",\"e911Address\":{\"address\":{\"aptNum\":\"\",\"streetNum\":\"200 South Street\",\"streetName\":\"\",\"type\":\"R\",\"addressLine2\":\"\",\"pobox\":\"\",\"ruralDel\":\"\",\"city\":\"MORRISTOWN\",\"state\":\"IN\",\"zipCode\":\"46161\",\"zipCode4\":\"9712\",\"country\":\"\",\"fipsCode\":\"\",\"firmName\":\"\",\"firstName\":\"JOSEPH\",\"lastName\":\"WRIGHT\",\"phoneNumber\":\"\",\"emailId\":\"\",\"attention\":\"\"}}}]}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-543157-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"showDevices\"},{\"path\":\"showAccessory\"},{\"path\":\"TradeIn\"},{\"path\":\"showFeatures\"},{\"path\":\"addDevice\"}]},\"customerInfo\":{\"registerNumber\":0,\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"cartInfo\":{\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\"},\"processMTNList\":[{\"mtn\":\"4235344191\",\"completedprocessSteps\":[\"\"]}]}}}}";
        E911AddressUIRequest request = mapper.readValue(requestString, E911AddressUIRequest.class);
        E911AddressUIResponse response = mapper.readValue(responseString, E911AddressUIResponse.class);
        URI url = URI.create("http://localhost/e911-address");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.addE911Address(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addE911Address(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addE911AddressBadRequestTest() throws IOException {
        String requestString = "{\"cartInfo\":{},\"data\":{\"lines\":[{\"mtn\":\"7657450260\"}]}}";
        E911AddressUIRequest request = mapper.readValue(requestString, E911AddressUIRequest.class);
        URI url = URI.create("http://localhost/e911-address");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url)
                .header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addE911Address(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addE911AddressErrorTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"bf46b575-fc97-4d46-bd8b-da25031ceb6c\",\"caseId\":\"SOP-566674-E01\",\"accountNumber\":\"0689121143-00001\",\"cartCreator\":\"7657450260\",\"processingMTN\":\"7655706413\",\"processStep\":\"E911\",\"intendType\":\"EUP\"},\"data\":{\"lines\":[{\"mtn\":\"7657450260\",\"e911Address\":{\"address\":{\"aptNum\":\"\",\"streetNum\":\"200 South Street\",\"streetName\":\"\",\"type\":\"R\",\"addressLine2\":\"\",\"pobox\":\"\",\"ruralDel\":\"\",\"city\":\"MORRISTOWN\",\"state\":\"IN\",\"zipCode\":\"46161\",\"zipCode4\":\"9712\",\"country\":\"\",\"fipsCode\":\"\",\"firmName\":\"\",\"firstName\":\"JOSEPH\",\"lastName\":\"WRIGHT\",\"phoneNumber\":\"\",\"emailId\":\"\",\"attention\":\"\"}}}]}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        E911AddressUIRequest request = mapper.readValue(requestString, E911AddressUIRequest.class);
        E911AddressUIResponse response = mapper.readValue(responseString, E911AddressUIResponse.class);
        URI url = URI.create("http://localhost/e911-address");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.addE911Address(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addE911Address(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void effectiveDateOverrideTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"intendTpye\":\"EUP/AAL\"},\"data\":{\"retrieveFeatureLossReferenceData\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"parentMtn\":\"\",\"managerId\":\"moramva\",\"password\":\"Tapsium@31\",\"lines\":[{\"mtn\":\"3369326289\"}]}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"PEGA generated message\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\" SAP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\",\"ShoppingCart\",\"CreditPage\"]},{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}],\"cartInfo\":{\"cartId\":\"69a66ef4d-7e344dfb-2db299209-ea8333\",\"lines\":[{\"mtn\":\"9207400273\",\"lineId\":\"9207400273\",\"status\":1,\"planValidationFailed\":false,\"errors\":[],\"activationDate\":null,\"activateLaterInd\":false,\"legalDisclosure\":null,\"plan\":{\"sorId\":\"97928\",\"price\":null,\"discountsResponse\":null},\"showInsurancePage\":false}],\"status\":1,\"effectiveDateDetails\":{\"isOnDemandAllowed\":true,\"isBackDateAllowed\":true,\"isFutureDateAllowed\":true,\"suggestedBackDate\":\"07/01/2019\",\"suggestedFutureDate\":\"08/01/2019\",\"currentBillCycleBeginDate\":\"08/26/2019\",\"nextBillCycleBeginDate\":\"09/26/2019\"},\"autoServiceValidationEnabled\":true}}},\"contextInfo\":{\"processAction\":\"\",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Interim\",\"availablePaths\":[{\"path\":\"Interim\"}]}}}";
        EffectiveDateOverrideUIRequest request = mapper.readValue(requestString, EffectiveDateOverrideUIRequest.class);
        EffectiveDateOverrideUIResponse response = mapper.readValue(responseString,
                EffectiveDateOverrideUIResponse.class);
        URI url = URI.create("http://localhost/effectiveDateOverride");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.effectiveDateOverride(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.effectiveDateOverride(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void effectiveDateOverrideBadRequestTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"intendTpye\":\"EUP/AAL\"},\"data\":{\"retrieveFeatureLossReferenceData\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"parentMtn\":\"\",\"managerId\":\"moramva\",\"password\":\"Tapsium@31\"}}";
        EffectiveDateOverrideUIRequest request = mapper.readValue(requestString, EffectiveDateOverrideUIRequest.class);
        URI url = URI.create("http://localhost/effectiveDateOverride");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-TELESALES").build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.effectiveDateOverride(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void effectiveDateOverrideErrorTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"intendTpye\":\"EUP/AAL\"},\"data\":{\"retrieveFeatureLossReferenceData\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"parentMtn\":\"\",\"managerId\":\"moramva\",\"password\":\"Tapsium@31\",\"lines\":[{\"mtn\":\"3369326289\"}]}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        EffectiveDateOverrideUIRequest request = mapper.readValue(requestString, EffectiveDateOverrideUIRequest.class);
        EffectiveDateOverrideUIResponse response = mapper.readValue(responseString,
                EffectiveDateOverrideUIResponse.class);
        URI url = URI.create("http://localhost/effectiveDateOverride");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.effectiveDateOverride(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.effectiveDateOverride(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void effectiveDateOverrideErrorTest2() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"intendTpye\":\"EUP/AAL\"},\"data\":{\"retrieveFeatureLossReferenceData\":\"\",\"checkAutoPayDiscountEligible\":\"N\",\"parentMtn\":\"\",\"managerId\":\"moramva\",\"password\":\"Tapsium@31\",\"lines\":[{\"mtn\":\"3369326289\"}]}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        EffectiveDateOverrideUIRequest request = mapper.readValue(requestString, EffectiveDateOverrideUIRequest.class);
        EffectiveDateOverrideUIResponse response = mapper.readValue(responseString,
                EffectiveDateOverrideUIResponse.class);
        URI url = URI.create("http://localhost/effectiveDateOverride");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.valueOf(500));
        when(cartHelper.effectiveDateOverride(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.effectiveDateOverride(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }


    @Test
    public void addInstantCreditDownPaymentTest() throws IOException {
        String requestString = "{     \"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"5ce6fc70-0885-4c2e-a298-1f9d49529b7c\",\"caseId\":\"SOP-608091-E01\",\"accountNumber\":\"0280000052-00001\",\"cartCreator\":\"3166481257\",\"processingMTN\":\"newLine1\",          \"processStep\": \"MTNSelectionPage\",          \"intendType\": \"AAL\"       },     \"data\": {         \"lines\": [             {                 \"mtn\": \"newLine1\",                 \"amount\": -40             }                     ]     } }";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{}}}";
        InstantCreditDownPaymentUIRequest request = mapper.readValue(requestString,
                InstantCreditDownPaymentUIRequest.class);
        InstantCreditDownPaymentUIResponse response = mapper.readValue(responseString,
                InstantCreditDownPaymentUIResponse.class);
        URI url = URI.create("http://localhost/instant-credit-downPayment");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.addInstantCreditDownPayment(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController
                .addInstantCreditDownPayment(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }
    @Test
    public void addInstantCreditDownPaymentBadRequestTest() throws IOException {
        String requestString = "{     \"cartInfo\":{},     \"data\": {         \"lines\": [             {                 \"mtn\": \"\",                 \"amount\": -40             }                     ]     } }";
        InstantCreditDownPaymentUIRequest request = mapper.readValue(requestString,
                InstantCreditDownPaymentUIRequest.class);
        URI url = URI.create("http://localhost/instant-credit-downPayment");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController
                .addInstantCreditDownPayment(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addInstantCreditDownPaymentErrorTest() throws IOException {
        String requestString = "{     \"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"5ce6fc70-0885-4c2e-a298-1f9d49529b7c\",\"caseId\":\"SOP-608091-E01\",\"accountNumber\":\"0280000052-00001\",\"cartCreator\":\"3166481257\",\"processingMTN\":\"newLine1\",          \"processStep\": \"MTNSelectionPage\",          \"intendType\": \"AAL\"       },     \"data\": {         \"lines\": [             {                 \"mtn\": \"newLine1\",                 \"amount\": -40             }                     ]     } }";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        InstantCreditDownPaymentUIRequest request = mapper.readValue(requestString,
                InstantCreditDownPaymentUIRequest.class);
        InstantCreditDownPaymentUIResponse response = mapper.readValue(responseString,
                InstantCreditDownPaymentUIResponse.class);
        URI url = URI.create("http://localhost/instant-credit-downPayment");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.addInstantCreditDownPayment(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController
                .addInstantCreditDownPayment(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }
    @Test
    public void addServiceAddressDigitalChannelTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"0280000052-00001\",\"cartCreator\":\"3166481257\",\"processingMTN\":\"3166481257\",     \"processStep\": \"OrderReview-Shipping-Payment-Agreement\",     \"intendType\": \"EUP\"   },   \"data\": {     \"lines\": [       {         \"mtn\": \"3166481257\",         \"serviceAddress\": {           \"address\": {             \"aptNum\": \"214A\",             \"streetNum\": \"5701\",             \"streetName\": \"DURHAM CASTLE\",             \"type\": \"R\",             \"addressLine1\":\"8710 Bash Street\",             \"addressLine2\": \"Rambo Street\",             \"pobox\": \"\",             \"ruralDel\": \"\",             \"city\": \"INDIANAPOLIS\",             \"state\": \"IN\",             \"zipCode\": \"46250\",             \"zipCode4\": \"5627\",             \"country\": \"USA\",             \"fipsCode\": \"\",             \"firmName\": \"ABC EnterPrise\",             \"firstName\": \"Alex\",             \"lastName\": \"John\",             \"phoneNumber\": \"3166481257\",             \"emailId\": \"Alex.john@verizon.com\",             \"attention\": \"Service Manager\"           }         }       }     ]   } }";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"showDevices\"},{\"path\":\"showAccessory\"},{\"path\":\"TradeIn\"},{\"path\":\"showFeatures\"},{\"path\":\"addDevice\"}]},\"customerInfo\":{\"registerNumber\":0,\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"cartInfo\":{\"cartId\":\"\"},\"processMTNList\":[{\"mtn\":\"4235344191\",\"completedprocessSteps\":[\"\"]}]}}}}";
        ServiceAddressUIRequest request = mapper.readValue(requestString, ServiceAddressUIRequest.class);
        ServiceAddressUIResponse response = mapper.readValue(responseString, ServiceAddressUIResponse.class);
        URI url = URI.create("http://localhost/service-address");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.addServiceAddress(any())).thenReturn(Mono.just(response));
        response.getServiceBody().getServiceResponse().getContext().setCaseId(null);
        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartId(null);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addServiceAddress(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addPlanTestForAIQuote() throws IOException {
        String requestString = "{\"channelId\":\"OMNI-RETAIL\",\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"4aa9765a-917b-4804-bcf5-75f7c2d49620\",\"caseId\":\"SOP-607536-E01\",\"accountNumber\":\"0825637535-00001\",\"cartCreator\":\"9106517716\",\"processingMTN\":\"9106517716\",\"processStep\":\"PlanSelection\",\"intendType\":\"CPC\"},\"data\":{\"lines\":[{\"mtn\":\"9106359416\",\"plan\":{\"id\":\"18045\"}}]}}";

        String responseString = sourceFileReaderUtil.readFile("data/addTaggingAI/AddPlanPegaResponse.json", testFileLocation);
        AddPlanUIRequest request = mapper.readValue(requestString, AddPlanUIRequest.class);
        AddPlanUIResponse response = mapper.readValue(responseString, AddPlanUIResponse.class);
        URI url = URI.create("http://localhost/add-plan");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").header("flowname","AIQuote").build();
        ServerHttpResponse httpResponse = null;
        when(cartHelper.addPlan(any())).thenReturn(Mono.just(response));
        when(redisHelper2.updateCartOrderFlowType("cpc")).thenReturn(Mono.just(true));
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just("eup"));
        when(redisHelper2.getPlanPathDetails()).thenReturn(Mono.just(new HashMap()));
        when(redisHelper.updateSPOsIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(false));
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addPlan(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        url = URI.create("http://localhost/flexV2/add-plan");
        httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").header("flowname","AIQuote").build();
        controllerResponse = cartController.addPlan(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addBuyoutTestForAIQuote() throws IOException {
        String requestString = sourceFileReaderUtil.readFile("data/addTaggingAI/AddBuyoutUIRequest.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/addTaggingAI/AddBuyoutPegaResponse.json", testFileLocation);
        AddBuyoutUIRequest request = mapper.readValue(requestString, AddBuyoutUIRequest.class);
        AddBuyoutUIResponse response = mapper.readValue(responseString, AddBuyoutUIResponse.class);
        URI url = URI.create("http://localhost/add-buyout");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").header("flowname","AIQuote").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.CONTINUE);
        when(cartHelper.addBuyout(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addBuyout(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addAccessoryTestForAIQuote() throws IOException {
        String requestString = sourceFileReaderUtil.readFile("data/addTaggingAI/AddAccessoryUIRequest.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/addTaggingAI/AddAccessoryPegaResponse.json", testFileLocation);
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/add-accessories");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").header("flowname","AIQuote").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","cdlThrottleList").build());
        when(accHelper.addAccessory(any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(false);
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put("cartCount","1");
        redisData.put("cartOrderFlowType","eup");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addFeaturesTestForAIQuote() throws IOException {
        String requestString = sourceFileReaderUtil.readFile("data/addTaggingAI/AddFeaturesUIRequest.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/addTaggingAI/AddFeaturesPegaResponse.json", testFileLocation);
        AddFeaturesUIRequest request = mapper.readValue(requestString, AddFeaturesUIRequest.class);
        AddFeaturesUIResponse response = mapper.readValue(responseString, AddFeaturesUIResponse.class);
        when(redisHelper.getAddFeaturesRequest()).thenReturn(Mono.just(request));
        URI url = URI.create("http://localhost/add-features");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url)
                .header("channelId", "OMNI-RETAIL")
                .header("flowname","AIQuote")
                .header("Referer","new/aiquote.html").build();
        ServerHttpResponse httpResponse =  new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.addFeatures(any())).thenReturn(Mono.just(response));
        when(cartHelper.populateProtectionVersion(Mockito.any(),Mockito.any())).
                thenReturn(Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(response)));
        when(cartHelper.populateSPOsFor5GBolt(Mockito.any(),Mockito.any()))
                .thenReturn(Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(response)));
        when(cartHelper.populateHumWifiConflictedSFos(Mockito.any(),Mockito.any())).thenReturn(
                Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(response)));
        when(cartHelper.updateFlowNameForAssisted(Mockito.any(),Mockito.any())).thenReturn(
                Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(response)));
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));

        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addFeatures(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateSessionForFlowNameTest() {
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(), Mockito.any())).thenReturn(Mono.just("AAL"));
        StepVerifier.create(cartController3.updateSessionForFlowName(null,new CreateLineUIResponse())).assertNext(Assert::assertNotNull).expectComplete().verify();
        StepVerifier.create(cartController3.updateSessionForFlowName(new CreateLineUIRequest(),new CreateLineUIResponse())).assertNext(Assert::assertNotNull).expectComplete().verify();

        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(false));
        StepVerifier.create(cartController3.updateSessionForFlowName(new CreateLineUIRequest(),new CreateLineUIResponse())).assertNext(Assert::assertNotNull).expectComplete().verify();

        CreateLineUIRequest request= new CreateLineUIRequest();
        request.setChannelId(null);
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        StepVerifier.create(cartController3.updateSessionForFlowName(request,new CreateLineUIResponse())).assertNext(Assert::assertNotNull).expectComplete().verify();

        request.setChannelId("");
        StepVerifier.create(cartController3.updateSessionForFlowName(request,new CreateLineUIResponse())).assertNext(Assert::assertNotNull).expectComplete().verify();

        request.setChannelId(CartConstants.VZW_DOTCOM);
        StepVerifier.create(cartController3.updateSessionForFlowName(request,new CreateLineUIResponse())).assertNext(Assert::assertNotNull).expectComplete().verify();

        request.setChannelId(CartConstants.RETAIL);
        StepVerifier.create(cartController3.updateSessionForFlowName(request,new CreateLineUIResponse())).assertNext(Assert::assertNotNull).expectComplete().verify();

        CreateLineUIResponse resp= new CreateLineUIResponse();
        resp.setServiceBody(new CreateLineServiceBody());
        StepVerifier.create(cartController3.updateSessionForFlowName(request,resp)).assertNext(Assert::assertNotNull).expectComplete().verify();
        resp.getServiceBody().setServiceResponse(new CreateLineServiceResponse());
        StepVerifier.create(cartController3.updateSessionForFlowName(request,resp)).assertNext(Assert::assertNotNull).expectComplete().verify();
        resp.getServiceBody().getServiceResponse().setContext(new CreateLineContext());
        StepVerifier.create(cartController3.updateSessionForFlowName(request,resp)).assertNext(Assert::assertNotNull).expectComplete().verify();
        resp.getServiceBody().getServiceResponse().getContext().setCartInfo(new CartServiceCartInfo());
        StepVerifier.create(cartController3.updateSessionForFlowName(request,resp)).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void addPlanTest_tagging() throws IOException {
        String requestString = "{\"channelId\":\"OMNI-RETAIL\",\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"4aa9765a-917b-4804-bcf5-75f7c2d49620\",\"caseId\":\"SOP-607536-E01\",\"accountNumber\":\"0825637535-00001\",\"cartCreator\":\"9106517716\",\"processingMTN\":\"9106517716\",\"processStep\":\"PlanSelection\",\"intendType\":\"CPC\"},\"data\":{\"lines\":[{\"mtn\":\"9106359416\",\"plan\":{\"id\":\"18045\"}}]}}";
        String responseString ="{\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \"SOP-334914702-W01\",\"contextInfo\": {\"callReason\": \"SalesOrderPurchase\",\"processStep\": \"ShoppingCart\",\"processAction\": \"\",\"availablePaths\": [{\"path\": \"ShoppingCart\"}]},\"customerInfo\": {\"accountNumber\": \"0789166749-00001\",\"cartCreator\": \"8125825035\",\"processingMTN\": \"8125825035\",\"registerNumber\": 0},\"cartInfo\": {\"tabletJetpackDiscountMultiLineLoss\": \"N\",\"cartItemCount\": 0,\"cartId\": \"ff70cbb7-096d-4580-8f9c-8206250ab95a\",\"statusMsg\": \"Success\",\"statusCode\": \"1\",\"lines\": [{\"plan\": {\"id\": \"39385\",\"price\": \"80.00\",\"isRecommendedPlan\": false},\"status\": 1,\"isFreeAppleMusicLoss\": \"N\",\"spos\": [{\"id\": \"671\",\"actionIndicator\": \"D\",\"success\": true,\"description\": \"Carryover Data\",\"is5GBolt\": false},{\"id\": \"672\",\"actionIndicator\": \"D\",\"success\": true,\"description\": \"Safety Mode\",\"is5GBolt\": false},{\"id\": \"975\",\"actionIndicator\": \"D\",\"success\": true,\"description\": \"AutoPay and Paper-Free Discount\",\"is5GBolt\": false},{\"id\": \"1708\",\"actionIndicator\": \"Z\",\"success\": true,\"description\": \"COVID IMPACTED INDICATOR\",\"is5GBolt\": false},{\"id\": \"1247\",\"actionIndicator\": \"A\",\"success\": true,\"description\": \"Auto Pay / Paper-free Discount Included\",\"is5GBolt\": false},{\"id\": \"1678\",\"actionIndicator\": \"A\",\"success\": true,\"description\": \"$10 Teachers Discount\",\"is5GBolt\": false},{\"id\": \"1747\",\"actionIndicator\": \"A\",\"success\": true,\"description\": \"Disney Bundle Included with Plan\",\"is5GBolt\": false},{\"id\": \"1802\",\"actionIndicator\": \"D\",\"success\": true,\"description\": \"Metered Plan Indicator\",\"is5GBolt\": false},{\"id\": \"1692\",\"actionIndicator\": \"Z\",\"success\": true,\"description\": \"5G Dynamic Spectrum Sharing\",\"is5GBolt\": false},{\"id\": \"732\",\"actionIndicator\": \"A\",\"success\": true,\"description\": \"CDMA-LESS ROAM TIER OVERRIDE\",\"is5GBolt\": false},{\"id\": \"1256\",\"actionIndicator\": \"A\",\"success\": true,\"description\": \"Includes Mexico & Canada with your domestic plan\",\"is5GBolt\": false},{\"id\": \"1552\",\"actionIndicator\": \"A\",\"success\": true,\"description\": \"5G Ultra Wideband Access\",\"is5GBolt\": false},{\"id\": \"1578\",\"actionIndicator\": \"A\",\"success\": true,\"description\": \"5G Ultra Wideband Trigger\",\"is5GBolt\": false},{\"id\": \"1741\",\"actionIndicator\": \"A\",\"success\": true,\"description\": \"5G Ultra Wideband Provisioning\",\"is5GBolt\": false},{\"id\": \"1801\",\"actionIndicator\": \"A\",\"success\": true,\"description\": \"Unlimited Plan Indicator\",\"is5GBolt\": false},{\"id\": \"1958\",\"actionIndicator\": \"A\",\"success\": true,\"description\": \"Device Set-Up Support 60 Days\",\"is5GBolt\": false}],\"sfos\": [{\"id\": \"48526\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Text Messaging Pay Per Message\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"48553\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Streamlined Billing\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"66332\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"Y\",\"description\": \"Decline Device Protection\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"68869\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Caller ID\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"68870\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"BUSY TRANSFER\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"68871\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Conference Calling\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"68872\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"CALL DELIVERY\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"68873\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Call Waiting\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"68874\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"No Answer / Busy Transfer\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"68876\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Call Forwarding\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"73502\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"Unlimited Picture and Video Messaging\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"73503\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"Unlimited Text Messages\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"74774\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"SDM REMOTE QUERY ENABLED\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"75440\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Block Web Purchases\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"75632\",\"actionIndicator\": \"D\",\"customerAddedInd\": \"N\",\"description\": \"Data Usage USA & Canada\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"75706\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Pay Per Message\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"75802\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Dynamic-Private IP\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"75836\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"4G INTERNET ACCESS\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"75837\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"4G APPLICATION ACCESS\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"76152\",\"actionIndicator\": \"D\",\"customerAddedInd\": \"N\",\"description\": \"PICTURE MESSAGE PROVISIONING\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"76404\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"4G Mobile Hotspot Provisioning\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"76600\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"SHARE NAME ID\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"77249\",\"actionIndicator\": \"D\",\"customerAddedInd\": \"N\",\"description\": \"MOBILE HOT SPOT TRIGGER $0\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"77556\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"4G PROVISIONING $0\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"77568\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"EMAIL ACCESS PDA $0\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"77581\",\"actionIndicator\": \"D\",\"customerAddedInd\": \"N\",\"description\": \"EMAIL TRIGGER ALP $0\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"77583\",\"actionIndicator\": \"D\",\"customerAddedInd\": \"N\",\"description\": \"DATA PROVISION ALP\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"77885\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Integrated Messaging\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"78706\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"ENHANCED ADDRESS BOOK\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"78707\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Video Calling\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"78734\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Premium Visual Voice Mail with Voice Mail to Text\",\"price\": \"2.99\",\"displayHumWiFi\": false},{\"id\": \"80148\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"International Messages While in US\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"81158\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"HD Voice\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"82417\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Integrated Calling\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"82419\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Access Wi-fi Calling\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"83439\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"Call Filter Plus\",\"price\": \"2.99\",\"displayHumWiFi\": false},{\"id\": \"83856\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"CDMA-LESS DEVICE PROVISIONING\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"84015\",\"actionIndicator\": \"D\",\"customerAddedInd\": \"N\",\"description\": \"Smartphone - Line Access\",\"price\": \"20.00\",\"displayHumWiFi\": false},{\"id\": \"84071\",\"actionIndicator\": \"D\",\"customerAddedInd\": \"N\",\"description\": \"RTR for Carryover Data\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"84076\",\"actionIndicator\": \"D\",\"customerAddedInd\": \"N\",\"description\": \"Provision Entitlement Services\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"84077\",\"actionIndicator\": \"D\",\"customerAddedInd\": \"N\",\"description\": \"RTR Service Trigger\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"84094\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"International Services Enabled Lite\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"85405\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"Entitlement for Unlimited\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"85553\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"Verizon Cloud Eligible\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"86189\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"Email and Web\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"86198\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"Mobile Hotspot 15GB\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"86209\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"Include Mexico & Canada in your domestic plan\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"86225\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"AUTO CONFIGURATION $0\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"86848\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"4G SERVICE ON 5G DEVICE\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"86905\",\"actionIndicator\": \"Z\",\"customerAddedInd\": \"N\",\"description\": \"GSM Roaming Priority\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"87953\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"RTR / UC Trigger Play More\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"87956\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"RTR Play More Unlimited\",\"price\": \"0.00\",\"displayHumWiFi\": false},{\"id\": \"87959\",\"actionIndicator\": \"A\",\"customerAddedInd\": \"N\",\"description\": \"Entitlement Trigger\",\"price\": \"0.00\",\"displayHumWiFi\": false}],\"pairingInfo\": {},\"featureMessages\": [{\"name\": \"VERIZON_CLOUD_DISCOUNT\",\"action\": \"ADD\"},{\"name\": \"5GUWBBOLT\",\"action\": \"ADD\"}],\"firstMonthInstallment\": 40.28,\"monthlyInstallment\": 39.99,\"tabletJetpackDiscountLoss\": \"N\",\"reasonCode\": \"PLAN_DEVICE_COMPATIBLE\",\"mtn\": \"8125825035\",\"devicePlanCompatible\": true,\"planValidationFailed\": false,\"currentPlanType\": \"LLP\",\"planQualifiedForPromotion\": false,\"fiveGUpSell\": false,\"is5GBoltEligible\": false,\"disqualifiedPropositions\": [],\"qualifiedPropositions\": [],\"fiveGPlanAdded\": true,\"editSim\": false,\"lineWithSkipMDN\": false,\"inWithVerizonOpted\": false,\"protectionNotRequired\": false}],\"expressCheckout\": false,\"effectiveDateDetails\": {\"isOnDemandAllowed\": false,\"isBackDateAllowed\": true,\"isFutureDateAllowed\": true,\"suggestedBackDate\": \"11/12/2021\",\"suggestedFutureDate\": \"12/12/2021\",\"currentBillCycleBeginDate\": \"11/12/2021\",\"nextBillCycleBeginDate\": \"12/12/2021\",\"onDemandDate\": \"\",\"onDemandRangeInDays\": \"45\"},\"autoPayEnrollmentDetails\": {\"isAutoPayEnrolled\": \"Y\",\"isPaperLessEnrolled\": \"Y\",\"isAutoPayPaperLessDiscountEligible\": \"N\"},\"planChangeWarningMessages\": [{\"warningMessageCode\": \"ECPD_DISCOUNT_NOT_CARRY_OVER_KEY\"},{\"warningMessageCode\": \"FIVEG_PLAN_CHANGE_WARNING\",\"warningMessage\": \"WARNING - This change will disconnect active voice and data sessions. Before processing, ensure that you address all concerns first. Advise the customer to power cycle their device(s) after the change to enjoy the benefits of their new plan.\"}],\"discountPromoTotal\": 0.0,\"registerNumber\": 0,\"protectionNotRequired\": false},\"processMTNList\": [{\"mtn\": \"8125825035\",\"completedprocessSteps\": [\"MTNSelectionPage\",\"GridWallPDP\",\"PlanSelection\"]}]}}},\"serviceHeader\": {\"clientId\": \"CHAT-STORE\",\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"soe-cart-2021.11.12.05.37.20-328.4184785081927\"}}";
        AddPlanUIRequest request = mapper.readValue(requestString, AddPlanUIRequest.class);
        AddPlanUIResponse response = mapper.readValue(responseString, AddPlanUIResponse.class);
        URI url = URI.create("http://localhost/add-plan");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", CartConstants.RETAIL).cookie(new HttpCookie(CartConstants.ASSISTED_IG_SESSION_ID,"assisted1")).build();
        ServerHttpResponse httpResponse = null;
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(cartHelper.addPlan(any())).thenReturn(Mono.just(response));
        when(redisHelper2.updateCartOrderFlowType("cpc")).thenReturn(Mono.just(true));
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just("eup"));
        when(redisHelper2.getPlanPathDetails()).thenReturn(Mono.just(new HashMap()));
        when(redisHelper.updateSPOsIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));
        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addPlan(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        when(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag()).thenReturn(Mono.error(new RuntimeException("Failed to fetch flag")));
        Mono<ResponseEntity<GenericResponse>> controllerResponse1 = cartController.addPlan(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse1).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

    }


}
