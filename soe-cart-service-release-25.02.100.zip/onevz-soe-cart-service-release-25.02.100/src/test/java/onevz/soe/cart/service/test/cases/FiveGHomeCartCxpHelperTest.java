package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.cxp.helper.FiveGHomeCartCxpHelper;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.model.retrieveCart.CXPRetrieveCartDataVO;
import onevz.soe.cart.requests.*;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.exception.SOEError;
import onevz.soe.exception.SOEErrorHolder;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.*;
import static reactor.core.publisher.Mono.just;


@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { CartServiceTestConfig.class })
//@WebFluxTest(FiveGHomeCartCxpHelper.class)
public class FiveGHomeCartCxpHelperTest {

	private static final Logger logger = LoggerFactory.getLogger(FiveGHomeCartCxpHelperTest.class);

	@MockBean
	private CartServiceCXPServices cxpService;

	@MockBean
	private CartServiceCxpHelper cartServiceCxpHelper;

	@Autowired
	private FiveGHomeCartCxpHelper cxpHelper;

	@Autowired
	private ObjectMapper mapper;


	@Test
	public void retrieve5GMoversCartTest() throws IOException {
		String sampleResponseString = "{\"meta\":{\"timestamp\":\"1665898851282\",\"cxpCorrelationId\":\"2022-10-16T05:40:51.+0000:abf808686a6a284:cxp-shopping-services-qa-ev6v-sit3e-nscxp-785d644b94-5dlqf:nssit3\"},\"data\":{\"cart\":{\"customerProfile\":{},\"orderDetails\":{\"totalUpgradeFee\":0,\"totalDeviceDollar\":0,\"totalRemainingDeviceDollar\":0,\"totalUsedDeviceDollar\":0,\"totalAccountLevelAccCost\":0,\"totalAccountLevelAccCostWithTax\":0,\"verizonCardPromoOfferList\":[],\"taxDetailsList\":[],\"subTotalDueTodayWithoutUpgradeFee\":0,\"subTotalDueMonthlyForAALBYODEUP\":0,\"shipTogetherPref\":true,\"assistanceOptedByCustomer\":false,\"httpHeaders\":\"{\\\"channelid\\\":\\\"VZW-DOTCOM\\\",\\\"originatingClientIp\\\":\\\"10.11.65.244\\\",\\\"sessionId\\\":\\\"POE-D-77a17513-cc54-46d4-8d70-3ae1e778263e\\\",\\\"User-Agent\\\":\\\"Apache-HttpClient/4.5.13 (Java/1.8.0_342-342)\\\"}\",\"totalVerizonDollarUsed\":\"0.0\",\"isShellAccountSelected\":true,\"accountCreateDate\":\"\",\"existingSpeed\":\"\",\"guestOrInactiveRefundLines\":false,\"totalDueMonthlyOnProfile\":0,\"subTotalDueMonthlyOnProfile\":0,\"totalMonthlyTaxesOnProfile\":0,\"subTotalOtherLinesOnProfile\":0,\"estimatedNextMonthChargeOnProfile\":0,\"totalDueMonthlyAfterDiscounts\":0,\"totalActivationFees\":0,\"remainingAmountAfterAffirmApplied\":0,\"orderType\":\"PS\",\"locationCode\":\"N832101\",\"customerType\":\"N\",\"billingSystem\":\"VN\",\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CA CVAS AUTOMATIC APPROVAL\",\"securityDepositAmount\":\"0.0\",\"totalTaxAmount\":\"0.0\",\"totalDueToday\":0,\"totalDueMonthly\":0,\"subTotalDueMonthly\":0,\"subTotalDueToday\":0,\"subTotalMonthlyTaxes\":0,\"estimatedNextMonthCharge\":0,\"totalMonthlyTaxes\":0,\"subTotalOtherLines\":0,\"subTotalOtherLinesTaxes\":0,\"instantDRCCredit\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0,\"orderChannelId\":\"VZW-DOTCOM\",\"orderList\":[],\"outletId\":\"124642\",\"registerNumber\":\"0\",\"saleType\":\"P\",\"salesRepId\":\"NPB2C\",\"enableSplitShipment\":false,\"splitShipmentIndicator\":false,\"cartReadyForCheckout\":true,\"isSingleModConnectedDevice\":false,\"fiveGUpSellAccountLevel\":false,\"customerOnTrialPlan\":false,\"availableSlotsForGrantee\":\"0\",\"totalDownPaymentAmt\":0,\"totalEdgeBuyOutAmount\":0,\"expressCheckout\":false,\"isEQPandPPLOfferApplied\":false,\"cartTotalDiscounts\":{\"totalDiscount\":\"0.0\",\"discountDetails\":[]},\"memberTotalDueToday\":0,\"eligible5GHomeBundle\":[{\"bundleName\":\"5GHomeGeminiSelfSetup\",\"id\":\"16900001\"},{\"bundleName\":\"5GHomeGeminiProfSetup\",\"id\":\"16900002\"}],\"totalDwosCost\":\"0.0\",\"billingState\":\"MI\",\"isTradeInOfferSelected\":false},\"lineDetails\":{\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"NSE_5G\",\"totalDueToday\":0,\"totalDueTodayWithoutTax\":0,\"totalDueMonthly\":60,\"mobileNumber\":\"newLine1\",\"serviceInfo\":{\"pairingInfo\":{},\"moversInfo\":{\"moveOutDate\":\"20220907\"},\"planDiscount\":{\"planEligibleForAutoPayPaperLessDiscount\":true,\"eligibleAutoPayPaperlessDiscount\":\"10.0\",\"discountIncluded\":false,\"totalPlanCostIncludingLineAccessFee\":\"60.0\"},\"otherPromotions\":[],\"primaryUserInfo\":{\"firstName\":\"FIRSTNAME\",\"lastName\":\"LASTNAME\",\"address\":{\"type\":\"ST\",\"streetNumber\":\"28820\",\"streetName\":\"BEECHWOOD\",\"addressLine1\":\"28820 BEECHWOOD ST\",\"city\":\"GARDEN CITY\",\"state\":\"MI\",\"zipCode\":\"48135\",\"zipCode4\":\"2439\",\"county\":\"\",\"countryCode\":\"US\",\"fipsCode\":\"2616331420\",\"firstName\":\"FIRSTNAME\",\"lastName\":\"LASTNAME\",\"emailId\":\"CxT.Digital.Regression@verizon.com\",\"phoneNumber\":\"7777777779\",\"attention\":\"FIRSTNAME LASTNAME\"},\"attention\":\"FIRSTNAME LASTNAME\",\"contactPersonPhone\":\"7777777779\",\"emailId\":\"CxT.Digital.Regression@verizon.com\"},\"cart5GAddress\":{\"streetNumber\":\"28820\",\"streetName\":\"BEECHWOOD\",\"addressLine1\":\"28820 BEECHWOOD ST\",\"city\":\"GARDEN CITY\",\"state\":\"MI\",\"zipCode\":\"48135\",\"zipCode4\":\"\",\"countryCode\":\"\",\"fipsCode\":\"2616331420\",\"emailId\":\"\",\"streetType\":\"ST\",\"floor\":0,\"eventCorrelationId\":\"48135_1665898553541_256\"}}}]},\"accountEligibility\":false}}}";


		RetrieveCartCXPResponse sampleCXPResponse = null;
		sampleCXPResponse = mapper.readValue(sampleResponseString, RetrieveCartCXPResponse.class);
		RetrieveCartCXPRequest request = new RetrieveCartCXPRequest();
		CXPRetrieveCartDataVO data = new CXPRetrieveCartDataVO();
		data.setCartId("1235447");
		request.setData(data);
		when(cxpService.retrieve5GMoversCart(Mockito.any())).thenReturn(just(sampleCXPResponse));
		Mono<RetrieveCartCXPResponse> UIResponse = cxpHelper.retrieve5GMoversCart(request);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete()
				.verify();

	}
	@Test
	public void retrieve5GMoversCartTest1() throws IOException {
		String sampleResponseString = "{\"meta\":{\"timestamp\":\"1665898851282\",\"cxpCorrelationId\":\"2022-10-16T05:40:51.+0000:abf808686a6a284:cxp-shopping-services-qa-ev6v-sit3e-nscxp-785d644b94-5dlqf:nssit3\"},\"data\":{\"cart\":{\"customerProfile\":{},\"orderDetails\":{\"totalUpgradeFee\":0,\"totalDeviceDollar\":0,\"totalRemainingDeviceDollar\":0,\"totalUsedDeviceDollar\":0,\"totalAccountLevelAccCost\":0,\"totalAccountLevelAccCostWithTax\":0,\"verizonCardPromoOfferList\":[],\"taxDetailsList\":[],\"subTotalDueTodayWithoutUpgradeFee\":0,\"subTotalDueMonthlyForAALBYODEUP\":0,\"shipTogetherPref\":true,\"assistanceOptedByCustomer\":false,\"httpHeaders\":\"{\\\"channelid\\\":\\\"VZW-DOTCOM\\\",\\\"originatingClientIp\\\":\\\"10.11.65.244\\\",\\\"sessionId\\\":\\\"POE-D-77a17513-cc54-46d4-8d70-3ae1e778263e\\\",\\\"User-Agent\\\":\\\"Apache-HttpClient/4.5.13 (Java/1.8.0_342-342)\\\"}\",\"totalVerizonDollarUsed\":\"0.0\",\"isShellAccountSelected\":true,\"accountCreateDate\":\"\",\"existingSpeed\":\"\",\"guestOrInactiveRefundLines\":false,\"totalDueMonthlyOnProfile\":0,\"subTotalDueMonthlyOnProfile\":0,\"totalMonthlyTaxesOnProfile\":0,\"subTotalOtherLinesOnProfile\":0,\"estimatedNextMonthChargeOnProfile\":0,\"totalDueMonthlyAfterDiscounts\":0,\"totalActivationFees\":0,\"remainingAmountAfterAffirmApplied\":0,\"orderType\":\"PS\",\"locationCode\":\"N832101\",\"customerType\":\"N\",\"billingSystem\":\"VN\",\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CA CVAS AUTOMATIC APPROVAL\",\"securityDepositAmount\":\"0.0\",\"totalTaxAmount\":\"0.0\",\"totalDueToday\":0,\"totalDueMonthly\":0,\"subTotalDueMonthly\":0,\"subTotalDueToday\":0,\"subTotalMonthlyTaxes\":0,\"estimatedNextMonthCharge\":0,\"totalMonthlyTaxes\":0,\"subTotalOtherLines\":0,\"subTotalOtherLinesTaxes\":0,\"instantDRCCredit\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0,\"orderChannelId\":\"VZW-DOTCOM\",\"orderList\":[],\"outletId\":\"124642\",\"registerNumber\":\"0\",\"saleType\":\"P\",\"salesRepId\":\"NPB2C\",\"enableSplitShipment\":false,\"splitShipmentIndicator\":false,\"cartReadyForCheckout\":true,\"isSingleModConnectedDevice\":false,\"fiveGUpSellAccountLevel\":false,\"customerOnTrialPlan\":false,\"availableSlotsForGrantee\":\"0\",\"totalDownPaymentAmt\":0,\"totalEdgeBuyOutAmount\":0,\"expressCheckout\":false,\"isEQPandPPLOfferApplied\":false,\"cartTotalDiscounts\":{\"totalDiscount\":\"0.0\",\"discountDetails\":[]},\"memberTotalDueToday\":0,\"eligible5GHomeBundle\":[{\"bundleName\":\"5GHomeGeminiSelfSetup\",\"id\":\"16900001\"},{\"bundleName\":\"5GHomeGeminiProfSetup\",\"id\":\"16900002\"}],\"totalDwosCost\":\"0.0\",\"billingState\":\"MI\",\"isTradeInOfferSelected\":false},\"lineDetails\":{\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"NSE_5G\",\"totalDueToday\":0,\"totalDueTodayWithoutTax\":0,\"totalDueMonthly\":60,\"mobileNumber\":\"newLine1\",\"serviceInfo\":{\"pairingInfo\":{},\"moversInfo\":{\"moveOutDate\":\"20220907\"},\"planDiscount\":{\"planEligibleForAutoPayPaperLessDiscount\":true,\"eligibleAutoPayPaperlessDiscount\":\"10.0\",\"discountIncluded\":false,\"totalPlanCostIncludingLineAccessFee\":\"60.0\"},\"otherPromotions\":[],\"primaryUserInfo\":{\"firstName\":\"FIRSTNAME\",\"lastName\":\"LASTNAME\",\"address\":{\"type\":\"ST\",\"streetNumber\":\"28820\",\"streetName\":\"BEECHWOOD\",\"addressLine1\":\"28820 BEECHWOOD ST\",\"city\":\"GARDEN CITY\",\"state\":\"MI\",\"zipCode\":\"48135\",\"zipCode4\":\"2439\",\"county\":\"\",\"countryCode\":\"US\",\"fipsCode\":\"2616331420\",\"firstName\":\"FIRSTNAME\",\"lastName\":\"LASTNAME\",\"emailId\":\"CxT.Digital.Regression@verizon.com\",\"phoneNumber\":\"7777777779\",\"attention\":\"FIRSTNAME LASTNAME\"},\"attention\":\"FIRSTNAME LASTNAME\",\"contactPersonPhone\":\"7777777779\",\"emailId\":\"CxT.Digital.Regression@verizon.com\"},\"cart5GAddress\":{\"streetNumber\":\"28820\",\"streetName\":\"BEECHWOOD\",\"addressLine1\":\"28820 BEECHWOOD ST\",\"city\":\"GARDEN CITY\",\"state\":\"MI\",\"zipCode\":\"48135\",\"zipCode4\":\"\",\"countryCode\":\"\",\"fipsCode\":\"2616331420\",\"emailId\":\"\",\"streetType\":\"ST\",\"floor\":0,\"eventCorrelationId\":\"48135_1665898553541_256\"}}}]},\"accountEligibility\":false}}}";


		RetrieveCartCXPResponse sampleCXPResponse = null;
		sampleCXPResponse = mapper.readValue(sampleResponseString, RetrieveCartCXPResponse.class);
		RetrieveCartCXPRequest request = new RetrieveCartCXPRequest();
		CXPRetrieveCartDataVO data = new CXPRetrieveCartDataVO();
		data.setCartId("1235447");
		request.setData(data);
		when(cxpService.retrieve5GMoversCart(Mockito.any())).thenReturn(just(sampleCXPResponse));
		doThrow(new RuntimeException()).when(cartServiceCxpHelper).updateDLData5g(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());
		Mono<RetrieveCartCXPResponse> UIResponse = cxpHelper.retrieve5GMoversCart(request);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete()
				.verify();
	}

	@Test
	public void retrieve5GMoversCartTest2() throws IOException {
		//String sampleResponseString = "{\"meta\":{\"timestamp\":\"1665898851282\",\"cxpCorrelationId\":\"2022-10-16T05:40:51.+0000:abf808686a6a284:cxp-shopping-services-qa-ev6v-sit3e-nscxp-785d644b94-5dlqf:nssit3\"},\"data\":{\"cart\":{\"customerProfile\":{},\"orderDetails\":{\"totalUpgradeFee\":0,\"totalDeviceDollar\":0,\"totalRemainingDeviceDollar\":0,\"totalUsedDeviceDollar\":0,\"totalAccountLevelAccCost\":0,\"totalAccountLevelAccCostWithTax\":0,\"verizonCardPromoOfferList\":[],\"taxDetailsList\":[],\"subTotalDueTodayWithoutUpgradeFee\":0,\"subTotalDueMonthlyForAALBYODEUP\":0,\"shipTogetherPref\":true,\"assistanceOptedByCustomer\":false,\"httpHeaders\":\"{\\\"channelid\\\":\\\"VZW-DOTCOM\\\",\\\"originatingClientIp\\\":\\\"10.11.65.244\\\",\\\"sessionId\\\":\\\"POE-D-77a17513-cc54-46d4-8d70-3ae1e778263e\\\",\\\"User-Agent\\\":\\\"Apache-HttpClient/4.5.13 (Java/1.8.0_342-342)\\\"}\",\"totalVerizonDollarUsed\":\"0.0\",\"isShellAccountSelected\":true,\"accountCreateDate\":\"\",\"existingSpeed\":\"\",\"guestOrInactiveRefundLines\":false,\"totalDueMonthlyOnProfile\":0,\"subTotalDueMonthlyOnProfile\":0,\"totalMonthlyTaxesOnProfile\":0,\"subTotalOtherLinesOnProfile\":0,\"estimatedNextMonthChargeOnProfile\":0,\"totalDueMonthlyAfterDiscounts\":0,\"totalActivationFees\":0,\"remainingAmountAfterAffirmApplied\":0,\"orderType\":\"PS\",\"locationCode\":\"N832101\",\"customerType\":\"N\",\"billingSystem\":\"VN\",\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CA CVAS AUTOMATIC APPROVAL\",\"securityDepositAmount\":\"0.0\",\"totalTaxAmount\":\"0.0\",\"totalDueToday\":0,\"totalDueMonthly\":0,\"subTotalDueMonthly\":0,\"subTotalDueToday\":0,\"subTotalMonthlyTaxes\":0,\"estimatedNextMonthCharge\":0,\"totalMonthlyTaxes\":0,\"subTotalOtherLines\":0,\"subTotalOtherLinesTaxes\":0,\"instantDRCCredit\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0,\"orderChannelId\":\"VZW-DOTCOM\",\"orderList\":[],\"outletId\":\"124642\",\"registerNumber\":\"0\",\"saleType\":\"P\",\"salesRepId\":\"NPB2C\",\"enableSplitShipment\":false,\"splitShipmentIndicator\":false,\"cartReadyForCheckout\":true,\"isSingleModConnectedDevice\":false,\"fiveGUpSellAccountLevel\":false,\"customerOnTrialPlan\":false,\"availableSlotsForGrantee\":\"0\",\"totalDownPaymentAmt\":0,\"totalEdgeBuyOutAmount\":0,\"expressCheckout\":false,\"isEQPandPPLOfferApplied\":false,\"cartTotalDiscounts\":{\"totalDiscount\":\"0.0\",\"discountDetails\":[]},\"memberTotalDueToday\":0,\"eligible5GHomeBundle\":[{\"bundleName\":\"5GHomeGeminiSelfSetup\",\"id\":\"16900001\"},{\"bundleName\":\"5GHomeGeminiProfSetup\",\"id\":\"16900002\"}],\"totalDwosCost\":\"0.0\",\"billingState\":\"MI\",\"isTradeInOfferSelected\":false},\"lineDetails\":{\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"NSE_5G\",\"totalDueToday\":0,\"totalDueTodayWithoutTax\":0,\"totalDueMonthly\":60,\"mobileNumber\":\"newLine1\",\"serviceInfo\":{\"pairingInfo\":{},\"moversInfo\":{\"moveOutDate\":\"20220907\"},\"planDiscount\":{\"planEligibleForAutoPayPaperLessDiscount\":true,\"eligibleAutoPayPaperlessDiscount\":\"10.0\",\"discountIncluded\":false,\"totalPlanCostIncludingLineAccessFee\":\"60.0\"},\"otherPromotions\":[],\"primaryUserInfo\":{\"firstName\":\"FIRSTNAME\",\"lastName\":\"LASTNAME\",\"address\":{\"type\":\"ST\",\"streetNumber\":\"28820\",\"streetName\":\"BEECHWOOD\",\"addressLine1\":\"28820 BEECHWOOD ST\",\"city\":\"GARDEN CITY\",\"state\":\"MI\",\"zipCode\":\"48135\",\"zipCode4\":\"2439\",\"county\":\"\",\"countryCode\":\"US\",\"fipsCode\":\"2616331420\",\"firstName\":\"FIRSTNAME\",\"lastName\":\"LASTNAME\",\"emailId\":\"CxT.Digital.Regression@verizon.com\",\"phoneNumber\":\"7777777779\",\"attention\":\"FIRSTNAME LASTNAME\"},\"attention\":\"FIRSTNAME LASTNAME\",\"contactPersonPhone\":\"7777777779\",\"emailId\":\"CxT.Digital.Regression@verizon.com\"},\"cart5GAddress\":{\"streetNumber\":\"28820\",\"streetName\":\"BEECHWOOD\",\"addressLine1\":\"28820 BEECHWOOD ST\",\"city\":\"GARDEN CITY\",\"state\":\"MI\",\"zipCode\":\"48135\",\"zipCode4\":\"\",\"countryCode\":\"\",\"fipsCode\":\"2616331420\",\"emailId\":\"\",\"streetType\":\"ST\",\"floor\":0,\"eventCorrelationId\":\"48135_1665898553541_256\"}}}]},\"accountEligibility\":false}}}";


		RetrieveCartCXPResponse sampleCXPResponse = new RetrieveCartCXPResponse();
		//sampleCXPResponse = mapper.readValue(sampleResponseString, RetrieveCartCXPResponse.class);
		RetrieveCartCXPRequest request = new RetrieveCartCXPRequest();
		CXPRetrieveCartDataVO data = new CXPRetrieveCartDataVO();
		data.setCartId("1235447");
		request.setData(data);
		when(cxpService.retrieve5GMoversCart(Mockito.any())).thenReturn(just(sampleCXPResponse));
		doThrow(new RuntimeException()).when(cartServiceCxpHelper).updateDLData5g(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());
		Mono<RetrieveCartCXPResponse> UIResponse = cxpHelper.retrieve5GMoversCart(request);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNull(resp.getData())).expectComplete()
				.verify();

	}
	@Test
	public void retrieve5GMoversCartExceptionTest() throws IOException {


		Mono<RetrieveCartCXPResponse> dummyResponse = Mono
				.just(Mockito.mock(RetrieveCartCXPResponse.class, RETURNS_SMART_NULLS));
		SOEErrorHolder soeErrorHolder = new SOEErrorHolder();
		List<SOEError> erros = new ArrayList<>();
		SOEError soeError = new SOEError();
		soeError.setDebug_id("test");
		soeError.setCategory("CXP");
		soeError.setMessage("BAD GATEWAY");
		erros.add(soeError);
		soeErrorHolder.setErrors(erros);
		SOEHTTPException soehttpException = new SOEHTTPException(500, soeErrorHolder);
		Mono<RetrieveCartCXPResponse> cxpResponse = Mono.error(soehttpException);
		when(cxpService.retrieve5GMoversCart(Mockito.any())).thenReturn(cxpResponse);

		RetrieveCartCXPRequest request = new RetrieveCartCXPRequest();
		CXPRetrieveCartDataVO data = new CXPRetrieveCartDataVO();
		data.setCartId("1235447");
		request.setData(data);

		Mono<RetrieveCartCXPResponse> UIResponse = cxpHelper.retrieve5GMoversCart(request);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp.getErrors())).expectComplete()
				.verify();

	}


}
