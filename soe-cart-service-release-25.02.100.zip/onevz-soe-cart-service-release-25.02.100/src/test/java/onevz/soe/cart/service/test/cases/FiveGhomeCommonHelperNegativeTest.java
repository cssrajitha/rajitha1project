package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.databind.ObjectMapper;
import net.jcip.annotations.NotThreadSafe;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.cxp.service.OrderProcessCXPServices;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.model.common.FiveG.FiveGLTEAddressRedis;
import onevz.soe.cart.model.retrieveCart.CXPCartItem;
import onevz.soe.cart.model.retrieveCart.RebateOffer;
import onevz.soe.cart.model.retrieveCart.fiveG.CXPOrderDetailsView;
import onevz.soe.cart.nbx.NBXFeedbackService;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.CustomerProfileByIdCXPResponse;
import onevz.soe.cart.responses.TechFlowRedisData;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.AddPlanAndDeviceUIRequest;
import onevz.soe.cart.ui.responses.AddPlanAndDeviceUIResponse;
import onevz.soe.cart.util.CommonUtil;
import onevz.soe.cradle.CradleAllocator;
import onevz.soe.omnidl.util.DLUtilityService;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.exceptions.base.MockitoException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;

import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static reactor.core.publisher.Mono.just;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { CartServiceTestConfig.class })
//@WebFluxTest(FiveGhomeCommonHelper.class)
//@NotThreadSafe
public class FiveGhomeCommonHelperNegativeTest {
    @Autowired
    private FiveGhomeCommonHelper helper;

    @Autowired
    private FiveGhomeNSEHelper fiveGhomeNSEHelper;

    @Autowired
    private FiveGhomeAALHelper fiveGhomeAALHelper;

    @MockBean
    CommonUtil commonUtilInfo;

    @MockBean
    private CartServiceCxpHelper cxpHelper;

    @MockBean
    private CartServiceCXPServices cxpService;

    @MockBean
    private CartServiceBpmHelper bpmHelper;

    @MockBean
    private RedisHelper redisHelper;

    @MockBean
    private RedisHelper3 redisHelper3;

    @Autowired
    private ObjectMapper mapper;

    @MockBean
    private NBXFeedbackService nbxService;

    @MockBean
    private CradleAllocator cradleAllocator;

    @MockBean
    private DLUtilityService dlUtilityService;

    @MockBean
    private OrderProcessCXPServices orderCxpService;

    @MockBean
    private SOELoginSessionBean sessionBean;

    @Autowired
    private FiveGhomeTechHelper fiveGhomeTechHelper;

    @Test
    public void createTechnicianCBandCartNegativeTest(){
        TechFlowRedisData techRedisData=new TechFlowRedisData ();
        techRedisData.setMtn("1234567890");
        techRedisData.setCBandSku("1234567890");
        Mono<Object> createTechnicianCBandCart = helper.createTechnicianCBandCart(techRedisData);
        StepVerifier.create(createTechnicianCBandCart).assertNext( val -> Assert.assertNotNull(val));
    }
    @Test
    public void addPlanAndDeviceNegativeTest() throws IOException, SOEHTTPException {
        String sampleRequestString = "{\"cartInfo\": {\"clientAppName\": \"VZW-DOTCOM\",\"cartId\": \"\",\"caseId\": \"\",\"accountNumber\": \"\",\"processingMTN\": \"\",\"processStep\": \"Accessory\",\"processAction\": \"DevicePlan\",\"action\": \"\",		\"intendType\": \"NSE_5G\",	\"bundleInstallType\": \"\"},\"data\": {\"lines\": [{\"depletionType\": \"F\"}]}}";
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM-MOB\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-5185950-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Accessories\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Accessories\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-M-0229cd48-af4d-4615-b35e-b81322f26569\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":1,\"cartId\":\"b4d7474f-34ee-4a90-855f-b4ec77ca5ee8\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"onDemandAllowed\":false,\"backDateAllowed\":false,\"futureDateAllowed\":false,\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"lines\":[{\"plan\":{\"id\":\"38365\",\"price\":\"70.00\",\"isRecommendedPlan\":false},\"status\":1,\"spos\":[{\"id\":\"732\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false}],\"sfos\":[{\"id\":\"48526\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"48553\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"54307\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68872\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"70421\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78003\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"83856\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"85503\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86112\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86926\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86928\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"87800\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"88561\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"88562\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"88683\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"88685\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"88686\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false}],\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"mtn\":\"newLine1\",\"isDeviceSelected\":true,\"userSelectedPlan\":false,\"lineId\":\"newLine1\",\"sortingNumber\":\"0\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"ASK-NCQ1338\",\"itemPrice\":\"240.0\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"Verizon Internet Gateway\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"currentPlanType\":\"LLP\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"isAppendedLine\":false,\"fiveGPlanAdded\":false}],\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"OrderNow\"]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"OrderNow\"]}]}}}}";
        AddPlanAndDeviceUIRequest sampleRequest = null;
        AddPlanAndDeviceUIResponse sampleResponse = null;
        String redisDataString = "{ \"cartId\": \"\", \"caseId\": \"\", \"processingMTN\": \"\", \"cartCreator\": \"\", \"accountNumber\": \"\", \"sessionId\": \"POE-M-0229cd48-af4d-4615-b35e-b81322f26569\" }";
        String TechFlowRedisData = "{ \"vpmOrderNum\": \"\", \"vpmLocationCode\": \"\", \"mtn\": \"\", \"aud\": \"\", \"exp\": \"\", \"iat\": \"\" }";
        String addressRedisData = "{ \"addressLine1\": \"258 POOLER PKWY\",\"crmResumeCartFlow\": \"crmResuem\", \"addressLine2\": \"\", \"city\": \"POOLER\", \"state\": \"GA\", \"zipCode\": \"31322\", \"apartmentNo\": \"\",\"streetNumber\": \"\",\"streetName\": \"\",\"fiveGHomeQualified\": \"\",\"LTEQualified\": \"true\",\"launchType\": \"\",\"addressType\": \"\",\"installType\": \"\",\"eventCorrelationId\": \"\",\"longitude\": \"\",\"latitude\": \"\",\"floor\": \"\",\"LTEHomeSku\": \"ASK-NCQ1338\",\"buildingId\": \"\" ,\"bundleName\": \"\" ,\"bundleId\": \"\" ,\"bundleType\": \"\" ,\"covidQuestionareAnswered\": \"\", \"prEmailId\": \"\", \"cbr\": \"\",\"locationId\": \"\" ,\"isD2DFlow\": \"\", \"networkBandwidthType\": \"NSE_5G\" ,\"fiveGMUCEligible\": \"\",\"cBandSku\": \"\",\"aqCaseId\": \"AQ-4173116-E01\" }";
        FiveGLTEAddressRedis fiveGAddressRedisData = mapper.readValue(addressRedisData, FiveGLTEAddressRedis.class);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        onevz.soe.cart.responses.TechFlowRedisData TechFlowRedisDataRedis = mapper.readValue(TechFlowRedisData, TechFlowRedisData.class);
        sampleRedisData.setMarket(null);
        sampleRedisData.setPreOrderInServiceDate("22-01-2022");
        sampleRedisData.setMtn("1234567890");
        sampleRedisData.setCartCreator("POE-789456");
        sampleRequest = mapper.readValue(sampleRequestString, AddPlanAndDeviceUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, AddPlanAndDeviceUIResponse.class);
        Mono<AddPlanAndDeviceUIResponse> sampleResponseMono = just(sampleResponse);
        when(redisHelper.getDataFromRedis()).thenReturn(just(sampleRedisData));
        when(redisHelper3.fetchTechnicianDataFromRedis()).thenReturn(just(TechFlowRedisDataRedis));
        when(redisHelper3.getFiveGAddressFromRedisFromFiveGFlow()).thenReturn(just(fiveGAddressRedisData));
        when(bpmHelper.addPlanAndDevice(sampleRequest)).thenReturn(just(sampleResponse));

        AddPlanAndDeviceUIResponse expectedResponse = sampleResponse;
        Mono<AddPlanAndDeviceUIResponse> response = helper.addPlanAndDevice(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }
    @Test
    public void addPlanAndDeviceNegativeTest2() throws IOException, SOEHTTPException {
        String sampleRequestString = "{\"cartInfo\": {\"clientAppName\": \"VZW-DOTCOM\",\"cartId\": \"\",\"caseId\": \"\",\"accountNumber\": \"\",\"processingMTN\": \"\",\"processStep\": \"Accessory\",\"processAction\": \"\",\"action\": \"\",		\"intendType\": \"NSE\",	\"bundleInstallType\": \"\"},\"data\": {\"lines\": [{\"depletionType\": \"F\"}]}}";
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM-MOB\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-5185950-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Accessories\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Accessories\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-M-0229cd48-af4d-4615-b35e-b81322f26569\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":1,\"cartId\":\"b4d7474f-34ee-4a90-855f-b4ec77ca5ee8\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"onDemandAllowed\":false,\"backDateAllowed\":false,\"futureDateAllowed\":false,\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"lines\":[{\"plan\":{\"id\":\"38365\",\"price\":\"70.00\",\"isRecommendedPlan\":false},\"status\":1,\"spos\":[{\"id\":\"732\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false}],\"sfos\":[{\"id\":\"48526\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"48553\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"54307\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68872\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"70421\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78003\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"83856\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"85503\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86112\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86926\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86928\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"87800\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"88561\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"88562\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"88683\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"88685\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"88686\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false}],\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"mtn\":\"newLine1\",\"isDeviceSelected\":true,\"userSelectedPlan\":false,\"lineId\":\"newLine1\",\"sortingNumber\":\"0\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"ASK-NCQ1338\",\"itemPrice\":\"240.0\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"Verizon Internet Gateway\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"currentPlanType\":\"LLP\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"isAppendedLine\":false,\"fiveGPlanAdded\":false}],\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"OrderNow\"]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"OrderNow\"]}]}}}}";
        AddPlanAndDeviceUIRequest sampleRequest = null;
        AddPlanAndDeviceUIResponse sampleResponse = null;
        String redisDataString = "{ \"cartId\": \"\", \"caseId\": \"\", \"processingMTN\": \"\", \"cartCreator\": \"\", \"accountNumber\": \"\", \"sessionId\": \"POE-M-0229cd48-af4d-4615-b35e-b81322f26569\" }";
        String TechFlowRedisData = "{ \"vpmOrderNum\": \"\", \"vpmLocationCode\": \"\", \"mtn\": \"\", \"aud\": \"\", \"exp\": \"\", \"iat\": \"\" }";
        String addressRedisData = "{ \"addressLine1\": \"258 POOLER PKWY\",\"crmResumeCartFlow\": \"crmResuem\", \"addressLine2\": \"\", \"city\": \"POOLER\", \"state\": \"GA\", \"zipCode\": \"31322\", \"apartmentNo\": \"\",\"streetNumber\": \"\",\"streetName\": \"\",\"fiveGHomeQualified\": \"\",\"LTEQualified\": \"true\",\"launchType\": \"\",\"addressType\": \"\",\"installType\": \"\",\"eventCorrelationId\": \"\",\"longitude\": \"\",\"latitude\": \"\",\"floor\": \"\",\"LTEHomeSku\": \"ASK-NCQ1338\",\"buildingId\": \"\" ,\"bundleName\": \"\" ,\"bundleId\": \"\" ,\"bundleType\": \"\" ,\"covidQuestionareAnswered\": \"\", \"prEmailId\": \"\", \"cbr\": \"\",\"locationId\": \"\" ,\"isD2DFlow\": \"\", \"networkBandwidthType\": \"NSE_5G\" ,\"fiveGMUCEligible\": \"\",\"cBandSku\": \"\",\"aqCaseId\": \"AQ-4173116-E01\" }";
        FiveGLTEAddressRedis fiveGAddressRedisData = mapper.readValue(addressRedisData, FiveGLTEAddressRedis.class);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        onevz.soe.cart.responses.TechFlowRedisData TechFlowRedisDataRedis = mapper.readValue(TechFlowRedisData, TechFlowRedisData.class);
        sampleRedisData.setMarket("MARKET");
        sampleRedisData.setPreOrderInServiceDate(null);
        sampleRedisData.setMtn("1234567890");
        sampleRequest = mapper.readValue(sampleRequestString, AddPlanAndDeviceUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, AddPlanAndDeviceUIResponse.class);
        Mono<AddPlanAndDeviceUIResponse> sampleResponseMono = just(sampleResponse);
        when(redisHelper.getDataFromRedis()).thenReturn(just(sampleRedisData));
        when(redisHelper3.fetchTechnicianDataFromRedis()).thenReturn(just(TechFlowRedisDataRedis));
        when(redisHelper3.getFiveGAddressFromRedisFromFiveGFlow()).thenReturn(just(fiveGAddressRedisData));
        when(bpmHelper.addPlanAndDevice(sampleRequest)).thenReturn(just(sampleResponse));

        AddPlanAndDeviceUIResponse expectedResponse = sampleResponse;
        Mono<AddPlanAndDeviceUIResponse> response = helper.addPlanAndDevice(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }
    @Test
    public void addPlanAndDeviceNegativeTest3() throws IOException, SOEHTTPException {
        String sampleRequestString = "{\"cartInfo\":{\"lqInfo\":{\"addressLine1\":\"686 S GRANT ST\",\"addressLine2\":\"street2\",\"aqCaseId\":\"AQ-1356736033-E01\",\"city\":\"DENVER\",\"eventCorrelationId\":\"80209_1662125785221_319\",\"fipsCode\":\"0803120000\",\"LTEHomeQualified\":\"false\",\"LTEHomeSku\":\"false\",\"floor\":\"2\",\"fiveGHomeQualified\":true,\"launchType\":\"FCL\",\"networkBandwidthType\":\"mmw\",\"state\":\"CO\",\"streetName\":\"S GRANT\",\"streetNumber\":\"686\",\"streetType\":\"ST\",\"zipCode\":\"80209\",\"bundleList\":[{\"bundleName\":\"5GHomeGeminiSelfSetup\",\"id\":\"16900001\",\"type\":\"s\"},{\"bundleName\":\"5GHomeGeminiProfSetup\",\"id\":\"16900002\",\"type\":\"p\"}]},\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"intendType\":\"NSE_5G\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\",\"enableResume\":\"false\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM-MOB\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-5185950-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Accessories\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Accessories\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-M-0229cd48-af4d-4615-b35e-b81322f26569\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":1,\"cartId\":\"b4d7474f-34ee-4a90-855f-b4ec77ca5ee8\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"onDemandAllowed\":false,\"backDateAllowed\":false,\"futureDateAllowed\":false,\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"lines\":[{\"plan\":{\"id\":\"38365\",\"price\":\"70.00\",\"isRecommendedPlan\":false},\"status\":1,\"spos\":[{\"id\":\"732\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false}],\"sfos\":[{\"id\":\"48526\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"48553\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"54307\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68872\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"70421\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78003\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"83856\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"85503\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86112\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86926\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86928\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"87800\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"88561\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"88562\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"88683\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"88685\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"88686\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false}],\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"mtn\":\"newLine1\",\"isDeviceSelected\":true,\"userSelectedPlan\":false,\"lineId\":\"newLine1\",\"sortingNumber\":\"0\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"ASK-NCQ1338\",\"itemPrice\":\"240.0\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"Verizon Internet Gateway\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"currentPlanType\":\"LLP\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"isAppendedLine\":false,\"fiveGPlanAdded\":false}],\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"OrderNow\"]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"OrderNow\"]}]}}}}";
        AddPlanAndDeviceUIRequest sampleRequest = null;
        AddPlanAndDeviceUIResponse sampleResponse = null;
        String redisDataString = "{ \"cartId\": \"\", \"caseId\": \"\", \"processingMTN\": \"\", \"cartCreator\": \"\", \"accountNumber\": \"\", \"sessionId\": \"POE-M-0229cd48-af4d-4615-b35e-b81322f26569\" }";
        String TechFlowRedisData = "{ \"vpmOrderNum\": \"\", \"vpmLocationCode\": \"\", \"mtn\": \"\", \"aud\": \"\", \"exp\": \"\", \"iat\": \"\" }";
        String addressRedisData = "{}";
        FiveGLTEAddressRedis fiveGAddressRedisData = mapper.readValue(addressRedisData, FiveGLTEAddressRedis.class);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        onevz.soe.cart.responses.TechFlowRedisData TechFlowRedisDataRedis = mapper.readValue(TechFlowRedisData, TechFlowRedisData.class);
        sampleRedisData.setMarket("MARKET");
        sampleRedisData.setPreOrderInServiceDate(null);
        sampleRedisData.setMtn("1234567890");
        sampleRequest = mapper.readValue(sampleRequestString, AddPlanAndDeviceUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, AddPlanAndDeviceUIResponse.class);
        Mono<AddPlanAndDeviceUIResponse> sampleResponseMono = just(sampleResponse);

        when(cxpHelper.getCustomerProfileAddress(Mockito.any())).thenReturn(just(new CustomerProfileByIdCXPResponse()));
        when(redisHelper.getDataFromRedis()).thenReturn(just(sampleRedisData));
        when(redisHelper3.fetchTechnicianDataFromRedis()).thenReturn(just(TechFlowRedisDataRedis));
        when(redisHelper3.getFiveGAddressFromRedisFromFiveGFlow()).thenReturn(just(fiveGAddressRedisData));
        when(bpmHelper.addPlanAndDevice(sampleRequest)).thenReturn(just(sampleResponse));
        when(redisHelper3.getBulkQualificationAddressFromRedis(Mockito.any())).thenReturn(Mono.just(fiveGAddressRedisData));


        AddPlanAndDeviceUIResponse expectedResponse = sampleResponse;
        Mono<AddPlanAndDeviceUIResponse> response = helper.addPlanAndDevice(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addPlanAndDeviceExceptionTest() throws IOException, SOEHTTPException {
        String sampleRequestString = "{\"cartInfo\":{\"lqInfo\":{\"addressLine1\":\"686 S GRANT ST\",\"addressLine2\":\"street2\",\"aqCaseId\":\"AQ-1356736033-E01\",\"city\":\"DENVER\",\"eventCorrelationId\":\"80209_1662125785221_319\",\"fipsCode\":\"0803120000\",\"LTEHomeQualified\":\"false\",\"LTEHomeSku\":\"false\",\"floor\":\"2\",\"fiveGHomeQualified\":true,\"launchType\":\"FCL\",\"networkBandwidthType\":\"mmw\",\"state\":\"CO\",\"streetName\":\"S GRANT\",\"streetNumber\":\"686\",\"streetType\":\"ST\",\"zipCode\":\"80209\",\"bundleList\":[{\"bundleName\":\"5GHomeGeminiSelfSetup\",\"id\":\"16900001\",\"type\":\"s\"},{\"bundleName\":\"5GHomeGeminiProfSetup\",\"id\":\"16900002\",\"type\":\"p\"}]},\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"intendType\":\"NSE_5G\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\",\"enableResume\":\"false\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM-MOB\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-5185950-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Accessories\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Accessories\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-M-0229cd48-af4d-4615-b35e-b81322f26569\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":1,\"cartId\":\"b4d7474f-34ee-4a90-855f-b4ec77ca5ee8\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"onDemandAllowed\":false,\"backDateAllowed\":false,\"futureDateAllowed\":false,\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"lines\":[{\"plan\":{\"id\":\"38365\",\"price\":\"70.00\",\"isRecommendedPlan\":false},\"status\":1,\"spos\":[{\"id\":\"732\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false}],\"sfos\":[{\"id\":\"48526\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"48553\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"54307\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68872\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"70421\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78003\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"83856\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"85503\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86112\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86926\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86928\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"87800\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"88561\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"88562\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"88683\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"88685\",\"conflict\":\"Add SFO due to missing required parent\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"88686\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false}],\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"mtn\":\"newLine1\",\"isDeviceSelected\":true,\"userSelectedPlan\":false,\"lineId\":\"newLine1\",\"sortingNumber\":\"0\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"ASK-NCQ1338\",\"itemPrice\":\"240.0\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"Verizon Internet Gateway\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"currentPlanType\":\"LLP\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"isAppendedLine\":false,\"fiveGPlanAdded\":false}],\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"OrderNow\"]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"OrderNow\"]}]}}}}";
        AddPlanAndDeviceUIRequest sampleRequest = null;
        AddPlanAndDeviceUIResponse sampleResponse = null;
        String redisDataString = "{ \"cartId\": \"\", \"caseId\": \"\", \"processingMTN\": \"\", \"cartCreator\": \"\", \"accountNumber\": \"\", \"sessionId\": \"POE-M-0229cd48-af4d-4615-b35e-b81322f26569\" }";
        String TechFlowRedisData = "{ \"vpmOrderNum\": \"\", \"vpmLocationCode\": \"\", \"mtn\": \"\", \"aud\": \"\", \"exp\": \"\", \"iat\": \"\" }";
        String addressRedisData = "{}";
        FiveGLTEAddressRedis fiveGAddressRedisData = mapper.readValue(addressRedisData, FiveGLTEAddressRedis.class);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        onevz.soe.cart.responses.TechFlowRedisData TechFlowRedisDataRedis = mapper.readValue(TechFlowRedisData, TechFlowRedisData.class);
        sampleRedisData.setMarket("MARKET");
        sampleRedisData.setPreOrderInServiceDate(null);
        sampleRedisData.setMtn("1234567890");
        sampleRequest = mapper.readValue(sampleRequestString, AddPlanAndDeviceUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, AddPlanAndDeviceUIResponse.class);
        Mono<AddPlanAndDeviceUIResponse> sampleResponseMono = just(sampleResponse);

        when(cxpHelper.getCustomerProfileAddress(Mockito.any())).thenReturn(just(new CustomerProfileByIdCXPResponse()));
        when(redisHelper.getDataFromRedis()).thenReturn(just(sampleRedisData));
        when(redisHelper3.fetchTechnicianDataFromRedis()).thenReturn(just(TechFlowRedisDataRedis));
        when(redisHelper3.getFiveGAddressFromRedisFromFiveGFlow()).thenReturn(just(fiveGAddressRedisData));
        when(bpmHelper.addPlanAndDevice(sampleRequest)).thenReturn(just(sampleResponse));
        when(redisHelper3.getBulkQualificationAddressFromRedis(Mockito.any())).thenReturn(Mono.just(fiveGAddressRedisData));


        AddPlanAndDeviceUIResponse expectedResponse = sampleResponse;
        doThrow(RuntimeException.class).when(commonUtilInfo).populatingUIrequestToRedisAddress(Mockito.any(),Mockito.any());
        Mono<AddPlanAndDeviceUIResponse> response = helper.addPlanAndDevice(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }
    @Test
    public void addPlanAndDeviceTech_CbandNegativeTest() throws IOException, SOEHTTPException {
        String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"1234567890\",\"caseId\":\"123456890\",\"accountNumber\":\"\",\"cartCreator\":\"POE-M-0229cd48-af4d-4615-b35e-b81322f26569\",\"processingMTN\":\"\",\"processStep\":\"Accessories\",\"processAction\":\"DeviceAndPlan\",\"intendType\":\"AAL_CBD_TECH\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-5188491-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Accessories\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Accessories\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-D-410f65a0-8535-471c-b1b3-0d14cbfcbd26\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":1,\"cartId\":\"6af05322-815c-423c-9bb2-9b0fce190075\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"onDemandAllowed\":false,\"backDateAllowed\":false,\"futureDateAllowed\":false,\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"lines\":[{\"status\":1,\"spos\":[{\"id\":\"732\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false},{\"id\":\"1508\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false}],\"sfos\":[{\"id\":\"48526\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"48553\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"54307\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68872\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"70421\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78003\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"83856\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"85503\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86112\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86926\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86927\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86928\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86952\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86953\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false}],\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"mtn\":\"newLine1\",\"isDeviceSelected\":true,\"userSelectedPlan\":false,\"lineId\":\"newLine1\",\"sortingNumber\":\"0\",\"device\":{\"id\":\"LVSKIHP\",\"itemPrice\":\"0.0\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"5G Internet Gateway\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false},\"sim\":{\"id\":\"NI-DPSIM\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"NSE_5G\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"isAppendedLine\":false,\"fiveGPlanAdded\":false}],\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]}]}}}}";
        AddPlanAndDeviceUIRequest sampleRequest = null;
        AddPlanAndDeviceUIResponse sampleResponse = null;
        String redisDataString = "{ \"cartId\": \"1234567890\", \"caseId\": \"\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"\", \"accountNumber\": \"\", \"sessionId\": \"POE-M-0229cd48-af4d-4615-b35e-b81322f26569\",\"intendType\":\"AAL_CBD_TECH\" }";
        String TechFlowRedisData = "{ \"vpmOrderNum\": \"5643457234\", \"vpmLocationCode\": \"NHGHG86\", \"fiveGPlan\": \"39247\", \"repId\": \"121284732\", \"outletId\": \"534645\", \"iat\": \"\",\"caseId\":\"123456890\" }";
        String addressRedisData = "{ \"addressLine1\": \"325 ROBINSON ST\", \"addressLine2\": \"\", \"city\": \"LOS ANGELES\", \"state\": \"CA\", \"zipCode\": \"90026\",\"fipsCode\": \"0603744000\", \"apartmentNo\": \"\",\"streetNumber\": \"\",\"streetName\": \"\",\"fiveGHomeQualified\": \"true\",\"LTEQualified\": \"\",\"launchType\": \"\",\"addressType\": \"\",\"installType\": \"\",\"eventCorrelationId\": \"55411_1635764454913_487\",\"longitude\": \"\",\"latitude\": \"\",\"floor\": \"\",\"LTEHomeSku\": \"\",\"buildingId\": \"\" ,\"bundleName\": \"5GHomeGeminiSelfSetup,5GHomeGeminiProfSetup\" ,\"bundleId\": \"16900001,16900002\" ,\"bundleType\": \"\" ,\"covidQuestionareAnswered\": \"\", \"prEmailId\": \"\",\"cbr\": \"\" ,\"cartCreatorOrderLocationCode\": \"NSQ568\" ,\"isD2DFlow\": \"\",\"networkBandwidthType\": \"\" ,\"fiveGMUCEligible\": \"true\",\"cBandSku\": \"\",\"bundleList\": [{\"bundleName\": \"5GHomeGeminiSelfSetup\",\"id\": \"16900001\"},{\"bundleName\": \"5GHomeGeminiProfSetup\",\"id\": \"16900001\"}] }";
        FiveGLTEAddressRedis fiveGAddressRedisData = mapper.readValue(addressRedisData, FiveGLTEAddressRedis.class);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setVzwRoles("VZW-Roles");
        sampleRedisData.setCartCreator("CartCreator");
        sampleRedisData.setCaseId("SOE-1234567890");
        sampleRedisData.setCartId("1234567890");
        onevz.soe.cart.responses.TechFlowRedisData TechFlowRedisDataRedis = mapper.readValue(TechFlowRedisData, TechFlowRedisData.class);


        sampleRequest = mapper.readValue(sampleRequestString, AddPlanAndDeviceUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, AddPlanAndDeviceUIResponse.class);
        Mono<AddPlanAndDeviceUIResponse> sampleResponseMono = just(sampleResponse);
        when(cxpHelper.getCustomerProfileAddress(Mockito.any())).thenReturn(just(new CustomerProfileByIdCXPResponse()));
        when(redisHelper.getDataFromRedis()).thenReturn(just(sampleRedisData));
        when(redisHelper3.fetchTechnicianDataFromRedis()).thenReturn(just(TechFlowRedisDataRedis));
        when(redisHelper3.getFiveGAddressFromRedisFromFiveGFlow()).thenReturn(just(fiveGAddressRedisData));
        when(redisHelper3.getBulkQualificationAddressFromRedis(Mockito.any())).thenReturn(Mono.just(fiveGAddressRedisData));
        when(bpmHelper.addPlanAndDevice(sampleRequest)).thenReturn(just(sampleResponse));

        AddPlanAndDeviceUIResponse expectedResponse = sampleResponse;
        Mono<AddPlanAndDeviceUIResponse> response = helper.addPlanAndDevice(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        //StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete() .verify();
    }

    @Test
    public void updateIntendTypeInredisNegativeTest() {
        String intendType = "NSE_5G";
        when(redisHelper3.setIntendTypeInRedis(Mockito.any())).thenThrow(new RuntimeException("intent failed"));
        try {
            helper.updateIntendTypeInredis(intendType);
        } catch (Exception e) {
            Assertions.assertEquals("intent failed", e.getMessage());
        }
    }

    @Test
    public void validateFWASweetnerDealInOrderTest() throws IOException, SOEHTTPException {
        String sampleRequestString1 = "{\"discountAmount\":0.0,\"deviceDollarApplied\":0.0,\"promoHubOfferList\":{\"promoHubOfferList\":[],\"offerCount\":0},\"qrScanNeededForEsimActivation\":false,\"isPreconfigureDuringAddDevice\":false,\"deviceDisplayName\":\"VZ INT ASK-NCQ1338FA\",\"accessoryGiftCardAmount\":0.0,\"tradeInAmountTowardsUserDPUsed\":0.0,\"sorDeviceCategory\":\"5G Router\",\"sorDeviceType\":\"5GE\",\"vendingKioskItem\":\"false\",\"tradeInAutoPull\":false,\"priceAdjustment\":false,\"priceAdjustmentQty\":0,\"newPurchasedQty\":0,\"networkBandwidthType\":\"LTE\",\"selectedForRFEX\":false,\"selectedForPAD\":false,\"bogoItem\":false,\"refxItemSeqNum\":0,\"restrictedAccySku\":false,\"maxAccyPurchaseLimit\":false,\"itemCode\":\"ASK-NCQ1338FA\",\"totalPriceWithDiscount\":0.0,\"sorId\":\"ASK-NCQ1338FA\",\"skuId\":\"sku5290001\",\"cartItemType\":\"DEVICE\",\"mobileNumber\":\"newLine1\",\"description\":\"Verizon Internet Gateway\",\"qty\":1,\"deviceDueToday\":0.0,\"bundleSeqNum\":0,\"itemPrice\":\"0.0\",\"discountedPercentage\":0.0,\"discountedPrice\":0.0,\"buyOutTaxAmountUnbilled\":0.0,\"buyOutAmountWithoutTax\":0.0,\"taxAmount\":0.0,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-2-router-white-arc-xci55ax\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-2-router-white-arc-xci55ax?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-2-router-white-arc-xci55ax?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-2-router-white-arc-xci55ax?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-2-router-white-arc-xci55ax?$device-thumb$\"},\"prodCode1\":\"5GD\",\"prodCode2\":\"NIC\",\"prodCode3\":\"5IR\",\"prodCode4\":\"B2B\",\"prodCode5\":\"RNT\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"depletionType\":\"O\",\"catalogPrice\":0.0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"color\":{},\"unitTaxBasedPrice\":0.0,\"itemNrpPrice\":0.0,\"itemCost\":0.0,\"upgradeReasonCode\":\"\",\"upgradeReasonDesc\":\"Invalid Reason Code - 0yr\",\"itemPriceType\":\"R\",\"discounts\":[],\"availableReasonCode\":[],\"inventory\":{\"isAvailable\":true,\"isBackorder\":false,\"isDeliverBy\":false,\"isPreOrder\":false,\"qtyAvailable\":105444},\"isCustomerProvidedSIM\":false,\"rebateOffers\": [ {\"description\": \"$201 Redemption Limit Barcode Test\",\"rebateAmount\": \"201.00\",\"revokeRebate\": false,\"platformPromoType\":\"Sweetener\",\"offerSubType\": \"Virtual Reward\",\"barcodeId\":\"UATTESTB1950\"}],\"isNetworkExtender\":false,\"ispuEligible\":true,\"itemSeqNum\":1,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0,\"sellerPrice\":\"0.0\",\"edgeDeviceCap\":\"0\",\"productId\":\"dev18800001\",\"numberShareCapabilityInfo\":{\"sorHdVoiceInd\":false,\"isNumberShareCapable\":false,\"isNumberShareMandatory\":false},\"taxDetailsList\":[],\"hasDeviceUnlockPolicy\":false,\"manufacturer\":\"Askey\",\"iconicPhone\":false,\"ringBell\":false,\"isPreconfigureEnabled\":false,\"isHumDevice\":false,\"isSmartLocator\":false,\"isSecurityAlarm\":false,\"isMotoMod\":false,\"isConnectedCar\":false,\"accountLevelAccessory\":false,\"byodESimPhone\":false,\"appleCareAccessoryFlag\":false}";
        String sampleRequestString2 =  "{\"totalUpgradeFee\":0.0,\"totalDeviceDollar\":0.0,\"totalRemainingDeviceDollar\":0.0,\"totalUsedDeviceDollar\":0.0,\"totalAccountLevelAccCost\":0.0,\"totalAccountLevelAccCostWithTax\":0.0,\"verizonCardPromoOfferList\":[],\"taxDetailsList\":[],\"subTotalDueTodayWithoutUpgradeFee\":0.0,\"subTotalDueMonthlyForAALBYODEUP\":0.0,\"shipTogetherPref\":true,\"assistanceOptedByCustomer\":false,\"totalVerizonDollarUsed\":\"0.0\",\"isShellAccountSelected\":false,\"guestOrInactiveRefundLines\":false,\"totalDueMonthlyOnProfile\":0.0,\"subTotalDueMonthlyOnProfile\":0.0,\"totalMonthlyTaxesOnProfile\":0.0,\"subTotalOtherLinesOnProfile\":0.0,\"estimatedNextMonthChargeOnProfile\":0.0,\"totalDueMonthlyAfterDiscounts\":0.0,\"totalActivationFees\":0.0,\"orderType\":\"PS\",\"locationCode\":\"0862001\",\"customerType\":\"N\",\"billingSystem\":\"VE\",\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CA CVAS AUTOMATIC APPROVAL\",\"securityDepositAmount\":\"0.0\",\"totalTaxAmount\":\"0.0\",\"totalDueToday\":0.0,\"totalDueMonthly\":60.0,\"subTotalDueMonthly\":60.0,\"subTotalDueToday\":0.0,\"subTotalMonthlyTaxes\":0.0,\"estimatedNextMonthCharge\":60.0,\"totalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"orderChannelId\":\"VZW-DOTCOM\",\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":999999000,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CA CVAS AUTOMATIC APPROVAL\",\"internationalEligibility\":false,\"securityDepositAmount\":\"0\"},\"orderActivityType\":\"NSE\",\"orderNumber\":12035672,\"numOfLinesForOrderActivityType\":0,\"preOrderNumber\":0,\"managerApprovalRequired\":false}],\"outletId\":\"8620\",\"registerNumber\":\"0\",\"saleType\":\"P\",\"salesRepId\":\"NPB2C\",\"enableSplitShipment\":false,\"splitShipmentIndicator\":false,\"cartReadyForCheckout\":true,\"isSingleModConnectedDevice\":false,\"fiveGUpSellAccountLevel\":false,\"customerOnTrialPlan\":false,\"availableSlotsForGrantee\":\"0\",\"totalDownPaymentAmt\":0.0,\"totalEdgeBuyOutAmount\":0.0,\"expressCheckout\":false,\"isEQPandPPLOfferApplied\":false,\"cartTotalDiscounts\":{\"totalDiscount\":\"0.0\",\"discountDetails\":[]},\"memberTotalDueToday\":0.0,\"eligible5GHomeBundle\":[],\"totalDwosCost\":\"0.0\",\"billingState\":\"GA\",\"isTradeInOfferSelected\":false}";
        CXPCartItem itemsInfo1 = mapper.readValue(sampleRequestString1, CXPCartItem.class);
        CXPOrderDetailsView orderDetailsView = mapper.readValue(sampleRequestString2, CXPOrderDetailsView.class);
        helper.validateFWASweetnerDealInOrder(orderDetailsView,itemsInfo1);
    }

    @Test
    public void validateFWASweetnerDealInOrderTest2() throws IOException, SOEHTTPException {
        String sampleRequestString1 = "{\"discountAmount\":0.0,\"deviceDollarApplied\":0.0,\"promoHubOfferList\":{\"promoHubOfferList\":[],\"offerCount\":0},\"qrScanNeededForEsimActivation\":false,\"isPreconfigureDuringAddDevice\":false,\"deviceDisplayName\":\"VZ INT ASK-NCQ1338FA\",\"accessoryGiftCardAmount\":0.0,\"tradeInAmountTowardsUserDPUsed\":0.0,\"sorDeviceCategory\":\"5G Router\",\"sorDeviceType\":\"5GE\",\"vendingKioskItem\":\"false\",\"tradeInAutoPull\":false,\"priceAdjustment\":false,\"priceAdjustmentQty\":0,\"newPurchasedQty\":0,\"networkBandwidthType\":\"LTE\",\"selectedForRFEX\":false,\"selectedForPAD\":false,\"bogoItem\":false,\"refxItemSeqNum\":0,\"restrictedAccySku\":false,\"maxAccyPurchaseLimit\":false,\"itemCode\":\"ASK-NCQ1338FA\",\"totalPriceWithDiscount\":0.0,\"sorId\":\"ASK-NCQ1338FA\",\"skuId\":\"sku5290001\",\"cartItemType\":\"DEVICE\",\"mobileNumber\":\"newLine1\",\"description\":\"Verizon Internet Gateway\",\"qty\":1,\"deviceDueToday\":0.0,\"bundleSeqNum\":0,\"itemPrice\":\"0.0\",\"discountedPercentage\":0.0,\"discountedPrice\":0.0,\"buyOutTaxAmountUnbilled\":0.0,\"buyOutAmountWithoutTax\":0.0,\"taxAmount\":0.0,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-2-router-white-arc-xci55ax\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-2-router-white-arc-xci55ax?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-2-router-white-arc-xci55ax?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-2-router-white-arc-xci55ax?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-2-router-white-arc-xci55ax?$device-thumb$\"},\"prodCode1\":\"5GD\",\"prodCode2\":\"NIC\",\"prodCode3\":\"5IR\",\"prodCode4\":\"B2B\",\"prodCode5\":\"RNT\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"depletionType\":\"O\",\"catalogPrice\":0.0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"color\":{},\"unitTaxBasedPrice\":0.0,\"itemNrpPrice\":0.0,\"itemCost\":0.0,\"upgradeReasonCode\":\"\",\"upgradeReasonDesc\":\"Invalid Reason Code - 0yr\",\"itemPriceType\":\"R\",\"discounts\":[],\"availableReasonCode\":[],\"inventory\":{\"isAvailable\":true,\"isBackorder\":false,\"isDeliverBy\":false,\"isPreOrder\":false,\"qtyAvailable\":105444},\"isCustomerProvidedSIM\":false,\"rebateOffers\": [ {\"description\": \"$201 Redemption Limit Barcode Test\",\"rebateAmount\": \"201.00\",\"revokeRebate\": false,\"platformPromoType\":\"Sweetener\",\"offerSubType\": \"Virtual Reward\",\"barcodeId\":\"UATTESTB1950\"}],\"isNetworkExtender\":false,\"ispuEligible\":true,\"itemSeqNum\":1,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0,\"sellerPrice\":\"0.0\",\"edgeDeviceCap\":\"0\",\"productId\":\"dev18800001\",\"numberShareCapabilityInfo\":{\"sorHdVoiceInd\":false,\"isNumberShareCapable\":false,\"isNumberShareMandatory\":false},\"taxDetailsList\":[],\"hasDeviceUnlockPolicy\":false,\"manufacturer\":\"Askey\",\"iconicPhone\":false,\"ringBell\":false,\"isPreconfigureEnabled\":false,\"isHumDevice\":false,\"isSmartLocator\":false,\"isSecurityAlarm\":false,\"isMotoMod\":false,\"isConnectedCar\":false,\"accountLevelAccessory\":false,\"byodESimPhone\":false,\"appleCareAccessoryFlag\":false}";
        String sampleRequestString2 = "{\"totalUpgradeFee\":0.0,\"totalDeviceDollar\":0.0,\"totalRemainingDeviceDollar\":0.0,\"totalUsedDeviceDollar\":0.0,\"totalAccountLevelAccCost\":0.0,\"totalAccountLevelAccCostWithTax\":0.0,\"verizonCardPromoOfferList\":[],\"taxDetailsList\":[],\"subTotalDueTodayWithoutUpgradeFee\":0.0,\"subTotalDueMonthlyForAALBYODEUP\":0.0,\"shipTogetherPref\":true,\"assistanceOptedByCustomer\":false,\"totalVerizonDollarUsed\":\"0.0\",\"isShellAccountSelected\":false,\"guestOrInactiveRefundLines\":false,\"totalDueMonthlyOnProfile\":0.0,\"subTotalDueMonthlyOnProfile\":0.0,\"totalMonthlyTaxesOnProfile\":0.0,\"subTotalOtherLinesOnProfile\":0.0,\"estimatedNextMonthChargeOnProfile\":0.0,\"totalDueMonthlyAfterDiscounts\":0.0,\"totalActivationFees\":0.0,\"orderType\":\"PS\",\"locationCode\":\"0862001\",\"customerType\":\"N\",\"billingSystem\":\"VE\",\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CA CVAS AUTOMATIC APPROVAL\",\"securityDepositAmount\":\"0.0\",\"totalTaxAmount\":\"0.0\",\"totalDueToday\":0.0,\"totalDueMonthly\":60.0,\"subTotalDueMonthly\":60.0,\"subTotalDueToday\":0.0,\"subTotalMonthlyTaxes\":0.0,\"estimatedNextMonthCharge\":60.0,\"totalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"orderChannelId\":\"VZW-DOTCOM\",\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":999999000,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CA CVAS AUTOMATIC APPROVAL\",\"internationalEligibility\":false,\"securityDepositAmount\":\"0\"},\"orderActivityType\":\"NSE\",\"orderNumber\":12035672,\"numOfLinesForOrderActivityType\":0,\"preOrderNumber\":0,\"managerApprovalRequired\":false}],\"outletId\":\"8620\",\"registerNumber\":\"0\",\"saleType\":\"P\",\"salesRepId\":\"NPB2C\",\"enableSplitShipment\":false,\"splitShipmentIndicator\":false,\"cartReadyForCheckout\":true,\"isSingleModConnectedDevice\":false,\"fiveGUpSellAccountLevel\":false,\"customerOnTrialPlan\":false,\"availableSlotsForGrantee\":\"0\",\"totalDownPaymentAmt\":0.0,\"totalEdgeBuyOutAmount\":0.0,\"expressCheckout\":false,\"isEQPandPPLOfferApplied\":false,\"cartTotalDiscounts\":{\"totalDiscount\":\"0.0\",\"discountDetails\":[]},\"memberTotalDueToday\":0.0,\"eligible5GHomeBundle\":[],\"totalDwosCost\":\"0.0\",\"billingState\":\"GA\",\"isTradeInOfferSelected\":false}";
        CXPCartItem itemsInfo1 = mapper.readValue(sampleRequestString1, CXPCartItem.class);
        CXPOrderDetailsView orderDetailsView = mapper.readValue(sampleRequestString2, CXPOrderDetailsView.class);
        itemsInfo1.getRebateOffers().clear();
        helper.validateFWASweetnerDealInOrder(orderDetailsView, itemsInfo1);
    }

    @Test
    public void validateFWASweetnerDealInOrderTest3() throws Exception {
        String sampleRequestString1 = "{\"discountAmount\":0.0,\"deviceDollarApplied\":0.0,\"promoHubOfferList\":{\"promoHubOfferList\":[],\"offerCount\":0},\"qrScanNeededForEsimActivation\":false,\"isPreconfigureDuringAddDevice\":false,\"deviceDisplayName\":\"VZ INT ASK-NCQ1338FA\",\"accessoryGiftCardAmount\":0.0,\"tradeInAmountTowardsUserDPUsed\":0.0,\"sorDeviceCategory\":\"5G Router\",\"sorDeviceType\":\"5GE\",\"vendingKioskItem\":\"false\",\"tradeInAutoPull\":false,\"priceAdjustment\":false,\"priceAdjustmentQty\":0,\"newPurchasedQty\":0,\"networkBandwidthType\":\"LTE\",\"selectedForRFEX\":false,\"selectedForPAD\":false,\"bogoItem\":false,\"refxItemSeqNum\":0,\"restrictedAccySku\":false,\"maxAccyPurchaseLimit\":false,\"itemCode\":\"ASK-NCQ1338FA\",\"totalPriceWithDiscount\":0.0,\"sorId\":\"ASK-NCQ1338FA\",\"skuId\":\"sku5290001\",\"cartItemType\":\"DEVICE\",\"mobileNumber\":\"newLine1\",\"description\":\"Verizon Internet Gateway\",\"qty\":1,\"deviceDueToday\":0.0,\"bundleSeqNum\":0,\"itemPrice\":\"0.0\",\"discountedPercentage\":0.0,\"discountedPrice\":0.0,\"buyOutTaxAmountUnbilled\":0.0,\"buyOutAmountWithoutTax\":0.0,\"taxAmount\":0.0,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-2-router-white-arc-xci55ax\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-2-router-white-arc-xci55ax?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-2-router-white-arc-xci55ax?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-2-router-white-arc-xci55ax?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/vzw-internet-gateway-askey-titan-2-router-white-arc-xci55ax?$device-thumb$\"},\"prodCode1\":\"5GD\",\"prodCode2\":\"NIC\",\"prodCode3\":\"5IR\",\"prodCode4\":\"B2B\",\"prodCode5\":\"RNT\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"depletionType\":\"O\",\"catalogPrice\":0.0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"color\":{},\"unitTaxBasedPrice\":0.0,\"itemNrpPrice\":0.0,\"itemCost\":0.0,\"upgradeReasonCode\":\"\",\"upgradeReasonDesc\":\"Invalid Reason Code - 0yr\",\"itemPriceType\":\"R\",\"discounts\":[],\"availableReasonCode\":[],\"inventory\":{\"isAvailable\":true,\"isBackorder\":false,\"isDeliverBy\":false,\"isPreOrder\":false,\"qtyAvailable\":105444},\"isCustomerProvidedSIM\":false,\"rebateOffers\": [ {\"description\": \"$201 Redemption Limit Barcode Test\",\"rebateAmount\": \"201.00\",\"revokeRebate\": false,\"platformPromoType\":\"Sweetener\",\"offerSubType\": \"Virtual Reward\",\"barcodeId\":\"UATTESTB1950\"}],\"isNetworkExtender\":false,\"ispuEligible\":true,\"itemSeqNum\":1,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0,\"sellerPrice\":\"0.0\",\"edgeDeviceCap\":\"0\",\"productId\":\"dev18800001\",\"numberShareCapabilityInfo\":{\"sorHdVoiceInd\":false,\"isNumberShareCapable\":false,\"isNumberShareMandatory\":false},\"taxDetailsList\":[],\"hasDeviceUnlockPolicy\":false,\"manufacturer\":\"Askey\",\"iconicPhone\":false,\"ringBell\":false,\"isPreconfigureEnabled\":false,\"isHumDevice\":false,\"isSmartLocator\":false,\"isSecurityAlarm\":false,\"isMotoMod\":false,\"isConnectedCar\":false,\"accountLevelAccessory\":false,\"byodESimPhone\":false,\"appleCareAccessoryFlag\":false}";
        String sampleRequestString2 = "{\"totalUpgradeFee\":0.0,\"totalDeviceDollar\":0.0,\"totalRemainingDeviceDollar\":0.0,\"totalUsedDeviceDollar\":0.0,\"totalAccountLevelAccCost\":0.0,\"totalAccountLevelAccCostWithTax\":0.0,\"verizonCardPromoOfferList\":[],\"taxDetailsList\":[],\"subTotalDueTodayWithoutUpgradeFee\":0.0,\"subTotalDueMonthlyForAALBYODEUP\":0.0,\"shipTogetherPref\":true,\"assistanceOptedByCustomer\":false,\"totalVerizonDollarUsed\":\"0.0\",\"isShellAccountSelected\":false,\"guestOrInactiveRefundLines\":false,\"totalDueMonthlyOnProfile\":0.0,\"subTotalDueMonthlyOnProfile\":0.0,\"totalMonthlyTaxesOnProfile\":0.0,\"subTotalOtherLinesOnProfile\":0.0,\"estimatedNextMonthChargeOnProfile\":0.0,\"totalDueMonthlyAfterDiscounts\":0.0,\"totalActivationFees\":0.0,\"orderType\":\"PS\",\"locationCode\":\"0862001\",\"customerType\":\"N\",\"billingSystem\":\"VE\",\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CA CVAS AUTOMATIC APPROVAL\",\"securityDepositAmount\":\"0.0\",\"totalTaxAmount\":\"0.0\",\"totalDueToday\":0.0,\"totalDueMonthly\":60.0,\"subTotalDueMonthly\":60.0,\"subTotalDueToday\":0.0,\"subTotalMonthlyTaxes\":0.0,\"estimatedNextMonthCharge\":60.0,\"totalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"orderChannelId\":\"VZW-DOTCOM\",\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":999999000,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CA CVAS AUTOMATIC APPROVAL\",\"internationalEligibility\":false,\"securityDepositAmount\":\"0\"},\"orderActivityType\":\"NSE\",\"orderNumber\":12035672,\"numOfLinesForOrderActivityType\":0,\"preOrderNumber\":0,\"managerApprovalRequired\":false}],\"outletId\":\"8620\",\"registerNumber\":\"0\",\"saleType\":\"P\",\"salesRepId\":\"NPB2C\",\"enableSplitShipment\":false,\"splitShipmentIndicator\":false,\"cartReadyForCheckout\":true,\"isSingleModConnectedDevice\":false,\"fiveGUpSellAccountLevel\":false,\"customerOnTrialPlan\":false,\"availableSlotsForGrantee\":\"0\",\"totalDownPaymentAmt\":0.0,\"totalEdgeBuyOutAmount\":0.0,\"expressCheckout\":false,\"isEQPandPPLOfferApplied\":false,\"cartTotalDiscounts\":{\"totalDiscount\":\"0.0\",\"discountDetails\":[]},\"memberTotalDueToday\":0.0,\"eligible5GHomeBundle\":[],\"totalDwosCost\":\"0.0\",\"billingState\":\"GA\",\"isTradeInOfferSelected\":false}";
        CXPCartItem itemsInfo1 = mapper.readValue(sampleRequestString1, CXPCartItem.class);
        CXPOrderDetailsView orderDetailsView = mapper.readValue(sampleRequestString2, CXPOrderDetailsView.class);
        itemsInfo1.getRebateOffers().get(0).setBarcodeId("");
        helper.validateFWASweetnerDealInOrder(orderDetailsView, itemsInfo1);

    }

}


