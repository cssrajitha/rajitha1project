package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper2;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper3;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.AddFeaturesUIRequest;
import onevz.soe.cart.ui.requests.InitiateCheckoutUIRequest;
import onevz.soe.cart.ui.requests.UpdateBarcodeUIRequest;
import onevz.soe.cart.ui.responses.AddFeaturesUIResponse;
import onevz.soe.cart.ui.responses.InitiateCheckoutUIResponse;
import onevz.soe.cart.ui.responses.UpdateBarcodeUIResponse;
import onevz.soe.cart.ui.responses.ValidateCartUIResponse;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(UpdateCartHelper.class)
public class CartServiceHelper7Test {

    @Autowired
    private UpdateCartHelper helper;

    @MockBean
    private CartServiceCxpHelper cxpHelper;

    @MockBean
    private CartServiceBpmHelper2 bpmHelper2;

    @MockBean
    private CartServiceBpmHelper3 bpmHelper3;

    @MockBean
    private RedisHelper redisHelper;
    @MockBean
    private FeatureFlagHelper featureFlagHelper;
    @MockBean
    private RedisHelper2 redisHelper2;

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;
    @MockBean
    private OmniDLHelper omniDLHelper;

    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;

    @Test
    public void validateCartAndCheckoutHelperTest1() throws IOException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest5.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse2.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse2.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData143.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        ValidateCartUIResponse sampleValidateResponse = null;
        InitiateCheckoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, InitiateCheckoutUIRequest.class);
        sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(bpmHelper2.validateOrder(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        Mono<InitiateCheckoutUIResponse> response = helper.validateCartAndCheckout(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void validateCartAndCheckoutHelperTest2() throws IOException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest6.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse2.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse2.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData144.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        ValidateCartUIResponse sampleValidateResponse = null;
        InitiateCheckoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, InitiateCheckoutUIRequest.class);
        sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(bpmHelper2.validateOrder(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        Mono<InitiateCheckoutUIResponse> response = helper.validateCartAndCheckout(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void validateCartAndCheckoutHelperTest3() throws IOException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest7.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse2.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse2.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData144.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        ValidateCartUIResponse sampleValidateResponse = null;
        InitiateCheckoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, InitiateCheckoutUIRequest.class);
        sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(bpmHelper2.validateOrder(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        Mono<InitiateCheckoutUIResponse> response = helper.validateCartAndCheckout(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void validateCartAndCheckoutHelperTest4() throws IOException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest7.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse2.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse2.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData145.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        ValidateCartUIResponse sampleValidateResponse = null;
        InitiateCheckoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, InitiateCheckoutUIRequest.class);
        sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(bpmHelper2.validateOrder(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        Mono<InitiateCheckoutUIResponse> response = helper.validateCartAndCheckout(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void validateCartAndCheckoutHelperTest5() throws IOException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest8.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse2.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse2.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData145.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        ValidateCartUIResponse sampleValidateResponse = null;
        InitiateCheckoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, InitiateCheckoutUIRequest.class);
        sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(bpmHelper2.validateOrder(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        Mono<InitiateCheckoutUIResponse> response = helper.validateCartAndCheckout(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void validateCartAndCheckoutHelperTest6() throws IOException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest9.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse2.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse2.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData146.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        ValidateCartUIResponse sampleValidateResponse = null;
        InitiateCheckoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, InitiateCheckoutUIRequest.class);
        sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(bpmHelper2.validateOrder(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        Mono<InitiateCheckoutUIResponse> response = helper.validateCartAndCheckout(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void validateCartAndCheckoutHelperTest7() throws IOException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest10.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse2.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse2.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        ValidateCartUIResponse sampleValidateResponse = null;
        InitiateCheckoutUIResponse sampleResponse =  mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, InitiateCheckoutUIRequest.class);
        sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(bpmHelper2.validateOrder(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        Mono<InitiateCheckoutUIResponse> response = helper.validateCartAndCheckout(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void validateCartAndCheckoutHelperTest8() throws IOException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest11.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse2.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse13.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        InitiateCheckoutUIResponse sampleResponse =  mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, InitiateCheckoutUIRequest.class);
        ValidateCartUIResponse sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(featureFlagHelper.earlyUpgradeBlockerFeatureFlag()).thenReturn(Mono.just(true));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(bpmHelper2.validateOrder(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        Mono<InitiateCheckoutUIResponse> response = helper.validateCartAndCheckout(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void validateCartAndCheckoutHelperTest9() throws IOException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest12.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse2.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse12.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        InitiateCheckoutUIResponse sampleResponse =  mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, InitiateCheckoutUIRequest.class);
        ValidateCartUIResponse sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(featureFlagHelper.earlyUpgradeBlockerFeatureFlag()).thenReturn(Mono.just(true));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(bpmHelper2.validateOrder(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        Mono<InitiateCheckoutUIResponse> response = helper.validateCartAndCheckout(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void validateCartAndCheckoutHelperTest10() throws IOException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest13.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse2.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse14.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        InitiateCheckoutUIResponse sampleResponse =  mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, InitiateCheckoutUIRequest.class);
        ValidateCartUIResponse sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(featureFlagHelper.earlyUpgradeBlockerFeatureFlag()).thenReturn(Mono.just(true));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(bpmHelper2.validateOrder(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        Mono<InitiateCheckoutUIResponse> response = helper.validateCartAndCheckout(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void validateCartAndCheckoutHelperTest11() throws IOException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest14.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse2.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse15.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        ValidateCartUIResponse sampleValidateResponse = null;
        InitiateCheckoutUIResponse sampleResponse =  mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, InitiateCheckoutUIRequest.class);
        sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(bpmHelper2.validateOrder(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        Mono<InitiateCheckoutUIResponse> response = helper.validateCartAndCheckout(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void validateCartAndCheckoutHelperTest12() throws IOException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest14.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse2.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse16.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        ValidateCartUIResponse sampleValidateResponse = null;
        InitiateCheckoutUIResponse sampleResponse =  mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, InitiateCheckoutUIRequest.class);
        sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(bpmHelper2.validateOrder(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        Mono<InitiateCheckoutUIResponse> response = helper.validateCartAndCheckout(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void validateCartAndCheckoutHelperTest13() throws IOException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest15.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse2.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse17.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        ValidateCartUIResponse sampleValidateResponse = null;
        InitiateCheckoutUIResponse sampleResponse =  mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, InitiateCheckoutUIRequest.class);
        sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(bpmHelper2.validateOrder(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        Mono<InitiateCheckoutUIResponse> response = helper.validateCartAndCheckout(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void validateCartAndCheckoutHelperTest14() throws IOException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest16.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse2.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse18.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        ValidateCartUIResponse sampleValidateResponse = null;
        InitiateCheckoutUIResponse sampleResponse =  mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, InitiateCheckoutUIRequest.class);
        sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(bpmHelper2.validateOrder(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        Mono<InitiateCheckoutUIResponse> response = helper.validateCartAndCheckout(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void validateCartAndCheckoutHelperTest15() throws IOException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest16.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse2.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse19.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        InitiateCheckoutUIResponse sampleResponse =  mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, InitiateCheckoutUIRequest.class);
        ValidateCartUIResponse sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(featureFlagHelper.earlyUpgradeBlockerFeatureFlag()).thenReturn(Mono.just(true));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(bpmHelper2.validateOrder(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        Mono<InitiateCheckoutUIResponse> response = helper.validateCartAndCheckout(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void validateCartAndCheckoutHelperTest16() throws IOException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest17.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse2.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse20.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        InitiateCheckoutUIResponse sampleResponse =  mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, InitiateCheckoutUIRequest.class);
        ValidateCartUIResponse sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(featureFlagHelper.earlyUpgradeBlockerFeatureFlag()).thenReturn(Mono.just(true));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(bpmHelper2.validateOrder(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        Mono<InitiateCheckoutUIResponse> response = helper.validateCartAndCheckout(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void validateCartAndCheckoutHelperTest17() throws IOException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest17.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse2.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse21.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        InitiateCheckoutUIResponse sampleResponse =  mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, InitiateCheckoutUIRequest.class);
        ValidateCartUIResponse sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(featureFlagHelper.earlyUpgradeBlockerFeatureFlag()).thenReturn(Mono.just(true));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(bpmHelper2.validateOrder(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        Mono<InitiateCheckoutUIResponse> response = helper.validateCartAndCheckout(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void validateCartAndCheckoutHelperTest18() throws IOException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest17.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse2.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse22.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        InitiateCheckoutUIResponse sampleResponse =  mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, InitiateCheckoutUIRequest.class);
        ValidateCartUIResponse sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(featureFlagHelper.earlyUpgradeBlockerFeatureFlag()).thenReturn(Mono.just(true));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(bpmHelper2.validateOrder(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        Mono<InitiateCheckoutUIResponse> response = helper.validateCartAndCheckout(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void validateCartAndCheckoutHelperTest19() throws IOException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest16.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse2.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse21.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        InitiateCheckoutUIResponse sampleResponse =  mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, InitiateCheckoutUIRequest.class);
        ValidateCartUIResponse sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(featureFlagHelper.earlyUpgradeBlockerFeatureFlag()).thenReturn(Mono.just(true));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(bpmHelper2.validateOrder(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        Mono<InitiateCheckoutUIResponse> response = helper.validateCartAndCheckout(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addFeatureHelperTest1() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddFeaturesUIResponse.json", testFileLocation);;
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddFeaturesUIRequest3.json", testFileLocation);
        AddFeaturesUIRequest sampleUIRequest =  mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
        AddFeaturesUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddFeaturesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData147.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddFeaturesUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getAddFeaturesRequest()).thenReturn(Mono.just(sampleUIRequest));
        when(bpmHelper2.addFeatures(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        Mono<AddFeaturesUIResponse> response = helper.addFeatures(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addFeatureHelperTest2() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddFeaturesUIResponse.json", testFileLocation);;
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddFeaturesUIRequest3.json", testFileLocation);
        AddFeaturesUIRequest sampleUIRequest =  mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
        AddFeaturesUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddFeaturesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData148.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddFeaturesUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getAddFeaturesRequest()).thenReturn(Mono.just(sampleUIRequest));
        when(bpmHelper2.addFeatures(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        Mono<AddFeaturesUIResponse> response = helper.addFeatures(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addFeatureHelperTest3() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddFeaturesUIResponse.json", testFileLocation);;
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddFeaturesUIRequest4.json", testFileLocation);
        AddFeaturesUIRequest sampleUIRequest =  mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
        AddFeaturesUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddFeaturesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData149.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddFeaturesUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getAddFeaturesRequest()).thenReturn(Mono.just(sampleUIRequest));
        when(bpmHelper2.addFeatures(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        Mono<AddFeaturesUIResponse> response = helper.addFeatures(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addFeatureHelperTest4() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddFeaturesUIResponse.json", testFileLocation);;
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddFeaturesUIRequest5.json", testFileLocation);
        AddFeaturesUIRequest sampleUIRequest =  mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
        AddFeaturesUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddFeaturesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData149.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddFeaturesUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getAddFeaturesRequest()).thenReturn(Mono.just(sampleUIRequest));
        when(bpmHelper2.addFeatures(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        Mono<AddFeaturesUIResponse> response = helper.addFeatures(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addFeatureHelperTest5() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddFeaturesUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddFeaturesUIRequest7.json", testFileLocation);
        AddFeaturesUIRequest sampleUIRequest =  mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
        AddFeaturesUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddFeaturesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData150.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddFeaturesUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getAddFeaturesRequest()).thenReturn(Mono.just(sampleUIRequest));
        when(bpmHelper2.addFeatures(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        Mono<AddFeaturesUIResponse> response = helper.addFeatures(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addFeatureHelperTest6() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddFeaturesUIResponse.json", testFileLocation);;
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddFeaturesUIRequest8.json", testFileLocation);
        AddFeaturesUIRequest sampleUIRequest =  mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
        AddFeaturesUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddFeaturesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData147.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddFeaturesUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getAddFeaturesRequest()).thenReturn(Mono.just(sampleUIRequest));
        when(bpmHelper2.addFeatures(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        Mono<AddFeaturesUIResponse> response = helper.addFeatures(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addFeatureHelperTest7() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddFeaturesUIResponse.json", testFileLocation);;
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddFeaturesUIRequest9.json", testFileLocation);
        AddFeaturesUIRequest sampleUIRequest =  mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
        AddFeaturesUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddFeaturesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData151.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddFeaturesUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getAddFeaturesRequest()).thenReturn(Mono.just(sampleUIRequest));
        when(bpmHelper2.addFeatures(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        Mono<AddFeaturesUIResponse> response = helper.addFeatures(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addFeatureHelperTest8() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddFeaturesUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddFeaturesUIRequest10.json", testFileLocation);
        AddFeaturesUIRequest sampleUIRequest =  mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
        AddFeaturesUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddFeaturesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData151.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddFeaturesUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getAddFeaturesRequest()).thenReturn(Mono.just(sampleUIRequest));
        when(bpmHelper2.addFeatures(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        Mono<AddFeaturesUIResponse> response = helper.addFeatures(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addFeatureHelperTest9() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddFeaturesUIResponse1.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddFeaturesUIRequest11.json", testFileLocation);
        AddFeaturesUIRequest sampleUIRequest =  mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
        AddFeaturesUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddFeaturesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData152.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddFeaturesUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getAddFeaturesRequest()).thenReturn(Mono.just(sampleUIRequest));
        when(bpmHelper2.addFeatures(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("true"));
        Mono<AddFeaturesUIResponse> response = helper.addFeatures(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addFeatureHelperTest10() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddFeaturesUIResponse12.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddFeaturesUIRequest12.json", testFileLocation);
        AddFeaturesUIRequest sampleUIRequest =  mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
        AddFeaturesUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddFeaturesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData153.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddFeaturesUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getAddFeaturesRequest()).thenReturn(Mono.just(sampleUIRequest));
        when(bpmHelper2.addFeatures(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just(""));
        Mono<AddFeaturesUIResponse> response = helper.addFeatures(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateBarcodeHelperForREX() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIRequest6.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIResponse2.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData154.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        UpdateBarcodeUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateBarcodeUIRequest.class);
        UpdateBarcodeUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateBarcodeUIResponse.class);
        Mono<UpdateBarcodeUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse1.json", testFileLocation);
        ValidateCartUIResponse sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(bpmHelper3.updateBarcode(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.upsertValueInRedis(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        Mono<UpdateBarcodeUIResponse> response = helper.updateBarcode(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }
    @Test
    public void validateCartAndCheckoutValidationErrorTest20() throws IOException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest18.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse20.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIPriceRestrictionResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        InitiateCheckoutUIResponse sampleResponse =  mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, InitiateCheckoutUIRequest.class);
        ValidateCartUIResponse sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(featureFlagHelper.earlyUpgradeBlockerFeatureFlag()).thenReturn(Mono.just(true));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(bpmHelper2.validateOrder(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        Mono<InitiateCheckoutUIResponse> response = helper.validateCartAndCheckout(sampleUIRequest);
        StepVerifier.create(response).assertNext(Assert::assertNotNull).expectComplete().verify();
    }
    @Test
    public void updateFlowNameForAssistedHelperTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddFeaturesUIRequest1.json", testFileLocation);
        //String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/GenericResponse.json", testFileLocation);
        String sampleResponseString = "{ \"serviceHeader\": { \"clientId\": \"OMNI-RETAIL\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\", \"correlationId\": \"soe-cart-2024.08.02.00.15.41-49.83925033013181\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \"SOP-17973439-E01\", \"contextInfo\": { \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"FeaturesPDP\", \"processAction\": \"\", \"availablePaths\": [ { \"path\": \"FeaturesPDP\" } ] }, \"customerInfo\": { \"nocByod\": false, \"accountNumber\": \"0286430928-00001\", \"cartCreator\": \"5702094433\", \"processingMTN\": \"5702094433\", \"registerNumber\": 0, \"noc\": false, \"myvPage\": false }, \"cartInfo\": { \"cartItemCount\": 0, \"cartId\": \"5d5caca1-7a75-4769-a2ab-79703376513d\", \"lines\": [ { \"status\": 1, \"spos\": [ { \"id\": \"671\", \"conflictId\": \"\" }, { \"id\": \"672\", \"conflictId\": \"\" }, { \"id\": \"2491\", \"conflictId\": \"\" }, { \"id\": \"1087\", \"conflictId\": \"\" }, { \"id\": \"1256\", \"conflictId\": \"\" }, { \"id\": \"1465\", \"conflictId\": \"\" } ], \"sfos\": [ { \"id\": \"78459\", \"conflictId\": \"\" }, { \"id\": \"75632\", \"conflictId\": \"\" }, { \"id\": \"77249\", \"conflictId\": \"\" }, { \"id\": \"77581\", \"conflictId\": \"\" }, { \"id\": \"77583\", \"conflictId\": \"\" }, { \"id\": \"80148\", \"conflictId\": \"\" }, { \"id\": \"84021\", \"conflictId\": \"\" }, { \"id\": \"84071\", \"conflictId\": \"\" }, { \"id\": \"84076\", \"conflictId\": \"\" }, { \"id\": \"84077\", \"conflictId\": \"\" }, { \"id\": \"86198\", \"conflictId\": \"\" }, { \"id\": \"86204\", \"conflictId\": \"\" }, { \"id\": \"86209\", \"conflictId\": \"\" }, { \"id\": \"88764\", \"conflictId\": \"\" }, { \"id\": \"88766\", \"conflictId\": \"\" }, { \"id\": \"88768\", \"conflictId\": \"\" } ], \"eupNoPromoFlow\": false, \"mtn\": \"5702094433\", \"devicePlanCompatible\": true, \"planValidationFailed\": false, \"lineActivityType\": \"CPC\", \"currentPlanType\": \"LLP\", \"editSim\": false, \"lineWithSkipMDN\": false, \"inWithVerizonOpted\": false, \"protectionNotRequired\": false, \"skipPromoChoiceOffer\": false }, { \"status\": 1, \"spos\": [ { \"id\": \"671\", \"conflictId\": \"\" }, { \"id\": \"672\", \"conflictId\": \"\" }, { \"id\": \"2491\", \"conflictId\": \"\" }, { \"id\": \"383\", \"conflictId\": \"\" }, { \"id\": \"1255\", \"conflictId\": \"\" }, { \"id\": \"2639\", \"conflictId\": \"\" }, { \"id\": \"2839\", \"conflictId\": \"\" } ], \"sfos\": [ { \"id\": \"73502\", \"conflictId\": \"\" }, { \"id\": \"73503\", \"conflictId\": \"\" }, { \"id\": \"76152\", \"conflictId\": \"\" }, { \"id\": \"77249\", \"conflictId\": \"\" }, { \"id\": \"77581\", \"conflictId\": \"\" }, { \"id\": \"77583\", \"conflictId\": \"\" }, { \"id\": \"84015\", \"conflictId\": \"\" }, { \"id\": \"84071\", \"conflictId\": \"\" }, { \"id\": \"84076\", \"conflictId\": \"\" }, { \"id\": \"84077\", \"conflictId\": \"\" }, { \"id\": \"85553\", \"conflictId\": \"\" }, { \"id\": \"86189\", \"conflictId\": \"\" }, { \"id\": \"86209\", \"conflictId\": \"\" }, { \"id\": \"87046\", \"conflictId\": \"\" }, { \"id\": \"88888\", \"conflictId\": \"\" }, { \"id\": \"89668\", \"conflictId\": \"\" }, { \"id\": \"89670\", \"conflictId\": \"\" }, { \"id\": \"89672\", \"conflictId\": \"\" }, { \"id\": \"89674\", \"conflictId\": \"\" } ], \"eupNoPromoFlow\": false, \"mtn\": \"5702093507\", \"devicePlanCompatible\": true, \"planValidationFailed\": false, \"lineActivityType\": \"CPC\", \"currentPlanType\": \"LLP\", \"editSim\": false, \"lineWithSkipMDN\": false, \"inWithVerizonOpted\": false, \"protectionNotRequired\": false, \"skipPromoChoiceOffer\": false } ], \"discountPromoTotal\": 0.0, \"registerNumber\": 0, \"hasMixAndMatchPlan\": false, \"isPlanChangeRequiredOnMultiLines\": false, \"protectionNotRequired\": false, \"fmiCheck\": false, \"lineDevices\": [ { \"mtn\": \"5702094433\", \"deviceCategory\": \"\", \"lineActivityType\": \"CPC\", \"promoIntent\": [] }, { \"mtn\": \"5702093507\", \"deviceCategory\": \"\", \"lineActivityType\": \"CPC\", \"promoIntent\": [] } ], \"isFlexV2\": false, \"isPrepaidToPostpaidMigration\": false, \"instantCreditAmount\": 0, \"flow\": \"FEA|CPC|FEA\", \"ngdFlow\": false }, \"processMTNList\": [ { \"mtn\": \"5702094433\", \"completedprocessSteps\": [] } ] } } }, \"warnings\": [] }";
        AddFeaturesUIRequest sampleRequest = null;
        AddFeaturesUIResponse sampleResponse = null;

        sampleRequest = mapper.readValue(sampleRequestString, AddFeaturesUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, AddFeaturesUIResponse.class);
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.updateProtectionVersionInRedis(" ")).thenReturn(Mono.just(Boolean.TRUE));
        when(omniDLHelper.setFlow(Mockito.any(), Mockito.any())).thenReturn(Mono.just("FEA"));
        sampleRequest.setChannelId("OMNI-RETAIL");
        Mono<ResponseEntity<GenericResponse>> response = helper.updateFlowNameForAssisted(sampleRequest,sampleResponse);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        sampleResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setFlow(null);
        response = helper.updateFlowNameForAssisted(sampleRequest,sampleResponse);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        sampleResponse.getServiceBody().getServiceResponse().getContext().setCartInfo(null);
        response = helper.updateFlowNameForAssisted(sampleRequest,sampleResponse);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        sampleResponse.getServiceBody().getServiceResponse().setContext(null);
        response = helper.updateFlowNameForAssisted(sampleRequest,sampleResponse);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        sampleResponse.getServiceBody().setServiceResponse(null);
        response = helper.updateFlowNameForAssisted(sampleRequest,sampleResponse);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        sampleResponse.setServiceBody(null);
        response = helper.updateFlowNameForAssisted(sampleRequest,sampleResponse);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        when(omniDLHelper.setFlow(Mockito.any(), Mockito.any())).thenReturn(Mono.just(""));
        response = helper.updateFlowNameForAssisted(sampleRequest,sampleResponse);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        when(omniDLHelper.setFlow(Mockito.any(), Mockito.any())).thenReturn(null);
        response = helper.updateFlowNameForAssisted(sampleRequest,sampleResponse);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        sampleRequest.setChannelId("dotcom");
        response = helper.updateFlowNameForAssisted(sampleRequest,sampleResponse);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        sampleRequest.setChannelId("");
        response = helper.updateFlowNameForAssisted(sampleRequest,sampleResponse);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        sampleRequest.setChannelId(null);
        response = helper.updateFlowNameForAssisted(sampleRequest,sampleResponse);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.FALSE));
        response = helper.updateFlowNameForAssisted(sampleRequest,sampleResponse);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

    }

}
