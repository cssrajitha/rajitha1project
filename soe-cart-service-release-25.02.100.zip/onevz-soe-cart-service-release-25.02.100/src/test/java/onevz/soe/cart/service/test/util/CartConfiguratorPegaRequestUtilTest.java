package onevz.soe.cart.service.test.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.constants.ConfiguratorConstants;
import onevz.soe.cart.helper.FeatureFlagHelper;
import onevz.soe.cart.model.common.BvoOffers;
import onevz.soe.cart.requests.AddAllConfiguratorPEGARequest;
import onevz.soe.cart.ui.requests.AddAllConfiguratorUIRequest;
import onevz.soe.cart.util.CartConfiguratorPegaRequestUtil;
import onevz.soe.cart.util.SourceFileReaderUtil;
import org.junit.Assert;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@WebFluxTest(CartConfiguratorPegaRequestUtil.class)
public class CartConfiguratorPegaRequestUtilTest {
    @MockBean
    CartConfiguratorPegaRequestUtil util;
    @MockBean
    private FeatureFlagHelper featureFlagHelper;
    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;
    @Autowired
    private ObjectMapper mapper;
    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;


    @Test
    public void formatAddConfiguratorRequestTestForNulls() throws JsonProcessingException {
        when(featureFlagHelper.isNgdTradeInBulkUpdateEnabled()).thenReturn(Boolean.FALSE);
        String requestFile = "data/addAllToCartConfigurator/request/requestForNullCheck.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        AddAllConfiguratorUIRequest uiRequest = mapper.readValue(requestString, AddAllConfiguratorUIRequest.class);
        AddAllConfiguratorPEGARequest pegaRequest = new AddAllConfiguratorPEGARequest();

        AddAllConfiguratorPEGARequest response = CartConfiguratorPegaRequestUtil.formatAddConfiguratorRequest(pegaRequest, uiRequest, featureFlagHelper.isNgdTradeInBulkUpdateEnabled());
        Assertions.assertNotNull(response.getServiceBody().getServiceRequest().getContext());
        Assertions.assertNotNull(response.getServiceHeader());
        Assertions.assertNotNull(response.getServiceBody().getServiceRequest().getContext().getCartInfo());
        Assert.assertEquals(ConfiguratorConstants.CONFIGURATOR_ITEM_TYPE, response.getServiceBody().getServiceRequest().getContext().getCartInfo().getItemType());

    }

    @Test
    public void formatAddConfiguratorRequestTestForRequestHeaders() throws JsonProcessingException {
        when(featureFlagHelper.isNgdTradeInBulkUpdateEnabled()).thenReturn(Boolean.FALSE);
        String requestFile = "data/addAllToCartConfigurator/request/requestForNullCheckForHeaders.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        AddAllConfiguratorUIRequest uiRequest = mapper.readValue(requestString, AddAllConfiguratorUIRequest.class);
        AddAllConfiguratorPEGARequest pegaRequest = new AddAllConfiguratorPEGARequest();

        AddAllConfiguratorPEGARequest response = CartConfiguratorPegaRequestUtil.formatAddConfiguratorRequest(pegaRequest, uiRequest, featureFlagHelper.isNgdTradeInBulkUpdateEnabled());
        Assertions.assertNotNull(response.getServiceBody().getServiceRequest().getContext());
        Assertions.assertNotNull(response.getServiceHeader());
        Assertions.assertNotNull(response.getServiceBody().getServiceRequest().getContext().getCartInfo());
        Assert.assertEquals(ConfiguratorConstants.CONFIGURATOR_ITEM_TYPE, response.getServiceBody().getServiceRequest().getContext().getCartInfo().getItemType());

    }

    @Test
    public void formatAddConfiguratorRequestTestForEmpty() throws JsonProcessingException {
        when(featureFlagHelper.isNgdTradeInBulkUpdateEnabled()).thenReturn(Boolean.FALSE);
        String requestFile = "data/addAllToCartConfigurator/request/requestForEmptyCheck.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        AddAllConfiguratorUIRequest uiRequest = mapper.readValue(requestString, AddAllConfiguratorUIRequest.class);
        AddAllConfiguratorPEGARequest pegaRequest = new AddAllConfiguratorPEGARequest();

        AddAllConfiguratorPEGARequest response = CartConfiguratorPegaRequestUtil.formatAddConfiguratorRequest(pegaRequest, uiRequest, featureFlagHelper.isNgdTradeInBulkUpdateEnabled());
        Assertions.assertNotNull(response.getServiceBody().getServiceRequest().getContext());
        Assertions.assertNotNull(response.getServiceHeader());
        Assertions.assertNotNull(response.getServiceBody().getServiceRequest().getContext().getCartInfo());
        Assert.assertEquals(ConfiguratorConstants.CONFIGURATOR_ITEM_TYPE, response.getServiceBody().getServiceRequest().getContext().getCartInfo().getItemType());

    }

    @Test
    public void formatAddConfiguratorRequestTest() throws JsonProcessingException {
        when(featureFlagHelper.isNgdTradeInBulkUpdateEnabled()).thenReturn(Boolean.FALSE);
        String requestFile = "data/addAllToCartConfigurator/request/successRequestFormatted.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        AddAllConfiguratorUIRequest uiRequest = mapper.readValue(requestString, AddAllConfiguratorUIRequest.class);
        AddAllConfiguratorPEGARequest pegaRequest = new AddAllConfiguratorPEGARequest();

        AddAllConfiguratorPEGARequest response = CartConfiguratorPegaRequestUtil.formatAddConfiguratorRequest(pegaRequest, uiRequest, featureFlagHelper.isNgdTradeInBulkUpdateEnabled());
        Assertions.assertNotNull(response.getServiceBody().getServiceRequest().getContext());
        Assertions.assertNotNull(response.getServiceHeader());
        Assertions.assertNotNull(response.getServiceBody().getServiceRequest().getContext().getCartInfo());
        Assert.assertEquals(ConfiguratorConstants.CONFIGURATOR_ITEM_TYPE, response.getServiceBody().getServiceRequest().getContext().getCartInfo().getItemType());

        uiRequest.getData().getLines().get(0).setIspuFlow(true);
        response = CartConfiguratorPegaRequestUtil.formatAddConfiguratorRequest(pegaRequest, uiRequest, featureFlagHelper.isNgdTradeInBulkUpdateEnabled());
        Assertions.assertNotNull(response.getServiceBody().getServiceRequest().getContext());
        Assertions.assertNotNull(response.getServiceHeader());
        Assertions.assertNotNull(response.getServiceBody().getServiceRequest().getContext().getCartInfo());
        Assert.assertEquals(ConfiguratorConstants.CONFIGURATOR_ITEM_TYPE, response.getServiceBody().getServiceRequest().getContext().getCartInfo().getItemType());

        uiRequest.getData().setLines(new ArrayList<>());
        response = CartConfiguratorPegaRequestUtil.formatAddConfiguratorRequest(pegaRequest, uiRequest, featureFlagHelper.isNgdTradeInBulkUpdateEnabled());
        Assertions.assertNotNull(response.getServiceBody().getServiceRequest().getContext());
        Assertions.assertNotNull(response.getServiceHeader());
        Assertions.assertNotNull(response.getServiceBody().getServiceRequest().getContext().getCartInfo());
        Assert.assertEquals(ConfiguratorConstants.CONFIGURATOR_ITEM_TYPE, response.getServiceBody().getServiceRequest().getContext().getCartInfo().getItemType());

    }

    @Test
    public void formatAddConfiguratorRequestTestForTradeIn() throws JsonProcessingException {
        when(featureFlagHelper.isNgdTradeInBulkUpdateEnabled()).thenReturn(Boolean.TRUE);
        String requestFile = "data/addAllToCartConfigurator/request/successRequestForTradeIn.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        AddAllConfiguratorUIRequest uiRequest = mapper.readValue(requestString, AddAllConfiguratorUIRequest.class);
        AddAllConfiguratorPEGARequest pegaRequest = new AddAllConfiguratorPEGARequest();

        AddAllConfiguratorPEGARequest response = CartConfiguratorPegaRequestUtil.formatAddConfiguratorRequest(pegaRequest, uiRequest, featureFlagHelper.isNgdTradeInBulkUpdateEnabled());
        Assertions.assertNotNull(response.getServiceBody().getServiceRequest().getContext());
        Assertions.assertNotNull(response.getServiceHeader());
        Assertions.assertNotNull(response.getServiceBody().getServiceRequest().getContext().getCartInfo());
        Assertions.assertNotNull(Arrays.stream(response.getServiceBody().getServiceRequest().getContext().getCartInfo().getLines()).findAny().get().getTradeInItems());
        Assert.assertEquals(ConfiguratorConstants.CONFIGURATOR_ITEM_TYPE, response.getServiceBody().getServiceRequest().getContext().getCartInfo().getItemType());

        uiRequest.getData().getLines().get(0).setIsBatteryDamaged(false);
        response = CartConfiguratorPegaRequestUtil.formatAddConfiguratorRequest(pegaRequest, uiRequest, featureFlagHelper.isNgdTradeInBulkUpdateEnabled());
        Assertions.assertNotNull(response.getServiceBody().getServiceRequest().getContext());

        uiRequest.getData().getLines().get(0).setIsBatteryDamaged(null);
        response = CartConfiguratorPegaRequestUtil.formatAddConfiguratorRequest(pegaRequest, uiRequest, featureFlagHelper.isNgdTradeInBulkUpdateEnabled());
        Assertions.assertNotNull(response.getServiceBody().getServiceRequest().getContext());

        uiRequest.getData().getLines().get(0).setIsRemoveTradeIn(Boolean.TRUE);
        uiRequest.getData().getLines().get(0).setIsTradeInIntentSelected(Boolean.FALSE);
        response = CartConfiguratorPegaRequestUtil.formatAddConfiguratorRequest(pegaRequest, uiRequest, featureFlagHelper.isNgdTradeInBulkUpdateEnabled());
        Assertions.assertNotNull(response.getServiceBody().getServiceRequest().getContext());

        uiRequest.getData().getLines().get(0).setIsRemoveTradeIn(null);
        uiRequest.getData().getLines().get(0).setIsTradeInIntentSelected(null);
        response = CartConfiguratorPegaRequestUtil.formatAddConfiguratorRequest(pegaRequest, uiRequest, featureFlagHelper.isNgdTradeInBulkUpdateEnabled());
        Assertions.assertNotNull(response.getServiceBody().getServiceRequest().getContext());

        uiRequest.getData().getLines().get(0).setIsRemoveTradeIn(false);
        uiRequest.getData().getLines().get(0).setIsTradeInIntentSelected(false);
        response = CartConfiguratorPegaRequestUtil.formatAddConfiguratorRequest(pegaRequest, uiRequest, featureFlagHelper.isNgdTradeInBulkUpdateEnabled());
        Assertions.assertNotNull(response.getServiceBody().getServiceRequest().getContext());
    }

}
