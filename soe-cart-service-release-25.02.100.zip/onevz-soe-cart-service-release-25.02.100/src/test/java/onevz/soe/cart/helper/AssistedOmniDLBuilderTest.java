package onevz.soe.cart.helper;

import onevz.soe.cart.model.common.*;
import onevz.soe.cart.omnidl.AssistedOmniDLBuilder;
import onevz.soe.omnidl.data.OmniDLData;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class AssistedOmniDLBuilderTest {

    private AssistedOmniDLBuilder builder;


    private Vzdl vzdl;
    private OmniDLData omniDLData;
    private Map<String,String> txn;
    private Product product;
    private Page page;

    @BeforeEach
   public  void setUp() {
        builder = new AssistedOmniDLBuilder();
        vzdl = mock(Vzdl.class);
        txn= new HashMap<>();
        product=new Product();
        page= new Page();
        omniDLData = new OmniDLData();
        Map<String, Object> customData = new HashMap<>();
        customData.put("txn", "txn123");
        customData.put("txn.product", "product123");
        customData.put("page", "page123");
        customData.put("user", "user123");
        customData.put("env", "env123");
        customData.put("event", "event123");
        customData.put("utils", "utils123");
        omniDLData.setCustomData(customData);
    }

    @Test
    public void testBuildData_whenVzdlIsNull() {
        Vzdl nullVzdl = null;
        builder.buildData(nullVzdl);
        assertNull(builder.getOmniDLData());
    }

    @Test
   public  void testBuildData_whenVzdlIsNotNull_andCustomDataIsEmpty() {
        when(vzdl.getTxn()).thenReturn(null);
        when(vzdl.getProduct()).thenReturn(null);
        when(vzdl.getPage()).thenReturn(null);
        when(vzdl.getUser()).thenReturn(null);
        when(vzdl.getEnv()).thenReturn(null);
        when(vzdl.getEvent()).thenReturn(null);
        when(vzdl.getUtils()).thenReturn(null);
        builder.buildData(vzdl);
        assertNotNull(builder.getOmniDLData());
    }

    @Test
   public  void testBuildData_whenVzdlIsNotNull_andCustomDataIsNotEmpty() {
        when(vzdl.getTxn()).thenReturn(txn);
        when(vzdl.getProduct()).thenReturn(product);
        when(vzdl.getPage()).thenReturn(page);
        when(vzdl.getUser()).thenReturn(new User());
        when(vzdl.getEnv()).thenReturn(new Env());
        when(vzdl.getEvent()).thenReturn(new Event());
        when(vzdl.getUtils()).thenReturn(new Utils());
        builder.buildData(vzdl);
        assertNotNull(builder.getOmniDLData());
        Map<String, Object> expectedCustomData = new HashMap<>();
        expectedCustomData.put("txn", "txn123");
        expectedCustomData.put("txn.product", "product123");
        expectedCustomData.put("page", "page123");
        expectedCustomData.put("user", "user123");
        expectedCustomData.put("env", "env123");
        expectedCustomData.put("event", "event123");
        expectedCustomData.put("utils", "utils123");
        assertEquals(expectedCustomData, omniDLData.getCustomData());
    }

    @Test
    public  void testPopulateTxnVzDLData_whenVzdlFieldsAreNotNull() {
        when(vzdl.getTxn()).thenReturn(txn);
        when(vzdl.getProduct()).thenReturn(product);
        when(vzdl.getPage()).thenReturn(page);
        when(vzdl.getUser()).thenReturn(new User());
        when(vzdl.getEnv()).thenReturn(new Env());
        when(vzdl.getEvent()).thenReturn(new Event());
        when(vzdl.getUtils()).thenReturn(new Utils());
        Map<String, Object> customData = new HashMap<>();
        builder.populateTxnVzDLData(vzdl, customData);
        assertEquals(new Product(), customData.get("txn.product"));
        assertEquals(new Page(), customData.get("page"));
        assertEquals(new User(), customData.get("user"));
        assertEquals(new Env(), customData.get("env"));
        assertEquals(new Event(), customData.get("event"));
        assertEquals(new Utils(),customData.get("utils"));
    }

    @Test
    public  void testPopulateTxnVzDLData_whenVzdlFieldsAreNull() {
        when(vzdl.getTxn()).thenReturn(null);
        when(vzdl.getProduct()).thenReturn(null);
        when(vzdl.getPage()).thenReturn(null);
        when(vzdl.getUser()).thenReturn(null);
        when(vzdl.getEnv()).thenReturn(null);
        when(vzdl.getEvent()).thenReturn(null);
        when(vzdl.getUtils()).thenReturn(null);
        Map<String, Object> customData = new HashMap<>();
        builder.populateTxnVzDLData(vzdl, customData);
        assertTrue(customData.isEmpty());
    }

    @Test
   public void testFromOrderReviewPage() {
        OmniDLData result = AssistedOmniDLBuilder.AssistedOmniBuilderService.fromOrderConfirmationPage(new Vzdl()).getOmniDLData();
        assertNotNull(result);
    }
}
