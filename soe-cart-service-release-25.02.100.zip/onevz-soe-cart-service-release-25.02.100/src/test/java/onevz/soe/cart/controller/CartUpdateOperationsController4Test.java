package onevz.soe.cart.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.cxp.feature.ConfigurationProfile;
import onevz.cxp.feature.Flag;
import onevz.cxp.feature.util.FeatureFlag;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper4;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.exceptions.JsonValidator;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.model.addDevice.ShowAALPromoIntercept;
import onevz.soe.cart.model.addPromoIntent.*;
import onevz.soe.cart.model.calculateTaxData.CalculateTaxData;
import onevz.soe.cart.model.calculateTaxData.TaxItemsCXPData;
import onevz.soe.cart.model.calculateTaxData.TaxLinesCXPData;
import onevz.soe.cart.model.calculateTaxData.TaxLinesResponses;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.common.TaxPerItem;
import onevz.soe.cart.model.fipscode.RetrieveFipsCode;
import onevz.soe.cart.model.mylink.MyLinkUIRequestData;
import onevz.soe.cart.model.mylink.MylinkData;
import onevz.soe.cart.model.mylink.MylinkReferralInfoResponse;
import onevz.soe.cart.model.mylink.MylinkReferralInfoUIRequest;
import onevz.soe.cart.model.taxengine.request.NGDCalculateTaxDetailsRequest;
import onevz.soe.cart.model.taxengine.request.NGDTaxEngineRequest;
import onevz.soe.cart.model.taxengine.response.NGDTaxEngineBaseResponse;
import onevz.soe.cart.model.taxengine.response.NGDTaxEngineResponseData;
import onevz.soe.cart.model.updateUserInfo.UpdateUserInfoLine;
import onevz.soe.cart.requests.UpdateAccountOwnerPEGAResponse;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.ui.common.DeviceCartInfo;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.omnidl.util.DLUtilityService;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.utilities.serialization.JacksonMapperFactory;
import org.assertj.core.api.Assertions;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.*;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpResponse;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.WebDataBinder;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.net.URI;
import java.util.*;
import java.util.concurrent.ExecutionException;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(CartUpdateOperationsController4.class)
public class CartUpdateOperationsController4Test extends BaseTest{

    @Autowired
    private ObjectMapper mapper;

    @MockBean
    private ReadCartHelper readCartHelper;

    @Autowired
    private CartUpdateOperationsController cartController;

    @Autowired
    private CartUpdateOperationsController2 cartController2;

    @Autowired
    private CartUpdateOperationsController3 cartController3;

    @Autowired
	private CartUpdateOperationsController4 cartController4;

    @MockBean
    private RedisHelper redisHelper;

    @MockBean
    private RedisHelper2 redisHelper2;

    @MockBean
    private RedisHelper3 redisHelper3;

    @MockBean
    private UpdateCartHelper helper;

    @MockBean
    private CradleHelper cradleHelper;

    @MockBean
    private ResumeCartHelper resumeCartHelper;

    @MockBean
    private CartServiceCxpHelper cxpHelper;
	@MockBean
	private CartServiceBpmHelper4 cartServiceBpmHelper4;

    @MockBean
    private UpdateCartHelper1 helper1;

    @MockBean
    private FeatureFlagHelper featureFlagHelper;

    @Value("${enableClearAndAddItem:false}")
    private boolean enableClearAndAddItem;

    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;

    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;

    @MockBean
    private JsonValidator validator;

    @MockBean
    private CartAddDeviceHelper devHelper;

    @MockBean
    private CartAddDeviceHelper1 deviceHelper;
    @MockBean
    private DLUtilityService dlUtilityService;

    @Mock
    CartServiceCXPServices cxpService;

    @Mock
    FeatureFlag featureFlag;

    @Test
    public void clearAndContinue() throws IOException {

        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();

        String requestFile = "data/CartUpdateOperationsControllerTestJson/clearAndContinueGRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/clearAndContinueGResponse.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        ClearAndContinueUIRequest request = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
        ClearAndContinueUIResponse response = mapper.readValue(responseString, ClearAndContinueUIResponse.class);
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("device"));
        CartRedisData cartRedisData = new CartRedisData();
        DeviceCartInfo deviceCartInfo = new DeviceCartInfo();
        deviceCartInfo.setIntendType("ACC");
        cartRedisData.setDeviceCartInfo(deviceCartInfo);
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(resumeCartHelper.clearAndResume(Mockito.any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController,"domains",List.of(".verizon.com",".verizonwireless.com"));

        URI url = URI.create("http://localhost/clearAndContinue");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();

        if(!enableClearAndAddItem)
            cartController.setEnableClearAndAddItem(true);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.clearAndContinue(httpRequest,httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {
            Assert.assertNotNull(resp);}).expectComplete().verify();

        request.getCartInfo().setProcessStep(CartConstants.SECOND_NUMBER_PAGE);
        controllerResponse = cartController.clearAndContinue(httpRequest,httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(Assert::assertNotNull).expectComplete().verify();

    }

    @Test
    public void clearAndContinueTest() throws IOException{
        String requestFile = "ClearAndContinueRequestTest.json";
        String responseFile = "ClearAndContinueResponseTest.json";
        String redisFile = "data/CartUpdateOperationsControllerTestJson/ClearAndContinueRedisACC.json";
        String getDataFromRedisAsString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        ClearAndContinueUIRequest request = mapper.readValue(sampleRequestString, ClearAndContinueUIRequest.class);
        ClearAndContinueUIResponse response = mapper.readValue(sampleResponseString, ClearAndContinueUIResponse.class);
        CartRedisData sampleRedisData = mapper.readValue(getDataFromRedisAsString, CartRedisData.class);
        when(helper.clearAndContinue(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("device"));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        ReflectionTestUtils.setField(cartController,"domains",List.of(".verizon.com",".verizonwireless.com"));

        URI url = URI.create("http://localhost/clearAndContinue");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        HttpCookie cookie = new HttpCookie(CartConstants.FROM_FREE_PHONES_QV, "false");
        bodyMap.add(CartConstants.FROM_FREE_PHONES_QV, cookie);
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.clearAndContinue(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void clearAndContinueTest1() throws IOException{

        String requestFile = "data/CartUpdateOperationsControllerTestJson/clearAndContinueMRequest.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/clearAndContinueMResponse.json";
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        String redisDataFile = "data/CartUpdateOperationsControllerTestJson/clearAndContinueMRedisData.json";
        String getDataFromRedisAsString = sourceFileReaderUtil.readFile(redisDataFile, testFileLocation);
        ClearAndContinueUIRequest request = mapper.readValue(sampleRequestString, ClearAndContinueUIRequest.class);
        ClearAndContinueUIResponse response = mapper.readValue(sampleResponseString, ClearAndContinueUIResponse.class);
        CartRedisData sampleRedisData = mapper.readValue(getDataFromRedisAsString, CartRedisData.class);
        when(helper.clearAndContinue(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("device"));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        ReflectionTestUtils.setField(cartController,"domains",List.of(".verizon.com",".verizonwireless.com"));

        URI url = URI.create("http://localhost/clearAndContinue");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        cartController.setEnableClearAndAddItem(false);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.clearAndContinue(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void clearAndContinueTest2() throws IOException{
        String requestFile = "data/CartUpdateOperationsControllerTestJson/clearAndContinueGTestRequest.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/clearAndContinueGTestResponse.json";
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        String redisDataFile = "data/CartUpdateOperationsControllerTestJson/clearAndContinueGTestRedisData.json";
        String getDataFromRedisAsString = sourceFileReaderUtil.readFile(redisDataFile, testFileLocation);
        ClearAndContinueUIRequest request = mapper.readValue(sampleRequestString, ClearAndContinueUIRequest.class);
        ClearAndContinueUIResponse response = mapper.readValue(sampleResponseString, ClearAndContinueUIResponse.class);
        CartRedisData sampleRedisData = mapper.readValue(getDataFromRedisAsString, CartRedisData.class);
        when(helper.clearAndContinue(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("device"));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        ReflectionTestUtils.setField(cartController,"domains",List.of(".verizon.com",".verizonwireless.com"));

        URI url = URI.create("http://localhost/clearAndContinue");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        cartController.setEnableClearAndAddItem(false);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.clearAndContinue(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void clearAndContinueTest3() throws IOException{
        String requestFile = "data/CartUpdateOperationsControllerTestJson/clearAndContinueGTestRequest.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/clearAndContinueGTestResponse.json";
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        String redisDataFile = "data/CartUpdateOperationsControllerTestJson/clearAndContinueGTestRedisData.json";
        String getDataFromRedisAsString = sourceFileReaderUtil.readFile(redisDataFile, testFileLocation);
        ClearAndContinueUIRequest request = mapper.readValue(sampleRequestString, ClearAndContinueUIRequest.class);
        ClearAndContinueUIResponse response = mapper.readValue(sampleResponseString, ClearAndContinueUIResponse.class);
        CartRedisData sampleRedisData = mapper.readValue(getDataFromRedisAsString, CartRedisData.class);
        when(helper.clearAndContinue(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("devi"));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        ReflectionTestUtils.setField(cartController,"domains",List.of(".verizon.com",".verizonwireless.com"));

        URI url = URI.create("http://localhost/clearAndContinue");
        HttpCookie cookie = new HttpCookie(CartConstants.FROM_FREE_PHONES_QV, "");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add(CartConstants.FROM_FREE_PHONES_QV, cookie);
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        cartController.setEnableClearAndAddItem(false);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.clearAndContinue(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void clearAndContinueTest4() throws IOException{
        String requestFile = "data/CartUpdateOperationsControllerTestJson/clearAndContinueGTestRequest.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/clearAndContinueGTestNetaceResponse.json";
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        String redisDataFile = "data/CartUpdateOperationsControllerTestJson/clearAndContinueGTestRedisData.json";
        String getDataFromRedisAsString = sourceFileReaderUtil.readFile(redisDataFile, testFileLocation);
        ClearAndContinueUIRequest request = mapper.readValue(sampleRequestString, ClearAndContinueUIRequest.class);
        ClearAndContinueUIResponse response = mapper.readValue(sampleResponseString, ClearAndContinueUIResponse.class);
        CartRedisData sampleRedisData = mapper.readValue(getDataFromRedisAsString, CartRedisData.class);
        when(helper.clearAndContinue(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just(""));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        ReflectionTestUtils.setField(cartController,"domains",List.of(".verizon.com",".verizonwireless.com"));

        URI url = URI.create("http://localhost/clearAndContinue");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        cartController.setEnableClearAndAddItem(false);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.clearAndContinue(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void clearAndContinueTest5() throws IOException{
        String requestFile = "data/CartUpdateOperationsControllerTestJson/clearAndContinueGTestRequest.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/clearAndContinueGTest1Response.json";
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        String redisDataFile = "data/CartUpdateOperationsControllerTestJson/clearAndContinueGTestRedisData.json";
        String getDataFromRedisAsString = sourceFileReaderUtil.readFile(redisDataFile, testFileLocation);
        ClearAndContinueUIRequest request = mapper.readValue(sampleRequestString, ClearAndContinueUIRequest.class);
        ClearAndContinueUIResponse response = mapper.readValue(sampleResponseString, ClearAndContinueUIResponse.class);
        CartRedisData sampleRedisData = mapper.readValue(getDataFromRedisAsString, CartRedisData.class);
        when(helper.clearAndContinue(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just(""));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        ReflectionTestUtils.setField(cartController,"domains",List.of(".verizon.com",".verizonwireless.com"));

        URI url = URI.create("http://localhost/clearAndContinue");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        cartController.setEnableClearAndAddItem(false);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.clearAndContinue(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(Assert::assertNotNull).expectComplete().verify();
    }


    @Test
    public void clearAndContinueTest6() throws IOException{
        String requestFile = "data/CartUpdateOperationsControllerTestJson/clearAndContinueGTestRequest.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/clearAndContinueGTest2Response.json";
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        String redisDataFile = "data/CartUpdateOperationsControllerTestJson/clearAndContinueGTestRedisData.json";
        String getDataFromRedisAsString = sourceFileReaderUtil.readFile(redisDataFile, testFileLocation);
        ClearAndContinueUIRequest request = mapper.readValue(sampleRequestString, ClearAndContinueUIRequest.class);
        ClearAndContinueUIResponse response = mapper.readValue(sampleResponseString, ClearAndContinueUIResponse.class);
        CartRedisData sampleRedisData = mapper.readValue(getDataFromRedisAsString, CartRedisData.class);
        when(helper.clearAndContinue(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just(""));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        ReflectionTestUtils.setField(cartController,"domains",List.of(".verizon.com",".verizonwireless.com"));

        URI url = URI.create("http://localhost/clearAndContinue");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        cartController.setEnableClearAndAddItem(false);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.clearAndContinue(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void clearAndContinueErrorsTest() throws IOException{
        String requestFile = "data/CartUpdateOperationsControllerTestJson/clearAndContinueGTestRequest.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = "{\"errors\":[{\"id\":\"001\",\"namespace\":\"CartService\"}]}";
        String redisDataFile = "data/CartUpdateOperationsControllerTestJson/clearAndContinueGTestRedisData.json";
        String getDataFromRedisAsString = sourceFileReaderUtil.readFile(redisDataFile, testFileLocation);
        ClearAndContinueUIRequest request = mapper.readValue(sampleRequestString, ClearAndContinueUIRequest.class);
        ClearAndContinueUIResponse response = mapper.readValue(sampleResponseString, ClearAndContinueUIResponse.class);
        CartRedisData sampleRedisData = mapper.readValue(getDataFromRedisAsString, CartRedisData.class);
        when(helper.clearAndContinue(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just(""));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        ReflectionTestUtils.setField(cartController,"domains",List.of(".verizon.com",".verizonwireless.com"));

        URI url = URI.create("http://localhost/clearAndContinue");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        cartController.setEnableClearAndAddItem(false);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.clearAndContinue(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }


    @Test
    public void clearAndContinueTest7() throws IOException{
        String requestFile = "data/CartUpdateOperationsControllerTestJson/clearAndContinueGTestRequest.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/clearAndContinueGTest2Response.json";
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        String redisDataFile = "data/CartUpdateOperationsControllerTestJson/clearAndContinueGTest2RedisData.json";
        String getDataFromRedisAsString = sourceFileReaderUtil.readFile(redisDataFile, testFileLocation);
        ClearAndContinueUIRequest request = mapper.readValue(sampleRequestString, ClearAndContinueUIRequest.class);
        ClearAndContinueUIResponse response = mapper.readValue(sampleResponseString, ClearAndContinueUIResponse.class);
        CartRedisData sampleRedisData = mapper.readValue(getDataFromRedisAsString, CartRedisData.class);
        when(helper.clearAndContinue(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just(""));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        ReflectionTestUtils.setField(cartController,"domains",List.of(".verizon.com",".verizonwireless.com"));

        URI url = URI.create("http://localhost/clearAndContinue");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        cartController.setEnableClearAndAddItem(false);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.clearAndContinue(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void updateDeviceSIMIdTest() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"data\": {}}";
        UpdateDeviceSIMIdUIRequest request = mapper.readValue(requestString, UpdateDeviceSIMIdUIRequest.class);
        URI url = URI.create("http://localhost/deviceSimId");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        Mono<ResponseEntity<GenericResponse>> response = cartController3.updateDeviceSIMId(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateDeviceSIMIdTest2() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/updateDeviceSIMIdRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"errors\": [{}]}";
        UpdateDeviceSIMIdUIRequest request = mapper.readValue(requestString, UpdateDeviceSIMIdUIRequest.class);
        UpdateDeviceSIMIdUIResponse uiResponse = mapper.readValue(responseString, UpdateDeviceSIMIdUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimId");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-CARE").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.updateDeviceSIMId(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController3.updateDeviceSIMId(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateDeviceSIMIdTest3() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/updateDeviceSIMIdRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{}";
        UpdateDeviceSIMIdUIRequest request = mapper.readValue(requestString, UpdateDeviceSIMIdUIRequest.class);
        UpdateDeviceSIMIdUIResponse uiResponse = mapper.readValue(responseString, UpdateDeviceSIMIdUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimId");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-CARE").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.updateDeviceSIMId(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController3.updateDeviceSIMId(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void numberShareTest() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/AALrequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{}";
        NumberShareUIRequest request = mapper.readValue(requestString, NumberShareUIRequest.class);
        NumberShareUIResponse uiResponse = mapper.readValue(responseString, NumberShareUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimId");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.numberShare(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController3.numberShare(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void numberShareTest2() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/numberShareRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{}";
        NumberShareUIRequest request = mapper.readValue(requestString, NumberShareUIRequest.class);
        NumberShareUIResponse uiResponse = mapper.readValue(responseString, NumberShareUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimId");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.numberShare(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController3.numberShare(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void numberShareTest3() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/numberShareRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"errors\": [{}]}";
        NumberShareUIRequest request = mapper.readValue(requestString, NumberShareUIRequest.class);
        NumberShareUIResponse uiResponse = mapper.readValue(responseString, NumberShareUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimId");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM-MOB").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.numberShare(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController3.numberShare(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addBillingAddressTest() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/AALrequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{}";
        BillingAddressUIRequest request = mapper.readValue(requestString, BillingAddressUIRequest.class);
        BillingAddressUIResponse uiResponse = mapper.readValue(responseString, BillingAddressUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimId");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.addBillingAddress(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController3.addBillingAddress(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addBillingAddressTest2() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addBillingAddressRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{}";
        BillingAddressUIRequest request = mapper.readValue(requestString, BillingAddressUIRequest.class);
        BillingAddressUIResponse uiResponse = mapper.readValue(responseString, BillingAddressUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimId");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.addBillingAddress(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController3.addBillingAddress(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addBillingAddressTest3() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addBillingAddressRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"errors\": [{}]}";
        BillingAddressUIRequest request = mapper.readValue(requestString, BillingAddressUIRequest.class);
        BillingAddressUIResponse uiResponse = mapper.readValue(responseString, BillingAddressUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimId");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM-MOB").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.addBillingAddress(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController3.addBillingAddress(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addServiceAddressTest() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/AALrequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{}";
        ServiceAddressUIRequest request = mapper.readValue(requestString, ServiceAddressUIRequest.class);
        ServiceAddressUIResponse uiResponse = mapper.readValue(responseString, ServiceAddressUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimId");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.addServiceAddress(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController.addServiceAddress(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addServiceAddressTest2() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addServiceAddressRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{}";
        ServiceAddressUIRequest request = mapper.readValue(requestString, ServiceAddressUIRequest.class);
        ServiceAddressUIResponse uiResponse = mapper.readValue(responseString, ServiceAddressUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimId");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.addServiceAddress(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController.addServiceAddress(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addServiceAddressTest3() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addServiceAddressRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"errors\": [{}]}";
        ServiceAddressUIRequest request = mapper.readValue(requestString, ServiceAddressUIRequest.class);
        ServiceAddressUIResponse uiResponse = mapper.readValue(responseString, ServiceAddressUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimId");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM-MOB").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.addServiceAddress(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController.addServiceAddress(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addE911AddressTest() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/AALrequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{}";
        E911AddressUIRequest request = mapper.readValue(requestString, E911AddressUIRequest.class);
        E911AddressUIResponse uiResponse = mapper.readValue(responseString, E911AddressUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimId");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.addE911Address(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController.addE911Address(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addE911AddressPartialSucessTest() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addE911AddressPartialSucessRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        E911AddressUIRequest request = mapper.readValue(requestString, E911AddressUIRequest.class);
        E911AddressUIResponse uiResponse = mapper.readValue(sourceFileReaderUtil.readFile("addE911AddressPartialTest.json", testFileLocation), E911AddressUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimId");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(helper.addE911Address(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController.addE911Address(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addE911AddressTest2() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/effectiveDateOverrideRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{}";
        E911AddressUIRequest request = mapper.readValue(requestString, E911AddressUIRequest.class);
        E911AddressUIResponse uiResponse = mapper.readValue(responseString, E911AddressUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimId");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.addE911Address(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController.addE911Address(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addE911AddressTest3() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/effectiveDateOverrideRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"errors\": [{}]}";
        E911AddressUIRequest request = mapper.readValue(requestString, E911AddressUIRequest.class);
        E911AddressUIResponse uiResponse = mapper.readValue(responseString, E911AddressUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimId");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM-MOB").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.addE911Address(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController.addE911Address(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addE911AddressTest4() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/effectiveDateOverrideRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"errors\": [{}]}";
        E911AddressUIRequest request = mapper.readValue(requestString, E911AddressUIRequest.class);
        E911AddressUIResponse uiResponse = mapper.readValue(responseString, E911AddressUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimId");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM-MOB").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(helper.addE911Address(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController.addE911Address(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addInstantCreditDownPaymentTest() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/AALrequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{}";
        InstantCreditDownPaymentUIRequest request = mapper.readValue(requestString, InstantCreditDownPaymentUIRequest.class);
        InstantCreditDownPaymentUIResponse uiResponse = mapper.readValue(responseString, InstantCreditDownPaymentUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimId");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.addInstantCreditDownPayment(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController.addInstantCreditDownPayment(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addInstantCreditDownPaymentTest2() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/effectiveDateOverrideRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{}";
        InstantCreditDownPaymentUIRequest request = mapper.readValue(requestString, InstantCreditDownPaymentUIRequest.class);
        InstantCreditDownPaymentUIResponse uiResponse = mapper.readValue(responseString, InstantCreditDownPaymentUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimId");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.addInstantCreditDownPayment(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController.addInstantCreditDownPayment(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addInstantCreditDownPaymentTest3() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/effectiveDateOverrideRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"errors\": [{}]}";
        InstantCreditDownPaymentUIRequest request = mapper.readValue(requestString, InstantCreditDownPaymentUIRequest.class);
        InstantCreditDownPaymentUIResponse uiResponse = mapper.readValue(responseString, InstantCreditDownPaymentUIResponse.class);
        URI url = URI.create("http://localhost/deviceSimId");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM-MOB").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.addInstantCreditDownPayment(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController.addInstantCreditDownPayment(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateBarcodeTest() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/AALrequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{}";
        UpdateBarcodeUIRequest request = mapper.readValue(requestString, UpdateBarcodeUIRequest.class);
        UpdateBarcodeUIResponse uiResponse = mapper.readValue(responseString, UpdateBarcodeUIResponse.class);
        URI url = URI.create("http://localhost/updateBarcode");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.updateBarcode(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController.updateBarcode(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateBarcodeTest12() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/NSELTERequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{}";
        UpdateBarcodeUIRequest request = mapper.readValue(requestString, UpdateBarcodeUIRequest.class);
        UpdateBarcodeUIResponse uiResponse = mapper.readValue(responseString, UpdateBarcodeUIResponse.class);
        URI url = URI.create("http://localhost/nse/5g/updateBarcode");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.updateBarcode(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController.updateBarcode(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateBarcodeTest2() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/effectiveDateOverrideRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{}";
        UpdateBarcodeUIRequest request = mapper.readValue(requestString, UpdateBarcodeUIRequest.class);
        UpdateBarcodeUIResponse uiResponse = mapper.readValue(responseString, UpdateBarcodeUIResponse.class);
        URI url = URI.create("http://localhost/updateBarcode");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.updateBarcode(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController.updateBarcode(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateBarcodeTest3() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/updateBarcodeNSEACCRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"errors\": [{}]}";
        UpdateBarcodeUIRequest request = mapper.readValue(requestString, UpdateBarcodeUIRequest.class);
        UpdateBarcodeUIResponse uiResponse = mapper.readValue(responseString, UpdateBarcodeUIResponse.class);
        URI url = URI.create("http://localhost/updateBarcode");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM-MOB").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.updateBarcode(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController.updateBarcode(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateBarcodeTest4() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/updateBarcodeACCRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"errors\": [{}]}";
        UpdateBarcodeUIRequest request = mapper.readValue(requestString, UpdateBarcodeUIRequest.class);
        UpdateBarcodeUIResponse uiResponse = mapper.readValue(responseString, UpdateBarcodeUIResponse.class);
        URI url = URI.create("http://localhost/updateBarcode");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM-MOB").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.updateBarcode(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController.updateBarcode(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateChatIdTest() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"chatId\": \"\"}";
        String responseString = "{}";
        UpdateChatIdUIRequest request = mapper.readValue(requestString, UpdateChatIdUIRequest.class);
        UpdateChatIdUIResponse uiResponse = mapper.readValue(responseString, UpdateChatIdUIResponse.class);
        URI url = URI.create("http://localhost/updateChatId");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.updateChatId(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController2.updateChatId(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateChatIdTest2() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"chatId\": \"AAL\"}";
        String responseString = "{}";
        UpdateChatIdUIRequest request = mapper.readValue(requestString, UpdateChatIdUIRequest.class);
        UpdateChatIdUIResponse uiResponse = mapper.readValue(responseString, UpdateChatIdUIResponse.class);
        URI url = URI.create("http://localhost/updateChatId");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.updateChatId(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(redisHelper2.updateChatId(Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> response = cartController2.updateChatId(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateChatIdTest3() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"chatId\": \"AAL\"}";
        String responseString = "{\"errors\": [{}]}";
        UpdateChatIdUIRequest request = mapper.readValue(requestString, UpdateChatIdUIRequest.class);
        UpdateChatIdUIResponse uiResponse = mapper.readValue(responseString, UpdateChatIdUIResponse.class);
        URI url = URI.create("http://localhost/nse/updateChatId");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.updateChatId(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController2.updateChatId(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateChatIdTest4() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"channelId\": \"VZW-DOTCOM\"}";
        String responseFile = "data/CartUpdateOperationsControllerTestJson/updateChatIdResponse.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        UpdateChatIdUIRequest request = mapper.readValue(requestString, UpdateChatIdUIRequest.class);
        UpdateChatIdUIResponse uiResponse = mapper.readValue(responseString, UpdateChatIdUIResponse.class);
        URI url = URI.create("http://localhost/updateChatId");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(helper.updateChatId(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController2.updateChatId(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }


    @Test
    public void updateSellerPriceNewTest() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"data\": {}}";
        String responseString = "{}";
        UpdateSellerPriceUIRequestNew request = mapper.readValue(requestString, UpdateSellerPriceUIRequestNew.class);
        UpdateSellerPriceUIResponseNew uiResponse = mapper.readValue(responseString, UpdateSellerPriceUIResponseNew.class);
        URI url = URI.create("http://localhost/updateSellerPrice");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.updateSellerPriceNew(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        Mono<ResponseEntity<GenericResponse>> response = cartController.updateSellerPriceNew(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateSellerPriceNewTest2() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/updateSellerPriceNewRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"errors\": [{}]}";
        UpdateSellerPriceUIRequestNew request = mapper.readValue(requestString, UpdateSellerPriceUIRequestNew.class);
        UpdateSellerPriceUIResponseNew uiResponse = mapper.readValue(responseString, UpdateSellerPriceUIResponseNew.class);
        URI url = URI.create("http://localhost/updateSellerPrice");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "id")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.updateSellerPriceNew(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController.updateSellerPriceNew(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateSellerPriceNewTest3() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"data\": {}}";
        String responseString = "{}";
        UpdateSellerPriceUIRequestNew request = mapper.readValue(requestString, UpdateSellerPriceUIRequestNew.class);
        UpdateSellerPriceUIResponseNew uiResponse = mapper.readValue(responseString, UpdateSellerPriceUIResponseNew.class);
        URI url = URI.create("http://localhost/updateSellerPrice");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.updateSellerPriceNew(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(new ErrorResponse());
        Mono<ResponseEntity<GenericResponse>> response = cartController.updateSellerPriceNew(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateSellerPriceNewTest4() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/updateSellerPriceNewRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"errors\": [{}]}";
        UpdateSellerPriceUIRequestNew request = mapper.readValue(requestString, UpdateSellerPriceUIRequestNew.class);
        UpdateSellerPriceUIResponseNew uiResponse = mapper.readValue(responseString, UpdateSellerPriceUIResponseNew.class);
        URI url = URI.create("http://localhost/updateSellerPrice");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "id")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.updateSellerPriceNew(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController.updateSellerPriceNew(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }


    @Test
    public void updateGiftItemTest() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/updateGiftItemRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/updateGiftItemResponse.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        UpdateGiftItemUIRequest request = mapper.readValue(requestString, UpdateGiftItemUIRequest.class);
        UpdateGiftItemUIResponse response = mapper.readValue(responseString, UpdateGiftItemUIResponse.class);
        URI url = URI.create("http://localhost/update-giftItem");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-MFA-ANDROID").build();
        ServerHttpResponse httpResponse = null;
        when(helper.updateGiftItem(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.updateGiftItem(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateGiftItemTest1() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/updateGiftItemTest1Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/updateGiftItemTest3998Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        UpdateGiftItemUIRequest request = mapper.readValue(requestString, UpdateGiftItemUIRequest.class);
        UpdateGiftItemUIResponse response = mapper.readValue(responseString, UpdateGiftItemUIResponse.class);
        URI url = URI.create("http://localhost/update-giftItem");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-MFA-ANDROID").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.NOT_FOUND);
        when(helper.updateGiftItem(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.updateGiftItem(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateVzccNBXInfoTest1() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/updateVzccNBXInfoRequest.json";
        String sampleRequest = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/updateVzccNBXInfoResponse.json";
        String sampleResponse = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        UpdateVzccNBXInfoUIRequest request = mapper.readValue(sampleRequest, UpdateVzccNBXInfoUIRequest.class);
        UpdateVzccNBXInfoUIResponse response = mapper.readValue(sampleResponse, UpdateVzccNBXInfoUIResponse.class);
        when(helper.updateVzccNBXInfo(request)).thenReturn(Mono.just(response));
        URI url = URI.create("http://localhost/updateVzccNBXInfo");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.updateVzccNBXInfo(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateVzccNBXInfoTest2() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/updateVzccNBXInfoAppliedRequest.json";
        String sampleRequest = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/updateGiftItemTest3998Response.json";
        String sampleResponse = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        UpdateVzccNBXInfoUIRequest request = mapper.readValue(sampleRequest, UpdateVzccNBXInfoUIRequest.class);
        UpdateVzccNBXInfoUIResponse response = mapper.readValue(sampleResponse, UpdateVzccNBXInfoUIResponse.class);
        when(helper.updateVzccNBXInfo(request)).thenReturn(Mono.just(response));
        URI url = URI.create("http://localhost/updateVzccNBXInfo");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.NOT_FOUND);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.updateVzccNBXInfo(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateEffectiveDateTest1() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/updateEffectiveDateRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/updateGiftItemTest3998Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        UpdateEffectiveDateUIRequest request = mapper.readValue(requestString, UpdateEffectiveDateUIRequest.class);
        UpdateEffectiveDateUIResponse response = mapper.readValue(responseString, UpdateEffectiveDateUIResponse.class);
        URI url = URI.create("http://localhost/updateEffectiveDate");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.NOT_FOUND);
        when(helper.updateEffectiveDate(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.updateEffectiveDate(httpHeader,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addDownPaymentTest1() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addDownPayment1Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addDownPayment1Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        DownPaymentUIRequest request = mapper.readValue(requestString, DownPaymentUIRequest.class);
        AddDownPaymentUIResponse response = mapper.readValue(responseString, AddDownPaymentUIResponse.class);
        URI url = URI.create("http://localhost/add-downpayment");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookie(new HttpCookie("digital_ig_session", "digital_ig_session")).build();
        ServerHttpResponse httpResponse = null;
        when(helper.addDownPayment(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDownPayment(httpHeader,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addDownPaymentErrorTest1() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addDownPaymentErrorTelesalesRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/updateGiftItemTest3998Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        DownPaymentUIRequest request = mapper.readValue(requestString, DownPaymentUIRequest.class);
        AddDownPaymentUIResponse response = mapper.readValue(responseString, AddDownPaymentUIResponse.class);
        URI url = URI.create("http://localhost/add-downpayment");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.NOT_FOUND);
        when(helper.addDownPayment(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDownPayment(httpHeader,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addDownPaymentTest2() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addDownPayment1Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addDownPayment1Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        DownPaymentUIRequest request = mapper.readValue(requestString, DownPaymentUIRequest.class);
        AddDownPaymentUIResponse response = mapper.readValue(responseString, AddDownPaymentUIResponse.class);
        URI url = URI.create("http://localhost/add-downpayment");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("digital_ig_session", "digital1").build();
        ServerHttpResponse httpResponse = null;
        when(helper.addDownPayment(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDownPayment(httpHeader,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }


    @Test
    public void updateAccountpinTest() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"data\": {}}";
        String responseString = "{}";
        AccountPinUIRequest request = mapper.readValue(requestString, AccountPinUIRequest.class);
        AccountPinUIResponse uiResponse = mapper.readValue(responseString, AccountPinUIResponse.class);
        URI url = URI.create("http://localhost/nse/updateAccountpin");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.updateAccountPin(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController2.updateAccountpin(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateAccountpinTest2() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/updateAccountpinRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{}";
        AccountPinUIRequest request = mapper.readValue(requestString, AccountPinUIRequest.class);
        AccountPinUIResponse uiResponse = mapper.readValue(responseString, AccountPinUIResponse.class);
        URI url = URI.create("http://localhost/nse/updateAccountpin");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "id")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.updateAccountPin(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController2.updateAccountpin(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateAccountpinTest3() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/updateAccountpinRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"errors\": [{}]}";
        AccountPinUIRequest request = mapper.readValue(requestString, AccountPinUIRequest.class);
        AccountPinUIResponse uiResponse = mapper.readValue(responseString, AccountPinUIResponse.class);
        URI url = URI.create("http://localhost/nse/updateAccountpin");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-CARE").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.updateAccountPin(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController2.updateAccountpin(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateAccountpinTest4() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/updateAccountpinRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"errors\": [{}]}";
        AccountPinUIRequest request = mapper.readValue(requestString, AccountPinUIRequest.class);
        AccountPinUIResponse uiResponse = mapper.readValue(responseString, AccountPinUIResponse.class);
        URI url = URI.create("http://localhost/nse/updateAccountpin");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.updateAccountPin(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController2.updateAccountpin(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateUserInfoTest() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"data\": {}}";
        String responseString = "{}";
        UpdateUserInfoUIRequest request = mapper.readValue(requestString, UpdateUserInfoUIRequest.class);
        UpdateUserInfoUIResponse uiResponse = mapper.readValue(responseString, UpdateUserInfoUIResponse.class);
        URI url = URI.create("http://localhost/userInfo");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.updateUserInfo(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController.updateUserInfo(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateUserInfoTest2() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/updateAccountpinRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"errors\": [{}]}";
        UpdateUserInfoUIRequest request = mapper.readValue(requestString, UpdateUserInfoUIRequest.class);
        UpdateUserInfoUIResponse uiResponse = mapper.readValue(responseString, UpdateUserInfoUIResponse.class);
        URI url = URI.create("http://localhost/userInfo");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "id")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.updateUserInfo(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController.updateUserInfo(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateUserInfoTest3() throws Exception {
        UpdateUserInfoUIRequest request=new UpdateUserInfoUIRequest();
        UpdateUserInfoLine line=new UpdateUserInfoLine();
        List<UpdateUserInfoLine> lines=new ArrayList<>();
        line.setMtn("7657308884");
        line.setFirstName("www.youtube.com");
        line.setEmail("ovvigvczh@vzw.com");
        lines.add(line);
        request.setLines(lines);
        request.setIntendType("EUP");
        ErrorResponse valRes = new ErrorResponse();
        List<CartError> errorList = new ArrayList<>();
        CartError crError = new CartError();
        crError.setMessage(CartConstants.NAME_VALIDATION_ERR);
        errorList.add(crError);
        valRes.setErrors(errorList);
        URI url = URI.create("http://localhost/userInfo");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.prevalidateUserRequest(Mockito.any())).thenReturn(valRes);
        Mono<ResponseEntity<GenericResponse>> response = cartController.updateUserInfo(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void enrollPaperlessBillingTest() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"data\": {}}";
        String responseString = "{}";
        PaperlessBillingUIRequest request = mapper.readValue(requestString, PaperlessBillingUIRequest.class);
        PaperlessBillingUIResponse uiResponse = mapper.readValue(responseString, PaperlessBillingUIResponse.class);
        URI url = URI.create("http://localhost/enroll-paperlessBilling");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.paperlessBilling(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController.enrollPaperlessBilling(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void enrollPaperlessBillingTest2() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/updateAccountpinRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"errors\": [{}]}";
        PaperlessBillingUIRequest request = mapper.readValue(requestString, PaperlessBillingUIRequest.class);
        PaperlessBillingUIResponse uiResponse = mapper.readValue(responseString, PaperlessBillingUIResponse.class);
        URI url = URI.create("http://localhost/enroll-paperlessBilling");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "id")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.paperlessBilling(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController.enrollPaperlessBilling(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateTradeinTypeTest() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"data\": {}}";
        String responseString = "{}";
        UpdateTradeinTypeUIRequest request = mapper.readValue(requestString, UpdateTradeinTypeUIRequest.class);
        UpdateTradeinTypeUIResponse uiResponse = mapper.readValue(responseString, UpdateTradeinTypeUIResponse.class);
        URI url = URI.create("http://localhost/tradeinType");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.updateTradeinType(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController.updateTradeinType(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateTradeinTypeTest2() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/updateAccountpinRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"errors\": [{}]}";
        UpdateTradeinTypeUIRequest request = mapper.readValue(requestString, UpdateTradeinTypeUIRequest.class);
        UpdateTradeinTypeUIResponse uiResponse = mapper.readValue(responseString, UpdateTradeinTypeUIResponse.class);
        URI url = URI.create("http://localhost/tradeinType");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "id")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.updateTradeinType(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController.updateTradeinType(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void calculateMultiLineTaxForCartTest7() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/calculateMultiLine6Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString =  "{\"meta\":{\"timestamp\":1660146695174,\"cxpCorrelationId\":\"2022-08-10T15:51:35.+0000:7539a7b3-6cd2-42fc-978f-687a648e06cb:cxp-shopping-services-qa-ev6v-sit1e-nscxp-654c9f75cb-gpqck:nssit1\"},\"data\":{\"calculateMultiLineTaxForCart\":{\"count\":1,\"orderTotalTax\":\"66.25\",\"zipCodeDetails\":{\"cityStatesFound\":[\"SECAUCUS-NJ\"],\"zipCode\":\"07094\",\"numberOfCitiesFound\":0},\"lineTaxDetails\":[{\"locationCode\":\"D239301\",\"multiLineSeqNumber\":1,\"orderType\":\"PS\",\"totalTax\":\"66.25\",\"totalPriceForTax\":\"1000.0\",\"itemsForTax\":[{\"mldSeqNum\":0,\"itemSequence\":0,\"itemCode\":\"BS32\",\"itemPrice\":\"1000.0\",\"unitTaxBasedPrice\":\"0.00\",\"qty\":1,\"discountAmount\":\"0.0\",\"e911Fee\":\"0\",\"taxAmount\":\"66.25\",\"taxBasedPriceFlag\":0,\"installmentTaxDetail\":{\"isOrderHaveDPorACC\":false},\"recycleTaxDetail\":{},\"taxDetailsList\":[{\"mldSequenceNum\":1,\"taxSequenceNum\":1,\"taxPassType\":\"10\",\"taxAmount\":\"66.25\",\"taxDescription\":\"NJ State Sales Tax\",\"taxType\":\"01\"}]}]}],\"totalDueToday\":66.25,\"totalDueMonthly\":120.57}}}";
        CalculateMultilineTaxUIRequest request = mapper.readValue(requestString, CalculateMultilineTaxUIRequest.class);
        CalculateMultilineTaxUIResponse response = mapper.readValue(responseString,CalculateMultilineTaxUIResponse.class);
        URI url = URI.create("http://localhost/nse/calculateMultiLineTaxForCart");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(helper.calculateMultiLineTaxForCart(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.calculateMultiLineTaxForCart(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void calculateMultiLineTaxForCartTest8() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/calculateMultiLine6Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString =  "{\"meta\":{\"timestamp\":1660146695174,\"cxpCorrelationId\":\"2022-08-10T15:51:35.+0000:7539a7b3-6cd2-42fc-978f-687a648e06cb:cxp-shopping-services-qa-ev6v-sit1e-nscxp-654c9f75cb-gpqck:nssit1\"},\"data\":{\"calculateMultiLineTaxForCart\":{\"count\":1,\"orderTotalTax\":\"66.25\",\"zipCodeDetails\":{\"cityStatesFound\":[\"SECAUCUS-NJ\"],\"zipCode\":\"07094\",\"numberOfCitiesFound\":null},\"lineTaxDetails\":[{\"locationCode\":\"D239301\",\"multiLineSeqNumber\":1,\"orderType\":\"PS\",\"totalTax\":\"66.25\",\"totalPriceForTax\":\"1000.0\",\"itemsForTax\":[{\"mldSeqNum\":0,\"itemSequence\":0,\"itemCode\":\"BS32\",\"itemPrice\":\"1000.0\",\"unitTaxBasedPrice\":\"0.00\",\"qty\":1,\"discountAmount\":\"0.0\",\"e911Fee\":\"0\",\"taxAmount\":\"66.25\",\"taxBasedPriceFlag\":0,\"installmentTaxDetail\":{\"isOrderHaveDPorACC\":false},\"recycleTaxDetail\":{},\"taxDetailsList\":[{\"mldSequenceNum\":1,\"taxSequenceNum\":1,\"taxPassType\":\"10\",\"taxAmount\":\"66.25\",\"taxDescription\":\"NJ State Sales Tax\",\"taxType\":\"01\"}]}]}],\"totalDueToday\":66.25,\"totalDueMonthly\":120.57}}}";
        CalculateMultilineTaxUIRequest request = mapper.readValue(requestString, CalculateMultilineTaxUIRequest.class);
        CalculateMultilineTaxUIResponse response = mapper.readValue(responseString,CalculateMultilineTaxUIResponse.class);
        URI url = URI.create("http://localhost/nse/calculateMultiLineTaxForCart");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(helper.calculateMultiLineTaxForCart(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.calculateMultiLineTaxForCart(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void calculateMultiLineTaxForCartTest9() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/calculateMultiLine6Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString =  "{\"meta\":{\"timestamp\":1660146695174,\"cxpCorrelationId\":\"2022-08-10T15:51:35.+0000:7539a7b3-6cd2-42fc-978f-687a648e06cb:cxp-shopping-services-qa-ev6v-sit1e-nscxp-654c9f75cb-gpqck:nssit1\"},\"data\":{\"calculateMultiLineTaxForCart\":{\"count\":1,\"orderTotalTax\":\"66.25\",\"zipCodeDetails\":null,\"lineTaxDetails\":[{\"locationCode\":\"D239301\",\"multiLineSeqNumber\":1,\"orderType\":\"PS\",\"totalTax\":\"66.25\",\"totalPriceForTax\":\"1000.0\",\"itemsForTax\":[{\"mldSeqNum\":0,\"itemSequence\":0,\"itemCode\":\"BS32\",\"itemPrice\":\"1000.0\",\"unitTaxBasedPrice\":\"0.00\",\"qty\":1,\"discountAmount\":\"0.0\",\"e911Fee\":\"0\",\"taxAmount\":\"66.25\",\"taxBasedPriceFlag\":0,\"installmentTaxDetail\":{\"isOrderHaveDPorACC\":false},\"recycleTaxDetail\":{},\"taxDetailsList\":[{\"mldSequenceNum\":1,\"taxSequenceNum\":1,\"taxPassType\":\"10\",\"taxAmount\":\"66.25\",\"taxDescription\":\"NJ State Sales Tax\",\"taxType\":\"01\"}]}]}],\"totalDueToday\":66.25,\"totalDueMonthly\":120.57}}}";
        CalculateMultilineTaxUIRequest request = mapper.readValue(requestString, CalculateMultilineTaxUIRequest.class);
        CalculateMultilineTaxUIResponse response = mapper.readValue(responseString,CalculateMultilineTaxUIResponse.class);
        URI url = URI.create("http://localhost/nse/calculateMultiLineTaxForCart");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(helper.calculateMultiLineTaxForCart(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.calculateMultiLineTaxForCart(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void calculateMultiLineTaxForCartTest10() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/calculateMultiLine6Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString =  "{\"meta\":{\"timestamp\":1660146695174,\"cxpCorrelationId\":\"2022-08-10T15:51:35.+0000:7539a7b3-6cd2-42fc-978f-687a648e06cb:cxp-shopping-services-qa-ev6v-sit1e-nscxp-654c9f75cb-gpqck:nssit1\"},\"data\":{\"calculateMultiLineTaxForCart\":null}}";
        CalculateMultilineTaxUIRequest request = mapper.readValue(requestString, CalculateMultilineTaxUIRequest.class);
        CalculateMultilineTaxUIResponse response = mapper.readValue(responseString,CalculateMultilineTaxUIResponse.class);
        URI url = URI.create("http://localhost/nse/calculateMultiLineTaxForCart");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(helper.calculateMultiLineTaxForCart(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.calculateMultiLineTaxForCart(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void calculateMultiLineTaxForCartTest11() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/calculateMultiLine6Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString =  "{\"meta\":{\"timestamp\":1660146695174,\"cxpCorrelationId\":\"2022-08-10T15:51:35.+0000:7539a7b3-6cd2-42fc-978f-687a648e06cb:cxp-shopping-services-qa-ev6v-sit1e-nscxp-654c9f75cb-gpqck:nssit1\"},\"data\":null}";
        CalculateMultilineTaxUIRequest request = mapper.readValue(requestString, CalculateMultilineTaxUIRequest.class);
        CalculateMultilineTaxUIResponse response = mapper.readValue(responseString,CalculateMultilineTaxUIResponse.class);
        URI url = URI.create("http://localhost/nse/calculateMultiLineTaxForCart");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(helper.calculateMultiLineTaxForCart(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.calculateMultiLineTaxForCart(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void calculateMultiLineTaxForCartTest13() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/calculateMultiLine6Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "createLineError1Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        CalculateMultilineTaxUIRequest request = mapper.readValue(requestString, CalculateMultilineTaxUIRequest.class);
        CalculateMultilineTaxUIResponse response = mapper.readValue(responseString,CalculateMultilineTaxUIResponse.class);
        URI url = URI.create("http://localhost/calculateMultiLineTaxForCart");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.NOT_FOUND);
        when(helper.calculateMultiLineTaxForCart(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.calculateMultiLineTaxForCart(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addPromoIntentTest() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/AALrequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{}";
        AddPromoIntentUIRequest request = mapper.readValue(requestString, AddPromoIntentUIRequest.class);
        AddPromoIntentUIResponse uiResponse = mapper.readValue(responseString, AddPromoIntentUIResponse.class);
        URI url = URI.create("http://localhost/addPromoIntent");
        Flag flag = new Flag();
        flag.setName("promoToPlanTransitionFFlag");
        flag.setEnabled(true);
        List<Flag> flags = new ArrayList<>();
        flags.add(flag);
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        AddPromoIntentContext context = new AddPromoIntentContext();
        context.setCaseId("SOP-538499-E01");
        AddPromoIntentServiceRequest serviceRequest = new AddPromoIntentServiceRequest();
        serviceRequest.setContext(context);
        AddPromoIntentServiceBody serviceBody = new AddPromoIntentServiceBody();
        serviceBody.setServiceRequest(serviceRequest);
        AddPromoIntentUIResponse addPromoIntentUIResponse = new AddPromoIntentUIResponse();
        addPromoIntentUIResponse.setServiceBody(serviceBody);
//        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"bbpImei\": \"8436667390\",\"bbpIccid\":\"89148000005148869944\" }";
//        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
//        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        String requestFile2 = "data/CartUpdateOperationsControllerTestJson/addPromoIntentTaggingRequest.json";
        String requestString2 = sourceFileReaderUtil.readFile(requestFile2, testFileLocation);
        String responseString2 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.11.28.09.44.24-993.5973380891764\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-13546665-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"PopularPlans\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"NewRecommendedPlanSelection\",\"processAction\":\"\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"globalId\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"noc\":false},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"539ff76b-3467-4b85-b9d0-fc9a8ccbed0e\",\"couponCode\":\"\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":23.24,\"monthlyInstallment\":23.05,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"sim\":{\"id\":\"UNIVESIM5G-SAB-D\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"OfferInterstitial\"]}]}}}}";
        AddPromoIntentUIRequest req = mapper.readValue(requestString2, AddPromoIntentUIRequest.class);
        AddPromoIntentUIResponse res = mapper.readValue(responseString2, AddPromoIntentUIResponse.class);
        ResponseEntity<Object> responseEntity =
                ResponseEntity.status(HttpStatus.OK).body(res);
        CartRedisData cartRedisData = jsonToObject("/data/cartServiceHelperTest/CartRedisData.json", CartRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(cartRedisData));
        BundleBuilderCXPResponseData bundleBuilderCXPResponseData = jsonToObject("/promobuildercxpcart_response.json", BundleBuilderCXPResponseData.class);
        when(readCartHelper.bundleBuilderCart(any())).thenReturn(Mono.just(bundleBuilderCXPResponseData));
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        when(featureFlagHelper.mergeFeatureFlagWithResponse(Mockito.any())).thenReturn(Mono.just(res));
        when(helper.addPromoIntent(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(new ErrorResponse());
        Mono<ResponseEntity<GenericResponse>> response = cartController2.addPromoIntent(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }
    @Test
    public void addPromoIntentTest1() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addPromoIntentRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"errors\": [{}]}";;
        AddPromoIntentUIRequest request = mapper.readValue(requestString, AddPromoIntentUIRequest.class);
        AddPromoIntentUIResponse uiResponse = mapper.readValue(responseString, AddPromoIntentUIResponse.class);
        URI url = URI.create("http://localhost/addPromoIntent");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "OMNI-CARE").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        AddPromoIntentContext context = new AddPromoIntentContext();
        context.setCaseId("SOP-538499-E01");
        AddPromoIntentServiceRequest serviceRequest = new AddPromoIntentServiceRequest();
        serviceRequest.setContext(context);
        AddPromoIntentServiceBody serviceBody = new AddPromoIntentServiceBody();
        serviceBody.setServiceRequest(serviceRequest);
        AddPromoIntentUIResponse addPromoIntentUIResponse = new AddPromoIntentUIResponse();
        addPromoIntentUIResponse.setServiceBody(serviceBody);
        String requestFile2 = "data/CartUpdateOperationsControllerTestJson/addPromoIntentTaggingRequest.json";
        String requestString2 = sourceFileReaderUtil.readFile(requestFile2, testFileLocation);
        String responseString2 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.11.28.09.44.24-993.5973380891764\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-13546665-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"PopularPlans\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"NewRecommendedPlanSelection\",\"processAction\":\"\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"globalId\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"noc\":false},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"539ff76b-3467-4b85-b9d0-fc9a8ccbed0e\",\"couponCode\":\"\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":23.24,\"monthlyInstallment\":23.05,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"sim\":{\"id\":\"UNIVESIM5G-SAB-D\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"OfferInterstitial\"]}]}}}}";
        AddPromoIntentUIRequest req = mapper.readValue(requestString2, AddPromoIntentUIRequest.class);
        AddPromoIntentUIResponse res = mapper.readValue(responseString2, AddPromoIntentUIResponse.class);
        ResponseEntity<Object> responseEntity =
                ResponseEntity.status(HttpStatus.OK).body(res);
        CartRedisData cartRedisData = jsonToObject("/data/cartServiceHelperTest/CartRedisData.json", CartRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(cartRedisData));
        BundleBuilderCXPResponseData bundleBuilderCXPResponseData = jsonToObject("/promobuildercxpcart_response.json", BundleBuilderCXPResponseData.class);
        when(readCartHelper.bundleBuilderCart(any())).thenReturn(Mono.just(bundleBuilderCXPResponseData));
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        when(featureFlagHelper.mergeFeatureFlagWithResponse(Mockito.any())).thenReturn(Mono.just(res));
        when(helper.addPromoIntent(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(new ErrorResponse());
        Mono<ResponseEntity<GenericResponse>> response = cartController2.addPromoIntent(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }


    @Test
    public void addPromoIntentTaggingTest() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addPromoIntentTaggingRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.11.28.09.44.24-993.5973380891764\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-13546665-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"PopularPlans\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"NewRecommendedPlanSelection\",\"processAction\":\"\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"globalId\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"noc\":false},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"539ff76b-3467-4b85-b9d0-fc9a8ccbed0e\",\"couponCode\":\"\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":23.24,\"monthlyInstallment\":23.05,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"sim\":{\"id\":\"UNIVESIM5G-SAB-D\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"OfferInterstitial\"]}]}}}}";
        AddPromoIntentUIRequest request = mapper.readValue(requestString, AddPromoIntentUIRequest.class);
        AddPromoIntentUIResponse uiResponse = mapper.readValue(responseString, AddPromoIntentUIResponse.class);
        URI url = URI.create("http://localhost/addPromoIntent");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        AddPromoIntentContext context = new AddPromoIntentContext();
        context.setCaseId("SOP-538499-E01");
        AddPromoIntentServiceRequest serviceRequest = new AddPromoIntentServiceRequest();
        serviceRequest.setContext(context);
        AddPromoIntentServiceBody serviceBody = new AddPromoIntentServiceBody();
        serviceBody.setServiceRequest(serviceRequest);
        AddPromoIntentUIResponse addPromoIntentUIResponse = new AddPromoIntentUIResponse();
        addPromoIntentUIResponse.setServiceBody(serviceBody);
        String requestFile2 = "data/CartUpdateOperationsControllerTestJson/addPromoIntentTaggingRequest.json";
        String requestString2 = sourceFileReaderUtil.readFile(requestFile2, testFileLocation);
        String responseString2 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.11.28.09.44.24-993.5973380891764\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-13546665-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"PopularPlans\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"NewRecommendedPlanSelection\",\"processAction\":\"\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"globalId\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"noc\":false},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"539ff76b-3467-4b85-b9d0-fc9a8ccbed0e\",\"couponCode\":\"\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":23.24,\"monthlyInstallment\":23.05,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"sim\":{\"id\":\"UNIVESIM5G-SAB-D\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"OfferInterstitial\"]}]}}}}";
        AddPromoIntentUIRequest req = mapper.readValue(requestString2, AddPromoIntentUIRequest.class);
        AddPromoIntentUIResponse res = mapper.readValue(responseString2, AddPromoIntentUIResponse.class);
        ResponseEntity<Object> responseEntity =
                ResponseEntity.status(HttpStatus.OK).body(res);
        CartRedisData cartRedisData = jsonToObject("/data/cartServiceHelperTest/CartRedisData.json", CartRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(cartRedisData));
        BundleBuilderCXPResponseData bundleBuilderCXPResponseData = jsonToObject("/promobuildercxpcart_response.json", BundleBuilderCXPResponseData.class);
        when(readCartHelper.bundleBuilderCart(any())).thenReturn(Mono.just(bundleBuilderCXPResponseData));
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        when(featureFlagHelper.mergeFeatureFlagWithResponse(Mockito.any())).thenReturn(Mono.just(res));
        when(helper.addPromoIntent(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(new ErrorResponse());
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        Mono<ResponseEntity<GenericResponse>> response = cartController2.addPromoIntent(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addPromoIntentTaggingFlowNullTest() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addPromoIntentTaggingRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.11.28.09.44.24-993.5973380891764\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-13546665-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"PopularPlans\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"NewRecommendedPlanSelection\",\"processAction\":\"\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"globalId\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"noc\":false},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"539ff76b-3467-4b85-b9d0-fc9a8ccbed0e\",\"couponCode\":\"\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":23.24,\"monthlyInstallment\":23.05,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"sim\":{\"id\":\"UNIVESIM5G-SAB-D\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"OfferInterstitial\"]}]}}}}";
        AddPromoIntentUIRequest request = mapper.readValue(requestString, AddPromoIntentUIRequest.class);
        AddPromoIntentUIResponse uiResponse = mapper.readValue(responseString, AddPromoIntentUIResponse.class);
        request.getCartInfo().setIntendType("");
        URI url = URI.create("http://localhost/addPromoIntent");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        AddPromoIntentContext context = new AddPromoIntentContext();
        context.setCaseId("SOP-538499-E01");
        AddPromoIntentServiceRequest serviceRequest = new AddPromoIntentServiceRequest();
        serviceRequest.setContext(context);
        AddPromoIntentServiceBody serviceBody = new AddPromoIntentServiceBody();
        serviceBody.setServiceRequest(serviceRequest);
        AddPromoIntentUIResponse addPromoIntentUIResponse = new AddPromoIntentUIResponse();
        addPromoIntentUIResponse.setServiceBody(serviceBody);
        String requestFile2 = "data/CartUpdateOperationsControllerTestJson/addPromoIntentTaggingRequest.json";
        String requestString2 = sourceFileReaderUtil.readFile(requestFile2, testFileLocation);
        String responseString2 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.11.28.09.44.24-993.5973380891764\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-13546665-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"PopularPlans\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"NewRecommendedPlanSelection\",\"processAction\":\"\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"globalId\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"noc\":false},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"539ff76b-3467-4b85-b9d0-fc9a8ccbed0e\",\"couponCode\":\"\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":23.24,\"monthlyInstallment\":23.05,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"sim\":{\"id\":\"UNIVESIM5G-SAB-D\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"OfferInterstitial\"]}]}}}}";
        AddPromoIntentUIRequest req = mapper.readValue(requestString2, AddPromoIntentUIRequest.class);
        AddPromoIntentUIResponse res = mapper.readValue(responseString2, AddPromoIntentUIResponse.class);
        ResponseEntity<Object> responseEntity =
                ResponseEntity.status(HttpStatus.OK).body(res);
        CartRedisData cartRedisData = jsonToObject("/data/cartServiceHelperTest/CartRedisData.json", CartRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(cartRedisData));
        BundleBuilderCXPResponseData bundleBuilderCXPResponseData = jsonToObject("/promobuildercxpcart_response.json", BundleBuilderCXPResponseData.class);
        when(readCartHelper.bundleBuilderCart(any())).thenReturn(Mono.just(bundleBuilderCXPResponseData));
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        when(featureFlagHelper.mergeFeatureFlagWithResponse(Mockito.any())).thenReturn(Mono.just(res));
        when(helper.addPromoIntent(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(new ErrorResponse());
        Mono<ResponseEntity<GenericResponse>> response = cartController2.addPromoIntent(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addPromoIntentTaggingFlowBYODTest() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addPromoIntentTaggingRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.11.28.09.44.24-993.5973380891764\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-13546665-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"PopularPlans\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"NewRecommendedPlanSelection\",\"processAction\":\"\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"globalId\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"noc\":false},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"539ff76b-3467-4b85-b9d0-fc9a8ccbed0e\",\"couponCode\":\"\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":23.24,\"monthlyInstallment\":23.05,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"sim\":{\"id\":\"UNIVESIM5G-SAB-D\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"OfferInterstitial\"]}]}}}}";
        AddPromoIntentUIRequest request = mapper.readValue(requestString, AddPromoIntentUIRequest.class);
        AddPromoIntentUIResponse uiResponse = mapper.readValue(responseString, AddPromoIntentUIResponse.class);
        request.getCartInfo().setIntendType("BYOD");
        URI url = URI.create("http://localhost/addPromoIntent");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        AddPromoIntentContext context = new AddPromoIntentContext();
        context.setCaseId("SOP-538499-E01");
        AddPromoIntentServiceRequest serviceRequest = new AddPromoIntentServiceRequest();
        serviceRequest.setContext(context);
        AddPromoIntentServiceBody serviceBody = new AddPromoIntentServiceBody();
        serviceBody.setServiceRequest(serviceRequest);
        AddPromoIntentUIResponse addPromoIntentUIResponse = new AddPromoIntentUIResponse();
        addPromoIntentUIResponse.setServiceBody(serviceBody);
        String requestFile2 = "data/CartUpdateOperationsControllerTestJson/addPromoIntentTaggingRequest.json";
        String requestString2 = sourceFileReaderUtil.readFile(requestFile2, testFileLocation);
        String responseString2 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.11.28.09.44.24-993.5973380891764\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-13546665-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"PopularPlans\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"NewRecommendedPlanSelection\",\"processAction\":\"\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"globalId\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"noc\":false},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"539ff76b-3467-4b85-b9d0-fc9a8ccbed0e\",\"couponCode\":\"\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":23.24,\"monthlyInstallment\":23.05,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"sim\":{\"id\":\"UNIVESIM5G-SAB-D\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"OfferInterstitial\"]}]}}}}";
        AddPromoIntentUIRequest req = mapper.readValue(requestString2, AddPromoIntentUIRequest.class);
        AddPromoIntentUIResponse res = mapper.readValue(responseString2, AddPromoIntentUIResponse.class);
        ResponseEntity<Object> responseEntity =
                ResponseEntity.status(HttpStatus.OK).body(res);
        CartRedisData cartRedisData = jsonToObject("/data/cartServiceHelperTest/CartRedisData.json", CartRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(cartRedisData));
        BundleBuilderCXPResponseData bundleBuilderCXPResponseData = jsonToObject("/promobuildercxpcart_response.json", BundleBuilderCXPResponseData.class);
        when(readCartHelper.bundleBuilderCart(any())).thenReturn(Mono.just(bundleBuilderCXPResponseData));
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        when(featureFlagHelper.mergeFeatureFlagWithResponse(Mockito.any())).thenReturn(Mono.just(res));
        when(helper.addPromoIntent(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(new ErrorResponse());
        Mono<ResponseEntity<GenericResponse>> response = cartController2.addPromoIntent(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addPromoIntentTaggingFlowEUPBYODTest() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addPromoIntentTaggingRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.11.28.09.44.24-993.5973380891764\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-13546665-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"PopularPlans\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"NewRecommendedPlanSelection\",\"processAction\":\"\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"globalId\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"noc\":false},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"539ff76b-3467-4b85-b9d0-fc9a8ccbed0e\",\"couponCode\":\"\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":23.24,\"monthlyInstallment\":23.05,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"sim\":{\"id\":\"UNIVESIM5G-SAB-D\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"OfferInterstitial\"]}]}}}}";
        AddPromoIntentUIRequest request = mapper.readValue(requestString, AddPromoIntentUIRequest.class);
        AddPromoIntentUIResponse uiResponse = mapper.readValue(responseString, AddPromoIntentUIResponse.class);
        request.getCartInfo().setIntendType("EUPBYOD");
        URI url = URI.create("http://localhost/addPromoIntent");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        AddPromoIntentContext context = new AddPromoIntentContext();
        context.setCaseId("SOP-538499-E01");
        AddPromoIntentServiceRequest serviceRequest = new AddPromoIntentServiceRequest();
        serviceRequest.setContext(context);
        AddPromoIntentServiceBody serviceBody = new AddPromoIntentServiceBody();
        serviceBody.setServiceRequest(serviceRequest);
        AddPromoIntentUIResponse addPromoIntentUIResponse = new AddPromoIntentUIResponse();
        addPromoIntentUIResponse.setServiceBody(serviceBody);
        String requestFile2 = "data/CartUpdateOperationsControllerTestJson/addPromoIntentTaggingRequest.json";
        String requestString2 = sourceFileReaderUtil.readFile(requestFile2, testFileLocation);
        String responseString2 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.11.28.09.44.24-993.5973380891764\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-13546665-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"PopularPlans\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"NewRecommendedPlanSelection\",\"processAction\":\"\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"globalId\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"noc\":false},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"539ff76b-3467-4b85-b9d0-fc9a8ccbed0e\",\"couponCode\":\"\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":23.24,\"monthlyInstallment\":23.05,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"sim\":{\"id\":\"UNIVESIM5G-SAB-D\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"OfferInterstitial\"]}]}}}}";
        AddPromoIntentUIRequest req = mapper.readValue(requestString2, AddPromoIntentUIRequest.class);
        AddPromoIntentUIResponse res = mapper.readValue(responseString2, AddPromoIntentUIResponse.class);
        ResponseEntity<Object> responseEntity =
                ResponseEntity.status(HttpStatus.OK).body(res);
        CartRedisData cartRedisData = jsonToObject("/data/cartServiceHelperTest/CartRedisData.json", CartRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(cartRedisData));
        BundleBuilderCXPResponseData bundleBuilderCXPResponseData = jsonToObject("/promobuildercxpcart_response.json", BundleBuilderCXPResponseData.class);
        when(readCartHelper.bundleBuilderCart(any())).thenReturn(Mono.just(bundleBuilderCXPResponseData));
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        when(featureFlagHelper.mergeFeatureFlagWithResponse(Mockito.any())).thenReturn(Mono.just(res));
        when(helper.addPromoIntent(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(new ErrorResponse());
        Mono<ResponseEntity<GenericResponse>> response = cartController2.addPromoIntent(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addPromoIntentTaggingFlowNSEBYODTest() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addPromoIntentTaggingRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.11.28.09.44.24-993.5973380891764\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-13546665-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"PopularPlans\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"NewRecommendedPlanSelection\",\"processAction\":\"\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"globalId\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"noc\":false},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"539ff76b-3467-4b85-b9d0-fc9a8ccbed0e\",\"couponCode\":\"\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":23.24,\"monthlyInstallment\":23.05,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"sim\":{\"id\":\"UNIVESIM5G-SAB-D\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"OfferInterstitial\"]}]}}}}";
        AddPromoIntentUIRequest request = mapper.readValue(requestString, AddPromoIntentUIRequest.class);
        AddPromoIntentUIResponse uiResponse = mapper.readValue(responseString, AddPromoIntentUIResponse.class);
        request.getCartInfo().setIntendType("NSEBYOD");
        URI url = URI.create("http://localhost/addPromoIntent");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        AddPromoIntentContext context = new AddPromoIntentContext();
        context.setCaseId("SOP-538499-E01");
        AddPromoIntentServiceRequest serviceRequest = new AddPromoIntentServiceRequest();
        serviceRequest.setContext(context);
        AddPromoIntentServiceBody serviceBody = new AddPromoIntentServiceBody();
        serviceBody.setServiceRequest(serviceRequest);
        AddPromoIntentUIResponse addPromoIntentUIResponse = new AddPromoIntentUIResponse();
        addPromoIntentUIResponse.setServiceBody(serviceBody);
        String requestFile2 = "data/CartUpdateOperationsControllerTestJson/addPromoIntentTaggingRequest.json";
        String requestString2 = sourceFileReaderUtil.readFile(requestFile2, testFileLocation);
        String responseString2 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.11.28.09.44.24-993.5973380891764\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-13546665-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"PopularPlans\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"NewRecommendedPlanSelection\",\"processAction\":\"\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"globalId\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"noc\":false},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"539ff76b-3467-4b85-b9d0-fc9a8ccbed0e\",\"couponCode\":\"\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":23.24,\"monthlyInstallment\":23.05,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"sim\":{\"id\":\"UNIVESIM5G-SAB-D\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"OfferInterstitial\"]}]}}}}";
        AddPromoIntentUIRequest req = mapper.readValue(requestString2, AddPromoIntentUIRequest.class);
        AddPromoIntentUIResponse res = mapper.readValue(responseString2, AddPromoIntentUIResponse.class);
        ResponseEntity<Object> responseEntity =
                ResponseEntity.status(HttpStatus.OK).body(res);
        CartRedisData cartRedisData = jsonToObject("/data/cartServiceHelperTest/CartRedisData.json", CartRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(cartRedisData));
        BundleBuilderCXPResponseData bundleBuilderCXPResponseData = jsonToObject("/promobuildercxpcart_response.json", BundleBuilderCXPResponseData.class);
        when(readCartHelper.bundleBuilderCart(any())).thenReturn(Mono.just(bundleBuilderCXPResponseData));
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        when(featureFlagHelper.mergeFeatureFlagWithResponse(Mockito.any())).thenReturn(Mono.just(res));
        when(helper.addPromoIntent(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(new ErrorResponse());
        Mono<ResponseEntity<GenericResponse>> response = cartController2.addPromoIntent(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }
    @Test
    public void addPromoIntent2() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addPromoIntentRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"errors\": [{}]}";
        AddPromoIntentUIRequest request = mapper.readValue(requestString, AddPromoIntentUIRequest.class);
        AddPromoIntentUIResponse uiResponse = mapper.readValue(responseString, AddPromoIntentUIResponse.class);
        URI url = URI.create("http://localhost/deassign-mtn");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "OMNI-CARE").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        AddPromoIntentContext context = new AddPromoIntentContext();
        context.setCaseId("SOP-538499-E01");
        AddPromoIntentServiceRequest serviceRequest = new AddPromoIntentServiceRequest();
        serviceRequest.setContext(context);
        AddPromoIntentServiceBody serviceBody = new AddPromoIntentServiceBody();
        serviceBody.setServiceRequest(serviceRequest);
        AddPromoIntentUIResponse addPromoIntentUIResponse = new AddPromoIntentUIResponse();
        addPromoIntentUIResponse.setServiceBody(serviceBody);
        String requestFile2 = "data/CartUpdateOperationsControllerTestJson/addPromoIntentTaggingRequest.json";
        String requestString2 = sourceFileReaderUtil.readFile(requestFile2, testFileLocation);
        String responseString2 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.11.28.09.44.24-993.5973380891764\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-13546665-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"PopularPlans\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"NewRecommendedPlanSelection\",\"processAction\":\"\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"globalId\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"noc\":false},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"539ff76b-3467-4b85-b9d0-fc9a8ccbed0e\",\"couponCode\":\"\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":23.24,\"monthlyInstallment\":23.05,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"sim\":{\"id\":\"UNIVESIM5G-SAB-D\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"OfferInterstitial\"]}]}}}}";
        AddPromoIntentUIRequest req = mapper.readValue(requestString2, AddPromoIntentUIRequest.class);
        AddPromoIntentUIResponse res = mapper.readValue(responseString2, AddPromoIntentUIResponse.class);
        ResponseEntity<Object> responseEntity =
                ResponseEntity.status(HttpStatus.OK).body(res);
        CartRedisData cartRedisData = jsonToObject("/data/cartServiceHelperTest/CartRedisData.json", CartRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(cartRedisData));
        BundleBuilderCXPResponseData bundleBuilderCXPResponseData = jsonToObject("/promobuildercxpcart_response.json", BundleBuilderCXPResponseData.class);
        when(readCartHelper.bundleBuilderCart(any())).thenReturn(Mono.just(bundleBuilderCXPResponseData));
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        when(featureFlagHelper.mergeFeatureFlagWithResponse(Mockito.any())).thenReturn(Mono.just(res));
        when(helper.addPromoIntent(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        Mono<ResponseEntity<GenericResponse>> response = cartController2.addPromoIntent(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }
    @Test
    public void addPromoIntent3() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addPromoIntentRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{}";
        AddPromoIntentUIRequest request = mapper.readValue(requestString, AddPromoIntentUIRequest.class);
        AddPromoIntentUIResponse uiResponse = mapper.readValue(responseString, AddPromoIntentUIResponse.class);
        URI url = URI.create("http://localhost/addPromoIntent");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        AddPromoIntentContext context = new AddPromoIntentContext();
        context.setCaseId("SOP-538499-E01");
        AddPromoIntentServiceRequest serviceRequest = new AddPromoIntentServiceRequest();
        serviceRequest.setContext(context);
        AddPromoIntentServiceBody serviceBody = new AddPromoIntentServiceBody();
        serviceBody.setServiceRequest(serviceRequest);
        AddPromoIntentUIResponse addPromoIntentUIResponse = new AddPromoIntentUIResponse();
        addPromoIntentUIResponse.setServiceBody(serviceBody);
        String requestFile2 = "data/CartUpdateOperationsControllerTestJson/addPromoIntentTaggingRequest.json";
        String requestString2 = sourceFileReaderUtil.readFile(requestFile2, testFileLocation);
        String responseString2 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.11.28.09.44.24-993.5973380891764\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-13546665-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"PopularPlans\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"NewRecommendedPlanSelection\",\"processAction\":\"\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"globalId\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"noc\":false},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"539ff76b-3467-4b85-b9d0-fc9a8ccbed0e\",\"couponCode\":\"\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":23.24,\"monthlyInstallment\":23.05,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"sim\":{\"id\":\"UNIVESIM5G-SAB-D\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"OfferInterstitial\"]}]}}}}";
        AddPromoIntentUIRequest req = mapper.readValue(requestString2, AddPromoIntentUIRequest.class);
        AddPromoIntentUIResponse res = mapper.readValue(responseString2, AddPromoIntentUIResponse.class);
        ResponseEntity<Object> responseEntity =
                ResponseEntity.status(HttpStatus.OK).body(res);
        CartRedisData cartRedisData = jsonToObject("/data/cartServiceHelperTest/CartRedisData.json", CartRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(cartRedisData));
        BundleBuilderCXPResponseData bundleBuilderCXPResponseData = jsonToObject("/promobuildercxpcart_response.json", BundleBuilderCXPResponseData.class);
        when(readCartHelper.bundleBuilderCart(any())).thenReturn(Mono.just(bundleBuilderCXPResponseData));
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        when(featureFlagHelper.mergeFeatureFlagWithResponse(Mockito.any())).thenReturn(Mono.just(res));
        when(helper.addPromoIntent(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        Mono<ResponseEntity<GenericResponse>> response = cartController2.addPromoIntent(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addPromoIntent4() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addPromoIntentRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"errors\": [{}]}";
        AddPromoIntentUIRequest request = mapper.readValue(requestString, AddPromoIntentUIRequest.class);
        AddPromoIntentUIResponse uiResponse = mapper.readValue(responseString, AddPromoIntentUIResponse.class);
        URI url = URI.create("http://localhost/addPromoIntent");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        AddPromoIntentContext context = new AddPromoIntentContext();
        context.setCaseId("SOP-538499-E01");
        AddPromoIntentServiceRequest serviceRequest = new AddPromoIntentServiceRequest();
        serviceRequest.setContext(context);
        AddPromoIntentServiceBody serviceBody = new AddPromoIntentServiceBody();
        serviceBody.setServiceRequest(serviceRequest);
        AddPromoIntentUIResponse addPromoIntentUIResponse = new AddPromoIntentUIResponse();
        addPromoIntentUIResponse.setServiceBody(serviceBody);
        String requestFile2 = "data/CartUpdateOperationsControllerTestJson/addPromoIntentTaggingRequest.json";
        String requestString2 = sourceFileReaderUtil.readFile(requestFile2, testFileLocation);
        String responseString2 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.11.28.09.44.24-993.5973380891764\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-13546665-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"PopularPlans\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"NewRecommendedPlanSelection\",\"processAction\":\"\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"globalId\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"noc\":false},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"539ff76b-3467-4b85-b9d0-fc9a8ccbed0e\",\"couponCode\":\"\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":23.24,\"monthlyInstallment\":23.05,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"sim\":{\"id\":\"UNIVESIM5G-SAB-D\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"OfferInterstitial\"]}]}}}}";
        AddPromoIntentUIRequest req = mapper.readValue(requestString2, AddPromoIntentUIRequest.class);
        AddPromoIntentUIResponse res = mapper.readValue(responseString2, AddPromoIntentUIResponse.class);
        ResponseEntity<Object> responseEntity =
                ResponseEntity.status(HttpStatus.OK).body(res);
        CartRedisData cartRedisData = jsonToObject("/data/cartServiceHelperTest/CartRedisData.json", CartRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(cartRedisData));
        BundleBuilderCXPResponseData bundleBuilderCXPResponseData = jsonToObject("/promobuildercxpcart_response.json", BundleBuilderCXPResponseData.class);
        when(readCartHelper.bundleBuilderCart(any())).thenReturn(Mono.just(bundleBuilderCXPResponseData));
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        when(featureFlagHelper.mergeFeatureFlagWithResponse(Mockito.any())).thenReturn(Mono.just(res));
        when(helper.addPromoIntent(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        Mono<ResponseEntity<GenericResponse>> response = cartController2.addPromoIntent(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addPromoIntent5() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addPromoIntentRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"errors\": [{}]}";
        AddPromoIntentUIRequest request = mapper.readValue(requestString, AddPromoIntentUIRequest.class);
        AddPromoIntentUIResponse uiResponse = mapper.readValue(responseString, AddPromoIntentUIResponse.class);
        URI url = URI.create("http://localhost/addPromoIntent");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        AddPromoIntentContext context = new AddPromoIntentContext();
        context.setCaseId("SOP-538499-E01");
        AddPromoIntentServiceRequest serviceRequest = new AddPromoIntentServiceRequest();
        serviceRequest.setContext(context);
        AddPromoIntentServiceBody serviceBody = new AddPromoIntentServiceBody();
        serviceBody.setServiceRequest(serviceRequest);
        AddPromoIntentUIResponse addPromoIntentUIResponse = new AddPromoIntentUIResponse();
        addPromoIntentUIResponse.setServiceBody(serviceBody);
        String requestFile2 = "data/CartUpdateOperationsControllerTestJson/addPromoIntentTaggingRequest.json";
        String requestString2 = sourceFileReaderUtil.readFile(requestFile2, testFileLocation);
        String responseString2 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.11.28.09.44.24-993.5973380891764\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-13546665-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"PopularPlans\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"NewRecommendedPlanSelection\",\"processAction\":\"\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"globalId\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"noc\":false},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"539ff76b-3467-4b85-b9d0-fc9a8ccbed0e\",\"couponCode\":\"\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":23.24,\"monthlyInstallment\":23.05,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"sim\":{\"id\":\"UNIVESIM5G-SAB-D\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"OfferInterstitial\"]}]}}}}";
        AddPromoIntentUIRequest req = mapper.readValue(requestString2, AddPromoIntentUIRequest.class);
        AddPromoIntentUIResponse res = mapper.readValue(responseString2, AddPromoIntentUIResponse.class);
        ResponseEntity<Object> responseEntity =
                ResponseEntity.status(HttpStatus.OK).body(res);
        CartRedisData cartRedisData = jsonToObject("/data/cartServiceHelperTest/CartRedisData.json", CartRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(cartRedisData));
        BundleBuilderCXPResponseData bundleBuilderCXPResponseData = jsonToObject("/promobuildercxpcart_response.json", BundleBuilderCXPResponseData.class);
        when(readCartHelper.bundleBuilderCart(any())).thenReturn(Mono.just(bundleBuilderCXPResponseData));
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        when(featureFlagHelper.mergeFeatureFlagWithResponse(Mockito.any())).thenReturn(Mono.just(res));
        when(helper.addPromoIntent(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        Mono<ResponseEntity<GenericResponse>> response = cartController2.addPromoIntent(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

	@Test
	public void addZipcodeThroughPegaTest() throws IOException{
		String sampleRequestString = "{\"cartInfo\": {\"intendType\": \"NSEBYOD\",\"cartId\":\"f0679741-4223-472b-a025-98824801ec24\",\"sessionId\":\"POS-D-5a609133-3963-4497-b669-864f7bf3ebc9\",\"zipCode\":\"07920\",\"action\":\"UPDATE\"} ,\"channelId\":\"VZW-DOTCOM-BBP\",\"isAddZipcodeCallToPega\":true,\"isSmartphoneFlow\":true}";
		String sampleResponseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-DOTCOM-BBP\", \"statusMsg\": \"PEGA generated message\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"sessionId\": \"\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"0\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \"SOP-1583186-DEV3\", \"customerInfo\": { \"accountNumber\": \"07893451230-00001\", \"cartCreator\": \"2515813861\",\"customerType\":\"N\", \"processingMTN\": \"newLine1\" }, \"cartInfo\": { \"cartId\": \"cff57848-8bbd-4c27-9afa-5bfd39c2b5ad\", \"statusCode\": 1, \"statusMsg\": \"SUCCESS\" } }, \"contextInfo\": { \"processAction\": \"\", \"processStep\": \"PlanSelection\", \"availablePaths\": [ { \"path\": \"PlanCategoryPage`\" } ], \"callReason\": \" SalesOrderPurchase \" } } } }";
		AddZipCodeUIRequest request = mapper.readValue(sampleRequestString, AddZipCodeUIRequest.class);
		BBPAddZipcodeResponse response = mapper.readValue(sampleResponseString, BBPAddZipcodeResponse.class);
		String redisFile = "MockRedisData.json";
		String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cartServiceBpmHelper4.addZipcodeThroughPEGA(request)).thenReturn(Mono.just(response));

		request.getCartInfo().setIntendType("NSEBYOD");
		URI url = URI.create("http://localhost/addZipcodeThroughPega");
		ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.OK);
		Mono<ResponseEntity<GenericResponse>>  controllerResponse = cartController4.addZipcodeThroughPega(httpRequest,httpResponse, request);
		StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();

	}
    @Test
    public void addZipcodeThroughPegaErrorTest() throws IOException{
        String sampleRequestString = "{\"cartInfo\": {\"intendType\": \"NSEBYOD\",\"cartId\":\"f0679741-4223-472b-a025-98824801ec24\",\"sessionId\":\"POS-D-5a609133-3963-4497-b669-864f7bf3ebc9\",\"zipCode\":\"07920\",\"action\":\"UPDATE\"} ,\"channelId\":\"VZW-DOTCOM-BBP\",\"isAddZipcodeCallToPega\":true,\"isSmartphoneFlow\":true}";
        String sampleResponseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-DOTCOM-BBP\", \"statusMsg\": \"PEGA generated message\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"sessionId\": \"\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"0\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \"SOP-1583186-DEV3\", \"customerInfo\": { \"accountNumber\": \"07893451230-00001\", \"cartCreator\": \"2515813861\",\"customerType\":\"N\", \"processingMTN\": \"newLine1\" }, \"cartInfo\": { \"cartId\": \"cff57848-8bbd-4c27-9afa-5bfd39c2b5ad\", \"statusCode\": 1, \"statusMsg\": \"SUCCESS\" } }, \"contextInfo\": { \"processAction\": \"\", \"processStep\": \"PlanSelection\", \"availablePaths\": [ { \"path\": \"PlanCategoryPage`\" } ], \"callReason\": \" SalesOrderPurchase \" } } } }";
        AddZipCodeUIRequest request = mapper.readValue(sampleRequestString, AddZipCodeUIRequest.class);
        BBPAddZipcodeResponse response = mapper.readValue(sampleResponseString, BBPAddZipcodeResponse.class);
        String redisFile = "MockRedisData.json";
        String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        CartError err=new CartError();
        err.setErrorCode("err");
        response.setErrors(Arrays.asList(err));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(cartServiceBpmHelper4.addZipcodeThroughPEGA(request)).thenReturn(Mono.just(response));

        request.getCartInfo().setIntendType("NSEBYOD");
        URI url = URI.create("http://localhost/addZipcodeThroughPega");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        Mono<ResponseEntity<GenericResponse>>  controllerResponse = cartController4.addZipcodeThroughPega(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();

    }

    @Test
    public void initBinderbyNameTest() {
        WebDataBinder binder = new WebDataBinder(null);
        cartController4.initBinderByName(binder);
        assertNotNull(binder.getDisallowedFields());
    }

    @Test
    public void validateMyLinkReferralInfoTest() {
        URI url = URI.create("http://localhost/myLink/validateMyLinkReferralInfo/nse");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url)
                .cookie(new HttpCookie(CartConstants.DIGITAL_IG_SESSION, "random"))
                .header("channelId", "VZW-DOTCOM")
                .header("mtn", "8437299178")
                .queryParam("hashKey","nse").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        httpResponse.addCookie(ResponseCookie.from(CartConstants.MYLINK_HASH_KEY, "random").build());
        MylinkReferralInfoUIRequest uiRequest = new MylinkReferralInfoUIRequest();
        MyLinkUIRequestData uiData = new MyLinkUIRequestData();
        uiData.setHashKey("test");
        uiRequest.setData(uiData);
        MylinkReferralInfoResponse mylinkReferralInfoResponse = new MylinkReferralInfoResponse();
        mylinkReferralInfoResponse.setData(new MylinkData());
        mylinkReferralInfoResponse.getData().setStatus("SUCCESS");
        when(helper.validateMyLinkReferralInfo(Mockito.any(),Mockito.any())).thenReturn(Mono.just(mylinkReferralInfoResponse));
        Mono<MylinkReferralInfoResponse> response = cartController4.validateMyLinkReferralInfo(httpHeader,httpResponse,uiRequest);
        StepVerifier.create(response).assertNext(Assert::assertNotNull).expectComplete().verify();

        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        response = cartController4.validateMyLinkReferralInfo(httpHeader,httpResponse,uiRequest);
        StepVerifier.create(response).assertNext(Assert::assertNotNull).expectComplete().verify();

        httpResponse.setStatusCode(HttpStatus.OK);
        mylinkReferralInfoResponse.getData().setStatus("FAILURE");
        when(helper.validateMyLinkReferralInfo(Mockito.any(),Mockito.any())).thenReturn(Mono.just(mylinkReferralInfoResponse));
        response = cartController4.validateMyLinkReferralInfo(httpHeader,httpResponse,uiRequest);
        StepVerifier.create(response).assertNext(Assert::assertNotNull).expectComplete().verify();

        mylinkReferralInfoResponse.setData(null);
        when(helper.validateMyLinkReferralInfo(Mockito.any(),Mockito.any())).thenReturn(Mono.just(mylinkReferralInfoResponse));
        response = cartController4.validateMyLinkReferralInfo(httpHeader,httpResponse,uiRequest);
        StepVerifier.create(response).assertNext(Assert::assertNotNull).expectComplete().verify();

        httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url)
                .cookie(new HttpCookie(CartConstants.DIGITAL_IG_SESSION, "")).build();
        response = cartController4.validateMyLinkReferralInfo(httpHeader,httpResponse,uiRequest);
        StepVerifier.create(response).assertNext(Assert::assertNotNull).expectComplete().verify();

        httpResponse.getCookies().clear();
        response = cartController4.validateMyLinkReferralInfo(httpHeader,httpResponse,uiRequest);
        StepVerifier.create(response).assertNext(Assert::assertNotNull).expectComplete().verify();

        httpResponse  = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        response = cartController4.validateMyLinkReferralInfo(httpHeader,httpResponse,uiRequest);
        StepVerifier.create(response).assertNext(Assert::assertNotNull).expectComplete().verify();

        httpResponse = null;
        response = cartController4.validateMyLinkReferralInfo(httpHeader,httpResponse,uiRequest);
        StepVerifier.create(response).assertNext(Assert::assertNotNull).expectComplete().verify();

        httpResponse  = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        uiData.setHashKey("");
        uiRequest.setData(uiData);
        response = cartController4.validateMyLinkReferralInfo(httpHeader,httpResponse,uiRequest);
        StepVerifier.create(response).assertNext(Assert::assertNotNull).expectError();
    }

    @Test
    public void addPromoIntentOfferInterstial() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/addPromoIntentOfferInterstialRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"errors\": [{}]}";;
        AddPromoIntentUIRequest request = mapper.readValue(requestString, AddPromoIntentUIRequest.class);
        AddPromoIntentUIResponse uiResponse = mapper.readValue(responseString, AddPromoIntentUIResponse.class);
        URI url = URI.create("http://localhost/addPromoIntent");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "OMNI-CARE").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        AddPromoIntentContext context = new AddPromoIntentContext();
        context.setCaseId("SOP-538499-E01");
        AddPromoIntentServiceRequest serviceRequest = new AddPromoIntentServiceRequest();
        serviceRequest.setContext(context);
        AddPromoIntentServiceBody serviceBody = new AddPromoIntentServiceBody();
        serviceBody.setServiceRequest(serviceRequest);
        AddPromoIntentUIResponse addPromoIntentUIResponse = new AddPromoIntentUIResponse();
        addPromoIntentUIResponse.setServiceBody(serviceBody);
        String requestFile2 = "data/CartUpdateOperationsControllerTestJson/addPromoIntentTaggingRequest.json";
        String requestString2 = sourceFileReaderUtil.readFile(requestFile2, testFileLocation);
        String responseString2 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.11.28.09.44.24-993.5973380891764\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-13546665-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"PopularPlans\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"NewRecommendedPlanSelection\",\"processAction\":\"\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"globalId\":\"POW-D-41073aa7-9489-409e-8c4e-fd9b8229212f\",\"noc\":false},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"539ff76b-3467-4b85-b9d0-fc9a8ccbed0e\",\"couponCode\":\"\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":23.24,\"monthlyInstallment\":23.05,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"sim\":{\"id\":\"UNIVESIM5G-SAB-D\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"OfferInterstitial\"]}]}}}}";
        AddPromoIntentUIRequest req = mapper.readValue(requestString2, AddPromoIntentUIRequest.class);
        AddPromoIntentUIResponse res = mapper.readValue(responseString2, AddPromoIntentUIResponse.class);
        ResponseEntity<Object> responseEntity =
                ResponseEntity.status(HttpStatus.OK).body(res);
        CartRedisData cartRedisData = jsonToObject("/data/cartServiceHelperTest/CartRedisData.json", CartRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(cartRedisData));
        BundleBuilderCXPResponseData bundleBuilderCXPResponseData = jsonToObject("/promobuildercxpcart_response.json", BundleBuilderCXPResponseData.class);
        when(readCartHelper.bundleBuilderCart(any())).thenReturn(Mono.just(bundleBuilderCXPResponseData));
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        when(featureFlagHelper.mergeFeatureFlagWithResponse(Mockito.any())).thenReturn(Mono.just(res));
        when(helper.addPromoIntent(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(new ErrorResponse());
        Mono<ResponseEntity<GenericResponse>> response = cartController2.addPromoIntent(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateBarcodeTest1() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/UpdateBarcodeRafRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/UpdateBarcodeRafResponse.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        UpdateBarcodeUIRequest request = mapper.readValue(requestString, UpdateBarcodeUIRequest.class);
        UpdateBarcodeUIResponse uiResponse = mapper.readValue(responseString, UpdateBarcodeUIResponse.class);
        URI url = URI.create("http://localhost/nse/updateBarcode");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.updateBarcode(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mockito.doNothing().when(cxpHelper).appendDlVZPageSubflow("raf");
        Mono<ResponseEntity<GenericResponse>> response = cartController.updateBarcode(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateBarcodeTest11() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/UpdateBarcodeNSE5GRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/UpdateBarcodeRafResponse.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        UpdateBarcodeUIRequest request = mapper.readValue(requestString, UpdateBarcodeUIRequest.class);
        UpdateBarcodeUIResponse uiResponse = mapper.readValue(responseString, UpdateBarcodeUIResponse.class);
        URI url = URI.create("http://localhost/nse/5g/updateBarcode");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.updateBarcode(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mockito.doNothing().when(cxpHelper).appendDlVZPageSubflow("raf");
        Mono<ResponseEntity<GenericResponse>> response = cartController.updateBarcode(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }
    @Test
    public void updateConflictsTest11() throws IOException {
        String requestString = "{ \"conflictsAccepted\" : true } ";
        String responseString = "{ \"status\": \"0\", \"message\": \"Success\" }";
        UpdateConflictStatusRequest request = mapper.readValue(requestString, UpdateConflictStatusRequest.class);
        UpdateDetailsToRedisResponse response = mapper.readValue(responseString, UpdateDetailsToRedisResponse.class);
        URI url = URI.create("http://localhost/updateConflictStatus");
        when(redisHelper3.updateConflictStatusToRedis(request)).thenReturn(Mono.just(response));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController4.updateConflictStatus(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> junit.framework.Assert.assertNotNull(resp)).expectComplete().verify();

    }

    @Test
    public void addPlanAndPerksToRedisTestSkippingFirstIf() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"cartCreator\":\"3029851806\",\"processingMTN\":\"3029851806\",\"processStep\":\"PlanSelection\",\"intendType\":\"AAL\"},\"data\":{\"lines\":[{\"mtn\":\"3029851806\",\"addFeatures\":[{\"id\":\"2678\",\"quantity\":\"1\",\"actionIndicator\":\"A\",\"type\":\"SPO\"}],\"removeFeatures\":[],\"plan\":{\"id\":\"69185\",\"isRecommendedPlan\":false,\"recommender\":\"\"}}],\"parentMtn\":\"\"}}";
        String responseString = "{ \"status\": \"0\", \"message\": \"Success\" }";

        AddPlanUIRequest request = mapper.readValue(requestString, AddPlanUIRequest.class);
        UpdateDetailsToRedisResponse response = mapper.readValue(responseString, UpdateDetailsToRedisResponse.class);

        URI url = URI.create("http://localhost/cart/toRedis");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").build();

//        when(CartPegaRequestErrorsUtil.handleAddPlanRequestErrors(request, httpHeader)).thenReturn(Mono.just(response));

        when(redisHelper3.addPlanAndPerksToRedis(request)).thenReturn(Mono.just(response));

        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController4.addPlanAndPerksToRedis(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> junit.framework.Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addPlanAndPerksToRedisTestInsideFirstIf() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"lines\":[{\"plan\":{\"sorId\":\"97928\"}}]}}";
        AddPlanUIRequest request = mapper.readValue(requestString, AddPlanUIRequest.class);

        URI url = URI.create("http://localhost/cart/toRedis");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").build();

        String responseString2 = "{ \"status\": \"0\", \"message\": \"Success\" }";
        UpdateDetailsToRedisResponse response2 = mapper.readValue(responseString2, UpdateDetailsToRedisResponse.class);

        //can split to 2
        when(redisHelper3.addPlanAndPerksToRedis(request)).thenReturn(Mono.just(response2));
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController4.addPlanAndPerksToRedis(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> junit.framework.Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addPlanAndPerksToRedisTestInsideSecondIf() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"lines\":[{\"plan\":{\"sorId\":\"97928\"}}]}}";
        AddPlanUIRequest request = mapper.readValue(requestString, AddPlanUIRequest.class);

        URI url = URI.create("http://localhost/cart/toRedis");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").build();

        String responseString2 = "{ \"status\": \"0\", \"message\": \"Success\" }";
        UpdateDetailsToRedisResponse response2 = mapper.readValue(responseString2, UpdateDetailsToRedisResponse.class);

        //can split to 2
        when(redisHelper3.addPlanAndPerksToRedis(request)).thenReturn(Mono.just(response2));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(new ErrorResponse());
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController4.addPlanAndPerksToRedis(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> junit.framework.Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addUpgradeDetailsTest() throws IOException{
        String requestFile = "{ \"cartInfo\": { \"cartId\": \"\", \"caseId\": \"\", \"accountNumber\": \"\", \"cartCreator\": \"\", \"processingMTN\": \"5404098746\", \"processStep\": \"GridWallPDP\", \"processAction\": \"ExpressUpgrade\", \"intendType\": \"EUP\", \"isTradeInSelected\": false, \"disableMyLink\": false, \"editDevice\": false, \"expressCheckout\": null, \"noPendingOfferExists\": false, \"isPromoPDP\": false, \"mtnFlow\": \"M\", \"myvPage\": true }, \"data\": { \"entryPoint\": \"PDP\", \"lines\": [ { \"isCommonPDP\": true, \"mtn\": \"5404098746\", \"purchasePath\": \"EUP\", \"portInNumber\": \"\", \"eupNoPromoFlow\": false, \"device\": { \"id\": \"MU6C3LL/A\", \"contractTerm\": \"VERIZON_EDGE\", \"iconicPhone\": true, \"dppMonths\": 36, \"productId\": \"dev21410696\", \"category\": \"Smartphones\", \"preconfigure\": false }, \"sim\": { \"id\": \"UNIVESIM5G-SAB-S\" }, \"ispuFlow\": false, \"estimatedReadyByDate\": \"\", \"depletionLocationCode\": \"\", \"depletionType\": \"F\", \"isKeepingExistingEqProtection\": true, \"newLineOrAAL\": false, \"isNewLine\": false, \"selectedPromoId\": \"promo3730541\", \"selectedPromoType\": \"BIC\", \"promoRejectionIndicator\": true, \"isIconicPhone\": true, \"selectedSedOfferId\": \"554871\", \"isStrategicOffer\": false, \"restricted\": \"\", \"skipPromoChoiceOffer\": false, \"isTradeInIntentSelected\": false, \"restrictedProductType\": null, \"tradeInShippingType\": \"return_store\" } ], \"rtm\": { \"url\": \"https://vzwqa2.verizonwireless.com/smartphones/apple-iphone-15-pro-max/\", \"img\": \"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-pro-max-256gb-white-titanium-mu673ll-a-a\", \"name\": \"iPhone 15 Pro Max\", \"make\": \"Apple\", \"categoryId\": \"Smartphones\", \"pageURL\": \"https://vzwqa2.verizonwireless.com/smartphones/apple-iphone-15-pro-max/\" }, \"enableFcc\": true } }";
        String responseFile = "{ \"serviceHeader\": { \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\", \"correlationId\": \"soe-cart-2024.09.16.07.48.47-416.23497932289865\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"contextInfo\": { \"availablePaths\": [ { \"path\": \"PromoHub\" } ], \"skipCheckoutCall\": false, \"unifiedNbsFlag\": false, \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"PromoHub\", \"processAction\": \"\" }, \"customerInfo\": { \"nocByod\": false, \"cartCreator\": \"5404098746\", \"processingMTN\": \"5404098746\", \"registerNumber\": 0, \"number_share_capable\": \"\", \"e911_addr_ind\": \"false\", \"existingCase\": \"\", \"noc\": false, \"myvPage\": false }, \"cartInfo\": { \"financeLimitExceeded\": \"false\", \"cartItemCount\": 1, \"statusMsg\": \"Success\", \"statusCode\": \"1\", \"lines\": [ { \"status\": 1, \"spos\": [ { \"id\": \"1958\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] } ], \"sfos\": [ { \"id\": \"86905\", \"conflict\": \"SFO dropped because of requal - ESN chg\", \"actionIndicator\": \"D\", \"displayHumWiFi\": false } ], \"firstMonthInstallment\": 39.19, \"monthlyInstallment\": 38.88, \"reasonCode\": \"PLAN_DEVICE_COMPATIBLE\", \"selectedPromoType\": \"BIC\", \"eupNoPromoFlow\": false, \"lineSubscriptionInfos\": [], \"mtn\": \"5404098746\", \"device\": { \"upgradeReasonCode\": \"EA\", \"id\": \"MU6C3LL/A\", \"installmentTerm\": \"0\", \"itemPrice\": \"1399.99\", \"finalPrice\": \"0.0\", \"discountAmount\": \"0.0\", \"qty\": 1, \"edgeUpEnabled\": false, \"numberShareEnabled\": false, \"existingDeviceName\": \"iPhone 15 Pro Max\", \"fiveGToFourGDownGrade\": false, \"byodESimPhone\": false, \"skipImei1Call\": false, \"amount\": 0.0, \"isNonVZDeviceSku\": false, \"skuId\": \"sku6004655\", \"skuDisplayName\": \" Apple iPhone 15 Pro Max 512GB in White Titanium\", \"isDfoSelected\": false }, \"sim\": { \"id\": \"UNIVESIM5G-SAB-S\" }, \"warranty\": { \"itemPrice\": \"0.0\" }, \"upgradeFee\": { \"qty\": 1, \"itemPrice\": \"35\" }, \"devicePlanCompatible\": true, \"planValidationFailed\": false, \"lineActivityType\": \"EUP\", \"currentPlanType\": \"LLP\", \"planQualifiedForPromotion\": false, \"fiveGUpSell\": false, \"is5GBoltEligible\": false, \"fiveGPlanAdded\": false, \"editSim\": false, \"lineWithSkipMDN\": false, \"inWithVerizonOpted\": false, \"protectionNotRequired\": false, \"skipPromoChoiceOffer\": false } ], \"expressCheckout\": false, \"effectiveDateDetails\": { \"suggestedBackDate\": \"\", \"suggestedFutureDate\": \"09/29/2024\", \"currentBillCycleBeginDate\": \"08/29/2024\", \"nextBillCycleBeginDate\": \"09/29/2024\", \"onDemandDate\": \"09/16/2024\", \"onDemandRangeInDays\": \"45\", \"selectedDate\": \"09/16/2024\" }, \"preAuthSuccess\": false, \"promoLossIndicator\": false, \"monthlyCreditAmount\": \"0.0\", \"agreementNumber\": \"0\", \"vztDiscountGain\": false, \"vztDiscountLoss\": false, \"discountPromoTotal\": 0.0, \"registerNumber\": 0, \"hasMixAndMatchPlan\": true, \"oneBillEnrolled\": false, \"protectionNotRequired\": false, \"fmiCheck\": false, \"isFlexV2\": false, \"isPrepaidToPostpaidMigration\": false, \"instantCreditAmount\": 0, \"ngdFlow\": false }, \"processMTNList\": [ { \"mtn\": \"5404098746\", \"completedprocessSteps\": [ \"GridWallPDP\", \"DeviceConfigurator\", \"PromoHub\", \"Initiate\", \"Initiate\", \"GridWallPDP\" ] } ] } } }, \"featureConfigurationProfileData\": { \"mdnSelectionOneClickEligibleFFlag\": { \"enabled\": false, \"found\": true, \"attributes\": { \"enabled\": [ \"false\" ] } }, \"expressUpgradeFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"enable1ClickDeviceProtectionFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"eupPromoRestructureFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"oneClkDppSummaryFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"offerFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"bauUpgradeFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"enableGiftingFeature\": [ \"true\" ], \"enableAccMemberMigration\": [ \"true\" ], \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"oneUnlimitedFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"getProductDetailsOneClickEligibleFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } } } }";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIRequest request = mapper.readValue(requestFile, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseFile, AddDeviceUIResponse.class);
        when(deviceHelper.addUpgradeDetails(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(deviceHelper.updateSubFlowForOneClickExpressUpgrade(Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("subFlow"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(helper.populateConflictedSPOsIfPresent(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(helper.populateHumWifiConflictedSFosWithCheck(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        URI url = URI.create("http://localhost/cart/addUpgradeDetails");
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalUpgradeCfgProfile()).thenReturn(Mono.just(configurationProfile));
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController4.addUpgradeDetails(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(response);}).expectComplete().verify();
    }
    @Test
    public void addUpgradeDetailsErrorTest() throws IOException{
        String requestFile = "{ \"cartInfo\": { \"cartId\": \"\", \"caseId\": \"\", \"accountNumber\": \"\", \"cartCreator\": \"\", \"processingMTN\": \"5404098746\", \"processStep\": \"GridWallPDP\", \"processAction\": \"ExpressUpgrade\", \"intendType\": \"EUP\", \"isTradeInSelected\": false, \"disableMyLink\": false, \"editDevice\": false, \"expressCheckout\": null, \"noPendingOfferExists\": false, \"isPromoPDP\": false, \"mtnFlow\": \"M\", \"myvPage\": true }, \"data\": { \"entryPoint\": \"PDP\", \"lines\": [ { \"isCommonPDP\": true, \"mtn\": \"5404098746\", \"purchasePath\": \"EUP\", \"portInNumber\": \"\", \"eupNoPromoFlow\": false, \"device\": { \"id\": \"MU6C3LL/A\", \"contractTerm\": \"VERIZON_EDGE\", \"iconicPhone\": true, \"dppMonths\": 36, \"productId\": \"dev21410696\", \"category\": \"Smartphones\", \"preconfigure\": false }, \"sim\": { \"id\": \"UNIVESIM5G-SAB-S\" }, \"ispuFlow\": false, \"estimatedReadyByDate\": \"\", \"depletionLocationCode\": \"\", \"depletionType\": \"F\", \"isKeepingExistingEqProtection\": true, \"newLineOrAAL\": false, \"isNewLine\": false, \"selectedPromoId\": \"promo3730541\", \"selectedPromoType\": \"BIC\", \"promoRejectionIndicator\": true, \"isIconicPhone\": true, \"selectedSedOfferId\": \"554871\", \"isStrategicOffer\": false, \"restricted\": \"\", \"skipPromoChoiceOffer\": false, \"isTradeInIntentSelected\": false, \"restrictedProductType\": null, \"tradeInShippingType\": \"return_store\" } ], \"rtm\": { \"url\": \"https://vzwqa2.verizonwireless.com/smartphones/apple-iphone-15-pro-max/\", \"img\": \"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-pro-max-256gb-white-titanium-mu673ll-a-a\", \"name\": \"iPhone 15 Pro Max\", \"make\": \"Apple\", \"categoryId\": \"Smartphones\", \"pageURL\": \"https://vzwqa2.verizonwireless.com/smartphones/apple-iphone-15-pro-max/\" }, \"enableFcc\": true } }";
        String responseFile = "{ \"serviceHeader\": { \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\", \"correlationId\": \"soe-cart-2024.09.16.07.48.47-416.23497932289865\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"contextInfo\": { \"availablePaths\": [ { \"path\": \"PromoHub\" } ], \"skipCheckoutCall\": false, \"unifiedNbsFlag\": false, \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"PromoHub\", \"processAction\": \"\" }, \"customerInfo\": { \"nocByod\": false, \"cartCreator\": \"5404098746\", \"processingMTN\": \"5404098746\", \"registerNumber\": 0, \"number_share_capable\": \"\", \"e911_addr_ind\": \"false\", \"existingCase\": \"\", \"noc\": false, \"myvPage\": false }, \"cartInfo\": { \"financeLimitExceeded\": \"false\", \"cartItemCount\": 1, \"statusMsg\": \"Success\", \"statusCode\": \"1\", \"lines\": [ { \"status\": 1, \"spos\": [ { \"id\": \"1958\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] } ], \"sfos\": [ { \"id\": \"86905\", \"conflict\": \"SFO dropped because of requal - ESN chg\", \"actionIndicator\": \"D\", \"displayHumWiFi\": false } ], \"firstMonthInstallment\": 39.19, \"monthlyInstallment\": 38.88, \"reasonCode\": \"PLAN_DEVICE_COMPATIBLE\", \"selectedPromoType\": \"BIC\", \"eupNoPromoFlow\": false, \"lineSubscriptionInfos\": [], \"mtn\": \"5404098746\", \"device\": { \"upgradeReasonCode\": \"EA\", \"id\": \"MU6C3LL/A\", \"installmentTerm\": \"0\", \"itemPrice\": \"1399.99\", \"finalPrice\": \"0.0\", \"discountAmount\": \"0.0\", \"qty\": 1, \"edgeUpEnabled\": false, \"numberShareEnabled\": false, \"existingDeviceName\": \"iPhone 15 Pro Max\", \"fiveGToFourGDownGrade\": false, \"byodESimPhone\": false, \"skipImei1Call\": false, \"amount\": 0.0, \"isNonVZDeviceSku\": false, \"skuId\": \"sku6004655\", \"skuDisplayName\": \" Apple iPhone 15 Pro Max 512GB in White Titanium\", \"isDfoSelected\": false }, \"sim\": { \"id\": \"UNIVESIM5G-SAB-S\" }, \"warranty\": { \"itemPrice\": \"0.0\" }, \"upgradeFee\": { \"qty\": 1, \"itemPrice\": \"35\" }, \"devicePlanCompatible\": true, \"planValidationFailed\": false, \"lineActivityType\": \"EUP\", \"currentPlanType\": \"LLP\", \"planQualifiedForPromotion\": false, \"fiveGUpSell\": false, \"is5GBoltEligible\": false, \"fiveGPlanAdded\": false, \"editSim\": false, \"lineWithSkipMDN\": false, \"inWithVerizonOpted\": false, \"protectionNotRequired\": false, \"skipPromoChoiceOffer\": false } ], \"expressCheckout\": false, \"effectiveDateDetails\": { \"suggestedBackDate\": \"\", \"suggestedFutureDate\": \"09/29/2024\", \"currentBillCycleBeginDate\": \"08/29/2024\", \"nextBillCycleBeginDate\": \"09/29/2024\", \"onDemandDate\": \"09/16/2024\", \"onDemandRangeInDays\": \"45\", \"selectedDate\": \"09/16/2024\" }, \"preAuthSuccess\": false, \"promoLossIndicator\": false, \"monthlyCreditAmount\": \"0.0\", \"agreementNumber\": \"0\", \"vztDiscountGain\": false, \"vztDiscountLoss\": false, \"discountPromoTotal\": 0.0, \"registerNumber\": 0, \"hasMixAndMatchPlan\": true, \"oneBillEnrolled\": false, \"protectionNotRequired\": false, \"fmiCheck\": false, \"isFlexV2\": false, \"isPrepaidToPostpaidMigration\": false, \"instantCreditAmount\": 0, \"ngdFlow\": false }, \"processMTNList\": [ { \"mtn\": \"5404098746\", \"completedprocessSteps\": [ \"GridWallPDP\", \"DeviceConfigurator\", \"PromoHub\", \"Initiate\", \"Initiate\", \"GridWallPDP\" ] } ] } } }, \"featureConfigurationProfileData\": { \"mdnSelectionOneClickEligibleFFlag\": { \"enabled\": false, \"found\": true, \"attributes\": { \"enabled\": [ \"false\" ] } }, \"expressUpgradeFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"enable1ClickDeviceProtectionFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"eupPromoRestructureFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"oneClkDppSummaryFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"offerFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"bauUpgradeFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"enableGiftingFeature\": [ \"true\" ], \"enableAccMemberMigration\": [ \"true\" ], \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"oneUnlimitedFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"getProductDetailsOneClickEligibleFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } } } }";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIRequest request = mapper.readValue(requestFile, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseFile, AddDeviceUIResponse.class);
        CartError err=new CartError();
        err.setErrorCode("err");
        response.setErrors(Arrays.asList(err));
        when(deviceHelper.addUpgradeDetails(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(deviceHelper.updateSubFlowForOneClickExpressUpgrade(Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("subFlow"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(helper.populateConflictedSPOsIfPresent(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(helper.populateHumWifiConflictedSFosWithCheck(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        URI url = URI.create("http://localhost/cart/addUpgradeDetails");
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalUpgradeCfgProfile()).thenReturn(Mono.just(configurationProfile));
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController4.addUpgradeDetails(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(response);}).expectComplete().verify();
    }

    @Test
    public void addUpgradeDetailsErrorTest1() throws IOException{
        String requestFile = "{ \"cartInfo\": { \"cartId\": \"\", \"caseId\": \"\", \"accountNumber\": \"\", \"cartCreator\": \"\", \"processingMTN\": \"5404098746\", \"processStep\": \"GridWallPDP\", \"processAction\": \"\", \"intendType\": \"EUP\", \"isTradeInSelected\": false, \"disableMyLink\": false, \"editDevice\": false, \"expressCheckout\": null, \"noPendingOfferExists\": false, \"isPromoPDP\": false, \"mtnFlow\": \"M\", \"myvPage\": true }, \"data\": { \"entryPoint\": \"PDP\", \"lines\": [ { \"isCommonPDP\": true, \"mtn\": \"5404098746\", \"purchasePath\": \"EUP\", \"portInNumber\": \"\", \"eupNoPromoFlow\": false, \"device\": { \"id\": \"MU6C3LL/A\", \"contractTerm\": \"VERIZON_EDGE\", \"iconicPhone\": true, \"dppMonths\": 36, \"productId\": \"dev21410696\", \"category\": \"Smartphones\", \"preconfigure\": false }, \"sim\": { \"id\": \"UNIVESIM5G-SAB-S\" }, \"ispuFlow\": false, \"estimatedReadyByDate\": \"\", \"depletionLocationCode\": \"\", \"depletionType\": \"F\", \"isKeepingExistingEqProtection\": true, \"newLineOrAAL\": false, \"isNewLine\": false, \"selectedPromoId\": \"promo3730541\", \"selectedPromoType\": \"BIC\", \"promoRejectionIndicator\": true, \"isIconicPhone\": true, \"selectedSedOfferId\": \"554871\", \"isStrategicOffer\": false, \"restricted\": \"\", \"skipPromoChoiceOffer\": false, \"isTradeInIntentSelected\": false, \"restrictedProductType\": null, \"tradeInShippingType\": \"return_store\" } ], \"rtm\": { \"url\": \"https://vzwqa2.verizonwireless.com/smartphones/apple-iphone-15-pro-max/\", \"img\": \"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-pro-max-256gb-white-titanium-mu673ll-a-a\", \"name\": \"iPhone 15 Pro Max\", \"make\": \"Apple\", \"categoryId\": \"Smartphones\", \"pageURL\": \"https://vzwqa2.verizonwireless.com/smartphones/apple-iphone-15-pro-max/\" }, \"enableFcc\": true } }";
        String responseFile = "{ \"serviceHeader\": { \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\", \"correlationId\": \"soe-cart-2024.09.16.07.48.47-416.23497932289865\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"contextInfo\": { \"availablePaths\": [ { \"path\": \"PromoHub\" } ], \"skipCheckoutCall\": false, \"unifiedNbsFlag\": false, \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"PromoHub\", \"processAction\": \"\" }, \"customerInfo\": { \"nocByod\": false, \"cartCreator\": \"5404098746\", \"processingMTN\": \"5404098746\", \"registerNumber\": 0, \"number_share_capable\": \"\", \"e911_addr_ind\": \"false\", \"existingCase\": \"\", \"noc\": false, \"myvPage\": false }, \"cartInfo\": { \"financeLimitExceeded\": \"false\", \"cartItemCount\": 1, \"statusMsg\": \"Success\", \"statusCode\": \"1\", \"lines\": [ { \"status\": 1, \"spos\": [ { \"id\": \"1958\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] } ], \"sfos\": [ { \"id\": \"86905\", \"conflict\": \"SFO dropped because of requal - ESN chg\", \"actionIndicator\": \"D\", \"displayHumWiFi\": false } ], \"firstMonthInstallment\": 39.19, \"monthlyInstallment\": 38.88, \"reasonCode\": \"PLAN_DEVICE_COMPATIBLE\", \"selectedPromoType\": \"BIC\", \"eupNoPromoFlow\": false, \"lineSubscriptionInfos\": [], \"mtn\": \"5404098746\", \"device\": { \"upgradeReasonCode\": \"EA\", \"id\": \"MU6C3LL/A\", \"installmentTerm\": \"0\", \"itemPrice\": \"1399.99\", \"finalPrice\": \"0.0\", \"discountAmount\": \"0.0\", \"qty\": 1, \"edgeUpEnabled\": false, \"numberShareEnabled\": false, \"existingDeviceName\": \"iPhone 15 Pro Max\", \"fiveGToFourGDownGrade\": false, \"byodESimPhone\": false, \"skipImei1Call\": false, \"amount\": 0.0, \"isNonVZDeviceSku\": false, \"skuId\": \"sku6004655\", \"skuDisplayName\": \" Apple iPhone 15 Pro Max 512GB in White Titanium\", \"isDfoSelected\": false }, \"sim\": { \"id\": \"UNIVESIM5G-SAB-S\" }, \"warranty\": { \"itemPrice\": \"0.0\" }, \"upgradeFee\": { \"qty\": 1, \"itemPrice\": \"35\" }, \"devicePlanCompatible\": true, \"planValidationFailed\": false, \"lineActivityType\": \"EUP\", \"currentPlanType\": \"LLP\", \"planQualifiedForPromotion\": false, \"fiveGUpSell\": false, \"is5GBoltEligible\": false, \"fiveGPlanAdded\": false, \"editSim\": false, \"lineWithSkipMDN\": false, \"inWithVerizonOpted\": false, \"protectionNotRequired\": false, \"skipPromoChoiceOffer\": false } ], \"expressCheckout\": false, \"effectiveDateDetails\": { \"suggestedBackDate\": \"\", \"suggestedFutureDate\": \"09/29/2024\", \"currentBillCycleBeginDate\": \"08/29/2024\", \"nextBillCycleBeginDate\": \"09/29/2024\", \"onDemandDate\": \"09/16/2024\", \"onDemandRangeInDays\": \"45\", \"selectedDate\": \"09/16/2024\" }, \"preAuthSuccess\": false, \"promoLossIndicator\": false, \"monthlyCreditAmount\": \"0.0\", \"agreementNumber\": \"0\", \"vztDiscountGain\": false, \"vztDiscountLoss\": false, \"discountPromoTotal\": 0.0, \"registerNumber\": 0, \"hasMixAndMatchPlan\": true, \"oneBillEnrolled\": false, \"protectionNotRequired\": false, \"fmiCheck\": false, \"isFlexV2\": false, \"isPrepaidToPostpaidMigration\": false, \"instantCreditAmount\": 0, \"ngdFlow\": false }, \"processMTNList\": [ { \"mtn\": \"5404098746\", \"completedprocessSteps\": [ \"GridWallPDP\", \"DeviceConfigurator\", \"PromoHub\", \"Initiate\", \"Initiate\", \"GridWallPDP\" ] } ] } } }, \"featureConfigurationProfileData\": { \"mdnSelectionOneClickEligibleFFlag\": { \"enabled\": false, \"found\": true, \"attributes\": { \"enabled\": [ \"false\" ] } }, \"expressUpgradeFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"enable1ClickDeviceProtectionFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"eupPromoRestructureFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"oneClkDppSummaryFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"offerFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"bauUpgradeFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"enableGiftingFeature\": [ \"true\" ], \"enableAccMemberMigration\": [ \"true\" ], \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"oneUnlimitedFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"getProductDetailsOneClickEligibleFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } } } }";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIRequest request = mapper.readValue(requestFile, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseFile, AddDeviceUIResponse.class);
        CartError err=new CartError();
        err.setErrorCode("err");
        response.setErrors(Arrays.asList(err));
        when(deviceHelper.addUpgradeDetails(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        URI url = URI.create("http://localhost/cart/addUpgradeDetails");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController4.addUpgradeDetails(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(response);}).expectComplete().verify();

        request.getCartInfo().setProcessAction("dummy");
        controllerResponse = cartController4.addUpgradeDetails(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(response);}).expectComplete().verify();
    }

    @Test
    public void addUpgradeDetailsTest2() throws IOException{
        String requestFile = "{ \"cartInfo\": { \"cartId\": \"\", \"caseId\": \"\", \"accountNumber\": \"\", \"cartCreator\": \"\", \"processingMTN\": \"5404098746\", \"processStep\": \"GridWallPDP\", \"processAction\": \"ExpressUpgrade\", \"intendType\": \"EUP\", \"isTradeInSelected\": false, \"disableMyLink\": false, \"editDevice\": false, \"expressCheckout\": null, \"noPendingOfferExists\": false, \"isPromoPDP\": false, \"mtnFlow\": \"M\", \"myvPage\": true }, \"data\": { \"entryPoint\": \"PDP\", \"lines\": [ { \"isCommonPDP\": true, \"mtn\": \"5404098746\", \"purchasePath\": \"EUP\", \"portInNumber\": \"\", \"eupNoPromoFlow\": false, \"device\": { \"id\": \"MU6C3LL/A\", \"contractTerm\": \"VERIZON_EDGE\", \"iconicPhone\": true, \"dppMonths\": 36, \"productId\": \"dev21410696\", \"category\": \"Smartphones\", \"preconfigure\": false }, \"sim\": { \"id\": \"UNIVESIM5G-SAB-S\" }, \"ispuFlow\": false, \"estimatedReadyByDate\": \"\", \"depletionLocationCode\": \"\", \"depletionType\": \"F\", \"isKeepingExistingEqProtection\": true, \"newLineOrAAL\": false, \"isNewLine\": false, \"selectedPromoId\": \"promo3730541\", \"selectedPromoType\": \"BIC\", \"promoRejectionIndicator\": true, \"isIconicPhone\": true, \"selectedSedOfferId\": \"554871\", \"isStrategicOffer\": false, \"restricted\": \"\", \"skipPromoChoiceOffer\": false, \"isTradeInIntentSelected\": false, \"restrictedProductType\": null, \"tradeInShippingType\": \"return_store\" } ], \"rtm\": { \"url\": \"https://vzwqa2.verizonwireless.com/smartphones/apple-iphone-15-pro-max/\", \"img\": \"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-pro-max-256gb-white-titanium-mu673ll-a-a\", \"name\": \"iPhone 15 Pro Max\", \"make\": \"Apple\", \"categoryId\": \"Smartphones\", \"pageURL\": \"https://vzwqa2.verizonwireless.com/smartphones/apple-iphone-15-pro-max/\" }, \"enableFcc\": true } }";
        String responseFile = "{ \"serviceHeader\": { \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\", \"correlationId\": \"soe-cart-2024.09.16.07.48.47-416.23497932289865\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"contextInfo\": { \"availablePaths\": [ { \"path\": \"PromoHub\" } ], \"skipCheckoutCall\": false, \"unifiedNbsFlag\": false, \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"PromoHub\", \"processAction\": \"\" }, \"customerInfo\": { \"nocByod\": false, \"cartCreator\": \"5404098746\", \"processingMTN\": \"5404098746\", \"registerNumber\": 0, \"number_share_capable\": \"\", \"e911_addr_ind\": \"false\", \"existingCase\": \"\", \"noc\": false, \"myvPage\": false }, \"cartInfo\": { \"financeLimitExceeded\": \"false\", \"cartItemCount\": 1, \"statusMsg\": \"Success\", \"statusCode\": \"1\", \"lines\": [ { \"status\": 1, \"spos\": [ { \"id\": \"1958\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] } ], \"sfos\": [ { \"id\": \"86905\", \"conflict\": \"SFO dropped because of requal - ESN chg\", \"actionIndicator\": \"D\", \"displayHumWiFi\": false } ], \"firstMonthInstallment\": 39.19, \"monthlyInstallment\": 38.88, \"reasonCode\": \"PLAN_DEVICE_COMPATIBLE\", \"selectedPromoType\": \"BIC\", \"eupNoPromoFlow\": false, \"lineSubscriptionInfos\": [], \"mtn\": \"5404098746\", \"device\": { \"upgradeReasonCode\": \"EA\", \"id\": \"MU6C3LL/A\", \"installmentTerm\": \"0\", \"itemPrice\": \"1399.99\", \"finalPrice\": \"0.0\", \"discountAmount\": \"0.0\", \"qty\": 1, \"edgeUpEnabled\": false, \"numberShareEnabled\": false, \"existingDeviceName\": \"iPhone 15 Pro Max\", \"fiveGToFourGDownGrade\": false, \"byodESimPhone\": false, \"skipImei1Call\": false, \"amount\": 0.0, \"isNonVZDeviceSku\": false, \"skuId\": \"sku6004655\", \"skuDisplayName\": \" Apple iPhone 15 Pro Max 512GB in White Titanium\", \"isDfoSelected\": false }, \"sim\": { \"id\": \"UNIVESIM5G-SAB-S\" }, \"warranty\": { \"itemPrice\": \"0.0\" }, \"upgradeFee\": { \"qty\": 1, \"itemPrice\": \"35\" }, \"devicePlanCompatible\": true, \"planValidationFailed\": false, \"lineActivityType\": \"EUP\", \"currentPlanType\": \"LLP\", \"planQualifiedForPromotion\": false, \"fiveGUpSell\": false, \"is5GBoltEligible\": false, \"fiveGPlanAdded\": false, \"editSim\": false, \"lineWithSkipMDN\": false, \"inWithVerizonOpted\": false, \"protectionNotRequired\": false, \"skipPromoChoiceOffer\": false } ], \"expressCheckout\": false, \"effectiveDateDetails\": { \"suggestedBackDate\": \"\", \"suggestedFutureDate\": \"09/29/2024\", \"currentBillCycleBeginDate\": \"08/29/2024\", \"nextBillCycleBeginDate\": \"09/29/2024\", \"onDemandDate\": \"09/16/2024\", \"onDemandRangeInDays\": \"45\", \"selectedDate\": \"09/16/2024\" }, \"preAuthSuccess\": false, \"promoLossIndicator\": false, \"monthlyCreditAmount\": \"0.0\", \"agreementNumber\": \"0\", \"vztDiscountGain\": false, \"vztDiscountLoss\": false, \"discountPromoTotal\": 0.0, \"registerNumber\": 0, \"hasMixAndMatchPlan\": true, \"oneBillEnrolled\": false, \"protectionNotRequired\": false, \"fmiCheck\": false, \"isFlexV2\": false, \"isPrepaidToPostpaidMigration\": false, \"instantCreditAmount\": 0, \"ngdFlow\": false }, \"processMTNList\": [ { \"mtn\": \"5404098746\", \"completedprocessSteps\": [ \"GridWallPDP\", \"DeviceConfigurator\", \"PromoHub\", \"Initiate\", \"Initiate\", \"GridWallPDP\" ] } ] } } }, \"featureConfigurationProfileData\": { \"mdnSelectionOneClickEligibleFFlag\": { \"enabled\": false, \"found\": true, \"attributes\": { \"enabled\": [ \"false\" ] } }, \"expressUpgradeFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"enable1ClickDeviceProtectionFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"eupPromoRestructureFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"oneClkDppSummaryFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"offerFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"bauUpgradeFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"enableGiftingFeature\": [ \"true\" ], \"enableAccMemberMigration\": [ \"true\" ], \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"oneUnlimitedFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"getProductDetailsOneClickEligibleFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } } } }";
        AddDeviceUIRequest request = mapper.readValue(requestFile, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseFile, AddDeviceUIResponse.class);
        when(deviceHelper.addUpgradeDetails(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(deviceHelper.updateSubFlowForOneClickExpressUpgrade(Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("subFlow"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(helper.populateConflictedSPOsIfPresent(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(helper.populateHumWifiConflictedSFosWithCheck(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        URI url = URI.create("http://localhost/cart/addUpgradeDetails");
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalUpgradeCfgProfile()).thenReturn(Mono.just(configurationProfile));
        ServerHttpRequest httpRequest1 = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController4.addUpgradeDetails(httpRequest1,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(response);}).expectComplete().verify();
    }

    @Test
    public void addUpgradeDetailsIsTradeInIntentSelectedFalseTest() throws IOException{
        String requestFile = "{ \"cartInfo\": { \"cartId\": \"\", \"caseId\": \"\", \"accountNumber\": \"\", \"cartCreator\": \"\", \"processingMTN\": \"5404098746\", \"processStep\": \"GridWallPDP\", \"processAction\": \"ExpressUpgrade\", \"intendType\": \"EUP\", \"isTradeInSelected\": false, \"disableMyLink\": false, \"editDevice\": false, \"expressCheckout\": null, \"noPendingOfferExists\": false, \"isPromoPDP\": false, \"mtnFlow\": \"M\", \"myvPage\": true }, \"data\": { \"entryPoint\": \"PDP\", \"lines\": [ { \"isCommonPDP\": true, \"mtn\": \"5404098746\", \"purchasePath\": \"EUP\", \"portInNumber\": \"\", \"eupNoPromoFlow\": false, \"device\": { \"id\": \"MU6C3LL/A\", \"contractTerm\": \"VERIZON_EDGE\", \"iconicPhone\": true, \"dppMonths\": 36, \"productId\": \"dev21410696\", \"category\": \"Smartphones\", \"preconfigure\": false }, \"sim\": { \"id\": \"UNIVESIM5G-SAB-S\" }, \"ispuFlow\": false, \"estimatedReadyByDate\": \"\", \"depletionLocationCode\": \"\", \"depletionType\": \"F\", \"isKeepingExistingEqProtection\": true, \"newLineOrAAL\": false, \"isNewLine\": false, \"selectedPromoId\": \"promo3730541\", \"selectedPromoType\": \"BIC\", \"promoRejectionIndicator\": true, \"isIconicPhone\": true, \"selectedSedOfferId\": \"554871\", \"isStrategicOffer\": false, \"restricted\": \"\", \"skipPromoChoiceOffer\": false, \"isTradeInIntentSelected\": false, \"restrictedProductType\": null, \"tradeInShippingType\": \"return_store\" } ], \"rtm\": { \"url\": \"https://vzwqa2.verizonwireless.com/smartphones/apple-iphone-15-pro-max/\", \"img\": \"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-pro-max-256gb-white-titanium-mu673ll-a-a\", \"name\": \"iPhone 15 Pro Max\", \"make\": \"Apple\", \"categoryId\": \"Smartphones\", \"pageURL\": \"https://vzwqa2.verizonwireless.com/smartphones/apple-iphone-15-pro-max/\" }, \"enableFcc\": true } }";
        String responseFile = "{ \"serviceHeader\": { \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\", \"correlationId\": \"soe-cart-2024.09.16.07.48.47-416.23497932289865\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"contextInfo\": { \"availablePaths\": [ { \"path\": \"PromoHub\" } ], \"skipCheckoutCall\": false, \"unifiedNbsFlag\": false, \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"PromoHub\", \"processAction\": \"\" }, \"customerInfo\": { \"nocByod\": false, \"cartCreator\": \"5404098746\", \"processingMTN\": \"5404098746\", \"registerNumber\": 0, \"number_share_capable\": \"\", \"e911_addr_ind\": \"false\", \"existingCase\": \"\", \"noc\": false, \"myvPage\": false }, \"cartInfo\": { \"financeLimitExceeded\": \"false\", \"cartItemCount\": 1, \"statusMsg\": \"Success\", \"statusCode\": \"1\", \"lines\": [ { \"status\": 1, \"spos\": [ { \"id\": \"1958\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] } ], \"sfos\": [ { \"id\": \"86905\", \"conflict\": \"SFO dropped because of requal - ESN chg\", \"actionIndicator\": \"D\", \"displayHumWiFi\": false } ], \"firstMonthInstallment\": 39.19, \"monthlyInstallment\": 38.88, \"reasonCode\": \"PLAN_DEVICE_COMPATIBLE\", \"selectedPromoType\": \"BIC\", \"eupNoPromoFlow\": false, \"lineSubscriptionInfos\": [], \"mtn\": \"5404098746\", \"device\": { \"upgradeReasonCode\": \"EA\", \"id\": \"MU6C3LL/A\", \"installmentTerm\": \"0\", \"itemPrice\": \"1399.99\", \"finalPrice\": \"0.0\", \"discountAmount\": \"0.0\", \"qty\": 1, \"edgeUpEnabled\": false, \"numberShareEnabled\": false, \"existingDeviceName\": \"iPhone 15 Pro Max\", \"fiveGToFourGDownGrade\": false, \"byodESimPhone\": false, \"skipImei1Call\": false, \"amount\": 0.0, \"isNonVZDeviceSku\": false, \"skuId\": \"sku6004655\", \"skuDisplayName\": \" Apple iPhone 15 Pro Max 512GB in White Titanium\", \"isDfoSelected\": false }, \"sim\": { \"id\": \"UNIVESIM5G-SAB-S\" }, \"warranty\": { \"itemPrice\": \"0.0\" }, \"upgradeFee\": { \"qty\": 1, \"itemPrice\": \"35\" }, \"devicePlanCompatible\": true, \"planValidationFailed\": false, \"lineActivityType\": \"EUP\", \"currentPlanType\": \"LLP\", \"planQualifiedForPromotion\": false, \"fiveGUpSell\": false, \"is5GBoltEligible\": false, \"fiveGPlanAdded\": false, \"editSim\": false, \"lineWithSkipMDN\": false, \"inWithVerizonOpted\": false, \"protectionNotRequired\": false, \"skipPromoChoiceOffer\": false } ], \"expressCheckout\": false, \"effectiveDateDetails\": { \"suggestedBackDate\": \"\", \"suggestedFutureDate\": \"09/29/2024\", \"currentBillCycleBeginDate\": \"08/29/2024\", \"nextBillCycleBeginDate\": \"09/29/2024\", \"onDemandDate\": \"09/16/2024\", \"onDemandRangeInDays\": \"45\", \"selectedDate\": \"09/16/2024\" }, \"preAuthSuccess\": false, \"promoLossIndicator\": false, \"monthlyCreditAmount\": \"0.0\", \"agreementNumber\": \"0\", \"vztDiscountGain\": false, \"vztDiscountLoss\": false, \"discountPromoTotal\": 0.0, \"registerNumber\": 0, \"hasMixAndMatchPlan\": true, \"oneBillEnrolled\": false, \"protectionNotRequired\": false, \"fmiCheck\": false, \"isFlexV2\": false, \"isPrepaidToPostpaidMigration\": false, \"instantCreditAmount\": 0, \"ngdFlow\": false }, \"processMTNList\": [ { \"mtn\": \"5404098746\", \"completedprocessSteps\": [ \"GridWallPDP\", \"DeviceConfigurator\", \"PromoHub\", \"Initiate\", \"Initiate\", \"GridWallPDP\" ] } ] } } }, \"featureConfigurationProfileData\": { \"mdnSelectionOneClickEligibleFFlag\": { \"enabled\": false, \"found\": true, \"attributes\": { \"enabled\": [ \"false\" ] } }, \"expressUpgradeFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"enable1ClickDeviceProtectionFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"eupPromoRestructureFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"oneClkDppSummaryFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"offerFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"bauUpgradeFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"enableGiftingFeature\": [ \"true\" ], \"enableAccMemberMigration\": [ \"true\" ], \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"oneUnlimitedFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"getProductDetailsOneClickEligibleFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } } } }";
        AddDeviceUIRequest request = mapper.readValue(requestFile, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseFile, AddDeviceUIResponse.class);
        if(request.getData()!= null && request.getData().getLines() != null && CollectionUtilities.isNotEmptyOrNull(request.getData().getLines())){
            request.getData().getLines().forEach( line -> {
                line.setIsTradeInIntentSelected(false);
            });
        }
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        when(deviceHelper.addUpgradeDetails(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(deviceHelper.updateSubFlowForOneClickExpressUpgrade(Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("subFlow"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(helper.populateConflictedSPOsIfPresent(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(helper.populateHumWifiConflictedSFosWithCheck(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        URI url = URI.create("http://localhost/cart/addUpgradeDetails");
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalUpgradeCfgProfile()).thenReturn(Mono.just(configurationProfile));
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController4.addUpgradeDetails(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(response);}).expectComplete().verify();
    }

    @Test
    public void updateAccountOwnerTest() throws IOException{
        URI url = URI.create("http://localhost/cart/update-account-owner");
        String sampleRequestString = "{\"cartInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"\",\"creditAppNum\":\"273033334\",\"cartId\":\"68a86ce0-a5fa-4b69-b6c4-8f862927c11b\",\"caseId\":\"SOP-15191726-C01\",\"processingMTN\":\"\",\"processStep\":\"InterimPage\",\"intendType\":\"NSE\"},\"data\":{\"lines\":[{\"mtn\":\"4703562771\",\"accountOwner\":\"4703562771\"},{\"mtn\":\"4703568065\"}]}}";
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-INDIRECT\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2024.04.08.18.26.01-600.8767454861346\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-15191726-C01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"ShoppingCart\"}]},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"273033334\",\"processingMTN\":\"\",\"registerNumber\":0,\"originalCreditApprovalNumber\":\"273033334\"},\"cartInfo\":{\"cartId\":\"\",\"statusMsg\":\"SUCCESS\",\"statusCode\":1},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"InterimPage\"]}]}}}}";
        UpdateAccountOwnerUIRequest request = mapper.readValue(sampleRequestString, UpdateAccountOwnerUIRequest.class);
        UpdateAccountOwnerPEGAResponse response = mapper.readValue(sampleResponseString, UpdateAccountOwnerPEGAResponse.class);
        when(cartServiceBpmHelper4.updateAccountOwner(request,"OMNI-INDIRECT")).thenReturn(Mono.just(response));
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-INDIRECT").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<UpdateAccountOwnerPEGAResponse>  controllerResponse = cartController4.updateAccountOwner(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();
    }
    @Test
    public void processStepCodeCoverageTest() {
        HttpStatus notFound = cartController4.processHttpStatusForPega(HttpStatus.NOT_FOUND);
        Assert.assertNotNull(notFound);
        HttpStatus httpStatus = cartController4.processHttpStatusForPega(HttpStatus.OK);
        Assert.assertNotNull(httpStatus);
    }
    
    @Test
    public void getCookieValuesCodeCoverageTest() {
        var httpRequest = MockServerHttpRequest.method(HttpMethod.POST, "localhost")
                .header("channelId", CartConstants.VZW_DOTCOM)
                .header("mtn", "8437299178")
                .cookies(addValues())
                .build();
        var addDeviceRequest = new AddDeviceUIRequest();
        addDeviceRequest.setCartInfo(new DeviceCartInfo());
        cartController4.getCookieValues(httpRequest,new CreateLineUIRequest(), addDeviceRequest);
        Assertions.assertThat(addDeviceRequest.getCartInfo().getReferralVendorId())
                .isNotBlank().isEqualTo("VENDOR_TEST");
    }
    @Test
    public void getTaxDetailsForConfiguratorTest() throws IOException, ExecutionException, InterruptedException {
        NGDTaxEngineRequest ngdTaxEngineRequest = JacksonMapperFactory.defaultReader().readValue("{\"calculateTaxDetailsRequest\":{\"taxLines\":[{\"zipcode\":\"07083\",\"multiLineSeqNumber\":\"1\",\"itemsForTax\":[{\"itemSeq\":\"0\",\"itemCode\":\"MTM43LL/A\",\"groupId\":\"0000\",\"itemId\":\"000\",\"itemTypeInd\":\"D\",\"itemPrice\":\"929.99\",\"unitTaxBasedPrice\":\"929.99\",\"qty\":\"1\",\"discountAmount\":\"0.0\",\"mldSequenceNum\":\"1\"}]}]}}", NGDTaxEngineRequest.class);
        when(deviceHelper.callTaxEngine(any(),any())).thenReturn(Mono.just(mapper.readValue("{\"orderTotalTax\":\"6161\",\"lineTaxDetails\":[{\"multiLineSeqNo\":\"1\",\"totalPriceForTax\":\"92999\",\"taxGrandTotal\":\"6161\",\"taxPerItem\":[{\"itemSeqNo\":\"0\",\"sku\":\"MTM43LL/A\",\"taxAmount\":\"6161\"}]}]}",NGDTaxEngineResponseData.class)));
        when(cxpService.retrieveFipsCode(any())).thenReturn(Mono.just(mapper.readValue("{\"data\":{\"retrieveFipsCodeByZipCode\":{\"response\":{\"fipsCode\":\"3403500000\"}}}}", RetrieveFipsCode.class)));
        Mono<NGDTaxEngineResponseData> responseMono = cartController4.getTaxDetailsForConfigurator(ngdTaxEngineRequest);
        StepVerifier.create(responseMono).assertNext(Assert::assertNotNull).verifyComplete();

    }

    @Test
    public void getTaxDetailsForConfigurator2Test() throws IOException, ExecutionException, InterruptedException {
        NGDTaxEngineRequest ngdTaxEngineRequest = JacksonMapperFactory.defaultReader().readValue("{\"calculateTaxDetailsRequest\":{\"taxLines\":[{\"zipcode\":\"07083\",\"multiLineSeqNumber\":\"1\",\"itemsForTax\":[{\"itemSeq\":\"0\",\"itemCode\":\"MTM43LL/A\",\"groupId\":\"0000\",\"itemId\":\"000\",\"itemTypeInd\":\"D\",\"itemPrice\":\"929.99\",\"unitTaxBasedPrice\":\"929.99\",\"qty\":\"1\",\"discountAmount\":\"0.0\",\"mldSequenceNum\":\"1\"}]}]}}", NGDTaxEngineRequest.class);
        when(deviceHelper.callTaxEngine(any(),any())).thenReturn(Mono.just(mapper.readValue("{\"orderTotalTax\":\"6161\",\"lineTaxDetails\":[{\"multiLineSeqNo\":\"1\",\"totalPriceForTax\":\"92999\",\"taxGrandTotal\":\"6161\",\"taxPerItem\":[{\"itemSeqNo\":\"0\",\"sku\":\"MTM43LL/A\",\"taxAmount\":\"6161\"}]}]}",NGDTaxEngineResponseData.class)));
        when(cxpService.retrieveFipsCode(any())).thenReturn(Mono.just(mapper.readValue("{\"data\":{\"retrieveFipsCodeByZipCode\":{\"response\":{\"fipsCode\":\"3403500000\"}}}}", RetrieveFipsCode.class)));
        Optional.of(ngdTaxEngineRequest).map(NGDTaxEngineRequest::getCalculateTaxDetailsRequest).map(NGDCalculateTaxDetailsRequest::getTaxLines)
                .filter(CollectionUtilities::isNotEmptyOrNull).ifPresent(taxLines -> taxLines.forEach(taxLine -> taxLine.setZipcode("ADFs")));
        Mono<NGDTaxEngineResponseData> responseMono2 = cartController4.getTaxDetailsForConfigurator(ngdTaxEngineRequest);
        StepVerifier.create(responseMono2).assertNext(Assert::assertNotNull).verifyComplete();
    }

    private MultiValueMap<String, HttpCookie> addValues() {
        MultiValueMap<String, HttpCookie> map = new LinkedMultiValueMap<>();
        map.add(CartConstants.COOKIE_ECPD_TOKEN, new HttpCookie(CartConstants.COOKIE_ECPD_TOKEN, "w77833:23788323:32798734:2378763"));
        map.add(CartConstants.COOKIE_ECPD_DOMAIN, new HttpCookie(CartConstants.COOKIE_ECPD_DOMAIN, "ECP_DOMAINTEST"));
        map.add(CartConstants.COOKIE_SALESREPID, new HttpCookie(CartConstants.COOKIE_SALESREPID, "SALES_TEST"));
        map.add(CartConstants.COOKIE_REFERRAL_VENDOR, new HttpCookie(CartConstants.COOKIE_REFERRAL_VENDOR, "VENDOR_TEST"));
        map.add(CartConstants.COOKIE_TARGET_PRICING_OFFER, new HttpCookie(CartConstants.COOKIE_TARGET_PRICING_OFFER, "PRICE_OFFER_TEST"));
        return map;
    }

    @Test
    public void ngdDeleteCartTest() throws IOException {
        String requestString = "{\"channelId\": \"VZW-DOTCOM\",\"ngdFlow\": true,\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"Configurator\",\"intendType\":\"NSE\"}}";
        String responseString = "{\"serviceBody\":{\"serviceResponse\":{\"context\":{\"cartInfo\":{\"cartItemCount\":0,\"couponCode\":\"\",\"discountPromoTotal\":0,\"fmiCheck\":false,\"instantCreditAmount\":0,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false,\"protectionNotRequired\":false,\"registerNumber\":0,\"statusCode\":\"1\",\"statusMsg\":\"cart cleared successfully!\"},\"contextInfo\":{\"availablePaths\":[],\"callReason\":\"SalesOrderPurchase\",\"processAction\":\"\",\"processStep\":\"PromoHub\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POW-D-a4374a66-327a-49db-8889-0583f3e260e8\",\"customerType\":\"N\",\"globalId\":\"POW-D-a4374a66-327a-49db-8889-0583f3e260e8\",\"myvPage\":false,\"noc\":false,\"nocByod\":false,\"processingMTN\":\"newLine1\",\"registerNumber\":0}}}},\"serviceHeader\":{\"correlationId\":\"soe-cart-2024.07.03.03.06.45-644.8149291665973\",\"serviceName\":\"SalesOrderPurchase\",\"sessionId\":\"\",\"statusCode\":\"00\",\"statusMsg\":\"SUCCESS\",\"userId\":\"\"}}";
        DeleteCartUIRequest request = mapper.readValue(requestString, DeleteCartUIRequest.class);
        DeleteCartUIResponse response = mapper.readValue(responseString, DeleteCartUIResponse.class);
        URI url = URI.create("http://localhost/nse/ngd/deleteCart");
        HttpCookie cookie1 = new HttpCookie("quickShopProspectCart", "abcd");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("digital_ig_session", "digital_1").cookie(cookie1).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(redisHelper.deleteAddDeviceDataFromRedis(any())).thenReturn(Mono.just(1L));
        when(redisHelper.deleteProcessingMtnFromRedis(any())).thenReturn(Mono.just(1L));
        when(helper1.ngdDeleteCart(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.ngdDeleteCart(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> junit.framework.Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }
    @Test
    public void ngdDeleteCartErrorTest() throws IOException {
        String requestString = "{\"channelId\": \"VZW-DOTCOM\",\"ngdFlow\": true,\"cartInfo\":{\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processStep\":\"Configurator\",\"intendType\":\"NSE\"}}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        DeleteCartUIRequest request = mapper.readValue(requestString, DeleteCartUIRequest.class);
        DeleteCartUIResponse response = mapper.readValue(responseString, DeleteCartUIResponse.class);
        URI url = URI.create("http://localhost/nse/ngd/deleteCart");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(redisHelper.deleteAddDeviceDataFromRedis(any())).thenReturn(Mono.just(1L));
        when(redisHelper.deleteProcessingMtnFromRedis(any())).thenReturn(Mono.just(1L));
        when(helper1.ngdDeleteCart(any())).thenReturn((Mono<DeleteCartUIResponse>) Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.ngdDeleteCart(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void ngdDeleteCartTest1() throws IOException {
        String requestString = "{\"channelId\": \"VZW-DOTCOM\",\"ngdFlow\": true,\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"Configurator\",\"intendType\":\"NSE\"}}";
        String responseString = "{\"serviceBody\":{\"serviceResponse\":{\"context\":{\"cartInfo\":{\"cartItemCount\":0,\"couponCode\":\"\",\"discountPromoTotal\":0,\"fmiCheck\":false,\"instantCreditAmount\":0,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false,\"protectionNotRequired\":false,\"registerNumber\":0,\"statusCode\":\"1\",\"statusMsg\":\"cart cleared successfully!\"},\"contextInfo\":{\"availablePaths\":[],\"callReason\":\"SalesOrderPurchase\",\"processAction\":\"\",\"processStep\":\"PromoHub\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POW-D-a4374a66-327a-49db-8889-0583f3e260e8\",\"customerType\":\"N\",\"globalId\":\"POW-D-a4374a66-327a-49db-8889-0583f3e260e8\",\"myvPage\":false,\"noc\":false,\"nocByod\":false,\"processingMTN\":\"newLine1\",\"registerNumber\":0}}}},\"serviceHeader\":{\"correlationId\":\"soe-cart-2024.07.03.03.06.45-644.8149291665973\",\"serviceName\":\"SalesOrderPurchase\",\"sessionId\":\"\",\"statusCode\":\"00\",\"statusMsg\":\"SUCCESS\",\"userId\":\"\"}}";
        DeleteCartUIRequest request = mapper.readValue(requestString, DeleteCartUIRequest.class);
        DeleteCartUIResponse response = mapper.readValue(responseString, DeleteCartUIResponse.class);
        URI url = URI.create("http://localhost/nse/ngd/deleteCart");
        HttpCookie cookie2 = new HttpCookie("digital_ig_session", "1234");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("digital_ig_session", "digital_1").cookie(cookie2).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        response.setCartCount("1");
        when(redisHelper.deleteAddDeviceDataFromRedis(any())).thenReturn(Mono.just(1L));
        when(redisHelper.deleteProcessingMtnFromRedis(any())).thenReturn(Mono.just(1L));
        when(helper1.ngdDeleteCart(any())).thenReturn(Mono.just(response));
        Mockito.when(redisHelper2.updateDeviceCartCount(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.ngdDeleteCart(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> junit.framework.Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void ngdDeleteCartTest2() throws IOException {
        String requestString = "{\"channelId\": \"VZW-DOTCOM\",\"ngdFlow\": true,\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\",\"processStep\":\"Configurator\"}}";
        String responseString = "{\"serviceBody\":{\"serviceResponse\":{\"context\":{\"cartInfo\":{\"cartItemCount\":0,\"couponCode\":\"\",\"discountPromoTotal\":0,\"fmiCheck\":false,\"instantCreditAmount\":0,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false,\"protectionNotRequired\":false,\"registerNumber\":0,\"statusCode\":\"1\",\"statusMsg\":\"cart cleared successfully!\"},\"contextInfo\":{\"availablePaths\":[],\"callReason\":\"SalesOrderPurchase\",\"processAction\":\"\",\"processStep\":\"PromoHub\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POW-D-a4374a66-327a-49db-8889-0583f3e260e8\",\"customerType\":\"N\",\"globalId\":\"POW-D-a4374a66-327a-49db-8889-0583f3e260e8\",\"myvPage\":false,\"noc\":false,\"nocByod\":false,\"processingMTN\":\"newLine1\",\"registerNumber\":0}}}},\"serviceHeader\":{\"correlationId\":\"soe-cart-2024.07.03.03.06.45-644.8149291665973\",\"serviceName\":\"SalesOrderPurchase\",\"sessionId\":\"\",\"statusCode\":\"00\",\"statusMsg\":\"SUCCESS\",\"userId\":\"\"}}";
        DeleteCartUIRequest request = mapper.readValue(requestString, DeleteCartUIRequest.class);
        DeleteCartUIResponse response = mapper.readValue(responseString, DeleteCartUIResponse.class);
        URI url = URI.create("http://localhost/nse/ngd/deleteCart");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("quickShopProspectCart","1234").header("digital_ig_session", "digital_1").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.ngdDeleteCart(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> junit.framework.Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addUpgradeDetailsSubFlowTest() throws IOException{
        String requestFile = "{ \"cartInfo\": { \"cartId\": \"\", \"caseId\": \"\", \"accountNumber\": \"\", \"cartCreator\": \"\", \"processingMTN\": \"5404098746\", \"processStep\": \"GridWallPDP\", \"processAction\": \"ExpressUpgrade\", \"intendType\": \"EUP\", \"isTradeInSelected\": false, \"disableMyLink\": false, \"editDevice\": false, \"expressCheckout\": null, \"noPendingOfferExists\": false, \"isPromoPDP\": false, \"mtnFlow\": \"M\", \"myvPage\": true }, \"data\": { \"entryPoint\": \"PDP\", \"lines\": [ { \"isCommonPDP\": true, \"mtn\": \"5404098746\", \"purchasePath\": \"EUP\", \"portInNumber\": \"\", \"eupNoPromoFlow\": false, \"device\": { \"id\": \"MU6C3LL/A\", \"contractTerm\": \"VERIZON_EDGE\", \"iconicPhone\": true, \"dppMonths\": 36, \"productId\": \"dev21410696\", \"category\": \"Smartphones\", \"preconfigure\": false }, \"sim\": { \"id\": \"UNIVESIM5G-SAB-S\" }, \"ispuFlow\": false, \"estimatedReadyByDate\": \"\", \"depletionLocationCode\": \"\", \"depletionType\": \"F\", \"isKeepingExistingEqProtection\": true, \"newLineOrAAL\": false, \"isNewLine\": false, \"selectedPromoId\": \"promo3730541\", \"selectedPromoType\": \"BIC\", \"promoRejectionIndicator\": true, \"isIconicPhone\": true, \"selectedSedOfferId\": \"554871\", \"isStrategicOffer\": false, \"restricted\": \"\", \"skipPromoChoiceOffer\": false, \"isTradeInIntentSelected\": false, \"restrictedProductType\": null, \"tradeInShippingType\": \"return_store\" } ], \"rtm\": { \"url\": \"https://vzwqa2.verizonwireless.com/smartphones/apple-iphone-15-pro-max/\", \"img\": \"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-pro-max-256gb-white-titanium-mu673ll-a-a\", \"name\": \"iPhone 15 Pro Max\", \"make\": \"Apple\", \"categoryId\": \"Smartphones\", \"pageURL\": \"https://vzwqa2.verizonwireless.com/smartphones/apple-iphone-15-pro-max/\" }, \"enableFcc\": true } }";
        String responseFile = "{ \"serviceHeader\": { \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\", \"correlationId\": \"soe-cart-2024.09.16.07.48.47-416.23497932289865\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"contextInfo\": { \"availablePaths\": [ { \"path\": \"PromoHub\" } ], \"skipCheckoutCall\": false, \"unifiedNbsFlag\": false, \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"PromoHub\", \"processAction\": \"\" }, \"customerInfo\": { \"nocByod\": false, \"cartCreator\": \"5404098746\", \"processingMTN\": \"5404098746\", \"registerNumber\": 0, \"number_share_capable\": \"\", \"e911_addr_ind\": \"false\", \"existingCase\": \"\", \"noc\": false, \"myvPage\": false }, \"cartInfo\": { \"financeLimitExceeded\": \"false\", \"cartItemCount\": 1, \"statusMsg\": \"Success\", \"statusCode\": \"1\", \"lines\": [ { \"status\": 1, \"spos\": [ { \"id\": \"1958\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] } ], \"sfos\": [ { \"id\": \"86905\", \"conflict\": \"SFO dropped because of requal - ESN chg\", \"actionIndicator\": \"D\", \"displayHumWiFi\": false } ], \"firstMonthInstallment\": 39.19, \"monthlyInstallment\": 38.88, \"reasonCode\": \"PLAN_DEVICE_COMPATIBLE\", \"selectedPromoType\": \"BIC\", \"eupNoPromoFlow\": false, \"lineSubscriptionInfos\": [], \"mtn\": \"5404098746\", \"device\": { \"upgradeReasonCode\": \"EA\", \"id\": \"MU6C3LL/A\", \"installmentTerm\": \"0\", \"itemPrice\": \"1399.99\", \"finalPrice\": \"0.0\", \"discountAmount\": \"0.0\", \"qty\": 1, \"edgeUpEnabled\": false, \"numberShareEnabled\": false, \"existingDeviceName\": \"iPhone 15 Pro Max\", \"fiveGToFourGDownGrade\": false, \"byodESimPhone\": false, \"skipImei1Call\": false, \"amount\": 0.0, \"isNonVZDeviceSku\": false, \"skuId\": \"sku6004655\", \"skuDisplayName\": \" Apple iPhone 15 Pro Max 512GB in White Titanium\", \"isDfoSelected\": false }, \"sim\": { \"id\": \"UNIVESIM5G-SAB-S\" }, \"warranty\": { \"itemPrice\": \"0.0\" }, \"upgradeFee\": { \"qty\": 1, \"itemPrice\": \"35\" }, \"devicePlanCompatible\": true, \"planValidationFailed\": false, \"lineActivityType\": \"EUP\", \"currentPlanType\": \"LLP\", \"planQualifiedForPromotion\": false, \"fiveGUpSell\": false, \"is5GBoltEligible\": false, \"fiveGPlanAdded\": false, \"editSim\": false, \"lineWithSkipMDN\": false, \"inWithVerizonOpted\": false, \"protectionNotRequired\": false, \"skipPromoChoiceOffer\": false } ], \"expressCheckout\": false, \"effectiveDateDetails\": { \"suggestedBackDate\": \"\", \"suggestedFutureDate\": \"09/29/2024\", \"currentBillCycleBeginDate\": \"08/29/2024\", \"nextBillCycleBeginDate\": \"09/29/2024\", \"onDemandDate\": \"09/16/2024\", \"onDemandRangeInDays\": \"45\", \"selectedDate\": \"09/16/2024\" }, \"preAuthSuccess\": false, \"promoLossIndicator\": false, \"monthlyCreditAmount\": \"0.0\", \"agreementNumber\": \"0\", \"vztDiscountGain\": false, \"vztDiscountLoss\": false, \"discountPromoTotal\": 0.0, \"registerNumber\": 0, \"hasMixAndMatchPlan\": true, \"oneBillEnrolled\": false, \"protectionNotRequired\": false, \"fmiCheck\": false, \"isFlexV2\": false, \"isPrepaidToPostpaidMigration\": false, \"instantCreditAmount\": 0, \"ngdFlow\": false }, \"processMTNList\": [ { \"mtn\": \"5404098746\", \"completedprocessSteps\": [ \"GridWallPDP\", \"DeviceConfigurator\", \"PromoHub\", \"Initiate\", \"Initiate\", \"GridWallPDP\" ] } ] } } }, \"featureConfigurationProfileData\": { \"mdnSelectionOneClickEligibleFFlag\": { \"enabled\": false, \"found\": true, \"attributes\": { \"enabled\": [ \"false\" ] } }, \"expressUpgradeFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"enable1ClickDeviceProtectionFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"eupPromoRestructureFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"oneClkDppSummaryFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"offerFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"bauUpgradeFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"enableGiftingFeature\": [ \"true\" ], \"enableAccMemberMigration\": [ \"true\" ], \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"oneUnlimitedFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"getProductDetailsOneClickEligibleFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } } } }";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIRequest request = mapper.readValue(requestFile, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseFile, AddDeviceUIResponse.class);
        when(deviceHelper.addUpgradeDetails(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(deviceHelper.updateSubFlowForOneClickExpressUpgrade(Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("subFlow"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(helper.populateConflictedSPOsIfPresent(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(helper.populateHumWifiConflictedSFosWithCheck(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        URI url = URI.create("http://localhost/cart/addUpgradeDetails");
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalUpgradeCfgProfile()).thenReturn(Mono.just(configurationProfile));
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController4.addUpgradeDetails(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(response);}).expectComplete().verify();
    }
    @Test
    public void addUpgradeDetailsSubFlowErrorTest() throws IOException{
        String requestFile = "{ \"cartInfo\": { \"cartId\": \"\", \"caseId\": \"\", \"accountNumber\": \"\", \"cartCreator\": \"\", \"processingMTN\": \"5404098746\", \"processStep\": \"GridWallPDP\", \"processAction\": \"ExpressUpgrade\", \"intendType\": \"EUP\", \"isTradeInSelected\": false, \"disableMyLink\": false, \"editDevice\": false, \"expressCheckout\": null, \"noPendingOfferExists\": false, \"isPromoPDP\": false, \"mtnFlow\": \"M\", \"myvPage\": true }, \"data\": { \"entryPoint\": \"PDP\", \"lines\": [ { \"isCommonPDP\": true, \"mtn\": \"5404098746\", \"purchasePath\": \"EUP\", \"portInNumber\": \"\", \"eupNoPromoFlow\": false, \"device\": { \"id\": \"MU6C3LL/A\", \"contractTerm\": \"VERIZON_EDGE\", \"iconicPhone\": true, \"dppMonths\": 36, \"productId\": \"dev21410696\", \"category\": \"Smartphones\", \"preconfigure\": false }, \"sim\": { \"id\": \"UNIVESIM5G-SAB-S\" }, \"ispuFlow\": false, \"estimatedReadyByDate\": \"\", \"depletionLocationCode\": \"\", \"depletionType\": \"F\", \"isKeepingExistingEqProtection\": true, \"newLineOrAAL\": false, \"isNewLine\": false, \"selectedPromoId\": \"promo3730541\", \"selectedPromoType\": \"BIC\", \"promoRejectionIndicator\": true, \"isIconicPhone\": true, \"selectedSedOfferId\": \"554871\", \"isStrategicOffer\": false, \"restricted\": \"\", \"skipPromoChoiceOffer\": false, \"isTradeInIntentSelected\": false, \"restrictedProductType\": null, \"tradeInShippingType\": \"return_store\" } ], \"rtm\": { \"url\": \"https://vzwqa2.verizonwireless.com/smartphones/apple-iphone-15-pro-max/\", \"img\": \"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-pro-max-256gb-white-titanium-mu673ll-a-a\", \"name\": \"iPhone 15 Pro Max\", \"make\": \"Apple\", \"categoryId\": \"Smartphones\", \"pageURL\": \"https://vzwqa2.verizonwireless.com/smartphones/apple-iphone-15-pro-max/\" }, \"enableFcc\": true } }";
        String responseFile = "{ \"serviceHeader\": { \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\", \"correlationId\": \"soe-cart-2024.09.16.07.48.47-416.23497932289865\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"contextInfo\": { \"availablePaths\": [ { \"path\": \"PromoHub\" } ], \"skipCheckoutCall\": false, \"unifiedNbsFlag\": false, \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"PromoHub\", \"processAction\": \"\" }, \"customerInfo\": { \"nocByod\": false, \"cartCreator\": \"5404098746\", \"processingMTN\": \"5404098746\", \"registerNumber\": 0, \"number_share_capable\": \"\", \"e911_addr_ind\": \"false\", \"existingCase\": \"\", \"noc\": false, \"myvPage\": false }, \"cartInfo\": { \"financeLimitExceeded\": \"false\", \"cartItemCount\": 1, \"statusMsg\": \"Success\", \"statusCode\": \"1\", \"lines\": [ { \"status\": 1, \"spos\": [ { \"id\": \"1958\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] } ], \"sfos\": [ { \"id\": \"86905\", \"conflict\": \"SFO dropped because of requal - ESN chg\", \"actionIndicator\": \"D\", \"displayHumWiFi\": false } ], \"firstMonthInstallment\": 39.19, \"monthlyInstallment\": 38.88, \"reasonCode\": \"PLAN_DEVICE_COMPATIBLE\", \"selectedPromoType\": \"BIC\", \"eupNoPromoFlow\": false, \"lineSubscriptionInfos\": [], \"mtn\": \"5404098746\", \"device\": { \"upgradeReasonCode\": \"EA\", \"id\": \"MU6C3LL/A\", \"installmentTerm\": \"0\", \"itemPrice\": \"1399.99\", \"finalPrice\": \"0.0\", \"discountAmount\": \"0.0\", \"qty\": 1, \"edgeUpEnabled\": false, \"numberShareEnabled\": false, \"existingDeviceName\": \"iPhone 15 Pro Max\", \"fiveGToFourGDownGrade\": false, \"byodESimPhone\": false, \"skipImei1Call\": false, \"amount\": 0.0, \"isNonVZDeviceSku\": false, \"skuId\": \"sku6004655\", \"skuDisplayName\": \" Apple iPhone 15 Pro Max 512GB in White Titanium\", \"isDfoSelected\": false }, \"sim\": { \"id\": \"UNIVESIM5G-SAB-S\" }, \"warranty\": { \"itemPrice\": \"0.0\" }, \"upgradeFee\": { \"qty\": 1, \"itemPrice\": \"35\" }, \"devicePlanCompatible\": true, \"planValidationFailed\": false, \"lineActivityType\": \"EUP\", \"currentPlanType\": \"LLP\", \"planQualifiedForPromotion\": false, \"fiveGUpSell\": false, \"is5GBoltEligible\": false, \"fiveGPlanAdded\": false, \"editSim\": false, \"lineWithSkipMDN\": false, \"inWithVerizonOpted\": false, \"protectionNotRequired\": false, \"skipPromoChoiceOffer\": false } ], \"expressCheckout\": false, \"effectiveDateDetails\": { \"suggestedBackDate\": \"\", \"suggestedFutureDate\": \"09/29/2024\", \"currentBillCycleBeginDate\": \"08/29/2024\", \"nextBillCycleBeginDate\": \"09/29/2024\", \"onDemandDate\": \"09/16/2024\", \"onDemandRangeInDays\": \"45\", \"selectedDate\": \"09/16/2024\" }, \"preAuthSuccess\": false, \"promoLossIndicator\": false, \"monthlyCreditAmount\": \"0.0\", \"agreementNumber\": \"0\", \"vztDiscountGain\": false, \"vztDiscountLoss\": false, \"discountPromoTotal\": 0.0, \"registerNumber\": 0, \"hasMixAndMatchPlan\": true, \"oneBillEnrolled\": false, \"protectionNotRequired\": false, \"fmiCheck\": false, \"isFlexV2\": false, \"isPrepaidToPostpaidMigration\": false, \"instantCreditAmount\": 0, \"ngdFlow\": false }, \"processMTNList\": [ { \"mtn\": \"5404098746\", \"completedprocessSteps\": [ \"GridWallPDP\", \"DeviceConfigurator\", \"PromoHub\", \"Initiate\", \"Initiate\", \"GridWallPDP\" ] } ] } } }, \"featureConfigurationProfileData\": { \"mdnSelectionOneClickEligibleFFlag\": { \"enabled\": false, \"found\": true, \"attributes\": { \"enabled\": [ \"false\" ] } }, \"expressUpgradeFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"enable1ClickDeviceProtectionFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"eupPromoRestructureFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"oneClkDppSummaryFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"offerFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"bauUpgradeFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"enableGiftingFeature\": [ \"true\" ], \"enableAccMemberMigration\": [ \"true\" ], \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"oneUnlimitedFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"getProductDetailsOneClickEligibleFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } } } }";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIRequest request = mapper.readValue(requestFile, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseFile, AddDeviceUIResponse.class);
        when(deviceHelper.addUpgradeDetails(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(deviceHelper.updateSubFlowForOneClickExpressUpgrade(Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("subFlow"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(helper.populateConflictedSPOsIfPresent(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(helper.populateHumWifiConflictedSFosWithCheck(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        URI url = URI.create("http://localhost/cart/addUpgradeDetails");
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalUpgradeCfgProfile()).thenReturn(Mono.just(configurationProfile));
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        request.getCartInfo().setIntendType("AccountGrowth");

        ShowAALPromoIntercept showAALPromoIntercept=new ShowAALPromoIntercept();
        response.getServiceBody().getServiceResponse().getContext().setShowAALPromoIntercept(showAALPromoIntercept);
        response.getServiceBody().getServiceResponse().getContext().getCustomerInfo().setExistingCase("test");
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController4.addUpgradeDetails(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(response);}).expectComplete().verify();
    }

    @Test
    public void addUpgradeDetailsSubFlowErrorTest1() throws IOException{
        //cartId caseId not null
        String requestFile = "{ \"cartInfo\": { \"cartId\": \"123456\", \"caseId\": \"SO-123445\", \"accountNumber\": \"\", \"cartCreator\": \"\", \"processingMTN\": \"5404098746\", \"processStep\": \"GridWallPDP\", \"processAction\": \"ExpressUpgrade\", \"intendType\": \"EUP\", \"isTradeInSelected\": false, \"disableMyLink\": false, \"editDevice\": false, \"expressCheckout\": null, \"noPendingOfferExists\": false, \"isPromoPDP\": false, \"mtnFlow\": \"M\", \"myvPage\": true }, \"data\": { \"entryPoint\": \"PDP\", \"lines\": [ { \"isCommonPDP\": true, \"mtn\": \"5404098746\", \"purchasePath\": \"EUP\", \"portInNumber\": \"\", \"eupNoPromoFlow\": false, \"device\": { \"id\": \"MU6C3LL/A\", \"contractTerm\": \"VERIZON_EDGE\", \"iconicPhone\": true, \"dppMonths\": 36, \"productId\": \"dev21410696\", \"category\": \"Smartphones\", \"preconfigure\": false }, \"sim\": { \"id\": \"UNIVESIM5G-SAB-S\" }, \"ispuFlow\": false, \"estimatedReadyByDate\": \"\", \"depletionLocationCode\": \"\", \"depletionType\": \"F\", \"isKeepingExistingEqProtection\": true, \"newLineOrAAL\": false, \"isNewLine\": false, \"selectedPromoId\": \"promo3730541\", \"selectedPromoType\": \"BIC\", \"promoRejectionIndicator\": true, \"isIconicPhone\": true, \"selectedSedOfferId\": \"554871\", \"isStrategicOffer\": false, \"restricted\": \"\", \"skipPromoChoiceOffer\": false, \"isTradeInIntentSelected\": false, \"restrictedProductType\": null, \"tradeInShippingType\": \"return_store\" } ], \"rtm\": { \"url\": \"https://vzwqa2.verizonwireless.com/smartphones/apple-iphone-15-pro-max/\", \"img\": \"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-pro-max-256gb-white-titanium-mu673ll-a-a\", \"name\": \"iPhone 15 Pro Max\", \"make\": \"Apple\", \"categoryId\": \"Smartphones\", \"pageURL\": \"https://vzwqa2.verizonwireless.com/smartphones/apple-iphone-15-pro-max/\" }, \"enableFcc\": true } }";
        String responseFile = "{ \"serviceHeader\": { \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\", \"correlationId\": \"soe-cart-2024.09.16.07.48.47-416.23497932289865\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"contextInfo\": { \"availablePaths\": [ { \"path\": \"PromoHub\" } ], \"skipCheckoutCall\": false, \"unifiedNbsFlag\": false, \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"PromoHub\", \"processAction\": \"\" }, \"customerInfo\": { \"nocByod\": false, \"cartCreator\": \"5404098746\", \"processingMTN\": \"5404098746\", \"registerNumber\": 0, \"number_share_capable\": \"\", \"e911_addr_ind\": \"false\", \"existingCase\": \"\", \"noc\": false, \"myvPage\": false }, \"cartInfo\": { \"financeLimitExceeded\": \"false\", \"cartItemCount\": 1, \"statusMsg\": \"Success\", \"statusCode\": \"1\", \"lines\": [ { \"status\": 1, \"spos\": [ { \"id\": \"1958\", \"actionIndicator\": \"A\", \"success\": true, \"is5GBolt\": false, \"parentProductsSorIds\": [] } ], \"sfos\": [ { \"id\": \"86905\", \"conflict\": \"SFO dropped because of requal - ESN chg\", \"actionIndicator\": \"D\", \"displayHumWiFi\": false } ], \"firstMonthInstallment\": 39.19, \"monthlyInstallment\": 38.88, \"reasonCode\": \"PLAN_DEVICE_COMPATIBLE\", \"selectedPromoType\": \"BIC\", \"eupNoPromoFlow\": false, \"lineSubscriptionInfos\": [], \"mtn\": \"5404098746\", \"device\": { \"upgradeReasonCode\": \"EA\", \"id\": \"MU6C3LL/A\", \"installmentTerm\": \"0\", \"itemPrice\": \"1399.99\", \"finalPrice\": \"0.0\", \"discountAmount\": \"0.0\", \"qty\": 1, \"edgeUpEnabled\": false, \"numberShareEnabled\": false, \"existingDeviceName\": \"iPhone 15 Pro Max\", \"fiveGToFourGDownGrade\": false, \"byodESimPhone\": false, \"skipImei1Call\": false, \"amount\": 0.0, \"isNonVZDeviceSku\": false, \"skuId\": \"sku6004655\", \"skuDisplayName\": \" Apple iPhone 15 Pro Max 512GB in White Titanium\", \"isDfoSelected\": false }, \"sim\": { \"id\": \"UNIVESIM5G-SAB-S\" }, \"warranty\": { \"itemPrice\": \"0.0\" }, \"upgradeFee\": { \"qty\": 1, \"itemPrice\": \"35\" }, \"devicePlanCompatible\": true, \"planValidationFailed\": false, \"lineActivityType\": \"EUP\", \"currentPlanType\": \"LLP\", \"planQualifiedForPromotion\": false, \"fiveGUpSell\": false, \"is5GBoltEligible\": false, \"fiveGPlanAdded\": false, \"editSim\": false, \"lineWithSkipMDN\": false, \"inWithVerizonOpted\": false, \"protectionNotRequired\": false, \"skipPromoChoiceOffer\": false } ], \"expressCheckout\": false, \"effectiveDateDetails\": { \"suggestedBackDate\": \"\", \"suggestedFutureDate\": \"09/29/2024\", \"currentBillCycleBeginDate\": \"08/29/2024\", \"nextBillCycleBeginDate\": \"09/29/2024\", \"onDemandDate\": \"09/16/2024\", \"onDemandRangeInDays\": \"45\", \"selectedDate\": \"09/16/2024\" }, \"preAuthSuccess\": false, \"promoLossIndicator\": false, \"monthlyCreditAmount\": \"0.0\", \"agreementNumber\": \"0\", \"vztDiscountGain\": false, \"vztDiscountLoss\": false, \"discountPromoTotal\": 0.0, \"registerNumber\": 0, \"hasMixAndMatchPlan\": true, \"oneBillEnrolled\": false, \"protectionNotRequired\": false, \"fmiCheck\": false, \"isFlexV2\": false, \"isPrepaidToPostpaidMigration\": false, \"instantCreditAmount\": 0, \"ngdFlow\": false }, \"processMTNList\": [ { \"mtn\": \"5404098746\", \"completedprocessSteps\": [ \"GridWallPDP\", \"DeviceConfigurator\", \"PromoHub\", \"Initiate\", \"Initiate\", \"GridWallPDP\" ] } ] } } }, \"featureConfigurationProfileData\": { \"mdnSelectionOneClickEligibleFFlag\": { \"enabled\": false, \"found\": true, \"attributes\": { \"enabled\": [ \"false\" ] } }, \"expressUpgradeFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"enable1ClickDeviceProtectionFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"eupPromoRestructureFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"oneClkDppSummaryFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"offerFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"bauUpgradeFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"enableGiftingFeature\": [ \"true\" ], \"enableAccMemberMigration\": [ \"true\" ], \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"oneUnlimitedFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } }, \"getProductDetailsOneClickEligibleFFlag\": { \"enabled\": true, \"found\": true, \"attributes\": { \"actPctOwner\": [ \"ACT046\" ], \"enabled\": [ \"true\" ] } } } }";
        String cdlThrottlist = "|VideoChatEnabled_PDP_NSE|ABANDON_CART_GW|FiosT|z1_p_t_g|CB_I_P|CHAT_EFF_C|G_To_BAU_W_INSIGHTS_P|COMMON_PDP_SP_P|HI_NAT_TRD_P|AGT_AVL_P|Perks_ctrl|PDP_SMLRRCM_P|PDP_BROTTGR_P|PPP_DF_NSE|Digital_Concierge_P|NSE_TRADE_ANYWHERE|PDP_C_PC_P|PDP_C_SFY_P|PDP_T_OOS_P|NSE_MT_RTN_CHOICE|QUICK_VIEW_P|";
        AddDeviceUIRequest request = mapper.readValue(requestFile, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseFile, AddDeviceUIResponse.class);
        when(deviceHelper.addUpgradeDetails(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(deviceHelper.updateSubFlowForOneClickExpressUpgrade(Mockito.any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("subFlow"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(helper.populateConflictedSPOsIfPresent(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        when(helper.populateHumWifiConflictedSFosWithCheck(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
        URI url = URI.create("http://localhost/cart/addUpgradeDetails");
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalUpgradeCfgProfile()).thenReturn(Mono.just(configurationProfile));
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        request.getCartInfo().setIntendType("AccountGrowth");

        ShowAALPromoIntercept showAALPromoIntercept=new ShowAALPromoIntercept();
        response.getServiceBody().getServiceResponse().getContext().setShowAALPromoIntercept(showAALPromoIntercept);
        response.getServiceBody().getServiceResponse().getContext().getCustomerInfo().setExistingCase("test");
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController4.addUpgradeDetails(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(response);}).expectComplete().verify();

        //line.device =null processStep is null
        String requestFile1 = "{ \"cartInfo\": { \"cartId\": \"123456\", \"caseId\": \"SO-123445\", \"accountNumber\": \"\", \"cartCreator\": \"\", \"processingMTN\": \"5404098746\", \"processStep\": null, \"processAction\": \"ExpressUpgrade\", \"intendType\": \"EUP\", \"isTradeInSelected\": false, \"disableMyLink\": false, \"editDevice\": false, \"expressCheckout\": null, \"noPendingOfferExists\": false, \"isPromoPDP\": false, \"mtnFlow\": \"M\", \"myvPage\": true }, \"data\": { \"entryPoint\": \"PDP\", \"lines\": [ { \"isCommonPDP\": true, \"mtn\": \"5404098746\", \"purchasePath\": \"EUP\", \"portInNumber\": \"\", \"eupNoPromoFlow\": false, \"device\": null, \"sim\": { \"id\": \"UNIVESIM5G-SAB-S\" }, \"ispuFlow\": false, \"estimatedReadyByDate\": \"\", \"depletionLocationCode\": \"\", \"depletionType\": \"F\", \"isKeepingExistingEqProtection\": true, \"newLineOrAAL\": false, \"isNewLine\": false, \"selectedPromoId\": \"promo3730541\", \"selectedPromoType\": \"BIC\", \"promoRejectionIndicator\": true, \"isIconicPhone\": true, \"selectedSedOfferId\": \"554871\", \"isStrategicOffer\": false, \"restricted\": \"\", \"skipPromoChoiceOffer\": false, \"isTradeInIntentSelected\": false, \"restrictedProductType\": null, \"tradeInShippingType\": \"return_store\" } ], \"rtm\": { \"url\": \"https://vzwqa2.verizonwireless.com/smartphones/apple-iphone-15-pro-max/\", \"img\": \"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-pro-max-256gb-white-titanium-mu673ll-a-a\", \"name\": \"iPhone 15 Pro Max\", \"make\": \"Apple\", \"categoryId\": \"Smartphones\", \"pageURL\": \"https://vzwqa2.verizonwireless.com/smartphones/apple-iphone-15-pro-max/\" }, \"enableFcc\": true } }";
        AddDeviceUIRequest request1 = mapper.readValue(requestFile1, AddDeviceUIRequest.class);
        Mono<ResponseEntity<GenericResponse>> controllerResponse1 = cartController4.addUpgradeDetails(httpRequest,httpResponse, request1);
        StepVerifier.create(controllerResponse1).assertNext(resp -> {Assert.assertNotNull(response);}).expectComplete().verify();

        //intend AAL
        String requestFile2 = "{ \"cartInfo\": { \"cartId\": \"\", \"caseId\": \"\", \"accountNumber\": \"\", \"cartCreator\": \"\", \"processingMTN\": \"5404098746\", \"processStep\": \"GridWallPDP\", \"processAction\": \"ExpressUpgrade\", \"intendType\": \"AAL\", \"isTradeInSelected\": false, \"disableMyLink\": false, \"editDevice\": false, \"expressCheckout\": null, \"noPendingOfferExists\": false, \"isPromoPDP\": false, \"mtnFlow\": \"M\", \"myvPage\": true }, \"data\": { \"entryPoint\": \"PDP\", \"lines\": [ { \"isCommonPDP\": true, \"mtn\": \"5404098746\", \"purchasePath\": \"EUP\", \"portInNumber\": \"\", \"eupNoPromoFlow\": false, \"device\": { \"id\": \"MU6C3LL/A\", \"contractTerm\": \"VERIZON_EDGE\", \"iconicPhone\": true, \"dppMonths\": 36, \"productId\": \"dev21410696\", \"category\": \"Smartphones\", \"preconfigure\": false }, \"sim\": { \"id\": \"UNIVESIM5G-SAB-S\" }, \"ispuFlow\": false, \"estimatedReadyByDate\": \"\", \"depletionLocationCode\": \"\", \"depletionType\": \"F\", \"isKeepingExistingEqProtection\": true, \"newLineOrAAL\": false, \"isNewLine\": false, \"selectedPromoId\": \"promo3730541\", \"selectedPromoType\": \"BIC\", \"promoRejectionIndicator\": true, \"isIconicPhone\": true, \"selectedSedOfferId\": \"554871\", \"isStrategicOffer\": false, \"restricted\": \"\", \"skipPromoChoiceOffer\": false, \"isTradeInIntentSelected\": false, \"restrictedProductType\": null, \"tradeInShippingType\": \"return_store\" } ], \"rtm\": { \"url\": \"https://vzwqa2.verizonwireless.com/smartphones/apple-iphone-15-pro-max/\", \"img\": \"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-pro-max-256gb-white-titanium-mu673ll-a-a\", \"name\": \"iPhone 15 Pro Max\", \"make\": \"Apple\", \"categoryId\": \"Smartphones\", \"pageURL\": \"https://vzwqa2.verizonwireless.com/smartphones/apple-iphone-15-pro-max/\" }, \"enableFcc\": true } }";
        AddDeviceUIRequest request2 = mapper.readValue(requestFile2, AddDeviceUIRequest.class);
        Mono<ResponseEntity<GenericResponse>> controllerResponse2 = cartController4.addUpgradeDetails(httpRequest,httpResponse, request2);
        StepVerifier.create(controllerResponse1).assertNext(resp -> {Assert.assertNotNull(response);}).expectComplete().verify();

        //data.line = null
        String requestFile3 = "{ \"cartInfo\": { \"cartId\": \"\", \"caseId\": \"\", \"accountNumber\": \"\", \"cartCreator\": \"\", \"processingMTN\": \"5404098746\", \"processStep\": \"GridWallPDP\", \"processAction\": \"ExpressUpgrade\", \"intendType\": \"EUP\", \"isTradeInSelected\": false, \"disableMyLink\": false, \"editDevice\": false, \"expressCheckout\": null, \"noPendingOfferExists\": false, \"isPromoPDP\": false, \"mtnFlow\": \"M\", \"myvPage\": true }, \"data\": { \"entryPoint\": \"PDP\", \"lines\": null, \"rtm\": { \"url\": \"https://vzwqa2.verizonwireless.com/smartphones/apple-iphone-15-pro-max/\", \"img\": \"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-pro-max-256gb-white-titanium-mu673ll-a-a\", \"name\": \"iPhone 15 Pro Max\", \"make\": \"Apple\", \"categoryId\": \"Smartphones\", \"pageURL\": \"https://vzwqa2.verizonwireless.com/smartphones/apple-iphone-15-pro-max/\" }, \"enableFcc\": true } }";
        AddDeviceUIRequest request3 = mapper.readValue(requestFile3, AddDeviceUIRequest.class);
        Mono<ResponseEntity<GenericResponse>> controllerResponse3 = cartController4.addUpgradeDetails(httpRequest,httpResponse, request3);
        StepVerifier.create(controllerResponse1).assertNext(resp -> {Assert.assertNotNull(response);}).expectComplete().verify();

    }

}
