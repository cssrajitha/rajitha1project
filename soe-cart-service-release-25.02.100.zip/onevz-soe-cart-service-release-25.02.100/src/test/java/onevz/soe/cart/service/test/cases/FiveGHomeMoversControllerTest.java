package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import junit.framework.Assert;
import net.jcip.annotations.NotThreadSafe;
import onevz.soe.cart.controller.FiveGHomeMoversController;
import onevz.soe.cart.helper.FiveGhomeMoversHelper;
import onevz.soe.cart.helper.RedisHelper3;
import onevz.soe.cart.model.addDevice.AddPlanDeviceCartInfo;
import onevz.soe.cart.model.common.FiveG.MoversCartRequest;
import onevz.soe.cart.model.common.FiveG.MoversRedisData;
import onevz.soe.cart.model.retrieveCart.CXPRetrieveCartDataVO;
import onevz.soe.cart.requests.GetCartDetailsRequest;
import onevz.soe.cart.requests.MoveDatesRequest;
import onevz.soe.cart.requests.MoversUpdatePlanRequest;
import onevz.soe.cart.responses.AddPlanAndDevicePEGAResponse;
import onevz.soe.cart.responses.FiveGHomeMoversUIResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.responses.AddMoveDatesUIResponse;
import onevz.soe.cart.ui.responses.MoversUpdatePlanResponse;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpResponse;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.bind.WebDataBinder;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.net.URI;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(FiveGHomeMoversController.class)
//@NotThreadSafe
public class FiveGHomeMoversControllerTest {



	@Autowired
	FiveGHomeMoversController controller;

	@MockBean
	private RedisHelper3 redisHelper3;

	@MockBean
	private FiveGhomeMoversHelper fiveGMoversHelper;

	@Autowired
	private ObjectMapper mapper;

	@Test
	public void getMoversRetrieveCartTest() throws IOException {

		URI url = URI.create("http://localhost/5g/movers/retrieve-cart");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		GetCartDetailsRequest request = new GetCartDetailsRequest();
		CXPRetrieveCartDataVO data = new CXPRetrieveCartDataVO();
		request.setData(data);
		String sampleStringResponse = "{\"moveServiceInfo\":{\"moveInDate\":\"Monday, October 5, 2022\",\"moveOutDate\":\"Monday, October 5, 2022\",\"planName\":\"LTE Home\",\"cart5GAddress\":{\"addressLine1\":\"3035 OAKLAND AVE\",\"city\":\"MINNEAPOLIS\",\"state\":\"MN\",\"zipCode\":\"55407\",\"zipCode4\":\"\",\"countryCode\":\"\",\"fipsCode\":\"2705343000\",\"floor\":0,\"latitude\":\"0.0\",\"longitude\":\"0.0\"}},\"orderDetailsView\":{\"orderNumber\":\"30002647\",\"locationCode\":\"N832101\",\"orderType\":\"PS\"}}";
		FiveGHomeMoversUIResponse response = mapper.readValue(sampleStringResponse, FiveGHomeMoversUIResponse.class);
		MoversRedisData redisData = new MoversRedisData();
		redisData.setCartId("sfg");
		when(redisHelper3.fiveGRedisMoversData()).thenReturn(Mono.just(redisData));
		when(fiveGMoversHelper.getMoversCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(response));
		Mono<FiveGHomeMoversUIResponse> controllerResponse = controller.getMoversRetrieveCart(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		redisData.setCartId("");
		when(redisHelper3.fiveGRedisMoversData()).thenReturn(Mono.just(redisData));
		Mono<FiveGHomeMoversUIResponse> controllerResponse1 = controller.getMoversRetrieveCart(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse1).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		GetCartDetailsRequest request1 = new GetCartDetailsRequest();
		CXPRetrieveCartDataVO data1 = new CXPRetrieveCartDataVO();
		data1.setCartId("34546789");
		data1.setOrderPlaced(false);
		request.setData(data1);
		Mono<FiveGHomeMoversUIResponse> controllerResponse2 = controller.getMoversRetrieveCart(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse2).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		GetCartDetailsRequest request2 = new GetCartDetailsRequest();
		CXPRetrieveCartDataVO data2 = new CXPRetrieveCartDataVO();
		request.setData(data2);
		Mono<FiveGHomeMoversUIResponse> controllerResponse3 = controller.getMoversRetrieveCart(httpHeader, httpResponse,
				request2);
		StepVerifier.create(controllerResponse3).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		GetCartDetailsRequest request3 = new GetCartDetailsRequest();
		Mono<FiveGHomeMoversUIResponse> controllerResponse4 = controller.getMoversRetrieveCart(httpHeader, httpResponse,
				request3);
		StepVerifier.create(controllerResponse4).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		Mono<FiveGHomeMoversUIResponse> controllerResponse5 = controller.getMoversRetrieveCart(httpHeader, httpResponse,
				null);
		StepVerifier.create(controllerResponse5).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();


	}

	@Test
	public void getMoversRetrieveCartTest2() throws IOException {

		URI url = URI.create("http://localhost/5g/movers/retrieve-cart");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		GetCartDetailsRequest request = new GetCartDetailsRequest();
		CXPRetrieveCartDataVO data = new CXPRetrieveCartDataVO();
		request.setData(data);
		String sampleStringResponse = "{\"moveServiceInfo\":{\"moveInDate\":\"Monday, October 5, 2022\",\"moveOutDate\":\"Monday, October 5, 2022\",\"planName\":\"LTE Home\",\"cart5GAddress\":{\"addressLine1\":\"3035 OAKLAND AVE\",\"city\":\"MINNEAPOLIS\",\"state\":\"MN\",\"zipCode\":\"55407\",\"zipCode4\":\"\",\"countryCode\":\"\",\"fipsCode\":\"2705343000\",\"floor\":0,\"latitude\":\"0.0\",\"longitude\":\"0.0\"}},\"orderDetailsView\":{\"orderNumber\":\"30002647\",\"locationCode\":\"N832101\",\"orderType\":\"PS\"}}";
		FiveGHomeMoversUIResponse response = mapper.readValue(sampleStringResponse, FiveGHomeMoversUIResponse.class);
		MoversRedisData redisData = new MoversRedisData();
		redisData.setCartId("sfg");
		when(redisHelper3.fiveGRedisMoversData()).thenReturn(Mono.just(redisData));
		when(fiveGMoversHelper.getMoversCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(response));
		Mono<FiveGHomeMoversUIResponse> controllerResponse = controller.getMoversRetrieveCart(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		redisData.setCartId("");
		when(redisHelper3.fiveGRedisMoversData()).thenReturn(Mono.just(redisData));
		Mono<FiveGHomeMoversUIResponse> controllerResponse1 = controller.getMoversRetrieveCart(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse1).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		redisData.setCompletedCartId("232323");
		CXPRetrieveCartDataVO data1 = new CXPRetrieveCartDataVO();
		data1.setOrderPlaced(true);
		request.setData(data1);
		Mono<FiveGHomeMoversUIResponse> controllerResponse2 = controller.getMoversRetrieveCart(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse2).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();


	}

	@Test
	public void initBinderByNameTest() {
		WebDataBinder binder = new WebDataBinder(null);
		controller.initBinderByName(binder);
		assertNotNull(binder.getDisallowedFields());
	}

	@Test
	public void testAddMoversPlanAndDevice() throws JsonProcessingException {
		MoversCartRequest request = new MoversCartRequest();
		AddPlanDeviceCartInfo cartInfo = new AddPlanDeviceCartInfo();
		cartInfo.setClientAppName("VZW-DOTCOM");
		request.setCartInfo(cartInfo);
		URI url = URI.create("http://localhost/5g/movers/updateCart");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		String pegaCallResponse = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"Movers\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"cartInfo\":{\"cartId\":\"c34829d0-8ba2-41a6-8712-9d9d442d3a4e\",\"statusMsg\":\"Success\",\"lines\":[{\"mtn\":\"2404298668\",\"sortingNumber\":0,\"lineId\":\"2404298668\",\"status\":1,\"planValidationFailed\":false,\"lineActivityType\":\"ACC\",\"devicePlanCompatible\":false,\"fiveGUpSell\":false,\"planQualifiedForPromotion\":false,\"displayHumWiFi\":false,\"downPaymentAmtApplied\":0,\"firstMonthInstallment\":0,\"fiveGPlanAdded\":false,\"fiveGMUCEligible\":false,\"isAppendedLine\":false,\"isDeviceSelected\":false,\"showGlobalChoiceOffer\":false,\"amRole\":\"\",\"protectionNotRequired\":false,\"networkBandwidthTypeChanged\":false,\"lacWithNumberShare\":false,\"activateSecDeviceNumShareElig\":false,\"numberShareOverlay\":false,\"gs4Device\":false,\"rioDevice\":false,\"simCompatibility\":false,\"eSimCapable\":false,\"totalDueMonthly\":0,\"planTradeInEligible\":false,\"userSelectedPlan\":false,\"monthlyInstallment\":0,\"ltehomeLine\":false,\"is5GBoltEligible\":false,\"is5GDevice\":false}],\"preAuthSuccess\":false,\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"financeLimitExceeded\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":0,\"agreementNumber\":0,\"expressCheckout\":false,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"validateOrderStatus\":false,\"subscriptionInfos\":[],\"showIntercept\":false,\"instantCreditEligible\":false,\"instantCreditValue\":0,\"showICPage\":false,\"preConfiguredCartType\":\"BAU\",\"preConfiguredCartTypeDuringAddDevice\":\"BAU\",\"cartItemCount\":0,\"numOfLinesWithDevices\":0,\"totalDueToday\":29.99,\"totalDueMonthly\":0,\"planSelectionRequired\":false,\"creditApplicationNum\":0,\"showGlobalChoiceOffer\":false,\"deviceCount\":0,\"affirmPaymentComplete\":false,\"upcomingAppointmentsAvailable\":false,\"relinquishTradeAmount\":0,\"emptyLine\":false,\"isRemoveTradeIn\":false},\"contextInfo\":{\"availablePaths\":[{\"path\":\"DateSelection\"}],\"processAction\":\"\",\"processStep\":\"DateSelection\",\"callReason\":\"Movers\"},\"caseId\":\"MOV-8826026-C01\",\"customerInfo\":{\"cartCreator\":\"POE-D-3b43852a-9ff8-4e9b-aa28-9d8ed3daab05\",\"processingMTN\":\"1234567890\",\"accountNumber\":\"\"},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]}]}}}}";
		AddPlanAndDevicePEGAResponse addPlanAndDevicePEGAResponse = mapper.readValue(pegaCallResponse,AddPlanAndDevicePEGAResponse.class);
		when(fiveGMoversHelper.addMoversPlanAndDevice(Mockito.any(), Mockito.any())).thenReturn(Mono.just(addPlanAndDevicePEGAResponse));
		Mono<AddPlanAndDevicePEGAResponse> addPlanAndDevicePEGAResponseMono  = controller.addMoversPlanAndDevice(httpHeader,null,request);
		StepVerifier.create(addPlanAndDevicePEGAResponseMono).assertNext(res -> Assert.assertNotNull(res)).expectComplete().verify();
	}

	@Test
	public void updateMoveDatesTest() throws JsonProcessingException {

		MoveDatesRequest request = new MoveDatesRequest();
		String response="{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM-MOB\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-8976794-C01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Accessories\"},{\"path\":\"PlanSelection\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"\"},\"customerInfo\":{\"pinCardPayment\":false,\"accountNumber\":\"\",\"cartCreator\":\"POE-M-61d3a55d-0e71-48e9-9797-beaebe0700a9\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":1,\"cartId\":\"da81f412-81c8-4678-81a4-6b9b5ecfd33a\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"onDemandAllowed\":false,\"backDateAllowed\":false,\"futureDateAllowed\":false,\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"lines\":[{\"status\":1,\"reasonCode\":\"PLAN_DEVICE_NOT_COMPATIBLE\",\"mtn\":\"newLine1\",\"isDeviceSelected\":true,\"userSelectedPlan\":false,\"lineId\":\"newLine1\",\"sortingNumber\":\"0\",\"device\":{\"id\":\"LVSKIHP\",\"itemPrice\":\"0.0\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"5G Internet Gateway\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false},\"sim\":{\"id\":\"NI-DPSIM\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE_5G\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"isAppendedLine\":false,\"fiveGPlanAdded\":false}],\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]}]}}}}";
		AddMoveDatesUIResponse MoveDateResponse=mapper.readValue(response,AddMoveDatesUIResponse.class);
		URI url = URI.create("http://localhost/5g/movers/updateCustomerMoveDates");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		when(fiveGMoversHelper.addCustomerMoveDates(httpHeader,request)).thenReturn(Mono.just(MoveDateResponse));

		Mono<AddMoveDatesUIResponse> responseMono= controller.updateMoveDates(httpHeader,null,request);
		StepVerifier.create(responseMono).assertNext(org.junit.Assert::assertNotNull).expectComplete().verify();
	}

	@Test
	public void moversUpdatePlanTest() throws JsonProcessingException {

		MoversUpdatePlanRequest request = new MoversUpdatePlanRequest();
		String response="{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"Movers\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"contextInfo\":{}}},\"serviceResponse\":{\"context\":{\"caseId\":\"MOV-12825602-C01\",\"contextInfo\":{\"processStep\":\"OrderReview-Shipping-Payment-Agreement\",\"callReason\":\"FiveGMovers\"},\"customerInfo\":{\"accountNumber\":\"0526690813-00001\"},\"processMTNList\":[{\"mtn\":\"5623201991\",\"completedprocessSteps\":[\"DateSelection\"]}]}}}}";
		MoversUpdatePlanResponse updateResponse = mapper.readValue(response, MoversUpdatePlanResponse.class);
		URI url = URI.create("http://localhost/5g/movers/updateCustomerPlan");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		when(fiveGMoversHelper.updateCustomerMoverPlan(request, httpHeader)).thenReturn(Mono.just(updateResponse));

		Mono<MoversUpdatePlanResponse> responseMono= controller.updateCustomerMoverPlan(httpHeader,null,request);

		StepVerifier.create(responseMono).assertNext(org.junit.Assert::assertNotNull).expectComplete().verify();
	}

	@Test
	public void getMoversRetrieveCartTest1() throws IOException {
		String sampleStringResponse = "{\"moveServiceInfo\":{\"moveInDate\":\"Monday, October 5, 2022\",\"moveOutDate\":\"Monday, October 5, 2022\",\"planName\":\"LTE Home\",\"cart5GAddress\":{\"addressLine1\":\"3035 OAKLAND AVE\",\"city\":\"MINNEAPOLIS\",\"state\":\"MN\",\"zipCode\":\"55407\",\"zipCode4\":\"\",\"countryCode\":\"\",\"fipsCode\":\"2705343000\",\"floor\":0,\"latitude\":\"0.0\",\"longitude\":\"0.0\"}},\"orderDetailsView\":{\"orderNumber\":\"30002647\",\"locationCode\":\"N832101\",\"orderType\":\"PS\"}}";
		FiveGHomeMoversUIResponse response = mapper.readValue(sampleStringResponse, FiveGHomeMoversUIResponse.class);
		GetCartDetailsRequest request = new GetCartDetailsRequest();
		CXPRetrieveCartDataVO data = new CXPRetrieveCartDataVO();
		request.setData(data);
		URI url = URI.create("http://localhost/5g/movers/retrieve-cart");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		MoversRedisData redisData = new MoversRedisData();
		redisData.setCartId("sfg");
		when(redisHelper3.fiveGRedisMoversData()).thenReturn(Mono.just(redisData));
		when(fiveGMoversHelper.getMoversCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(response));
		Mono<FiveGHomeMoversUIResponse> controllerResponse = controller.getMoversRetrieveCart(httpHeader, httpResponse,request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void testAddMoversPlanAndDevice1() throws JsonProcessingException {
		MoversCartRequest request = new MoversCartRequest();
		AddPlanDeviceCartInfo cartInfo = new AddPlanDeviceCartInfo();
		cartInfo.setClientAppName("VZW-DOTCOM");
		request.setCartInfo(cartInfo);
		URI url = URI.create("http://localhost/5g/movers/updateCart");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
		String pegaCallResponse = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"Movers\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"cartInfo\":{\"cartId\":\"c34829d0-8ba2-41a6-8712-9d9d442d3a4e\",\"statusMsg\":\"Success\",\"lines\":[{\"mtn\":\"2404298668\",\"sortingNumber\":0,\"lineId\":\"2404298668\",\"status\":1,\"planValidationFailed\":false,\"lineActivityType\":\"ACC\",\"devicePlanCompatible\":false,\"fiveGUpSell\":false,\"planQualifiedForPromotion\":false,\"displayHumWiFi\":false,\"downPaymentAmtApplied\":0,\"firstMonthInstallment\":0,\"fiveGPlanAdded\":false,\"fiveGMUCEligible\":false,\"isAppendedLine\":false,\"isDeviceSelected\":false,\"showGlobalChoiceOffer\":false,\"amRole\":\"\",\"protectionNotRequired\":false,\"networkBandwidthTypeChanged\":false,\"lacWithNumberShare\":false,\"activateSecDeviceNumShareElig\":false,\"numberShareOverlay\":false,\"gs4Device\":false,\"rioDevice\":false,\"simCompatibility\":false,\"eSimCapable\":false,\"totalDueMonthly\":0,\"planTradeInEligible\":false,\"userSelectedPlan\":false,\"monthlyInstallment\":0,\"ltehomeLine\":false,\"is5GBoltEligible\":false,\"is5GDevice\":false}],\"preAuthSuccess\":false,\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"financeLimitExceeded\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":0,\"agreementNumber\":0,\"expressCheckout\":false,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"validateOrderStatus\":false,\"subscriptionInfos\":[],\"showIntercept\":false,\"instantCreditEligible\":false,\"instantCreditValue\":0,\"showICPage\":false,\"preConfiguredCartType\":\"BAU\",\"preConfiguredCartTypeDuringAddDevice\":\"BAU\",\"cartItemCount\":0,\"numOfLinesWithDevices\":0,\"totalDueToday\":29.99,\"totalDueMonthly\":0,\"planSelectionRequired\":false,\"creditApplicationNum\":0,\"showGlobalChoiceOffer\":false,\"deviceCount\":0,\"affirmPaymentComplete\":false,\"upcomingAppointmentsAvailable\":false,\"relinquishTradeAmount\":0,\"emptyLine\":false,\"isRemoveTradeIn\":false},\"contextInfo\":{\"availablePaths\":[{\"path\":\"DateSelection\"}],\"processAction\":\"\",\"processStep\":\"DateSelection\",\"callReason\":\"Movers\"},\"caseId\":\"MOV-8826026-C01\",\"customerInfo\":{\"cartCreator\":\"POE-D-3b43852a-9ff8-4e9b-aa28-9d8ed3daab05\",\"processingMTN\":\"1234567890\",\"accountNumber\":\"\"},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]}]}}}}";
		AddPlanAndDevicePEGAResponse addPlanAndDevicePEGAResponse = mapper.readValue(pegaCallResponse,AddPlanAndDevicePEGAResponse.class);
		when(fiveGMoversHelper.addMoversPlanAndDevice(Mockito.any(), Mockito.any())).thenReturn(Mono.just(addPlanAndDevicePEGAResponse));
		Mono<AddPlanAndDevicePEGAResponse> addPlanAndDevicePEGAResponseMono  = controller.addMoversPlanAndDevice(httpHeader,null,request);
		StepVerifier.create(addPlanAndDevicePEGAResponseMono).assertNext(res -> Assert.assertNotNull(res)).expectComplete().verify();
	}

}