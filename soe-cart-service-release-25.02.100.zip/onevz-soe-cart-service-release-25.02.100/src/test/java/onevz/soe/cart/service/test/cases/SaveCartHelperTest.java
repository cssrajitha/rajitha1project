package onevz.soe.cart.service.test.cases;

import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import onevz.soe.cart.model.quote.QuotePrices;
import onevz.soe.cart.model.saveCart.AddressInfo;
import onevz.soe.cart.model.saveCart.CartDetails;
import onevz.soe.cart.model.saveCart.UpdateLead;
import onevz.soe.cart.responses.QuotePricingRedisData;
import onevz.soe.cart.util.FlexV2Util;
import onevz.soe.customerprofile.model.gql.assisted.Customer;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fasterxml.jackson.databind.ObjectMapper;

import onevz.soe.cart.bpm.helper.CartServiceBpmHelper2;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper3;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.helper.SaveCartHelper;
import onevz.soe.cart.helper.UpdateCartHelper;
import onevz.soe.cart.nbx.NBXFeedbackService;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.SaveCartForLaterUIRequest;
import onevz.soe.cart.ui.requests.SaveCartUIRequest;
import onevz.soe.cart.ui.responses.SaveCartUIResponse;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.cradle.CradleAllocator;
import onevz.soe.omnidl.util.DLUtilityService;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { CartServiceTestConfig.class })
//@WebFluxTest(SaveCartHelper.class)
//@SpringBootTest
public class SaveCartHelperTest {

	@Autowired
	private UpdateCartHelper helper;
	
	@Autowired
	private SaveCartHelper saveCartHelper;

	@MockBean
	private CartServiceCxpHelper cxpHelper;
	
	@MockBean
	private CartServiceCXPServices cxpService;

	@MockBean
	private CartServiceBpmHelper2 bpmHelper2;
	
	@MockBean
	private CartServiceBpmHelper3 bpmHelper3;

	@MockBean
	private RedisHelper redisHelper;

	@Autowired
	private ObjectMapper mapper;
	
	@MockBean
	private NBXFeedbackService nbxService;
	
	@MockBean
	private CradleAllocator cradleAllocator;
	
	@Autowired
	SourceFileReaderUtil sourceFileReaderUtil;
	
	@Value("${onevz.soe.cart.test.fileLocation}")
	private String testFileLocation;
	
	@MockBean
	private DLUtilityService dlUtilityService;

	List<String> preorderWhitelistMtnsList = new ArrayList<>();

	UpdateCartHelper csh = new UpdateCartHelper("1234567890,9087654321","Smartphones,Connected Devices,Tablets");



	@Test
	public void saveCartHelperTest() throws IOException, SOEHTTPException {
		String requestFile = "MockSaveCartRequest.json";
		String responseFile = "MockSaveCartResponse.json";
		String redisFile = "MockRedisData.json";
		String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
		String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
		SaveCartUIRequest sampleRequest = null;
		SaveCartUIResponse sampleResponse = null;
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRequest = mapper.readValue(sampleRequestString, SaveCartUIRequest.class);
		sampleResponse = mapper.readValue(sampleResponseString, SaveCartUIResponse.class);
		Mono<SaveCartUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper2.saveCart(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		SaveCartUIResponse expectedResponse = sampleResponse;
		Mono<SaveCartUIResponse> response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}

	@Test
	public void saveCartHelperTestWithoutFlags() throws IOException, SOEHTTPException {
		String requestFile = "MockSaveCartRequestWithoutFlags.json";
		String responseFile = "MockSaveCartResponse.json";
		String redisFile = "MockRedisData.json";
		String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
		String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
		SaveCartUIRequest sampleRequest = null;
		SaveCartUIResponse sampleResponse = null;
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRequest = mapper.readValue(sampleRequestString, SaveCartUIRequest.class);
		sampleResponse = mapper.readValue(sampleResponseString, SaveCartUIResponse.class);
		Mono<SaveCartUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper2.saveCart(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		SaveCartUIResponse expectedResponse = sampleResponse;
		Mono<SaveCartUIResponse> response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}

	@Test
	public void saveCartHelperTest2() throws IOException, SOEHTTPException {
		String requestFile = "MockSaveCartRequest.json";
		String responseFile = "MockSaveCartResponse.json";
		String redisFile = "MockRedisData.json";
		String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
		String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
		SaveCartUIRequest sampleRequest = null;
		SaveCartUIResponse sampleResponse = null;
		//CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		CartRedisData sampleRedisData = new CartRedisData();
		sampleRequest = mapper.readValue(sampleRequestString, SaveCartUIRequest.class);
		sampleResponse = mapper.readValue(sampleResponseString, SaveCartUIResponse.class);
		Mono<SaveCartUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper2.saveCart(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		SaveCartUIResponse expectedResponse = sampleResponse;
		Mono<SaveCartUIResponse> response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}

	@Test
	public void saveCartHelperTest3() throws IOException, SOEHTTPException {
		String requestFile = "MockSaveCartEUPRequest.json";
		String responseFile = "MockSaveCartResponse.json";
		String redisFile = "MockRedisData.json";
		String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
		String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
		SaveCartUIRequest sampleRequest = null;
		SaveCartUIResponse sampleResponse = null;
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRequest = mapper.readValue(sampleRequestString, SaveCartUIRequest.class);
		sampleResponse = mapper.readValue(sampleResponseString, SaveCartUIResponse.class);
		sampleRequest.getCartInfo().setCartId("");
		Mono<SaveCartUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper2.saveCart(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		SaveCartUIResponse expectedResponse = sampleResponse;
		Mono<SaveCartUIResponse> response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}

	@Test
	public void saveCartHelperTest4() throws IOException, SOEHTTPException {
		String requestFile = "MockSaveCartNSEAssistedRequest.json";
		String responseFile = "MockSaveCartResponse.json";
		String redisFile = "MockRedisData.json";
		String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
		String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
		SaveCartUIRequest sampleRequest = null;
		SaveCartUIResponse sampleResponse = null;
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRequest = mapper.readValue(sampleRequestString, SaveCartUIRequest.class);
		sampleResponse = mapper.readValue(sampleResponseString, SaveCartUIResponse.class);
		sampleRequest.getCartInfo().setCartId("");
		Mono<SaveCartUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper2.saveCart(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		SaveCartUIResponse expectedResponse = sampleResponse;
		Mono<SaveCartUIResponse> response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}

	@Test
	public void saveCartHelperTest5() throws IOException, SOEHTTPException {
		String requestFile = "MockSaveCartEnforceDigitalRequest.json";
		String responseFile = "MockSaveCartResponse.json";
		String redisFile = "MockRedisData.json";
		String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
		String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
		SaveCartUIRequest sampleRequest = null;
		SaveCartUIResponse sampleResponse = null;
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRequest = mapper.readValue(sampleRequestString, SaveCartUIRequest.class);
		sampleResponse = mapper.readValue(sampleResponseString, SaveCartUIResponse.class);
		sampleRedisData.setProcessingMTN("9876543212");
		sampleRequest.getCartInfo().setCartId("");
		Mono<SaveCartUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper2.saveCart(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		SaveCartUIResponse expectedResponse = sampleResponse;
		Mono<SaveCartUIResponse> response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}

	@Test
	public void saveCartForLaterHelperTest() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-514162-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"GridWallPDP\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addBuyOutAmt\"},\"customerInfo\":{\"accountNumber\":\"0100007530-00001\",\"cartCreator\":\"4125102507\"},\"cartInfo\":{\"cartId\":\"8ab56dcb-4268-4ea8-99f2-99955effe2cd\",\"statusCode\":\"0\",\"statusMsg\":\"Success\"}}}}}";
		SaveCartForLaterUIRequest sampleRequest = null;
		SaveCartUIResponse sampleResponse = null;
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRequest = mapper.readValue(sampleRequestString, SaveCartForLaterUIRequest.class);
		sampleResponse = mapper.readValue(sampleResponseString, SaveCartUIResponse.class);
		Mono<SaveCartUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.saveCartForLater(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		SaveCartUIResponse expectedResponse = sampleResponse;
		Mono<SaveCartUIResponse> response = saveCartHelper.saveCartForLater(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}

	@Test
	public void saveCartForLaterHelperTest2() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-514162-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"GridWallPDP\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addBuyOutAmt\"},\"customerInfo\":{\"accountNumber\":\"0100007530-00001\",\"cartCreator\":\"4125102507\"},\"cartInfo\":{\"cartId\":\"8ab56dcb-4268-4ea8-99f2-99955effe2cd\",\"statusCode\":\"0\",\"statusMsg\":\"Success\"}}}}}";
		SaveCartForLaterUIRequest sampleRequest = null;
		SaveCartUIResponse sampleResponse = null;
		//String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		//CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		CartRedisData sampleRedisData = new CartRedisData();
		sampleRequest = mapper.readValue(sampleRequestString, SaveCartForLaterUIRequest.class);
		sampleResponse = mapper.readValue(sampleResponseString, SaveCartUIResponse.class);
		Mono<SaveCartUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.saveCartForLater(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		SaveCartUIResponse expectedResponse = sampleResponse;
		Mono<SaveCartUIResponse> response = saveCartHelper.saveCartForLater(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}

	@Test
	public void saveCartForLaterHelperTest3() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"\",\"processStep\":\"OrderReview-Shipping\",\"intendType\":\"AAL\"}}";
		String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-NETACE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-514162-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"GridWallPDP\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addBuyOutAmt\"},\"customerInfo\":{\"accountNumber\":\"0100007530-00001\",\"cartCreator\":\"4125102507\"},\"cartInfo\":{\"cartId\":\"8ab56dcb-4268-4ea8-99f2-99955effe2cd\",\"statusCode\":\"0\",\"statusMsg\":\"Success\"}}}}}";
		SaveCartForLaterUIRequest sampleRequest = null;
		SaveCartUIResponse sampleResponse = null;
		//String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		//CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		CartRedisData sampleRedisData = new CartRedisData();
		sampleRequest = mapper.readValue(sampleRequestString, SaveCartForLaterUIRequest.class);
		sampleResponse = mapper.readValue(sampleResponseString, SaveCartUIResponse.class);
		Mono<SaveCartUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.saveCartForLater(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		SaveCartUIResponse expectedResponse = sampleResponse;
		Mono<SaveCartUIResponse> response = saveCartHelper.saveCartForLater(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void saveCartHelperNSETest() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"itemType\":\"SAVE-FOR-LATER\",\"processStep\":\"ShoppingCart\",\"processAction\":\"saveForLater\",\"intendType\":\"\"},\"data\":{\"lines\":[{\"mtn\":\"newLine1\"}]}}";
		String sampleResponseString = "{\"serviceHeader\": {\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"correlationId\":\"soe-cart-2022.07.12.14.52.53-970.2567167617408\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\": {\"serviceResponse\":{\"context\":{\"cartInfo\":{\"statusMsg\":\"\",\"cartId\":\"\",\"statusCode\":\"0\"},\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"}],\"processAction\":\"ShoppingCart\",\"processStep\":\"ShoppingCart\",\"callReason\":\"SalesOrderPurchase\"},\"caseId\":\"SOP-7616727-E01\",\"customerInfo\":{\"cartCreator\":\"POW-D-1896580b-600a-4561-925e-074f9b702b6d\",\"processingMTN\":\"newLine1\",\"accountNumber\":\"\"},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"ShoppingCart\"]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"ShoppingCart\"]}]}}}}\n" +
				"\t";
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"intendType\" : \"NSE\"}";
		SaveCartForLaterUIRequest sampleRequest = null;
		SaveCartUIResponse sampleResponse = null;
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRequest = mapper.readValue(sampleRequestString, SaveCartForLaterUIRequest.class);
		sampleResponse = mapper.readValue(sampleResponseString, SaveCartUIResponse.class);
		sampleRequest.getCartInfo().setCartId("");
		Mono<SaveCartUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.saveCartForLater(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		Mono<SaveCartUIResponse> response = saveCartHelper.saveCartForLater(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
	}
	
	@Test
	public void saveCartHelperTest6() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"enforceData\": {},\"cartInfo\": {\"intendType\": \"NSEBYOD\"}}";
		String sampleResponseString = "{}";
		String redisDataString = "{}";
		SaveCartUIRequest sampleRequest = mapper.readValue(sampleRequestString, SaveCartUIRequest.class);
		SaveCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, SaveCartUIResponse.class);
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRedisData.setProcessingMTN("9876543212");
		sampleRequest.getCartInfo().setCartId("");
		when(bpmHelper2.saveCart(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		Mono<SaveCartUIResponse> response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	 
	@Test
	public void saveCartHelperTest7() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\": \"OMNI-INDIRECT\",\"cartInfo\": {\"intendType\": \"NSE\"}}";
		String sampleResponseString = "{}";
		String redisDataString = "{\"processingMTN\": \"mtn\"}";
		SaveCartUIRequest sampleRequest = mapper.readValue(sampleRequestString, SaveCartUIRequest.class);
		SaveCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, SaveCartUIResponse.class);
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRedisData.setProcessingMTN("9876543212");
		sampleRequest.getCartInfo().setCartId("");
		when(bpmHelper2.saveCart(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		Mono<SaveCartUIResponse> response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void saveCartHelperTest8() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"enforceData\": {},\"channelId\": \"OMNI-INDIRECT\",\"cartInfo\": {\"intendType\": \"NSE\"}}";
		String sampleResponseString = "{}";
		String redisDataString = "{\"processingMTN\": \"mtn\",\"creditAppNum\": \"credit\"}";
		SaveCartUIRequest sampleRequest = mapper.readValue(sampleRequestString, SaveCartUIRequest.class);
		SaveCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, SaveCartUIResponse.class);
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRedisData.setProcessingMTN("9876543212");
		sampleRequest.getCartInfo().setCartId("");
		when(bpmHelper2.saveCart(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		Mono<SaveCartUIResponse> response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void saveCartHelperTest9() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"enforceData\": {},\"channelId\": \"VZW-MFA\",\"cartInfo\": {\"intendType\": \"AAL\"}}";
		String sampleResponseString = "{}";
		String redisDataString = "{\"processingMTN\": \"mtn\"}";
		SaveCartUIRequest sampleRequest = mapper.readValue(sampleRequestString, SaveCartUIRequest.class);
		SaveCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, SaveCartUIResponse.class);
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRedisData.setProcessingMTN("9876543212");
		sampleRequest.getCartInfo().setCartId("");
		when(bpmHelper2.saveCart(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		Mono<SaveCartUIResponse> response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void saveCartHelperTest10() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"enforceData\":{},\"channelId\": \"VZW-MFA\",\"cartInfo\": {\"intendType\": \"AAL\"}}";
		String sampleResponseString = "{}";
		String redisDataString = "{\"mtn\": \"mtn\",\"cartCreator\": \"cart\"}";
		SaveCartUIRequest sampleRequest = mapper.readValue(sampleRequestString, SaveCartUIRequest.class);
		SaveCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, SaveCartUIResponse.class);
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRedisData.setProcessingMTN("9876543212");
		sampleRequest.getCartInfo().setCartId("");
		when(bpmHelper2.saveCart(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		Mono<SaveCartUIResponse> response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void saveCartHelperTest11() throws IOException, SOEHTTPException {
		String requestFile = "MockSaveCartRequest.json";
		String responseFile = "MockSaveCartResponse.json";
		String redisFile = "MockRedisData.json";
		String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
		String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
		SaveCartUIRequest sampleRequest = null;
		SaveCartUIResponse sampleResponse = null;
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);

		QuotePricingRedisData quoteRedis = new QuotePricingRedisData();
		List<QuotePrices> quotePriceList = new ArrayList<>();
		QuotePrices quotePrice1 = new QuotePrices();
		quotePrice1.setCartId("36fd7aa9-eda1-4a3b-9849-1867853997b7");
		quotePrice1.setCaseId("SOP-12152288-C01");
		quotePrice1.setQuoteId("0001");
		quotePriceList.add(quotePrice1);
		QuotePrices quotePrice2 = new QuotePrices();
		quotePrice2.setCartId("c2cb71dd-ca5b-46f8-81ad-e34ca50b2925");
		quotePrice2.setCaseId("SOP-12152556-C01");
		quotePriceList.add(quotePrice2);
		quoteRedis.setQuotePrices(quotePriceList);
		sampleRedisData.setQuotePricingValues(quoteRedis);

		sampleRequest = mapper.readValue(sampleRequestString, SaveCartUIRequest.class);
		sampleResponse = mapper.readValue(sampleResponseString, SaveCartUIResponse.class);
		Mono<SaveCartUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper2.saveCart(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		SaveCartUIResponse expectedResponse = sampleResponse;
		Mono<SaveCartUIResponse> response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}

	@Test
	public void saveCartHelperEmailIdTest() throws IOException, SOEHTTPException {
		String requestFile = "MockSaveCartRequest.json";
		String responseFile = "MockSaveCartResponse.json";
		String redisFile = "MockRedisData.json";
		String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
		String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
		SaveCartUIRequest sampleRequest = null;
		SaveCartUIResponse sampleResponse = null;
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRequest = mapper.readValue(sampleRequestString, SaveCartUIRequest.class);
		sampleResponse = mapper.readValue(sampleResponseString, SaveCartUIResponse.class);

		sampleRequest.getCartInfo().setSaveCartEmailId("");
		sampleRedisData.setSaveCartEmailId("test.qa@test.com");

		Mono<SaveCartUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper2.saveCart(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		SaveCartUIResponse expectedResponse = sampleResponse;
		Mono<SaveCartUIResponse> response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}
	@Test
	public void saveCartHelperFlexv2Test_cart() throws IOException {
		String requestFile = "MockSaveCartRequest_flexv2.json";
		String responseFile = "MockSaveCartResponse.json";
		String redisFile = "MockRedisData_flexv2.json";
		String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
		String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
		SaveCartUIRequest sampleRequest = null;
		SaveCartUIResponse sampleResponse = null;
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRequest = mapper.readValue(sampleRequestString, SaveCartUIRequest.class);
		sampleResponse = mapper.readValue(sampleResponseString, SaveCartUIResponse.class);

		sampleRequest.getCartInfo().setFlexV2(true);
		UpdateLead updLead =  sampleRequest.getData().getUpdateLead();
		Mono<SaveCartUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper2.saveCart(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		SaveCartUIResponse expectedResponse = sampleResponse;
		Mono<SaveCartUIResponse> response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		List<CartDetails> cartDetails = new ArrayList<>();
		updLead.setCartDetails(cartDetails);
		Arrays.stream(sampleRedisData.getRetrieveCart().getCart().getLineDetails().getLineInfo())
				.forEach(x-> Arrays.stream(x.getItemsInfo())
						.forEach(y-> Arrays.stream(y.getCartItems().getCartItem()).forEach(z->z.setProductId(null))));
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		updLead.setCartDetails(cartDetails);
		Arrays.stream(sampleRedisData.getRetrieveCart().getCart().getLineDetails().getLineInfo())
				.forEach(x-> Arrays.stream(x.getItemsInfo())
						.forEach(y-> Arrays.stream(y.getCartItems().getCartItem()).forEach(z->z.setProductId(""))));

		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		updLead.setCartDetails(cartDetails);
		Arrays.stream(sampleRedisData.getRetrieveCart().getCart().getLineDetails().getLineInfo())
				.forEach(x-> Arrays.stream(x.getItemsInfo())
						.forEach(y-> Arrays.stream(y.getCartItems().getCartItem()).forEach(z->z.setCartItemType("ACCESSORY"))));
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		updLead.setCartDetails(cartDetails);
		Arrays.stream(sampleRedisData.getRetrieveCart().getCart().getLineDetails().getLineInfo())
				.forEach(x-> Arrays.stream(x.getItemsInfo())
						.forEach(y-> Arrays.stream(y.getCartItems().getCartItem()).forEach(z->z.setCartItemType("SIM"))));
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
		updLead.setCartDetails(cartDetails);
		Arrays.stream(sampleRedisData.getRetrieveCart().getCart().getLineDetails().getLineInfo())
				.forEach(x-> Arrays.stream(x.getItemsInfo())
						.forEach(y-> Arrays.stream(y.getCartItems().getCartItem()).forEach(z->z.setCartItemType(null))));
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		updLead.setCartDetails(cartDetails);
		Arrays.stream(sampleRedisData.getRetrieveCart().getCart().getLineDetails().getLineInfo())
				.forEach(x-> Arrays.stream(x.getItemsInfo()).forEach(y->y.getCartItems().setCartItem(null)));
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		updLead.setCartDetails(cartDetails);
		Arrays.stream(sampleRedisData.getRetrieveCart().getCart().getLineDetails().getLineInfo())
				.forEach(x-> Arrays.stream(x.getItemsInfo()).forEach(y->y.setCartItems(null)));
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		updLead.setCartDetails(cartDetails);
		Arrays.stream(sampleRedisData.getRetrieveCart().getCart().getLineDetails().getLineInfo())
				.forEach(x->x.setItemsInfo(null));
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		updLead.setCartDetails(cartDetails);
		Arrays.stream(sampleRedisData.getRetrieveCart().getCart().getLineDetails().getLineInfo()).forEach(lineinfo-> {
			lineinfo.getServiceInfo().getNewPricePlanInfo().setPricePlanCode(null);
			lineinfo.getMtnDetails().setMobileNumber(null);
		});
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		updLead.setCartDetails(cartDetails);
		Arrays.stream(sampleRedisData.getRetrieveCart().getCart().getLineDetails().getLineInfo()).forEach(lineinfo-> {
			lineinfo.getServiceInfo().setNewPricePlanInfo(null);
			lineinfo.setMtnDetails(null);
		});
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		updLead.setCartDetails(cartDetails);
		Arrays.stream(sampleRedisData.getRetrieveCart().getCart().getLineDetails().getLineInfo()).forEach(lineinfo-> {
			lineinfo.setServiceInfo(null);		});
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		updLead.setCartDetails(cartDetails);
		try(MockedStatic<FlexV2Util> utils=Mockito.mockStatic(FlexV2Util.class)){
			utils.when(()->FlexV2Util.isCartHasLine(Mockito.any())).thenReturn(true);
		}
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		updLead.setCartDetails(cartDetails);
		try(MockedStatic<FlexV2Util> utils=Mockito.mockStatic(FlexV2Util.class)){
			utils.when(()->FlexV2Util.isCartHasLine(Mockito.any())).thenReturn(false);
		}
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		updLead.setCartDetails(cartDetails);
		sampleRedisData.setRetrieveCart(null);
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		updLead.setCartDetails(cartDetails);
		sampleRedisData.setIntendType("AAL");
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}
	@Test
	public void saveCartHelperFlexv2_custProf() throws IOException {
		String requestFile = "MockSaveCartRequest_flexv2.json";
		String responseFile = "MockSaveCartResponse.json";
		String redisFile = "MockRedisData_flexv2_3.json";
		String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
		String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
		SaveCartUIRequest sampleRequest = null;
		SaveCartUIResponse sampleResponse = null;
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRequest = mapper.readValue(sampleRequestString, SaveCartUIRequest.class);
		sampleResponse = mapper.readValue(sampleResponseString, SaveCartUIResponse.class);

		sampleRequest.getCartInfo().setFlexV2(true);

		Mono<SaveCartUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper2.saveCart(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		SaveCartUIResponse expectedResponse = sampleResponse;
		Mono<SaveCartUIResponse> response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

//		sampleRedisData.setLocationCode(null);
//		response = saveCartHelper.saveCart(sampleRequest);
//		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
//				.verify();
//		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
//				.verify();

		Customer customer = sampleRedisData.getCustomerProfile().getData().getCustomer();
		sampleRequest.getData().setZipCode(null);
		customer.getAddress().setZipCode(null);
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRequest.getData().setZipCode("07739");
		customer.getAddress().setAddressLine2(null);
		customer.getAddress().setAddressLine1(null);
		customer.getAddress().setCity(null);
		customer.getAddress().setState(null);
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRequest.getData().getUpdateLead().setAddressInfo(null);
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		AddressInfo addressInfo = new AddressInfo();
		sampleRequest.getData().getUpdateLead().setAddressInfo(addressInfo);
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
		sampleRequest.getData().setCustomerName("");
		customer.getCustomerName().setLastName(null);
		customer.getCustomerName().setFirstName(null);
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRequest.getData().setUpdateLead(null);
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRedisData.getCustomerProfile().getData().getCustomer().setAddress(null);
		sampleRedisData.getCustomerProfile().getData().getCustomer().setCustomerName(null);
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();


		sampleRedisData.getCustomerProfile().getData().setCustomer(null);
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRedisData.getCustomerProfile().setData(null);
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRedisData.setCustomerProfile(null);
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
		sampleRequest.getData().setUpdateLead(null);
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRequest.setData(null);
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRequest.getCartInfo().setFlexV2(false);
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}

	@Test
	public void saveCartHelperFlexv2_flag() throws IOException {
		String requestFile = "MockSaveCartRequest_flexv2.json";
		String responseFile = "MockSaveCartResponse.json";
		String redisFile = "MockRedisData_flexv2_3.json";
		String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
		String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
		SaveCartUIRequest sampleRequest = null;
		SaveCartUIResponse sampleResponse = null;
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRequest = mapper.readValue(sampleRequestString, SaveCartUIRequest.class);
		sampleResponse = mapper.readValue(sampleResponseString, SaveCartUIResponse.class);

		sampleRequest.getCartInfo().setFlexV2(false);

		Mono<SaveCartUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper2.saveCart(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		SaveCartUIResponse expectedResponse = sampleResponse;
		Mono<SaveCartUIResponse> response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRequest.getData().setUpdateLead(null);
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRequest.setData(null);
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}

	@Test
	public void saveCartHelperFlexv2_intendType() throws IOException {
		String requestFile = "MockSaveCartRequest_flexv2.json";
		String responseFile = "MockSaveCartResponse.json";
		String redisFile = "MockRedisData_flexv2_1.json";
		String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
		String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
		SaveCartUIRequest sampleRequest = null;
		SaveCartUIResponse sampleResponse = null;
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRequest = mapper.readValue(sampleRequestString, SaveCartUIRequest.class);
		sampleResponse = mapper.readValue(sampleResponseString, SaveCartUIResponse.class);

		sampleRequest.getCartInfo().setFlexV2(true);
		Mono<SaveCartUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper2.saveCart(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		SaveCartUIResponse expectedResponse = sampleResponse;
		Mono<SaveCartUIResponse> response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRequest.getCartInfo().setIntendType("");
		Arrays.stream(sampleRedisData.getRetrieveCart().getCart().getLineDetails().getLineInfo()).forEach(x->
		{
			x.setLineActivityType(null);
			Arrays.stream(x.getItemsInfo()).forEach(y-> Arrays.stream(y.getCartItems().getCartItem()).forEach(z->z.setCartItemType("SIM")));
		});
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRequest.getCartInfo().setIntendType("");
		sampleRedisData.getRetrieveCart().getCart().getLineDetails().setLineInfo(null);
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRequest.getCartInfo().setIntendType("");
		sampleRedisData.getRetrieveCart().getCart().setLineDetails(null);
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRequest.getCartInfo().setIntendType("");
		sampleRedisData.getRetrieveCart().setCart(null);
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRequest.getCartInfo().setIntendType("");
		sampleRedisData.setRetrieveCart(null);
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRequest.getCartInfo().setIntendType("");
		sampleRedisData.setFlow("RF");
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRequest.getCartInfo().setIntendType("");
		sampleRedisData.setFlow("EXISTING");
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRequest.getCartInfo().setIntendType("");
		sampleRedisData.setFlow(null);
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRequest.getCartInfo().setIntendType("");
		sampleRequest.getCartInfo().setIntendType(null);
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRequest.getCartInfo().setIntendType("");
		sampleRedisData.setCustomerType("N");
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRequest.getCartInfo().setIntendType("");
		sampleRedisData.setCustomerType("E");
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRequest.getCartInfo().setIntendType("");
		sampleRedisData.setCustomerType("");
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRequest.getCartInfo().setIntendType("");
		sampleRedisData.setCustomerType(null);
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRequest.getCartInfo().setIntendType("");
		sampleRedisData.setIntendType("AAL");
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

	}

	@Test
	public void saveCartHelperFlexv2_Updatelead() throws IOException {
		String requestFile = "MockSaveCartRequest_flexv2.json";
		String responseFile = "MockSaveCartResponse.json";
		String redisFile = "MockRedisData_flexv2_4.json";
		String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
		String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
		SaveCartUIRequest sampleRequest = null;
		SaveCartUIResponse sampleResponse = null;
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRequest = mapper.readValue(sampleRequestString, SaveCartUIRequest.class);
		sampleResponse = mapper.readValue(sampleResponseString, SaveCartUIResponse.class);

		sampleRequest.getCartInfo().setFlexV2(true);
		Mono<SaveCartUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper2.saveCart(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		SaveCartUIResponse expectedResponse = sampleResponse;
		Mono<SaveCartUIResponse> response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRequest.getCartInfo().setIntendType("NSE");
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		UpdateLead updLead = sampleRequest.getData().getUpdateLead();
		sampleRequest.getCartInfo().setIntendType(null);
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRedisData.setRepId("");
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRedisData.setRepId(null);
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		updLead.setECode(null);
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		updLead.setLeadOwner(null);
		sampleRedisData.setLoggedInUser(null);
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		updLead.setLeadOwner("v492759");
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();


		updLead.setEventCategory("");
		sampleRequest.getCartInfo().setIntendType(null);
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		updLead.setStoreId(null);
		sampleRedisData.setLocationCode(null);
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		updLead.setStoreId("2777301");
		response = saveCartHelper.saveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

	}
}
