package onevz.soe.cart.service.test.common;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.helper.DeviceSimValidationService;
import onevz.soe.cart.requests.ProductInquiryEPSRequest;
import onevz.soe.cart.responses.ProductInquiryEPSResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.ProductInquiryUIRequest;
import onevz.soe.cart.ui.responses.ProductInquiryUIResponse;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { CartServiceTestConfig.class })

public class DeviceSimValidationServiceTest {

    @Autowired
    private DeviceSimValidationService service;

    @MockBean
    CartServiceCXPServices cxpServices;
    @Autowired
    private ObjectMapper mapper;

    @Test
    public void processDeviceProductInquiryTest() throws JsonProcessingException {
        String requestJson = "{\"deviceId\": \"350039081484648\",\"iccId\": \"89148000007113280602\"}";
        String expectedJson = "{\"responseSummary\":{\"successCount\":1,\"successfulResponses\":{\"sequenceNumber\":[1]},\"failureCount\": 0,\"failureResponses\":{\"sequenceNumber\":[]}},\"responses\":[{\"sequenceNumber\":1,\"response\":{\"responseHeader\":{\"returnCode\": \"000\",\"returnMessage\":\"Success\"}}}]}";
        ProductInquiryUIRequest sampleRequest =  mapper.readValue(requestJson,ProductInquiryUIRequest.class);
        ProductInquiryEPSResponse expectedResult = mapper.readValue(expectedJson,ProductInquiryEPSResponse.class);
        ProductInquiryEPSRequest epsRequest = null;
        Mono<ProductInquiryEPSResponse> soeResponse = Mono.just(expectedResult);
        ReflectionTestUtils.setField(service, "cartServiceCXPServices", cxpServices);
        Mockito.when(cxpServices.getDeviceProductInquiry(Mockito.any())).thenReturn(soeResponse);
        Mono<ProductInquiryUIResponse> productInquiryResp = service.processDeviceProductInquiry(sampleRequest,"OMNI-TELESALES");
        StepVerifier.create(productInquiryResp).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }
}
