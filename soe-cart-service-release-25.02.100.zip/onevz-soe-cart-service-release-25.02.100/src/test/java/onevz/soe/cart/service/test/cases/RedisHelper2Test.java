package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.helper.RedisHelper2;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.createLine.CreateLineContext;
import onevz.soe.cart.model.deviceSimValidation.DeviceSimValidationUIResponseData;
import onevz.soe.cart.requests.DeviceExchangeRequest;
import onevz.soe.cart.requests.ValidateCartCXPRequest;
import onevz.soe.cart.responses.BbyLocalOrderDetails;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.DualNumber;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.common.AddDeviceData;
import onevz.soe.cart.ui.common.CreateLineData;
import onevz.soe.cart.ui.common.DeviceCartInfo;

import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.AddDeviceUIRequest;
import onevz.soe.cart.ui.requests.AddPlanUIRequest;
import onevz.soe.cart.ui.requests.CreateLineUIRequest;
import onevz.soe.cart.ui.responses.ValidateCartUIResponse;
import onevz.soe.cradle.client.SOECradleDatastoreClient;
import onevz.soe.customerprofile.model.gql.assisted.PerkSPOInfo;
import onevz.soe.exception.SOEException;
import onevz.soe.session.bean.SOELoginSessionBean;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;

import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.*;


@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { CartServiceTestConfig.class })
//@WebFluxTest(RedisHelper2.class)
public class RedisHelper2Test {

    @Autowired
    RedisHelper2 redisHelper2;

    @InjectMocks
    RedisHelper2 redisHelper21;

    @MockBean
    SOELoginSessionBean sessionBean;

    @Autowired
    ObjectMapper mapper;

    @Mock
    SOECradleDatastoreClient soeCradleDatastoreClient;

    @Test
    public void upsertDualNumToRedisTest() throws Exception{
        CreateLineUIRequest request = null;
        CreateLineContext context = null;
        redisHelper2.upsertDualNumToRedis(request, context);

        request= new CreateLineUIRequest();
        redisHelper2.upsertDualNumToRedis(request, context);

        request.setData(new CreateLineData());
        redisHelper2.upsertDualNumToRedis(request, context);

        request.getData().setLines(new ArrayList<>());
        redisHelper2.upsertDualNumToRedis(request, context);

        List<Lines> lines = new ArrayList<>();
        lines.add(null);
        request.getData().setLines(lines);
        redisHelper2.upsertDualNumToRedis(request, context);

        lines = new ArrayList<>();
        Lines line=new Lines();
        lines.add(line);
        request.getData().setLines(lines);
        redisHelper2.upsertDualNumToRedis(request, context);

        lines = new ArrayList<>();
        Lines line1=new Lines();
        line1.setSecondNumber(new SecondNumber());
        lines.add(line1);
        request.getData().setLines(lines);
        redisHelper2.upsertDualNumToRedis(request, context);

        lines = new ArrayList<>();
        line1.setIsSecondNumber(null);
        lines.add(line1);
        request.getData().setLines(lines);
        redisHelper2.upsertDualNumToRedis(request, context);

        lines = new ArrayList<>();
        line1.setIsSecondNumber(false);
        lines.add(line1);
        request.getData().setLines(lines);
        redisHelper2.upsertDualNumToRedis(request, context);

        lines = new ArrayList<>();
        line1.setIsSecondNumber(true);
        lines.add(line1);
        request.getData().setLines(lines);
        redisHelper2.upsertDualNumToRedis(request, context);

        lines = new ArrayList<>();
        line1.setPrimaryMtn(null);
        lines.add(line1);
        request.getData().setLines(lines);
        redisHelper2.upsertDualNumToRedis(request, context);

        lines = new ArrayList<>();
        line1.setPrimaryMtn("");
        lines.add(line1);
        request.getData().setLines(lines);
        redisHelper2.upsertDualNumToRedis(request, context);

        lines = new ArrayList<>();
        line1.setPrimaryMtn("123");
        lines.add(line1);
        request.getData().setLines(lines);
        redisHelper2.upsertDualNumToRedis(request, context);

        context= new CreateLineContext();
        redisHelper2.upsertDualNumToRedis(request, context);

        context.setCartInfo(new CartServiceCartInfo());
        redisHelper2.upsertDualNumToRedis(request, context);

        context.getCartInfo().setLineNumbers(null);
        redisHelper2.upsertDualNumToRedis(request, context);

        context.getCartInfo().setLineNumbers(new ArrayList<>());
        redisHelper2.upsertDualNumToRedis(request, context);

        List<String> lineNumbers= new ArrayList<>();
        lineNumbers.add("newLine1");
        context.getCartInfo().setLineNumbers(lineNumbers);
        redisHelper2.upsertDualNumToRedis(request, context);

        request.getData().setDualNumber(null);
        redisHelper2.upsertDualNumToRedis(request, context);

        request.getData().setDualNumber(new DualNumber());
        redisHelper2.upsertDualNumToRedis(request, context);

        request.getData().getDualNumber().setSecondNumber(null);
        redisHelper2.upsertDualNumToRedis(request, context);

        request.getData().getDualNumber().setSecondNumber(new ArrayList<>());
        redisHelper2.upsertDualNumToRedis(request, context);

        List<SecondNumber> list = new ArrayList<>();
        list.add(new SecondNumber());
        request.getData().getDualNumber().setSecondNumber(list);
        Assert.assertNotNull(redisHelper2.upsertDualNumToRedis(request, context));
    }

    @Test
    public void readPerkSPOInfoTest() throws Exception {
        when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.just(""));
        StepVerifier.create(redisHelper2.readPerkSPOInfo()).assertNext(resp -> Assert.assertNotNull(resp));

        when(sessionBean.getSessionData(any(), any())).thenReturn(Mono.error(Exception::new));
        StepVerifier.create(redisHelper2.readPerkSPOInfo()).assertNext(resp-> Assert.assertNotNull(resp)).expectError();
    }

    @Test
    public void isPendingCancelFlowTest()throws Exception{
        String request = "{\"cartInfo\":{\"cartCreator\":\"2487651501\",\"processingMTN\":\"2487651501\",\"processStep\":\"PlanSelection\",\"intendType\":\"CPC\"},\"data\":{\"lines\":[{\"mtn\":\"2487651501\",\"addFeatures\":[],\"removeFeatures\":[]},{\"mtn\":\"2487651511\",\"addFeatures\":[{\"id\":\"2640\",\"quantity\":\"1\",\"actionIndicator\":\"Z\",\"type\":\"SPO\",\"pendingCancelCaseID\":\"PRK-86630-E01\"}],\"removeFeatures\":[]},{\"mtn\":\"2487651512\",\"removeFeatures\":[]}],\"parentMtn\":\"\"}}";
        AddPlanUIRequest addPlanUIRequest = mapper.readValue(request, AddPlanUIRequest.class);
        Assert.assertEquals(true,redisHelper2.isPendingCancelFlow(addPlanUIRequest));
        addPlanUIRequest.getData().setLines(new Lines[0]);
        Assert.assertEquals(false,redisHelper2.isPendingCancelFlow(addPlanUIRequest));
        addPlanUIRequest.getData().setLines(null);
        Assert.assertEquals(false,redisHelper2.isPendingCancelFlow(addPlanUIRequest));
        addPlanUIRequest.setData(null);
        Assert.assertEquals(false,redisHelper2.isPendingCancelFlow(addPlanUIRequest));

    }

    @Test
    public void updateRedisPerkSpoInfoTest() throws Exception {
        String request = "{\"cartInfo\":{\"cartCreator\":\"2487651501\",\"processingMTN\":\"2487651501\",\"processStep\":\"PlanSelection\",\"intendType\":\"CPC\"},\"data\":{\"lines\":[{\"mtn\":\"2487651501\",\"addFeatures\":[{\"id\":\"2641\",\"quantity\":\"1\",\"actionIndicator\":\"Z\",\"type\":\"SPO\",\"pendingCancelCaseID\":\"PRK-86630-E01\"}],\"removeFeatures\":[]},{\"mtn\":\"2487651511\",\"addFeatures\":[{\"id\":\"2640\",\"quantity\":\"1\",\"actionIndicator\":\"Z\",\"type\":\"SPO\",\"pendingCancelCaseID\":\"PRK-86630-E01\"}],\"removeFeatures\":[]},{\"mtn\":\"2487651512\",\"addFeatures\":[{\"id\":\"2641\",\"quantity\":\"1\",\"actionIndicator\":\"A\",\"type\":\"SPO\"}],\"removeFeatures\":[]}],\"parentMtn\":\"\"}}";
        String perkSpoInfoRedis = "{\"perkDetailInfo\":[{\"mtn\":\"2487651501\",\"perkDetail\":[{\"spoId\":\"2640\",\"status\":\"SUBSCRIBED\",\"caseId\":\"PRK-70182-E01\",\"cancelEffTimestamp\":\"\",\"isWithin24HoursOfExpiry\":false},{\"spoId\":\"2641\",\"status\":\"PENDING_CANCEL_RESUME\",\"caseId\":\"PRK-86630-E01\",\"cancelEffTimestamp\":\"07/06/23\",\"isWithin24HoursOfExpiry\":false},{\"spoId\":\"2621\",\"status\":\"SUBSCRIBED\",\"caseId\":\"PRK-70180-E01\",\"cancelEffTimestamp\":\"\",\"isWithin24HoursOfExpiry\":false},{\"spoId\":\"2622\",\"status\":\"SUBSCRIBED\",\"caseId\":\"PRK-70181-E01\",\"cancelEffTimestamp\":\"\",\"isWithin24HoursOfExpiry\":false}]},{\"mtn\":\"2487651511\",\"perkDetail\":[{\"spoId\":\"2641\",\"status\":\"SUBSCRIBED\",\"caseId\":\"PRK-70182-E01\",\"cancelEffTimestamp\":\"\",\"isWithin24HoursOfExpiry\":false},{\"spoId\":\"2640\",\"status\":\"PENDING_CANCEL_RESUME\",\"caseId\":\"PRK-86630-E01\",\"cancelEffTimestamp\":\"07/06/23\",\"isWithin24HoursOfExpiry\":false},{\"spoId\":\"2621\",\"status\":\"SUBSCRIBED\",\"caseId\":\"PRK-70180-E01\",\"cancelEffTimestamp\":\"\",\"isWithin24HoursOfExpiry\":false},{\"spoId\":\"2622\",\"status\":\"SUBSCRIBED\",\"caseId\":\"PRK-70181-E01\",\"cancelEffTimestamp\":\"\",\"isWithin24HoursOfExpiry\":false}]},{\"mtn\":\"2487651512\",\"perkDetail\":[{\"spoId\":\"2641\",\"status\":\"SUBSCRIBED\",\"caseId\":\"PRK-70182-E01\",\"cancelEffTimestamp\":\"\",\"isWithin24HoursOfExpiry\":false},{\"spoId\":\"2640\",\"status\":\"PENDING_CANCEL_RESUME\",\"caseId\":\"PRK-86630-E01\",\"cancelEffTimestamp\":\"07/06/23\",\"isWithin24HoursOfExpiry\":false},{\"spoId\":\"2621\",\"status\":\"SUBSCRIBED\",\"caseId\":\"PRK-70180-E01\",\"cancelEffTimestamp\":\"\",\"isWithin24HoursOfExpiry\":false},{\"spoId\":\"2622\",\"status\":\"SUBSCRIBED\",\"caseId\":\"PRK-70181-E01\",\"cancelEffTimestamp\":\"\",\"isWithin24HoursOfExpiry\":false}]}]}";

        AddPlanUIRequest addPlanUIRequest = mapper.readValue(request, AddPlanUIRequest.class);
        PerkSPOInfo perkSPOInfo = mapper.readValue(perkSpoInfoRedis, PerkSPOInfo.class);

        String perkSpoNew= "{\"perkDetailInfo\":[{\"mtn\":\"2487651501\",\"perkDetail\":[{\"spoId\":\"2640\",\"status\":\"SUBSCRIBED\",\"caseId\":\"PRK-70182-E01\",\"cancelEffTimestamp\":\"\",\"isWithin24HoursOfExpiry\":false},{\"spoId\":\"2621\",\"status\":\"SUBSCRIBED\",\"caseId\":\"PRK-70180-E01\",\"cancelEffTimestamp\":\"\",\"isWithin24HoursOfExpiry\":false},{\"spoId\":\"2622\",\"status\":\"SUBSCRIBED\",\"caseId\":\"PRK-70181-E01\",\"cancelEffTimestamp\":\"\",\"isWithin24HoursOfExpiry\":false}]},{\"mtn\":\"2487651511\",\"perkDetail\":[{\"spoId\":\"2641\",\"status\":\"SUBSCRIBED\",\"caseId\":\"PRK-70182-E01\",\"cancelEffTimestamp\":\"\",\"isWithin24HoursOfExpiry\":false},{\"spoId\":\"2621\",\"status\":\"SUBSCRIBED\",\"caseId\":\"PRK-70180-E01\",\"cancelEffTimestamp\":\"\",\"isWithin24HoursOfExpiry\":false},{\"spoId\":\"2622\",\"status\":\"SUBSCRIBED\",\"caseId\":\"PRK-70181-E01\",\"cancelEffTimestamp\":\"\",\"isWithin24HoursOfExpiry\":false}]},{\"mtn\":\"2487651512\",\"perkDetail\":[{\"spoId\":\"2641\",\"status\":\"SUBSCRIBED\",\"caseId\":\"PRK-70182-E01\",\"cancelEffTimestamp\":\"\",\"isWithin24HoursOfExpiry\":false},{\"spoId\":\"2640\",\"status\":\"PENDING_CANCEL_RESUME\",\"caseId\":\"PRK-86630-E01\",\"cancelEffTimestamp\":\"07/06/23\",\"isWithin24HoursOfExpiry\":false},{\"spoId\":\"2621\",\"status\":\"SUBSCRIBED\",\"caseId\":\"PRK-70180-E01\",\"cancelEffTimestamp\":\"\",\"isWithin24HoursOfExpiry\":false},{\"spoId\":\"2622\",\"status\":\"SUBSCRIBED\",\"caseId\":\"PRK-70181-E01\",\"cancelEffTimestamp\":\"\",\"isWithin24HoursOfExpiry\":false}]}]}";
        PerkSPOInfo perkSPOInfoNew = mapper.readValue(perkSpoNew, PerkSPOInfo.class);
        Map sessionData= new HashMap();
        sessionData.put(CartConstants.PERK_SPO_INFO,perkSPOInfoNew);
        when(sessionBean.setSessionData(sessionData)).thenReturn(Mono.just(Boolean.TRUE));
        StepVerifier.create(redisHelper2.updatePerkSpoInfoInRedis(Mono.just(addPlanUIRequest), Mono.just(perkSPOInfo))).expectError().verify();

        addPlanUIRequest.getData().setLines(new Lines[0]);
        StepVerifier.create(redisHelper2.updatePerkSpoInfoInRedis(Mono.just(addPlanUIRequest), Mono.just(perkSPOInfo))).expectError().verify();

        addPlanUIRequest.getData().setLines(null);
        StepVerifier.create(redisHelper2.updatePerkSpoInfoInRedis(Mono.just(addPlanUIRequest), Mono.just(perkSPOInfo))).expectError().verify();

        addPlanUIRequest.setData(null);
        StepVerifier.create(redisHelper2.updatePerkSpoInfoInRedis(Mono.just(addPlanUIRequest), Mono.just(perkSPOInfo))).expectError().verify();

    }

    @Test
    public void DualNumber() throws JsonProcessingException {
        String dualNum = "dualNumber";
        Map<String, String> sessionData = new HashMap<String, String>();
        sessionData.put("6692200515", "35.00");
        String dualNumber = "{ \"secondNumber\": [ { \"isSecondNumber\": true, \"primaryMtn\": \"newLine1\", \"secondMtn\": \"newLine1\" } ] }";
        DualNumber DualNumberData = mapper.readValue(dualNumber, DualNumber.class);
        when(sessionBean.setSessionData(dualNum,DualNumberData)).thenReturn( Mono.empty());
        redisHelper2.upsertDualNumberInSession(DualNumberData);
        //StepVerifier.create(redisHelper.getDataFromRedis()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }
    @Test
    public void realAgentCodeUpsertTest() {
        when(sessionBean.setSessionData(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        StepVerifier.create(redisHelper2.upsertrealAgentCodeSession("911")).expectSubscription();
    }


    @Test
    public void updateBByOrderDetailsTest() {

        AddDeviceUIRequest request = new AddDeviceUIRequest();
        CartRedisData data = new CartRedisData();
        DeviceCartInfo deviceCartInfo = new DeviceCartInfo();
        data.setLocationSubType("GN");
        data.setMaid("BBX");
        AddDeviceData addDeviceData = new AddDeviceData();
        List<Lines> lines = new ArrayList<>();
        Lines lines1 = new Lines();
        Device device = new Device();
        device.setUpc("");
        device.setPriceId("");
        deviceCartInfo.setMasterAgentId(null);
        deviceCartInfo.setOrderLocation(null);
        deviceCartInfo.setOutletId(null);
        lines1.setDevice(device);
        lines.add(lines1);
        addDeviceData.setLines(lines);
        request.setData(addDeviceData);
        request.setCartInfo(deviceCartInfo);
        when(sessionBean.setSessionData(any())).thenReturn(Mono.just(Boolean.TRUE));
        redisHelper2.updateBByOrderDetails(request,data);
        request.getData().getLines().get(0).getDevice().setUpc("1234");
        request.getData().getLines().get(0).getDevice().setPriceId("123");
        Mono<Boolean> booleanMono = redisHelper2.updateBByOrderDetails(request,data);
        StepVerifier.create(booleanMono).assertNext(Assert::assertTrue).expectComplete().verify();

        request.getCartInfo().setOrderLocation("0026301");
        request.getCartInfo().setMasterAgentId("123");
        request.getCartInfo().setOutletId("12345");
        Mono<Boolean> booleanMono1 = redisHelper2.updateBByOrderDetails(request,data);
        StepVerifier.create(booleanMono1).assertNext(Assert::assertTrue).expectComplete().verify();
        request.getCartInfo().setOrderLocation("");
        request.getCartInfo().setMasterAgentId("");
        request.getCartInfo().setOutletId("");
        Mono<Boolean> booleanMono2 = redisHelper2.updateBByOrderDetails(request,data);
        StepVerifier.create(booleanMono2).assertNext(Assert::assertTrue).expectComplete().verify();
        data.setMaid("BBX1");
        redisHelper2.updateBByOrderDetails(request,data);
        data.setMaid(null);
        redisHelper2.updateBByOrderDetails(request,data);
        data.setLocationSubType("GN1");
        redisHelper2.updateBByOrderDetails(request,data);
        data.setLocationSubType(null);
        redisHelper2.updateBByOrderDetails(request,data);
        data.setPriceId("priceId");
        redisHelper2.updateBByOrderDetails(request,data);
        data.setPriceId(null);
        redisHelper2.updateBByOrderDetails(request,data);
        data.setMaid(null);
        redisHelper2.updateBByOrderDetails(request,null);
    }

    @Test
    public void readSoeCradleDataTest() throws Exception{
        ValidateCartCXPRequest request = new ValidateCartCXPRequest();
        String responseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"numOfAccessoryAndDeviceItemsInCart\":0,\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"productId\":\"dev11480004\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
        ValidateCartUIResponse response = mapper.readValue(responseString, ValidateCartUIResponse.class);
        List<String> rtCartCountRes = new ArrayList<>();
        rtCartCountRes.add("10");
        when(soeCradleDatastoreClient.multiReadSessionValues(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(rtCartCountRes));
        request.setRtCartCount(true);
        StepVerifier.create(redisHelper2.readSoeCradleData(request, response)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        request.setRtCartCount(false);
        StepVerifier.create(redisHelper2.readSoeCradleData(request, response)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        request.setRtCartCount(null);
        StepVerifier.create(redisHelper2.readSoeCradleData(request, response)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
//        request=null;
//        StepVerifier.create(redisHelper2.readSoeCradleData(request, response)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        when(soeCradleDatastoreClient.multiReadSessionValues(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.empty());
        request.setRtCartCount(true);
        StepVerifier.create(redisHelper2.readSoeCradleData(request, response)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        when(soeCradleDatastoreClient.multiReadSessionValues(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.error(new SOEException("Cart Data not found")));
        request.setRtCartCount(true);
        StepVerifier.create(redisHelper2.readSoeCradleData(request, response)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }
    @Test
    public void upsertDeviceSimValidationDataIntoRedisTest1(){
        when(sessionBean.setSessionData(any())).thenReturn(Mono.just(true));
        DeviceSimValidationUIResponseData Data = new DeviceSimValidationUIResponseData();
        Data.setIccid("12345678");
        Data.setImei("64676466473");
        Data.setIsSmartphone(true);
        Data.setBbpDefaultZipcodeForTabletFlow("7920");
        Data.setIsEsimDevice(true);
        Data.setIsValidationSuccess(true);
        Data.setDevid("1234");
        Data.setESimType("esim");
        Data.setFlowType("NSE");
        Data.setEid("12345");
        Data.setPhoneNumber("123456789");
        Data.setEmail("asdfghjkl");
        Data.setDevid("12345");
        Data.setLastName("mha");
        Data.setFirstName("lak");
        Data.setZipcode("520002");
        Data.setImei2("1234");
        StepVerifier.create(redisHelper2.upsertDeviceSimValidationDataIntoRedis(Data)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        Data.setIsSmartphone(false);
        StepVerifier.create(redisHelper2.upsertDeviceSimValidationDataIntoRedis(Data)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        Data.setIsEsimDevice(null);
        StepVerifier.create(redisHelper2.upsertDeviceSimValidationDataIntoRedis(Data)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        Data.setIsValidationSuccess(null);
        StepVerifier.create(redisHelper2.upsertDeviceSimValidationDataIntoRedis(Data)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        Data.setEsimFlowType("BYOD");
        Data.setPendingMdn("1234");
        StepVerifier.create(redisHelper2.upsertDeviceSimValidationDataIntoRedis(Data)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void fetchRedisDataTest(){
        DeviceExchangeRequest soeRequest = new DeviceExchangeRequest();
        soeRequest.setIntent("EUP_5G");
        soeRequest.setAccountNumber("0685927769-00001");
        DeviceUpgradeData upgradeDetails = new DeviceUpgradeData();
        DeviceUpgradeMtn mtn = new DeviceUpgradeMtn();
        mtn.setNetworkBandwidthType("CBD");
        mtn.setMtn("2243064621");
        upgradeDetails.setMtn(mtn);
        HashMap<String,Object> map = new HashMap<>();
        map.put("deviceUpgradeDetails",upgradeDetails);
        when(sessionBean.getSessionData(Mockito.any(), Mockito.any())).thenReturn(Mono.just(upgradeDetails));
        StepVerifier.create(redisHelper2.fetchRedisData(soeRequest))
                .assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        //null case
        upgradeDetails.setMtn(null);
        when(sessionBean.getSessionData(Mockito.any(), Mockito.any())).thenReturn(Mono.just(map));
        StepVerifier.create(redisHelper2.fetchRedisData(soeRequest))
                .assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        when(sessionBean.getSessionData(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new HashMap()));
        StepVerifier.create(redisHelper2.fetchRedisData(soeRequest))
                .assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void upsertDataintoRedisTest(){
        Map<String, String> redisData = new HashMap<String, String>();
        when(sessionBean.setSessionData(redisData)).thenReturn( Mono.empty());
        redisHelper2.upsertDataIntoSession(redisData);
        assertTrue(true);

        redisData.put("cartId", "af7617e7-dde0-42e0-a571-97be5de3d12b");
        when(sessionBean.setSessionData(redisData)).thenReturn( Mono.empty());
        redisHelper2.upsertDataIntoSession(redisData);
        assertTrue(true);

        redisData = null;
        when(sessionBean.setSessionData(redisData)).thenReturn( Mono.empty());
        redisHelper2.upsertDataIntoSession(redisData);
        assertTrue(true);
    }

}
