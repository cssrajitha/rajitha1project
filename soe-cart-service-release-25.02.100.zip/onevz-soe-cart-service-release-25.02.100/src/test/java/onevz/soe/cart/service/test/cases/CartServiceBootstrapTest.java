package onevz.soe.cart.service.test.cases;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import onevz.soe.cart.CartServiceBootstrap;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
public class CartServiceBootstrapTest {
	

	@Test
	public void test() {
		String[] args = new String[2];
		args[0]="Test";
		args[1]="Run";
		CartServiceBootstrap.main(args);
		StepVerifier.create(Mono.just("")).assertNext(d -> Assert.assertNotNull(d));
	}

}
