package onevz.soe.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.cxp.feature.ConfigurationProfile;
import onevz.cxp.feature.FeatureFlagRequest;
import onevz.cxp.feature.Flag;
import onevz.cxp.feature.util.FeatureFlag;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.RetrieveCartCXPResponse;
import onevz.soe.session.featureflag.FeatureFlagAdapter;
import onevz.soe.cart.constants.FeatureFlagConstants;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntentUIResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;

import onevz.soe.cart.ui.responses.v2.FlagDetails;
import onevz.soe.spring.web.filter.RequestAccessContext;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.ReflectionUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyString;
import org.mockito.Mockito;
import onevz.soe.cart.util.SourceFileReaderUtil;
import reactor.util.function.Tuple2;

import java.lang.reflect.Method;
import java.util.*;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {CartServiceTestConfig.class})
public class FeatureFlagHelperTest {

    @MockBean
    private FeatureFlag featureFlagMock;
    @Autowired
    private FeatureFlagHelper featureFlagHelper;
    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;
    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;
    @Autowired
    private ObjectMapper mapper;
    @MockBean
    private FeatureFlagAdapter featureFlagAdapterMock;

    @Test
    public void testD2DfeatureFlag(){

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_ASSISTED,
                FeatureFlagConstants.PROFILE_ACCOUNTLANDING, FeatureFlagConstants.FLEXV2_D2D_FLAG,
                false))
                .thenReturn(Mono.just(true));
        StepVerifier.create(featureFlagHelper.fetchD2DFeatureFlag())
                .expectNext(true)
                .verifyComplete();

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_ASSISTED,
                FeatureFlagConstants.PROFILE_ACCOUNTLANDING, FeatureFlagConstants.FLEXV2_D2D_FLAG,
                false))
                .thenReturn(Mono.just(false));
        StepVerifier.create(featureFlagHelper.fetchD2DFeatureFlag())
                .expectNext(false)
                .verifyComplete();
    }

    @Test
    public void testfetchMonoElvisFeatureFlag()
    {
        when(featureFlagMock.isFeatureEnabled((FeatureFlagRequest) any())).thenReturn(Mono.just(true));
        StepVerifier.create(featureFlagHelper.fetchMonoElvisFeatureFlag(true))
                .expectNext(false)
                .verifyComplete();
        when(featureFlagMock.isFeatureEnabled((FeatureFlagRequest) any())).thenReturn(Mono.just(true));
        StepVerifier.create(featureFlagHelper.fetchMonoElvisFeatureFlag(false))
                .expectNext(false)
                .verifyComplete();
    }

    @Test
    public void testSnTaggingFeatureFlag(){

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.AWS_CONFIG_APP_NAME,
                FeatureFlagConstants.SN_AWS_CONFIG_PROFILE, FeatureFlagConstants.SECOND_NUMBER_TAGGING_FLAG, true))
                .thenReturn(Mono.just(true));
        StepVerifier.create(featureFlagHelper.snTaggingFeatureFlag())
                .expectNext(true)
                .verifyComplete();

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.AWS_CONFIG_APP_NAME,
                FeatureFlagConstants.SN_AWS_CONFIG_PROFILE, FeatureFlagConstants.SECOND_NUMBER_TAGGING_FLAG, true))
                .thenReturn(Mono.just(false));
        StepVerifier.create(featureFlagHelper.snTaggingFeatureFlag())
                .expectNext(false)
                .verifyComplete();
    }

    @Test
    public void testUpdateTaggingFeatureFlag(){

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_ASSISTED,
                FeatureFlagConstants.PROFILE_FRAMEWORK, FeatureFlagConstants.FLEXV2_ASSISTED_TAGGING,
                false))
                .thenReturn(Mono.just(true));
        StepVerifier.create(featureFlagHelper.fetchAssistedTaggingFeatureFlag())
                .expectNext(true)
                .verifyComplete();

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_ASSISTED,
                FeatureFlagConstants.PROFILE_FRAMEWORK, FeatureFlagConstants.FLEXV2_ASSISTED_TAGGING,
                false))
                .thenReturn(Mono.just(false));
        StepVerifier.create(featureFlagHelper.fetchAssistedTaggingFeatureFlag())
                .expectNext(false)
                .verifyComplete();
    }

   
    @Test
    public void testAccMemMigrationFeatureFlag(){

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME, FeatureFlagConstants.BAU_UPG_FLAG,
                FeatureFlagConstants.ENABLE_ACC_MEM_MIGRATION, "true"))
                .thenReturn(Mono.just(true));
        StepVerifier.create(featureFlagHelper.isAccMemberMigrationEnabled())
                .expectNext(true)
                .verifyComplete();

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME, FeatureFlagConstants.BAU_UPG_FLAG,
                FeatureFlagConstants.ENABLE_ACC_MEM_MIGRATION, "false"))
                .thenReturn(Mono.just(true));
        StepVerifier.create(featureFlagHelper.isAccMemberMigrationEnabled())
                .expectNext(true)
                .verifyComplete();
    }

    @Test
    public void fetchDigitalPerformanceCfgProfileTest() {
        Mockito.when(featureFlagHelper.fetchDigitalPerformanceCfgProfile())
                .thenReturn(Mono.just(new ConfigurationProfile()));
        StepVerifier.create(featureFlagMock.getConfigurationProfile(anyString(), anyString()))
                .assertNext(data -> assertThat(data).isNotNull());
    }

    @Test
    public void fetchDigitalUpgradeCfgProfileTest(){
        Mockito.when(featureFlagHelper.fetchDigitalUpgradeCfgProfile()).thenReturn(Mono.just(new ConfigurationProfile()));
        StepVerifier.create(featureFlagMock.getConfigurationProfile(anyString(),anyString()))
                .assertNext(data -> assertThat(data).isNotNull());
    }
    
	@Test
	public void retrieveFflagForDvmOnboardingTest() {
		Map<String, Boolean> testMap = new HashMap<>();
		when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_MARKETING_HOME,
				FeatureFlagConstants.CONFIG_PROFILE_SALES, FeatureFlagConstants.EXISTING_NETWORK_TRIAL_VALIDATION_FFLAG,
				false)).thenReturn(Mono.just(true));
		when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_MARKETING_HOME,
				FeatureFlagConstants.CONFIG_PROFILE_SALES, FeatureFlagConstants.EXISTING_TRIAL_HASH_VALIDATION_FFLAG,
				false)).thenReturn(Mono.just(true));
		when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_MARKETING_HOME,
				FeatureFlagConstants.CONFIG_PROFILE_SALES, FeatureFlagConstants.PERFORMANCE_OPTIMIZATION_FFLAG, false))
				.thenReturn(Mono.just(true));
		testMap.put(FeatureFlagConstants.EXISTING_NETWORK_TRIAL_VALIDATION_FFLAG, true);
		testMap.put(FeatureFlagConstants.EXISTING_TRIAL_HASH_VALIDATION_FFLAG, true);
		testMap.put(FeatureFlagConstants.PERFORMANCE_OPTIMIZATION_FFLAG, true);
		//StepVerifier.create(featureFlagHelper.retrieveFflagForDvmOnboarding()).expectNext(testMap).verifyComplete();
	}

    @Test
    public void isRouterFlagEnabledTest() {
        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_FWA_DIFITAL,
                FeatureFlagConstants.ROUTER_UPGRADE_CFG_PROFILE, FeatureFlagConstants.ROUTER_UPGRADE_FF_FLAG, false))
                .thenReturn(Mono.just(true));
        StepVerifier.create(featureFlagHelper.isRouterFlagEnabled())
                .expectNext(true)
                .verifyComplete();

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_FWA_DIFITAL,
                FeatureFlagConstants.ROUTER_UPGRADE_CFG_PROFILE, FeatureFlagConstants.ROUTER_UPGRADE_FF_FLAG, false))
                .thenReturn(Mono.just(false));
        StepVerifier.create(featureFlagHelper.isRouterFlagEnabled())
                .expectNext(false)
                .verifyComplete();
    }
    @Test
    public void isflexMFEValidationTest() {
        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_ASSISTED,
                FeatureFlagConstants.PROFILE_FRAMEWORK, FeatureFlagConstants.FLEX_MFE_VALIDATION, false))
                .thenReturn(Mono.just(true));
        StepVerifier.create(featureFlagHelper.isFlexV2ValidationEnabled())
                .expectNext(true)
                .verifyComplete();

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_ASSISTED,
                FeatureFlagConstants.PROFILE_FRAMEWORK, FeatureFlagConstants.FLEX_MFE_VALIDATION, false))
                .thenReturn(Mono.just(false));
        StepVerifier.create(featureFlagHelper.isFlexV2ValidationEnabled())
                .expectNext(false)
                .verifyComplete();
    }

    @Test
    public void isRouterUpgradeFlagEnabledTest() {
        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_FWA_DIFITAL,
                FeatureFlagConstants.ROUTER_UPGRADE_CFG_PROFILE, FeatureFlagConstants.ROUTER_UPGRADE_FF_FLAG, false))
                .thenReturn(Boolean.TRUE);
        assertTrue(featureFlagHelper.isRouterUpgradeFlagEnabled());
        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_FWA_DIFITAL,
                FeatureFlagConstants.ROUTER_UPGRADE_CFG_PROFILE, FeatureFlagConstants.ROUTER_UPGRADE_FF_FLAG, false))
                .thenReturn(Boolean.FALSE);
        assertFalse(featureFlagHelper.isRouterUpgradeFlagEnabled());
    }

    @Test
    public void isMoversUnifiedNBSEnabledTest() {
        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_FWA_DIGITAL, FeatureFlagConstants.MOV_PROFILE_CONFIG,
                FeatureFlagConstants.FEATURE_FLAG_MOV_UNIFIED_NBS, Boolean.FALSE))
                .thenReturn(Boolean.TRUE);
        assertTrue(featureFlagHelper.isMoversUnifiedNBSEnabled());
        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_FWA_DIGITAL, FeatureFlagConstants.MOV_PROFILE_CONFIG,
                FeatureFlagConstants.FEATURE_FLAG_MOV_UNIFIED_NBS, Boolean.FALSE))
                .thenReturn(false);
        assertFalse(featureFlagHelper.isMoversUnifiedNBSEnabled());
    }

    @Test
    public void isMoversOmniCartReqEnabledTest() {
        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_FWA_DIGITAL, FeatureFlagConstants.MOV_PROFILE_CONFIG,
                FeatureFlagConstants.FEATURE_FLAG_MOV_OMNI_CART_REQ, Boolean.FALSE))
                .thenReturn(Boolean.TRUE);
        assertTrue(featureFlagHelper.isMoversOmniCartReqEnabled());
        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_FWA_DIGITAL, FeatureFlagConstants.MOV_PROFILE_CONFIG,
                FeatureFlagConstants.FEATURE_FLAG_MOV_OMNI_CART_REQ, Boolean.FALSE))
                .thenReturn(false);
        assertFalse(featureFlagHelper.isMoversOmniCartReqEnabled());
    }

    @Test
    public void isFWAUnifiedNBSEnabledTest() {
        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_FWA_DIGITAL, FeatureFlagConstants.ENHANCEMENTTRIAGE_PROFILE_CONFIG,
                FeatureFlagConstants.FEATURE_FLAG_FWA_UNIFIED_NBS, Boolean.FALSE))
                .thenReturn(Boolean.TRUE);
        assertTrue(featureFlagHelper.isFWAUnifiedNBSEnabled());
        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_FWA_DIGITAL, FeatureFlagConstants.ENHANCEMENTTRIAGE_PROFILE_CONFIG,
                FeatureFlagConstants.FEATURE_FLAG_FWA_UNIFIED_NBS, Boolean.FALSE))
                .thenReturn(Boolean.FALSE);
        assertFalse(featureFlagHelper.isFWAUnifiedNBSEnabled());
    }


    @Test
    public void isTradeInPromoCheckFflagEnabledTest() {
        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.AWS_CONFIG_APP_NAME,
                FeatureFlagConstants.SWIFT_CFG_PROFILE, FeatureFlagConstants.TRADE_IN_PROMOCCheckFFlag, false))
                .thenReturn(Mono.just(true));
        StepVerifier.create(featureFlagHelper.isTradeInPromoCheckFflagEnabled())
                .expectNext(true)
                .verifyComplete();

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.AWS_CONFIG_APP_NAME,
                FeatureFlagConstants.SWIFT_CFG_PROFILE, FeatureFlagConstants.TRADE_IN_PROMOCCheckFFlag, false))
                .thenReturn(Mono.just(false));
        StepVerifier.create(featureFlagHelper.isTradeInPromoCheckFflagEnabled())
                .expectNext(false)
                .verifyComplete();
    }
    @Test
    public void isAssistedLPMFETaggingFeatureFlagTest() {
        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_ASSISTED,
                FeatureFlagConstants.PROFILE_ACCOUNTLANDING, FeatureFlagConstants.ASSISTED_LANDING_MFE_TAGGING_FFLAG,
                false)).thenReturn(true);
        assertTrue(featureFlagHelper.isAssistedLPMFETaggingFeatureFlag());

        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_ASSISTED,
                FeatureFlagConstants.PROFILE_ACCOUNTLANDING, FeatureFlagConstants.ASSISTED_LANDING_MFE_TAGGING_FFLAG,
                false))
                .thenReturn(false);
        assertFalse(featureFlagHelper.isAssistedLPMFETaggingFeatureFlag());

    }
    @Test
    public void amNextGenFeatureFlagTest() {
        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME, FeatureFlagConstants.ENABLE_AM_NEXTGEN_FFLAG, false))
                .thenReturn(Mono.just(true));
        StepVerifier.create(featureFlagHelper.amNextGenFeatureFlag())
                .expectSubscription();

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_FWA_DIFITAL,
                FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME, FeatureFlagConstants.ENABLE_AM_NEXTGEN_FFLAG, false))
                .thenReturn(Mono.just(false));
        StepVerifier.create(featureFlagHelper.amNextGenFeatureFlag())
                .expectSubscription();
    }
    @Test
    public void fetchDigitalPegaPredictivePrefetchFFlagTest() {
        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_PERFORMANCE_CFG_PROFILE, FeatureFlagConstants.PEGA_PRDEDECTIVE_PREFETCHF_FLAG, false))
                .thenReturn(Mono.just(true));
        StepVerifier.create(featureFlagHelper.fetchDigitalPegaPredictivePrefetchFFlag())
                .expectNext(true)
                .verifyComplete();

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_PERFORMANCE_CFG_PROFILE, FeatureFlagConstants.PEGA_PRDEDECTIVE_PREFETCHF_FLAG, false))
                .thenReturn(Mono.just(false));
        StepVerifier.create(featureFlagHelper.fetchDigitalPegaPredictivePrefetchFFlag())
                .expectNext(false)
                .verifyComplete();
    }

    @Test
    public void testFetchHolidayReturnPolicyNSEFFlag() {
        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_PROMOS_CFG_PROFILE, "test", false))
                .thenReturn(Mono.just(true));
        StepVerifier.create(featureFlagHelper.fetchHolidayReturnPolicyNSEFFlag("test"))
                .expectSubscription();

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_PROMOS_CFG_PROFILE, "test", true))
                .thenReturn(Mono.just(true));
        StepVerifier.create(featureFlagHelper.fetchHolidayReturnPolicyNSEFFlag("test"))
                .expectSubscription();

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_PROMOS_CFG_PROFILE, "test", false))
                .thenReturn(Mono.just(false));
        StepVerifier.create(featureFlagHelper.fetchHolidayReturnPolicyNSEFFlag("test"))
                .expectSubscription();

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_PROMOS_CFG_PROFILE, "test", true))
                .thenReturn(Mono.just(false));
        StepVerifier.create(featureFlagHelper.fetchHolidayReturnPolicyNSEFFlag("test"))
                .expectSubscription();

    }

    @Test
    public void testPreToPostActFeeFFlagStatus() {
        RequestAccessContext.RequestAccess reqAccess = new RequestAccessContext.RequestAccess();
        reqAccess.getCookies().add(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, new HttpCookie(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, "true"));
        RequestAccessContext.updateRequestData(reqAccess);
        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.PRE_TO_POST_CFG_PROFILE_NAME, "test", false))
                .thenReturn(Mono.just(true));
        StepVerifier.create(featureFlagHelper.isEnabledFFlagForPreToPostActivationFee("test"))
                .expectSubscription();

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.PRE_TO_POST_CFG_PROFILE_NAME, "test", true))
                .thenReturn(Mono.just(true));
        StepVerifier.create(featureFlagHelper.isEnabledFFlagForPreToPostActivationFee("test"))
                .expectSubscription();

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.PRE_TO_POST_CFG_PROFILE_NAME, "test", false))
                .thenReturn(Mono.just(false));
        StepVerifier.create(featureFlagHelper.isEnabledFFlagForPreToPostActivationFee("test"))
                .expectSubscription();

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.PRE_TO_POST_CFG_PROFILE_NAME, "test", true))
                .thenReturn(Mono.just(false));
        StepVerifier.create(featureFlagHelper.isEnabledFFlagForPreToPostActivationFee("test"))
                .expectSubscription();

    }


    @Test
    public void fetchDigitalOfferInterstitialCfgProfileTest() {
        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_OFFER_CFG_PROFILE, FeatureFlagConstants.ENABLE_WINBACK_OFFER_FFLAG,
                true))
                .thenReturn(Mono.just(true));
        StepVerifier.create(featureFlagHelper.isWinbackOfferFlagEnabled())
                .expectNext(true)
                .verifyComplete();

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_OFFER_CFG_PROFILE, FeatureFlagConstants.ENABLE_WINBACK_OFFER_FFLAG,
                true))
                .thenReturn(Mono.just(false));
        StepVerifier.create(featureFlagHelper.isWinbackOfferFlagEnabled())
                .expectNext(false)
                .verifyComplete();
    }

    @Test
    public void isTrialHashFflagEnabledTest() {
        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_MARKETING_HOME, FeatureFlagConstants.CONFIG_PROFILE_SALES,
				FeatureFlagConstants.EXISTING_TRIAL_HASH_VALIDATION_FFLAG, false))
                .thenReturn(Mono.just(true));
        StepVerifier.create(featureFlagHelper.isTrialHashFflagEnabled())
                .expectNext(true)
                .verifyComplete();

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_MARKETING_HOME, FeatureFlagConstants.CONFIG_PROFILE_SALES,
				FeatureFlagConstants.EXISTING_TRIAL_HASH_VALIDATION_FFLAG, false))
                .thenReturn(Mono.just(false));
        StepVerifier.create(featureFlagHelper.isTrialHashFflagEnabled())
                .expectNext(false)
                .verifyComplete();
    
    	
    }
    @Test
    public void mergeFeatureFlagWithResponseTest() {
        AddPromoIntentUIResponse res=new AddPromoIntentUIResponse();
        ResponseEntity<Object> responseEntity =
                ResponseEntity.status(HttpStatus.OK).body(res);
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        assertNotNull(responseEntity);
        assertNotNull(featureFlagHelper.fetchDigitalPerformanceCfgProfile());
    }
    @Test(expected = NullPointerException.class)
    public void mergeFeatureFlagWithResponseNullTest() {
        AddPromoIntentUIResponse res = new AddPromoIntentUIResponse();
        ResponseEntity<Object> responseEntity =
                ResponseEntity.status(HttpStatus.OK).body(res);
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = null;
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        assertNotNull(responseEntity);
        assertNull(featureFlagHelper.fetchDigitalPerformanceCfgProfile());

    }
    @Test
    public void testFetchMarketingHomeFFlagStatus() {
        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.AWS_CONFIG_APP_NAME,
                FeatureFlagConstants.AWS_CONFIG_PROFILE, "test", false))
                .thenReturn(Mono.just(true));
        StepVerifier.create(featureFlagHelper.fetchMarketingHomeFFlagStatus("test"))
                .expectSubscription();

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.AWS_CONFIG_APP_NAME,
                FeatureFlagConstants.AWS_CONFIG_PROFILE, "test", true))
                .thenReturn(Mono.just(true));
        StepVerifier.create(featureFlagHelper.fetchMarketingHomeFFlagStatus("test"))
                .expectSubscription();

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.AWS_CONFIG_APP_NAME,
                FeatureFlagConstants.AWS_CONFIG_PROFILE, "test", false))
                .thenReturn(Mono.just(false));
        StepVerifier.create(featureFlagHelper.fetchMarketingHomeFFlagStatus("test"))
                .expectSubscription();

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.AWS_CONFIG_APP_NAME,
                FeatureFlagConstants.AWS_CONFIG_PROFILE, "test", true))
                .thenReturn(Mono.just(false));
        StepVerifier.create(featureFlagHelper.fetchMarketingHomeFFlagStatus("test"))
                .expectSubscription();

    }
    public void fetchMiniCartCfgProfileTest() {
        Mockito.when(featureFlagHelper.fetchMiniCartCfgProfile())
                .thenReturn(Mono.just(new ConfigurationProfile()));
        StepVerifier.create(featureFlagMock.getConfigurationProfile(anyString(), anyString()))
                .assertNext(data -> assertThat(data).isNotNull());

    }
    
    @Test
    public void testEarlyUpgradeBlockerFeatureFlag() {
        FeatureFlagRequest featureFlagRequest = new FeatureFlagRequest();
        featureFlagRequest.setConfigurationProfile(FeatureFlagConstants.PROFILE_TRADEIN);
        featureFlagRequest.setFlagName(FeatureFlagConstants.EARLY_UPGRADE_BLOCKERF_FLAG);
        when(featureFlagAdapterMock.isAssistedCSFeatureEnabled(featureFlagRequest))
                .thenReturn(Mono.just(true));
        StepVerifier.create(featureFlagHelper.earlyUpgradeBlockerFeatureFlag())
                .expectNext(true)
                .verifyComplete();
    }

    @Test
    public void addDigitalPromoFeatureFlagTest() throws Exception {
        Method method = FeatureFlagHelper.class.getDeclaredMethod("addDigitalPromoFeatureFlag",
                Map.class, Map.class);
        ReflectionUtils.makeAccessible(method);
        Map<String, FlagDetails> featureConfigurationProfileData = new HashMap<>();
        Map<String, Flag> fFlagMap = null;
        method.invoke(featureFlagHelper, fFlagMap,featureConfigurationProfileData);
        assertNotNull(method);

        fFlagMap = new HashMap<>();
        method.invoke(featureFlagHelper, fFlagMap,featureConfigurationProfileData);
        assertNotNull(method);

        Flag flag = new Flag();
        flag.setName("abcd");
        fFlagMap.put("abcd",flag);
        method.invoke(featureFlagHelper, fFlagMap,featureConfigurationProfileData);
        assertNotNull(method);
    }

    @Test
    public void addDigitalPerformanceFeatureFlagTest() throws Exception {
        Method method = FeatureFlagHelper.class.getDeclaredMethod("addDigitalPerformanceFeatureFlag",
                ConfigurationProfile.class, Map.class);
        ReflectionUtils.makeAccessible(method);
        Map<String, FlagDetails> featureConfigurationProfileData = new HashMap<>();
        ConfigurationProfile configurationProfile = null;
        method.invoke(featureFlagHelper, configurationProfile,featureConfigurationProfileData);
        assertNotNull(method);

        configurationProfile = new ConfigurationProfile();
        method.invoke(featureFlagHelper, configurationProfile,featureConfigurationProfileData);
        assertNotNull(method);

        List<Flag> flags = new ArrayList<>();
        Flag flag = new Flag();
        flag.setName("abcd");
        Flag flag2 = new Flag();
        flag2.setName("abcd3f");
        flags.add(flag);
        flags.add(flag2);
        configurationProfile.setFlags(flags);
        method.invoke(featureFlagHelper, configurationProfile,featureConfigurationProfileData);
        assertNotNull(method);
    }
    
    
    @Test
    public void testFetchFiosLoginPDPPearlFFlagStatus() {
        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.AWS_CONFIG_APP_NAME,
                FeatureFlagConstants.PEARL_CFG_PROFILE, "test", false))
                .thenReturn(Mono.just(true));
        StepVerifier.create(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus())
                .expectSubscription();

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.AWS_CONFIG_APP_NAME,
                FeatureFlagConstants.PEARL_CFG_PROFILE, "test", true))
                .thenReturn(Mono.just(true));
        StepVerifier.create(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus())
                .expectSubscription();

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.AWS_CONFIG_APP_NAME,
                FeatureFlagConstants.PEARL_CFG_PROFILE, "test", false))
                .thenReturn(Mono.just(false));
        StepVerifier.create(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus())
                .expectSubscription();

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.AWS_CONFIG_APP_NAME,
                FeatureFlagConstants.PEARL_CFG_PROFILE, "test", true))
                .thenReturn(Mono.just(false));
        StepVerifier.create(featureFlagHelper.fetchFiosLoginPDPPearlFFlagStatus())
                .expectSubscription();

    }

    @Test
    public void fetchDigitalPromosCfgProfileTest() {
        List<String> flagList=List.of("saveTheSaleFFlag");
        when(featureFlagHelper.fetchDigitalPromosCfgProfile(flagList))
                .thenReturn(Mono.just(new HashMap<>()));
        StepVerifier.create(featureFlagHelper.fetchDigitalPromosCfgProfile(flagList))
                .assertNext(data -> assertThat(data).isNotNull());
    }

    @Test
    public void fetchDigitalUpgradeCfgProfileTest1() {
        List<String> flagList=List.of("promoIntentMapFFlag");
        when(featureFlagHelper.fetchDigitalUpgradeCfgProfile(flagList))
                .thenReturn(Mono.just(new HashMap<>()));
        StepVerifier.create(featureFlagHelper.fetchDigitalUpgradeCfgProfile(flagList))
                .assertNext(data -> assertThat(data).isNotNull());
    }

    @Test
    public void isLineInfoFeatureFlagTest() {
        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_MARKETING_HOME,
                FeatureFlagConstants.CONFIG_PROFILE_SALES, FeatureFlagConstants.ENABLE_LINEINFO_FFLAG, false))
                .thenReturn(Boolean.TRUE);
        boolean result = featureFlagHelper.isLineInfoFeatureFlag();
        assertTrue(result);

    }
    @Test
    public void testMergeFeatureFlagWithResponse() throws AssertionError {
        // Arrange
        Mono<Tuple2<AddPromoIntentUIResponse, ConfigurationProfile>> justResult = Mono
                .<Tuple2<AddPromoIntentUIResponse, ConfigurationProfile>>just(mock(Tuple2.class));

        // Act and Assert
        StepVerifier.FirstStep<AddPromoIntentUIResponse> createResult = StepVerifier
                .create(featureFlagHelper.mergeFeatureFlagWithResponse(justResult));
        createResult.assertNext(a -> {
            AddPromoIntentUIResponse addPromoIntentUIResponse = a;
            addPromoIntentUIResponse.getErrors();
            addPromoIntentUIResponse.getFeatureConfigurationProfileData();
            addPromoIntentUIResponse.getGenericHeader();
            addPromoIntentUIResponse.getServiceBody();
            addPromoIntentUIResponse.getServiceHeader();
            return;
        }).expectComplete().verify();
        StepVerifier.FirstStep<Tuple2<AddPromoIntentUIResponse, ConfigurationProfile>> createResult2 = StepVerifier
                .create(justResult);
        createResult2.assertNext(t -> {
        }).expectComplete().verify();
    }

    @Test
    public void isNgdAbandonCartFFlagTest() {
        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.CONFIGURATOR, FeatureFlagConstants.NGD_ABANDONCART_FFLAG, false))
                .thenReturn(Mono.just(Boolean.TRUE));
        StepVerifier.create(featureFlagHelper.isNgdAbandonCartFFlag())
                .expectSubscription();
        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.CONFIGURATOR, FeatureFlagConstants.NGD_ABANDONCART_FFLAG, false))
                .thenReturn(Mono.just(Boolean.FALSE));
        StepVerifier.create(featureFlagHelper.isNgdAbandonCartFFlag())
                .expectSubscription();


    }

    @Test
    public void testBmsmFeatureFlag() throws JsonProcessingException {
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveCartCXPResponse1.json", testFileLocation);
        RetrieveCartCXPResponse resp = null;
        resp = mapper.readValue(responseString, RetrieveCartCXPResponse.class);
        FeatureFlagRequest featureFlagRequest = new FeatureFlagRequest();
        featureFlagRequest.setApplicationName(FeatureFlagConstants.AWS_CONFIG_APP_NAME);
        featureFlagRequest.setConfigurationProfile(FeatureFlagConstants.AWS_CONFIG_PROFILE);
        featureFlagRequest.setFlagName(FeatureFlagConstants.AWS_FLAG_BMSM_OFFER);
        featureFlagRequest.setDefaultValue(false);
        featureFlagRequest.setLocationCode(resp.getData().getCart().getCartHeader().getCartCreatorOrderLocationCode());
        featureFlagHelper.bmsmFeatureFlag(resp);
    }

    @Test
    public void trade3POChoiceOfferFFlagTest()  throws JsonProcessingException {

        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_ASSISTED,
                FeatureFlagConstants.OFFERS_CFG_PROFILE, FeatureFlagConstants.TRADE_3PO_CHOICE_OFFER_FLAG, false))
                .thenReturn(Boolean.TRUE);
        boolean result = featureFlagHelper.trade3POChoiceOfferFFlag();
        assertTrue(result);

        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_ASSISTED,
                FeatureFlagConstants.OFFERS_CFG_PROFILE, FeatureFlagConstants.TRADE_3PO_CHOICE_OFFER_FLAG, false))
                .thenReturn(Boolean.FALSE);
        boolean result1 = featureFlagHelper.trade3POChoiceOfferFFlag();
        assertFalse(result1);
    }
    
    @Test
    public void emberDiscountFeatureFlagTest()  throws JsonProcessingException {

        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_MARKETING_HOME,
                FeatureFlagConstants.EMBER_CONFIG_PROFILE_NAME, FeatureFlagConstants.EMBER_DISCOUNT_F_FLAG, false))
                .thenReturn(Boolean.TRUE);
        boolean result = featureFlagHelper.emberDiscountFeatureFlag();
        assertTrue(result);

        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_MARKETING_HOME,
                FeatureFlagConstants.EMBER_CONFIG_PROFILE_NAME, FeatureFlagConstants.EMBER_DISCOUNT_F_FLAG, false))
                .thenReturn(Boolean.FALSE);
        boolean result1 = featureFlagHelper.emberDiscountFeatureFlag();
        assertFalse(result1);
    }
    @Test
    public void isNgdTradeInBulkUpdateEnabledTest()  throws JsonProcessingException {

           when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                   FeatureFlagConstants.CONFIGURATOR, FeatureFlagConstants.NGD_PLANS_TRADEIN_FLOW, false))
                   .thenReturn(Boolean.TRUE);
           boolean result = featureFlagHelper.isNgdTradeInBulkUpdateEnabled();
           assertTrue(result);

        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.CONFIGURATOR, FeatureFlagConstants.NGD_PLANS_TRADEIN_FLOW, false))
                .thenReturn(Boolean.FALSE);
        boolean result1 = featureFlagHelper.isNgdTradeInBulkUpdateEnabled();
        assertFalse(result1);
    }

    @Test
    public void isNgdProspectClearCartCookiesEnabledTest()  throws JsonProcessingException {

        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.CONFIGURATOR, FeatureFlagConstants.NGD_CLEAR_CART_NSE_FFLAG, false))
                .thenReturn(Boolean.TRUE);
        boolean result = featureFlagHelper.isNgdProspectClearCartCookiesEnabled();
        assertTrue(result);

        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.CONFIGURATOR, FeatureFlagConstants.NGD_CLEAR_CART_NSE_FFLAG, false))
                .thenReturn(Boolean.FALSE);
        boolean result1 = featureFlagHelper.isNgdProspectClearCartCookiesEnabled();
        assertFalse(result1);
    }

    @Test
    public void isMaskingForBYODFFlagTest()  throws JsonProcessingException {

        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.CONFIG_PROFILE_BYOD, FeatureFlagConstants.ENABLE_MASKING_BYOD, false))
                .thenReturn(Boolean.TRUE);
        boolean result = featureFlagHelper.isMaskingForBYODFFlag();
        assertTrue(result);

        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.CONFIG_PROFILE_BYOD, FeatureFlagConstants.ENABLE_MASKING_BYOD, false))
                .thenReturn(Boolean.FALSE);
        boolean result1 = featureFlagHelper.isMaskingForBYODFFlag();
        assertFalse(result1);
    }

    @Test
    public void getFeatureFlagWithAccNumThrottleTest() {

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME, FeatureFlagConstants.ENABLE_AM_NEXTGEN_FFLAG, false))
                .thenReturn(Mono.just(true));
        assertFalse(featureFlagHelper.getFeatureFlagWithAccNumThrottle(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME, FeatureFlagConstants.ENABLE_AM_NEXTGEN_FFLAG,
                "0001386800-00001","9999988888"));

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_FWA_DIFITAL,
                FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME, FeatureFlagConstants.ENABLE_AM_NEXTGEN_FFLAG, false))
                .thenReturn(Mono.just(false));
        assertFalse(featureFlagHelper.getFeatureFlagWithAccNumThrottle(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME, FeatureFlagConstants.ENABLE_AM_NEXTGEN_FFLAG,
                "0001386828-00001", "9999988888"));

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME, FeatureFlagConstants.ENABLE_AM_NEXTGEN_FFLAG, false))
                .thenReturn(Mono.just(true));
        assertFalse(featureFlagHelper.getFeatureFlagWithAccNumThrottle(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME, FeatureFlagConstants.ENABLE_AM_NEXTGEN_FFLAG,
                null, "9999988888"));

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME, FeatureFlagConstants.ENABLE_AM_NEXTGEN_FFLAG, false))
                .thenReturn(Mono.just(true));
        assertFalse(featureFlagHelper.getFeatureFlagWithAccNumThrottle(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME, FeatureFlagConstants.ENABLE_AM_NEXTGEN_FFLAG,
                "000138680000001", "9999988888"));

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME, FeatureFlagConstants.ENABLE_AM_NEXTGEN_FFLAG, false))
                .thenReturn(Mono.just(true));
        assertFalse(featureFlagHelper.getFeatureFlagWithAccNumThrottle(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME, FeatureFlagConstants.ENABLE_AM_NEXTGEN_FFLAG,
                "000138680000001", null));
    }
    @Test
    public void addBYODFeatureFlagTest() throws Exception {
        Method method = FeatureFlagHelper.class.getDeclaredMethod("addBYODFeatureFlag",
                Map.class, Map.class);
        ReflectionUtils.makeAccessible(method);
        Map<String, FlagDetails> featureConfigurationProfileData = new HashMap<>();
        Map<String, Flag> fFlagMap = null;
        method.invoke(featureFlagHelper, fFlagMap,featureConfigurationProfileData);
        assertNotNull(method);

        fFlagMap = new HashMap<>();
        method.invoke(featureFlagHelper, fFlagMap,featureConfigurationProfileData);
        assertNotNull(method);

        Flag flag = new Flag();
        flag.setName("enableSaveCartForBYODFFlag");
        fFlagMap.put("enableSaveCartForBYODFFlag",flag);
        method.invoke(featureFlagHelper, fFlagMap,featureConfigurationProfileData);
        assertNotNull(method);
    }

    @Test
    public void isSkipResumeCaseFFlagEnabledTest()  throws JsonProcessingException {

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME, FeatureFlagConstants.SKIP_RESUME_CASE_FFLAG, false))
                .thenReturn(Mono.just(true));
        StepVerifier.create(featureFlagHelper.isSkipResumeCaseFFlagEnabled())
                .expectSubscription();

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME, FeatureFlagConstants.SKIP_RESUME_CASE_FFLAG, false))
                .thenReturn(Mono.just(true));
        StepVerifier.create(featureFlagHelper.isSkipResumeCaseFFlagEnabled())
                .expectSubscription();
    }

    @Test
    public void isPOYPEnabledTest() {
        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_PROMOS_CFG_PROFILE, FeatureFlagConstants.POYP_OFFER_FFLAG, false))
                .thenReturn(Boolean.FALSE);
        assertFalse(featureFlagHelper.isPOYPEnabled());

        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_PROMOS_CFG_PROFILE, FeatureFlagConstants.POYP_OFFER_FFLAG, false))
                .thenReturn(Boolean.TRUE);
        assertTrue(featureFlagHelper.isPOYPEnabled());


    }

    @Test
    public void isBauUpgPdpTradeinFFlagEnabledTest() {
        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME, FeatureFlagConstants.BAU_UPGRADE_PDP_TRADEIN_FFLAG,
                false))
                .thenReturn(Mono.just(true));
        StepVerifier.create(featureFlagHelper.isBauUpgPdpTradeinFFlagEnabled())
                .expectNext(true)
                .verifyComplete();

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME, FeatureFlagConstants.BAU_UPGRADE_PDP_TRADEIN_FFLAG,
                false))
                .thenReturn(Mono.just(false));
        StepVerifier.create(featureFlagHelper.isBauUpgPdpTradeinFFlagEnabled())
                .expectNext(false)
                .verifyComplete();

    }
    @Test
    public void fetchAiQuoteTaggingFeatureFlag() {
        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_ASSISTED,
                FeatureFlagConstants.PROFILE_QUOTECFG, FeatureFlagConstants.AIQUOTE_TAGGING_ENABLED,
                false))
                .thenReturn(Mono.just(true));
        StepVerifier.create(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag())
                .expectNext(true)
                .verifyComplete();

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_ASSISTED,
                FeatureFlagConstants.PROFILE_QUOTECFG, FeatureFlagConstants.AIQUOTE_TAGGING_ENABLED,
                false))
                .thenReturn(Mono.just(false));
        StepVerifier.create(featureFlagHelper.fetchAiQuoteTaggingFeatureFlag())
                .expectNext(false)
                .verifyComplete();

    }
    
    @Test
    public void emberDiscountFeatureFlagMonoTest() {
        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_MARKETING_HOME,
                FeatureFlagConstants.EMBER_CONFIG_PROFILE_NAME, FeatureFlagConstants.EMBER_DISCOUNT_F_FLAG, false))
                .thenReturn(Mono.just(true));
        StepVerifier.create(featureFlagHelper.emberDiscountFeatureFlagMono())
                .expectNext(true)
                .verifyComplete();

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_MARKETING_HOME,
                FeatureFlagConstants.EMBER_CONFIG_PROFILE_NAME, FeatureFlagConstants.EMBER_DISCOUNT_F_FLAG, false))
                .thenReturn(Mono.just(false));
        StepVerifier.create(featureFlagHelper.emberDiscountFeatureFlagMono())
                .expectNext(false)
                .verifyComplete();

    }

    @Test
    public void fetchBulkUpdateAiQuoteTaggingFeatureFlag1() {
        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_ASSISTED,
                FeatureFlagConstants.PROFILE_QUOTECFG, FeatureFlagConstants.BULKUPDATE_AIQUOTE_TAGGING_ENABLED,
                false))
                .thenReturn(Mono.just(true));
        StepVerifier.create(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag())
                .expectNext(true)
                .verifyComplete();

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_ASSISTED,
                FeatureFlagConstants.PROFILE_QUOTECFG, FeatureFlagConstants.BULKUPDATE_AIQUOTE_TAGGING_ENABLED,
                false))
                .thenReturn(Mono.just(false));
        StepVerifier.create(featureFlagHelper.fetchBulkUpdateAiQuoteTaggingFeatureFlag())
                .expectNext(false)
                .verifyComplete();

    }

    @Test
    public void isBYODIMEIRangeFFlagEnabledTest() {
        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.CONFIG_PROFILE_BYOD, FeatureFlagConstants.BYOD_IMEI_RANGE_FFLAG, false))
                .thenReturn(Boolean.FALSE);
        assertFalse(featureFlagHelper.isBYODIMEIRangeFFlagEnabled());

        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.CONFIG_PROFILE_BYOD, FeatureFlagConstants.BYOD_IMEI_RANGE_FFLAG, false))
                .thenReturn(Boolean.TRUE);
        assertTrue(featureFlagHelper.isBYODIMEIRangeFFlagEnabled());


    }

    @Test
    public void isPlanSelectionProgressivePlansFFlagEnabledTest() {
        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_PLANS_CFG_FILE, FeatureFlagConstants.PLAN_SELECTION_PROGRESSIVE_PLANS_FFLAG, false))
                .thenReturn(Boolean.FALSE);
        assertFalse(featureFlagHelper.isPlanSelectionProgressivePlansFFlagEnabled());

        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_PLANS_CFG_FILE, FeatureFlagConstants.PLAN_SELECTION_PROGRESSIVE_PLANS_FFLAG, false))
                .thenReturn(Boolean.TRUE);
        assertTrue(featureFlagHelper.isPlanSelectionProgressivePlansFFlagEnabled());
    }

    @Test
    public void isBYODIMEIInstructionsFFlagEnabledTest() {
        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.CONFIG_PROFILE_BYOD, FeatureFlagConstants.ENABLE_IMEI_INSTRUCTIONS_FFLAG, false))
                .thenReturn(Boolean.FALSE);
        assertFalse(featureFlagHelper.isBYODIMEIInstructionsFFlagEnabled());

        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.CONFIG_PROFILE_BYOD, FeatureFlagConstants.ENABLE_IMEI_INSTRUCTIONS_FFLAG, false))
                .thenReturn(Boolean.TRUE);
        assertTrue(featureFlagHelper.isBYODIMEIInstructionsFFlagEnabled());
    }

    @Test
    public void isSafeCheckForBuyOutFFlagTest() {
        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME,
                FeatureFlagConstants.SAFE_CHECK_FOR_BUYOUT_FFLAG,
                false))
                .thenReturn(false);
        assertFalse(featureFlagHelper.isSafeCheckForBuyOutFFlag());

        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME,
                FeatureFlagConstants.SAFE_CHECK_FOR_BUYOUT_FFLAG,
                false))
                .thenReturn(true);
        assertTrue(featureFlagHelper.isSafeCheckForBuyOutFFlag());
    }

    @Test
    public void isPastDueBYODFFlagTest() {
        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.CONFIG_PROFILE_BYOD, FeatureFlagConstants.PAST_DUE_BYOD_FLAG,
                false))
                .thenReturn(false);
        assertFalse(featureFlagHelper.isPastDueBYODFFlag());

        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.CONFIG_PROFILE_BYOD, FeatureFlagConstants.PAST_DUE_BYOD_FLAG,
                false))
                .thenReturn(true);
        assertTrue(featureFlagHelper.isPastDueBYODFFlag());
    }

    @Test
    public void isPendingOrderRedirectionFFlagEnabledTest() {
        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.ACCOUNT_MANAGEMENT_CX, FeatureFlagConstants.PENDING_ORDER_REDIRECTION_FFLAG,
                false))
                .thenReturn(false);
        assertFalse(featureFlagHelper.isPendingOrderRedirectionFFlagEnabled());

        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.ACCOUNT_MANAGEMENT_CX, FeatureFlagConstants.PENDING_ORDER_REDIRECTION_FFLAG,
                false))
                .thenReturn(true);
        assertTrue(featureFlagHelper.isPendingOrderRedirectionFFlagEnabled());
    }

    @Test
    public void isSkipCartValidationOnUpdateCouponForFWATest() {
        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_FWA_DIFITAL, FeatureFlagConstants.ENHANCEMENTTRIAGE_PROFILE_CONFIG, FeatureFlagConstants.SKIP_VALIDATE_CART_FFLAG, false))
                .thenReturn(false);
        assertFalse(featureFlagHelper.isSkipCartValidationOnUpdateCouponForFWA());

        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_FWA_DIFITAL, FeatureFlagConstants.ENHANCEMENTTRIAGE_PROFILE_CONFIG, FeatureFlagConstants.SKIP_VALIDATE_CART_FFLAG, false))
                .thenReturn(true);
        assertTrue(featureFlagHelper.isSkipCartValidationOnUpdateCouponForFWA());
    }

    @Test
    public void isOneclkTaggingFFlagEnabledTest() {
        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME,
                FeatureFlagConstants.ONECLIK_TAGGING_FFLAG,
                false))
                .thenReturn(false);
        assertFalse(featureFlagHelper.isOneclkTaggingFFlagEnabled());

        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_UPG_CFG_PROFILE_NAME,
                FeatureFlagConstants.ONECLIK_TAGGING_FFLAG,
                false))
                .thenReturn(true);
        assertTrue(featureFlagHelper.isOneclkTaggingFFlagEnabled());
    }

    @Test
    public void testFetchUnifiedNBSFeatureFlag(){
        CartRedisData redisData = new CartRedisData();
        redisData.setMtn("1234567890");
        redisData.setAccountNumber("0987654321");

        when(featureFlagMock.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.UNIFIEDNBS_CONFIG_PROFILE,
                FeatureFlagConstants.FULLBLOWNNBS_THROTTLING, null, redisData.getMtn(), null, redisData.getAccountNumber(),
                null, null, false)).thenReturn(Mono.just(true));
        StepVerifier.create(featureFlagHelper.fetchUnifiedNBSFeatureFlag(redisData)).expectNext(true).verifyComplete();
    }

    @Test
    public void testIsHubProspectCartCookieDomainIssueFFlagEnabled() {
        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_PDP_CFG_PROFILE,
                FeatureFlagConstants.HUB_PROSPECT_CART_COOKIE_DOMAIN_ISSUE_FFLAG,
                false))
                .thenReturn(false);
        assertFalse(featureFlagHelper.isHubProspectCartCookieDomainIssueFFlagEnabled());

        when(featureFlagMock.isFeatureFlagEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL,
                FeatureFlagConstants.DIGITAL_PDP_CFG_PROFILE,
                FeatureFlagConstants.HUB_PROSPECT_CART_COOKIE_DOMAIN_ISSUE_FFLAG,
                false))
                .thenReturn(true);
        assertTrue(featureFlagHelper.isHubProspectCartCookieDomainIssueFFlagEnabled());
    }
}



