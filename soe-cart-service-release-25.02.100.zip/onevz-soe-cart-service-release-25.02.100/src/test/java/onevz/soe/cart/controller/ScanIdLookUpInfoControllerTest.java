package onevz.soe.cart.controller;

import static org.mockito.Mockito.when;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import onevz.soe.cart.helper.ScanIdLookUpInfoHelper;
import onevz.soe.cart.requests.ScanIdLookUpInfoRequest;
import onevz.soe.cart.responses.ScanIdLookUpInfoResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { CartServiceTestConfig.class })
public class ScanIdLookUpInfoControllerTest {
	@Autowired
	ObjectMapper mapper;
	
	@InjectMocks
	ScanIdLookUpInfoController controller;
	
	@Mock
	ScanIdLookUpInfoHelper helper;

	@Test
	public void scanIdLookUpInfoTest() throws JsonMappingException, JsonProcessingException {
		ScanIdLookUpInfoRequest request = new ScanIdLookUpInfoRequest();
		ScanIdLookUpInfoResponse response = new ScanIdLookUpInfoResponse();
		request.setGemaltoSessionid("5f3450a6-8887-4290-9695-40f534282266");

		String respString = "{ \"errors\": null, \"data\": { \"status\": 1, \"scanIdLookupInfoVo\": { \"firstName\": \"SUKHVINDER\", \"lastName\": \"MATHAROO\", \"addressLine1\": \"131 WINDSOR CT\", \"city\": \"EWING\", \"state\": \"NJ\", \"zip\": \"08638-1846\", \"dob\": \"1988-09-28\", \"gemaltoStatus\": \"NoFailedChecks\", \"docNum\": \"M08077268209882\", \"docTypeName\": \"New Jersey (NJ) Auto Driver License - Not For Federal ID 2020\", \"statusCode\": \"00\" } } }";
		response = mapper.readValue(respString, ScanIdLookUpInfoResponse.class);

		when(helper.scanIdLookUp(Mockito.any())).thenReturn(Mono.just(response));
		Mono<ScanIdLookUpInfoResponse> serviceResp = controller.scanIdLookUpInfo(request);
		StepVerifier.create(serviceResp).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete()
				.verify();

	}

}
