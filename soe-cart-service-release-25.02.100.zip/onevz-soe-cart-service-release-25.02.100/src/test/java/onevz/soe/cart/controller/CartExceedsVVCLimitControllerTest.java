package onevz.soe.cart.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.micrometer.core.instrument.util.IOUtils;
import lombok.extern.slf4j.Slf4j;
import onevz.soe.cart.helper.UpdateCartHelper;
import onevz.soe.cart.requests.CartExceedsLimitRequest;
import onevz.soe.cart.requests.RetrieveCartCXPRequest;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.ui.responses.CartExceedsLimitResponse;
import onevz.soe.cart.ui.responses.RetrieveCartUIResponse;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpResponse;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.nio.charset.StandardCharsets;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = {CartServiceTestConfig.class})
@WebFluxTest(CartExceedsVVCLimitController.class)
public class CartExceedsVVCLimitControllerTest {

    @Autowired
    private CartExceedsVVCLimitController cartExceedsVVCLimitController;

    @MockBean
    private UpdateCartHelper cartHelper;

    ObjectMapper mapper = new ObjectMapper();

    @Test
    public void getCartExceedsLimitDataTest() throws JsonProcessingException {

        String requestString = readFromFile("getCartExceedsLimit_request.json");
        String responseString = readFromFile("getCartExceedsLimit_response.json");
        CartExceedsLimitRequest request = mapper.readValue(requestString, CartExceedsLimitRequest.class);
        CartExceedsLimitResponse response = mapper.readValue(responseString, CartExceedsLimitResponse.class);
        URI url = URI.create("http://localhost/getCartExceedsLimit");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").build();
        MockServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatusCode.valueOf(200));
        when(cartHelper.getCartExceedsLimitService(any(),any(),any())).thenReturn(Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(response)));
        Mono<ResponseEntity<CartExceedsLimitResponse>> controllerResponse = cartExceedsVVCLimitController.getCartExceedsLimitData(httpHeader, httpResponse,
                request);
        Assert.assertNotNull(controllerResponse);
    }

    public static String readFromFile(String fileName) {

        ClassLoader classLoader = CartExceedsVVCLimitControllerTest.class.getClassLoader();

        try (InputStream inputStream = classLoader.getResourceAsStream(fileName)) {
            String result = IOUtils.toString(inputStream, StandardCharsets.UTF_8);
            return result;
        } catch (IOException e) {
            e.printStackTrace();
        }

        return "{}";
    }
}
