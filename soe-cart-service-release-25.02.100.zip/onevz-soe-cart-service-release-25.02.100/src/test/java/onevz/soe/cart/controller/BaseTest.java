package onevz.soe.cart.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.json.JsonSanitizer;
import lombok.extern.slf4j.Slf4j;
import onevz.soe.cart.constants.CartConstants;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = CartContextConfiguration.class)
@Slf4j
public abstract class BaseTest {
	
	@Autowired
	protected ObjectMapper objectMapper;
	
	protected  <T> T jsonToObject(String fileName, Class<T> type) throws IOException {
		String json = IOUtils.toString(Objects.requireNonNull(this.getClass().getResourceAsStream(fileName)), Charset.defaultCharset());
		return objectMapper.readValue(json, type);
	}
	
	protected static MockServerHttpRequest getMockServerHttpRequest() {
		return MockServerHttpRequest.method(HttpMethod.POST, "localhost")
				.header(CartConstants.CHANNEL_ID, CartConstants.VZW_DOTCOM)
				.build();
	}
	
	protected  <T> List<T> objectToList(Object data, TypeReference<List<T>> typeReference) {
		return objectMapper.convertValue(data, typeReference);
	}
	
	protected <T> T convertToPojo(Object data,Class<T> type) {
		return objectMapper.convertValue(data, type);
	}
	
	protected  <T> List<T> objectToList(String data, TypeReference<List<T>> typeReference) {
		try {
			return objectMapper.readValue(data, typeReference);
		} catch (JsonProcessingException e) {
			log.error("Unable to process the json {} ",e.getMessage() );
			return Collections.emptyList();
		}
	}
	
	protected <T> String convertToJson(T object) {
		try {
			return JsonSanitizer.sanitize(objectMapper.writeValueAsString(object));
		} catch (JsonProcessingException e) {
			log.error("Unable to process the json {} ",e.getMessage() );
			return StringUtils.EMPTY;
		}
	}
}
