package onevz.soe.cart.service.test.cases;

import static org.mockito.Mockito.when;

import java.io.IOException;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fasterxml.jackson.databind.ObjectMapper;

import onevz.soe.cart.bpm.helper.CartServiceBpmHelper;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper3;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.helper.AccessoryFinancingOffersHelper;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.AccessoryFinancingOffersUIRequest;
import onevz.soe.cart.ui.requests.AffirmFinancingUIRequest;
import onevz.soe.cart.ui.responses.AccessoryFinancingOffersUIResponse;
import onevz.soe.cart.ui.responses.AffirmFinancingUIResponse;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(AccessoryFinancingOffersHelper.class)
public class AccessoryFinancingOffersHelperTest {

	@Autowired
	private AccessoryFinancingOffersHelper accessoryFinancingOffersHelper;

	@MockBean
	private CartServiceBpmHelper bpmHelper;
	
	@MockBean
	private CartServiceBpmHelper3 bpmHelper3;

	@MockBean
	private RedisHelper redisHelper;

	@Autowired
	private ObjectMapper mapper;
	
	@Autowired
	SourceFileReaderUtil sourceFileReaderUtil;
	
	@Value("${onevz.soe.cart.test.fileLocation}")
	private String testFileLocation;
	

	@Test
	public void updateAccessoryFinancingOffersTest() throws IOException, SOEHTTPException {
		String requestFile = "UpdateAFOInfoRequest.json";
		String responseFile = "UpdateAFOInfoResponse.json";
		String redisFile = "MockRedisData.json";
		String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
		String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
		AccessoryFinancingOffersUIRequest sampleRequest = mapper.readValue(sampleRequestString, AccessoryFinancingOffersUIRequest.class);
		AccessoryFinancingOffersUIResponse sampleResponse = mapper.readValue(sampleResponseString, AccessoryFinancingOffersUIResponse.class);
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<AccessoryFinancingOffersUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper.updateAccessoryFinancingOffers(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		AccessoryFinancingOffersUIResponse expectedResponse = sampleResponse;
		Mono<AccessoryFinancingOffersUIResponse> response = accessoryFinancingOffersHelper.updateAccessoryFinancingOffers(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
		sampleRequest.getCartInfo().setIntendType(CartConstants.ADD_ACCESSORY);

		response = accessoryFinancingOffersHelper.updateAccessoryFinancingOffers(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRequest.getCartInfo().setIntendType(CartConstants.NSE_LTE);

		response = accessoryFinancingOffersHelper.updateAccessoryFinancingOffers(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRequest.getCartInfo().setIntendType(CartConstants.AAL_LTE);

		response = accessoryFinancingOffersHelper.updateAccessoryFinancingOffers(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRequest.getCartInfo().setIntendType(CartConstants.NSE_BYOD);

		response = accessoryFinancingOffersHelper.updateAccessoryFinancingOffers(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRequest.getCartInfo().setIntendType(CartConstants.AAL_5G);

		response = accessoryFinancingOffersHelper.updateAccessoryFinancingOffers(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRequest.getCartInfo().setIntendType(CartConstants.NSE_5G);

		response = accessoryFinancingOffersHelper.updateAccessoryFinancingOffers(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRequest.getCartInfo().setIntendType(CartConstants.BYOD);

		response = accessoryFinancingOffersHelper.updateAccessoryFinancingOffers(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRequest.getCartInfo().setIntendType(CartConstants.AAL);

		response = accessoryFinancingOffersHelper.updateAccessoryFinancingOffers(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRequest.getCartInfo().setIntendType(CartConstants.DEO);

		response = accessoryFinancingOffersHelper.updateAccessoryFinancingOffers(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

	}

	@Test
	public void updateAccessoryFinancingOffersErrorTest() throws IOException, SOEHTTPException {
		String requestFile = "UpdateAFOInfoRequest.json";
		String responseFile = "UpdateAFOInfoErrorResponse.json";
		//String redisFile = "MockRedisData.json";
		String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
		//String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
		AccessoryFinancingOffersUIRequest sampleRequest = mapper.readValue(sampleRequestString, AccessoryFinancingOffersUIRequest.class);
		sampleRequest.getCartInfo().setCartId("");
		AccessoryFinancingOffersUIResponse sampleResponse = mapper.readValue(sampleResponseString, AccessoryFinancingOffersUIResponse.class);
		CartRedisData sampleRedisData = new CartRedisData();
		Mono<AccessoryFinancingOffersUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper.updateAccessoryFinancingOffers(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		AccessoryFinancingOffersUIResponse expectedErrorResponse = sampleResponse;
		Mono<AccessoryFinancingOffersUIResponse> response = accessoryFinancingOffersHelper.updateAccessoryFinancingOffers(sampleRequest);

		response = accessoryFinancingOffersHelper.updateAccessoryFinancingOffers(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
		/*StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedErrorResponse, resp)).expectComplete()
				.verify();*/

	}

	@Test
	public void updateAccessoryFinancingOffersNSETest() throws IOException, SOEHTTPException {
		String requestFile = "UpdateAFOInfoNSERequest.json";
		String responseFile = "UpdateAFOInfoResponse.json";
		String redisFile = "MockRedisData.json";
		String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
		String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
		AccessoryFinancingOffersUIRequest sampleRequest = mapper.readValue(sampleRequestString, AccessoryFinancingOffersUIRequest.class);
		AccessoryFinancingOffersUIResponse sampleResponse = mapper.readValue(sampleResponseString, AccessoryFinancingOffersUIResponse.class);
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<AccessoryFinancingOffersUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper.updateAccessoryFinancingOffers(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		AccessoryFinancingOffersUIResponse expectedResponse = sampleResponse;
		Mono<AccessoryFinancingOffersUIResponse> response = accessoryFinancingOffersHelper.updateAccessoryFinancingOffers(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}
	
	@Test
	public void updateAffirmStatusTest() throws IOException, SOEHTTPException {
		String requestFile = "UpdateAffirmStatusRequest.json";
		String responseFile = "UpdateAffirmStatusResponse.json";
		String redisFile = "MockRedisData.json";
		String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
		String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
		AffirmFinancingUIRequest sampleRequest = mapper.readValue(sampleRequestString, AffirmFinancingUIRequest.class);
		AffirmFinancingUIResponse sampleResponse = mapper.readValue(sampleResponseString, AffirmFinancingUIResponse.class);
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRedisData.setProcessingMTN("1234567890");
		Mono<AffirmFinancingUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.updateAffirmFinancingStatus(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		AffirmFinancingUIResponse expectedResponse = sampleResponse;
		Mono<AffirmFinancingUIResponse> response = accessoryFinancingOffersHelper.updateAffirmFinancingStatus(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();

		sampleRequest.getCartInfo().setIntendType(CartConstants.EUP);

		response = accessoryFinancingOffersHelper.updateAffirmFinancingStatus(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}
	
	@Test
	public void updateAffirmStatusErrorTest() throws IOException, SOEHTTPException {
		String requestFile = "UpdateAffirmStatusRequest.json";
		String responseFile = "UpdateAffirmStatusErrorResponse.json";
		String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
		AffirmFinancingUIRequest sampleRequest = mapper.readValue(sampleRequestString, AffirmFinancingUIRequest.class);
		sampleRequest.getCartInfo().setCartId("");
		AffirmFinancingUIResponse sampleResponse = mapper.readValue(sampleResponseString, AffirmFinancingUIResponse.class);
		CartRedisData sampleRedisData = new CartRedisData();
		Mono<AffirmFinancingUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.updateAffirmFinancingStatus(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		Mono<AffirmFinancingUIResponse> response = accessoryFinancingOffersHelper.updateAffirmFinancingStatus(sampleRequest);

		response = accessoryFinancingOffersHelper.updateAffirmFinancingStatus(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

	}
	
	@Test
	public void updateAffirmStatusNSETest() throws IOException, SOEHTTPException {
		String requestFile = "UpdateAFOInfoNSERequest.json";
		String responseFile = "UpdateAffirmStatusResponse.json";
		String redisFile = "MockRedisData.json";
		String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
		String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
		AffirmFinancingUIRequest sampleRequest = mapper.readValue(sampleRequestString, AffirmFinancingUIRequest.class);
		AffirmFinancingUIResponse sampleResponse = mapper.readValue(sampleResponseString, AffirmFinancingUIResponse.class);
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<AffirmFinancingUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.updateAffirmFinancingStatus(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		AffirmFinancingUIResponse expectedResponse = sampleResponse;
		Mono<AffirmFinancingUIResponse> response = accessoryFinancingOffersHelper.updateAffirmFinancingStatus(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}
	
	@Test
	public void updateAccessoryFinancingOffersTest2() throws IOException, SOEHTTPException {
		String requestFile = "{\"channelId\": \"OMNI-TELESALES\",\"cartInfo\": {\"cartId\": \"\",\"caseId\": \"id\",\"cartCreator\": \"2693657984\",\"processingMTN\": \"2693657984\",\"processStep\": \"VerizonVisaCardAFO\",\"intendType\": \"NSE\",\"action\": \"UPDATE\"},\"offerAccepted\": true,\"disclosureAgreementSent\": false}";
		String responseFile = "{\"serviceHeader\": {\"clientId\": \"OMNI-RETAIL\",\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"soe-cart-2022.06.03.08.14.03-593.0156284657792\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"contextInfo\": {\"availablePaths\": [{\"path\": \"VerizonVisaCardAfo\"}],\"callReason\": \"SalesOrderPurchase\",\"processStep\": \"VerizonVisaCardAfo\",\"processAction\": \"updateAccessoryFinancingInfo\"},\"customerInfo\": {\"accountNumber\": \"0280645944-00002\",\"cartCreator\": \"2693657984\",\"processingMTN\": \"2693657984\",\"registerNumber\": 0},\"cartInfo\": {\"cartItemCount\": 0,\"cartId\": \"76bc10e5-6067-41e5-871b-bdeb9269402a\",\"statusMsg\": \"Success\",\"statusCode\": \"1\",\"preAuthSuccess\": false,\"discountPromoTotal\": 0.0,\"registerNumber\": 0,\"protectionNotRequired\": false},\"processMTNList\": [{\"mtn\": \"2693657984\",\"completedprocessSteps\": []}],\"caseId\": \"SOP-7281471-E01\"}}}}";
		String redisFile = "{\"processingMTN\": \"2693657984\",\"creditAppNum\": \"credit\",\"cartId\": \"\",\"caseId\": \"SOP-6849878-E01\",\"accountNumber\": \"0216897840-00001\",\"mtn\": \"5402305402\",\"cartCreator\": \"5402305402\",\"cartCount\": \"1\",\"cartOrderFlowType\": \"eup\",\"locationCode\": \"0026301\",\"storeLocationState\": \"NJ\",\"customerAddressState\": \"VA\",\"isSmartphone\": false,\"isAppleDevice\": false,\"safeTechSessionId\": \"xkaTw8nHlJPyfp3761fL00uB\",\"verifiedName\": \"RYAN CANU\",\"creditCheckFailedCount\": 0,\"autoPayEnrolled\": \"false\",\"repId\": \"ENC\",\"storeName\": \"ATLANTIC CITY COMM STORE\",\"loggedInUser\": \"chamasi\",\"isfiveGUpSellSelected\": false,\"isDirectApply\": true,\"intendType\": \"AAL_CBD_TECH\",\"mtnFlow\": \"G\"}";
		AccessoryFinancingOffersUIRequest sampleRequest = mapper.readValue(requestFile, AccessoryFinancingOffersUIRequest.class);
		AccessoryFinancingOffersUIResponse sampleResponse = mapper.readValue(responseFile, AccessoryFinancingOffersUIResponse.class);
		CartRedisData sampleRedisData = mapper.readValue(redisFile, CartRedisData.class);
		when(bpmHelper.updateAccessoryFinancingOffers(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		Mono<AccessoryFinancingOffersUIResponse> response = accessoryFinancingOffersHelper.updateAccessoryFinancingOffers(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getErrors())).expectComplete().verify();
	}
	
	@Test
	public void updateAccessoryFinancingOffersTest3() throws IOException, SOEHTTPException {
		String requestFile = "{\"channelId\": \"OMNI-TELESALES\",\"cartInfo\": {\"caseId\": \"id\",\"cartCreator\": \"2693657984\",\"processingMTN\": \"\",\"processStep\": \"VerizonVisaCardAFO\",\"intendType\": \"\",\"action\": \"UPDATE\"},\"offerAccepted\": true,\"disclosureAgreementSent\": false}";
		String responseFile = "{\"serviceHeader\": {\"clientId\": \"OMNI-RETAIL\",\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"soe-cart-2022.06.03.08.14.03-593.0156284657792\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"contextInfo\": {\"availablePaths\": [{\"path\": \"VerizonVisaCardAfo\"}],\"callReason\": \"SalesOrderPurchase\",\"processStep\": \"VerizonVisaCardAfo\",\"processAction\": \"updateAccessoryFinancingInfo\"},\"customerInfo\": {\"accountNumber\": \"0280645944-00002\",\"cartCreator\": \"2693657984\",\"processingMTN\": \"2693657984\",\"registerNumber\": 0},\"cartInfo\": {\"cartItemCount\": 0,\"cartId\": \"76bc10e5-6067-41e5-871b-bdeb9269402a\",\"statusMsg\": \"Success\",\"statusCode\": \"1\",\"preAuthSuccess\": false,\"discountPromoTotal\": 0.0,\"registerNumber\": 0,\"protectionNotRequired\": false},\"processMTNList\": [{\"mtn\": \"2693657984\",\"completedprocessSteps\": []}],\"caseId\": \"SOP-7281471-E01\"}}}}";
		String redisFile = "{\"processingMTN\": \"2693657984\",\"creditAppNum\": \"credit\",\"cartId\": \"27a75fed-e393-46bf-a42c-87345a0a0536\",\"caseId\": \"SOP-6849878-E01\",\"accountNumber\": \"0216897840-00001\",\"mtn\": \"5402305402\",\"cartCreator\": \"5402305402\",\"cartCount\": \"1\",\"cartOrderFlowType\": \"eup\",\"locationCode\": \"0026301\",\"storeLocationState\": \"NJ\",\"customerAddressState\": \"VA\",\"isSmartphone\": false,\"isAppleDevice\": false,\"safeTechSessionId\": \"xkaTw8nHlJPyfp3761fL00uB\",\"verifiedName\": \"RYAN CANU\",\"creditCheckFailedCount\": 0,\"autoPayEnrolled\": \"false\",\"repId\": \"ENC\",\"storeName\": \"ATLANTIC CITY COMM STORE\",\"loggedInUser\": \"chamasi\",\"isfiveGUpSellSelected\": false,\"isDirectApply\": true,\"intendType\": \"AAL_CBD_TECH\",\"mtnFlow\": \"G\"}";
		AccessoryFinancingOffersUIRequest sampleRequest = mapper.readValue(requestFile, AccessoryFinancingOffersUIRequest.class);
		AccessoryFinancingOffersUIResponse sampleResponse = mapper.readValue(responseFile, AccessoryFinancingOffersUIResponse.class);
		CartRedisData sampleRedisData = mapper.readValue(redisFile, CartRedisData.class);
		when(bpmHelper.updateAccessoryFinancingOffers(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		AccessoryFinancingOffersUIResponse expectedResponse = sampleResponse;
		Mono<AccessoryFinancingOffersUIResponse> response = accessoryFinancingOffersHelper.updateAccessoryFinancingOffers(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
	}
	
	@Test
	public void updateAccessoryFinancingOffersTest4() throws IOException, SOEHTTPException {
		String requestFile = "{\"channelId\": \"OMNI-TELESALES\",\"cartInfo\": {\"cartId\": \"id\",\"caseId\": \"id\",\"cartCreator\": \"2693657984\",\"processingMTN\": \"\",\"processStep\": \"VerizonVisaCardAFO\",\"intendType\": \"\",\"action\": \"UPDATE\"},\"offerAccepted\": true,\"disclosureAgreementSent\": false}";
		String responseFile = "{\"serviceHeader\": {\"clientId\": \"OMNI-RETAIL\",\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"soe-cart-2022.06.03.08.14.03-593.0156284657792\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"contextInfo\": {\"availablePaths\": [{\"path\": \"VerizonVisaCardAfo\"}],\"callReason\": \"SalesOrderPurchase\",\"processStep\": \"VerizonVisaCardAfo\",\"processAction\": \"updateAccessoryFinancingInfo\"},\"customerInfo\": {\"accountNumber\": \"0280645944-00002\",\"cartCreator\": \"2693657984\",\"processingMTN\": \"2693657984\",\"registerNumber\": 0},\"cartInfo\": {\"cartItemCount\": 0,\"cartId\": \"76bc10e5-6067-41e5-871b-bdeb9269402a\",\"statusMsg\": \"Success\",\"statusCode\": \"1\",\"preAuthSuccess\": false,\"discountPromoTotal\": 0.0,\"registerNumber\": 0,\"protectionNotRequired\": false},\"processMTNList\": [{\"mtn\": \"2693657984\",\"completedprocessSteps\": []}],\"caseId\": \"SOP-7281471-E01\"}}}}";
		String redisFile = "{\"processingMTN\": \"\",\"creditAppNum\": \"\",\"cartId\": \"27a75fed-e393-46bf-a42c-87345a0a0536\",\"caseId\": \"SOP-6849878-E01\",\"accountNumber\": \"0216897840-00001\",\"mtn\": \"5402305402\",\"cartCreator\": \"5402305402\",\"cartCount\": \"1\",\"cartOrderFlowType\": \"eup\",\"locationCode\": \"0026301\",\"storeLocationState\": \"NJ\",\"customerAddressState\": \"VA\",\"isSmartphone\": false,\"isAppleDevice\": false,\"safeTechSessionId\": \"xkaTw8nHlJPyfp3761fL00uB\",\"verifiedName\": \"RYAN CANU\",\"creditCheckFailedCount\": 0,\"autoPayEnrolled\": \"false\",\"repId\": \"ENC\",\"storeName\": \"ATLANTIC CITY COMM STORE\",\"loggedInUser\": \"chamasi\",\"isfiveGUpSellSelected\": false,\"isDirectApply\": true,\"intendType\": \"AAL_CBD_TECH\",\"mtnFlow\": \"G\"}";
		AccessoryFinancingOffersUIRequest sampleRequest = mapper.readValue(requestFile, AccessoryFinancingOffersUIRequest.class);
		AccessoryFinancingOffersUIResponse sampleResponse = mapper.readValue(responseFile, AccessoryFinancingOffersUIResponse.class);
		CartRedisData sampleRedisData = mapper.readValue(redisFile, CartRedisData.class);
		when(bpmHelper.updateAccessoryFinancingOffers(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		AccessoryFinancingOffersUIResponse expectedResponse = sampleResponse;
		Mono<AccessoryFinancingOffersUIResponse> response = accessoryFinancingOffersHelper.updateAccessoryFinancingOffers(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
	}
	
	@Test
	public void updateAccessoryFinancingOffersTest5() throws IOException, SOEHTTPException {
		String requestFile = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"cartId\": \"id\",\"caseId\": \"id\",\"cartCreator\": \"2693657984\",\"processingMTN\": \"\",\"processStep\": \"VerizonVisaCardAFO\",\"intendType\": \"\",\"action\": \"UPDATE\"},\"offerAccepted\": true,\"disclosureAgreementSent\": false}";
		String responseFile = "{\"serviceHeader\": {\"clientId\": \"OMNI-RETAIL\",\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"soe-cart-2022.06.03.08.14.03-593.0156284657792\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"contextInfo\": {\"availablePaths\": [{\"path\": \"VerizonVisaCardAfo\"}],\"callReason\": \"SalesOrderPurchase\",\"processStep\": \"VerizonVisaCardAfo\",\"processAction\": \"updateAccessoryFinancingInfo\"},\"customerInfo\": {\"accountNumber\": \"0280645944-00002\",\"cartCreator\": \"2693657984\",\"processingMTN\": \"2693657984\",\"registerNumber\": 0},\"cartInfo\": {\"cartItemCount\": 0,\"cartId\": \"76bc10e5-6067-41e5-871b-bdeb9269402a\",\"statusMsg\": \"Success\",\"statusCode\": \"1\",\"preAuthSuccess\": false,\"discountPromoTotal\": 0.0,\"registerNumber\": 0,\"protectionNotRequired\": false},\"processMTNList\": [{\"mtn\": \"2693657984\",\"completedprocessSteps\": []}],\"caseId\": \"SOP-7281471-E01\"}}}}";
		String redisFile = "{\"processingMTN\": \"\",\"creditAppNum\": \"\",\"cartId\": \"27a75fed-e393-46bf-a42c-87345a0a0536\",\"caseId\": \"SOP-6849878-E01\",\"accountNumber\": \"0216897840-00001\",\"mtn\": \"5402305402\",\"cartCreator\": \"5402305402\",\"cartCount\": \"1\",\"cartOrderFlowType\": \"eup\",\"locationCode\": \"0026301\",\"storeLocationState\": \"NJ\",\"customerAddressState\": \"VA\",\"isSmartphone\": false,\"isAppleDevice\": false,\"safeTechSessionId\": \"xkaTw8nHlJPyfp3761fL00uB\",\"verifiedName\": \"RYAN CANU\",\"creditCheckFailedCount\": 0,\"autoPayEnrolled\": \"false\",\"repId\": \"ENC\",\"storeName\": \"ATLANTIC CITY COMM STORE\",\"loggedInUser\": \"chamasi\",\"isfiveGUpSellSelected\": false,\"isDirectApply\": true,\"intendType\": \"AAL_CBD_TECH\",\"mtnFlow\": \"G\"}";
		AccessoryFinancingOffersUIRequest sampleRequest = mapper.readValue(requestFile, AccessoryFinancingOffersUIRequest.class);
		AccessoryFinancingOffersUIResponse sampleResponse = mapper.readValue(responseFile, AccessoryFinancingOffersUIResponse.class);
		CartRedisData sampleRedisData = mapper.readValue(redisFile, CartRedisData.class);
		when(bpmHelper.updateAccessoryFinancingOffers(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		AccessoryFinancingOffersUIResponse expectedResponse = sampleResponse;
		Mono<AccessoryFinancingOffersUIResponse> response = accessoryFinancingOffersHelper.updateAccessoryFinancingOffers(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
	}
	
	@Test
	public void updateAccessoryFinancingOffersTest6() throws IOException, SOEHTTPException {
		String requestFile = "{\"channelId\": \"\",\"cartInfo\": {\"cartId\": \"id\",\"caseId\": \"id\",\"cartCreator\": \"2693657984\",\"processingMTN\": \"\",\"processStep\": \"VerizonVisaCardAFO\",\"intendType\": \"\",\"action\": \"UPDATE\"},\"offerAccepted\": true,\"disclosureAgreementSent\": false}";
		String responseFile = "{\"serviceHeader\": {\"clientId\": \"OMNI-RETAIL\",\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"soe-cart-2022.06.03.08.14.03-593.0156284657792\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"contextInfo\": {\"availablePaths\": [{\"path\": \"VerizonVisaCardAfo\"}],\"callReason\": \"SalesOrderPurchase\",\"processStep\": \"VerizonVisaCardAfo\",\"processAction\": \"updateAccessoryFinancingInfo\"},\"customerInfo\": {\"accountNumber\": \"0280645944-00002\",\"cartCreator\": \"2693657984\",\"processingMTN\": \"2693657984\",\"registerNumber\": 0},\"cartInfo\": {\"cartItemCount\": 0,\"cartId\": \"76bc10e5-6067-41e5-871b-bdeb9269402a\",\"statusMsg\": \"Success\",\"statusCode\": \"1\",\"preAuthSuccess\": false,\"discountPromoTotal\": 0.0,\"registerNumber\": 0,\"protectionNotRequired\": false},\"processMTNList\": [{\"mtn\": \"2693657984\",\"completedprocessSteps\": []}],\"caseId\": \"SOP-7281471-E01\"}}}}";
		String redisFile = "{\"processingMTN\": \"\",\"creditAppNum\": \"\",\"cartId\": \"27a75fed-e393-46bf-a42c-87345a0a0536\",\"caseId\": \"SOP-6849878-E01\",\"accountNumber\": \"0216897840-00001\",\"mtn\": \"5402305402\",\"cartCreator\": \"5402305402\",\"cartCount\": \"1\",\"cartOrderFlowType\": \"eup\",\"locationCode\": \"0026301\",\"storeLocationState\": \"NJ\",\"customerAddressState\": \"VA\",\"isSmartphone\": false,\"isAppleDevice\": false,\"safeTechSessionId\": \"xkaTw8nHlJPyfp3761fL00uB\",\"verifiedName\": \"RYAN CANU\",\"creditCheckFailedCount\": 0,\"autoPayEnrolled\": \"false\",\"repId\": \"ENC\",\"storeName\": \"ATLANTIC CITY COMM STORE\",\"loggedInUser\": \"chamasi\",\"isfiveGUpSellSelected\": false,\"isDirectApply\": true,\"intendType\": \"AAL_CBD_TECH\",\"mtnFlow\": \"G\"}";
		AccessoryFinancingOffersUIRequest sampleRequest = mapper.readValue(requestFile, AccessoryFinancingOffersUIRequest.class);
		AccessoryFinancingOffersUIResponse sampleResponse = mapper.readValue(responseFile, AccessoryFinancingOffersUIResponse.class);
		CartRedisData sampleRedisData = mapper.readValue(redisFile, CartRedisData.class);
		when(bpmHelper.updateAccessoryFinancingOffers(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		AccessoryFinancingOffersUIResponse expectedResponse = sampleResponse;
		Mono<AccessoryFinancingOffersUIResponse> response = accessoryFinancingOffersHelper.updateAccessoryFinancingOffers(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
	}
	
	@Test
	public void updateAffirmFinancingStatusTest2() throws IOException, SOEHTTPException {
		String requestFile = "{\"channelId\": \"OMNI-TELESALES\",\"cartInfo\": {\"cartId\": \"\",\"caseId\": \"id\",\"cartCreator\": \"2693657984\",\"processingMTN\": \"2693657984\",\"processStep\": \"VerizonVisaCardAFO\",\"intendType\": \"NSE\",\"action\": \"UPDATE\"},\"offerAccepted\": true,\"disclosureAgreementSent\": false}";
		String responseFile = "{\"serviceHeader\": {\"clientId\": \"OMNI-RETAIL\",\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"soe-cart-2022.06.03.08.14.03-593.0156284657792\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"contextInfo\": {\"availablePaths\": [{\"path\": \"VerizonVisaCardAfo\"}],\"callReason\": \"SalesOrderPurchase\",\"processStep\": \"VerizonVisaCardAfo\",\"processAction\": \"updateAccessoryFinancingInfo\"},\"customerInfo\": {\"accountNumber\": \"0280645944-00002\",\"cartCreator\": \"2693657984\",\"processingMTN\": \"2693657984\",\"registerNumber\": 0},\"cartInfo\": {\"cartItemCount\": 0,\"cartId\": \"76bc10e5-6067-41e5-871b-bdeb9269402a\",\"statusMsg\": \"Success\",\"statusCode\": \"1\",\"preAuthSuccess\": false,\"discountPromoTotal\": 0.0,\"registerNumber\": 0,\"protectionNotRequired\": false},\"processMTNList\": [{\"mtn\": \"2693657984\",\"completedprocessSteps\": []}],\"caseId\": \"SOP-7281471-E01\"}}}}";
		String redisFile = "{\"processingMTN\": \"2693657984\",\"creditAppNum\": \"credit\",\"cartId\": \"\",\"caseId\": \"SOP-6849878-E01\",\"accountNumber\": \"0216897840-00001\",\"mtn\": \"5402305402\",\"cartCreator\": \"5402305402\",\"cartCount\": \"1\",\"cartOrderFlowType\": \"eup\",\"locationCode\": \"0026301\",\"storeLocationState\": \"NJ\",\"customerAddressState\": \"VA\",\"isSmartphone\": false,\"isAppleDevice\": false,\"safeTechSessionId\": \"xkaTw8nHlJPyfp3761fL00uB\",\"verifiedName\": \"RYAN CANU\",\"creditCheckFailedCount\": 0,\"autoPayEnrolled\": \"false\",\"repId\": \"ENC\",\"storeName\": \"ATLANTIC CITY COMM STORE\",\"loggedInUser\": \"chamasi\",\"isfiveGUpSellSelected\": false,\"isDirectApply\": true,\"intendType\": \"AAL_CBD_TECH\",\"mtnFlow\": \"G\"}";
		AffirmFinancingUIRequest sampleRequest = mapper.readValue(requestFile, AffirmFinancingUIRequest.class);
		AffirmFinancingUIResponse sampleResponse = mapper.readValue(responseFile, AffirmFinancingUIResponse.class);
		CartRedisData sampleRedisData = mapper.readValue(redisFile, CartRedisData.class);
		when(bpmHelper3.updateAffirmFinancingStatus(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		Mono<AffirmFinancingUIResponse> response = accessoryFinancingOffersHelper.updateAffirmFinancingStatus(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getErrors())).expectComplete().verify();
	}
	
	@Test
	public void updateAffirmFinancingStatusTest3() throws IOException, SOEHTTPException {
		String requestFile = "{\"channelId\": \"OMNI-TELESALES\",\"cartInfo\": {\"caseId\": \"id\",\"cartCreator\": \"2693657984\",\"processingMTN\": \"\",\"processStep\": \"VerizonVisaCardAFO\",\"intendType\": \"\",\"action\": \"UPDATE\"},\"offerAccepted\": true,\"disclosureAgreementSent\": false}";
		String responseFile = "{\"serviceHeader\": {\"clientId\": \"OMNI-RETAIL\",\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"soe-cart-2022.06.03.08.14.03-593.0156284657792\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"contextInfo\": {\"availablePaths\": [{\"path\": \"VerizonVisaCardAfo\"}],\"callReason\": \"SalesOrderPurchase\",\"processStep\": \"VerizonVisaCardAfo\",\"processAction\": \"updateAccessoryFinancingInfo\"},\"customerInfo\": {\"accountNumber\": \"0280645944-00002\",\"cartCreator\": \"2693657984\",\"processingMTN\": \"2693657984\",\"registerNumber\": 0},\"cartInfo\": {\"cartItemCount\": 0,\"cartId\": \"76bc10e5-6067-41e5-871b-bdeb9269402a\",\"statusMsg\": \"Success\",\"statusCode\": \"1\",\"preAuthSuccess\": false,\"discountPromoTotal\": 0.0,\"registerNumber\": 0,\"protectionNotRequired\": false},\"processMTNList\": [{\"mtn\": \"2693657984\",\"completedprocessSteps\": []}],\"caseId\": \"SOP-7281471-E01\"}}}}";
		String redisFile = "{\"processingMTN\": \"2693657984\",\"creditAppNum\": \"credit\",\"cartId\": \"27a75fed-e393-46bf-a42c-87345a0a0536\",\"caseId\": \"SOP-6849878-E01\",\"accountNumber\": \"0216897840-00001\",\"mtn\": \"5402305402\",\"cartCreator\": \"5402305402\",\"cartCount\": \"1\",\"cartOrderFlowType\": \"eup\",\"locationCode\": \"0026301\",\"storeLocationState\": \"NJ\",\"customerAddressState\": \"VA\",\"isSmartphone\": false,\"isAppleDevice\": false,\"safeTechSessionId\": \"xkaTw8nHlJPyfp3761fL00uB\",\"verifiedName\": \"RYAN CANU\",\"creditCheckFailedCount\": 0,\"autoPayEnrolled\": \"false\",\"repId\": \"ENC\",\"storeName\": \"ATLANTIC CITY COMM STORE\",\"loggedInUser\": \"chamasi\",\"isfiveGUpSellSelected\": false,\"isDirectApply\": true,\"intendType\": \"AAL_CBD_TECH\",\"mtnFlow\": \"G\"}";
		AffirmFinancingUIRequest sampleRequest = mapper.readValue(requestFile, AffirmFinancingUIRequest.class);
		AffirmFinancingUIResponse sampleResponse = mapper.readValue(responseFile, AffirmFinancingUIResponse.class);
		CartRedisData sampleRedisData = mapper.readValue(redisFile, CartRedisData.class);
		when(bpmHelper3.updateAffirmFinancingStatus(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		AffirmFinancingUIResponse expectedResponse = sampleResponse;
		Mono<AffirmFinancingUIResponse> response = accessoryFinancingOffersHelper.updateAffirmFinancingStatus(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
	}
	
	@Test
	public void updateAffirmFinancingStatusTest4() throws IOException, SOEHTTPException {
		String requestFile = "{\"channelId\": \"OMNI-TELESALES\",\"cartInfo\": {\"cartId\": \"id\",\"caseId\": \"id\",\"cartCreator\": \"2693657984\",\"processingMTN\": \"\",\"processStep\": \"VerizonVisaCardAFO\",\"intendType\": \"\",\"action\": \"UPDATE\"},\"offerAccepted\": true,\"disclosureAgreementSent\": false}";
		String responseFile = "{\"serviceHeader\": {\"clientId\": \"OMNI-RETAIL\",\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"soe-cart-2022.06.03.08.14.03-593.0156284657792\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"contextInfo\": {\"availablePaths\": [{\"path\": \"VerizonVisaCardAfo\"}],\"callReason\": \"SalesOrderPurchase\",\"processStep\": \"VerizonVisaCardAfo\",\"processAction\": \"updateAccessoryFinancingInfo\"},\"customerInfo\": {\"accountNumber\": \"0280645944-00002\",\"cartCreator\": \"2693657984\",\"processingMTN\": \"2693657984\",\"registerNumber\": 0},\"cartInfo\": {\"cartItemCount\": 0,\"cartId\": \"76bc10e5-6067-41e5-871b-bdeb9269402a\",\"statusMsg\": \"Success\",\"statusCode\": \"1\",\"preAuthSuccess\": false,\"discountPromoTotal\": 0.0,\"registerNumber\": 0,\"protectionNotRequired\": false},\"processMTNList\": [{\"mtn\": \"2693657984\",\"completedprocessSteps\": []}],\"caseId\": \"SOP-7281471-E01\"}}}}";
		String redisFile = "{\"processingMTN\": \"\",\"creditAppNum\": \"\",\"cartId\": \"27a75fed-e393-46bf-a42c-87345a0a0536\",\"caseId\": \"SOP-6849878-E01\",\"accountNumber\": \"0216897840-00001\",\"mtn\": \"5402305402\",\"cartCreator\": \"5402305402\",\"cartCount\": \"1\",\"cartOrderFlowType\": \"eup\",\"locationCode\": \"0026301\",\"storeLocationState\": \"NJ\",\"customerAddressState\": \"VA\",\"isSmartphone\": false,\"isAppleDevice\": false,\"safeTechSessionId\": \"xkaTw8nHlJPyfp3761fL00uB\",\"verifiedName\": \"RYAN CANU\",\"creditCheckFailedCount\": 0,\"autoPayEnrolled\": \"false\",\"repId\": \"ENC\",\"storeName\": \"ATLANTIC CITY COMM STORE\",\"loggedInUser\": \"chamasi\",\"isfiveGUpSellSelected\": false,\"isDirectApply\": true,\"intendType\": \"AAL_CBD_TECH\",\"mtnFlow\": \"G\"}";
		AffirmFinancingUIRequest sampleRequest = mapper.readValue(requestFile, AffirmFinancingUIRequest.class);
		AffirmFinancingUIResponse sampleResponse = mapper.readValue(responseFile, AffirmFinancingUIResponse.class);
		CartRedisData sampleRedisData = mapper.readValue(redisFile, CartRedisData.class);
		when(bpmHelper3.updateAffirmFinancingStatus(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		AffirmFinancingUIResponse expectedResponse = sampleResponse;
		Mono<AffirmFinancingUIResponse> response = accessoryFinancingOffersHelper.updateAffirmFinancingStatus(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
	}
	
	@Test
	public void updateAffirmFinancingStatusTest5() throws IOException, SOEHTTPException {
		String requestFile = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"cartId\": \"id\",\"caseId\": \"id\",\"cartCreator\": \"2693657984\",\"processingMTN\": \"\",\"processStep\": \"VerizonVisaCardAFO\",\"intendType\": \"\",\"action\": \"UPDATE\"},\"offerAccepted\": true,\"disclosureAgreementSent\": false}";
		String responseFile = "{\"serviceHeader\": {\"clientId\": \"OMNI-RETAIL\",\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"soe-cart-2022.06.03.08.14.03-593.0156284657792\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"contextInfo\": {\"availablePaths\": [{\"path\": \"VerizonVisaCardAfo\"}],\"callReason\": \"SalesOrderPurchase\",\"processStep\": \"VerizonVisaCardAfo\",\"processAction\": \"updateAccessoryFinancingInfo\"},\"customerInfo\": {\"accountNumber\": \"0280645944-00002\",\"cartCreator\": \"2693657984\",\"processingMTN\": \"2693657984\",\"registerNumber\": 0},\"cartInfo\": {\"cartItemCount\": 0,\"cartId\": \"76bc10e5-6067-41e5-871b-bdeb9269402a\",\"statusMsg\": \"Success\",\"statusCode\": \"1\",\"preAuthSuccess\": false,\"discountPromoTotal\": 0.0,\"registerNumber\": 0,\"protectionNotRequired\": false},\"processMTNList\": [{\"mtn\": \"2693657984\",\"completedprocessSteps\": []}],\"caseId\": \"SOP-7281471-E01\"}}}}";
		String redisFile = "{\"processingMTN\": \"\",\"creditAppNum\": \"\",\"cartId\": \"27a75fed-e393-46bf-a42c-87345a0a0536\",\"caseId\": \"SOP-6849878-E01\",\"accountNumber\": \"0216897840-00001\",\"mtn\": \"5402305402\",\"cartCreator\": \"5402305402\",\"cartCount\": \"1\",\"cartOrderFlowType\": \"eup\",\"locationCode\": \"0026301\",\"storeLocationState\": \"NJ\",\"customerAddressState\": \"VA\",\"isSmartphone\": false,\"isAppleDevice\": false,\"safeTechSessionId\": \"xkaTw8nHlJPyfp3761fL00uB\",\"verifiedName\": \"RYAN CANU\",\"creditCheckFailedCount\": 0,\"autoPayEnrolled\": \"false\",\"repId\": \"ENC\",\"storeName\": \"ATLANTIC CITY COMM STORE\",\"loggedInUser\": \"chamasi\",\"isfiveGUpSellSelected\": false,\"isDirectApply\": true,\"intendType\": \"AAL_CBD_TECH\",\"mtnFlow\": \"G\"}";
		AffirmFinancingUIRequest sampleRequest = mapper.readValue(requestFile, AffirmFinancingUIRequest.class);
		AffirmFinancingUIResponse sampleResponse = mapper.readValue(responseFile, AffirmFinancingUIResponse.class);
		CartRedisData sampleRedisData = mapper.readValue(redisFile, CartRedisData.class);
		when(bpmHelper3.updateAffirmFinancingStatus(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		AffirmFinancingUIResponse expectedResponse = sampleResponse;
		Mono<AffirmFinancingUIResponse> response = accessoryFinancingOffersHelper.updateAffirmFinancingStatus(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
	}
	
	@Test
	public void updateAffirmFinancingStatusTest6() throws IOException, SOEHTTPException {
		String requestFile = "{\"channelId\": \"\",\"cartInfo\": {\"cartId\": \"id\",\"caseId\": \"id\",\"cartCreator\": \"2693657984\",\"processingMTN\": \"\",\"processStep\": \"VerizonVisaCardAFO\",\"intendType\": \"\",\"action\": \"UPDATE\"},\"offerAccepted\": true,\"disclosureAgreementSent\": false}";
		String responseFile = "{\"serviceHeader\": {\"clientId\": \"OMNI-RETAIL\",\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"soe-cart-2022.06.03.08.14.03-593.0156284657792\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"contextInfo\": {\"availablePaths\": [{\"path\": \"VerizonVisaCardAfo\"}],\"callReason\": \"SalesOrderPurchase\",\"processStep\": \"VerizonVisaCardAfo\",\"processAction\": \"updateAccessoryFinancingInfo\"},\"customerInfo\": {\"accountNumber\": \"0280645944-00002\",\"cartCreator\": \"2693657984\",\"processingMTN\": \"2693657984\",\"registerNumber\": 0},\"cartInfo\": {\"cartItemCount\": 0,\"cartId\": \"76bc10e5-6067-41e5-871b-bdeb9269402a\",\"statusMsg\": \"Success\",\"statusCode\": \"1\",\"preAuthSuccess\": false,\"discountPromoTotal\": 0.0,\"registerNumber\": 0,\"protectionNotRequired\": false},\"processMTNList\": [{\"mtn\": \"2693657984\",\"completedprocessSteps\": []}],\"caseId\": \"SOP-7281471-E01\"}}}}";
		String redisFile = "{\"processingMTN\": \"\",\"creditAppNum\": \"\",\"cartId\": \"27a75fed-e393-46bf-a42c-87345a0a0536\",\"caseId\": \"SOP-6849878-E01\",\"accountNumber\": \"0216897840-00001\",\"mtn\": \"5402305402\",\"cartCreator\": \"5402305402\",\"cartCount\": \"1\",\"cartOrderFlowType\": \"eup\",\"locationCode\": \"0026301\",\"storeLocationState\": \"NJ\",\"customerAddressState\": \"VA\",\"isSmartphone\": false,\"isAppleDevice\": false,\"safeTechSessionId\": \"xkaTw8nHlJPyfp3761fL00uB\",\"verifiedName\": \"RYAN CANU\",\"creditCheckFailedCount\": 0,\"autoPayEnrolled\": \"false\",\"repId\": \"ENC\",\"storeName\": \"ATLANTIC CITY COMM STORE\",\"loggedInUser\": \"chamasi\",\"isfiveGUpSellSelected\": false,\"isDirectApply\": true,\"intendType\": \"AAL_CBD_TECH\",\"mtnFlow\": \"G\"}";
		AffirmFinancingUIRequest sampleRequest = mapper.readValue(requestFile, AffirmFinancingUIRequest.class);
		AffirmFinancingUIResponse sampleResponse = mapper.readValue(responseFile, AffirmFinancingUIResponse.class);
		CartRedisData sampleRedisData = mapper.readValue(redisFile, CartRedisData.class);
		when(bpmHelper3.updateAffirmFinancingStatus(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		AffirmFinancingUIResponse expectedResponse = sampleResponse;
		Mono<AffirmFinancingUIResponse> response = accessoryFinancingOffersHelper.updateAffirmFinancingStatus(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
	}
}
