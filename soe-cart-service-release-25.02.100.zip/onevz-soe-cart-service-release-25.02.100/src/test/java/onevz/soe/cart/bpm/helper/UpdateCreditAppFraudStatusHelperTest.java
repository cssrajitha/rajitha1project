package onevz.soe.cart.bpm.helper;

import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.helper.UpdateCreditAppFraudStatusHelper;
import onevz.soe.cart.model.updateCreditAppFraud.UpdateCreditAppFraudStatusCxpResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.UpdateCreditAppFraudStatusRequest;
import onevz.soe.cart.ui.responses.UpdateCreditAppFraudStatusMainResponse;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {CartServiceTestConfig.class})
public class UpdateCreditAppFraudStatusHelperTest {
    @InjectMocks
    private UpdateCreditAppFraudStatusHelper updateCreditAppFraudStatusHelper;

    @Mock
    private CartServiceCXPServices cartServiceCXPServices;

    @Test
    public void updateCreditAppFraudStatus(){
        UpdateCreditAppFraudStatusRequest request=new UpdateCreditAppFraudStatusRequest();
        request.setCcaAppNum("21321321");
        request.setFpforId("Id");
        request.setCustId("231231");
        request.setLinkedCcaAppNum("linked");
        UpdateCreditAppFraudStatusCxpResponse updateCreditAppFraudStatusCxpResponse=new UpdateCreditAppFraudStatusCxpResponse();
        UpdateCreditAppFraudStatusCxpResponse.UpdateCreditAppFraudStatusCxpData updateCreditCxpData =new UpdateCreditAppFraudStatusCxpResponse.UpdateCreditAppFraudStatusCxpData();
        updateCreditCxpData.setEnforceStatus("Success");
        updateCreditAppFraudStatusCxpResponse.setData(updateCreditCxpData);
        Mockito.when(cartServiceCXPServices.updateCreditAppFraudStatus(Mockito.any())).thenReturn(Mono.just(updateCreditAppFraudStatusCxpResponse));
        Mono<UpdateCreditAppFraudStatusMainResponse> monoResp=updateCreditAppFraudStatusHelper.updateCreditAppFraudStatus(request);
        StepVerifier.create(monoResp).assertNext(res ->{
            Assert.assertNotNull(res.getData());
            Assert.assertNotNull(res.getData().getUpdateCreditAppFraudStatusResponse());
        }).expectComplete().verify();
    }
    @Test
    public void updateCreditAppFraudStatusInvalid(){
        UpdateCreditAppFraudStatusRequest request=new UpdateCreditAppFraudStatusRequest();
        Mockito.when(cartServiceCXPServices.updateCreditAppFraudStatus(Mockito.any())).thenReturn(Mono.error(new NullPointerException()));
        Mono<UpdateCreditAppFraudStatusMainResponse> monoResp=updateCreditAppFraudStatusHelper.updateCreditAppFraudStatus(request);
        StepVerifier.create(monoResp).expectError().verify();
    }
    @Test
    public void updateCreditAppFraudStatusDataNull(){
        UpdateCreditAppFraudStatusRequest request=new UpdateCreditAppFraudStatusRequest();
        request.setCcaAppNum("21321321");
        request.setFpforId("Id");
        request.setCustId("231231");
        request.setLinkedCcaAppNum("linked");
        UpdateCreditAppFraudStatusCxpResponse updateCreditAppFraudStatusCxpResponse=new UpdateCreditAppFraudStatusCxpResponse();
        Mockito.when(cartServiceCXPServices.updateCreditAppFraudStatus(Mockito.any())).thenReturn(Mono.just(updateCreditAppFraudStatusCxpResponse));
        Mono<UpdateCreditAppFraudStatusMainResponse> monoResp=updateCreditAppFraudStatusHelper.updateCreditAppFraudStatus(request);
        StepVerifier.create(monoResp).assertNext(res ->{
            Assert.assertNotNull(res.getData());
            Assert.assertNotNull(res.getData().getUpdateCreditAppFraudStatusResponse());
        }).expectComplete().verify();
    }
}
