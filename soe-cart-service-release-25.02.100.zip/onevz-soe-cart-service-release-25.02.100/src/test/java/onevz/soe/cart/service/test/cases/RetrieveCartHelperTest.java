package onevz.soe.cart.service.test.cases;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.helper.RetrieveCartHelper;
import onevz.soe.cart.requests.RetrieveCartCXPRequest;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.ui.responses.RetrieveCartUIResponse;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.http.HttpMethod;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.net.URI;

@RunWith(SpringJUnit4ClassRunner.class)
@WebFluxTest(RetrieveCartHelper.class)
public class RetrieveCartHelperTest
{
    @Autowired
    private ObjectMapper mapper;
    @Autowired
    RetrieveCartHelper retrieveCartHelper;
    @Test
    public void validateRetrieveCartRequestTest1() throws JsonProcessingException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"VZW-DOTCOM\"},\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"}}";
        RetrieveCartCXPRequest request = mapper.readValue(requestString, RetrieveCartCXPRequest.class);
        URI url = URI.create("http://localhost/retrieve-cart");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").build();
        retrieveCartHelper.validateRetrieveCartRequest(httpHeader,request);

        request.getMeta().put("user","abcdefghtiklmnogjfhff122fnf33bfnffnf");
        retrieveCartHelper.validateRetrieveCartRequest(httpHeader,request);

        request.getMeta().put("user","@@abcdefghtiklmnogjfhff122fnf33bfnffnf");
        retrieveCartHelper.validateRetrieveCartRequest(httpHeader,request);

        request.getMeta().put("user","");
        retrieveCartHelper.validateRetrieveCartRequest(httpHeader,request);

        request.getMeta().remove("user");
        retrieveCartHelper.validateRetrieveCartRequest(httpHeader,request);

        request.setMeta(null);
        retrieveCartHelper.validateRetrieveCartRequest(httpHeader,request);
        request=null;
        retrieveCartHelper.validateRetrieveCartRequest(httpHeader,request);



    }
}
