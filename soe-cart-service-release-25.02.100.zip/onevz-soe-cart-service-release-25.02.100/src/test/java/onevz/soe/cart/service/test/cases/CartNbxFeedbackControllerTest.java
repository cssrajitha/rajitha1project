package onevz.soe.cart.service.test.cases;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.net.URI;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fasterxml.jackson.databind.ObjectMapper;

import junit.framework.Assert;
import onevz.soe.cart.controller.CartNbxFeedbackController;
import onevz.soe.cart.helper.UpdateCartHelper;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.responses.NBXFeedbackResponse;
import onevz.soe.cart.ui.requests.NBXFeedbackUIRequest;
import onevz.soe.omnidl.util.DLUtilityService;
import onevz.soe.security.TokenProcessor;
import org.springframework.web.bind.WebDataBinder;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(CartNbxFeedbackController.class)
public class CartNbxFeedbackControllerTest {

	@MockBean
	private UpdateCartHelper cartHelper;

	@Autowired
	private CartNbxFeedbackController cartController;

	@Autowired
	private ObjectMapper mapper;

	@MockBean
	private RedisHelper redisHelper;

	@MockBean
	private DLUtilityService dlUtilityService;

	@MockBean
	private TokenProcessor tokenProcessor;

	@Test
	public void nbxFeedbackTest() throws IOException {
		String nbxString = "{\"service\": {\"serviceHeader\": {\"clientId\": \"NETACE\",\"clientTransactionId\": \"NETACE-28023137-TXN\",\"clientSessionId\": \"NETACE-32a6993a-SESSION\",\"timestamp\": \"2020-05-06 07:50:30 GMT\",\"serviceName\": \"NBX\"},\"serviceBody\": {\"serviceRequest\": {\"contextInfo\": {\"callReason\": \"Recommendation\",\"category\": \"Offers\",\"subServiceName\": \"CaptureResponse\",\"sessionId\": \"-2233353673817713409\",\"rtdSessionID\": \"\"},\"customerInfo\": {\"mtn\": \"7573285016\",\"accountNo\": \"0420914396-00001\"},\"customerResponse\": {\"responseList\": [{\"rank\": \"1\",\"propositionId\": \"RO_01\",\"dispositionOptionId\": \"82\",\"soiEngagementId\": \"501002648\",\"timeStamp\": \"2020-05-06 07:50:30 GMT\",\"dynamicAttrList\": [{\"attrId\": \"skuid\",\"value\": \"MWAR2LL/A\"},{\"attrId\": \"Offer\",\"value\": \"RS_131\"}]}],\"externalResponseList\": [{\"rank\": null,\"propositionId\": \"RS_131\",\"dispositionOptionId\": \"82\",\"dynamicAttrList\": [{\"attrId\": \"isRtdOffer\",\"value\": \"N\"}],\"externalId\": null}]}}}}}";
		String nbxRequestString = "{ \"cartInfo\": {\"accountNumber\": \"0280106868-00001\"}, \"data\": {\"lines\": [{ \"mtn\": \"7169849755\", \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\"}}] }}";
		;
		NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
		NBXFeedbackUIRequest nbxReq = mapper.readValue(nbxRequestString, NBXFeedbackUIRequest.class);
		when(cartHelper.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
		URI url = URI.create("http://localhost/nbxFeedback");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		Mono<ResponseEntity<NBXFeedbackResponse>> controllerResponse = cartController.nbxFeedback(httpHeader,
				httpResponse, nbxReq);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void initBinderByNameTest() {
		WebDataBinder binder = new WebDataBinder(null);
		cartController.initBinderByName(binder);
		assertNotNull(binder.getDisallowedFields());
	}
}
