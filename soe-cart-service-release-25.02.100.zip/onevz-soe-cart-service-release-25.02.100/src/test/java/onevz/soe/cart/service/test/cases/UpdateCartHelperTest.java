package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.cradle.vo.CradleResponse;
import onevz.cxp.feature.util.FeatureFlag;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper2;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper3;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelperAddPlan;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper2;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.gql.schema.bundlebuildercartlightweight.PromoHubOffer;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntentUIRequest;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntentUIResponse;
import onevz.soe.cart.model.bvp.BVPLine;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.clearAndContinue.ClearAndContinueContext;
import onevz.soe.cart.model.createLine.HomeSalesAddress;
import onevz.soe.cart.model.mylink.MylinkData;
import onevz.soe.cart.model.mylink.MylinkReferralInfoResponse;
import onevz.soe.cart.model.retrieveCart.*;
import onevz.soe.cart.model.session.PDMOfferData;
import onevz.soe.cart.model.updateUserInfo.UpdateUserInfoLine;
import onevz.soe.cart.nbx.NBXFeedbackService;
import onevz.soe.cart.omnidl.OmniBuilder;
import onevz.soe.cart.omnidl.OmniDLBuilder;
import onevz.soe.cart.requests.CartExceedsLimitRequest;
import onevz.soe.cart.requests.NBXFeedbackRequest;
import onevz.soe.cart.requests.RetrieveCartCXPRequest;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.common.CartInfo;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.common.UpdateBarCodeData;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.cart.util.CartPegaRequestUtil;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.cradle.CradleAllocator;
import onevz.soe.omnidl.data.OmniDLDataBuilder;
import onevz.soe.omnidl.util.DLUtilityService;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.utilities.CollectionUtilities;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpResponse;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.ReflectionUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URI;
import java.util.*;

import static onevz.soe.cart.controller.CartExceedsVVCLimitControllerTest.readFromFile;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.ArgumentMatchers.any;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.*;


@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { CartServiceTestConfig.class })
public class UpdateCartHelperTest {

    @Autowired
    private UpdateCartHelper helper;

    @Autowired
    private UpdateCartHelper1 helper1;

    @MockBean
    private CartServiceCxpHelper cxpHelper;
    
    @MockBean
    private CartServiceCxpHelper2 cxpHelper2;

    @MockBean
    private CartServiceCXPServices cxpService;

    @MockBean
    CartServiceBpmHelperAddPlan bpmHelperAddPlan;

    @MockBean
    OmniDLHelper omniDLHelper;

    @MockBean
    private CartServiceBpmHelper bpmHelper;

    @MockBean
    private CartPegaRequestUtil cartPegaRequestUtil;

    @MockBean
    private CartAccessoryHelper cartAccessoryHelper;

    @MockBean
    private RedisHelper redisHelper;

    @MockBean
    private RedisHelper2 redisHelper2;

    @Autowired
    private ObjectMapper mapper;

    @MockBean
    private NBXFeedbackService nbxService;

    @MockBean
    private CradleAllocator cradleAllocator;

    @MockBean
    private DLUtilityService dlUtilityService;

    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;

    @MockBean
    CartAddDeviceHelper deviceHelper;

    @MockBean
    private CartServiceBpmHelper2 bpmHelper2;

    @MockBean
    private CartServiceBpmHelper3 bpmHelper3;

    @Autowired
    CartPegaRequestUtil cartPegaRequest;
    @MockBean
    FeatureFlag featureFlag;
    @MockBean
    private RedisHelper3 redisHelper3;

    @MockBean
    FeatureFlagHelper featureFlagHelper;

    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;

    @MockBean
    private SOELoginSessionBean soeLoginSessionBean;

    @MockBean
    private PromoHubOffer promoHubOffer;

    @MockBean
    OmniBuilder omniBuilder;
    List<String> preorderWhitelistMtnsList = new ArrayList<>();

    UpdateCartHelper csh = new UpdateCartHelper("1234567890,9087654321","Smartphones,Connected Devices,Tablets");



    @Test
    public void nullifyBarCodeForIsDynOfferRebate_ValidRebateOffers_NullifiesBarCodes() {
        CXPCartVO cartVo = new CXPCartVO();
        CXPOrderDetails orderDetail = new CXPOrderDetails();
        orderDetail.setBarCodes(new String[]{"rebate1", "rebate2"});
        cartVo.setOrderDetails(orderDetail);
        CXPLineDetailsVO lineDetails = new CXPLineDetailsVO();
        CXPLineInfo lineInfo = new CXPLineInfo();
        lineDetails.setLineInfo(new CXPLineInfo[]{lineInfo});
        cartVo.setLineDetails(lineDetails);

        Mockito.when(CollectionUtilities.isNotEmptyOrNull(Mockito.anyList())).thenReturn(true);

        helper.nullifyBarCodeForIsDynOfferRebate(cartVo);

        assertNull(cartVo.getOrderDetails().getBarCodes());
        assertTrue(cartVo.getOrderDetails().getIsDynSWOfferApplied());
    }

    @Test
    public void nullifyBarCodeForIsDynOfferRebate_NoRebateOffers_DoesNotNullifyBarCodes() {
        CXPCartVO cartVo = new CXPCartVO();
        CXPOrderDetails orderDetail = new CXPOrderDetails();
        orderDetail.setBarCodes(new String[]{"rebate1", "rebate2"});
        cartVo.setOrderDetails(orderDetail);
        CXPLineDetailsVO lineDetails = new CXPLineDetailsVO();
        CXPLineInfo lineInfo = new CXPLineInfo();
        lineDetails.setLineInfo(new CXPLineInfo[]{lineInfo});
        cartVo.setLineDetails(lineDetails);

        Mockito.when(CollectionUtilities.isNotEmptyOrNull(Mockito.anyList())).thenReturn(false);

        helper.nullifyBarCodeForIsDynOfferRebate(cartVo);

        assertNotNull(cartVo.getOrderDetails().getBarCodes());
        assertFalse(cartVo.getOrderDetails().getIsDynSWOfferApplied());
    }

    @Test
    public void nullifyBarCodeForIsDynOfferRebate_NullOrderDetails_DoesNotThrowException() {
        CXPCartVO cartVo = new CXPCartVO();
        cartVo.setOrderDetails(null);

        helper.nullifyBarCodeForIsDynOfferRebate(cartVo);

        assertNull(cartVo.getOrderDetails());
    }

    @Test
    public void nullifyBarCodeForIsDynOfferRebate_NullBarCodes_DoesNotThrowException() {
        CXPCartVO cartVo = new CXPCartVO();
        CXPOrderDetails orderDetail = new CXPOrderDetails();
        orderDetail.setBarCodes(null);
        cartVo.setOrderDetails(orderDetail);

        helper.nullifyBarCodeForIsDynOfferRebate(cartVo);

        assertNull(cartVo.getOrderDetails().getBarCodes());
    }

    @Test
    public void isthirdpartyFeaturePromoTest(){
        PromoHubOffer promoHubOffer1=new PromoHubOffer();
        when(featureFlagHelper.isPOYPEnabled()).thenReturn(true);
        promoHubOffer1.setPromoType("FEATURED_PROMO");
        promoHubOffer1.setOfferId("");
        boolean featuredPromo = helper.isthirdpartyFeaturePromo(promoHubOffer1);
        Assertions.assertTrue(featuredPromo);
        promoHubOffer1.setOfferId("abc");
        featuredPromo = helper.isthirdpartyFeaturePromo(promoHubOffer1);
        Assertions.assertFalse(featuredPromo);
        promoHubOffer1.setPromoType("FEATURED");
        featuredPromo = helper.isthirdpartyFeaturePromo(promoHubOffer1);
        Assertions.assertFalse(featuredPromo);
        promoHubOffer1.setPromoType(null);
        featuredPromo = helper.isthirdpartyFeaturePromo(promoHubOffer1);
        Assertions.assertFalse(featuredPromo);
        when(featureFlagHelper.isPOYPEnabled()).thenReturn(false);
        featuredPromo = helper.isthirdpartyFeaturePromo(promoHubOffer1);
        Assertions.assertFalse(featuredPromo);


    }

    @Test
    public void addReplenishmentToCartTest() throws IOException, SOEHTTPException {
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);

        String addReplenishmentToCartUIResponseString="{\"cartInfo\":{\"clientAppName\":\"ATG-TELE-ONEPOS\",\"cartCreator\":\"\",\"creditAppNumber\":\"240042539\",\"cartId\":\"05826fbe-3e7a-4ef8-87ad-5e708c05a9af\",\"caseId\":\"SOF-11445792-C01\",\"processingMTN\":\"8039204546\",\"intendType\":\"NSE\",\"processStep\":\"addReplenishment\"},\"data\":{\"lines\":[{\"mtn\":\"8039204546\",\"isActivateWithoutReplenish\":false,\"replenishmentAmount\":\"80.00\",\"processingMTN\":\"8039204546\"}]}}    ";
        AddReplenishmentToCartUIRequest addReplenishmentToCartUIRequest= mapper.readValue(addReplenishmentToCartUIResponseString, AddReplenishmentToCartUIRequest.class);

        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mockito.when(bpmHelper3.addReplenishmentToCart(Mockito.any(AddReplenishmentToCartUIRequest.class)))
                .thenReturn(Mono.just(new AddReplenishmentToCartUIResponse()));
        Mono<AddReplenishmentToCartUIResponse> addReplenishmentToCartUIResponseMono=helper.addReplenishmentToCart(addReplenishmentToCartUIRequest);

        StepVerifier.create(addReplenishmentToCartUIResponseMono).assertNext(resp->{
            Assertions.assertNotNull(resp);
        }).verifyComplete();
        addReplenishmentToCartUIRequest.getCartInfo().setProcessingMTN("");
        addReplenishmentToCartUIRequest.getCartInfo().setIntendType("NSE");
        sampleRedisData.setCreditAppNum("ABC");
        addReplenishmentToCartUIRequest.getCartInfo().setClientAppName("");
        sampleRedisData.setCartInfo(new CartInfo());
        sampleRedisData.getCartInfo().setClientAppName("abc");
        sampleRedisData.setMtn(null);
        addReplenishmentToCartUIResponseMono=helper.addReplenishmentToCart(addReplenishmentToCartUIRequest);

        StepVerifier.create(addReplenishmentToCartUIResponseMono).assertNext(resp->{
            Assertions.assertNotNull(resp);
        }).verifyComplete();
        addReplenishmentToCartUIRequest.getCartInfo().setClientAppName("");
        sampleRedisData.setProcessingMTN(null);
       addReplenishmentToCartUIRequest.getCartInfo().setClientAppName("abc");
       sampleRedisData.setCaseId(null);
       sampleRedisData.setCartId(null);
        addReplenishmentToCartUIResponseMono=helper.addReplenishmentToCart(addReplenishmentToCartUIRequest);

        StepVerifier.create(addReplenishmentToCartUIResponseMono).assertNext(resp->{
            Assertions.assertNotNull(resp);
        }).verifyComplete();


    }

    @Test
    public void reviewOrderTysValidationTest() throws IOException, SOEHTTPException {

        String reviewOrderTYSUIRequestString = "{\"cartInfo\":{\"cartId\":\"\"}}";
        ReviewOrderTYSUIRequest reviewOrderTYSUIRequest = mapper.readValue(reviewOrderTYSUIRequestString, ReviewOrderTYSUIRequest.class);

        Mockito.when(bpmHelper3.reviewOrderTys(reviewOrderTYSUIRequest)).thenReturn(Mono.just(new ReviewOrderTYSUIResponse()));

        Mono<ReviewOrderTYSUIResponse> reviewOrderTYSUIResponseMono=helper.reviewOrderTysValidation(reviewOrderTYSUIRequest);

        StepVerifier.create(reviewOrderTYSUIResponseMono).assertNext(resp->{
            Assertions.assertNotNull(resp);
        }).verifyComplete();
    }

    @Test
    public void populateCustomerProfileCookieIfPresentTest() throws IOException, SOEHTTPException {

        String customerProfileCXPResponseString = "{\"meta\":{\"timestamp\":\"1669704347948\",\"cxpCorrelationId\":\"2022-11-29T06:45:47.+0000:48a2348ec1e0411a:cxp-customerprofile-se-qa-ev6v-sit3e-nscxp-659ff44c46-rdnzz:nssit3\"},\"data\":{\"customer\":{\"caseId\":\"SOP-10723267-E01\",\"cartId\":\"e3c72084-90d6-4b9a-84bf-5f82d82eb6b9\",\"processStep\":\"MTNSelectionPage\",\"availablePaths\":[{\"path\":\"MTNSelectionPage\"}],\"email\":\"OBMMNZOXLON@VZW.COM\",\"customerHash\":\"3b93759454e625620cc005c7b171ccd0666c47479dd83e1998f422d3f30ec278\",\"customerName\":{\"firstName\":\"KYLE\",\"lastName\":\"WRIGHT\"},\"customerAttributes\":{\"customerType\":\"PE\",\"ecpdConcession\":false,\"digitalCustomerType\":\"B2C\",\"consumerAccount\":true,\"businessAccount\":false,\"agentAccount\":false,\"salesMakerAccount\":false,\"vzwemployeeAccount\":false},\"billAccounts\":[{\"activeMtnCount\":null,\"accountLevelChangeEligibility\":{\"isAddNewLineAllowed\":true,\"isBundleChangeAllowed\":true,\"isSharePlanChangeAllowed\":true,\"pendingOrderDetail\":null},\"accountAttributes\":{\"trialUnlimitedCustomer\":false,\"isCollection\":false,\"isCashOnly\":false,\"isCashOnlyExceptCC\":false,\"isCashOnlyExceptCO\":false,\"isOverThreshHold\":false,\"fraudInfo\":{\"fraud\":false,\"fraud_C\":false,\"fraud_M\":false,\"fraud_R\":false,\"fraud_S\":false,\"fraud_V\":false,\"fraud_X\":false,\"fraud_Y\":false,\"fraud_Z\":false},\"mixedPlanCategories\":true},\"paymentInfo\":{\"pastDueBalance\":\"0.00\",\"arPastDueBalance\":\"0.00\",\"isBalancePastDue\":false},\"mtns\":[{\"mtnHashCode\":\"f20119a961ed7dbe33695e737dd3790403e7bb1473fa839f6749dbb074a63144\",\"promotions\":[{\"promotionType\":\"TradeIn\",\"promotionText\":\"Upgrade & get $100 off, or add a new line & get $300 off on us.\",\"legalText\":\"Less $100 trade-in/promo credit (upgrades) or $300 trade-in/promo credit (new lines) applied to account over 24 mos w/in 1-2 billing cycles; promo credit ends when balance paid or line terminated/transferred; 0% APR. Trade-in must be in good working and cosmetic condition.\",\"promotionPrice\":\"300\"}],\"mtn\":\"7038019561\",\"nextBestAction\":null,\"nickName\":\"KYLE B WRIGHT-9561\",\"equipmentInfos\":[{\"deviceInfo\":{\"tradeInValue\":\"95.00\",\"deviceId\":\"354846092464732\",\"deviceUrl\":\"https://ss7.vzw.com/is/image/VerizonWireless/iPhoneX-Svr\",\"brandName\":\"Apple\",\"displayName\":\"Apple iPhone X 64GB in Silver\",\"appleDevice\":true,\"operatingSystem\":\"Apple iOS\",\"category\":{\"basicphone\":false,\"smartphone\":true,\"connectedDevice\":false,\"internetDevice\":false,\"tablet\":false,\"smartwatch\":false},\"deviceType\":{\"backupRouter4G\":false,\"device4G\":true,\"device3G\":false,\"device5GA\":false,\"device5GE\":false,\"antenna5G\":false,\"home5G\":false,\"deviceType\":\"4GE\",\"home4GLte\":false},\"color\":{\"description\":\"Silver\",\"displayName\":\"Silver\"},\"capacity\":\"64 GB\",\"ringDevice\":false,\"deviceProdId\":\"dev8720300\",\"euiccCapable\":false,\"simClass4G\":\"PI\",\"eid\":\"\",\"preferredSoftSim\":\"\",\"preferredSim\":null,\"simType\":\"P\",\"deviceSku\":\"MQCL2LL/A\",\"pairedImeiData\":{\"pairedImei\":null,\"eid\":null,\"sku\":null,\"preferredSim\":null,\"devicePreferredSoftSim\":null,\"simClass4G\":null,\"euiccCapable\":false,\"simType\":\"P\"},\"cdmaRestrictedDevice\":false,\"cdmaSuspended\":false},\"simInfo\":{\"simId\":\"89148000004106703153\",\"simSku\":\"EMBD4GSIM-N\"}}],\"pricePlanInfo\":{\"planId\":\"26872\",\"planCategoryName\":\"UNLIMITED FOR ALL\",\"planSkuName\":\"5G Start\",\"planAttributes\":{\"is5GPlan\":false,\"sharePlan\":false}},\"mobileInfoAttributes\":{\"hasTabletPromo\":false,\"modCompatible\":false,\"upsellEligible\":false,\"hllp2DiscountLoss\":false,\"numberShareParent\":\"\",\"numberShareTrunk\":false,\"hasJustKidsSmartFamilyParentFeature\":false},\"installmentLoans\":[],\"equipmentUpgradeEligibility\":{\"upgradeEligible\":true,\"annualUpgradeEligible\":false,\"buyoutEligible\":false,\"buyoutRestricted\":false,\"upgradeEligibilityDate\":\"09/02/2020\",\"alwaysUpgradeEligible\":true,\"earlyUpgradeEligible\":false,\"edgeUpEligible\":false,\"upgradeEligibilityLabel\":\"Upgrade Now\",\"devicePaymentEligible\":true,\"inEligibility\":{\"votPendingOrder\":false,\"mtnPermanentlyInactive\":false,\"mtnSuspended\":false,\"starIndicator\":false,\"hubDevice\":false,\"mtnInstallment\":false,\"pricePlanPendingOrder\":false,\"iconicPendingOrder\":false,\"equipmentUpgradeWithSpoPendingOrder\":false,\"lineLevelPendingOrder\":false,\"pendingOrder\":false,\"humDevice\":false},\"twoYearContract\":{\"contractTermText\":null,\"daysPercentage\":null,\"downpaymentPercentageFor2D\":null,\"endDate\":null,\"monthsRemainingText\":null,\"numberOfDays\":0,\"description\":null,\"daysRemainingText\":null},\"pendingOrderDetail\":null,\"lineUpgradedwithin24Hrs\":false,\"transferUpgradeEligibility\":{\"giverEligible\":true,\"takerEligible\":false,\"takerMtns\":[]}},\"lineLevelChangeEligibility\":{\"pendingOrderDetail\":null},\"deviceMtnIndicator\":\"\",\"simType\":\"P\",\"mtnStatus\":{\"mtnStatusReasonCode\":\"\",\"isMtnSuspended\":false,\"mtnSuspendAllowed\":false,\"isActive\":true}},{\"mtnHashCode\":\"3281f5ecbaab1de8db7668d6155f5100d931ee497622a34799194e095b85e61b\",\"promotions\":[],\"mtn\":\"9105154828\",\"nextBestAction\":null,\"nickName\":\"KYLE B WRIGHT-4828\",\"equipmentInfos\":[{\"deviceInfo\":{\"tradeInValue\":\"50.00\",\"deviceId\":\"350760503406865\",\"deviceUrl\":\"https://ss7.vzw.com/is/image/VerizonWireless/samsung-galaxy-a42-5g-smartphone-black-sma426uzkv\",\"brandName\":\"Samsung\",\"displayName\":\"Samsung Galaxy A42 5G 128GB in Prism Dot Black\",\"appleDevice\":false,\"operatingSystem\":\"Android\",\"category\":{\"basicphone\":false,\"smartphone\":true,\"connectedDevice\":false,\"internetDevice\":false,\"tablet\":false,\"smartwatch\":false},\"deviceType\":{\"backupRouter4G\":false,\"device4G\":false,\"device3G\":false,\"device5GA\":false,\"device5GE\":true,\"antenna5G\":false,\"home5G\":false,\"deviceType\":\"5GE\",\"home4GLte\":false},\"color\":{\"description\":\"Black\",\"displayName\":\"Prism Dot Black\"},\"capacity\":\"128 GB\",\"ringDevice\":false,\"deviceProdId\":\"dev15400009\",\"euiccCapable\":false,\"simClass4G\":\"PI\",\"eid\":\"\",\"preferredSoftSim\":\"\",\"preferredSim\":null,\"simType\":\"P\",\"deviceSku\":\"SMA426UZKV\",\"pairedImeiData\":{\"pairedImei\":null,\"eid\":null,\"sku\":null,\"preferredSim\":null,\"devicePreferredSoftSim\":null,\"simClass4G\":null,\"euiccCapable\":false,\"simType\":\"P\"},\"cdmaRestrictedDevice\":false,\"cdmaSuspended\":false},\"simInfo\":{\"simId\":\"89148000007294506585\",\"simSku\":\"EMBDSIM5G\"}}],\"pricePlanInfo\":{\"planId\":\"26872\",\"planCategoryName\":\"UNLIMITED FOR ALL\",\"planSkuName\":\"5G Start\",\"planAttributes\":{\"is5GPlan\":false,\"sharePlan\":false}},\"mobileInfoAttributes\":{\"hasTabletPromo\":false,\"modCompatible\":false,\"upsellEligible\":false,\"hllp2DiscountLoss\":true,\"numberShareParent\":\"\",\"numberShareTrunk\":false,\"hasJustKidsSmartFamilyParentFeature\":false},\"installmentLoans\":[{\"loanTransferEligibility\":true,\"loanAmount\":\"399.99\",\"paidAmountToDate\":\"216.73\",\"totalPrincipalAmountUnpaid\":\"183.26\",\"loanTermMonths\":\"24\",\"pendingNumberOfInstallments\":10,\"daysLeftForNextEligibleUpgrade\":298,\"loanMonthlyPaymentAmount\":\"16.66\",\"paidAmountPercentage\":\"0.54\",\"edgeUpRequiredPercent\":\"100.00\",\"firstInstallmentAmount\":\"16.81\",\"loanNumber\":\"2063417388\",\"pastTradeInRestrictionTimePeriod\":true,\"edgeUpPrincipalAmountUnpaid\":\"0.00\",\"displayKeepOption\":true,\"displayReturnOption\":false,\"deviceMismatch\":false,\"buyoutQuote\":{\"taxAmountUnbilled\":\"0.00\"},\"loanStatus\":{\"active\":true,\"buyout\":true,\"canceled\":false,\"earlyUpgrade\":false,\"edgeUp\":false,\"forceBuyout\":false,\"indirectPendingApproval\":false,\"indirectRejectedFinal\":false,\"indirectRejectedInitial\":false,\"indirectWaitingForFax\":false,\"paid\":false,\"pending\":false,\"reassign\":false,\"suspendedForMilitaryService\":false,\"transferedToAnotherLoan\":false,\"aol\":false}}],\"equipmentUpgradeEligibility\":{\"upgradeEligible\":true,\"annualUpgradeEligible\":false,\"buyoutEligible\":true,\"buyoutRestricted\":false,\"upgradeEligibilityDate\":\"09/24/2023\",\"alwaysUpgradeEligible\":true,\"earlyUpgradeEligible\":false,\"edgeUpEligible\":false,\"upgradeEligibilityLabel\":\"$183.26 Eligible to buyout\",\"devicePaymentEligible\":false,\"inEligibility\":{\"votPendingOrder\":false,\"mtnPermanentlyInactive\":false,\"mtnSuspended\":false,\"starIndicator\":false,\"hubDevice\":false,\"mtnInstallment\":true,\"pricePlanPendingOrder\":false,\"iconicPendingOrder\":false,\"equipmentUpgradeWithSpoPendingOrder\":false,\"lineLevelPendingOrder\":false,\"pendingOrder\":false,\"humDevice\":false},\"twoYearContract\":{\"contractTermText\":null,\"daysPercentage\":null,\"downpaymentPercentageFor2D\":null,\"endDate\":null,\"monthsRemainingText\":null,\"numberOfDays\":0,\"description\":null,\"daysRemainingText\":null},\"pendingOrderDetail\":null,\"lineUpgradedwithin24Hrs\":false,\"transferUpgradeEligibility\":{\"giverEligible\":false,\"takerEligible\":false,\"takerMtns\":[]}},\"lineLevelChangeEligibility\":{\"pendingOrderDetail\":null},\"deviceMtnIndicator\":\"\",\"simType\":\"P\",\"mtnStatus\":{\"mtnStatusReasonCode\":\"\",\"isMtnSuspended\":false,\"mtnSuspendAllowed\":false,\"isActive\":true}},{\"mtnHashCode\":\"023f9e0702a98527a65456d9a8d13e09a2324a4adac02882b2b937ad0e0a3ebe\",\"promotions\":[],\"mtn\":\"9108800442\",\"nextBestAction\":null,\"nickName\":\"KYLE B WRIGHT-0442\",\"equipmentInfos\":[{\"deviceInfo\":{\"tradeInValue\":\"\",\"deviceId\":\"A0000034C44F7F\",\"deviceUrl\":null,\"brandName\":null,\"displayName\":null,\"appleDevice\":false,\"operatingSystem\":null,\"category\":{\"basicphone\":true,\"smartphone\":false,\"connectedDevice\":false,\"internetDevice\":false,\"tablet\":false,\"smartwatch\":false},\"deviceType\":{\"backupRouter4G\":false,\"device4G\":true,\"device3G\":false,\"device5GA\":false,\"device5GE\":false,\"antenna5G\":false,\"home5G\":false,\"deviceType\":\"VZW\",\"home4GLte\":false},\"color\":{},\"capacity\":\"\",\"ringDevice\":false,\"deviceProdId\":\"\",\"euiccCapable\":false,\"simClass4G\":\"\",\"eid\":\"\",\"preferredSoftSim\":\"\",\"preferredSim\":null,\"simType\":\"P\",\"deviceSku\":\"LG-VN360\",\"pairedImeiData\":{\"pairedImei\":null,\"eid\":null,\"sku\":null,\"preferredSim\":null,\"devicePreferredSoftSim\":null,\"simClass4G\":null,\"euiccCapable\":false,\"simType\":\"P\"},\"cdmaRestrictedDevice\":true,\"cdmaSuspended\":false},\"simInfo\":{\"simId\":\"\",\"simSku\":\"\"}}],\"pricePlanInfo\":{},\"mobileInfoAttributes\":{\"hasTabletPromo\":false,\"modCompatible\":false,\"upsellEligible\":false,\"hllp2DiscountLoss\":false,\"numberShareParent\":\"\",\"numberShareTrunk\":false,\"hasJustKidsSmartFamilyParentFeature\":false},\"installmentLoans\":[],\"equipmentUpgradeEligibility\":{\"upgradeEligible\":false,\"annualUpgradeEligible\":false,\"buyoutEligible\":false,\"buyoutRestricted\":false,\"upgradeEligibilityDate\":null,\"alwaysUpgradeEligible\":false,\"earlyUpgradeEligible\":false,\"edgeUpEligible\":false,\"upgradeEligibilityLabel\":\"Upgrade on May 6, 2016 - Not Transferrable\",\"devicePaymentEligible\":false,\"inEligibility\":{\"votPendingOrder\":false,\"mtnPermanentlyInactive\":true,\"mtnSuspended\":false,\"starIndicator\":false,\"hubDevice\":false,\"mtnInstallment\":false,\"pricePlanPendingOrder\":false,\"iconicPendingOrder\":false,\"equipmentUpgradeWithSpoPendingOrder\":false,\"lineLevelPendingOrder\":false,\"pendingOrder\":false,\"humDevice\":false},\"twoYearContract\":{\"contractTermText\":null,\"daysPercentage\":null,\"downpaymentPercentageFor2D\":null,\"endDate\":null,\"monthsRemainingText\":null,\"numberOfDays\":0,\"description\":null,\"daysRemainingText\":null},\"pendingOrderDetail\":null,\"lineUpgradedwithin24Hrs\":false,\"transferUpgradeEligibility\":{\"giverEligible\":false,\"takerEligible\":false,\"takerMtns\":[]}},\"lineLevelChangeEligibility\":{\"pendingOrderDetail\":null},\"deviceMtnIndicator\":\"\",\"simType\":\"P\",\"mtnStatus\":{\"mtnStatusReasonCode\":\"C1\",\"isMtnSuspended\":false,\"mtnSuspendAllowed\":false,\"isActive\":false}}],\"programEligibility\":{\"RemainingBTAAmount\":\"750.00\",\"tradeInCreditEligible\":\"true\"}}],\"address\":{\"area\":\"South|Tennessee\",\"state\":\"NC\",\"zipCode\":\"28467\",\"zipCodePlus4\":\"2168\"},\"lob\":\"vzw\",\"channel\":\"EXPRESS-STORE\",\"loginMtn\":\"7038019561\",\"vzwRole\":\"accountManager\"},\"mostRecentSalesRepCustomerData\":{\"ecode\":\"abc\"}}}";
        CustomerProfileCXPResponse customerProfileCXPResponse = mapper.readValue(customerProfileCXPResponseString, CustomerProfileCXPResponse.class);

        MockServerHttpResponse mockServerHttpResponse=new MockServerHttpResponse();
        mockServerHttpResponse.setRawStatusCode(200);

        Mockito.when(helper.customerProfileDigital("123")).thenReturn(Mono.just(customerProfileCXPResponse));

        Mono<ResponseEntity<GenericResponse>> genericResp=helper.populateCustomerProfileCookieIfPresent(mockServerHttpResponse,"123", new GenericResponse());
        StepVerifier.create(genericResp).assertNext(resp->{
            Assertions.assertNotNull(resp);
        }).verifyComplete();
    }

    @Test
    public void updateTradeInOffer_DataNotNull_Test() throws JsonParseException, JsonMappingException, IOException {
        String UpdateTradeInOfferUIRequestString="{\"cartId\":\"test-test\",\"isTradeInOfferSelected\":true,\"chatId\":\"123\",\"channelId\":\"TEST\"}";
        UpdateTradeInOfferUIRequest updateTradeInOfferUIRequest = mapper.readValue(UpdateTradeInOfferUIRequestString, UpdateTradeInOfferUIRequest.class);
        String cartRedisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData cartRedisData = mapper.readValue(cartRedisDataString, CartRedisData.class);
        String BVPRedisDataString = "{\"lines\" : [ {\"mtn\" : \"7169849755\",\"getBestValuePromotions\" : {\"bestValueOffers\" :[{\"id\":\"551120\",\"myOffer\":false,\"name\":\"UATREBATETEST\",\"verizonUp\":false,\"description\":\"Test offer for Jenita Keran\",\"contractTypes\":[\"DPP\"],\"rank\":\"1\",\"deviceSku\":\"MHC63LL/A\",\"myOfferAccepted\":\"false\",\"verizonUpAccepted\":\"false\",\"compatiblePlanIds\":[\"\"],\"finalQualifiedOffer\":\"false\",\"offerType\":\"Rebates\",\"offerSubType\":\"Virtual Reward\",\"allowStackWithTrade\":\"Y\",\"tradeInAccepted\":false,\"bogoOfferAccepted\":false,\"propositionAmount\":\"0\",\"rebateOffer\":true,\"bogoOffer\":false,\"tradeOffer\":false}] }}]}";
        BVPRedisData bvpRedisData = mapper.readValue(BVPRedisDataString, BVPRedisData.class);
        String updateTradeInOfferUIResponseString = "{\"meta\":{\"timestamp\":1582009662751,\"cxpCorrelationId\":\"2020-02-18T07:07:42.+0000:933193aa-6608-4ecc-a92e-5877dda9bcb0:cxp-tax-domain-dev-ev6v-dev-sboxcxp-55c9d6946d-r9hwh:nsd2\"},\"data\":{\"statusMsg\":\"Success\",\"calculateMultiLineTaxForCart\":{\"count\":1,\"orderTotalTax\":\"95.70\",\"lineTaxDetails\":[{\"locationCode\":\"N833301\",\"multiLineSeqNumber\":1,\"orderType\":\"PS\",\"totalTax\":\"95.70\",\"totalPriceForTax\":\"1319.99\",\"itemsForTax\":[{\"mldSeqNum\":0,\"itemSequence\":1,\"itemCode\":\"SMN976VZKV\",\"itemPrice\":\"1299.99\",\"unitTaxBasedPrice\":\"0.00\",\"qty\":1,\"discountAmount\":\"0.00\",\"taxAmount\":\"94.25\",\"taxBasedPriceFlag\":0,\"taxDetailsList\":[{\"mldSequenceNum\":0,\"taxSequenceNum\":0,\"taxAmount\":\"19.50\",\"taxDescription\":\"OH Local Sales Tax\",\"taxType\":\"taxes_fees\"},{\"mldSequenceNum\":0,\"taxSequenceNum\":0,\"taxAmount\":\"74.75\",\"taxDescription\":\"OH State Sales Tax\",\"taxType\":\"taxes_fees\"}]},{\"mldSeqNum\":0,\"itemSequence\":2,\"itemCode\":\"EMBDSIMTRI\",\"itemPrice\":\"0.00\",\"unitTaxBasedPrice\":\"0.00\",\"qty\":1,\"discountAmount\":\"0.00\",\"taxAmount\":\"0.00\",\"taxBasedPriceFlag\":0},{\"mldSeqNum\":0,\"itemSequence\":3,\"itemCode\":\"WAR6002\",\"itemPrice\":\"0.00\",\"unitTaxBasedPrice\":\"0.00\",\"qty\":1,\"discountAmount\":\"0.00\",\"taxAmount\":\"0.00\",\"taxBasedPriceFlag\":0},{\"mldSeqNum\":0,\"itemSequence\":4,\"itemCode\":\"UPGRADEFEE20\",\"itemPrice\":\"20.00\",\"unitTaxBasedPrice\":\"0.00\",\"qty\":1,\"discountAmount\":\"0.00\",\"taxAmount\":\"1.45\",\"taxBasedPriceFlag\":0,\"taxDetailsList\":[{\"mldSequenceNum\":0,\"taxSequenceNum\":0,\"taxAmount\":\"0.30\",\"taxDescription\":\"OH Local Sales Tax\",\"taxType\":\"taxes_fees\"},{\"mldSequenceNum\":0,\"taxSequenceNum\":0,\"taxAmount\":\"1.15\",\"taxDescription\":\"OH State Sales Tax\",\"taxType\":\"taxes_fees\"}]},{\"mldSeqNum\":0,\"itemSequence\":5,\"itemCode\":\"SHP002\",\"itemPrice\":\"0.00\",\"unitTaxBasedPrice\":\"0.00\",\"qty\":1,\"discountAmount\":\"0.00\",\"taxAmount\":\"0.00\",\"taxBasedPriceFlag\":0}]}]}}}";
        UpdateTradeInOfferUIResponse updateTradeInOfferUIResponse=mapper.readValue(updateTradeInOfferUIResponseString, UpdateTradeInOfferUIResponse.class);

        Mockito.when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpRedisData));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(cartRedisData));
        Mockito.when(cxpHelper2.updateTradeInOffer(Mockito.any(UpdateTradeInOfferUIRequest.class))).thenReturn(Mono.just(updateTradeInOfferUIResponse));
        Mockito.when(redisHelper2.upsertBVPTradeInOFferIntoRedis(bvpRedisData)).thenReturn(Mono.just(Boolean.TRUE));

        Mono<UpdateTradeInOfferUIResponse> genericResp=helper.updateTradeInOffer(updateTradeInOfferUIRequest);
        StepVerifier.create(genericResp).assertNext(resp->{
            Assertions.assertNotNull(resp);
        }).verifyComplete();
    }

    @Test
    public void addFeature_NotNYCustomerAddress_Test() throws IOException {
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGAgeneratedmessage\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1583186-DEV3\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"ShoppingCart`\"}]},\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"cartInfo\":{\"cartId\":\"69a66ef4d-7e344dfb-2db299209-ea8333\",\"lines\":[{\"lineId\":\"4345949784\",\"status\":1,\"errors\":[],\"conflictedSPO\":[],\"conflictedSFO\":[],\"mtn\":\"4345949784\",\"planValidationFailed\":false,\"featureResponse\":[{\"sorId\":\"82825\",\"actionIndicator\":\"A\",\"type\":\"SFO\",\"price\":20,\"level\":\"L\"}],\"activateLaterInd\":false,\"showInsurancePage\":false,\"impactedLines\":false}],\"accountLevelSPOs\":[],\"tmpmdDrop\":false},\"processMTNList\":[{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}]}}},\"exceptions\":[{\"system\":\"CXP\",\"service\":\"addToCartService\",\"type\":\"Warning\",\"code\":\"E1223\",\"message\":\"Accountvalidationfailed\"}],\"warnings\":[]}";
        String sampleUIRequestString ="{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"ca7608de-6c65-4b6b-85e1-a2904fdb86a2\",\"caseId\":\"SOP-639240-E01\",\"accountNumber\":\"0322638103-00001\",\"cartCreator\":\"8643319007\",\"processingMTN\":\"\",\"intendType\":\"EUP\",\"processStep\":\"FeaturesPDP\"},\"data\":{\"account\":null,\"lines\":[{\"mtn\":\"8643858663\",\"features\":{\"add\":[{\"id\":\"66332\",\"actionIndicator\":\"A\",\"type\":\"SFO\",\"quantity\":1}]},\"mcsSubscription\":{\"add\":[{\"itemId\":\"307355196\",\"name\":\"YouTubeTV Basic Subscription\",\"actionIndicator\":\"A\",\"description\":\"VIDEO\",\"pricePlanId\":\"35616999\",\"price\":\"64.99\",\"contentId\":\"YTTVBASIC\"}]}}]}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\",\"flowName\": \"AAL\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\",\"intent\": \"NLG\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddFeaturesUIRequest addFeaturesUIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
        AddFeaturesUIResponse addFeaturesUIResponse = mapper.readValue(sampleResponseString, AddFeaturesUIResponse.class);

        sampleRedisData.setStoreLocationState("NY");
        sampleRedisData.setCustomerAddressState("CA");
        sampleRedisData.setLineLevelDigitalSecureSubscriptionCount("2");

        Mockito.when(redisHelper.getAddFeaturesRequest()).thenReturn(Mono.just(addFeaturesUIRequest));
        Mockito.when(bpmHelper2.addFeatures(Mockito.any())).thenReturn(Mono.just(addFeaturesUIResponse));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mockito.when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        Mockito.when(redisHelper2.updateLinelevelDigitalSecureSubscriptionCountintoRedis(Mockito.anyInt())).thenReturn(Mono.just(Boolean.TRUE));

        Mono<AddFeaturesUIResponse> response = helper.addFeatures(addFeaturesUIRequest);

        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).verifyComplete();

    }

    @Test
    public void addFeature_NYCustomerAddress_Test() throws IOException {
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGAgeneratedmessage\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1583186-DEV3\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"ShoppingCart`\"}]},\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"cartInfo\":{\"cartId\":\"69a66ef4d-7e344dfb-2db299209-ea8333\",\"lines\":[{\"lineId\":\"4345949784\",\"status\":1,\"errors\":[],\"conflictedSPO\":[],\"conflictedSFO\":[],\"mtn\":\"4345949784\",\"planValidationFailed\":false,\"featureResponse\":[{\"sorId\":\"82825\",\"actionIndicator\":\"A\",\"type\":\"SFO\",\"price\":20,\"level\":\"L\"}],\"activateLaterInd\":false,\"showInsurancePage\":false,\"impactedLines\":false}],\"accountLevelSPOs\":[],\"tmpmdDrop\":false},\"processMTNList\":[{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}]}}},\"exceptions\":[{\"system\":\"CXP\",\"service\":\"addToCartService\",\"type\":\"Warning\",\"code\":\"E1223\",\"message\":\"Accountvalidationfailed\"}],\"warnings\":[]}";
        String sampleUIRequestString ="{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"ca7608de-6c65-4b6b-85e1-a2904fdb86a2\",\"caseId\":\"SOP-639240-E01\",\"accountNumber\":\"0322638103-00001\",\"cartCreator\":\"8643319007\",\"processingMTN\":\"\",\"intendType\":\"EUP\",\"processStep\":\"FeaturesPDP\"},\"data\":{\"account\":null,\"lines\":[{\"mtn\":\"8643858663\",\"features\":{\"add\":[{\"id\":\"66332\",\"actionIndicator\":\"A\",\"type\":\"SFO\",\"quantity\":1}]},\"mcsSubscription\":{\"add\":[{\"itemId\":\"307272146\",\"name\":\"YouTubeTV Basic Subscription\",\"actionIndicator\":\"A\",\"description\":\"VIDEO\",\"pricePlanId\":\"35616999\",\"price\":\"64.99\",\"contentId\":\"YTTVBASIC\"}]}}]}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\",\"intent\": \"NLG\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddFeaturesUIRequest addFeaturesUIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
        AddFeaturesUIResponse addFeaturesUIResponse = mapper.readValue(sampleResponseString, AddFeaturesUIResponse.class);

        sampleRedisData.setStoreLocationState("NY");
        sampleRedisData.setCustomerAddressState("NY");
        sampleRedisData.setLineLevelDigitalSecureSubscriptionCount("2");
        Mockito.when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(true));
        Mockito.when(redisHelper.getAddFeaturesRequest()).thenReturn(Mono.just(addFeaturesUIRequest));
        Mockito.when(bpmHelper2.addFeatures(Mockito.any())).thenReturn(Mono.just(addFeaturesUIResponse));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mockito.when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        Mockito.when(redisHelper2.updateLinelevelDigitalSecureSubscriptionCountintoRedis(Mockito.anyInt())).thenReturn(Mono.just(Boolean.TRUE));

        Mono<AddFeaturesUIResponse> response = helper.addFeatures(addFeaturesUIRequest);

        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void addFeature_AccountNotNull_Test() throws IOException {
        String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGAgeneratedmessage\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1583186-DEV3\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"ShoppingCart`\"}]},\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"cartInfo\":{\"cartId\":\"69a66ef4d-7e344dfb-2db299209-ea8333\",\"lines\":[{\"lineId\":\"4345949784\",\"status\":1,\"errors\":[],\"conflictedSPO\":[],\"conflictedSFO\":[],\"mtn\":\"4345949784\",\"planValidationFailed\":false,\"featureResponse\":[{\"sorId\":\"82825\",\"actionIndicator\":\"A\",\"type\":\"SFO\",\"price\":20,\"level\":\"L\"}],\"activateLaterInd\":false,\"showInsurancePage\":false,\"impactedLines\":false}],\"accountLevelSPOs\":[],\"tmpmdDrop\":false},\"processMTNList\":[{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}]}}},\"exceptions\":[{\"system\":\"CXP\",\"service\":\"addToCartService\",\"type\":\"Warning\",\"code\":\"E1223\",\"message\":\"Accountvalidationfailed\"}],\"warnings\":[]}";
        String sampleUIRequestString ="{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"ca7608de-6c65-4b6b-85e1-a2904fdb86a2\",\"caseId\":\"SOP-639240-E01\",\"accountNumber\":\"0322638103-00001\",\"cartCreator\":\"8643319007\",\"processingMTN\":\"\",\"intendType\":\"EUP\",\"processStep\":\"FeaturesPDP\"},\"data\":{\"account\":{\"mcsSubscription\":{\"add\":[{\"itemId\":\"307462196\",\"name\":\"YouTubeTV Basic Subscription\",\"actionIndicator\":\"A\",\"description\":\"VIDEO\",\"pricePlanId\":\"35616999\",\"price\":\"64.99\",\"contentId\":\"YTTVBASIC\"}]}},\"lines\":[{\"mtn\":\"8643858663\",\"features\":{\"add\":[{\"id\":\"66332\",\"actionIndicator\":\"A\",\"type\":\"SFO\",\"quantity\":1}]},\"mcsSubscription\":{\"add\":[{\"itemId\":\"307272146\",\"name\":\"YouTubeTV Basic Subscription\",\"actionIndicator\":\"A\",\"description\":\"VIDEO\",\"pricePlanId\":\"35616999\",\"price\":\"64.99\",\"contentId\":\"YTTVBASIC\"}]}}]}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\",\"flowName\": \"\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\",\"intent\": \"NLG\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddFeaturesUIRequest addFeaturesUIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
        AddFeaturesUIResponse addFeaturesUIResponse = mapper.readValue(sampleResponseString, AddFeaturesUIResponse.class);

        sampleRedisData.setStoreLocationState("NY");
        sampleRedisData.setCustomerAddressState("CA");
        sampleRedisData.setLineLevelDigitalSecureSubscriptionCount("2");
        Mockito.when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(true));
        Mockito.when(redisHelper.getAddFeaturesRequest()).thenReturn(Mono.just(addFeaturesUIRequest));
        Mockito.when(bpmHelper2.addFeatures(Mockito.any())).thenReturn(Mono.just(addFeaturesUIResponse));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mockito.when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        Mockito.when(redisHelper2.updateLinelevelDigitalSecureSubscriptionCountintoRedis(Mockito.anyInt())).thenReturn(Mono.just(Boolean.TRUE));

        Mono<AddFeaturesUIResponse> response = helper.addFeatures(addFeaturesUIRequest);

        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void resumeAndContinue_ServiceBodyNull_Test() throws IOException, SOEHTTPException {
        String sampleRequestString = "{\"cartInfo\":{\"processingMTN\": \"4235344191\",\"intendTpye\": \"XXX\"},\"data\": {\"itemType\": \"SELLERPRICE\",\"action\": \"UPDATE\",\"lines\": [{\"mtn\": \"4699199099\",\"sellerPrice\":\"4699199099\"},{\"mtn\": \"4699199098\",\"sellerPrice\":\"4699199099\"}]}}";
        String sampleResponseString ="{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"99\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        ResumeAndContinueUIRequest resumeAndContinueUIRequest = mapper.readValue(sampleRequestString, ResumeAndContinueUIRequest.class);
        ResumeAndContinueUIResponse resumeAndContinueUIResponse = mapper.readValue(sampleResponseString, ResumeAndContinueUIResponse.class);

        Mockito.when(bpmHelper3.resumeAndContinue(Mockito.any())).thenReturn(Mono.just(resumeAndContinueUIResponse));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));

        Mono<ResumeAndContinueUIResponse> response = helper.resumeAndContinue(resumeAndContinueUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void resumeAndContinue_CartCaseEmpty_Test() throws IOException, SOEHTTPException {
        String sampleRequestString = "{\"cartInfo\":{\"processingMTN\": \"4235344191\",\"intendTpye\": \"XXX\"},\"data\": {\"itemType\": \"SELLERPRICE\",\"action\": \"UPDATE\",\"lines\": [{\"mtn\": \"4699199099\",\"sellerPrice\":\"4699199099\"},{\"mtn\": \"4699199098\",\"sellerPrice\":\"4699199099\"}]}}";
        String sampleResponseString ="{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"\",\"contextInfo\":{\"processAction\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"availablePaths\":[{\"path\":\"AccessoryPDP\"}]},\"customerInfo\":{\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\",\"accountNumber\":\"0820215913-00001\"},\"cartInfo\":{\"cartId\":\"\",\"statusCode\":\"0\",\"statusMsg\":\"Success\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\"]},{\"mtn\":\"2515813861\",\"completedprocessSteps\":[]}]}}}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        ResumeAndContinueUIRequest resumeAndContinueUIRequest = mapper.readValue(sampleRequestString, ResumeAndContinueUIRequest.class);
        ResumeAndContinueUIResponse resumeAndContinueUIResponse = mapper.readValue(sampleResponseString, ResumeAndContinueUIResponse.class);

        Mockito.when(bpmHelper3.resumeAndContinue(Mockito.any())).thenReturn(Mono.just(resumeAndContinueUIResponse));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mockito.when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));

        Mono<ResumeAndContinueUIResponse> response = helper.resumeAndContinue(resumeAndContinueUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).verifyComplete();
    }

    @Test
    public void addAccessoryClearAndContinue_CartIdNotNull_Test() throws IOException {
        String sampleResponseString = "{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.12.06.05.31.45-448.15006739142274\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"availablePaths\":[{\"path\":\"ShoppingCart\"},{\"path\":\"addDevice\"},{\"path\":\"addFeatures\"},{\"path\":\"showFeatures\"},{\"path\":\"showDevice\"},{\"path\":\"showAccessory\"},{\"path\":\"addAccessory\"},{\"path\":\"TradeIn\"}]},\"customerInfo\":{\"customerType\":\"N\",\"originalCreditApprovalNumber\":\"423157091\",\"accountNumber\":\"\",\"cartCreator\":\"423157091\",\"processingMTN\":\"9732705801\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":123,\"statusMsg\":\"\",\"statusCode\":\"0\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"9732705801\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"InterimPage\",\"GridWallPDP\",\"GridWallPDP\",\"PlanSelection\",\"ShoppingCart\",\"ShowHandoff\",\"GridWallPDP\",\"ShoppingCart\"]}]}}},\"cartCount\":\"2\"}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddAccessoriesUIResponse addAccessoriesUIResponse = mapper.readValue(sampleResponseString, AddAccessoriesUIResponse.class);

        sampleRedisData.setIntendType("NSE");
        Lines lines1=new Lines();
        lines1.setCurrentDeviceID("123");
        List<Lines> lines=new ArrayList<>();
        lines.add(lines1);
        sampleRedisData.setLines(lines);
        sampleRedisData.setDepletionType("depl");
        sampleRedisData.setChannelId("VZW-ACSS");
        CartInfo cartInfo=new CartInfo();
        cartInfo.setIntendType("NSE");
        sampleRedisData.setAccessoryCartInfo(cartInfo);
        sampleRedisData.setDepletionType("depl");

        Mockito.when(redisHelper.updateDataIntoRedisAsString(sampleRedisData,"accessory")).thenReturn(Mono.just(Boolean.TRUE));
        Mockito.when(cartAccessoryHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(addAccessoriesUIResponse));

        Mono<AddAccessoriesUIResponse> activationResponse = helper.addAccessoryClearAndContinue(sampleRedisData,"SOP-329-E01","20ae6bcb-1150-4d16-99dd-14b7d9f128c7");

        StepVerifier.create(activationResponse).expectError().verify();
    }

    @Test
    public void nbxFeedbackHelper_ContractTerm_VERIZON_EDGE_Test() throws IOException {
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String nbxString = "{\"service\": {\"serviceHeader\": {\"clientId\": \"NETACE\",\"clientTransactionId\": \"NETACE-28023137-TXN\",\"clientSessionId\": \"NETACE-32a6993a-SESSION\",\"timestamp\": \"2020-05-06 07:50:30 GMT\",\"serviceName\": \"NBX\"},\"serviceBody\": {\"serviceRequest\": {\"contextInfo\": {\"callReason\": \"Recommendation\",\"category\": \"Offers\",\"subServiceName\": \"CaptureResponse\",\"sessionId\": \"-2233353673817713409\",\"rtdSessionID\": \"\"},\"customerInfo\": {\"mtn\": \"7573285016\",\"accountNo\": \"0420914396-00001\"},\"customerResponse\": {\"responseList\": [{\"rank\": \"1\",\"propositionId\": \"RO_01\",\"dispositionOptionId\": \"82\",\"soiEngagementId\": \"501002648\",\"timeStamp\": \"2020-05-06 07:50:30 GMT\",\"dynamicAttrList\": [{\"attrId\": \"skuid\",\"value\": \"MWAR2LL/A\"},{\"attrId\": \"Offer\",\"value\": \"RS_131\"}]}],\"externalResponseList\": [{\"rank\": null,\"propositionId\": \"RS_131\",\"dispositionOptionId\": \"82\",\"dynamicAttrList\": [{\"attrId\": \"isRtdOffer\",\"value\": \"N\"}],\"externalId\": null}]}}}}}";
        String nbxRequestString = "{ \"cartInfo\": {\"accountNumber\": \"0280106868-00001\"}, \"data\": {\"lines\": [{ \"mtn\": \"7169849755\", \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\"}}] }}";;
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        NBXFeedbackUIRequest nbxReq = mapper.readValue(nbxRequestString, NBXFeedbackUIRequest.class);
        String bvpStr = "{\"lines\" : [ {\"mtn\" : \"7169849755\",\"getBestValuePromotions\" : {\"bestValueOffers\" : [{ \"id\" : \"545810\", \"dispositionOptionId\" : \"81\", \"myOffer\" : false, \"name\" : \"TestSM\", \"verizonUp\" : false, \"description\" : \"TestSM\", \"contractTypes\" : [ \"FR\", \"DPP\", \"VERIZON_EDGE\" ], \"rank\" : \"1\", \"myOfferAccepted\" : \"false\", \"verizonUpAccepted\" : \"false\", \"compatiblePlanIds\" : [ \"\" ] },{ \"id\" : \"RS_131\", \"myOffer\" : false, \"name\" : \"$25 Device Dollars\", \"verizonUp\" : true, \"description\" : \"\", \"myOfferAccepted\" : \"false\", \"verizonUpAccepted\" : \"true\", \"redemptionIds\" : [ \"801000000504353\", \"801000000505722\" ] },{ \"id\" : \"RS_131\", \"myOffer\" : false, \"name\" : \"$25 Device Dollars\", \"barcode\" : \"XYZ\" , \"verizonUp\" : true, \"description\" : \"\", \"myOfferAccepted\" : \"false\", \"verizonUpAccepted\" : \"false\", \"redemptionIds\" : [ \"801000000504353\", \"801000000505722\" ] }],\"clientId\" : \"VZW-ONEPOS\",\"sessionId\" : \"-2691359438552318681\",\"rtdSessionId\" : \"\",\"clientSessionId\" : \"86b0714c-27bd-4f11-80c2-824747a90565\",\"clientTransactionId\" : \"2020-06-26T05:04:19.+0000:121234c9-cdd5-4afc-82f2-39d3fd047f0b:cxp-promotion-domain-qa-ev6v-sit1e-nscxp-bb8d6dc68-sz26p:nssit1\",\"totalDeviceDollarsBalance\" : \"20.0\",\"deviceDollarDisplayName\" : \"\",\"isVerizonUpAvailable\" : \"true\",\"isDeviceDollarManuallyAccepted\" : \"false\",\"rank\" : \"2\",\"propositionId\" : \"RO_03\",\"dispositionId\" : \"10\",\"soiEngagementId\" : \"\"}} ]}";
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);

        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mockito.when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        Mockito.when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        Mockito.when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just("abc"));

        Mono<NBXFeedbackResponse> response = helper.nbxFeedbackCall(nbxReq);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

    }

    @Test
    public void nbxFeedbackHelper_MthFlow_NotNull_Test() throws IOException {
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String nbxString = "{\"service\": {\"serviceHeader\": {\"clientId\": \"NETACE\",\"clientTransactionId\": \"NETACE-28023137-TXN\",\"clientSessionId\": \"NETACE-32a6993a-SESSION\",\"timestamp\": \"2020-05-06 07:50:30 GMT\",\"serviceName\": \"NBX\"},\"serviceBody\": {\"serviceRequest\": {\"contextInfo\": {\"callReason\": \"Recommendation\",\"category\": \"Offers\",\"subServiceName\": \"CaptureResponse\",\"sessionId\": \"-2233353673817713409\",\"rtdSessionID\": \"\"},\"customerInfo\": {\"mtn\": \"7573285016\",\"accountNo\": \"0420914396-00001\"},\"customerResponse\": {\"responseList\": [{\"rank\": \"1\",\"propositionId\": \"RO_01\",\"dispositionOptionId\": \"82\",\"soiEngagementId\": \"501002648\",\"timeStamp\": \"2020-05-06 07:50:30 GMT\",\"dynamicAttrList\": [{\"attrId\": \"skuid\",\"value\": \"MWAR2LL/A\"},{\"attrId\": \"Offer\",\"value\": \"RS_131\"}]}],\"externalResponseList\": [{\"rank\": null,\"propositionId\": \"RS_131\",\"dispositionOptionId\": \"82\",\"dynamicAttrList\": [{\"attrId\": \"isRtdOffer\",\"value\": \"N\"}],\"externalId\": null}]}}}}}";
        String nbxRequestString = "{\"service\":{\"serviceHeader\":{\"clientId\":\"ONEPOS\",\"clientTransactionId\":\"2022-12-06T08:12:07.+0000:ed1f3dee5ae9cd92:cxp-browsing-services-qa-ev6v-sit2w-nscxp-666bb46587-cbw78:nssit2\",\"clientSessionId\":\"9db60bd1-bdeb-41ba-bc6e-ffb874c239e4\",\"timestamp\":\"2022-12-06 08:12:11 GMT\",\"serviceName\":\"NBX\"},\"serviceBody\":{\"serviceRequest\":{\"contextInfo\":{\"callReason\":\"Recommendation\",\"category\":\"Offers\",\"subServiceName\":\"CaptureResponse\",\"sessionId\":\"-9019117867860633445\",\"rtdSessionID\":\"\",\"agentID\":\"rahmmu3\"},\"customerInfo\":{\"mtn\":\"2409351896\",\"mtnFlow\":\"PromoBundle\",\"accountNo\":\"0520406594-00001\"},\"customerResponse\":{\"responseList\":[{\"rank\":\"1\",\"propositionId\":\"RO_01\",\"dispositionOptionId\":\"82\",\"soiEngagementId\":\"500000562\",\"timeStamp\":\"2022-12-06 08:12:11 GMT\",\"dynamicAttrList\":[{\"attrId\":\"Offer\",\"value\":\"551120\"}]}],\"externalResponseList\":[{\"rank\":\"1\",\"propositionId\":\"551120\",\"dispositionOptionId\":\"82\",\"soiEngagementId\":\"500000562\",\"timeStamp\":\"2022-12-06 08:12:11 GMT\",\"dynamicAttrList\":[{\"attrId\":\"isRtdOffer\",\"value\":\"N\"}]}]}}}}}";
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        NBXFeedbackUIRequest nbxReq = mapper.readValue(nbxRequestString, NBXFeedbackUIRequest.class);
        String bvpStr = "{\"lines\" : [ {\"mtn\" : \"7169849755\",\"getBestValuePromotions\" : {\"bestValueOffers\" : [{ \"id\" : \"545810\", \"dispositionOptionId\" : \"81\", \"myOffer\" : false, \"name\" : \"TestSM\", \"verizonUp\" : false, \"description\" : \"TestSM\", \"contractTypes\" : [ \"FR\", \"DPP\" ], \"rank\" : \"1\", \"myOfferAccepted\" : \"false\", \"verizonUpAccepted\" : \"false\", \"compatiblePlanIds\" : [ \"\" ] },{ \"id\" : \"RS_131\", \"myOffer\" : false, \"name\" : \"$25 Device Dollars\", \"verizonUp\" : true, \"description\" : \"\", \"myOfferAccepted\" : \"false\", \"verizonUpAccepted\" : \"true\", \"redemptionIds\" : [ \"801000000504353\", \"801000000505722\" ] },{ \"id\" : \"RS_131\", \"myOffer\" : false, \"name\" : \"$25 Device Dollars\", \"barcode\" : \"XYZ\" , \"verizonUp\" : true, \"description\" : \"\", \"myOfferAccepted\" : \"false\", \"verizonUpAccepted\" : \"false\", \"redemptionIds\" : [ \"801000000504353\", \"801000000505722\" ] }],\"clientId\" : \"VZW-ONEPOS\",\"sessionId\" : \"-2691359438552318681\",\"rtdSessionId\" : \"\",\"clientSessionId\" : \"86b0714c-27bd-4f11-80c2-824747a90565\",\"clientTransactionId\" : \"2020-06-26T05:04:19.+0000:121234c9-cdd5-4afc-82f2-39d3fd047f0b:cxp-promotion-domain-qa-ev6v-sit1e-nscxp-bb8d6dc68-sz26p:nssit1\",\"totalDeviceDollarsBalance\" : \"20.0\",\"deviceDollarDisplayName\" : \"\",\"isVerizonUpAvailable\" : \"true\",\"isDeviceDollarManuallyAccepted\" : \"false\",\"rank\" : \"2\",\"propositionId\" : \"RO_03\",\"dispositionId\" : \"10\",\"soiEngagementId\" : \"\"}} ]}";
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);

        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mockito.when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        Mockito.when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        Mockito.when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just("abc"));

        Mono<NBXFeedbackResponse> response = helper.nbxFeedbackCall(nbxReq);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

    }

    @Test
    public void removeBvoOffersHelper_EqualMtn_Test() throws IOException {
        String sampleUIRequestString ="{\"cartInfo\":{\"processingMTN\":\"4235344191\",\"intendTpye\":\"XXX\"},\"data\":{\"lines\":[{\"mtn\":\"7169849755\",\"removeOffers\":[{\"id\":\"2500009\",\"subType\":\"Multi Line BOGO\"}]},{\"mtn\":\"7169849755\",\"removeOffers\":[{\"id\":\"2580005\",\"subType\":\"Trade\"}]}]}}";
        String sampleResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \"SOP-329-E01\",\"contextInfo\": {\"processAction\": \" \",\"callReason\": \"SalesOrderPurchase\",\"processStep\": \"ShoppingCart\",\"availablePaths\": [{\"path\": \"AccessoryPDP\"}]},\"customerInfo\": {\"cartCreator\": \"2515813861\",\"processingMTN\": \"2515813860\",\"accountNumber\": \"0820215913-00001\"},\"cartInfo\": {\"cartId\": \"2515813861\",\"statusCode\": \"0\",\"statusMsg\": \"Success\"},\"processMTNList\": [{\"mtn\": \"2515813860\",\"completedprocessSteps\": [\"MTNSelectionPage\",\"GridWallPDP\"]},{\"mtn\": \"2515813861\",\"completedprocessSteps\": []}]}}}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        String bvpStr = "{\"lines\" : [ {\"mtn\" : \"7169849755\",\"getBestValuePromotions\" : {\"bestValueOffers\" : [{ \"id\" : \"545810\", \"dispositionOptionId\" : \"81\", \"myOffer\" : false, \"name\" : \"TestSM\", \"verizonUp\" : false, \"description\" : \"TestSM\", \"contractTypes\" : [ \"FR\", \"DPP\" ], \"rank\" : \"1\", \"myOfferAccepted\" : \"false\", \"verizonUpAccepted\" : \"false\", \"compatiblePlanIds\" : [ \"\" ] },{ \"id\" : \"RS_131\", \"myOffer\" : false, \"name\" : \"$25 Device Dollars\", \"verizonUp\" : true, \"description\" : \"\", \"myOfferAccepted\" : \"false\", \"verizonUpAccepted\" : \"true\", \"redemptionIds\" : [ \"801000000504353\", \"801000000505722\" ] },{ \"id\" : \"RS_131\", \"myOffer\" : false, \"name\" : \"$25 Device Dollars\", \"barcode\" : \"XYZ\" , \"verizonUp\" : true, \"description\" : \"\", \"myOfferAccepted\" : \"false\", \"verizonUpAccepted\" : \"false\", \"redemptionIds\" : [ \"801000000504353\", \"801000000505722\" ] }],\"clientId\" : \"VZW-ONEPOS\",\"sessionId\" : \"-2691359438552318681\",\"rtdSessionId\" : \"\",\"clientSessionId\" : \"86b0714c-27bd-4f11-80c2-824747a90565\",\"clientTransactionId\" : \"2020-06-26T05:04:19.+0000:121234c9-cdd5-4afc-82f2-39d3fd047f0b:cxp-promotion-domain-qa-ev6v-sit1e-nscxp-bb8d6dc68-sz26p:nssit1\",\"totalDeviceDollarsBalance\" : \"20.0\",\"deviceDollarDisplayName\" : \"\",\"isVerizonUpAvailable\" : \"true\",\"isDeviceDollarManuallyAccepted\" : \"false\",\"rank\" : \"2\",\"propositionId\" : \"RO_03\",\"dispositionId\" : \"10\",\"soiEngagementId\" : \"\"}} ]}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        UpdateBvoOffersUIRequest updateBvoOffersUIRequest = mapper.readValue(sampleUIRequestString, UpdateBvoOffersUIRequest.class);
        UpdateBvoOffersUIResponse updateBvoOffersUIResponse = mapper.readValue(sampleResponseString, UpdateBvoOffersUIResponse.class);
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);

        Mockito.when(bpmHelper3.removeBvoOffers(Mockito.any())).thenReturn(Mono.just(updateBvoOffersUIResponse));
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mockito.when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        Mockito.when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just(new String()));
        Mockito.when(redisHelper2.deleteRemoveOfferDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        Mockito.when(redisHelper2.getRemoveOfferDataIntoRedis()).thenReturn(Mono.just(new RemoveOfferRedisData()));
        Mockito.when(nbxService.formatNbxFeedbackRequest(Mockito.any(BVPLine.class),Mockito.anyString(),Mockito.anyString())).thenReturn(new NBXFeedbackRequest());
        Mockito.when(nbxService.nbxFeedbackCall(Mockito.any(NBXFeedbackRequest.class))).thenReturn(Mono.just(new NBXFeedbackResponse()));

        Mono<UpdateBvoOffersUIResponse> response = helper.removeBvoOffers(updateBvoOffersUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).verifyComplete();

    }

    @Test
    public void populateSPOsHelper_SpoNotEmpty_Test() throws IOException, SOEHTTPException {
        String sampleResponseString ="{\"genericHeader\":\"header\"}";
        CartServiceCartInfo cartServiceCartInfo=new CartServiceCartInfo();
        Line[] lines=new Line[1];
        Line line=new Line();
        ConflictedSPO[] conflictedSPOS=new ConflictedSPO[1];
        ConflictedSPO conflictedSPO=new ConflictedSPO();
        conflictedSPO.setId("1");
        conflictedSPOS[0]=conflictedSPO;
        line.setSpos(conflictedSPOS);
        lines[0]=line;
        cartServiceCartInfo.setLines(lines);
        GenericResponse genericResponse = mapper.readValue(sampleResponseString, GenericResponse.class);
        Mockito.when(redisHelper.updateSPOsIntoRedis(Mockito.any(ConflictedSPOs.class))).thenReturn(Mono.just(Boolean.TRUE));

        Mono<ResponseEntity<GenericResponse>> response = helper.populateSPOs(cartServiceCartInfo,genericResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).verifyComplete();
        Mockito.when(redisHelper.updateSPOsIntoRedis(Mockito.any(ConflictedSPOs.class))).thenReturn(Mono.just(Boolean.FALSE));
        response = helper.populateSPOs(cartServiceCartInfo,genericResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).verifyComplete();
        line.setSpos(null);
        lines[0]=line;
        cartServiceCartInfo.setLines(lines);
        response = helper.populateSPOs(cartServiceCartInfo,genericResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).verifyComplete();
        cartServiceCartInfo.setLines(null);
        response = helper.populateSPOs(cartServiceCartInfo,genericResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).verifyComplete();


    }

    @Test
    public void populateSPOsFor5GBolt_SpoNotEmpty_Test() throws IOException, SOEHTTPException {
        String sampleResponseString ="{\"genericHeader\":\"header\"}";
        CartServiceCartInfo cartServiceCartInfo=new CartServiceCartInfo();
        Line[] lines=new Line[1];
        Line line=new Line();
        ConflictedSPO[] conflictedSPOS=new ConflictedSPO[1];
        ConflictedSPO conflictedSPO=new ConflictedSPO();
        conflictedSPO.setId("1");
        conflictedSPO.setIs5GBolt(true);
        conflictedSPOS[0]=conflictedSPO;
        line.setSpos(conflictedSPOS);
        lines[0]=line;
        cartServiceCartInfo.setLines(lines);
        GenericResponse genericResponse = mapper.readValue(sampleResponseString, GenericResponse.class);
        Mockito.when(redisHelper.updateSPOsIntoRedis(Mockito.any(ConflictedSPOs.class))).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> response = helper.populateSPOsFor5GBolt(cartServiceCartInfo,genericResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).verifyComplete();
        conflictedSPO.setIs5GBolt(false);
        conflictedSPOS[0]=conflictedSPO;
        response = helper.populateSPOsFor5GBolt(cartServiceCartInfo,genericResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).verifyComplete();
        conflictedSPO.setIs5GBolt(null);
        response = helper.populateSPOsFor5GBolt(cartServiceCartInfo,genericResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).verifyComplete();
        line.setSpos(new ConflictedSPO[1]);
        response = helper.populateSPOsFor5GBolt(cartServiceCartInfo,genericResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).verifyComplete();
        line.setSpos(null);
        response = helper.populateSPOsFor5GBolt(cartServiceCartInfo,genericResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).verifyComplete();
        cartServiceCartInfo.setLines(new Line[1]);
        response = helper.populateSPOsFor5GBolt(cartServiceCartInfo,genericResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).verifyComplete();

        cartServiceCartInfo.setLines(null);
        response = helper.populateSPOsFor5GBolt(cartServiceCartInfo,genericResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).verifyComplete();

    }

    @Test
    public void populateHumWifiConflictedSFos_SpoNotEmpty_Test() throws IOException, SOEHTTPException {
        String sampleResponseString ="{\"genericHeader\":\"header\"}";
        GenericResponse genericResponse = mapper.readValue(sampleResponseString, GenericResponse.class);
        CartServiceCartInfo cartServiceCartInfo=new CartServiceCartInfo();
        Line[] lines=new Line[1];
        Line line=new Line();
        ConflictedSFO[] conflictedSFOS=new ConflictedSFO[1];
        ConflictedSFO conflictedSFO=new ConflictedSFO();
        conflictedSFO.setId("1");
        conflictedSFO.setDisplayHumWiFi(true);
        conflictedSFOS[0]=conflictedSFO;
        line.setSfos(conflictedSFOS);
        lines[0]=line;
        cartServiceCartInfo.setLines(lines);
        Mockito.when(redisHelper.updateSFOsIntoRedis(Mockito.any(ConflictedSFOs.class))).thenReturn(Mono.just(Boolean.TRUE));

        Mono<ResponseEntity<GenericResponse>> response = helper.populateHumWifiConflictedSFos(cartServiceCartInfo,genericResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).verifyComplete();
        Mockito.when(redisHelper.updateSFOsIntoRedis(Mockito.any(ConflictedSFOs.class))).thenReturn(Mono.just(Boolean.TRUE));
        response = helper.populateHumWifiConflictedSFos(cartServiceCartInfo,genericResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).verifyComplete();
        conflictedSFO.setDisplayHumWiFi(false);
        response = helper.populateHumWifiConflictedSFos(cartServiceCartInfo,genericResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).verifyComplete();
        conflictedSFO.setDisplayHumWiFi(null);
        response = helper.populateHumWifiConflictedSFos(cartServiceCartInfo,genericResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).verifyComplete();
        conflictedSFOS[0]=new ConflictedSFO();
        response = helper.populateHumWifiConflictedSFos(cartServiceCartInfo,genericResponse);
        line.setSfos(new ConflictedSFO[1]);
        response = helper.populateHumWifiConflictedSFos(cartServiceCartInfo,genericResponse);
        line.setSfos(null);
        response = helper.populateHumWifiConflictedSFos(cartServiceCartInfo,genericResponse);
        lines[0]=new Line();
        response = helper.populateHumWifiConflictedSFos(cartServiceCartInfo,genericResponse);
        cartServiceCartInfo.setLines(new Line[1]);
        response = helper.populateHumWifiConflictedSFos(cartServiceCartInfo,genericResponse);
        cartServiceCartInfo.setLines(null);
        response = helper.populateHumWifiConflictedSFos(cartServiceCartInfo,genericResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).verifyComplete();

    }
    @Test
    public void addReplenishmentToCartTest1() throws IOException, SOEHTTPException {
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);

        String addReplenishmentToCartUIResponseString="{\"cartInfo\":{\"clientAppName\":\"ATG-TELE-ONEPOS\",\"cartCreator\":\"\",\"creditAppNumber\":\"240042539\",\"cartId\":\"05826fbe-3e7a-4ef8-87ad-5e708c05a9af\",\"caseId\":\"SOF-11445792-C01\",\"processingMTN\":\"8039204546\",\"intendType\":\"AAL\",\"processStep\":\"addReplenishment\"},\"data\":{\"lines\":[{\"mtn\":\"8039204546\",\"isActivateWithoutReplenish\":false,\"replenishmentAmount\":\"80.00\",\"processingMTN\":\"8039204546\"}]}}    ";
        AddReplenishmentToCartUIRequest addReplenishmentToCartUIRequest= mapper.readValue(addReplenishmentToCartUIResponseString, AddReplenishmentToCartUIRequest.class);

        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mockito.when(bpmHelper3.addReplenishmentToCart(Mockito.any(AddReplenishmentToCartUIRequest.class)))
                .thenReturn(Mono.just(new AddReplenishmentToCartUIResponse()));
        Mono<AddReplenishmentToCartUIResponse> addReplenishmentToCartUIResponseMono=helper.addReplenishmentToCart(addReplenishmentToCartUIRequest);

        StepVerifier.create(addReplenishmentToCartUIResponseMono).assertNext(resp->{
            Assertions.assertNotNull(resp);
        }).verifyComplete();
    }
    @Test
    public void addReplenishmentToCartTest2() throws IOException, SOEHTTPException {
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);

        String addReplenishmentToCartUIResponseString="{\"cartInfo\":{\"clientAppName\":\"ATG-TELE-ONEPOS\",\"cartCreator\":\"\",\"creditAppNumber\":\"240042539\",\"cartId\":\"05826fbe-3e7a-4ef8-87ad-5e708c05a9af\",\"caseId\":\"SOF-11445792-C01\",\"processingMTN\":\"8039204546\",\"intendType\":\"BYOD\",\"processStep\":\"addReplenishment\"},\"data\":{\"lines\":[{\"mtn\":\"8039204546\",\"isActivateWithoutReplenish\":false,\"replenishmentAmount\":\"80.00\",\"processingMTN\":\"8039204546\"}]}}    ";
        AddReplenishmentToCartUIRequest addReplenishmentToCartUIRequest= mapper.readValue(addReplenishmentToCartUIResponseString, AddReplenishmentToCartUIRequest.class);

        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mockito.when(bpmHelper3.addReplenishmentToCart(Mockito.any(AddReplenishmentToCartUIRequest.class)))
                .thenReturn(Mono.just(new AddReplenishmentToCartUIResponse()));
        Mono<AddReplenishmentToCartUIResponse> addReplenishmentToCartUIResponseMono=helper.addReplenishmentToCart(addReplenishmentToCartUIRequest);

        StepVerifier.create(addReplenishmentToCartUIResponseMono).assertNext(resp->{
            Assertions.assertNotNull(resp);
        }).verifyComplete();
    }
    @Test
    public void updateBarcodeTest() throws IOException, SOEHTTPException {
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" ,\"customerType\": \"U\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);

        String updateBarcodeUIRequestString="{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"52162a02-4c30-4f00-8a19-4cfc434daa2d\",\"caseId\":\"SOF-14766581-E01\",\"accountNumber\":\"A56162213783\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"ShoppingCart\",\"barCodeIds\":[{\"barCodeId\":\"UATTSTABCD00014001\"}],\"creditAppNum\":\"\"},\"data\":{\"includeExpiryBarcodeStatus\":\"Y\",\"lines\":[{\"mtn\":\"77535345345\"}]}}";
        UpdateBarcodeUIRequest updateBarcodeUIRequest= mapper.readValue(updateBarcodeUIRequestString, UpdateBarcodeUIRequest.class);

        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		/*
		 * Mockito.when(bpmHelper3.addReplenishmentToCart(Mockito.any(
		 * AddReplenishmentToCartUIRequest.class))) .thenReturn(Mono.just(new
		 * AddReplenishmentToCartUIResponse()));
		 */
        Mono<UpdateBarcodeUIResponse> monoRes =helper.updateBarcode(updateBarcodeUIRequest);
        StepVerifier.create(monoRes).expectError().verify();
        //StepVerifier.create(monoRes).assertNext(resp -> Assert.assertNotNull(resp)).verifyComplete();

       
    }
    @Test
    public void updateBarcodeTest_1() throws IOException, SOEHTTPException {
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" ,\"customerType\": \"U\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);

        String updateBarcodeUIRequestString="{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"cartId\":\"52162a02-4c30-4f00-8a19-4cfc434daa2d\",\"caseId\":\"SOF-14766581-E01\",\"accountNumber\":\"A56162213783\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"ShoppingCart\",\"barCodeIds\":[{\"barCodeId\":\"UATTSTABCD00014001\"}],\"creditAppNum\":\"\"},\"data\":{\"includeExpiryBarcodeStatus\":\"Y\",\"lines\":[{\"mtn\":\"77535345345\"}]}}";
        
        String updateBarcodePegaResponse="{\r\n" + 
        		"        \"serviceHeader\": {\r\n" + 
        		"                \"clientId\": \"OMNI-TELESALES\",\r\n" + 
        		"                \"statusMsg\": \"SUCCESS\",\r\n" + 
        		"                \"correlationId\": \"soe-cart-2022.07.26.07.38.08-336.01655170087196\",\r\n" + 
        		"                \"sessionId\": \"\",\r\n" + 
        		"                \"serviceName\": \"SalesOrderFlex\",\r\n" + 
        		"                \"userId\": \"\",\r\n" + 
        		"                \"statusCode\": \"00\"\r\n" + 
        		"        },\r\n" + 
        		"        \"serviceBody\": {\r\n" + 
        		"                \"serviceResponse\": {\r\n" + 
        		"                        \"context\": {\r\n" + 
        		"                                \"cartInfo\": {\r\n" + 
        		"                                        \"statusMsg\": \"Barcode validated successfully\",\r\n" + 
        		"                                        \"cartId\": \"40981fb4-87b8-4e80-bcbc-b5546c4a559e\",\r\n" + 
        		"                                        \"effectiveDateDetails\": {\r\n" + 
        		"                                                \"futureDateAllowed\": \"false\",\r\n" + 
        		"                                                \"isOnDemandAllowed\": false,\r\n" + 
        		"                                                \"isBackDateAllowed\": false,\r\n" + 
        		"                                                \"onDemandAllowed\": \"false\",\r\n" + 
        		"                                                \"backDateAllowed\": \"false\",\r\n" + 
        		"                                                \"selectedDate\": \"07/26/2022\",\r\n" + 
        		"                                                \"isFutureDateAllowed\": false\r\n" + 
        		"                                        },\r\n" + 
        		"                                        \"lines\": [],\r\n" + 
        		"                                        \"statusCode\": \"1\"\r\n" + 
        		"                                },\r\n" + 
        		"                                \"contextInfo\": {\r\n" + 
        		"                                        \"availablePaths\": [\r\n" + 
        		"                                                {\r\n" + 
        		"                                                        \"path\": \"PromoHub\"\r\n" + 
        		"                                                }\r\n" + 
        		"                                        ],\r\n" + 
        		"                                        \"processAction\": \"\",\r\n" + 
        		"                                        \"processStep\": \"ShoppingCart\",\r\n" + 
        		"                                        \"callReason\": \"SalesOrderFlex\"\r\n" + 
        		"                                },\r\n" + 
        		"                                \"caseId\": \"SOF-8698959-E01\",\r\n" + 
        		"                                \"customerInfo\": {\r\n" + 
        		"                                        \"cartCreator\": \"POE-D-0677d2b2-c1ff-403f-aa41-24aa06a8ba66\",\r\n" + 
        		"                                        \"customerType\": \"U\",\r\n" + 
        		"                                        \"globalId\": \"POE-D-0677d2b2-c1ff-403f-aa41-24aa06a8ba66\",\r\n" + 
        		"                                        \"processingMTN\": \"newLine1\",\r\n" + 
        		"                                        \"accountNumber\": \"\",\r\n" + 
        		"                                        \"mtnFlow\": \"D\"\r\n" + 
        		"                                },\r\n" + 
        		"                                \"processMTNList\": [\r\n" + 
        		"                                        {\r\n" + 
        		"                                                \"mtn\": \"newLine1\",\r\n" + 
        		"                                                \"completedprocessSteps\": [\r\n" + 
        		"                                                        \"AccessoryInterestial\",\r\n" + 
        		"                                                        \"PromoHub\",\r\n" + 
        		"                                                        \"NewRecommendedPlanSelection\",\r\n" + 
        		"                                                        \"DeviceConfigurator\",\r\n" + 
        		"                                                        \"PromoHub\",\r\n" + 
        		"                                                        \"PromoHub\",\r\n" + 
        		"                                                        \"PromoHub\"\r\n" + 
        		"                                                ]\r\n" + 
        		"                                        }\r\n" + 
        		"                                ]\r\n" + 
        		"                        }\r\n" + 
        		"                }\r\n" + 
        		"        }\r\n" + 
        		"}";
        UpdateBarcodeUIRequest updateBarcodeUIRequest= mapper.readValue(updateBarcodeUIRequestString, UpdateBarcodeUIRequest.class);
        UpdateBarcodeUIResponse updateBarcodeUIResponse= mapper.readValue(updateBarcodePegaResponse, UpdateBarcodeUIResponse.class);
        Mono<UpdateBarcodeUIResponse> updateBarcodeUIResponseMon= Mono.just(updateBarcodeUIResponse);
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		
		  Mockito.when(bpmHelper3.updateBarcode(Mockito.any(UpdateBarcodeUIRequest.class))) .thenReturn(updateBarcodeUIResponseMon);
		 
        Mono<UpdateBarcodeUIResponse> monoRes =helper.updateBarcode(updateBarcodeUIRequest);
        //StepVerifier.create(monoRes).expectError().verify();
        StepVerifier.create(monoRes).assertNext(resp -> Assert.assertNotNull(monoRes)).verifyComplete();

       
    }

    @Test
    public void validateCartAndCheckout_WithFlow_isRF() throws Exception {
        String redisDataString = "{ \"flow\": \"RF\"}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(featureFlagHelper.earlyUpgradeBlockerFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        String initCheckoutUIString = "{    \"cartInfo\": {        \"isInterimValidation\": true,        \"effectivedate\": false,        \"intendType\": \"REX\", \"processingMTN\": \"4049738445\",        \"processStep\": \"ShoppingCart\",        \"processAction\": \"proceedToOrder\",        \"cartId\": \"11cf8982-3ec2-4b6d-8c18-815cadbd7d68\",        \"caseId\": \"SOA-11473474-E01\",        \"accountNumber\": \"\"    },    \"channelId\": \"OMNI-RETAIL\"}";
        InitiateCheckoutUIRequest initCheckoutUIRequest = mapper.readValue(initCheckoutUIString, InitiateCheckoutUIRequest.class);

        String validateCartUIString = "{\"data\": {\"validateCartAndUpdate\": {\"orderDetails\": {}}}}";
        ValidateCartUIResponse validateCartUIResp = mapper.readValue(validateCartUIString, ValidateCartUIResponse.class);

        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mockito.when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartUIResp));
        Mockito.when(bpmHelper2.validateOrder(Mockito.any()))
                .thenReturn(Mono.just(new InitiateCheckoutUIResponse()));

        Mono<InitiateCheckoutUIResponse> monoRes = helper.validateCartAndCheckout(initCheckoutUIRequest);

        StepVerifier.create(monoRes).assertNext(resp -> Assert.assertNotNull(monoRes)).verifyComplete();

        String validateCartUIString1 = "{\"data\": {\"validateCartAndUpdate\":{\"orderDetails\":{\"cartReadyForCheckout\":true},\"cartValidationErrors\":[{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"1090\",\"errorMessage\":\"Shipping is Required\",\"fieldPath\":\"\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"1091\",\"errorMessage\":\"Payment is Required\",\"fieldPath\":\"\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"2214\",\"errorMessage\":\"TradeInShippingType option is restricted with RecoveryKit\",\"fieldPath\":\"\"}]}}}";
        ValidateCartUIResponse validateCartUIResp1 = mapper.readValue(validateCartUIString1, ValidateCartUIResponse.class);
        Mockito.when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartUIResp1));
        Mono<InitiateCheckoutUIResponse> monoRes1 = helper.validateCartAndCheckout(initCheckoutUIRequest);
        StepVerifier.create(monoRes1).assertNext(resp -> Assert.assertNotNull(monoRes1)).verifyComplete();
        
        initCheckoutUIRequest.setChannelId("OMNI-TELESALES");
        String validateCartUIString2 = "{\"data\": {\"validateCartAndUpdate\":{\"orderDetails\":{\"cartReadyForCheckout\":false},\"cartValidationErrors\":[{\"errorCategory\":\"Cart\",\"errorLevel\":\"Blocker\",\"errorCode\":\"1030\",\"errorMessage\":\"Shipping is Required\",\"fieldPath\":\"\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"1091\",\"errorMessage\":\"Payment is Required\",\"fieldPath\":\"\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"2214\",\"errorMessage\":\"TradeInShippingType option is restricted with RecoveryKit\",\"fieldPath\":\"\"}]}}}";
        ValidateCartUIResponse validateCartUIResp2 = mapper.readValue(validateCartUIString2, ValidateCartUIResponse.class);
        Mockito.when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartUIResp2));
        Mono<InitiateCheckoutUIResponse> monoRes2 = helper.validateCartAndCheckout(initCheckoutUIRequest);
        StepVerifier.create(monoRes2).assertNext(resp -> Assert.assertNotNull(monoRes1)).verifyComplete();

        //flexV2 Existing customer
        String request="{\"cartInfo\":{\"intendType\":\"\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\",\"creditAppNum\":\"\",\"skipValidationErrorCodes\":\"\",\"quoteWithoutCredit\":false}}";
        InitiateCheckoutUIRequest initCheckoutUIRequest2 = mapper.readValue(request, InitiateCheckoutUIRequest.class);
        initCheckoutUIRequest2.getCartInfo().setFlexV2(true);
        initCheckoutUIRequest2.setChannelId("OMNI-TELESALES");
        String validateCartUIString3 = "{\"data\": {\"validateCartAndUpdate\":{\"orderDetails\":{\"cartReadyForCheckout\":true},\"cartValidationErrors\":[{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"1090\",\"errorMessage\":\"Shipping is Required\",\"fieldPath\":\"\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"1091\",\"errorMessage\":\"Payment is Required\",\"fieldPath\":\"\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"2214\",\"errorMessage\":\"TradeInShippingType option is restricted with RecoveryKit\",\"fieldPath\":\"\"}]}}}";
        ValidateCartUIResponse validateCartUIResp3 = mapper.readValue(validateCartUIString3, ValidateCartUIResponse.class);
        String redisDataString1 = "{\"cartId\":\"9cd0fb9e-c613-4a01-8ef3-91bc4223e1ef\",\"caseId\":\"SOP-15577629-E01\",\"accountNumber\":\"0219690862-00001\",\"mtn\":\"7178706686\",\"cartCreator\":\"7178706686\",\"cartOrderFlowType\":\"nao\",\"locationCode\":\"0026301\"}";
        CartRedisData sampleRedisData1 = mapper.readValue(redisDataString1, CartRedisData.class);
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData1));
        Mockito.when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartUIResp3));
        monoRes2 = helper.validateCartAndCheckout(initCheckoutUIRequest2);
        StepVerifier.create(monoRes2).assertNext(resp -> Assert.assertNotNull(monoRes1)).verifyComplete();

        //No account number, cartcreator
        redisDataString1 = "{\"cartId\":\"9cd0fb9e-c613-4a01-8ef3-91bc4223e1ef\",\"caseId\":\"SOP-15577629-E01\",\"accountNumber\":\"\",\"mtn\":\"7178706686\",\"cartCreator\":\"\",\"cartOrderFlowType\":\"nao\",\"locationCode\":\"0026301\"}";
        sampleRedisData1 = mapper.readValue(redisDataString1, CartRedisData.class);
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData1));
        Mockito.when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartUIResp3));
        monoRes2 = helper.validateCartAndCheckout(initCheckoutUIRequest2);
        StepVerifier.create(monoRes2).assertNext(resp -> Assert.assertNotNull(monoRes1)).verifyComplete();

        //Account number & cartcreator
        redisDataString1 = "{\"cartId\":\"9cd0fb9e-c613-4a01-8ef3-91bc4223e1ef\",\"caseId\":\"SOP-15577629-E01\",\"accountNumber\":\"0219690862-00001\",\"mtn\":\"7178706686\",\"cartCreator\":\"7178706686\",\"cartOrderFlowType\":\"nao\",\"locationCode\":\"0026301\"}";
        sampleRedisData1 = mapper.readValue(redisDataString1, CartRedisData.class);
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData1));
        Mockito.when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartUIResp3));
        monoRes2 = helper.validateCartAndCheckout(initCheckoutUIRequest2);
        StepVerifier.create(monoRes2).assertNext(resp -> Assert.assertNotNull(monoRes1)).verifyComplete();


        //flexV2 NSE request, N
        request="{\"cartInfo\":{\"intendType\":\"NSE_5G\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\",\"creditAppNum\":\"\",\"skipValidationErrorCodes\":\"\",\"isFWASimplificationEnabled\":false,\"quoteWithoutCredit\":false}}}}";
        initCheckoutUIRequest2 = mapper.readValue(request, InitiateCheckoutUIRequest.class);
        initCheckoutUIRequest2.getCartInfo().setFlexV2(true);
        initCheckoutUIRequest2.getCartInfo().setIntent("");
        initCheckoutUIRequest2.setChannelId("OMNI-TELESALES");
        redisDataString1 = "{\"cartId\":\"9cd0fb9e-c613-4a01-8ef3-91bc4223e1ef\",\"caseId\":\"SOP-15577629-E01\",\"accountNumber\":\"0219690862-00001\",\"mtn\":\"7178706686\",\"cartCreator\":\"7178706686\",\"cartOrderFlowType\":\"NSE\",\"locationCode\":\"0026301\",\"intendType\":\"NSE\",\"customerType\":\"N\"}";
        sampleRedisData1 = mapper.readValue(redisDataString1, CartRedisData.class);
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData1));
        monoRes2 = helper.validateCartAndCheckout(initCheckoutUIRequest2);
        StepVerifier.create(monoRes2).assertNext(resp -> Assert.assertNotNull(monoRes1)).verifyComplete();


    }
    @Test
    public void validateCartAndCheckout_WithFlow_2() throws Exception {
        String redisDataString = "{ \"flowName\":\"NAO\"}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String initCheckoutUIString = "{    \"cartInfo\": {        \"isInterimValidation\": true,        \"effectivedate\": false,        \"intendType\": \"REX\", \"processingMTN\": \"4049738445\",        \"processStep\": \"ShoppingCart\",        \"processAction\": \"proceedToOrder\",        \"cartId\": \"11cf8982-3ec2-4b6d-8c18-815cadbd7d68\",        \"caseId\": \"SOA-11473474-E01\",        \"accountNumber\": \"\"    },    \"channelId\": \"OMNI-RETAIL\"}";
        InitiateCheckoutUIRequest initCheckoutUIRequest = mapper.readValue(initCheckoutUIString, InitiateCheckoutUIRequest.class);

        when(featureFlagHelper.earlyUpgradeBlockerFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));

        String validateCartUIString = "{\"data\": {\"validateCartAndUpdate\": {\"orderDetails\": {}}}}";
        ValidateCartUIResponse validateCartUIResp = mapper.readValue(validateCartUIString, ValidateCartUIResponse.class);

        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mockito.when(cxpHelper.validateCart(Mockito.any(), Mockito.any())).thenReturn(Mono.just(validateCartUIResp));
        Mockito.when(bpmHelper2.validateOrder(Mockito.any()))
                .thenReturn(Mono.just(new InitiateCheckoutUIResponse()));

        String request="{\"cartInfo\":{\"intendType\":\"NSE_5G\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\",\"creditAppNum\":\"\",\"skipValidationErrorCodes\":\"\",\"isFWASimplificationEnabled\":false,\"quoteWithoutCredit\":false}}}}";
        InitiateCheckoutUIRequest initCheckoutUIRequest2 = mapper.readValue(request, InitiateCheckoutUIRequest.class);
        Mono<InitiateCheckoutUIResponse> monoRes2 = helper.validateCartAndCheckout(initCheckoutUIRequest2);

        String validateCartUIString1 = "{\"data\": {\"validateCartAndUpdate\":{\"orderDetails\":{\"cartReadyForCheckout\":true},\"cartValidationErrors\":[{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"1090\",\"errorMessage\":\"Shipping is Required\",\"fieldPath\":\"\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"1091\",\"errorMessage\":\"Payment is Required\",\"fieldPath\":\"\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"2214\",\"errorMessage\":\"TradeInShippingType option is restricted with RecoveryKit\",\"fieldPath\":\"\"}]}}}";
        ValidateCartUIResponse validateCartUIResp1 = mapper.readValue(validateCartUIString1, ValidateCartUIResponse.class);
        Mockito.when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartUIResp1));
        Mono<InitiateCheckoutUIResponse> monoRes1 = helper.validateCartAndCheckout(initCheckoutUIRequest);
        StepVerifier.create(monoRes1).assertNext(resp -> Assert.assertNotNull(monoRes1)).verifyComplete();

        //flowName
        String redisDataString1 = "{\"cartId\":\"9cd0fb9e-c613-4a01-8ef3-91bc4223e1ef\",\"caseId\":\"SOP-15577629-E01\",\"accountNumber\":\"0219690862-00001\",\"mtn\":\"7178706686\",\"cartCreator\":\"7178706686\",\"cartOrderFlowType\":\"NSE\",\"locationCode\":\"0026301\",\"intendType\":\"NSE\",\"customerType\":\"N\",\"flowName\":\"NAO\"}";
        CartRedisData sampleRedisData1 = mapper.readValue(redisDataString1, CartRedisData.class);
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData1));
        monoRes2 = helper.validateCartAndCheckout(initCheckoutUIRequest2);
        StepVerifier.create(monoRes2).assertNext(resp -> Assert.assertNotNull(monoRes1)).verifyComplete();

    }

        @Test
    public void validateCartAndCheckout_WithFlow_isRF1() throws Exception {
        String redisDataString = "{ \"flow\": \"RF\"}";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(featureFlagHelper.earlyUpgradeBlockerFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        String initCheckoutUIString = "{    \"cartInfo\": {        \"isInterimValidation\": true,        \"effectivedate\": false,        \"intendType\": \"REX\", \"processingMTN\": \"4049738445\",        \"processStep\": \"ShoppingCart\",        \"processAction\": \"proceedToOrder\",        \"cartId\": \"11cf8982-3ec2-4b6d-8c18-815cadbd7d68\",        \"caseId\": \"SOA-11473474-E01\",        \"accountNumber\": \"\"    },    \"channelId\": \"OMNI-RETAIL\"}";
        InitiateCheckoutUIRequest initCheckoutUIRequest = mapper.readValue(initCheckoutUIString, InitiateCheckoutUIRequest.class);

        String validateCartUIString = "{\"data\": {\"validateCartAndUpdate\": {\"orderDetails\": {}}}}";
        ValidateCartUIResponse validateCartUIResp = mapper.readValue(validateCartUIString, ValidateCartUIResponse.class);

        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mockito.when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartUIResp));
        Mockito.when(bpmHelper2.validateOrder(Mockito.any()))
                .thenReturn(Mono.just(new InitiateCheckoutUIResponse()));

        Mono<InitiateCheckoutUIResponse> monoRes = helper.validateCartAndCheckout(initCheckoutUIRequest);

        StepVerifier.create(monoRes).assertNext(resp -> Assert.assertNotNull(monoRes)).verifyComplete();

        String validateCartUIString1 = "{\"data\": {\"validateCartAndUpdate\":{\"orderDetails\":{\"cartReadyForCheckout\":true},\"cartValidationErrors\":[{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"1090\",\"errorMessage\":\"Shipping is Required\",\"fieldPath\":\"\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"1091\",\"errorMessage\":\"Payment is Required\",\"fieldPath\":\"\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"2214\",\"errorMessage\":\"TradeInShippingType option is restricted with RecoveryKit\",\"fieldPath\":\"\"}]}}}";
        ValidateCartUIResponse validateCartUIResp1 = mapper.readValue(validateCartUIString1, ValidateCartUIResponse.class);
        Mockito.when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartUIResp1));
        Mono<InitiateCheckoutUIResponse> monoRes1 = helper.validateCartAndCheckout(initCheckoutUIRequest);


        initCheckoutUIRequest.setChannelId("OMNI-TELESALES");
        String validateCartUIString2 = "{\"data\": {\"validateCartAndUpdate\":{\"orderDetails\":{\"cartReadyForCheckout\":false},\"cartValidationErrors\":[{\"errorCategory\":\"Cart\",\"errorLevel\":\"Blocker\",\"errorCode\":\"1030\",\"errorMessage\":\"Shipping is Required\",\"fieldPath\":\"\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"1091\",\"errorMessage\":\"Payment is Required\",\"fieldPath\":\"\"},{\"errorCategory\":\"Cart\",\"errorLevel\":\"Warning\",\"errorCode\":\"2214\",\"errorMessage\":\"TradeInShippingType option is restricted with RecoveryKit\",\"fieldPath\":\"\"}]}}}";
        ValidateCartUIResponse validateCartUIResp2 = mapper.readValue(validateCartUIString2, ValidateCartUIResponse.class);
        Mockito.when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(validateCartUIResp2));
        Mono<InitiateCheckoutUIResponse> monoRes2 = helper.validateCartAndCheckout(initCheckoutUIRequest);
        String request="{\"cartInfo\":{\"intendType\":\"\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\",\"creditAppNum\":\"\",\"skipValidationErrorCodes\":\"\",\"quoteWithoutCredit\":false}}";
        InitiateCheckoutUIRequest initCheckoutUIRequest2 = mapper.readValue(request, InitiateCheckoutUIRequest.class);
        initCheckoutUIRequest2.getCartInfo().setFlexV2(true);
        initCheckoutUIRequest2.setChannelId("OMNI-TELESALES");

        //req "", N
        initCheckoutUIRequest2.getCartInfo().setIntendType("");
        monoRes2 = helper.validateCartAndCheckout(initCheckoutUIRequest2);
        StepVerifier.create(monoRes2).assertNext(resp -> Assert.assertNotNull(monoRes1)).verifyComplete();

        //no intentype , !N
        String redisDataString1 = "{\"cartId\":\"9cd0fb9e-c613-4a01-8ef3-91bc4223e1ef\",\"caseId\":\"SOP-15577629-E01\",\"accountNumber\":\"0219690862-00001\",\"mtn\":\"7178706686\",\"cartCreator\":\"7178706686\",\"cartOrderFlowType\":\"NSE\",\"locationCode\":\"0026301\",\"customerType\":\"E\",\"intendType\":\"\"}";
        CartRedisData sampleRedisData1 = mapper.readValue(redisDataString1, CartRedisData.class);
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData1));
        monoRes2 = helper.validateCartAndCheckout(initCheckoutUIRequest2);
        StepVerifier.create(monoRes2).assertNext(resp -> Assert.assertNotNull(monoRes1)).verifyComplete();

        request="{\"cartInfo\":{\"quoteWithoutCredit\": false}}";
        initCheckoutUIRequest2 = mapper.readValue(request, InitiateCheckoutUIRequest.class);
        initCheckoutUIRequest2.getCartInfo().setFlexV2(false);
        initCheckoutUIRequest2.setChannelId("OMNI-TELESALES");
        monoRes2 = helper.validateCartAndCheckout(initCheckoutUIRequest2);
        StepVerifier.create(monoRes2).assertNext(resp -> Assert.assertNotNull(monoRes1)).verifyComplete();

        //cartinfo
        request="{\"cartInfo\":{}}";
        initCheckoutUIRequest2 = mapper.readValue(request, InitiateCheckoutUIRequest.class);
        initCheckoutUIRequest2.setChannelId("OMNI-TELESALES");
        initCheckoutUIRequest2.setCartInfo(null);
        monoRes2 = helper.validateCartAndCheckout(initCheckoutUIRequest2);
        StepVerifier.create(monoRes2).expectError().verify();

    }


    @Test
    public void testsalesOrderAdjustmentWithAccNumInRedis() throws Exception {
        String uiRequestStr = "{\"cartInfo\":{\"intent\":\"REX\",\"processStep\":\"TransactionSelectionPage\",\"processAction\":\"ReviewOrder\",\"intendType\":\"REX\",\"cartId\":\"5bc71bde-269d-4cbd-af90-0a39dc69fe04\",\"caseId\":\"SOA-11179174-E01\",\"salesRepId\":\"ENC01\",\"cartCreatorLocationCode\":\"0026301\",\"cartCreator\":\"20183098\"},\"data\":{\"lines\":{\"lineInfo\":[{\"mtnDetails\":{\"mobileNumber\":\"9144960189\",\"lineNumber\":\"9144960189\"},\"multiLineSeqNumber\":\"1\",\"items\":[{\"itemCode\":\"MG6G3LL/A\",\"fmiCheckRequired\":true,\"newInUnOpenedBox\":\"N\",\"cartItemType\":\"DEVICE\",\"qty\":1,\"itemSeqNum\":1,\"refxItemSeqNum\":1,\"returnType\":\"R\",\"refundType\":\"R\",\"returnReason\":{\"returnType\":\"W\",\"primaryReasonCode\":\"90\",\"secondaryReasonCode\":\"94\",\"symptoms\":\"In-Store Pickup Abandoned\"}}]}]},\"selectedReturnItems\":{\"tradeinItemInfo\":[]},\"addressValidationRequired\":true,\"isDisconnectedSelected\":false}}";
        SalesOrderAdjustmentUIRequest uiRequest = mapper.readValue(uiRequestStr, SalesOrderAdjustmentUIRequest.class);
        uiRequest.setChannelId("OMNI-RETAIL");
        String uiResponseStr = "{\"serviceHeader\":{\"clientId\":\"OMNI-RETAIL\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderAdjustment\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.07.13.13.16-817.1812338832891\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOA-11179174-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"},{\"path\":\"ShoppingCart\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderAdjustment\",\"processStep\":\"ShoppingCart\"},\"customerInfo\":{\"accountNumber\":\"0000000000-00001\",\"cartCreator\":\"20183098\",\"processingMTN\":\"\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"refundOrderDetails\":{\"lines\":{\"lineInfo\":[{\"lineActivityType\":\"REF\",\"mtnDetails\":{\"lineNumber\":\"9144960189\",\"mobileNumber\":\"9144960189\"},\"multiLineSeqNumber\":\"1\",\"items\":[{\"deviceId\":\"\"}]}]}},\"missedProfileInfo\":{\"firstName\":\"\",\"lastName\":\"\",\"email\":\"\",\"city\":\"\",\"state\":\"\",\"zipCode\":\"\",\"streetNumber\":\"\",\"streetName\":\"\",\"businessName\":\"\",\"zipCode4\":\"\"},\"cartId\":\"5bc71bde-269d-4cbd-af90-0a39dc69fe04\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false}}}}}";
        SalesOrderAdjustmentUIResponse uiResponse = mapper.readValue(uiResponseStr, SalesOrderAdjustmentUIResponse.class);
        CartRedisData rd = new CartRedisData();
        rd.setAccountNumber("1234567890-00001");
        rd.setCartId("5bc71bde-269d-4cbd-af90-0a39dc69fe04");
        rd.setCaseId("SOA-11179174-E01");
        rd.setProcessingMTN("9144960189");
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(rd));
        Mockito.when(bpmHelper3.salesOrderAdjustment(Mockito.any())).thenReturn(Mono.just(uiResponse));
        StepVerifier.create(helper.salesOrderAdjustment(uiRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void testsalesOrderAdjustmentWithOutAccNumInRedis() throws Exception {
        String uiRequestStr = "{\"cartInfo\":{\"intent\":\"REX\",\"processStep\":\"TransactionSelectionPage\",\"processAction\":\"ReviewOrder\",\"intendType\":\"REX\",\"cartId\":\"5bc71bde-269d-4cbd-af90-0a39dc69fe04\",\"caseId\":\"SOA-11179174-E01\",\"salesRepId\":\"ENC01\",\"cartCreatorLocationCode\":\"0026301\",\"cartCreator\":\"20183098\"},\"data\":{\"lines\":{\"lineInfo\":[{\"mtnDetails\":{\"mobileNumber\":\"9144960189\",\"lineNumber\":\"9144960189\"},\"multiLineSeqNumber\":\"1\",\"items\":[{\"itemCode\":\"MG6G3LL/A\",\"fmiCheckRequired\":true,\"newInUnOpenedBox\":\"N\",\"cartItemType\":\"DEVICE\",\"qty\":1,\"itemSeqNum\":1,\"refxItemSeqNum\":1,\"returnType\":\"R\",\"refundType\":\"R\",\"returnReason\":{\"returnType\":\"W\",\"primaryReasonCode\":\"90\",\"secondaryReasonCode\":\"94\",\"symptoms\":\"In-Store Pickup Abandoned\"}}]}]},\"selectedReturnItems\":{\"tradeinItemInfo\":[]},\"addressValidationRequired\":true,\"isDisconnectedSelected\":false}}";
        SalesOrderAdjustmentUIRequest uiRequest = mapper.readValue(uiRequestStr, SalesOrderAdjustmentUIRequest.class);
        uiRequest.setChannelId("OMNI-RETAIL");
        String uiResponseStr = "{\"serviceHeader\":{\"clientId\":\"OMNI-RETAIL\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderAdjustment\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.07.13.13.16-817.1812338832891\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOA-11179174-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"},{\"path\":\"ShoppingCart\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderAdjustment\",\"processStep\":\"ShoppingCart\"},\"customerInfo\":{\"accountNumber\":\"0000000000-00001\",\"cartCreator\":\"20183098\",\"processingMTN\":\"\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"refundOrderDetails\":{\"lines\":{\"lineInfo\":[{\"lineActivityType\":\"REF\",\"mtnDetails\":{\"lineNumber\":\"9144960189\",\"mobileNumber\":\"9144960189\"},\"multiLineSeqNumber\":\"1\",\"items\":[{\"deviceId\":\"\"}]}]}},\"missedProfileInfo\":{\"firstName\":\"\",\"lastName\":\"\",\"email\":\"\",\"city\":\"\",\"state\":\"\",\"zipCode\":\"\",\"streetNumber\":\"\",\"streetName\":\"\",\"businessName\":\"\",\"zipCode4\":\"\"},\"cartId\":\"5bc71bde-269d-4cbd-af90-0a39dc69fe04\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false}}}}}";
        SalesOrderAdjustmentUIResponse uiResponse = mapper.readValue(uiResponseStr, SalesOrderAdjustmentUIResponse.class);
        CartRedisData rd = new CartRedisData();
        rd.setCartId("5bc71bde-269d-4cbd-af90-0a39dc69fe04");
        rd.setCaseId("SOA-11179174-E01");
        rd.setProcessingMTN("9144960189");
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(rd));
        Mockito.when(bpmHelper3.salesOrderAdjustment(Mockito.any())).thenReturn(Mono.just(uiResponse));
        StepVerifier.create(helper.salesOrderAdjustment(uiRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }
    @Test
    public void addPromoIntentTest(){
        AddPromoIntentUIRequest addPromoIntentUIRequest=new AddPromoIntentUIRequest();
        AddPromoIntentUIResponse addPromoIntentUIResponse=new AddPromoIntentUIResponse();
        addPromoIntentUIRequest.setCartInfo(new CartInfo());
        CartRedisData rd = new CartRedisData();
        rd.setCartId("5bc71bde-269d-4cbd-af90-0a39dc69fe04");
        rd.setCaseId("SOA-11179174-E01");
        rd.setProcessingMTN("9144960189");
        rd.setCartInfo(new CartInfo());
        rd.setMtnFlow("");
        rd.setCustomerType("");
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(rd));
        Mockito.when(bpmHelper2.addPromoIntent(addPromoIntentUIRequest)).thenReturn(Mono.just(addPromoIntentUIResponse));
        StepVerifier.create(helper.addPromoIntent(addPromoIntentUIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();

    }
    @Test
    public void addPromoIntentTest1(){
        AddPromoIntentUIRequest addPromoIntentUIRequest=new AddPromoIntentUIRequest();
        AddPromoIntentUIResponse addPromoIntentUIResponse=new AddPromoIntentUIResponse();
        CartInfo cartInfo=new CartInfo();
        cartInfo.setGlobalId("test");
        addPromoIntentUIRequest.setCartInfo(new CartInfo());
        CartRedisData rd = new CartRedisData();
        rd.setCartId("5bc71bde-269d-4cbd-af90-0a39dc69fe04");
        rd.setCaseId("SOA-11179174-E01");
        rd.setProcessingMTN("9144960189");
        rd.setCartCreator("5bc71bde-269d-4cbd-af90-0a39dc69fe04");
        rd.setCartInfo(cartInfo);
        rd.setMtnFlow("test");
        rd.setCustomerType("test");
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(rd));
        Mockito.when(bpmHelper2.addPromoIntent(addPromoIntentUIRequest)).thenReturn(Mono.just(addPromoIntentUIResponse));
        StepVerifier.create(helper.addPromoIntent(addPromoIntentUIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();

    }
    
    
  //VZWDRE-652
    @Test
    public void testupdateSalesRepAndLocationCode() throws Exception {
        String uiRequestStr = "{\"cartInfo\": {\"cartId\": \"a1749357-6b72-4a8f-864d-fa2da197475b\",\"caseId\": \"SOA-15632963-E01\",\"accountNumber\": \"0001238987-00001\",\"cartCreator\": \"4438786532\",\"processingMTN\": \"4438786532\",\"processStep\": \"ShoppingCart\",\"creditAppNum\": null},\"data\": {\"orderLocationCode\": null,\"salesRepId\": \"T0123\"}}";
        SalesRepAndLocationCodeUIRequest uiRequest = mapper.readValue(uiRequestStr, SalesRepAndLocationCodeUIRequest.class);
        uiRequest.setChannelId("OMNI-RETAIL");
        String uiResponseStr = "{\"serviceHeader\": {\"clientId\": \"OMNI-RETAIL\",\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderAdjustment\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"soe-cart-2023.03.10.13.36.17-137.57678548497344\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \"SOA-15633776-E01\",\"contextInfo\": {\"callReason\": \"SalesOrderAdjustment\",\"processStep\": \"ShoppingCart\",\"processAction\": \"Update-SalesRepLocation\",\"availablePaths\": [{\"path\": \"ShoppingCart\"}]},\"customerInfo\": {\"accountNumber\": \"0281455093-00001\",\"cartCreator\": \"6175814852\",\"processingMTN\": \"6175814852\",\"registerNumber\": 0},\"cartInfo\": {\"cartItemCount\": 0,\"cartId\": \"d6d94695-030a-4664-b338-e4e7f643784e\",\"statusMsg\": \"Success\",\"statusCode\": \"1\",\"promoLossIndicator\": false,\"agreementNumber\": \"0\",\"vztDiscountGain\": false,\"vztDiscountLoss\": false,\"discountPromoTotal\": 0.0,\"registerNumber\": 0,\"salesRep\": {\"givenName\": \"TEAM 1\",\"familyName\": \"NON-COMMISSIONABLE\",\"salesRepType\": \"E\",\"jobTitleId\": \"REP\",\"locationCode\": \"0026301\"},\"protectionNotRequired\": false,\"fmiCheck\": false}}}}}";
        SalesRepAndLocationCodeUIResponse uiResponse = mapper.readValue(uiResponseStr, SalesRepAndLocationCodeUIResponse.class);
        CartRedisData rd = new CartRedisData();
        rd.setAccountNumber("0001238987-00001");
        rd.setCartId("5bc71bde-269d-4cbd-af90-0a39dc69fe04");
        rd.setCaseId("SOA-11179174-E01");
        rd.setProcessingMTN("9144960189");
        rd.setMtn("9144960189");
        rd.setIntendType("REX");
        rd.setCartCreator("1234567890");
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(rd));
        Mockito.when(bpmHelper3.updateSalesRepAndLocationCode(Mockito.any())).thenReturn(Mono.just(uiResponse));
        StepVerifier.create(helper.updateSalesRepAndLocationCode(uiRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void validateMyLinkReferralInfoTest() throws JsonProcessingException {
        String hashKey = "nse";
        String salesFlowSessionId = "random";
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData cartRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        cartRedisData.setIsMyLinkAvailable(true);
        cartRedisData.setMyLinkHashKey("random");
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(cartRedisData));
        MylinkReferralInfoResponse mylinkReferralInfoResponse = new MylinkReferralInfoResponse();
        MylinkData data = new MylinkData();
        data.setStatus("SUCCESS");
        mylinkReferralInfoResponse.setData(data);
        Mockito.when(cxpHelper2.validateMyLinkReferralInfo(Mockito.any(),Mockito.any())).thenReturn(Mono.just(mylinkReferralInfoResponse));
        StepVerifier.create(redisHelper.getDataFromRedis()).assertNext(System.out::println);
        Assert.assertNotNull(helper.validateMyLinkReferralInfo(hashKey,salesFlowSessionId));

        cartRedisData.setIsMyLinkAvailable(false);
        cartRedisData.setMyLinkHashKey("");
        Assert.assertNotNull(helper.validateMyLinkReferralInfo(hashKey,salesFlowSessionId));

        mylinkReferralInfoResponse.getData().setStatus("FAILURE");
        Mockito.when(cxpHelper2.validateMyLinkReferralInfo(Mockito.any(),Mockito.any())).thenReturn(Mono.just(mylinkReferralInfoResponse));
        Assert.assertNotNull(helper.validateMyLinkReferralInfo(hashKey,salesFlowSessionId));

        mylinkReferralInfoResponse.setData(null);
        Mockito.when(cxpHelper2.validateMyLinkReferralInfo(Mockito.any(),Mockito.any())).thenReturn(Mono.just(mylinkReferralInfoResponse));
        Assert.assertNotNull(helper.validateMyLinkReferralInfo(hashKey,salesFlowSessionId));

        Mockito.when(cxpHelper2.validateMyLinkReferralInfo(Mockito.any(),Mockito.any())).thenReturn(Mono.empty());
        Assert.assertNotNull(helper.validateMyLinkReferralInfo(hashKey,salesFlowSessionId));
    }
    @Test
    public void removeLinesTest() throws Exception {
        String uiRequestStr = "{ \"cartInfo\": { \"clientAppName\": \"VZW-NETACE\", \"creditAppNum\": \"\", \"processingMTN\": \"7653093950\", \"processStep\": \"ShoppingCart\", \"intendType\": \"\", \"processAction\": \"removeDevice\" }, \"data\": { \"lines\": [ { \"mtn\": \"7653093950\" } ] } }";
        RemoveLinesUIRequest uiRequest = mapper.readValue(uiRequestStr, RemoveLinesUIRequest.class);
        uiRequest.setChannelId("OMNI-RETAIL");
        uiRequest.getCartInfo().setFlexV2(true);
        String uiResponseStr = "{\"serviceHeader\": {\"clientId\": \"OMNI-RETAIL\",\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderAdjustment\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"soe-cart-2023.03.10.13.36.17-137.57678548497344\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \"SOA-15633776-E01\",\"contextInfo\": {\"callReason\": \"SalesOrderAdjustment\",\"processStep\": \"ShoppingCart\",\"processAction\": \"Update-SalesRepLocation\",\"availablePaths\": [{\"path\": \"ShoppingCart\"}]},\"customerInfo\": {\"accountNumber\": \"0281455093-00001\",\"cartCreator\": \"6175814852\",\"processingMTN\": \"6175814852\",\"registerNumber\": 0},\"cartInfo\": {\"cartItemCount\": 0,\"cartId\": \"d6d94695-030a-4664-b338-e4e7f643784e\",\"statusMsg\": \"Success\",\"statusCode\": \"1\",\"promoLossIndicator\": false,\"agreementNumber\": \"0\",\"vztDiscountGain\": false,\"vztDiscountLoss\": false,\"discountPromoTotal\": 0.0,\"registerNumber\": 0,\"salesRep\": {\"givenName\": \"TEAM 1\",\"familyName\": \"NON-COMMISSIONABLE\",\"salesRepType\": \"E\",\"jobTitleId\": \"REP\",\"locationCode\": \"0026301\"},\"protectionNotRequired\": false,\"fmiCheck\": false}}}}}";
        RemoveLinesUIResponse uiResponse = mapper.readValue(uiResponseStr, RemoveLinesUIResponse.class);
        CartRedisData rd = new CartRedisData();
        rd.setAccountNumber("0001238987-00001");
        rd.setCartId("5bc71bde-269d-4cbd-af90-0a39dc69fe04");
        rd.setCaseId("SOA-11179174-E01");
        rd.setProcessingMTN("9144960189");
        rd.setMtn("9144960189");
        rd.setCartCreator("1234567890");
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(rd));
        Mockito.when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(new BVPRedisData()));
        Mockito.when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just("userId"));
        Mockito.when(bpmHelper2.removeLines(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mockito.when(featureFlagHelper.isAssistedLPMFETaggingFeatureFlag()).thenReturn(true);
        StepVerifier.create(helper.removeLines(uiRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }
    @Test
    public void removeLines2Test() throws Exception {
        String uiRequestStr = "{ \"cartInfo\": { \"clientAppName\": \"VZW-NETACE\", \"creditAppNum\": \"\", \"processingMTN\": \"7653093950\", \"processStep\": \"ShoppingCart\", \"intendType\": \"\", \"processAction\": \"removeDevice\" }, \"data\": { \"lines\": [ { \"mtn\": \"7653093950\" } ] } }";
        RemoveLinesUIRequest uiRequest = mapper.readValue(uiRequestStr, RemoveLinesUIRequest.class);
        uiRequest.setChannelId("OMNI-RETAIL");
        uiRequest.getCartInfo().setFlexV2(true);
        String uiResponseStr = "{\"serviceHeader\": {\"clientId\": \"OMNI-RETAIL\",\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderAdjustment\",\"userId\": \"\",\"statusCode\": \"00\",\"sessionId\": \"\",\"correlationId\": \"soe-cart-2023.03.10.13.36.17-137.57678548497344\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \"SOA-15633776-E01\",\"contextInfo\": {\"callReason\": \"SalesOrderAdjustment\",\"processStep\": \"ShoppingCart\",\"processAction\": \"Update-SalesRepLocation\",\"availablePaths\": [{\"path\": \"ShoppingCart\"}]},\"customerInfo\": {\"accountNumber\": \"0281455093-00001\",\"cartCreator\": \"6175814852\",\"processingMTN\": \"6175814852\",\"registerNumber\": 0},\"cartInfo\": {\"cartItemCount\": 0,\"cartId\": \"d6d94695-030a-4664-b338-e4e7f643784e\",\"statusMsg\": \"Success\",\"statusCode\": \"1\",\"promoLossIndicator\": false,\"agreementNumber\": \"0\",\"vztDiscountGain\": false,\"vztDiscountLoss\": false,\"discountPromoTotal\": 0.0,\"registerNumber\": 0,\"salesRep\": {\"givenName\": \"TEAM 1\",\"familyName\": \"NON-COMMISSIONABLE\",\"salesRepType\": \"E\",\"jobTitleId\": \"REP\",\"locationCode\": \"0026301\"},\"protectionNotRequired\": false,\"fmiCheck\": false}}}}}";
        RemoveLinesUIResponse uiResponse = mapper.readValue(uiResponseStr, RemoveLinesUIResponse.class);
        CartRedisData rd = new CartRedisData();
        rd.setAccountNumber("0001238987-00001");
        rd.setCartId("5bc71bde-269d-4cbd-af90-0a39dc69fe04");
        rd.setCaseId("SOA-11179174-E01");
        rd.setProcessingMTN("9144960189");
        rd.setMtn("9144960189");
        rd.setCartCreator("1234567890");
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(rd));
        Mockito.when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(new BVPRedisData()));
        Mockito.when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just("userId"));
        Mockito.when(bpmHelper2.removeLines(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mockito.when(featureFlagHelper.isAssistedLPMFETaggingFeatureFlag()).thenReturn(true);

        //null check processAction
        uiRequest.getCartInfo().setProcessAction(null);
        StepVerifier.create(helper.removeLines(uiRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                        .verify();
    }

    @Test
    public void createLineTest() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/createLine1Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/createLine1Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        request.getCartInfo().setIntendType("NSE");
        request.setChannelId("VZW-DOTCOM");
        CreateLineUIResponse response = mapper.readValue(responseString, CreateLineUIResponse.class);
        URI url = URI.create("http://localhost/new-line");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).header("x-akamai-edgescape", "country_code=US,region_code=MD,city=Silver Spring,dma=511,msa=511,lat=39.0680,long=-76.9933,zip=20904,continent=NA,timezone=EST").build();
        ServerHttpResponse httpResponse = null;
        CartRedisData rd = new CartRedisData();
        rd.setAccountNumber("0001238987-00001");
        rd.setCartId("5bc71bde-269d-4cbd-af90-0a39dc69fe04");
        rd.setCaseId("SOA-11179174-E01");
        rd.setProcessingMTN("9144960189");
        rd.setMtn("9144960189");
        rd.setCartCreator("1234567890");
        Map<String, String> requestMap = new HashMap<>();
        String redisDataString = "{\"mtn\":\"1234567890\",\"channel\":\"Digital\"}";
        Map<String,Object> sampleRedisData = mapper.readValue(redisDataString, Map.class);
        String outPut = "{\"cradleFlowJourney\": \"\",\n" +
                "\t\t\"throttleList\": \"|PPP_DF_NSE|\"}";
        CradleResponse cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(outPut);
        request.setHttpRequest(httpHeader);
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(rd));
        Mockito.when(bpmHelper2.createLine(Mockito.any())).thenReturn(Mono.just(response));
        Mockito.when(featureFlag.isFeatureEnabled(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyBoolean())).thenReturn(Mono.just(false));
        when(cradleAllocator.invokeReactiveCradle(httpHeader,httpResponse,requestMap)).thenReturn(Mono.just(cradleResponse));
        StepVerifier.create(helper.createLine(request)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void createLineTest1() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/createLine1Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/createLine1Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        request.getCartInfo().setIntendType("NSE");
        request.setChannelId("VZW-DOTCOM");
        HttpCookie cookie1 = new HttpCookie("abc123", "abcd");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("abc123", cookie1);
        URI url = URI.create("http://localhost/new-line");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-DOTCOM").cookies(bodyMap).build();
        request.setHttpRequest(httpHeader);
        CreateLineUIResponse response = mapper.readValue(responseString, CreateLineUIResponse.class);
        ServerHttpResponse httpResponse = null;
        CartRedisData rd = new CartRedisData();
        rd.setCartId("5bc71bde-269d-4cbd-af90-0a39dc69fe04");
        rd.setCaseId("SOA-11179174-E01");
        rd.setCartCreator("1234567890");
        Map<String, String> requestMap = new HashMap<>();
        String redisDataString = "{\"mtn\":\"1234567890\",\"channel\":\"Digital\"}";
        Map<String,Object> sampleRedisData = mapper.readValue(redisDataString, Map.class);
        String outPut = "{\"cradleFlowJourney\": \"test\",\n" +
                "\t\t\"throttleList\": \"|PPP_DF_NSE|\"}";
        CradleResponse cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(outPut);
        Map<String, String> map = new HashMap<>();
        map.put(CartConstants.THROTTLE_LIST, "abcsd");
        request.setHttpRequest(httpHeader);
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(rd));
        when(redisHelper3.getHomeSalesAddressFromRedis()).thenReturn(Mono.just(new HomeSalesAddress()));
        Mockito.when(bpmHelper2.createLine(Mockito.any())).thenReturn(Mono.just(response));
        Mockito.when(cradleAllocator.invokeReactiveCradle(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(cradleResponse));
        Mockito.when(cradleAllocator.getDataMap()).thenReturn(Mono.just(map));
        when(redisHelper3.getDataFromSession(Mockito.any())).thenReturn(Mono.just(new HashMap<>()));
        Mockito.when(featureFlag.isFeatureEnabled(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyBoolean())).thenReturn(Mono.just(true));
        StepVerifier.create(helper.createLine(request)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();

        httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-MFA-IOS").cookies(bodyMap).build();
        request.setHttpRequest(httpHeader);
        request.setChannelId("VZW-MFA-IOS");
        StepVerifier.create(helper.createLine(request)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();

        httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-MFA-IOS").build();
        request.setHttpRequest(httpHeader);
        StepVerifier.create(helper.createLine(request)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();

        HttpCookie uuidCookie = new HttpCookie("uuid", "abcd");
        bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("uuid", uuidCookie);
        httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-MFA-IOS").cookies(bodyMap).build();
        request.setHttpRequest(httpHeader);
        StepVerifier.create(helper.createLine(request)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();

        HttpCookie uuidCookie1 = new HttpCookie("uuid", null);
        MultiValueMap<String, HttpCookie> bodyMap2 = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap2.add("uuid", uuidCookie1);
        httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-MFA-IOS").cookies(bodyMap2).build();
        request.setHttpRequest(httpHeader);
        StepVerifier.create(helper.createLine(request)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();

        HttpCookie uuidCookie2 = new HttpCookie("uuid", " ");
        MultiValueMap<String, HttpCookie> bodyMap3 = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap3.add("uuid", uuidCookie2);
        httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-MFA-IOS").cookies(bodyMap3).build();
        request.setHttpRequest(httpHeader);
        StepVerifier.create(helper.createLine(request)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();

        MultiValueMap<String, HttpCookie> bodyMap1 = new LinkedMultiValueMap<String, HttpCookie>();
        httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-MFA-IOS").cookies(bodyMap1).build();
        request.setHttpRequest(httpHeader);
        StepVerifier.create(helper.createLine(request)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();

        request.setHttpRequest(null);
        StepVerifier.create(helper.createLine(request)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();

        request.getCartInfo().setIntendType("EUP");
        StepVerifier.create(helper.createLine(request)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();

        Mockito.when(featureFlag.isFeatureEnabled(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyBoolean())).thenReturn(Mono.just(false));
        StepVerifier.create(helper.createLine(request)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();

        request.getCartInfo().setIntendType("BYOD");
        StepVerifier.create(helper.createLine(request)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateSWBarCodeInRequestTest() throws  Exception{
        String sampleRequestString = sourceFileReaderUtil.readFile(
                "data/cartServiceHelperTest/UpdateBarcodeUIRequest3.json", testFileLocation);
        UpdateBarcodeUIRequest request = mapper.readValue(sampleRequestString, UpdateBarcodeUIRequest.class);
        Method method = UpdateCartHelper.class.getDeclaredMethod("updateSWBarCodeInRequest", UpdateBarcodeUIRequest.class);
        method.setAccessible(true);
        method.invoke(helper, request);
        Assert.assertNotNull(method);

        ReflectionTestUtils.setField(helper, "barcodeOffer", null);
        method.invoke(helper, request);
        Assert.assertNotNull(method);

        request.getCartInfo().setSWOfferAccepted(false);
        method.invoke(helper, request);
        Assert.assertNotNull(method);
    }

    @Test
    public void nullifyBarCodeForUIAtOrderDetailsTest() throws Exception{
        ReflectionTestUtils.setField(helper, "barcodeOffer", "BXGY2002024BC7");
        String sampleResponseString = sourceFileReaderUtil.readFile(
                "ValidateCartResponseForUi.json", testFileLocation);
        ValidateCartUIResponse response = mapper.readValue(sampleResponseString, ValidateCartUIResponse.class);
        Method method = UpdateCartHelper.class.getDeclaredMethod("nullifyBarCodeForUIAtOrderDetails", CXPCartVO.class);
        method.setAccessible(true);
        CXPCartVO cxpCartVO = response.getData().getValidateCartAndUpdate();
        method.invoke(helper, cxpCartVO);
        Assert.assertNotNull(method);

        String[] barCodes = {"SMART200","BXGY2002024BC7"};
        cxpCartVO.getOrderDetails().setBarCodes(barCodes);
        method.invoke(helper, cxpCartVO);
        Assert.assertNotNull(method);

        String[] barCodes1 = {"SMART200"};
        cxpCartVO.getOrderDetails().setBarCodes(barCodes1);
        method.invoke(helper, cxpCartVO);
        Assert.assertNotNull(method);

        String[] barCodes2 = {};
        cxpCartVO.getOrderDetails().setBarCodes(barCodes2);
        method.invoke(helper, cxpCartVO);
        Assert.assertNotNull(method);

        cxpCartVO.getOrderDetails().setBarCodes(null);
        method.invoke(helper, cxpCartVO);
        Assert.assertNotNull(method);

        cxpCartVO.setOrderDetails(null);
        method.invoke(helper, cxpCartVO);
        Assert.assertNotNull(method);

        ReflectionTestUtils.setField(helper, "barcodeOffer", null);
        method.invoke(helper, cxpCartVO);
        Assert.assertNotNull(method);
    }

    @Test
    public void nullifyBarCodeForUIAtLineLevelTest() throws  Exception{
        ReflectionTestUtils.setField(helper, "barcodeOffer", "BXGY2002024BC7");
        String sampleResponseString = sourceFileReaderUtil.readFile(
                "ValidateCartResponseForUi.json", testFileLocation);
        ValidateCartUIResponse response = mapper.readValue(sampleResponseString, ValidateCartUIResponse.class);
        Method method = UpdateCartHelper.class.getDeclaredMethod("nullifyBarCodeForUIAtLineLevel", List.class);
        method.setAccessible(true);
        CXPCartVO cxpCartVO = response.getData().getValidateCartAndUpdate();
        method.invoke(helper,  Arrays.asList(Arrays.asList(cxpCartVO.getLineDetails().getLineInfo()).get(0).getItemsInfo()));
        Assert.assertNotNull(method);

        ReflectionTestUtils.setField(helper, "barcodeOffer", "XXXXXXX");
        method.invoke(helper, Arrays.asList(Arrays.asList(cxpCartVO.getLineDetails().getLineInfo()).get(0).getItemsInfo()));
        Assert.assertNotNull(method);

        ReflectionTestUtils.setField(helper, "barcodeOffer", null);
        method.invoke(helper, Arrays.asList(Arrays.asList(cxpCartVO.getLineDetails().getLineInfo()).get(0).getItemsInfo()));
        Assert.assertNotNull(method);
    }

    public void nullifyBarCodeForUIAtLineLevelTest2() throws  Exception{
        ReflectionTestUtils.setField(helper, "barcodeOffer", "BXGY2002024BC7");
        String sampleResponseString = sourceFileReaderUtil.readFile(
                "ValidateCartResponseForUi.json", testFileLocation);
        ValidateCartUIResponse response = mapper.readValue(sampleResponseString, ValidateCartUIResponse.class);
        Method method = UpdateCartHelper.class.getDeclaredMethod("nullifyBarCodeForUIAtLineLevel", List.class);
        method.setAccessible(true);
        CXPCartVO cxpCartVO = response.getData().getValidateCartAndUpdate();
        Arrays.asList(Arrays.asList(cxpCartVO.getLineDetails()
                .getLineInfo()).get(0).getItemsInfo()).stream().forEach(lineInfo -> {
            Arrays.asList(lineInfo.getCartItems().getCartItem()).stream().forEach(cartItem -> {
                    cartItem.getSedOfferList().getSedOffer().stream().forEach(sedOffer -> {
                        sedOffer.setBarcodeID(null);
                    });
            });
        });
        method.invoke(helper, Arrays.asList(cxpCartVO.getLineDetails().getLineInfo()));
        Assert.assertNotNull(method);

        Arrays.asList(Arrays.asList(cxpCartVO.getLineDetails()
                .getLineInfo()).get(0).getItemsInfo()).stream().forEach(lineInfo -> {
            Arrays.asList(lineInfo.getCartItems().getCartItem()).stream().forEach(cartItem -> {
                Arrays.asList(cartItem.getSedOfferList().getSedOffer()).clear();
            });
        });
        method.invoke(helper, Arrays.asList(cxpCartVO.getLineDetails().getLineInfo()));
        Assert.assertNotNull(method);

        Arrays.asList(Arrays.asList(cxpCartVO.getLineDetails()
                .getLineInfo()).get(0).getItemsInfo()).stream().forEach(lineInfo -> {
            Arrays.asList(lineInfo.getCartItems().getCartItem()).stream().forEach(cartItem -> {
                cartItem.getSedOfferList().setSedOffer(null);
            });
        });
        method.invoke(helper, Arrays.asList(cxpCartVO.getLineDetails().getLineInfo()));
        Assert.assertNotNull(method);

        Arrays.asList(Arrays.asList(cxpCartVO.getLineDetails()
                .getLineInfo()).get(0).getItemsInfo()).stream().forEach(lineInfo -> {
            Arrays.asList(lineInfo.getCartItems().getCartItem()).stream().forEach(cartItem -> {
                cartItem.setSedOfferList(null);
            });
        });
        method.invoke(helper, Arrays.asList(cxpCartVO.getLineDetails().getLineInfo()));
        Assert.assertNotNull(method);

        Arrays.asList(Arrays.asList(cxpCartVO.getLineDetails()
                .getLineInfo()).get(0).getItemsInfo()).stream().forEach(lineInfo -> {
            Arrays.asList(lineInfo.getCartItems().getCartItem()).removeIf(
                    cartItem -> CartConstants.DEVICE.equalsIgnoreCase(cartItem.getCartItemType()));
        });
        method.invoke(helper, Arrays.asList(cxpCartVO.getLineDetails().getLineInfo()));
        Assert.assertNotNull(method);

        Arrays.asList(Arrays.asList(cxpCartVO.getLineDetails()
                .getLineInfo()).get(0).getItemsInfo()).stream().forEach(lineInfo -> {
            Arrays.asList(lineInfo.getCartItems().getCartItem()).clear();
        });
        method.invoke(helper, Arrays.asList(cxpCartVO.getLineDetails().getLineInfo()));
        Assert.assertNotNull(method);

        Arrays.asList(Arrays.asList(cxpCartVO.getLineDetails()
                .getLineInfo()).get(0).getItemsInfo()).stream().forEach(lineInfo -> {
            lineInfo.getCartItems().setCartItem(null);
        });
        method.invoke(helper, Arrays.asList(cxpCartVO.getLineDetails().getLineInfo()));
        Assert.assertNotNull(method);
    }
    @Test
    public void setExistingCradleFlowJourneyForCreateLineTest() throws  Exception{
        String requestFile = "data/CartUpdateOperationsControllerTestJson/createLine1Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/createLine1Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        request.getCartInfo().setIntendType("NSEBYOD");
        request.setChannelId("VZW-MFA-ANDRIOD");
        HttpCookie uuidCookie = new HttpCookie("uuid", "abcd");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("uuid", uuidCookie);
        URI url = URI.create("http://localhost/nse/new-line");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-MFA-IOS").cookies(bodyMap).build();
        request.setHttpRequest(httpHeader);
        CreateLineUIResponse response = mapper.readValue(responseString, CreateLineUIResponse.class);
        ServerHttpResponse httpResponse = null;
        CartRedisData rd = new CartRedisData();
        rd.setCartId("5bc71bde-269d-4cbd-af90-0a39dc69fe04");
        rd.setCaseId("SOP-508208-E01");
        rd.setCartCreator("1234567890");
        String redisDataString = "{\"mtn\":\"1234567890\",\"channel\":\"Digital\"}";
        Map<String,Object> sampleRedisData = mapper.readValue(redisDataString, Map.class);
        String outPut = "{\"cradleFlowJourney\": \"\",\n" +
                "\t\t\"throttleList\": \"|PPP_DF_NSE|\"}";
        CradleResponse cradleResponse = new CradleResponse();
        cradleResponse.setOutPut(outPut);
        Map<String, String> map = new HashMap<>();
        map.put(CartConstants.THROTTLE_LIST, "abcsd");
        request.setHttpRequest(httpHeader);
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(rd));
        Mockito.when(bpmHelper2.createLine(Mockito.any())).thenReturn(Mono.just(response));
        Mockito.when(cradleAllocator.invokeReactiveCradle(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(cradleResponse));
        Mockito.when(cradleAllocator.getDataMap()).thenReturn(Mono.just(map));
        Mockito.when(featureFlag.isFeatureEnabled(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyBoolean())).thenReturn(Mono.just(false));
        StepVerifier.create(helper.createLine(request)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateSWBarCodeInRequestFromNBXTest() throws NoSuchMethodException, JsonProcessingException, InvocationTargetException, IllegalAccessException {
        String sampleRequestString = sourceFileReaderUtil.readFile(
                "data/cartServiceHelperTest/UpdateBarcodeUIRequest3.json", testFileLocation);
        UpdateBarcodeUIRequest request = mapper.readValue(sampleRequestString, UpdateBarcodeUIRequest.class);
        Method method = UpdateCartHelper.class.getDeclaredMethod("updateSWBarCodeInRequestFromNBX",
                UpdateBarcodeUIRequest.class,CartRedisData.class);
        CartRedisData cartRedisData = new CartRedisData();
        cartRedisData.setSwBarCodeId("66666");
        method.setAccessible(true);
        method.invoke(helper, request,cartRedisData);
        Assert.assertNotNull(method);

        request.getCartInfo().setDynSWOfferAccepted(true);
        method.invoke(helper, request,cartRedisData);
        Assert.assertNotNull(method);

        request.getCartInfo().setDynSWOfferAccepted(false);
        request.setData(new UpdateBarCodeData());
        method.invoke(helper, request,cartRedisData);
        Assert.assertNotNull(method);

        request.getData().setNbxOfferId("");
        cartRedisData.setFwaPDMOffers(null);
        method.invoke(helper, request,cartRedisData);
        Assert.assertNotNull(method);

        request.getData().setNbxOfferId("NBxTestId");
        cartRedisData.setFwaPDMOffers(null);
        method.invoke(helper, request,cartRedisData);
        Assert.assertNotNull(method);

        cartRedisData.setFwaPDMOffers(new ArrayList<>());
        method.invoke(helper, request,cartRedisData);
        Assert.assertNotNull(method);

        cartRedisData.setFwaPDMOffers(new ArrayList<>());
        cartRedisData.getFwaPDMOffers().add(new PDMOfferData());
        method.invoke(helper, request,cartRedisData);
        Assert.assertNotNull(method);

        cartRedisData.setFwaPDMOffers(new ArrayList<>());
        PDMOfferData pdmOfferData = new PDMOfferData();
        pdmOfferData.setOfferId("NBxTestId");
        cartRedisData.getFwaPDMOffers().add(pdmOfferData);
        method.invoke(helper, request,cartRedisData);
        Assert.assertNotNull(method);

        cartRedisData.setFwaPDMOffers(new ArrayList<>());
        PDMOfferData pdmOfferData1 = new PDMOfferData();
        pdmOfferData.setOfferId("NBxTestIdTest");
        cartRedisData.getFwaPDMOffers().add(pdmOfferData1);
        method.invoke(helper, request,cartRedisData);
        Assert.assertNotNull(method);
    }
    @Test
    public void nullifyBarCodeForIsDynOfferRebateTest() throws Exception{
        Method method = UpdateCartHelper.class.getDeclaredMethod("nullifyBarCodeForIsDynOfferRebate", CXPCartVO.class);
        ReflectionUtils.makeAccessible(method);
        String sampleResponseString = sourceFileReaderUtil.readFile(
                "ValidateCartResponseForUiRebate.json", testFileLocation);
        ValidateCartUIResponse response = mapper.readValue(sampleResponseString, ValidateCartUIResponse.class);

        CXPCartVO cxpCartVO = new CXPCartVO();
        method.invoke(helper, cxpCartVO);
        assertNotNull(method);

        method.invoke(helper, response.getData().getValidateCartAndUpdate());
        assertNotNull(method);

        Arrays.asList(response.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()).stream().filter(Objects::nonNull).forEach(lineInfo -> {
            Arrays.asList(lineInfo.getItemsInfo()).stream().filter(Objects::nonNull).forEach(itemsInfo -> {
                Optional<CXPCartItem> cartItemDeviceOpt = Arrays.asList(itemsInfo.getCartItems().getCartItem()).stream()
                        .filter(cartItem -> CartConstants.DEVICE.equalsIgnoreCase(cartItem.getCartItemType())).findFirst();
                if(cartItemDeviceOpt.get().getRebateOffers() != null) {
                    cartItemDeviceOpt.get().getRebateOffers().get(0).setBarcodeId("fffff");
                }
            });
        });

        String[] barcode = new String[] { "112312","434324","534545"};
        response.getData().getValidateCartAndUpdate().getOrderDetails().setBarCodes(barcode);
        method.invoke(helper, response.getData().getValidateCartAndUpdate());
        assertNotNull(method);

        Arrays.asList(response.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()).stream().filter(Objects::nonNull).forEach(lineInfo -> {
            Arrays.asList(lineInfo.getItemsInfo()).stream().filter(Objects::nonNull).forEach(itemsInfo -> {
                Optional<CXPCartItem> cartItemDeviceOpt = Arrays.asList(itemsInfo.getCartItems().getCartItem()).stream()
                        .filter(cartItem -> CartConstants.DEVICE.equalsIgnoreCase(cartItem.getCartItemType())).findFirst();
                if(cartItemDeviceOpt.get().getRebateOffers() != null) {
                    cartItemDeviceOpt.get().getRebateOffers().get(0).setPlatformPromoType("");
                }
            });
        });

        method.invoke(helper, response.getData().getValidateCartAndUpdate());
        assertNotNull(method);

        Arrays.asList(response.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()).stream().filter(Objects::nonNull).forEach(lineInfo -> {
            Arrays.asList(lineInfo.getItemsInfo()).stream().filter(Objects::nonNull).forEach(itemsInfo -> {
                Optional<CXPCartItem> cartItemDeviceOpt = Arrays.asList(itemsInfo.getCartItems().getCartItem()).stream()
                        .filter(cartItem -> CartConstants.DEVICE.equalsIgnoreCase(cartItem.getCartItemType())).findFirst();
                if(cartItemDeviceOpt.get().getRebateOffers() != null) {
                    cartItemDeviceOpt.get().getRebateOffers().get(0).setPlatformPromoType(null);
                }
            });
        });

        method.invoke(helper, response.getData().getValidateCartAndUpdate());
        assertNotNull(method);

        Arrays.asList(response.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()).stream().filter(Objects::nonNull).forEach(lineInfo -> {
            Arrays.asList(lineInfo.getItemsInfo()).stream().filter(Objects::nonNull).forEach(itemsInfo -> {
                Optional<CXPCartItem> cartItemDeviceOpt = Arrays.asList(itemsInfo.getCartItems().getCartItem()).stream()
                        .filter(cartItem -> CartConstants.DEVICE.equalsIgnoreCase(cartItem.getCartItemType())).findFirst();
                if(cartItemDeviceOpt.get().getRebateOffers() != null) {
                    cartItemDeviceOpt.get().getRebateOffers().get(0).setPlatformPromoType("xyz");
                }
            });
        });

        method.invoke(helper, response.getData().getValidateCartAndUpdate());
        assertNotNull(method);

        Arrays.asList(response.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()).stream().filter(Objects::nonNull).forEach(lineInfo -> {
            Arrays.asList(lineInfo.getItemsInfo()).stream().filter(Objects::nonNull).forEach(itemsInfo -> {
                Optional<CXPCartItem> cartItemDeviceOpt = Arrays.asList(itemsInfo.getCartItems().getCartItem()).stream()
                        .filter(cartItem -> CartConstants.DEVICE.equalsIgnoreCase(cartItem.getCartItemType())).findFirst();
                if(cartItemDeviceOpt.get().getRebateOffers() != null) {
                    cartItemDeviceOpt.get().getRebateOffers().get(0).setBarcodeId("");
                }
            });
        });

        method.invoke(helper, response.getData().getValidateCartAndUpdate());
        assertNotNull(method);

        Arrays.asList(response.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()).stream().filter(Objects::nonNull).forEach(lineInfo -> {
            Arrays.asList(lineInfo.getItemsInfo()).stream().filter(Objects::nonNull).forEach(itemsInfo -> {
                Optional<CXPCartItem> cartItemDeviceOpt = Arrays.asList(itemsInfo.getCartItems().getCartItem()).stream()
                        .filter(cartItem -> CartConstants.DEVICE.equalsIgnoreCase(cartItem.getCartItemType())).findFirst();
                if(cartItemDeviceOpt.get().getRebateOffers() != null) {
                    cartItemDeviceOpt.get().getRebateOffers().get(0).setBarcodeId(null);
                }
            });
        });

        method.invoke(helper, response.getData().getValidateCartAndUpdate());
        assertNotNull(method);

        Arrays.asList(response.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()).stream().filter(Objects::nonNull).forEach(lineInfo -> {
            Arrays.asList(lineInfo.getItemsInfo()).stream().filter(Objects::nonNull).forEach(itemsInfo -> {
                Optional<CXPCartItem> cartItemDeviceOpt = Arrays.asList(itemsInfo.getCartItems().getCartItem()).stream()
                        .filter(cartItem -> CartConstants.DEVICE.equalsIgnoreCase(cartItem.getCartItemType())).findFirst();
                if(cartItemDeviceOpt.get().getRebateOffers() != null) {
                    cartItemDeviceOpt.get().getRebateOffers().clear();
                }
            });
        });

        method.invoke(helper, response.getData().getValidateCartAndUpdate());
        assertNotNull(method);

        Arrays.asList(response.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()).stream().filter(Objects::nonNull).forEach(lineInfo -> {
            Arrays.asList(lineInfo.getItemsInfo()).stream().filter(Objects::nonNull).forEach(itemsInfo -> {
                Optional<CXPCartItem> cartItemDeviceOpt = Arrays.asList(itemsInfo.getCartItems().getCartItem()).stream()
                        .filter(cartItem -> CartConstants.DEVICE.equalsIgnoreCase(cartItem.getCartItemType())).findFirst();
                cartItemDeviceOpt.get().setRebateOffers(null);
            });
        });

        method.invoke(helper, response.getData().getValidateCartAndUpdate());
        assertNotNull(method);


        Arrays.asList(response.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()).stream().filter(Objects::nonNull).forEach(lineInfo -> {
            Arrays.asList(lineInfo.getItemsInfo()).stream().filter(Objects::nonNull).forEach(itemsInfo -> {
                Arrays.asList(itemsInfo.getCartItems().getCartItem()).stream().forEach(item -> {
                    if(CartConstants.DEVICE.equalsIgnoreCase(item.getCartItemType())){
                        item.setCartItemType("ACCESSORY");
                    }
                });
            });
        });

        method.invoke(helper, response.getData().getValidateCartAndUpdate());
        assertNotNull(method);

        Arrays.asList(response.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()).stream().filter(Objects::nonNull).forEach(lineInfo -> {
            Arrays.asList(lineInfo.getItemsInfo()).stream().filter(Objects::nonNull).forEach(itemsInfo -> {
                itemsInfo.getCartItems().setCartItem(null);
            });
        });

        method.invoke(helper, response.getData().getValidateCartAndUpdate());
        assertNotNull(method);

        Arrays.asList(response.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()).stream().filter(Objects::nonNull).forEach(lineInfo -> {
            Arrays.asList(lineInfo.getItemsInfo()).stream().filter(Objects::nonNull).forEach(itemsInfo -> {
                itemsInfo.setCartItems(null);
            });
        });

        method.invoke(helper, response.getData().getValidateCartAndUpdate());
        assertNotNull(method);

        response.getData().getValidateCartAndUpdate().setLineDetails(null);
        method.invoke(helper, response.getData().getValidateCartAndUpdate());
        assertNotNull(method);

        ReflectionTestUtils.setField(helper, "dynSWPlatformPromoType", null);
        method.invoke(helper, response.getData().getValidateCartAndUpdate());
        assertNotNull(method);

        ReflectionTestUtils.setField(helper, "dynSWPlatformPromoType", "");
        method.invoke(helper, response.getData().getValidateCartAndUpdate());
        assertNotNull(method);
    }

    @Test
    public void isNotNFLTest() throws Exception {
        Method method = UpdateCartHelper.class.getDeclaredMethod("isNotNFL", PromoHubOffer.class);
        ReflectionUtils.makeAccessible(method);
        PromoHubOffer promoHubOffer = new PromoHubOffer();

        method.invoke(helper, promoHubOffer);
        assertNotNull(method);

        List<PromoBadgeMessages> promoBadgeMessagesList = new ArrayList<>();
        promoHubOffer.setPromoBadges(promoBadgeMessagesList);

        method.invoke(helper, promoHubOffer);
        assertNotNull(method);

        promoHubOffer.getPromoBadges().clear();
        PromoBadgeMessages promoBadgeMessages = new PromoBadgeMessages();
        promoBadgeMessagesList.add(promoBadgeMessages);
        promoHubOffer.setPromoBadges(promoBadgeMessagesList);

        method.invoke(helper, promoHubOffer);
        assertNotNull(method);

        promoHubOffer.getPromoBadges().clear();
        PromoBadgeMessages promoBadgeMessages1 = new PromoBadgeMessages();
        promoBadgeMessages1.setBadgeText("");
        promoBadgeMessagesList.add(promoBadgeMessages1);
        promoHubOffer.setPromoBadges(promoBadgeMessagesList);

        method.invoke(helper, promoHubOffer);
        assertNotNull(method);

        promoHubOffer.getPromoBadges().clear();
        PromoBadgeMessages promoBadgeMessages2 = new PromoBadgeMessages();
        promoBadgeMessages2.setBadgeText("TV offer");
        promoBadgeMessagesList.add(promoBadgeMessages2);
        promoHubOffer.setPromoBadges(promoBadgeMessagesList);

        method.invoke(helper, promoHubOffer);
        assertNotNull(method);

        promoHubOffer.getPromoBadges().clear();
        PromoBadgeMessages promoBadgeMessages3 = new PromoBadgeMessages();
        promoBadgeMessages3.setBadgeText("NFL");
        promoBadgeMessagesList.add(promoBadgeMessages3);
        promoHubOffer.setPromoBadges(promoBadgeMessagesList);

        method.invoke(helper, promoHubOffer);
        assertNotNull(method);

    }

    @Test
    public void filterExistingLinesTest() throws Exception {

        RetrieveCartCXPRequest request = null;
        helper.filterExistingCustomerLineDetails(null,request);
        assertNull(request);

        request = new RetrieveCartCXPRequest();
        CXPRetrieveCartDataVO data = new CXPRetrieveCartDataVO();
        request.setData(data);
        data.setRepRole(null);
        helper.filterExistingCustomerLineDetails(null,request);
        assertNull(request.getData().getRepRole());

        data.setRepRole("POSIT");
        helper.filterExistingCustomerLineDetails(null,request);
        assertNotNull(request.getData().getRepRole());

        data.setRepRole("D2D5GFMEM");
        RetrieveCartUIResponse response = null;
        helper.filterExistingCustomerLineDetails(response,request);
        assertNotNull(request.getData().getRepRole());

        response = new RetrieveCartUIResponse();
        CXPRetrieveCartDataVO respData = null;
        response.setData(null);
        respData = new CXPRetrieveCartDataVO();
        helper.filterExistingCustomerLineDetails(response,request);
        assertNotNull(respData);

        respData = new CXPRetrieveCartDataVO();
        response.setData(respData);
        CXPCartVO cart = new CXPCartVO();
        respData.setCart(null);
        helper.filterExistingCustomerLineDetails(response,request);
        assertNull(respData.getCart());

        respData.setCart(cart);
        request.getData().setNewCustomer(true);
        helper.filterExistingCustomerLineDetails(response,request);
        assertNotNull(respData.getCart());

        request.getData().setNewCustomer(false);
        helper.filterExistingCustomerLineDetails(response,request);
        assertNotNull(respData.getCart());


        cart.setLineDetails(null);
        helper.filterExistingCustomerLineDetails(response,request);
        assertNull(respData.getCart().getLineDetails());

        CXPLineDetailsVO lineDetails = new CXPLineDetailsVO();
        cart.setLineDetails(lineDetails);
        respData.setCart(cart);
        CXPLineInfo[] lineInfo =null;
        lineDetails.setLineInfo(null);
        helper.filterExistingCustomerLineDetails(response,request);
        assertNotNull(respData.getCart().getLineDetails());


        CXPLineInfo lineInfo1 = null;
        CXPLineInfo lineInfo2 = new CXPLineInfo();
        lineInfo2.setLineActivityType("AAL");

        CXPLineInfo lineInfo3 = new CXPLineInfo();
        lineInfo3.setLineActivityType("");

        CXPLineInfo lineInfo4 = new CXPLineInfo();
        lineInfo = new CXPLineInfo[4];
        lineInfo4.setLineActivityType("EUP");
        lineInfo[0] = lineInfo1;
        lineInfo[1] = lineInfo2;
        lineInfo[2] = lineInfo3;
        lineInfo[3] = lineInfo4;
        lineDetails.setLineInfo(lineInfo);
        helper.filterExistingCustomerLineDetails(response,request);
        assertNotNull(respData.getCart().getLineDetails());

        lineInfo = new CXPLineInfo[]{};
        helper.filterExistingCustomerLineDetails(response,request);
        assertNotNull(respData.getCart().getLineDetails());

        request.getData().setRepRole(CartConstants.NR_ROLE_ID);
        helper.filterExistingCustomerLineDetails(response,request);
        assertNotNull(respData.getCart().getLineDetails());

        CXPCartVO cxpCartVO = new CXPCartVO();
        CXPOrderDetails cxpOrderDetails = new CXPOrderDetails();
        cxpCartVO.setOrderDetails(cxpOrderDetails);
        request.getData().setCart(cxpCartVO);
        cxpOrderDetails.setMasterAgentId(CartConstants.MASTER_AGENT_ID);
        helper.filterExistingCustomerLineDetails(response,request);

        cxpOrderDetails.setMasterAgentId("");
        helper.filterExistingCustomerLineDetails(response,request);
        assertNotNull(respData.getCart().getLineDetails());


    }

    @Test
    public void setLGPORedisDataInRequest_Test1() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"processingMTN\":\"newLine1\",\"processStep\":\"NewRecommendedPlanSelection\",\"intendType\":\"NSEBYOD\",\"editPlanClick\":false,\"addressLine1\":\"\",\"city\":\"\",\"state\":\"\",\"zipCode\":\"\",\"customerType\":\"N\",\"mtnFlow\":\"D\",\"processAction\":\"addPlan\"},\"data\":{\"lines\":[{\"path\":\"custom\",\"action\":\"customized\",\"mtn\":\"newLine1\",\"plan\":{\"id\":\"63215\"},\"addFeatures\":[{\"id\":\"2885\",\"type\":\"SPO\",\"quantity\":1,\"actionIndicator\":\"A\"}],\"removeFeatures\":[]}],\"enableFcc\":true,\"parentMtn\":\"\"},\"optPlanSku\":true,\"isByou\":true}";
        AddPlanUIRequest addPlanUIRequest = mapper.readValue(requestString, AddPlanUIRequest.class);
        CartRedisData redisData = new CartRedisData();
        //ns1
        redisData.setIsLgpoEligibleCustomer(true);
        redisData.setLgpoSpo(null);
        helper.setLGPORedisDataInRequest(redisData,addPlanUIRequest);
        //ns2
        redisData.setIsLgpoEligibleCustomer(false);
        redisData.setLgpoSpo("2885");
        helper.setLGPORedisDataInRequest(redisData,addPlanUIRequest);
        //ns3
        redisData.setIsLgpoEligibleCustomer(null);
        redisData.setLgpoSpo("2885");
        helper.setLGPORedisDataInRequest(redisData,addPlanUIRequest);
        //ns4
        helper.setLGPORedisDataInRequest(null, addPlanUIRequest);
        //ns5
        requestString = "{\"cartInfo\":{\"processingMTN\":\"newLine1\",\"processStep\":\"NewRecommendedPlanSelection\",\"editPlanClick\":false,\"addressLine1\":\"\",\"city\":\"\",\"state\":\"\",\"zipCode\":\"\",\"customerType\":\"N\",\"mtnFlow\":\"D\",\"processAction\":\"addPlan\"},\"data\":{\"lines\":[{\"path\":\"custom\",\"action\":\"customized\",\"mtn\":\"newLine1\",\"plan\":{\"id\":\"63215\"},\"addFeatures\":[{\"id\":\"2885\",\"type\":\"SPO\",\"quantity\":1,\"actionIndicator\":\"A\"}],\"removeFeatures\":[]}],\"enableFcc\":true,\"parentMtn\":\"\"},\"optPlanSku\":true,\"isByou\":true}";
        addPlanUIRequest = mapper.readValue(requestString, AddPlanUIRequest.class);
        redisData.setIsLgpoEligibleCustomer(true);
        redisData.setLgpoSpo("2885");
        addPlanUIRequest.getCartInfo().setIntendType(null);
        helper.setLGPORedisDataInRequest(redisData,addPlanUIRequest);
        //ns6
        requestString = "{\"cartInfo\":{\"processingMTN\":\"newLine1\",\"processStep\":\"NewRecommendedPlanSelection\",\"editPlanClick\":false,\"addressLine1\":\"\",\"city\":\"\",\"state\":\"\",\"zipCode\":\"\",\"customerType\":\"N\",\"mtnFlow\":\"D\",\"processAction\":\"addPlan\"},\"data\":{\"lines\":[{\"path\":\"custom\",\"action\":\"customized\",\"mtn\":\"newLine1\",\"plan\":{\"id\":\"63215\"},\"addFeatures\":[{\"id\":\"2885\",\"type\":\"SPO\",\"quantity\":1,\"actionIndicator\":\"A\"}],\"removeFeatures\":[]}],\"enableFcc\":true,\"parentMtn\":\"\"},\"optPlanSku\":true,\"isByou\":true}";
        addPlanUIRequest = mapper.readValue(requestString, AddPlanUIRequest.class);
        redisData.setIsLgpoEligibleCustomer(true);
        redisData.setLgpoSpo("2885");
        addPlanUIRequest.setCartInfo(null);
        helper.setLGPORedisDataInRequest(redisData,addPlanUIRequest);
        //ns8
        helper.setLGPORedisDataInRequest(redisData,null);

        //NSE flow
        String requestString1 = "{\"cartInfo\":{\"processingMTN\":\"newLine1\",\"processStep\":\"NewRecommendedPlanSelection\",\"intendType\":\"NSE\",\"editPlanClick\":false,\"addressLine1\":\"\",\"city\":\"\",\"state\":\"\",\"zipCode\":\"\",\"customerType\":\"N\",\"mtnFlow\":\"D\",\"processAction\":\"addPlan\"},\"data\":{\"lines\":[{\"path\":\"custom\",\"action\":\"customized\",\"mtn\":\"newLine1\",\"plan\":{\"id\":\"63215\"},\"addFeatures\":[{\"id\":\"2885\",\"type\":\"SPO\",\"quantity\":1,\"actionIndicator\":\"A\"}],\"removeFeatures\":[]}],\"enableFcc\":true,\"parentMtn\":\"\"},\"optPlanSku\":true,\"isByou\":true}";
        AddPlanUIRequest addDeviceReq1 = mapper.readValue(requestString1, AddPlanUIRequest.class);
        CartRedisData redisData1 = new CartRedisData();
        redisData1.setIsLgpoEligibleCustomer(true);
        redisData1.setLgpoSpo("2885");
        helper.setLGPORedisDataInRequest(redisData1, addDeviceReq1);

        //NSE BYOD
        String requestString2 = "{\"cartInfo\":{\"processingMTN\":\"newLine1\",\"processStep\":\"NewRecommendedPlanSelection\",\"intendType\":\"NSEBYOD\",\"editPlanClick\":false,\"addressLine1\":\"\",\"city\":\"\",\"state\":\"\",\"zipCode\":\"\",\"customerType\":\"N\",\"mtnFlow\":\"D\",\"processAction\":\"addPlan\"},\"data\":{\"lines\":[{\"path\":\"custom\",\"action\":\"customized\",\"mtn\":\"newLine1\",\"plan\":{\"id\":\"63215\"},\"addFeatures\":[{\"id\":\"2885\",\"type\":\"SPO\",\"quantity\":1,\"actionIndicator\":\"A\"}],\"removeFeatures\":[]}],\"enableFcc\":true,\"parentMtn\":\"\"},\"optPlanSku\":true,\"isByou\":true}";
        AddPlanUIRequest addDeviceReq2 = mapper.readValue(requestString2, AddPlanUIRequest.class);
        CartRedisData redisData2 = new CartRedisData();
        redisData2.setIsLgpoEligibleCustomer(true);
        redisData2.setLgpoSpo("2885");
        helper.setLGPORedisDataInRequest(redisData2, addDeviceReq2);
    }

    @Test
    public void prevalidateUserRequestFirstName() throws IOException, SOEHTTPException {

        UpdateUserInfoUIRequest request=new UpdateUserInfoUIRequest();
        UpdateUserInfoLine line=new UpdateUserInfoLine();
        List<UpdateUserInfoLine> lines=new ArrayList<>();

        line.setMtn("7657308884");
        line.setFirstName("<a href=www.youtube.com>");
        line.setEmail("ovvigvczh@vzw.com");
        lines.add(line);
        request.setLines(lines);
        request.setIntendType("EUP");

        ErrorResponse res = helper.prevalidateUserRequest(request);

        assertNotNull(res.getErrors());
    }

    @Test
    public void prevalidateUserRequestEmail() throws IOException, SOEHTTPException {

        UpdateUserInfoUIRequest request=new UpdateUserInfoUIRequest();
        UpdateUserInfoLine line=new UpdateUserInfoLine();
        List<UpdateUserInfoLine> lines=new ArrayList<>();

        line.setMtn("7657308884");
        line.setFirstName("Tester");
        line.setEmail("ovvigvczh.com");
        lines.add(line);
        request.setLines(lines);
        request.setIntendType("EUP");

        ErrorResponse res = helper.prevalidateUserRequest(request);

        assertNotNull(res.getErrors());
    }

    @Test
    public void prevalidateUserRequestTest() throws Exception {

        UpdateUserInfoUIRequest request=new UpdateUserInfoUIRequest();
        UpdateUserInfoLine line=new UpdateUserInfoLine();
        List<UpdateUserInfoLine> lines=new ArrayList<>();

        line.setMtn("7657308884");
        line.setFirstName("Tester");
        line.setEmail("ovvigvczh@vzw.com");
        lines.add(line);
        request.setLines(lines);
        request.setIntendType("EUP");

        ErrorResponse res = helper.prevalidateUserRequest(request);

        assertNull(res.getErrors());
    }

    @Test
    public void prevalidateUserRequestNullName() throws Exception {

        UpdateUserInfoUIRequest request=new UpdateUserInfoUIRequest();
        UpdateUserInfoLine line=new UpdateUserInfoLine();
        List<UpdateUserInfoLine> lines=new ArrayList<>();

        line.setMtn("7657308884");
        line.setFirstName("");
        line.setEmail("ovvigvczh@vzw.com");
        lines.add(line);
        request.setLines(lines);
        request.setIntendType("EUP");

        ErrorResponse res = helper.prevalidateUserRequest(request);

        assertNotNull(res);
    }

    @Test
    public void prevalidateUserRequestNullEmail() throws Exception {

        UpdateUserInfoUIRequest request=new UpdateUserInfoUIRequest();
        UpdateUserInfoLine line=new UpdateUserInfoLine();
        List<UpdateUserInfoLine> lines=new ArrayList<>();

        line.setMtn("7657308884");
        line.setFirstName("Tester");
        line.setEmail("");
        lines.add(line);
        request.setLines(lines);
        request.setIntendType("EUP");

        ErrorResponse res = helper.prevalidateUserRequest(request);

        assertNotNull(res);
    }

    @Test
    public void prevalidateUserRequestNullLines() throws Exception {

        UpdateUserInfoUIRequest request=new UpdateUserInfoUIRequest();

        List<UpdateUserInfoLine> lines=null;
        request.setLines(lines);
        request.setIntendType("EUP");

        ErrorResponse res = helper.prevalidateUserRequest(request);

        assertNotNull(res);
    }

    @Test
    public void prevalidateUserRequestNullRequest() throws Exception {
        UpdateUserInfoUIRequest request=null;
        ErrorResponse res = helper.prevalidateUserRequest(request);
        assertNotNull(res);
    }

    @Test(expected = Exception.class)
    public void prevalidateUserRequestNullLines1() {
        UpdateUserInfoUIRequest request= null;
        Mockito.when(helper.prevalidateUserRequest(request)).thenThrow(new Exception("Illegal argument"));
    }

    @Test
    public void updateTaggingPlanDetailsTest() throws Exception {

        RetrieveCartCXPRequest request = null;
        helper.updateTaggingPlanDetails(null,request);
        assertNull(request);
        //CXPRetrieveCartDataVO data = new CXPRetrieveCartDataVO();
        request = new RetrieveCartCXPRequest();
        request.setData(null);
        helper.updateTaggingPlanDetails(null,request);
        request.setData(new CXPRetrieveCartDataVO());
        request.getData().setPlanTaggingDetails(null);
        helper.updateTaggingPlanDetails(null,request);
        List<PlanTaggingDetails> plDetails = new ArrayList<>();
        request.getData().setPlanTaggingDetails(plDetails);
        helper.updateTaggingPlanDetails(null,request);
        PlanTaggingDetails data = new PlanTaggingDetails();
        data.setMtn("newLine1");
        plDetails.add(data);
        helper.updateTaggingPlanDetails(null,request);

        RetrieveCartUIResponse response = new RetrieveCartUIResponse();
        CXPRetrieveCartDataVO respData = null;
        response.setData(null);
        respData = new CXPRetrieveCartDataVO();
        helper.updateTaggingPlanDetails(response,request);
        assertNotNull(respData);

        PlanTaggingDetails detail = new PlanTaggingDetails();
        detail.setGroup(1);
        detail.setPath("recommended");
        detail.setAction("preset");
        detail.setMtn("1234567890");
        PlansPerks planData = new PlansPerks();
        planData.setId("123");
        planData.setSharedPlan("Y");
        detail.setPlan(planData);
        ArrayList<PlansPerks> perks = new ArrayList<>();
        perks.add(planData);
        detail.setPerks(perks);
        List<PlanTaggingDetails> details = new ArrayList<>();
        details.add(detail);
		PlanTaggingDetails detail1 = new PlanTaggingDetails();
		detail1.setPath(null);
        detail1.setGroup(null);
        detail1.setPath(null);
        detail1.setAction(null);
        detail1.setPlan(null);
        detail1.setPerks(null);
		detail1.setMtn("newLine2");
		details.add(detail1);
        request.getData().setPlanTaggingDetails(details);

        PlanTaggingDetails detail2 = new PlanTaggingDetails();
        detail2.setMtn("newLine1");
        detail2.setGroup(2);
        detail2.setPath("recommended");
        detail2.setAction("preset");
        detail2.setMtn("1234567890");
        PlansPerks planData1 = new PlansPerks();
        planData1.setId("123");
        planData1.setSharedPlan("Y");
        detail2.setPlan(planData1);
        ArrayList<PlansPerks> perks1 = new ArrayList<>();
        perks1.add(planData1);
        detail2.setPerks(perks1);
        plDetails.add(detail2);
        request.getData().setPlanTaggingDetails(plDetails);

        PlanTaggingDetails detail3 = new PlanTaggingDetails();
        detail3.setMtn("newLine8");
        plDetails.add(detail3);
        request.getData().setPlanTaggingDetails(plDetails);

        PlanTaggingDetails detail4 = new PlanTaggingDetails();
        detail4.setMtn(null);
        detail4.setPath("Build");
        plDetails.add(detail4);
        request.getData().setPlanTaggingDetails(plDetails);

        respData = new CXPRetrieveCartDataVO();
        response.setData(respData);
        CXPCartVO cart = new CXPCartVO();
        respData.setCart(null);
        helper.updateTaggingPlanDetails(response,request);
        assertNull(respData.getCart());

        respData.setCart(cart);
        helper.updateTaggingPlanDetails(response,request);
        assertNotNull(respData.getCart());


        cart.setLineDetails(null);
        helper.updateTaggingPlanDetails(response,request);
        assertNull(respData.getCart().getLineDetails());

        CXPLineDetailsVO lineDetails = new CXPLineDetailsVO();
        cart.setLineDetails(lineDetails);
        respData.setCart(cart);
        CXPLineInfo[] lineInfo =null;
        lineDetails.setLineInfo(null);
        helper.updateTaggingPlanDetails(response,request);
        assertNotNull(respData.getCart().getLineDetails());
        lineInfo = new CXPLineInfo[]{};
        lineDetails.setLineInfo(lineInfo);
        helper.updateTaggingPlanDetails(response,request);

        CXPLineInfo lineInfo1 = null;
        CXPLineInfo lineInfo2 = new CXPLineInfo();
        lineInfo2.setMobileNumber("newLine1");

        CXPLineInfo lineInfo3 = new CXPLineInfo();
        lineInfo3.setLineNumber("newLine2");
        lineInfo3.setMobileNumber("newLine22");

        CXPLineInfo lineInfo4 = new CXPLineInfo();
        lineInfo4.setMobileNumber("1234567890");

        CXPLineInfo lineInfo5 = new CXPLineInfo();
        lineInfo5.setMobileNumber("1234567899");
        lineInfo5.setLineNumber("newLine09");

        CXPLineInfo lineInfo6 = new CXPLineInfo();
        lineInfo6.setMobileNumber("12345678991");
        CXPLineInfo lineInfo7 = new CXPLineInfo();
        lineInfo = new CXPLineInfo[7];
        lineInfo6.setMobileNumber(null);
        lineInfo[0] = lineInfo1;
        lineInfo[1] = lineInfo2;
        lineInfo[2] = lineInfo3;
        lineInfo[3] = lineInfo4;
        lineInfo[4] = lineInfo5;
        lineInfo[5] = lineInfo6;
        lineInfo[6] = lineInfo7;
        lineDetails.setLineInfo(lineInfo);
        helper.updateTaggingPlanDetails(response, request);
        assertNotNull(respData.getCart().getLineDetails());
    }

    @Test
    public void updateSubflowForByodTest() throws IOException{
        String responseFile = "data/CartUpdateOperationsControllerTestJson/clearXboxFromCartOnDppSummaryResponse.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        ClearAndContinuePegaResponse response = mapper.readValue(responseString, ClearAndContinuePegaResponse.class);
        ClearAndContinueContext context = response.getServiceBody().getServiceResponse().getContext();
        ClearAndContinueUIRequest clearAndContinueUIRequest = new ClearAndContinueUIRequest();
        CartInfo cartInfo = new CartInfo();
        clearAndContinueUIRequest.setCartInfo(cartInfo);

        when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));

        cartInfo.setIsBYODSession("true");
        context.getContextInfo().setCradleFlowJourney("NEXTGEN_EC");

        helper1.updateSubflowForByod(clearAndContinueUIRequest,context);
        Assert.assertNotNull(context);



        cartInfo.setIsBYODSession("true");
        context.getContextInfo().setCradleFlowJourney("test");

        helper1.updateSubflowForByod(clearAndContinueUIRequest,context);
        Assert.assertNotNull(context);


        cartInfo.setIsBYODSession("true");
        context.setContextInfo(null);

        helper1.updateSubflowForByod(clearAndContinueUIRequest,context);
        Assert.assertNotNull(context);


        cartInfo.setIsBYODSession("false");

        helper1.updateSubflowForByod(clearAndContinueUIRequest,context);
        Assert.assertNotNull(context);


        cartInfo.setIsBYODSession("");

        helper1.updateSubflowForByod(clearAndContinueUIRequest,context);
        Assert.assertNotNull(context);

    }

    @Test
    public void getCartExceedsLimitServiceTest() throws JsonProcessingException {
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);

        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        String requestString = readFromFile("getCartExceedsLimit_request.json");
        String responseString = readFromFile("getCartExceedsLimit_response.json");
        CartExceedsLimitRequest request = mapper.readValue(requestString, CartExceedsLimitRequest.class);
        CartExceedsLimitResponse response = mapper.readValue(responseString, CartExceedsLimitResponse.class);
        URI url = URI.create("http://localhost/getCartExceedsLimit");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").build();
        MockServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatusCode.valueOf(200));
        when(cxpHelper.getCartExceedsLimitCXPResponse(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<CartExceedsLimitResponse>> responseEntityMono  = helper.getCartExceedsLimitService(httpHeader,httpResponse,request);
        StepVerifier.create(responseEntityMono).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }
    @Test
    public void removeSensitiveInfoForValidateOrderTest() throws JsonProcessingException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        String responseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-NETACE\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \"SOP-20647-E01\", \"contextInfo\": { \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"OrderReview-Shipping-Payment-Agreement\", \"processAction\": \"\", \"availablePaths\": [ { \"path\": \"AvailablePaths\" } ] }, \"cartInfo\": { \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"method\": \"addtoCart\" }, \"customerInfo\": { \"registerNumber\": 0, \"accountNumber\": \"0224065213-00001\", \"cartCreator\": \"2402169848\", \"processingMTN\": \"2402169848\" }, \"processMTNList\": [ { \"mtn\": \"2402169848\", \"completedprocessSteps\": [ \"MTNSelectionPage\", \"GridWallPDP\", \"ShoppingCart\" ] } ], \"validateOrder\": { \"orderDetails\": [ { \"systemId\": \"\", \"creditApplicationNum\": \"382938499\", \"orderStatus\": \"SUCCESS\", \"shipmentAddressValidated\": true, \"userId\": \"\", \"statusMsg\": \"\", \"creditApprovalStatus\": \"AP\", \"creditStatusReason\": \"CA CVAS AUTOMATIC APPROVAL\", \"securityDepositAmount\": \"0\", \"loveligibility\": false, \"statusCode\": \"\" } ], \"cartId\": \"cbf26bd7-035a-49a0-ba2c-e320bc46f3bf\", \"locationCode\": \"E247201\" } } } }, \"cartReadyForCheckout\": true }";
        InitiateCheckoutUIResponse response = mapper.readValue(responseString, InitiateCheckoutUIResponse.class);
        Method method = UpdateCartHelper.class.getDeclaredMethod("removeSensitiveInfoForValidateOrder", InitiateCheckoutUIResponse.class);
        ReflectionUtils.makeAccessible(method);
        method.invoke(helper, response);
        assertNotNull(method);
        response.getServiceBody().getServiceResponse().getContext().setCartInfo(null);
        method.invoke(helper, response);
        assertNotNull(method);
        response.setServiceBody(null);
        method.invoke(helper, response);
        assertNotNull(method);
    }

    @Test
    public void addStepFlowNameUpdateTest(){
        String intendtype="BYOD";
        helper.addStepFlowNameUpdate("BYOD");
        helper.addStepFlowNameUpdate("NSEBYOD");
        helper.addStepFlowNameUpdate("aal");
        helper.addStepFlowNameUpdate("eup");
        Assert.assertNotNull(intendtype);
        helper.addStepFlowNameUpdate("abc");
        helper.addStepFlowNameUpdate("ab12@#$");
        helper.addStepFlowNameUpdate(null);
    }
    @Test
    public void isthirdpartyFeaturePromoTest2(){
        promoHubOffer.setPromoType("FEATURED_PROMO");
        promoHubOffer.setOfferId("dummy");
        boolean featuredPromo = helper.isthirdpartyFeaturePromo(promoHubOffer);
        Assertions.assertFalse(featuredPromo);
    }
    @Test
    public void isEmailValidTest()
    {
        boolean response = ReflectionTestUtils.invokeMethod(helper,"isEmailValid","Jrlee3586@gmail.com");
        Assert.assertEquals(true,response);

        boolean response1 = ReflectionTestUtils.invokeMethod(helper,"isEmailValid","Jrlee3586@.com");
        Assert.assertEquals(false,response1);

        boolean response2 = ReflectionTestUtils.invokeMethod(helper,"isEmailValid","yshields2021@gmail.com");
        Assert.assertEquals(true,response2);

        boolean response3 = ReflectionTestUtils.invokeMethod(helper,"isEmailValid","@gmail.com");
        Assert.assertEquals(false,response3);

        boolean response4 = ReflectionTestUtils.invokeMethod(helper,"isEmailValid","tnee918@gmail.com");
        Assert.assertEquals(true,response4);

        boolean response5 = ReflectionTestUtils.invokeMethod(helper,"isEmailValid","Alxthgr88@gmail.com");
        Assert.assertEquals(true,response5);

        boolean response6 = ReflectionTestUtils.invokeMethod(helper,"isEmailValid","tneeh4918@gmail.com");
        Assert.assertEquals(true,response6);

        boolean response7 = ReflectionTestUtils.invokeMethod(helper,"isEmailValid","Jrlee3586@com");
        Assert.assertEquals(false,response7);
    }

    @Test
    public void testMaskingBYOD() throws JsonProcessingException {
        String responseString = sourceFileReaderUtil.readFile("/data/RetrieveCartUIResponse.json", testFileLocation);
        RetrieveCartUIResponse response = mapper.readValue(responseString, RetrieveCartUIResponse.class);
        when(featureFlagHelper.isMaskingForBYODFFlag()).thenReturn(Boolean.TRUE);
        helper.performMaskingBYOD(response);
        Assert.assertEquals("8776", response.getData().getCart().getLineDetails().getLineInfo()[0].getServiceInfo().getOrderDevice().getLteVoraEquipInfo().getLteVoraDeviceInfo().getDeviceId());
        Assert.assertEquals("3665", response.getData().getCart().getLineDetails().getLineInfo()[1].getItemsInfo()[0].getCartItems().getCartItem()[1].getESIM());
        response.getData().getCart().getLineDetails().getLineInfo()[1].getItemsInfo()[0].getCartItems().getCartItem()[0].setESIM(null);
        helper.performMaskingBYOD(response);
        response.getData().getCart().getLineDetails().getLineInfo()[1].getItemsInfo()[0].getCartItems().setCartItem(new CXPCartItem[]{null});
        helper.performMaskingBYOD(response);
        response.getData().getCart().getLineDetails().getLineInfo()[1].getItemsInfo()[0].getCartItems().setCartItem(null);
        helper.performMaskingBYOD(response);
        response.getData().getCart().getLineDetails().getLineInfo()[1].getItemsInfo()[0].setCartItems(null);
        helper.performMaskingBYOD(response);
        response.getData().getCart().getLineDetails().getLineInfo()[1].setItemsInfo(new CXPItemInfo[]{null});
        helper.performMaskingBYOD(response);
        response.getData().getCart().getLineDetails().getLineInfo()[1].setItemsInfo(null);
        helper.performMaskingBYOD(response);
        response.getData().getCart().getLineDetails().setLineInfo(new CXPLineInfo[]{null});
        helper.performMaskingBYOD(response);
        response.getData().getCart().getLineDetails().setLineInfo(null);
        helper.performMaskingBYOD(response);
        response.getData().getCart().setLineDetails(null);
        helper.performMaskingBYOD(response);
        response.getData().setCart(null);
        helper.performMaskingBYOD(response);
        response.setData(null);
        helper.performMaskingBYOD(response);
        helper.performMaskingBYOD(null);
        when(featureFlagHelper.isMaskingForBYODFFlag()).thenReturn(Boolean.FALSE);
        helper.performMaskingBYOD(null);
    }

    @Test
    public void testCheckMaskingMethod() throws JsonProcessingException {
        String responseString = sourceFileReaderUtil.readFile("/data/RetrieveCartUIResponse.json", testFileLocation);
        RetrieveCartUIResponse response = mapper.readValue(responseString, RetrieveCartUIResponse.class);
        when(featureFlagHelper.isMaskingForBYODFFlag()).thenReturn(Boolean.TRUE);
        helper.checkForBYODMasking(response);
        Assert.assertEquals("8776", response.getData().getCart().getLineDetails().getLineInfo()[0].getServiceInfo().getOrderDevice().getLteVoraEquipInfo().getLteVoraDeviceInfo().getDeviceId());
        Assert.assertEquals("3665", response.getData().getCart().getLineDetails().getLineInfo()[1].getItemsInfo()[0].getCartItems().getCartItem()[1].getESIM());
        response.getData().getCart().getLineDetails().getLineInfo()[1].getItemsInfo()[0].getCartItems().getCartItem()[0].setESIM(null);
        helper.checkForBYODMasking(response);
        response.getData().getCart().getLineDetails().getLineInfo()[1].getItemsInfo()[0].getCartItems().setCartItem(new CXPCartItem[]{null});
        helper.checkForBYODMasking(response);
        response.getData().getCart().getLineDetails().getLineInfo()[1].getItemsInfo()[0].getCartItems().setCartItem(null);
        helper.checkForBYODMasking(response);
        response.getData().getCart().getLineDetails().getLineInfo()[1].getItemsInfo()[0].setCartItems(null);
        helper.checkForBYODMasking(response);
        response.getData().getCart().getLineDetails().getLineInfo()[1].setItemsInfo(new CXPItemInfo[]{null});
        helper.checkForBYODMasking(response);
        response.getData().getCart().getLineDetails().getLineInfo()[1].setItemsInfo(null);
        helper.checkForBYODMasking(response);
        response.getData().getCart().getLineDetails().setLineInfo(new CXPLineInfo[]{null});
        helper.checkForBYODMasking(response);
        response.getData().getCart().getLineDetails().setLineInfo(null);
        helper.checkForBYODMasking(response);
        response.getData().getCart().setLineDetails(null);
        helper.checkForBYODMasking(response);
        response.getData().setCart(null);
        helper.checkForBYODMasking(response);
        response.setData(null);
        helper.checkForBYODMasking(response);
        helper.checkForBYODMasking(null);
        when(featureFlagHelper.isMaskingForBYODFFlag()).thenReturn(Boolean.FALSE);
        helper.checkForBYODMasking(null);
    }


    @Test
    public void testPastDues() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"pastDueAccepted\":\"Y\",\"clientAppName\":\"B2C-TELESALES\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"f61a7954-4300-4e97-9478-f001475bdf9b\",\"caseId\":\"SOP-508208-E01\",\"accountNumber\":\"0420194063-00001\",\"cartCreator\":\"4235342870\",\"processingMTN\":\"4235344191\"},\"data\":{\"pastdue\":{\"amount\":\"140.25\"},\"effectiveDate\":\"09/26/2019\",\"Cart\":\"cart\"}}";
        PastDuesUIRequest request = mapper.readValue(requestString, PastDuesUIRequest.class);
        request.getCartInfo().setIntendType(CartConstants.BYOD);
        request.setChannelId("VZW-DOTCOM");
        CartRedisData sampleRedisData = new CartRedisData();
        sampleRedisData.setPastDueRedisData(new PastDueRedisData());
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(featureFlagHelper.isPastDueBYODFFlag()).thenReturn(Boolean.TRUE);
        StepVerifier.create(helper.pastDues(request)).assertNext(resp -> Assert.assertNotNull(request)).expectComplete().verify();
        assertNotNull(request);
        sampleRedisData.setPastDueRedisData(null);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        helper.pastDues(request).subscribe();
        request.getCartInfo().setIntendType("OTHER");
        helper.pastDues(request).subscribe();
        request.getCartInfo().setIntendType("");
        helper.pastDues(request).subscribe();
        request.getCartInfo().setIntendType(null);
        helper.pastDues(request).subscribe();
        request.setCartInfo(null);
        helper.pastDues(request).subscribe();
        when(featureFlagHelper.isPastDueBYODFFlag()).thenReturn(Boolean.FALSE);
        helper.pastDues(request).subscribe();
        request.setChannelId("");
        helper.pastDues(request).subscribe();
    }

    @Test
    public void updateUserInfoHelperTest2() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateUserInfoUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateUserInfoUIResponse1.json", testFileLocation);
        UpdateUserInfoUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateUserInfoUIRequest.class);
        UpdateUserInfoUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateUserInfoUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData2.json", testFileLocation);
        ;
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<UpdateUserInfoUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(cxpHelper.updateUserInfo(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        sampleRequest.setFlexV2(true);
        UpdateUserInfoUIResponse expectedResponse = sampleResponse;
        Mono<UpdateUserInfoUIResponse> response = helper.updateUserInfo(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }
    @Test
    public void addPlanforNSETest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIResponse.json", testFileLocation);
        String sampleRetrieveCartResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveCartCXPResponse.json", testFileLocation);
        AddPlanUIRequest UIRequest = new AddPlanUIRequest();
        UIRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
        AddPlanUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData3.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setUserRole("userrole");
        sampleRedisData.setRelinquishAccountNumber("123456");
        sampleRedisData.setTysLinesCount("7");
        sampleResponse = mapper.readValue(sampleResponseString, AddPlanUIResponse.class);
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(omniDLHelper.upsertPlanTaggingValueToRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(bpmHelperAddPlan.addPlan(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getOneClickCheckoutFlag()).thenReturn(Mono.just("false"));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(new MyOfferETRRedisData()));
        when(featureFlag.isFeatureEnabled(anyString(), anyString(), anyString(), anyBoolean())).thenReturn(Mono.just(Boolean.TRUE));
        RetrieveCartCXPResponse sampleCXPResponse = null;
        sampleCXPResponse = mapper.readValue(sampleRetrieveCartResponseString, RetrieveCartCXPResponse.class);
        Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
        AddPlanUIResponse expectedResponse = sampleResponse;
        Mono<AddPlanUIResponse> response = helper.addPlan(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void addFeatureHelperTest1() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddFeaturesUIResponse.json", testFileLocation);;
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddFeaturesUIRequest3.json", testFileLocation);
        AddFeaturesUIRequest sampleUIRequest =  mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
        sampleUIRequest.setVzHPfeatureforAcc(false);
        AddFeaturesUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddFeaturesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData147.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddFeaturesUIResponse expectedResponse = sampleResponse;
        sampleRedisData.setUserRole("userrole");
        sampleRedisData.setLineActivityType("line");
        sampleRedisData.setRelinquishAccountNumber("123456");
        sampleRedisData.setTysLinesCount("6");
        sampleRedisData.setDepletionType("depl");
        when(redisHelper.getAddFeaturesRequest()).thenReturn(Mono.just(sampleUIRequest));
        when(bpmHelper2.addFeatures(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        Mono<AddFeaturesUIResponse> response = helper.addFeatures(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void deassignMTNHelperTest3() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DeassignMtnUIRequest.json",
                testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DeassignMtnUIResponse.json",
                testFileLocation);
        RemoveLinesUIRequest sampleRequest = null;
        DeassignMtnUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisDataForDeassign.json",
                testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCartId(null);
        sampleRedisData.setAccountNumber(null);
        sampleRedisData.setCaseId(null);
        sampleRedisData.setProcessingMTN(null);

        sampleRequest = mapper.readValue(sampleRequestString, RemoveLinesUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, DeassignMtnUIResponse.class);
        Mono<DeassignMtnUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.deassignMtn(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        DeassignMtnUIResponse expectedResponse = sampleResponse;
        Mono<DeassignMtnUIResponse> response = helper.deassignMtnUIResponseMono(sampleRequest, sampleRedisData);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }
}
