package onevz.soe.cart.bpm.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.cxp.feature.Flag;
import onevz.cxp.feature.util.FeatureFlag;
import onevz.soe.cart.bpm.service.CartServiceBPMServices;
import onevz.soe.cart.helper.FeatureFlagHelper;
import onevz.soe.cart.helper.RedisHelper2;
import onevz.soe.cart.responses.AddDevicePEGAResponse;
import onevz.soe.cart.responses.CreateLinePEGAResponse;
import onevz.soe.cart.ui.requests.AddDeviceUIRequest;
import onevz.soe.cart.ui.requests.CreateLineUIRequest;
import onevz.soe.cart.ui.responses.AddDeviceUIResponse;
import onevz.soe.cart.ui.responses.CreateLineUIResponse;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.net.URI;

import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@WebFluxTest(CartServiceBpmHelper.class)
public class CartServiceBpmHelper1Test {
    @InjectMocks
    private CartServiceBpmHelper2 bpmHelper2;

    @Mock
    private CartServiceBPMServices bpmServices;

    @Mock
    private RedisHelper2 redisHelper2;
    @Mock
    private FeatureFlagHelper featureFlagHelper;

    @Autowired
    private ObjectMapper mapper;

    @Mock
    FeatureFlag featureFlag;

    @Test
    public void createLineByodLineDetailsTest() throws JsonProcessingException, SOEHTTPException {
        String reqString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"clientAppName\": \"\",\"processStep\": \"LineSelection\",\"intendType\": \"NSEBYOD\",\"mtnFlow\": \"D\",\"customerType\": \"N\",\"cartCreatorSalesRepId\": \"ENC\",\"cartCreatorOrderLocationCode\": \"P175401\",\"cartCreator\": \"POE-D-47c8034f-8dab-41dc-b4bb-4ae55e8619aa\",\"globalId\": \"POE-D-47c8034f-8dab-41dc-b4bb-4ae55e8619aa\"},\"data\": {\"zipCode\": \"30004\",\"numOfLines\": 1,\"friendsAndFamilyCode\": \"\",\"lines\": [{\"mtn\": \"\",\"deviceTypeSelected\": \"\",\"portInNumber\": \"\"}],\"byodLineDetails\": [{\"mtn\": \"newLine1\",\"deviceCategory\": \"Smartphones\"}]}}";
        CreateLineUIRequest request =mapper.readValue(reqString,CreateLineUIRequest.class);

        when(featureFlagHelper.isDeviceFirstEnableForExistingBYODFFlag()).thenReturn(true);
        when(featureFlagHelper.isDeviceFirstEnableForProspectBYODFFlag()).thenReturn(true);
        when(bpmServices.createLine(Mockito.any())).thenReturn(Mono.just(new CreateLinePEGAResponse()));
        Mono<CreateLineUIResponse> createLineUIResponseMono = bpmHelper2.
                createLine(request);
        StepVerifier.create(createLineUIResponseMono).assertNext(resp -> {
            Assert.assertNotNull(resp);
        }).expectComplete().verify();

        request.getData().getByodLineDetails().clear();
        Mono<CreateLineUIResponse> createLineUIResponseMono1 = bpmHelper2.
                createLine(request);
        StepVerifier.create(createLineUIResponseMono1).assertNext(resp -> {
            Assert.assertNotNull(resp);
        }).expectComplete().verify();

        request.getData().setByodLineDetails(null);
        Mono<CreateLineUIResponse> createLineUIResponseMono2= bpmHelper2.
                createLine(request);
        StepVerifier.create(createLineUIResponseMono2).assertNext(resp -> {
            Assert.assertNotNull(resp);
        }).expectComplete().verify();
    }

    @Test
    public void addDeviceByodMtnTest() throws JsonProcessingException, SOEHTTPException {
        String sampleRequestString = "{\"channelId\":\"VZW-DOTCOM\",\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"BYOD\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"noPendingOfferExists\":false,\"isPromoPDP\":false,\"mtnFlow\":\"G\",\"isLineLevelPlanAccount\":true,\"amRole\":\"mobileSecure\"},\"data\":{\"lines\":[{\"isCommonPDP\":true,\"mtn\":\"\",\"purchasePath\":\"EUP\",\"portInNumber\":\"\",\"eupNoPromoFlow\":false,\"device\":{\"id\":\"MTXT3LL/A\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":true,\"dppMonths\":36,\"productId\":\"dev21410695\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"UNIVESIM5G-SAB-D\"},\"ispuFlow\":false,\"estimatedReadyByDate\":\"\",\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"newLineOrAAL\":false,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":true,\"selectedSedOfferId\":\"\",\"isStrategicOffer\":false,\"restricted\":\"\",\"skipPromoChoiceOffer\":false,\"isTradeInIntentSelected\":true,\"restrictedProductType\":null}],\"byodMtn\":\"newLine1\",\"rtm\":{\"url\":\"https://vzwqa3.verizonwireless.com/smartphones/apple-iphone-15-plus/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-15-plus-128gb-pink-mtxt3ll-a-a?fmt=webp\",\"name\":\"iPhone 15 Plus\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://vzwqa3.verizonwireless.com/smartphones/apple-iphone-15-plus/\"},\"enableFcc\":true}}";
        AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);

        URI url = URI.create("http://localhost/add-device");

        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just("sampleRedisData"));
        when(redisHelper2.getLVSoftsku()).thenReturn(Mono.just("SampleResponseData"));
        when(featureFlagHelper.isSkipResumeCaseFFlagEnabled()).thenReturn(Mono.just(Boolean.TRUE));
        when(bpmServices.addDevice(Mockito.any())).thenReturn(Mono.just(new AddDevicePEGAResponse()));
        when(featureFlagHelper.isRouterFlagEnabled()).thenReturn(Mono.just(Boolean.TRUE));
        when(featureFlagHelper.isTradeInPromoCheckFflagEnabled()).thenReturn(Mono.just(Boolean.TRUE));
        when(featureFlagHelper.amNextGenFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        when(featureFlagHelper.getFeatureFlagWithAccNumThrottle(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(true);
        when(featureFlagHelper.isDeviceFirstEnableForExistingBYODFFlag()).thenReturn(true);
        when(featureFlagHelper.isDeviceFirstEnableForProspectBYODFFlag()).thenReturn(true);
        when(featureFlagHelper.isFlexV2ValidationEnabled()).thenReturn(Mono.just(Boolean.TRUE));
        Flag flag = new Flag();
        when(featureFlag.getFeatureFlag(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(flag));
        Mono<AddDeviceUIResponse> addDeviceBpmResponse = bpmHelper2.
                addDevice(request);
        StepVerifier.create(addDeviceBpmResponse).assertNext(resp -> {
            Assert.assertNotNull(resp);
        }).expectComplete().verify();

        request.getData().setByodMtn(null);
        Mono<AddDeviceUIResponse> addDeviceBpmResponse1 = bpmHelper2.
                addDevice(request);
        StepVerifier.create(addDeviceBpmResponse1).assertNext(resp -> {
            Assert.assertNotNull(resp);
        }).expectComplete().verify();

    }

}
