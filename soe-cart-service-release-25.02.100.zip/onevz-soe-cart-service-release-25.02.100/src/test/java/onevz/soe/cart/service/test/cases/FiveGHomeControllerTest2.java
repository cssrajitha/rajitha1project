package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import junit.framework.Assert;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper;
import onevz.soe.cart.controller.FiveGHomeController;
import onevz.soe.cart.gql.schema.LineInfo;
import onevz.soe.cart.gql.schema.ServiceInfo;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.common.FieldValidationException;
import onevz.soe.cart.model.retrieveCart.Cart5GAppointment;
import onevz.soe.cart.model.reviewOrderInsipico.InspicioResponseOrderInfo;
import onevz.soe.cart.model.reviewOrderInsipico.InspicioTermsAndConditions;
import onevz.soe.cart.model.reviewOrderInsipico.ReviewOrderData;
import onevz.soe.cart.requests.GetCartDetailsRequest;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.AddPlanAndDeviceUIResponse;
import onevz.soe.cart.ui.responses.CrmRetrieveCartUIResponse;
import onevz.soe.session.bean.SOELoginSessionBean;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.*;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpResponse;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.ResourceUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.*;

@RunWith(SpringJUnit4ClassRunner.class)
@WebFluxTest(FiveGHomeController.class)
public class FiveGHomeControllerTest2 {

	@MockBean
	private FiveGhomeNSEHelper nseHelper;
	@Autowired
	private FiveGHomeController cartController;
	@Autowired
	private ObjectMapper mapper;

	@Test
	public void getDueMonthlyAndDueTodayTest() throws IOException {
		String requestString = "{\"meta\":{},\"data\":{\"cartId\":\"b58e3b4d-f13c-440d-8ca8-465f4856a16b\"}}";
		String responseString = "{\"orderDetailsView\":{\"dueTodayAmount\":\"108.19\",\"dueMonthlyAmount\":\"105.78\"}}";
		GetCartDetailsRequest request = mapper.readValue(requestString, GetCartDetailsRequest.class);
		GetCartDetailsUIResponse response = mapper.readValue(responseString, GetCartDetailsUIResponse.class);
		when(nseHelper.get5GCart(Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(200).body(response)));
		StepVerifier.create(cartController.getDueMonthlyAndDueToday(request)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
		String responseNullString = "{\"orderDetailsView\":null}";
		GetCartDetailsUIResponse response1 = mapper.readValue(responseNullString, GetCartDetailsUIResponse.class);
		when(nseHelper.get5GCart(Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(200).body(response1)));
		StepVerifier.create(cartController.getDueMonthlyAndDueToday(request)).assertNext(resp -> Assert.assertNull(resp.getOrderDetailsView())).expectComplete()
				.verify();
		GetCartDetailsUIResponse response2 = mapper.readValue("{\"errors\":null}", GetCartDetailsUIResponse.class);
		GetCartDetailsUIResponse response3 = mapper.readValue("{\"errors\":[{\"id\":\"400\"}]}", GetCartDetailsUIResponse.class);
		when(nseHelper.get5GCart(Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(200).body(response2)));
		StepVerifier.create(cartController.getDueMonthlyAndDueToday(request)).assertNext(resp -> Assert.assertNull(resp.getErrors())).expectComplete()
				.verify();
		when(nseHelper.get5GCart(Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(200).body(response3)));
		StepVerifier.create(cartController.getDueMonthlyAndDueToday(request)).assertNext(resp -> Assert.assertNull(resp.getOrderDetailsView())).expectComplete()
				.verify();
	}

}