package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import onevz.soe.cart.bpm.helper.CartWithDateServiceBpmHelper;
import onevz.soe.cart.bpm.service.CartServiceBPMServices;
import onevz.soe.cart.model.cartwithdate.*;
import onevz.soe.cart.responses.CartWithDatePegaResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.CartWithDateUIRequest;
import onevz.soe.exception.SOEError;
import onevz.soe.exception.SOEErrorHolder;
import onevz.soe.wsclient.bpm.model.CustomerInfo;
import onevz.soe.wsclient.bpm.model.response.Error;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import static org.mockito.Mockito.when;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {CartServiceTestConfig.class})
public class CartWithDateServiceBpmHelperTest {

    @Autowired
    CartWithDateServiceBpmHelper cartWithDateServiceBpmHelper;
    @MockBean
    private CartServiceBPMServices services;
    @Autowired
    private ObjectMapper mapper;

    @Test
    public void saveCartWithDateTest() throws IOException
    {
        String requestString = "{\n \"context\": {\n \"caseId\": \"SOP-3597615-E01\",\n\"contextInfo\": {\n \"callReason\": \"SalesOrderPurchase\",\n \"processStep\": \"OrderReview\",\n\"processAction\": \"UpdateScheduleAppointment\",\n \"intent\": \"MOVER\"\n},\n\"customerInfo\": {\n\"accountNumber\": \"0389467727-00001\",\n\"cartCreator\": \"6072376627\",\n\"processingMTN\": \"8136958775\",\n \"registerNumber\": 0\n},\n\"cartInfo\": {\n\"cartId\": \"cfe0a112-c547-41a6-bfde-7e0688d7a774\",\n  \"itemType\": \"SCHEDULE5GAPPT\",\n\"intendType\": \"MOVER\",\n\"moversInfo\": {\n\"moveInDate\": \"07/20/2021\",\n  \"moveOutDate\": \"07/30/2021\"\n }\n }\n }\n}";
        String responseString = "{\n \"serviceHeader\" : {\n \"statusMsg\" : \"SUCCESS\",\n \"sessionId\" : \"\",\n \"serviceName\" : \"SalesOrderPurchase\",\n \"userId\" : \"\",\n\"statusCode\" : \"00\"\n },\n \"serviceBody\" : {\n \"serviceResponse\" : {\n\"context\" : {\n\"cartInfo\" : {\n  \"statusMsg\" : \"Success\",\n\"cartId\" : \"1f69c02f-c68f-4445-b5ff-8814fbd3412d\",\n \"preAuthSuccess\" : false,\n \"statusCode\" : \"1\"\n },\n \"contextInfo\" : {\n \"availablePaths\" : [{\n \"path\" : \"OrderReview-Shipping-Payment-Agreement\"\n  }\n   ],\n  \"processAction\" : \"\",\n \"processStep\" : \"OrderReview-Shipping-Payment-Agreement\",\n  \"callReason\" : \"SalesOrderPurchase\"\n    },\n \"caseId\" : \"SOP-3335332-E01\",\n\"customerInfo\" : {\n \"cartCreator\" : \"4029847575\",\n  \"processingMTN\" : \"newLine1\",\n \"accountNumber\" : \"0283134872-00001\"\n },\n   \"processMTNList\" : [{\n   \"mtn\" : \"newLine1\",\n\"completedprocessSteps\" : [\"NumberSelection\", \"Accessories\", \"NumberSelection\", \"NumberSelection\", \"ShoppingCart\", \"ContactInfo\", \"ShippingOptions\", \"ShippingOptions\", \"AppointmentSchedule\"]\n }\n]\n }\n  }\n }\n}\n";
        CartWithDateUIRequest request = mapper.readValue(requestString, CartWithDateUIRequest.class);
        CartWithDatePegaResponse expectedResponse = mapper.readValue(responseString, CartWithDatePegaResponse.class);
        try {
            when(services.updateCartWithDate(Mockito.any())).thenReturn(Mono.just(expectedResponse));
        } catch (SOEHTTPException e) {
            e.printStackTrace();
        }

        Mono<CartWithDatePegaResponse>   response =cartWithDateServiceBpmHelper.saveCartWithDate(request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void saveCartWithDateWithoutCartInfoTest() throws IOException
    {
        String requestString = "{\"context\":{\"caseId\":\"SOP-3597615-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"OrderReview\",\"processAction\":\"UpdateScheduleAppointment\",\"intent\":\"MOVER\"},\"customerInfo\":{\"accountNumber\":\"0389467727-00001\",\"cartCreator\":\"6072376627\",\"processingMTN\":\"8136958775\",\"registerNumber\":0},\"cartInfo\":{\"cartId\":null,\"itemType\":null,\"intendType\":null,\"moversInfo\":{\"moveInDate\":null,\"moveOutDate\":null}}}}";
        String responseString = "{\n \"serviceHeader\" : {\n \"statusMsg\" : \"SUCCESS\",\n \"sessionId\" : \"\",\n \"serviceName\" : \"SalesOrderPurchase\",\n \"userId\" : \"\",\n\"statusCode\" : \"00\"\n },\n \"serviceBody\" : {\n \"serviceResponse\" : {\n\"context\" : {\n\"cartInfo\" : {\n  \"statusMsg\" : \"Success\",\n\"cartId\" : \"1f69c02f-c68f-4445-b5ff-8814fbd3412d\",\n \"preAuthSuccess\" : false,\n \"statusCode\" : \"1\"\n },\n \"contextInfo\" : {\n \"availablePaths\" : [{\n \"path\" : \"OrderReview-Shipping-Payment-Agreement\"\n  }\n   ],\n  \"processAction\" : \"\",\n \"processStep\" : \"OrderReview-Shipping-Payment-Agreement\",\n  \"callReason\" : \"SalesOrderPurchase\"\n    },\n \"caseId\" : \"SOP-3335332-E01\",\n\"customerInfo\" : {\n \"cartCreator\" : \"4029847575\",\n  \"processingMTN\" : \"newLine1\",\n \"accountNumber\" : \"0283134872-00001\"\n },\n   \"processMTNList\" : [{\n   \"mtn\" : \"newLine1\",\n\"completedprocessSteps\" : [\"NumberSelection\", \"Accessories\", \"NumberSelection\", \"NumberSelection\", \"ShoppingCart\", \"ContactInfo\", \"ShippingOptions\", \"ShippingOptions\", \"AppointmentSchedule\"]\n }\n]\n }\n  }\n }\n}\n";
        CartWithDateUIRequest request = mapper.readValue(requestString, CartWithDateUIRequest.class);
        CartWithDatePegaResponse expectedResponse = mapper.readValue(responseString, CartWithDatePegaResponse.class);
        try {
            when(services.updateCartWithDate(Mockito.any())).thenReturn(Mono.just(expectedResponse));
        } catch (SOEHTTPException e) {
            e.printStackTrace();
        }

        Mono<CartWithDatePegaResponse>   response =cartWithDateServiceBpmHelper.saveCartWithDate(request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void saveCartWithDateWithScheduleAppointmentInfoTest() throws IOException
    {
        String requestString = "{\"context\":{\"caseId\":\"SOP-3597615-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"OrderReview\",\"processAction\":\"UpdateScheduleAppointment\",\"intent\":\"MOVER\"},\"customerInfo\":{\"accountNumber\":\"0389467727-00001\",\"cartCreator\":\"6072376627\",\"processingMTN\":\"8136958775\",\"registerNumber\":0},\"cartInfo\":{\"cartId\":\"cfe0a112-c547-41a6-bfde-7e0688d7a774\",\"itemType\":\"SCHEDULE5GAPPT\",\"intendType\":\"MOVER\",\"moversInfo\":{\"moveInDate\":\"07/20/2021\",\"moveOutDate\":\"07/30/2021\"},\"scheduleAppointmentRequest\":{\"cartId\":\"cfe0a112-c547-41a6-bfde-7e0688d7a774\",\"cartLineMtn\":\"8136958775\",\"apptInfo\":{\"homePhone\":\"8134151947\",\"primaryPhoneType\":\"Home\",\"preferredContactType\":\"Email\",\"emailAddress\":\"abc.def@verizon.com\",\"firstName\":\"abc\",\"lastName\":\"def\",\"installationFloor\":\"\",\"languagePref\":\"E\",\"installApptSelectedDate\":{\"availableDate\":\"20220607\",\"availableDay\":\"2\",\"availableType\":\"0\",\"serviceProviderAccount\":\"1115183\",\"serviceProviderName\":\"ASURION INSTALLER\",\"slotLength\":\"2\",\"slotStartTime\":\"1500\"},\"customerInstructions\":\"testing Consumer \",\"eventCorrelationId\":\"55411_1654589390762_812\"}}}}}";
        String responseString = "{\n \"serviceHeader\" : {\n \"statusMsg\" : \"SUCCESS\",\n \"sessionId\" : \"\",\n \"serviceName\" : \"SalesOrderPurchase\",\n \"userId\" : \"\",\n\"statusCode\" : \"00\"\n },\n \"serviceBody\" : {\n \"serviceResponse\" : {\n\"context\" : {\n\"cartInfo\" : {\n  \"statusMsg\" : \"Success\",\n\"cartId\" : \"1f69c02f-c68f-4445-b5ff-8814fbd3412d\",\n \"preAuthSuccess\" : false,\n \"statusCode\" : \"1\"\n },\n \"contextInfo\" : {\n \"availablePaths\" : [{\n \"path\" : \"OrderReview-Shipping-Payment-Agreement\"\n  }\n   ],\n  \"processAction\" : \"\",\n \"processStep\" : \"OrderReview-Shipping-Payment-Agreement\",\n  \"callReason\" : \"SalesOrderPurchase\"\n    },\n \"caseId\" : \"SOP-3335332-E01\",\n\"customerInfo\" : {\n \"cartCreator\" : \"4029847575\",\n  \"processingMTN\" : \"newLine1\",\n \"accountNumber\" : \"0283134872-00001\"\n },\n   \"processMTNList\" : [{\n   \"mtn\" : \"newLine1\",\n\"completedprocessSteps\" : [\"NumberSelection\", \"Accessories\", \"NumberSelection\", \"NumberSelection\", \"ShoppingCart\", \"ContactInfo\", \"ShippingOptions\", \"ShippingOptions\", \"AppointmentSchedule\"]\n }\n]\n }\n  }\n }\n}\n";
        CartWithDateUIRequest request = mapper.readValue(requestString, CartWithDateUIRequest.class);
        CartWithDatePegaResponse expectedResponse = mapper.readValue(responseString, CartWithDatePegaResponse.class);
        try {
            when(services.updateCartWithDate(Mockito.any())).thenReturn(Mono.just(expectedResponse));
        } catch (SOEHTTPException e) {
            e.printStackTrace();
        }
        Mono<CartWithDatePegaResponse>   response =cartWithDateServiceBpmHelper.saveCartWithDate(request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void saveCartWithDateWithInvalidCustomerInfoTest() throws IOException
    {
        String requestString = "{\"context\":{\"caseId\":\"SOP-3597615-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"OrderReview\",\"processAction\":\"UpdateScheduleAppointment\",\"intent\":\"MOVER\"},\"customerInfo\":{\"accountNumber\":null,\"cartCreator\":null,\"processingMTN\":null,\"registerNumber\":null},\"cartInfo\":{\"cartId\":\"cfe0a112-c547-41a6-bfde-7e0688d7a774\",\"itemType\":\"SCHEDULE5GAPPT\",\"intendType\":\"MOVER\",\"moversInfo\":{\"moveInDate\":\"07/20/2021\",\"moveOutDate\":\"07/30/2021\"},\"scheduleAppointmentInfo\":{\"cartId\":\"cfe0a112-c547-41a6-bfde-7e0688d7a774\",\"cartLineMtn\":\"123456789\"}}}}";
        String responseString = "{\n \"serviceHeader\" : {\n \"statusMsg\" : \"SUCCESS\",\n \"sessionId\" : \"\",\n \"serviceName\" : \"SalesOrderPurchase\",\n \"userId\" : \"\",\n\"statusCode\" : \"00\"\n },\n \"serviceBody\" : {\n \"serviceResponse\" : {\n\"context\" : {\n\"cartInfo\" : {\n  \"statusMsg\" : \"Success\",\n\"cartId\" : \"1f69c02f-c68f-4445-b5ff-8814fbd3412d\",\n \"preAuthSuccess\" : false,\n \"statusCode\" : \"1\"\n },\n \"contextInfo\" : {\n \"availablePaths\" : [{\n \"path\" : \"OrderReview-Shipping-Payment-Agreement\"\n  }\n   ],\n  \"processAction\" : \"\",\n \"processStep\" : \"OrderReview-Shipping-Payment-Agreement\",\n  \"callReason\" : \"SalesOrderPurchase\"\n    },\n \"caseId\" : \"SOP-3335332-E01\",\n\"customerInfo\" : {\n \"cartCreator\" : \"4029847575\",\n  \"processingMTN\" : \"newLine1\",\n \"accountNumber\" : \"0283134872-00001\"\n },\n   \"processMTNList\" : [{\n   \"mtn\" : \"newLine1\",\n\"completedprocessSteps\" : [\"NumberSelection\", \"Accessories\", \"NumberSelection\", \"NumberSelection\", \"ShoppingCart\", \"ContactInfo\", \"ShippingOptions\", \"ShippingOptions\", \"AppointmentSchedule\"]\n }\n]\n }\n  }\n }\n}\n";
        CartWithDateUIRequest request = mapper.readValue(requestString, CartWithDateUIRequest.class);
        CartWithDatePegaResponse expectedResponse = mapper.readValue(responseString, CartWithDatePegaResponse.class);
        try {
            when(services.updateCartWithDate(Mockito.any())).thenReturn(Mono.just(expectedResponse));
        } catch (SOEHTTPException e) {
            e.printStackTrace();
        }
        Mono<CartWithDatePegaResponse>   response =cartWithDateServiceBpmHelper.saveCartWithDate(request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void saveCartWithDateHTTPExceptionTest() throws IOException {
        String requestString = "{\n \"context\": {\n \"caseId\": \"SOP-3597615-E01\",\n\"contextInfo\": {\n \"callReason\": \"SalesOrderPurchase\",\n \"processStep\": \"OrderReview\",\n\"processAction\": \"UpdateScheduleAppointment\",\n \"intent\": \"MOVER\"\n},\n\"customerInfo\": {\n\"accountNumber\": \"0389467727-00001\",\n\"cartCreator\": \"6072376627\",\n\"processingMTN\": \"8136958775\",\n \"registerNumber\": 0\n},\n\"cartInfo\": {\n\"cartId\": \"cfe0a112-c547-41a6-bfde-7e0688d7a774\",\n  \"itemType\": \"SCHEDULE5GAPPT\",\n\"intendType\": \"MOVER\",\n\"moversInfo\": {\n\"moveInDate\": \"07/20/2021\",\n  \"moveOutDate\": \"07/30/2021\"\n }\n }\n }\n}";
        String responseString = "{\"errors\" : [{\"message\":\"Test error occurred\"}]}";
        CartWithDateUIRequest request = mapper.readValue(requestString, CartWithDateUIRequest.class);
        CartWithDatePegaResponse expectedResponse = mapper.readValue(responseString, CartWithDatePegaResponse.class);
        try {
            when(services.updateCartWithDate(Mockito.any())).thenReturn(Mono.just(expectedResponse));
        } catch (SOEHTTPException e) {
            e.printStackTrace();
        }
        Mono<CartWithDatePegaResponse> response = cartWithDateServiceBpmHelper.saveCartWithDate(request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void saveCartWithDateExceptionTest() throws IOException
    {
        String requestString = "{\n \"context\": {\n \"caseId\": \"SOP-3597615-E01\",\n\"contextInfo\": {\n \"callReason\": \"SalesOrderPurchase\",\n \"processStep\": \"OrderReview\",\n\"processAction\": \"UpdateScheduleAppointment\",\n \"intent\": \"MOVER\"\n},\n\"customerInfo\": {\n\"accountNumber\": \"0389467727-00001\",\n\"cartCreator\": \"6072376627\",\n\"processingMTN\": \"8136958775\",\n \"registerNumber\": 0\n},\n\"cartInfo\": {\n\"cartId\": \"cfe0a112-c547-41a6-bfde-7e0688d7a774\",\n  \"itemType\": \"SCHEDULE5GAPPT\",\n\"intendType\": \"MOVER\",\n\"moversInfo\": {\n\"moveInDate\": \"07/20/2021\",\n  \"moveOutDate\": \"07/30/2021\"\n }\n }\n }\n}";
        String responseString = "{\n \"serviceHeader\" : {\n \"statusMsg\" : \"SUCCESS\",\n \"sessionId\" : \"\",\n \"serviceName\" : \"SalesOrderPurchase\",\n \"userId\" : \"\",\n\"statusCode\" : \"00\"\n },\n \"serviceBody\" : {\n \"serviceResponse\" : {\n\"context\" : {\n\"cartInfo\" : {\n  \"statusMsg\" : \"Success\",\n\"cartId\" : \"1f69c02f-c68f-4445-b5ff-8814fbd3412d\",\n \"preAuthSuccess\" : false,\n \"statusCode\" : \"1\"\n },\n \"contextInfo\" : {\n \"availablePaths\" : [{\n \"path\" : \"OrderReview-Shipping-Payment-Agreement\"\n  }\n   ],\n  \"processAction\" : \"\",\n \"processStep\" : \"OrderReview-Shipping-Payment-Agreement\",\n  \"callReason\" : \"SalesOrderPurchase\"\n    },\n \"caseId\" : \"SOP-3335332-E01\",\n\"customerInfo\" : {\n \"cartCreator\" : \"4029847575\",\n  \"processingMTN\" : \"newLine1\",\n \"accountNumber\" : \"0283134872-00001\"\n },\n   \"processMTNList\" : [{\n   \"mtn\" : \"newLine1\",\n\"completedprocessSteps\" : [\"NumberSelection\", \"Accessories\", \"NumberSelection\", \"NumberSelection\", \"ShoppingCart\", \"ContactInfo\", \"ShippingOptions\", \"ShippingOptions\", \"AppointmentSchedule\"]\n }\n]\n }\n  }\n }\n}\n";
        CartWithDateUIRequest request = mapper.readValue(requestString, CartWithDateUIRequest.class);
        CartWithDatePegaResponse expectedResponse = mapper.readValue(responseString, CartWithDatePegaResponse.class);
        try {
            when(services.updateCartWithDate(Mockito.any())).thenThrow(new SOEHTTPException(404, "Some Exception!"));
        } catch (SOEHTTPException e) {
            e.printStackTrace();
        }

        Mono<CartWithDatePegaResponse>  response = cartWithDateServiceBpmHelper.saveCartWithDate(request);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();

    }

    @Test
    public void saveCartWithDateErrorTest() throws IOException
    {
        String requestString = "{\n \"context\": {\n \"caseId\": \"SOP-3597615-E01\",\n\"contextInfo\": {\n \"callReason\": \"SalesOrderPurchase\",\n \"processStep\": \"OrderReview\",\n\"processAction\": \"UpdateScheduleAppointment\",\n \"intent\": \"MOVER\"\n},\n\"customerInfo\": {\n\"accountNumber\": \"0389467727-00001\",\n\"cartCreator\": \"6072376627\",\n\"processingMTN\": \"8136958775\",\n \"registerNumber\": 0\n},\n\"cartInfo\": {\n\"cartId\": \"cfe0a112-c547-41a6-bfde-7e0688d7a774\",\n  \"itemType\": \"SCHEDULE5GAPPT\",\n\"intendType\": \"MOVER\",\n\"moversInfo\": {\n\"moveInDate\": \"07/20/2021\",\n  \"moveOutDate\": \"07/30/2021\"\n }\n }\n }\n}";
        String responseString = "{\n \"serviceHeader\" : {\n \"statusMsg\" : \"SUCCESS\",\n \"sessionId\" : \"\",\n \"serviceName\" : \"SalesOrderPurchase\",\n \"userId\" : \"\",\n\"statusCode\" : \"00\"\n },\n \"serviceBody\" : {\n \"serviceResponse\" : {\n\"context\" : {\n\"cartInfo\" : {\n  \"statusMsg\" : \"Success\",\n\"cartId\" : \"1f69c02f-c68f-4445-b5ff-8814fbd3412d\",\n \"preAuthSuccess\" : false,\n \"statusCode\" : \"1\"\n },\n \"contextInfo\" : {\n \"availablePaths\" : [{\n \"path\" : \"OrderReview-Shipping-Payment-Agreement\"\n  }\n   ],\n  \"processAction\" : \"\",\n \"processStep\" : \"OrderReview-Shipping-Payment-Agreement\",\n  \"callReason\" : \"SalesOrderPurchase\"\n    },\n \"caseId\" : \"SOP-3335332-E01\",\n\"customerInfo\" : {\n \"cartCreator\" : \"4029847575\",\n  \"processingMTN\" : \"newLine1\",\n \"accountNumber\" : \"0283134872-00001\"\n },\n   \"processMTNList\" : [{\n   \"mtn\" : \"newLine1\",\n\"completedprocessSteps\" : [\"NumberSelection\", \"Accessories\", \"NumberSelection\", \"NumberSelection\", \"ShoppingCart\", \"ContactInfo\", \"ShippingOptions\", \"ShippingOptions\", \"AppointmentSchedule\"]\n }\n]\n }\n  }\n }\n}\n";
        CartWithDateUIRequest request = mapper.readValue(requestString, CartWithDateUIRequest.class);
        CartWithDatePegaResponse expectedResponse = mapper.readValue(responseString, CartWithDatePegaResponse.class);

        SOEErrorHolder soeErrorHolder = new SOEErrorHolder();
        List<SOEError> erros = new ArrayList<>();
        SOEError soeError = new SOEError();
        soeError.setId("1234");
        soeError.setDebug_id("test");
        soeError.setMessage("BAD GATEWAY");
        soeError.setNamespace("hello");
        soeError.setName("404");
        erros.add(soeError);
        soeErrorHolder.setErrors(erros);
        SOEHTTPException soehttpException = new SOEHTTPException(500, soeErrorHolder);
        Mono<CartWithDatePegaResponse> pegaResponse1 = Mono.error(soehttpException);

//        SOEHTTPException exception = new SOEHTTPException();
        List<Error> errors = new ArrayList<>();
        CartWithDatePegaResponse  errorResponse= new CartWithDatePegaResponse();

        Error error = new Error();
        error.setMessage("BAD GATEWAY");
        error.setId("1234");
        error.setNamespace("hello");
        error.setName("404");
        error.setDebug_id("test");
        errors.add(error);
        errorResponse.setErrors(errors);

        try {
            when(services.updateCartWithDate(Mockito.any())).thenReturn(pegaResponse1);
        } catch (SOEHTTPException e) {
            e.printStackTrace();
        }

        Mono<CartWithDatePegaResponse>  response = cartWithDateServiceBpmHelper.saveCartWithDate(request);
        StepVerifier.create(response)
                .expectNext(errorResponse)
                .verifyComplete();

    }
//    @Test
//    public void getPegaFormatAaptInfoNotNullTest() throws IOException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
//        CartWithDatePegaReqApptInfo request = new CartWithDatePegaReqApptInfo();
//        request.setHomePhone("9835787152");
//        request.setPrimaryPhoneType("NA");
//        request.setPreferredContactType("NA");
//        request.setInstallationFloor("NA");
//        request.setEmailAddress("manish@gmail.com");
//        request.setFirstName("Jack");
//        request.setLastName(null);
//        request.setInstallationFloor("2nd");
//        request.setLanguagePref("english");
//
//        String req = mapper.writeValueAsString(request);
//        Method method = cartWithDateServiceBpmHelper.getClass().getDeclaredMethod("getPegaFormatAaptInfoNotNull", CartWithDatePegaReqApptInfo.class);
//        method.setAccessible(true);
//        CartWithDatePegaReqApptInfo response = (CartWithDatePegaReqApptInfo) method.invoke(cartWithDateServiceBpmHelper, request);
//        org.junit.Assert.assertEquals(response.getHomePhone(), request.getHomePhone());
//        org.junit.Assert.assertEquals(null, request.getLastName());
//        org.junit.Assert.assertEquals(response.getInstallationFloor(), request.getInstallationFloor());
//        org.junit.Assert.assertEquals(request.getLanguagePref(), response.getLanguagePref());
//
//    }
//    @Test
//    public void getInstallApptNotNullTest() throws IOException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
//        CartWithDatePegaReqApptInfo request = new CartWithDatePegaReqApptInfo();
//        CartWithDateUIInstallApptSelectedDateInfo cartWithDateUIInstallApptSelectedDateInfo = new CartWithDateUIInstallApptSelectedDateInfo();
//        request.setInstallApptSelectedDateInfo(cartWithDateUIInstallApptSelectedDateInfo);
//        request.getInstallApptSelectedDateInfo().setAvailableDate("09 JUN 2022");
//        request.getInstallApptSelectedDateInfo().setAvailableDay("SUNDAY");
//        request.getInstallApptSelectedDateInfo().setAvailableType("NA");
//        request.getInstallApptSelectedDateInfo().setServiceProviderAccount("26354623564");
//        request.getInstallApptSelectedDateInfo().setServiceProviderName("verizon");
//        request.getInstallApptSelectedDateInfo().setSlotLength("32");
//        Method method = cartWithDateServiceBpmHelper.getClass().getDeclaredMethod("getInstallApptNotNull", CartWithDatePegaReqApptInfo.class);
//        method.setAccessible(true);
//        CartWithDateUIInstallApptSelectedDateInfo response = (CartWithDateUIInstallApptSelectedDateInfo) method.invoke(cartWithDateServiceBpmHelper, request);
//        org.junit.Assert.assertEquals(response.getAvailableDate(),
//                request.getInstallApptSelectedDateInfo().getAvailableDate());
//    }

//    @Test
//    public void getScheduleAppointmentInfoNotNull() throws IOException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
//        String requestString = "{\n \"context\": {\n \"caseId\": \"SOP-3597615-E01\",\n\"contextInfo\": {\n \"callReason\": \"SalesOrderPurchase\",\n \"processStep\": \"OrderReview\",\n\"processAction\": \"UpdateScheduleAppointment\",\n \"intent\": \"MOVER\"\n},\n\"customerInfo\": {\n\"accountNumber\": \"0389467727-00001\",\n\"cartCreator\": \"6072376627\",\n\"processingMTN\": \"8136958775\",\n \"registerNumber\": 0\n},\n\"cartInfo\": {\n\"cartId\": \"cfe0a112-c547-41a6-bfde-7e0688d7a774\",\n  \"itemType\": \"SCHEDULE5GAPPT\",\n\"intendType\": \"MOVER\",\n\"moversInfo\": {\n\"moveInDate\": \"07/20/2021\",\n  \"moveOutDate\": \"07/30/2021\"\n }\n }\n }\n}";
//        String responseString = "{\n \"serviceHeader\" : {\n \"statusMsg\" : \"SUCCESS\",\n \"sessionId\" : \"\",\n \"serviceName\" : \"SalesOrderPurchase\",\n \"userId\" : \"\",\n\"statusCode\" : \"00\"\n },\n \"serviceBody\" : {\n \"serviceResponse\" : {\n\"context\" : {\n\"cartInfo\" : {\n  \"statusMsg\" : \"Success\",\n\"cartId\" : \"1f69c02f-c68f-4445-b5ff-8814fbd3412d\",\n \"preAuthSuccess\" : false,\n \"statusCode\" : \"1\"\n },\n \"contextInfo\" : {\n \"availablePaths\" : [{\n \"path\" : \"OrderReview-Shipping-Payment-Agreement\"\n  }\n   ],\n  \"processAction\" : \"\",\n \"processStep\" : \"OrderReview-Shipping-Payment-Agreement\",\n  \"callReason\" : \"SalesOrderPurchase\"\n    },\n \"caseId\" : \"SOP-3335332-E01\",\n\"customerInfo\" : {\n \"cartCreator\" : \"4029847575\",\n  \"processingMTN\" : \"newLine1\",\n \"accountNumber\" : \"0283134872-00001\"\n },\n   \"processMTNList\" : [{\n   \"mtn\" : \"newLine1\",\n\"completedprocessSteps\" : [\"NumberSelection\", \"Accessories\", \"NumberSelection\", \"NumberSelection\", \"ShoppingCart\", \"ContactInfo\", \"ShippingOptions\", \"ShippingOptions\", \"AppointmentSchedule\"]\n }\n]\n }\n  }\n }\n}\n";
//        CartWithDateUIRequest request = mapper.readValue(requestString, CartWithDateUIRequest.class);
//        CartWithDatePegaReqScheduleAppointmentInfo scheduleAppointmentInfo = new CartWithDatePegaReqScheduleAppointmentInfo();
//        scheduleAppointmentInfo.setCartLineMtn("13133432");
//        request.getCartWithDateContext().getCartInfo().setScheduleAppointmentInfo(scheduleAppointmentInfo);
//        Method method = cartWithDateServiceBpmHelper.getClass().getDeclaredMethod("getScheduleAppointmentInfoNotNull", CartWithDateUIRequest.class);
//        method.setAccessible(true);
//        CartWithDatePegaReqScheduleAppointmentInfo response = (CartWithDatePegaReqScheduleAppointmentInfo) method.invoke(cartWithDateServiceBpmHelper, request);
//        org.junit.Assert.assertEquals(response.getCartLineMtn(),
//                request.getCartWithDateContext().getCartInfo().getScheduleAppointmentInfo().getCartLineMtn());
//    }
//
//    @Test
//    public void getMoversInfoNull() throws IOException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
//        CartWithDateUIMoversInfo moversInfo = new CartWithDateUIMoversInfo();
//        moversInfo.setMoveInDate("");
//        moversInfo.setMoveOutDate("");
//        Method method = cartWithDateServiceBpmHelper.getClass().getDeclaredMethod("getMoversInfoNull");
//        method.setAccessible(true);
//        CartWithDateUIMoversInfo response = (CartWithDateUIMoversInfo) method.invoke(cartWithDateServiceBpmHelper);
//        org.junit.Assert.assertEquals(response.getMoveInDate(),
//                moversInfo.getMoveInDate());
//        org.junit.Assert.assertEquals(response.getMoveOutDate(),
//                moversInfo.getMoveOutDate());
//    }

    @Test
    public void getContextInfoTest() {
        CartWithDateUIRequest CartWithDateUIRequestObj = new CartWithDateUIRequest();
        CartWithDateUIRequestObj.setCartWithDateContext(new CartWithDateUIContext());
        CartWithDateUIRequestObj.getCartWithDateContext().setContextInfo(new CartWithDatePegaReqContextInfo());
        CartWithDateUIRequestObj.getCartWithDateContext().getContextInfo().setCallReason(null);
        CartWithDateUIRequestObj.getCartWithDateContext().getContextInfo().setProcessStep(null);
        CartWithDateUIRequestObj.getCartWithDateContext().getContextInfo().setProcessAction(null);
        CartWithDateUIRequestObj.getCartWithDateContext().getContextInfo().setIntent(null);
        CartWithDateUIRequestObj.getCartWithDateContext().setCartInfo(new CartWithDateUICartInfo());
        CartWithDateUIRequestObj.getCartWithDateContext().getCartInfo().setMoversInfo(null);
        CartWithDateUIRequestObj.getCartWithDateContext().getCartInfo().setScheduleAppointmentInfo(new CartWithDatePegaReqScheduleAppointmentInfo());
        CartWithDateUIRequestObj.getCartWithDateContext().getCartInfo().getScheduleAppointmentInfo().setCartLineMtn(null);
        CartWithDateUIRequestObj.getCartWithDateContext().setCustomerInfo(new CustomerInfo());
        CartWithDatePegaReqApptInfo CartWithDatePegaReqApptInfoObj = new CartWithDatePegaReqApptInfo();
        CartWithDatePegaReqApptInfoObj.setHomePhone(null);
        CartWithDatePegaReqApptInfoObj.setPrimaryPhoneType(null);
        CartWithDatePegaReqApptInfoObj.setPreferredContactType(null);
        CartWithDatePegaReqApptInfoObj.setEmailAddress(null);
        CartWithDatePegaReqApptInfoObj.setFirstName(null);
        CartWithDatePegaReqApptInfoObj.setLastName(null);
        CartWithDatePegaReqApptInfoObj.setInstallationFloor(null);
        CartWithDatePegaReqApptInfoObj.setLanguagePref(null);
        CartWithDatePegaReqApptInfoObj.setCustomerInstructions(null);
        CartWithDatePegaReqApptInfoObj.setEventCorrelationId(null);
        CartWithDateUIInstallApptSelectedDateInfo CartWithDateUIInstallApptSelectedDateInfoObj = new CartWithDateUIInstallApptSelectedDateInfo();
        CartWithDateUIInstallApptSelectedDateInfoObj.setAvailableDate(null);
        CartWithDateUIInstallApptSelectedDateInfoObj.setAvailableDay(null);
        CartWithDateUIInstallApptSelectedDateInfoObj.setAvailableType(null);
        CartWithDateUIInstallApptSelectedDateInfoObj.setServiceProviderAccount(null);
        CartWithDateUIInstallApptSelectedDateInfoObj.setServiceProviderName(null);
        CartWithDateUIInstallApptSelectedDateInfoObj.setSlotLength(null);
        CartWithDateUIInstallApptSelectedDateInfoObj.setSlotStartTime(null);
        CartWithDatePegaReqApptInfoObj.setInstallApptSelectedDateInfo(CartWithDateUIInstallApptSelectedDateInfoObj);
        CartWithDateUIRequestObj.getCartWithDateContext().getCartInfo().getScheduleAppointmentInfo().setApptInfo(CartWithDatePegaReqApptInfoObj);
        cartWithDateServiceBpmHelper.formatSaveApptRequest(CartWithDateUIRequestObj);
        CartWithDatePegaReqApptInfoObj.setInstallApptSelectedDateInfo(null);
        CartWithDateUIRequestObj.getCartWithDateContext().getCartInfo().getScheduleAppointmentInfo().setApptInfo(CartWithDatePegaReqApptInfoObj);
        cartWithDateServiceBpmHelper.formatSaveApptRequest(CartWithDateUIRequestObj);
        CartWithDateUIRequestObj.getCartWithDateContext().getCartInfo().getScheduleAppointmentInfo().setApptInfo(null);
        Assert.assertNotNull( cartWithDateServiceBpmHelper.formatSaveApptRequest(CartWithDateUIRequestObj));
    }
}