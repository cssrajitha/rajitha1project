package onevz.soe.cart.service.test.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.responses.RTDRedisData;
import onevz.soe.cart.util.CartCxpRequestUtil;
import onevz.soe.cart.util.RetrieveCartErrorsUtil;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@WebFluxTest(RetrieveCartErrorsUtil.class)
public class RetrieveCartErrorsUtilTest {

    @InjectMocks
    RetrieveCartErrorsUtil util;

    @Test
    public void handleRetrieveCartRequestErrorsTest() {
        ErrorResponse errorResponse=util.handleRetrieveCartRequestErrors(getErrorResponse());
        Assert.assertEquals("3000",errorResponse.getErrors().get(0).getId());

        errorResponse.setErrors(null);
        errorResponse=util.handleRetrieveCartRequestErrors(errorResponse);
        Assert.assertNotNull(errorResponse);
    }

    private ErrorResponse getErrorResponse(){
        ErrorResponse errResp= new ErrorResponse();
        CartError cartError=new CartError();
        cartError.setErrorCategory("BUSINESSERR");
        cartError.setId("3000");
        errResp.setErrors(List.of(cartError));
        return errResp;
    }

}
