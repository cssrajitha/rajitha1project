package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.net.URI;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.controller.AccessoryFinancingOfferController;
import onevz.soe.cart.helper.AccessoryFinancingOffersHelper;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.AccessoryFinancingOffersUIRequest;
import onevz.soe.cart.ui.responses.AccessoryFinancingOffersUIResponse;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.net.URI;
import java.util.Arrays;

import org.junit.Test;
import org.junit.runner.RunWith;
import static org.mockito.Mockito.when;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.bind.WebDataBinder;
import onevz.soe.cart.ui.requests.AffirmFinancingUIRequest;
import onevz.soe.cart.ui.responses.AffirmFinancingUIResponse;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(AccessoryFinancingOfferController.class)
public class AccessoryFinancingOfferControllerTest {

    @Autowired
    private AccessoryFinancingOfferController controller;

    @Autowired
    private ObjectMapper mapper;

    @MockBean
    private AccessoryFinancingOffersHelper accessoryFinancingOffersHelper;

    @Test
    public void initBinderByNameTest() {
        WebDataBinder binder = new WebDataBinder(null);
        controller.initBinderByName(binder);
        assertNotNull(binder.getDisallowedFields());
    }

    @Test
    public void accessoryFinancingOffersTest() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"cartCreator\":\"6097319501\",\"processingMTN\":\"6097319501\",\"processStep\":\"VerizonVisaCardAFO\",\"intendType\":\"EUP\",\"action\":\"UPDATE\"},\"offerAccepted\":true,\"disclosureAgreementSent\":false}\t";
        AccessoryFinancingOffersUIRequest request = mapper.readValue(requestString, AccessoryFinancingOffersUIRequest.class);
        String responseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-CARE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.06.10.13.40.12-391.1961291124465\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"availablePaths\":[{\"path\":\"VerizonVisaCardAfo\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"VerizonVisaCardAfo\",\"processAction\":\"updateAccessoryFinancingInfo\"},\"customerInfo\":{\"accountNumber\":\"0001448743-00001\",\"cartCreator\":\"6097319501\",\"processingMTN\":\"6097319501\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"5338b2e4-e1a0-4184-9054-d189819de96d\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"preAuthSuccess\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false},\"processMTNList\":[{\"mtn\":\"6097319501\",\"completedprocessSteps\":[]}],\"caseId\":\"SOP-7667518-E01\"}}}}\n";
        AccessoryFinancingOffersUIResponse response = mapper.readValue(responseString, AccessoryFinancingOffersUIResponse.class);
        URI url = URI.create("http://localhost/nse/updateAFOInfo");
        HttpHeaders headers = new HttpHeaders();
        headers.add("channelId", "VZW-DOTCOM");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        ServerHttpResponse httpResponse = null;
        when(accessoryFinancingOffersHelper.updateAccessoryFinancingOffers(request)).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse =  controller.accessoryFinancingOffers(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void accessoryFinancingOffersWithoutChannelIdTest() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"cartCreator\":\"6097319501\",\"processingMTN\":\"6097319501\",\"processStep\":\"VerizonVisaCardAFO\",\"intendType\":\"EUP\",\"action\":\"UPDATE\"},\"offerAccepted\":true,\"disclosureAgreementSent\":false}\t";
        AccessoryFinancingOffersUIRequest request = mapper.readValue(requestString, AccessoryFinancingOffersUIRequest.class);
        String responseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-CARE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.06.10.13.40.12-391.1961291124465\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"availablePaths\":[{\"path\":\"VerizonVisaCardAfo\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"VerizonVisaCardAfo\",\"processAction\":\"updateAccessoryFinancingInfo\"},\"customerInfo\":{\"accountNumber\":\"0001448743-00001\",\"cartCreator\":\"6097319501\",\"processingMTN\":\"6097319501\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"5338b2e4-e1a0-4184-9054-d189819de96d\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"preAuthSuccess\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false},\"processMTNList\":[{\"mtn\":\"6097319501\",\"completedprocessSteps\":[]}],\"caseId\":\"SOP-7667518-E01\"}}}}\n";
        AccessoryFinancingOffersUIResponse response = mapper.readValue(responseString, AccessoryFinancingOffersUIResponse.class);
        URI url = URI.create("http://localhost/nse/updateAFOInfo");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(accessoryFinancingOffersHelper.updateAccessoryFinancingOffers(request)).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse =  controller.accessoryFinancingOffers(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void accessoryFinancingOffersErrorTest() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"cartCreator\":\"6097319501\",\"processingMTN\":\"6097319501\",\"processStep\":\"VerizonVisaCardAFO\",\"action\":\"UPDATE\"},\"offerAccepted\":true,\"disclosureAgreementSent\":false}\t";
        AccessoryFinancingOffersUIRequest request = mapper.readValue(requestString, AccessoryFinancingOffersUIRequest.class);
        String responseString = "{\"errors\":[{\"namespace\":\"CartService\",\"details\":[{\"field\":\"cartId\",\"value\":\"null/blank\",\"issue\":\"cartId is/are missing.\",\"location\":\"request\"},{\"field\":\"caseId\",\"value\":\"null/blank\",\"issue\":\"caseId is/are missing.\",\"location\":\"request\"}],\"id\":\"701\",\"message\":\"This session has ended. Please reprocess to proceed\",\"name\":\" REQUEST VALIDATION ERROR\"}]}\n";
        AccessoryFinancingOffersUIResponse response = mapper.readValue(responseString, AccessoryFinancingOffersUIResponse.class);
        URI url = URI.create("http://localhost/nse/updateAFOInfo");
        HttpHeaders headers = new HttpHeaders();
        headers.add("channelId", "VZW-DOTCOM");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        ServerHttpResponse httpResponse = null;
        when(accessoryFinancingOffersHelper.updateAccessoryFinancingOffers(request)).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse =  controller.accessoryFinancingOffers(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void accessoryFinancingOffersTest2() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"cartCreator\":\"6097319501\",\"processingMTN\":\"6097319501\",\"processStep\":\"VerizonVisaCardAFO\",\"intendType\":\"EUP\",\"action\":\"UPDATE\"},\"offerAccepted\":true,\"disclosureAgreementSent\":false}\t";
        AccessoryFinancingOffersUIRequest request = mapper.readValue(requestString, AccessoryFinancingOffersUIRequest.class);
        String responseString = "{\"errors\":[{\"namespace\":\"CartService\",\"details\":[{\"field\":\"cartId\",\"value\":\"null/blank\",\"issue\":\"cartId is/are missing.\",\"location\":\"request\"},{\"field\":\"caseId\",\"value\":\"null/blank\",\"issue\":\"caseId is/are missing.\",\"location\":\"request\"}],\"id\":\"701\",\"message\":\"This session has ended. Please reprocess to proceed\",\"name\":\" REQUEST VALIDATION ERROR\"}]}\n";
        AccessoryFinancingOffersUIResponse response = mapper.readValue(responseString, AccessoryFinancingOffersUIResponse.class);
        URI url = URI.create("http://localhost/nse/updateAFOInfo");
        HttpHeaders headers = new HttpHeaders();
        headers.add("channelId", "VZW-DOTCOM");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.NOT_FOUND);
        when(accessoryFinancingOffersHelper.updateAccessoryFinancingOffers(request)).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse =  controller.accessoryFinancingOffers(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void accessoryFinancingOffersTest3() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"cartCreator\":\"6097319501\",\"processingMTN\":\"6097319501\",\"processStep\":\"VerizonVisaCardAFO\",\"intendType\":\"EUP\",\"action\":\"UPDATE\"},\"offerAccepted\":true,\"disclosureAgreementSent\":false}\t";
        AccessoryFinancingOffersUIRequest request = mapper.readValue(requestString, AccessoryFinancingOffersUIRequest.class);
        String responseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-CARE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.06.10.13.40.12-391.1961291124465\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"availablePaths\":[{\"path\":\"VerizonVisaCardAfo\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"VerizonVisaCardAfo\",\"processAction\":\"updateAccessoryFinancingInfo\"},\"customerInfo\":{\"accountNumber\":\"0001448743-00001\",\"cartCreator\":\"6097319501\",\"processingMTN\":\"6097319501\",\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"6097319501\",\"completedprocessSteps\":[]}],\"caseId\":\"SOP-7667518-E01\"}}}}";
        AccessoryFinancingOffersUIResponse response = mapper.readValue(responseString, AccessoryFinancingOffersUIResponse.class);
        URI url = URI.create("http://localhost/nse/updateAFOInfo");
        HttpHeaders headers = new HttpHeaders();
        headers.add("channelId", "VZW-DOTCOM");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        ServerHttpResponse httpResponse = null;
        when(accessoryFinancingOffersHelper.updateAccessoryFinancingOffers(request)).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse =  controller.accessoryFinancingOffers(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }
    
    @Test
    public void updateAffirmStatusTest() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"processStep\":\"OrderReview-Shipping\",\"processAction\":\"UpdateAffirm\",\"intendType\":\"EUP\",\"action\":\"UPDATE\"},\"offerRejected\":true,\"channelId\":\"OMNI_RETAIL\"}";
        AffirmFinancingUIRequest request = mapper.readValue(requestString, AffirmFinancingUIRequest.class);
        String responseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-ECOM\", \"statusMsg\": \"PEGA generated message\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"sessionId\": \"\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"0\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \" SOP-1583186-DEV3\", \"customerInfo\" : { \"accountNumber\": \"07893451230-00001\", \"cartCreator\":\"2515813861\", \"processingMTN\": \"2515813860\" }, \"cartInfo\": { \"cartId\": \"cff57848-8bbd-4c27-9afa-5bfd39c2b5ad\", \"statusCode\": 1, \"statusMsg\": \"SUCCESS\" } } , \"contextInfo\": { \"processAction\": \"\", \"processStep\": \"ShoppingCart\", \"availablePaths\":[ { \"path\":\"ShoppingCart`\" }], \"callReason\": \" SalesOrderPurchase \" } } } }";
        AffirmFinancingUIResponse response = mapper.readValue(responseString, AffirmFinancingUIResponse.class);
        URI url = URI.create("http://localhost/nse/updateAffirmStatus");
        HttpHeaders headers = new HttpHeaders();
        headers.add("channelId", "OMNI-RETAIL");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        ServerHttpResponse httpResponse = null;
        when(accessoryFinancingOffersHelper.updateAffirmFinancingStatus(request)).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse =  controller.updateAffirmStatus(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }
    
    @Test
    public void updateAffirmStatusWithoutChannelIdTest() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"processStep\":\"OrderReview-Shipping\",\"processAction\":\"UpdateAffirm\",\"intendType\":\"EUP\",\"action\":\"UPDATE\"},\"offerRejected\":true,\"channelId\":\"OMNI_RETAIL\"}";
        AffirmFinancingUIRequest request = mapper.readValue(requestString, AffirmFinancingUIRequest.class);
        String responseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-ECOM\", \"statusMsg\": \"PEGA generated message\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"sessionId\": \"\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"0\" }, \"serviceBodyy\": { \"serviceResponse\": { \"context\": { \"caseId\": \" SOP-1583186-DEV3\", \"customerInfo\" : { \"accountNumber\": \"07893451230-00001\", \"cartCreator\":\"2515813861\", \"processingMTN\": \"2515813860\" }, \"cartInfo\": { \"cartId\": \"cff57848-8bbd-4c27-9afa-5bfd39c2b5ad\", \"statusCode\": 1, \"statusMsg\": \"SUCCESS\" } } , \"contextIinfo\": { \"processAction\": \"\", \"processStep\": \"ShoppingCart\", \"availablePaths\":[ { \"path\":\"ShoppingCart`\" }], \"callReason\": \" SalesOrderPurchase \" } } } }";
        AffirmFinancingUIResponse response = mapper.readValue(responseString, AffirmFinancingUIResponse.class);
        URI url = URI.create("http://localhost/updateAffirmStatus");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(accessoryFinancingOffersHelper.updateAffirmFinancingStatus(request)).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse =  controller.updateAffirmStatus(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }
    
    @Test
    public void updateAffirmStatusErrorTest() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"processwStep\":\"OrderReview-Shipping\",\"proceessAction\":\"UpdateAffirm\",\"intendtType\":\"EUP\",\"actioon\":\"UPDATE\"},\"offerRejected\":true,\"offerAccepted\":false}";
        AffirmFinancingUIRequest request = mapper.readValue(requestString, AffirmFinancingUIRequest.class);
        URI url = URI.create("http://localhost/nse/updateAffirmStatus");
        HttpHeaders headers = new HttpHeaders();
        headers.add("channelId", "OMNI_TELESALES");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        ServerHttpResponse httpResponse = null;
        Mono<ResponseEntity<GenericResponse>> controllerResponse =  controller.updateAffirmStatus(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).consumeNextWith(response -> assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode())).expectComplete().verify();
    }
    
    @Test
    public void updateAffirmStatusPegaErrorTest() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"processStep\":\"OrderReview-Shipping\",\"processAction\":\"UpdateAffirm\",\"intendType\":\"EUP\",\"action\":\"UPDATE\"},\"offerRejected\":true,\"channelId\":\"OMNI_RETAIL\"}";
        AffirmFinancingUIRequest request = mapper.readValue(requestString, AffirmFinancingUIRequest.class);
        String responseString = "{ \"errors\": [ { \"namespace\": \"cxp_pega_bpm\", \"name\": \"VALIDATION_ERROR\", \"id\": \"1000\", \"debug_id\": \"20220720T120026.630 GMT||pega-82c9fa5a-3447-4d80-b85f-012bbd75798b-07202022-050026-624|\", \"message\": \"Cart accessed by another user or customer, please reprocess\", \"severity\": \"High\", \"errorCategory\": \"BUSINESSERR\", \"details\": [ { \"field\": \"Call Reason\", \"value\": \"\", \"issue\": \"Invalid Call Reason\", \"location\": \"contextInfo\" } ] } ] }";
        AffirmFinancingUIResponse response = mapper.readValue(responseString, AffirmFinancingUIResponse.class);
        URI url = URI.create("http://localhost/nse/updateAffirmStatus");
        HttpHeaders headers = new HttpHeaders();
        headers.add("channelId", "OMNI-RETAIL");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.NOT_FOUND);
        when(accessoryFinancingOffersHelper.updateAffirmFinancingStatus(request)).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse =  controller.updateAffirmStatus(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }
    
    @Test
    public void updateAffirmCartIdError() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"processStep\":\"OrderReview-Shipping\",\"processAction\":\"UpdateAffirm\",\"intendType\":\"EUP\",\"action\":\"UPDATE\"},\"offerRejected\":true,\"channelId\":\"OMNI_RETAIL\"}";
        AffirmFinancingUIRequest request = mapper.readValue(requestString, AffirmFinancingUIRequest.class);
        String responseString = "{\"errors\":[{\"namespace\":\"CartService\",\"details\":[{\"field\":\"cartId\",\"value\":\"null/blank\",\"issue\":\"cartId is/are missing.\",\"location\":\"request\"},{\"field\":\"caseId\",\"value\":\"null/blank\",\"issue\":\"caseId is/are missing.\",\"location\":\"request\"}],\"id\":\"701\",\"message\":\"This session has ended. Please reprocess to proceed\",\"name\":\" REQUEST VALIDATION ERROR\"}]}\n";
        AffirmFinancingUIResponse response = mapper.readValue(responseString, AffirmFinancingUIResponse.class);
        URI url = URI.create("http://localhost/updateAffirmStatus");
        HttpHeaders headers = new HttpHeaders();
        headers.add("channelId", "VZW-RETAIL");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.NOT_FOUND);
        when(accessoryFinancingOffersHelper.updateAffirmFinancingStatus(request)).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse =  controller.updateAffirmStatus(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updateAffirmStatusNullCheck() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"processStep\":\"OrderReview-Shipping\",\"processAction\":\"UpdateAffirm\",\"intendType\":\"EUP\",\"action\":\"UPDATE\"},\"offerRejected\":true,\"channelId\":\"OMNI_RETAIL\"}";
        AffirmFinancingUIRequest request = mapper.readValue(requestString, AffirmFinancingUIRequest.class);
        String responseString = "{ \"serviceHeader\": { \"clientId\": \"VZW-ECOM\", \"statusMsg\": \"PEGA generated message\", \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\", \"sessionId\": \"\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"0\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \" SOP-1583186-DEV3\", \"customerInfo\" : { \"accountNumber\": \"07893451230-00001\", \"cartCreator\":\"2515813861\", \"processingMTN\": \"2515813860\" }, \"cartInfo\": { \"cartId\": \"cff57848-8bbd-4c27-9afa-5bfd39c2b5ad\", \"statusCode\": 1, \"statusMsg\": \"SUCCESS\" } } , \"contextInfo\": { \"processAction\": \"\", \"processStep\": \"ShoppingCart\", \"availablePaths\":[ { \"path\":\"ShoppingCart`\" }], \"callReason\": \" SalesOrderPurchase \" } } } }";
        AffirmFinancingUIResponse response = mapper.readValue(responseString, AffirmFinancingUIResponse.class);
        URI url = URI.create("http://localhost/nse/updateAffirmStatus");
        HttpHeaders headers = new HttpHeaders();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        headers.add("channelId", "OMNI-RETAIL");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        when(accessoryFinancingOffersHelper.updateAffirmFinancingStatus(request)).thenReturn(Mono.just(response));
        StepVerifier.create(controller.updateAffirmStatus(httpHeader, httpResponse, request)).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        response.setErrors(Arrays.asList(new CartError()));
        httpResponse.setStatusCode(HttpStatus.NOT_FOUND);
        response.getServiceBody().getServiceResponse().getContext().setCartInfo(null);
        when(accessoryFinancingOffersHelper.updateAffirmFinancingStatus(request)).thenReturn(Mono.just(response));
        StepVerifier.create(controller.updateAffirmStatus(httpHeader, httpResponse, request)).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        response.setErrors(null);
        httpResponse.setStatusCode(HttpStatus.OK);
        response.getServiceBody().getServiceResponse().getContext().setCartInfo(null);
        when(accessoryFinancingOffersHelper.updateAffirmFinancingStatus(request)).thenReturn(Mono.just(response));
        StepVerifier.create(controller.updateAffirmStatus(httpHeader, httpResponse, request)).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        response.setErrors(null);
        httpResponse.setStatusCode(HttpStatus.NOT_FOUND);
        response.getServiceBody().getServiceResponse().getContext().setCartInfo(null);
        when(accessoryFinancingOffersHelper.updateAffirmFinancingStatus(request)).thenReturn(Mono.just(response));
        StepVerifier.create(controller.updateAffirmStatus(httpHeader, httpResponse, request)).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        response.getServiceBody().getServiceResponse().setContext(null);
        when(accessoryFinancingOffersHelper.updateAffirmFinancingStatus(request)).thenReturn(Mono.just(response));
        StepVerifier.create(controller.updateAffirmStatus(httpHeader, httpResponse, request)).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        response.getServiceBody().setServiceResponse(null);
        when(accessoryFinancingOffersHelper.updateAffirmFinancingStatus(request)).thenReturn(Mono.just(response));
        StepVerifier.create(controller.updateAffirmStatus(httpHeader, httpResponse, request)).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        response.setServiceBody(null);
        when(accessoryFinancingOffersHelper.updateAffirmFinancingStatus(request)).thenReturn(Mono.just(response));
        StepVerifier.create(controller.updateAffirmStatus(httpHeader, httpResponse, request)).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void accessoryFinancingOffersNullCheck() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"cartCreator\":\"6097319501\",\"processingMTN\":\"6097319501\",\"processStep\":\"VerizonVisaCardAFO\",\"intendType\":\"EUP\",\"action\":\"UPDATE\"},\"offerAccepted\":true,\"disclosureAgreementSent\":false}\t";
        AccessoryFinancingOffersUIRequest request = mapper.readValue(requestString, AccessoryFinancingOffersUIRequest.class);
        String responseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-CARE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.06.10.13.40.12-391.1961291124465\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"availablePaths\":[{\"path\":\"VerizonVisaCardAfo\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"VerizonVisaCardAfo\",\"processAction\":\"updateAccessoryFinancingInfo\"},\"customerInfo\":{\"accountNumber\":\"0001448743-00001\",\"cartCreator\":\"6097319501\",\"processingMTN\":\"6097319501\",\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"6097319501\",\"completedprocessSteps\":[]}],\"caseId\":\"SOP-7667518-E01\"}}}}";
        AccessoryFinancingOffersUIResponse response = mapper.readValue(responseString, AccessoryFinancingOffersUIResponse.class);
        URI url = URI.create("http://localhost/nse/updateAFOInfo");
        HttpHeaders headers = new HttpHeaders();
        headers.add("channelId", "VZW-DOTCOM");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        MockServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        headers.add("channelId", "OMNI-RETAIL");
        when(accessoryFinancingOffersHelper.updateAccessoryFinancingOffers(request)).thenReturn(Mono.just(response));
        StepVerifier.create(controller.accessoryFinancingOffers(httpHeader, httpResponse, request)).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        response.setErrors(Arrays.asList(new CartError()));
        httpResponse.setStatusCode(HttpStatus.NOT_FOUND);
        response.getServiceBody().getServiceResponse().getContext().setCartInfo(null);
        when(accessoryFinancingOffersHelper.updateAccessoryFinancingOffers(request)).thenReturn(Mono.just(response));
        StepVerifier.create(controller.accessoryFinancingOffers(httpHeader, httpResponse, request)).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        response.setErrors(null);
        httpResponse.setStatusCode(HttpStatus.OK);
        response.getServiceBody().getServiceResponse().getContext().setCartInfo(null);
        when(accessoryFinancingOffersHelper.updateAccessoryFinancingOffers(request)).thenReturn(Mono.just(response));
        StepVerifier.create(controller.accessoryFinancingOffers(httpHeader, httpResponse, request)).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        response.setErrors(null);
        httpResponse.setStatusCode(HttpStatus.NOT_FOUND);
        response.getServiceBody().getServiceResponse().getContext().setCartInfo(null);
        when(accessoryFinancingOffersHelper.updateAccessoryFinancingOffers(request)).thenReturn(Mono.just(response));
        StepVerifier.create(controller.accessoryFinancingOffers(httpHeader, httpResponse, request)).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        response.getServiceBody().getServiceResponse().setContext(null);
        when(accessoryFinancingOffersHelper.updateAccessoryFinancingOffers(request)).thenReturn(Mono.just(response));
        StepVerifier.create(controller.accessoryFinancingOffers(httpHeader, httpResponse, request)).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        response.getServiceBody().setServiceResponse(null);
        when(accessoryFinancingOffersHelper.updateAccessoryFinancingOffers(request)).thenReturn(Mono.just(response));
        StepVerifier.create(controller.accessoryFinancingOffers(httpHeader, httpResponse, request)).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        response.setServiceBody(null);
        when(accessoryFinancingOffersHelper.updateAccessoryFinancingOffers(request)).thenReturn(Mono.just(response));
        StepVerifier.create(controller.accessoryFinancingOffers(httpHeader, httpResponse, request)).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }
}
