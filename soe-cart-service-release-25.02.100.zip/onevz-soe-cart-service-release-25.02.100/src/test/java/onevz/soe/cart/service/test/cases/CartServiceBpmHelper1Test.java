package onevz.soe.cart.service.test.cases;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.cxp.feature.ConfigurationProfile;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper2;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper3;
import onevz.soe.cart.bpm.service.CartServiceBPMServices;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.helper.FeatureFlagHelper;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.model.assignMtn.AssignMtnData;
import onevz.soe.cart.model.assignMtn.AssignMtnServiceBody;
import onevz.soe.cart.model.common.CartServiceServiceHeader;
import onevz.soe.cart.requests.AssignMtnPEGARequest;
import onevz.soe.cart.responses.AssignMtnPEGAResponse;
import onevz.soe.cart.responses.DeleteCartPegaResponse;
import onevz.soe.cart.ui.common.CartInfo;
import onevz.soe.cart.ui.requests.AssignMtnUIRequest;
import onevz.soe.cart.ui.requests.DeleteCartUIRequest;
import onevz.soe.cart.ui.requests.InitiateCheckoutUIRequest;
import onevz.soe.cart.ui.responses.DeleteCartUIResponse;
import onevz.soe.cart.ui.responses.InitiateCheckoutUIResponse;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.util.ArrayList;

import static org.mockito.Mockito.*;

@RunWith(SpringJUnit4ClassRunner.class)
@WebFluxTest(CartServiceBpmHelper.class)
public class CartServiceBpmHelper1Test {

    @MockBean
    private CartServiceBPMServices cartServiceBPMServices;

    @Autowired
    private CartServiceBpmHelper3 bpmHelper3;

    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;

    @MockBean
    SOELoginSessionBean soeLoginSessionBean;

    @Autowired
    private ObjectMapper mapper;

    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;
    @InjectMocks
    private CartServiceBpmHelper2 bpmHelper2;
    @Mock
    FeatureFlagHelper featureFlagHelper;


    @Mock
    CartServiceBPMServices bpmServices;
    @Mock
    RedisHelper redisHelper;

    @Test
    public void deleteCartTest() throws JsonProcessingException, SOEHTTPException {

            String sampleUIRequestString = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"467e2a19-c2cb-4d79-b042-22e75c16bb39\",\"caseId\":\"SOP-507867-E01\",\"cartCreator\":\"3013513888\",\"intendType\": \"NSE\"}}";
            String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"MOTRN1\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-277-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"\",\"processAction\":\"\"},\"cartInfo\":{\"cartId\":\"69a66ef4d-7e344dfb-2db299209-ea8333\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"8643804638\",\"processingMTN\":\"8643804638\"}}}}}";

            DeleteCartUIRequest UIRequest = new DeleteCartUIRequest();
            UIRequest = mapper.readValue(sampleUIRequestString, DeleteCartUIRequest.class);

            DeleteCartPegaResponse sampleResponse = null;
            sampleResponse = mapper.readValue(sampleResponseString, DeleteCartPegaResponse.class);
            Mono<DeleteCartPegaResponse> responseMono = Mono.just(sampleResponse);

            Mockito.when(cartServiceBPMServices.ngdDeleteCart(Mockito.any())).thenReturn(responseMono);
            Mono<DeleteCartUIResponse> pegaResponse = bpmHelper3.ngdDeleteCart(UIRequest,true);
            StepVerifier.create(pegaResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

    }

    @Test
    public void DeleteCartHTTPEXceptionTest() throws JsonProcessingException, SOEHTTPException {

            String sampleUIRequestString = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"467e2a19-c2cb-4d79-b042-22e75c16bb39\",\"caseId\":\"SOP-507867-E01\",\"cartCreator\":\"3013513888\",\"intendType\": \"NSE\"}}";

            DeleteCartUIRequest UIRequest = new DeleteCartUIRequest();
            UIRequest = mapper.readValue(sampleUIRequestString, DeleteCartUIRequest.class);
            Mono<DeleteCartPegaResponse> dummyResponse = Mono
                    .just(Mockito.mock(DeleteCartPegaResponse.class, RETURNS_SMART_NULLS));
            Mockito.when(cartServiceBPMServices.ngdDeleteCart(Mockito.any()))
                    .thenThrow(new SOEHTTPException(sampleUIRequestString, null, dummyResponse.toString()));
            Mono<DeleteCartUIResponse> pegaResponse = bpmHelper3.ngdDeleteCart(UIRequest,false);
            StepVerifier.create(pegaResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();


    }

    @Test
    public void DeleteCartErrorResponseTest() throws JsonProcessingException, SOEHTTPException {

        String sampleUIRequestString = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"467e2a19-c2cb-4d79-b042-22e75c16bb39\",\"caseId\":\"SOP-507867-E01\",\"cartCreator\":\"3013513888\",\"intendType\": \"NSE\"}}";
        String sampleResponseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";

        DeleteCartUIRequest UIRequest = new DeleteCartUIRequest();
        UIRequest = mapper.readValue(sampleUIRequestString, DeleteCartUIRequest.class);

        DeleteCartPegaResponse sampleResponse = null;
        sampleResponse = mapper.readValue(sampleResponseString, DeleteCartPegaResponse.class);
        Mono<DeleteCartPegaResponse> responseMono = Mono.just(sampleResponse);

        Mockito.when(cartServiceBPMServices.ngdDeleteCart(Mockito.any())).thenReturn(responseMono);
        Mono<DeleteCartUIResponse> pegaResponse = bpmHelper3.ngdDeleteCart(UIRequest, false);
        StepVerifier.create(pegaResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

    }
    @Test
    public void assignMtnTestCoverage() throws SOEHTTPException {
        AssignMtnUIRequest uiRequest = new AssignMtnUIRequest();
        uiRequest.setCartInfo(new CartInfo());
        uiRequest.setData(new AssignMtnData());
        uiRequest.getData().setLines(new ArrayList<>());
        uiRequest.setPredictivePrefetchEnabled(true);
        AssignMtnPEGAResponse addPromoIntentPEGAResponse = new AssignMtnPEGAResponse();
        addPromoIntentPEGAResponse.setServiceBody(new AssignMtnServiceBody());
        addPromoIntentPEGAResponse.setServiceHeader(new CartServiceServiceHeader());

        uiRequest.setPredictivePrefetchEnabled(true);
        when(featureFlagHelper.fetchDigitalPegaPredictivePrefetchFFlag()).thenReturn(Mono.just(false));
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(new ConfigurationProfile()));
        when(cartServiceBPMServices.assignMtn(new AssignMtnPEGARequest())).thenReturn(Mono.just(new AssignMtnPEGAResponse()));
        StepVerifier.create(bpmHelper2.assignMtn(uiRequest)).expectNextMatches(res->res!=null).verifyComplete();

        uiRequest.setPredictivePrefetchEnabled(true);
        when(featureFlagHelper.fetchDigitalPegaPredictivePrefetchFFlag()).thenReturn(Mono.just(true));
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(new ConfigurationProfile()));
        when(cartServiceBPMServices.assignMtn(new AssignMtnPEGARequest())).thenReturn(Mono.just(addPromoIntentPEGAResponse));
        StepVerifier.create(bpmHelper2.assignMtn(uiRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        uiRequest.setPredictivePrefetchEnabled(false);
        when(featureFlagHelper.fetchDigitalPegaPredictivePrefetchFFlag()).thenReturn(Mono.just(true));
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(new ConfigurationProfile()));
        when(cartServiceBPMServices.assignMtn(new AssignMtnPEGARequest())).thenReturn(Mono.just(addPromoIntentPEGAResponse));
        StepVerifier.create(bpmHelper2.assignMtn(uiRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void removeSensitiveDataForCheckOutCartTest() throws JsonProcessingException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse.json", testFileLocation);
        InitiateCheckoutUIResponse sampleUIResponse =  mapper.readValue(sampleUIRequestString, InitiateCheckoutUIResponse.class);
        String channelId=CartConstants.CHANNEL_ASSISTED;

        bpmHelper2.removeSensitiveDataForCheckOutCart(sampleUIResponse,channelId);
        bpmHelper2.removeSensitiveDataForCheckOutCart(sampleUIResponse,"");
        bpmHelper2.removeSensitiveDataForCheckOutCart(sampleUIResponse,"123");
        bpmHelper2.removeSensitiveDataForCheckOutCart(null,channelId);
        sampleUIResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartId(null);
        bpmHelper2.removeSensitiveDataForCheckOutCart(sampleUIResponse,channelId);
        sampleUIResponse.getServiceBody().getServiceResponse().getContext().setCartInfo(null);
        bpmHelper2.removeSensitiveDataForCheckOutCart(sampleUIResponse,channelId);
        sampleUIResponse.getServiceBody().getServiceResponse().getContext().setCaseId(null);
        bpmHelper2.removeSensitiveDataForCheckOutCart(sampleUIResponse,channelId);
        sampleUIResponse.getServiceBody().getServiceResponse().setContext(null);
        bpmHelper2.removeSensitiveDataForCheckOutCart(sampleUIResponse,channelId);
        sampleUIResponse.getServiceBody().setServiceResponse(null);
        bpmHelper2.removeSensitiveDataForCheckOutCart(sampleUIResponse,channelId);

    }

    @Test
    public void validateOrderTest() throws JsonProcessingException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest.json", testFileLocation);
        InitiateCheckoutUIRequest sampleUIResponse =  mapper.readValue(sampleUIRequestString, InitiateCheckoutUIRequest.class);
        when(redisHelper.isDigitalHomeFlow()).thenReturn(Mono.just(true));
        Mono<InitiateCheckoutUIResponse> resp=bpmHelper2.validateOrder(sampleUIResponse);
        sampleUIResponse.getCartInfo().setIntent(CartConstants.WHW_INTENT);
        resp=bpmHelper2.validateOrder(sampleUIResponse);

    }


}