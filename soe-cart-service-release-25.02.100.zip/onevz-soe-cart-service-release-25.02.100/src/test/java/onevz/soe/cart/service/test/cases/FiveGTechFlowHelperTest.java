package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import net.jcip.annotations.NotThreadSafe;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper;
import onevz.soe.cart.helper.FiveGTechFlowHelper;
import onevz.soe.cart.helper.RedisHelper3;
import onevz.soe.cart.initiatecart.InitiateCartUIResponse;
import onevz.soe.cart.responses.TechFlowRedisData;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.AddPlanAndDeviceUIRequest;
import onevz.soe.cart.ui.responses.AddPlanAndDeviceUIResponse;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.wsclient.bpm.model.CustomerInfo;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(FiveGTechFlowHelper.class)
//@NotThreadSafe
//@SpringBootTest
public class FiveGTechFlowHelperTest {

	@Autowired
	private FiveGTechFlowHelper helper;

	@MockBean
	private CartServiceBpmHelper bpmHelper;

    @MockBean
    private RedisHelper3 redisHelper3;

    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;

    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;

    @Autowired
    private ObjectMapper mapper;


    @Test
    public void cpcUpdateCartTest() throws JsonProcessingException {

        AddPlanAndDeviceUIResponse addPlanAndDeviceUIResponse= new AddPlanAndDeviceUIResponse();
        String responseFile = "AddPlanAndDeviceUIResponse.json";
        String redisFile = "TechFlowRedisData.json";
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
        TechFlowRedisData sampleRedisData = mapper.readValue(redisDataString, TechFlowRedisData.class);
        addPlanAndDeviceUIResponse = mapper.readValue(sampleResponseString, AddPlanAndDeviceUIResponse.class);
        when(redisHelper3.fetchTechnicianDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(),Mockito.anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(bpmHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(addPlanAndDeviceUIResponse));

        Mono<AddPlanAndDeviceUIResponse> response = helper.cpcUpdateCart(new AddPlanAndDeviceUIRequest());
        StepVerifier.create(response).expectError()
                .verify();

    }
    @Test
    public void cpcSubmitPlanTest(){
        AddPlanAndDeviceUIResponse addPlanAndDeviceUIResponse=new AddPlanAndDeviceUIResponse();
        when(redisHelper3.fetchTechnicianDataFromRedis()).thenReturn(Mono.just(new TechFlowRedisData()));
        when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(),Mockito.anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(bpmHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(addPlanAndDeviceUIResponse));

        Mono<AddPlanAndDeviceUIResponse> response = helper.cpcSubmitPlan(new AddPlanAndDeviceUIRequest());
        StepVerifier.create(response).expectError()
                .verify();

    }

    @Test
    public void cpcInititateCart() throws JsonProcessingException {
        String resp="{ \"serviceHeader\": { \"clientId\": \"VZW-DOTCOM\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"CPC\", \"statusCode\": \"00\" }, \"serviceBody\":" +
                " { \"serviceResponse\": { \"context\": { \"caseId\": \"CPC-12401688-E01\", \"contextInfo\": { \"callReason\": \"CPC\", \"processStep\": \"planSelection\", \"availablePaths\": [ { \"path\": \"planSelection\" }, { \"path\": \"featureSelection\" } ], \"pastDueBalance\": \"false\", \"pendingOrderAccountLevel\": \"false\" }, \"customerInfo\": { \"accountNumber\": \"0326564274-00001\", \"cartCreator\": \"5619384700\", \"registerNumber\": 0 }, \"cartInfo\": { \"cartId\": \"5bad495f-b32f-4bc3-8293-c0064cb7750f\" } } } } }";
        InitiateCartUIResponse initiateCartUIResponse =mapper.readValue(resp,InitiateCartUIResponse.class);
        CustomerInfo customerInfo =new CustomerInfo();
        when(redisHelper3.fetchProfileInfoFromRedis()).thenReturn(Mono.just(customerInfo));
        when(bpmHelper.cpcInitiateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(initiateCartUIResponse));
        Mono<InitiateCartUIResponse> response = helper.cpcInititateCart(new AddPlanAndDeviceUIRequest());
        StepVerifier.create(response).assertNext(Assert::assertNotNull).expectComplete()
                .verify();
    }

}
