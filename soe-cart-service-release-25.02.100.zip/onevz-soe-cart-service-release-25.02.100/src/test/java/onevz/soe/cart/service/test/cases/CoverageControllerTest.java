package onevz.soe.cart.service.test.cases;

import java.io.IOException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import junit.framework.Assert;
import onevz.soe.cart.controller.CartCodeCoverageController;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;


@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(CartCodeCoverageController.class)
public class CoverageControllerTest {

	@Autowired
	private CartCodeCoverageController coverageController;

	@Test
	public void getITCoverage() throws IOException {
		ResponseEntity<Resource> controllerResponse = coverageController.getITCoverage();
		StepVerifier.create(Mono.just(controllerResponse)).assertNext(resp -> Assert.assertNotNull(resp))
				.expectComplete().verify();
	}

}
