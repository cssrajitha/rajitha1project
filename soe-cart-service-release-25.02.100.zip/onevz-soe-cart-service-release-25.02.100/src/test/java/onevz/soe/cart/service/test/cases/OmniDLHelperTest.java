package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.helper.OmniDLHelper;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.helper.RedisHelper2;
import onevz.soe.cart.model.addPlan.AddPlanContext;
import onevz.soe.cart.model.addPlan.AddPlanServiceBody;
import onevz.soe.cart.model.addPlan.AddPlanServiceResponse;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.removeLines.RemoveLinesServiceBody;
import onevz.soe.cart.model.retrieveCart.MtnDetails;
import onevz.soe.cart.model.retrieveCart.ServiceInfo;
import onevz.soe.cart.model.retrieveCart.*;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.common.*;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.AddPlanUIResponse;
import onevz.soe.cart.ui.responses.RemoveLinesUIResponse;
import onevz.soe.cart.ui.responses.RetrieveCartUIResponse;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.customerprofile.model.gql.assisted.Address;
import onevz.soe.customerprofile.model.gql.assisted.BillAccount;
import onevz.soe.customerprofile.model.gql.assisted.PricePlanInfo;
import onevz.soe.customerprofile.model.gql.assisted.*;
import onevz.soe.customerprofile.response.CustomerProfileResponse;
import onevz.soe.session.bean.SOELoginSessionBean;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.util.*;

import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {CartServiceTestConfig.class})
public class OmniDLHelperTest {

    @Autowired
    OmniDLHelper omniDLHelper;

    @Autowired
    ObjectMapper mapper;

    @Mock
    RedisHelper redisHelper;


    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;
    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;
    @Mock
    RedisHelper2 redisHelper2;
    @MockBean
    SOELoginSessionBean sessionBean;
    private RetrieveCartUIResponse cxpResponse;
    private Vzdl vzdl;
    private CXPRetrieveCartDataVO mockData;
    private CXPCartVO mockCart;
    private RetrieveCartUIResponse mockCxpResponse;
    private Map<String, String> txn;




    @Before
    public void setUp(){
        cxpResponse=new RetrieveCartUIResponse();
        vzdl = new Vzdl();
        mockCxpResponse=mock(RetrieveCartUIResponse.class);
        mockCart= mock(CXPCartVO.class);
        mockData=mock(CXPRetrieveCartDataVO.class);
        txn=new HashMap<>();

    }
    @Test
    public void getVzdlDataForAddPlanTest() {
        AddPlanUIRequest request = null;
        AddPlanUIResponse response = null;
        Assert.assertNull(omniDLHelper.getVzdlDataForAddPlan(request, response, new CartRedisData()));

        request = new AddPlanUIRequest();
        response = new AddPlanUIResponse();
        Assert.assertNull(omniDLHelper.getVzdlDataForAddPlan(request, response, new CartRedisData()));

        request.setData(new AddPlanData());
        omniDLHelper.getVzdlDataForAddPlan(request, response, new CartRedisData());

        response.setServiceBody(new AddPlanServiceBody());
        omniDLHelper.getVzdlDataForAddPlan(request, response, new CartRedisData());

        request = new AddPlanUIRequest();
        omniDLHelper.getVzdlDataForAddPlan(request, response, new CartRedisData());

    }

    @Test
    public void populateVzdlDataForAddPlanTest() {
        AddPlanUIRequest request = new AddPlanUIRequest();
        AddPlanUIResponse response = new AddPlanUIResponse();
        CartRedisData cartRedisData = new CartRedisData();
        Assert.assertNull(omniDLHelper.populateVzdlDataForAddPlan(request, response, cartRedisData));

        AddPlanServiceBody serviceBody = new AddPlanServiceBody();
        AddPlanServiceResponse addPlanServiceResponse = new AddPlanServiceResponse();
        AddPlanContext context = new AddPlanContext();
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        context.setCartInfo(cartInfo);
        addPlanServiceResponse.setContext(context);
        serviceBody.setServiceResponse(addPlanServiceResponse);
        response.setServiceBody(serviceBody);

        AddPlanData data = new AddPlanData();
        request.setData(data);
        Assert.assertNull(omniDLHelper.populateVzdlDataForAddPlan(request, response, cartRedisData));

        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(null);
        Assert.assertNull(omniDLHelper.populateVzdlDataForAddPlan(request, response, cartRedisData));

        List<Line> lineList= new ArrayList<>();
        Line[] lineArr= new Line[lineList.size()];
        lineList.toArray(lineArr);
        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(lineArr);
        Assert.assertNull(omniDLHelper.populateVzdlDataForAddPlan(request, response, cartRedisData));

        lineList= new ArrayList<>();
        lineList.add(new Line());
        lineArr= new Line[lineList.size()];
        lineList.toArray(lineArr);
        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(lineArr);
        Assert.assertNull(omniDLHelper.populateVzdlDataForAddPlan(request, response, cartRedisData));

        Line[] lines = new Line[2];
        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(lines);
        Assert.assertNull(omniDLHelper.populateVzdlDataForAddPlan(request, response, cartRedisData));

        Lines[] linesArr= new Lines[0];
        request.getData().setLines(linesArr);
        Assert.assertNull(omniDLHelper.populateVzdlDataForAddPlan(request, response, cartRedisData));

        List<Lines> linesList= new ArrayList<>();
        linesList.add(null);
        linesList.add(new Lines());
        linesArr= new Lines[linesList.size()];
        linesList.toArray(linesArr);
        request.getData().setLines(linesArr);
        Assert.assertNull(omniDLHelper.populateVzdlDataForAddPlan(request, response, cartRedisData));

        Lines[] reqLine = new Lines[2];
        request.getData().setLines(reqLine);
        Assert.assertNull(omniDLHelper.populateVzdlDataForAddPlan(request, response, cartRedisData));

        lines[0] = new Line();
        Line line1= new Line();
        lines[1]= line1;
        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(lines);
        Assert.assertNull(omniDLHelper.populateVzdlDataForAddPlan(request, response, cartRedisData));

        reqLine[0] = new Lines();
        Lines lines1= new Lines();
        reqLine[1]= lines1;
        request.getData().setLines(reqLine);
        Assert.assertNotNull(omniDLHelper.populateVzdlDataForAddPlan(request, response, cartRedisData));

    }

    @Test
    public void updateUserDataTest() {
        Vzdl vzdl = new Vzdl();
        CartRedisData rr = null;
        AddPlanUIRequest request = new AddPlanUIRequest();
        omniDLHelper.updateUserData(vzdl, rr, request);

        CartInfo cartInfo = new CartInfo();
        cartInfo.setSessionId("12345");
        request.setCartInfo(cartInfo);
        rr = new CartRedisData();
        rr.setCustomerProfile(null);
        omniDLHelper.updateUserData(vzdl, rr, request);

        rr.setCustomerProfile(new CustomerProfileResponse());
        rr.getCustomerProfile().setData(null);
        omniDLHelper.updateUserData(vzdl, rr, request);

        rr.getCustomerProfile().setData(new Data());
        rr.getCustomerProfile().getData().setCustomer(null);
        omniDLHelper.updateUserData(vzdl, rr, request);

        rr.getCustomerProfile().getData().setCustomer(new Customer());
        rr.getCustomerProfile().getData().getCustomer().setBillAccounts(null);
        rr.getCustomerProfile().getData().getCustomer().setCustomerName(null);
        rr.getCustomerProfile().getData().getCustomer().setCustomerAttributes(null);
        rr.getCustomerProfile().getData().getCustomer().setIsSalesRepIdMismatch(null);
        rr.getCustomerProfile().getData().getCustomer().setIsComboOrderAllowed(null);
        omniDLHelper.updateUserData(vzdl, rr, request);

        rr.getCustomerProfile().getData().setCustomer(new Customer());
        rr.getCustomerProfile().getData().getCustomer().setCustomerHash("");
        rr.getCustomerProfile().getData().getCustomer().setAccountNo("");
        rr.getCustomerProfile().getData().getCustomer().setBillAccounts(new ArrayList<>());
        omniDLHelper.updateUserData(vzdl, rr, request);

        rr.getCustomerProfile().getData().getCustomer().setCustomerHash("123");
        rr.getCustomerProfile().getData().getCustomer().setAccountNo("1234-000");
        rr.getCustomerProfile().getData().getCustomer().setLookupMtn("678");
        Address address = new Address();
        rr.getCustomerProfile().getData().getCustomer().setAddress(address);
        omniDLHelper.updateUserData(vzdl, rr, request);

        address.setZipCode("1234");
        rr.getCustomerProfile().getData().getCustomer().setAddress(address);
        BillAccount billAccount = new BillAccount();
        billAccount.setMtns(null);
        List<BillAccount> accounts = new ArrayList<>();
        accounts.add(billAccount);
        accounts.add(null);
        omniDLHelper.updateUserData(vzdl, rr, request);

        BillAccount billAccount1 = new BillAccount();
        Mtn mtn = new Mtn();
        List<Mtn> mtns = new ArrayList<>();
        mtns.add(new Mtn());
        mtns.add(mtn);

        mtn.setMtn("678");
        mtn.setPricePlanInfo(new PricePlanInfo());
        mtns.add(mtn);
        Mtn mtn1 = new Mtn();
        PricePlanInfo pricePlanInfo = new PricePlanInfo();
        pricePlanInfo.setDescription("Test");
        mtn1.setMtn("123");
        mtn1.setPricePlanInfo(pricePlanInfo);
        mtns.add(mtn1);
        billAccount1.setMtns(mtns);
        accounts.add(billAccount1);
        rr.getCustomerProfile().getData().getCustomer().setBillAccounts(accounts);
        omniDLHelper.updateUserData(vzdl, rr, request);
        Assert.assertNotNull(vzdl.getUser());
    }

    @Test
    public void updatePageDataTest() throws JsonProcessingException {
        Vzdl vzdl = new Vzdl();
        AddPlanUIRequest request = new AddPlanUIRequest();
        omniDLHelper.updatePageData(vzdl, request);

        CartInfo cartInfo = new CartInfo();
        request.setCartInfo(cartInfo);
        String requestString = "{ \"cartInfo\": { \"processingMTN\": \"6413543766\", \"processStep\": \"PlanSelection\" }, \"data\": { \"lines\": [ { \"mtn\": \"9194377114\", \"addFeatures\": [ { \"id\": \"2839\", \"quantity\": \"1\", \"actionIndicator\": \"A\", \"type\": \"SPO\" } ], \"removeFeatures\": [], \"linechanged\": false, \"plan\": { \"id\": \"63217\", \"isRecommendedPlan\": false, \"recommender\": \"\", \"path\": \"Popular Plan\" } }, { \"mtn\": \"6413543733\", \"addFeatures\": [ { \"id\": \"2678\", \"quantity\": \"1\", \"actionIndicator\": \"A\", \"type\": \"SPO\" } ], \"removeFeatures\": [], \"linechanged\": false, \"plan\": { \"id\": \"69185\", \"isRecommendedPlan\": false, \"recommender\": \"\", \"path\": \"Build Plan\" } } ], \"parentMtn\": \"\", \"enableAssistedTagging\": true, \"isPerksSelectedFromVT\": \"N\" } }";
        request = mapper.readValue(requestString, AddPlanUIRequest.class);
        omniDLHelper.updatePageData(vzdl, request);

        request.getCartInfo().setSessionId("");
        request.setChannelId(null);
        request.getCartInfo().setIntendType("");
        request.getCartInfo().setCaseId("");
        request.getCartInfo().setCartId("");

        omniDLHelper.updatePageData(vzdl, request);
        Assert.assertNotNull(vzdl.getPage());

        request.getCartInfo().setSessionId("12345");
        request.getCartInfo().setIntendType("NSE");
        request.getCartInfo().setCaseId("1234");
        request.getCartInfo().setCartId("567888");
        request.setChannelId("");
        omniDLHelper.updatePageData(vzdl, request);
        Assert.assertNotNull(vzdl.getPage());

        request.getCartInfo().setIntendType(CartConstants.NSE_BYOD);
        request.setChannelId(CartConstants.RETAIL);
        omniDLHelper.updatePageData(vzdl, request);

        request.setChannelId(CartConstants.RETAIL_IPAD);
        omniDLHelper.updatePageData(vzdl, request);
    }

    @Test
    public void updateTxnDataTest() {
        when( redisHelper2.upsertDeviceCartMapInRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        Vzdl vzdl = new Vzdl();
        CartRedisData rr = null;
        Optional<CartServiceCartInfo> cartInfo = Optional.empty();
        omniDLHelper.updateTxnData(vzdl, rr, cartInfo);
        assertTrue(vzdl.getTxn().isEmpty());


        rr = new CartRedisData();
        omniDLHelper.updateTxnData(vzdl, rr, cartInfo);

        CartServiceCartInfo cartServiceCartInfo = new CartServiceCartInfo();
        cartInfo = Optional.of(cartServiceCartInfo);
        omniDLHelper.updateTxnData(vzdl, rr, cartInfo);

        cartServiceCartInfo.setCartId("");
        cartInfo = Optional.of(cartServiceCartInfo);
        omniDLHelper.updateTxnData(vzdl, rr, cartInfo);

        rr.setAutoPayEnrolled("");
        rr.setRepId("");
        rr.setLocationCode("");
        rr.setAgentRole("");
        omniDLHelper.updateTxnData(vzdl, rr, cartInfo);

        cartServiceCartInfo.setCartId("5362537");
        cartInfo = Optional.of(cartServiceCartInfo);
        rr.setAutoPayEnrolled("123");
        rr.setAgentRole("ENC-123");
        rr.setRepId("ENC");
        rr.setLocationCode("1234");
        omniDLHelper.updateTxnData(vzdl, rr, cartInfo);

        rr.setAutoPayEnrolled("true");
        omniDLHelper.updateTxnData(vzdl, rr, cartInfo);

    }

    @Test
    public void updateProductDataTest() {
        Vzdl vzdl = new Vzdl();
        CartRedisData rr = null;
        AddPlanUIRequest request = new AddPlanUIRequest();
        request.setData(new AddPlanData());
        Optional<Lines> requestLines= Optional.empty();
        rr= new CartRedisData();
        Lines[] reqLine = new Lines[1];
        Lines lines= new Lines();
        reqLine[0]=lines;
        request.getData().setLines(reqLine);

        CartServiceCartInfo cartInfo = new CartServiceCartInfo();

        omniDLHelper.updateProductData(vzdl,rr,request,requestLines, Optional.empty());
        Assert.assertNotNull(vzdl.getProduct());

        rr.setCustomerProfile(new CustomerProfileResponse());
        reqLine[0]= null;
        request.getData().setLines(reqLine);
        omniDLHelper.updateProductData(vzdl,rr,request,requestLines, Optional.empty());

        Data data= new Data();
        data.setCustomer(new Customer());
        List<BillAccount> billAccounts= new ArrayList<>();
        Mtn mtn = new Mtn();
        mtn.setMtn("123");
        mtn.setPricePlanInfo(new PricePlanInfo());
        Mtn mtn1 = new Mtn();
        mtn1.setMtn("123");
        PricePlanInfo pricePlanInfo= new PricePlanInfo();
        pricePlanInfo.setDescription("");
        mtn1.setPricePlanInfo(pricePlanInfo);
        mtn1.setMtnHashCode("");
        Mtn mtn2 = new Mtn();
        mtn2.setMtn("123");
        pricePlanInfo.setDescription("123457");
        pricePlanInfo.setPlanId("097");
        mtn2.setPricePlanInfo(pricePlanInfo);
        mtn2.setMtnHashCode("aec");
        List<Mtn> mtns = new ArrayList<>();
        Mtn mtn3 = new Mtn();
        mtn3.setMtn("");
        Mtn mtn4 = new Mtn();
        mtns.add(new Mtn());
        Mtn mtn5= new Mtn();
        mtn5.setMtn("123");
        mtn5.setMtnHashCode("");
        mtns.add(mtn);
        mtns.add(mtn1);
        mtns.add(mtn2);
        mtns.add(mtn3);
        mtns.add(mtn4);
        mtns.add(mtn5);
        Mtn mtn6= new Mtn();
        mtn6.setMtn("123");
        mtn6.setMtnHashCode("1234566");
        mtns.add(mtn6);
        BillAccount billAccount= new BillAccount();
        billAccount.setMtns(mtns);
        billAccounts.add(billAccount);
        billAccounts.add(null);
        data.getCustomer().setBillAccounts(billAccounts);
        rr.getCustomerProfile().setData(data);
        reqLine = new Lines[3];
        Lines line= new Lines();
        line.setMtn("123");
        reqLine[0]= line;
        line.setPlan(new Plan());
        line.setAddFeatures(new ArrayList<>());
        line.setLinechanged(true);
        reqLine[1]= line;
        line.getPlan().setId("abc");
        line.getPlan().setPath(null);
        Feature feature= new Feature();
        List<Feature> features= new ArrayList<>();
        features.add(null);
        features.add(feature);
        feature.setId("spo1");
        features.add(feature);
        line.setAddFeatures(features);
        line.setPlan(null);
        reqLine[2] = line;
        request.getData().setLines(reqLine);
        requestLines= Optional.of(reqLine[0]);
        omniDLHelper.updateProductData(vzdl,rr,request,requestLines,Optional.empty());

        reqLine= new Lines[1];
        reqLine[0]= null;
        request.getData().setLines(reqLine);
        omniDLHelper.updateProductData(vzdl,rr,request,requestLines,Optional.of(cartInfo));

        reqLine= new Lines[1];
        line.setMtn(null);
        reqLine[0]= line;
        request.getData().setLines(reqLine);
        omniDLHelper.updateProductData(vzdl,rr,request,requestLines,Optional.of(cartInfo));

        reqLine= new Lines[1];
        line.setMtn("");
        reqLine[0]= line;
        request.getData().setLines(reqLine);
        omniDLHelper.updateProductData(vzdl,rr,request,requestLines,Optional.of(cartInfo));

        line.setPlan(new Plan());
        line.setAddFeatures(new ArrayList<>());
        reqLine= new Lines[1];
        line.setLinechanged(false);
        line.setMtn("123");
        reqLine[0]= line;
        request.getData().setLines(reqLine);
        omniDLHelper.updateProductData(vzdl,rr,request,requestLines,Optional.of(cartInfo));



        line.setLinechanged(true);
        line.getPlan().setId("");
        line.getPlan().setPath("");
        reqLine[0]= line;
        request.getData().setLines(reqLine);
        Line[] respLine= new Line[2];
        cartInfo.setLines(respLine);
        request.getData().getLines()[0].setAddFeatures(features);
        omniDLHelper.updateProductData(vzdl,null,request,requestLines,Optional.empty());
        omniDLHelper.updateProductData(vzdl,rr,request,requestLines,Optional.of(cartInfo));

        line.getPlan().setId("abc");
        line.getPlan().setPath(null);
        reqLine[0]= line;
        request.getData().setLines(reqLine);
        Line[] lines1 = new Line[2];
        lines1[0] =null;
        Line line1= new Line();
        lines1[1]= line1;
        respLine[0]= null;
        respLine[1]= new Line();
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductData(vzdl,rr,request,requestLines, Optional.of(cartInfo));

        line.getPlan().setPath("plans page");
        line.setMultiLineSeqNumber(null);
        line.getPlan().setPropId("");
        reqLine[0]= line;
        request.getData().setLines(reqLine);
        omniDLHelper.updateProductData(vzdl,rr,request,requestLines, Optional.of(cartInfo));

        line.getPlan().setPath(CartConstants.BUILD_PLAN_PATH);
        line.setMultiLineSeqNumber(1);
        line.getPlan().setPropId(null);
        reqLine[0]= line;
        request.getData().setLines(reqLine);
        omniDLHelper.updateProductData(vzdl,rr,request,requestLines, Optional.of(cartInfo));

        line.getPlan().setPropId("123");
        reqLine[0]= line;
        request.getData().setLines(reqLine);
        omniDLHelper.updateProductData(vzdl,rr,request,requestLines, Optional.of(cartInfo));

        Line respLine1= new Line();
        respLine1.setMtn("");
        respLine[0] = respLine1;
        respLine1.setMtn("123");
        respLine[1]= respLine1;
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductData(vzdl,rr,request,requestLines, Optional.of(cartInfo));

        respLine1.setPlan(new Plan());
        respLine= new Line[1];
        respLine[0]= respLine1;
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductData(vzdl,rr,request,requestLines, Optional.of(cartInfo));

        respLine1.getPlan().setId("");
        respLine[0]= respLine1;
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductData(vzdl,rr,request,requestLines, Optional.of(cartInfo));

        respLine1.getPlan().setId(null);
        respLine[0]= respLine1;
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductData(vzdl,rr,request,requestLines, Optional.of(cartInfo));

        respLine1.getPlan().setId("abc");
        respLine1.getPlan().setDiscountedPrice(null);
        respLine[0]= respLine1;
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductData(vzdl,rr,request,requestLines, Optional.of(cartInfo));

        respLine1.getPlan().setDiscountedPrice("");
        respLine1.setCurrentPlanType("");
        respLine[0]= respLine1;
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductData(vzdl,rr,request,requestLines, Optional.of(cartInfo));

        respLine1.getPlan().setDiscountedPrice("20.00");
        respLine1.setCurrentPlanType(null);
        respLine[0]= respLine1;
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductData(vzdl,rr,request,requestLines, Optional.of(cartInfo));

        respLine1.setCurrentPlanType("123");
        respLine[0]= respLine1;
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductData(vzdl,rr,request,requestLines, Optional.of(cartInfo));

        respLine1.setCurrentPlanType("ALP");
        respLine[0]= respLine1;
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductData(vzdl,rr,request,requestLines, Optional.of(cartInfo));

        respLine1.setCurrentPlanType("LLP");
        respLine[0]= respLine1;
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductData(vzdl,rr,request,requestLines, Optional.of(cartInfo));

        respLine1.setSpos(new ConflictedSPO[1]);
        respLine[0]= respLine1;
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductData(vzdl,rr,request,requestLines, Optional.of(cartInfo));

        ConflictedSPO spo= new ConflictedSPO();
        spo.setId("spo1");
        spo.setSkuId("sku23456789");
        ConflictedSPO[] spos= new ConflictedSPO[4];
        spos[0]=spo;
        spo.setId("");
        spo.setSkuId("");
        spos[1]=spo;
        spo.setId(null);
        spos[2]= spo;
        spos[3]=null;
        respLine1.setSpos(spos);
        respLine[0]= respLine1;
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductData(vzdl,rr,request,requestLines, Optional.of(cartInfo));

        request.getData().getLines()[0].setMtn("64764836832");
        omniDLHelper.updateProductData(vzdl,rr,request,requestLines, Optional.of(cartInfo));

        request.getData().getLines()[0].setMtn("123");
        request.getData().getLines()[0].setPlan(null);
        omniDLHelper.updateProductData(vzdl,rr,request,requestLines, Optional.of(cartInfo));

        request.getData().getLines()[0].setPlan(new Plan());
        request.getData().getLines()[0].getPlan().setPath(null);
        omniDLHelper.updateProductData(vzdl,rr,request,requestLines, Optional.of(cartInfo));

        request.getData().getLines()[0].getPlan().setPath("");
        omniDLHelper.updateProductData(vzdl,rr,request,requestLines, Optional.of(cartInfo));

        request.getData().getLines()[0].getPlan().setPath("Plans page");
        omniDLHelper.updateProductData(vzdl,rr,request,requestLines, Optional.of(cartInfo));

        request.getData().getLines()[0].getPlan().setPath("Build Plan");
        omniDLHelper.updateProductData(vzdl,rr,request,requestLines, Optional.of(cartInfo));

        feature.setId("1234");
        spo.setId("1234");
        spos[1]=spo;
        omniDLHelper.updateProductData(vzdl,rr,request,requestLines, Optional.of(cartInfo));

        feature.setId("1234");
        spo.setId("1234");
        spos[1]=spo;
        spo.setSkuId("sku123456");
        omniDLHelper.updateProductData(vzdl,rr,request,requestLines, Optional.of(cartInfo));

        omniDLHelper.updateProductData(vzdl,null,request,requestLines,Optional.of(cartInfo));

        omniDLHelper.updateProductData(vzdl,rr,request,requestLines,Optional.empty());
    }

    @Test
    public void updateUtilsDataTest() throws Exception{
        Vzdl vzdl= new Vzdl();
        AddPlanUIRequest request= new AddPlanUIRequest();
        omniDLHelper.updateUtilsData(vzdl, request);
        Assert.assertNull(vzdl.getUtils().getPegaCaseId());

        request.setCartInfo(new CartInfo());
        omniDLHelper.updateUtilsData(vzdl, request);

        request.getCartInfo().setCaseId(null);
        omniDLHelper.updateUtilsData(vzdl, request);

        request.getCartInfo().setCaseId("");
        omniDLHelper.updateUtilsData(vzdl, request);

        request.getCartInfo().setCaseId("caseId");
        omniDLHelper.updateUtilsData(vzdl, request);
    }

    @Test
    public void setFlowNameTest() throws Exception {
        when(redisHelper.addFlowNameToRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(sessionBean.setSessionData(any(),any())).thenReturn(Mono.just(false));
        StepVerifier.create(omniDLHelper.setFlow(null, null)).assertNext(Assert::assertNotNull).expectComplete().verify();
        omniDLHelper.setNewLineFlow(null, null);

        StepVerifier.create(omniDLHelper.setFlow("", "")).assertNext(Assert::assertNotNull).expectComplete().verify();
        omniDLHelper.setNewLineFlow("", "");

        omniDLHelper.setNewLineFlow("-", "");
        StepVerifier.create(omniDLHelper.setFlow("-", "")).assertNext(Assert::assertNotNull).expectComplete().verify();

        StepVerifier.create(omniDLHelper.setFlow("CPC", "")).assertNext(Assert::assertNotNull).expectComplete().verify();
        omniDLHelper.setNewLineFlow("CPC", "");

        StepVerifier.create(omniDLHelper.setFlow("CPC", null)).assertNext(Assert::assertNotNull).expectComplete().verify();
        omniDLHelper.setNewLineFlow("CPC", null);

        StepVerifier.create(omniDLHelper.setFlow(null, "CPC")).assertNext(Assert::assertNotNull).expectComplete().verify();
        omniDLHelper.setNewLineFlow(null, "CPC");

        StepVerifier.create(omniDLHelper.setFlow("CPC", "CPC")).assertNext(Assert::assertNotNull).expectComplete().verify();
        omniDLHelper.setNewLineFlow("CPC", "CPC");

        StepVerifier.create(omniDLHelper.setFlow("EUP", "CPC")).assertNext(Assert::assertNotNull).expectComplete().verify();
        omniDLHelper.setNewLineFlow("EUP", "CPC");

        StepVerifier.create(omniDLHelper.setFlow("CPC|EUP", "CPC")).assertNext(Assert::assertNotNull).expectComplete().verify();
        omniDLHelper.setNewLineFlow("CPC|EUP", "CPC");
        StepVerifier.create(omniDLHelper.setFlow("CPC|EUP|CPC", "CPC")).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void setFlowNameFalseTest() throws Exception {
        when(redisHelper.addFlowNameToRedis(Mockito.any())).thenReturn(Mono.just(false));
        when(sessionBean.setSessionData(any(),any())).thenReturn(Mono.just(false));
        StepVerifier.create(omniDLHelper.setFlow("CPC|EUP|CPC", "CPC")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }
    @Test
    public void setFlowNameTrueTest() throws Exception {
        when(redisHelper.addFlowNameToRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(sessionBean.setSessionData(any(),any())).thenReturn(Mono.just(true));
        StepVerifier.create(omniDLHelper.setFlow("CPC|EUP|CPC", "CPC")).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }
    @Test
    public void getVzdlDataForRemoveDeviceTest() throws JsonProcessingException {
        String requestString = "{ \"cartInfo\": { \"processingMTN\": \"9194377114\", \"processAction\": \"removeDevice\" }, \"data\": { \"lines\": [ { \"mtn\": \"9194377114\" } ], \"enableAssistedTagging\": true } }";
        RemoveLinesUIRequest request = mapper.readValue(requestString, RemoveLinesUIRequest.class);

        String responseString = "{ \"serviceHeader\": { \"clientId\": \"OMNI-RETAIL\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\", \"correlationId\": \"soe-cart-2024.04.23.09.35.04-178.37801937771425\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \"SOP-18707596-E01\", \"contextInfo\": { \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"ShoppingCart\", \"availablePaths\": [ { \"path\": \"TradeIn\" } ] }, \"customerInfo\": { \"nocByod\": false, \"accountNumber\": \"0513778948-00001\", \"cartCreator\": \"2519798197\", \"processingMTN\": \"9083318304\" }, \"cartInfo\": { \"cartId\": \"029a944d-9e52-42c0-888d-2b978cb239b5\", \"statusMsg\": \"Success\", \"statusCode\": \"1\" }, \"processMTNList\": [ { \"mtn\": \"9083318304\", \"completedprocessSteps\": [ \"ShoppingCart\" ] } ] } } }, \"cartCount\": \"0\" }";
        RemoveLinesUIResponse response = mapper.readValue(responseString, RemoveLinesUIResponse.class);

        CartRedisData cartSession= new CartRedisData();


        String customerProfileJson = "CustomerProfileResponseRD.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(customerProfileJson, testFileLocation);
        CustomerProfileResponse profileResponse = mapper.readValue(sampleRequestString, CustomerProfileResponse.class);

        String cartJson = "RetrieveCartRD.json";
        String sampleCartString = sourceFileReaderUtil.readFile(cartJson, testFileLocation);
        CXPRetrieveCartDataVO cart = mapper.readValue(sampleCartString, CXPRetrieveCartDataVO.class);
        cartSession.setRetrieveCart(cart);
        cartSession.setCustomerProfile(profileResponse);

        Assert.assertNotNull(omniDLHelper.populateVzdlDataForRemoveDevice(request, cartSession));
        request.getCartInfo().setIntendType("EUP");
        Assert.assertNotNull(omniDLHelper.getVzdlDataForRemoveDevice(request,response, cartSession));

        omniDLHelper.getVzdlDataForRemoveDevice(null,response,cartSession);

        request.setData(null);
        omniDLHelper.getVzdlDataForRemoveDevice(request,response, cartSession);

        request.setData(new RemoveLinesData());
        request.getCartInfo().setProcessAction(null);
        omniDLHelper.getVzdlDataForRemoveDevice(request,response, cartSession);

        request.getCartInfo().setProcessAction("abc");
        omniDLHelper.getVzdlDataForRemoveDevice(request,response, cartSession);

        request.getCartInfo().setProcessAction("removeDevice");
        omniDLHelper.getVzdlDataForRemoveDevice(request,response, cartSession);
    }
    @Test
    public void updateMtnHashTest() throws JsonProcessingException {
        String requestString = "{ \"cartInfo\": { \"processingMTN\": \"9194377114\", \"processAction\": \"removeDevice\" }, \"data\": { \"lines\": [ { \"mtn\": \"9194377114\" } ], \"enableAssistedTagging\": true } }";
        RemoveLinesUIRequest request = mapper.readValue(requestString, RemoveLinesUIRequest.class);

        String responseString = "{ \"serviceHeader\": { \"clientId\": \"OMNI-RETAIL\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\", \"correlationId\": \"soe-cart-2024.04.23.09.35.04-178.37801937771425\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \"SOP-18707596-E01\", \"contextInfo\": { \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"ShoppingCart\", \"availablePaths\": [ { \"path\": \"TradeIn\" } ] }, \"customerInfo\": { \"nocByod\": false, \"accountNumber\": \"0513778948-00001\", \"cartCreator\": \"2519798197\", \"processingMTN\": \"9083318304\" }, \"cartInfo\": { \"cartId\": \"029a944d-9e52-42c0-888d-2b978cb239b5\", \"statusMsg\": \"Success\", \"statusCode\": \"1\" }, \"processMTNList\": [ { \"mtn\": \"9083318304\", \"completedprocessSteps\": [ \"ShoppingCart\" ] } ] } } }, \"cartCount\": \"0\" }";
        RemoveLinesUIResponse response = mapper.readValue(responseString, RemoveLinesUIResponse.class);

        CartRedisData cartSession= new CartRedisData();


        String customerProfileJson = "CustomerProfileResponseRD.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(customerProfileJson, testFileLocation);
        CustomerProfileResponse profileResponse = mapper.readValue(sampleRequestString, CustomerProfileResponse.class);

        String cartJson = "RetrieveCartRD.json";
        String sampleCartString = sourceFileReaderUtil.readFile(cartJson, testFileLocation);
        CXPRetrieveCartDataVO cart = mapper.readValue(sampleCartString, CXPRetrieveCartDataVO.class);
        cartSession.setRetrieveCart(cart);
        cartSession.setCustomerProfile(profileResponse);

        Assert.assertNotNull(omniDLHelper.populateVzdlDataForRemoveDevice(request, cartSession));

        List<Mtn> mtns= new ArrayList<>();
        Mtn mtn= new Mtn();
        mtn.setMtn("9194377114");
        mtn.setMtnHashCode("");
        mtns.add(mtn);
        cartSession.getCustomerProfile().getData().getCustomer().getBillAccounts().get(0).setMtns(mtns);
        Assert.assertNotNull(omniDLHelper.populateVzdlDataForRemoveDevice(request, cartSession));

        mtns= new ArrayList<>();
        mtn= new Mtn();
        mtn.setMtn("9194377114");
        mtn.setMtnHashCode(null);
        mtns.add(mtn);
        cartSession.getCustomerProfile().getData().getCustomer().getBillAccounts().get(0).setMtns(mtns);
        Assert.assertNotNull(omniDLHelper.populateVzdlDataForRemoveDevice(request, cartSession));

        cartSession.getCustomerProfile().getData().setCustomer(null);
        omniDLHelper.updateMtnHash(cartSession,null, null);
        cartSession.setCustomerProfile(null);
        omniDLHelper.updateMtnHash(cartSession,null, null);

    }
    @Test
    public void getVzdlTxnDataForRemoveDeviceTest() throws JsonProcessingException {
        String requestString = "{ \"cartInfo\": { \"processingMTN\": \"9194377114\", \"processAction\": \"removeDevice\" }, \"data\": { \"lines\": [ { \"mtn\": \"9194377114\" } ], \"enableAssistedTagging\": true } }";
        RemoveLinesUIRequest request = mapper.readValue(requestString, RemoveLinesUIRequest.class);

        String responseString = "{ \"serviceHeader\": { \"clientId\": \"OMNI-RETAIL\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\", \"correlationId\": \"soe-cart-2024.04.23.09.35.04-178.37801937771425\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \"SOP-18707596-E01\", \"contextInfo\": { \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"ShoppingCart\", \"availablePaths\": [ { \"path\": \"TradeIn\" } ] }, \"customerInfo\": { \"nocByod\": false, \"accountNumber\": \"0513778948-00001\", \"cartCreator\": \"2519798197\", \"processingMTN\": \"9083318304\" }, \"cartInfo\": { \"cartId\": \"029a944d-9e52-42c0-888d-2b978cb239b5\", \"statusMsg\": \"Success\", \"statusCode\": \"1\" }, \"processMTNList\": [ { \"mtn\": \"9083318304\", \"completedprocessSteps\": [ \"ShoppingCart\" ] } ] } } }, \"cartCount\": \"0\" }";
        RemoveLinesUIResponse response = mapper.readValue(responseString, RemoveLinesUIResponse.class);

        CartRedisData cartSession= new CartRedisData();

        String customerProfileJson = "CustomerProfileResponseRD.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(customerProfileJson, testFileLocation);
        CustomerProfileResponse profileResponse = mapper.readValue(sampleRequestString, CustomerProfileResponse.class);

        String sampleCartString = "{ \"cart\": { \"cartHasOnlyAccessories\": false, \"cartHasConflicts\": true, \"conflictsAccepted\": false, \"cartHeader\": { \"vendorId\": \"NETACE\", \"ani\": 9194377114, \"repRole\": \"POSSYSTST\", \"locationType\": \"S\", \"sourceSystem\": \"OMNI-RETAIL\", \"cartId\": \"f9f76751-1bed-4d8f-ae9e-dfe7896117a8\", \"fullAccountNumber\": \"0319507991-1\", \"status\": \"A\", \"cartCreator\": \"9194377114\", \"cartCreatorChannelId\": \"OMNI-RETAIL\", \"cartCreatorOrderLocationCode\": \"P332201\", \"cartCreatorSalesRepId\": \"ENC\", \"caseId\": \"SOP-14196606-C01\", \"visionCustomerType\": \"PE\", \"isERTRep\": false }, \"orderDetails\": { \"totalTaxAmount\": \"0.0\", \"totalPerksSavings\": \"0.0\" }, \"lineDetails\": { \"lineInfo\": [ { \"isCommonPDP\": false, \"isTradeInIntentSelected\": false, \"multiLineSeqNumber\": 2, \"lineActivityType\": \"AAL\", \"totalDueToday\": 1299.99, \"totalDueTodayWithoutTax\": 1299.99, \"totalDueTodayWithoutTaxWithoutDiscount\": 1299.99, \"totalDueMonthly\": 0.0, \"mobileNumber\": \"9194377114\", \"showGlobalChoiceOffer\": false, \"itemsInfo\": [ { \"depletionType\": \"F\", \"attention\": \"RAVI WRIGHT\", \"shipping\": { \"address\": { \"firmName\": \"\", \"apartmentNo\": \"\", \"streetDirection\": \"\" }, \"bsnsName\": \"\", \"shipToCustomerAddress\": false }, \"fipsCode\": \"3403503340\", \"itemCount\": 1, \"itemTabSeqNum\": 0, \"cartItems\": { \"cartItem\": [ { \"discountAmount\": 0.0, \"deviceDollarApplied\": 0.0, \"qrScanNeededForEsimActivation\": false, \"isPreconfigureDuringAddDevice\": false, \"deviceDisplayName\": \"GALAXY S24U 256 VL\", \"accessoryGiftCardAmount\": 0.0, \"tradeInAmountTowardsUserDPUsed\": 0.0, \"sorDeviceCategory\": \"5G Smartphone\", \"sorDeviceType\": \"5GE\", \"operatingSystem\": \"Android\", \"vendingKioskItem\": \"false\", \"canonicalUrl\": \"smartphones/samsung-galaxy-s24-ultra/\", \"bogoItem\": false, \"refxItemSeqNum\": 0, \"sorProductFamily\": \"GALAXY S24 ULTRA\", \"giftCard\": false, \"itemCode\": \"SMS928UZVV\", \"totalPriceWithDiscount\": 1299.99, \"sorId\": \"SMS928UZVV\", \"skuId\": \"sku6010133\", \"cartItemType\": \"DEVICEE\", \"mobileNumber\": \"6413528577\", \"minNumber\": \"6417505600\", \"description\": \"Galaxy S24 Ultra\", \"capacity\": \"256 GB\", \"qty\": 1, \"bundleSeqNum\": 0, \"itemPrice\": \"1299.99\", \"deviceId\": \"\", \"discountedPercentage\": 0.0, \"discountedPrice\": 1299.99, \"buyOutTaxAmountUnbilled\": 0.0, \"buyOutAmountWithoutTax\": 0.0, \"taxAmount\": 0.0, \"imageUrlMap\": { \"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet\", \"largeImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet?$device-lg$\", \"mediumImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet?$device-med$\", \"miniImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet?$device-mini$\", \"thumbImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet?$device-thumb$\" }, \"prodCode1\": \"5GD\", \"prodCode2\": \"SMT\", \"prodCode3\": \"DIG\", \"prodCode4\": \"VDS\", \"prodCode5\": \"ISL\", \"priceType\": \"VERIZON_EDGE\", \"deviceDueMonthly\": 36.11, \"btaEligible\": \"true\", \"depletionType\": \"F\", \"catalogPrice\": 1299.99, \"instantCreditAmountUsed\": 0.0, \"instantCreditAmountUsedForTaxes\": 0.0, \"color\": { \"color\": \"#746f86\", \"colorDisplayName\": \"TITANIUM VIOLET\" }, \"unitTaxBasedPrice\": 1299.99, \"itemNrpPrice\": 1299.99, \"itemCost\": 1299.99, \"upgradeReasonCode\": \"\", \"upgradeReasonDesc\": \"Invalid Reason Code - 0yr\", \"itemPriceType\": \"R\", \"discounts\": [], \"availableReasonCode\": [], \"itemSeqNum\": 1, \"sddEligible\": true, \"smartIMEI\": false, \"year\": 0, \"sellerPrice\": \"0.0\", \"edgeDeviceCap\": \"1299.99\", \"productId\": \"dev21411188\", \"numberShareCapabilityInfo\": { \"sorHdVoiceInd\": true, \"isNumberShareCapable\": false, \"isNumberShareMandatory\": false }, \"taxDetailsList\": [], \"hasDeviceUnlockPolicy\": true, \"manufacturer\": \"Samsung\", \"iconicPhone\": false, \"ringBell\": false, \"quantityAllowed\": false } ] }, \"depletionLocation\": \"\", \"isPromoSelected\": false, \"isTradeInSelected\": false, \"taxExemptionTypes\": \"\" } ], \"assignMTNIndicator\": \"Y\", \"mtnDetails\": { \"dummyMTNForDomain\": \"9437711401\", \"lineNumber\": \"newLine1\", \"minNumber\": \"6417505600\", \"mobileNumber\": \"6413528577\", \"assignMTNTimestamp\": \"2024-04-23T16:35:51.313473-04:00[US/Eastern]\", \"npaNXX\": \"641352\" }, \"lineNumber\": \"newLine1\", \"fiveGToFourGDownGrade\": false, \"deviceTypeSelected\": \"Smartphones\", \"deviceCategoryName\": \"Smartphones\", \"reasonCode\": \"PLAN_DEVICE_COMPATIBLE\", \"disqualifiedPropositions\": [], \"qualifiedPropositions\": [], \"lineCreator\": \"9194377114\", \"lineRefundTotal\": 0.0, \"lineExchangeTotal\": 1299.99, \"totalDueMonthlyBeforeCredit\": 0.0, \"sugAllowed\": false, \"totalDueAddOnMonthly\": 0.0, \"totalPriceOfPlanAndPerks\": \"0.0\", \"isCpe\": false, \"isLTEHomeLine\": false, \"isDevicePlanCompatible\": false, \"portinMtnAssignment\": false, \"impactedLine\": false, \"preOrBackOrder\": false, \"ispuItem\": false, \"ispuItemBYOD\": false, \"isModConnected\": false, \"modDevice\": false, \"byodCapable\": false, \"isCarLine\": false, \"buySimOnly\": false, \"broadBandInd\": false, \"ispuDownPaymentAdjstRequired\": false, \"ispuDownPaymentAmount\": 0.0, \"lineWithSkipMDN\": false, \"protectionNotRequired\": false } ], \"numOfAccessoryAndDeviceItemsInCart\": 1, \"totalEdgeUpAmount\": 0.0, \"totalEdgeBuyOutAmount\": 0.0, \"tradeInDetail\": {}, \"totalDownPaymentAmt\": 0.0, \"numOfLinesWithDevices\": 1, \"subscriptionInfos\": [], \"numofApprovedLines\": 0, \"rfexPayments\": [], \"cartId\": \"f9f76751-1bed-4d8f-ae9e-dfe7896117a8\", \"numOfLines\": 2, \"numofLinesAAL\": 1, \"numofLinesEUP\": 1, \"payments\": [], \"lineSeq\": 0, \"acctMcsSubscription\": [], \"spendingLimitAmountExceededBy\": \"1299.99\", \"numofAccessories\": 0, \"subAccountNBSInfo\": [], \"bagTax\": false, \"couponDetails\": [ {} ] }, \"displayCartValidationErrors\": true }, \"warningMessages\": [], \"redesignFlow\": false, \"isLocalStoreOfferEnabled\": false }";
        CXPRetrieveCartDataVO cart = mapper.readValue(sampleCartString, CXPRetrieveCartDataVO.class);
        cartSession.setRetrieveCart(cart);
        cartSession.setCustomerProfile(profileResponse);

        sampleCartString = "{ \"cart\": { \"cartHasOnlyAccessories\": false, \"cartHasConflicts\": true, \"conflictsAccepted\": false, \"cartHeader\": { \"vendorId\": \"NETACE\", \"ani\": 9194377114, \"repRole\": \"POSSYSTST\", \"locationType\": \"S\", \"sourceSystem\": \"OMNI-RETAIL\", \"cartId\": \"f9f76751-1bed-4d8f-ae9e-dfe7896117a8\", \"fullAccountNumber\": \"0319507991-1\", \"status\": \"A\", \"cartCreator\": \"9194377114\", \"cartCreatorChannelId\": \"OMNI-RETAIL\", \"cartCreatorOrderLocationCode\": \"P332201\", \"cartCreatorSalesRepId\": \"ENC\", \"caseId\": \"SOP-14196606-C01\", \"visionCustomerType\": \"PE\", \"isERTRep\": false }, \"orderDetails\": { \"totalTaxAmount\": \"0.0\", \"totalPerksSavings\": \"0.0\" }, \"lineDetails\": { \"lineInfo\": [ { \"isCommonPDP\": false, \"isTradeInIntentSelected\": false, \"multiLineSeqNumber\": 2, \"lineActivityType\": \"AAL\", \"totalDueToday\": 1299.99, \"totalDueTodayWithoutTax\": 1299.99, \"totalDueTodayWithoutTaxWithoutDiscount\": 1299.99, \"totalDueMonthly\": 0.0, \"mobileNumber\": \"9194377114\", \"showGlobalChoiceOffer\": false, \"itemsInfo\": [ { \"depletionType\": \"F\", \"attention\": \"RAVI WRIGHT\", \"shipping\": { \"address\": { \"firmName\": \"\", \"apartmentNo\": \"\", \"streetDirection\": \"\" }, \"bsnsName\": \"\", \"shipToCustomerAddress\": false }, \"fipsCode\": \"3403503340\", \"itemCount\": 1, \"itemTabSeqNum\": 0, \"cartItems\": { \"cartItem\": [ { \"discountAmount\": 0.0, \"deviceDollarApplied\": 0.0, \"qrScanNeededForEsimActivation\": false, \"isPreconfigureDuringAddDevice\": false, \"deviceDisplayName\": \"GALAXY S24U 256 VL\", \"accessoryGiftCardAmount\": 0.0, \"tradeInAmountTowardsUserDPUsed\": 0.0, \"sorDeviceCategory\": \"5G Smartphone\", \"sorDeviceType\": \"5GE\", \"operatingSystem\": \"Android\", \"vendingKioskItem\": \"false\", \"canonicalUrl\": \"smartphones/samsung-galaxy-s24-ultra/\", \"bogoItem\": false, \"refxItemSeqNum\": 0, \"sorProductFamily\": \"GALAXY S24 ULTRA\", \"giftCard\": false, \"itemCode\": \"SMS928UZVV\", \"totalPriceWithDiscount\": 1299.99, \"sorId\": \"SMS928UZVV\", \"skuId\": \"sku6010133\", \"cartItemType\": \"\", \"mobileNumber\": \"6413528577\", \"minNumber\": \"6417505600\", \"description\": \"Galaxy S24 Ultra\", \"capacity\": \"256 GB\", \"qty\": 1, \"bundleSeqNum\": 0, \"itemPrice\": \"1299.99\", \"deviceId\": \"\", \"discountedPercentage\": 0.0, \"discountedPrice\": 1299.99, \"buyOutTaxAmountUnbilled\": 0.0, \"buyOutAmountWithoutTax\": 0.0, \"taxAmount\": 0.0, \"imageUrlMap\": { \"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet\", \"largeImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet?$device-lg$\", \"mediumImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet?$device-med$\", \"miniImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet?$device-mini$\", \"thumbImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet?$device-thumb$\" }, \"prodCode1\": \"5GD\", \"prodCode2\": \"SMT\", \"prodCode3\": \"DIG\", \"prodCode4\": \"VDS\", \"prodCode5\": \"ISL\", \"priceType\": \"VERIZON_EDGE\", \"deviceDueMonthly\": 36.11, \"btaEligible\": \"true\", \"depletionType\": \"F\", \"catalogPrice\": 1299.99, \"instantCreditAmountUsed\": 0.0, \"instantCreditAmountUsedForTaxes\": 0.0, \"color\": { \"color\": \"#746f86\", \"colorDisplayName\": \"TITANIUM VIOLET\" }, \"unitTaxBasedPrice\": 1299.99, \"itemNrpPrice\": 1299.99, \"itemCost\": 1299.99, \"upgradeReasonCode\": \"\", \"upgradeReasonDesc\": \"Invalid Reason Code - 0yr\", \"itemPriceType\": \"R\", \"discounts\": [], \"availableReasonCode\": [], \"itemSeqNum\": 1, \"sddEligible\": true, \"smartIMEI\": false, \"year\": 0, \"sellerPrice\": \"0.0\", \"edgeDeviceCap\": \"1299.99\", \"productId\": \"dev21411188\", \"numberShareCapabilityInfo\": { \"sorHdVoiceInd\": true, \"isNumberShareCapable\": false, \"isNumberShareMandatory\": false }, \"taxDetailsList\": [], \"hasDeviceUnlockPolicy\": true, \"manufacturer\": \"Samsung\", \"iconicPhone\": false, \"ringBell\": false, \"quantityAllowed\": false } ] }, \"depletionLocation\": \"\", \"isPromoSelected\": false, \"isTradeInSelected\": false, \"taxExemptionTypes\": \"\" } ], \"assignMTNIndicator\": \"Y\", \"mtnDetails\": { \"dummyMTNForDomain\": \"9437711401\", \"lineNumber\": \"newLine1\", \"minNumber\": \"6417505600\", \"mobileNumber\": \"6413528577\", \"assignMTNTimestamp\": \"2024-04-23T16:35:51.313473-04:00[US/Eastern]\", \"npaNXX\": \"641352\" }, \"lineNumber\": \"newLine1\", \"fiveGToFourGDownGrade\": false, \"deviceTypeSelected\": \"Smartphones\", \"deviceCategoryName\": \"Smartphones\", \"reasonCode\": \"PLAN_DEVICE_COMPATIBLE\", \"disqualifiedPropositions\": [], \"qualifiedPropositions\": [], \"lineCreator\": \"9194377114\", \"lineRefundTotal\": 0.0, \"lineExchangeTotal\": 1299.99, \"totalDueMonthlyBeforeCredit\": 0.0, \"sugAllowed\": false, \"totalDueAddOnMonthly\": 0.0, \"totalPriceOfPlanAndPerks\": \"0.0\", \"isCpe\": false, \"isLTEHomeLine\": false, \"isDevicePlanCompatible\": false, \"portinMtnAssignment\": false, \"impactedLine\": false, \"preOrBackOrder\": false, \"ispuItem\": false, \"ispuItemBYOD\": false, \"isModConnected\": false, \"modDevice\": false, \"byodCapable\": false, \"isCarLine\": false, \"buySimOnly\": false, \"broadBandInd\": false, \"ispuDownPaymentAdjstRequired\": false, \"ispuDownPaymentAmount\": 0.0, \"lineWithSkipMDN\": false, \"protectionNotRequired\": false } ], \"numOfAccessoryAndDeviceItemsInCart\": 1, \"totalEdgeUpAmount\": 0.0, \"totalEdgeBuyOutAmount\": 0.0, \"tradeInDetail\": {}, \"totalDownPaymentAmt\": 0.0, \"numOfLinesWithDevices\": 1, \"subscriptionInfos\": [], \"numofApprovedLines\": 0, \"rfexPayments\": [], \"cartId\": \"f9f76751-1bed-4d8f-ae9e-dfe7896117a8\", \"numOfLines\": 2, \"numofLinesAAL\": 1, \"numofLinesEUP\": 1, \"payments\": [], \"lineSeq\": 0, \"acctMcsSubscription\": [], \"spendingLimitAmountExceededBy\": \"1299.99\", \"numofAccessories\": 0, \"subAccountNBSInfo\": [], \"bagTax\": false, \"couponDetails\": [ {} ] }, \"displayCartValidationErrors\": true }, \"warningMessages\": [], \"redesignFlow\": false, \"isLocalStoreOfferEnabled\": false }";
        cart = mapper.readValue(sampleCartString, CXPRetrieveCartDataVO.class);
        cartSession.setRetrieveCart(cart);
        cartSession.setCustomerProfile(profileResponse);

        Assert.assertNotNull(omniDLHelper.getVzdlTxnDataForRemoveDevice(request, cartSession));
        sampleCartString = "{ \"cart\": { \"cartHasOnlyAccessories\": false, \"cartHasConflicts\": true, \"conflictsAccepted\": false, \"cartHeader\": { \"vendorId\": \"NETACE\", \"ani\": 9194377114, \"repRole\": \"POSSYSTST\", \"locationType\": \"S\", \"sourceSystem\": \"OMNI-RETAIL\", \"cartId\": \"f9f76751-1bed-4d8f-ae9e-dfe7896117a8\", \"fullAccountNumber\": \"0319507991-1\", \"status\": \"A\", \"cartCreator\": \"9194377114\", \"cartCreatorChannelId\": \"OMNI-RETAIL\", \"cartCreatorOrderLocationCode\": \"P332201\", \"cartCreatorSalesRepId\": \"ENC\", \"caseId\": \"SOP-14196606-C01\", \"visionCustomerType\": \"PE\", \"isERTRep\": false }, \"orderDetails\": { \"totalTaxAmount\": \"0.0\", \"totalPerksSavings\": \"0.0\" }, \"lineDetails\": { \"lineInfo\": [ { \"isCommonPDP\": false, \"isTradeInIntentSelected\": false, \"multiLineSeqNumber\": 2, \"lineActivityType\": \"AAL\", \"totalDueToday\": 1299.99, \"totalDueTodayWithoutTax\": 1299.99, \"totalDueTodayWithoutTaxWithoutDiscount\": 1299.99, \"totalDueMonthly\": 0.0, \"mobileNumber\": \"9194377114\", \"showGlobalChoiceOffer\": false, \"itemsInfo\": [ { \"depletionType\": \"F\", \"attention\": \"RAVI WRIGHT\", \"shipping\": { \"address\": { \"firmName\": \"\", \"apartmentNo\": \"\", \"streetDirection\": \"\" }, \"bsnsName\": \"\", \"shipToCustomerAddress\": false }, \"fipsCode\": \"3403503340\", \"itemCount\": 1, \"itemTabSeqNum\": 0, \"cartItems\": { \"cartItem\": [ { \"discountAmount\": 0.0, \"deviceDollarApplied\": 0.0, \"qrScanNeededForEsimActivation\": false, \"isPreconfigureDuringAddDevice\": false, \"deviceDisplayName\": \"GALAXY S24U 256 VL\", \"accessoryGiftCardAmount\": 0.0, \"tradeInAmountTowardsUserDPUsed\": 0.0, \"sorDeviceCategory\": \"5G Smartphone\", \"sorDeviceType\": \"5GE\", \"operatingSystem\": \"Android\", \"vendingKioskItem\": \"false\", \"canonicalUrl\": \"smartphones/samsung-galaxy-s24-ultra/\", \"bogoItem\": false, \"refxItemSeqNum\": 0, \"sorProductFamily\": \"GALAXY S24 ULTRA\", \"giftCard\": false, \"itemCode\": \"SMS928UZVV\", \"totalPriceWithDiscount\": 1299.99, \"sorId\": \"SMS928UZVV\", \"skuId\": \"sku6010133\", \"mobileNumber\": \"6413528577\", \"minNumber\": \"6417505600\", \"description\": \"Galaxy S24 Ultra\", \"capacity\": \"256 GB\", \"qty\": 1, \"bundleSeqNum\": 0, \"itemPrice\": \"1299.99\", \"deviceId\": \"\", \"discountedPercentage\": 0.0, \"discountedPrice\": 1299.99, \"buyOutTaxAmountUnbilled\": 0.0, \"buyOutAmountWithoutTax\": 0.0, \"taxAmount\": 0.0, \"imageUrlMap\": { \"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet\", \"largeImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet?$device-lg$\", \"mediumImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet?$device-med$\", \"miniImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet?$device-mini$\", \"thumbImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet?$device-thumb$\" }, \"prodCode1\": \"5GD\", \"prodCode2\": \"SMT\", \"prodCode3\": \"DIG\", \"prodCode4\": \"VDS\", \"prodCode5\": \"ISL\", \"priceType\": \"VERIZON_EDGE\", \"deviceDueMonthly\": 36.11, \"btaEligible\": \"true\", \"depletionType\": \"F\", \"catalogPrice\": 1299.99, \"instantCreditAmountUsed\": 0.0, \"instantCreditAmountUsedForTaxes\": 0.0, \"color\": { \"color\": \"#746f86\", \"colorDisplayName\": \"TITANIUM VIOLET\" }, \"unitTaxBasedPrice\": 1299.99, \"itemNrpPrice\": 1299.99, \"itemCost\": 1299.99, \"upgradeReasonCode\": \"\", \"upgradeReasonDesc\": \"Invalid Reason Code - 0yr\", \"itemPriceType\": \"R\", \"discounts\": [], \"availableReasonCode\": [], \"itemSeqNum\": 1, \"sddEligible\": true, \"smartIMEI\": false, \"year\": 0, \"sellerPrice\": \"0.0\", \"edgeDeviceCap\": \"1299.99\", \"productId\": \"dev21411188\", \"numberShareCapabilityInfo\": { \"sorHdVoiceInd\": true, \"isNumberShareCapable\": false, \"isNumberShareMandatory\": false }, \"taxDetailsList\": [], \"hasDeviceUnlockPolicy\": true, \"manufacturer\": \"Samsung\", \"iconicPhone\": false, \"ringBell\": false, \"quantityAllowed\": false } ] }, \"depletionLocation\": \"\", \"isPromoSelected\": false, \"isTradeInSelected\": false, \"taxExemptionTypes\": \"\" } ], \"assignMTNIndicator\": \"Y\", \"mtnDetails\": { \"dummyMTNForDomain\": \"9437711401\", \"lineNumber\": \"newLine1\", \"minNumber\": \"6417505600\", \"mobileNumber\": \"6413528577\", \"assignMTNTimestamp\": \"2024-04-23T16:35:51.313473-04:00[US/Eastern]\", \"npaNXX\": \"641352\" }, \"lineNumber\": \"newLine1\", \"fiveGToFourGDownGrade\": false, \"deviceTypeSelected\": \"Smartphones\", \"deviceCategoryName\": \"Smartphones\", \"reasonCode\": \"PLAN_DEVICE_COMPATIBLE\", \"disqualifiedPropositions\": [], \"qualifiedPropositions\": [], \"lineCreator\": \"9194377114\", \"lineRefundTotal\": 0.0, \"lineExchangeTotal\": 1299.99, \"totalDueMonthlyBeforeCredit\": 0.0, \"sugAllowed\": false, \"totalDueAddOnMonthly\": 0.0, \"totalPriceOfPlanAndPerks\": \"0.0\", \"isCpe\": false, \"isLTEHomeLine\": false, \"isDevicePlanCompatible\": false, \"portinMtnAssignment\": false, \"impactedLine\": false, \"preOrBackOrder\": false, \"ispuItem\": false, \"ispuItemBYOD\": false, \"isModConnected\": false, \"modDevice\": false, \"byodCapable\": false, \"isCarLine\": false, \"buySimOnly\": false, \"broadBandInd\": false, \"ispuDownPaymentAdjstRequired\": false, \"ispuDownPaymentAmount\": 0.0, \"lineWithSkipMDN\": false, \"protectionNotRequired\": false } ], \"numOfAccessoryAndDeviceItemsInCart\": 1, \"totalEdgeUpAmount\": 0.0, \"totalEdgeBuyOutAmount\": 0.0, \"tradeInDetail\": {}, \"totalDownPaymentAmt\": 0.0, \"numOfLinesWithDevices\": 1, \"subscriptionInfos\": [], \"numofApprovedLines\": 0, \"rfexPayments\": [], \"cartId\": \"f9f76751-1bed-4d8f-ae9e-dfe7896117a8\", \"numOfLines\": 2, \"numofLinesAAL\": 1, \"numofLinesEUP\": 1, \"payments\": [], \"lineSeq\": 0, \"acctMcsSubscription\": [], \"spendingLimitAmountExceededBy\": \"1299.99\", \"numofAccessories\": 0, \"subAccountNBSInfo\": [], \"bagTax\": false, \"couponDetails\": [ {} ] }, \"displayCartValidationErrors\": true }, \"warningMessages\": [], \"redesignFlow\": false, \"isLocalStoreOfferEnabled\": false }";
        cart = mapper.readValue(sampleCartString, CXPRetrieveCartDataVO.class);
        cartSession.setRetrieveCart(cart);
        Assert.assertNotNull(omniDLHelper.getVzdlTxnDataForRemoveDevice(request, cartSession));

        Assert.assertNotNull(omniDLHelper.getVzdlTxnDataForRemoveDevice(request, cartSession));
        sampleCartString = "{ \"cart\": { \"cartHasOnlyAccessories\": false, \"cartHasConflicts\": true, \"conflictsAccepted\": false, \"cartHeader\": { \"vendorId\": \"NETACE\", \"ani\": 9194377114, \"repRole\": \"POSSYSTST\", \"locationType\": \"S\", \"sourceSystem\": \"OMNI-RETAIL\", \"cartId\": \"f9f76751-1bed-4d8f-ae9e-dfe7896117a8\", \"fullAccountNumber\": \"0319507991-1\", \"status\": \"A\", \"cartCreator\": \"9194377114\", \"cartCreatorChannelId\": \"OMNI-RETAIL\", \"cartCreatorOrderLocationCode\": \"P332201\", \"cartCreatorSalesRepId\": \"ENC\", \"caseId\": \"SOP-14196606-C01\", \"visionCustomerType\": \"PE\", \"isERTRep\": false }, \"orderDetails\": { \"totalTaxAmount\": \"0.0\", \"totalPerksSavings\": \"0.0\" }, \"lineDetails\": { \"lineInfo\": [ { \"isCommonPDP\": false, \"isTradeInIntentSelected\": false, \"multiLineSeqNumber\": 2, \"lineActivityType\": \"AAL\", \"totalDueToday\": 1299.99, \"totalDueTodayWithoutTax\": 1299.99, \"totalDueTodayWithoutTaxWithoutDiscount\": 1299.99, \"totalDueMonthly\": 0.0, \"mobileNumber\": \"9194377114\", \"showGlobalChoiceOffer\": false, \"itemsInfo\": [ { \"depletionType\": \"F\", \"attention\": \"RAVI WRIGHT\", \"shipping\": { \"address\": { \"firmName\": \"\", \"apartmentNo\": \"\", \"streetDirection\": \"\" }, \"bsnsName\": \"\", \"shipToCustomerAddress\": false }, \"fipsCode\": \"3403503340\", \"itemCount\": 1, \"itemTabSeqNum\": 0, \"cartItems\": {}, \"depletionLocation\": \"\", \"isPromoSelected\": false, \"isTradeInSelected\": false, \"taxExemptionTypes\": \"\" } ], \"assignMTNIndicator\": \"Y\", \"mtnDetails\": { \"dummyMTNForDomain\": \"9437711401\", \"lineNumber\": \"newLine1\", \"minNumber\": \"6417505600\", \"mobileNumber\": \"6413528577\", \"assignMTNTimestamp\": \"2024-04-23T16:35:51.313473-04:00[US/Eastern]\", \"npaNXX\": \"641352\" }, \"lineNumber\": \"newLine1\", \"fiveGToFourGDownGrade\": false, \"deviceTypeSelected\": \"Smartphones\", \"deviceCategoryName\": \"Smartphones\", \"reasonCode\": \"PLAN_DEVICE_COMPATIBLE\", \"disqualifiedPropositions\": [], \"qualifiedPropositions\": [], \"lineCreator\": \"9194377114\", \"lineRefundTotal\": 0.0, \"lineExchangeTotal\": 1299.99, \"totalDueMonthlyBeforeCredit\": 0.0, \"sugAllowed\": false, \"totalDueAddOnMonthly\": 0.0, \"totalPriceOfPlanAndPerks\": \"0.0\", \"isCpe\": false, \"isLTEHomeLine\": false, \"isDevicePlanCompatible\": false, \"portinMtnAssignment\": false, \"impactedLine\": false, \"preOrBackOrder\": false, \"ispuItem\": false, \"ispuItemBYOD\": false, \"isModConnected\": false, \"modDevice\": false, \"byodCapable\": false, \"isCarLine\": false, \"buySimOnly\": false, \"broadBandInd\": false, \"ispuDownPaymentAdjstRequired\": false, \"ispuDownPaymentAmount\": 0.0, \"lineWithSkipMDN\": false, \"protectionNotRequired\": false } ], \"numOfAccessoryAndDeviceItemsInCart\": 1, \"totalEdgeUpAmount\": 0.0, \"totalEdgeBuyOutAmount\": 0.0, \"tradeInDetail\": {}, \"totalDownPaymentAmt\": 0.0, \"numOfLinesWithDevices\": 1, \"subscriptionInfos\": [], \"numofApprovedLines\": 0, \"rfexPayments\": [], \"cartId\": \"f9f76751-1bed-4d8f-ae9e-dfe7896117a8\", \"numOfLines\": 2, \"numofLinesAAL\": 1, \"numofLinesEUP\": 1, \"payments\": [], \"lineSeq\": 0, \"acctMcsSubscription\": [], \"spendingLimitAmountExceededBy\": \"1299.99\", \"numofAccessories\": 0, \"subAccountNBSInfo\": [], \"bagTax\": false, \"couponDetails\": [ {} ] }, \"displayCartValidationErrors\": true }, \"warningMessages\": [], \"redesignFlow\": false, \"isLocalStoreOfferEnabled\": false }";
        cart = mapper.readValue(sampleCartString, CXPRetrieveCartDataVO.class);
        cartSession.setRetrieveCart(cart);
        Assert.assertNotNull(omniDLHelper.getVzdlTxnDataForRemoveDevice(request, cartSession));

        Assert.assertNotNull(omniDLHelper.getVzdlTxnDataForRemoveDevice(request, cartSession));
        sampleCartString = "{ \"cart\": { \"cartHasOnlyAccessories\": false, \"cartHasConflicts\": true, \"conflictsAccepted\": false, \"cartHeader\": { \"vendorId\": \"NETACE\", \"ani\": 9194377114, \"repRole\": \"POSSYSTST\", \"locationType\": \"S\", \"sourceSystem\": \"OMNI-RETAIL\", \"cartId\": \"f9f76751-1bed-4d8f-ae9e-dfe7896117a8\", \"fullAccountNumber\": \"0319507991-1\", \"status\": \"A\", \"cartCreator\": \"9194377114\", \"cartCreatorChannelId\": \"OMNI-RETAIL\", \"cartCreatorOrderLocationCode\": \"P332201\", \"cartCreatorSalesRepId\": \"ENC\", \"caseId\": \"SOP-14196606-C01\", \"visionCustomerType\": \"PE\", \"isERTRep\": false }, \"orderDetails\": { \"totalTaxAmount\": \"0.0\", \"totalPerksSavings\": \"0.0\" }, \"lineDetails\": { \"lineInfo\": [ { \"isCommonPDP\": false, \"isTradeInIntentSelected\": false, \"multiLineSeqNumber\": 2, \"lineActivityType\": \"AAL\", \"totalDueToday\": 1299.99, \"totalDueTodayWithoutTax\": 1299.99, \"totalDueTodayWithoutTaxWithoutDiscount\": 1299.99, \"totalDueMonthly\": 0.0, \"mobileNumber\": \"9194377114\", \"showGlobalChoiceOffer\": false, \"itemsInfo\": [ { \"depletionType\": \"F\", \"attention\": \"RAVI WRIGHT\", \"shipping\": { \"address\": { \"firmName\": \"\", \"apartmentNo\": \"\", \"streetDirection\": \"\" }, \"bsnsName\": \"\", \"shipToCustomerAddress\": false }, \"fipsCode\": \"3403503340\", \"itemCount\": 1, \"itemTabSeqNum\": 0, \"depletionLocation\": \"\", \"isPromoSelected\": false, \"isTradeInSelected\": false, \"taxExemptionTypes\": \"\" } ], \"assignMTNIndicator\": \"Y\", \"mtnDetails\": { \"dummyMTNForDomain\": \"9437711401\", \"lineNumber\": \"newLine1\", \"minNumber\": \"6417505600\", \"mobileNumber\": \"6413528577\", \"assignMTNTimestamp\": \"2024-04-23T16:35:51.313473-04:00[US/Eastern]\", \"npaNXX\": \"641352\" }, \"lineNumber\": \"newLine1\", \"fiveGToFourGDownGrade\": false, \"deviceTypeSelected\": \"Smartphones\", \"deviceCategoryName\": \"Smartphones\", \"reasonCode\": \"PLAN_DEVICE_COMPATIBLE\", \"disqualifiedPropositions\": [], \"qualifiedPropositions\": [], \"lineCreator\": \"9194377114\", \"lineRefundTotal\": 0.0, \"lineExchangeTotal\": 1299.99, \"totalDueMonthlyBeforeCredit\": 0.0, \"sugAllowed\": false, \"totalDueAddOnMonthly\": 0.0, \"totalPriceOfPlanAndPerks\": \"0.0\", \"isCpe\": false, \"isLTEHomeLine\": false, \"isDevicePlanCompatible\": false, \"portinMtnAssignment\": false, \"impactedLine\": false, \"preOrBackOrder\": false, \"ispuItem\": false, \"ispuItemBYOD\": false, \"isModConnected\": false, \"modDevice\": false, \"byodCapable\": false, \"isCarLine\": false, \"buySimOnly\": false, \"broadBandInd\": false, \"ispuDownPaymentAdjstRequired\": false, \"ispuDownPaymentAmount\": 0.0, \"lineWithSkipMDN\": false, \"protectionNotRequired\": false } ], \"numOfAccessoryAndDeviceItemsInCart\": 1, \"totalEdgeUpAmount\": 0.0, \"totalEdgeBuyOutAmount\": 0.0, \"tradeInDetail\": {}, \"totalDownPaymentAmt\": 0.0, \"numOfLinesWithDevices\": 1, \"subscriptionInfos\": [], \"numofApprovedLines\": 0, \"rfexPayments\": [], \"cartId\": \"f9f76751-1bed-4d8f-ae9e-dfe7896117a8\", \"numOfLines\": 2, \"numofLinesAAL\": 1, \"numofLinesEUP\": 1, \"payments\": [], \"lineSeq\": 0, \"acctMcsSubscription\": [], \"spendingLimitAmountExceededBy\": \"1299.99\", \"numofAccessories\": 0, \"subAccountNBSInfo\": [], \"bagTax\": false, \"couponDetails\": [ {} ] }, \"displayCartValidationErrors\": true }, \"warningMessages\": [], \"redesignFlow\": false, \"isLocalStoreOfferEnabled\": false }";
        cart = mapper.readValue(sampleCartString, CXPRetrieveCartDataVO.class);
        cartSession.setRetrieveCart(cart);
        Assert.assertNotNull(omniDLHelper.getVzdlTxnDataForRemoveDevice(request, cartSession));


        Assert.assertNotNull(omniDLHelper.getVzdlTxnDataForRemoveDevice(request, cartSession));
        sampleCartString = "{ \"cart\": { \"cartHasOnlyAccessories\": false, \"cartHasConflicts\": true, \"conflictsAccepted\": false, \"cartHeader\": { \"vendorId\": \"NETACE\", \"ani\": 9194377114, \"repRole\": \"POSSYSTST\", \"locationType\": \"S\", \"sourceSystem\": \"OMNI-RETAIL\", \"cartId\": \"f9f76751-1bed-4d8f-ae9e-dfe7896117a8\", \"fullAccountNumber\": \"0319507991-1\", \"status\": \"A\", \"cartCreator\": \"9194377114\", \"cartCreatorChannelId\": \"OMNI-RETAIL\", \"cartCreatorOrderLocationCode\": \"P332201\", \"cartCreatorSalesRepId\": \"ENC\", \"caseId\": \"SOP-14196606-C01\", \"visionCustomerType\": \"PE\", \"isERTRep\": false }, \"orderDetails\": { \"totalTaxAmount\": \"0.0\", \"totalPerksSavings\": \"0.0\" }, \"lineDetails\": { \"lineInfo\": [ { \"isCommonPDP\": false, \"isTradeInIntentSelected\": false, \"multiLineSeqNumber\": 2, \"lineActivityType\": \"AAL\", \"totalDueToday\": 1299.99, \"totalDueTodayWithoutTax\": 1299.99, \"totalDueTodayWithoutTaxWithoutDiscount\": 1299.99, \"totalDueMonthly\": 0.0, \"mobileNumber\": \"9194377114\", \"showGlobalChoiceOffer\": false, \"assignMTNIndicator\": \"Y\", \"mtnDetails\": { \"dummyMTNForDomain\": \"9437711401\", \"lineNumber\": \"newLine1\", \"minNumber\": \"6417505600\", \"mobileNumber\": \"6413528577\", \"assignMTNTimestamp\": \"2024-04-23T16:35:51.313473-04:00[US/Eastern]\", \"npaNXX\": \"641352\" }, \"lineNumber\": \"newLine1\", \"fiveGToFourGDownGrade\": false, \"deviceTypeSelected\": \"Smartphones\", \"deviceCategoryName\": \"Smartphones\", \"reasonCode\": \"PLAN_DEVICE_COMPATIBLE\", \"disqualifiedPropositions\": [], \"qualifiedPropositions\": [], \"lineCreator\": \"9194377114\", \"lineRefundTotal\": 0.0, \"lineExchangeTotal\": 1299.99, \"totalDueMonthlyBeforeCredit\": 0.0, \"sugAllowed\": false, \"totalDueAddOnMonthly\": 0.0, \"totalPriceOfPlanAndPerks\": \"0.0\", \"isCpe\": false, \"isLTEHomeLine\": false, \"isDevicePlanCompatible\": false, \"portinMtnAssignment\": false, \"impactedLine\": false, \"preOrBackOrder\": false, \"ispuItem\": false, \"ispuItemBYOD\": false, \"isModConnected\": false, \"modDevice\": false, \"byodCapable\": false, \"isCarLine\": false, \"buySimOnly\": false, \"broadBandInd\": false, \"ispuDownPaymentAdjstRequired\": false, \"ispuDownPaymentAmount\": 0.0, \"lineWithSkipMDN\": false, \"protectionNotRequired\": false } ], \"numOfAccessoryAndDeviceItemsInCart\": 1, \"totalEdgeUpAmount\": 0.0, \"totalEdgeBuyOutAmount\": 0.0, \"tradeInDetail\": {}, \"totalDownPaymentAmt\": 0.0, \"numOfLinesWithDevices\": 1, \"subscriptionInfos\": [], \"numofApprovedLines\": 0, \"rfexPayments\": [], \"cartId\": \"f9f76751-1bed-4d8f-ae9e-dfe7896117a8\", \"numOfLines\": 2, \"numofLinesAAL\": 1, \"numofLinesEUP\": 1, \"payments\": [], \"lineSeq\": 0, \"acctMcsSubscription\": [], \"spendingLimitAmountExceededBy\": \"1299.99\", \"numofAccessories\": 0, \"subAccountNBSInfo\": [], \"bagTax\": false, \"couponDetails\": [ {} ] }, \"displayCartValidationErrors\": true }, \"warningMessages\": [], \"redesignFlow\": false, \"isLocalStoreOfferEnabled\": false }";
        cart = mapper.readValue(sampleCartString, CXPRetrieveCartDataVO.class);
        cartSession.setRetrieveCart(cart);
        Assert.assertNull(omniDLHelper.getVzdlTxnDataForRemoveDevice(request, cartSession));

        request.getData().getLines()[0].setMtn("12345");
        Assert.assertNull(omniDLHelper.getVzdlTxnDataForRemoveDevice(request, cartSession));

        request.getData().getLines()[0].setMtn(null);
        Assert.assertNull(omniDLHelper.getVzdlTxnDataForRemoveDevice(request, cartSession));


        cartSession.getRetrieveCart().getCart().getLineDetails().getLineInfo()[0].setMobileNumber(null);
        Assert.assertNull(omniDLHelper.getVzdlTxnDataForRemoveDevice(request, cartSession));

        cartSession.getRetrieveCart().getCart().setLineDetails(null);
        Assert.assertNull(omniDLHelper.getVzdlTxnDataForRemoveDevice(request, cartSession));

        cartSession.setRetrieveCart(null);
        Assert.assertNull(omniDLHelper.getVzdlTxnDataForRemoveDevice(request, cartSession));

        request.getData().setLines(null);
        Assert.assertNull(omniDLHelper.getVzdlTxnDataForRemoveDevice(request, cartSession));

        request.getData().setLines(new Lines[0]);
        Assert.assertNull(omniDLHelper.getVzdlTxnDataForRemoveDevice(request, cartSession));

        Assert.assertNotNull(omniDLHelper.populateVzdlDataForRemoveDevice(request, cartSession));
    }

    @Test
    public void getVzdlDataForRemoveDevice(){

        omniDLHelper.getVzdlDataForRemoveDevice(null, null, null);
        RemoveLinesUIRequest request = new RemoveLinesUIRequest();
        RemoveLinesUIResponse response =  new RemoveLinesUIResponse();
        CartRedisData session = new CartRedisData();
        omniDLHelper.getVzdlDataForRemoveDevice(request, response, session);

        request.setCartInfo(new CartInfo());
        omniDLHelper.getVzdlDataForRemoveDevice(request, response, session);

        CartInfo info = new CartInfo();
        info.setProcessAction("delete");
        request.setCartInfo(info);
        omniDLHelper.getVzdlDataForRemoveDevice(request, response, session);

        request.getCartInfo().setProcessAction(null);
        response.setServiceBody(null);
        omniDLHelper.getVzdlDataForRemoveDevice(request, response, session);

        request.getCartInfo().setProcessAction("removeDevice");
        response.setServiceBody(new RemoveLinesServiceBody());
        omniDLHelper.getVzdlDataForRemoveDevice(request, response, session);

    }
    @Test
    public void setCurrentDataForRemoveDeviceTest(){
        CXPCartItem cxpCartItem = new CXPCartItem();
        cxpCartItem.setPriceType("VERIZON_EDGE");
        cxpCartItem.setDeviceDueMonthly(32.11);
        omniDLHelper.setCurrentDataForRemoveDevice(cxpCartItem , null, new HashMap<>(), new CartRedisData() , new ArrayList<>());

        cxpCartItem = new CXPCartItem();
        cxpCartItem.setPriceType("VERIZON_EDGE1");
        omniDLHelper.setCurrentDataForRemoveDevice(cxpCartItem , null, new HashMap<>(), new CartRedisData() , new ArrayList<>());

        cxpCartItem = new CXPCartItem();
        cxpCartItem.setPriceType("VERIZON_EDGE");
        cxpCartItem.setDeviceDueMonthly(null);
        omniDLHelper.setCurrentDataForRemoveDevice(cxpCartItem , null, new HashMap<>(), new CartRedisData() , new ArrayList<>());

    }

    @Test
    public void updatePageData1Test() throws JsonProcessingException {
        Vzdl vzdl = new Vzdl();
        AddPlanUIRequest request = new AddPlanUIRequest();
        omniDLHelper.updatePageData(vzdl, request);

        String requestString = "{ \"cartInfo\": { \"processingMTN\": \"6413543766\", \"processStep\": \"PlanSelection\" }, \"data\": { \"lines\": [ { \"mtn\": \"9194377114\", \"addFeatures\": [ { \"id\": \"2839\", \"quantity\": \"1\", \"actionIndicator\": \"A\", \"type\": \"SPO\" } ], \"removeFeatures\": [], \"linechanged\": false, \"plan\": { \"id\": \"63217\", \"isRecommendedPlan\": false, \"recommender\": \"\", \"path\": \"Popular Plan\" } }, { \"mtn\": \"6413543733\", \"addFeatures\": [ { \"id\": \"2678\", \"quantity\": \"1\", \"actionIndicator\": \"A\", \"type\": \"SPO\" } ], \"removeFeatures\": [], \"linechanged\": false, \"plan\": { \"id\": \"69185\", \"isRecommendedPlan\": false, \"recommender\": \"\", \"path\": \"Build Plan\" } } ], \"parentMtn\": \"\", \"enableAssistedTagging\": true, \"isPerksSelectedFromVT\": \"N\" } }";
        request = mapper.readValue(requestString, AddPlanUIRequest.class);


        CartInfo cartInfo = new CartInfo();
        request.setCartInfo(cartInfo);
        request.getCartInfo().setSessionId("");
        omniDLHelper.updatePageData(vzdl, request);

        requestString = "{ \"cartInfo\": { \"processingMTN\": \"6413543766\", \"processStep\": \"PlanSelection\" }, \"data\": { \"lines\": [ { \"mtn\": \"9194377114\", \"addFeatures\": [ { \"id\": \"2839\", \"quantity\": \"1\", \"actionIndicator\": \"A\", \"type\": \"SPO\" } ], \"removeFeatures\": [], \"linechanged\": true, \"plan\": { \"id\": \"63217\", \"isRecommendedPlan\": false, \"recommender\": \"\", \"path\": \"Popular Plan\" } }, { \"mtn\": \"6413543733\", \"addFeatures\": [ { \"id\": \"2678\", \"quantity\": \"1\", \"actionIndicator\": \"A\", \"type\": \"SPO\" } ], \"removeFeatures\": [], \"linechanged\": false, \"plan\": { \"id\": \"69185\", \"isRecommendedPlan\": false, \"recommender\": \"\", \"path\": \"Build Plan\" } } ], \"parentMtn\": \"\", \"enableAssistedTagging\": true, \"isPerksSelectedFromVT\": \"N\" } }";
        request = mapper.readValue(requestString, AddPlanUIRequest.class);
        omniDLHelper.updatePageData(vzdl, request);

        requestString = "{ \"cartInfo\": { \"processingMTN\": \"6413543766\", \"processStep\": \"PlanSelection\" }, \"data\": { \"lines\": [ { \"mtn\": \"9194377114\", \"addFeatures\": [ { \"id\": \"2839\", \"quantity\": \"1\", \"actionIndicator\": \"A\", \"type\": \"SPO\" } ], \"removeFeatures\": [], \"plan\": { \"id\": \"63217\", \"isRecommendedPlan\": false, \"recommender\": \"\", \"path\": \"Popular Plan\" } }, { \"mtn\": \"6413543733\", \"addFeatures\": [ { \"id\": \"2678\", \"quantity\": \"1\", \"actionIndicator\": \"A\", \"type\": \"SPO\" } ], \"removeFeatures\": [], \"linechanged\": false, \"plan\": { \"id\": \"69185\", \"isRecommendedPlan\": false, \"recommender\": \"\", \"path\": \"Build Plan\" } } ], \"parentMtn\": \"\", \"enableAssistedTagging\": true, \"isPerksSelectedFromVT\": \"N\" } }";
        request = mapper.readValue(requestString, AddPlanUIRequest.class);
        omniDLHelper.updatePageData(vzdl, request);

        requestString = "{ \"cartInfo\": { \"processingMTN\": \"6413543766\", \"processStep\": \"PlanSelection\" }, \"data\": { \"lines\": [ { \"addFeatures\": [ { \"id\": \"2839\", \"quantity\": \"1\", \"actionIndicator\": \"A\", \"type\": \"SPO\" } ], \"removeFeatures\": [], \"linechanged\": true, \"plan\": { \"id\": \"63217\", \"isRecommendedPlan\": false, \"recommender\": \"\", \"path\": \"Popular Plan\" } }, { \"addFeatures\": [ { \"id\": \"2678\", \"quantity\": \"1\", \"actionIndicator\": \"A\", \"type\": \"SPO\" } ], \"removeFeatures\": [], \"linechanged\": false, \"plan\": { \"id\": \"69185\", \"isRecommendedPlan\": false, \"recommender\": \"\", \"path\": \"Build Plan\" } } ], \"parentMtn\": \"\", \"enableAssistedTagging\": true, \"isPerksSelectedFromVT\": \"N\" } }";
        request = mapper.readValue(requestString, AddPlanUIRequest.class);
        omniDLHelper.updatePageData(vzdl, request);

        requestString = "{ \"cartInfo\": { \"processingMTN\": \"6413543766\", \"processStep\": \"PlanSelection\" }, \"data\": { \"lines\": [ {} ], \"parentMtn\": \"\", \"enableAssistedTagging\": true, \"isPerksSelectedFromVT\": \"N\" } }";
        request = mapper.readValue(requestString, AddPlanUIRequest.class);
        omniDLHelper.updatePageData(vzdl, request);

        requestString = "{ \"cartInfo\": { \"processingMTN\": \"6413543766\", \"processStep\": \"PlanSelection\" }, \"data\": { \"lines\": [ { \"mtn\": \"9194377114\", \"addFeatures\": [ { \"id\": \"2839\", \"quantity\": \"1\", \"actionIndicator\": \"A\", \"type\": \"SPO\" } ], \"removeFeatures\": [], \"linechanged\": true, \"plan\": { \"id\": \"63217\", \"isRecommendedPlan\": false, \"recommender\": \"\", \"path\": \"Popular Plan\" } }, { \"mtn\": \"6413543733\", \"addFeatures\": [ { \"id\": \"2678\", \"quantity\": \"1\", \"actionIndicator\": \"A\", \"type\": \"SPO\" } ], \"removeFeatures\": [], \"linechanged\": false, \"plan\": { \"id\": \"69185\", \"isRecommendedPlan\": false, \"recommender\": \"\", \"path\": \"Build Plan\" } } ], \"parentMtn\": \"\", \"enableAssistedTagging\": true, \"isPerksSelectedFromVT\": \"N\" } }";
        request = mapper.readValue(requestString, AddPlanUIRequest.class);
        request.setChannelId(null);
        request.getCartInfo().setIntendType("AAL");

        omniDLHelper.updatePageData(vzdl, request);
        Assert.assertNotNull(vzdl.getPage());

        requestString = "{ \"cartInfo\": { \"processingMTN\": \"6413543766\", \"processStep\": \"PlanSelection\" }, \"data\": { \"lines\": [ { \"mtn\": \"91943771\", \"addFeatures\": [ { \"id\": \"2839\", \"quantity\": \"1\", \"actionIndicator\": \"A\", \"type\": \"SPO\" } ], \"removeFeatures\": [], \"linechanged\": true, \"plan\": { \"id\": \"63217\", \"isRecommendedPlan\": false, \"recommender\": \"\", \"path\": \"Popular Plan\" } }, { \"mtn\": \"6413543\", \"addFeatures\": [ { \"id\": \"2678\", \"quantity\": \"1\", \"actionIndicator\": \"A\", \"type\": \"SPO\" } ], \"removeFeatures\": [], \"linechanged\": false, \"plan\": { \"id\": \"69185\", \"isRecommendedPlan\": false, \"recommender\": \"\", \"path\": \"Build Plan\" } } ], \"parentMtn\": \"\", \"enableAssistedTagging\": true, \"isPerksSelectedFromVT\": \"N\" } }";
        request = mapper.readValue(requestString, AddPlanUIRequest.class);
        request.getCartInfo().setIntendType("AAL");
        omniDLHelper.updatePageData(vzdl, request);
        Assert.assertNotNull(vzdl.getPage());

        request.getCartInfo().setIntendType("EUP");
        omniDLHelper.updatePageData(vzdl, request);
        Assert.assertNotNull(vzdl.getPage());

        request.getCartInfo().setIntendType(CartConstants.CPC);
        omniDLHelper.updatePageData(vzdl, request);

        request.setChannelId(CartConstants.RETAIL_IPAD);
        omniDLHelper.updatePageData(vzdl, request);

        request.setChannelId(CartConstants.RETAIL_IPAD);
        omniDLHelper.updatePageData(vzdl, request);
    }

    @Test
    public void updateNewlineFlow() throws JsonProcessingException {
        CreateLineUIRequest request = new CreateLineUIRequest();
        omniDLHelper.updateNewLineFlowName(request);

        request.setCartInfo(new CartInfo());
        omniDLHelper.updateNewLineFlowName(request);

        request.getCartInfo().setIntendType(null);
        omniDLHelper.updateNewLineFlowName(request);

        request.getCartInfo().setIntendType("AAL");
        request.setData(null);
        omniDLHelper.updateNewLineFlowName(request);

        request.getCartInfo().setIntendType("AAL");
        request.setData(new CreateLineData());
        omniDLHelper.updateNewLineFlowName(request);

        request.getData().setLines(null);
        omniDLHelper.updateNewLineFlowName(request);

        request.getData().setLines(new ArrayList<>());
        omniDLHelper.updateNewLineFlowName(request);

        List<Lines> linesList= new ArrayList<>();
        linesList.add(new Lines());
        Lines lines= new Lines();
        lines.setDeviceTypeSelected(null);
        request.getData().setLines(linesList);
        request.setFlowName(null);
        omniDLHelper.updateNewLineFlowName(request);

        request.setFlowName("AAL");
        omniDLHelper.updateNewLineFlowName(request);

        linesList= new ArrayList<>();
        lines= new Lines();
        lines.setDeviceTypeSelected("device");
        request.getData().setLines(linesList);
        request.setFlowName(null);
        omniDLHelper.updateNewLineFlowName(request);

        String requestObj = "{ \"cartInfo\": { \"processStep\": \"MTNSelectionPage\", \"intendType\": \"AAL\" }, \"data\": { \"lines\": [ { \"mtn\": \"\", \"deviceTypeSelected\": \"Smartphones\" }, { \"mtn\": \"\", \"deviceTypeSelected\": \"5G Internet\" } ] } }";
        request = mapper.readValue(requestObj, CreateLineUIRequest.class);
        assertEquals("AAL|AAL_5G",omniDLHelper.updateNewLineFlowName(request));

        requestObj = "{ \"cartInfo\": { \"processStep\": \"MTNSelectionPage\", \"intendType\": \"NSE\" }, \"data\": { \"lines\": [ { \"mtn\": \"\", \"deviceTypeSelected\": \"Smartphones\" }, { \"mtn\": \"\", \"deviceTypeSelected\": \"5G Internet\" } ] } }";
        request = mapper.readValue(requestObj, CreateLineUIRequest.class);
        assertEquals("NSE|NSE_5G",omniDLHelper.updateNewLineFlowName(request));


        requestObj = "{ \"cartInfo\": { \"processStep\": \"MTNSelectionPage\", \"intendType\": \"NSE\" }, \"data\": { \"lines\": [ { \"mtn\": \"\",  \"isByod\": true, \"deviceTypeSelected\": \"Smartphones\" }, { \"mtn\": \"\", \"deviceTypeSelected\": \"5G Internet\" } ] } }";
        request = mapper.readValue(requestObj, CreateLineUIRequest.class);
        assertEquals("NSE|NSE_5G",omniDLHelper.updateNewLineFlowName(request));

        requestObj = "{ \"cartInfo\": { \"processStep\": \"MTNSelectionPage\", \"intendType\": \"AAL_5G\" }, \"data\": { \"lines\": [ { \"mtn\": \"\", \"deviceTypeSelected\": \"Smartphones\" } ] } }";
        request = mapper.readValue(requestObj, CreateLineUIRequest.class);
        assertEquals("AAL",omniDLHelper.updateNewLineFlowName(request));

        requestObj = "{ \"cartInfo\": { \"processStep\": \"MTNSelectionPage\", \"intendType\": \"AAL_5G\" }, \"data\": { \"lines\": [ { \"isByod\": true,\"mtn\": \"\", \"deviceTypeSelected\": \"Smartphones\" } ] } }";
        request = mapper.readValue(requestObj, CreateLineUIRequest.class);
        assertEquals("AAL",omniDLHelper.updateNewLineFlowName(request));


        requestObj = "{ \"cartInfo\": { \"processStep\": \"MTNSelectionPage\", \"intendType\": \"NSE\" }, \"data\": { \"lines\": [ { \"mtn\": \"\", \"deviceTypeSelected\": \"Smartphones\" }, { \"mtn\": \"\", \"deviceTypeSelected\": \"5G \" } ] } }";
        request = mapper.readValue(requestObj, CreateLineUIRequest.class);
        assertEquals("NSE",omniDLHelper.updateNewLineFlowName(request));

        requestObj = "{ \"flowName\": \"NSE\",\"cartInfo\": { \"processStep\": \"MTNSelectionPage\", \"intendType\": \"NSE\" }, \"data\": { \"lines\": [ { \"mtn\": \"\", \"deviceTypeSelected\": \"Smartphones\" }, { \"mtn\": \"\", \"deviceTypeSelected\": \"5G \" } ] } }";
        request = mapper.readValue(requestObj, CreateLineUIRequest.class);
        assertEquals("NSE",omniDLHelper.updateNewLineFlowName(request));

        requestObj = "{ \"cartInfo\": { \"processStep\": \"MTNSelectionPage\", \"intendType\": \"NSE\" }, \"data\": { \"lines\": [ { } ] } }";
        request = mapper.readValue(requestObj, CreateLineUIRequest.class);
        omniDLHelper.updateNewLineFlowName(request);

        requestObj = "{ \"cartInfo\": { \"processStep\": \"MTNSelectionPage\", \"intendType\": \"NSE\" } }";
        request = mapper.readValue(requestObj, CreateLineUIRequest.class);
        omniDLHelper.updateNewLineFlowName(request);

        requestObj = "{ \"cartInfo\": { \"processStep\": \"MTNSelectionPage\"} }";
        request = mapper.readValue(requestObj, CreateLineUIRequest.class);
        omniDLHelper.updateNewLineFlowName(request);
        request.setCartInfo(null);
        omniDLHelper.updateNewLineFlowName(request);
    }

    @Test
    public void getFlowTest(){
        when(sessionBean.setSessionData(any(),any())).thenReturn(Mono.just(true));
        when(redisHelper.addFlowNameToRedis(Mockito.any())).thenReturn(Mono.just(true));
        AddPlanUIRequest request= new AddPlanUIRequest();
        CXPRetrieveCartDataVO cart= new CXPRetrieveCartDataVO();
        request.setData(null);
        StepVerifier.create(omniDLHelper.getFlow(request, cart)).expectComplete().verify();

        request.setData(new AddPlanData());
        StepVerifier.create(omniDLHelper.getFlow(request, cart)).expectComplete().verify();

        request.getData().setLines(null);
        StepVerifier.create(omniDLHelper.getFlow(request, cart)).expectComplete().verify();

        request.getData().setLines(new Lines[0]);
        StepVerifier.create(omniDLHelper.getFlow(request, cart)).expectComplete().verify();

        request.getData().setLines(new Lines[1]);
        StepVerifier.create(omniDLHelper.getFlow(request, cart)).assertNext(Assert::assertNotNull).expectComplete().verify();

        List<Lines> lines= new ArrayList<>();
        lines.add(null);
        Lines line1= new Lines();
        line1.setMtn(null);
        lines.add(line1);
        Lines[] lineArr= new Lines[lines.size()];
        lines.toArray(lineArr);
        request.getData().setLines(lineArr);
        StepVerifier.create(omniDLHelper.getFlow(request, cart)).assertNext(Assert::assertNotNull).expectComplete().verify();

        lines= new ArrayList<>();
        line1= new Lines();
        line1.setMtn("123");
        line1.setLinechanged(null);
        lines.add(line1);
        lineArr= new Lines[lines.size()];
        lines.toArray(lineArr);
        request.getData().setLines(lineArr);
        StepVerifier.create(omniDLHelper.getFlow(request, cart)).assertNext(Assert::assertNotNull).expectComplete().verify();

        lines= new ArrayList<>();
        line1= new Lines();
        line1.setMtn("123");
        line1.setLinechanged(Boolean.FALSE);
        lines.add(line1);
        lineArr= new Lines[lines.size()];
        lines.toArray(lineArr);
        request.getData().setLines(lineArr);
        StepVerifier.create(omniDLHelper.getFlow(request, cart)).assertNext(Assert::assertNotNull).expectComplete().verify();

        lines= new ArrayList<>();
        line1= new Lines();
        line1.setMtn("123");
        line1.setLinechanged(Boolean.TRUE);
        lines.add(line1);
        lineArr= new Lines[lines.size()];
        lines.toArray(lineArr);
        request.getData().setLines(lineArr);
        StepVerifier.create(omniDLHelper.getFlow(request, cart)).assertNext(Assert::assertNotNull).expectComplete().verify();

        cart.setCart(new CXPCartVO());
        request.setCartInfo(null);
        StepVerifier.create(omniDLHelper.getFlow(request, cart)).assertNext(Assert::assertNotNull).expectComplete().verify();

        cart.getCart().setLineDetails(new CXPLineDetailsVO());
        request.setCartInfo(new CartInfo());
        request.getCartInfo().setIntendType(null);
        StepVerifier.create(omniDLHelper.getFlow(request, cart)).assertNext(Assert::assertNotNull).expectComplete().verify();

        request.getCartInfo().setIntendType("");
        StepVerifier.create(omniDLHelper.getFlow(request, cart)).assertNext(Assert::assertNotNull).expectComplete().verify();

        request.getCartInfo().setIntendType("null");
        StepVerifier.create(omniDLHelper.getFlow(request, cart)).assertNext(Assert::assertNotNull).expectComplete().verify();

        request.getCartInfo().setIntendType("cpc");
        StepVerifier.create(omniDLHelper.getFlow(request, cart)).assertNext(Assert::assertNotNull).expectComplete().verify();

        cart.getCart().getLineDetails().setLineInfo(new CXPLineInfo[2]);
        StepVerifier.create(omniDLHelper.getFlow(request, cart)).assertNext(Assert::assertNotNull).expectComplete().verify();

        List<CXPLineInfo> lineInfos= new ArrayList<>();
        lineInfos.add(null);
        CXPLineInfo lineInfo= new CXPLineInfo();
        lineInfo.setMobileNumber(null);
        lineInfos.add(lineInfo);
        CXPLineInfo[] lineInfoArr= new CXPLineInfo[lineInfos.size()];
        lineInfos.toArray(lineInfoArr);
        cart.getCart().getLineDetails().setLineInfo(lineInfoArr);
        StepVerifier.create(omniDLHelper.getFlow(request, cart)).assertNext(Assert::assertNotNull).expectComplete().verify();

        lineInfos= new ArrayList<>();
        lineInfo= new CXPLineInfo();
        lineInfo.setMobileNumber("123");
        lineInfo.setLineActivityType(null);
        lineInfos.add(lineInfo);
        lineInfoArr= new CXPLineInfo[lineInfos.size()];
        lineInfos.toArray(lineInfoArr);
        cart.getCart().getLineDetails().setLineInfo(lineInfoArr);
        StepVerifier.create(omniDLHelper.getFlow(request, cart)).assertNext(Assert::assertNotNull).expectComplete().verify();

        lineInfos= new ArrayList<>();
        lineInfo= new CXPLineInfo();
        lineInfo.setMobileNumber("12334");
        lineInfo.setLineActivityType("eup");
        lineInfos.add(lineInfo);
        lineInfoArr= new CXPLineInfo[lineInfos.size()];
        lineInfos.toArray(lineInfoArr);
        cart.getCart().getLineDetails().setLineInfo(lineInfoArr);
        StepVerifier.create(omniDLHelper.getFlow(request, cart)).assertNext(Assert::assertNotNull).expectComplete().verify();

        lineInfos= new ArrayList<>();
        lineInfo= new CXPLineInfo();
        lineInfo.setMobileNumber("123");
        lineInfo.setLineActivityType("eup1");
        lineInfos.add(lineInfo);
        lineInfoArr= new CXPLineInfo[lineInfos.size()];
        lineInfos.toArray(lineInfoArr);
        cart.getCart().getLineDetails().setLineInfo(lineInfoArr);
        StepVerifier.create(omniDLHelper.getFlow(request, cart)).assertNext(Assert::assertNotNull).expectComplete().verify();

        lineInfos= new ArrayList<>();
        lineInfo= new CXPLineInfo();
        lineInfo.setMobileNumber("123");
        lineInfo.setLineActivityType("EUP");
        lineInfos.add(lineInfo);
        lineInfoArr= new CXPLineInfo[lineInfos.size()];
        lineInfos.toArray(lineInfoArr);
        cart.getCart().getLineDetails().setLineInfo(lineInfoArr);
        StepVerifier.create(omniDLHelper.getFlow(request, cart)).assertNext(Assert::assertNotNull).expectComplete().verify();
    }
    @Test
    public void updateNewlineFlow1() throws JsonProcessingException {
        CreateLineUIRequest request ;
        String requestObj = "{ \"cartInfo\": { \"processStep\": \"MTNSelectionPage\", \"intendType\": \"AAL\" }, \"data\": { \"lines\": [ { \"mtn\": \"\", \"deviceTypeSelected\": \"Smartphones\" }, { \"mtn\": \"\", \"deviceTypeSelected\": \"5G Internet\" } ] } }";
        request = mapper.readValue(requestObj, CreateLineUIRequest.class);
        omniDLHelper.updateNewLineFlowName(request);
        assertEquals("AAL|AAL_5G|AAL|AAL_5G",omniDLHelper.updateNewLineFlowName(request));

        requestObj = "{ \"cartInfo\": { \"processStep\": \"MTNSelectionPage\", \"intendType\": \"AAL_5G\" }, \"data\": { \"lines\": [ { \"mtn\": \"\", \"deviceTypeSelected\": \"Smartphones\" }, { \"mtn\": \"\", \"deviceTypeSelected\": \"5G Internet\" } ] } }";
        request = mapper.readValue(requestObj, CreateLineUIRequest.class);
        omniDLHelper.updateNewLineFlowName(request);
        assertEquals("AAL|AAL_5G|AAL|AAL_5G",omniDLHelper.updateNewLineFlowName(request));

        requestObj = "{ \"cartInfo\": { \"processStep\": \"MTNSelectionPage\", \"intendType\": \"AAL_5G\" }, \"data\": { \"lines\": [ { \"mtn\": \"\", \"deviceTypeSelected\": \"Smartphones\" } ] } }";
        request = mapper.readValue(requestObj, CreateLineUIRequest.class);
        omniDLHelper.updateNewLineFlowName(request);
        assertEquals("AAL",omniDLHelper.updateNewLineFlowName(request));

        requestObj = "{ \"cartInfo\": { \"processStep\": \"MTNSelectionPage\", \"intendType\": \"NSE\" }, \"data\": { \"lines\": [ { \"mtn\": \"\", \"deviceTypeSelected\": \"Smartphones\" }, { \"mtn\": \"\", \"deviceTypeSelected\": \"5G Internet\" } ] } }";
        request = mapper.readValue(requestObj, CreateLineUIRequest.class);
        omniDLHelper.updateNewLineFlowName(request);
        assertEquals("NSE|NSE_5G|NSE|NSE_5G",omniDLHelper.updateNewLineFlowName(request));

        requestObj = "{ \"cartInfo\": { \"processStep\": \"MTNSelectionPage\", \"intendType\": \"NSE\" }, \"data\": { \"lines\": [ { } ] } }";
        request = mapper.readValue(requestObj, CreateLineUIRequest.class);
        omniDLHelper.updateNewLineFlowName(request);

        requestObj = "{ \"cartInfo\": { \"processStep\": \"MTNSelectionPage\", \"intendType\": \"NSE\" } }";
        request = mapper.readValue(requestObj, CreateLineUIRequest.class);
        omniDLHelper.updateNewLineFlowName(request);

        requestObj = "{ \"cartInfo\": { \"processStep\": \"MTNSelectionPage\"} }";
        request = mapper.readValue(requestObj, CreateLineUIRequest.class);
        omniDLHelper.updateNewLineFlowName(request);
        request.setCartInfo(null);
        omniDLHelper.updateNewLineFlowName(request);

    }


    @Test
    public void setGroupValueTest(){
        AddPlanUIRequest request= new AddPlanUIRequest();
        List<PlanTaggingDetails> planTaggingDetailsList= new ArrayList<>();
        planTaggingDetailsList.add(null);
        planTaggingDetailsList.add(new PlanTaggingDetails());
        request.setPlanTaggingDetails(planTaggingDetailsList);
        omniDLHelper.setGroupValue("", request);
        omniDLHelper.setGroupValue(null, request);
        omniDLHelper.setGroupValue("345", request);

        planTaggingDetailsList= new ArrayList<>();
        PlanTaggingDetails node= new PlanTaggingDetails();
        node.setMtn("");
        planTaggingDetailsList.add(node);
        request.setPlanTaggingDetails(planTaggingDetailsList);
        omniDLHelper.setGroupValue("345", request);

        planTaggingDetailsList= new ArrayList<>();
        node= new PlanTaggingDetails();
        node.setMtn(null);
        planTaggingDetailsList.add(node);
        request.setPlanTaggingDetails(planTaggingDetailsList);
        omniDLHelper.setGroupValue("345", request);

        planTaggingDetailsList= new ArrayList<>();
        node= new PlanTaggingDetails();
        node.setMtn("123");
        node.setGroup(23);
        planTaggingDetailsList.add(node);
        request.setPlanTaggingDetails(planTaggingDetailsList);
        Assert.assertEquals("24", omniDLHelper.setGroupValue("345", request));
        Assert.assertEquals("23",omniDLHelper.setGroupValue("123", request));

    }

    @Test
    public void setActionPathGroupTest(){
        AddPlanUIRequest request= new AddPlanUIRequest();
        request.setPlanTaggingDetails(null);
        Current current= new Current();
        Lines lines= new Lines();
        lines.setMtn("123");
        omniDLHelper.setActionPathGroup(request,current,lines);

        request.setPlanTaggingDetails(new ArrayList<>());
        omniDLHelper.setActionPathGroup(request,current,lines);
        Assert.assertEquals("1",current.getGroup());

        List<PlanTaggingDetails>planTaggingDetail= new ArrayList<>();
        PlanTaggingDetails planTaggingDetails= new PlanTaggingDetails();
        planTaggingDetails.setMtn("123");
        planTaggingDetail.add(planTaggingDetails);
        request.setPlanTaggingDetails(planTaggingDetail);
        omniDLHelper.setActionPathGroup(request,current,lines);
    }

    @Test
    public void isMtnInPlanTaggingTest(){
        omniDLHelper.isMtnInPlanTagging(null,null);
        omniDLHelper.isMtnInPlanTagging(new ArrayList<>(),null);

        List<PlanTaggingDetails> planTaggingDetail= new ArrayList<>();
        planTaggingDetail.add(null);
        omniDLHelper.isMtnInPlanTagging(planTaggingDetail,null);

        planTaggingDetail= new ArrayList<>();
        planTaggingDetail.add(new PlanTaggingDetails());
        omniDLHelper.isMtnInPlanTagging(planTaggingDetail,null);

        Lines lines= new Lines();
        omniDLHelper.isMtnInPlanTagging(planTaggingDetail,lines);

        planTaggingDetail= new ArrayList<>();
        PlanTaggingDetails planTaggingDetails= new PlanTaggingDetails();
        planTaggingDetails.setMtn(null);
        planTaggingDetail.add(planTaggingDetails);
        omniDLHelper.isMtnInPlanTagging(planTaggingDetail,lines);

        planTaggingDetail= new ArrayList<>();
        planTaggingDetails= new PlanTaggingDetails();
        planTaggingDetails.setMtn("");
        planTaggingDetail.add(planTaggingDetails);
        omniDLHelper.isMtnInPlanTagging(planTaggingDetail,lines);

        planTaggingDetail= new ArrayList<>();
        planTaggingDetails= new PlanTaggingDetails();
        planTaggingDetails.setMtn("123");
        planTaggingDetail.add(planTaggingDetails);
        lines.setMtn(null);
        omniDLHelper.isMtnInPlanTagging(planTaggingDetail,lines);

        lines.setMtn("");
        omniDLHelper.isMtnInPlanTagging(planTaggingDetail,lines);

        lines.setMtn("678");
        omniDLHelper.isMtnInPlanTagging(planTaggingDetail,lines);

        lines.setMtn("123");
        Assert.assertTrue(omniDLHelper.isMtnInPlanTagging(planTaggingDetail,lines).isPresent());
    }

    @Test
    public void updateTaggingDetailsTest(){
        AddPlanUIRequest request= new AddPlanUIRequest();
        request.setPlanTaggingDetails(null);
        omniDLHelper.updateTaggingDetails(null,null,request);
        request.setPlanTaggingDetails(new ArrayList<>());
        omniDLHelper.updateTaggingDetails(null,null,request );

        List<PlanTaggingDetails> planTaggingDetailsList= new ArrayList<>();
        planTaggingDetailsList.add(null);
        planTaggingDetailsList.add(new PlanTaggingDetails());
        request.setPlanTaggingDetails(planTaggingDetailsList);
        omniDLHelper.updateTaggingDetails(null,null,request );

        CXPRetrieveCartDataVO retrieveCart= new CXPRetrieveCartDataVO();
        retrieveCart.setCart(new CXPCartVO());
        omniDLHelper.updateTaggingDetails(null,retrieveCart,request );

        retrieveCart.getCart().setLineDetails(new CXPLineDetailsVO());
        retrieveCart.getCart().getLineDetails().setLineInfo(new CXPLineInfo[1]);
        omniDLHelper.updateTaggingDetails(null,retrieveCart,request );

        List<CXPLineInfo> list= new ArrayList<>();
        list.add(null);
        CXPLineInfo[] array= new CXPLineInfo[list.size()];
        list.toArray(array);
        retrieveCart.getCart().getLineDetails().setLineInfo(array);
        omniDLHelper.updateTaggingDetails(null,retrieveCart,request );

        planTaggingDetailsList= new ArrayList<>();
        PlanTaggingDetails node= new PlanTaggingDetails();
        node.setMtn(null);
        planTaggingDetailsList.add(node);
        request.setPlanTaggingDetails(planTaggingDetailsList);
        omniDLHelper.updateTaggingDetails(null,retrieveCart,request );

        planTaggingDetailsList= new ArrayList<>();
        node= new PlanTaggingDetails();
        node.setMtn("");
        planTaggingDetailsList.add(node);
        request.setPlanTaggingDetails(planTaggingDetailsList);
        omniDLHelper.updateTaggingDetails(null,retrieveCart,request );

        planTaggingDetailsList= new ArrayList<>();
        node= new PlanTaggingDetails();
        node.setMtn("123");
        planTaggingDetailsList.add(node);
        request.setPlanTaggingDetails(planTaggingDetailsList);
        omniDLHelper.updateTaggingDetails(null,retrieveCart,request );

        list= new ArrayList<>();
        CXPLineInfo line= new CXPLineInfo();
        line.setMtnDetails(null);
        list.add(line);
        array= new CXPLineInfo[list.size()];
        list.toArray(array);
        retrieveCart.getCart().getLineDetails().setLineInfo(array);
        omniDLHelper.updateTaggingDetails("",retrieveCart,request );

        omniDLHelper.updateTaggingDetails("123",retrieveCart,request );

        list= new ArrayList<>();
        line= new CXPLineInfo();
        line.setMtnDetails(new MtnDetails());
        line.getMtnDetails().setLineNumber("");
        list.add(line);
        array= new CXPLineInfo[list.size()];
        list.toArray(array);
        retrieveCart.getCart().getLineDetails().setLineInfo(array);
        omniDLHelper.updateTaggingDetails("123",retrieveCart,request );

        list= new ArrayList<>();
        line= new CXPLineInfo();
        line.setMtnDetails(new MtnDetails());
        line.getMtnDetails().setLineNumber(null);
        list.add(line);
        array= new CXPLineInfo[list.size()];
        list.toArray(array);
        retrieveCart.getCart().getLineDetails().setLineInfo(array);
        omniDLHelper.updateTaggingDetails("123",retrieveCart,request );

        list= new ArrayList<>();
        line= new CXPLineInfo();
        line.setMtnDetails(new MtnDetails());
        line.getMtnDetails().setLineNumber("345");
        line.setMobileNumber(null);
        list.add(line);
        array= new CXPLineInfo[list.size()];
        list.toArray(array);
        retrieveCart.getCart().getLineDetails().setLineInfo(array);
        omniDLHelper.updateTaggingDetails("123",retrieveCart,request );

        list= new ArrayList<>();
        line= new CXPLineInfo();
        line.setMtnDetails(new MtnDetails());
        line.getMtnDetails().setLineNumber("345");
        line.setMobileNumber("");
        list.add(line);
        array= new CXPLineInfo[list.size()];
        list.toArray(array);
        retrieveCart.getCart().getLineDetails().setLineInfo(array);
        omniDLHelper.updateTaggingDetails("123",retrieveCart,request );

        list= new ArrayList<>();
        line= new CXPLineInfo();
        line.setMtnDetails(new MtnDetails());
        line.getMtnDetails().setLineNumber("345");
        line.setMobileNumber("345");
        list.add(line);
        array= new CXPLineInfo[list.size()];
        list.toArray(array);
        retrieveCart.getCart().getLineDetails().setLineInfo(array);
        omniDLHelper.updateTaggingDetails("123",retrieveCart,request );

        list= new ArrayList<>();
        line= new CXPLineInfo();
        line.setMtnDetails(new MtnDetails());
        line.getMtnDetails().setLineNumber("123");
        line.setMobileNumber("123");
        list.add(line);
        array= new CXPLineInfo[list.size()];
        list.toArray(array);
        retrieveCart.getCart().getLineDetails().setLineInfo(array);
        omniDLHelper.updateTaggingDetails("123",retrieveCart,request );

        list= new ArrayList<>();
        line= new CXPLineInfo();
        line.setMtnDetails(new MtnDetails());
        line.getMtnDetails().setLineNumber("345");
        line.setMobileNumber("123");
        list.add(line);
        array= new CXPLineInfo[list.size()];
        list.toArray(array);
        retrieveCart.getCart().getLineDetails().setLineInfo(array);
        omniDLHelper.updateTaggingDetails("123",retrieveCart,request );

        planTaggingDetailsList= new ArrayList<>();
        node= new PlanTaggingDetails();
        node.setMtn("345");
        node.setGroup(4);
        planTaggingDetailsList.add(node);
        request.setPlanTaggingDetails(planTaggingDetailsList);
        Assert.assertEquals(Integer.valueOf(4),omniDLHelper.updateTaggingDetails("123",retrieveCart,request ));
    }
    @Test
    public void upsertPlanTaggingValueToRedisTest(){
        when(redisHelper.addPlanTaggingDetailsToRedis(Mockito.any())).thenReturn(Mono.just(true));
        StepVerifier.create(omniDLHelper.upsertPlanTaggingValueToRedis(null)).assertNext(Assert::assertFalse).expectComplete();
        StepVerifier.create(omniDLHelper.upsertPlanTaggingValueToRedis(new ArrayList<>())).assertNext(Assert::assertFalse).expectComplete();

        List<PlanTaggingDetails> list= new ArrayList<>();
        PlanTaggingDetails planTaggingDetails=new PlanTaggingDetails();
        planTaggingDetails.setPath("path");
        planTaggingDetails.setGroup(9);
        planTaggingDetails.setAction("action");
        planTaggingDetails.setMtn("mtn");
        list.add(planTaggingDetails);
        StepVerifier.create(omniDLHelper.upsertPlanTaggingValueToRedis(list)).assertNext(Assert::assertFalse).expectComplete();
    }
    @Test
    public void updateTxnDataForOrderReviewWithEmptyTest()  {
        Vzdl vzdl=new Vzdl();
        cxpResponse.setData(null);
        Vzdl result=omniDLHelper.updateTxnDataForOrderReviewPage(cxpResponse,vzdl);
        assertTrue(result.getTxn().isEmpty());

    }
    @Test
    public void testUpdateForOrderReviewPageWithEmptyData(){
        Vzdl vzdl=new Vzdl();
        Vzdl result=omniDLHelper.updateTxnDataForOrderReviewPage(null,vzdl);
        assertTrue(result.getTxn().isEmpty());

    }
    @Test
    public void testUpdateforOrderReviewPageWithOrderDetails(){
        CXPOrderDetails orderDetails=new CXPOrderDetails();
        orderDetails.setOrderType("Online");
        orderDetails.setTotalTaxAmount("5.00");
        orderDetails.setTotalShippingCost(10.0);
        orderDetails.setTotalDueToday(15.00);
        CXPCartVO cartVO=new CXPCartVO();
        cartVO.setOrderDetails(orderDetails);
        CXPRetrieveCartDataVO data=new CXPRetrieveCartDataVO();
        data.setCart(cartVO);
        cxpResponse.setData(data);
        Vzdl vzdl=new Vzdl();
        Vzdl result=omniDLHelper.updateTxnDataForOrderReviewPage(cxpResponse,vzdl);
        Map<String,String> expectedTxn=new HashMap<>();
        expectedTxn.put("taxAmt","5.00");
        expectedTxn.put("shippingTotal","10.0");
        expectedTxn.put("total","15.0");
        assertEquals(expectedTxn,result.getTxn());
    }
    @Test
    public void testUpdateForOrderReviewPageWithQuote(){
        Quote qoute=new Quote();
        qoute.setQuoteId("12345");
        CXPCartVO cxpCartVO1=new CXPCartVO();
        cxpCartVO1.setFlow("EUP|NAO");
        cxpCartVO1.setQuote(qoute);
        CXPRetrieveCartDataVO data=new CXPRetrieveCartDataVO();
        data.setCart(cxpCartVO1);
        cxpResponse.setData(data);
        Vzdl vzdl=new Vzdl();
        Vzdl result=omniDLHelper.updateTxnDataForOrderReviewPage(cxpResponse,vzdl);
        Map<String,String> expectedTxn=new HashMap<>();
        expectedTxn.put("quoteId","12345");
        expectedTxn.put("orderType", "EUP+NAO");
        expectedTxn.put("agentRole","");
        assertEquals(expectedTxn,result.getTxn());

    }
    @Test
    public void testUpdateForOrderReviewPageWithPayments(){
        PaymentDetails paymentDetails=new PaymentDetails();
        paymentDetails.setPaymentType("creditCard");
        onevz.soe.cart.model.common.Address address=new onevz.soe.cart.model.common.Address();
        address.setZipCode("999");
        paymentDetails.setAddress(address);
        CXPPaymentsVO payment=new CXPPaymentsVO();
        payment.setOrderNumber(6789);
        payment.setPaymentDetails(paymentDetails);
        CXPLineDetailsVO lineDetailsVO=new CXPLineDetailsVO();
        lineDetailsVO.setPayments(List.of(payment));
        CXPCartVO cxpCartVO1=new CXPCartVO();
        cxpCartVO1.setFlow("EUP|NAO");
        ServiceInfo serviceInfo = new ServiceInfo();
        PrimaryUserInfo userInfo=new PrimaryUserInfo();
        userInfo.setFirstName("MGR");
        serviceInfo.setPrimaryUserInfo(userInfo);
        CXPLineInfo lineInfo = new CXPLineInfo();
        lineInfo.setServiceInfo(serviceInfo);
        cxpCartVO1.setLineDetails(lineDetailsVO);
        CXPRetrieveCartDataVO data= new CXPRetrieveCartDataVO();
        data.setCart(cxpCartVO1);
        cxpResponse.setData(data);
        Vzdl vzdl=new Vzdl();
        Vzdl result=omniDLHelper.updateTxnDataForOrderReviewPage(cxpResponse,vzdl);
        Map<String,String> expectedTxn=new HashMap<>();
        expectedTxn.put("id","6789");
        expectedTxn.put("paymentType","creditCard");
        expectedTxn.put("orderType", "EUP+NAO");
        expectedTxn.put("autoPay", "N");
        expectedTxn.put("agentRole", "");
        assertEquals(expectedTxn,result.getTxn());

    }
    @Test public void testUpdateForOrderReviewPageWithDiscountId() {
        RetrieveCartDiscounts discount = new RetrieveCartDiscounts();
        discount.setDiscountId("DISCOUNT123");
        VisFeature visFeature = new VisFeature();
        visFeature.setFeatureDiscounts(java.util.List.of(discount));
        SelectedFeaturesList selectedFeaturesList = new SelectedFeaturesList();
        selectedFeaturesList.setVisFeature(java.util.List.of(visFeature));
        ServiceInfo serviceInfo = new ServiceInfo();
        PrimaryUserInfo userInfo=new PrimaryUserInfo();
        userInfo.setFirstName("MGR");
        serviceInfo.setPrimaryUserInfo(userInfo);
        serviceInfo.setSelectedFeaturesList(selectedFeaturesList);
        CXPLineInfo lineInfo = new CXPLineInfo();
        lineInfo.setServiceInfo(serviceInfo);
        CXPLineDetailsVO lineDetailsVO = new CXPLineDetailsVO();
        lineDetailsVO.setLineInfo(new CXPLineInfo[]{lineInfo});
        CXPCartVO cart = new CXPCartVO();
        cart.setFlow("EUP|NAO");
        cart.setLineDetails(lineDetailsVO);
        CXPRetrieveCartDataVO data = new CXPRetrieveCartDataVO();
        data.setCart(cart); cxpResponse.setData(data);
        Vzdl vzdl = new Vzdl();
        Vzdl result = omniDLHelper.updateTxnDataForOrderReviewPage(cxpResponse, vzdl);
        Map<String, String> expectedTxn = new HashMap<>();
        expectedTxn.put("discountId", "DISCOUNT123");
        expectedTxn.put("orderType", "EUP+NAO");
        expectedTxn.put("autoPay", "N");
        expectedTxn.put("agentRole", "");
        assertEquals(expectedTxn, result.getTxn());
    }
    @Test public void testUpdateForOrderReviewPageWithOffer() {
        ThirdPartyOffer thirdPartyOffer1 = new ThirdPartyOffer();
        thirdPartyOffer1.setOfferName("SpecialOffer1");
        ThirdPartyOffer thirdPartyOffer2 = new ThirdPartyOffer();
        thirdPartyOffer2.setOfferName("SpecialOffer2");
        ServiceInfo serviceInfo = new ServiceInfo();
        serviceInfo.setThirdPartyOffer(new ThirdPartyOffer[]{thirdPartyOffer1,thirdPartyOffer2});
        CXPLineInfo lineInfo = new CXPLineInfo();
        lineInfo.setServiceInfo(serviceInfo);
        CXPLineDetailsVO cxpLineDetailsVO=new CXPLineDetailsVO();
        cxpLineDetailsVO.setLineInfo(new CXPLineInfo[]{lineInfo});
        CXPCartVO cart = new CXPCartVO();
        cart.setFlow("EUP|NAO");
        cart.setLineDetails(cxpLineDetailsVO);
        CXPRetrieveCartDataVO data = new CXPRetrieveCartDataVO();
        data.setCart(cart);
        cxpResponse.setData(data);
        Vzdl vzdl = new Vzdl();
        Vzdl result = omniDLHelper.updateTxnDataForOrderReviewPage(cxpResponse, vzdl);
        Map<String, String> expectedTxn = new HashMap<>();
        expectedTxn.put("offer", "SpecialOffer1");
        expectedTxn.put("orderType", "EUP+NAO");
        expectedTxn.put("autoPay", "N");
        expectedTxn.put("agentRole", "");
        assertEquals(expectedTxn, result.getTxn());
    }
    @Test public void testUpdateForOrderReviewPageWithNullThirdPartyOffer() {
        ServiceInfo serviceInfo = new ServiceInfo();
        serviceInfo.setThirdPartyOffer(null);
        CXPLineInfo lineInfo = new CXPLineInfo();
        lineInfo.setServiceInfo(serviceInfo);
        CXPLineDetailsVO cxpLineDetailsVO=new CXPLineDetailsVO();
        cxpLineDetailsVO.setLineInfo(new CXPLineInfo[]{lineInfo});
        CXPCartVO cart = new CXPCartVO();
        cart.setLineDetails(cxpLineDetailsVO);
        CXPRetrieveCartDataVO data = new CXPRetrieveCartDataVO();
        data.setCart(cart); cxpResponse.setData(data);
        Vzdl vzdl = new Vzdl(); Vzdl result = omniDLHelper.updateTxnDataForOrderReviewPage(cxpResponse, vzdl);
        assertTrue(result.getTxn().isEmpty());
    }
    @Test
    public void testUpdateForOrderReviewPageWithTradeInDetails(){
        TradeInItem tradeInItem = new TradeInItem();
        tradeInItem.setOrganicPrice("100");
        TradeInDetail tradeInDetail= new TradeInDetail();
        tradeInDetail.setTradeInItems(List.of(tradeInItem));
        CXPLineDetailsVO cxpLineDetailsVO=new CXPLineDetailsVO();
        cxpLineDetailsVO.setTradeInDetail(tradeInDetail);
        CXPCartVO cart = new CXPCartVO();
        cart.setFlow("EUP|NAO");
        cart.setLineDetails(cxpLineDetailsVO);
        CXPRetrieveCartDataVO data = new CXPRetrieveCartDataVO();
        data.setCart(cart); cxpResponse.setData(data);
        Vzdl vzdl = new Vzdl();
        Vzdl result = omniDLHelper.updateTxnDataForOrderReviewPage(cxpResponse, vzdl);
        Map<String, String> expectedTxn = new HashMap<>();
        expectedTxn.put("tradeInQty", "1");
        expectedTxn.put("tradeInAmt", "100");
        expectedTxn.put("orderType", "EUP+NAO");
        expectedTxn.put("autoPay", "N");
        expectedTxn.put("agentRole", "");
        assertEquals(expectedTxn, result.getTxn());

    }
    @Test
    public void testUpdateForOrderReviewPageWithAutoPayEnrolled(){
        CXPLineDetailsVO cxpLineDetailsVO=new CXPLineDetailsVO();
        cxpLineDetailsVO.setIsAutoPayEnrolled("YES");
        CXPCartVO cart = new CXPCartVO();
        cart.setFlow("EUP|NAO");
        cart.setLineDetails(cxpLineDetailsVO);
        CXPRetrieveCartDataVO data = new CXPRetrieveCartDataVO();
        data.setCart(cart); cxpResponse.setData(data);
        Vzdl vzdl = new Vzdl();
        Vzdl result = omniDLHelper.updateTxnDataForOrderReviewPage(cxpResponse, vzdl);
        Map<String, String> expectedTxn = new HashMap<>();
        expectedTxn.put("autoPay", "YES");
        expectedTxn.put("agentRole", "");
        expectedTxn.put("orderType", "EUP+NAO");
        assertEquals(expectedTxn, result.getTxn());


    }

    @Test
    public void updateVzdlDataTest(){
        CXPOrderDetails orderDetails=new CXPOrderDetails();
        orderDetails.setOrderType("online");
        orderDetails.setTotalTaxAmount("5.00");
        orderDetails.setTotalShippingCost(10.0);
        orderDetails.setTotalDueToday(15.00);
        Quote qoute=new Quote();
        qoute.setQuoteId("12345");
        PaymentDetails paymentDetails=new PaymentDetails();
        paymentDetails.setPaymentType("creditCard");
        onevz.soe.cart.model.common.Address address=new onevz.soe.cart.model.common.Address();
        address.setZipCode("999");
        paymentDetails.setAddress(address);
        CXPPaymentsVO payment=new CXPPaymentsVO();
        payment.setOrderNumber(6789);
        payment.setPaymentDetails(paymentDetails);
        CXPLineDetailsVO lineDetailsVO=new CXPLineDetailsVO();
        lineDetailsVO.setPayments(List.of(payment));
        RetrieveCartDiscounts discounts= new RetrieveCartDiscounts();
        discounts.setDiscountId("DiscountId123");
        VisFeature visFeature=new VisFeature();
        visFeature.setFeatureDiscounts(List.of(discounts));
        SelectedFeaturesList selectedFeaturesList=new SelectedFeaturesList();
        selectedFeaturesList.setVisFeature(List.of(visFeature));
        ServiceInfo serviceInfo = new ServiceInfo();
        serviceInfo.setSelectedFeaturesList(selectedFeaturesList);
        CXPLineInfo cxpLineInfo= new CXPLineInfo();
        cxpLineInfo.setServiceInfo(serviceInfo);
        CXPLineDetailsVO cxpLineDetailsVO1= new CXPLineDetailsVO();
        cxpLineDetailsVO1.setLineInfo(new CXPLineInfo[]{cxpLineInfo});
        CXPCartVO cxpCartVO1=new CXPCartVO();
        cxpCartVO1.setOrderDetails(orderDetails);
        cxpCartVO1.setQuote(qoute);
        cxpCartVO1.setLineDetails(lineDetailsVO);
        cxpCartVO1.setLineDetails(cxpLineDetailsVO1);
        CXPRetrieveCartDataVO data=new CXPRetrieveCartDataVO();
        data.setCart(cxpCartVO1);
        cxpResponse.setData(data);
        Vzdl result=omniDLHelper.updateVzdlData(cxpResponse);
        Map<String,String> expectedTxn=new HashMap<>();
        expectedTxn.put("orderType","Online");
        expectedTxn.put("taxAmt","5.00");
        expectedTxn.put("shippingTotal","10.0");
        expectedTxn.put("total","15.0");
        expectedTxn.put("quoteId","12345");
        expectedTxn.put("discountId","DiscountId123");


    }

    @Test
    public void isRedisHasBillAcctTest(){
        Assert.assertFalse(omniDLHelper.isRedisHasBillAcct(null));

        CartRedisData rr= new CartRedisData();
        rr.setCustomerProfile(null);
        Assert.assertFalse(omniDLHelper.isRedisHasBillAcct(rr));

        rr.setCustomerProfile(new CustomerProfileResponse());
        rr.getCustomerProfile().setData(null);
        Assert.assertFalse(omniDLHelper.isRedisHasBillAcct(rr));

        rr.getCustomerProfile().setData(new Data());
        rr.getCustomerProfile().getData().setCustomer(new Customer());
        List<BillAccount> billAccounts= new ArrayList<>();
        billAccounts.add(new BillAccount());
        rr.getCustomerProfile().getData().getCustomer().setBillAccounts(billAccounts);
        Assert.assertTrue(omniDLHelper.isRedisHasBillAcct(rr));
    }

    @Test
    public void lineHasPlanTest(){
        Assert.assertFalse(omniDLHelper.lineHasPlan(null));
        Assert.assertFalse(omniDLHelper.linesHasFeatures(null));

        Lines lines= new Lines();
        lines.setPlan(null);
        lines.setAddFeatures(null);
        Assert.assertFalse(omniDLHelper.lineHasPlan(lines));
        Assert.assertFalse(omniDLHelper.linesHasFeatures(lines));

        lines.setPlan(new Plan());
        lines.getPlan().setId(null);
        lines.setAddFeatures(new ArrayList<>());
        Assert.assertFalse(omniDLHelper.lineHasPlan(lines));
        Assert.assertFalse(omniDLHelper.linesHasFeatures(lines));

        lines.getPlan().setId("id");
        lines.setLinechanged(false);
        List<Feature> features= new ArrayList<>();
        features.add(new Feature());
        lines.setAddFeatures(features);
        Assert.assertFalse(omniDLHelper.lineHasPlan(lines));
        Assert.assertFalse(omniDLHelper.linesHasFeatures(lines));

        lines.setLinechanged(true);
        Assert.assertTrue(omniDLHelper.lineHasPlan(lines));
        Assert.assertTrue(omniDLHelper.linesHasFeatures(lines));
    }

    @Test
    public void cartHasPlanTest(){
        Line line= new Line();
        Lines lines= new Lines();
        Assert.assertFalse(omniDLHelper.cartHasPlan(null, lines));

        line.setMtn(null);
        Assert.assertFalse(omniDLHelper.cartHasPlan(line, lines));

        line.setMtn("");
        Assert.assertFalse(omniDLHelper.cartHasPlan(line, lines));

        line.setMtn("123");
        lines.setMtn("");
        Assert.assertFalse(omniDLHelper.cartHasPlan(line, lines));

        lines.setMtn(null);
        Assert.assertFalse(omniDLHelper.cartHasPlan(line, lines));

        lines.setMtn("678");
        Assert.assertFalse(omniDLHelper.cartHasPlan(line, lines));

        lines.setMtn("123");
        line.setPlan(null);
        Assert.assertFalse(omniDLHelper.cartHasPlan(line, lines));

        line.setPlan(new Plan());
        line.getPlan().setId("");
        Assert.assertFalse(omniDLHelper.cartHasPlan(line, lines));

        line.getPlan().setId(null);
        Assert.assertFalse(omniDLHelper.cartHasPlan(line, lines));

        line.getPlan().setId("123");
        lines.setPlan(new Plan());
        lines.getPlan().setId("890");
        Assert.assertFalse(omniDLHelper.cartHasPlan(line, lines));

        lines.getPlan().setId("123");
        Assert.assertTrue(omniDLHelper.cartHasPlan(line, lines));
    }

    @Test
    public void setDefaultPriceNodeTest(){
        Assert.assertEquals("0.00",omniDLHelper.setDefaultPriceNode(null));
        Assert.assertEquals("0.00",omniDLHelper.setDefaultPriceNode(""));
        Assert.assertEquals("1.00",omniDLHelper.setDefaultPriceNode("1.00"));

        Assert.assertEquals("",omniDLHelper.setDefaultValue(null));
        Assert.assertEquals("",omniDLHelper.setDefaultValue(""));
        Assert.assertEquals("1.00",omniDLHelper.setDefaultValue("1.00"));
    }

    @Test
    public void cartHasSPOTest(){
        ConflictedSPO spo= new ConflictedSPO();
        Feature feature= new Feature();
        Assert.assertFalse(omniDLHelper.cartHasSPO(null, feature));

        spo.setId(null);
        Assert.assertFalse(omniDLHelper.cartHasSPO(spo, feature));

        spo.setId("");
        Assert.assertFalse(omniDLHelper.cartHasSPO(spo, feature));

        spo.setId("123");
        feature.setId("");
        Assert.assertFalse(omniDLHelper.cartHasSPO(spo, feature));

        feature.setId(null);
        Assert.assertFalse(omniDLHelper.cartHasSPO(spo, feature));

        feature.setId("890");
        Assert.assertFalse(omniDLHelper.cartHasSPO(spo, feature));

        feature.setId("123");
        Assert.assertTrue(omniDLHelper.cartHasSPO(spo, feature));
    }

    @Test
    public void cartInfoHasLines(){
        Assert.assertFalse(omniDLHelper.cartInfoHasLines(Optional.empty()));
        CartServiceCartInfo cartInfo= new CartServiceCartInfo();
        cartInfo.setLines(null);
        Optional<CartServiceCartInfo> cartInfoOpt= Optional.of(cartInfo);
        Assert.assertFalse(omniDLHelper.cartInfoHasLines(cartInfoOpt));

        cartInfo.setLines(new Line[1]);
        cartInfoOpt= Optional.of(cartInfo);
        Assert.assertTrue(omniDLHelper.cartInfoHasLines(cartInfoOpt));
    }
    @Test
    public  void updateEventTest(){
        Vzdl vzdl = new Vzdl();
        Event event = new Event();
        event.setValue(" ");
        vzdl.setEvent(event);
        omniDLHelper.eventUpdate(vzdl);
    }

    @Test
    public void updateVHDLDatForPageAndEventTest(){
        Vzdl vzdl = new Vzdl();
        String sessionId ="123456";
        Page page= new Page();
        page.setName("order-review-handoff");
        page.setChannelSession(sessionId);
        vzdl.setPage(page);
        omniDLHelper.getVzdlDataForEventAndPage(sessionId,"NAO");
        assertNotNull(vzdl);
        assertNotNull(vzdl.getPage());
        assertEquals(sessionId,vzdl.getPage().getChannelSession());
        assertEquals("order-review-handoff",vzdl.getPage().getName());

    }
    @Test
    public void updatePageantryEventNull(){
        Vzdl vzdl = omniDLHelper.getVzdlDataForEventAndPage(null,"");
        assertNotNull(vzdl);
    }

    @Test
    public void testSetAccountTypeWhenPrePayCart() {
        CXPOrderDetails orderDetails=new CXPOrderDetails();
        orderDetails.setOrderType("Online");
        orderDetails.setTotalTaxAmount("5.00");
        orderDetails.setTotalShippingCost(10.0);
        orderDetails.setTotalDueToday(15.00);
        orderDetails.setIsPrePayCart("true");
        List<OrderList> orderList=new ArrayList<>();
        OrderList list=new OrderList();
        CreditApplicationDetails det= new CreditApplicationDetails();
        det.setCreditApplicationNum(254102332);
        list.setCreditApplication(det);
        orderList.add(list);
        orderDetails.setOrderList(orderList);
        CXPCartVO cartVO=new CXPCartVO();
        cartVO.setOrderDetails(orderDetails);
        CXPRetrieveCartDataVO data=new CXPRetrieveCartDataVO();
        data.setCart(cartVO);
        cxpResponse.setData(data);
       Vzdl vzdl= omniDLHelper.updateVzdlData(cxpResponse);
        assertEquals("prepaid", vzdl.getUser().getAccountType());
        assertEquals("254102332",vzdl.getUser().getCreditAppNum());
    }
    @Test
    public void testSetAccountTypeWhenPostPayCart() {
        CXPOrderDetails orderDetails=new CXPOrderDetails();
        orderDetails.setOrderType("Online");
        orderDetails.setTotalTaxAmount("5.00");
        orderDetails.setTotalShippingCost(10.0);
        orderDetails.setTotalDueToday(15.00);
        orderDetails.setIsPrePayCart("false");
        CXPCartVO cartVO=new CXPCartVO();
        cartVO.setOrderDetails(orderDetails);
        CXPRetrieveCartDataVO data=new CXPRetrieveCartDataVO();
        data.setCart(cartVO);
        cxpResponse.setData(data);
        Vzdl vzdl= omniDLHelper.updateVzdlData(cxpResponse);
        assertEquals("postpaid", vzdl.getUser().getAccountType());
    }
    @Test
    public void testUserTarget() {
        User user = mock(User.class);
        when(user.getAmid()).thenReturn(null);
        when(user.getProspect()).thenReturn(null);
        when(user.getChildId()).thenReturn(null);
        when(user.getChatId()).thenReturn(null);
        when(user.getDeviceDollars()).thenReturn(null);
        when(user.getProductsQualified()).thenReturn(null);
        when(user.getAcctId_unhashed()).thenReturn(null);
        when(user.getVisionCustID_unhashed()).thenReturn(null);
        when(user.getCdUserId()).thenReturn(null);
        when(user.getExistingServices()).thenReturn(null);
        when(user.getAccountType()).thenReturn(null);
        when(user.getCustomerRole()).thenReturn(null);
        when(user.getAuthStatus()).thenReturn(null);
        when(user.getAuthType()).thenReturn(null);
        when(user.getTenure()).thenReturn(null);
        when(user.getCreditAppNum()).thenReturn(null);
        Vzdl vzdl= omniDLHelper.getVzdlDataForEventAndPage("12345678hgyu","NAO");
        Assertions.assertEquals("", vzdl.getUser().getCdUserId());

    }
    @Test
    public void testSetAuthStatusWhenCart() {
        CXPOrderDetails orderDetails=new CXPOrderDetails();
        orderDetails.setOrderType("Online");
        orderDetails.setTotalTaxAmount("5.00");
        orderDetails.setTotalShippingCost(10.0);
        orderDetails.setTotalDueToday(15.00);
        orderDetails.setIsPrePayCart("false");
        orderDetails.setCustomerType("N");
        CXPCartVO cartVO=new CXPCartVO();
        cartVO.setOrderDetails(orderDetails);
        CXPRetrieveCartDataVO data=new CXPRetrieveCartDataVO();
        data.setCart(cartVO);
        cxpResponse.setData(data);
        Vzdl vzdl= omniDLHelper.updateVzdlData(cxpResponse);
        assertEquals("postpaid", vzdl.getUser().getAccountType());
        assertEquals("anonymous", vzdl.getUser().getAuthStatus());
    }

    @Test
    public void testSetAuthStatusPEWhenCart() {
        CXPOrderDetails orderDetails=new CXPOrderDetails();
        orderDetails.setOrderType("Online");
        orderDetails.setTotalTaxAmount("5.00");
        orderDetails.setTotalShippingCost(10.0);
        orderDetails.setTotalDueToday(15.00);
        orderDetails.setIsPrePayCart("false");
        orderDetails.setCustomerType("PE");
        CXPCartVO cartVO=new CXPCartVO();
        cartVO.setOrderDetails(orderDetails);
        CXPRetrieveCartDataVO data=new CXPRetrieveCartDataVO();
        data.setCart(cartVO);
        cxpResponse.setData(data);
        Vzdl vzdl= omniDLHelper.updateVzdlData(cxpResponse);
        assertEquals("postpaid", vzdl.getUser().getAccountType());
        assertEquals("Logged In", vzdl.getUser().getAuthStatus());
    }

    @Test
    public void setPlanTaggingDetailsTest(){
        AddPlanUIRequest request= new AddPlanUIRequest();
        PlanTaggingDetails planTaggingDetails= new PlanTaggingDetails();
        List< PlansPerks > perkDetails= new ArrayList<>();
        Lines lines= new Lines();
        Current current= new Current();
        lines.setMtn("12345");
        lines.setLinechanged(false);
        planTaggingDetails.setMtn(null);
        omniDLHelper.setPlanTaggingDetails(request,null,null,lines,current);
        lines.setLinechanged(true);
        omniDLHelper.setPlanTaggingDetails(request,null,null,lines,current);

        planTaggingDetails.setAction("");
        omniDLHelper.setPlanTaggingDetails(request,planTaggingDetails,null,lines,current);
        planTaggingDetails.setAction(null);
        planTaggingDetails.setMtn("");
        omniDLHelper.setPlanTaggingDetails(request,planTaggingDetails,perkDetails,lines,current);
        planTaggingDetails.setAction("action");
        omniDLHelper.setPlanTaggingDetails(request,planTaggingDetails,perkDetails,lines,current);
        planTaggingDetails.setPath("path");
        planTaggingDetails.setGroup(1);
        perkDetails.add(new PlansPerks());
        planTaggingDetails.setMtn("123");
        request.setPlanTaggingDetails(null);
        omniDLHelper.setPlanTaggingDetails(request,planTaggingDetails,perkDetails,lines,current);
        planTaggingDetails.setPath("");
        planTaggingDetails.setMtn("123");
        request.setPlanTaggingDetails(new ArrayList<>());
        omniDLHelper.setPlanTaggingDetails(request,planTaggingDetails,perkDetails,lines,current);
        planTaggingDetails.setPath(null);
        omniDLHelper.setPlanTaggingDetails(request,planTaggingDetails,perkDetails,lines,current);
        planTaggingDetails.setPath("path");
        omniDLHelper.setPlanTaggingDetails(request,planTaggingDetails,perkDetails,lines,current);
        planTaggingDetails.setPath("path");
        planTaggingDetails.setAction("action");
        planTaggingDetails.setGroup(null);
        omniDLHelper.setPlanTaggingDetails(request,planTaggingDetails,perkDetails,lines,current);
        planTaggingDetails.setPath("path");
        planTaggingDetails.setAction("action");
        planTaggingDetails.setGroup(1);
        omniDLHelper.setPlanTaggingDetails(request,planTaggingDetails,perkDetails,lines,current);

        Assert.assertNotNull(request.getPlanTaggingDetails());
    }

    @Test
    public void setActionPathGroupForFeaturesTest(){
        Current current= new Current();
        Current featureCurrent= new Current();
        AddPlanUIRequest request= new AddPlanUIRequest();
        Lines lines= new Lines();

        current.setAction("");
        omniDLHelper.setActionPathGroupForFeatures(current,featureCurrent,request,lines);
        current.setAction(null);
        omniDLHelper.setActionPathGroupForFeatures(current,featureCurrent,request,lines);
        current.setAction("action");
        omniDLHelper.setActionPathGroupForFeatures(current,featureCurrent,request,lines);
        current.setPath("");
        omniDLHelper.setActionPathGroupForFeatures(current,featureCurrent,request,lines);
        current.setPath(null);
        omniDLHelper.setActionPathGroupForFeatures(current,featureCurrent,request,lines);
        current.setPath("path");
        omniDLHelper.setActionPathGroupForFeatures(current,featureCurrent,request,lines);
        current.setGroup(null);
        omniDLHelper.setActionPathGroupForFeatures(current,featureCurrent,request,lines);
        current.setGroup("");
        omniDLHelper.setActionPathGroupForFeatures(current,featureCurrent,request,lines);
        current.setGroup("1");
        omniDLHelper.setActionPathGroupForFeatures(current,featureCurrent,request,lines);

        Assert.assertEquals(current.getAction(),featureCurrent.getAction());
    }
    @Test
    public void testUpdateForOrderReviewPageWithAutoPayNotEnrolled(){
        CXPLineDetailsVO cxpLineDetailsVO=new CXPLineDetailsVO();cxpLineDetailsVO.setIsAutoPayEnrolled("N");
        CXPCartVO cart = new CXPCartVO();
        cart.setLineDetails(cxpLineDetailsVO);
        PrimaryUserInfo userInfo=new PrimaryUserInfo();userInfo.setFirstName("MGR");
        CXPRetrieveCartDataVO data = new CXPRetrieveCartDataVO();
        data.setCart(cart); cxpResponse.setData(data);
        Vzdl vzdl = new Vzdl();Vzdl result = omniDLHelper.updateTxnDataForOrderReviewPage(cxpResponse, vzdl);
        Map<String, String> expectedTxn = new HashMap<>();expectedTxn.put("autoPay", "N");expectedTxn.put("agentRole", "");assertEquals(expectedTxn, result.getTxn());
    }
    @Test
    public void testUpdateTxnDataForOrderReviewPage_StandaloneTradeInOnly() {
        when(mockCxpResponse.getData()).thenReturn(mockData);
        when(mockData.getCart()).thenReturn(mockCart);
        when(mockCart.getFlow()).thenReturn("STANDALONETRADEIN");
        omniDLHelper.updateTxnDataForOrderReviewPage(mockCxpResponse, vzdl);
        assertEquals("TradeIn",  vzdl.getTxn().get("orderType"));
    }

    @Test
    public void testUpdateTxnDataForOrderReviewPage_StandaloneTradeInWithOtherComponents() {
        when(mockCxpResponse.getData()).thenReturn(mockData);
        when(mockData.getCart()).thenReturn(mockCart);
        when(mockCart.getFlow()).thenReturn("STANDALONETRADEIN|EUP|AAL");
        omniDLHelper.updateTxnDataForOrderReviewPage(mockCxpResponse, vzdl);
        assertEquals("TradeIn+EUP+AAL", vzdl.getTxn().get("orderType"));
    }

    @Test
    public void testUpdateTxnDataForOrderReviewPage_DuplicateComponents() {
        when(mockCxpResponse.getData()).thenReturn(mockData);
        when(mockData.getCart()).thenReturn(mockCart);
        when(mockCart.getFlow()).thenReturn("EUP|AAL|EUP|NAO|NAO");
        omniDLHelper.updateTxnDataForOrderReviewPage(mockCxpResponse, vzdl);
        assertEquals("EUP+AAL+NAO", vzdl.getTxn().get("orderType"));
    }

    @Test
    public void testUpdateTxnDataForOrderReviewPage_EmptyOrBlankFlow() {
        when(mockCxpResponse.getData()).thenReturn(mockData);
        when(mockData.getCart()).thenReturn(mockCart);
        when(mockCart.getFlow()).thenReturn("");
        omniDLHelper.updateTxnDataForOrderReviewPage(mockCxpResponse, vzdl);
        assertNull(txn.get("OrderType"));
    }

    @Test
    public void testUpdateTxnDataForOrderReviewPage_NullFlow() {
        when(mockCxpResponse.getData()).thenReturn(mockData);
        when(mockData.getCart()).thenReturn(mockCart);
        when(mockCart.getFlow()).thenReturn(null);
        omniDLHelper.updateTxnDataForOrderReviewPage(mockCxpResponse, vzdl);
        assertNull(vzdl.getTxn().get("OrderType"));
    }

    @Test
    public void testUpdateTxnDataForOrderReviewPage_NoDataOrCart() {
        when(mockCxpResponse.getData()).thenReturn(null);
        omniDLHelper.updateTxnDataForOrderReviewPage(mockCxpResponse, vzdl);
        assertNull(txn.get("OrderType"));
    }
    @Test
    public void testUpdateVzdlData_StandaloneTradeInOnly() {
        when(mockCxpResponse.getData()).thenReturn(mockData);
        when(mockData.getCart()).thenReturn(mockCart);
        when(mockCart.getFlow()).thenReturn("STANDALONETRADEIN");

        Vzdl result = omniDLHelper.updateVzdlData(mockCxpResponse);

        assertNotNull(result);
        assertNotNull(result.getPage());
        assertEquals("TradeIn", result.getPage().getFlow());
    }

    @Test
    public void testUpdateVzdlData_StandaloneTradeInWithOtherComponents() {
        when(mockCxpResponse.getData()).thenReturn(mockData);
        when(mockData.getCart()).thenReturn(mockCart);
        when(mockCart.getFlow()).thenReturn("STANDALONETRADEIN|EUP|AAL");

        Vzdl result = omniDLHelper.updateVzdlData(mockCxpResponse);

        assertNotNull(result);
        assertNotNull(result.getPage());
        assertEquals("TradeIn|EUP|AAL", result.getPage().getFlow());
    }

    @Test
    public void testUpdateVzdlData_DuplicateComponents() {
        when(mockCxpResponse.getData()).thenReturn(mockData);
        when(mockData.getCart()).thenReturn(mockCart);
        when(mockCart.getFlow()).thenReturn("EUP|AAL|AAL|NAO");

        Vzdl result = omniDLHelper.updateVzdlData(mockCxpResponse);

        assertNotNull(result);
        assertNotNull(result.getPage());
        assertEquals("EUP|AAL|NAO", result.getPage().getFlow());
    }
    @Test
    public void testUpdateVzdlData_NullFlow() {
        when(mockCxpResponse.getData()).thenReturn(mockData);
        when(mockData.getCart()).thenReturn(mockCart);
        when(mockCart.getFlow()).thenReturn(null);
        Vzdl result = omniDLHelper.updateVzdlData(mockCxpResponse);
        assertNotNull(result);
        assertNotNull(result.getPage());
        assertNull(result.getPage().getFlow());
    }

    @Test
    public void testUpdateVzdlData_BlankFlow() {
        when(mockCxpResponse.getData()).thenReturn(mockData);
        when(mockData.getCart()).thenReturn(mockCart);
        when(mockCart.getFlow()).thenReturn("   ");
        Vzdl result = omniDLHelper.updateVzdlData(mockCxpResponse);
        assertNotNull(result);
        assertNotNull(result.getPage());
        assertNull(result.getPage().getFlow());
    }

    @Test
    public void testUpdateVzdlData_NoCart() {
        when(mockCxpResponse.getData()).thenReturn(mockData);
        when(mockData.getCart()).thenReturn(null);
        Vzdl result = omniDLHelper.updateVzdlData(mockCxpResponse);
        assertNotNull(result);
        assertNotNull(result.getPage());
        assertNull(result.getPage().getFlow());
    }

    @Test
    public void testUpdateVzdlData_NoData() {
        when(mockCxpResponse.getData()).thenReturn(null);

        Vzdl result = omniDLHelper.updateVzdlData(mockCxpResponse);

        assertNotNull(result);
        assertNotNull(result.getPage());
        assertNull(result.getPage().getFlow());
    }

}
