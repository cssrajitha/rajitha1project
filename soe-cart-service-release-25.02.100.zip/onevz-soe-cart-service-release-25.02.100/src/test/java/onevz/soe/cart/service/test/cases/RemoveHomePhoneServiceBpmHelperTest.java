package onevz.soe.cart.service.test.cases;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import junit.framework.Assert;
import onevz.soe.cart.bpm.helper.RemoveHomePhoneServiceBpmHelper;
import onevz.soe.cart.bpm.service.CartServiceBPMServices;
import onevz.soe.cart.requests.RemoveHomePhonePegaRequest;
import onevz.soe.cart.responses.RemoveHomePhonePegaResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.RemoveHomePhoneUIRequest;
import onevz.soe.exception.SOEError;
import onevz.soe.exception.SOEErrorHolder;
import onevz.soe.wsclient.bpm.model.response.Error;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {CartServiceTestConfig.class})
//@WebFluxTest(RemoveHomePhoneServiceBpmHelper.class)
public class RemoveHomePhoneServiceBpmHelperTest {

    @Autowired
    private RemoveHomePhoneServiceBpmHelper removeHomePhoneServiceBpmHelper;
    @Autowired
    private ObjectMapper mapper;

    @MockBean
    private CartServiceBPMServices services;

    @Test
    public void removeHomePhoneTest() throws Exception
    {
        String requestString = "{\n \"cartInfo\": {\n \"clientAppName\": \"VZW-DOTCOM\",\n \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\n \"cartId\": \"\",\n \"caseId\": \"\",\n  \"accountNumber\": \"0213143123-00001\", \n \"cartCreator\": \"8136958775\",\n\"processingMTN\": \"8136958775\",\n \"homePhoneMTN\":\"xxxxxx\",\n  \"processStep\": \"ShoppingCart\",\n  \"processAction\": \"removeDevice\",\n \"intendType\": \"MOVER\",\n \"action\" : \"REMOVE\"\n \n  }\n}";
        String responseString = "{\n \"serviceHeader\" : {\n   \"clientId\" : \"OMNI-RETAIL\",\n   \"statusMsg\" : \"SUCCESS\",\n \"correlationId\" : \"soe-cart-2021.08.06.17.50.24-125.72236596853669\",\n  \"sessionId\" : \"\",\n   \"serviceName\" : \"SalesOrderPurchase\",\n  \"userId\" : \"\",\n\"statusCode\" : \"00\"\n },\n \"serviceBody\" : {\n\"serviceResponse\" : {\n \"context\" : {\n    \"cartInfo\" : {\n   \"statusMsg\" : \"Success\",\n\"cartId\" : \"aa3a61e9-5410-4243-9efe-598c3ec2ac08\",\n \"statusCode\" : \"1\"\n },\n      \"contextInfo\" : {\n     \"availablePaths\" : [{\n   \"path\" : \"ShoppingCart\"\n }, {\n    \"path\" : \"addDevice\"\n }\n   ],\n \"processStep\" : \"ShoppingCart\",\n  \"callReason\" : \"SalesOrderPurchase\"\n },\n\"caseId\" : \"SOP-3647723-E01\",\n    \"customerInfo\" : {\n    \"cartCreator\" : \"4102411705\",\n\"processingMTN\" : \"4014436878\",\n   \"accountNumber\" : \"0001445545-00001\"\n },\n   \"processMTNList\" : [{\n   \"mtn\" : \"2404951496\",\n  \"completedprocessSteps\" : [\"ShoppingCart\",\"addDevice\"]\n}\n    ]\n}\n}\n}\n}\n";
        RemoveHomePhoneUIRequest request = mapper.readValue(requestString, RemoveHomePhoneUIRequest.class);
        RemoveHomePhonePegaResponse response = mapper.readValue(responseString, RemoveHomePhonePegaResponse.class);
        when(services.removeLine(Mockito.any())).thenReturn(Mono.just(response));
        Mono<RemoveHomePhonePegaResponse> expectedResponse = removeHomePhoneServiceBpmHelper.removeHomePhone(request);
        StepVerifier.create(expectedResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        StepVerifier.create(expectedResponse).assertNext(resp -> org.junit.Assert.assertEquals(response, resp)).expectComplete()
                .verify();
    }

    @Test
    public void removeHomePhoneTest2() throws Exception
    {
        String requestString = "{\n \"cartInfo\": {\n \"clientAppName\": \"VZW-DOTCOM\",\n \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\n \"cartId\": \"\",\n \"caseId\": \"\",\n  \"accountNumber\": \"0213143123-00001\", \n \"cartCreator\": \"8136958775\",\n\"processingMTN\": \"8136958775\",\n \"homePhoneMTN\":\"xxxxxx\",\n  \"processStep\": \"ShoppingCart\",\n  \"processAction\": \"removeDevice\",\n \"intendType\": \"MOVER\",\n \"action\" : \"REMOVE\"\n \n  }\n}";
        String responseString = "{\n \"serviceHeader\" : {\n   \"clientId\" : \"OMNI-RETAIL\",\n   \"statusMsg\" : \"SUCCESS\",\n \"correlationId\" : \"soe-cart-2021.08.06.17.50.24-125.72236596853669\",\n  \"sessionId\" : \"\",\n   \"serviceName\" : \"SalesOrderPurchase\",\n  \"userId\" : \"\",\n\"statusCode\" : \"00\"\n },\n \"serviceBody\" : {\n\"serviceResponse\" : {\n \"context\" : {\n    \"cartInfo\" : {\n   \"statusMsg\" : \"Success\",\n\"cartId\" : \"aa3a61e9-5410-4243-9efe-598c3ec2ac08\",\n \"statusCode\" : \"1\"\n },\n      \"contextInfo\" : {\n     \"availablePaths\" : [{\n   \"path\" : \"ShoppingCart\"\n }, {\n    \"path\" : \"addDevice\"\n }\n   ],\n \"processStep\" : \"ShoppingCart\",\n  \"callReason\" : \"SalesOrderPurchase\"\n },\n\"caseId\" : \"SOP-3647723-E01\",\n    \"customerInfo\" : {\n    \"cartCreator\" : \"4102411705\",\n\"processingMTN\" : \"4014436878\",\n   \"accountNumber\" : \"0001445545-00001\"\n },\n   \"processMTNList\" : [{\n   \"mtn\" : \"2404951496\",\n  \"completedprocessSteps\" : [\"ShoppingCart\",\"addDevice\"]\n}\n    ]\n}\n}\n}\n}\n";
        RemoveHomePhoneUIRequest request = mapper.readValue(requestString, RemoveHomePhoneUIRequest.class);
        RemoveHomePhonePegaResponse response = mapper.readValue(responseString, RemoveHomePhonePegaResponse.class);
        RemoveHomePhoneServiceBpmHelper removeHomePhoneServiceBpmHelper1 = mock(RemoveHomePhoneServiceBpmHelper.class);
        when(services.removeLine(Mockito.any())).thenThrow(new SOEHTTPException(404, "page Not Found"));
        Mono<RemoveHomePhonePegaResponse> expectedResponse = removeHomePhoneServiceBpmHelper.removeHomePhone(request);
        StepVerifier.create(expectedResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void removeHomePhoneErrorTest() throws Exception
    {
        String requestString = "{\n \"cartInfo\": {\n \"clientAppName\": \"VZW-DOTCOM\",\n \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\n \"cartId\": \"\",\n \"caseId\": \"\",\n  \"accountNumber\": \"0213143123-00001\", \n \"cartCreator\": \"8136958775\",\n\"processingMTN\": \"8136958775\",\n \"homePhoneMTN\":\"xxxxxx\",\n  \"processStep\": \"ShoppingCart\",\n  \"processAction\": \"removeDevice\",\n \"intendType\": \"MOVER\",\n \"action\" : \"REMOVE\"\n \n  }\n}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        RemoveHomePhoneUIRequest request = mapper.readValue(requestString, RemoveHomePhoneUIRequest.class);
        RemoveHomePhonePegaResponse response = mapper.readValue(responseString, RemoveHomePhonePegaResponse.class);
        RemoveHomePhoneServiceBpmHelper removeHomePhoneServiceBpmHelper1 = mock(RemoveHomePhoneServiceBpmHelper.class);
        when(services.removeLine(Mockito.any())).thenReturn(Mono.just(response));
        Mono<RemoveHomePhonePegaResponse> expectedResponse = removeHomePhoneServiceBpmHelper.removeHomePhone(request);
        StepVerifier.create(expectedResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void removeHomePhoneErrorTest2() throws Exception
    {
        String requestString = "{\n \"cartInfo\": {\n \"clientAppName\": \"VZW-DOTCOM\",\n \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\n \"cartId\": \"\",\n \"caseId\": \"\",\n  \"accountNumber\": \"0213143123-00001\", \n \"cartCreator\": \"8136958775\",\n\"processingMTN\": \"8136958775\",\n \"homePhoneMTN\":\"xxxxxx\",\n  \"processStep\": \"ShoppingCart\",\n  \"processAction\": \"removeDevice\",\n \"intendType\": \"MOVER\",\n \"action\" : \"REMOVE\"\n \n  }\n}";
        String responseString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        RemoveHomePhoneUIRequest request = mapper.readValue(requestString, RemoveHomePhoneUIRequest.class);
        RemoveHomePhonePegaResponse response = mapper.readValue(responseString, RemoveHomePhonePegaResponse.class);
        RemoveHomePhoneServiceBpmHelper removeHomePhoneServiceBpmHelper1 = mock(RemoveHomePhoneServiceBpmHelper.class);
        when(services.removeLine(Mockito.any())).thenReturn(Mono.just(response));
        Mono<RemoveHomePhonePegaResponse> expectedResponse = removeHomePhoneServiceBpmHelper.removeHomePhone(request);
        StepVerifier.create(expectedResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        StepVerifier.create(expectedResponse.log()).expectSubscription().expectNext(response).verifyComplete();
    }

    @Test
    public void removeHomePhoneErrorTest3() throws Exception
    {
        String requestString = "{\n \"cartInfo\": {\n \"clientAppName\": \"VZW-DOTCOM\",\n \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\n \"cartId\": \"\",\n \"caseId\": \"\",\n  \"accountNumber\": \"0213143123-00001\", \n \"cartCreator\": \"8136958775\",\n\"processingMTN\": \"8136958775\",\n \"homePhoneMTN\":\"xxxxxx\",\n  \"processStep\": \"ShoppingCart\",\n  \"processAction\": \"removeDevice\",\n \"intendType\": \"MOVER\",\n \"action\" : \"REMOVE\"\n \n  }\n}";
        String responseString = "{\n \"serviceHeader\" : {\n   \"clientId\" : \"OMNI-RETAIL\",\n   \"statusMsg\" : \"SUCCESS\",\n \"correlationId\" : \"soe-cart-2021.08.06.17.50.24-125.72236596853669\",\n  \"sessionId\" : \"\",\n   \"serviceName\" : \"SalesOrderPurchase\",\n  \"userId\" : \"\",\n\"statusCode\" : \"00\"\n },\n \"serviceBody\" : {\n\"serviceResponse\" : {\n \"context\" : {\n    \"cartInfo\" : {\n   \"statusMsg\" : \"Success\",\n\"cartId\" : \"aa3a61e9-5410-4243-9efe-598c3ec2ac08\",\n \"statusCode\" : \"1\"\n },\n      \"contextInfo\" : {\n     \"availablePaths\" : [{\n   \"path\" : \"ShoppingCart\"\n }, {\n    \"path\" : \"addDevice\"\n }\n   ],\n \"processStep\" : \"ShoppingCart\",\n  \"callReason\" : \"SalesOrderPurchase\"\n },\n\"caseId\" : \"SOP-3647723-E01\",\n    \"customerInfo\" : {\n    \"cartCreator\" : \"4102411705\",\n\"processingMTN\" : \"4014436878\",\n   \"accountNumber\" : \"0001445545-00001\"\n },\n   \"processMTNList\" : [{\n   \"mtn\" : \"2404951496\",\n  \"completedprocessSteps\" : [\"ShoppingCart\",\"addDevice\"]\n}\n    ]\n}\n}\n}\n}\n";
        String errorString = "{\"errors\": [{\"id\": \"3998\",\"debug_id\": \"2019-10-21T07:13:29.+0000:b1a9d8a3-33d5-4771-b216-c7582142c13c:cxp-cart-domain-qa-ev6v-qa-nsq1cxp-75457cf4c7-xfmfv\",\"name\": \"API_ERROR\",\"message\": \"Exception while fetching data (/cart) : onevz.cxp.cart.exception.DataNotFoundException: Cart not found\",\"namespace\": \"cxp-cart-domain\"}]}";
        RemoveHomePhoneUIRequest request = mapper.readValue(requestString, RemoveHomePhoneUIRequest.class);
        List<Error> errors = mapper.readValue(errorString, List.class);
        RemoveHomePhonePegaResponse response = mapper.readValue(responseString, RemoveHomePhonePegaResponse.class);
        RemoveHomePhonePegaResponse removeHomePhonePegaResponse = new RemoveHomePhonePegaResponse();
        response.setErrors(errors);
        when(services.removeLine(Mockito.any())).thenReturn(Mono.just(response));
        Mono<RemoveHomePhonePegaResponse> expectedResponse = removeHomePhoneServiceBpmHelper.removeHomePhone(request)
                .doOnError(e -> e.getMessage())
                .onErrorResume(s -> {
                    return Mono.just(response);
                });
        StepVerifier.create(expectedResponse).expectNext(response).verifyComplete();
    }
//    @Test
//    public void RemoveHomePhonePegaReqCartInfoTest() throws IOException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
//        String requestString = "{\n \"cartInfo\": {\n \"clientAppName\": \"VZW-DOTCOM\",\n \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\n \"cartId\": \"\",\n \"caseId\": \"\",\n  \"accountNumber\": \"0213143123-00001\", \n \"cartCreator\": \"8136958775\",\n\"processingMTN\": \"8136958775\",\n \"homePhoneMTN\":\"xxxxxx\",\n  \"processStep\": \"ShoppingCart\",\n  \"processAction\": \"removeDevice\",\n \"intendType\": \"MOVER\",\n \"action\" : \"REMOVE\"\n \n  }\n}";
//        RemoveHomePhoneUIRequest request = mapper.readValue(requestString, RemoveHomePhoneUIRequest.class);
//        Method method = removeHomePhoneServiceBpmHelper.getClass().getDeclaredMethod("getCartInfo", RemoveHomePhoneUIRequest.class);
//        method.setAccessible(true);
//        RemoveHomePhonePegaReqCartInfo response = (RemoveHomePhonePegaReqCartInfo) method.invoke(
//                removeHomePhoneServiceBpmHelper, request);
//        org.junit.Assert.assertEquals(response.getCartCreator(), request.getCartInfo().getCartCreator());
//        org.junit.Assert.assertEquals(response.getIntendType(), request.getCartInfo().getIntendType());
//        org.junit.Assert.assertEquals(response.getCartId(), request.getCartInfo().getCartId());
//        org.junit.Assert.assertEquals(response.getAction(), request.getCartInfo().getAction());
//    }
    @Test
    public void formatRemoveHomePhoneRequestTest() throws JsonMappingException, JsonProcessingException {
    	String requestString = "{\"cartInfo\": {}}";
    	RemoveHomePhoneUIRequest request = mapper.readValue(requestString, RemoveHomePhoneUIRequest.class);
    	RemoveHomePhonePegaRequest response = removeHomePhoneServiceBpmHelper.formatRemoveHomePhoneRequest(request);
    	Assert.assertNull(response.getServiceBody().getServiceRequest().getContext().getCaseId());
    }
    
    @Test
    public void removeHomePhoneErrorTest4() throws Exception
    {
        String requestString = "{\n \"cartInfo\": {\n \"clientAppName\": \"VZW-DOTCOM\",\n \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\n \"cartId\": \"\",\n \"caseId\": \"\",\n  \"accountNumber\": \"0213143123-00001\", \n \"cartCreator\": \"8136958775\",\n\"processingMTN\": \"8136958775\",\n \"homePhoneMTN\":\"xxxxxx\",\n  \"processStep\": \"ShoppingCart\",\n  \"processAction\": \"removeDevice\",\n \"intendType\": \"MOVER\",\n \"action\" : \"REMOVE\"\n \n  }\n}";
        RemoveHomePhoneUIRequest request = mapper.readValue(requestString, RemoveHomePhoneUIRequest.class);
        SOEErrorHolder err = new SOEErrorHolder();
        List<SOEError> errors = new ArrayList<>();
        SOEError error = new SOEError();
        errors.add(error);
        err.setErrors(errors);
        when(services.removeLine(Mockito.any())).thenReturn(Mono.error(new SOEHTTPException(0, err)));
        Mono<RemoveHomePhonePegaResponse> expectedResponse = removeHomePhoneServiceBpmHelper.removeHomePhone(request);
        StepVerifier.create(expectedResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }
}
