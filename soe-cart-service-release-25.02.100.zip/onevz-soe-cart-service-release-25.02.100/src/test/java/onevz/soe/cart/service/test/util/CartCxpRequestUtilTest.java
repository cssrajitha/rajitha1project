package onevz.soe.cart.service.test.util;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.myOffer.Offer;
import onevz.soe.cart.model.myOffers.Offers;
import onevz.soe.cart.model.vzccAppStatus.VZCCStatus;
import onevz.soe.cart.ui.common.DeviceCartInfo;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.initiateDeviceSimActivation.IntiateDeviceSimActivationUIRequest;
import onevz.soe.cart.model.initiateESimActivation.IntiateESimActivationUIRequest;
import onevz.soe.cart.model.myOffer.MyOfferLine;
import onevz.soe.cart.model.myOffer.Offer;
import onevz.soe.cart.model.myOffers.ComplianceSkuDetails;
import onevz.soe.cart.model.myOffers.RTDOfferDetails;
import onevz.soe.cart.model.numberlinkE911Address.AddressRequest;
import onevz.soe.cart.requests.AddZipcodeCXPRequest;
import onevz.soe.cart.requests.CheckDfillInventoryCXPRequest;
import onevz.soe.cart.requests.DeviceSimValidationCXPRequest;
import onevz.soe.cart.requests.InitiateCbandCheckCXPRequest;
import onevz.soe.cart.requests.InitiateESimActivationCXPRequest;
import onevz.soe.cart.requests.IntiateDeviceSimActivationCXPRequest;
import onevz.soe.cart.requests.MyOffersCXPRequest;
import onevz.soe.cart.requests.NbsDataCXPRequest;
import onevz.soe.cart.requests.RPSE911AddressRetrieveCxpRequest;
import onevz.soe.cart.requests.RPSE911AddressUpdateCXPRequest;
import onevz.soe.cart.requests.RPSReleasePendingOrderRequestCXPRequest;
import onevz.soe.cart.requests.UpdateConsentCxpRequest;
import onevz.soe.cart.requests.UpdateTradeInOfferCXPRequest;
import onevz.soe.cart.requests.UpdateTradeinTypeCXPRequest;
import onevz.soe.cart.requests.UpdateVzccNBXInfoCXPRequest;
import onevz.soe.cart.requests.VZCCAppStatusCXPRequest;
import onevz.soe.cart.requests.ValidateOffersRequest;
import onevz.soe.cart.responses.MyOfferETRRedisData;
import onevz.soe.cart.responses.RTDRedisData;
import onevz.soe.cart.ui.common.DeviceCartInfo;
import onevz.soe.cart.ui.requests.AddDeviceUIRequest;
import onevz.soe.cart.ui.requests.AddZipCodeUIRequest;
import onevz.soe.cart.ui.requests.ApplyOfferRequest;
import onevz.soe.cart.ui.requests.CheckDfillInventoryUIRequest;
import onevz.soe.cart.ui.requests.DeviceSimValidationUIRequest;
import onevz.soe.cart.ui.requests.InitiateCbandCheckUIRequest;
import onevz.soe.cart.ui.requests.MyOfferCartInfo;
import onevz.soe.cart.ui.requests.RPSE911AddressRetrieveUIRequest;
import onevz.soe.cart.ui.requests.RPSE911AddressUpdateUIRequest;
import onevz.soe.cart.ui.requests.RPSReleasePendingOrderUIRequest;
import onevz.soe.cart.ui.requests.UpdateTradeInOfferUIRequest;
import onevz.soe.cart.ui.requests.UpdateTradeinTypeUIRequest;
import onevz.soe.cart.ui.requests.UpdateVzccNBXInfoUIRequest;
import onevz.soe.cart.ui.requests.VZCCAppStatusUIRequest;
import onevz.soe.cart.util.CartCxpRequestUtil;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(CartCxpRequestUtil.class)
public class CartCxpRequestUtilTest {

	@Autowired
	private ObjectMapper mapper;

	@MockBean
	CartCxpRequestUtil util;

	@Test
	public void formMyOffersRequestTest() throws JsonMappingException, JsonProcessingException
	{
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		String  channelId="OMNI-INDIRECT";
		RTDRedisData rtdData=mapper.readValue(redisDataString, RTDRedisData.class);
		util.formMyOffersRequest(rtdData, channelId);
	}

	@Test
	public void formatUpdateRPSE911AddressRequestTest() throws JsonMappingException, JsonProcessingException
	{
		String sampleResponseString =  "{\"mtn\":[\"1234567890\",\"9876543210\"],\"channelId\":\"VZW-RPS\"}";
		String sampleRequestString = "{\"client\": \"CXP\",\"cartId\": \"09cfa680-f331-4c03-b83f-e27322882457\",\"lines\":[{\"mtn\": \"1234567890\",\"firstName\": \"Jane\",\"lastName\": \"Doe\",\"email\":\"xyz@vzcorp.com\"}]}";
		RPSE911AddressUpdateCXPRequest cxpRequest = new RPSE911AddressUpdateCXPRequest();
		RPSE911AddressUpdateUIRequest uiRequest=mapper.readValue(sampleResponseString, RPSE911AddressUpdateUIRequest.class);
		util.formatUpdateRPSE911AddressRequest(uiRequest, cxpRequest);
	}

	@Test
	public void formatReleasePendingOrderRequestTest()  throws JsonMappingException, JsonProcessingException
	{
		String sampleResponseString = "{\"meta\":{\"timestamp\":\"2019-08-05T13:27:07Z\",\"cxpCorrelationId\":\"3d5f3c15-aa3b-4a42-9245-5cb4177468e4\"},\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"},\"channelId\":\"VZW-NUMBERLINK\",\"deviceId\":\"999\",\"mtn\":\"999\",\"zipCode\":\"500086\",\"lineItemNumber\":\"999\",\"orderNumber\":\"999\",\"lineItemInfoList\":[{\"lineItemNumber\":\"999\",\"lineItemTimeStamp\":\"1000\",\"orderNumber\":\"9879\"}]}";
		String sampleRequestString = "{\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"},\"client\": \"CXP\",\"cartId\": \"09cfa680-f331-4c03-b83f-e27322882457\",\"lines\":[{\"mtn\": \"1234567890\",\"firstName\": \"Jane\",\"lastName\": \"Doe\",\"email\":\"xyz@vzcorp.com\"}]}";

		RPSReleasePendingOrderUIRequest uiRequest=mapper.readValue(sampleResponseString, RPSReleasePendingOrderUIRequest.class);
		RPSReleasePendingOrderRequestCXPRequest cxpRequest=mapper.readValue(sampleRequestString, RPSReleasePendingOrderRequestCXPRequest.class);
		util.formatReleasePendingOrderRequest(uiRequest, cxpRequest);
	}

	@Test
	public void formatRetrieveRPSE911AddressRequestTest() throws JsonMappingException, JsonProcessingException
	{
		String sampleResponseString =  "{\"mtn\":[\"1234567890\",\"9876543210\"],\"channelId\":\"VZW-NUMBERLINK\"}";
		String sampleRequestString = "{\"client\": \"CXP\",\"cartId\": \"09cfa680-f331-4c03-b83f-e27322882457\",\"lines\":[{\"mtn\": \"1234567890\",\"firstName\": \"Jane\",\"lastName\": \"Doe\",\"email\":\"xyz@vzcorp.com\"}]}";
		RPSE911AddressRetrieveCxpRequest cxpRequest=new RPSE911AddressRetrieveCxpRequest();
		RPSE911AddressRetrieveUIRequest uiRequest=mapper.readValue(sampleResponseString, RPSE911AddressRetrieveUIRequest.class);
		util.formatRetrieveRPSE911AddressRequest(uiRequest, cxpRequest);
	}

	@Test
	public void  formatUpdateTradeInOfferRequestTest() throws JsonMappingException, JsonProcessingException
	{
		String sampleResponseString = "{\"meta\":{\"timestamp\":\"2019-08-05T13:27:07Z\",\"cxpCorrelationId\":\"3d5f3c15-aa3b-4a42-9245-5cb4177468e4\"},\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"},\"channelId\":\"VZW-NUMBERLINK\",\"deviceId\":\"999\",\"mtn\":\"999\",\"zipCode\":\"500086\",\"lineItemNumber\":\"999\",\"orderNumber\":\"999\",\"lineItemInfoList\":{\"lineItemNumber\":\"999\",\"lineItemTimeStamp\":\"1000\",\"orderNumber\":\"9879\"}}";
		String sampleRequestString = "{\"client\": \"CXP\",\"cartId\": \"09cfa680-f331-4c03-b83f-e27322882457\",\"lines\":[{\"mtn\": \"1234567890\",\"firstName\": \"Jane\",\"lastName\": \"Doe\",\"email\":\"xyz@vzcorp.com\"}]}";
		UpdateTradeInOfferCXPRequest cxpRequest=new UpdateTradeInOfferCXPRequest();
		UpdateTradeInOfferUIRequest uiRequest=mapper.readValue(sampleResponseString, UpdateTradeInOfferUIRequest.class);
		util. formatUpdateTradeInOfferRequest(uiRequest, cxpRequest);
	}
	
	@Test
	public void  formatUpdateTradeinTypeRequest() throws JsonMappingException, JsonProcessingException
	{
		String sampleResponseString = "{\"meta\":{\"timestamp\":\"1684339338960\",\"cxpCorrelationId\":\"2023-05-17T16:02:18.+0000:9dec804e07e006af:cxp-shopping-services-75d6bcf5cf-cr5qd:nssit3\"},\"data\":{\"cartId\":\"a25f9cd3-6122-444a-a3bd-5faaa0ec3fbc\",\"statusMsg\":\"Success\"}}\r\n"
				+ "\r\n";
		String sampleRequestString = "{\"meta\":\r\n" + "{\"client\":\"CXP\"},\r\n" + "\"data\":\r\n" + "{\r\n"
				+ "\"cartId\":\"a25f9cd3-6122-444a-a3bd-5faaa0ec3fbc\",\"intendType\":\"AAL\",\"itemType\":\"TRADEINTYPE\",\"action\":\"UPDATE\",\"tradeInType\":\"Store\",\"tradeInShippingType\":\"return_store\",\r\n"
				+ "\"preferredStoreId\":\"0026301\",\"preferredStoreAddress\":\"One way\"\r\n" + "}}\r\n";
		UpdateTradeinTypeCXPRequest cxpRequest = new UpdateTradeinTypeCXPRequest();
		UpdateTradeinTypeUIRequest uiRequest = mapper.readValue(sampleRequestString, UpdateTradeinTypeUIRequest.class);
		CartCxpRequestUtil.formatUpdateTradeinTypeRequest(uiRequest, cxpRequest);
	
	}

	@Test
	public void formatAddZipcodeRequestTest() throws JsonMappingException, JsonProcessingException
	{
		String sampleResponseString = "{\"meta\":{\"timestamp\":\"2019-08-05T13:27:07Z\",\"cxpCorrelationId\":\"3d5f3c15-aa3b-4a42-9245-5cb4177468e4\"},\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"},\"channelId\":\"VZW-NUMBERLINK\",\"deviceId\":\"999\",\"mtn\":\"999\",\"zipCode\":\"500086\",\"lineItemNumber\":\"999\",\"orderNumber\":\"999\",\"lineItemInfoList\":{\"lineItemNumber\":\"999\",\"lineItemTimeStamp\":\"1000\",\"orderNumber\":\"9879\",\"itemType\":\"pc\",\"intendType\":\"pc\"}}";
		String sampleRequestString = "{\"client\": \"CXP\",\"cartId\": \"09cfa680-f331-4c03-b83f-e27322882457\",\"lines\":[{\"mtn\": \"1234567890\",\"firstName\": \"Jane\",\"lastName\": \"Doe\",\"email\":\"xyz@vzcorp.com\"}]}";
		AddZipcodeCXPRequest cxpRequest=new AddZipcodeCXPRequest();
		AddZipCodeUIRequest uiRequest=mapper.readValue(sampleResponseString, AddZipCodeUIRequest.class);
		util.formatAddZipcodeRequest(uiRequest,cxpRequest);

		uiRequest.setItemType(null);
		util.formatAddZipcodeRequest(uiRequest,cxpRequest);

		uiRequest.setItemType("random");
		util.formatAddZipcodeRequest(uiRequest,cxpRequest);
	}

	@Test
	public void formatDeviceSimValidationRequestTest() throws JsonMappingException, JsonProcessingException
	{
		try
		{
			String sampleResponseString = "{\"meta\":{\"timestamp\":\"2019-08-05T13:27:07Z\",\"cxpCorrelationId\":\"3d5f3c15-aa3b-4a42-9245-5cb4177468e4\"},\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"},\"channelId\":\"VZW-NUMBERLINK\",\"deviceId\":\"999\",\"mtn\":\"999\",\"zipCode\":\"500086\",\"lineItemNumber\":\"999\",\"orderNumber\":\"999\",\"lineItemInfoList\":{\"lineItemNumber\":\"999\",\"lineItemTimeStamp\":\"1000\",\"orderNumber\":\"9879\"},\"itemType\":\"pc\",\"intendType\":\"pc\",\"eid\":\"1234\",\"imei2\":\"1234\",\"techType\":\"MANAGEACCOUNT\",\"imei\":\"1234\",\"iccid\":\"1234\",\"billingId\":\"1234\",\"devid\":\"123\",\"iccid\":\"1234\"}}";
			String sampleRequestString = "{\"client\": \"CXP\",\"cartId\": \"09cfa680-f331-4c03-b83f-e27322882457\",\"lines\":[{\"mtn\": \"1234567890\",\"firstName\": \"Jane\",\"lastName\": \"Doe\",\"email\":\"xyz@vzcorp.com\"}]}";
			DeviceSimValidationCXPRequest cxpRequest=new DeviceSimValidationCXPRequest();
			DeviceSimValidationUIRequest uiRequest=mapper.readValue(sampleResponseString, DeviceSimValidationUIRequest.class);
			util.formatDeviceSimValidationRequest(uiRequest,cxpRequest);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	@Test
	public void formatVzccNBXInfoRequestTest() throws JsonMappingException, JsonProcessingException
	{
		String sampleResponseString = "{\"meta\":{\"timestamp\":\"2019-08-05T13:27:07Z\",\"cxpCorrelationId\":\"3d5f3c15-aa3b-4a42-9245-5cb4177468e4\"},\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"},\"channelId\":\"VZW-NUMBERLINK\",\"deviceId\":\"999\",\"mtn\":\"999\",\"zipCode\":\"500086\",\"lineItemNumber\":\"999\",\"orderNumber\":\"999\",\"lineItemInfoList\":{\"lineItemNumber\":\"999\",\"lineItemTimeStamp\":\"1000\",\"orderNumber\":\"9879\",\"itemType\":\"pc\",\"intendType\":\"pc\"}}";
		String sampleRequestString = "{\"client\": \"CXP\",\"cartId\": \"09cfa680-f331-4c03-b83f-e27322882457\",\"lines\":[{\"mtn\": \"1234567890\",\"firstName\": \"Jane\",\"lastName\": \"Doe\",\"email\":\"xyz@vzcorp.com\"}]}";
		UpdateVzccNBXInfoCXPRequest cxpRequest=new UpdateVzccNBXInfoCXPRequest();
		UpdateVzccNBXInfoUIRequest uiRequest=mapper.readValue(sampleResponseString, UpdateVzccNBXInfoUIRequest.class);
		util.formatVzccNBXInfoRequest(uiRequest,cxpRequest);
	}

	@Test
	public void formatValidateE911AddressRequestTest() throws JsonMappingException, JsonProcessingException
	{
		String sampleResponseString =  "{\"mtn\":[\"1234567890\",\"9876543210\"],\"channelId\":\"VZW-RPS\"}";
		String sampleRequestString = "{\"client\": \"CXP\",\"cartId\": \"09cfa680-f331-4c03-b83f-e27322882457\",\"lines\":[{\"mtn\": \"1234567890\",\"firstName\": \"Jane\",\"lastName\": \"Doe\",\"email\":\"xyz@vzcorp.com\"}]}";
		AddressRequest cxpRequest=new AddressRequest();
		RPSE911AddressUpdateUIRequest uiRequest=mapper.readValue(sampleResponseString, RPSE911AddressUpdateUIRequest.class);
		util.formatValidateE911AddressRequest(uiRequest,cxpRequest);
	}

	@Test
	public void formatInitiateESimActivationCXPRequestTest() throws JsonMappingException, JsonProcessingException
	{
		String sampleResponseString = "{\"meta\":{\"timestamp\":\"2019-08-05T13:27:07Z\",\"cxpCorrelationId\":\"3d5f3c15-aa3b-4a42-9245-5cb4177468e4\"},\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"},\"channelId\":\"VZW-NUMBERLINK\",\"deviceId\":\"999\",\"mtn\":\"999\",\"zipCode\":\"500086\",\"lineItemNumber\":\"999\",\"orderNumber\":\"999\",\"lineItemInfoList\":{\"lineItemNumber\":\"999\",\"lineItemTimeStamp\":\"1000\",\"orderNumber\":\"9879\",\"itemType\":\"pc\",\"intendType\":\"pc\"}}";
		String sampleRequestString = "{\"client\": \"CXP\",\"cartId\": \"09cfa680-f331-4c03-b83f-e27322882457\",\"lines\":[{\"mtn\": \"1234567890\",\"firstName\": \"Jane\",\"lastName\": \"Doe\",\"email\":\"xyz@vzcorp.com\"}]}";
		InitiateESimActivationCXPRequest cxpRequest=new InitiateESimActivationCXPRequest();
		IntiateESimActivationUIRequest uiRequest=mapper.readValue(sampleResponseString, IntiateESimActivationUIRequest.class);
		util.formatInitiateESimActivationCXPRequest(uiRequest,cxpRequest);

	}

	@Test
	public void formatInitiateDeviceSimActivationCXPRequestTest() throws JsonMappingException, JsonProcessingException
	{
		String sampleResponseString = "{\"meta\":{\"timestamp\":\"2019-08-05T13:27:07Z\",\"cxpCorrelationId\":\"3d5f3c15-aa3b-4a42-9245-5cb4177468e4\"},\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"},\"channelId\":\"VZW-NUMBERLINK\",\"deviceId\":\"999\",\"mtn\":\"999\",\"zipCode\":\"500086\",\"lineItemNumber\":\"999\",\"orderNumber\":\"999\",\"lineItemInfoList\":{\"lineItemNumber\":\"999\",\"lineItemTimeStamp\":\"1000\",\"orderNumber\":\"9879\",\"itemType\":\"pc\",\"intendType\":\"pc\"}}";
		String sampleRequestString = "{\"client\": \"CXP\",\"cartId\": \"09cfa680-f331-4c03-b83f-e27322882457\",\"lines\":[{\"mtn\": \"1234567890\",\"firstName\": \"Jane\",\"lastName\": \"Doe\",\"email\":\"xyz@vzcorp.com\"}]}";
		IntiateDeviceSimActivationCXPRequest cxpRequest=new IntiateDeviceSimActivationCXPRequest();
		IntiateDeviceSimActivationUIRequest uiRequest=mapper.readValue(sampleResponseString, IntiateDeviceSimActivationUIRequest.class);
		util.formatInitiateDeviceSimActivationCXPRequest(uiRequest,cxpRequest);

	}

	@Test
	public void formatDeviceSimValidationWIthEidRequestTest() throws JsonMappingException, JsonProcessingException
	{
		String sampleResponseString = "{\"meta\":{\"timestamp\":\"2019-08-05T13:27:07Z\",\"cxpCorrelationId\":\"3d5f3c15-aa3b-4a42-9245-5cb4177468e4\"},\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"},\"channelId\":\"VZW-NUMBERLINK\",\"deviceId\":\"999\",\"mtn\":\"999\",\"zipCode\":\"500086\",\"lineItemNumber\":\"999\",\"orderNumber\":\"999\",\"lineItemInfoList\":{\"lineItemNumber\":\"999\",\"lineItemTimeStamp\":\"1000\",\"orderNumber\":\"9879\",\"itemType\":\"pc\",\"intendType\":\"pc\"}}";
		String sampleRequestString = "{\"client\": \"CXP\",\"cartId\": \"09cfa680-f331-4c03-b83f-e27322882457\",\"lines\":[{\"mtn\": \"1234567890\",\"firstName\": \"Jane\",\"lastName\": \"Doe\",\"email\":\"xyz@vzcorp.com\"}]}";
		DeviceSimValidationCXPRequest cxpRequest=new DeviceSimValidationCXPRequest();
		DeviceSimValidationUIRequest uiRequest=mapper.readValue(sampleResponseString, DeviceSimValidationUIRequest.class);
		util.formatDeviceSimValidationWIthEidRequest(uiRequest,cxpRequest);

	}

	@Test
	public void formatCheckDfillInventoryRequestTest() {
		CheckDfillInventoryUIRequest uiRequest = new CheckDfillInventoryUIRequest();
		uiRequest.setIntendType("NSE");
		CheckDfillInventoryCXPRequest response = util.formatCheckDfillInventoryRequest(uiRequest, new CheckDfillInventoryCXPRequest());
		Assert.assertEquals("NSE", response.getData().getIntendType());
	}

	@Test
	public void buildCXPValidateOfferRequestTest() {
		ApplyOfferRequest applyOfferRequest = new ApplyOfferRequest();
		applyOfferRequest.setCartInfo(new MyOfferCartInfo());
		MyOfferETRRedisData myOfferData = new MyOfferETRRedisData();
		List<MyOfferLine> lines = new ArrayList<MyOfferLine>();
		lines.add(new MyOfferLine());
		myOfferData.setLines(lines);
		ValidateOffersRequest response = util.buildCXPValidateOfferRequest(applyOfferRequest, myOfferData);
		Assert.assertNull(response.getData().getCartId());
	}

	@Test
	public void formatVZCCAppStatusRequestTest() {
		VZCCAppStatusUIRequest uiRequest = new VZCCAppStatusUIRequest();
		uiRequest.setIntentType("NSE");
		VZCCAppStatusCXPRequest response = util.formatVZCCAppStatusRequest(uiRequest, new VZCCAppStatusCXPRequest());
		Assert.assertEquals("NSE", response.getData().getIntendType());
	}

	@Test
	public void formatVZCCAppStatusRequest1Test() {
		VZCCAppStatusUIRequest uiRequest = new VZCCAppStatusUIRequest();
		VZCCStatus vzccStatus1 = new VZCCStatus();
		vzccStatus1.setFeedbackStatus("Rechazado");
		uiRequest.setVzccStatus(vzccStatus1);
		VZCCAppStatusCXPRequest response = util.formatVZCCAppStatusRequest(uiRequest, new VZCCAppStatusCXPRequest());
		Assert.assertEquals("Declined", response.getData().getVzccStatus().getFeedbackStatus());
	}
	@Test
	public void formatVZCCAppStatusRequest2Test() {
		VZCCAppStatusUIRequest uiRequest = new VZCCAppStatusUIRequest();
		VZCCStatus vzccStatus1 = new VZCCStatus();
		vzccStatus1.setFeedbackStatus("se aplicó");
		uiRequest.setVzccStatus(vzccStatus1);
		VZCCAppStatusCXPRequest response = util.formatVZCCAppStatusRequest(uiRequest, new VZCCAppStatusCXPRequest());
		Assert.assertEquals("Applied", response.getData().getVzccStatus().getFeedbackStatus());
	}

	@Test
	public void formatVZCCAppStatusRequest3Test() {
		VZCCAppStatusUIRequest uiRequest = new VZCCAppStatusUIRequest();
		VZCCStatus vzccStatus1 = new VZCCStatus();
		vzccStatus1.setFeedbackStatus(null);
		uiRequest.setVzccStatus(vzccStatus1);
		VZCCAppStatusCXPRequest response = util.formatVZCCAppStatusRequest(uiRequest, new VZCCAppStatusCXPRequest());
		Assert.assertEquals(null, response.getData().getVzccStatus().getFeedbackStatus());
	}

	@Test
	public void formatVZCCAppStatusRequest4Test() {
		VZCCAppStatusUIRequest uiRequest = new VZCCAppStatusUIRequest();
		uiRequest.setVzccStatus(null);
		VZCCAppStatusCXPRequest response = util.formatVZCCAppStatusRequest(uiRequest, new VZCCAppStatusCXPRequest());
		Assert.assertEquals(null, response.getData().getVzccStatus());
	}
	@Test
	public void formMyOffersRequestTest2() throws JsonMappingException, JsonProcessingException {
		String redisDataString = "{\"cartId\": \"\",\"intendType\": \"NSE\",\"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"\" }";
		RTDRedisData rtdData = mapper.readValue(redisDataString, RTDRedisData.class);
		MyOffersCXPRequest response = util.formMyOffersRequest(rtdData, "OMNI-INDIRECT");
		Assert.assertEquals("NSE", response.getData().getIntendType());
	}

	@Test
	public void formMyOffersRequestTest3() throws JsonMappingException, JsonProcessingException {
		String redisDataString = "{\"intendType\": \"NSE\",\"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"34567\" }";
		RTDRedisData rtdData = mapper.readValue(redisDataString, RTDRedisData.class);
		Map<String, List<RTDOfferDetails>> map = new HashMap<>();
		List<RTDOfferDetails> list = new ArrayList<>();
		list.add(new RTDOfferDetails());
		map.put("1234", list);
		rtdData.setOffers(map);
		MyOffersCXPRequest response = util.formMyOffersRequest(rtdData, "OMNI-INDIRECT");
		Assert.assertEquals("NSE", response.getData().getIntendType());
	}

	@Test
	public void formMyOffersRequestTest4() throws JsonMappingException, JsonProcessingException {
		String redisDataString = "{\"intendType\": \"NSE\",\"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"1234\" }";
		RTDRedisData rtdData = mapper.readValue(redisDataString, RTDRedisData.class);
		Map<String, List<RTDOfferDetails>> map = new HashMap<>();
		List<RTDOfferDetails> list = new ArrayList<>();
		list.add(new RTDOfferDetails());
		map.put("1234", list);
		rtdData.setOffers(map);
		MyOffersCXPRequest response = util.formMyOffersRequest(rtdData, "OMNI-INDIRECT");
		Assert.assertEquals("NSE", response.getData().getIntendType());
	}

	@Test
	public void formMyOffersRequestTest5() throws JsonMappingException, JsonProcessingException {
		String redisDataString = "{\"intendType\": \"\",\"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"1234\" }";
		RTDRedisData rtdData = mapper.readValue(redisDataString, RTDRedisData.class);
		Map<String, List<RTDOfferDetails>> map = new HashMap<>();
		List<RTDOfferDetails> list = new ArrayList<>();
		RTDOfferDetails offerDetails = mapper.readValue("{\"complianceType\": \"C\"}", RTDOfferDetails.class);
		Map<String, List<ComplianceSkuDetails>> mapSku = new HashMap<>();
		List<ComplianceSkuDetails> listSku = new ArrayList<>();
		listSku.add(new ComplianceSkuDetails());
		mapSku.put("A", listSku);
		offerDetails.setComplianceSkus(mapSku);
		list.add(offerDetails);
		map.put("1234", list);
		rtdData.setOffers(map);
		MyOffersCXPRequest response = util.formMyOffersRequest(rtdData, "OMNI-INDIRECT");
		Assert.assertEquals("C", response.getData().getLines().get(0).getRestrictedProductType());
	}

	@Test
	public void formMyOffersRequestTest6() throws JsonMappingException, JsonProcessingException {
		String redisDataString = "{\"intendType\": \"\",\"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"1234\" }";
		RTDRedisData rtdData = mapper.readValue(redisDataString, RTDRedisData.class);
		Map<String, List<RTDOfferDetails>> map = new HashMap<>();
		List<RTDOfferDetails> list = new ArrayList<>();
		RTDOfferDetails offerDetails = mapper.readValue("{\"complianceType\": \"C\"}", RTDOfferDetails.class);
		Map<String, List<ComplianceSkuDetails>> mapSku = new HashMap<>();
		List<ComplianceSkuDetails> listSku = new ArrayList<>();
		listSku.add(new ComplianceSkuDetails());
		mapSku.put("Y", listSku);
		offerDetails.setComplianceSkus(mapSku);
		list.add(offerDetails);
		map.put("1234", list);
		rtdData.setOffers(map);
		MyOffersCXPRequest response = util.formMyOffersRequest(rtdData, "OMNI-INDIRECT");
		Assert.assertEquals("Y", response.getData().getLines().get(0).getRestricted());
	}

	@Test
	public void formatAddZipcodeRequestTest2() throws JsonMappingException, JsonProcessingException {
		String sampleRequestString = "{\"meta\":{\"timestamp\":\"2019-08-05T13:27:07Z\",\"cxpCorrelationId\":\"3d5f3c15-aa3b-4a42-9245-5cb4177468e4\"},\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"},\"channelId\":\"VZW-NUMBERLINK\",\"deviceId\":\"999\",\"mtn\":\"999\",\"zipCode\":\"500086\",\"lineItemNumber\":\"999\",\"orderNumber\":\"999\",\"lineItemInfoList\":{\"lineItemNumber\":\"999\",\"lineItemTimeStamp\":\"1000\",\"orderNumber\":\"9879\",\"intendType\":\"pc\"}}";
		AddZipCodeUIRequest uiRequest = mapper.readValue(sampleRequestString, AddZipCodeUIRequest.class);
		AddZipcodeCXPRequest response = util.formatAddZipcodeRequest(uiRequest, new AddZipcodeCXPRequest());
		Assert.assertEquals("USERCONTACTINFO", response.getData().getItemType());
	}

	@Test
	public void formatDeviceSimValidationRequestTest2() throws JsonMappingException, JsonProcessingException {
		String sampleRequestString = "{\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"},\"channelId\":\"VZW-NUMBERLINK\",\"deviceId\":\"999\",\"mtn\":\"999\",\"zipCode\":\"500086\",\"lineItemNumber\":\"999\",\"orderNumber\":\"999\",\"lineItemInfoList\":{\"lineItemNumber\":\"999\",\"lineItemTimeStamp\":\"1000\",\"orderNumber\":\"9879\"},\"itemType\":\"pc\",\"intendType\":\"pc\",\"eid\":\"\",\"imei2\":\"\",\"techType\":\"MANAGEACCOUNT\",\"imei\":\"1234\",\"iccid\":\"\",\"billingId\":\"1234\",\"devid\":\"123\",\"iccid\":\"1234\"}}";
		DeviceSimValidationUIRequest uiRequest = mapper.readValue(sampleRequestString, DeviceSimValidationUIRequest.class);
		DeviceSimValidationCXPRequest response = util.formatDeviceSimValidationRequest(uiRequest,new DeviceSimValidationCXPRequest());
		Assert.assertEquals("1234", response.getData().getESim().getDeviceId());
	}

	@Test
	public void formatDeviceSimValidationRequestTest3() throws JsonMappingException, JsonProcessingException {
		String sampleRequestString = "{\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"},\"channelId\":\"VZW-NUMBERLINK\",\"deviceId\":\"999\",\"mtn\":\"999\",\"zipCode\":\"500086\",\"lineItemNumber\":\"999\",\"orderNumber\":\"999\",\"lineItemInfoList\":{\"lineItemNumber\":\"999\",\"lineItemTimeStamp\":\"1000\",\"orderNumber\":\"9879\"},\"itemType\":\"pc\",\"intendType\":\"pc\",\"eid\":\"\",\"imei2\":\"\",\"techType\":\"MANAGEACCOUNT\",\"imei\":\"1234\",\"iccid\":\"\",\"billingId\":\"1234\",\"devid\":\"123\",\"iccid\":\"1234\"}}";
		DeviceSimValidationUIRequest uiRequest = mapper.readValue(sampleRequestString, DeviceSimValidationUIRequest.class);
		DeviceSimValidationCXPRequest response = util.formatDeviceSimValidationRequest(uiRequest,new DeviceSimValidationCXPRequest());
		Assert.assertEquals("1234", response.getData().getESim().getDeviceId());
	}

	@Test
	public void formatDeviceSimValidationRequestTest4() throws JsonMappingException, JsonProcessingException {
		String sampleRequestString = "{\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"},\"channelId\":\"VZW-NUMBERLINK\",\"deviceId\":\"999\",\"mtn\":\"999\",\"zipCode\":\"500086\",\"lineItemNumber\":\"999\",\"orderNumber\":\"999\",\"lineItemInfoList\":{\"lineItemNumber\":\"999\",\"lineItemTimeStamp\":\"1000\",\"orderNumber\":\"9879\"},\"itemType\":\"pc\",\"intendType\":\"pc\",\"eid\":\"\",\"imei2\":\"\",\"techType\":\"MANAGEACCOUNT\",\"imei\":\"1234\",\"iccid\":\"\",\"billingId\":\"1234\",\"devid\":\"123\",\"iccid\":\"1234\"}}";
		DeviceSimValidationUIRequest uiRequest = mapper.readValue(sampleRequestString, DeviceSimValidationUIRequest.class);
		DeviceSimValidationCXPRequest response = util.formatDeviceSimValidationRequest(uiRequest,new DeviceSimValidationCXPRequest());
		Assert.assertEquals("1234", response.getData().getESim().getDeviceId());
	}

	@Test
	public void formatDeviceSimValidationRequestTest5() throws JsonMappingException, JsonProcessingException {
		String sampleRequestString = "{\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"},\"channelId\":\"VZW-NUMBERLINK\",\"deviceId\":\"999\",\"mtn\":\"999\",\"zipCode\":\"500086\",\"lineItemNumber\":\"999\",\"orderNumber\":\"999\",\"lineItemInfoList\":{\"lineItemNumber\":\"999\",\"lineItemTimeStamp\":\"1000\",\"orderNumber\":\"9879\"},\"itemType\":\"pc\",\"intendType\":\"pc\",\"eid\":\"\",\"imei2\":\"\",\"techType\":\"MANAGEACCOUNT\",\"imei\":\"1234\",\"iccid\":\"1234\",\"billingId\":\"\",\"devid\":\"\",\"iccid\":\"1234\"}}";
		DeviceSimValidationUIRequest uiRequest = mapper.readValue(sampleRequestString, DeviceSimValidationUIRequest.class);
		DeviceSimValidationCXPRequest response = util.formatDeviceSimValidationRequest(uiRequest,new DeviceSimValidationCXPRequest());
	}

	@Test
	public void formatDeviceSimValidationRequestTest6() throws JsonMappingException, JsonProcessingException {
		String sampleRequestString = "{\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"},\"channelId\":\"VZW-NUMBERLINK\",\"deviceId\":\"999\",\"mtn\":\"999\",\"zipCode\":\"500086\",\"lineItemNumber\":\"999\",\"orderNumber\":\"999\",\"lineItemInfoList\":{\"lineItemNumber\":\"999\",\"lineItemTimeStamp\":\"1000\",\"orderNumber\":\"9879\"},\"itemType\":\"pc\",\"intendType\":\"pc\",\"eid\":\"\",\"imei2\":\"\",\"techType\":\"MANAGEACCOUNT\",\"imei\":\"1234\",\"iccid\":\"\",\"billingId\":\"\",\"devid\":\"\",\"iccid\":\"1234\"}}";
		DeviceSimValidationUIRequest uiRequest = mapper.readValue(sampleRequestString, DeviceSimValidationUIRequest.class);
		DeviceSimValidationCXPRequest response = util.formatDeviceSimValidationRequest(uiRequest,new DeviceSimValidationCXPRequest());
	}

	@Test
	public void formatDeviceSimValidationRequestTest7() throws JsonMappingException, JsonProcessingException {
		String sampleRequestString = "{\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"},\"channelId\":\"VZW-NUMBERLINK\",\"deviceId\":\"999\",\"mtn\":\"999\",\"zipCode\":\"500086\",\"lineItemNumber\":\"999\",\"orderNumber\":\"999\",\"lineItemInfoList\":{\"lineItemNumber\":\"999\",\"lineItemTimeStamp\":\"1000\",\"orderNumber\":\"9879\"},\"itemType\":\"pc\",\"intendType\":\"pc\",\"eid\":\"\",\"imei2\":\"\",\"techType\":\"MANAGEACCOUNT\",\"imei\":\"\",\"iccid\":\"\",\"billingId\":\"\",\"devid\":\"\",\"iccid\":\"1234\"}}";
		DeviceSimValidationUIRequest uiRequest = mapper.readValue(sampleRequestString, DeviceSimValidationUIRequest.class);
		DeviceSimValidationCXPRequest response = util.formatDeviceSimValidationRequest(uiRequest,new DeviceSimValidationCXPRequest());
	}

	@Test
	public void formatDeviceSimValidationRequestTest8() throws JsonMappingException, JsonProcessingException {
		String sampleRequestString = "{\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"},\"channelId\":\"VZW-NUMBERLINK\",\"deviceId\":\"999\",\"mtn\":\"999\",\"zipCode\":\"500086\",\"lineItemNumber\":\"999\",\"orderNumber\":\"999\",\"lineItemInfoList\":{\"lineItemNumber\":\"999\",\"lineItemTimeStamp\":\"1000\",\"orderNumber\":\"9879\"},\"itemType\":\"pc\",\"intendType\":\"pc\",\"eid\":\"\",\"imei2\":\"\",\"techType\":\"\",\"imei\":\"\",\"iccid\":\"\",\"billingId\":\"\",\"devid\":\"\",\"iccid\":\"1234\"}}";
		DeviceSimValidationUIRequest uiRequest = mapper.readValue(sampleRequestString, DeviceSimValidationUIRequest.class);
		DeviceSimValidationCXPRequest response = util.formatDeviceSimValidationRequest(uiRequest,new DeviceSimValidationCXPRequest());
	}

	@Test
	public void formatDeviceSimValidationRequestTest9() throws JsonMappingException, JsonProcessingException {
		String sampleRequestString = "{\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"},\"channelId\":\"VZW-NUMBERLINK\",\"deviceId\":\"999\",\"mtn\":\"999\",\"zipCode\":\"500086\",\"lineItemNumber\":\"999\",\"orderNumber\":\"999\",\"lineItemInfoList\":{\"lineItemNumber\":\"999\",\"lineItemTimeStamp\":\"1000\",\"orderNumber\":\"9879\"},\"itemType\":\"pc\",\"intendType\":\"pc\",\"eid\":\"2134\",\"imei2\":\"\",\"techType\":\"\",\"imei\":\"\",\"iccid\":\"\",\"billingId\":\"\",\"devid\":\"\",\"iccid\":\"1234\"}}";
		DeviceSimValidationUIRequest uiRequest = mapper.readValue(sampleRequestString, DeviceSimValidationUIRequest.class);
		DeviceSimValidationCXPRequest response = util.formatDeviceSimValidationRequest(uiRequest,new DeviceSimValidationCXPRequest());
	}

	@Test
	public void formatDeviceSimValidationRequestTest10() throws JsonMappingException, JsonProcessingException {
		String sampleRequestString = "{\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"},\"channelId\":\"VZW-NUMBERLINK\",\"deviceId\":\"\",\"mtn\":\"999\",\"zipCode\":\"500086\",\"lineItemNumber\":\"999\",\"orderNumber\":\"999\",\"lineItemInfoList\":{\"lineItemNumber\":\"999\",\"lineItemTimeStamp\":\"1000\",\"orderNumber\":\"9879\"},\"itemType\":\"pc\",\"intendType\":\"pc\",\"eid\":\"2134\",\"imei2\":\"\",\"techType\":\"\",\"imei\":\"\",\"iccid\":\"\",\"billingId\":\"\",\"devid\":\"1234\"}}";
		DeviceSimValidationUIRequest uiRequest = mapper.readValue(sampleRequestString, DeviceSimValidationUIRequest.class);
		DeviceSimValidationCXPRequest response = util.formatDeviceSimValidationRequest(uiRequest,new DeviceSimValidationCXPRequest());
	}

	@Test
	public void formatDeviceSimValidationRequestTest11() throws JsonMappingException, JsonProcessingException {
		String sampleRequestString = "{\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"},\"channelId\":\"VZW-NUMBERLINK\",\"deviceId\":\"\",\"mtn\":\"999\",\"zipCode\":\"500086\",\"lineItemNumber\":\"999\",\"orderNumber\":\"999\",\"lineItemInfoList\":{\"lineItemNumber\":\"999\",\"lineItemTimeStamp\":\"1000\",\"orderNumber\":\"9879\"},\"itemType\":\"pc\",\"intendType\":\"pc\",\"eid\":\"1234\",\"imei2\":\"1234\",\"techType\":\"\",\"imei\":\"\",\"iccid\":\"\",\"billingId\":\"\",\"devid\":\"\"}}";
		DeviceSimValidationUIRequest uiRequest = mapper.readValue(sampleRequestString, DeviceSimValidationUIRequest.class);
		DeviceSimValidationCXPRequest response = util.formatDeviceSimValidationRequest(uiRequest,new DeviceSimValidationCXPRequest());
		Assert.assertEquals("PHONE", response.getData().getESim().getEsimType());
	}

	@Test
	public void formatDeviceSimValidationRequestTest12() throws JsonMappingException, JsonProcessingException {
		String sampleRequestString = "{\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"},\"channelId\":\"VZW-NUMBERLINK\",\"deviceId\":\"\",\"mtn\":\"999\",\"zipCode\":\"500086\",\"lineItemNumber\":\"999\",\"orderNumber\":\"999\",\"lineItemInfoList\":{\"lineItemNumber\":\"999\",\"lineItemTimeStamp\":\"1000\",\"orderNumber\":\"9879\"},\"itemType\":\"pc\",\"intendType\":\"pc\",\"eid\":\"\",\"imei2\":\"1234\",\"techType\":\"\",\"imei\":\"1234\",\"iccid\":\"1234\",\"billingId\":\"1234\",\"devid\":\"\"}}";
		DeviceSimValidationUIRequest uiRequest = mapper.readValue(sampleRequestString, DeviceSimValidationUIRequest.class);
		DeviceSimValidationCXPRequest response = util.formatDeviceSimValidationRequest(uiRequest,new DeviceSimValidationCXPRequest());
		Assert.assertEquals("1234", response.getData().getPSim().getBillingId());
	}

	@Test
	public void formatDeviceSimValidationRequestTest13() throws JsonMappingException, JsonProcessingException {
		String sampleRequestString = "{\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"},\"channelId\":\"VZW-NUMBERLINK\",\"deviceId\":\"\",\"mtn\":\"999\",\"zipCode\":\"500086\",\"lineItemNumber\":\"999\",\"orderNumber\":\"999\",\"lineItemInfoList\":{\"lineItemNumber\":\"999\",\"lineItemTimeStamp\":\"1000\",\"orderNumber\":\"9879\"},\"itemType\":\"pc\",\"intendType\":\"pc\",\"eid\":\"\",\"imei2\":\"1234\",\"techType\":\"\",\"imei\":\"1234\",\"iccid\":\"\",\"billingId\":\"\",\"devid\":\"\"}}";
		DeviceSimValidationUIRequest uiRequest = mapper.readValue(sampleRequestString, DeviceSimValidationUIRequest.class);
		DeviceSimValidationCXPRequest response = util.formatDeviceSimValidationRequest(uiRequest,new DeviceSimValidationCXPRequest());
		Assert.assertEquals("1234", response.getData().getPSim().getDeviceId());
	}

	@Test
	public void formatInitiateCbandCheckRequestTest() throws JsonMappingException, JsonProcessingException {
		String sampleRequestString = "{\"pendingInstallScenario\": true}";
		InitiateCbandCheckUIRequest uiRequest = mapper.readValue(sampleRequestString, InitiateCbandCheckUIRequest.class);
		InitiateCbandCheckCXPRequest response = util.formatInitiateCbandCheckRequest(uiRequest,new InitiateCbandCheckCXPRequest());
		Assert.assertTrue(response.getData().getPendingInstallScenario());
	}

	@Test
	public void formatVzccNBXInfoRequestTest2() throws JsonMappingException, JsonProcessingException {
		String sampleRequestString = "{\"intentType\": \"NSE\"}";
		UpdateVzccNBXInfoUIRequest uiRequest = mapper.readValue(sampleRequestString, UpdateVzccNBXInfoUIRequest.class);
		UpdateVzccNBXInfoCXPRequest response = util.formatVzccNBXInfoRequest(uiRequest,new UpdateVzccNBXInfoCXPRequest());
		Assert.assertEquals("NSE", response.getData().getIntendType());
	}

	@Test
	public void formatInitiateESimActivationCXPRequestTest2() throws JsonMappingException, JsonProcessingException {
		String sampleRequestString = "{\"imei\": \"1234\",\"eid\": \"321\",\"handOffToken\": \"token\"}";
		IntiateESimActivationUIRequest uiRequest = mapper.readValue(sampleRequestString, IntiateESimActivationUIRequest.class);
		InitiateESimActivationCXPRequest response = util.formatInitiateESimActivationCXPRequest(uiRequest,new InitiateESimActivationCXPRequest());
		Assert.assertEquals("1234", response.getData().getEsim().getDeviceId());
	}

	@Test
	public void formatUpdateCusetomerConsentRequestTest() throws JsonMappingException, JsonProcessingException {
		String sampleRequestString = "{\"cartInfo\": {}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
		uiRequest.setCartInfo(new DeviceCartInfo());
		uiRequest.getCartInfo().setCustomerConsent(true);
		UpdateConsentCxpRequest response = util.formatUpdateCusetomerConsentRequest(uiRequest,new UpdateConsentCxpRequest());
		Assert.assertEquals("CONSENT", response.getData().getItemType());

		uiRequest.getCartInfo().setCustomerConsent(false);
		util.formatUpdateCusetomerConsentRequest(uiRequest,new UpdateConsentCxpRequest());
	}

	@Test
	public void formatNbsDataRequestTest() throws JsonMappingException, JsonProcessingException {
		String sampleRequestString = "{\"cartInfo\": {}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
		NbsDataCXPRequest response = util.formatNbsDataRequest(uiRequest,new NbsDataCXPRequest());
	}

	@Test
	public void formatDeviceSimValidationRequestNullCheck() throws JsonMappingException, JsonProcessingException
	{
		String sampleResponseString = "{\"meta\":{\"timestamp\":\"2019-08-05T13:27:07Z\",\"cxpCorrelationId\":\"3d5f3c15-aa3b-4a42-9245-5cb4177468e4\"},\"data\":{\"cartId\":\"03019841-59b2-44a4-9b41-88eafb43b4c6\",\"statusMsg\":\"Userinformationupdatedsuccessfully.\"},\"channelId\":\"VZW-NUMBERLINK\",\"deviceId\":\"999\",\"mtn\":\"999\",\"zipCode\":\"500086\",\"lineItemNumber\":\"999\",\"orderNumber\":\"999\",\"lineItemInfoList\":{\"lineItemNumber\":\"999\",\"lineItemTimeStamp\":\"1000\",\"orderNumber\":\"9879\"},\"itemType\":\"pc\",\"intendType\":\"pc\",\"eid\":\"1234\",\"imei2\":\"1234\",\"techType\":\"MANAGEACCOUNT\",\"imei\":\"1234\",\"iccid\":\"1234\",\"billingId\":\"1234\",\"devid\":\"123\",\"iccid\":\"1234\"}}";
		String sampleRequestString = "{\"client\": \"CXP\",\"cartId\": \"09cfa680-f331-4c03-b83f-e27322882457\",\"lines\":[{\"mtn\": \"1234567890\",\"firstName\": \"Jane\",\"lastName\": \"Doe\",\"email\":\"xyz@vzcorp.com\"}]}";
		DeviceSimValidationCXPRequest cxpRequest=new DeviceSimValidationCXPRequest();
		DeviceSimValidationUIRequest uiRequest=mapper.readValue(sampleResponseString, DeviceSimValidationUIRequest.class);
		util.formatDeviceSimValidationRequest(uiRequest,cxpRequest);

		uiRequest.setDevid(null);
		util.formatDeviceSimValidationRequest(uiRequest,cxpRequest);

		uiRequest.setEid(null);
		uiRequest.setImei2("random");
		uiRequest.setImei("random");
		uiRequest.setIccid("random");
		uiRequest.setBillingId("random");
		uiRequest.setTechType(CartConstants.MANAGE_ACCOUNT);
		util.formatDeviceSimValidationRequest(uiRequest,cxpRequest);

		uiRequest.setEid("random");
		uiRequest.setImei2(null);
		util.formatDeviceSimValidationRequest(uiRequest,cxpRequest);

		uiRequest.setEid("random");
		uiRequest.setImei2("random");
		uiRequest.setIccid(null);
		util.formatDeviceSimValidationRequest(uiRequest,cxpRequest);

		uiRequest.setIccid("random");
		uiRequest.setBillingId(null);
		util.formatDeviceSimValidationRequest(uiRequest,cxpRequest);

		uiRequest.setBillingId("random");
		uiRequest.setTechType("random");
		util.formatDeviceSimValidationRequest(uiRequest,cxpRequest);

		uiRequest.setTechType("random");
		uiRequest.setBillingId(null);
		uiRequest.setIccid(null);
		uiRequest.setEid(null);
		util.formatDeviceSimValidationRequest(uiRequest,cxpRequest);

		uiRequest.setEid("random");
		util.formatDeviceSimValidationRequest(uiRequest,cxpRequest);
	}

	@Test
	public void applyOfferTest(){
		Offer offer = new Offer();
		offer.setComplianceType("SPO");
		offer.setSku("1710");
		offer.setMmtier("");
		util.applyOffer(offer,"1710");

		offer.setMmtier(null);
		util.applyOffer(offer,"1710");

		offer.setMmtier("test");
		Assert.assertNotNull(util.applyOffer(offer,"1710"));
	}

	@Test
	public void buildCXPValidateOfferRequestTest1() throws JsonProcessingException{
		ApplyOfferRequest applyOfferRequest = new ApplyOfferRequest();
		applyOfferRequest.setCartInfo(new MyOfferCartInfo());
		String etrString = "{\"cartId\": \"\",\"atenaSessionId\": \"\",\"lines\": [{\"mtn\": \"5079937563\",\"offers\": [{\"complianceType\": \"ACC\",\"sku\": \"200350,1234,2346\",\"description\": \"UAT_73 SL: Get 50% off of Any Phone Case\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_73\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"},{\"complianceType\": \"EQP\",\"sku\": \"202617\",\"description\": \"Get $300 Recurring BIC on Smartphone Upgrade (Multi Line)\",\"compatibleIndicator\": \"N\",\"reasonCode\": \"EA\",\"barcodeId\": \"\",\"requiresInd\": \"\",\"propId\": \"UAT_85\",\"tradeInOffer\": \"\",\"aal\": \"\",\"mmtier\": \"\",\"offerCompliance\": \"Y\"}]}]}";
		MyOfferETRRedisData etrData = mapper.readValue(etrString,MyOfferETRRedisData.class);
		ValidateOffersRequest response = util.buildCXPValidateOfferRequest(applyOfferRequest, etrData);
		Assert.assertNull(response.getData().getCartId());
	}

}