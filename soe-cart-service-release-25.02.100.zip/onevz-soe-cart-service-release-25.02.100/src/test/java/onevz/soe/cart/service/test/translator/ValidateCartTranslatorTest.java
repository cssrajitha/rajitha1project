package onevz.soe.cart.service.test.translator;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.cxp.feature.ConfigurationProfile;
import onevz.cxp.feature.Flag;
import onevz.cxp.feature.util.FeatureFlag;
import onevz.soe.cart.constants.FeatureFlagConstants;
import onevz.soe.cart.controller.CartReadOperationsController;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.retrieveCart.CXPLineDetailsVO;
import onevz.soe.cart.model.retrieveCart.CXPLineInfo;
import onevz.soe.cart.model.validateCart.CartValidationError;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.translator.ValidateCartTranslator;
import onevz.soe.cart.ui.responses.ValidateCartUIResponse;
import onevz.soe.orderprocess.model.checkoutdetails.PendingItems;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.ResourceUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import reactor.util.function.*;

import java.io.File;

import java.io.IOException;
import java.nio.file.Files;
import java.util.*;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest
//@NotThreadSafe
public class ValidateCartTranslatorTest {

    @Autowired
    private final ObjectMapper mapper= new ObjectMapper();

    @Mock
    FeatureFlag featureFlagHelper;

    @Autowired
    CartReadOperationsController cartReadOperationsController;



    @Test
    public void translateValidateCartUIResponseTest() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);
        List<CartValidationError> cartValidationErrors=cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().getCartValidationErrors();
        CartValidationError cartValidationError=new CartValidationError();
        cartValidationError.setErrorLevel("Blocker");
        cartValidationError.setErrorCode("1023");
        cartValidationError.setFieldPath("newLine1,newLine2");
        cartValidationErrors.add(cartValidationError);
        CartValidationError cartValidationError1=new CartValidationError();
        cartValidationError1.setErrorLevel("Blocker");
        cartValidationError1.setErrorCode("1026");
        cartValidationError1.setFieldPath("newLine1,newLine2");
        cartValidationErrors.add(cartValidationError1);
        cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().setCartValidationErrors(cartValidationErrors);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);
    }

    @Test
    public void translateValidateCartUICartErrorResponseTest() throws IOException {
        ValidateCartUIResponse cxpValidateCartUIResponse = new ValidateCartUIResponse();
        List<CartError> errors =new ArrayList<>();
        CartError cartError=new CartError();
        errors.add(cartError);
        cxpValidateCartUIResponse.setErrors(errors);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);
    }
    @Test
    public void translateValidateCartUIResponseTest1() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_1.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);
    }
    @Test
    public void translateValidateCartUIResponseTest2() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_2.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);
    }

    @Test
    public void translateValidateCartUIResponseTestNoOffers() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_Nooffers.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);
    }
    @Test
    public void translateValidateCartUIResponseTest_NSE() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_2.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);
        CXPLineDetailsVO lineDetails=cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails();
        lineDetails.setNumofLinesEUP(1);
        lineDetails.setNumofLinesAAL(1);
        cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().setLineDetails(lineDetails);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);
    }

    @Test
    public void translateValidateCartUIResponseTest_NSE_5G() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_NSE_5G.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);
    }
    @Test
    public void translateValidateCartUIResponseTest_NSE_5G_Home_Device_Protection() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_NSE_5G_Home_Device_Protection.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);
    }
    @Test
    public void translateValidateCartUIResponseTest_NSE_5G_Home_Device_Adviser_Protection() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_NSE_5G_Home_Device_Protection.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);
    }
    @Test
    public void translateValidateCartUIResponseTest_EUP() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_EUP.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);
        CXPLineDetailsVO lineDetails=cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails();
        lineDetails.setNumofLinesEUP(1);
        lineDetails.setNumofLinesAAL(1);
        cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().setLineDetails(lineDetails);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);
    }

    @Test
    public void translateValidateCartUIResponseTest_NSEBYOD() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_NSEBYOD.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);
        CXPLineDetailsVO lineDetails=cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails();
        lineDetails.setNumofLinesEUP(1);
        lineDetails.setNumofLinesAAL(1);
        cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().setLineDetails(lineDetails);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);
    }
    @Test
    public void translateValidateCartUIResponseTest_NSEBYOD_NEXT() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_NSEBYOD_NEXT.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);
        CXPLineDetailsVO lineDetails=cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails();
        lineDetails.setNumofLinesEUP(1);
        lineDetails.setNumofLinesAAL(1);
        cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().setLineDetails(lineDetails);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);
    }
    @Test
    public void translateValidateCartUIResponseTest_BYOD() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_BYOD.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);
    }
    @Test
    public void translateValidateCartUIResponseTest_byodEUPLines() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_byodEUPLines.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);
    }
    @Test
    public void translateValidateCartUIResponseTest_FEA() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_FEA.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);
    }
    @Test
    public void translateValidateCartUIResponseTest_NSEACCLines() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_NSEACCLines.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);
    }
    @Test
    public void translateValidateCartUIResponseTest_ACC() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_ACC.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);
    }
    @Test
    public void translateValidateCartUIResponseTest_AAL() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_AAL.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);
    }
    @Test
    public void translateValidateCartUIResponseTest_Address() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_Address.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);
    }

    @Test
    public void translateValidateCartUIResponseTest_Bundle() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_bundles.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);
    }

    @Test
    public void translateValidateCartUIResponseTest_ECPD() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_ECPD.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);

    }

    @Test
    public void translateValidateCartUIResponse_SetPendingACtionTest() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_PendingAction.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);
        CXPLineInfo[] lineinfo = cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo();
        lineinfo[1].setPreOrBackOrder(true);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);
    }
    @Test
    public void translateValidateCartUIResponseTest_NSEACCLinesTest() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_NSEACCLines.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);
        cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()[0].getServiceInfo().getSelectedFeaturesList()
                .getVisFeature().forEach(item->{
                    if(item.getVisFeatureCode().equalsIgnoreCase("1533")){
                        item.setAddDeleteInd("Z");
                    }
                });
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);

        cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()[0].getServiceInfo().getSelectedFeaturesList()
                .getVisFeature().forEach(item->{
                    if(item.getVisFeatureCode().equalsIgnoreCase("1533")){
                        item.setAddDeleteInd("C");
                    }
                });
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse1 = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse1);
    }

    @Test
    public void translateValidateCartUIResponseTest_NSEACCLines1Test() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_NSEACCLines.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);

        cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()[0].getServiceInfo().getSelectedFeaturesList()
                .getVisFeature().forEach(item->{
                    if(item.getVisFeatureCode().equalsIgnoreCase("1533")){
                        item.setProtection(false);
                    }
                });
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse1 = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse1);

        cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()[0].getServiceInfo().getSelectedFeaturesList()
                .getVisFeature().forEach(item->{
                    if(item.getVisFeatureCode().equalsIgnoreCase("1533")){
                        item.setLevel("T");
                    }
                });
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse2 = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse2);

        cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()[0].getServiceInfo().getSelectedFeaturesList()
                .getVisFeature().forEach(item->{
                    if(item.getVisFeatureCode().equalsIgnoreCase("1533")){
                        item.setSource("Test");
                    }
                });
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);
    }

    @Test
    public void translateValidateCartUIResponseTest_NSEACCLines2Test() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_NSEACCLines.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);

        cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()[0].getServiceInfo().getSelectedFeaturesList()
                .getVisFeature().forEach(item->{
                    if(item.getVisFeatureCode().equalsIgnoreCase("1533")){
                        item.setCallFilter(true);
                    }
                });
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse1 = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse1);

        cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()[0].getServiceInfo().getSelectedFeaturesList()
                .getVisFeature().forEach(item->{
                    if(item.getVisFeatureCode().equalsIgnoreCase("1533")){
                        item.setCustomerSelected("Z");
                    }
                });
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);
    }

    @Test
    public void translateValidateCartUIResponseTest_NSEACCLines3Test() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_NSEACCLines.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);
        cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()[0].getItemsInfo()[0]
                .getShipping().setAddress(null);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);
    }

    @Test
    public void translateValidateCartUIResponseTest_setLines_NSEACCLines() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_NSEACCLines.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);
        cxpValidateCartUIResponse.getData().setValidateCartAndUpdate(null);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNull(validateCartUIResponse.getData());
    }

    @Test
    public void translateValidateCartUIResponse_GetValidateTest_NSEACCLines() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_NSEACCLines.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);
        cxpValidateCartUIResponse.setData(null);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNull(validateCartUIResponse.getData());
    }
    @Test
    public void translateValidateCartUIResponse_GetShipping_TesT() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);
        List<CartValidationError> cartValidationErrors=cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().getCartValidationErrors();
        CartValidationError cartValidationError=new CartValidationError();
        cartValidationError.setErrorLevel("Blocker");
        cartValidationError.setErrorCode("1023");
        cartValidationError.setFieldPath("newLine1,newLine2");
        cartValidationErrors.add(cartValidationError);
        CartValidationError cartValidationError1=new CartValidationError();
        cartValidationError1.setErrorLevel("Blocker");
        cartValidationError1.setErrorCode("1026");
        cartValidationError1.setFieldPath("newLine1,newLine2");
        cartValidationErrors.add(cartValidationError1);
        cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().setCartValidationErrors(cartValidationErrors);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);
    }

    @Test
    public void translateValidateCartUIResponseTest_NSEACCLines4Test() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_NSEACCLines.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);

        cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()[0].getItemsInfo()[0].setCartItems(null);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse1 = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse1);
    }
    @Test
    public void translateValidateCartUIResponseTest_NSEACCLines5Test() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_NSEACCLines.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);

        cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()[0].getServiceInfo().getSelectedFeaturesList()
                .getVisFeature().forEach(item -> {
                    if (item.getVisFeatureCode().equalsIgnoreCase("78732")) {
                        item.setType("SPO");
                        item.setVisFeatureCode("1614");
                    }
                    if (item.getVisFeatureCode().equalsIgnoreCase("80148")) {
                        item.setType("SPO");
                        item.setVisFeatureCode("1965");
                    }
                });
        CXPLineInfo cxpLineInfo = cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()[0];
        cxpLineInfo.setReasonCode("Test");
        cxpLineInfo.setIsDevicePlanCompatible(true);
        cxpLineInfo.setIsCarLine(true);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse1 = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse1);
    }

    @Test
    public void translateValidateCartUIResponse_SetPendingACtion1Test() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_PendingAction.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);

        cxpValidateCartUIResponse.getData().setPendingsteps(null);
        CXPLineInfo[] lineinfo = cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo();
        lineinfo[1].setPreOrBackOrder(true);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse1 = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse1);

        cxpValidateCartUIResponse.setData(null);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);
    }

    @Test
    public void translateValidateCartUIResponse_SetPendingACtion2Test() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_PendingAction.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);
        List<PendingItems> sortedSteps = cxpValidateCartUIResponse.getData().getPendingsteps().get("sortedSteps");
        PendingItems item = new PendingItems();
        item.setId("902");
        item.setErrorLevel("normal");
        item.setStep("PlanSelection");
        sortedSteps.add(item);

        cxpValidateCartUIResponse.getData().setCxpPendingsteps(Map.of("test",sortedSteps));
        CXPLineInfo[] lineinfo = cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo();
        lineinfo[1].setPreOrBackOrder(true);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);

        cxpValidateCartUIResponse.getData().getPendingsteps().get("sortedSteps").get(0).setStep("Test");
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse2 = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse2);
    }

    @Test
    public void translateValidateCartUIResponseTest_NSEACCLines6Test() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_NSEACCLines.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);

        CXPLineDetailsVO lineDetails = cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails();
        lineDetails.setNumOfAccessoryAndDeviceItemsInCart(null);
        lineDetails.setLineSeq(null);
        lineDetails.setFivegOrderind(null);
        lineDetails.setAceOrderCreated(false);
        lineDetails.setStandaloneAccessory(false);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse1 = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse1);

        cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().setLineDetails(null);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);
    }

    @Test
    public void translateValidateCartUIResponseTest_NSEACCLines7Test() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_NSEACCLines.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);
        CXPLineDetailsVO lineDetails = cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails();
        lineDetails.getLineInfo()[0].getServiceInfo().getSelectedFeaturesList().setVisFeature(null);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);

        lineDetails.setLineInfo(new CXPLineInfo[]{});
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse1 = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse1);
    }
    @Test
    public void mergeFeatureFlagsWithResponseValidateCartTest() throws SOEHTTPException, IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);
        List<CartValidationError> cartValidationErrors=cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().getCartValidationErrors();
        CartValidationError cartValidationError=new CartValidationError();
        cartValidationError.setErrorLevel("Blocker");
        cartValidationError.setErrorCode("1023");
        cartValidationError.setFieldPath("newLine1,newLine2");
        cartValidationErrors.add(cartValidationError);
        CartValidationError cartValidationError1=new CartValidationError();
        cartValidationError1.setErrorLevel("Blocker");
        cartValidationError1.setErrorCode("1026");
        cartValidationError1.setFieldPath("newLine1,newLine2");
        cartValidationErrors.add(cartValidationError1);
        cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().setCartValidationErrors(cartValidationErrors);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        List<String> fetchFlagList= List.of("saveTheSaleFFlag");
        List<Flag> flagList = new ArrayList<>();
        Flag flag = new Flag();
        flag.setName("test");
        Flag flag2 = new Flag();
        flag2.setName("test2");
        flagList.add(flag2);
        flagList.add(flag);
        configurationProfile.setFlags(flagList);
        Flag flag3 = new Flag();
        flag3.setName("saveTheSaleFFlag");
        Map<String,Flag> digitalPromoFlag = new HashMap<>();
        digitalPromoFlag.put("saveTheSaleFFlag",flag3);
        when(featureFlagHelper.getConfigurationProfile(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.DIGITAL_PERFORMANCE_CFG_PROFILE)).thenReturn(Mono.just(configurationProfile));
        when(featureFlagHelper.getConfigurationProfile(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.DIGITAL_MINI_CART_CFG_PROFILE)).thenReturn(Mono.just(configurationProfile));
        when(featureFlagHelper.getFeatureFlagList(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.DIGITAL_PROMOS_CFG_PROFILE,fetchFlagList)).thenReturn(Mono.just(digitalPromoFlag));
        when(featureFlagHelper.getConfigurationProfile(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.DIGITAL_PERFORMANCE_CFG_PROFILE)).thenReturn(Mockito.any());
        Flag flag7 = new Flag();
        flag7.setName("enableSaveCartForBYODFFlag");
        Map<String,Flag> addBYODFeatureFlag = new HashMap<>();
        addBYODFeatureFlag.put("enableSaveCartForBYODFFlag",flag7);
        Mono<Tuple2<Tuple8<onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse, ConfigurationProfile, ConfigurationProfile, Boolean, Boolean, Map<String,Flag>, Boolean,Map<String,Flag>>, Boolean>> zip  = Mono.zip(Mono.just(validateCartUIResponse), Mono.just(configurationProfile),Mono.just(configurationProfile),Mono.just(Boolean.FALSE),Mono.just(Boolean.FALSE),Mono.just(digitalPromoFlag),Mono.just(Boolean.FALSE),Mono.just(addBYODFeatureFlag)).zipWith(Mono.just(Boolean.FALSE));
        when(featureFlagHelper.isFeatureEnabled(FeatureFlagConstants.HOLIDAY_RETURN_POLICY_NSE_FLAG)).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartReadOperationsController.mergeFeatureFlagWithResponse(zip, true);
        StepVerifier.create(controllerResponse).assertNext(junit.framework.Assert::assertNotNull).expectComplete().verify();

    }
    @Test
    public void translateValidateCartUIResponseAutopayTest() throws IOException {
        File cxpResFile = ResourceUtils.getFile("src/test/resources/v2-validate-cart_1.json");
        String cxpResString = new String(Files.readAllBytes(cxpResFile.toPath()));
        ValidateCartUIResponse cxpValidateCartUIResponse = mapper.readValue(cxpResString, ValidateCartUIResponse.class);
        cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()[0].getServiceInfo().getPlanDiscount().setEligibleAutoPayPaperlessDiscount(null);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse);

        cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()[0].getServiceInfo().getPlanDiscount().setEligibleAutoPayPaperlessDiscount("1.0");
        cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()[0].getServiceInfo().getPlanDiscount().setTotalPlanCostIncludingLineAccessFee(null);
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse1 = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse1);

        cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()[0].setTotalPriceOfPerksAndProtection("");
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse2 = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse2);

        cxpValidateCartUIResponse.getData().getValidateCartAndUpdate().getLineDetails().getLineInfo()[0].setTotalPriceOfPerksAndProtection("10");
        onevz.soe.cart.ui.responses.v2.ValidateCartUIResponse validateCartUIResponse3 = ValidateCartTranslator.translateValidateCartUIResponse(cxpValidateCartUIResponse);
        Assert.assertNotNull(validateCartUIResponse3);
    }

}