package onevz.soe.cart.service.test.cases;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.helper.RemoveLockHelper;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.RemoveHomePhonePegaResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.RemoveHomePhoneUIRequest;
import onevz.soe.cart.ui.requests.RemoveLockRequest;
import onevz.soe.cart.ui.responses.RemoveLockUIResponse;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = {CartServiceTestConfig.class})
@WebFluxTest(RemoveLockHelper.class)
public class RemoveLockUpdateHelperTest {

    @Autowired
    RemoveLockHelper removeLockHelper;

    @MockBean
    RedisHelper redisHelper;

    @MockBean
    CartServiceBpmHelper removeLockBpmHelper;

    @Autowired
    ObjectMapper mapper;

    //NSA
    //updateRemoveLock
    @Test
    public void updateRemoveLockHelperTest() throws JsonProcessingException {
        String requestString = "{\n \"cartInfo\": {\n \"clientAppName\": \"VZW-DOTCOM\",\n \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\n \"cartId\": \"\",\n \"caseId\": \"\",\n  \"accountNumber\": \"0213143123-00001\", \n \"cartCreator\": \"8136958775\",\n\"processingMTN\": \"8136958775\",\n \"homePhoneMTN\":\"xxxxxx\",\n  \"processStep\": \"ShoppingCart\",\n  \"processAction\": \"removeDevice\",\n \"intendType\": \"MOVER\",\n \"action\" : \"REMOVE\"\n \n  }\n}";
        String responseString = "{\n \"serviceHeader\" : {\n   \"clientId\" : \"OMNI-RETAIL\",\n   \"statusMsg\" : \"SUCCESS\",\n \"correlationId\" : \"soe-cart-2021.08.06.17.50.24-125.72236596853669\",\n  \"sessionId\" : \"\",\n   \"serviceName\" : \"SalesOrderPurchase\",\n  \"userId\" : \"\",\n\"statusCode\" : \"00\"\n },\n \"serviceBody\" : {\n\"serviceResponse\" : {\n \"context\" : {\n    \"cartInfo\" : {\n   \"statusMsg\" : \"Success\",\n\"cartId\" : \"aa3a61e9-5410-4243-9efe-598c3ec2ac08\",\n \"statusCode\" : \"1\"\n },\n      \"contextInfo\" : {\n     \"availablePaths\" : [{\n   \"path\" : \"ShoppingCart\"\n }, {\n    \"path\" : \"addDevice\"\n }\n   ],\n \"processStep\" : \"ShoppingCart\",\n  \"callReason\" : \"SalesOrderPurchase\"\n },\n\"caseId\" : \"SOP-3647723-E01\",\n    \"customerInfo\" : {\n    \"cartCreator\" : \"4102411705\",\n\"processingMTN\" : \"4014436878\",\n   \"accountNumber\" : \"0001445545-00001\"\n },\n   \"processMTNList\" : [{\n   \"mtn\" : \"2404951496\",\n  \"completedprocessSteps\" : [\"ShoppingCart\",\"addDevice\"]\n}\n    ]\n}\n}\n}\n}\n";
        RemoveLockRequest sampleRequest = mapper.readValue(requestString, RemoveLockRequest.class);
        RemoveLockUIResponse sampleResponse = mapper.readValue(responseString, RemoveLockUIResponse.class);
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(removeLockBpmHelper.removeLock(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        Mono<RemoveLockUIResponse> response = removeLockHelper.updateRemoveLock(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> org.junit.Assert.assertEquals(sampleResponse, resp)).expectComplete().verify();
    }
}
