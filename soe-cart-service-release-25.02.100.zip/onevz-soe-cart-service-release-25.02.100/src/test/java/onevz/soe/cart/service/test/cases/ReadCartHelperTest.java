package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper3;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper2;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.model.bundleAccessories.BundleAccessoryDetail;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.common.Device;
import onevz.soe.cart.model.common.DeviceImeiSimDetails;
import onevz.soe.cart.model.deviceIdValidation.*;
import onevz.soe.cart.model.deviceSimValidation.CustomerReqType;
import onevz.soe.cart.model.getCase.GetCaseResponse;
import onevz.soe.cart.model.retrieveActivationStatus.OrderActivationStatusCXPInfo;
import onevz.soe.cart.model.retrieveActivationStatus.RetrieveActivationStatusCXPData;
import onevz.soe.cart.requests.*;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.common.CartInfo;
import onevz.soe.cart.ui.common.GetDepletionTypeData;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.session.client.model.AccountInfoEligible;
import onevz.soe.spring.web.filter.RequestAccessContext;
import onevz.soe.spring.web.filter.RequestAccessContext.RequestAccess;
import onevz.soe.utilities.serialization.JacksonMapperFactory;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.assertj.core.api.Assertions;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpMethod;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpResponse;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.verify;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { CartServiceTestConfig.class })
public class ReadCartHelperTest {

	@Autowired
	SourceFileReaderUtil sourceFileReaderUtil;

	@Mock
	FeatureFlagHelper featureFlagHelper;

	@Value("${onevz.soe.cart.test.fileLocation}")
	private String testFileLocation;

	@InjectMocks
	private ReadCartHelper helper;

	@Mock
	private CartServiceCxpHelper cxpHelper;

	@Mock
	CartRequestBuilder cartRequestBuilder;

	@Mock
	RedisHelper3 redisHelper3;
	
	@Mock
	private CartServiceCxpHelper2 cxpHelper2;
	
	@Mock
	private CartServiceCXPServices cxpService;
	
	@Mock
	private CartServiceBpmHelper3 bpmHelper3;
	
	@Mock
	private CartServiceBpmHelper bpmHelper4;

	@Mock
	private RedisHelper redisHelper;

	@Mock
	private RedisHelper2 redisHelper2;

	@Autowired
	private ObjectMapper mapper;
	
	@Mock
	CartIgHelper cartIgHelper;

	@Test
	public void eSimDetailsTest() throws IOException {
		ReflectionTestUtils.setField(helper, "enableEsimMigrationChanges", true);
		ESimDetailsETNIRequest sampleUIRequest = new ESimDetailsETNIRequest();
		ESimDetailsUIResponse sampleResponse = new ESimDetailsUIResponse();
		when(cxpHelper.eSimDetails(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		sampleUIRequest.setBillerId("VISION_EAST");
		sampleUIRequest.setProcessInd(CartConstants.PROCESS_INDICATOR_M);
		Mono<ESimDetailsUIResponse> response = helper.eSimDetails(sampleUIRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		sampleUIRequest.setBillerId("VISION_WEST");
		sampleUIRequest.setProcessInd(CartConstants.PROCESS_INDICATOR_M);
		response = helper.eSimDetails(sampleUIRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		sampleUIRequest.setBillerId("VISION_NORTH");
		sampleUIRequest.setProcessInd(CartConstants.PROCESS_INDICATOR_M);
		response = helper.eSimDetails(sampleUIRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		sampleUIRequest.setBillerId("VISION_B_2_B");
		sampleUIRequest.setProcessInd(CartConstants.PROCESS_INDICATOR_M);
		response = helper.eSimDetails(sampleUIRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		sampleUIRequest.setBillerId("VISION_B2B");
		sampleUIRequest.setProcessInd(CartConstants.PROCESS_INDICATOR_M);
		response = helper.eSimDetails(sampleUIRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		sampleUIRequest.setBillerId("VISION_B_2_B");
		sampleUIRequest.setProcessInd(CartConstants.PROCESS_INDICATOR_M);
		response = helper.eSimDetails(sampleUIRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		sampleUIRequest.setBillerId("VN");
		sampleUIRequest.setProcessInd(CartConstants.PROCESS_INDICATOR_M);
		response = helper.eSimDetails(sampleUIRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		sampleUIRequest.setBillerId("VW");
		sampleUIRequest.setProcessInd(CartConstants.PROCESS_INDICATOR_M);
		response = helper.eSimDetails(sampleUIRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		sampleUIRequest.setBillerId("VE");
		sampleUIRequest.setProcessInd(CartConstants.PROCESS_INDICATOR_M);
		response = helper.eSimDetails(sampleUIRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		
		sampleUIRequest.setBillerId("VN");
		sampleUIRequest.setProcessInd("");
		response = helper.eSimDetails(sampleUIRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		
		sampleUIRequest.setBillerId("VN");
		sampleUIRequest.setProcessInd("");
		response = helper.eSimDetails(sampleUIRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		
		sampleUIRequest.setBillerId("VN");
		sampleUIRequest.setProcessInd("N");
		response = helper.eSimDetails(sampleUIRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		
		sampleUIRequest.setBillerId("VN");
		sampleUIRequest.setProcessInd(null);
		response = helper.eSimDetails(sampleUIRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

	}
	@Test
	public void eSimDetailsTest1() throws IOException, IllegalAccessException, NoSuchFieldException {
		ReflectionTestUtils.setField(helper, "enableEsimMigrationChanges", true);
		ESimDetailsETNIRequest sampleUIRequest = new ESimDetailsETNIRequest();
		ESimDetailsUIResponse sampleResponse = new ESimDetailsUIResponse();
		when(cxpHelper.eSimDetails(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		Field enableEsimMigrationChanges = ReadCartHelperParent.class.getDeclaredField("enableEsimMigrationChanges");
		enableEsimMigrationChanges.setAccessible(true);
		enableEsimMigrationChanges.set(helper,true);

		sampleUIRequest.setBillerId("VISION_EAST");
		sampleUIRequest.setProcessInd(CartConstants.PROCESS_INDICATOR_M);
		Mono<ESimDetailsUIResponse> response = helper.eSimDetails(sampleUIRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		sampleUIRequest.setBillerId("VISION_WEST");
		sampleUIRequest.setProcessInd(CartConstants.PROCESS_INDICATOR_M);
		response = helper.eSimDetails(sampleUIRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		sampleUIRequest.setBillerId("VISION_NORTH");
		sampleUIRequest.setProcessInd(CartConstants.PROCESS_INDICATOR_M);
		response = helper.eSimDetails(sampleUIRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		sampleUIRequest.setBillerId("VISION_B_2_B");
		sampleUIRequest.setProcessInd(CartConstants.PROCESS_INDICATOR_M);
		response = helper.eSimDetails(sampleUIRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		sampleUIRequest.setBillerId("VISION_B2B");
		sampleUIRequest.setProcessInd(CartConstants.PROCESS_INDICATOR_M);
		response = helper.eSimDetails(sampleUIRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		sampleUIRequest.setBillerId("VISION_B_2_B");
		sampleUIRequest.setProcessInd(CartConstants.PROCESS_INDICATOR_M);
		response = helper.eSimDetails(sampleUIRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	
	@Test
	public void eSimDetailsTestForNegativescenario() throws IOException {
		ReflectionTestUtils.setField(helper, "enableEsimMigrationChanges", false);
		ESimDetailsETNIRequest sampleUIRequest = new ESimDetailsETNIRequest();
		ESimDetailsUIResponse sampleResponse = new ESimDetailsUIResponse();
		when(cxpHelper.eSimDetails(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		sampleUIRequest.setBillerId("VISION_EAST");
		sampleUIRequest.setProcessInd(null);
		Mono<ESimDetailsUIResponse> response = helper.eSimDetails(sampleUIRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		
	}
	
	@Test
	public void validateDeviceSimIdHelperTest() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT\",\"cartInfo\": {\"cartCreator\": \"7039159592\",\"clientAppName\": \"VZW-MFA\",\"cartId\": \"4b207c97-6278-4562-9e41-b6411763bcd6\",\"caseId\": \"SOP-947715-E01\",\"processingMTN\": \"\",\"accountNumber\": \"0201430224-00001\",\"intent\": \"BYOD\",\"processStep\": \"BYODLandingPage\",\"processAction\": \"validatedevicesim\"},\"data\": {\"lines\": [{\"mtn\": \"\",\"device\": {\"id\": \"353338070105553\",\"Flowtype\": \"DEVICE\",\"CurrentId\": \"\",\"isCustomerProvidedEquipment\": true,\"sku\": \"\",\"smartIMEI\": true,\"searchAttributes\": {\"postpaidRestrictStartDate\": \"2018-07-01T04:00:00.000Z\",\"prodCode\": \"LTE\",\"hdVoiceInd\": true,\"deviceType\": \"4GE\",\"dacc\": \"00854\"},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": \"\"}}}]}}";
		String sampleResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \"SPA-1589374-DEV3\"}}}}";
		DeviceIdValidationUIRequest sampleRequest = new DeviceIdValidationUIRequest();
		DeviceIdValidationUIResponse sampleResponse = new DeviceIdValidationUIResponse();
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"creditAppNum\": \"8436667390\", \"customerType\": \"U\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationUIResponse.class);
		when(cxpHelper.getSmartImeiDevices(Mockito.anyString(),Mockito.anyString())).thenReturn(Mono.just(getSmartImeiDevicesResponse()));
		Mono<DeviceIdValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.deviceIdValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		DeviceIdValidationUIResponse expectedResponse = sampleResponse;
		Mono<DeviceIdValidationUIResponse> response = helper.deviceIdValidation(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
		sampleRequest.getData().getLines().get(0).setDevice(new Device());
		sampleRequest.getData().getLines().get(0).getDevice().setSorDisplayName("Iphone 12");
		sampleRequest.getData().getLines().get(0).getDevice().setSkuCarrier("VERIZON");
		response = helper.deviceIdValidation(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		sampleRequest.getData().getLines().get(0).getDevice().setSorDisplayName("Iphone 12");
		sampleRequest.getData().getLines().get(0).getDevice().setSkuCarrier("");
		response = helper.deviceIdValidation(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
		sampleRequest.getData().getLines().get(0).getDevice().setSorDisplayName("");
		sampleRequest.getData().getLines().get(0).getDevice().setSkuCarrier("ATT");
		response = helper.deviceIdValidation(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	public SmartImeiDevicesResponse getSmartImeiDevicesResponse() {
		SmartImeiDevicesResponse resp=new SmartImeiDevicesResponse();
		resp.setData(new SmartImeiDeviceData());
		SmartImeiDeviceDetails deviceDetails=new SmartImeiDeviceDetails();
		deviceDetails.setDeviceDisplayName("Iphone 12");
		deviceDetails.setDacc("01120");
		deviceDetails.setSorDeviceType("Iphone 12");
		deviceDetails.setDescription("Test device");
		deviceDetails.setProductId("Test");
		deviceDetails.setSkuId("MGFK3LL/A");
		resp.getData().setSmartImeiDeviceDetails(List.of(deviceDetails));
		return resp;

	}
	@Test
	public void validateDeviceSimIdHelperForNSEBYODIntentTest() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT\",\"cartInfo\": {\"cartCreator\": \"7039159592\",\"clientAppName\": \"VZW-MFA\",\"cartId\": \"4b207c97-6278-4562-9e41-b6411763bcd6\",\"caseId\": \"SOP-947715-E01\",\"processingMTN\": \"\",\"accountNumber\": \"0201430224-00001\",\"intent\": \"NSEBYOD\",\"processStep\": \"BYODLandingPage\",\"processAction\": \"validatedevicesim\"},\"data\": {\"lines\": [{\"mtn\": \"\",\"device\": {\"id\": \"353338070105553\",\"Flowtype\": \"DEVICE\",\"CurrentId\": \"\",\"isCustomerProvidedEquipment\": true,\"sku\": \"\",\"smartIMEI\": true,\"searchAttributes\": {\"postpaidRestrictStartDate\": \"2018-07-01T04:00:00.000Z\",\"prodCode\": \"LTE\",\"hdVoiceInd\": true,\"deviceType\": \"4GE\",\"dacc\": \"00854\"},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": \"\"}}}]}}";
		String sampleResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \"SPA-1589374-DEV3\"}}}}";
		DeviceIdValidationUIRequest sampleRequest = new DeviceIdValidationUIRequest();
		DeviceIdValidationUIResponse sampleResponse = new DeviceIdValidationUIResponse();
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"creditAppNum\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationUIResponse.class);
		when(cxpHelper.getSmartImeiDevices(Mockito.anyString(),Mockito.anyString())).thenReturn(Mono.just(getSmartImeiDevicesResponse()));
		Mono<DeviceIdValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.deviceIdValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		DeviceIdValidationUIResponse expectedResponse = sampleResponse;
		Mono<DeviceIdValidationUIResponse> response = helper.deviceIdValidation(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}
	
	@Test
	public void validateDeviceESimIdHelperTest() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\":\"OMNI-RETAIL\",\"cartInfo\": {\"cartCreator\": \"7039159592\",\"clientAppName\": \"OMNI-RETAIL\",\"cartId\": \"4b207c97-6278-4562-9e41-b6411763bcd6\",\"caseId\": \"SOP-947715-E01\",\"processingMTN\": \"\",\"accountNumber\": \"0201430224-00001\",\"intent\": \"AAL\",\"intendType\":\"AAL\",\"processStep\": \"BYODLandingPage\",\"processAction\": \"validatedevicesim\"},\"data\": {\"lines\": [{\"mtn\": \"\",\"device\": {\"id\": \"353338070105553\",\"Flowtype\": \"DEVICE\",\"CurrentId\": \"\",\"isCustomerProvidedEquipment\": true,\"sku\": \"\",\"smartIMEI\": true,\"searchAttributes\": {\"postpaidRestrictStartDate\": \"2018-07-01T04:00:00.000Z\",\"prodCode\": \"LTE\",\"hdVoiceInd\": true,\"deviceType\": \"4GE\",\"dacc\": \"00854\"},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": \"\"}}}]}}";
		String sampleResponseString = "{\"serviceHeader\": {\"clientId\": \"OMNI-RETAIL\",\"statusMsg\": \"SUCCESS\",\"correlationId\": \"soe-cart-2022.07.07.10.43.43-748.309558981539\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"cartInfo\": {\"cartId\": \"55f58a35-4b9e-4363-9f75-ae12b2361af8\"},\"contextInfo\": {\"availablePaths\": [{\"path\": \"GridWallPDP\"}],\"processAction\": \"\",\"processStep\": \"GridWallPDP\",\"callReason\": \"SalesOrderPurchase\"},\"caseId\": \"SOP-8019223-E01\",\"customerInfo\": {\"cartCreator\": \"5038034329\",\"processingMTN\": \"\",\"accountNumber\": \"0271187354-00001\"},\"deviceInfo\": {\"lostAndStolen\": {\"lostStolen\": \"N\",\"nonPay\": \"N\"},\"appleCarrieLock\": false,\"color\": {\"colorId\": \"clr40003\",\"displayName\": \"Black\",\"description\": \"Black\",\"colorCssStyle\": \"#000000\"},\"deviceSimM2MPair\": \"N\",\"deviceId\": \"353409200130033\",\"isRestrictedDevice\": \"N\",\"skipSimIdFlag\": false,\"imei2\": \"358071150130036\",\"imei1\": \"353409200130033\",\"price\": {\"fullRetailPrice\": {\"originalPrice\": 1000.0,\"discountedPrice\": 0.0,\"contractDuration\": 0.0,\"contractText\": \"Full Retail Price\"},\"devicePaymentPrice\": [],\"oneYearPrice\": {\"originalPrice\": 1000.0,\"discountedPrice\": 0.0,\"contractDuration\": 0.0,\"contractText\": \"One Year Price\"}},\"osType\": \"Android\",\"simInfo\": {\"eID\": \"\",\"mobileNumber\": \"\",\"imsiv\": \"\",\"available\": \"false\",\"grandFathered\": false,\"imsivf\": \"\",\"dfillCompatibleSim\": \"DFILLSIM5G-SA-A\",\"launchPackageSku\": \"5GDSDSESIMTEST\",\"type\": \"\",\"pairedIccid\": \"\",\"iccIdStat\": \"\",\"iccid\": \"\",\"min\": \"\",\"euimid\": \"\",\"ispuCompatibleSIM\": \"BULKSIM5G-SA-A\",\"prodName\": \"\",\"mfgCode\": \"\",\"retired\": false,\"mtn\": \"\",\"active\": \"false\",\"esimid\": \"\",\"launchPackageSkuType\": \"5GDSDSESIMTEST\",\"preferredSoftSim\": \"DFILLSIM5G-SA-A\",\"aging\": \"false\",\"status\": \"\"},\"imageUrlMap\": {\"largeImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/kyocera-dark-knight-5g-black-01042021?$device-lg$\",\"thumbImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/kyocera-dark-knight-5g-black-01042021?$device-thumb$\",\"miniImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/kyocera-dark-knight-5g-black-01042021?$device-mini$\",\"mediumImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/kyocera-dark-knight-5g-black-01042021?$device-med$\",\"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/kyocera-dark-knight-5g-black-01042021\"},\"appleWatchFlag\": false,\"softMessages\": [],\"standalonePairingEligible\": true,\"imageName\": \"kyocera-dark-knight-5g-black-01042021\",\"deviceESimM2MPair\": \"N\",\"deviceSku\": \"5GDSDSESIMTEST\",\"makeEtniPersApi\": false,\"deviceFamilyType\": \"Phone\",\"e911AddrInd\": \"\",\"fmipLocked\": false,\"deviceESimCompatible\": \"N\",\"euiccCapable\": \"N\",\"skuDisplayName\": \"5G DSDS ESIM TEST\",\"deviceAttributes\": {\"deviceType\": \"5GE\",\"gpsIndicator\": \"Y\",\"productId\": \"dev18840012\",\"equipMode\": \"5GDevice\",\"prodType\": \"5GSmartphone\",\"prepayRestrictStartDate\": \"\",\"equipModeCode\": \"5GE\",\"deviceCategory\": \"5G Smartphone\",\"postpaidRestrictStartDate\": \"\",\"prodName\": \"5G DSDS ESIM TEST\",\"mfgCode\": \"SAM\",\"wholesaleRestrictStartDate\": \"\",\"mfgName\": \"Samsung\",\"daccCode\": \"01847\"},\"deviceSimCompatible\": \"N\",\"simClass4G\": \"NP\",\"numbershareCapability\": \"\"}}}}}";
		DeviceIdValidationUIRequest sampleRequest = new DeviceIdValidationUIRequest();
		DeviceIdValidationUIResponse sampleResponse = new DeviceIdValidationUIResponse();
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"creditAppNum\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationUIResponse.class);
		when(cxpHelper.getSmartImeiDevices(Mockito.anyString(),Mockito.anyString())).thenReturn(Mono.just(getSmartImeiDevicesResponse()));
		Mono<DeviceIdValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.deviceIdValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		DeviceIdValidationUIResponse expectedResponse = sampleResponse;
		Mono<DeviceIdValidationUIResponse> response = helper.deviceIdValidation(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}
	
	@Test
	public void validateISPUOrderHelperTest() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"}}";
		String sampleRetrieveCartResponseString = "{\"data\": {\"cart\": {\"customerProfile\": {},\"cartHeader\": {\"winBackAccountNumber\": \"\",\"referralSaleRepId\": \"\",\"ecpdToken\": \"\",\"adobeId\": \"\",\"vendorId\": \"NETACE\",\"referralVendorId\": \"\",\"d2dFlag\": \"N\",\"sourceSystem\": \"OMNI-RETAIL\",\"cartId\": \"077d51dd-0511-4e87-bc34-3de25cf18ef8\",\"status\": \"A\",\"createTimestamp\": \"2021-11-16T06:52:54.935671-05:00[US/Eastern]\",\"lastUpdateTimestamp\": \"2021-11-16T06:57:23.139929-05:00[US/Eastern]\",\"cartCreator\": \"\",\"cartCreatorChannelId\": \"OMNI-RETAIL\",\"cartCreatorOrderLocationCode\": \"0026301\",\"cartCreatorSalesRepId\": \"ENC\",\"caseId\": \"SOP-4465635-E01\",\"visionCustomerType\": \"PE\",\"maverickLocation\": false,\"preConfiguredCartType\": \"BAU\",\"preConfiguredCartTypeDuringAddDevice\": \"BAU\",\"isCoreRep\": false},\"orderDetails\": {\"totalUpgradeFee\": 0.0,\"totalDeviceDollar\": 0.0,\"totalRemainingDeviceDollar\": 0.0,\"totalUsedDeviceDollar\": 0.0,\"totalAccountLevelAccCost\": 0.0,\"totalAccountLevelAccCostWithTax\": 0.0,\"totalShippingCost\": 0.0,\"totalDiscountedShippingCost\": 0.0,\"hqUser\": false,\"returnException\": false,\"taxDetailsList\": [],\"subTotalDueTodayWithoutUpgradeFee\": 0.0,\"subTotalDueMonthlyForAALBYODEUP\": 0.0,\"shipTogetherPref\": true,\"assistanceOptedByCustomer\": false,\"locationState\": \"NJ\",\"totalVerizonDollarUsed\": \"0.0\",\"isShellAccountSelected\": false,\"fullfillmentLocation\": \"1000001\",\"guestOrInactiveRefundLines\": false,\"totalDueMonthlyOnProfile\": 0.0,\"subTotalDueMonthlyOnProfile\": 0.0,\"totalMonthlyTaxesOnProfile\": 0.0,\"subTotalOtherLinesOnProfile\": 0.0,\"estimatedNextMonthChargeOnProfile\": 0.0,\"originalSubTotalDueMonthly\": 0.0,\"totalDueMonthlyAfterDiscounts\": 0.0,\"refundNotifications\": {\"notificationEmail\": \"POS@VZW.COM\",\"emailIds\": [\"POS@VZW.COM\"],\"phoneNumbers\": []},\"totalSurchargeAmount\": \"0.0\",\"orderType\": \"PS\",\"locationCode\": \"0026301\",\"customerType\": \"N\",\"billingSystem\": \"VN\",\"totalTaxAmount\": \"0.0\",\"spocs\": {\"notificationOptions\": {\"primaryEmailId\": \"POS@VZW.COM\"}},\"totalDueToday\": 0.0,\"runningTotalDueToday\": 0.0,\"totalDueTodayFlag\": true,\"totalDueMonthly\": 0.0,\"subTotalDueMonthly\": 0.0,\"subTotalDueToday\": 0.0,\"subTotalMonthlyTaxes\": 0.0,\"estimatedNextMonthCharge\": 0.0,\"totalMonthlyTaxes\": 0.0,\"subTotalOtherLines\": 0.0,\"subTotalOtherLinesTaxes\": 0.0,\"instantDRCCredit\": false,\"isAttachmentCompleted\": false,\"nextMonthBillTotal\": 0.0,\"customerNotification\": {\"smsLanguage\": \"E\"},\"orderChannelId\": \"OMNI-RETAIL\",\"orderList\": [{\"creditApplication\": {\"creditApplicationNum\": 428037738,\"creditApprovalStatus\": \"AP\",\"creditStatusReason\": \"CA CVAS AUTOMATIC APPROVAL\",\"internationalEligibility\": false,\"securityDepositAmount\": \"0\",\"serviceClass\": \"B\",\"lineCreditClass\": \"1D\"},\"orderActivityType\": \"NSE\",\"orderNumber\": 0,\"numOfLinesForOrderActivityType\": 1,\"preOrderNumber\": 0,\"managerApprovalRequired\": false}],\"outletId\": \"000000263\",\"registerNumber\": \"13\",\"saleType\": \"P\",\"salesRepId\": \"ENC\",\"enableSplitShipment\": false,\"splitShipmentIndicator\": false,\"isSingleModConnectedDevice\": false,\"fiveGUpSellAccountLevel\": false,\"customerOnTrialPlan\": false,\"totalDownPaymentAmt\": 0.0,\"totalEdgeBuyOutAmount\": 0.0,\"expressCheckout\": false,\"nbxInfo\": {\"isPreQualifiedNBX\": true,\"syfOfferId\": \"8803458027\",\"propositionMessage\": \"Thank You! You have been Pre-Approved.Sign up and receive: $100 sign up bonus and more\",\"propositionName\": \"Pre-Qualified - Transaction Flow\",\"propositionId\": \"GC_01\",\"isVZCCHolder\": false,\"sessionId\": \"8483170179439212780\"},\"isEQPandPPLOfferApplied\": false,\"cartTotalDiscounts\": {\"totalDiscount\": \"0.0\",\"discountDetails\": []},\"memberTotalDueToday\": 0.0,\"customerConsent\": \"Y\",\"totalDwosCost\": \"0.0\",\"billingState\": \"NJ\",\"isTradeInOfferSelected\": false,\"homePhone\": \"9879879879\",\"isAssignMtnRequired\": false,\"fiosCapable\": false,\"fiosEligible\": false,\"quoteWithoutCredit\": false},\"lineDetails\": {\"lineInfo\": [{\"multiLineSeqNumber\": 1,\"lineActivityType\": \"NSE_5G\",\"totalDueToday\": 0.0,\"totalDueTodayWithoutTax\": 0.0,\"totalDueMonthly\": 80.0,\"mobileNumber\": \"8627041933\",\"showGlobalChoiceOffer\": false,\"serviceInfo\": {\"otherPromotions\": [],\"primaryUserInfo\": {\"firstName\": \"POSTESTFBV\",\"lastName\": \"USEROJP\",\"address\": {\"streetNumber\": \"30\",\"streetName\": \"INDEPENDENCE\",\"addressLine1\": \"30 INDEPENDENCE BL\",\"city\": \"WARREN\",\"state\": \"NJ\",\"zipCode\": \"07059\",\"zipCode4\": \"6747\",\"county\": \"\",\"countryCode\": \"US\",\"fipsCode\": \"3403576940\",\"emailId\": \"POS@VZW.COM\",\"phoneNumber\": \"9879879879\",\"streetType\": \"BL\"},\"contactPersonPhone\": \"9879879879\",\"emailId\": \"POS@VZW.COM\"},\"cart5GAddress\": {\"type\": \"all\",\"streetNumber\": \"30\",\"streetName\": \"INDEPENDENCE\",\"addressLine2\": \"\",\"addressLine1\": \"1 VERIZON WAY  \",\"city\": \"BASKING RIDGE\",\"state\": \"NJ\",\"zipCode\": \"07920\",\"zipCode4\": \"1025\",\"countryCode\": \"\",\"emailId\": \"POS@VZW.COM\",\"phoneNumber\": \"9879879879\",\"streetType\": \"DR\",\"floor\": 0,\"eventCorrelationId\": \"07920_1637063710309_487\"},\"cart5GAppointment\": {\"installApptSelectedDate\": {\"selfInstallDate\": \"11/21/2021\"}},\"mtn\": \"8627041933\",\"min\": \"9738773139\",\"newPricePlanId\": \"39425\",\"contractTermId\": \"48\",\"newPricePlanInfo\": {\"pricePlanCategory\": \"N\",\"ratePlanType\": \"L\",\"accessFeeRange\": \"0\",\"categoryCode\": \"74\",\"contractRange\": \"-1\",\"contractDuration\": 0,\"pricePlanCode\": \"39425\",\"pricePlanDesc\": \"5G HOME INTERNET\",\"contractTermId\": \"48\",\"imageUrlMap\": {},\"planPrice\": 80.0},\"selectedFeaturesList\": {\"featuresCount\": 0,\"visFeature\": []},\"planDetails\": {\"planPrice\": 80.0,\"planDiscounts\": []},\"currentDevice\": {},\"isSharePlanAdded\": false,\"mea\": \"AOR\",\"dacc\": \"01425\",\"isE911AddressValidated\": false,\"isFreeAppleMusicLoss\": \"N\",\"newBgsa\": \"978\",\"newPlanFlag\": \"L\",\"orderDevice\": {\"lteVoraEquipInfo\": {\"lteEqpt\": {},\"lteVoraDeviceInfo\": {\"deviceType\": \"5GF\"}}},\"kidsPlanParentMtn\": false,\"mcsSubscription\": [],\"fiveGUpSell\": false,\"e911AddressSameAsServiceAddress\": false,\"unpairedGrantor\": false},\"itemsInfo\": [{\"depletionType\": \"F\",\"attention\": \"POSTESTFBV USEROJP\",\"shipping\": {\"address\": {\"type\": \"all\",\"streetNumber\": \"30\",\"streetName\": \"INDEPENDENCE\",\"addressLine2\": \"\",\"addressLine1\": \"1 VERIZON WAY  \",\"city\": \"BASKING RIDGE\",\"state\": \"NJ\",\"zipCode\": \"07920\",\"zipCode4\": \"1025\",\"county\": \"\",\"countryCode\": \"\",\"emailId\": \"POS@VZW.COM\",\"phoneNumber\": \"9879879879\",\"streetType\": \"DR\"},\"cbrPhone\": \"9879879879\",\"firstName\": \"POSTESTFBV\",\"lastName\": \"USEROJP\",\"isUseUnVerifiedAddress\": false,\"isValidAddress\": false,\"email\": \"POS@VZW.COM\"},\"fipsCode\": \"3403576940\",\"itemCount\": 1,\"itemTabSeqNum\": 0,\"cartItems\": {\"cartItem\": [{\"discountAmount\": 0.0,\"deviceDollarApplied\": 0.0,\"qrScanNeededForEsimActivation\": false,\"isPreconfigureDuringAddDevice\": false,\"accessoryGiftCardAmount\": 0.0,\"tradeInAmountTowardsUserDPUsed\": 0.0,\"sorDeviceType\": \"5GF\",\"vendingKioskItem\": \"false\",\"tradeInAutoPull\": false,\"priceAdjustment\": false,\"priceAdjustmentQty\": 0,\"newPurchasedQty\": 0,\"networkBandwidthType\": \"MMW\",\"selectedForRFEX\": false,\"selectedForPAD\": false,\"bogoItem\": false,\"itemCode\": \"LVSKIHP\",\"totalPriceWithDiscount\": 0.0,\"sorId\": \"LVSKIHP\",\"cartItemType\": \"DEVICE\",\"mobileNumber\": \"8627041933\",\"minNumber\": \"9738773139\",\"description\": \"5G Internet Gateway\",\"qty\": 1,\"bundleSeqNum\": 0,\"itemPrice\": \"0.0\",\"discountedPercentage\": 0.0,\"discountedPrice\": 0.0,\"taxAmount\": 0.0,\"imageUrlMap\": {\"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/verizon-gemini-5g-internet-gateway-gen-3-high-power-cpe-lvskihp\",\"largeImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/verizon-gemini-5g-internet-gateway-gen-3-high-power-cpe-lvskihp?$device-lg$\",\"mediumImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/verizon-gemini-5g-internet-gateway-gen-3-high-power-cpe-lvskihp?$device-med$\",\"miniImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/verizon-gemini-5g-internet-gateway-gen-3-high-power-cpe-lvskihp?$device-mini$\",\"thumbImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/verizon-gemini-5g-internet-gateway-gen-3-high-power-cpe-lvskihp?$device-thumb$\"},\"prodCode1\": \"5GD\",\"prodCode2\": \"NIC\",\"prodCode3\": \"5IR\",\"prodCode4\": \"B2B\",\"prodCode5\": \"RNT\",\"priceType\": \"MONTH_TO_MONTH\",\"btaEligible\": \"true\",\"depletionType\": \"F\",\"catalogPrice\": 0.0,\"instantCreditAmountUsed\": 0.0,\"instantCreditAmountUsedForTaxes\": 0.0,\"itemNrpPrice\": 0.0,\"itemCost\": 0.0,\"itemPriceType\": \"R\",\"discounts\": [],\"availableReasonCode\": [],\"inventory\": {\"isAvailable\": true,\"isBackorder\": false,\"isPreOrder\": false,\"qtyAvailable\": 1000},\"isCustomerProvidedSIM\": false,\"isNetworkExtender\": false,\"ispuEligible\": true,\"itemSeqNum\": 1,\"sddEligible\": true,\"smartIMEI\": false,\"year\": 0,\"sellerPrice\": \"0.0\",\"edgeDeviceCap\": \"750\",\"productId\": \"16900001\",\"taxDetailsList\": [],\"iconicPhone\": false,\"ringBell\": false,\"isPreconfigureEnabled\": false,\"isHumDevice\": false,\"isSmartLocator\": false,\"isSecurityAlarm\": false,\"isMotoMod\": false,\"isConnectedCar\": false,\"accountLevelAccessory\": false,\"byodESimPhone\": false,\"appleCareAccessoryFlag\": false},{\"discountAmount\": 0.0,\"deviceDollarApplied\": 0.0,\"qrScanNeededForEsimActivation\": false,\"isPreconfigureDuringAddDevice\": false,\"accessoryGiftCardAmount\": 0.0,\"tradeInAmountTowardsUserDPUsed\": 0.0,\"vendingKioskItem\": \"false\",\"tradeInAutoPull\": false,\"priceAdjustment\": false,\"priceAdjustmentQty\": 0,\"newPurchasedQty\": 0,\"selectedForRFEX\": false,\"selectedForPAD\": false,\"bogoItem\": false,\"itemCode\": \"NI-DPSIM\",\"totalPriceWithDiscount\": 0.0,\"sorId\": \"NI-DPSIM\",\"cartItemType\": \"SIM\",\"qty\": 1,\"bundleSeqNum\": 0,\"itemPrice\": \"0.0\",\"discountedPercentage\": 0.0,\"discountedPrice\": 0.0,\"instantCreditAmountUsed\": 0.0,\"instantCreditAmountUsedForTaxes\": 0.0,\"discounts\": [],\"availableReasonCode\": [],\"isCustomerProvidedSIM\": false,\"isNetworkExtender\": false,\"ispuEligible\": false,\"itemSeqNum\": 2,\"sddEligible\": false,\"smartIMEI\": false,\"year\": 0,\"sellerPrice\": \"0.0\",\"taxDetailsList\": [],\"iconicPhone\": false,\"ringBell\": false,\"isPreconfigureEnabled\": false,\"isHumDevice\": false,\"isSmartLocator\": false,\"isSecurityAlarm\": false,\"isMotoMod\": false,\"isConnectedCar\": false,\"accountLevelAccessory\": false,\"byodESimPhone\": false,\"appleCareAccessoryFlag\": false},{\"discountAmount\": 0.0,\"deviceDollarApplied\": 0.0,\"qrScanNeededForEsimActivation\": false,\"isPreconfigureDuringAddDevice\": false,\"accessoryGiftCardAmount\": 0.0,\"tradeInAmountTowardsUserDPUsed\": 0.0,\"vendingKioskItem\": \"false\",\"tradeInAutoPull\": false,\"priceAdjustment\": false,\"priceAdjustmentQty\": 0,\"newPurchasedQty\": 0,\"selectedForRFEX\": false,\"selectedForPAD\": false,\"bogoItem\": false,\"itemCode\": \"WAR6002\",\"totalPriceWithDiscount\": 0.0,\"sorId\": \"WAR6002\",\"cartItemType\": \"WARRANTY\",\"qty\": 1,\"bundleSeqNum\": 0,\"itemPrice\": \"0.0\",\"discountedPercentage\": 0.0,\"discountedPrice\": 0.0,\"instantCreditAmountUsed\": 0.0,\"instantCreditAmountUsedForTaxes\": 0.0,\"discounts\": [],\"availableReasonCode\": [],\"isCustomerProvidedSIM\": false,\"isNetworkExtender\": false,\"ispuEligible\": false,\"itemSeqNum\": 3,\"sddEligible\": false,\"smartIMEI\": false,\"year\": 0,\"sellerPrice\": \"0.0\",\"taxDetailsList\": [],\"iconicPhone\": false,\"ringBell\": false,\"isPreconfigureEnabled\": false,\"isHumDevice\": false,\"isSmartLocator\": false,\"isSecurityAlarm\": false,\"isMotoMod\": false,\"isConnectedCar\": false,\"accountLevelAccessory\": false,\"byodESimPhone\": false,\"appleCareAccessoryFlag\": false}]},\"depletionLocation\": \"\",\"isPromoSelected\": false,\"isTradeInSelected\": false,\"taxExemptionTypes\": \"\"}],\"assignMTNIndicator\": \"Y\",\"mtnDetails\": {\"dummyMTNForDomain\": \"9999999901\",\"lineNumber\": \"newLine1\",\"minNumber\": \"9738773139\",\"mobileNumber\": \"8627041933\",\"assignMTNTimestamp\": \"2021-11-16T06:56:26.897813-05:00[US/Eastern]\",\"npaNXX\": \"862704\"},\"securityDepositAmount\": \"0\",\"lineNumber\": \"newLine1\",\"fiveGToFourGDownGrade\": false,\"deviceTypeSelected\": \"5G Internet\",\"reasonCode\": \"PLAN_DEVICE_COMPATIBLE\",\"launchType\": \"FCL\",\"lineRefundTotal\": 0.0,\"lineExchangeTotal\": 0.0,\"totalDueMonthlyBeforeCredit\": 0.0,\"isCpe\": false,\"isLTEHomeLine\": false,\"isDevicePlanCompatible\": true,\"portinMtnAssignment\": false,\"impactedLine\": false,\"preOrBackOrder\": false,\"ispuItem\": false,\"ispuItemBYOD\": false,\"isModConnected\": false,\"modDevice\": false,\"byodCapable\": false,\"isCarLine\": false,\"buySimOnly\": false,\"broadBandInd\": false,\"ispuDownPaymentAdjstRequired\": false,\"ispuDownPaymentAmount\": 0.0,\"lineWithSkipMDN\": false,\"protectionNotRequired\": false}],\"numOfAccessoryAndDeviceItemsInCart\": 1,\"totalEdgeUpAmount\": 0.0,\"totalEdgeBuyOutAmount\": 0.0,\"tradeInDetail\": {},\"totalDownPaymentAmt\": 0.0,\"numOfLinesWithDevices\": 1,\"numofApprovedLines\": 0,\"rfexPayments\": [],\"cartId\": \"077d51dd-0511-4e87-bc34-3de25cf18ef8\",\"numOfLines\": 1,\"numofLinesAAL\": 0,\"numofLinesEUP\": 0,\"payments\": [],\"lineSeq\": 0,\"vlcactivePhoneCount\": 0,\"fivegOrderind\": true,\"aceOrderCreated\": false,\"serviceLinesCreated\": false,\"aceItemsModified\": false,\"clnrOrderFlag\": false,\"broadbandInd\": false,\"acctMcsSubscription\": [],\"spendingLimitAmountExceededBy\": \"0.0\",\"numofAccessories\": 0,\"subAccountNBSInfo\": []},\"accountEligibility\": false,\"displayCartValidationErrors\": true},\"warningMessages\": [],\"basicORSmartPhoneExists\": false,\"fiveGDeviceORLTEHomeExists\": true,\"redesignFlow\": false,\"orderPlaced\": false,\"validateCart\": false},\"meta\": {\"timestamp\": \"1637063846283\",\"cxpCorrelationId\": \"2021-11-16T11:57:26.+0000:6a3027a3-8396-4761-b3cf-c952d76ee702:cxp-shopping-services-qa-ev6v-sit2w-nscxp-6b5fc85895-6fk9d:nssit2\"}}";
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		RetrieveCartUIResponse sampleRetrieveCartResponse = null;
		sampleRetrieveCartResponse = mapper.readValue(sampleRetrieveCartResponseString, RetrieveCartUIResponse.class);
		ValidateISPUOrderUIRequest sampleRequest = mapper.readValue(sampleRequestString,
				ValidateISPUOrderUIRequest.class);
		Mono<RetrieveCartUIResponse> sampleRetrieveCartResponseMono = Mono.just(sampleRetrieveCartResponse);
		when(cxpHelper.retrieveCart(Mockito.any())).thenReturn(sampleRetrieveCartResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		Mono<ValidateISPUOrderUIResponse> response = helper.validateISPUOrder(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete()
				.verify();

	}
	
	@Test
	public void getUpgradeReasonCodesHelperTest() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"user\": \"kumasa1\",\"client\": \"CXP\",\"data\": {\"cartId\": \"b6379363-fe90-42d5-b7fa-bf133f913207\",\"mtn\": \"7655706413\",\"priceOption\": \"ONE_YEAR\"}}";
		String sampleResponseString = "{\"meta\": {\"timestamp\": 1578654692539,\"cxpCorrelationId\": \"2020-01-10T11:11:32.+0000:4118317f-f443-4653-a2a9-0fb4004ee40e:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-bb449886-t5hsh\"},\"data\": {\"cartId\": \"b6379363-fe90-42d5-b7fa-bf133f913207\",\"mtn\": \"7655706413\",\"eligibleReasonCodes\": [{\"upgradeReasonCode\": \"UP\",\"upgradeReasonDesc\": \"Standard Upgrade - 1yr\"}]}}";
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		GetUpgradeReasonCodeUIRequest UIRequest = mapper.readValue(sampleRequestString,
				GetUpgradeReasonCodeUIRequest.class);
		GetUpgradeReasonCodeUIResponse soeResponse = mapper.readValue(sampleResponseString,
				GetUpgradeReasonCodeUIResponse.class);
		Mono<GetUpgradeReasonCodeUIResponse> sampleResponseMono = Mono.just(soeResponse);
		when(cxpHelper2.getUpgradeReasonCodes(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		Mono<GetUpgradeReasonCodeUIResponse> response = helper.getUpgradeReasonCodes(UIRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

	}
	
	@Test
	public void checkDfillInventoryHelperTest() throws IOException, SOEHTTPException {
		String sampleResponseString = "{  \"cartId\": \"d9cdae0c-0db2-496d-8f43-55d4e9d3d9fa\",  \"intendType\": \"AAL\"}";
		String sampleRequestString = "{ \"meta\": { \"timestamp\": 1579024925151, \"cxpCorrelationId\": \"2020-01-14T12:02:05.-0600:5c40a72e-3f8c-496e-ad98-a13d7174801c:WTX0109ALDITAUX:cxp-cart-domain:nsd2\" }, \"data\": { \"cartId\": \"d9cdae0c-0db2-496d-8f43-55d4e9d3d9fa\", \"statusCode\": 1, \"statusMsg\": \"Success\", \"lines\": [{ \"mtn\": \"2819001513\", \"status\": 1, \"planValidationFailed\": false, \"lineActivityType\": \"ACC\", \"currentPlanType\": \"LLP\", \"accessory\": { \"cartItemType\": \"ACCESSORY\", \"quantityOnHand\": 27037, \"description\": \"4G LTE Network Extender 2\" }, \"devicePlanCompatible\": false }, { \"mtn\": \"7346259623\", \"status\": 1, \"planValidationFailed\": false, \"lineActivityType\": \"BYOD\", \"currentPlanType\": \"LLP\", \"device\": { \"cartItemType\": \"DEVICE\", \"quantityOnHand\": 27037, \"description\": \"IPHONE XS SPACE GRAY 64GB VZ\" }, \"accessory\": { \"cartItemType\": \"ACCESSORY\", \"quantityOnHand\": 27037, \"description\": \"4G LTE Network Extender 2\" }, \"devicePlanCompatible\": false }], \"preAuthSuccess\": false, \"vztDiscountGain\": false, \"vztDiscountLoss\": false, \"financeLimitExceeded\": false, \"promoLossIndicator\": false, \"monthlyCreditAmount\": 0.0, \"agreementNumber\": 0 } }";
		CheckDfillInventoryUIRequest sampleRequest = null;
		CheckDfillInventoryUIResponse sampleResponse = null;
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRequest = mapper.readValue(sampleRequestString, CheckDfillInventoryUIRequest.class);
		sampleResponse = mapper.readValue(sampleResponseString, CheckDfillInventoryUIResponse.class);
		Mono<CheckDfillInventoryUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(cxpHelper2.checkDfillInventory(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		CheckDfillInventoryUIResponse expectedResponse = sampleResponse;
		Mono<CheckDfillInventoryUIResponse> response = helper.checkDfillInventory(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}
	
	@Test
	public void getDepletionTypeHelperTest() throws IOException, SOEHTTPException {
		String sampleRequestString = "{ \"data\":{    \"cartId\": \"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\" } }";
		String sampleResponseString = "{\"data\":{\"cart\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"status\":\"A\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"cartCreator\":\"4434541510\",\"cartCreatorOrderLocationCode\":\"E248201\",\"cartCreatorSalesRepId\":\"ENC\",\"creditApplicationNum\":\"388936130\",\"secondaryCreditApplicationNum\":0},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"customerType\":\"U\",\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"totalTaxAmount\":\"38.75\",\"spocs\":{\"notificationOptions\":{\"contactPhoneNumber\":\"1196120299\",\"primaryEmailId\":\"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"instantCreditAmount\":0.0,\"instantCreditAmountRemaining\":0.0,\"instantCreditEligible\":false,\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":388936130,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\":\"true\",\"creditAdvisory\":\"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\":\"0\",\"serviceClass\":\"B\",\"lineCreditClass\":\"\"},\"orderActivityType\":\"EUP\",\"orderNumber\":\"1112\"}],\"orderNumber\":0,\"outletId\":\"124632\",\"registerNumber\":0,\"saleType\":\"P\",\"salesRepId\":\"ENC\",\"totalInstantCreditAmount\":0.0,\"totalInstantCreditAmountUsed\":0.0},\"lineDetails\":{\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"mldTrunkMTN\":0,\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"zipCode4\":\"7848\"},\"isValidAddress\":true},\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"currentDevice\":{\"oldLteVoraEquipInfo\":{\"iccid\":\"89148000004671963398\",\"lteVoraDeviceInfo\":{\"deviceId\":\"352530085081859\",\"deviceType\":\"4GE\"}}},\"isSharePlanAdded\":false,\"edgeLine\":false,\"vlcLine\":false,\"isE911AddressValidated\":false,\"oldPlanFlag\":\"L\",\"orderDevice\":{\"lteVoraEquipInfo\":{\"lteEqpt\":{},\"lteVoraDeviceInfo\":{}}}},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"shippingCost\":\"0.0\",\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"isUseUnVerifiedAddress\":false,\"isValidAddress\":false},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"mobileNumber\":\"4434541510\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"groupDiscInd\":0,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-thumb$\"},\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"color\":{\"color\":\"#cfbea9\",\"colorDisplayName\":\"GOLD/PINKSAND\"},\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"discounts\":[],\"availableReasonCode\":[],\"inventory\":{\"isAvailable\":true,\"isBackorder\":false,\"isPreOrder\":false,\"qtyAvailable\":39437.0},\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"numberShareEligible\":\"true\",\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0}]},\"isPromoSelected\":false,\"isTradeInSelected\":false}],\"lineIdentifier\":0,\"itemSeqNum5GL\":0,\"itemSeqNum4GR\":0,\"lineExchangeTotal\":0.0,\"lineRefundTotal\":0.0,\"isCpe\":false,\"isDevicePlanCompatible\":false,\"portinMtnAssignment\":false,\"impactedLine\":false,\"preOrBackOrder\":false,\"ispuItem\":true,\"ispuItemBYOD\":false}],\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"numofLinesAAL\":0,\"numofLinesEUP\":0,\"validationMessages\":[],\"payments\":[],\"lineSeq\":0,\"vlcactivePhoneCount\":0,\"fivegOrderind\":false,\"aceOrderCreated\":false,\"serviceLinesCreated\":false,\"aceItemsModified\":false,\"clnrOrderFlag\":false,\"broadbandInd\":false,\"isPaperLessBilling\":\"false\"}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		String depletionResponseString = "{\"data\": {  \"isIspuItemsInCarts\": true,   \"isDfillItemsInCart\": false,   \"isLocalItemsInCart\": true}}";
		String redisDataString = "{ \"cartId\": \"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\" }";
		GetDepletionTypeUIRequest sampleRequest = null;
		RetrieveCartUIResponse sampleResponse = null;
		GetDepletionTypeUIResponse sampleDepletionResponse = null;
		CartRedisData sampleRedisData = null;
		sampleRequest = mapper.readValue(sampleRequestString, GetDepletionTypeUIRequest.class);
		sampleResponse = mapper.readValue(sampleResponseString, RetrieveCartUIResponse.class);
		sampleDepletionResponse = mapper.readValue(depletionResponseString, GetDepletionTypeUIResponse.class);
		sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(cxpHelper.retrieveCart(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		GetDepletionTypeUIResponse expectedResponse = sampleDepletionResponse;
		Mono<GetDepletionTypeUIResponse> response = helper.getDepletionType(sampleRequest);
		GetDepletionTypeData data = expectedResponse.getData();
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(data, resp.getData())).expectComplete()
				.verify();
	}
	
	@Test
	public void managerApprovalLinesHelperTest() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"},\"mtnList\":[\"1234567890\"]}";
		String sampleResponseString = "{\"data\":{\"cart\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"status\":\"A\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"cartCreator\":\"4434541510\",\"cartCreatorOrderLocationCode\":\"E248201\",\"cartCreatorSalesRepId\":\"ENC\",\"creditApplicationNum\":\"388936130\",\"secondaryCreditApplicationNum\":0},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"customerType\":\"U\",\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"totalTaxAmount\":\"38.75\",\"spocs\":{\"notificationOptions\":{\"contactPhoneNumber\":\"1196120299\",\"primaryEmailId\":\"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"instantCreditAmount\":0.0,\"instantCreditAmountRemaining\":0.0,\"instantCreditEligible\":false,\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":388936130,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\":\"true\",\"creditAdvisory\":\"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\":\"0\",\"serviceClass\":\"B\",\"lineCreditClass\":\"\"},\"orderActivityType\":\"EUP\",\"orderNumber\":\"1112\"}],\"orderNumber\":0,\"outletId\":\"124632\",\"registerNumber\":0,\"saleType\":\"P\",\"salesRepId\":\"ENC\",\"totalInstantCreditAmount\":0.0,\"totalInstantCreditAmountUsed\":0.0},\"lineDetails\":{\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"mldTrunkMTN\":0,\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"zipCode4\":\"7848\"},\"isValidAddress\":true},\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"currentDevice\":{\"oldLteVoraEquipInfo\":{\"iccid\":\"89148000004671963398\",\"lteVoraDeviceInfo\":{\"deviceId\":\"352530085081859\",\"deviceType\":\"4GE\"}}},\"isSharePlanAdded\":false,\"edgeLine\":false,\"vlcLine\":false,\"isE911AddressValidated\":false,\"oldPlanFlag\":\"L\",\"orderDevice\":{\"lteVoraEquipInfo\":{\"lteEqpt\":{},\"lteVoraDeviceInfo\":{}}}},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"shippingCost\":\"0.0\",\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"isUseUnVerifiedAddress\":false,\"isValidAddress\":false},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"mobileNumber\":\"4434541510\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"groupDiscInd\":0,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-thumb$\"},\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"color\":{\"color\":\"#cfbea9\",\"colorDisplayName\":\"GOLD/PINKSAND\"},\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"discounts\":[],\"availableReasonCode\":[],\"inventory\":{\"isAvailable\":true,\"isBackorder\":false,\"isPreOrder\":false,\"qtyAvailable\":39437.0},\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"numberShareEligible\":\"true\",\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0}]},\"isPromoSelected\":false,\"isTradeInSelected\":false}],\"lineIdentifier\":0,\"itemSeqNum5GL\":0,\"itemSeqNum4GR\":0,\"lineExchangeTotal\":0.0,\"lineRefundTotal\":0.0,\"isCpe\":false,\"isDevicePlanCompatible\":false,\"portinMtnAssignment\":false,\"impactedLine\":false,\"preOrBackOrder\":false,\"ispuItem\":true,\"ispuItemBYOD\":false}],\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"numofLinesAAL\":0,\"numofLinesEUP\":0,\"validationMessages\":[],\"payments\":[],\"lineSeq\":0,\"vlcactivePhoneCount\":0,\"fivegOrderind\":false,\"aceOrderCreated\":false,\"serviceLinesCreated\":false,\"aceItemsModified\":false,\"clnrOrderFlag\":false,\"broadbandInd\":false,\"isPaperLessBilling\":\"false\"}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveCartCXPRequest sampleRequest = null;
		RetrieveCartUIResponse sampleResponse = null;
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRequest = mapper.readValue(sampleRequestString, RetrieveCartCXPRequest.class);
		sampleResponse = mapper.readValue(sampleResponseString, RetrieveCartUIResponse.class);
		Mono<RetrieveCartUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(cxpHelper.retrieveCart(Mockito.any())).thenReturn(sampleResponseMono);
		CustomerByMtnListUIResponse custResp = new CustomerByMtnListUIResponse();
		custResp.setErrors(new CartError[1]);
		when(cxpHelper2.customerByMtnList(Mockito.any())).thenReturn(Mono.just(custResp));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		InEligibleLinesRedisData ie = new InEligibleLinesRedisData();
		ie.setMtn("");
		ie.setReason("");
		List<InEligibleLinesRedisData> ieData = new ArrayList<>();
		ieData.add(ie);
		String ineligibleData = "[{\"mtn\":\"7169849755\", \"reason\":\"Crisis\"}]";
		try {
			ieData = mapper.readValue(ineligibleData, new TypeReference<List<InEligibleLinesRedisData>>(){});
		} catch (JsonProcessingException e) {
			System.out.println(CartConstants.JSON_PRCSSNG_EXCPTN_STRNG + e);
		}
		when(redisHelper.getInEligibleUpgradeLinesFromRedis()).thenReturn(Mono.just(ieData));
		Mono<RetrieveCartUIResponse> response = helper.managerApprovalLines(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete()
				.verify();
	}
	
	@Test
	public void retrieveCartHelperTest() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"}}";
		String sampleResponseString = "{\"data\":{\"cart\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"status\":\"A\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"cartCreator\":\"4434541510\",\"cartCreatorOrderLocationCode\":\"E248201\",\"cartCreatorSalesRepId\":\"ENC\",\"creditApplicationNum\":\"388936130\",\"secondaryCreditApplicationNum\":0},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"customerType\":\"U\",\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"totalTaxAmount\":\"38.75\",\"spocs\":{\"notificationOptions\":{\"contactPhoneNumber\":\"1196120299\",\"primaryEmailId\":\"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"instantCreditAmount\":0.0,\"instantCreditAmountRemaining\":0.0,\"instantCreditEligible\":false,\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":388936130,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\":\"true\",\"creditAdvisory\":\"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\":\"0\",\"serviceClass\":\"B\",\"lineCreditClass\":\"\"},\"orderActivityType\":\"EUP\",\"orderNumber\":\"1112\"}],\"orderNumber\":0,\"outletId\":\"124632\",\"registerNumber\":0,\"saleType\":\"P\",\"salesRepId\":\"ENC\",\"totalInstantCreditAmount\":0.0,\"totalInstantCreditAmountUsed\":0.0,\"fiosAccountInfo\":{\"upSpeedInfo\":\"1024M\"}},\"lineDetails\":{\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"mldTrunkMTN\":0,\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"zipCode4\":\"7848\"},\"isValidAddress\":true},\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"currentDevice\":{\"oldLteVoraEquipInfo\":{\"iccid\":\"89148000004671963398\",\"lteVoraDeviceInfo\":{\"deviceId\":\"352530085081859\",\"deviceType\":\"4GE\"}}},\"isSharePlanAdded\":false,\"edgeLine\":false,\"vlcLine\":false,\"isE911AddressValidated\":false,\"oldPlanFlag\":\"L\",\"orderDevice\":{\"lteVoraEquipInfo\":{\"lteEqpt\":{},\"lteVoraDeviceInfo\":{}}}},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"shippingCost\":\"0.0\",\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"isUseUnVerifiedAddress\":false,\"isValidAddress\":false},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"mobileNumber\":\"4434541510\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"groupDiscInd\":0,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-thumb$\"},\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"color\":{\"color\":\"#cfbea9\",\"colorDisplayName\":\"GOLD/PINKSAND\"},\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"discounts\":[],\"availableReasonCode\":[],\"inventory\":{\"isAvailable\":true,\"isBackorder\":false,\"isPreOrder\":false,\"qtyAvailable\":39437.0},\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"numberShareEligible\":\"true\",\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0}]},\"isPromoSelected\":false,\"isTradeInSelected\":false}],\"lineIdentifier\":0,\"itemSeqNum5GL\":0,\"itemSeqNum4GR\":0,\"lineExchangeTotal\":0.0,\"lineRefundTotal\":0.0,\"isCpe\":false,\"isDevicePlanCompatible\":false,\"portinMtnAssignment\":false,\"impactedLine\":false,\"preOrBackOrder\":false,\"ispuItem\":true,\"ispuItemBYOD\":false}],\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"numofLinesAAL\":0,\"numofLinesEUP\":0,\"validationMessages\":[],\"payments\":[],\"lineSeq\":0,\"vlcactivePhoneCount\":0,\"fivegOrderind\":false,\"aceOrderCreated\":false,\"serviceLinesCreated\":false,\"aceItemsModified\":false,\"clnrOrderFlag\":false,\"broadbandInd\":false,\"isPaperLessBilling\":\"false\"}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveCartCXPRequest sampleRequest = null;
		RetrieveCartUIResponse sampleResponse = null;
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"locationCode\": \"LOCATION\",\"upc\": \"SMGALAXYS99\",\"locationSubType\": \"GN\",\"maid\": \"BBx\",\"priceId\": \"priceid\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"creditAppNum\": \"8436667390\", \"customerType\": \"U\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRequest = mapper.readValue(sampleRequestString, RetrieveCartCXPRequest.class);
		sampleRequest.setSkipUpdateDLLData(true);
		sampleResponse = mapper.readValue(sampleResponseString, RetrieveCartUIResponse.class);
		Mono<RetrieveCartUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(cxpHelper.retrieveCart(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(new FiveGAddressRedisData()));
		when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.anyString())).thenReturn(Mono.just(Boolean.TRUE));
		when(redisHelper3.getConflictsStatusFromSession()).thenReturn(Mono.just(true));

		RetrieveCartUIResponse expectedResponse = sampleResponse;
		Mono<RetrieveCartUIResponse> response = helper.retrieveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}

	@Test
	public void retrieveCartHelperCategoryCodeTest() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"}}";
		String sampleResponseString = "{\"data\":{\"cart\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"status\":\"A\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"cartCreator\":\"4434541510\",\"cartCreatorOrderLocationCode\":\"E248201\",\"cartCreatorSalesRepId\":\"ENC\",\"creditApplicationNum\":\"388936130\",\"secondaryCreditApplicationNum\":0},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"customerType\":\"U\",\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"totalTaxAmount\":\"38.75\",\"spocs\":{\"notificationOptions\":{\"contactPhoneNumber\":\"1196120299\",\"primaryEmailId\":\"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"instantCreditAmount\":0.0,\"instantCreditAmountRemaining\":0.0,\"instantCreditEligible\":false,\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":388936130,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\":\"true\",\"creditAdvisory\":\"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\":\"0\",\"serviceClass\":\"B\",\"lineCreditClass\":\"\"},\"orderActivityType\":\"EUP\",\"orderNumber\":\"1112\"}],\"orderNumber\":0,\"outletId\":\"124632\",\"registerNumber\":0,\"saleType\":\"P\",\"salesRepId\":\"ENC\",\"totalInstantCreditAmount\":0.0,\"totalInstantCreditAmountUsed\":0.0,\"fiosAccountInfo\":{\"upSpeedInfo\":\"1024M\"}},\"lineDetails\":{\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"newPricePlanInfo\":{\"categoryCode\":\"87\"},\"mldTrunkMTN\":0,\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"zipCode4\":\"7848\"},\"isValidAddress\":true},\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"currentDevice\":{\"oldLteVoraEquipInfo\":{\"iccid\":\"89148000004671963398\",\"lteVoraDeviceInfo\":{\"deviceId\":\"352530085081859\",\"deviceType\":\"4GE\"}}},\"isSharePlanAdded\":false,\"edgeLine\":false,\"vlcLine\":false,\"isE911AddressValidated\":false,\"oldPlanFlag\":\"L\",\"orderDevice\":{\"lteVoraEquipInfo\":{\"lteEqpt\":{},\"lteVoraDeviceInfo\":{}}}},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"shippingCost\":\"0.0\",\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"isUseUnVerifiedAddress\":false,\"isValidAddress\":false},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"mobileNumber\":\"4434541510\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"groupDiscInd\":0,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-thumb$\"},\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"color\":{\"color\":\"#cfbea9\",\"colorDisplayName\":\"GOLD/PINKSAND\"},\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"discounts\":[],\"availableReasonCode\":[],\"inventory\":{\"isAvailable\":true,\"isBackorder\":false,\"isPreOrder\":false,\"qtyAvailable\":39437.0},\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"numberShareEligible\":\"true\",\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0}]},\"isPromoSelected\":false,\"isTradeInSelected\":false}],\"lineIdentifier\":0,\"itemSeqNum5GL\":0,\"itemSeqNum4GR\":0,\"lineExchangeTotal\":0.0,\"lineRefundTotal\":0.0,\"isCpe\":false,\"isDevicePlanCompatible\":false,\"portinMtnAssignment\":false,\"impactedLine\":false,\"preOrBackOrder\":false,\"ispuItem\":true,\"ispuItemBYOD\":false}],\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"numofLinesAAL\":0,\"numofLinesEUP\":0,\"validationMessages\":[],\"payments\":[],\"lineSeq\":0,\"vlcactivePhoneCount\":0,\"fivegOrderind\":false,\"aceOrderCreated\":false,\"serviceLinesCreated\":false,\"aceItemsModified\":false,\"clnrOrderFlag\":false,\"broadbandInd\":false,\"isPaperLessBilling\":\"false\"}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveCartCXPRequest sampleRequest = null;
		RetrieveCartUIResponse sampleResponse = null;
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRequest = mapper.readValue(sampleRequestString, RetrieveCartCXPRequest.class);
		sampleResponse = mapper.readValue(sampleResponseString, RetrieveCartUIResponse.class);
		Mono<RetrieveCartUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(cxpHelper.retrieveCart(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(new FiveGAddressRedisData()));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.anyString())).thenReturn(Mono.just(Boolean.TRUE));
		when(redisHelper3.getConflictsStatusFromSession()).thenReturn(Mono.just(true));
		RetrieveCartUIResponse expectedResponse = sampleResponse;
		Mono<RetrieveCartUIResponse> response = helper.retrieveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}

	@Test
	public void validateCartHelperTest() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\",\"clientId\":\"VZW-MFA\"},\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\",\"channel\":\"assissted\",\"pageId\":\"landing\",\"flow\":\"upgrade\"}";
		String sampleResponseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
		ValidateCartCXPRequest sampleRequest = null;
		ValidateCartUIResponse sampleResponse = null;
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRequest = mapper.readValue(sampleRequestString, ValidateCartCXPRequest.class);
		sampleResponse = mapper.readValue(sampleResponseString, ValidateCartUIResponse.class);
		Mono<ValidateCartUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper.upsertOneClickCheckoutFlag(Mockito.any())).thenReturn(Mono.empty());
		ValidateCartUIResponse expectedResponse = sampleResponse;
		Mono<ValidateCartUIResponse> response = helper.validateCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}

	//test cases for VZWCS-17115
	@Test
	public void initiateCbandCheckHelperTest() throws IOException {
		String sampleRequestString = "{\"flowType\":\"imsi\",\"imsi\":\"311480589646564\"}";
		String sampleResponseString = "{\"meta\":{\"timestamp\":\"1646038921968\",\"cxpCorrelationId\":\"2022-02-28T09:02:01.+0000:27725cc9-1c08-420e-9653-90650363a6e7:cxp-customerprofile-se-qa-ev6v-sit3e-nscxp-5c7bdbf4f4-8wt5x:nssit3\"},\"data\":{\"vmasBootUpInfo\":{\"mtn\":\"8322622598\",\"booted\":false,\"deviceReachable\":\"Y\",\"snr5G\":\"12\",\"networkType\":\"UW Mid Band\",\"setupReason\":\"NEW SETUP\",\"postMount5GSignal\":\"\"}}}";
        InitiateCbandCheckUIRequest sampleRequest = mapper.readValue(sampleRequestString,InitiateCbandCheckUIRequest.class);
        InitiateCbandCheckUIResponse sampleResponse = mapper.readValue(sampleResponseString,InitiateCbandCheckUIResponse.class);
        Mono<InitiateCbandCheckUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(cxpHelper2.initiateCbandCheck(Mockito.any())).thenReturn(sampleResponseMono);
        Mono<InitiateCbandCheckUIResponse> response = helper.initiateCbandCheck(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}

	//test cases for NSA
	//checkExistingCartFromPega
	@Test
	public void checkExistingCartFromPegaHelperTest() throws IOException {
		String requestString = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"prospectCartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processAction\":\"addAccessoryAndCheckout\",\"processStep\":\"AccessoryPDP\",\"intendType\":\"NSEACC\",\"pageId\":\"CART\",\"intent\":\"StandAloneAccessory\",\"cradleFlowJourney\":\"PromoHub\",\"action\":\"UPDATE\",\"itemType\":\"ACCESSORY\"}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGAgeneratedmessage\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\"]},{\"mtn\": \"2515813861\",\"completedprocessSteps\": []}],\"cartInfo\":{\"cartId\":\"a705f835-c61a-4e20-b616-0c9839202a15\"},\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"PromoHub\",\"availablePaths\":[{\"path\":\"PromoHub\"},{\"path\":\"MTNSelectionPage\"}],\"callReason\":\"SalesOrderPurchase\"}}}}}";
		CheckExistingCartUIRequest sampleRequest = null;
		CheckExistingCartUIResponse sampleResponse = null;
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRequest = mapper.readValue(requestString, CheckExistingCartUIRequest.class);
		sampleResponse = mapper.readValue(responseString, CheckExistingCartUIResponse.class);

		when(bpmHelper4.checkExistingCart(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		CheckExistingCartUIResponse expectedResponse = sampleResponse;
		Mono<CheckExistingCartUIResponse> response = helper.checkExistingCartFromPega(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
		.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
		.verify();

	}

	//test cases for NSA
	//retrieveActivationStatusFromCXP
	@Test
	public void retrieveActivationStatusFromCXPHelperTest() throws IOException, SOEHTTPException {
		String sampleRequestString = "OMNI-INDIRECT";
		RetrieveActivationStatusUIResponse sampleResponse =  new RetrieveActivationStatusUIResponse();
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		RetrieveActivationStatusCXPResponse retrieveActivationCXPResponse = new RetrieveActivationStatusCXPResponse();
		retrieveActivationCXPResponse.setData(new RetrieveActivationStatusCXPData());
		retrieveActivationCXPResponse.getData().setOrderActivationStatusInfo(Arrays.asList(new OrderActivationStatusCXPInfo()));
		when(cxpService.retrieveActivationStatusOrdering(Mockito.any())).thenReturn(Mono.just(retrieveActivationCXPResponse));
		RetrieveActivationStatusUIResponse expectedResponse = sampleResponse;
		Mono<RetrieveActivationStatusUIResponse> response = helper.retrieveActivationStatusFromCXP(sampleRequestString);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
		.verify();
	}

	//test cases for NSA
	//guestChoiceFromPega
	@Test
	public void guestChoiceFromPegaHelperTest() throws IOException {
		GuestChoiceUIRequest sampleRequest =  new GuestChoiceUIRequest();
		GuestChoiceUIResponse sampleResponse =  new GuestChoiceUIResponse();
		Mono<GuestChoiceUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(bpmHelper4.guestChoice(Mockito.any())).thenReturn(sampleResponseMono);
		sampleRequest.setCartInfo(new CartInfo());
		Mono<GuestChoiceUIResponse> response = helper.guestChoiceFromPega(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
		.verify();

	}

	//test cases for NSA
	//customerByMtnForParentLines
	@Test
	public void customerByMtnForParentLinesHelperTest() throws IOException {
		String SampleRequestPLMTN = "";
		GetParentLinesUIResponse sampleResponse = new GetParentLinesUIResponse();
		Mono<GetParentLinesUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(cxpHelper2.customerByMtnForParentLines(Mockito.any())).thenReturn(sampleResponseMono);
		Mono<GetParentLinesUIResponse> response = helper.customerByMtnForParentLines(SampleRequestPLMTN);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
		.verify();

	}


	//test cases for NSA
	//salesRepIdProfile
	@Test
	public void salesRepIdProfileHelperTest() throws IOException {
		String SampleRequestRepId = "";
		CustomerProfileUIResponse sampleResponse = new CustomerProfileUIResponse();
		Mono<CustomerProfileUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(cxpHelper2.salesRepIdProfile(Mockito.any())).thenReturn(sampleResponseMono);
		Mono<CustomerProfileUIResponse> response = helper.salesRepIdProfile(SampleRequestRepId);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
		.verify();

	}

	//test cases for NSA
	//customerByMtn
	@Test
	public void customerByMtnHelperTest() throws IOException {
		String SampleRequestCMTN = "";
		CustomerByMtnUIResponse sampleResponse = new CustomerByMtnUIResponse();
		Mono<CustomerByMtnUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(cxpHelper2.customerByMtn(Mockito.any())).thenReturn(sampleResponseMono);
		Mono<CustomerByMtnUIResponse> response = helper.customerByMtn(new CustomerReqType());
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
		.verify();

	}

	//test cases for NSA
	//retrieveBundleAccessoryInfo
	@Test
	public void retrieveBundleAccessoryInfoHelperTest() throws IOException, SOEHTTPException {

		String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"}}";
		String sampleResponseString = "{\"data\":{\"cart\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"status\":\"A\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"cartCreator\":\"4434541510\",\"cartCreatorOrderLocationCode\":\"E248201\",\"cartCreatorSalesRepId\":\"ENC\",\"creditApplicationNum\":\"388936130\",\"secondaryCreditApplicationNum\":0},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"customerType\":\"U\",\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"totalTaxAmount\":\"38.75\",\"spocs\":{\"notificationOptions\":{\"contactPhoneNumber\":\"1196120299\",\"primaryEmailId\":\"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"instantCreditAmount\":0.0,\"instantCreditAmountRemaining\":0.0,\"instantCreditEligible\":false,\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":388936130,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\":\"true\",\"creditAdvisory\":\"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\":\"0\",\"serviceClass\":\"B\",\"lineCreditClass\":\"\"},\"orderActivityType\":\"EUP\",\"orderNumber\":\"1112\"}],\"orderNumber\":0,\"outletId\":\"124632\",\"registerNumber\":0,\"saleType\":\"P\",\"salesRepId\":\"ENC\",\"totalInstantCreditAmount\":0.0,\"totalInstantCreditAmountUsed\":0.0},\"lineDetails\":{\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"mldTrunkMTN\":0,\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"zipCode4\":\"7848\"},\"isValidAddress\":true},\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"currentDevice\":{\"oldLteVoraEquipInfo\":{\"iccid\":\"89148000004671963398\",\"lteVoraDeviceInfo\":{\"deviceId\":\"352530085081859\",\"deviceType\":\"4GE\"}}},\"isSharePlanAdded\":false,\"edgeLine\":false,\"vlcLine\":false,\"isE911AddressValidated\":false,\"oldPlanFlag\":\"L\",\"orderDevice\":{\"lteVoraEquipInfo\":{\"lteEqpt\":{},\"lteVoraDeviceInfo\":{}}}},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"shippingCost\":\"0.0\",\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"isUseUnVerifiedAddress\":false,\"isValidAddress\":false},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"mobileNumber\":\"4434541510\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"groupDiscInd\":0,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-thumb$\"},\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"color\":{\"color\":\"#cfbea9\",\"colorDisplayName\":\"GOLD/PINKSAND\"},\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"discounts\":[],\"availableReasonCode\":[],\"inventory\":{\"isAvailable\":true,\"isBackorder\":false,\"isPreOrder\":false,\"qtyAvailable\":39437.0},\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"numberShareEligible\":\"true\",\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0}]},\"isPromoSelected\":false,\"isTradeInSelected\":false}],\"lineIdentifier\":0,\"itemSeqNum5GL\":0,\"itemSeqNum4GR\":0,\"lineExchangeTotal\":0.0,\"lineRefundTotal\":0.0,\"isCpe\":false,\"isDevicePlanCompatible\":false,\"portinMtnAssignment\":false,\"impactedLine\":false,\"preOrBackOrder\":false,\"ispuItem\":true,\"ispuItemBYOD\":false}],\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"numofLinesAAL\":0,\"numofLinesEUP\":0,\"validationMessages\":[],\"payments\":[],\"lineSeq\":0,\"vlcactivePhoneCount\":0,\"fivegOrderind\":false,\"aceOrderCreated\":false,\"serviceLinesCreated\":false,\"aceItemsModified\":false,\"clnrOrderFlag\":false,\"broadbandInd\":false,\"isPaperLessBilling\":\"false\"}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveBundleAccRequest sampleRequest = null;
		BundleAccessoryDetail sampleResponseBundle = null;
		RetrieveAccCartCXPResponse sampleResponseRetrieve = null;
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRequest = mapper.readValue(sampleRequestString, RetrieveBundleAccRequest.class);
		sampleResponseBundle = mapper.readValue(sampleResponseString, BundleAccessoryDetail.class);
		sampleResponseRetrieve = mapper.readValue(sampleResponseString, RetrieveAccCartCXPResponse.class);
		//Mono<BundleAccessoryDetail> sampleResponseMonoBundle = Mono.just(sampleResponseBundle);
		Mono<RetrieveAccCartCXPResponse> sampleResponseMonoRetrieve = Mono.just(sampleResponseRetrieve);
		when(cxpService.retrieveBundleAccessories(Mockito.any())).thenReturn(sampleResponseMonoRetrieve);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		//when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.anyString())).thenReturn(Mono.just(Boolean.TRUE));
		BundleAccessoryDetail expectedResponse = sampleResponseBundle;
		Mono<BundleAccessoryDetail> response = helper.retrieveBundleAccessoryInfo(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
		.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}

	@Test
	public void populateRedirectionErrorTest() {
		StepVerifier.create(helper.populateRedirectionError()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(helper.populateRedirectionError()).assertNext(resp -> Assert.assertNotNull(resp.getErrors())).expectComplete().verify();
		StepVerifier.create(helper.populateRedirectionError()).assertNext(resp -> Assert.assertEquals("CartId or Case Id is not present in redis",
				resp.getErrors().get(0).getMessage())).expectComplete().verify();
	}
	//test cases for NSA
	//validateSecureToken
	@SuppressWarnings("unchecked")
	@Test
	public void validateSecureTokenHelperTest() throws IOException, SOEHTTPException {
		String requestString = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"prospectCartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processAction\":\"addAccessoryAndCheckout\",\"processStep\":\"AccessoryPDP\",\"intendType\":\"NSEACC\",\"pageId\":\"CART\",\"intent\":\"StandAloneAccessory\",\"cradleFlowJourney\":\"PromoHub\",\"action\":\"UPDATE\",\"itemType\":\"ACCESSORY\"}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGAgeneratedmessage\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\"]},{\"mtn\": \"2515813861\",\"completedprocessSteps\": []}],\"cartInfo\":{\"cartId\":\"a705f835-c61a-4e20-b616-0c9839202a15\"},\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"PromoHub\",\"availablePaths\":[{\"path\":\"PromoHub\"},{\"path\":\"MTNSelectionPage\"}],\"callReason\":\"SalesOrderPurchase\"}}}}}";
		ValidateSecureTokenRequest sampleRequest = mapper.readValue(requestString, ValidateSecureTokenRequest.class);
		DeviceSimValidationUIRequest sampleResponse = mapper.readValue(responseString, DeviceSimValidationUIRequest.class);
		when(cartIgHelper.validateSecureToken(Mockito.any())).thenReturn(sampleResponse);
		Assert.assertNotNull(helper.validateSecureToken(sampleRequest));
	}

	//test cases for NSA
	//retrieveActivationStatus
	@Test
	public void retrieveActivationStatusHelperTest() throws Exception {
	    ServerHttpRequest request = mock(ServerHttpRequest.class);
	    String requestString = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"prospectCartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processAction\":\"addAccessoryAndCheckout\",\"processStep\":\"AccessoryPDP\",\"intendType\":\"NSEACC\",\"pageId\":\"CART\",\"intent\":\"StandAloneAccessory\",\"cradleFlowJourney\":\"PromoHub\",\"action\":\"UPDATE\",\"itemType\":\"ACCESSORY\"}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGAgeneratedmessage\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\"]},{\"mtn\": \"2515813861\",\"completedprocessSteps\": []}],\"cartInfo\":{\"cartId\":\"a705f835-c61a-4e20-b616-0c9839202a15\"},\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"PromoHub\",\"availablePaths\":[{\"path\":\"PromoHub\"},{\"path\":\"MTNSelectionPage\"}],\"callReason\":\"SalesOrderPurchase\"}}}}}";
		RetrieveActivationStatusUIRequest sampleRequest = null;
		RetrieveActivationStatusUIResponse sampleResponse = null;
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRequest = mapper.readValue(requestString, RetrieveActivationStatusUIRequest.class);
		sampleResponse = mapper.readValue(responseString, RetrieveActivationStatusUIResponse.class);

		when(bpmHelper4.retrieveActivationStatus(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		RetrieveActivationStatusUIResponse expectedResponse = sampleResponse;
		Mono<RetrieveActivationStatusUIResponse> response = helper.retrieveActivationStatus(request,sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
		.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
		.verify();

	}

	//test cases for NSA
	//deviceSimValidation
	@Test
	public void deviceSimValidationHelperTest() throws Exception {
		ServerHttpRequest httpRequest = mock(ServerHttpRequest.class);
		String requestString = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"prospectCartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processAction\":\"addAccessoryAndCheckout\",\"processStep\":\"AccessoryPDP\",\"intendType\":\"NSEACC\",\"pageId\":\"CART\",\"intent\":\"StandAloneAccessory\",\"cradleFlowJourney\":\"PromoHub\",\"action\":\"UPDATE\",\"itemType\":\"ACCESSORY\"}}";
		DeviceSimValidationUIRequest sampleRequest = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
		when(cxpHelper2.deviceSimValidation(Mockito.any(), Mockito.any())).thenReturn((Mono.just(new DeviceSimValidationUIResponse())));
		Mono<DeviceSimValidationUIResponse> response = helper.deviceSimValidation(httpRequest, sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
		.verify();
	}

	@Test
	public void retrieveCartAbandonTest() throws Exception {
		RequestAccess reqAccess = new RequestAccess();
		reqAccess.getHeaders().add("cartId","69a66ef4d7e344dfb2db299209ea8333");
		RequestAccessContext.updateRequestData(reqAccess);
		String requestString = "{\"pageId\":\"cart\",\"flow\":\"EUP\"}";
		AbandonCartSOERequest request = new AbandonCartSOERequest();
		request = mapper.readValue(requestString,AbandonCartSOERequest.class);
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		Mono<RetrieveLatestDeviceCXPResponse> response = helper.retrieveCartAbandon(httpResponse,request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void retrieveCartHelperTest2() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"}}";
		String sampleResponseString = "{\"data\":{\"cart\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"flow\":\"EUP\",\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"status\":\"A\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"cartCreator\":\"4434541510\",\"cartCreatorOrderLocationCode\":\"E248201\",\"cartCreatorSalesRepId\":\"ENC\",\"creditApplicationNum\":\"388936130\",\"secondaryCreditApplicationNum\":0},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"customerType\":\"U\",\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"totalTaxAmount\":\"38.75\",\"spocs\":{\"notificationOptions\":{\"contactPhoneNumber\":\"1196120299\",\"primaryEmailId\":\"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"instantCreditAmount\":0.0,\"instantCreditAmountRemaining\":0.0,\"instantCreditEligible\":false,\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":388936130,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\":\"true\",\"creditAdvisory\":\"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\":\"0\",\"serviceClass\":\"B\",\"lineCreditClass\":\"\"},\"orderActivityType\":\"EUP\",\"orderNumber\":\"1112\"}],\"orderNumber\":0,\"outletId\":\"124632\",\"registerNumber\":0,\"saleType\":\"P\",\"salesRepId\":\"ENC\",\"totalInstantCreditAmount\":0.0,\"totalInstantCreditAmountUsed\":0.0,\"fiosAccountInfo\":{\"upSpeedInfo\":\"104M\"}},\"lineDetails\":{\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"mldTrunkMTN\":0,\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"zipCode4\":\"7848\"},\"isValidAddress\":true},\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"currentDevice\":{\"oldLteVoraEquipInfo\":{\"iccid\":\"89148000004671963398\",\"lteVoraDeviceInfo\":{\"deviceId\":\"352530085081859\",\"deviceType\":\"4GE\"}}},\"isSharePlanAdded\":false,\"edgeLine\":false,\"vlcLine\":false,\"isE911AddressValidated\":false,\"oldPlanFlag\":\"L\",\"orderDevice\":{\"lteVoraEquipInfo\":{\"lteEqpt\":{},\"lteVoraDeviceInfo\":{}}}},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"shippingCost\":\"0.0\",\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"isUseUnVerifiedAddress\":false,\"isValidAddress\":false},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"mobileNumber\":\"4434541510\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"groupDiscInd\":0,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-thumb$\"},\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"color\":{\"color\":\"#cfbea9\",\"colorDisplayName\":\"GOLD/PINKSAND\"},\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"discounts\":[],\"availableReasonCode\":[],\"inventory\":{\"isAvailable\":true,\"isBackorder\":false,\"isPreOrder\":false,\"qtyAvailable\":39437.0},\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"numberShareEligible\":\"true\",\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0}]},\"isPromoSelected\":false,\"isTradeInSelected\":false}],\"lineIdentifier\":0,\"itemSeqNum5GL\":0,\"itemSeqNum4GR\":0,\"lineExchangeTotal\":0.0,\"lineRefundTotal\":0.0,\"isCpe\":false,\"isDevicePlanCompatible\":false,\"portinMtnAssignment\":false,\"impactedLine\":false,\"preOrBackOrder\":false,\"ispuItem\":true,\"ispuItemBYOD\":false}],\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"numofLinesAAL\":0,\"numofLinesEUP\":0,\"validationMessages\":[],\"payments\":[],\"lineSeq\":0,\"vlcactivePhoneCount\":0,\"fivegOrderind\":false,\"aceOrderCreated\":false,\"serviceLinesCreated\":false,\"aceItemsModified\":false,\"clnrOrderFlag\":false,\"broadbandInd\":false,\"isPaperLessBilling\":\"false\"}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveCartCXPRequest sampleRequest = mapper.readValue(sampleRequestString, RetrieveCartCXPRequest.class);
		RetrieveCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, RetrieveCartUIResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\",\"repRole\": \"POS\",\"flowName\": \"EUP\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<RetrieveCartUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(cxpHelper.retrieveCart(Mockito.any())).thenReturn(sampleResponseMono);
		FiveGAddressRedisData sampleRedisData1 = mapper.readValue("{\"addressRequest\":{\"addressLine1\":\"680 WILDFLOWER DR\",\"addressLine2\":\"UNIT 710\",\"apartmentNo\":\"710\",\"city\":\"WILKES BARRE\",\"streetName\":\"WILDFLOWER\",\"streetNumber\":\"680\",\"streetType\":\"DR\",\"state\":\"PA\",\"zipCode\":\"18702\",\"zipCode4\":\"7929\",\"channel\":\"digital\",\"type\":\"all\",\"enableDebug\":false,\"enableCustomGQL\":false,\"eventCorrelationId\":\"18702_1732699479219_973\",\"scrubbedAddress\":{\"streetNumber\":\"680\",\"streetName\":\"WILDFLOWER\",\"streetType\":\"DR\",\"streetDirection\":\"\",\"addressLine2\":\"UNIT 710\",\"city\":\"WILKES BARRE\",\"state\":\"PA\",\"zipCode\":\"18702\",\"zipCodePlus4\":\"7929\",\"locationId\":\"400111709813\",\"baselocationId\":\"400052923913\"},\"streetDirection\":\"\",\"eligibilities\":{\"tanglewoodBundle\":[{\"bundleName\":\"VSHIProsetup\",\"id\":\"26730087\",\"type\":\"p\"}]},\"locationId\":\"400111709813\",\"baselocationId\":\"400052923913\",\"fwaLVThresholdLimitExceeded\":false,\"fiveGHomeQualified\":\"false\",\"LTEQualified\":false,\"cBandQualified\":false,\"tanglewoodQualified\":true}}",FiveGAddressRedisData.class);
		when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(sampleRedisData1));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.anyString())).thenReturn(Mono.just(Boolean.TRUE));
		when(redisHelper3.getConflictsStatusFromSession()).thenReturn(Mono.just(true));

		RetrieveCartUIResponse expectedResponse = sampleResponse;
		Mono<RetrieveCartUIResponse> response = helper.retrieveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}

	@Test
	public void retrieveCartHelperTest3() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"}}";
		String sampleResponseString = "{\"data\":{\"cart\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"status\":\"A\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"cartCreator\":\"4434541510\",\"cartCreatorOrderLocationCode\":\"E248201\",\"cartCreatorSalesRepId\":\"ENC\",\"creditApplicationNum\":\"388936130\",\"secondaryCreditApplicationNum\":0},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"customerType\":\"U\",\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"totalTaxAmount\":\"38.75\",\"spocs\":{\"notificationOptions\":{\"contactPhoneNumber\":\"1196120299\",\"primaryEmailId\":\"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"instantCreditAmount\":0.0,\"instantCreditAmountRemaining\":0.0,\"instantCreditEligible\":false,\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":388936130,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\":\"true\",\"creditAdvisory\":\"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\":\"0\",\"serviceClass\":\"B\",\"lineCreditClass\":\"\"},\"orderActivityType\":\"EUP\",\"orderNumber\":\"1112\"}],\"orderNumber\":0,\"outletId\":\"124632\",\"registerNumber\":0,\"saleType\":\"P\",\"salesRepId\":\"ENC\",\"totalInstantCreditAmount\":0.0,\"totalInstantCreditAmountUsed\":0.0,\"fiosAccountInfo\":{\"upSpeedInfo\":\"1024M\"}},\"lineDetails\":{\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"newPricePlanInfo\": {\"categoryCode\": \"80\"},\"mldTrunkMTN\":0,\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"zipCode4\":\"7848\"},\"isValidAddress\":true},\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"currentDevice\":{\"oldLteVoraEquipInfo\":{\"iccid\":\"89148000004671963398\",\"lteVoraDeviceInfo\":{\"deviceId\":\"352530085081859\",\"deviceType\":\"4GE\"}}},\"isSharePlanAdded\":false,\"edgeLine\":false,\"vlcLine\":false,\"isE911AddressValidated\":false,\"oldPlanFlag\":\"L\",\"orderDevice\":{\"lteVoraEquipInfo\":{\"lteEqpt\":{},\"lteVoraDeviceInfo\":{}}}},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"shippingCost\":\"0.0\",\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"isUseUnVerifiedAddress\":false,\"isValidAddress\":false},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"mobileNumber\":\"4434541510\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"groupDiscInd\":0,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-thumb$\"},\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"color\":{\"color\":\"#cfbea9\",\"colorDisplayName\":\"GOLD/PINKSAND\"},\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"discounts\":[],\"availableReasonCode\":[],\"inventory\":{\"isAvailable\":true,\"isBackorder\":false,\"isPreOrder\":false,\"qtyAvailable\":39437.0},\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"numberShareEligible\":\"true\",\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0}]},\"isPromoSelected\":false,\"isTradeInSelected\":false}],\"lineIdentifier\":0,\"itemSeqNum5GL\":0,\"itemSeqNum4GR\":0,\"lineExchangeTotal\":0.0,\"lineRefundTotal\":0.0,\"isCpe\":false,\"isDevicePlanCompatible\":false,\"portinMtnAssignment\":false,\"impactedLine\":false,\"preOrBackOrder\":false,\"ispuItem\":true,\"ispuItemBYOD\":false}],\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"numofLinesAAL\":0,\"numofLinesEUP\":0,\"validationMessages\":[],\"payments\":[],\"lineSeq\":0,\"vlcactivePhoneCount\":0,\"fivegOrderind\":false,\"aceOrderCreated\":false,\"serviceLinesCreated\":false,\"aceItemsModified\":false,\"clnrOrderFlag\":false,\"broadbandInd\":false,\"isPaperLessBilling\":\"false\"}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveCartCXPRequest sampleRequest = mapper.readValue(sampleRequestString, RetrieveCartCXPRequest.class);
		RetrieveCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, RetrieveCartUIResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\",\"flowName\": \"-\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<RetrieveCartUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(cxpHelper.retrieveCart(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(new FiveGAddressRedisData()));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.anyString())).thenReturn(Mono.just(Boolean.TRUE));
		when(redisHelper3.getConflictsStatusFromSession()).thenReturn(Mono.just(true));
		RetrieveCartUIResponse expectedResponse = sampleResponse;
		Mono<RetrieveCartUIResponse> response = helper.retrieveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}

	@Test
	public void retrieveCartHelperTest4() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"}}";
		String sampleResponseString = "{\"data\":{\"cart\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"status\":\"A\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"cartCreator\":\"4434541510\",\"cartCreatorOrderLocationCode\":\"E248201\",\"cartCreatorSalesRepId\":\"ENC\",\"creditApplicationNum\":\"388936130\",\"secondaryCreditApplicationNum\":0},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"customerType\":\"U\",\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"totalTaxAmount\":\"38.75\",\"spocs\":{\"notificationOptions\":{\"contactPhoneNumber\":\"1196120299\",\"primaryEmailId\":\"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"instantCreditAmount\":0.0,\"instantCreditAmountRemaining\":0.0,\"instantCreditEligible\":false,\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":388936130,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\":\"true\",\"creditAdvisory\":\"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\":\"0\",\"serviceClass\":\"B\",\"lineCreditClass\":\"\"},\"orderActivityType\":\"EUP\",\"orderNumber\":\"1112\"}],\"orderNumber\":0,\"outletId\":\"124632\",\"registerNumber\":0,\"saleType\":\"P\",\"salesRepId\":\"ENC\",\"totalInstantCreditAmount\":0.0,\"totalInstantCreditAmountUsed\":0.0,\"fiosAccountInfo\":{\"upSpeedInfo\":\"1024M\"}},\"lineDetails\":{\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"newPricePlanInfo\": null,\"mldTrunkMTN\":0,\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"zipCode4\":\"7848\"},\"isValidAddress\":true},\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"currentDevice\":{\"oldLteVoraEquipInfo\":{\"iccid\":\"89148000004671963398\",\"lteVoraDeviceInfo\":{\"deviceId\":\"352530085081859\",\"deviceType\":\"4GE\"}}},\"isSharePlanAdded\":false,\"edgeLine\":false,\"vlcLine\":false,\"isE911AddressValidated\":false,\"oldPlanFlag\":\"L\",\"orderDevice\":{\"lteVoraEquipInfo\":{\"lteEqpt\":{},\"lteVoraDeviceInfo\":{}}}},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"shippingCost\":\"0.0\",\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"isUseUnVerifiedAddress\":false,\"isValidAddress\":false},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"mobileNumber\":\"4434541510\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"groupDiscInd\":0,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-thumb$\"},\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"color\":{\"color\":\"#cfbea9\",\"colorDisplayName\":\"GOLD/PINKSAND\"},\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"discounts\":[],\"availableReasonCode\":[],\"inventory\":{\"isAvailable\":true,\"isBackorder\":false,\"isPreOrder\":false,\"qtyAvailable\":39437.0},\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"numberShareEligible\":\"true\",\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0}]},\"isPromoSelected\":false,\"isTradeInSelected\":false}],\"lineIdentifier\":0,\"itemSeqNum5GL\":0,\"itemSeqNum4GR\":0,\"lineExchangeTotal\":0.0,\"lineRefundTotal\":0.0,\"isCpe\":false,\"isDevicePlanCompatible\":false,\"portinMtnAssignment\":false,\"impactedLine\":false,\"preOrBackOrder\":false,\"ispuItem\":true,\"ispuItemBYOD\":false}],\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"numofLinesAAL\":0,\"numofLinesEUP\":0,\"validationMessages\":[],\"payments\":[],\"lineSeq\":0,\"vlcactivePhoneCount\":0,\"fivegOrderind\":false,\"aceOrderCreated\":false,\"serviceLinesCreated\":false,\"aceItemsModified\":false,\"clnrOrderFlag\":false,\"broadbandInd\":false,\"isPaperLessBilling\":\"false\"}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveCartCXPRequest sampleRequest = mapper.readValue(sampleRequestString, RetrieveCartCXPRequest.class);
		RetrieveCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, RetrieveCartUIResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<RetrieveCartUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(cxpHelper.retrieveCart(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(new FiveGAddressRedisData()));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.anyString())).thenReturn(Mono.just(Boolean.TRUE));
		when(redisHelper3.getConflictsStatusFromSession()).thenReturn(Mono.just(true));
		RetrieveCartUIResponse expectedResponse = sampleResponse;
		Mono<RetrieveCartUIResponse> response = helper.retrieveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}

	@Test
	public void retrieveCartHelperTest5() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"}}";
		String sampleResponseString = "{\"data\":{\"cart\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"status\":\"A\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"cartCreator\":\"4434541510\",\"cartCreatorOrderLocationCode\":\"E248201\",\"cartCreatorSalesRepId\":\"ENC\",\"creditApplicationNum\":\"388936130\",\"secondaryCreditApplicationNum\":0},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"customerType\":\"U\",\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"totalTaxAmount\":\"38.75\",\"spocs\":{\"notificationOptions\":{\"contactPhoneNumber\":\"1196120299\",\"primaryEmailId\":\"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"instantCreditAmount\":0.0,\"instantCreditAmountRemaining\":0.0,\"instantCreditEligible\":false,\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":388936130,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\":\"true\",\"creditAdvisory\":\"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\":\"0\",\"serviceClass\":\"B\",\"lineCreditClass\":\"\"},\"orderActivityType\":\"EUP\",\"orderNumber\":\"1112\"}],\"orderNumber\":0,\"outletId\":\"124632\",\"registerNumber\":0,\"saleType\":\"P\",\"salesRepId\":\"ENC\",\"totalInstantCreditAmount\":0.0,\"totalInstantCreditAmountUsed\":0.0,\"fiosAccountInfo\":{\"upSpeedInfo\":\"1024M\"}},\"lineDetails\":{\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"shippingCost\":\"0.0\",\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"isUseUnVerifiedAddress\":false,\"isValidAddress\":false},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"mobileNumber\":\"4434541510\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"groupDiscInd\":0,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-thumb$\"},\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"color\":{\"color\":\"#cfbea9\",\"colorDisplayName\":\"GOLD/PINKSAND\"},\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"discounts\":[],\"availableReasonCode\":[],\"inventory\":{\"isAvailable\":true,\"isBackorder\":false,\"isPreOrder\":false,\"qtyAvailable\":39437.0},\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"numberShareEligible\":\"true\",\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0}]},\"isPromoSelected\":false,\"isTradeInSelected\":false}],\"lineIdentifier\":0,\"itemSeqNum5GL\":0,\"itemSeqNum4GR\":0,\"lineExchangeTotal\":0.0,\"lineRefundTotal\":0.0,\"isCpe\":false,\"isDevicePlanCompatible\":false,\"portinMtnAssignment\":false,\"impactedLine\":false,\"preOrBackOrder\":false,\"ispuItem\":true,\"ispuItemBYOD\":false}],\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"numofLinesAAL\":0,\"numofLinesEUP\":0,\"validationMessages\":[],\"payments\":[],\"lineSeq\":0,\"vlcactivePhoneCount\":0,\"fivegOrderind\":false,\"aceOrderCreated\":false,\"serviceLinesCreated\":false,\"aceItemsModified\":false,\"clnrOrderFlag\":false,\"broadbandInd\":false,\"isPaperLessBilling\":\"false\"}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveCartCXPRequest sampleRequest = mapper.readValue(sampleRequestString, RetrieveCartCXPRequest.class);
		RetrieveCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, RetrieveCartUIResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<RetrieveCartUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(cxpHelper.retrieveCart(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(new FiveGAddressRedisData()));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.anyString())).thenReturn(Mono.just(Boolean.TRUE));
		when(redisHelper3.getConflictsStatusFromSession()).thenReturn(Mono.just(true));
		RetrieveCartUIResponse expectedResponse = sampleResponse;
		Mono<RetrieveCartUIResponse> response = helper.retrieveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}

	@Test
	public void retrieveCartHelperTest6() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"}}";
		String sampleResponseString = "{\"data\": {\"cart\": {\"cartId\": \"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"cartHeader\": {\"sourceSystem\": \"CXP\",\"cartId\": \"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\": \"0225597159-1\",\"userId\": \"kumasa1\",\"customFit\": false,\"status\": \"A\",\"lastAccessSystem\": \"CXP\",\"createTimestamp\": \"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\": \"2019-11-20T11:09:41.549Z\",\"cartCreator\": \"4434541510\",\"cartCreatorOrderLocationCode\": \"E248201\",\"cartCreatorSalesRepId\": \"ENC\",\"creditApplicationNum\": \"388936130\",\"secondaryCreditApplicationNum\": 0},\"orderDetails\": {\"orderType\": \"PS\",\"locationCode\": \"E248201\",\"customerType\": \"U\",\"billingSystem\": \"CXP\",\"linkApplicationNum\": 0,\"prepayApplicationNum\": 0,\"totalTaxAmount\": \"38.75\",\"spocs\": {\"notificationOptions\": {\"contactPhoneNumber\": \"1196120299\",\"primaryEmailId\": \"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\": 538.74,\"totalDueMonthly\": 0.0,\"subTotalDueMonthly\": 0.0,\"subTotalMonthlyTaxes\": 0.0,\"subTotalOtherLines\": 0.0,\"subTotalOtherLinesTaxes\": 0.0,\"instantDRCCredit\": false,\"managerApprovalRequired\": false,\"isAttachmentCompleted\": false,\"nextMonthBillTotal\": 0.0,\"barCodes\": [],\"instantCreditAmount\": 0.0,\"instantCreditAmountRemaining\": 0.0,\"instantCreditEligible\": false,\"orderList\": [{\"creditApplication\": {\"creditApplicationNum\": 388936130,\"creditApprovalStatus\": \"AP\",\"creditStatusReason\": \"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\": \"true\",\"creditAdvisory\": \"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\": \"0\",\"serviceClass\": \"B\",\"lineCreditClass\": \"\"},\"orderActivityType\": \"EUP\",\"orderNumber\": \"1112\"}],\"orderNumber\": 0,\"outletId\": \"124632\",\"registerNumber\": 0,\"saleType\": \"P\",\"salesRepId\": \"ENC\",\"totalInstantCreditAmount\": 0.0,\"totalInstantCreditAmountUsed\": 0.0,\"fiosAccountInfo\": {\"upSpeedInfo\": \"1024M\"}},\"lineDetails\": {\"lineInfo\": null,\"cartId\": \"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\": 1,\"numofLinesAAL\": 0,\"numofLinesEUP\": 0,\"validationMessages\": [],\"payments\": [],\"lineSeq\": 0,\"vlcactivePhoneCount\": 0,\"fivegOrderind\": false,\"aceOrderCreated\": false,\"serviceLinesCreated\": false,\"aceItemsModified\": false,\"clnrOrderFlag\": false,\"broadbandInd\": false,\"isPaperLessBilling\": \"false\"}}},\"meta\": {\"timestamp\": \"1576761387264\",\"cxpCorrelationId\": \"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveCartCXPRequest sampleRequest = mapper.readValue(sampleRequestString, RetrieveCartCXPRequest.class);
		RetrieveCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, RetrieveCartUIResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<RetrieveCartUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(cxpHelper.retrieveCart(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(new FiveGAddressRedisData()));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.anyString())).thenReturn(Mono.just(Boolean.TRUE));
		when(redisHelper3.getConflictsStatusFromSession()).thenReturn(Mono.just(true));
		RetrieveCartUIResponse expectedResponse = sampleResponse;
		Mono<RetrieveCartUIResponse> response = helper.retrieveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}

	@Test
	public void retrieveCartHelperTest7() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"}}";
		String sampleResponseString = "{\"data\": {\"cart\": {\"cartId\": \"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"cartHeader\": {\"sourceSystem\": \"CXP\",\"cartId\": \"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\": \"0225597159-1\",\"userId\": \"kumasa1\",\"customFit\": false,\"status\": \"A\",\"lastAccessSystem\": \"CXP\",\"createTimestamp\": \"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\": \"2019-11-20T11:09:41.549Z\",\"cartCreator\": \"4434541510\",\"cartCreatorOrderLocationCode\": \"E248201\",\"cartCreatorSalesRepId\": \"ENC\",\"creditApplicationNum\": \"388936130\",\"secondaryCreditApplicationNum\": 0},\"orderDetails\": {\"orderType\": \"PS\",\"locationCode\": \"E248201\",\"customerType\": \"U\",\"billingSystem\": \"CXP\",\"linkApplicationNum\": 0,\"prepayApplicationNum\": 0,\"totalTaxAmount\": \"38.75\",\"spocs\": {\"notificationOptions\": {\"contactPhoneNumber\": \"1196120299\",\"primaryEmailId\": \"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\": 538.74,\"totalDueMonthly\": 0.0,\"subTotalDueMonthly\": 0.0,\"subTotalMonthlyTaxes\": 0.0,\"subTotalOtherLines\": 0.0,\"subTotalOtherLinesTaxes\": 0.0,\"instantDRCCredit\": false,\"managerApprovalRequired\": false,\"isAttachmentCompleted\": false,\"nextMonthBillTotal\": 0.0,\"barCodes\": [],\"instantCreditAmount\": 0.0,\"instantCreditAmountRemaining\": 0.0,\"instantCreditEligible\": false,\"orderList\": [{\"creditApplication\": {\"creditApplicationNum\": 388936130,\"creditApprovalStatus\": \"AP\",\"creditStatusReason\": \"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\": \"true\",\"creditAdvisory\": \"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\": \"0\",\"serviceClass\": \"B\",\"lineCreditClass\": \"\"},\"orderActivityType\": \"EUP\",\"orderNumber\": \"1112\"}],\"orderNumber\": 0,\"outletId\": \"124632\",\"registerNumber\": 0,\"saleType\": \"P\",\"salesRepId\": \"ENC\",\"totalInstantCreditAmount\": 0.0,\"totalInstantCreditAmountUsed\": 0.0,\"fiosAccountInfo\": {\"upSpeedInfo\": \"1024M\"}},\"lineDetails\": null}},\"meta\": {\"timestamp\": \"1576761387264\",\"cxpCorrelationId\": \"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveCartCXPRequest sampleRequest = mapper.readValue(sampleRequestString, RetrieveCartCXPRequest.class);
		RetrieveCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, RetrieveCartUIResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<RetrieveCartUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(cxpHelper.retrieveCart(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(new FiveGAddressRedisData()));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.anyString())).thenReturn(Mono.just(Boolean.TRUE));
		when(redisHelper3.getConflictsStatusFromSession()).thenReturn(Mono.just(true));
		RetrieveCartUIResponse expectedResponse = sampleResponse;
		Mono<RetrieveCartUIResponse> response = helper.retrieveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}

	@Test
	public void retrieveCartHelperTest8() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"}}";
		String sampleResponseString = "{\"data\": {\"cart\": {\"cartId\": \"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"cartHeader\": {\"sourceSystem\": \"CXP\",\"cartId\": \"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\": \"0225597159-1\",\"userId\": \"kumasa1\",\"customFit\": false,\"status\": \"A\",\"lastAccessSystem\": \"CXP\",\"createTimestamp\": \"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\": \"2019-11-20T11:09:41.549Z\",\"cartCreator\": \"4434541510\",\"cartCreatorOrderLocationCode\": \"E248201\",\"cartCreatorSalesRepId\": \"ENC\",\"creditApplicationNum\": \"388936130\",\"secondaryCreditApplicationNum\": 0},\"orderDetails\": {\"orderType\": \"PS\",\"locationCode\": \"E248201\",\"customerType\": \"U\",\"billingSystem\": \"CXP\",\"linkApplicationNum\": 0,\"prepayApplicationNum\": 0,\"totalTaxAmount\": \"38.75\",\"spocs\": {\"notificationOptions\": {\"contactPhoneNumber\": \"1196120299\",\"primaryEmailId\": \"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\": 538.74,\"totalDueMonthly\": 0.0,\"subTotalDueMonthly\": 0.0,\"subTotalMonthlyTaxes\": 0.0,\"subTotalOtherLines\": 0.0,\"subTotalOtherLinesTaxes\": 0.0,\"instantDRCCredit\": false,\"managerApprovalRequired\": false,\"isAttachmentCompleted\": false,\"nextMonthBillTotal\": 0.0,\"barCodes\": [],\"instantCreditAmount\": 0.0,\"instantCreditAmountRemaining\": 0.0,\"instantCreditEligible\": false,\"orderList\": [{\"creditApplication\": {\"creditApplicationNum\": 388936130,\"creditApprovalStatus\": \"AP\",\"creditStatusReason\": \"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\": \"true\",\"creditAdvisory\": \"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\": \"0\",\"serviceClass\": \"B\",\"lineCreditClass\": \"\"},\"orderActivityType\": \"EUP\",\"orderNumber\": \"1112\"}],\"orderNumber\": 0,\"outletId\": \"124632\",\"registerNumber\": 0,\"saleType\": \"P\",\"salesRepId\": \"ENC\",\"totalInstantCreditAmount\": 0.0,\"totalInstantCreditAmountUsed\": 0.0,\"fiosAccountInfo\": {\"upSpeedInfo\": \"1024M\"}},\"lineDetails\": {\"lineInfo\": [],\"cartId\": \"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\": 1,\"numofLinesAAL\": 0,\"numofLinesEUP\": 0,\"validationMessages\": [],\"payments\": [],\"lineSeq\": 0,\"vlcactivePhoneCount\": 0,\"fivegOrderind\": false,\"aceOrderCreated\": false,\"serviceLinesCreated\": false,\"aceItemsModified\": false,\"clnrOrderFlag\": false,\"broadbandInd\": false,\"isPaperLessBilling\": \"false\"}}},\"meta\": {\"timestamp\": \"1576761387264\",\"cxpCorrelationId\": \"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveCartCXPRequest sampleRequest = mapper.readValue(sampleRequestString, RetrieveCartCXPRequest.class);
		RetrieveCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, RetrieveCartUIResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<RetrieveCartUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(cxpHelper.retrieveCart(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(new FiveGAddressRedisData()));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.anyString())).thenReturn(Mono.just(Boolean.TRUE));
		when(redisHelper3.getConflictsStatusFromSession()).thenReturn(Mono.just(true));
		RetrieveCartUIResponse expectedResponse = sampleResponse;
		Mono<RetrieveCartUIResponse> response = helper.retrieveCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}
	
	@Test
	public void deviceIdValidationTest() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT-TAB\",\"cartInfo\": {\"intendType\": \"BYOD\",\"cartCreator\": \"7039159592\",\"clientAppName\": \"VZW-MFA\",\"cartId\": \"4b207c97-6278-4562-9e41-b6411763bcd6\",\"caseId\": \"SOP-947715-E01\",\"processingMTN\": \"\",\"accountNumber\": \"0201430224-00001\",\"intent\": \"BYOD\",\"processStep\": \"BYODLandingPage\",\"processAction\": \"validatedevicesim\"},\"data\": {\"lines\": [{\"mtn\": \"\",\"device\": {\"id\": \"353338070105553\",\"Flowtype\": \"DEVICE\",\"CurrentId\": \"\",\"isCustomerProvidedEquipment\": true,\"sku\": \"\",\"smartIMEI\": true,\"searchAttributes\": {\"postpaidRestrictStartDate\": \"2018-07-01T04:00:00.000Z\",\"prodCode\": \"LTE\",\"hdVoiceInd\": true,\"deviceType\": \"4GE\",\"dacc\": \"00854\"},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": \"\"}}}]}}";
		String sampleResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"deviceInfo\": {\"simInfo\": {},\"makeEtniPersApi\": true,\"imei2\": \"imei\"},\"caseId\": \"SPA-1589374-DEV3\"}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationUIResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"creditAppNum\": \"8436667390\" }";
		sampleRequest.getCartInfo().setFlexV2(true);
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<DeviceIdValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.deviceIdValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cxpHelper.getSmartImeiDevices(Mockito.anyString(),Mockito.anyString())).thenReturn(Mono.just(getSmartImeiDevicesResponse()));
		DeviceIdValidationUIResponse expectedResponse = sampleResponse;
		Mono<DeviceIdValidationUIResponse> response = helper.deviceIdValidation(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
		sampleRequest.getCartInfo().setIntendType("random");
		StepVerifier.create(helper.deviceIdValidation(sampleRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		sampleRequest.getCartInfo().setIntendType(CartConstants.BYOD);
		StepVerifier.create(helper.deviceIdValidation(sampleRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		sampleRequest.getCartInfo().setIntendType(CartConstants.EUPBYOD);
		StepVerifier.create(helper.deviceIdValidation(sampleRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		sampleRequest.getData().getLines().get(0).getDevice().getSim().setCurrentSimid(null);
		StepVerifier.create(helper.deviceIdValidation(sampleRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		sampleRequest.getData().getLines().get(0).getDevice().setSim(null);
		StepVerifier.create(helper.deviceIdValidation(sampleRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		sampleRequest.getData().getLines().get(0).setDevice(null);
		StepVerifier.create(helper.deviceIdValidation(sampleRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectError();
		ArrayList arr = new ArrayList<DeviceIdValidationLine>();
		DeviceIdValidationLine line  = new DeviceIdValidationLine();
		arr.add(0, line);
		sampleRequest.getData().setLines(arr);
		StepVerifier.create(helper.deviceIdValidation(sampleRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectError();
		sampleRequest.getData().setLines(null);
		StepVerifier.create(helper.deviceIdValidation(sampleRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectError();
		sampleRequest.setData(null);
		StepVerifier.create(helper.deviceIdValidation(sampleRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectError();
		sampleRequest.getCartInfo().setIntendType("random");
		StepVerifier.create(helper.deviceIdValidation(sampleRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectError();
	}
	
	@Test
	public void deviceIdValidationTest2() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\":\"OMNI-CARE\",\"cartInfo\": {\"cartCreator\": \"7039159592\",\"clientAppName\": \"VZW-MFA\",\"cartId\": \"4b207c97-6278-4562-9e41-b6411763bcd6\",\"caseId\": \"SOP-947715-E01\",\"processingMTN\": \"\",\"accountNumber\": \"0201430224-00001\",\"intent\": \"BYOD\",\"processStep\": \"BYODLandingPage\",\"processAction\": \"validatedevicesim\"},\"data\": {\"lines\": [{\"mtn\": \"\",\"device\": {\"id\": \"353338070105553\",\"Flowtype\": \"DEVICE\",\"CurrentId\": \"\",\"isCustomerProvidedEquipment\": true,\"sku\": \"\",\"smartIMEI\": true,\"searchAttributes\": {\"postpaidRestrictStartDate\": \"2018-07-01T04:00:00.000Z\",\"prodCode\": \"LTE\",\"hdVoiceInd\": true,\"deviceType\": \"4GE\",\"dacc\": \"00854\"},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": \"\"}}}]}}";
		String sampleResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseId\": \"SPA-1589374-DEV3\"}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationUIResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"creditAppNum\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(cxpHelper.getSmartImeiDevices(Mockito.anyString(),Mockito.anyString())).thenReturn(Mono.just(getSmartImeiDevicesResponse()));
		Mono<DeviceIdValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.deviceIdValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		DeviceIdValidationUIResponse expectedResponse = sampleResponse;
		Mono<DeviceIdValidationUIResponse> response = helper.deviceIdValidation(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
	}
	
	@Test
	public void deviceIdValidationTest3() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\":\"OMNI-RETAIL-TAB\",\"cartInfo\": {\"intendType\": \"EUP\",\"cartCreator\": \"7039159592\",\"clientAppName\": \"VZW-MFA\",\"cartId\": \"4b207c97-6278-4562-9e41-b6411763bcd6\",\"caseId\": \"SOP-947715-E01\",\"processingMTN\": \"\",\"accountNumber\": \"0201430224-00001\",\"intent\": \"BYOD\",\"processStep\": \"BYODLandingPage\",\"processAction\": \"validatedevicesim\"},\"data\": {\"lines\": [{\"mtn\": \"\",\"device\": {\"id\": \"353338070105553\",\"Flowtype\": \"DEVICE\",\"CurrentId\": \"\",\"isCustomerProvidedEquipment\": true,\"sku\": \"\",\"smartIMEI\": true,\"searchAttributes\": {\"postpaidRestrictStartDate\": \"2018-07-01T04:00:00.000Z\",\"prodCode\": \"LTE\",\"hdVoiceInd\": true,\"deviceType\": \"4GE\",\"dacc\": \"00854\"},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": \"\"}}}]}}";
		String sampleResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"deviceInfo\": {\"makeEtniPersApi\": true,\"simInfo\": {},\"imei2\": \"imei\",\"simClass4G\": \"simClass4G\"},\"caseId\": \"SPA-1589374-DEV3\"}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationUIResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"creditAppNum\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<DeviceIdValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.deviceIdValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cxpHelper.getSmartImeiDevices(Mockito.anyString(),Mockito.anyString())).thenReturn(Mono.just(getSmartImeiDevicesResponse()));
		DeviceIdValidationUIResponse expectedResponse = sampleResponse;
		Mono<DeviceIdValidationUIResponse> response = helper.deviceIdValidation(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
	}
	
	@Test
	public void deviceIdValidationTest4() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\":\"OMNI-RETAIL-TAB\",\"cartInfo\": {\"intendType\": \"EUP\",\"cartCreator\": \"7039159592\",\"clientAppName\": \"VZW-MFA\",\"cartId\": \"4b207c97-6278-4562-9e41-b6411763bcd6\",\"caseId\": \"SOP-947715-E01\",\"processingMTN\": \"\",\"accountNumber\": \"0201430224-00001\",\"intent\": \"BYOD\",\"processStep\": \"BYODLandingPage\",\"processAction\": \"validatedevicesim\"},\"data\": {\"lines\": [{\"mtn\": \"\",\"device\": {\"id\": \"353338070105553\",\"Flowtype\": \"DEVICE\",\"CurrentId\": \"\",\"isCustomerProvidedEquipment\": true,\"sku\": \"\",\"smartIMEI\": true,\"searchAttributes\": {\"postpaidRestrictStartDate\": \"2018-07-01T04:00:00.000Z\",\"prodCode\": \"LTE\",\"hdVoiceInd\": true,\"deviceType\": \"4GE\",\"dacc\": \"00854\"},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": \"\"}}}]}}";
		String sampleResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"deviceInfo\": {\"makeEtniPersApi\": true,\"simInfo\": {},\"imei2\": \"imei\",\"simClass4G\": \"\"},\"caseId\": \"SPA-1589374-DEV3\"}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationUIResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"creditAppNum\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<DeviceIdValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.deviceIdValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		DeviceIdValidationUIResponse expectedResponse = sampleResponse;
		when(cxpHelper.getSmartImeiDevices(Mockito.anyString(),Mockito.anyString())).thenReturn(Mono.just(getSmartImeiDevicesResponse()));
		Mono<DeviceIdValidationUIResponse> response = helper.deviceIdValidation(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
	}
	
	@Test
	public void retrieveBundleAccessoryInfoHelperTest2() throws IOException, SOEHTTPException {
		
		String sampleRequestString = "{\"channelId\":\"VZW-DOTCOM\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"}}";
		String sampleResponseString = "{\"data\":{\"cart\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"status\":\"A\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"cartCreator\":\"4434541510\",\"cartCreatorOrderLocationCode\":\"E248201\",\"cartCreatorSalesRepId\":\"ENC\",\"creditApplicationNum\":\"388936130\",\"secondaryCreditApplicationNum\":0},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"customerType\":\"U\",\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"totalTaxAmount\":\"38.75\",\"spocs\":{\"notificationOptions\":{\"contactPhoneNumber\":\"1196120299\",\"primaryEmailId\":\"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"instantCreditAmount\":0.0,\"instantCreditAmountRemaining\":0.0,\"instantCreditEligible\":false,\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":388936130,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\":\"true\",\"creditAdvisory\":\"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\":\"0\",\"serviceClass\":\"B\",\"lineCreditClass\":\"\"},\"orderActivityType\":\"EUP\",\"orderNumber\":\"1112\"}],\"orderNumber\":0,\"outletId\":\"124632\",\"registerNumber\":0,\"saleType\":\"P\",\"salesRepId\":\"ENC\",\"totalInstantCreditAmount\":0.0,\"totalInstantCreditAmountUsed\":0.0},\"lineDetails\":{\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"mldTrunkMTN\":0,\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"zipCode4\":\"7848\"},\"isValidAddress\":true},\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"currentDevice\":{\"oldLteVoraEquipInfo\":{\"iccid\":\"89148000004671963398\",\"lteVoraDeviceInfo\":{\"deviceId\":\"352530085081859\",\"deviceType\":\"4GE\"}}},\"isSharePlanAdded\":false,\"edgeLine\":false,\"vlcLine\":false,\"isE911AddressValidated\":false,\"oldPlanFlag\":\"L\",\"orderDevice\":{\"lteVoraEquipInfo\":{\"lteEqpt\":{},\"lteVoraDeviceInfo\":{}}}},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"shippingCost\":\"0.0\",\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"isUseUnVerifiedAddress\":false,\"isValidAddress\":false},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"mobileNumber\":\"4434541510\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"groupDiscInd\":0,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-thumb$\"},\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"color\":{\"color\":\"#cfbea9\",\"colorDisplayName\":\"GOLD/PINKSAND\"},\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"discounts\":[],\"availableReasonCode\":[],\"inventory\":{\"isAvailable\":true,\"isBackorder\":false,\"isPreOrder\":false,\"qtyAvailable\":39437.0},\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"numberShareEligible\":\"true\",\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0}]},\"isPromoSelected\":false,\"isTradeInSelected\":false}],\"lineIdentifier\":0,\"itemSeqNum5GL\":0,\"itemSeqNum4GR\":0,\"lineExchangeTotal\":0.0,\"lineRefundTotal\":0.0,\"isCpe\":false,\"isDevicePlanCompatible\":false,\"portinMtnAssignment\":false,\"impactedLine\":false,\"preOrBackOrder\":false,\"ispuItem\":true,\"ispuItemBYOD\":false}],\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"numofLinesAAL\":0,\"numofLinesEUP\":0,\"validationMessages\":[],\"payments\":[],\"lineSeq\":0,\"vlcactivePhoneCount\":0,\"fivegOrderind\":false,\"aceOrderCreated\":false,\"serviceLinesCreated\":false,\"aceItemsModified\":false,\"clnrOrderFlag\":false,\"broadbandInd\":false,\"isPaperLessBilling\":\"false\"}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveBundleAccRequest sampleRequest = mapper.readValue(sampleRequestString, RetrieveBundleAccRequest.class);
		BundleAccessoryDetail sampleResponseBundle = mapper.readValue(sampleResponseString, BundleAccessoryDetail.class);
		RetrieveAccCartCXPResponse sampleResponseRetrieve = mapper.readValue(sampleResponseString, RetrieveAccCartCXPResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<RetrieveAccCartCXPResponse> sampleResponseMonoRetrieve = Mono.just(sampleResponseRetrieve);
		when(cxpService.retrieveBundleAccessories(Mockito.any())).thenReturn(sampleResponseMonoRetrieve);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		BundleAccessoryDetail expectedResponse = sampleResponseBundle;
		Mono<BundleAccessoryDetail> response = helper.retrieveBundleAccessoryInfo(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
		.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify(); 
	}
	
	@Test
	public void retrieveBundleAccessoryInfoHelperTest3() throws IOException, SOEHTTPException {
		
		String sampleRequestString = "{\"channelId\":\"VZW-DOTCOM\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"}}";
		String sampleResponseString = "{\"data\":{\"cart\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"status\":\"A\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"cartCreator\":\"4434541510\",\"cartCreatorOrderLocationCode\":\"E248201\",\"cartCreatorSalesRepId\":\"ENC\",\"creditApplicationNum\":\"388936130\",\"secondaryCreditApplicationNum\":0},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"customerType\":\"U\",\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"totalTaxAmount\":\"38.75\",\"spocs\":{\"notificationOptions\":{\"contactPhoneNumber\":\"1196120299\",\"primaryEmailId\":\"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"instantCreditAmount\":0.0,\"instantCreditAmountRemaining\":0.0,\"instantCreditEligible\":false,\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":388936130,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\":\"true\",\"creditAdvisory\":\"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\":\"0\",\"serviceClass\":\"B\",\"lineCreditClass\":\"\"},\"orderActivityType\":\"EUP\",\"orderNumber\":\"1112\"}],\"orderNumber\":0,\"outletId\":\"124632\",\"registerNumber\":0,\"saleType\":\"P\",\"salesRepId\":\"ENC\",\"totalInstantCreditAmount\":0.0,\"totalInstantCreditAmountUsed\":0.0},\"lineDetails\":{\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"mldTrunkMTN\":0,\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"zipCode4\":\"7848\"},\"isValidAddress\":true},\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"currentDevice\":{\"oldLteVoraEquipInfo\":{\"iccid\":\"89148000004671963398\",\"lteVoraDeviceInfo\":{\"deviceId\":\"352530085081859\",\"deviceType\":\"4GE\"}}},\"isSharePlanAdded\":false,\"edgeLine\":false,\"vlcLine\":false,\"isE911AddressValidated\":false,\"oldPlanFlag\":\"L\",\"orderDevice\":{\"lteVoraEquipInfo\":{\"lteEqpt\":{},\"lteVoraDeviceInfo\":{}}}},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"shippingCost\":\"0.0\",\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"isUseUnVerifiedAddress\":false,\"isValidAddress\":false},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"mobileNumber\":\"4434541510\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"groupDiscInd\":0,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-thumb$\"},\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"color\":{\"color\":\"#cfbea9\",\"colorDisplayName\":\"GOLD/PINKSAND\"},\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"discounts\":[],\"availableReasonCode\":[],\"inventory\":{\"isAvailable\":true,\"isBackorder\":false,\"isPreOrder\":false,\"qtyAvailable\":39437.0},\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"numberShareEligible\":\"true\",\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0}]},\"isPromoSelected\":false,\"isTradeInSelected\":false}],\"lineIdentifier\":0,\"itemSeqNum5GL\":0,\"itemSeqNum4GR\":0,\"lineExchangeTotal\":0.0,\"lineRefundTotal\":0.0,\"isCpe\":false,\"isDevicePlanCompatible\":false,\"portinMtnAssignment\":false,\"impactedLine\":false,\"preOrBackOrder\":false,\"ispuItem\":true,\"ispuItemBYOD\":false}],\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"numofLinesAAL\":0,\"numofLinesEUP\":0,\"validationMessages\":[],\"payments\":[],\"lineSeq\":0,\"vlcactivePhoneCount\":0,\"fivegOrderind\":false,\"aceOrderCreated\":false,\"serviceLinesCreated\":false,\"aceItemsModified\":false,\"clnrOrderFlag\":false,\"broadbandInd\":false,\"isPaperLessBilling\":\"false\"}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveBundleAccRequest sampleRequest = mapper.readValue(sampleRequestString, RetrieveBundleAccRequest.class);
		RetrieveAccCartCXPResponse sampleResponseRetrieve = mapper.readValue(sampleResponseString, RetrieveAccCartCXPResponse.class);
		String redisDataString = "{ \"cartId\": \"\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<RetrieveAccCartCXPResponse> sampleResponseMonoRetrieve = Mono.just(sampleResponseRetrieve);
		when(cxpService.retrieveBundleAccessories(Mockito.any())).thenReturn(sampleResponseMonoRetrieve);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		Mono<BundleAccessoryDetail> response = helper.retrieveBundleAccessoryInfo(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
		.verify();
	}
	
	@Test
	public void retrieveCartAbandonTest2() throws Exception {
		RequestAccess reqAccess = new RequestAccess();
		reqAccess.getCookies().add("acid", new HttpCookie("cartId", "cartId"));
		RequestAccessContext.updateRequestData(reqAccess);
		String requestString = "{\"pageId\":\"cart\",\"flow\":\"EUP\"}";
		AbandonCartSOERequest request = mapper.readValue(requestString,AbandonCartSOERequest.class);
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cxpService.retrieveLatestDevice(Mockito.any(), Mockito.eq(request.getPageId()))).thenReturn(Mono.just(new RetrieveLatestDeviceCXPResponse()));
		Mono<RetrieveLatestDeviceCXPResponse> response = helper.retrieveCartAbandon(httpResponse,request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void checkExistingCartFromPegaHelperTest1() throws IOException {
		
		String requestString = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"prospectCartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processAction\":\"addAccessoryAndCheckout\",\"processStep\":\"AccessoryPDP\",\"intendType\":\"NSEACC\",\"pageId\":\"CART\",\"intent\":\"StandAloneAccessory\",\"cradleFlowJourney\":\"PromoHub\",\"action\":\"UPDATE\",\"itemType\":\"ACCESSORY\"}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGAgeneratedmessage\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\"]},{\"mtn\": \"2515813861\",\"completedprocessSteps\": []}],\"cartInfo\":{\"cartId\":\"a705f835-c61a-4e20-b616-0c9839202a15\"},\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"PromoHub\",\"availablePaths\":[{\"path\":\"PromoHub\"},{\"path\":\"MTNSelectionPage\"}],\"callReason\":\"SalesOrderPurchase\"}}}}}";
		CheckExistingCartUIRequest sampleRequest = null;
		CheckExistingCartUIResponse sampleResponse = null;
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"vzwRoles\":\"ENC\",\"caseId\": \"SOP-538499-E01\",\"prospectCartId\":\"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"processingMTN\":null, \"cartCreator\": null, \"accountNumber\": null, \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRequest = mapper.readValue(requestString, CheckExistingCartUIRequest.class);
		sampleResponse = mapper.readValue(responseString, CheckExistingCartUIResponse.class);
		when(bpmHelper4.checkExistingCart(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		CheckExistingCartUIResponse expectedResponse = sampleResponse;
		Mono<CheckExistingCartUIResponse> response = helper.checkExistingCartFromPega(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
	}
	
	@Test
	public void guestChoiceFromPegaHelperTest1() throws IOException {
		
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"ShoppingCart\",\"processAction\":\"checkOut\",\"intendType\":\"NSEACC\",\"intent\":\"StandAloneAccessory\",\"editAccessory\":false,\"expressflowForAcc\":false,\"mtnFlow\":\"D\",\"globalId\":\"\",\"customerType\":\"N\",\"zipCode\":\"76092\"}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.07.25.09.12.35-726.9785488871123\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"SignInOrderReview\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"SignInOrderReview\"},{\"path\":\"SignIn\"},{\"path\":\"GuestCheckOut\"}]},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-D-8318ca25-ecc7-40a1-8945-11e4d3cf87fb\",\"processingMTN\":\"9999999999\",\"registerNumber\":0},\"cartInfo\":{}}}}}";
		GuestChoiceUIRequest sampleRequest =  null;
		GuestChoiceUIResponse sampleResponse =  null;
		sampleRequest = mapper.readValue(requestString, GuestChoiceUIRequest.class);
		sampleResponse = mapper.readValue(responseString, GuestChoiceUIResponse.class);
		Mono<GuestChoiceUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"vzwRoles\":\"ENC\",\"caseId\": \"SOP-538499-E01\",\"prospectCartId\":\"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"processingMTN\":\"2357829757\", \"cartCreator\": null, \"accountNumber\": \"4682690335\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(bpmHelper4.guestChoice(Mockito.any())).thenReturn(sampleResponseMono);
		Mono<GuestChoiceUIResponse> response = helper.guestChoiceFromPega(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void guestChoiceFromPegaHelperTest2() throws IOException {
		
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"ShoppingCart\",\"processAction\":\"checkOut\",\"intendType\":\"NSEACC\",\"intent\":\"StandAloneAccessory\",\"editAccessory\":false,\"expressflowForAcc\":false,\"mtnFlow\":\"D\",\"globalId\":\"\",\"customerType\":\"N\",\"zipCode\":\"76092\"}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.07.25.09.12.35-726.9785488871123\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"SignInOrderReview\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"SignInOrderReview\"},{\"path\":\"SignIn\"},{\"path\":\"GuestCheckOut\"}]},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-D-8318ca25-ecc7-40a1-8945-11e4d3cf87fb\",\"processingMTN\":\"9999999999\",\"registerNumber\":0},\"cartInfo\":{}}}}}";
		GuestChoiceUIRequest sampleRequest =  null;
		GuestChoiceUIResponse sampleResponse =  null;
		sampleRequest = mapper.readValue(requestString, GuestChoiceUIRequest.class);
		sampleResponse = mapper.readValue(responseString, GuestChoiceUIResponse.class);
		Mono<GuestChoiceUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		String redisDataString = "{ \"cartId\": null, \"vzwRoles\":\"ENC\",\"caseId\": null,\"prospectCartId\":\"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"processingMTN\":null, \"cartCreator\": null, \"accountNumber\": null, \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(bpmHelper4.guestChoice(Mockito.any())).thenReturn(sampleResponseMono);
		Mono<GuestChoiceUIResponse> response = helper.guestChoiceFromPega(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void retrieveActivationStatusFromCXPHelperTest1() throws IOException, SOEHTTPException {
		
		String sampleRequestString = "VZW-DOTCOM";
		String sampleResponseString = "{\"deviceType\":\"PHONE\",\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM-BBP\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.07.23.08.13.00-799.1525689895993\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Confirmation\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Confirmation\",\"processAction\":\"\"},\"customerInfo\":{\"customerType\":\"N\",\"skipImei1Call\":false,\"accountNumber\":\"\",\"cartCreator\":\"POE-T-2152fb5f-80a7-45e7-9f89-603d73d19c4c\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"mtnFlow\":\"D\",\"globalId\":\"POE-T-2152fb5f-80a7-45e7-9f89-603d73d19c4c\"},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"\",\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false},\"activationInfo\":{\"isActivationStatus\":\"SUCCESS\",\"activationCode\":\"\"},\"orderActivationStatusInfo\":{}}}}}";
		RetrieveActivationStatusUIResponse sampleResponse = mapper.readValue(sampleResponseString, RetrieveActivationStatusUIResponse.class);
		String redisDataString = "{ \"cartId\": null, \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		String cxpResponse = "{\"data\":{\"cartId\":\"bb4c8f6e-ac4e-4b3d-a4b4-82718d68885f\",\"rpsDeviceFlowType\":\"Numbershare\",\"rpsLoggedinDeviceMtn\":\"9705739647\",\"orderActivationStatusInfo\":[{\"orderNumber\":5113072,\"orderStatus\":\"U\",\"creditApplicationNum\":\"298990056\",\"activationInfoList\":[{\"mobileNumber\":\"9705739647\",\"activationStatus\":\"NOTSENT\",\"message\":\"Not sent for activation\",\"visionOrderNumber\":\"0\",\"visionLineItemNumber\":\"0\",\"accountNumber\":\"0313526839\",\"accountSubNumber\":\"1\",\"fullName\":\"JAKE HERNANDEZ\",\"preferFirstName\":\"\",\"preferLastName\":\"\",\"preferPronoun\":\"\"}]}]},\"meta\":{\"timestamp\":\"1658745299295\",\"cxpCorrelationId\":\"2022-07-25T10:34:59.+0000:773bd3a5-1e86-4795-88ff-6c454427e73a:cxp-ordering-services-qa-ev6v-sit5e-nscxp-68ddcd95bf-s6hxk:nssit5\"}}";
		RetrieveActivationStatusCXPResponse retrieveResponse = mapper.readValue(cxpResponse, RetrieveActivationStatusCXPResponse.class);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cxpService.retrieveActivationStatusOrdering(Mockito.any())).thenReturn(Mono.just(retrieveResponse));
		RetrieveActivationStatusUIResponse expectedResponse = sampleResponse;        
		Mono<RetrieveActivationStatusUIResponse> response = helper.retrieveActivationStatusFromCXP(sampleRequestString);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void deviceSimValidationHelperTest1() throws Exception {
			
		URI url = URI.create("http://localhost/deviceSimValidation");
		ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("digital_ig_session", "VZW-DOTCOM-1").header("mtn", "8437299178").cookie(new HttpCookie("digital_ig_session", "digital_1")).cookie(new HttpCookie("ecpdcookie", "1234")).cookie(new HttpCookie("domainCookie", "ecpd")).build();
		String sampleRequestString = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"prospectCartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processAction\":\"addAccessoryAndCheckout\",\"processStep\":\"AccessoryPDP\",\"intendType\":\"NSEACC\",\"pageId\":\"CART\",\"intent\":\"StandAloneAccessory\",\"cradleFlowJourney\":\"PromoHub\",\"action\":\"UPDATE\",\"itemType\":\"ACCESSORY\"}}";
		DeviceSimValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceSimValidationUIRequest.class);
		String sampleResponseString = "{\"meta\":{\"timestamp\":\"1658744542111\",\"cxpCorrelationId\":\"2022-07-25T10:22:22.+0000:89a0af40-b60f-4fde-bf1f-e0c188aa5ee2:cxp-customerprofile-se-qa-ev6v-sit3e-nscxp-d575658c-bg78b:nssit3\"},\"data\":{\"channelId\":\"VZW-DOTCOM-BBP\",\"iccid\":\"\",\"imei\":\"\",\"billingId\":\"I\",\"isSmartphone\":false,\"isEsimDevice\":false,\"flowType\":\"NSE\",\"bbpDefaultZipcodeForTabletFlow\":\"94596\",\"isValidationSuccess\":true,\"isSDKDevice\":false}}";
		DeviceSimValidationUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceSimValidationUIResponse.class);
		Mono<DeviceSimValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(cxpHelper2.deviceSimValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		Mono<DeviceSimValidationUIResponse> response = helper.deviceSimValidation(httpRequest, sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void retrieveActivationStatusHelperTest1() throws Exception {
		
		URI url = URI.create("http://localhost/nse/retrieveActivationStatus");
		MockServerHttpRequest request = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		String requestString = "{\"intent\":\"AAL\",\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"intent\":\"AAL\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"prospectCartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processAction\":\"addAccessoryAndCheckout\",\"processStep\":\"AccessoryPDP\",\"intendType\":\"NSEACC\",\"pageId\":\"CART\",\"cradleFlowJourney\":\"PromoHub\",\"action\":\"UPDATE\",\"itemType\":\"ACCESSORY\"}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGAgeneratedmessage\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\"]},{\"mtn\": \"2515813861\",\"completedprocessSteps\": []}],\"cartInfo\":{\"cartId\":\"a705f835-c61a-4e20-b616-0c9839202a15\"},\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"PromoHub\",\"availablePaths\":[{\"path\":\"PromoHub\"},{\"path\":\"MTNSelectionPage\"}],\"callReason\":\"SalesOrderPurchase\"}}}}}";
		RetrieveActivationStatusUIRequest sampleRequest = null;
		RetrieveActivationStatusUIResponse sampleResponse = null;
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRequest = mapper.readValue(requestString, RetrieveActivationStatusUIRequest.class);
		sampleResponse = mapper.readValue(responseString, RetrieveActivationStatusUIResponse.class);
		when(bpmHelper4.retrieveActivationStatus(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		RetrieveActivationStatusUIResponse expectedResponse = sampleResponse;
		Mono<RetrieveActivationStatusUIResponse> response = helper.retrieveActivationStatus(request,sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
	 }
	
	@Test
	public void retrieveActivationStatusHelperTest2() throws Exception {
		
		URI url = URI.create("http://localhost/retrieveActivationStatus");
		MockServerHttpRequest request = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		String requestString = "{\"intent\":\"AAL\",\"channelId\":\"VZW-DOTCOM-BBP\",\"processStep\":\"add-device\",\"processAction\":\"add-accessory\",\"cartInfo\":{\"intent\":\"AAL\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"prospectCartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processAction\":\"addAccessoryAndCheckout\",\"processStep\":\"AccessoryPDP\",\"intendType\":\"NSEACC\",\"pageId\":\"CART\",\"cradleFlowJourney\":\"PromoHub\",\"action\":\"UPDATE\",\"itemType\":\"ACCESSORY\"}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGAgeneratedmessage\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\"]},{\"mtn\": \"2515813861\",\"completedprocessSteps\": []}],\"cartInfo\":{\"cartId\":\"a705f835-c61a-4e20-b616-0c9839202a15\"},\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"PromoHub\",\"availablePaths\":[{\"path\":\"PromoHub\"},{\"path\":\"MTNSelectionPage\"}],\"callReason\":\"SalesOrderPurchase\"}}}}}";
		RetrieveActivationStatusUIRequest sampleRequest = null;
		RetrieveActivationStatusUIResponse sampleResponse = null;
		String redisDataString = "{ \"cartId\": null, \"caseId\":null, \"processingMTN\":null, \"cartCreator\":null, \"accountNumber\":null, \"mtn\": null }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRequest = mapper.readValue(requestString, RetrieveActivationStatusUIRequest.class);
		sampleResponse = mapper.readValue(responseString, RetrieveActivationStatusUIResponse.class);
		when(bpmHelper4.retrieveActivationStatus(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		RetrieveActivationStatusUIResponse expectedResponse = sampleResponse;
		Mono<RetrieveActivationStatusUIResponse> response = helper.retrieveActivationStatus(request,sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
	}
	
	@Test
	public void retrieveActivationStatusHelperTest3() throws Exception {
		
		URI url = URI.create("");
		MockServerHttpRequest request = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		String requestString = "{\"intent\":\"AAL\",\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"intent\":\"AAL\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"prospectCartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processAction\":\"addAccessoryAndCheckout\",\"processStep\":\"AccessoryPDP\",\"intendType\":\"NSEACC\",\"pageId\":\"CART\",\"cradleFlowJourney\":\"PromoHub\",\"action\":\"UPDATE\",\"itemType\":\"ACCESSORY\"}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGAgeneratedmessage\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\"]},{\"mtn\": \"2515813861\",\"completedprocessSteps\": []}],\"cartInfo\":{\"cartId\":\"a705f835-c61a-4e20-b616-0c9839202a15\"},\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"PromoHub\",\"availablePaths\":[{\"path\":\"PromoHub\"},{\"path\":\"MTNSelectionPage\"}],\"callReason\":\"SalesOrderPurchase\"}}}}}";
		RetrieveActivationStatusUIRequest sampleRequest = null;
		RetrieveActivationStatusUIResponse sampleResponse = null;
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRequest = mapper.readValue(requestString, RetrieveActivationStatusUIRequest.class);
		sampleResponse = mapper.readValue(responseString, RetrieveActivationStatusUIResponse.class);
		when(bpmHelper4.retrieveActivationStatus(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		RetrieveActivationStatusUIResponse expectedResponse = sampleResponse;
		Mono<RetrieveActivationStatusUIResponse> response = helper.retrieveActivationStatus(request,sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
	}
	
	@Test
	public void retrieveActivationStatusHelperTest4() throws Exception {
		
		URI url = URI.create("http://localhost/retrieveCart");
		MockServerHttpRequest request = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		String requestString = "{\"intent\":\"AAL\",\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"intent\":\"AAL\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"prospectCartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processAction\":\"addAccessoryAndCheckout\",\"processStep\":\"AccessoryPDP\",\"intendType\":\"NSEACC\",\"pageId\":\"CART\",\"cradleFlowJourney\":\"PromoHub\",\"action\":\"UPDATE\",\"itemType\":\"ACCESSORY\"}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGAgeneratedmessage\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\"]},{\"mtn\": \"2515813861\",\"completedprocessSteps\": []}],\"cartInfo\":{\"cartId\":\"a705f835-c61a-4e20-b616-0c9839202a15\"},\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"PromoHub\",\"availablePaths\":[{\"path\":\"PromoHub\"},{\"path\":\"MTNSelectionPage\"}],\"callReason\":\"SalesOrderPurchase\"}}}}}";
		RetrieveActivationStatusUIRequest sampleRequest = null;
		RetrieveActivationStatusUIResponse sampleResponse = null;
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRequest = mapper.readValue(requestString, RetrieveActivationStatusUIRequest.class);
		sampleResponse = mapper.readValue(responseString, RetrieveActivationStatusUIResponse.class);
		when(bpmHelper4.retrieveActivationStatus(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		RetrieveActivationStatusUIResponse expectedResponse = sampleResponse;
		Mono<RetrieveActivationStatusUIResponse> response = helper.retrieveActivationStatus(request,sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
	}
	
	@Test
	public void deviceIdValidationTest5() throws IOException, SOEHTTPException {
		
		String sampleRequestString = "{\"channelId\":\"VZW-MFA\",\"cartInfo\": {\"intendType\": \"BYOD\",\"cartCreator\": \"7039159592\",\"clientAppName\": \"VZW-MFA\",\"cartId\": \"4b207c97-6278-4562-9e41-b6411763bcd6\",\"caseId\": \"SOP-947715-E01\",\"processingMTN\": \"\",\"accountNumber\": \"0201430224-00001\",\"intent\": \"BYOD\",\"processStep\": \"BYODLandingPage\",\"processAction\": \"validatedevicesim\"},\"data\": {\"lines\": [{\"mtn\": \"\",\"device\": {\"id\": \"353338070105553\",\"Flowtype\": \"DEVICE\",\"CurrentId\": \"\",\"isCustomerProvidedEquipment\": true,\"sku\": \"\",\"smartIMEI\": true,\"searchAttributes\": {\"postpaidRestrictStartDate\": \"2018-07-01T04:00:00.000Z\",\"prodCode\": \"LTE\",\"hdVoiceInd\": true,\"deviceType\": \"4GE\",\"dacc\": \"00854\"},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": \"\"}}}]}}";
		String sampleResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"deviceInfo\": {\"simInfo\": {},\"makeEtniPersApi\": true,\"imei2\": \"imei\"},\"caseId\": \"SPA-1589374-DEV3\"}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationUIResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"creditAppNum\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<DeviceIdValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.deviceIdValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cxpHelper2.deviceIdValidation(Mockito.any(),Mockito.any())).thenReturn(sampleResponseMono);
		DeviceIdValidationUIResponse expectedResponse = sampleResponse;
		when(cxpHelper.getSmartImeiDevices(Mockito.anyString(),Mockito.anyString())).thenReturn(Mono.just(getSmartImeiDevicesResponse()));
		Mono<DeviceIdValidationUIResponse> response = helper.deviceIdValidation(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
	}
	
	@Test
	public void deviceIdValidationTest6() throws IOException, SOEHTTPException {
		
		String sampleRequestString = "{\"channelId\":\"VZW-MFA\",\"cartInfo\": {\"intendType\": \"BYOD\",\"cartCreator\": \"7039159592\",\"clientAppName\": \"VZW-MFA\",\"cartId\": \"4b207c97-6278-4562-9e41-b6411763bcd6\",\"caseId\": \"SOP-947715-E01\",\"processingMTN\": \"\",\"accountNumber\": \"0201430224-00001\",\"intent\": \"BYOD\",\"processStep\": \"BYODLandingPage\",\"processAction\": \"validatedevicesim\"},\"data\": {\"lines\": [{\"mtn\": \"\",\"device\": {\"id\": \"353338070105553\",\"Flowtype\": \"DEVICE\",\"CurrentId\": \"\",\"isCustomerProvidedEquipment\": true,\"sku\": \"\",\"smartIMEI\": true,\"searchAttributes\": {\"postpaidRestrictStartDate\": \"2018-07-01T04:00:00.000Z\",\"prodCode\": \"LTE\",\"hdVoiceInd\": true,\"deviceType\": \"4GE\",\"dacc\": \"00854\"},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": \"\"}}}]}}";
		String sampleResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"deviceInfo\": {\"simInfo\": {},\"makeEtniPersApi\": true,\"imei2\": \"imei\"},\"caseId\": \"SPA-1589374-DEV3\"}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationUIResponse.class);
		String redisDataString = "{\"channelType\":\"assisted\", \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"creditAppNum\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<DeviceIdValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.deviceIdValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cxpHelper2.deviceIdValidation(Mockito.any(),Mockito.any())).thenReturn(sampleResponseMono);
		DeviceIdValidationUIResponse expectedResponse = sampleResponse;
		when(cxpHelper.getSmartImeiDevices(Mockito.anyString(),Mockito.anyString())).thenReturn(Mono.just(getSmartImeiDevicesResponse()));
		Mono<DeviceIdValidationUIResponse> response = helper.deviceIdValidation(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
	}
	
	@Test
	public void deviceIdValidationTest7() throws IOException, SOEHTTPException {
		
		String sampleRequestString = "{\"channelId\":\"OMNI-RETAIL\",\"cartInfo\": {\"intendType\": \"NSE\",\"cartCreator\": \"7039159592\",\"clientAppName\": \"VZW-MFA\",\"cartId\": \"4b207c97-6278-4562-9e41-b6411763bcd6\",\"caseId\": \"SOP-947715-E01\",\"processingMTN\": \"\",\"accountNumber\": \"0201430224-00001\",\"intent\": \"BYOD\",\"processStep\": \"BYODLandingPage\",\"processAction\": \"validatedevicesim\"},\"data\": {\"lines\": [{\"mtn\": \"\",\"device\": {\"id\": \"353338070105553\",\"Flowtype\": \"DEVICE\",\"CurrentId\": \"\",\"isCustomerProvidedEquipment\": true,\"sku\": \"\",\"smartIMEI\": true,\"searchAttributes\": {\"postpaidRestrictStartDate\": \"2018-07-01T04:00:00.000Z\",\"prodCode\": \"LTE\",\"hdVoiceInd\": true,\"deviceType\": \"4GE\",\"dacc\": \"00854\"},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": \"\"}}}]}}";
		String sampleResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"deviceInfo\": {\"simInfo\": {},\"makeEtniPersApi\": true,\"imei2\": \"imei\"},\"caseId\": \"SPA-1589374-DEV3\"}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationUIResponse.class);
		String redisDataString = "{\"channelType\":\"assisted\",\"creditAppNum\":\"246173845602\", \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"creditAppNum\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<DeviceIdValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.deviceIdValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cxpHelper2.deviceIdValidation(Mockito.any(),Mockito.any())).thenReturn(sampleResponseMono);
		DeviceIdValidationUIResponse expectedResponse = sampleResponse;
		when(cxpHelper.getSmartImeiDevices(Mockito.anyString(),Mockito.anyString())).thenReturn(Mono.just(getSmartImeiDevicesResponse()));
		Mono<DeviceIdValidationUIResponse> response = helper.deviceIdValidation(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
	}
	
	@Test
	public void deviceIdValidationTest8() throws IOException, SOEHTTPException {
		
		String sampleRequestString = "{\"channelId\":\"OMNI-RETAIL\",\"cartInfo\": {\"intendType\": \"NSEBYOD\",\"cartCreator\": \"7039159592\",\"clientAppName\": \"VZW-MFA\",\"cartId\": \"4b207c97-6278-4562-9e41-b6411763bcd6\",\"caseId\": \"SOP-947715-E01\",\"processingMTN\": \"\",\"accountNumber\": \"0201430224-00001\",\"intent\": \"BYOD\",\"processStep\": \"BYODLandingPage\",\"processAction\": \"validatedevicesim\"},\"data\": {\"lines\": [{\"mtn\": \"\",\"device\": {\"id\": \"353338070105553\",\"Flowtype\": \"DEVICE\",\"CurrentId\": \"\",\"isCustomerProvidedEquipment\": true,\"sku\": \"\",\"smartIMEI\": true,\"searchAttributes\": {\"postpaidRestrictStartDate\": \"2018-07-01T04:00:00.000Z\",\"prodCode\": \"LTE\",\"hdVoiceInd\": true,\"deviceType\": \"4GE\",\"dacc\": \"00854\"},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": \"\"}}}]}}";
		String sampleResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"deviceInfo\": {\"simInfo\": {},\"makeEtniPersApi\": true,\"imei2\": \"imei\"},\"caseId\": \"SPA-1589374-DEV3\"}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationUIResponse.class);
		String redisDataString = "{\"channelType\":\"assisted\",\"creditAppNum\":\"246173845602\", \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"creditAppNum\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<DeviceIdValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.deviceIdValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cxpHelper2.deviceIdValidation(Mockito.any(),Mockito.any())).thenReturn(sampleResponseMono);
		DeviceIdValidationUIResponse expectedResponse = sampleResponse;
		when(cxpHelper.getSmartImeiDevices(Mockito.anyString(),Mockito.anyString())).thenReturn(Mono.just(getSmartImeiDevicesResponse()));
		Mono<DeviceIdValidationUIResponse> response = helper.deviceIdValidation(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
	}
	
	@Test
	public void deviceIdValidationTest9() throws IOException, SOEHTTPException {
		
		String sampleRequestString = "{\"channelId\":\"OMNI-RETAIL\",\"cartInfo\": {\"intendType\": \"NSE\",\"cartCreator\": \"7039159592\",\"clientAppName\": \"VZW-MFA\",\"cartId\": \"4b207c97-6278-4562-9e41-b6411763bcd6\",\"caseId\": \"SOP-947715-E01\",\"processingMTN\": \"\",\"accountNumber\": \"0201430224-00001\",\"intent\": \"BYOD\",\"processStep\": \"BYODLandingPage\",\"processAction\": \"validatedevicesim\"},\"data\": {\"lines\": [{\"mtn\": \"\",\"device\": {\"id\": \"353338070105553\",\"Flowtype\": \"DEVICE\",\"CurrentId\": \"\",\"isCustomerProvidedEquipment\": true,\"sku\": \"\",\"smartIMEI\": true,\"searchAttributes\": {\"postpaidRestrictStartDate\": \"2018-07-01T04:00:00.000Z\",\"prodCode\": \"LTE\",\"hdVoiceInd\": true,\"deviceType\": \"4GE\",\"dacc\": \"00854\"},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": \"\"}}}]}}";
		String sampleResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"deviceInfo\": {\"simInfo\": {},\"makeEtniPersApi\": true,\"imei2\": \"imei\"},\"caseId\": \"SPA-1589374-DEV3\"}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationUIResponse.class);
		String redisDataString = "{\"channelType\":\"assisted\",\"creditAppNum\":null, \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\"}";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<DeviceIdValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.deviceIdValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cxpHelper2.deviceIdValidation(Mockito.any(),Mockito.any())).thenReturn(sampleResponseMono);
		when(cxpHelper.getSmartImeiDevices(Mockito.anyString(),Mockito.anyString())).thenReturn(Mono.just(getSmartImeiDevicesResponse()));
		DeviceIdValidationUIResponse expectedResponse = sampleResponse;
		Mono<DeviceIdValidationUIResponse> response = helper.deviceIdValidation(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
	}
	
	@Test
	public void deviceIdValidationTest10() throws IOException, SOEHTTPException {
		
		String sampleRequestString = "{\"channelId\":\"VZW-DOTCOM\",\"ca" +
				"rtInfo\": {\"intendType\": \"NSE\",\"cartCreator\": \"7039159592\",\"clientAppName\": \"VZW-MFA\",\"cartId\": \"4b207c97-6278-4562-9e41-b6411763bcd6\",\"caseId\": \"SOP-947715-E01\",\"processingMTN\": \"\",\"accountNumber\": \"0201430224-00001\",\"intent\": \"BYOD\",\"processStep\": \"BYODLandingPage\",\"processAction\": \"validatedevicesim\"},\"data\": {\"lines\": [{\"mtn\": \"\",\"device\": {\"id\": \"353338070105553\",\"Flowtype\": \"DEVICE\",\"CurrentId\": \"\",\"isCustomerProvidedEquipment\": true,\"sku\": \"\",\"smartIMEI\": true,\"searchAttributes\": {\"postpaidRestrictStartDate\": \"2018-07-01T04:00:00.000Z\",\"prodCode\": \"LTE\",\"hdVoiceInd\": true,\"deviceType\": \"4GE\",\"dacc\": \"00854\"},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": \"\"}}}]}}";
		String sampleResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"deviceInfo\": {\"simInfo\": {},\"makeEtniPersApi\": true,\"imei2\": \"imei\"},\"caseId\": \"SPA-1589374-DEV3\"}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationUIResponse.class);
		String redisDataString = "{\"creditAppNum\":\"2454765856254\", \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\"}";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<DeviceIdValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.deviceIdValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cxpHelper2.deviceIdValidation(Mockito.any(),Mockito.any())).thenReturn(sampleResponseMono);
		when(cxpHelper.getSmartImeiDevices(Mockito.anyString(),Mockito.anyString())).thenReturn(Mono.just(getSmartImeiDevicesResponse()));
		DeviceIdValidationUIResponse expectedResponse = sampleResponse;
		Mono<DeviceIdValidationUIResponse> response = helper.deviceIdValidation(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
	}
	
	@Test
	public void deviceIdValidationTest11() throws IOException, SOEHTTPException {
		
		String sampleRequestString = "{\"channelId\":\"VRETO\",\"cartInfo\": {\"intendType\": \"NSE\",\"cartCreator\": \"7039159592\",\"clientAppName\": \"VZW-MFA\",\"cartId\": \"4b207c97-6278-4562-9e41-b6411763bcd6\",\"caseId\": \"SOP-947715-E01\",\"processingMTN\": \"\",\"accountNumber\": \"0201430224-00001\",\"intent\": \"BYOD\",\"processStep\": \"BYODLandingPage\",\"processAction\": \"validatedevicesim\"},\"data\": {\"lines\": [{\"mtn\": \"\",\"device\":null}]}}";
		String sampleResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"deviceInfo\": {\"simInfo\": {},\"makeEtniPersApi\": true,\"imei2\": \"imei\"},\"caseId\": \"SPA-1589374-DEV3\"}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationUIResponse.class);
		String redisDataString = "{\"creditAppNum\":\"2454765856254\", \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\"}";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<DeviceIdValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.deviceIdValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cxpHelper2.deviceIdValidation(Mockito.any(),Mockito.any())).thenReturn(sampleResponseMono);
		DeviceIdValidationUIResponse expectedResponse = sampleResponse;
		when(cxpHelper.getSmartImeiDevices(Mockito.anyString(),Mockito.anyString())).thenReturn(Mono.just(getSmartImeiDevicesResponse()));
		Mono<DeviceIdValidationUIResponse> response = helper.deviceIdValidation(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
	}
	
	@Test
	public void deviceIdValidationTest12() throws IOException, SOEHTTPException {
		
		ReflectionTestUtils.setField(helper, "enableDeviceIdChecksumGenerator", false);
		String sampleRequestString = "{\"channelId\":\"OMNI-RETAIL\",\"cartInfo\": {\"intendType\": \"AAL\",\"cartCreator\": \"7039159592\",\"clientAppName\": \"VZW-MFA\",\"cartId\": \"4b207c97-6278-4562-9e41-b6411763bcd6\",\"caseId\": \"SOP-947715-E01\",\"processingMTN\": \"\",\"accountNumber\": \"0201430224-00001\",\"intent\": \"BYOD\",\"processStep\": \"BYODLandingPage\",\"processAction\": \"validatedevicesim\"},\"data\": {\"lines\": [{\"mtn\": \"\",\"device\": {\"id\": \"353338070105553\",\"Flowtype\": \"DEVICE\",\"CurrentId\": \"\",\"isCustomerProvidedEquipment\": true,\"sku\": \"\",\"smartIMEI\": true,\"searchAttributes\": {\"postpaidRestrictStartDate\": \"2018-07-01T04:00:00.000Z\",\"prodCode\": \"LTE\",\"hdVoiceInd\": true,\"deviceType\": \"4GE\",\"dacc\": \"00854\"},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": \"\"}}}]}}";
		String sampleResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"deviceInfo\": {\"simInfo\": {},\"makeEtniPersApi\": true,\"imei2\": \"imei\"},\"caseId\": \"SPA-1589374-DEV3\"}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationUIResponse.class);
		String redisDataString = "{\"creditAppNum\":\"2454765856254\", \"cartId\":null, \"caseId\":null, \"processingMTN\":null, \"cartCreator\":null, \"accountNumber\":null, \"mtn\":null}";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<DeviceIdValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.deviceIdValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cxpHelper2.deviceIdValidation(Mockito.any(),Mockito.any())).thenReturn(sampleResponseMono);
		DeviceIdValidationUIResponse expectedResponse = sampleResponse;
		when(cxpHelper.getSmartImeiDevices(Mockito.anyString(),Mockito.anyString())).thenReturn(Mono.just(getSmartImeiDevicesResponse()));
		Mono<DeviceIdValidationUIResponse> response = helper.deviceIdValidation(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
	}
	
	
	@Test
	public void deviceIdValidationTest13() throws IOException, SOEHTTPException {
		
		ReflectionTestUtils.setField(helper, "enableEsimAtlocalInventory", false);
		String sampleRequestString = "{\"channelId\":\"OMNI-RETAIL\",\"cartInfo\": {\"intendType\": \"AAL\",\"cartCreator\": \"7039159592\",\"clientAppName\": \"VZW-MFA\",\"cartId\": \"4b207c97-6278-4562-9e41-b6411763bcd6\",\"caseId\": \"SOP-947715-E01\",\"processingMTN\": \"\",\"accountNumber\": \"0201430224-00001\",\"intent\": \"BYOD\",\"processStep\": \"BYODLandingPage\",\"processAction\": \"validatedevicesim\"},\"data\": {\"lines\": [{\"mtn\": \"\",\"device\": {\"id\":null,\"Flowtype\": \"DEVICE\",\"CurrentId\": \"\",\"isCustomerProvidedEquipment\": true,\"sku\": \"\",\"smartIMEI\": true,\"searchAttributes\": {\"postpaidRestrictStartDate\": \"2018-07-01T04:00:00.000Z\",\"prodCode\": \"LTE\",\"hdVoiceInd\": true,\"deviceType\": \"4GE\",\"dacc\": \"00854\"},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": \"\"}}}]}}";
		String sampleResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"deviceInfo\": {\"simInfo\": {},\"makeEtniPersApi\": true,\"imei2\": \"imei\"},\"caseId\": \"SPA-1589374-DEV3\"}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationUIResponse.class);
		String redisDataString = "{\"creditAppNum\":\"2454765856254\", \"cartId\":null, \"caseId\":null, \"processingMTN\":null, \"cartCreator\":null, \"accountNumber\":null, \"mtn\":null}";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<DeviceIdValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.deviceIdValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cxpHelper2.deviceIdValidation(Mockito.any(),Mockito.any())).thenReturn(sampleResponseMono);
		DeviceIdValidationUIResponse expectedResponse = sampleResponse;
		when(cxpHelper.getSmartImeiDevices(Mockito.anyString(),Mockito.anyString())).thenReturn(Mono.just(getSmartImeiDevicesResponse()));
		Mono<DeviceIdValidationUIResponse> response = helper.deviceIdValidation(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
	}
	
	@Test
	public void deviceIdValidationTest14() throws IOException, SOEHTTPException {
		
		ReflectionTestUtils.setField(helper, "enableEsimAtlocalInventory", true);
		String sampleRequestString = "{\"disableEsimAtLocalInventory\":true,\"channelId\":\"OMNI-RETAIL\",\"cartInfo\": {\"intendType\": \"AAL\",\"cartCreator\": \"7039159592\",\"clientAppName\": \"VZW-MFA\",\"cartId\": \"4b207c97-6278-4562-9e41-b6411763bcd6\",\"caseId\": \"SOP-947715-E01\",\"processingMTN\": \"\",\"accountNumber\": \"0201430224-00001\",\"intent\": \"BYOD\",\"processStep\": \"BYODLandingPage\",\"processAction\": \"validatedevicesim\"},\"data\": {\"lines\": [{\"mtn\": \"\",\"device\": {\"id\":\"4489954345\",\"Flowtype\": \"DEVICE\",\"CurrentId\": \"\",\"isCustomerProvidedEquipment\": true,\"sku\": \"\",\"smartIMEI\": true,\"searchAttributes\": {\"postpaidRestrictStartDate\": \"2018-07-01T04:00:00.000Z\",\"prodCode\": \"LTE\",\"hdVoiceInd\": true,\"deviceType\": \"4GE\",\"dacc\": \"00854\"},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": \"\"}}}]}}";
		String sampleResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"deviceInfo\": {\"simInfo\": {},\"makeEtniPersApi\": true,\"imei2\": \"imei\"},\"caseId\": \"SPA-1589374-DEV3\"}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationUIResponse.class);
		String redisDataString = "{\"creditAppNum\":\"2454765856254\", \"cartId\":null, \"caseId\":null, \"processingMTN\":null, \"cartCreator\":null, \"accountNumber\":null, \"mtn\":null}";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<DeviceIdValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.deviceIdValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cxpHelper2.deviceIdValidation(Mockito.any(),Mockito.any())).thenReturn(sampleResponseMono);
		DeviceIdValidationUIResponse expectedResponse = sampleResponse;
		when(cxpHelper.getSmartImeiDevices(Mockito.anyString(),Mockito.anyString())).thenReturn(Mono.just(getSmartImeiDevicesResponse()));
		Mono<DeviceIdValidationUIResponse> response = helper.deviceIdValidation(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
	}
	
	@Test
	public void deviceIdValidationTest15() throws IOException, SOEHTTPException {


		String eidSimDetailsUIResponseString = "{\"data\":{\"simEidResponseBean\":[{\"statusDesc\":\":SUCCESSFUL\",\"statusCode\":\"00000\",\"rowsPop\":\"4\",\"rowIdList\":[{\"vzwImsi\":\"311480111500108\",\"vfImsi\":\"\",\"euimId\":\"A00001122DCDCA\",\"iccidStatus\":\"PA\",\"mdn\":\"8483340509\",\"simCreateDate\":\"2023-09-05-16.09.06.605919\",\"simUpdateDate\":\"2023-11-04-03.19.34.000092\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$8483340509-0503889576\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692229539\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111471934\",\"vfImsi\":\"\",\"euimId\":\"A00001122DCD08\",\"iccidStatus\":\"PA\",\"mdn\":\"6075901699\",\"simCreateDate\":\"2023-09-05-16.09.08.762178\",\"simUpdateDate\":\"2023-11-02-05.58.19.000753\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$6075901699-0211053007\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692227590\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111478472\",\"vfImsi\":\"\",\"euimId\":\"A00001122DC190\",\"iccidStatus\":\"PA\",\"mdn\":\"6075900414\",\"simCreateDate\":\"2023-09-05-16.09.04.131573\",\"simUpdateDate\":\"2023-11-02-05.50.19.000582\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$6075900414-0294247860\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692198239\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111509353\",\"vfImsi\":\"\",\"euimId\":\"A00001122DB7EA\",\"iccidStatus\":\"AI\",\"mdn\":\"9126025456\",\"simCreateDate\":\"2023-09-05-16.09.03.896542\",\"simUpdateDate\":\"2023-11-0113:47:45.000860\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$9126025456-0460441555\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692173539\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"}]}]}}" ;
		EidSimDetailsUIResponse eidSimDetailsUIResponse = mapper.readValue(eidSimDetailsUIResponseString, EidSimDetailsUIResponse.class);
		when(cxpHelper.EidSimDetail(Mockito.any())).thenReturn(Mono.just(eidSimDetailsUIResponse));
		
		String sampleRequestString = "{\"channelId\":\"OMNI-RETAIL\",\"cartInfo\": {\"intendType\": \"BYOD\",\"cartCreator\": \"7039159592\",\"clientAppName\": \"VZW-MFA\",\"cartId\": \"4b207c97-6278-4562-9e41-b6411763bcd6\",\"caseId\": \"SOP-947715-E01\",\"processingMTN\": \"\",\"accountNumber\": \"0201430224-00001\",\"intent\": \"BYOD\",\"processStep\": \"BYODLandingPage\",\"processAction\": \"validatedevicesim\"},\"data\": {\"lines\": [{\"mtn\": \"\",\"device\": {\"id\": \"353338070105553\",\"Flowtype\": \"DEVICE\",\"CurrentId\": \"\",\"isCustomerProvidedEquipment\": true,\"sku\": \"\",\"smartIMEI\": true,\"searchAttributes\": {\"postpaidRestrictStartDate\": \"2018-07-01T04:00:00.000Z\",\"prodCode\": \"LTE\",\"hdVoiceInd\": true,\"deviceType\": \"4GE\",\"dacc\": \"00854\"},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": \"\"}}}]}}";
		String sampleResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"deviceInfo\":null,\"caseId\": \"SPA-1589374-DEV3\"}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationUIResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"creditAppNum\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		if(sampleResponse.getServiceBody().getServiceResponse().getContext().getDeviceInfo() == null) {
			DeviceInfo deviceInfo = new DeviceInfo();
			deviceInfo.setSimInfo(new SimInfo());
			sampleResponse.getServiceBody().getServiceResponse().getContext().setDeviceInfo(deviceInfo);
		}
		sampleResponse.getServiceBody().getServiceResponse().getContext().getDeviceInfo().setPairedImeiData(new PairedImeiData());
		sampleResponse.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getPairedImeiData().setEid("1234");
		Mono<DeviceIdValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.deviceIdValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cxpHelper2.deviceIdValidation(Mockito.any(),Mockito.any())).thenReturn(sampleResponseMono);
		DeviceIdValidationUIResponse expectedResponse = sampleResponse;
		when(cxpHelper.getSmartImeiDevices(Mockito.anyString(),Mockito.anyString())).thenReturn(Mono.just(getSmartImeiDevicesResponse()));
		Mono<DeviceIdValidationUIResponse> response = helper.deviceIdValidation(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
	}
	
	
	@Test
	public void deviceIdValidationTest16() throws IOException, SOEHTTPException {
		
		String sampleRequestString = "{\"channelId\":\"OMNI-RETAIL\",\"cartInfo\": {\"intendType\": \"BYOD\",\"cartCreator\": \"7039159592\",\"clientAppName\": \"VZW-MFA\",\"cartId\": \"4b207c97-6278-4562-9e41-b6411763bcd6\",\"caseId\": \"SOP-947715-E01\",\"processingMTN\": \"\",\"accountNumber\": \"0201430224-00001\",\"intent\": \"BYOD\",\"processStep\": \"BYODLandingPage\",\"processAction\": \"validatedevicesim\"},\"data\": {\"lines\": [{\"mtn\": \"\",\"device\": {\"id\": \"353338070105553\",\"Flowtype\": \"DEVICE\",\"CurrentId\": \"\",\"isCustomerProvidedEquipment\": true,\"sku\": \"\",\"smartIMEI\": true,\"searchAttributes\": {\"postpaidRestrictStartDate\": \"2018-07-01T04:00:00.000Z\",\"prodCode\": \"LTE\",\"hdVoiceInd\": true,\"deviceType\": \"4GE\",\"dacc\": \"00854\"},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": \"\"}}}]}}";
		String sampleResponseString = "{\"serviceHeader\": {\"clientId\": \"VZW-ECOM\",\"statusMsg\": \"PEGA generated message\",\"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\": \"\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"0\"},\"serviceBody\": {\"serviceResponse\": {\"context\": null}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationUIResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"creditAppNum\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<DeviceIdValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.deviceIdValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cxpHelper2.deviceIdValidation(Mockito.any(),Mockito.any())).thenReturn(sampleResponseMono);
		DeviceIdValidationUIResponse expectedResponse = sampleResponse;
		when(cxpHelper.getSmartImeiDevices(Mockito.anyString(),Mockito.anyString())).thenReturn(Mono.just(getSmartImeiDevicesResponse()));
		Mono<DeviceIdValidationUIResponse> response = helper.deviceIdValidation(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
	}
	
	@Test
	public void deviceIdValidationTest17() throws IOException, SOEHTTPException {
		String eidSimDetailsUIResponseString = "{\"data\":{\"simEidResponseBean\":[{\"statusDesc\":\":SUCCESSFUL\",\"statusCode\":\"00000\",\"rowsPop\":\"4\",\"rowIdList\":[{\"vzwImsi\":\"311480111500108\",\"vfImsi\":\"\",\"euimId\":\"A00001122DCDCA\",\"iccidStatus\":\"PA\",\"mdn\":\"8483340509\",\"simCreateDate\":\"2023-09-05-16.09.06.605919\",\"simUpdateDate\":\"2023-11-04-03.19.34.000092\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$8483340509-0503889576\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692229539\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111471934\",\"vfImsi\":\"\",\"euimId\":\"A00001122DCD08\",\"iccidStatus\":\"PA\",\"mdn\":\"6075901699\",\"simCreateDate\":\"2023-09-05-16.09.08.762178\",\"simUpdateDate\":\"2023-11-02-05.58.19.000753\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$6075901699-0211053007\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692227590\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111478472\",\"vfImsi\":\"\",\"euimId\":\"A00001122DC190\",\"iccidStatus\":\"PA\",\"mdn\":\"6075900414\",\"simCreateDate\":\"2023-09-05-16.09.04.131573\",\"simUpdateDate\":\"2023-11-02-05.50.19.000582\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$6075900414-0294247860\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692198239\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111509353\",\"vfImsi\":\"\",\"euimId\":\"A00001122DB7EA\",\"iccidStatus\":\"AI\",\"mdn\":\"9126025456\",\"simCreateDate\":\"2023-09-05-16.09.03.896542\",\"simUpdateDate\":\"2023-11-0113:47:45.000860\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$9126025456-0460441555\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692173539\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"}]}]}}" ;
		EidSimDetailsUIResponse eidSimDetailsUIResponse = mapper.readValue(eidSimDetailsUIResponseString, EidSimDetailsUIResponse.class);
		when(cxpHelper.EidSimDetail(Mockito.any())).thenReturn(Mono.just(eidSimDetailsUIResponse));
		String sampleRequestString = "{\"channelId\":\"OMNI-RETAIL\",\"cartInfo\":{\"cartCreator\":\"7272445960\",\"cartId\":\"0b95bd88-66ac-4400-a7d2-3c5f43bcbbd5\",\"caseId\":\"SOP-9774000-E01\",\"creditAppNum\":null,\"processingMTN\":\"7272445960\",\"accountNumber\":\"0321747971-00001\",\"intent\":\"BYOD\",\"intendType\":\"BYOD\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":\"validateDeviceSim\",\"action\":\"\"},\"data\":{\"lines\":[{\"mtn\":\"7272445960\",\"eskuId\":\"\",\"device\":{\"id\":\"355843801449939\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"356628100445533\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":false,\"sim\":{\"id\":\"\",\"sku\":\"\",\"isCustomerProvidedSIM\":false,\"CurrentSimid\":\"89148000005207167008\"}}}]},\"disableEsimAtLocalInventory\":false}";
		String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-RETAIL\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.10.13.02.18.48-880.5654141238181\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-9774000-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"GridWallPDP\"}]},\"customerInfo\":{\"pinCardPayment\":false,\"accountNumber\":\"\",\"cartCreator\":\"7272445960\",\"processingMTN\":\"\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"0b95bd88-66ac-4400-a7d2-3c5f43bcbbd5\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false},\"deviceInfo\":{\"simInfo\":{\"iccid\":\"89148000005207167008\",\"mfgCode\":\"STM\",\"launchPackageSku\":\"EMBDSIMTRI\",\"prodName\":\"ST Multi-Form-Factor SIM\",\"preferredSoftSim\":\"EMBDSIM5G\",\"launchPackageSkuType\":\"MLR53LL/A\",\"pairedIccid\":\"\",\"type\":\"4GS\",\"mtn\":\"\",\"mobileNumber\":\"\",\"active\":false,\"aging\":false,\"available\":false,\"retired\":false,\"grandFathered\":false,\"status\":\"\",\"euimid\":\"\",\"imsiv\":\"\",\"imsivf\":\"\",\"iccIdStat\":\"\",\"min\":\"\",\"ispuCompatibleSIM\":\"BULKSIM5G-SA-A\",\"makeEtniPersApi\":false,\"deviceId\":\"355843801449939\",\"dfillCompatibleSim\":\"DFILLSIM5G-SA-A\",\"esimid\":\"\",\"eID\":\"\"},\"simInfo2\":{\"iccid\":\"\",\"mfgCode\":\"\",\"launchPackageSku\":\"MLR53LL/A-2\",\"prodName\":\"\",\"preferredSoftSim\":\"SOFTSIM5G-SA-A\",\"launchPackageSkuType\":\"MLR53LL/A-2\",\"pairedIccid\":\"\",\"type\":\"\",\"mtn\":\"\",\"mobileNumber\":\"\",\"active\":false,\"aging\":false,\"available\":false,\"retired\":false,\"grandFathered\":false,\"status\":\"\",\"euimid\":\"\",\"imsiv\":\"\",\"imsivf\":\"\",\"iccIdStat\":\"\",\"min\":\"\",\"ispuCompatibleSIM\":\"BULKSIM5G-SA-A\",\"makeEtniPersApi\":true,\"deviceId\":\"355843801316351\",\"dfillCompatibleSim\":\"DFILLSIM5G-SA-A\",\"esimid\":\"\",\"eID\":\"89049032007008882600117663233736\"},\"deviceSimCompatible\":\"Y\",\"deviceSimM2MPair\":\"N\",\"deviceESimCompatible\":\"N\",\"deviceESimM2MPair\":\"N\",\"deviceId\":\"355843801449939\",\"color\":{\"colorId\":\"clr10520003\",\"displayName\":\"Sierra Blue\",\"description\":\"Blue\",\"colorCssStyle\":\"#A7C1D9\"},\"imageName\":\"apple-iphone-13-pro-sierra-blue-09142021\",\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-thumb$\"},\"skuDisplayName\":\"Apple iPhone 13 Pro 128GB in Sierra Blue\",\"deviceSku\":\"MLR53LL/A\",\"isRestrictedDevice\":\"N\",\"deviceAttributes\":{\"mfgCode\":\"APL\",\"mfgName\":\"Apple\",\"prodName\":\"IPHONE 13 PRO 128 SIERRA BLUE\",\"prodType\":\"5GSmartphone\",\"equipModeCode\":\"5GE\",\"equipMode\":\"5GDevice\",\"gpsIndicator\":\"Y\",\"daccCode\":\"01661\",\"deviceType\":\"5GE\",\"deviceCategory\":\"5G Smartphone\",\"productId\":\"dev16720003\",\"postpaidRestrictStartDate\":\"\",\"prepayRestrictStartDate\":\"\",\"wholesaleRestrictStartDate\":\"\"},\"lostAndStolen\":{\"lostStolen\":\"N\",\"nonPay\":\"N\"},\"numbershareCapability\":\"\",\"price\":{\"fullRetailPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"Full Retail Price\"},\"oneYearPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"One Year Price\"},\"devicePaymentPrice\":[]},\"skipSimIdFlag\":true,\"appleWatchFlag\":false,\"fmipLocked\":false,\"appleCarrieLock\":false,\"e911AddrInd\":\"\",\"simClass4G\":\"PI\",\"makeEtniPersApi\":false,\"softMessages\":[],\"standalonePairingEligible\":true,\"deviceFamilyType\":\"Phone\",\"osType\":\"Apple iOS\",\"euiccCapable\":\"Y\",\"imei1\":\"355843801449939\",\"imei2\":\"355843801316351\",\"productFamily\":\"iPhone 13 Pro\",\"pairedImeiData\":{\"pairedImei\":\"353207331839021\",\"eid\":\"89049032007008882600127471300369\",\"sku\":\"MLA23LL/A\",\"preferredSim\":\"DFILLSIM5G-SA-A\",\"devicePreferredSoftSim\":\"SOFTSIM5G-SA-D\",\"simClass4G\":\"PI\",\"euiccCapable\":true},\"eSIMOnly\":false,\"profileState\":\"CO\"}}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationUIResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"creditAppNum\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleResponse.getServiceBody().getServiceResponse().getContext().getDeviceInfo().setPairedImeiData(new PairedImeiData());
		sampleResponse.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getPairedImeiData().setEid("1234");
		Mono<DeviceIdValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.deviceIdValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cxpHelper2.deviceIdValidation(Mockito.any(),Mockito.any())).thenReturn(sampleResponseMono);
		DeviceIdValidationUIResponse expectedResponse = sampleResponse;
		when(cxpHelper.getSmartImeiDevices(Mockito.anyString(),Mockito.anyString())).thenReturn(Mono.just(getSmartImeiDevicesResponse()));
		Mono<DeviceIdValidationUIResponse> response = helper.deviceIdValidation(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
	}
	
	@Test
	public void retrieveBundleAccessoryInfoHelperTest4() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"}}";
		String sampleResponseString = "{\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveBundleAccRequest sampleRequest = mapper.readValue(sampleRequestString, RetrieveBundleAccRequest.class);
		BundleAccessoryDetail sampleResponseBundle = mapper.readValue(sampleResponseString, BundleAccessoryDetail.class);
		RetrieveAccCartCXPResponse sampleResponseRetrieve = mapper.readValue(sampleResponseString, RetrieveAccCartCXPResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(cxpService.retrieveBundleAccessories(Mockito.any())).thenReturn(Mono.just(sampleResponseRetrieve));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		BundleAccessoryDetail expectedResponse = sampleResponseBundle;
		Mono<BundleAccessoryDetail> response = helper.retrieveBundleAccessoryInfo(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify(); 
	}
	
	@Test
	public void retrieveBundleAccessoryInfoHelperTest5() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"}}";
		String sampleResponseString = "{\"data\": {},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveBundleAccRequest sampleRequest = mapper.readValue(sampleRequestString, RetrieveBundleAccRequest.class);
		BundleAccessoryDetail sampleResponseBundle = mapper.readValue(sampleResponseString, BundleAccessoryDetail.class);
		RetrieveAccCartCXPResponse sampleResponseRetrieve = mapper.readValue(sampleResponseString, RetrieveAccCartCXPResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(cxpService.retrieveBundleAccessories(Mockito.any())).thenReturn(Mono.just(sampleResponseRetrieve));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		BundleAccessoryDetail expectedResponse = sampleResponseBundle;
		Mono<BundleAccessoryDetail> response = helper.retrieveBundleAccessoryInfo(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify(); 
	}
	
	@Test
	public void retrieveBundleAccessoryInfoHelperTest6() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"}}";
		String sampleResponseString = "{\"data\": {\"cart\": {}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveBundleAccRequest sampleRequest = mapper.readValue(sampleRequestString, RetrieveBundleAccRequest.class);
		BundleAccessoryDetail sampleResponseBundle = mapper.readValue(sampleResponseString, BundleAccessoryDetail.class);
		RetrieveAccCartCXPResponse sampleResponseRetrieve = mapper.readValue(sampleResponseString, RetrieveAccCartCXPResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(cxpService.retrieveBundleAccessories(Mockito.any())).thenReturn(Mono.just(sampleResponseRetrieve));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		BundleAccessoryDetail expectedResponse = sampleResponseBundle;
		Mono<BundleAccessoryDetail> response = helper.retrieveBundleAccessoryInfo(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify(); 
	}

	@Test
	public void retrieveBundleAccessoryInfoHelperTest7() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"}}";
		String sampleResponseString = "{\"data\": {\"cart\": {\"lineDetails\": {}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveBundleAccRequest sampleRequest = mapper.readValue(sampleRequestString, RetrieveBundleAccRequest.class);
		BundleAccessoryDetail sampleResponseBundle = mapper.readValue(sampleResponseString, BundleAccessoryDetail.class);
		RetrieveAccCartCXPResponse sampleResponseRetrieve = mapper.readValue(sampleResponseString, RetrieveAccCartCXPResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(cxpService.retrieveBundleAccessories(Mockito.any())).thenReturn(Mono.just(sampleResponseRetrieve));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		BundleAccessoryDetail expectedResponse = sampleResponseBundle;
		Mono<BundleAccessoryDetail> response = helper.retrieveBundleAccessoryInfo(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify(); 
	}
	
	@Test
	public void retrieveBundleAccessoryInfoHelperTest8() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"}}";
		String sampleResponseString = "{\"data\": {\"cart\": {\"lineDetails\": {\"lineInfo\": [{}]}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveBundleAccRequest sampleRequest = mapper.readValue(sampleRequestString, RetrieveBundleAccRequest.class);
		BundleAccessoryDetail sampleResponseBundle = mapper.readValue(sampleResponseString, BundleAccessoryDetail.class);
		RetrieveAccCartCXPResponse sampleResponseRetrieve = mapper.readValue(sampleResponseString, RetrieveAccCartCXPResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(cxpService.retrieveBundleAccessories(Mockito.any())).thenReturn(Mono.just(sampleResponseRetrieve));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		BundleAccessoryDetail expectedResponse = sampleResponseBundle;
		Mono<BundleAccessoryDetail> response = helper.retrieveBundleAccessoryInfo(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify(); 
	}
	
	@Test
	public void retrieveBundleAccessoryInfoHelperTest9() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"}}";
		String sampleResponseString = "{\"data\": {\"cart\": {\"lineDetails\": {\"lineInfo\": [{\"itemsInfo\": [{}]}]}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveBundleAccRequest sampleRequest = mapper.readValue(sampleRequestString, RetrieveBundleAccRequest.class);
		BundleAccessoryDetail sampleResponseBundle = mapper.readValue(sampleResponseString, BundleAccessoryDetail.class);
		RetrieveAccCartCXPResponse sampleResponseRetrieve = mapper.readValue(sampleResponseString, RetrieveAccCartCXPResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(cxpService.retrieveBundleAccessories(Mockito.any())).thenReturn(Mono.just(sampleResponseRetrieve));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		BundleAccessoryDetail expectedResponse = sampleResponseBundle;
		Mono<BundleAccessoryDetail> response = helper.retrieveBundleAccessoryInfo(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify(); 
	}
	
	@Test
	public void retrieveBundleAccessoryInfoHelperTest10() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"}}";
		String sampleResponseString = "{\"data\": {\"cart\": {\"lineDetails\": {\"lineInfo\": [{\"itemsInfo\": [{\"cartItems\": {}}]}]}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveBundleAccRequest sampleRequest = mapper.readValue(sampleRequestString, RetrieveBundleAccRequest.class);
		BundleAccessoryDetail sampleResponseBundle = mapper.readValue(sampleResponseString, BundleAccessoryDetail.class);
		RetrieveAccCartCXPResponse sampleResponseRetrieve = mapper.readValue(sampleResponseString, RetrieveAccCartCXPResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(cxpService.retrieveBundleAccessories(Mockito.any())).thenReturn(Mono.just(sampleResponseRetrieve));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		BundleAccessoryDetail expectedResponse = sampleResponseBundle;
		Mono<BundleAccessoryDetail> response = helper.retrieveBundleAccessoryInfo(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify(); 
	}
	
	@Test
	public void retrieveBundleAccessoryInfoHelperTest11() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"}}";
		String sampleResponseString = "{\"data\": {\"cart\": {\"lineDetails\": {\"lineInfo\": [{\"itemsInfo\": [{\"cartItems\": {\"cartItem\": [{\"cartItemType\": \"ACCESSORY\"}]}}]}]}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveBundleAccRequest sampleRequest = mapper.readValue(sampleRequestString, RetrieveBundleAccRequest.class);
		BundleAccessoryDetail sampleResponseBundle = mapper.readValue(sampleResponseString, BundleAccessoryDetail.class);
		RetrieveAccCartCXPResponse sampleResponseRetrieve = mapper.readValue(sampleResponseString, RetrieveAccCartCXPResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(cxpService.retrieveBundleAccessories(Mockito.any())).thenReturn(Mono.just(sampleResponseRetrieve));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		BundleAccessoryDetail expectedResponse = sampleResponseBundle;
		Mono<BundleAccessoryDetail> response = helper.retrieveBundleAccessoryInfo(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify(); 
	}
	
	@Test
	public void retrieveBundleAccessoryInfoHelperTest12() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"}}";
		String sampleResponseString = "{\"data\": {\"cart\": {\"lineDetails\": {\"lineInfo\": [{\"itemsInfo\": [{\"cartItems\": {\"cartItem\": [{\"cartItemType\": \"ACCESSORY\",\"categoryDisplayNames\": []}]}}]}]}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveBundleAccRequest sampleRequest = mapper.readValue(sampleRequestString, RetrieveBundleAccRequest.class);
		BundleAccessoryDetail sampleResponseBundle = mapper.readValue(sampleResponseString, BundleAccessoryDetail.class);
		RetrieveAccCartCXPResponse sampleResponseRetrieve = mapper.readValue(sampleResponseString, RetrieveAccCartCXPResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(cxpService.retrieveBundleAccessories(Mockito.any())).thenReturn(Mono.just(sampleResponseRetrieve));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		BundleAccessoryDetail expectedResponse = sampleResponseBundle;
		Mono<BundleAccessoryDetail> response = helper.retrieveBundleAccessoryInfo(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify(); 
	}
	
	@Test
	public void retrieveBundleAccessoryInfoHelperTest13() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"}}";
		String sampleResponseString = "{\"data\": {\"cart\": {\"lineDetails\": {\"lineInfo\": [{\"itemsInfo\": [{\"cartItems\": {\"cartItem\": [{\"cartItemType\": \"ACCESSORY\",\"categoryDisplayNames\": [\"Discount\"]}]}}]}]}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveBundleAccRequest sampleRequest = mapper.readValue(sampleRequestString, RetrieveBundleAccRequest.class);
		BundleAccessoryDetail sampleResponseBundle = mapper.readValue(sampleResponseString, BundleAccessoryDetail.class);
		RetrieveAccCartCXPResponse sampleResponseRetrieve = mapper.readValue(sampleResponseString, RetrieveAccCartCXPResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(cxpService.retrieveBundleAccessories(Mockito.any())).thenReturn(Mono.just(sampleResponseRetrieve));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		BundleAccessoryDetail expectedResponse = sampleResponseBundle;
		Mono<BundleAccessoryDetail> response = helper.retrieveBundleAccessoryInfo(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify(); 
	}
	
	@Test
	public void retrieveBundleAccessoryInfoHelperTest14() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"}}";
		String sampleResponseString = "{\"data\": {\"cart\": {\"lineDetails\": {\"lineInfo\": [{\"itemsInfo\": [{\"cartItems\": {\"cartItem\": [{\"cartItemType\": \"ACCESSORY\",\"categoryDisplayNames\": [\"Discount Bundle Eligible\"]}]}}]}]}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveBundleAccRequest sampleRequest = mapper.readValue(sampleRequestString, RetrieveBundleAccRequest.class);
		BundleAccessoryDetail sampleResponseBundle = mapper.readValue(sampleResponseString, BundleAccessoryDetail.class);
		RetrieveAccCartCXPResponse sampleResponseRetrieve = mapper.readValue(sampleResponseString, RetrieveAccCartCXPResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(cxpService.retrieveBundleAccessories(Mockito.any())).thenReturn(Mono.just(sampleResponseRetrieve));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		BundleAccessoryDetail expectedResponse = sampleResponseBundle;
		Mono<BundleAccessoryDetail> response = helper.retrieveBundleAccessoryInfo(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify(); 
	}
	
	@Test
	public void retrieveBundleAccessoryInfoHelperTest15() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"}}";
		String sampleResponseString = "{\"data\": {\"cart\": {\"lineDetails\": {\"lineInfo\": [{\"itemsInfo\": [{\"cartItems\": {\"cartItem\": [{\"qty\": 1,\"imageUrlMap\": {},\"cartItemType\": \"ACCESSORY\",\"categoryDisplayNames\": [\"Discount Bundle Eligible\"]}]}}]}]}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveBundleAccRequest sampleRequest = mapper.readValue(sampleRequestString, RetrieveBundleAccRequest.class);
		BundleAccessoryDetail sampleResponseBundle = mapper.readValue(sampleResponseString, BundleAccessoryDetail.class);
		RetrieveAccCartCXPResponse sampleResponseRetrieve = mapper.readValue(sampleResponseString, RetrieveAccCartCXPResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(cxpService.retrieveBundleAccessories(Mockito.any())).thenReturn(Mono.just(sampleResponseRetrieve));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		BundleAccessoryDetail expectedResponse = sampleResponseBundle;
		Mono<BundleAccessoryDetail> response = helper.retrieveBundleAccessoryInfo(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify(); 
	}
	
	@Test
	public void retrieveBundleAccessoryInfoHelperTest16() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"}}";
		String sampleResponseString = "{\"data\": {\"cart\": {\"orderDetails\": {},\"lineDetails\": {\"lineInfo\": [{\"itemsInfo\": [{\"cartItems\": {\"cartItem\": [{\"qty\": 1,\"imageUrlMap\": {},\"cartItemType\": \"ACCESSORY\",\"categoryDisplayNames\": [\"Discount Bundle Eligible\"]}]}}]}]}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveBundleAccRequest sampleRequest = mapper.readValue(sampleRequestString, RetrieveBundleAccRequest.class);
		RetrieveAccCartCXPResponse sampleResponseRetrieve = mapper.readValue(sampleResponseString, RetrieveAccCartCXPResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(cxpService.retrieveBundleAccessories(Mockito.any())).thenReturn(Mono.just(sampleResponseRetrieve));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		Mono<BundleAccessoryDetail> response = helper.retrieveBundleAccessoryInfo(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void retrieveBundleAccessoryInfoHelperTest17() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"}}";
		String sampleResponseString = "{\"data\": {\"cart\": {\"orderDetails\": {},\"lineDetails\": {\"lineInfo\": [{\"itemsInfo\": [{\"cartItems\": {\"cartItem\": [{\"qty\": 11,\"imageUrlMap\": {},\"cartItemType\": \"ACCESSORY\",\"categoryDisplayNames\": [\"Discount Bundle Eligible\"]}]}}]}]}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveBundleAccRequest sampleRequest = mapper.readValue(sampleRequestString, RetrieveBundleAccRequest.class);
		RetrieveAccCartCXPResponse sampleResponseRetrieve = mapper.readValue(sampleResponseString, RetrieveAccCartCXPResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(cxpService.retrieveBundleAccessories(Mockito.any())).thenReturn(Mono.just(sampleResponseRetrieve));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		Mono<BundleAccessoryDetail> response = helper.retrieveBundleAccessoryInfo(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void retrieveCartCustomLogsTest() throws JsonMappingException, JsonProcessingException {
		String dataString = "{\"customerFiosPlanType\": \"fios\",\"intent\": \"NSE\",\"externalID\": \"id\",\"fiosAuthenticated\": \"true\", \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
		helper.retrieveCartCustomLogs(data);
		Assertions.assertThat(data).isNotNull();
	}
	@Test
	public void retrieveCartCustomLogsTest1() throws JsonProcessingException
	{
		String dataString = "{\"customerFiosPlanType\": \"fios\",\"intent\": \"NSE\",\"externalID\": \"id\",\"fiosAuthenticated\": \"true\", \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData data = mapper.readValue(dataString, CartRedisData.class);

		try(MockedStatic<JacksonMapperFactory> mockedStatic = mockStatic(JacksonMapperFactory.class)){
			ObjectWriter mockWriter = mock(ObjectWriter.class);

			when(JacksonMapperFactory.defaultWriter()).thenReturn(mockWriter);
			when(mockWriter.writeValueAsString(any())).thenThrow(new JsonProcessingException("Mocked exception"){});

			helper.retrieveCartCustomLogs(data);
		}
	}

	@Test
	public void validateCartHelperTest2() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\": \"OMNI-CARE\",\"quoteId\": \"id\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\",\"clientId\":\"VZW-MFA\"},\"channel\":\"assissted\",\"pageId\":\"landing\",\"flow\":\"upgrade\"}";
		String sampleResponseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
		ValidateCartCXPRequest sampleRequest = mapper.readValue(sampleRequestString, ValidateCartCXPRequest.class);
		ValidateCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, ValidateCartUIResponse.class);
		String redisDataString = "{\"caseId\": \"SOP-538499-E01\",\"processingMTN\": \"1234567890\",\"cartCreator\": \"1234567890\"}";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper.upsertOneClickCheckoutFlag(Mockito.any())).thenReturn(Mono.empty());
		Mono<ValidateCartUIResponse> response = helper.validateCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}
	
	@Test
	public void validateCartHelperTest3() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"channelId\": \"VZW-DOTCOM\",\"quoteId\": \"id\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\",\"clientId\":\"VZW-MFA\"},\"channel\":\"assissted\",\"pageId\":\"landing\",\"flow\":\"upgrade\"}";
		String sampleResponseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
		ValidateCartCXPRequest sampleRequest = mapper.readValue(sampleRequestString, ValidateCartCXPRequest.class);
		ValidateCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, ValidateCartUIResponse.class);
		String redisDataString = "{\"caseId\": \"SOP-538499-E01\",\"processingMTN\": \"1234567890\",\"cartCreator\": \"1234567890\"}";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper.upsertOneClickCheckoutFlag(Mockito.any())).thenReturn(Mono.empty());
		when(bpmHelper3.getCases(Mockito.any())).thenReturn(Mono.just(new GetCaseResponse()));
		Mono<ValidateCartUIResponse> response = helper.validateCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}
	
	@Test
	public void validateCartHelperTest4() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"pageId\": \"page\",\"channelId\": \"VZW-DOTCOM\",\"quoteId\": \"id\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\",\"clientId\":\"VZW-MFA\"},\"channel\":\"assissted\",\"pageId\":\"landing\",\"flow\":\"upgrade\"}";
		String sampleResponseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
		ValidateCartCXPRequest sampleRequest = mapper.readValue(sampleRequestString, ValidateCartCXPRequest.class);
		ValidateCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, ValidateCartUIResponse.class);
		String redisDataString = "{\"accountNumber\": \"345678\",\"mtn\": \"76543\",\"caseId\": \"SOP-538499-E01\",\"processingMTN\": \"1234567890\",\"cartCreator\": \"1234567890\"}";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper.upsertOneClickCheckoutFlag(Mockito.any())).thenReturn(Mono.empty());
		when(bpmHelper3.getCases(Mockito.any())).thenReturn(Mono.just(new GetCaseResponse()));
		Mono<ValidateCartUIResponse> response = helper.validateCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}
	
	@Test
	public void validateCartHelperTest5() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"pageId\": \"cart\",\"channelId\": \"VZW-DOTCOM\",\"quoteId\": \"\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\",\"clientId\":\"VZW-MFA\"},\"channel\":\"assissted\",\"pageId\":\"landing\",\"flow\":\"upgrade\"}";
		String sampleResponseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
		ValidateCartCXPRequest sampleRequest = mapper.readValue(sampleRequestString, ValidateCartCXPRequest.class);
		ValidateCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, ValidateCartUIResponse.class);
		String redisDataString = "{\"accountNumber\": \"345678\",\"mtn\": \"\",\"caseId\": \"SOP-538499-E01\",\"processingMTN\": \"1234567890\",\"cartCreator\": \"1234567890\"}";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper.upsertOneClickCheckoutFlag(Mockito.any())).thenReturn(Mono.empty());
		when(bpmHelper3.getCases(Mockito.any())).thenReturn(Mono.just(new GetCaseResponse()));
		Mono<ValidateCartUIResponse> response = helper.validateCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}
	
	@Test
	public void validateCartHelperTest6() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"pageId\": \"cart\",\"channelId\": \"VZW-DOTCOM\",\"quoteId\": \"id\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\",\"clientId\":\"VZW-MFA\"},\"channel\":\"assissted\",\"pageId\":\"landing\",\"flow\":\"upgrade\"}";
		String sampleResponseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
		String responseString = "{\"errors\": [{}]}";
		GetCaseResponse caseResponse = mapper.readValue(responseString, GetCaseResponse.class);
		ValidateCartCXPRequest sampleRequest = mapper.readValue(sampleRequestString, ValidateCartCXPRequest.class);
		ValidateCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, ValidateCartUIResponse.class);
		String redisDataString = "{\"accountNumber\": \"345678\",\"mtn\": \"\",\"caseId\": \"SOP-538499-E01\",\"processingMTN\": \"1234567890\",\"cartCreator\": \"1234567890\"}";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper.upsertOneClickCheckoutFlag(Mockito.any())).thenReturn(Mono.empty());
		when(bpmHelper3.getCases(Mockito.any())).thenReturn(Mono.just(caseResponse));
		Mono<ValidateCartUIResponse> response = helper.validateCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}
	
	@Test
	public void validateCartHelperTest7() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"pageId\": \"cart\",\"channelId\": \"VZW-DOTCOM\",\"quoteId\": \"id\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\",\"clientId\":\"VZW-MFA\"},\"channel\":\"assissted\",\"pageId\":\"landing\",\"flow\":\"upgrade\"}";
		String sampleResponseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
		String responseString = "{\"serviceBody\": {}}";
		GetCaseResponse caseResponse = mapper.readValue(responseString, GetCaseResponse.class);
		ValidateCartCXPRequest sampleRequest = mapper.readValue(sampleRequestString, ValidateCartCXPRequest.class);
		ValidateCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, ValidateCartUIResponse.class);
		String redisDataString = "{\"accountNumber\": \"345678\",\"mtn\": \"\",\"caseId\": \"SOP-538499-E01\",\"processingMTN\": \"1234567890\",\"cartCreator\": \"1234567890\"}";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper.upsertOneClickCheckoutFlag(Mockito.any())).thenReturn(Mono.empty());
		when(bpmHelper3.getCases(Mockito.any())).thenReturn(Mono.just(caseResponse));
		Mono<ValidateCartUIResponse> response = helper.validateCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}

	@Test
	public void validateCartHelperTest8() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"pageId\": \"cart\",\"channelId\": \"VZW-DOTCOM\",\"quoteId\": \"id\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\",\"clientId\":\"VZW-MFA\"},\"channel\":\"assissted\",\"pageId\":\"landing\",\"flow\":\"upgrade\"}";
		String sampleResponseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
		String responseString = "{\"serviceBody\": {\"serviceResponse\": {}}}";
		GetCaseResponse caseResponse = mapper.readValue(responseString, GetCaseResponse.class);
		ValidateCartCXPRequest sampleRequest = mapper.readValue(sampleRequestString, ValidateCartCXPRequest.class);
		ValidateCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, ValidateCartUIResponse.class);
		String redisDataString = "{\"accountNumber\": \"345678\",\"mtn\": \"\",\"caseId\": \"SOP-538499-E01\",\"processingMTN\": \"1234567890\",\"cartCreator\": \"1234567890\"}";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper.upsertOneClickCheckoutFlag(Mockito.any())).thenReturn(Mono.empty());
		when(bpmHelper3.getCases(Mockito.any())).thenReturn(Mono.just(caseResponse));
		Mono<ValidateCartUIResponse> response = helper.validateCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}
	
	@Test
	public void validateCartHelperTest9() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"pageId\": \"cart\",\"channelId\": \"VZW-DOTCOM\",\"quoteId\": \"id\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\",\"clientId\":\"VZW-MFA\"},\"channel\":\"assissted\",\"pageId\":\"landing\",\"flow\":\"upgrade\"}";
		String sampleResponseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
		String responseString = "{\"serviceBody\": {\"serviceResponse\": {\"context\": {}}}}";
		GetCaseResponse caseResponse = mapper.readValue(responseString, GetCaseResponse.class);
		ValidateCartCXPRequest sampleRequest = mapper.readValue(sampleRequestString, ValidateCartCXPRequest.class);
		ValidateCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, ValidateCartUIResponse.class);
		String redisDataString = "{\"accountNumber\": \"345678\",\"mtn\": \"\",\"caseId\": \"SOP-538499-E01\",\"processingMTN\": \"1234567890\",\"cartCreator\": \"1234567890\"}";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper.upsertOneClickCheckoutFlag(Mockito.any())).thenReturn(Mono.empty());
		when(bpmHelper3.getCases(Mockito.any())).thenReturn(Mono.just(caseResponse));
		Mono<ValidateCartUIResponse> response = helper.validateCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}
	
	@Test
	public void validateCartHelperTest10() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"pageId\": \"page\",\"cartId\": \"876543\",\"channelId\": \"VZW-DOTCOM\",\"quoteId\": \"id\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\",\"clientId\":\"VZW-MFA\"},\"channel\":\"assissted\",\"flow\":\"upgrade\"}";
		String sampleResponseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
		String responseString = "{\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseList\": []}}}}";
		GetCaseResponse caseResponse = mapper.readValue(responseString, GetCaseResponse.class);
		ValidateCartCXPRequest sampleRequest = mapper.readValue(sampleRequestString, ValidateCartCXPRequest.class);
		ValidateCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, ValidateCartUIResponse.class);
		String redisDataString = "{\"accountNumber\": \"345678\",\"mtn\": \"\",\"caseId\": \"SOP-538499-E01\",\"processingMTN\": \"1234567890\",\"cartCreator\": \"1234567890\"}";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper.upsertOneClickCheckoutFlag(Mockito.any())).thenReturn(Mono.empty());
		when(bpmHelper3.getCases(Mockito.any())).thenReturn(Mono.just(caseResponse));
		Mono<ValidateCartUIResponse> response = helper.validateCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}
	
	@Test
	public void validateCartHelperTest11() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"pageId\": \"cart\",\"cartId\": \"345678\",\"channelId\": \"VZW-DOTCOM\",\"quoteId\": \"id\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\",\"clientId\":\"VZW-MFA\"},\"channel\":\"assissted\",\"flow\":\"upgrade\"}";
		String sampleResponseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
		String responseString = "{\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseList\": [{}]}}}}";
		GetCaseResponse caseResponse = mapper.readValue(responseString, GetCaseResponse.class);
		ValidateCartCXPRequest sampleRequest = mapper.readValue(sampleRequestString, ValidateCartCXPRequest.class);
		ValidateCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, ValidateCartUIResponse.class);
		String redisDataString = "{\"accountNumber\": \"345678\",\"mtn\": \"\",\"caseId\": \"SOP-538499-E01\",\"processingMTN\": \"1234567890\",\"cartCreator\": \"1234567890\"}";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper.upsertOneClickCheckoutFlag(Mockito.any())).thenReturn(Mono.empty());
		when(bpmHelper3.getCases(Mockito.any())).thenReturn(Mono.just(caseResponse));
		Mono<ValidateCartUIResponse> response = helper.validateCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}
	
	@Test
	public void validateCartHelperTest12() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"cartId\": \"345678\",\"channelId\": \"VZW-DOTCOM\",\"quoteId\": \"id\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\",\"clientId\":\"VZW-MFA\"},\"channel\":\"assissted\",\"flow\":\"upgrade\"}";
		String sampleResponseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
		String responseString = "{\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseList\": [{}]}}}}";
		GetCaseResponse caseResponse = mapper.readValue(responseString, GetCaseResponse.class);
		ValidateCartCXPRequest sampleRequest = mapper.readValue(sampleRequestString, ValidateCartCXPRequest.class);
		ValidateCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, ValidateCartUIResponse.class);
		String redisDataString = "{\"accountNumber\": \"345678\",\"mtn\": \"\",\"caseId\": \"SOP-538499-E01\",\"processingMTN\": \"1234567890\",\"cartCreator\": \"1234567890\"}";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper.upsertOneClickCheckoutFlag(Mockito.any())).thenReturn(Mono.empty());
		when(bpmHelper3.getCases(Mockito.any())).thenReturn(Mono.just(caseResponse));
		Mono<ValidateCartUIResponse> response = helper.validateCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}
	
	@Test
	public void validateCartHelperTest13() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"pageId\": \"cart\",\"mtnList\": [\"\"],\"cartId\": \"345678\",\"channelId\": \"VZW-DOTCOM\",\"quoteId\": \"id\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\",\"clientId\":\"VZW-MFA\"},\"channel\":\"assissted\",\"flow\":\"upgrade\"}";
		String sampleResponseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"}}";
		String responseString = "{\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseList\": [{}]}}}}";
		GetCaseResponse caseResponse = mapper.readValue(responseString, GetCaseResponse.class);
		ValidateCartCXPRequest sampleRequest = mapper.readValue(sampleRequestString, ValidateCartCXPRequest.class);
		ValidateCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, ValidateCartUIResponse.class);
		String redisDataString = "{\"accountNumber\": \"345678\",\"mtn\": \"\",\"caseId\": \"SOP-538499-E01\",\"processingMTN\": \"1234567890\",\"cartCreator\": \"1234567890\"}";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper.upsertOneClickCheckoutFlag(Mockito.any())).thenReturn(Mono.empty());
		when(bpmHelper3.getCases(Mockito.any())).thenReturn(Mono.just(caseResponse));
		Mono<ValidateCartUIResponse> response = helper.validateCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void validateCartHelperTest14() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"pageId\": \"\",\"cartId\": \"345678\",\"channelId\": \"VZW-DOTCOM\",\"quoteId\": \"id\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\",\"clientId\":\"VZW-MFA\"},\"channel\":\"assissted\",\"flow\":\"upgrade\"}";
		String sampleResponseString = "{\"data\": {},\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"}}";
		String responseString = "{\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseList\": [{}]}}}}";
		GetCaseResponse caseResponse = mapper.readValue(responseString, GetCaseResponse.class);
		ValidateCartCXPRequest sampleRequest = mapper.readValue(sampleRequestString, ValidateCartCXPRequest.class);
		ValidateCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, ValidateCartUIResponse.class);
		String redisDataString = "{\"accountNumber\": \"345678\",\"mtn\": \"34567\",\"caseId\": \"SOP-538499-E01\",\"processingMTN\": \"1234567890\",\"cartCreator\": \"1234567890\"}";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper.upsertOneClickCheckoutFlag(Mockito.any())).thenReturn(Mono.empty());
		when(bpmHelper3.getCases(Mockito.any())).thenReturn(Mono.just(caseResponse));
		Mono<ValidateCartUIResponse> response = helper.validateCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}
	
	@Test
	public void validateCartHelperTest15() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"pageId\": \"\",\"cartId\": \"345678\",\"channelId\": \"VZW-DOTCOM\",\"quoteId\": \"id\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\",\"clientId\":\"VZW-MFA\"},\"channel\":\"assissted\",\"flow\":\"upgrade\"}";
		String sampleResponseString = "{\"data\": {\"validateCartAndUpdate\": {\"orderDetails\": {}}},\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"}}";
		String responseString = "{\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseList\": [{}]}}}}";
		GetCaseResponse caseResponse = mapper.readValue(responseString, GetCaseResponse.class);
		ValidateCartCXPRequest sampleRequest = mapper.readValue(sampleRequestString, ValidateCartCXPRequest.class);
		ValidateCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, ValidateCartUIResponse.class);
		String redisDataString = "{\"vzwRoles\": \"mobileSecure\",\"customerFiosPlanType\": \"fios\",\"accountNumber\": \"345678\",\"mtn\": \"4567\",\"caseId\": \"SOP-538499-E01\",\"processingMTN\": \"1234567890\",\"cartCreator\": \"1234567890\"}";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper.upsertOneClickCheckoutFlag(Mockito.any())).thenReturn(Mono.empty());
		when(bpmHelper3.getCases(Mockito.any())).thenReturn(Mono.just(caseResponse));
		Mono<ValidateCartUIResponse> response = helper.validateCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}
	
	@Test
	public void validateCartHelperTest16() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"pageId\": \"\",\"cartId\": \"345678\",\"channelId\": \"VZW-DOTCOM\",\"quoteId\": \"id\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\",\"clientId\":\"VZW-MFA\"},\"channel\":\"assissted\",\"flow\":\"upgrade\"}";
		String sampleResponseString = "{\"data\": {\"validateCartAndUpdate\": {\"cartId\": \"45678\",\"orderDetails\": {\"visionCustomerId\": \"id\"}}},\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"}}";
		String responseString = "{\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseList\": [{}]}}}}";
		GetCaseResponse caseResponse = mapper.readValue(responseString, GetCaseResponse.class);
		ValidateCartCXPRequest sampleRequest = mapper.readValue(sampleRequestString, ValidateCartCXPRequest.class);
		ValidateCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, ValidateCartUIResponse.class);
		String redisDataString = "{\"vzwRoles\": \"accountMember\",\"customerFiosPlanType\": \"Y\",\"accountNumber\": \"345678\",\"mtn\": \"4567\",\"caseId\": \"SOP-538499-E01\",\"processingMTN\": \"1234567890\",\"cartCreator\": \"1234567890\"}";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper.upsertOneClickCheckoutFlag(Mockito.any())).thenReturn(Mono.empty());
		when(bpmHelper3.getCases(Mockito.any())).thenReturn(Mono.just(caseResponse));
		when(redisHelper2.getAccountInfoEligibleFlagFromRedis()).thenReturn(Mono.just(new AccountInfoEligible()));
		Mono<ValidateCartUIResponse> response = helper.validateCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}
	
	@Test
	public void validateCartHelperTest17() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"pageId\": \"\",\"cartId\": \"345678\",\"channelId\": \"VZW-DOTCOM\",\"quoteId\": \"id\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\",\"clientId\":\"VZW-MFA\"},\"channel\":\"assissted\",\"flow\":\"upgrade\"}";
		String sampleResponseString = "{\"data\": {\"validateCartAndUpdate\": {\"cartId\": \"345678\",\"orderDetails\": {\"accountCreateDate\": \"date\",\"visionCustomerId\": \"id\"}}},\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"}}";
		String responseString = "{\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseList\": [{}]}}}}";
		GetCaseResponse caseResponse = mapper.readValue(responseString, GetCaseResponse.class);
		ValidateCartCXPRequest sampleRequest = mapper.readValue(sampleRequestString, ValidateCartCXPRequest.class);
		ValidateCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, ValidateCartUIResponse.class);
		String redisDataString = "{\"vzwRoles\": \"vzw\",\"customerFiosPlanType\": \"Y\",\"accountNumber\": \"345678\",\"mtn\": \"4567\",\"caseId\": \"SOP-538499-E01\",\"processingMTN\": \"1234567890\",\"cartCreator\": \"1234567890\"}";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		AccountInfoEligible accountInfo = mapper.readValue("{\"accountEligibleForEUP\": true}", AccountInfoEligible.class);
		when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper.upsertOneClickCheckoutFlag(Mockito.any())).thenReturn(Mono.empty());
		when(bpmHelper3.getCases(Mockito.any())).thenReturn(Mono.just(caseResponse));
		when(redisHelper2.getAccountInfoEligibleFlagFromRedis()).thenReturn(Mono.just(accountInfo));
		Mono<ValidateCartUIResponse> response = helper.validateCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}
	
	@Test
	public void validateCartHelperTest18() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"pageId\": \"\",\"cartId\": \"345678\",\"channelId\": \"VZW-DOTCOM\",\"quoteId\": \"id\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\",\"clientId\":\"VZW-MFA\"},\"channel\":\"assissted\",\"flow\":\"upgrade\"}";
		String sampleResponseString = "{\"data\": {\"validateCartAndUpdate\": {\"cartId\": \"345678\",\"orderDetails\": {\"existingSpeed\": \"speed\",\"accountCreateDate\": \"date\",\"visionCustomerId\": \"id\"}}},\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"}}";
		String responseString = "{\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseList\": [{}]}}}}";
		GetCaseResponse caseResponse = mapper.readValue(responseString, GetCaseResponse.class);
		ValidateCartCXPRequest sampleRequest = mapper.readValue(sampleRequestString, ValidateCartCXPRequest.class);
		ValidateCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, ValidateCartUIResponse.class);
		String redisDataString = "{\"vzwRoles\": \"vzw\",\"customerFiosPlanType\": \"Y\",\"accountNumber\": \"345678\",\"mtn\": \"4567\",\"caseId\": \"SOP-538499-E01\",\"processingMTN\": \"1234567890\",\"cartCreator\": \"1234567890\"}";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		AccountInfoEligible accountInfo = mapper.readValue("{\"accountEligibleForBYOD\": true}", AccountInfoEligible.class);
		when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper.upsertOneClickCheckoutFlag(Mockito.any())).thenReturn(Mono.empty());
		when(bpmHelper3.getCases(Mockito.any())).thenReturn(Mono.just(caseResponse));
		when(redisHelper2.getAccountInfoEligibleFlagFromRedis()).thenReturn(Mono.just(accountInfo));
		Mono<ValidateCartUIResponse> response = helper.validateCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}
	
	@Test
	public void validateCartHelperTest19() throws IOException, SOEHTTPException {
		String sampleRequestString = "{\"pageId\": \"\",\"cartId\": \"345678\",\"channelId\": \"VZW-DOTCOM\",\"quoteId\": \"id\",\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\",\"clientId\":\"VZW-MFA\"},\"channel\":\"assissted\",\"flow\":\"upgrade\"}";
		String sampleResponseString = "{\"data\": {\"validateCartAndUpdate\": {\"cartId\": \"345678\",\"orderDetails\": {\"accountCreateDate\": \"\",\"visionCustomerId\": \"id\"}}},\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"}}";
		String responseString = "{\"serviceBody\": {\"serviceResponse\": {\"context\": {\"caseList\": [{}]}}}}";
		GetCaseResponse caseResponse = mapper.readValue(responseString, GetCaseResponse.class);
		ValidateCartCXPRequest sampleRequest = mapper.readValue(sampleRequestString, ValidateCartCXPRequest.class);
		ValidateCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, ValidateCartUIResponse.class);
		String redisDataString = "{\"vzwRoles\": \"vzw\",\"customerFiosPlanType\": \"\",\"accountNumber\": \"345678\",\"mtn\": \"4567\",\"caseId\": \"SOP-538499-E01\",\"processingMTN\": \"1234567890\",\"cartCreator\": \"1234567890\"}";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		AccountInfoEligible accountInfo = mapper.readValue("{\"accountEligibleForAAL\": true}", AccountInfoEligible.class);
		when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper.upsertOneClickCheckoutFlag(Mockito.any())).thenReturn(Mono.empty());
		when(bpmHelper3.getCases(Mockito.any())).thenReturn(Mono.just(caseResponse));
		when(redisHelper2.getAccountInfoEligibleFlagFromRedis()).thenReturn(Mono.just(accountInfo));
		Mono<ValidateCartUIResponse> response = helper.validateCart(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}
	@Test
	public void deviceIdValidationProfileTest() throws IOException, SOEHTTPException {
		ReflectionTestUtils.setField(helper, "enableEsimMigrationChanges", true);
		ESimDetailsETNIRequest sampleUIRequest = new ESimDetailsETNIRequest();
		String eidSimDetailsUIResponseString = "{\"data\":{\"simEidResponseBean\":[{\"statusDesc\":\":SUCCESSFUL\",\"statusCode\":\"00000\",\"rowsPop\":\"4\",\"rowIdList\":[{\"vzwImsi\":\"311480111500108\",\"vfImsi\":\"\",\"euimId\":\"A00001122DCDCA\",\"iccidStatus\":\"PA\",\"mdn\":\"7272445960\",\"simCreateDate\":\"2023-09-05-16.09.06.605919\",\"simUpdateDate\":\"2023-11-04-03.19.34.000092\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$8483340509-0503889576\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692229539\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111471934\",\"vfImsi\":\"\",\"euimId\":\"A00001122DCD08\",\"iccidStatus\":\"PA\",\"mdn\":\"6075901699\",\"simCreateDate\":\"2023-09-05-16.09.08.762178\",\"simUpdateDate\":\"2023-11-02-05.58.19.000753\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$6075901699-0211053007\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692227590\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111478472\",\"vfImsi\":\"\",\"euimId\":\"A00001122DC190\",\"iccidStatus\":\"PA\",\"mdn\":\"6075900414\",\"simCreateDate\":\"2023-09-05-16.09.04.131573\",\"simUpdateDate\":\"2023-11-02-05.50.19.000582\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$6075900414-0294247860\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692198239\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111509353\",\"vfImsi\":\"\",\"euimId\":\"A00001122DB7EA\",\"iccidStatus\":\"AI\",\"mdn\":\"9126025456\",\"simCreateDate\":\"2023-09-05-16.09.03.896542\",\"simUpdateDate\":\"2023-11-0113:47:45.000860\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$9126025456-0460441555\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692173539\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"}]}]}}" ;
		EidSimDetailsUIResponse eidSimDetailsUIResponse = mapper.readValue(eidSimDetailsUIResponseString, EidSimDetailsUIResponse.class);
		when(cxpHelper.EidSimDetail(Mockito.any())).thenReturn(Mono.just(eidSimDetailsUIResponse));
		sampleUIRequest.setEid("89049032007008882600092386726095");
		sampleUIRequest.setApplicationId(CartConstants.DEFAULT_APPLICATION_ID);
		sampleUIRequest.setUserId(CartConstants.DEFAULT_USER_ID);
		String sampleRequestString = "{\"channelId\":\"OMNI-RETAIL\",\"cartInfo\":{\"cartCreator\":\"7272445960\",\"cartId\":\"0b95bd88-66ac-4400-a7d2-3c5f43bcbbd5\",\"caseId\":\"SOP-9774000-E01\",\"creditAppNum\":null,\"processingMTN\":\"7272445960\",\"accountNumber\":\"0321747971-00001\",\"intent\":\"BYOD\",\"intendType\":\"BYOD\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":\"validateDeviceSim\",\"action\":\"\",\"makeEtniQeidApi\":true},\"data\":{\"lines\":[{\"mtn\":\"7272445960\",\"eskuId\":\"\",\"device\":{\"id\":\"355843801449939\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"356628100445533\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":false,\"sim\":{\"id\":\"89148000005207167008\",\"sku\":\"\",\"isCustomerProvidedSIM\":false,\"CurrentSimid\":\"89148000005207167008\"}}}]},\"disableEsimAtLocalInventory\":false}";
		String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-RETAIL\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.10.13.02.18.48-880.5654141238181\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-9774000-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"GridWallPDP\"}]},\"customerInfo\":{\"pinCardPayment\":false,\"accountNumber\":\"\",\"cartCreator\":\"7272445960\",\"processingMTN\":\"7272445960\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"0b95bd88-66ac-4400-a7d2-3c5f43bcbbd5\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false},\"deviceInfo\":{\"simInfo\":{\"iccid\":\"89148000005207167008\",\"mfgCode\":\"STM\",\"launchPackageSku\":\"EMBDSIMTRI\",\"prodName\":\"ST Multi-Form-Factor SIM\",\"preferredSoftSim\":\"EMBDSIM5G\",\"launchPackageSkuType\":\"MLR53LL/A\",\"pairedIccid\":\"\",\"type\":\"4GS\",\"mtn\":\"\",\"mobileNumber\":\"\",\"active\":false,\"aging\":false,\"available\":false,\"retired\":false,\"grandFathered\":false,\"status\":\"\",\"euimid\":\"\",\"imsiv\":\"\",\"imsivf\":\"\",\"iccIdStat\":\"\",\"min\":\"\",\"ispuCompatibleSIM\":\"BULKSIM5G-SA-A\",\"makeEtniPersApi\":false,\"deviceId\":\"355843801449939\",\"dfillCompatibleSim\":\"DFILLSIM5G-SA-A\",\"esimid\":\"\",\"eID\":\"7565655576576567565765675\"},\"simInfo2\":{\"iccid\":\"\",\"mfgCode\":\"\",\"launchPackageSku\":\"MLR53LL/A-2\",\"prodName\":\"\",\"preferredSoftSim\":\"SOFTSIM5G-SA-A\",\"launchPackageSkuType\":\"MLR53LL/A-2\",\"pairedIccid\":\"\",\"type\":\"\",\"mtn\":\"\",\"mobileNumber\":\"\",\"active\":false,\"aging\":false,\"available\":false,\"retired\":false,\"grandFathered\":false,\"status\":\"\",\"euimid\":\"\",\"imsiv\":\"\",\"imsivf\":\"\",\"iccIdStat\":\"\",\"min\":\"\",\"ispuCompatibleSIM\":\"BULKSIM5G-SA-A\",\"makeEtniPersApi\":true,\"deviceId\":\"355843801316351\",\"dfillCompatibleSim\":\"DFILLSIM5G-SA-A\",\"esimid\":\"\",\"eID\":\"89049032007008882600117663233736\"},\"deviceSimCompatible\":\"Y\",\"deviceSimM2MPair\":\"N\",\"deviceESimCompatible\":\"N\",\"deviceESimM2MPair\":\"N\",\"deviceId\":\"355843801449939\",\"color\":{\"colorId\":\"clr10520003\",\"displayName\":\"Sierra Blue\",\"description\":\"Blue\",\"colorCssStyle\":\"#A7C1D9\"},\"imageName\":\"apple-iphone-13-pro-sierra-blue-09142021\",\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-thumb$\"},\"skuDisplayName\":\"Apple iPhone 13 Pro 128GB in Sierra Blue\",\"deviceSku\":\"MLR53LL/A\",\"isRestrictedDevice\":\"N\",\"deviceAttributes\":{\"mfgCode\":\"APL\",\"mfgName\":\"Apple\",\"prodName\":\"IPHONE 13 PRO 128 SIERRA BLUE\",\"prodType\":\"5GSmartphone\",\"equipModeCode\":\"5GE\",\"equipMode\":\"5GDevice\",\"gpsIndicator\":\"Y\",\"daccCode\":\"01661\",\"deviceType\":\"5GE\",\"deviceCategory\":\"5G Smartphone\",\"productId\":\"dev16720003\",\"postpaidRestrictStartDate\":\"\",\"prepayRestrictStartDate\":\"\",\"wholesaleRestrictStartDate\":\"\"},\"lostAndStolen\":{\"lostStolen\":\"N\",\"nonPay\":\"N\"},\"numbershareCapability\":\"\",\"price\":{\"fullRetailPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"Full Retail Price\"},\"oneYearPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"One Year Price\"},\"devicePaymentPrice\":[]},\"skipSimIdFlag\":true,\"appleWatchFlag\":false,\"fmipLocked\":false,\"appleCarrieLock\":false,\"e911AddrInd\":\"\",\"simClass4G\":\"PI\",\"makeEtniPersApi\":false,\"softMessages\":[],\"standalonePairingEligible\":true,\"deviceFamilyType\":\"Phone\",\"osType\":\"Apple iOS\",\"euiccCapable\":\"Y\",\"imei1\":\"355843801449939\",\"imei2\":\"355843801316351\",\"productFamily\":\"iPhone 13 Pro\",\"pairedImeiData\":{\"pairedImei\":\"353207331839021\",\"eid\":\"89049032007008882600127471300369\",\"sku\":\"MLA23LL/A\",\"preferredSim\":\"DFILLSIM5G-SA-A\",\"devicePreferredSoftSim\":\"SOFTSIM5G-SA-D\",\"simClass4G\":\"PI\",\"euiccCapable\":true},\"eSIMOnly\":false,\"profileState\":\"CO\"}}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationUIResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"creditAppNum\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<DeviceIdValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.deviceIdValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cxpHelper2.deviceIdValidation(Mockito.any(),Mockito.any())).thenReturn(sampleResponseMono);
		DeviceIdValidationUIResponse expectedResponse = sampleResponse;
		when(cxpHelper.getSmartImeiDevices(Mockito.anyString(),Mockito.anyString())).thenReturn(Mono.just(getSmartImeiDevicesResponse()));
		Mono<DeviceIdValidationUIResponse> response = helper.deviceIdValidation(sampleRequest);
		sampleResponse.getServiceBody().getServiceResponse().getContext().getDeviceInfo().setPairedImeiData(new PairedImeiData());
		sampleResponse.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getPairedImeiData().setEid("1234");
		Mono<DeviceIdValidationUIResponse> response2 = helper.eidSimDetails(sampleResponse,sampleRequest);

		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response2).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void deviceIdValidationProfileTestINDIRECT() throws IOException, SOEHTTPException {
		ReflectionTestUtils.setField(helper, "enableEsimMigrationChanges", true);
		ESimDetailsETNIRequest sampleUIRequest = new ESimDetailsETNIRequest();
		String eidSimDetailsUIResponseString = "{\"data\":{\"simEidResponseBean\":[{\"statusDesc\":\":SUCCESSFUL\",\"statusCode\":\"00000\",\"rowsPop\":\"4\",\"rowIdList\":[{\"vzwImsi\":\"311480111500108\",\"vfImsi\":\"\",\"euimId\":\"A00001122DCDCA\",\"iccidStatus\":\"PA\",\"mdn\":\"7272445960\",\"simCreateDate\":\"2023-09-05-16.09.06.605919\",\"simUpdateDate\":\"2023-11-04-03.19.34.000092\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$8483340509-0503889576\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692229539\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111471934\",\"vfImsi\":\"\",\"euimId\":\"A00001122DCD08\",\"iccidStatus\":\"PA\",\"mdn\":\"6075901699\",\"simCreateDate\":\"2023-09-05-16.09.08.762178\",\"simUpdateDate\":\"2023-11-02-05.58.19.000753\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$6075901699-0211053007\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692227590\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111478472\",\"vfImsi\":\"\",\"euimId\":\"A00001122DC190\",\"iccidStatus\":\"PA\",\"mdn\":\"6075900414\",\"simCreateDate\":\"2023-09-05-16.09.04.131573\",\"simUpdateDate\":\"2023-11-02-05.50.19.000582\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$6075900414-0294247860\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692198239\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111509353\",\"vfImsi\":\"\",\"euimId\":\"A00001122DB7EA\",\"iccidStatus\":\"AI\",\"mdn\":\"9126025456\",\"simCreateDate\":\"2023-09-05-16.09.03.896542\",\"simUpdateDate\":\"2023-11-0113:47:45.000860\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$9126025456-0460441555\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692173539\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"}]}]}}" ;
		EidSimDetailsUIResponse eidSimDetailsUIResponse = mapper.readValue(eidSimDetailsUIResponseString, EidSimDetailsUIResponse.class);
		when(cxpHelper.EidSimDetail(Mockito.any())).thenReturn(Mono.just(eidSimDetailsUIResponse));
		sampleUIRequest.setEid("89049032007008882600092386726095");
		sampleUIRequest.setApplicationId(CartConstants.DEFAULT_APPLICATION_ID);
		sampleUIRequest.setUserId(CartConstants.DEFAULT_USER_ID);
		String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT\",\"cartInfo\":{\"cartCreator\":\"7272445960\",\"cartId\":\"0b95bd88-66ac-4400-a7d2-3c5f43bcbbd5\",\"caseId\":\"SOP-9774000-E01\",\"creditAppNum\":null,\"processingMTN\":\"7272445960\",\"accountNumber\":\"0321747971-00001\",\"intent\":\"BYOD\",\"intendType\":\"BYOD\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":\"validateDeviceSim\",\"action\":\"\",\"makeEtniQeidApi\":true},\"data\":{\"lines\":[{\"mtn\":\"7272445960\",\"eskuId\":\"\",\"device\":{\"id\":\"355843801449939\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"356628100445533\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":false,\"sim\":{\"id\":\"89148000005207167008\",\"sku\":\"\",\"isCustomerProvidedSIM\":false,\"CurrentSimid\":\"89148000005207167008\"}}}]},\"disableEsimAtLocalInventory\":false}";
		String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-INDIRECT\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.10.13.02.18.48-880.5654141238181\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-9774000-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"GridWallPDP\"}]},\"customerInfo\":{\"pinCardPayment\":false,\"accountNumber\":\"\",\"cartCreator\":\"7272445960\",\"processingMTN\":\"7272445960\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"0b95bd88-66ac-4400-a7d2-3c5f43bcbbd5\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false},\"deviceInfo\":{\"simInfo\":{\"iccid\":\"89148000005207167008\",\"mfgCode\":\"STM\",\"launchPackageSku\":\"EMBDSIMTRI\",\"prodName\":\"ST Multi-Form-Factor SIM\",\"preferredSoftSim\":\"EMBDSIM5G\",\"launchPackageSkuType\":\"MLR53LL/A\",\"pairedIccid\":\"\",\"type\":\"4GS\",\"mtn\":\"\",\"mobileNumber\":\"\",\"active\":false,\"aging\":false,\"available\":false,\"retired\":false,\"grandFathered\":false,\"status\":\"\",\"euimid\":\"\",\"imsiv\":\"\",\"imsivf\":\"\",\"iccIdStat\":\"\",\"min\":\"\",\"ispuCompatibleSIM\":\"BULKSIM5G-SA-A\",\"makeEtniPersApi\":false,\"deviceId\":\"355843801449939\",\"dfillCompatibleSim\":\"DFILLSIM5G-SA-A\",\"esimid\":\"\",\"eID\":\"\"},\"simInfo2\":{\"iccid\":\"\",\"mfgCode\":\"\",\"launchPackageSku\":\"MLR53LL/A-2\",\"prodName\":\"\",\"preferredSoftSim\":\"SOFTSIM5G-SA-A\",\"launchPackageSkuType\":\"MLR53LL/A-2\",\"pairedIccid\":\"\",\"type\":\"\",\"mtn\":\"\",\"mobileNumber\":\"\",\"active\":false,\"aging\":false,\"available\":false,\"retired\":false,\"grandFathered\":false,\"status\":\"\",\"euimid\":\"\",\"imsiv\":\"\",\"imsivf\":\"\",\"iccIdStat\":\"\",\"min\":\"\",\"ispuCompatibleSIM\":\"BULKSIM5G-SA-A\",\"makeEtniPersApi\":true,\"deviceId\":\"355843801316351\",\"dfillCompatibleSim\":\"DFILLSIM5G-SA-A\",\"esimid\":\"\",\"eID\":\"89049032007008882600117663233736\"},\"deviceSimCompatible\":\"Y\",\"deviceSimM2MPair\":\"N\",\"deviceESimCompatible\":\"N\",\"deviceESimM2MPair\":\"N\",\"deviceId\":\"355843801449939\",\"color\":{\"colorId\":\"clr10520003\",\"displayName\":\"Sierra Blue\",\"description\":\"Blue\",\"colorCssStyle\":\"#A7C1D9\"},\"imageName\":\"apple-iphone-13-pro-sierra-blue-09142021\",\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-thumb$\"},\"skuDisplayName\":\"Apple iPhone 13 Pro 128GB in Sierra Blue\",\"deviceSku\":\"MLR53LL/A\",\"isRestrictedDevice\":\"N\",\"deviceAttributes\":{\"mfgCode\":\"APL\",\"mfgName\":\"Apple\",\"prodName\":\"IPHONE 13 PRO 128 SIERRA BLUE\",\"prodType\":\"5GSmartphone\",\"equipModeCode\":\"5GE\",\"equipMode\":\"5GDevice\",\"gpsIndicator\":\"Y\",\"daccCode\":\"01661\",\"deviceType\":\"5GE\",\"deviceCategory\":\"5G Smartphone\",\"productId\":\"dev16720003\",\"postpaidRestrictStartDate\":\"\",\"prepayRestrictStartDate\":\"\",\"wholesaleRestrictStartDate\":\"\"},\"lostAndStolen\":{\"lostStolen\":\"N\",\"nonPay\":\"N\"},\"numbershareCapability\":\"\",\"price\":{\"fullRetailPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"Full Retail Price\"},\"oneYearPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"One Year Price\"},\"devicePaymentPrice\":[]},\"skipSimIdFlag\":true,\"appleWatchFlag\":false,\"fmipLocked\":false,\"appleCarrieLock\":false,\"e911AddrInd\":\"\",\"simClass4G\":\"PI\",\"makeEtniPersApi\":false,\"softMessages\":[],\"standalonePairingEligible\":true,\"deviceFamilyType\":\"Phone\",\"osType\":\"Apple iOS\",\"euiccCapable\":\"Y\",\"imei1\":\"355843801449939\",\"imei2\":\"355843801316351\",\"productFamily\":\"iPhone 13 Pro\",\"pairedImeiData\":{\"pairedImei\":\"353207331839021\",\"eid\":\"89049032007008882600127471300369\",\"sku\":\"MLA23LL/A\",\"preferredSim\":\"DFILLSIM5G-SA-A\",\"devicePreferredSoftSim\":\"SOFTSIM5G-SA-D\",\"simClass4G\":\"PI\",\"euiccCapable\":true},\"eSIMOnly\":false,\"profileState\":\"CO\"}}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationUIResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"creditAppNum\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<DeviceIdValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.deviceIdValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cxpHelper2.deviceIdValidation(Mockito.any(),Mockito.any())).thenReturn(sampleResponseMono);
		DeviceIdValidationUIResponse expectedResponse = sampleResponse;
		when(cxpHelper.getSmartImeiDevices(Mockito.anyString(),Mockito.anyString())).thenReturn(Mono.just(getSmartImeiDevicesResponse()));
		Mono<DeviceIdValidationUIResponse> response = helper.deviceIdValidation(sampleRequest);
		sampleResponse.getServiceBody().getServiceResponse().getContext().getDeviceInfo().setPairedImeiData(new PairedImeiData());
		sampleResponse.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getPairedImeiData().setEid("1234");
		Mono<DeviceIdValidationUIResponse> response2 = helper.eidSimDetails(sampleResponse,sampleRequest);

		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response2).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void deviceIdValidationProfileTestINDIRECTTAB() throws IOException, SOEHTTPException {
		ReflectionTestUtils.setField(helper, "enableEsimMigrationChanges", true);
		ESimDetailsETNIRequest sampleUIRequest = new ESimDetailsETNIRequest();
		String eidSimDetailsUIResponseString = "{\"data\":{\"simEidResponseBean\":[{\"statusDesc\":\":SUCCESSFUL\",\"statusCode\":\"00000\",\"rowsPop\":\"4\",\"rowIdList\":[{\"vzwImsi\":\"311480111500108\",\"vfImsi\":\"\",\"euimId\":\"A00001122DCDCA\",\"iccidStatus\":\"PA\",\"mdn\":\"7272445960\",\"simCreateDate\":\"2023-09-05-16.09.06.605919\",\"simUpdateDate\":\"2023-11-04-03.19.34.000092\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$8483340509-0503889576\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692229539\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111471934\",\"vfImsi\":\"\",\"euimId\":\"A00001122DCD08\",\"iccidStatus\":\"PA\",\"mdn\":\"6075901699\",\"simCreateDate\":\"2023-09-05-16.09.08.762178\",\"simUpdateDate\":\"2023-11-02-05.58.19.000753\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$6075901699-0211053007\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692227590\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111478472\",\"vfImsi\":\"\",\"euimId\":\"A00001122DC190\",\"iccidStatus\":\"PA\",\"mdn\":\"6075900414\",\"simCreateDate\":\"2023-09-05-16.09.04.131573\",\"simUpdateDate\":\"2023-11-02-05.50.19.000582\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$6075900414-0294247860\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692198239\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111509353\",\"vfImsi\":\"\",\"euimId\":\"A00001122DB7EA\",\"iccidStatus\":\"AI\",\"mdn\":\"9126025456\",\"simCreateDate\":\"2023-09-05-16.09.03.896542\",\"simUpdateDate\":\"2023-11-0113:47:45.000860\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$9126025456-0460441555\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692173539\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"}]}]}}" ;
		EidSimDetailsUIResponse eidSimDetailsUIResponse = mapper.readValue(eidSimDetailsUIResponseString, EidSimDetailsUIResponse.class);
		when(cxpHelper.EidSimDetail(Mockito.any())).thenReturn(Mono.just(eidSimDetailsUIResponse));
		sampleUIRequest.setEid("89049032007008882600092386726095");
		sampleUIRequest.setApplicationId(CartConstants.DEFAULT_APPLICATION_ID);
		sampleUIRequest.setUserId(CartConstants.DEFAULT_USER_ID);
		String sampleRequestString = "{\"channelId\":\"OMNI-INDIRECT-TAB\",\"cartInfo\":{\"cartCreator\":\"7272445960\",\"cartId\":\"0b95bd88-66ac-4400-a7d2-3c5f43bcbbd5\",\"caseId\":\"SOP-9774000-E01\",\"creditAppNum\":null,\"processingMTN\":\"7272445960\",\"accountNumber\":\"0321747971-00001\",\"intent\":\"BYOD\",\"intendType\":\"BYOD\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":\"validateDeviceSim\",\"action\":\"\",\"makeEtniQeidApi\":true},\"data\":{\"lines\":[{\"mtn\":\"7272445960\",\"eskuId\":\"\",\"device\":{\"id\":\"355843801449939\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"356628100445533\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":false,\"sim\":{\"id\":\"89148000005207167008\",\"sku\":\"\",\"isCustomerProvidedSIM\":false,\"CurrentSimid\":\"89148000005207167008\"}}}]},\"disableEsimAtLocalInventory\":false}";
		String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-INDIRECT-TAB\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.10.13.02.18.48-880.5654141238181\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-9774000-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"GridWallPDP\"}]},\"customerInfo\":{\"pinCardPayment\":false,\"accountNumber\":\"\",\"cartCreator\":\"7272445960\",\"processingMTN\":\"7272445960\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"0b95bd88-66ac-4400-a7d2-3c5f43bcbbd5\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false},\"deviceInfo\":{\"simInfo\":{\"iccid\":\"89148000005207167008\",\"mfgCode\":\"STM\",\"launchPackageSku\":\"EMBDSIMTRI\",\"prodName\":\"ST Multi-Form-Factor SIM\",\"preferredSoftSim\":\"EMBDSIM5G\",\"launchPackageSkuType\":\"MLR53LL/A\",\"pairedIccid\":\"\",\"type\":\"4GS\",\"mtn\":\"\",\"mobileNumber\":\"\",\"active\":false,\"aging\":false,\"available\":false,\"retired\":false,\"grandFathered\":false,\"status\":\"\",\"euimid\":\"\",\"imsiv\":\"\",\"imsivf\":\"\",\"iccIdStat\":\"\",\"min\":\"\",\"ispuCompatibleSIM\":\"BULKSIM5G-SA-A\",\"makeEtniPersApi\":false,\"deviceId\":\"355843801449939\",\"dfillCompatibleSim\":\"DFILLSIM5G-SA-A\",\"esimid\":\"\",\"eID\":\"\"},\"simInfo2\":{\"iccid\":\"\",\"mfgCode\":\"\",\"launchPackageSku\":\"MLR53LL/A-2\",\"prodName\":\"\",\"preferredSoftSim\":\"SOFTSIM5G-SA-A\",\"launchPackageSkuType\":\"MLR53LL/A-2\",\"pairedIccid\":\"\",\"type\":\"\",\"mtn\":\"\",\"mobileNumber\":\"\",\"active\":false,\"aging\":false,\"available\":false,\"retired\":false,\"grandFathered\":false,\"status\":\"\",\"euimid\":\"\",\"imsiv\":\"\",\"imsivf\":\"\",\"iccIdStat\":\"\",\"min\":\"\",\"ispuCompatibleSIM\":\"BULKSIM5G-SA-A\",\"makeEtniPersApi\":true,\"deviceId\":\"355843801316351\",\"dfillCompatibleSim\":\"DFILLSIM5G-SA-A\",\"esimid\":\"\",\"eID\":\"89049032007008882600117663233736\"},\"deviceSimCompatible\":\"Y\",\"deviceSimM2MPair\":\"N\",\"deviceESimCompatible\":\"N\",\"deviceESimM2MPair\":\"N\",\"deviceId\":\"355843801449939\",\"color\":{\"colorId\":\"clr10520003\",\"displayName\":\"Sierra Blue\",\"description\":\"Blue\",\"colorCssStyle\":\"#A7C1D9\"},\"imageName\":\"apple-iphone-13-pro-sierra-blue-09142021\",\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-thumb$\"},\"skuDisplayName\":\"Apple iPhone 13 Pro 128GB in Sierra Blue\",\"deviceSku\":\"MLR53LL/A\",\"isRestrictedDevice\":\"N\",\"deviceAttributes\":{\"mfgCode\":\"APL\",\"mfgName\":\"Apple\",\"prodName\":\"IPHONE 13 PRO 128 SIERRA BLUE\",\"prodType\":\"5GSmartphone\",\"equipModeCode\":\"5GE\",\"equipMode\":\"5GDevice\",\"gpsIndicator\":\"Y\",\"daccCode\":\"01661\",\"deviceType\":\"5GE\",\"deviceCategory\":\"5G Smartphone\",\"productId\":\"dev16720003\",\"postpaidRestrictStartDate\":\"\",\"prepayRestrictStartDate\":\"\",\"wholesaleRestrictStartDate\":\"\"},\"lostAndStolen\":{\"lostStolen\":\"N\",\"nonPay\":\"N\"},\"numbershareCapability\":\"\",\"price\":{\"fullRetailPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"Full Retail Price\"},\"oneYearPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"One Year Price\"},\"devicePaymentPrice\":[]},\"skipSimIdFlag\":true,\"appleWatchFlag\":false,\"fmipLocked\":false,\"appleCarrieLock\":false,\"e911AddrInd\":\"\",\"simClass4G\":\"PI\",\"makeEtniPersApi\":false,\"softMessages\":[],\"standalonePairingEligible\":true,\"deviceFamilyType\":\"Phone\",\"osType\":\"Apple iOS\",\"euiccCapable\":\"Y\",\"imei1\":\"355843801449939\",\"imei2\":\"355843801316351\",\"productFamily\":\"iPhone 13 Pro\",\"pairedImeiData\":{\"pairedImei\":\"353207331839021\",\"eid\":\"89049032007008882600127471300369\",\"sku\":\"MLA23LL/A\",\"preferredSim\":\"DFILLSIM5G-SA-A\",\"devicePreferredSoftSim\":\"SOFTSIM5G-SA-D\",\"simClass4G\":\"PI\",\"euiccCapable\":true},\"eSIMOnly\":false,\"profileState\":\"CO\"}}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationUIResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"creditAppNum\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<DeviceIdValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.deviceIdValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cxpHelper2.deviceIdValidation(Mockito.any(),Mockito.any())).thenReturn(sampleResponseMono);
		DeviceIdValidationUIResponse expectedResponse = sampleResponse;
		when(cxpHelper.getSmartImeiDevices(Mockito.anyString(),Mockito.anyString())).thenReturn(Mono.just(getSmartImeiDevicesResponse()));
		Mono<DeviceIdValidationUIResponse> response = helper.deviceIdValidation(sampleRequest);
		sampleResponse.getServiceBody().getServiceResponse().getContext().getDeviceInfo().setPairedImeiData(new PairedImeiData());
		sampleResponse.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getPairedImeiData().setEid("1234");
		Mono<DeviceIdValidationUIResponse> response2 = helper.eidSimDetails(sampleResponse,sampleRequest);

		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response2).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void deviceIdValidationProfileTestRetailTAB() throws IOException, SOEHTTPException {
		ReflectionTestUtils.setField(helper, "enableEsimMigrationChanges", true);
		ESimDetailsETNIRequest sampleUIRequest = new ESimDetailsETNIRequest();
		String eidSimDetailsUIResponseString = "{\"data\":{\"simEidResponseBean\":[{\"statusDesc\":\":SUCCESSFUL\",\"statusCode\":\"00000\",\"rowsPop\":\"4\",\"rowIdList\":[{\"vzwImsi\":\"311480111500108\",\"vfImsi\":\"\",\"euimId\":\"A00001122DCDCA\",\"iccidStatus\":\"PA\",\"mdn\":\"7272445960\",\"simCreateDate\":\"2023-09-05-16.09.06.605919\",\"simUpdateDate\":\"2023-11-04-03.19.34.000092\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$8483340509-0503889576\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692229539\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111471934\",\"vfImsi\":\"\",\"euimId\":\"A00001122DCD08\",\"iccidStatus\":\"PA\",\"mdn\":\"6075901699\",\"simCreateDate\":\"2023-09-05-16.09.08.762178\",\"simUpdateDate\":\"2023-11-02-05.58.19.000753\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$6075901699-0211053007\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692227590\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111478472\",\"vfImsi\":\"\",\"euimId\":\"A00001122DC190\",\"iccidStatus\":\"PA\",\"mdn\":\"6075900414\",\"simCreateDate\":\"2023-09-05-16.09.04.131573\",\"simUpdateDate\":\"2023-11-02-05.50.19.000582\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$6075900414-0294247860\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692198239\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111509353\",\"vfImsi\":\"\",\"euimId\":\"A00001122DB7EA\",\"iccidStatus\":\"AI\",\"mdn\":\"9126025456\",\"simCreateDate\":\"2023-09-05-16.09.03.896542\",\"simUpdateDate\":\"2023-11-0113:47:45.000860\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$9126025456-0460441555\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692173539\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"}]}]}}" ;
		EidSimDetailsUIResponse eidSimDetailsUIResponse = mapper.readValue(eidSimDetailsUIResponseString, EidSimDetailsUIResponse.class);
		when(cxpHelper.EidSimDetail(Mockito.any())).thenReturn(Mono.just(eidSimDetailsUIResponse));
		sampleUIRequest.setEid("89049032007008882600092386726095");
		sampleUIRequest.setApplicationId(CartConstants.DEFAULT_APPLICATION_ID);
		sampleUIRequest.setUserId(CartConstants.DEFAULT_USER_ID);
		String sampleRequestString = "{\"channelId\":\"OMNI-RETAIL-TAB\",\"cartInfo\":{\"cartCreator\":\"7272445960\",\"cartId\":\"0b95bd88-66ac-4400-a7d2-3c5f43bcbbd5\",\"caseId\":\"SOP-9774000-E01\",\"creditAppNum\":null,\"processingMTN\":\"7272445960\",\"accountNumber\":\"0321747971-00001\",\"intent\":\"BYOD\",\"intendType\":\"BYOD\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":\"validateDeviceSim\",\"action\":\"\",\"makeEtniQeidApi\":true},\"data\":{\"lines\":[{\"mtn\":\"7272445960\",\"eskuId\":\"\",\"device\":{\"id\":\"355843801449939\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"356628100445533\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":false,\"sim\":{\"id\":\"89148000005207167008\",\"sku\":\"\",\"isCustomerProvidedSIM\":false,\"CurrentSimid\":\"89148000005207167008\"}}}]},\"disableEsimAtLocalInventory\":false}";
		String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-RETAIL-TAB\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.10.13.02.18.48-880.5654141238181\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-9774000-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"GridWallPDP\"}]},\"customerInfo\":{\"pinCardPayment\":false,\"accountNumber\":\"\",\"cartCreator\":\"7272445960\",\"processingMTN\":\"7272445960\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"0b95bd88-66ac-4400-a7d2-3c5f43bcbbd5\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false},\"deviceInfo\":{\"simInfo\":{\"iccid\":\"89148000005207167008\",\"mfgCode\":\"STM\",\"launchPackageSku\":\"EMBDSIMTRI\",\"prodName\":\"ST Multi-Form-Factor SIM\",\"preferredSoftSim\":\"EMBDSIM5G\",\"launchPackageSkuType\":\"MLR53LL/A\",\"pairedIccid\":\"\",\"type\":\"4GS\",\"mtn\":\"\",\"mobileNumber\":\"\",\"active\":false,\"aging\":false,\"available\":false,\"retired\":false,\"grandFathered\":false,\"status\":\"\",\"euimid\":\"\",\"imsiv\":\"\",\"imsivf\":\"\",\"iccIdStat\":\"\",\"min\":\"\",\"ispuCompatibleSIM\":\"BULKSIM5G-SA-A\",\"makeEtniPersApi\":false,\"deviceId\":\"355843801449939\",\"dfillCompatibleSim\":\"DFILLSIM5G-SA-A\",\"esimid\":\"\",\"eID\":\"\"},\"simInfo2\":{\"iccid\":\"\",\"mfgCode\":\"\",\"launchPackageSku\":\"MLR53LL/A-2\",\"prodName\":\"\",\"preferredSoftSim\":\"SOFTSIM5G-SA-A\",\"launchPackageSkuType\":\"MLR53LL/A-2\",\"pairedIccid\":\"\",\"type\":\"\",\"mtn\":\"\",\"mobileNumber\":\"\",\"active\":false,\"aging\":false,\"available\":false,\"retired\":false,\"grandFathered\":false,\"status\":\"\",\"euimid\":\"\",\"imsiv\":\"\",\"imsivf\":\"\",\"iccIdStat\":\"\",\"min\":\"\",\"ispuCompatibleSIM\":\"BULKSIM5G-SA-A\",\"makeEtniPersApi\":true,\"deviceId\":\"355843801316351\",\"dfillCompatibleSim\":\"DFILLSIM5G-SA-A\",\"esimid\":\"\",\"eID\":\"89049032007008882600117663233736\"},\"deviceSimCompatible\":\"Y\",\"deviceSimM2MPair\":\"N\",\"deviceESimCompatible\":\"N\",\"deviceESimM2MPair\":\"N\",\"deviceId\":\"355843801449939\",\"color\":{\"colorId\":\"clr10520003\",\"displayName\":\"Sierra Blue\",\"description\":\"Blue\",\"colorCssStyle\":\"#A7C1D9\"},\"imageName\":\"apple-iphone-13-pro-sierra-blue-09142021\",\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-thumb$\"},\"skuDisplayName\":\"Apple iPhone 13 Pro 128GB in Sierra Blue\",\"deviceSku\":\"MLR53LL/A\",\"isRestrictedDevice\":\"N\",\"deviceAttributes\":{\"mfgCode\":\"APL\",\"mfgName\":\"Apple\",\"prodName\":\"IPHONE 13 PRO 128 SIERRA BLUE\",\"prodType\":\"5GSmartphone\",\"equipModeCode\":\"5GE\",\"equipMode\":\"5GDevice\",\"gpsIndicator\":\"Y\",\"daccCode\":\"01661\",\"deviceType\":\"5GE\",\"deviceCategory\":\"5G Smartphone\",\"productId\":\"dev16720003\",\"postpaidRestrictStartDate\":\"\",\"prepayRestrictStartDate\":\"\",\"wholesaleRestrictStartDate\":\"\"},\"lostAndStolen\":{\"lostStolen\":\"N\",\"nonPay\":\"N\"},\"numbershareCapability\":\"\",\"price\":{\"fullRetailPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"Full Retail Price\"},\"oneYearPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"One Year Price\"},\"devicePaymentPrice\":[]},\"skipSimIdFlag\":true,\"appleWatchFlag\":false,\"fmipLocked\":false,\"appleCarrieLock\":false,\"e911AddrInd\":\"\",\"simClass4G\":\"PI\",\"makeEtniPersApi\":false,\"softMessages\":[],\"standalonePairingEligible\":true,\"deviceFamilyType\":\"Phone\",\"osType\":\"Apple iOS\",\"euiccCapable\":\"Y\",\"imei1\":\"355843801449939\",\"imei2\":\"355843801316351\",\"productFamily\":\"iPhone 13 Pro\",\"pairedImeiData\":{\"pairedImei\":\"353207331839021\",\"eid\":\"89049032007008882600127471300369\",\"sku\":\"MLA23LL/A\",\"preferredSim\":\"DFILLSIM5G-SA-A\",\"devicePreferredSoftSim\":\"SOFTSIM5G-SA-D\",\"simClass4G\":\"PI\",\"euiccCapable\":true},\"eSIMOnly\":false,\"profileState\":\"CO\"}}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationUIResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"creditAppNum\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<DeviceIdValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.deviceIdValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cxpHelper2.deviceIdValidation(Mockito.any(),Mockito.any())).thenReturn(sampleResponseMono);
		DeviceIdValidationUIResponse expectedResponse = sampleResponse;
		when(cxpHelper.getSmartImeiDevices(Mockito.anyString(),Mockito.anyString())).thenReturn(Mono.just(getSmartImeiDevicesResponse()));
		Mono<DeviceIdValidationUIResponse> response = helper.deviceIdValidation(sampleRequest);
		sampleResponse.getServiceBody().getServiceResponse().getContext().getDeviceInfo().setPairedImeiData(new PairedImeiData());
		sampleResponse.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getPairedImeiData().setEid("1234");
		Mono<DeviceIdValidationUIResponse> response2 = helper.eidSimDetails(sampleResponse,sampleRequest);

		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response2).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void deviceIdValidationProfileErrorTestRetailTAB() throws IOException, SOEHTTPException {
		ReflectionTestUtils.setField(helper, "enableEsimMigrationChanges", true);
		ESimDetailsETNIRequest sampleUIRequest = new ESimDetailsETNIRequest();
		String eidSimDetailsUIResponseString = "{\"errors\":[{\"namespace\":\"cxp-mdnqueryservices-domain\",\"name\":\"DATA_ERROR\",\"message\":\":ROWNOTFOUNDINSIM_INV;INVALIDEID;EID=89049032007008882600092386726\",\"code\":\"20068\"}]}\"\"{\"errors\":[{\"namespace\":\"cxp-mdnqueryservices-domain\",\"name\":\"DATA_ERROR\",\"message\":\":ROWNOTFOUNDINSIM_INV;INVALIDEID;EID=89049032007008882600092386726\",\"code\":\"20068\"}]}";
		EidSimDetailsUIResponse eidSimDetailsUIResponse = mapper.readValue(eidSimDetailsUIResponseString, EidSimDetailsUIResponse.class);
		when(cxpHelper.EidSimDetail(Mockito.any())).thenReturn(Mono.just(eidSimDetailsUIResponse));
		sampleUIRequest.setEid("89049032007008882600092386726095");
		sampleUIRequest.setApplicationId(CartConstants.DEFAULT_APPLICATION_ID);
		sampleUIRequest.setUserId(CartConstants.DEFAULT_USER_ID);
		String sampleRequestString = "{\"channelId\":\"OMNI-RETAIL-TAB\",\"cartInfo\":{\"cartCreator\":\"7272445960\",\"cartId\":\"0b95bd88-66ac-4400-a7d2-3c5f43bcbbd5\",\"caseId\":\"SOP-9774000-E01\",\"creditAppNum\":null,\"processingMTN\":\"7272445960\",\"accountNumber\":\"0321747971-00001\",\"intent\":\"BYOD\",\"intendType\":\"BYOD\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":\"validateDeviceSim\",\"action\":\"\",\"makeEtniQeidApi\":true},\"data\":{\"lines\":[{\"mtn\":\"7272445960\",\"eskuId\":\"\",\"device\":{\"id\":\"355843801449939\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"356628100445533\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":false,\"sim\":{\"id\":\"89148000005207167008\",\"sku\":\"\",\"isCustomerProvidedSIM\":false,\"CurrentSimid\":\"89148000005207167008\"}}}]},\"disableEsimAtLocalInventory\":false}";
		String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-RETAIL-TAB\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.10.13.02.18.48-880.5654141238181\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-9774000-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"GridWallPDP\"}]},\"customerInfo\":{\"pinCardPayment\":false,\"accountNumber\":\"\",\"cartCreator\":\"7272445960\",\"processingMTN\":\"7272445960\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"0b95bd88-66ac-4400-a7d2-3c5f43bcbbd5\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false},\"deviceInfo\":{\"simInfo\":{\"iccid\":\"89148000005207167008\",\"mfgCode\":\"STM\",\"launchPackageSku\":\"EMBDSIMTRI\",\"prodName\":\"ST Multi-Form-Factor SIM\",\"preferredSoftSim\":\"EMBDSIM5G\",\"launchPackageSkuType\":\"MLR53LL/A\",\"pairedIccid\":\"\",\"type\":\"4GS\",\"mtn\":\"\",\"mobileNumber\":\"\",\"active\":false,\"aging\":false,\"available\":false,\"retired\":false,\"grandFathered\":false,\"status\":\"\",\"euimid\":\"\",\"imsiv\":\"\",\"imsivf\":\"\",\"iccIdStat\":\"\",\"min\":\"\",\"ispuCompatibleSIM\":\"BULKSIM5G-SA-A\",\"makeEtniPersApi\":false,\"deviceId\":\"355843801449939\",\"dfillCompatibleSim\":\"DFILLSIM5G-SA-A\",\"esimid\":\"\",\"eID\":\"\"},\"simInfo2\":{\"iccid\":\"\",\"mfgCode\":\"\",\"launchPackageSku\":\"MLR53LL/A-2\",\"prodName\":\"\",\"preferredSoftSim\":\"SOFTSIM5G-SA-A\",\"launchPackageSkuType\":\"MLR53LL/A-2\",\"pairedIccid\":\"\",\"type\":\"\",\"mtn\":\"\",\"mobileNumber\":\"\",\"active\":false,\"aging\":false,\"available\":false,\"retired\":false,\"grandFathered\":false,\"status\":\"\",\"euimid\":\"\",\"imsiv\":\"\",\"imsivf\":\"\",\"iccIdStat\":\"\",\"min\":\"\",\"ispuCompatibleSIM\":\"BULKSIM5G-SA-A\",\"makeEtniPersApi\":true,\"deviceId\":\"355843801316351\",\"dfillCompatibleSim\":\"DFILLSIM5G-SA-A\",\"esimid\":\"\",\"eID\":\"89049032007008882600117663233736\"},\"deviceSimCompatible\":\"Y\",\"deviceSimM2MPair\":\"N\",\"deviceESimCompatible\":\"N\",\"deviceESimM2MPair\":\"N\",\"deviceId\":\"355843801449939\",\"color\":{\"colorId\":\"clr10520003\",\"displayName\":\"Sierra Blue\",\"description\":\"Blue\",\"colorCssStyle\":\"#A7C1D9\"},\"imageName\":\"apple-iphone-13-pro-sierra-blue-09142021\",\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-thumb$\"},\"skuDisplayName\":\"Apple iPhone 13 Pro 128GB in Sierra Blue\",\"deviceSku\":\"MLR53LL/A\",\"isRestrictedDevice\":\"N\",\"deviceAttributes\":{\"mfgCode\":\"APL\",\"mfgName\":\"Apple\",\"prodName\":\"IPHONE 13 PRO 128 SIERRA BLUE\",\"prodType\":\"5GSmartphone\",\"equipModeCode\":\"5GE\",\"equipMode\":\"5GDevice\",\"gpsIndicator\":\"Y\",\"daccCode\":\"01661\",\"deviceType\":\"5GE\",\"deviceCategory\":\"5G Smartphone\",\"productId\":\"dev16720003\",\"postpaidRestrictStartDate\":\"\",\"prepayRestrictStartDate\":\"\",\"wholesaleRestrictStartDate\":\"\"},\"lostAndStolen\":{\"lostStolen\":\"N\",\"nonPay\":\"N\"},\"numbershareCapability\":\"\",\"price\":{\"fullRetailPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"Full Retail Price\"},\"oneYearPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"One Year Price\"},\"devicePaymentPrice\":[]},\"skipSimIdFlag\":true,\"appleWatchFlag\":false,\"fmipLocked\":false,\"appleCarrieLock\":false,\"e911AddrInd\":\"\",\"simClass4G\":\"PI\",\"makeEtniPersApi\":false,\"softMessages\":[],\"standalonePairingEligible\":true,\"deviceFamilyType\":\"Phone\",\"osType\":\"Apple iOS\",\"euiccCapable\":\"Y\",\"imei1\":\"355843801449939\",\"imei2\":\"355843801316351\",\"productFamily\":\"iPhone 13 Pro\",\"pairedImeiData\":{\"pairedImei\":\"353207331839021\",\"eid\":\"89049032007008882600127471300369\",\"sku\":\"MLA23LL/A\",\"preferredSim\":\"DFILLSIM5G-SA-A\",\"devicePreferredSoftSim\":\"SOFTSIM5G-SA-D\",\"simClass4G\":\"PI\",\"euiccCapable\":true},\"eSIMOnly\":false,\"profileState\":\"CO\"}}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationUIResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"creditAppNum\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<DeviceIdValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.deviceIdValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cxpHelper2.deviceIdValidation(Mockito.any(),Mockito.any())).thenReturn(sampleResponseMono);
		DeviceIdValidationUIResponse expectedResponse = sampleResponse;
		when(cxpHelper.getSmartImeiDevices(Mockito.anyString(),Mockito.anyString())).thenReturn(Mono.just(getSmartImeiDevicesResponse()));
		Mono<DeviceIdValidationUIResponse> response = helper.deviceIdValidation(sampleRequest);
		sampleResponse.getServiceBody().getServiceResponse().getContext().getDeviceInfo().setPairedImeiData(new PairedImeiData());
		sampleResponse.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getPairedImeiData().setEid("1234");
		Mono<DeviceIdValidationUIResponse> response2 = helper.eidSimDetails(sampleResponse,sampleRequest);

		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response2).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void deviceIdValidationProfileWo_Eid() throws IOException, SOEHTTPException {
		ReflectionTestUtils.setField(helper, "enableEsimMigrationChanges", true);
		ESimDetailsETNIRequest sampleUIRequest = new ESimDetailsETNIRequest();
		String eidSimDetailsUIResponseString = "{\"data\":{\"simEidResponseBean\":[{\"statusDesc\":\":SUCCESSFUL\",\"statusCode\":\"00000\",\"rowsPop\":\"4\",\"rowIdList\":[{\"vzwImsi\":\"311480111500108\",\"vfImsi\":\"\",\"euimId\":\"A00001122DCDCA\",\"iccidStatus\":\"PA\",\"mdn\":\"7272445960\",\"simCreateDate\":\"2023-09-05-16.09.06.605919\",\"simUpdateDate\":\"2023-11-04-03.19.34.000092\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$8483340509-0503889576\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692229539\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111471934\",\"vfImsi\":\"\",\"euimId\":\"A00001122DCD08\",\"iccidStatus\":\"PA\",\"mdn\":\"6075901699\",\"simCreateDate\":\"2023-09-05-16.09.08.762178\",\"simUpdateDate\":\"2023-11-02-05.58.19.000753\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$6075901699-0211053007\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692227590\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111478472\",\"vfImsi\":\"\",\"euimId\":\"A00001122DC190\",\"iccidStatus\":\"PA\",\"mdn\":\"6075900414\",\"simCreateDate\":\"2023-09-05-16.09.04.131573\",\"simUpdateDate\":\"2023-11-02-05.50.19.000582\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$6075900414-0294247860\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692198239\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111509353\",\"vfImsi\":\"\",\"euimId\":\"A00001122DB7EA\",\"iccidStatus\":\"AI\",\"mdn\":\"9126025456\",\"simCreateDate\":\"2023-09-05-16.09.03.896542\",\"simUpdateDate\":\"2023-11-0113:47:45.000860\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$9126025456-0460441555\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692173539\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"}]}]}}" ;
		EidSimDetailsUIResponse eidSimDetailsUIResponse = mapper.readValue(eidSimDetailsUIResponseString, EidSimDetailsUIResponse.class);
		when(cxpHelper.EidSimDetail(Mockito.any())).thenReturn(Mono.just(eidSimDetailsUIResponse));
		sampleUIRequest.setEid("89049032007008882600092386726095");
		sampleUIRequest.setApplicationId(CartConstants.DEFAULT_APPLICATION_ID);
		sampleUIRequest.setUserId(CartConstants.DEFAULT_USER_ID);
		String sampleRequestString = "{\"channelId\":\"OMNI-RETAIL-TAB\",\"cartInfo\":{\"cartCreator\":\"7272445960\",\"cartId\":\"0b95bd88-66ac-4400-a7d2-3c5f43bcbbd5\",\"caseId\":\"SOP-9774000-E01\",\"creditAppNum\":null,\"processingMTN\":\"7272445960\",\"accountNumber\":\"0321747971-00001\",\"intent\":\"BYOD\",\"intendType\":\"BYOD\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":\"validateDeviceSim\",\"action\":\"\",\"makeEtniQeidApi\":true},\"data\":{\"lines\":[{\"mtn\":\"7272445960\",\"eskuId\":\"\",\"device\":{\"id\":\"355843801449939\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"356628100445533\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":false,\"sim\":{\"id\":\"89148000005207167008\",\"sku\":\"\",\"isCustomerProvidedSIM\":false,\"CurrentSimid\":\"89148000005207167008\"}}}]},\"disableEsimAtLocalInventory\":false}";
		String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-RETAIL-TAB\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.10.13.02.18.48-880.5654141238181\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-9774000-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"GridWallPDP\"}]},\"customerInfo\":{\"pinCardPayment\":false,\"accountNumber\":\"\",\"cartCreator\":\"7272445960\",\"processingMTN\":\"7272445960\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"0b95bd88-66ac-4400-a7d2-3c5f43bcbbd5\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false},\"deviceInfo\":{\"simInfo\":{\"iccid\":\"89148000005207167008\",\"mfgCode\":\"STM\",\"launchPackageSku\":\"EMBDSIMTRI\",\"prodName\":\"ST Multi-Form-Factor SIM\",\"preferredSoftSim\":\"EMBDSIM5G\",\"launchPackageSkuType\":\"MLR53LL/A\",\"pairedIccid\":\"\",\"type\":\"4GS\",\"mtn\":\"\",\"mobileNumber\":\"\",\"active\":false,\"aging\":false,\"available\":false,\"retired\":false,\"grandFathered\":false,\"status\":\"\",\"euimid\":\"\",\"imsiv\":\"\",\"imsivf\":\"\",\"iccIdStat\":\"\",\"min\":\"\",\"ispuCompatibleSIM\":\"BULKSIM5G-SA-A\",\"makeEtniPersApi\":false,\"deviceId\":\"355843801449939\",\"dfillCompatibleSim\":\"DFILLSIM5G-SA-A\",\"esimid\":\"\",\"eID\":\"\"},\"simInfo2\":{\"iccid\":\"\",\"mfgCode\":\"\",\"launchPackageSku\":\"MLR53LL/A-2\",\"prodName\":\"\",\"preferredSoftSim\":\"SOFTSIM5G-SA-A\",\"launchPackageSkuType\":\"MLR53LL/A-2\",\"pairedIccid\":\"\",\"type\":\"\",\"mtn\":\"\",\"mobileNumber\":\"\",\"active\":false,\"aging\":false,\"available\":false,\"retired\":false,\"grandFathered\":false,\"status\":\"\",\"euimid\":\"\",\"imsiv\":\"\",\"imsivf\":\"\",\"iccIdStat\":\"\",\"min\":\"\",\"ispuCompatibleSIM\":\"BULKSIM5G-SA-A\",\"makeEtniPersApi\":true,\"deviceId\":\"355843801316351\",\"dfillCompatibleSim\":\"DFILLSIM5G-SA-A\",\"esimid\":\"\",\"eID\":\"89049032007008882600117663233736\"},\"deviceSimCompatible\":\"Y\",\"deviceSimM2MPair\":\"N\",\"deviceESimCompatible\":\"N\",\"deviceESimM2MPair\":\"N\",\"deviceId\":\"355843801449939\",\"color\":{\"colorId\":\"clr10520003\",\"displayName\":\"Sierra Blue\",\"description\":\"Blue\",\"colorCssStyle\":\"#A7C1D9\"},\"imageName\":\"apple-iphone-13-pro-sierra-blue-09142021\",\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-thumb$\"},\"skuDisplayName\":\"Apple iPhone 13 Pro 128GB in Sierra Blue\",\"deviceSku\":\"MLR53LL/A\",\"isRestrictedDevice\":\"N\",\"deviceAttributes\":{\"mfgCode\":\"APL\",\"mfgName\":\"Apple\",\"prodName\":\"IPHONE 13 PRO 128 SIERRA BLUE\",\"prodType\":\"5GSmartphone\",\"equipModeCode\":\"5GE\",\"equipMode\":\"5GDevice\",\"gpsIndicator\":\"Y\",\"daccCode\":\"01661\",\"deviceType\":\"5GE\",\"deviceCategory\":\"5G Smartphone\",\"productId\":\"dev16720003\",\"postpaidRestrictStartDate\":\"\",\"prepayRestrictStartDate\":\"\",\"wholesaleRestrictStartDate\":\"\"},\"lostAndStolen\":{\"lostStolen\":\"N\",\"nonPay\":\"N\"},\"numbershareCapability\":\"\",\"price\":{\"fullRetailPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"Full Retail Price\"},\"oneYearPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"One Year Price\"},\"devicePaymentPrice\":[]},\"skipSimIdFlag\":true,\"appleWatchFlag\":false,\"fmipLocked\":false,\"appleCarrieLock\":false,\"e911AddrInd\":\"\",\"simClass4G\":\"PI\",\"makeEtniPersApi\":false,\"softMessages\":[],\"standalonePairingEligible\":true,\"deviceFamilyType\":\"Phone\",\"osType\":\"Apple iOS\",\"euiccCapable\":\"Y\",\"imei1\":\"355843801449939\",\"imei2\":\"355843801316351\",\"productFamily\":\"iPhone 13 Pro\",\"pairedImeiData\":{\"pairedImei\":\"353207331839021\",\"eid\":\"89049032007008882600127471300369\",\"sku\":\"MLA23LL/A\",\"preferredSim\":\"DFILLSIM5G-SA-A\",\"devicePreferredSoftSim\":\"SOFTSIM5G-SA-D\",\"simClass4G\":\"PI\",\"euiccCapable\":true},\"eSIMOnly\":false,\"profileState\":\"CO\"}}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationUIResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"creditAppNum\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<DeviceIdValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.deviceIdValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cxpHelper2.deviceIdValidation(Mockito.any(),Mockito.any())).thenReturn(sampleResponseMono);
		DeviceIdValidationUIResponse expectedResponse = sampleResponse;
		when(cxpHelper.getSmartImeiDevices(Mockito.anyString(),Mockito.anyString())).thenReturn(Mono.just(getSmartImeiDevicesResponse()));
		Mono<DeviceIdValidationUIResponse> response = helper.deviceIdValidation(sampleRequest);
		sampleResponse.getServiceBody().getServiceResponse().getContext().getDeviceInfo().setPairedImeiData(new PairedImeiData());
		sampleResponse.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getPairedImeiData().setEid("1234");
		Mono<DeviceIdValidationUIResponse> response2 = helper.eidSimDetails(sampleResponse,sampleRequest);

		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response2).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void deviceIdValidationProfilePairedIMEINull() throws IOException, SOEHTTPException {
		ReflectionTestUtils.setField(helper, "enableEsimMigrationChanges", true);
		ESimDetailsETNIRequest sampleUIRequest = new ESimDetailsETNIRequest();
		String eidSimDetailsUIResponseString = "{\"data\":{\"simEidResponseBean\":[{\"statusDesc\":\":SUCCESSFUL\",\"statusCode\":\"00000\",\"rowsPop\":\"4\",\"rowIdList\":[{\"vzwImsi\":\"311480111500108\",\"vfImsi\":\"\",\"euimId\":\"A00001122DCDCA\",\"iccidStatus\":\"PA\",\"mdn\":\"7272445960\",\"simCreateDate\":\"2023-09-05-16.09.06.605919\",\"simUpdateDate\":\"2023-11-04-03.19.34.000092\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$8483340509-0503889576\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692229539\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111471934\",\"vfImsi\":\"\",\"euimId\":\"A00001122DCD08\",\"iccidStatus\":\"PA\",\"mdn\":\"6075901699\",\"simCreateDate\":\"2023-09-05-16.09.08.762178\",\"simUpdateDate\":\"2023-11-02-05.58.19.000753\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$6075901699-0211053007\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692227590\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111478472\",\"vfImsi\":\"\",\"euimId\":\"A00001122DC190\",\"iccidStatus\":\"PA\",\"mdn\":\"6075900414\",\"simCreateDate\":\"2023-09-05-16.09.04.131573\",\"simUpdateDate\":\"2023-11-02-05.50.19.000582\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$6075900414-0294247860\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692198239\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111509353\",\"vfImsi\":\"\",\"euimId\":\"A00001122DB7EA\",\"iccidStatus\":\"AI\",\"mdn\":\"9126025456\",\"simCreateDate\":\"2023-09-05-16.09.03.896542\",\"simUpdateDate\":\"2023-11-0113:47:45.000860\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$9126025456-0460441555\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692173539\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"}]}]}}" ;
		EidSimDetailsUIResponse eidSimDetailsUIResponse = mapper.readValue(eidSimDetailsUIResponseString, EidSimDetailsUIResponse.class);
		when(cxpHelper.EidSimDetail(Mockito.any())).thenReturn(Mono.just(eidSimDetailsUIResponse));
		sampleUIRequest.setEid("89049032007008882600092386726095");
		sampleUIRequest.setApplicationId(CartConstants.DEFAULT_APPLICATION_ID);
		sampleUIRequest.setUserId(CartConstants.DEFAULT_USER_ID);
		String sampleRequestString = "{\"channelId\":\"OMNI-RETAIL-TAB\",\"cartInfo\":{\"cartCreator\":\"7272445960\",\"cartId\":\"0b95bd88-66ac-4400-a7d2-3c5f43bcbbd5\",\"caseId\":\"SOP-9774000-E01\",\"creditAppNum\":null,\"processingMTN\":\"7272445960\",\"accountNumber\":\"0321747971-00001\",\"intent\":\"BYOD\",\"intendType\":\"BYOD\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":\"validateDeviceSim\",\"action\":\"\",\"makeEtniQeidApi\":true},\"data\":{\"lines\":[{\"mtn\":\"7272445960\",\"eskuId\":\"\",\"device\":{\"id\":\"355843801449939\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"356628100445533\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":false,\"sim\":{\"id\":\"89148000005207167008\",\"sku\":\"\",\"isCustomerProvidedSIM\":false,\"CurrentSimid\":\"89148000005207167008\"}}}]},\"disableEsimAtLocalInventory\":false}";
		String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-RETAIL-TAB\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.10.13.02.18.48-880.5654141238181\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-9774000-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"GridWallPDP\"}]},\"customerInfo\":{\"pinCardPayment\":false,\"accountNumber\":\"\",\"cartCreator\":\"7272445960\",\"processingMTN\":\"7272445960\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"0b95bd88-66ac-4400-a7d2-3c5f43bcbbd5\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false},\"deviceInfo\":{\"simInfo\":{\"iccid\":\"89148000005207167008\",\"mfgCode\":\"STM\",\"launchPackageSku\":\"EMBDSIMTRI\",\"prodName\":\"ST Multi-Form-Factor SIM\",\"preferredSoftSim\":\"EMBDSIM5G\",\"launchPackageSkuType\":\"MLR53LL/A\",\"pairedIccid\":\"\",\"type\":\"4GS\",\"mtn\":\"\",\"mobileNumber\":\"\",\"active\":false,\"aging\":false,\"available\":false,\"retired\":false,\"grandFathered\":false,\"status\":\"\",\"euimid\":\"\",\"imsiv\":\"\",\"imsivf\":\"\",\"iccIdStat\":\"\",\"min\":\"\",\"ispuCompatibleSIM\":\"BULKSIM5G-SA-A\",\"makeEtniPersApi\":false,\"deviceId\":\"355843801449939\",\"dfillCompatibleSim\":\"DFILLSIM5G-SA-A\",\"esimid\":\"\",\"eID\":\"\"},\"simInfo2\":{\"iccid\":\"\",\"mfgCode\":\"\",\"launchPackageSku\":\"MLR53LL/A-2\",\"prodName\":\"\",\"preferredSoftSim\":\"SOFTSIM5G-SA-A\",\"launchPackageSkuType\":\"MLR53LL/A-2\",\"pairedIccid\":\"\",\"type\":\"\",\"mtn\":\"\",\"mobileNumber\":\"\",\"active\":false,\"aging\":false,\"available\":false,\"retired\":false,\"grandFathered\":false,\"status\":\"\",\"euimid\":\"\",\"imsiv\":\"\",\"imsivf\":\"\",\"iccIdStat\":\"\",\"min\":\"\",\"ispuCompatibleSIM\":\"BULKSIM5G-SA-A\",\"makeEtniPersApi\":true,\"deviceId\":\"355843801316351\",\"dfillCompatibleSim\":\"DFILLSIM5G-SA-A\",\"esimid\":\"\",\"eID\":\"89049032007008882600117663233736\"},\"deviceSimCompatible\":\"Y\",\"deviceSimM2MPair\":\"N\",\"deviceESimCompatible\":\"N\",\"deviceESimM2MPair\":\"N\",\"deviceId\":\"355843801449939\",\"color\":{\"colorId\":\"clr10520003\",\"displayName\":\"Sierra Blue\",\"description\":\"Blue\",\"colorCssStyle\":\"#A7C1D9\"},\"imageName\":\"apple-iphone-13-pro-sierra-blue-09142021\",\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-thumb$\"},\"skuDisplayName\":\"Apple iPhone 13 Pro 128GB in Sierra Blue\",\"deviceSku\":\"MLR53LL/A\",\"isRestrictedDevice\":\"N\",\"deviceAttributes\":{\"mfgCode\":\"APL\",\"mfgName\":\"Apple\",\"prodName\":\"IPHONE 13 PRO 128 SIERRA BLUE\",\"prodType\":\"5GSmartphone\",\"equipModeCode\":\"5GE\",\"equipMode\":\"5GDevice\",\"gpsIndicator\":\"Y\",\"daccCode\":\"01661\",\"deviceType\":\"5GE\",\"deviceCategory\":\"5G Smartphone\",\"productId\":\"dev16720003\",\"postpaidRestrictStartDate\":\"\",\"prepayRestrictStartDate\":\"\",\"wholesaleRestrictStartDate\":\"\"},\"lostAndStolen\":{\"lostStolen\":\"N\",\"nonPay\":\"N\"},\"numbershareCapability\":\"\",\"price\":{\"fullRetailPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"Full Retail Price\"},\"oneYearPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"One Year Price\"},\"devicePaymentPrice\":[]},\"skipSimIdFlag\":true,\"appleWatchFlag\":false,\"fmipLocked\":false,\"appleCarrieLock\":false,\"e911AddrInd\":\"\",\"simClass4G\":\"PI\",\"makeEtniPersApi\":false,\"softMessages\":[],\"standalonePairingEligible\":true,\"deviceFamilyType\":\"Phone\",\"osType\":\"Apple iOS\",\"euiccCapable\":\"Y\",\"imei1\":\"355843801449939\",\"imei2\":\"355843801316351\",\"productFamily\":\"iPhone 13 Pro\",\"pairedImeiData\":{\"pairedImei\":\"353207331839021\",\"eid\":\"89049032007008882600127471300369\",\"sku\":\"MLA23LL/A\",\"preferredSim\":\"DFILLSIM5G-SA-A\",\"devicePreferredSoftSim\":\"SOFTSIM5G-SA-D\",\"simClass4G\":\"PI\",\"euiccCapable\":true},\"eSIMOnly\":false,\"profileState\":\"CO\"}}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationUIResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"creditAppNum\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<DeviceIdValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.deviceIdValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cxpHelper2.deviceIdValidation(Mockito.any(),Mockito.any())).thenReturn(sampleResponseMono);
		DeviceIdValidationUIResponse expectedResponse = sampleResponse;
		when(cxpHelper.getSmartImeiDevices(Mockito.anyString(),Mockito.anyString())).thenReturn(Mono.just(getSmartImeiDevicesResponse()));
		Mono<DeviceIdValidationUIResponse> response = helper.deviceIdValidation(sampleRequest);
		sampleResponse.getServiceBody().getServiceResponse().getContext().getDeviceInfo().setPairedImeiData(null);
		Mono<DeviceIdValidationUIResponse> response2 = helper.eidSimDetails(sampleResponse,sampleRequest);

		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response2).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void deviceIdValidationProfileDeviceInfo() throws IOException, SOEHTTPException {
		ReflectionTestUtils.setField(helper, "enableEsimMigrationChanges", true);
		ESimDetailsETNIRequest sampleUIRequest = new ESimDetailsETNIRequest();
		String eidSimDetailsUIResponseString = "{\"data\":{\"simEidResponseBean\":[{\"statusDesc\":\":SUCCESSFUL\",\"statusCode\":\"00000\",\"rowsPop\":\"4\",\"rowIdList\":[{\"vzwImsi\":\"311480111500108\",\"vfImsi\":\"\",\"euimId\":\"A00001122DCDCA\",\"iccidStatus\":\"PA\",\"mdn\":\"7272445960\",\"simCreateDate\":\"2023-09-05-16.09.06.605919\",\"simUpdateDate\":\"2023-11-04-03.19.34.000092\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$8483340509-0503889576\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692229539\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111471934\",\"vfImsi\":\"\",\"euimId\":\"A00001122DCD08\",\"iccidStatus\":\"PA\",\"mdn\":\"6075901699\",\"simCreateDate\":\"2023-09-05-16.09.08.762178\",\"simUpdateDate\":\"2023-11-02-05.58.19.000753\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$6075901699-0211053007\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692227590\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111478472\",\"vfImsi\":\"\",\"euimId\":\"A00001122DC190\",\"iccidStatus\":\"PA\",\"mdn\":\"6075900414\",\"simCreateDate\":\"2023-09-05-16.09.04.131573\",\"simUpdateDate\":\"2023-11-02-05.50.19.000582\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$6075900414-0294247860\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692198239\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111509353\",\"vfImsi\":\"\",\"euimId\":\"A00001122DB7EA\",\"iccidStatus\":\"AI\",\"mdn\":\"9126025456\",\"simCreateDate\":\"2023-09-05-16.09.03.896542\",\"simUpdateDate\":\"2023-11-0113:47:45.000860\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$9126025456-0460441555\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692173539\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"}]}]}}" ;
		EidSimDetailsUIResponse eidSimDetailsUIResponse = mapper.readValue(eidSimDetailsUIResponseString, EidSimDetailsUIResponse.class);
		when(cxpHelper.EidSimDetail(Mockito.any())).thenReturn(Mono.just(eidSimDetailsUIResponse));
		sampleUIRequest.setEid("89049032007008882600092386726095");
		sampleUIRequest.setApplicationId(CartConstants.DEFAULT_APPLICATION_ID);
		sampleUIRequest.setUserId(CartConstants.DEFAULT_USER_ID);
		String sampleRequestString = "{\"channelId\":\"OMNI-RETAIL-TAB\",\"cartInfo\":{\"cartCreator\":\"7272445960\",\"cartId\":\"0b95bd88-66ac-4400-a7d2-3c5f43bcbbd5\",\"caseId\":\"SOP-9774000-E01\",\"creditAppNum\":null,\"processingMTN\":\"7272445960\",\"accountNumber\":\"0321747971-00001\",\"intent\":\"BYOD\",\"intendType\":\"BYOD\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":\"validateDeviceSim\",\"action\":\"\",\"makeEtniQeidApi\":true},\"data\":{\"lines\":[{\"mtn\":\"7272445960\",\"eskuId\":\"\",\"device\":{\"id\":\"355843801449939\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"356628100445533\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":false,\"sim\":{\"id\":\"89148000005207167008\",\"sku\":\"\",\"isCustomerProvidedSIM\":false,\"CurrentSimid\":\"89148000005207167008\"}}}]},\"disableEsimAtLocalInventory\":false}";
		String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-RETAIL-TAB\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.10.13.02.18.48-880.5654141238181\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-9774000-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"GridWallPDP\"}]},\"customerInfo\":{\"pinCardPayment\":false,\"accountNumber\":\"\",\"cartCreator\":\"7272445960\",\"processingMTN\":\"7272445960\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"0b95bd88-66ac-4400-a7d2-3c5f43bcbbd5\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false},\"deviceInfo\":{\"simInfo\":{\"iccid\":\"89148000005207167008\",\"mfgCode\":\"STM\",\"launchPackageSku\":\"EMBDSIMTRI\",\"prodName\":\"ST Multi-Form-Factor SIM\",\"preferredSoftSim\":\"EMBDSIM5G\",\"launchPackageSkuType\":\"MLR53LL/A\",\"pairedIccid\":\"\",\"type\":\"4GS\",\"mtn\":\"\",\"mobileNumber\":\"\",\"active\":false,\"aging\":false,\"available\":false,\"retired\":false,\"grandFathered\":false,\"status\":\"\",\"euimid\":\"\",\"imsiv\":\"\",\"imsivf\":\"\",\"iccIdStat\":\"\",\"min\":\"\",\"ispuCompatibleSIM\":\"BULKSIM5G-SA-A\",\"makeEtniPersApi\":false,\"deviceId\":\"355843801449939\",\"dfillCompatibleSim\":\"DFILLSIM5G-SA-A\",\"esimid\":\"\",\"eID\":\"\"},\"simInfo2\":{\"iccid\":\"\",\"mfgCode\":\"\",\"launchPackageSku\":\"MLR53LL/A-2\",\"prodName\":\"\",\"preferredSoftSim\":\"SOFTSIM5G-SA-A\",\"launchPackageSkuType\":\"MLR53LL/A-2\",\"pairedIccid\":\"\",\"type\":\"\",\"mtn\":\"\",\"mobileNumber\":\"\",\"active\":false,\"aging\":false,\"available\":false,\"retired\":false,\"grandFathered\":false,\"status\":\"\",\"euimid\":\"\",\"imsiv\":\"\",\"imsivf\":\"\",\"iccIdStat\":\"\",\"min\":\"\",\"ispuCompatibleSIM\":\"BULKSIM5G-SA-A\",\"makeEtniPersApi\":true,\"deviceId\":\"355843801316351\",\"dfillCompatibleSim\":\"DFILLSIM5G-SA-A\",\"esimid\":\"\",\"eID\":\"89049032007008882600117663233736\"},\"deviceSimCompatible\":\"Y\",\"deviceSimM2MPair\":\"N\",\"deviceESimCompatible\":\"N\",\"deviceESimM2MPair\":\"N\",\"deviceId\":\"355843801449939\",\"color\":{\"colorId\":\"clr10520003\",\"displayName\":\"Sierra Blue\",\"description\":\"Blue\",\"colorCssStyle\":\"#A7C1D9\"},\"imageName\":\"apple-iphone-13-pro-sierra-blue-09142021\",\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-thumb$\"},\"skuDisplayName\":\"Apple iPhone 13 Pro 128GB in Sierra Blue\",\"deviceSku\":\"MLR53LL/A\",\"isRestrictedDevice\":\"N\",\"deviceAttributes\":{\"mfgCode\":\"APL\",\"mfgName\":\"Apple\",\"prodName\":\"IPHONE 13 PRO 128 SIERRA BLUE\",\"prodType\":\"5GSmartphone\",\"equipModeCode\":\"5GE\",\"equipMode\":\"5GDevice\",\"gpsIndicator\":\"Y\",\"daccCode\":\"01661\",\"deviceType\":\"5GE\",\"deviceCategory\":\"5G Smartphone\",\"productId\":\"dev16720003\",\"postpaidRestrictStartDate\":\"\",\"prepayRestrictStartDate\":\"\",\"wholesaleRestrictStartDate\":\"\"},\"lostAndStolen\":{\"lostStolen\":\"N\",\"nonPay\":\"N\"},\"numbershareCapability\":\"\",\"price\":{\"fullRetailPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"Full Retail Price\"},\"oneYearPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"One Year Price\"},\"devicePaymentPrice\":[]},\"skipSimIdFlag\":true,\"appleWatchFlag\":false,\"fmipLocked\":false,\"appleCarrieLock\":false,\"e911AddrInd\":\"\",\"simClass4G\":\"PI\",\"makeEtniPersApi\":false,\"softMessages\":[],\"standalonePairingEligible\":true,\"deviceFamilyType\":\"Phone\",\"osType\":\"Apple iOS\",\"euiccCapable\":\"Y\",\"imei1\":\"355843801449939\",\"imei2\":\"355843801316351\",\"productFamily\":\"iPhone 13 Pro\",\"pairedImeiData\":{\"pairedImei\":\"353207331839021\",\"eid\":\"89049032007008882600127471300369\",\"sku\":\"MLA23LL/A\",\"preferredSim\":\"DFILLSIM5G-SA-A\",\"devicePreferredSoftSim\":\"SOFTSIM5G-SA-D\",\"simClass4G\":\"PI\",\"euiccCapable\":true},\"eSIMOnly\":false,\"profileState\":\"CO\"}}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationUIResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"creditAppNum\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<DeviceIdValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.deviceIdValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cxpHelper2.deviceIdValidation(Mockito.any(),Mockito.any())).thenReturn(sampleResponseMono);
		DeviceIdValidationUIResponse expectedResponse = sampleResponse;
		when(cxpHelper.getSmartImeiDevices(Mockito.anyString(),Mockito.anyString())).thenReturn(Mono.just(getSmartImeiDevicesResponse()));
		Mono<DeviceIdValidationUIResponse> response = helper.deviceIdValidation(sampleRequest);
		sampleResponse.getServiceBody().getServiceResponse().getContext().setDeviceInfo(null);
		Mono<DeviceIdValidationUIResponse> response2 = helper.eidSimDetails(sampleResponse,sampleRequest);

		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response2).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void deviceIdValidationProfileTestContext() throws IOException, SOEHTTPException {
		ReflectionTestUtils.setField(helper, "enableEsimMigrationChanges", true);
		ESimDetailsETNIRequest sampleUIRequest = new ESimDetailsETNIRequest();
		String eidSimDetailsUIResponseString = "{\"data\":{\"simEidResponseBean\":[{\"statusDesc\":\":SUCCESSFUL\",\"statusCode\":\"00000\",\"rowsPop\":\"4\",\"rowIdList\":[{\"vzwImsi\":\"311480111500108\",\"vfImsi\":\"\",\"euimId\":\"A00001122DCDCA\",\"iccidStatus\":\"PA\",\"mdn\":\"7272445960\",\"simCreateDate\":\"2023-09-05-16.09.06.605919\",\"simUpdateDate\":\"2023-11-04-03.19.34.000092\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$8483340509-0503889576\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692229539\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111471934\",\"vfImsi\":\"\",\"euimId\":\"A00001122DCD08\",\"iccidStatus\":\"PA\",\"mdn\":\"6075901699\",\"simCreateDate\":\"2023-09-05-16.09.08.762178\",\"simUpdateDate\":\"2023-11-02-05.58.19.000753\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$6075901699-0211053007\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692227590\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111478472\",\"vfImsi\":\"\",\"euimId\":\"A00001122DC190\",\"iccidStatus\":\"PA\",\"mdn\":\"6075900414\",\"simCreateDate\":\"2023-09-05-16.09.04.131573\",\"simUpdateDate\":\"2023-11-02-05.50.19.000582\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$6075900414-0294247860\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692198239\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111509353\",\"vfImsi\":\"\",\"euimId\":\"A00001122DB7EA\",\"iccidStatus\":\"AI\",\"mdn\":\"9126025456\",\"simCreateDate\":\"2023-09-05-16.09.03.896542\",\"simUpdateDate\":\"2023-11-0113:47:45.000860\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$9126025456-0460441555\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692173539\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"}]}]}}" ;
		EidSimDetailsUIResponse eidSimDetailsUIResponse = mapper.readValue(eidSimDetailsUIResponseString, EidSimDetailsUIResponse.class);
		when(cxpHelper.EidSimDetail(Mockito.any())).thenReturn(Mono.just(eidSimDetailsUIResponse));
		sampleUIRequest.setEid("89049032007008882600092386726095");
		sampleUIRequest.setApplicationId(CartConstants.DEFAULT_APPLICATION_ID);
		sampleUIRequest.setUserId(CartConstants.DEFAULT_USER_ID);
		String sampleRequestString = "{\"channelId\":\"OMNI-RETAIL-TAB\",\"cartInfo\":{\"cartCreator\":\"7272445960\",\"cartId\":\"0b95bd88-66ac-4400-a7d2-3c5f43bcbbd5\",\"caseId\":\"SOP-9774000-E01\",\"creditAppNum\":null,\"processingMTN\":\"7272445960\",\"accountNumber\":\"0321747971-00001\",\"intent\":\"BYOD\",\"intendType\":\"BYOD\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":\"validateDeviceSim\",\"action\":\"\",\"makeEtniQeidApi\":true},\"data\":{\"lines\":[{\"mtn\":\"7272445960\",\"eskuId\":\"\",\"device\":{\"id\":\"355843801449939\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"356628100445533\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":false,\"sim\":{\"id\":\"89148000005207167008\",\"sku\":\"\",\"isCustomerProvidedSIM\":false,\"CurrentSimid\":\"89148000005207167008\"}}}]},\"disableEsimAtLocalInventory\":false}";
		String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-RETAIL-TAB\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.10.13.02.18.48-880.5654141238181\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-9774000-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"GridWallPDP\"}]},\"customerInfo\":{\"pinCardPayment\":false,\"accountNumber\":\"\",\"cartCreator\":\"7272445960\",\"processingMTN\":\"7272445960\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"0b95bd88-66ac-4400-a7d2-3c5f43bcbbd5\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false},\"deviceInfo\":{\"simInfo\":{\"iccid\":\"89148000005207167008\",\"mfgCode\":\"STM\",\"launchPackageSku\":\"EMBDSIMTRI\",\"prodName\":\"ST Multi-Form-Factor SIM\",\"preferredSoftSim\":\"EMBDSIM5G\",\"launchPackageSkuType\":\"MLR53LL/A\",\"pairedIccid\":\"\",\"type\":\"4GS\",\"mtn\":\"\",\"mobileNumber\":\"\",\"active\":false,\"aging\":false,\"available\":false,\"retired\":false,\"grandFathered\":false,\"status\":\"\",\"euimid\":\"\",\"imsiv\":\"\",\"imsivf\":\"\",\"iccIdStat\":\"\",\"min\":\"\",\"ispuCompatibleSIM\":\"BULKSIM5G-SA-A\",\"makeEtniPersApi\":false,\"deviceId\":\"355843801449939\",\"dfillCompatibleSim\":\"DFILLSIM5G-SA-A\",\"esimid\":\"\",\"eID\":\"\"},\"simInfo2\":{\"iccid\":\"\",\"mfgCode\":\"\",\"launchPackageSku\":\"MLR53LL/A-2\",\"prodName\":\"\",\"preferredSoftSim\":\"SOFTSIM5G-SA-A\",\"launchPackageSkuType\":\"MLR53LL/A-2\",\"pairedIccid\":\"\",\"type\":\"\",\"mtn\":\"\",\"mobileNumber\":\"\",\"active\":false,\"aging\":false,\"available\":false,\"retired\":false,\"grandFathered\":false,\"status\":\"\",\"euimid\":\"\",\"imsiv\":\"\",\"imsivf\":\"\",\"iccIdStat\":\"\",\"min\":\"\",\"ispuCompatibleSIM\":\"BULKSIM5G-SA-A\",\"makeEtniPersApi\":true,\"deviceId\":\"355843801316351\",\"dfillCompatibleSim\":\"DFILLSIM5G-SA-A\",\"esimid\":\"\",\"eID\":\"89049032007008882600117663233736\"},\"deviceSimCompatible\":\"Y\",\"deviceSimM2MPair\":\"N\",\"deviceESimCompatible\":\"N\",\"deviceESimM2MPair\":\"N\",\"deviceId\":\"355843801449939\",\"color\":{\"colorId\":\"clr10520003\",\"displayName\":\"Sierra Blue\",\"description\":\"Blue\",\"colorCssStyle\":\"#A7C1D9\"},\"imageName\":\"apple-iphone-13-pro-sierra-blue-09142021\",\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-thumb$\"},\"skuDisplayName\":\"Apple iPhone 13 Pro 128GB in Sierra Blue\",\"deviceSku\":\"MLR53LL/A\",\"isRestrictedDevice\":\"N\",\"deviceAttributes\":{\"mfgCode\":\"APL\",\"mfgName\":\"Apple\",\"prodName\":\"IPHONE 13 PRO 128 SIERRA BLUE\",\"prodType\":\"5GSmartphone\",\"equipModeCode\":\"5GE\",\"equipMode\":\"5GDevice\",\"gpsIndicator\":\"Y\",\"daccCode\":\"01661\",\"deviceType\":\"5GE\",\"deviceCategory\":\"5G Smartphone\",\"productId\":\"dev16720003\",\"postpaidRestrictStartDate\":\"\",\"prepayRestrictStartDate\":\"\",\"wholesaleRestrictStartDate\":\"\"},\"lostAndStolen\":{\"lostStolen\":\"N\",\"nonPay\":\"N\"},\"numbershareCapability\":\"\",\"price\":{\"fullRetailPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"Full Retail Price\"},\"oneYearPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"One Year Price\"},\"devicePaymentPrice\":[]},\"skipSimIdFlag\":true,\"appleWatchFlag\":false,\"fmipLocked\":false,\"appleCarrieLock\":false,\"e911AddrInd\":\"\",\"simClass4G\":\"PI\",\"makeEtniPersApi\":false,\"softMessages\":[],\"standalonePairingEligible\":true,\"deviceFamilyType\":\"Phone\",\"osType\":\"Apple iOS\",\"euiccCapable\":\"Y\",\"imei1\":\"355843801449939\",\"imei2\":\"355843801316351\",\"productFamily\":\"iPhone 13 Pro\",\"pairedImeiData\":{\"pairedImei\":\"353207331839021\",\"eid\":\"89049032007008882600127471300369\",\"sku\":\"MLA23LL/A\",\"preferredSim\":\"DFILLSIM5G-SA-A\",\"devicePreferredSoftSim\":\"SOFTSIM5G-SA-D\",\"simClass4G\":\"PI\",\"euiccCapable\":true},\"eSIMOnly\":false,\"profileState\":\"CO\"}}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationUIResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"creditAppNum\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<DeviceIdValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.deviceIdValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cxpHelper2.deviceIdValidation(Mockito.any(),Mockito.any())).thenReturn(sampleResponseMono);
		DeviceIdValidationUIResponse expectedResponse = sampleResponse;
		when(cxpHelper.getSmartImeiDevices(Mockito.anyString(),Mockito.anyString())).thenReturn(Mono.just(getSmartImeiDevicesResponse()));
		Mono<DeviceIdValidationUIResponse> response = helper.deviceIdValidation(sampleRequest);
		sampleResponse.getServiceBody().getServiceResponse().setContext(null);
		Mono<DeviceIdValidationUIResponse> response2 = helper.eidSimDetails(sampleResponse,sampleRequest);

		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response2).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void deviceIdValidationProfileTestContextNull() throws IOException, SOEHTTPException {
		ReflectionTestUtils.setField(helper, "enableEsimMigrationChanges", true);
		ESimDetailsETNIRequest sampleUIRequest = new ESimDetailsETNIRequest();
		String eidSimDetailsUIResponseString = "{\"data\":{\"simEidResponseBean\":[{\"statusDesc\":\":SUCCESSFUL\",\"statusCode\":\"00000\",\"rowsPop\":\"4\",\"rowIdList\":[{\"vzwImsi\":\"311480111500108\",\"vfImsi\":\"\",\"euimId\":\"A00001122DCDCA\",\"iccidStatus\":\"PA\",\"mdn\":\"7272445960\",\"simCreateDate\":\"2023-09-05-16.09.06.605919\",\"simUpdateDate\":\"2023-11-04-03.19.34.000092\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$8483340509-0503889576\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692229539\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111471934\",\"vfImsi\":\"\",\"euimId\":\"A00001122DCD08\",\"iccidStatus\":\"PA\",\"mdn\":\"6075901699\",\"simCreateDate\":\"2023-09-05-16.09.08.762178\",\"simUpdateDate\":\"2023-11-02-05.58.19.000753\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$6075901699-0211053007\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692227590\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111478472\",\"vfImsi\":\"\",\"euimId\":\"A00001122DC190\",\"iccidStatus\":\"PA\",\"mdn\":\"6075900414\",\"simCreateDate\":\"2023-09-05-16.09.04.131573\",\"simUpdateDate\":\"2023-11-02-05.50.19.000582\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$6075900414-0294247860\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692198239\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111509353\",\"vfImsi\":\"\",\"euimId\":\"A00001122DB7EA\",\"iccidStatus\":\"AI\",\"mdn\":\"9126025456\",\"simCreateDate\":\"2023-09-05-16.09.03.896542\",\"simUpdateDate\":\"2023-11-0113:47:45.000860\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$9126025456-0460441555\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692173539\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"}]}]}}" ;
		EidSimDetailsUIResponse eidSimDetailsUIResponse = mapper.readValue(eidSimDetailsUIResponseString, EidSimDetailsUIResponse.class);
		when(cxpHelper.EidSimDetail(Mockito.any())).thenReturn(Mono.just(eidSimDetailsUIResponse));
		sampleUIRequest.setEid("89049032007008882600092386726095");
		sampleUIRequest.setApplicationId(CartConstants.DEFAULT_APPLICATION_ID);
		sampleUIRequest.setUserId(CartConstants.DEFAULT_USER_ID);
		String sampleRequestString = "{\"channelId\":\"OMNI-RETAIL-TAB\",\"cartInfo\":{\"cartCreator\":\"7272445960\",\"cartId\":\"0b95bd88-66ac-4400-a7d2-3c5f43bcbbd5\",\"caseId\":\"SOP-9774000-E01\",\"creditAppNum\":null,\"processingMTN\":\"7272445960\",\"accountNumber\":\"0321747971-00001\",\"intent\":\"BYOD\",\"intendType\":\"BYOD\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":\"validateDeviceSim\",\"action\":\"\",\"makeEtniQeidApi\":true},\"data\":{\"lines\":[{\"mtn\":\"7272445960\",\"eskuId\":\"\",\"device\":{\"id\":\"355843801449939\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"356628100445533\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":false,\"sim\":{\"id\":\"89148000005207167008\",\"sku\":\"\",\"isCustomerProvidedSIM\":false,\"CurrentSimid\":\"89148000005207167008\"}}}]},\"disableEsimAtLocalInventory\":false}";
		String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-RETAIL-TAB\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.10.13.02.18.48-880.5654141238181\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-9774000-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"GridWallPDP\"}]},\"customerInfo\":{\"pinCardPayment\":false,\"accountNumber\":\"\",\"cartCreator\":\"7272445960\",\"processingMTN\":\"7272445960\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"0b95bd88-66ac-4400-a7d2-3c5f43bcbbd5\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false},\"deviceInfo\":{\"simInfo\":{\"iccid\":\"89148000005207167008\",\"mfgCode\":\"STM\",\"launchPackageSku\":\"EMBDSIMTRI\",\"prodName\":\"ST Multi-Form-Factor SIM\",\"preferredSoftSim\":\"EMBDSIM5G\",\"launchPackageSkuType\":\"MLR53LL/A\",\"pairedIccid\":\"\",\"type\":\"4GS\",\"mtn\":\"\",\"mobileNumber\":\"\",\"active\":false,\"aging\":false,\"available\":false,\"retired\":false,\"grandFathered\":false,\"status\":\"\",\"euimid\":\"\",\"imsiv\":\"\",\"imsivf\":\"\",\"iccIdStat\":\"\",\"min\":\"\",\"ispuCompatibleSIM\":\"BULKSIM5G-SA-A\",\"makeEtniPersApi\":false,\"deviceId\":\"355843801449939\",\"dfillCompatibleSim\":\"DFILLSIM5G-SA-A\",\"esimid\":\"\",\"eID\":\"\"},\"simInfo2\":{\"iccid\":\"\",\"mfgCode\":\"\",\"launchPackageSku\":\"MLR53LL/A-2\",\"prodName\":\"\",\"preferredSoftSim\":\"SOFTSIM5G-SA-A\",\"launchPackageSkuType\":\"MLR53LL/A-2\",\"pairedIccid\":\"\",\"type\":\"\",\"mtn\":\"\",\"mobileNumber\":\"\",\"active\":false,\"aging\":false,\"available\":false,\"retired\":false,\"grandFathered\":false,\"status\":\"\",\"euimid\":\"\",\"imsiv\":\"\",\"imsivf\":\"\",\"iccIdStat\":\"\",\"min\":\"\",\"ispuCompatibleSIM\":\"BULKSIM5G-SA-A\",\"makeEtniPersApi\":true,\"deviceId\":\"355843801316351\",\"dfillCompatibleSim\":\"DFILLSIM5G-SA-A\",\"esimid\":\"\",\"eID\":\"89049032007008882600117663233736\"},\"deviceSimCompatible\":\"Y\",\"deviceSimM2MPair\":\"N\",\"deviceESimCompatible\":\"N\",\"deviceESimM2MPair\":\"N\",\"deviceId\":\"355843801449939\",\"color\":{\"colorId\":\"clr10520003\",\"displayName\":\"Sierra Blue\",\"description\":\"Blue\",\"colorCssStyle\":\"#A7C1D9\"},\"imageName\":\"apple-iphone-13-pro-sierra-blue-09142021\",\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-thumb$\"},\"skuDisplayName\":\"Apple iPhone 13 Pro 128GB in Sierra Blue\",\"deviceSku\":\"MLR53LL/A\",\"isRestrictedDevice\":\"N\",\"deviceAttributes\":{\"mfgCode\":\"APL\",\"mfgName\":\"Apple\",\"prodName\":\"IPHONE 13 PRO 128 SIERRA BLUE\",\"prodType\":\"5GSmartphone\",\"equipModeCode\":\"5GE\",\"equipMode\":\"5GDevice\",\"gpsIndicator\":\"Y\",\"daccCode\":\"01661\",\"deviceType\":\"5GE\",\"deviceCategory\":\"5G Smartphone\",\"productId\":\"dev16720003\",\"postpaidRestrictStartDate\":\"\",\"prepayRestrictStartDate\":\"\",\"wholesaleRestrictStartDate\":\"\"},\"lostAndStolen\":{\"lostStolen\":\"N\",\"nonPay\":\"N\"},\"numbershareCapability\":\"\",\"price\":{\"fullRetailPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"Full Retail Price\"},\"oneYearPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"One Year Price\"},\"devicePaymentPrice\":[]},\"skipSimIdFlag\":true,\"appleWatchFlag\":false,\"fmipLocked\":false,\"appleCarrieLock\":false,\"e911AddrInd\":\"\",\"simClass4G\":\"PI\",\"makeEtniPersApi\":false,\"softMessages\":[],\"standalonePairingEligible\":true,\"deviceFamilyType\":\"Phone\",\"osType\":\"Apple iOS\",\"euiccCapable\":\"Y\",\"imei1\":\"355843801449939\",\"imei2\":\"355843801316351\",\"productFamily\":\"iPhone 13 Pro\",\"pairedImeiData\":{\"pairedImei\":\"353207331839021\",\"eid\":\"89049032007008882600127471300369\",\"sku\":\"MLA23LL/A\",\"preferredSim\":\"DFILLSIM5G-SA-A\",\"devicePreferredSoftSim\":\"SOFTSIM5G-SA-D\",\"simClass4G\":\"PI\",\"euiccCapable\":true},\"eSIMOnly\":false,\"profileState\":\"CO\"}}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationUIResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"creditAppNum\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<DeviceIdValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.deviceIdValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cxpHelper2.deviceIdValidation(Mockito.any(),Mockito.any())).thenReturn(sampleResponseMono);
		DeviceIdValidationUIResponse expectedResponse = sampleResponse;
		when(cxpHelper.getSmartImeiDevices(Mockito.anyString(),Mockito.anyString())).thenReturn(Mono.just(getSmartImeiDevicesResponse()));
		Mono<DeviceIdValidationUIResponse> response = helper.deviceIdValidation(sampleRequest);
		sampleResponse.getServiceBody().setServiceResponse(null);
		Mono<DeviceIdValidationUIResponse> response2 = helper.eidSimDetails(sampleResponse,sampleRequest);

		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response2).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void deviceIdValidationProfile() throws IOException, SOEHTTPException {
		ReflectionTestUtils.setField(helper, "enableEsimMigrationChanges", true);
		ESimDetailsETNIRequest sampleUIRequest = new ESimDetailsETNIRequest();
		String eidSimDetailsUIResponseString = "{\"data\":{\"simEidResponseBean\":[{\"statusDesc\":\":SUCCESSFUL\",\"statusCode\":\"00000\",\"rowsPop\":\"4\",\"rowIdList\":[{\"vzwImsi\":\"311480111500108\",\"vfImsi\":\"\",\"euimId\":\"A00001122DCDCA\",\"iccidStatus\":\"PA\",\"mdn\":\"7272445960\",\"simCreateDate\":\"2023-09-05-16.09.06.605919\",\"simUpdateDate\":\"2023-11-04-03.19.34.000092\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$8483340509-0503889576\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692229539\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111471934\",\"vfImsi\":\"\",\"euimId\":\"A00001122DCD08\",\"iccidStatus\":\"PA\",\"mdn\":\"6075901699\",\"simCreateDate\":\"2023-09-05-16.09.08.762178\",\"simUpdateDate\":\"2023-11-02-05.58.19.000753\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$6075901699-0211053007\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692227590\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111478472\",\"vfImsi\":\"\",\"euimId\":\"A00001122DC190\",\"iccidStatus\":\"PA\",\"mdn\":\"6075900414\",\"simCreateDate\":\"2023-09-05-16.09.04.131573\",\"simUpdateDate\":\"2023-11-02-05.50.19.000582\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$6075900414-0294247860\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692198239\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"},{\"vzwImsi\":\"311480111509353\",\"vfImsi\":\"\",\"euimId\":\"A00001122DB7EA\",\"iccidStatus\":\"AI\",\"mdn\":\"9126025456\",\"simCreateDate\":\"2023-09-05-16.09.03.896542\",\"simUpdateDate\":\"2023-11-0113:47:45.000860\",\"profileState\":\"C0\",\"simProfile\":\"EV50008a\",\"embeddedSim\":\"E\",\"selfActInd\":\"N\",\"simType\":\"S\",\"activationCode\":\"1$RPS.STUBBED.RESPONSE.COM$9126025456-0460441555\",\"profileInd\":\"\",\"sku\":\"SOFTSIM5G-SA-D\",\"fqdn\":\"vzw-livelab-es2plus-in.prod.ondemandconnectivity.com\",\"formFactor\":\"N/A\",\"locationCode\":\"5000015\",\"smsrOid\":\"\",\"iccId4g\":\"89148000009692173539\",\"eidout\":\"89049032007008882600092386726095\",\"profilePolicy\":\"5\",\"installCnt\":\"0\"}]}]}}" ;
		EidSimDetailsUIResponse eidSimDetailsUIResponse = mapper.readValue(eidSimDetailsUIResponseString, EidSimDetailsUIResponse.class);
		when(cxpHelper.EidSimDetail(Mockito.any())).thenReturn(Mono.just(eidSimDetailsUIResponse));
		sampleUIRequest.setEid("89049032007008882600092386726095");
		sampleUIRequest.setApplicationId(CartConstants.DEFAULT_APPLICATION_ID);
		sampleUIRequest.setUserId(CartConstants.DEFAULT_USER_ID);
		String sampleRequestString = "{\"channelId\":\"OMNI-RETAIL-TAB\",\"cartInfo\":{\"cartCreator\":\"7272445960\",\"cartId\":\"0b95bd88-66ac-4400-a7d2-3c5f43bcbbd5\",\"caseId\":\"SOP-9774000-E01\",\"creditAppNum\":null,\"processingMTN\":\"7272445960\",\"accountNumber\":\"0321747971-00001\",\"intent\":\"BYOD\",\"intendType\":\"BYOD\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":\"validateDeviceSim\",\"action\":\"\",\"makeEtniQeidApi\":true},\"data\":{\"lines\":[{\"mtn\":\"7272445960\",\"eskuId\":\"\",\"device\":{\"id\":\"355843801449939\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"356628100445533\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":false,\"sim\":{\"id\":\"89148000005207167008\",\"sku\":\"\",\"isCustomerProvidedSIM\":false,\"CurrentSimid\":\"89148000005207167008\"}}}]},\"disableEsimAtLocalInventory\":false}";
		String sampleResponseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-RETAIL-TAB\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.10.13.02.18.48-880.5654141238181\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-9774000-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"GridWallPDP\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"GridWallPDP\"}]},\"customerInfo\":{\"pinCardPayment\":false,\"accountNumber\":\"\",\"cartCreator\":\"7272445960\",\"processingMTN\":\"7272445960\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"0b95bd88-66ac-4400-a7d2-3c5f43bcbbd5\",\"discountPromoTotal\":0,\"registerNumber\":0,\"protectionNotRequired\":false},\"deviceInfo\":{\"simInfo\":{\"iccid\":\"89148000005207167008\",\"mfgCode\":\"STM\",\"launchPackageSku\":\"EMBDSIMTRI\",\"prodName\":\"ST Multi-Form-Factor SIM\",\"preferredSoftSim\":\"EMBDSIM5G\",\"launchPackageSkuType\":\"MLR53LL/A\",\"pairedIccid\":\"\",\"type\":\"4GS\",\"mtn\":\"\",\"mobileNumber\":\"\",\"active\":false,\"aging\":false,\"available\":false,\"retired\":false,\"grandFathered\":false,\"status\":\"\",\"euimid\":\"\",\"imsiv\":\"\",\"imsivf\":\"\",\"iccIdStat\":\"\",\"min\":\"\",\"ispuCompatibleSIM\":\"BULKSIM5G-SA-A\",\"makeEtniPersApi\":false,\"deviceId\":\"355843801449939\",\"dfillCompatibleSim\":\"DFILLSIM5G-SA-A\",\"esimid\":\"\",\"eID\":\"\"},\"simInfo2\":{\"iccid\":\"\",\"mfgCode\":\"\",\"launchPackageSku\":\"MLR53LL/A-2\",\"prodName\":\"\",\"preferredSoftSim\":\"SOFTSIM5G-SA-A\",\"launchPackageSkuType\":\"MLR53LL/A-2\",\"pairedIccid\":\"\",\"type\":\"\",\"mtn\":\"\",\"mobileNumber\":\"\",\"active\":false,\"aging\":false,\"available\":false,\"retired\":false,\"grandFathered\":false,\"status\":\"\",\"euimid\":\"\",\"imsiv\":\"\",\"imsivf\":\"\",\"iccIdStat\":\"\",\"min\":\"\",\"ispuCompatibleSIM\":\"BULKSIM5G-SA-A\",\"makeEtniPersApi\":true,\"deviceId\":\"355843801316351\",\"dfillCompatibleSim\":\"DFILLSIM5G-SA-A\",\"esimid\":\"\",\"eID\":\"89049032007008882600117663233736\"},\"deviceSimCompatible\":\"Y\",\"deviceSimM2MPair\":\"N\",\"deviceESimCompatible\":\"N\",\"deviceESimM2MPair\":\"N\",\"deviceId\":\"355843801449939\",\"color\":{\"colorId\":\"clr10520003\",\"displayName\":\"Sierra Blue\",\"description\":\"Blue\",\"colorCssStyle\":\"#A7C1D9\"},\"imageName\":\"apple-iphone-13-pro-sierra-blue-09142021\",\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-pro-sierra-blue-09142021?$device-thumb$\"},\"skuDisplayName\":\"Apple iPhone 13 Pro 128GB in Sierra Blue\",\"deviceSku\":\"MLR53LL/A\",\"isRestrictedDevice\":\"N\",\"deviceAttributes\":{\"mfgCode\":\"APL\",\"mfgName\":\"Apple\",\"prodName\":\"IPHONE 13 PRO 128 SIERRA BLUE\",\"prodType\":\"5GSmartphone\",\"equipModeCode\":\"5GE\",\"equipMode\":\"5GDevice\",\"gpsIndicator\":\"Y\",\"daccCode\":\"01661\",\"deviceType\":\"5GE\",\"deviceCategory\":\"5G Smartphone\",\"productId\":\"dev16720003\",\"postpaidRestrictStartDate\":\"\",\"prepayRestrictStartDate\":\"\",\"wholesaleRestrictStartDate\":\"\"},\"lostAndStolen\":{\"lostStolen\":\"N\",\"nonPay\":\"N\"},\"numbershareCapability\":\"\",\"price\":{\"fullRetailPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"Full Retail Price\"},\"oneYearPrice\":{\"originalPrice\":\"999.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"One Year Price\"},\"devicePaymentPrice\":[]},\"skipSimIdFlag\":true,\"appleWatchFlag\":false,\"fmipLocked\":false,\"appleCarrieLock\":false,\"e911AddrInd\":\"\",\"simClass4G\":\"PI\",\"makeEtniPersApi\":false,\"softMessages\":[],\"standalonePairingEligible\":true,\"deviceFamilyType\":\"Phone\",\"osType\":\"Apple iOS\",\"euiccCapable\":\"Y\",\"imei1\":\"355843801449939\",\"imei2\":\"355843801316351\",\"productFamily\":\"iPhone 13 Pro\",\"pairedImeiData\":{\"pairedImei\":\"353207331839021\",\"eid\":\"89049032007008882600127471300369\",\"sku\":\"MLA23LL/A\",\"preferredSim\":\"DFILLSIM5G-SA-A\",\"devicePreferredSoftSim\":\"SOFTSIM5G-SA-D\",\"simClass4G\":\"PI\",\"euiccCapable\":true},\"eSIMOnly\":false,\"profileState\":\"CO\"}}}}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationUIResponse.class);
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\", \"creditAppNum\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<DeviceIdValidationUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper3.deviceIdValidation(Mockito.any(), Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cxpHelper2.deviceIdValidation(Mockito.any(),Mockito.any())).thenReturn(sampleResponseMono);
		DeviceIdValidationUIResponse expectedResponse = sampleResponse;
		when(cxpHelper.getSmartImeiDevices(Mockito.anyString(),Mockito.anyString())).thenReturn(Mono.just(getSmartImeiDevicesResponse()));
		Mono<DeviceIdValidationUIResponse> response = helper.deviceIdValidation(sampleRequest);
		sampleResponse.setServiceBody(null);
		Mono<DeviceIdValidationUIResponse> response2 = helper.eidSimDetails(sampleResponse,sampleRequest);

		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		StepVerifier.create(response2).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceInventoryStatusCheckTest(){
		InventoryStatusCheckRequest request = new InventoryStatusCheckRequest();
		request.setSerialNumber("357355067212768");
		InventoryStatusCheckResponse response = new InventoryStatusCheckResponse();
		InventoryStatusCheckResponseData data = new InventoryStatusCheckResponseData();
		data.setIsDeviceAvailableInStoreInventory(true);
		response.setData(data);
		when(cxpService.deviceInventoryStatusCheck(Mockito.any())).thenReturn(Mono.just(response));
		Mono<InventoryStatusCheckResponse> result = helper.deviceInventoryStatusCheck(request);
		StepVerifier.create(result).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		//false response
		InventoryStatusCheckRequest request2 = new InventoryStatusCheckRequest();
		request.setSerialNumber("354655067212268");
		InventoryStatusCheckResponse response2 = new InventoryStatusCheckResponse();
		InventoryStatusCheckResponseData data2 = new InventoryStatusCheckResponseData();
		data2.setIsDeviceAvailableInStoreInventory(false);
		response2.setData(data);
		when(cxpService.deviceInventoryStatusCheck(Mockito.any())).thenReturn(Mono.just(response2));
		Mono<InventoryStatusCheckResponse> result2 = helper.deviceInventoryStatusCheck(request2);
		StepVerifier.create(result2).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void setSearchAttributesDataTest() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
	{
		Method setSearchAttributesData = ReadCartHelper.class.getDeclaredMethod("setSearchAttributesData",SmartImeiDevicesResponse.class,SearchAttributes.class);
		setSearchAttributesData.setAccessible(true);
		SmartImeiDevicesResponse smartImeiDevicesResponse = new SmartImeiDevicesResponse();
		SearchAttributes searchAttributes = new SearchAttributes();

		SmartImeiDeviceData data = new SmartImeiDeviceData();
		SmartImeiDeviceDetails deviceDetails = new SmartImeiDeviceDetails();
		List<SmartImeiDeviceDetails> smartImeiDeviceDetailsList = new ArrayList<>();
		smartImeiDeviceDetailsList.add(deviceDetails);
		data.setSmartImeiDeviceDetails(smartImeiDeviceDetailsList);
		smartImeiDevicesResponse.setData(data);

		deviceDetails.setSorHdVoiceInd("invalid");
		setSearchAttributesData.invoke(helper,smartImeiDevicesResponse, searchAttributes);
		deviceDetails.setSorHdVoiceInd(null);
		deviceDetails.setProdCode1("invalid");
		setSearchAttributesData.invoke(helper,smartImeiDevicesResponse, searchAttributes);
		deviceDetails.setProdCode1(null);
		deviceDetails.setSorId("invalid");
		setSearchAttributesData.invoke(helper,smartImeiDevicesResponse, searchAttributes);
	}

	@Test
	public void maskingForBYODTest() throws IOException {
		String responseString = sourceFileReaderUtil.readFile("/data/DeviceIdValidationResponseMask.json", testFileLocation);
		DeviceIdValidationUIResponse response = mapper.readValue(responseString, DeviceIdValidationUIResponse.class);
		when(featureFlagHelper.isMaskingForBYODFFlag()).thenReturn(Boolean.TRUE);
		DeviceIdValidationUIRequest request = new DeviceIdValidationUIRequest();
		request.setCartInfo(new CartInfo());
		request.getCartInfo().setIntent("BYOD");
		response.getServiceBody().getServiceResponse().getContext()
						.getDeviceInfo().setESimInfo(new ESimInfo());
		response.getServiceBody().getServiceResponse().getContext()
				.getDeviceInfo().getESimInfo().setEID("1234567891234");
		response.getServiceBody().getServiceResponse().getContext()
				.getDeviceInfo().getSimInfo().setESimid("1234567891234");
		response.getServiceBody().getServiceResponse().getContext()
				.getDeviceInfo().getSimInfo().setDeviceId("1234567891234");
		response.getServiceBody().getServiceResponse().getContext()
				.getDeviceInfo().getSimInfo().setEID("1234567891234");
		response.getServiceBody().getServiceResponse().getContext()
				.getDeviceInfo().getSimInfo().setIccid("1234567891234");

		response.getServiceBody().getServiceResponse().getContext()
				.getDeviceInfo().getSimInfo2().setESimid("1234567891234");
		response.getServiceBody().getServiceResponse().getContext()
				.getDeviceInfo().getSimInfo2().setDeviceId("1234567891234");
		response.getServiceBody().getServiceResponse().getContext()
				.getDeviceInfo().getSimInfo2().setEID("1234567891234");
		response.getServiceBody().getServiceResponse().getContext()
				.getDeviceInfo().getSimInfo2().setIccid("1234567891234");
		helper.performMaskingForBYOD(response, request);
		Assert.assertEquals("3295", response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getDeviceId());
		Assert.assertEquals("3295", response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getImei1());
		Assert.assertEquals("4335", response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getImei2());
		Assert.assertEquals("4335", response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getPairedImeiData().getPairedImei());
		Assert.assertEquals("7827", response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getPairedImeiData().getEid());
		Assert.assertEquals("1234", response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getESimInfo().getEID());
		Assert.assertEquals("1234", response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getSimInfo().getESimid());
		Assert.assertEquals("1234", response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getSimInfo().getEID());
		Assert.assertEquals("1234", response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getSimInfo().getDeviceId());
		Assert.assertEquals("1234", response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getSimInfo().getIccid());

		Assert.assertEquals("1234", response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getSimInfo2().getESimid());
		Assert.assertEquals("1234", response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getSimInfo2().getEID());
		Assert.assertEquals("1234", response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getSimInfo2().getDeviceId());
		Assert.assertEquals("1234", response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getSimInfo2().getIccid());
		response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().setDeviceId("");
		response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().setImei1("");
		response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().setImei2("");
		response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getPairedImeiData().setPairedImei("");
		response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getPairedImeiData().setEid("");
		response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getESimInfo().setEID("");
		response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getSimInfo().setESimid("");
		response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getSimInfo().setDeviceId("");
		response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getSimInfo().setEID("");
		response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getSimInfo().setIccid("");
		response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getSimInfo2().setESimid("");
		response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getSimInfo2().setDeviceId("");
		response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getSimInfo2().setEID("");
		response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getSimInfo2().setIccid("");

		helper.performMaskingForBYOD(response, request);
		response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().setDeviceId(null);
		response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().setImei1(null);
		response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().setImei2(null);
		response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getPairedImeiData().setEid(null);
		response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getPairedImeiData().setPairedImei(null);
		helper.performMaskingForBYOD(response, request);
		response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().setPairedImeiData(null);
		response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().setESIMOnly(null);
		response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getSimInfo().setESimid(null);
		response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getSimInfo().setDeviceId(null);
		response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getSimInfo().setEID(null);
		response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getSimInfo().setIccid(null);
		response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getSimInfo2().setESimid(null);
		response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getSimInfo2().setDeviceId(null);
		response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getSimInfo2().setEID(null);
		response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().getSimInfo2().setIccid(null);

		helper.performMaskingForBYOD(response, request);
		response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().setSimInfo(null);
		response.getServiceBody().getServiceResponse().getContext().getDeviceInfo().setSimInfo2(null);
		helper.performMaskingForBYOD(response, request);
		response.getServiceBody().getServiceResponse().getContext().setDeviceInfo(null);
		helper.performMaskingForBYOD(response, request);
		response.getServiceBody().getServiceResponse().setContext(null);
		helper.performMaskingForBYOD(response, request);
		response.getServiceBody().setServiceResponse(null);
		helper.performMaskingForBYOD(response, request);
		response.setServiceBody(null);
		helper.performMaskingForBYOD(response, request);
		helper.performMaskingForBYOD(response, request);
		request.getCartInfo().setIntent("");
		helper.performMaskingForBYOD(response, request);
		request.getCartInfo().setIntent(null);
		helper.performMaskingForBYOD(response, request);
		when(featureFlagHelper.isMaskingForBYODFFlag()).thenReturn(Boolean.FALSE);
		helper.performMaskingForBYOD(response, request);
		request.getCartInfo().setIntent("BYOD");
		helper.performMaskingForBYOD(response, request);
	}

	@Test
	public void updateDeviceIdForEmptyPairedIMEITest() throws JsonProcessingException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
		String sampleRequestString = "{\"channelId\":\"OMNI-CARE\",\"cartInfo\":{\"cartCreator\":\"7039159592\",\"clientAppName\":\"VZW-MFA\",\"cartId\":\"4b207c97-6278-4562-9e41-b6411763bcd6\",\"caseId\":\"SOP-947715-E01\",\"processingMTN\":\"\",\"accountNumber\":\"0201430224-00001\",\"intent\":\"BYOD\",\"processStep\":\"BYODLandingPage\",\"processAction\":\"validatedevicesim\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"device\":{\"id\":\"353338070105553\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":true,\"searchAttributes\":{\"postpaidRestrictStartDate\":\"2018-07-01T04:00:00.000Z\",\"prodCode\":\"LTE\",\"hdVoiceInd\":true,\"deviceType\":\"4GE\",\"dacc\":\"00854\"},\"sim\":{\"id\":\"\",\"isCustomerProvidedSIM\":false,\"CurrentSimid\":\"\"},\"pairedImeiDetailsEmpty\":true,\"byodEsimPhone\":true}}]}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		CartRedisData sampleRedisData = new CartRedisData();
		DeviceImeiSimDetails deviceImeiSimDetails = new DeviceImeiSimDetails();
		deviceImeiSimDetails.setImei1("imei1");
		deviceImeiSimDetails.setImei2("imei2");
		sampleRedisData.setDeviceImeiSimDetails(deviceImeiSimDetails);
		sampleRequest.getData().getLines().get(0).getDevice().setPairedImeiDetailsEmpty(true);
		sampleRequest.getData().getLines().get(0).getDevice().setByodESimPhone(true);
		when(featureFlagHelper.isMaskingForBYODFFlag()).thenReturn(Boolean.TRUE);
		helper.updateRequestDataFromRedisForMasking(sampleRequest, sampleRedisData);
		Assert.assertEquals("imei2", sampleRequest.getData().getLines().get(0).getDevice().getId());
		sampleRequest.getData().getLines().get(0).getDevice().setByodESimPhone(false);
		helper.updateRequestDataFromRedisForMasking(sampleRequest, sampleRedisData);
		Assert.assertEquals("imei1", sampleRequest.getData().getLines().get(0).getDevice().getId());
		sampleRequest.getData().getLines().get(0).getDevice().setPairedImeiDetailsEmpty(false);
		helper.updateRequestDataFromRedisForMasking(sampleRequest, sampleRedisData);
		sampleRequest.getData().getLines().get(0).getDevice().setInactiveDeviceFlow(true);
		sampleRequest.getData().getLines().get(0).getDevice().setId("5553");
		sampleRequest.getData().getLines().get(0).getDevice().setSorId("SMS916UZKV");
		HashMap<String,String> inactiveDevices = new HashMap<>();
		inactiveDevices.put("SMS916UZKV5553","353338070105553");
		deviceImeiSimDetails.setInactiveDevices(inactiveDevices);
		helper.updateRequestDataFromRedisForMasking(sampleRequest, sampleRedisData);
		inactiveDevices.put("SMS916UZKV5553",null);
		helper.updateRequestDataFromRedisForMasking(sampleRequest, sampleRedisData);
		deviceImeiSimDetails.setInactiveDevices(null);
		helper.updateRequestDataFromRedisForMasking(sampleRequest, sampleRedisData);
		sampleRequest.getData().getLines().get(0).setDevice(null);
		helper.updateRequestDataFromRedisForMasking(sampleRequest, sampleRedisData);
		sampleRedisData.setDeviceImeiSimDetails(null);
		helper.updateRequestDataFromRedisForMasking(sampleRequest, sampleRedisData);
		sampleRequest.getData().getLines().set(0,null);
		helper.updateRequestDataFromRedisForMasking(sampleRequest, sampleRedisData);
		sampleRequest.getData().setLines(null);
		helper.updateRequestDataFromRedisForMasking(sampleRequest, sampleRedisData);
		when(featureFlagHelper.isMaskingForBYODFFlag()).thenReturn(Boolean.FALSE);
		helper.updateRequestDataFromRedisForMasking(sampleRequest, sampleRedisData);
		Method method = ReadCartHelperParent.class.getDeclaredMethod("updateForPairedImeiDetailsEmpty", DeviceIdValidationLine.class, DeviceImeiSimDetails.class);
		method.setAccessible(true);
		method.invoke(helper,null,null);
		DeviceIdValidationLine deviceIdValidationLine = new DeviceIdValidationLine();
		method.invoke(helper,deviceIdValidationLine,null);
		deviceIdValidationLine.setDevice(new Device());
		method.invoke(helper,deviceIdValidationLine,null);
	}

}
