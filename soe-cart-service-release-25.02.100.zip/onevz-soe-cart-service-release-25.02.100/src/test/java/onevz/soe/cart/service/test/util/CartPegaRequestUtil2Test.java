package onevz.soe.cart.service.test.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.cxp.feature.Flag;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.constants.FeatureFlagConstants;
import onevz.soe.cart.requests.*;
import onevz.soe.cart.smartimeisearch.DeviceIdValidationRequestFormatter;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.util.*;
import onevz.soe.spring.web.filter.RequestAccessContext;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpHeaders;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.LinkedMultiValueMap;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;

@RunWith(SpringJUnit4ClassRunner.class)
@WebFluxTest(CartPegaRequestUtil.class)
public class CartPegaRequestUtil2Test {

    @Autowired
    private ObjectMapper mapper;


    @Autowired
    private DeviceIdValidationRequestFormatter formater;

    @Before
    public void setUp(){
        final LinkedMultiValueMap<String, HttpCookie> cookies = new LinkedMultiValueMap<>();
        HttpCookie migrationCookie = new HttpCookie(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, "true-cookie");
        cookies.add(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, migrationCookie);
        RequestAccessContext.RequestAccess requestAccess = new RequestAccessContext.RequestAccess(cookies, new HttpHeaders());
        RequestAccessContext.updateRequestData(requestAccess);
    }

    private Flag getFFlag() {
        Flag flag = new Flag();
        flag.setName(FeatureFlagConstants.FLAG_NAME_ACTIVATION_FEE_WAIVER_FFAG);
        flag.setEnabled(true);
        flag.setFound(true);
        List<String> offerCode = new ArrayList<>();
        offerCode.add("DP2PM");
        Map<String, List<String>> fmap = new HashMap<>();
        fmap.put("offerCode", offerCode);
        flag.setAttributes(fmap);

        return flag;
    }

    @Test
    public void formatCreateLineRequestRAFRTest() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"\",\"processStep\":\"LineSelection\",\"intendType\":\"NSE\",\"mtnFlow\":\"P\",\"customerType\":\"N\",\"cartCreatorSalesRepId\":\"ENC\",\"cartCreatorOrderLocationCode\":\"D463801\"},\"data\":{\"zipCode\":\"07920\",\"numOfLines\":2,\"friendsAndFamilyCode\":\"fnfCode\",\"couponCode\":\"testCoupon\",\"lines\":[{\"mtn\":\"\",\"deviceTypeSelected\":\"\",\"portInNumber\":\"\"},{\"mtn\":\"\",\"deviceTypeSelected\":\"\"}]}}";
        CreateLineUIRequest uiRequest = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLinePEGARequest response = CartPegaRequestUtil3.formatCreateLineRequest(new CreateLinePEGARequest(), uiRequest);
        Assert.assertEquals("testCoupon", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getCouponCode());
    }

    @Test
    public void formatCreateLineRequestRAFR2Test() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"\",\"processStep\":\"LineSelection\",\"intendType\":\"NSE\",\"mtnFlow\":\"P\",\"customerType\":\"N\",\"cartCreatorSalesRepId\":\"ENC\",\"cartCreatorOrderLocationCode\":\"D463801\"},\"data\":{\"zipCode\":\"07920\",\"numOfLines\":2,\"friendsAndFamilyCode\":\"fnfCode\",\"couponCode\":\"\",\"lines\":[{\"mtn\":\"\",\"deviceTypeSelected\":\"\",\"portInNumber\":\"\"},{\"mtn\":\"\",\"deviceTypeSelected\":\"\"}]}}";
        CreateLineUIRequest uiRequest = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLinePEGARequest response = CartPegaRequestUtil3.formatCreateLineRequest(new CreateLinePEGARequest(), uiRequest);
        Assert.assertNull(response.getServiceBody().getServiceRequest().getContext().getCartInfo().getCouponCode());
    }

    @Test
    public void formatAddFeaturesRequestOneClickTestPrepayBYOD1Test() throws IOException {
        String sampleUIRequestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"\",\"intendType\":\"BYOD\",\"cartId\":\"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\":\"SOF-123445\",\"accountNumber\":\"account\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-DOTCOM-BBP\",\"intent\":\"Inline\",\"rpsIntent\":\"rpsIntent\",\"oneClick\":true,\"lineActivityType\":\"TSE\",\"isPrepayCart\":\"Y\"},\"data\":{\"checkAutoPayDiscountEligible\":\"checkAutoPayDiscountEligible\",\"lines\":[{\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\"}}";
        AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
        AddFeaturesPEGARequest pegaRequest = new AddFeaturesPEGARequest();
        AddFeaturesPEGARequest response = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
        Assert.assertEquals("SOF-123445", response.getServiceBody().getServiceRequest().getContext().getCaseId());
    }

    @Test
    public void formatAddFeaturesRequestOneClickTestPrepay2BYOD() throws IOException {
        String sampleUIRequestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"\",\"intendType\":\"BYOD\",\"cartId\":\"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\":\"SOF-123445\",\"accountNumber\":\"account\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-DOTCOM-BBP\",\"intent\":\"Inline\",\"rpsIntent\":\"rpsIntent\",\"oneClick\":true,\"isPrepayCart\":\"Y\",\"tysLinesCount\":\"test\",\"relinquishAccountNumber\":\"test\"},\"data\":{\"checkAutoPayDiscountEligible\":\"checkAutoPayDiscountEligible\",\"lines\":[{\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\"}}";
        AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
        AddFeaturesPEGARequest pegaRequest = new AddFeaturesPEGARequest();
        AddFeaturesPEGARequest response = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
        Assert.assertEquals("BYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
    }

    @Test
    public void formatAddFeaturesRequestAddAccesories() throws IOException {
        String sampleUIRequestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"\",\"intendType\":\"AAL\",\"cartId\":\"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\":\"SOF-123445\",\"accountNumber\":\"account\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-DOTCOM-BBP\",\"intent\":\"Inline\",\"rpsIntent\":\"rpsIntent\",\"oneClick\":true,\"isPrepayCart\":\"Y\"},\"data\":{\"checkAutoPayDiscountEligible\":\"checkAutoPayDiscountEligible\",\"lines\":[{\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null,\"accessories\":{}}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\"}}";
        AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
        UIRequest.getCartInfo().setDepletionType("F");
        UIRequest.getCartInfo().setIspuFlow(Boolean.TRUE);
        AddFeaturesPEGARequest pegaRequest = new AddFeaturesPEGARequest();
        AddFeaturesPEGARequest response = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
        Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
    }

    @Test
    public void formatAddFeaturesRequest2AddAccesories() throws IOException {
        String sampleUIRequestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"\",\"intendType\":\"AAL\",\"cartId\":\"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\":\"SOF-123445\",\"accountNumber\":\"account\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-DOTCOM-BBP\",\"intent\":\"Inline\",\"rpsIntent\":\"rpsIntent\",\"oneClick\":true,\"isPrepayCart\":\"Y\"},\"data\":{\"checkAutoPayDiscountEligible\":\"checkAutoPayDiscountEligible\",\"lines\":[{\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null,\"accessories\":{\"add\":[],\"remove\":[]}}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\"}}";
        AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
        UIRequest.getCartInfo().setDepletionType("F");
        UIRequest.getCartInfo().setIspuFlow(Boolean.TRUE);
        AddFeaturesPEGARequest pegaRequest = new AddFeaturesPEGARequest();
        AddFeaturesPEGARequest response = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
        Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
    }

    @Test
    public void formatAddFeaturesRequest3AddAccesories() throws IOException {
        String sampleUIRequestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"\",\"intendType\":\"AAL\",\"cartId\":\"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\":\"\",\"accountNumber\":\"account\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-DOTCOM-BBP\",\"intent\":\"Inline\",\"rpsIntent\":\"rpsIntent\",\"oneClick\":true,\"isPrepayCart\":\"Y\"},\"data\":{\"checkAutoPayDiscountEligible\":\"checkAutoPayDiscountEligible\",\"lines\":[{\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null,\"accessories\":{\"add\":[],\"remove\":[]}}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\"}}";
        AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
        UIRequest.getCartInfo().setDepletionType("F");
        UIRequest.getCartInfo().setIspuFlow(Boolean.TRUE);
        AddFeaturesPEGARequest pegaRequest = new AddFeaturesPEGARequest();
        AddFeaturesPEGARequest response = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
        Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
    }

    @Test
    public void formatAddFeaturesRequest4AddAccesories() throws IOException {
        String sampleUIRequestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"\",\"intendType\":\"AAL\",\"cartId\":\"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\":\"Test\",\"accountNumber\":\"account\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-DOTCOM-BBP\",\"intent\":\"Inline\",\"rpsIntent\":\"rpsIntent\",\"oneClick\":true,\"isPrepayCart\":\"Y\"},\"data\":{\"checkAutoPayDiscountEligible\":\"checkAutoPayDiscountEligible\",\"lines\":[{\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null,\"accessories\":{\"add\":[],\"remove\":[]}}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\"}}";
        AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
        UIRequest.getCartInfo().setDepletionType("F");
        UIRequest.getCartInfo().setIspuFlow(Boolean.TRUE);
        AddFeaturesPEGARequest pegaRequest = new AddFeaturesPEGARequest();
        AddFeaturesPEGARequest response = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
        Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
    }

    @Test
    public void formatAddFeaturesRequest5AddAccesories() throws IOException {
        String sampleUIRequestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"\",\"intendType\":\"AAL\",\"cartId\":\"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\":\"Test\",\"accountNumber\":\"account\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-DOTCOM-BBP\",\"intent\":\"Inline\",\"rpsIntent\":\"rpsIntent\",\"oneClick\":false,\"isPrepayCart\":\"Y\"},\"data\":{\"checkAutoPayDiscountEligible\":\"checkAutoPayDiscountEligible\",\"lines\":[{\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null,\"accessories\":{\"add\":[],\"remove\":[]}}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\"}}";
        AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
        UIRequest.getCartInfo().setDepletionType("F");
        UIRequest.getCartInfo().setIspuFlow(Boolean.TRUE);
        AddFeaturesPEGARequest pegaRequest = new AddFeaturesPEGARequest();
        AddFeaturesPEGARequest response = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
        Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
    }

    @Test
    public void formatAddFeaturesRequest6AddAccesories() throws IOException {
        String sampleUIRequestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"\",\"intendType\":\"AAL\",\"cartId\":\"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\":\"Test\",\"accountNumber\":\"account\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-DOTCOM-BBP\",\"intent\":\"Inline\",\"rpsIntent\":\"rpsIntent\",\"isPrepayCart\":\"Y\"},\"data\":{\"checkAutoPayDiscountEligible\":\"checkAutoPayDiscountEligible\",\"lines\":[{\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null,\"accessories\":{\"add\":[],\"remove\":[]}}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\"}}";
        AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
        UIRequest.getCartInfo().setDepletionType("F");
        UIRequest.getCartInfo().setIspuFlow(Boolean.TRUE);
        AddFeaturesPEGARequest pegaRequest = new AddFeaturesPEGARequest();
        AddFeaturesPEGARequest response = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
        Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
    }

    @Test
    public void formatAddFeaturesRequestOneClickTestPrepay1BYOD() throws IOException {
        String sampleUIRequestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"\",\"intendType\":\"TEST\",\"cartId\":\"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\":\"SOF-123445\",\"accountNumber\":\"account\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-DOTCOM-BBP\",\"intent\":\"Inline\",\"rpsIntent\":\"rpsIntent\",\"oneClick\":true,\"isPrepayCart\":\"Y\"},\"data\":{\"checkAutoPayDiscountEligible\":\"checkAutoPayDiscountEligible\",\"lines\":[{\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\"}}";
        AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
        AddFeaturesPEGARequest pegaRequest = new AddFeaturesPEGARequest();
        AddFeaturesPEGARequest response = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
        Assert.assertEquals("TEST", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
    }

    @Test
    public void formatAddAccessoriesRequestoneClickTestPrepay1TestWFW() throws IOException {
        String sampleUIRequestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"\",\"processAction\":\"xxx\",\"intendType\":\"NSEACC\",\"flowType\":\"WHW_Redemption\",\"cartId\":\"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\":\"SOF-123445\",\"accountNumber\":\"account\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-DOTCOM-BBP\",\"intent\":\"Inline\",\"rpsIntent\":\"rpsIntent\",\"oneClick\":true,\"isPrepayCart\":\"Y\",\"zipCode\":\"06029\"},\"data\":{\"checkAutoPayDiscountEligible\":\"checkAutoPayDiscountEligible\",\"lines\":[{\"addAccessories\":[{\"id\":\"CR1000A\",\"qty\":2,\"isSoftSku\":false,\"accountLevelAccessory\":false,\"macId\":\"\",\"macIds\":[\"1CD6BE386883\",\"1CD6BE3868AD\"]}],\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\",\"zipCode\":\"06029\"}}";
        AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
        AddAccessoryPEGARequest pegaRequest = new AddAccessoryPEGARequest();
        AddAccessoryPEGARequest response = CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, UIRequest, "oneClickCheckoutForAccessory", true);
        Assert.assertEquals("NSEACC", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
    }

    @Test
    public void formatAddAccessoriesRequestoneClickTestPrepay2TestWFW() throws IOException {
        String sampleUIRequestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"\",\"processAction\":\"xxx\",\"intendType\":\"\",\"cartId\":\"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\":\"SOF-123445\",\"accountNumber\":\"account\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-DOTCOM-BBP\",\"intent\":\"Inline\",\"rpsIntent\":\"rpsIntent\",\"oneClick\":true,\"isPrepayCart\":\"Y\",\"zipCode\":\"\"},\"data\":{\"checkAutoPayDiscountEligible\":\"checkAutoPayDiscountEligible\",\"lines\":[{\"addAccessories\":[{\"id\":\"CR1000A\",\"qty\":2,\"isSoftSku\":false,\"accountLevelAccessory\":false,\"macId\":\"\",\"macIds\":[\"1CD6BE386883\",\"1CD6BE3868AD\"]}],\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\",\"zipCode\":\"\"}}";
        AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
        AddAccessoryPEGARequest pegaRequest = new AddAccessoryPEGARequest();
        AddAccessoryPEGARequest response = CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, UIRequest, "oneClickCheckoutForAccessory", true);
        Assert.assertEquals("SOF-123445", response.getServiceBody().getServiceRequest().getContext().getCaseId());
    }

    @Test
    public void formatAddAccessoriesRequestoneClickTestPrepay3TestWFW() throws IOException {
        String sampleUIRequestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"\",\"processAction\":\"xxx\",\"intendType\":\"NSEACC\",\"cartId\":\"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\":\"SOF-123445\",\"accountNumber\":\"account\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-DOTCOM-BBP\",\"intent\":\"Inline\",\"rpsIntent\":\"rpsIntent\",\"oneClick\":true,\"isPrepayCart\":\"Y\",\"zipCode\":\"\"},\"data\":{\"checkAutoPayDiscountEligible\":\"checkAutoPayDiscountEligible\",\"lines\":[{\"addAccessories\":[{\"id\":\"CR1000A\",\"qty\":2,\"isSoftSku\":false,\"accountLevelAccessory\":false,\"macId\":\"\",\"macIds\":[\"1CD6BE386883\",\"1CD6BE3868AD\"]}],\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\",\"zipCode\":\"\"}}";
        AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
        AddAccessoryPEGARequest pegaRequest = new AddAccessoryPEGARequest();
        AddAccessoryPEGARequest response = CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, UIRequest, "oneClickCheckoutForAccessory", true);
        Assert.assertEquals("SOF-123445", response.getServiceBody().getServiceRequest().getContext().getCaseId());
    }

    @Test
    public void formatAddAccessoriesRequestoneClickTestPrepayDepletionLocationTest() throws IOException {
        String sampleUIRequestString="{\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"\",\"processAction\":\"xxx\",\"intendType\":\"BYOD\",\"cartId\":\"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\":\"SOP-123445\",\"accountNumber\":\"account\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-DOTCOM-BBP\",\"intent\":\"Inline\",\"rpsIntent\":\"rpsIntent\",\"oneClick\":true,\"isPrepayCart\":\"Y\"},\"data\":{\"checkAutoPayDiscountEligible\":\"checkAutoPayDiscountEligible\",\"depletionLocationCode\":\"1000040\",\"lines\":[{\"addAccessories\":[{\"id\":\"\",\"qty\":2,\"isSoftSku\":false,\"accountLevelAccessory\":false,\"macId\":\"\",\"adjPrc\":\"adjPrc\",\"macIds\":[\"1CD6BE386883\",\"1CD6BE3868AD\"]}],\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null,\"restricted\":\"restricted\",\"restrictedProductType\":\"restrictedProductType\",\"barCodeId\":\"barCodeId\",\"lineCreatorChannel\":\"lineCreatorChannel\"}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\"}}";
        AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
        AddAccessoryPEGARequest pegaRequest = new AddAccessoryPEGARequest();
        AddAccessoryPEGARequest response = CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, UIRequest, "oneClickCheckoutForAccessory", true);
        Assert.assertEquals("BYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
    }

    @Test
    public void formatAddAccessoriesRequestOneClickTestPrepayDepletionLocationTest() throws IOException {
        String sampleUIRequestString="{\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"\",\"intendType\":\"BYOD\",\"depletionLocationCode\":\"1000040\",\"cartId\":\"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\":\"Test\",\"accountNumber\":\"account\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-DOTCOM-BBP\",\"intent\":\"Inline\",\"rpsIntent\":\"rpsIntent\",\"oneClick\":false,\"isPrepayCart\":\"Y\"},\"data\":{\"checkAutoPayDiscountEligible\":\"checkAutoPayDiscountEligible\",\"lines\":[{\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\"}}";
        AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
        AddAccessoryPEGARequest pegaRequest = new AddAccessoryPEGARequest();
        AddAccessoryPEGARequest response = CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, UIRequest,"oneClickCheckoutForAccessory", true);
        Assert.assertEquals("BYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
    }

    @Test
    public void formatAddAccessoriesRequestOneClickTestPrepayDepletionLocation2Test() throws IOException {
        String sampleUIRequestString="{\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"\",\"intendType\":\"\",\"depletionLocationCode\":\"1000040\",\"cartId\":\"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\":\"Test\",\"accountNumber\":\"account\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-DOTCOM-BBP\",\"intent\":\"Inline\",\"rpsIntent\":\"rpsIntent\",\"isPrepayCart\":\"Y\"},\"data\":{\"checkAutoPayDiscountEligible\":\"checkAutoPayDiscountEligible\",\"lines\":[{\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\"}}";
        AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
        AddAccessoryPEGARequest pegaRequest = new AddAccessoryPEGARequest();
        AddAccessoryPEGARequest response = CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, UIRequest,"oneClickCheckoutForAccessory", true);
        Assert.assertEquals("Test", response.getServiceBody().getServiceRequest().getContext().getCaseId());
    }

    @Test
    public void formatCreateLineRequestTest() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"caseId\":\"SOF-case\",\"isPrepayCart\":\"Y\",\"intendType\":\"NSE\",\"customerType\":\"customerType\"},\"data\":{\"lines\":[]}}";
        CreateLineUIRequest uiRequest = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLinePEGARequest response = CartPegaRequestUtil3.formatCreateLineRequest(new CreateLinePEGARequest(), uiRequest);
        Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
    }

    @Test
    public void formatCreateLineRequest1Test() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"caseId\":\"SOF-case\",\"intendType\":\"NSE\",\"flowType\":\"DVM_CONVERSION\",\"customerType\":\"U\"},\"data\":{\"lines\":[]}}";
        CreateLineUIRequest uiRequest = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLinePEGARequest response = CartPegaRequestUtil3.formatCreateLineRequest(new CreateLinePEGARequest(), uiRequest);
        Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
    }

    @Test
    public void formatCreateLineRequest2Test() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"caseId\":\"SOF-case\",\"isPrepayCart\":\"N\",\"intendType\":\"AAL\",\"customerType\":\"U\"},\"data\":{\"lines\":[]}}";
        CreateLineUIRequest uiRequest = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLinePEGARequest response = CartPegaRequestUtil3.formatCreateLineRequest(new CreateLinePEGARequest(), uiRequest);
        Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
    }
    @Test
    public void formatCreateLineRequest3Test() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"caseId\":\"SOF-case\",\"intendType\":\"AAL\",\"customerType\":\"U\"},\"data\":{\"lines\":[]}}";
        CreateLineUIRequest uiRequest = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLinePEGARequest response = CartPegaRequestUtil3.formatCreateLineRequest(new CreateLinePEGARequest(), uiRequest);
        Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
    }

    @Test
    public void formatCreateLineRequest4Test() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"caseId\":\"SOF-case\",\"isPrepayCart\":\"N\",\"intendType\":\"AAL\",\"customerType\":\"U\"},\"data\":{\"lines\":[]}}";
        CreateLineUIRequest uiRequest = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLinePEGARequest response = CartPegaRequestUtil3.formatCreateLineRequest(new CreateLinePEGARequest(), uiRequest);
        Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
    }

    @Test
    public void formatCreateLineRequest5Test() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"caseId\":\"SOF-case\",\"intendType\":\"AAL\",\"customerType\":\"U\"},\"data\":{\"lines\":[]}}";
        CreateLineUIRequest uiRequest = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLinePEGARequest response = CartPegaRequestUtil3.formatCreateLineRequest(new CreateLinePEGARequest(), uiRequest);
        Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());

        uiRequest.setAppUniversalId("abcd");
        uiRequest.getCartInfo().setIntendType("NSE");
        response = CartPegaRequestUtil3.formatCreateLineRequest(new CreateLinePEGARequest(), uiRequest);
        Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
    }

    @Test
    public void formatCreateLineRequest6Test() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"caseId\":\"SOF-case\",\"intendType\":\"AAL\",\"customerType\":\"X\"},\"data\":{\"lines\":[]}}";
        CreateLineUIRequest uiRequest = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLinePEGARequest response = CartPegaRequestUtil3.formatCreateLineRequest(new CreateLinePEGARequest(), uiRequest);
        Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
    }
    @Test
    public void addDeviceForLVSfotskuTest() throws JsonMappingException, JsonProcessingException {
        String sampleUIRequestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"editAccessory\":false,\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"AccessoryPDP\",\"processAction\":\"addAccessoryAndCheckout\",\"intendType\":\"ACC\",\"intent\":\"StandAloneAccessory\",\"expressflowForAcc\":true,\"expressCheckout\":false,\"subscriptionType\":\"GAMINGCONSOLE\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"\",\"mdnFilterValue\":\"\",\"device\":{\"networkBandwidthType\":\"CBD\"},\"ispuFlow\":false,\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"preBackOrderDate\":\"\",\"preBackOrderDisplayType\":\"\",\"addAccessories\":[{\"giftCard\":false,\"id\":\"LVSoftSku\",\"qty\":1,\"isSoftSku\":true,\"accessoryBundle\":false,\"productId\":\"acc18040009\",\"category\":\"Gaming\",\"isEcpdDiscountEligilble\":false,\"cashOptionEnabled\":true}]}],\"rtm\":{\"url\":\"https://vzwqa1.verizonwireless.com/products/xbox-console-series-x/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/microsoft-xbox-w-controller-a-a?fmt=pjpg\",\"name\":\"All Access - Series X Console\",\"make\":\"Xbox\",\"categoryId\":\"Gaming\",\"pageURL\":\"https://vzwqa1.verizonwireless.com/products/xbox-all-access-series-x-console/\",\"acc_url\":\"https://vzwqa1.verizonwireless.com/products/xbox-console-series-x/\",\"acc_img\":\"https://ss7.vzw.com/is/image/VerizonWireless/microsoft-xbox-w-controller-a-a?fmt=pjpg\",\"acc_categoryId\":\"Gaming\"}}}";
        AddDeviceUIRequest uiRequest = mapper.readValue(sampleUIRequestString, AddDeviceUIRequest.class);
        AddDevicePEGARequest pegaRequest = new AddDevicePEGARequest();
        CartPegaRequestUtil4.formatAddDeviceRequest(pegaRequest,uiRequest,null,true,true,true, getFFlag());
        for(Lines lines: uiRequest.getData().getLines()){
            Assert.assertNotNull(lines.getAddAccessories());

        }
    }
    @Test
    public void formatAddAccessoriesRequestoneClickTestPrepay4TestWFW() throws IOException {
        String sampleUIRequestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"\",\"processAction\":\"xxx\",\"intendType\":\"\",\"cartId\":\"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\":\"SOF-123445\",\"accountNumber\":\"account\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-DOTCOM-BBP\",\"intent\":\"Inline\",\"rpsIntent\":\"rpsIntent\",\"oneClick\":true,\"isPrepayCart\":\"Y\",\"zipCode\":\"\"},\"data\":{\"checkAutoPayDiscountEligible\":\"checkAutoPayDiscountEligible\",\"lines\":[{\"removeAccessories\":[{\"qty\":2,\"isSoftSku\":false,\"accountLevelAccessory\":false,\"macId\":\"\",\"macIds\":[\"1CD6BE386883\",\"1CD6BE3868AD\"]}],\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\",\"zipCode\":\"\"}}";
        AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
        AddAccessoryPEGARequest pegaRequest = new AddAccessoryPEGARequest();
        AddAccessoryPEGARequest response = CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, UIRequest, "oneClickCheckoutForAccessory", true);
        Assert.assertEquals("SOF-123445", response.getServiceBody().getServiceRequest().getContext().getCaseId());
    }

    @Test
    public void formatAddAccessoriesRequestScanAndGoTest() throws IOException {
        String sampleUIRequestString = "{\"channelId\":\"VZW-MFA-IOS\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"PromoHub\",\"processAction\":\"addAccessoryAndCheckout\",\"intendType\":\"ACC\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"0001797712-00001\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-MFA-IOS\",\"intent\":\"ACCSG\",\"flowType\":\"SCAN_AND_GO\"},\"data\":{\"lines\":[{\"removeAccessories\":[{\"qty\":2,\"isSoftSku\":false,\"accountLevelAccessory\":false,\"macId\":\"\",\"macIds\":[\"1CD6BE386883\",\"1CD6BE3868AD\"]}],\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\",\"zipCode\":\"\"}}";
        AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
        AddAccessoryPEGARequest pegaRequest = new AddAccessoryPEGARequest();
        AddAccessoryPEGARequest response = CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, UIRequest, "oneClickCheckoutForAccessory", true);
        Assert.assertEquals("SCAN_AND_GO", response.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getFlowType());
    }

    @Test
    public void formatAddAccessoriesRequestScanAndGoTest1() throws IOException {
        String sampleUIRequestString = "{\"channelId\":\"VZW-MFA-IOS\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"PromoHub\",\"processAction\":\"addAccessoryAndCheckout\",\"intendType\":\"ACC\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"0001797712-00001\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-MFA-IOS\",\"intent\":\"ACCSG\",\"flowType\":\"SCANANDGO\"},\"data\":{\"lines\":[{\"removeAccessories\":[{\"qty\":2,\"isSoftSku\":false,\"accountLevelAccessory\":false,\"macId\":\"\",\"macIds\":[\"1CD6BE386883\",\"1CD6BE3868AD\"]}],\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\",\"zipCode\":\"\"}}";
        AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
        AddAccessoryPEGARequest pegaRequest = new AddAccessoryPEGARequest();
        AddAccessoryPEGARequest response = CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, UIRequest, "oneClickCheckoutForAccessory", true);
        Assert.assertNull(response.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getFlowType());
    }

    @Test
    public void formatAddAccessoriesRequestScanAndGoEmptyFlowTypeTest() throws IOException {
        String sampleUIRequestString = "{\"channelId\":\"VZW-MFA-IOS\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"PromoHub\",\"processAction\":\"addAccessoryAndCheckout\",\"intendType\":\"ACC\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"0001797712-00001\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-MFA-IOS\",\"intent\":\"ACCSG\",\"flowType\":\"\"},\"data\":{\"lines\":[{\"removeAccessories\":[{\"qty\":2,\"isSoftSku\":false,\"accountLevelAccessory\":false,\"macId\":\"\",\"macIds\":[\"1CD6BE386883\",\"1CD6BE3868AD\"]}],\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\",\"zipCode\":\"\"}}";
        AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
        AddAccessoryPEGARequest pegaRequest = new AddAccessoryPEGARequest();
        AddAccessoryPEGARequest response = CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, UIRequest, "oneClickCheckoutForAccessory", true);
        Assert.assertNull(response.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getFlowType());
    }

    @Test
    public void formatAddDeviceRequestCustConsentTest() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"caseId\":\"SOF-case\",\"byodESim\":\"byod\",\"universalId\":\"Y\",\"intendType\":\"DEO\"},\"data\":{\"couponCode\":\"testCoupon\",\"lines\":[{\"portInNumber\":\"9905629442\",\"idVerifyStatus\":\"pass\",\"isCustConsentAcceptedSMSBlast\":true,\"highRiskSimswapDelayActivation\":true,\"device\":{\"connectedCarDetails\":{}}}]}}";
        AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,true,true, getFFlag());
        Assert.assertEquals("DEO", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
    }

    @Test
    public void formatRequestForPrepaidToPostpaidMigrationTest() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"noPendingOfferExists\":false,\"isPromoPDP\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"30004\"},\"data\":{\"lines\":[{\"isCommonPDP\":true,\"mtn\":\"\",\"purchasePath\":\"NSE\",\"portInNumber\":\"\",\"eupNoPromoFlow\":false,\"device\":{\"id\":\"MR3J3LL/A\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":true,\"dppMonths\":36,\"productId\":\"dev19920002\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"UNIVESIM5G-SA-S\"},\"ispuFlow\":false,\"estimatedReadyByDate\":\"\",\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"newLineOrAAL\":false,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":true,\"selectedSedOfferId\":\"\",\"isStrategicOffer\":\"\",\"restricted\":\"\",\"isTradeInIntentSelected\":false}],\"prepaidMtn\":\"9349349342\",\"rtm\":{\"url\":\"https://vzwqa1.verizonwireless.com/smartphones/apple-iphone-14/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-yellow-spring2023\",\"name\":\"iPhone 14\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://vzwqa1.verizonwireless.com/smartphones/apple-iphone-14/\"}}}";
        AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
        uiRequest.getCartInfo().setPrepaidToPostpaidMigration(true);
        AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,true,true, getFFlag());
        Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
    }

    @Test
    public void formatRequestAddressTest() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"noPendingOfferExists\":false,\"isPromoPDP\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"30004\", " +
                "\"city\": \"BATON ROUGE\",\"addressLine1\": \"1 ONE AMERICAN PL\",\"state\": \"LA\",\"zipCode\": \"87001\"}," +
                "\"data\":{\"enableFcc\": true,\"lines\":[{\"isCommonPDP\":true,\"mtn\":\"\",\"purchasePath\":\"NSE\",\"portInNumber\":\"\",\"eupNoPromoFlow\":false,\"device\":{\"id\":\"MR3J3LL/A\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":true,\"dppMonths\":36,\"productId\":\"dev19920002\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"UNIVESIM5G-SA-S\"},\"ispuFlow\":false,\"estimatedReadyByDate\":\"\",\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"newLineOrAAL\":false,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":true,\"selectedSedOfferId\":\"\",\"isStrategicOffer\":\"\",\"restricted\":\"\",\"isTradeInIntentSelected\":false}],\"prepaidMtn\":\"9349349342\",\"rtm\":{\"url\":\"https://vzwqa1.verizonwireless.com/smartphones/apple-iphone-14/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/iphone-14-yellow-spring2023\",\"name\":\"iPhone 14\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://vzwqa1.verizonwireless.com/smartphones/apple-iphone-14/\"}}}";
        AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
        uiRequest.getCartInfo().setPrepaidToPostpaidMigration(true);
        AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,true,true, getFFlag());
        Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
        uiRequest.getCartInfo().setIntendType("NSEBYOD");
        AddDevicePEGARequest response1 = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,true,true, getFFlag());
        Assert.assertEquals("NSEBYOD", response1.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
    }

    @Test
    public void formatRequestForBauByodFlow() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":\"addDeviceSim\",\"intendType\":\"NSEBYOD\",\"validateDevicePlanCompatible\":true},\"data\":{\"subFlow\":\"Nxtgen-BYOD-C\",\"lines\":[{\"mtn\":\"newLine1\",\"device\":{\"id\":\"MHCY3LL/A\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"\",\"contractTerm\":\"MONTH_TO_MONTH\",\"deviceId\":\"\",\"smartIMEI\":true,\"category\":\"Smartphone\",\"rawCategory\":\"4G Smartphone\",\"prodType\":\"4GSmartphone-IN\",\"byodESimPhone\":false},\"sim\":{\"id\":\"DFILLSIM5G-SA-A\",\"isCustomerProvidedSIM\":false,\"iccid\":\"\",\"eSIM\":\"\"},\"isNewLine\":true,\"ispuFlow\":false,\"depletionType\":\"F\",\"depletionLocationCode\":\"\",\"isKeepingExistingEqProtection\":true}]}}" ;
        AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
        uiRequest.setChannelId("VZW-DOTCOM");
        AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,true,true, getFFlag());
        Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());

        uiRequest.getData().setSubFlow("instant");
        response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,true,true, getFFlag());
        Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());

        uiRequest.getData().setSubFlow("");
        response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,true,true, getFFlag());
        Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());

        uiRequest.setChannelId("OMNI-RETAIL");
        response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,true,true, getFFlag());
        Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());

        uiRequest.setChannelId(null);
        response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,true,true, getFFlag());
        Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());


    }

    @Test
    public void formatRequestForByodFlow() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"\",\"processStep\":\"LineSelection\",\"intendType\":\"BYOD\",\"mtnFlow\":\"P\",\"customerType\":\"N\",\"cartCreatorSalesRepId\":\"ENC\",\"cartCreatorOrderLocationCode\":\"D463801\"},\"data\":{\"zipCode\":\"07920\",\"numOfLines\":2,\"friendsAndFamilyCode\":\"fnfCode\",\"couponCode\":\"testCoupon\",\"lines\":[{\"mtn\":\"\",\"deviceTypeSelected\":\"\",\"portInNumber\":\"\"},{\"mtn\":\"\",\"deviceTypeSelected\":\"\"}]}}";
        CreateLineUIRequest uiRequest = mapper.readValue(requestString, CreateLineUIRequest.class);
        uiRequest.setChannelId("VZW-DOTCOM");
        CreateLinePEGARequest response = CartPegaRequestUtil3.formatCreateLineRequest(new CreateLinePEGARequest(), uiRequest);
        Assert.assertEquals("BYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());

        uiRequest.getCartInfo().setIntendType("NSEBYOD");
        response = CartPegaRequestUtil3.formatCreateLineRequest(new CreateLinePEGARequest(), uiRequest);
        Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());

        uiRequest.setChannelId("OMNI-RETAIL");
        response = CartPegaRequestUtil3.formatCreateLineRequest(new CreateLinePEGARequest(), uiRequest);
        Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());

    }

    @Test
    public void bauByodTest(){
        AddDeviceUIRequest addDeviceUIRequest = new AddDeviceUIRequest();
        addDeviceUIRequest.setChannelId("VZW-DOTCOM");
        String bauByodFlow = CartPegaRequestUtil4.isBauByodFlow(addDeviceUIRequest);
        Assert.assertNotNull(bauByodFlow);
    }

    @Test
    public void formatClearandResumeRequestTest() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"channelId\":\"VZW-DOTCOM\",\"cartInfo\":{\"caseId\":\"case\",\"salesRepId\":\"global\",\"intendType\":\"BYOD\"},\"data\":{\"lines\":[{}]}}";
        ClearAndContinueUIRequest uiRequest = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
        ClearAndContinuePegaRequest response = CartPegaRequestUtil6.formatClearandResumeRequest(new ClearAndContinuePegaRequest(), uiRequest);
        Assert.assertEquals("BYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
    }

    @Test
    public void formatClearandResumeRequest1Test() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"channelId\":\"OMNI-RETAIL\",\"cartInfo\":{\"caseId\":\"case\",\"salesRepId\":\"global\",\"intendType\":\"BYOD\"},\"data\":{\"lines\":[{}]}}";
        ClearAndContinueUIRequest uiRequest = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
        ClearAndContinuePegaRequest response = CartPegaRequestUtil6.formatClearandResumeRequest(new ClearAndContinuePegaRequest(), uiRequest);
        Assert.assertEquals("BYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
    }

    @Test
    public void updateLGPOMarkerSPO_Test() throws JsonMappingException, JsonProcessingException{
        String requestString = "{\"cartInfo\":{\"processingMTN\":\"newLine1\",\"processStep\":\"NewRecommendedPlanSelection\",\"intendType\":\"NSE\",\"editPlanClick\":false,\"addressLine1\":\"\",\"city\":\"\",\"state\":\"\",\"zipCode\":\"\",\"customerType\":\"N\",\"mtnFlow\":\"D\",\"processAction\":\"addPlan\"},\"data\":{\"lines\":[{\"path\":\"custom\",\"action\":\"customized\",\"mtn\":\"newLine1\",\"plan\":{\"id\":\"63215\"},\"addFeatures\":[{\"id\":\"2885\",\"type\":\"SPO\",\"quantity\":1,\"actionIndicator\":\"A\"}],\"removeFeatures\":[]}],\"enableFcc\":true,\"parentMtn\":\"\"},\"optPlanSku\":true,\"isByou\":true}";
        AddPlanUIRequest request = mapper.readValue(requestString, AddPlanUIRequest.class);
        CartPegaRequestUtil2.updateLGPOMarkerSPO(request);

        CartPegaRequestUtil2.updateLGPOMarkerSPO(request);

        CartPegaRequestUtil2.updateLGPOMarkerSPO(request);
    }
}
