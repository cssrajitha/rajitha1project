package onevz.soe.cart.service.test.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.ui.responses.AddAllConfiguratorUIResponse;
import onevz.soe.cart.util.CartConfiguratorPegaResponseErrorsUtil;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.exception.SOEErrorHolder;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@WebFluxTest(CartConfiguratorPegaResponseErrorsUtil.class)
public class CartConfiguratorPegaResponseErrorsUtilTest {
    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;
    @Autowired
    private ObjectMapper mapper;
    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;

    @Test
    public void handleAddAllConfiguratorResponseErrorsTest() throws JsonProcessingException {
        String responseFile = "data/addAllToCartConfigurator/response/uiErrorResponse.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAllConfiguratorUIResponse response = mapper.readValue(responseString, AddAllConfiguratorUIResponse.class);
        CartConfiguratorPegaResponseErrorsUtil.handleAddAllConfiguratorResponseErrors(response);
        response.setErrors(null);
        Assert.assertNotNull(CartConfiguratorPegaResponseErrorsUtil.handleAddAllConfiguratorResponseErrors(response));
    }

    @Test
    public void handleAddAllConfiguratorResponseErrorsTest2() throws JsonProcessingException {
        String responseFile = "data/addAllToCartConfigurator/response/uiErrorResponse2.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAllConfiguratorUIResponse response = mapper.readValue(responseString, AddAllConfiguratorUIResponse.class);
        CartConfiguratorPegaResponseErrorsUtil.handleAddAllConfiguratorResponseErrors(response);
        Assert.assertNotNull(response);
    }

    @Test
    public void handleCommonErrorTest() throws JsonProcessingException {
        String responseFile = "data/addAllToCartConfigurator/response/uiErrorResponse.json";
        String errorString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        SOEErrorHolder response = mapper.readValue(errorString, SOEErrorHolder.class);
        Assert.assertNotNull(CartConfiguratorPegaResponseErrorsUtil.handleCommonError(response));
        response = null;
        Assert.assertNotNull(CartConfiguratorPegaResponseErrorsUtil.handleCommonError(response));
    }
}