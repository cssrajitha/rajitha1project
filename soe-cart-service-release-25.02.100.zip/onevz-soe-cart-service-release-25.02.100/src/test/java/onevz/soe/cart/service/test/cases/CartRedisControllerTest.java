package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.databind.ObjectMapper;
import junit.framework.Assert;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.controller.CartRedisController;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.helper.RedisHelper2;
import onevz.soe.cart.helper.UpdateCartHelper;
import onevz.soe.cart.requests.DualNumberRedisInfo;
import onevz.soe.cart.responses.FiveGAddressRedisData;
import onevz.soe.cart.responses.RTDRedisData;
import onevz.soe.cart.responses.RemoveOfferRedisData;
import onevz.soe.cart.responses.RemoveOfferRedisResponse;
import onevz.soe.omnidl.util.DLUtilityService;
import onevz.soe.security.TokenProcessor;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(CartRedisController.class)
public class CartRedisControllerTest {

	@MockBean
	private UpdateCartHelper cartHelper;

	@Autowired
	private CartRedisController cartController;

	@MockBean
	private RedisHelper redisHelper;

	@MockBean
	private RedisHelper2 redisHelper2;

	@MockBean
	private DLUtilityService dlUtilityService;

	@MockBean
	private TokenProcessor tokenProcessor;
	
	@Autowired
	private ObjectMapper mapper;

	@Test
	public void upsert5GAddressTest() throws IOException {
		URI url = URI.create("http://localhost/upsert5GAddress");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		when(redisHelper2.upsertFiveGAddressIntoRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<Boolean>> controllerResponse = cartController.upsert5GAddress(httpHeader, httpResponse,
				new FiveGAddressRedisData());
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}
	
	@Test
	public void removeHexPlanInfofromRedisTest() throws IOException {
		URI url = URI.create("http://localhost/removeHexPlanInfofromRedis");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, url).build();
		ServerHttpResponse httpResponse = null;
		List<String> keys = new ArrayList<>();
		keys.add(CartConstants.MYOFFER_HEXPLAN_INFO);
		when(redisHelper.deleteHexPlanOfferInfoIntoRedis(keys)).thenReturn(Mono.just(1L));
		Mono<ResponseEntity<Boolean>> controllerResponse = cartController.removeHexPlanInfofromRedis(httpHeader,httpResponse);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}
	
	@Test
	public void upsertRTDDataTest() throws IOException {
		URI url = URI.create("http://localhost/upsertRTDData");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		when(redisHelper2.upsertRTDRedisDataIntoRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<Boolean>> controllerResponse = cartController.upsertRTDData(httpHeader,httpResponse , new RTDRedisData());
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}
	


	@Test
	public void upsertRemoveOfferDataTest() throws IOException {
		String request = "{ \"lines\": [{ \"mtn\": \"7082851259\", \"removeOffers\": [{ \"id\": \"203780\" }] }] }";
 		RemoveOfferRedisData requestString = mapper.readValue(request, RemoveOfferRedisData.class);
 		String removeOfferRequest = "{ \"lines\": [{ \"mtn\": \"7082851259\", \"removeOffers\": [{ \"id\": \"203781\" }] }] }";
 		RemoveOfferRedisData RemoveOfferRequestString = mapper.readValue(removeOfferRequest, RemoveOfferRedisData.class);
		URI url = URI.create("http://localhost/upsertRemoveOfferData");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		when(redisHelper2.getRemoveOfferDataIntoRedis()).thenReturn(Mono.just(RemoveOfferRequestString));
		when(redisHelper2.upsertRemoveOfferDataIntoRedis(RemoveOfferRequestString)).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<RemoveOfferRedisResponse>> controllerResponse = cartController.upsertRemoveOfferData(httpHeader,httpResponse , requestString);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void upsertRemoveOfferDataTest2() throws IOException {
		String request = "{ \"lines\": [{ \"mtn\": \"\", \"removeOffers\": [{ \"id\": \"203780\" }] }] }";
		RemoveOfferRedisData requestString = mapper.readValue(request, RemoveOfferRedisData.class);
		String removeOfferRequest = "{ \"lines\": [{ \"mtn\": \"7082851259\", \"removeOffers\": [{ \"id\": \"203781\" }] }] }";
		RemoveOfferRedisData RemoveOfferRequestString = mapper.readValue(removeOfferRequest, RemoveOfferRedisData.class);
		URI url = URI.create("http://localhost/upsertRemoveOfferData");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		when(redisHelper2.getRemoveOfferDataIntoRedis()).thenReturn(Mono.just(RemoveOfferRequestString));
		when(redisHelper2.upsertRemoveOfferDataIntoRedis(RemoveOfferRequestString)).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<RemoveOfferRedisResponse>> controllerResponse = cartController.upsertRemoveOfferData(httpHeader,httpResponse , requestString);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}
	
	@Test
	public void upsertRemoveOfferDataTest3() throws IOException {
		String request = "{\"lines\": []}";
		RemoveOfferRedisData requestString = mapper.readValue(request, RemoveOfferRedisData.class);
		URI url = URI.create("http://localhost/upsertRemoveOfferData");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		when(redisHelper2.getRemoveOfferDataIntoRedis()).thenReturn(Mono.just(new RemoveOfferRedisData()));
		when(redisHelper2.upsertRemoveOfferDataIntoRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<RemoveOfferRedisResponse>> controllerResponse = cartController.upsertRemoveOfferData(httpHeader,httpResponse , requestString);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertEquals(HttpStatus.BAD_REQUEST, resp.getStatusCode())).expectComplete().verify();
	}
	
	@Test
	public void upsertRemoveOfferDataTest4() throws IOException {
		String request = "{\"lines\": [{\"mtn\": \"45678\",\"removeOffers\": [{\"id\": \"id\"}]}]}";
		RemoveOfferRedisData requestString = mapper.readValue(request, RemoveOfferRedisData.class);
		String removeOfferRequestString = "{ \"lines\": [{ \"mtn\": \"7082851259\", \"removeOffers\": [{ \"id\": \"203781\" }] }] }";
		RemoveOfferRedisData removeOfferRequest = mapper.readValue(removeOfferRequestString, RemoveOfferRedisData.class);
		URI url = URI.create("http://localhost/upsertRemoveOfferData");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		when(redisHelper2.getRemoveOfferDataIntoRedis()).thenReturn(Mono.just(removeOfferRequest));
		when(redisHelper2.upsertRemoveOfferDataIntoRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<RemoveOfferRedisResponse>> controllerResponse = cartController.upsertRemoveOfferData(httpHeader,httpResponse , requestString);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertEquals(HttpStatus.OK, resp.getStatusCode())).expectComplete().verify();
	}
	
	@Test
	public void upsertRemoveOfferDataTest5() throws IOException {
		String request = "{\"lines\": [{\"mtn\": \"7082851259\",\"removeOffers\": [{\"id\": \"203781\"}]}]}";
		RemoveOfferRedisData requestString = mapper.readValue(request, RemoveOfferRedisData.class);
		String removeOfferRequestString = "{ \"lines\": [{ \"mtn\": \"7082851259\", \"removeOffers\": [{ \"id\": \"203781\" }] }] }";
		RemoveOfferRedisData removeOfferRequest = mapper.readValue(removeOfferRequestString, RemoveOfferRedisData.class);
		URI url = URI.create("http://localhost/upsertRemoveOfferData");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		when(redisHelper2.getRemoveOfferDataIntoRedis()).thenReturn(Mono.just(removeOfferRequest));
		when(redisHelper2.upsertRemoveOfferDataIntoRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<RemoveOfferRedisResponse>> controllerResponse = cartController.upsertRemoveOfferData(httpHeader,httpResponse , requestString);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertEquals(HttpStatus.OK, resp.getStatusCode())).expectComplete().verify();
	}
	
	@Test
	public void upsertRemoveOfferDataTest6() throws IOException {
		String request = "{\"lines\": [{\"mtn\": \"7082851259\",\"removeOffers\": [{\"id\": \"4567\" }]}]}";
		RemoveOfferRedisData requestString = mapper.readValue(request, RemoveOfferRedisData.class);
		String removeOfferRequestString = "{ \"lines\": [{ \"mtn\": \"7082851259\", \"removeOffers\": [{\"id\": \"id1\"},{\"id\": \"id2\"}]}] }";
		RemoveOfferRedisData removeOfferRequest = mapper.readValue(removeOfferRequestString, RemoveOfferRedisData.class);
		URI url = URI.create("http://localhost/upsertRemoveOfferData");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		when(redisHelper2.getRemoveOfferDataIntoRedis()).thenReturn(Mono.just(removeOfferRequest));
		when(redisHelper2.upsertRemoveOfferDataIntoRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<RemoveOfferRedisResponse>> controllerResponse = cartController.upsertRemoveOfferData(httpHeader,httpResponse , requestString);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertEquals(HttpStatus.OK, resp.getStatusCode())).expectComplete().verify();
	}

	@Test
	public void removeDualNumberDetailsFromRedisTest() throws IOException {
		URI url = URI.create("http://localhost/removeSecondNumberDetails");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		List<String> keys = new ArrayList<>();
		keys.add(CartConstants.DUAL_NUMBER);
		DualNumberRedisInfo dualNumberInfo = new DualNumberRedisInfo();
		dualNumberInfo.setIsDualNumberFlow(true);
		when(redisHelper.deletDualNumberDetailsFromRedis(dualNumberInfo)).thenReturn(Mono.just(1L));
		Mono<ResponseEntity<Boolean>> controllerResponse = cartController.removeDualNumberDetailsFromRedis(httpHeader,httpResponse,dualNumberInfo);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}
}
