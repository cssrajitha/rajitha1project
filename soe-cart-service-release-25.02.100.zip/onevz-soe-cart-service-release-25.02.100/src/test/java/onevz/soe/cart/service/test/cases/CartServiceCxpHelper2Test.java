package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.SneakyThrows;
import onevz.aem.errorhandling.service.CartAEMService;
import onevz.aem.response.DeviceModelMap;
import onevz.aem.response.ESim;
import onevz.aem.response.PSim;
import onevz.aem.response.ProspectDeviceModelMapResponse;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper2;
import onevz.soe.cart.cxp.helper.CatalogServiceHelper;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.cxp.service.CatalogService;
import onevz.soe.cart.helper.FeatureFlagHelper;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.helper.RedisHelper2;
import onevz.soe.cart.helper.RedisHelper3;
import onevz.soe.cart.model.bundleBuilderCart.BundleBuilderCXPCartDataVO;
import onevz.soe.cart.model.bundleBuilderCart.BundleBuilderCXPCartVO;
import onevz.soe.cart.model.bundleBuilderCart.BundleBuilderCartHeader;
import onevz.soe.cart.model.catalog.CatalogData;
import onevz.soe.cart.model.catalog.FeatureCatalogItem;
import onevz.soe.cart.model.common.ConnectedCarDetails;
import onevz.soe.cart.model.common.Device;
import onevz.soe.cart.model.common.SoftSKUItem;
import onevz.soe.cart.model.deviceIdValidation.DeviceIdValidationLine;
import onevz.soe.cart.model.deviceIdValidation.SearchAttributes;
import onevz.soe.cart.model.deviceIdValidation.WireLineAccountInformation;
import onevz.soe.cart.model.deviceSimValidation.DeviceAttributes;
import onevz.soe.cart.model.deviceSimValidation.EsimInfo;
import onevz.soe.cart.model.elasticsearch.Brands;
import onevz.soe.cart.model.elasticsearch.TypeAheadData;
import onevz.soe.cart.model.mylink.MylinkReferralInfoResponse;
import onevz.soe.cart.model.retrieveCart.*;
import onevz.soe.cart.requests.BundleBuilderRequest;
import onevz.soe.cart.requests.GetOrderDetailsGQLRequest;
import onevz.soe.cart.requests.RetrieveCartCXPRequest;
import onevz.soe.cart.requests.ValidateCartCXPRequest;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.common.GiftBox;
import onevz.soe.cart.ui.requests.DeviceIdValidationUIRequest;
import onevz.soe.cart.ui.requests.DeviceSimValidationUIRequest;
import onevz.soe.cart.ui.requests.GetBrandsRequest;
import onevz.soe.cart.ui.responses.DeviceSimValidationUIResponse;
import onevz.soe.cart.ui.responses.RetrieveCartUIResponse;
import onevz.soe.cart.ui.responses.ValidateCartUIResponse;
import onevz.soe.cart.util.CommonUtil;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.exception.SOEErrorHolder;
import onevz.soe.orderprocess.translator.BundleBuilderResponse;
import onevz.soe.orderprocess.translator.model.CartHeaderLW;
import onevz.soe.orderprocess.translator.model.CartLW;
import onevz.soe.orderprocess.translator.model.DataLW;
import onevz.soe.spring.web.filter.RequestAccessContext;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.api.Assertions;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.ResourceUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.URI;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.*;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import onevz.cxp.feature.Flag;
import onevz.cxp.feature.util.FeatureFlag;
import onevz.soe.cart.constants.FeatureFlagConstants;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { CartServiceTestConfig.class })
public class CartServiceCxpHelper2Test {

	private static final Logger logger = LoggerFactory.getLogger(CartServiceCxpHelper2Test.class);

	@Mock
	private CartServiceCXPServices cxpService;

	@Mock
	Environment environment;

	@Mock
	private CatalogService catalogService;

	@Mock
	CatalogServiceHelper catalogServiceHelper;
	
	@Mock
    CommonUtil util;
	
	@InjectMocks
	private CartServiceCxpHelper cxpHelper;
	@InjectMocks
	private CartServiceCxpHelper2 cxpHelper2;
	
	@Mock
	FeatureFlagHelper featureFlagHelper;

	@Autowired
	private ObjectMapper mapper;

	@Mock
	private RedisHelper redisHelper;

	@Mock
	private RedisHelper2 redisHelper2;

	@Mock
	private RedisHelper3 redisHelper3;

	@Mock
	private CartAEMService cartAEMService;
	
	@Captor
	private ArgumentCaptor<String> argumentCaptor;
	@Mock
	FeatureFlag featureFlag;
	@Mock
	CartServiceCXPServices cartServiceCXPServices;
	@Mock
	CommonUtil commonUtil;

	@Autowired
	SourceFileReaderUtil sourceFileReaderUtil;

	@Value("${onevz.soe.cart.test.fileLocation}")
	private String testFileLocation;

	@Test
	public void deviceIdValidationTestNullCheck() throws IOException {
		String sampleRequestString = "{ \"channelId\":\"OMNI-CARE\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"action\": \"BYOD\",                \"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",                \"processingMTN\": \"\",                                \"intent\": \"5GHome\",                \"processStep\": \"GridWallPDP\",                \"processAction\": \"validateGiftBoxId\"        },        \"data\": {                \"lines\": [{                        \"mtn\": \"6159691822\",                        \"device\": {                                        \"Flowtype\": \"GIFTBOX\",                                \"isCustomerProvidedEquipment\":true,                                \"giftBox\": {                                \"id\":\"LVSKPGB\"                        }                        }                }]        }}";
		String sampleResponseString = "{\"client\": \"CXP\", \"data\": {  \"lines\": [{  \"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		StepVerifier.create(cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		ProspectDeviceModelMapResponse ProspectDeviceModelMapResponseObj = new ProspectDeviceModelMapResponse();
		DeviceModelMap DeviceModelMapObj = new DeviceModelMap();
		DeviceModelMapObj.setKey("randomABC()");
		ESim ESimObj1 = new ESim();
		ESimObj1.setVERIZON("VERIZON");
		DeviceModelMapObj.setESim(ESimObj1);
		PSim PSimObj1 = new PSim();
		PSimObj1.setVERIZON("VERIZON");
		DeviceModelMapObj.setPSim(PSimObj1);
		DeviceModelMap DeviceModelMapObj1 = new DeviceModelMap();
		DeviceModelMapObj1.setKey(null);
		DeviceModelMapObj1.setESim(ESimObj1);
		DeviceModelMapObj1.setPSim(PSimObj1);
		DeviceModelMap DeviceModelMapObj2 = new DeviceModelMap();
		DeviceModelMapObj2.setESim(ESimObj1);
		DeviceModelMapObj2.setPSim(PSimObj1);
		DeviceModelMapObj2.setKey("random()");
		ProspectDeviceModelMapResponseObj.setDeviceModelMap(Arrays.asList(DeviceModelMapObj, DeviceModelMapObj1,DeviceModelMapObj2));
		when(cartAEMService.getSKUDetail(Mockito.any())).thenReturn(Mono.just(ProspectDeviceModelMapResponseObj));
		sampleRequest.getData().getLines().get(0).setEsimFlow(true);
		sampleRequest.getData().getLines().get(0).getDevice().setSmartIMEI(true);
		sampleRequest.setChannelId("random");
		sampleRequest.getData().getLines().get(0).getDevice().setSkuCarrier(CartConstants.VERIZON);
		sampleRequest.getData().getLines().get(0).getDevice().setSimSelected("random");
		sampleRequest.getData().getLines().get(0).getDevice().setIdentifier("random()");
		sampleRequest.getData().getLines().get(0).getDevice().setId("invalid");
		sampleRequest.getData().getLines().get(0).getDevice().setFlowtype("invalid");
		sampleRequest.getData().getLines().get(0).getDevice().setCurrentId("invalid");
		sampleRequest.getData().getLines().get(0).getDevice().setIsCustomerProvidedEquipment(true);
		when(commonUtil.formatDevice(Mockito.any(), Mockito.any())).thenReturn(new Device());
		StepVerifier.create(Mono.fromCallable(()->cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes()))).expectError(NullPointerException.class)
				.verify();

		sampleRequest.getData().getLines().get(0).setEsimFlow(false);
		sampleRequest.getData().getLines().get(0).getDevice().setSimSelected("random");
		sampleRequest.getData().getLines().get(0).getDevice().setSkuCarrier(CartConstants.OTHER);
		StepVerifier.create(Mono.fromCallable(()->cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes()))).expectError(NullPointerException.class)
				.verify();

		sampleRequest.getData().getLines().get(0).getDevice().setSkuCarrier("random");
		ProspectDeviceModelMapResponseObj.setDeviceModelMap(new ArrayList<>());
		when(cartAEMService.getSKUDetail(Mockito.any())).thenReturn(Mono.just(ProspectDeviceModelMapResponseObj));
		StepVerifier.create(Mono.fromCallable(()->cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes()))).expectError(NullPointerException.class)
				.verify();

		when(cartAEMService.getSKUDetail(Mockito.any())).thenReturn(Mono.error(Exception::new));
		StepVerifier.create(Mono.fromCallable(()->cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes()))).expectError(NullPointerException.class)
				.verify();

		DeviceModelMapObj.setKey("random()");
		DeviceModelMapObj.setModel("random");
		ESim ESimObj = new ESim();
		ESimObj.setVERIZON("VERIZON");
		DeviceModelMapObj.setESim(ESimObj);
		PSim PSimObj = new PSim();
		PSimObj.setVERIZON("VERIZON");
		DeviceModelMapObj.setPSim(PSimObj);

		DeviceModelMapObj1.setKey(null);
		DeviceModelMapObj1.setModel("random");
		ESimObj.setVERIZON("VERIZON");
		DeviceModelMapObj1.setESim(ESimObj);
		PSimObj.setVERIZON("VERIZON");
		DeviceModelMapObj1.setPSim(PSimObj);
		ProspectDeviceModelMapResponseObj.setDeviceModelMap(Arrays.asList(DeviceModelMapObj, DeviceModelMapObj1));
		when(cartAEMService.getSKUDetail(Mockito.any())).thenReturn(Mono.just(ProspectDeviceModelMapResponseObj));
		sampleRequest.getData().getLines().get(0).getDevice().setSkuCarrier("VERIZON");
		sampleRequest.getData().getLines().get(0).getDevice().setIdentifier("random()");
		StepVerifier.create(Mono.fromCallable(()->cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes()))).expectError(NullPointerException.class)
				.verify();

		sampleRequest.getData().getLines().get(0).getDevice().setSkuCarrier(null);
		StepVerifier.create(Mono.fromCallable(()->cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes()))).expectError(NullPointerException.class)
				.verify();
		sampleRequest.getData().getLines().get(0).getDevice().setSkuCarrier(null);
		ProspectDeviceModelMapResponseObj.setDeviceModelMap(Arrays.asList());
		when(cartAEMService.getSKUDetail(Mockito.any())).thenReturn(Mono.just(ProspectDeviceModelMapResponseObj));
		StepVerifier.create(Mono.fromCallable(()->cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes()))).expectError(NullPointerException.class)
				.verify();;
		
	}
	@Test
	public void deviceIdValidationTestDvm() throws IOException {
		String sampleRequestString = "{ \"channelId\":\"OMNI-CARE\",\"cartInfo\": {\"clientAppName\": \"VZW-NETACE\",\"action\": \"BYOD\",                \"cartId\": \"845001b6-5524-4424-ae61-ba9f4099c18d\",\"caseId\": \"SOP-1103-E01\",\"accountNumber\": \"0207688462-00001\",\"cartCreator\": \"6159691822\",                \"processingMTN\": \"\",                                \"intent\": \"5GHome\",                \"processStep\": \"GridWallPDP\",                \"processAction\": \"validateGiftBoxId\"        },        \"data\": {                \"lines\": [{                        \"mtn\": \"6159691822\",                        \"device\": {                                        \"Flowtype\": \"GIFTBOX\",                                \"isCustomerProvidedEquipment\":true,                                \"giftBox\": {                                \"id\":\"LVSKPGB\"                        }                        }                }]        }}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
	
		WireLineAccountInformation wirelineRequest = new WireLineAccountInformation();
		wirelineRequest.setVztAccountNo("testValue123");
		wirelineRequest.setEmail("testEmail@verizon.com");
		wirelineRequest.setMtn("123456789");
		wirelineRequest.setNetworkTrialHash("MTIzLTQ1Ni03ODkw");
		sampleRequest.getData().getLines().get(0).setWireLineAccountInformation(wirelineRequest);
		StepVerifier.create(cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		when(featureFlagHelper.isTrialHashFflagEnabled()).thenReturn(Mono.just(true));
		StepVerifier.create(cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		
		when(featureFlagHelper.isTrialHashFflagEnabled()).thenReturn(Mono.just(false));
		StepVerifier.create(cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

	}

	@Test
	public void validateCartTestNullCheck() throws JsonParseException, JsonMappingException, IOException {
		String sampleRequestString = "{\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\",\"channel\":\"assissted\",\"pageId\":\"landing\",\"flow\":\"upgrade\"}";
		String sampleResponseString = "{\"meta\":{\"timestamp\":1576738912272,\"cxpCorrelationId\":\"2019-12-19T07:01:52.+0000:9aac3280-ddf8-4d7f-b6a5-e830afcfbddd:cxp-cart-domain-dev-ev6v-dev-nsd2cxp-857ffb57c4-2fx2v\"},\"data\":{\"validateCartAndUpdate\":{\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"emailAddress\":null,\"shellAccountNumber\":null,\"mtn\":null,\"creditApplicationNum\":388936130,\"secondaryCreditApplicationNum\":0,\"lockStatus\":null,\"lockingSystem\":null,\"lastAccessSystem\":\"CXP\",\"originatingSalesRep\":null,\"lastAccessSalesRep\":null,\"latestCartRefId\":null,\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"businessName\":null,\"dbCartId\":null,\"cpqCartVersionId\":null,\"cpqCartId\":null,\"creditApplication\":null,\"ecpdInfo\":null},\"orderDetails\":{\"orderType\":\"PS\",\"accountType\":null,\"locationCode\":\"E248201\",\"homeLocation\":null,\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"creditApprovalStatus\":null,\"creditStatusReason\":null,\"creditAdvisory\":null,\"creditClass\":null,\"securityDepositAmount\":null,\"totalTaxAmount\":\"38.75\",\"fraudLevel\":null,\"deviceRecycleAttempted\":null,\"explicitSaveInd\":null,\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"tradeAtHome\":null,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"reservationId\":null},\"globalPromotions\":{\"promoDetails\":[{\"promoBadgeMessages\":[{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"null\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"},{\"badgeText\":\"AppleMusicincluded,onuswithselectUnlimitedplans.GetitoniOSandAndroid.\",\"badgeToolTip\":\"\",\"badgeToolTipUrl\":\"<tooltip-url>/content/wcms/reusable-content/offers/apple-music.html</tooltip-url>\",\"badgeImage\":\"\",\"placement\":\"CONTENT-HEADER\",\"pageId\":\"CART\",\"masterpageId\":\"ALL\"}],\"promoType\":\"PLAN_OFFER\",\"promotionId\":\"promo1370098\",\"priority\":10}]},\"lineDetails\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"saleType\":null,\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"country\":null},\"isValidAddress\":true},\"activationDate\":null,\"activateLaterInd\":null,\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"newPricePlanId\":null,\"contractTermId\":null,\"pricePlanInfo\":null,\"selectedFeaturesList\":null,\"selectedALPShareList\":null,\"planDetails\":null,\"correlationID\":null,\"isSharePlanAdded\":false,\"sbdOffer\":null},\"tradeInItems\":null,\"taxPrices\":null,\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"addrType\":null,\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"type\":null,\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"bsnsName\":null,\"shippingCode\":null,\"shippingCost\":\"0.0\",\"cbrPhone\":null},\"fipsCode\":null,\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"ACCESSORY\",\"cartHasPCD\":false,\"isPreconfigureEnabled\":true,\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"description\":null,\"qty\":1,\"itemPrice\":null,\"taxAmount\":0.0,\"prodCode1\":null,\"prodCode2\":null,\"prodCode3\":null,\"prodCode4\":null,\"priceType\":null,\"btaEligible\":null,\"catalogPrice\":null,\"unitTaxBasedPrice\":null,\"itemNrpPrice\":null,\"itemCost\":null,\"upgradeReasonCode\":null,\"itemPriceType\":null,\"sedOfferList\":null,\"rebateOffer\":null}]}}]}]}}}}";
		ValidateCartCXPRequest request = mapper.readValue(sampleRequestString, ValidateCartCXPRequest.class);
		ValidateCartCXPResponse sampleCXPResponse = mapper.readValue(sampleResponseString, ValidateCartCXPResponse.class);
		CXPCartVO CXPCartVOObj = new CXPCartVO();
		CXPCartVOObj.setLineDetails(new CXPLineDetailsVO());
		CXPCartVOObj.getLineDetails().setTradeInDetail(new TradeInDetail());
		ServiceInfo ServiceInfoObj = new ServiceInfo();
		ServiceInfoObj.setSelectedALPShareList(new SelectedALPShareList());
		ServiceInfoObj.getSelectedALPShareList().setNewAlpShareInfo(new AlpShareInfo[]{new AlpShareInfo()});
		ServiceInfoObj.setNewPricePlanInfo(new PricePlanInfo());
		CXPLineInfo CXPLineInfoObj = new CXPLineInfo();
		CXPLineInfoObj.setLineActivityType("Random");
		CXPLineInfoObj.setServiceInfo(ServiceInfoObj);
		CXPLineInfo CXPLineInfoObj1 = new CXPLineInfo();
		CXPLineInfoObj1.setLineActivityType(CartConstants.NSE_BYOD);
		CXPLineInfo CXPLineInfoObj2 = new CXPLineInfo();
		CXPLineInfoObj2.setLineActivityType(CartConstants.BYOD);
		CXPLineInfo CXPLineInfoObj3 = new CXPLineInfo();
		CXPLineInfoObj3.setLineActivityType(CartConstants.ACC);
		CXPLineInfo CXPLineInfoObj4 = new CXPLineInfo();
		CXPLineInfoObj4.setLineActivityType(CartConstants.AAL);
		CXPLineInfoObj4.setServiceInfo(ServiceInfoObj);
		CXPLineInfo CXPLineInfoObj5 = new CXPLineInfo();
		CXPLineInfoObj5.setLineActivityType(CartConstants.CPC);
		CXPLineInfo CXPLineInfoObj6 = new CXPLineInfo();
		CXPLineInfoObj6.setLineActivityType(CartConstants.NSE);
		CXPCartVOObj.getLineDetails().setLineInfo(new CXPLineInfo[]{CXPLineInfoObj,CXPLineInfoObj1, CXPLineInfoObj2,CXPLineInfoObj3,CXPLineInfoObj4,CXPLineInfoObj5,CXPLineInfoObj6});
		sampleCXPResponse.getData().setValidateCartAndUpdate(CXPCartVOObj);
		when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just("newCustomer"));
		when(redisHelper2.updateCartOrderFlowType(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		when(cxpService.validateCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleCXPResponse));
		when(redisHelper2.upsertDeviceCartMapInRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		when(cxpService.validateCartNewCustomer(Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(new ValidateCartCXPResponse()));
		CartRedisData data=new CartRedisData();
		Mono<ValidateCartUIResponse> UIResponse = cxpHelper.validateCart(request,data);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just(CartConstants.EXPRESS));
		CXPLineInfoObj.setLineActivityType(null);
		CXPCartVOObj.getLineDetails().setLineInfo(new CXPLineInfo[]{CXPLineInfoObj,CXPLineInfoObj1, CXPLineInfoObj2,CXPLineInfoObj3,CXPLineInfoObj4,CXPLineInfoObj5,CXPLineInfoObj6});
		sampleCXPResponse.getData().setValidateCartAndUpdate(CXPCartVOObj);
		when(cxpService.validateCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(sampleCXPResponse));
		StepVerifier.create(cxpHelper.validateCart(request,data)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just(CartConstants.STANDALONE));
		StepVerifier.create(cxpHelper.validateCart(request,data)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just(CartConstants.CPC));
		StepVerifier.create(cxpHelper.validateCart(request,data)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just(""));
		StepVerifier.create(cxpHelper.validateCart(request,data)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just("random"));
		StepVerifier.create(cxpHelper.validateCart(request,data)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getOrderReviewDetailsTest() throws IOException, SOEHTTPException {
      /* String PegaResponse = getData("classpath:AddTruckRollCartBPMResponse.json");
           AddTruckRollCartUIResponse uiResponse = mapper.readValue(PegaResponse,AddTruckRollCartUIResponse.class);
           StepVerifier.create(helper.getOrderReviewDetails(uiResponse)).expectComplete(); */
//		String sampleRequest = "{cart(cartId:\"3fd555a0-3d6a-4284-b245-d504c650246f\",retrieveCurrentFeatures:false){cartIdlineDetails{lineInfo{serviceInfo{cart5GAppointment{altPhonecustomerInstructionsemailAddresseventCorrelationIdfirstNamehomePhoneinstallApptSelectedDate{availableDateavailableDayavailableTypeserviceProviderAccountserviceProviderNameslotLengthslotStartTimeselfInstallDate}lastNamepreferredContactTypeprimaryPhoneTypeworkPhone}}}}}}";
//		GetOrderDetailsGQLRequest orderReviewDetailsRequest = mapper.readValue(sampleRequest,GetOrderDetailsGQLRequest.class);
		GetOrderDetailsGQLRequest orderReviewDetailsRequest = new GetOrderDetailsGQLRequest();
		String sampleResponseString = "{\"data\":{\"cart\":{\"cartId\":\"3fd555a0-3d6a-4284-b245-d504c650246f\",\"lineDetails\":{\"lineInfo\":[{\"serviceInfo\":{\"cart5GAppointment\":{}},\"lineRefundTotal\":0.0,\"lineExchangeTotal\":0.0,\"protectionNotRequired\":false}]}}},\"meta\":{\"timestamp\":\"1669139714748\",\"cxpCorrelationId\":\"2022-11-22T17:55:14.+0000:f5e6d62fcb18e249:cxp-shopping-services-qa-ev6v-sit1e-nscxp-56dbd99557-jq95f:nssit1\"}}";
		OrderReviewDetailsResponse orderReviewDetailsResponse = mapper.readValue(sampleResponseString,OrderReviewDetailsResponse.class);
		when(cxpService.getOrderReviewDetails(Mockito.any(),Mockito.any())).thenReturn(Mono.just(orderReviewDetailsResponse));

//    Mono<OrderReviewDetailsResponse> getOrderReviewDetailsResponse = cxpHelper.getOrderReviewDetails(request);
		StepVerifier.create(cxpHelper.getOrderReviewDetails(orderReviewDetailsRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

	}

	@Test
	public void getDeviceCartCountTest2() throws IOException {
		String sampleRequestString = "{\"meta\":{\"user\":\"kumasa1\",\"client\":\"B2C-TELESALES\"},\"data\":{\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\"}}";
		String sampleResponseString = "{\"data\":{\"cart\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"status\":\"A\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"cartCreator\":\"4434541510\",\"cartCreatorOrderLocationCode\":\"E248201\",\"cartCreatorSalesRepId\":\"ENC\",\"creditApplicationNum\":\"388936130\",\"secondaryCreditApplicationNum\":0},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"customerType\":\"U\",\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"totalTaxAmount\":\"38.75\",\"spocs\":{\"notificationOptions\":{\"contactPhoneNumber\":\"1196120299\",\"primaryEmailId\":\"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"instantCreditAmount\":0.0,\"instantCreditAmountRemaining\":0.0,\"instantCreditEligible\":false,\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":388936130,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\":\"true\",\"creditAdvisory\":\"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\":\"0\",\"serviceClass\":\"B\",\"lineCreditClass\":\"\"},\"orderActivityType\":\"EUP\",\"orderNumber\":\"1112\"}],\"orderNumber\":0,\"outletId\":\"124632\",\"registerNumber\":0,\"saleType\":\"P\",\"salesRepId\":\"ENC\",\"totalInstantCreditAmount\":0.0,\"totalInstantCreditAmountUsed\":0.0},\"lineDetails\":{\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"mldTrunkMTN\":0,\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"zipCode4\":\"7848\"},\"isValidAddress\":true},\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"currentDevice\":{\"oldLteVoraEquipInfo\":{\"iccid\":\"89148000004671963398\",\"lteVoraDeviceInfo\":{\"deviceId\":\"352530085081859\",\"deviceType\":\"4GE\"}}},\"isSharePlanAdded\":false,\"edgeLine\":false,\"vlcLine\":false,\"isE911AddressValidated\":false,\"oldPlanFlag\":\"L\",\"orderDevice\":{\"lteVoraEquipInfo\":{\"lteEqpt\":{},\"lteVoraDeviceInfo\":{}}}},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"shippingCost\":\"0.0\",\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"isUseUnVerifiedAddress\":false,\"isValidAddress\":false},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"mobileNumber\":\"4434541510\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"groupDiscInd\":0,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-thumb$\"},\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"color\":{\"color\":\"#cfbea9\",\"colorDisplayName\":\"GOLD/PINKSAND\"},\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"discounts\":[],\"availableReasonCode\":[],\"inventory\":{\"isAvailable\":true,\"isBackorder\":false,\"isPreOrder\":false,\"qtyAvailable\":39437.0},\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"numberShareEligible\":\"true\",\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0}]},\"isPromoSelected\":false,\"isTradeInSelected\":false}],\"lineIdentifier\":0,\"itemSeqNum5GL\":0,\"itemSeqNum4GR\":0,\"lineExchangeTotal\":0.0,\"lineRefundTotal\":0.0,\"isCpe\":false,\"isDevicePlanCompatible\":false,\"portinMtnAssignment\":false,\"impactedLine\":false,\"preOrBackOrder\":false,\"ispuItem\":true,\"ispuItemBYOD\":false}],\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"numofLinesAAL\":0,\"numofLinesEUP\":0,\"validationMessages\":[],\"payments\":[],\"lineSeq\":0,\"vlcactivePhoneCount\":0,\"fivegOrderind\":false,\"aceOrderCreated\":false,\"serviceLinesCreated\":false,\"aceItemsModified\":false,\"clnrOrderFlag\":false,\"broadbandInd\":false,\"isPaperLessBilling\":\"false\"}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
		RetrieveCartCXPRequest request = mapper.readValue(sampleRequestString, RetrieveCartCXPRequest.class);
		RetrieveCartCXPResponse sampleCXPResponse = mapper.readValue(sampleResponseString, RetrieveCartCXPResponse.class);
		when(cxpService.deviceCountInCart(Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleCXPResponse));
		Mono<Integer> response=cxpHelper.getDeviceCartCount("3efad59a-f94e-45fa-9ed9-fd72aeae9bd5");
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void bundleBuilderCartTest() throws IOException {
		String requestString = "{\"cartId\":\"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\",\"channelId\":\"VZW-DOTCOM\",\"pageId\":\"\"}";
		String responseString = "{\"data\":{\"cart\":{\"cartHeader\":{\"cartId\":\"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\"},\"lineDetails\":{\"lineSeq\":1,\"numOfLines\":1,\"numofLinesAAL\":1,\"numofLinesEUP\":0,\"allLines\":[\"AAL\",\"EUP\"],\"lineInfo\":[{\"lineActivityType\":\"EUP\",\"multiLineSeqNumber\":1,\"mobileNumber\":\"988888888\",\"itemsInfo\":[{\"cartItemType\":\"DEVICE\"}]}]}}}}";
		String redisDataString = "{\"data\":{\"cart\":{\"cartHeader\":{\"cartId\":\"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\"},\"lineDetails\":{\"lineSeq\":1,\"numOfLines\":1,\"numofLinesAAL\":1,\"numofLinesEUP\":0,\"allLines\":[\"AAL\",\"EUP\"],\"lineInfo\":[{\"lineActivityType\":\"EUP\",\"multiLineSeqNumber\":1,\"mobileNumber\":\"988888888\",\"itemsInfo\":[{\"cartItemType\":\"DEVICE\"}]}]}}}}";

		BundleBuilderRequest request = getBundleBuilderRequest();
		BundleBuilderCXPResponseData serviceResponse = mapper.readValue(responseString, BundleBuilderCXPResponseData.class);
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Map<String, Object> secondAppvedData = new HashMap<>();
		secondAppvedData.put(CartConstants.APPROVED_SECONDCAPTCHA_REDIS_KEY, Boolean.TRUE.toString());
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(cxpService.bundleBuilderCart(anyString(),anyString(),Mockito.anyBoolean(),anyString(),
				Mockito.anyBoolean(),anyString(),anyString(),Mockito.anyList(),Mockito.anyBoolean(),anyString(),Mockito.anyList())).thenReturn(Mono.just(serviceResponse));
		when(featureFlag.isFeatureEnabled(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.FALSE));
		when(featureFlagHelper.isWinbackOfferFlagEnabled()).thenReturn(Mono.just(Boolean.FALSE));
		Mono<BundleBuilderCXPResponseData> cartServiceHelperResponse = cxpHelper.bundleBuilderCart(request);
		StepVerifier.create(cartServiceHelperResponse).expectError(NullPointerException.class)
				.verify();

	}

	@Test
	public void localStoreOffersTest() throws IOException {
		ReflectionTestUtils.setField(cxpHelper, "enableOptimisedDigitalRetrieveCart", true);
        String sampleResponseString = getData("classpath:LocalStoreOffers_RetrieveCart.json");
		String sampleRequestString = "{\"meta\":null,\"data\":{\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\", \"retrieveCurrentFeatures\":true, \"isLocalStoreOfferEnabled\":true, \"eligiblePlanIdsForLocalStoreOffer\":\"50434,50433,50432,50431,50430,50428,50427,50420\"}}";

		RetrieveCartCXPRequest request = mapper.readValue(sampleRequestString, RetrieveCartCXPRequest.class);
		RetrieveCartCXPResponse sampleCXPResponse = null;
		sampleCXPResponse = mapper.readValue(sampleResponseString, RetrieveCartCXPResponse.class);
		Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
		when(cxpService.retrieveCart(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(catalogService.getCatalogRefData(Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		when(catalogServiceHelper.getCatalogDomainData(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		when(redisHelper3.upsertCartCreator(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<RetrieveCartUIResponse> UIResponse = cxpHelper.retrieveCart(request);
		logger.debug("cxpResponse " + UIResponse);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}

    @Test
    public void localStoreOffersTest1() throws IOException {
        ReflectionTestUtils.setField(cxpHelper, "enableOptimisedDigitalRetrieveCart", true);
        String sampleResponseString = getData("classpath:LocalStoreOffers_RetrieveCart1.json");
        String sampleRequestString = "{\"meta\":null,\"data\":{\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\", \"retrieveCurrentFeatures\":true, \"isLocalStoreOfferEnabled\":true, \"eligiblePlanIdsForLocalStoreOffer\":\"50434,50433,50432,50431,50430,50428,50427,50420\"}}";

        RetrieveCartCXPRequest request = mapper.readValue(sampleRequestString, RetrieveCartCXPRequest.class);
        RetrieveCartCXPResponse sampleCXPResponse = null;
        sampleCXPResponse = mapper.readValue(sampleResponseString, RetrieveCartCXPResponse.class);
        Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
        when(cxpService.retrieveCart(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
        when(catalogService.getCatalogRefData(Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		when(catalogServiceHelper.getCatalogDomainData(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
        when(redisHelper3.upsertCartCreator(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<RetrieveCartUIResponse> UIResponse = cxpHelper.retrieveCart(request);
        logger.debug("cxpResponse " + UIResponse);
        StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
    }

	@Test
	public void localStoreOffersTest2() throws IOException {
		ReflectionTestUtils.setField(cxpHelper, "enableOptimisedDigitalRetrieveCart", true);
		String sampleResponseString = getData("classpath:LocalStoreOffers_RetrieveCart2.json");
		String sampleRequestString = "{\"meta\":null,\"data\":{\"cartId\":\"5560eeed-2ad2-4634-866b-c4986502594b\", \"retrieveCurrentFeatures\":true, \"isLocalStoreOfferEnabled\":true, \"eligiblePlanIdsForLocalStoreOffer\":\"50434,50433,50432,50431,50430,50428,50427,50420\"}}";

		RetrieveCartCXPRequest request = mapper.readValue(sampleRequestString, RetrieveCartCXPRequest.class);
		RetrieveCartCXPResponse sampleCXPResponse = null;
		sampleCXPResponse = mapper.readValue(sampleResponseString, RetrieveCartCXPResponse.class);
		Mono<RetrieveCartCXPResponse> sampleCXPResponseMono = Mono.just(sampleCXPResponse);
		when(cxpService.retrieveCart(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(sampleCXPResponseMono);
		when(catalogService.getCatalogRefData(Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		when(catalogServiceHelper.getCatalogDomainData(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CatalogResponse()));
		when(redisHelper3.upsertCartCreator(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<RetrieveCartUIResponse> UIResponse = cxpHelper.retrieveCart(request);
		logger.debug("cxpResponse " + UIResponse);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
	}

    private String getData(String jsonFilePath) throws IOException {
        File file = ResourceUtils.getFile(jsonFilePath);
        String data = new String(Files.readAllBytes(file.toPath()));
        return new String(data.getBytes("UTF-8"));
    }

	@Test
	public void validateMyLinkReferralInfoTest() {
		String hashKey = "random"; String salesFlowSessionId = "random";
		when(cxpService.validateMyLinkReferralInfo(Mockito.any())).thenReturn(Mono.just(new MylinkReferralInfoResponse()));
		Assert.assertNotNull(cxpHelper2.validateMyLinkReferralInfo(hashKey,salesFlowSessionId));

		when(cxpService.validateMyLinkReferralInfo(Mockito.any())).thenReturn(Mono.empty());
		Assert.assertNotNull(cxpHelper2.validateMyLinkReferralInfo(hashKey,salesFlowSessionId));
	}
	public void deviceSimValidationTest9() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"imei\": \"imei\", \"eid\": \"eid\", \"techType\": \"tech\", \"imei2\": \"imei2\"}";
		String dataString = "{\"mtn\": \"\"}";
		String cxpResponseString = "{\"data\": {\"esimInfo\": null, \"deviceInfo\": {\"deivceAttributes\": null}}}";
		EsimInfo esimInfo = new EsimInfo();
		DeviceAttributes deviceAttributes = mapper.readValue("{\"daccCode\": \"014335\", \"deviceCategory\": \"5G Tablet\"}", DeviceAttributes.class);
		DeviceSimValidationCXPResponse cxpResponse = mapper.readValue(cxpResponseString, DeviceSimValidationCXPResponse.class);
		cxpResponse.getData().setEsimInfo(esimInfo);
		cxpResponse.getData().getDeviceInfo().setDeviceAttributes(deviceAttributes);
		cxpResponse.getData().getDeviceInfo().setEuiccCapable("Y");
		CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
		DeviceSimValidationUIRequest uiRequest = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
		URI url = URI.create("http://localhost/nse/deviceSimValidation");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(data));
		when(cxpService.deviceSimValidation(Mockito.any())).thenReturn(Mono.just(cxpResponse));
		Mono<DeviceSimValidationUIResponse> response = cxpHelper2.deviceSimValidation(httpHeader, uiRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	public void deviceSimValidationTest10() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"imei\": \"imei\", \"eid\": \"eid\", \"techType\": \"tech\", \"imei2\": \"imei2\"}";
		String dataString = "{\"mtn\": \"\"}";
		String cxpResponseString = "{\"data\": {\"esimInfo\": null, \"deviceInfo\": {\"deivceAttributes\": null}}}";
		EsimInfo esimInfo = new EsimInfo();
		DeviceAttributes deviceAttributes = mapper.readValue("{\"daccCode\": \"014335\", \"deviceCategory\": \"4G Tablet\"}", DeviceAttributes.class);
		DeviceSimValidationCXPResponse cxpResponse = mapper.readValue(cxpResponseString, DeviceSimValidationCXPResponse.class);
		cxpResponse.getData().setEsimInfo(esimInfo);
		cxpResponse.getData().getDeviceInfo().setDeviceAttributes(deviceAttributes);
		cxpResponse.getData().getDeviceInfo().setEuiccCapable("Y");
		CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
		DeviceSimValidationUIRequest uiRequest = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
		URI url = URI.create("http://localhost/nse/deviceSimValidation");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(data));
		when(cxpService.deviceSimValidation(Mockito.any())).thenReturn(Mono.just(cxpResponse));
		Mono<DeviceSimValidationUIResponse> response = cxpHelper2.deviceSimValidation(httpHeader, uiRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deviceSimValidationTest11() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"imei\": \"imei\", \"eid\": \"eid\", \"techType\": \"tech\", \"imei2\": \"imei2\"}";
		String dataString = "{\"mtn\": \"\"}";
		String cxpResponseString = "{\"data\": {\"esimInfo\": null, \"deviceInfo\": {\"deivceAttributes\": null}}}";
		EsimInfo esimInfo = new EsimInfo();
		DeviceAttributes deviceAttributes = mapper.readValue("{\"daccCode\": \"014813\", \"deviceCategory\": \"5G LAPTOP\"}", DeviceAttributes.class);
		DeviceSimValidationCXPResponse cxpResponse = mapper.readValue(cxpResponseString, DeviceSimValidationCXPResponse.class);
		cxpResponse.getData().setEsimInfo(esimInfo);
		cxpResponse.getData().getDeviceInfo().setDeviceAttributes(deviceAttributes);
		cxpResponse.getData().getDeviceInfo().setEuiccCapable("Y");
		CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
		DeviceSimValidationUIRequest uiRequest = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
		URI url = URI.create("http://localhost/nse/deviceSimValidation");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(data));
		when(environment.getProperty(Mockito.any())).thenReturn("esim.ipad.daccs");
		when(cxpService.deviceSimValidation(Mockito.any())).thenReturn(Mono.just(cxpResponse));
		Mono<DeviceSimValidationUIResponse> response = cxpHelper2.deviceSimValidation(httpHeader, uiRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	public void deviceSimValidationTest12() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"imei\": \"imei\", \"eid\": \"eid\", \"techType\": \"tech\", \"imei2\": \"imei2\"}";
		String dataString = "{\"mtn\": \"\"}";
		String cxpResponseString = "{\"data\": {\"esimInfo\": null, \"deviceInfo\": {\"deivceAttributes\": null}}}";
		EsimInfo esimInfo = new EsimInfo();
		DeviceAttributes deviceAttributes = mapper.readValue("{\"daccCode\": \"014831\", \"deviceCategory\": \"4G LAPTOP\"}", DeviceAttributes.class);
		DeviceSimValidationCXPResponse cxpResponse = mapper.readValue(cxpResponseString, DeviceSimValidationCXPResponse.class);
		cxpResponse.getData().setEsimInfo(esimInfo);
		cxpResponse.getData().getDeviceInfo().setDeviceAttributes(deviceAttributes);
		cxpResponse.getData().getDeviceInfo().setEuiccCapable("Y");
		CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
		DeviceSimValidationUIRequest uiRequest = mapper.readValue(requestString, DeviceSimValidationUIRequest.class);
		URI url = URI.create("http://localhost/nse/deviceSimValidation");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(data));
		when(cxpService.deviceSimValidation(Mockito.any())).thenReturn(Mono.just(cxpResponse));
		Mono<DeviceSimValidationUIResponse> response = cxpHelper2.deviceSimValidation(httpHeader, uiRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getOrderReviewDetailsTest1() throws SOEHTTPException {
		GetOrderDetailsGQLRequest getOrderDetailsGQLRequest = new GetOrderDetailsGQLRequest();
		SOEErrorHolder soeErrorHolder = new SOEErrorHolder();
		when(cartServiceCXPServices.getOrderReviewDetails(any(),anyBoolean())).thenThrow(new SOEHTTPException(500,soeErrorHolder));
		//doThrow(new SOEHTTPException(500,soeErrorHolder)).when(cartServiceCXPServices.getOrderReviewDetails(any(),anyBoolean()));
		Mono<OrderReviewDetailsResponse> response = cxpHelper.getOrderReviewDetails(getOrderDetailsGQLRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void groupDeviceAndCarrierTest()
	{
		List<TypeAheadData> typeAheadDataList = new ArrayList<>();
		TypeAheadData data = new TypeAheadData();
		data.setModel_name_typeahead("-E");
		data.setModifiedName("test_device");
		List<String> carrier = new ArrayList<>();
		carrier.add("test_carrier");
		data.setCarrier(carrier);
		typeAheadDataList.add(data);
		ReflectionTestUtils.setField(cxpHelper,"SMART_IMEI_SUPPRESS_CARRIERS","empty");
		List<TypeAheadData> response = ReflectionTestUtils.invokeMethod(cxpHelper,"groupDeviceAndCarrier",typeAheadDataList);
		Assert.assertNotNull(response);

	}

	@Test
	public void getBrandsTest1() throws JsonParseException, JsonMappingException, IOException{
		String sampleResponseString="{ \"data\": { \"smartImeiTypeAheadDetails\": [ { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry 8703e\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry 7130e\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry Curve 9330\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry Pearl 8130\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry Storm2 9550\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry Bold 9650\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [], \"modelName\": \"SONY XPERIA 1 III\", \"euiccCapable\": false, \"makeTypeahead\": \"Sony Electronics Inc\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry 8230\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"PRIV by Blackberry\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry 8330\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry Curve 9310\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry Classic\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [], \"modelName\": \"MOTO G POWER 2021 XT2117-4\", \"euiccCapable\": false, \"makeTypeahead\": \"Motorola Mobility Inc\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry Curve 8530\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry Bold 9650 6.0\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry Bold 9930\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [], \"modelName\": \"4G Smartphone PDI\", \"euiccCapable\": false, \"makeTypeahead\": \"Provisional Device ID\" }, { \"carrier\": [], \"modelName\": \"HOT PEPPER JALAPENO UNL\", \"euiccCapable\": false, \"makeTypeahead\": \"Hot Pepper Inc\" }, { \"carrier\": [], \"modelName\": \"3G Smartphone PDI\", \"euiccCapable\": false, \"makeTypeahead\": \"Provisional Device ID\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BLACKBERRY Z10\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [], \"modelName\": \"HOT PEPPER HPP-GS1\", \"euiccCapable\": false, \"makeTypeahead\": \"Hot Pepper Inc\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry Z30\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry Curve 9370\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry Q10\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry 7250 EVDO\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry 9630\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry Storm\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry Torch 9850\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"SONY XPERIA PRO-I\", \"euiccCapable\": false, \"makeTypeahead\": \"Sony Electronics Inc\" }, { \"carrier\": [], \"modelName\": \"A_7130\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry 8830\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 7\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 5S\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone XS\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone SE\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 6S\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 5\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 6\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"SPRINT\", \"TMOBILE\" ], \"modelName\": \"iPhone 13 NVZ\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"SPRINT\", \"TMOBILE\" ], \"modelName\": \"IPHONE XR NVZ\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone XS Max\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12 MINI\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 8 Plus\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"SPRINT\", \"TMOBILE\" ], \"modelName\": \"IPHONE XS MAX\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 13 SO\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 11-E\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [], \"modelName\": \"iPhone XS SimOut\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE XR PP\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 6S Plus\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12 PRO\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12 SO eSIM\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 13 Pro SO\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"modelName\": \"IPHONE X NON VERIZON\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"SPRINT\", \"TMOBILE\" ], \"modelName\": \"IPHONE XR NVZ-E\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"modelName\": \"iPhone 8 Non Verizon\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 13 mini-2\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"modelName\": \"IPHONE12 MINI GEN NVZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 13 Pro Max\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [], \"modelName\": \"iPhone XS Max SimOut\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"SPRINT\", \"TMOBILE\", \"ATT\" ], \"modelName\": \"iPhone 13 Pro NVZ\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"SPRINT\", \"TMOBILE\", \"ATT\" ], \"modelName\": \"iPhone 7 - Non VZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"ATT\" ], \"modelName\": \"IPHONE XR NON VZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12 MINI eSIM\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE SE-E 2020\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"SPRINT\" ], \"modelName\": \"IPHONE 8 NON NVZ\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12 PRO Sim Out\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12 MINI SO eSIM\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 13 Pro Max-2\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"SPRINT\", \"TMOBILE\" ], \"modelName\": \"iPhone 13 Pro Max NVZ\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [], \"modelName\": \"iPhone 8 Non VZ CDMALess\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"SPRINT\", \"TMOBILE\" ], \"modelName\": \"IPHONE XS MAX NON VZW\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"modelName\": \"IPHONE12 MINI GEN-E NVZW\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [], \"modelName\": \"iPhone 8 Plus Sim Out\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [], \"modelName\": \"IPHONE 11 PRO MAX SO\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"modelName\": \"iPhone 6S Plus Non VZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 13 Pro Max SO\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"TMOBILE\", \"SPRINT\" ], \"modelName\": \"iPhone 6 Plus - Non VZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 11 PRO MAX-E\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"TMOBILE\", \"SPRINT\" ], \"modelName\": \"IPHONE 12 GEN-E NVZW\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12 MINI Sim Out\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12 PRO SO eSIM\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [], \"modelName\": \"iPhone 6 Plus Non VZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12 PRO MAX eSIM\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"SPRINT\", \"TMOBILE\" ], \"modelName\": \"iPhone 13 Pro Max-2 NVZ\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12 PRO MAX SO eSIM\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"TMOBILE\", \"ATT\", \"SPRINT\" ], \"modelName\": \"IPHONE 11 PRO MAX NON VZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [], \"modelName\": \"IPHONE X NON VERIZON CDMA LESS\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE X\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 11\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 8\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone XR\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 5C\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 4\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 13\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 4S\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 13 mini\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE SE 2020\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [], \"modelName\": \"IPHONE 6 TRACPHONE\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 13 Pro\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 6 Plus\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 11 PRO\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"SPRINT\", \"TMOBILE\" ], \"modelName\": \"IPHONE XS NVZ\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12 eSIM\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone XR SimOut\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 11 SO\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 7 Plus\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [], \"modelName\": \"iPhone XS eSIM\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 13-2\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone XR eSIM\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"SPRINT\" ], \"modelName\": \"IPHONE 6 SPRINT\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"SPRINT\", \"TMOBILE\" ], \"modelName\": \"IPHONE 11 NON VZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 11 PRO MAX\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 13 mini SO\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"modelName\": \"iPhone 6 - Non VZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [], \"modelName\": \"IPHONE 11 PRO SO\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"SPRINT\", \"TMOBILE\" ], \"modelName\": \"iPhone 13 mini NVZ\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 11 SO-E\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12 PRO eSIM\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"SPRINT\", \"ATT\", \"TMOBILE\" ], \"modelName\": \"iPhone SE Non VZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 8 VZN PP\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"modelName\": \"IPHONE12 PROMAX GEN NVZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12 PRO MAX\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"TMOBILE\", \"ATT\", \"SPRINT\" ], \"modelName\": \"iPhone 13-2 NVZ\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [], \"modelName\": \"IPHONE XS NON VZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 11 PRO-E\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [], \"modelName\": \"iPhone 6 Non VZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [], \"modelName\": \"iPhone 8 Sim Out\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 13 Pro-2\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12 Sim Out\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"modelName\": \"IPHONE 12 GEN NVZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"modelName\": \"iPhone 6S Non VZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"modelName\": \"IPHONE12 PRO GEN NVZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [], \"modelName\": \"IPHONE X SIM OUT\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [], \"modelName\": \"iPhone XS Max eSIM\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE SE SO 2020\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE SE SO-E 2020\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"modelName\": \"iPhone 8 Plus Non Verizon\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"SPRINT\", \"TMOBILE\" ], \"modelName\": \"iPhone 13 mini-2 NVZ\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 11 PRO SO-E\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"modelName\": \"IPHONE12 PROMAX GEN-E NVZW\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"SPRINT\", \"TMOBILE\" ], \"modelName\": \"IPHONE 11 PRO NON VZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"SPRINT\", \"ATT\", \"TMOBILE\" ], \"modelName\": \"iPHONE SE GENERIC NON VZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"SPRINT\", \"TMOBILE\" ], \"modelName\": \"IPHONE 11-E NON VZW\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"SPRINT\", \"ATT\", \"TMOBILE\" ], \"modelName\": \"iPhone 7 Plus - Non VZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"SPRINT\", \"TMOBILE\" ], \"modelName\": \"iPhone 13 Pro-2 NVZ\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"modelName\": \"IPHONE12 PRO GEN-E NVZW\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 11 PRO MAX SO-E\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"SPRINT\", \"TMOBILE\" ], \"modelName\": \"IPHONE 11 PRO-E NON VZW\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12 PRO MAX Sim Out\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" } ] } }";
		SmartImeiTypeAheadCXPResponse sampleUiResponse=mapper.readValue(sampleResponseString, SmartImeiTypeAheadCXPResponse.class);
		Mono<SmartImeiTypeAheadCXPResponse> sampleCXPResponseMono = Mono.just(sampleUiResponse);
		when(catalogService.smartImeiTypeAhead(Mockito.any())).thenReturn(sampleCXPResponseMono);
		GetBrandsRequest getBrandsReq=new GetBrandsRequest();
		getBrandsReq.setDeviceCategory(CartConstants.SMARTPHONES);
		Mono<Brands> uIResponse = cxpHelper.getBrands(getBrandsReq);
        StepVerifier.create(uIResponse).assertNext(resp -> Assert.assertNotNull(resp.getBrands())).expectComplete()
				.verify();


		getBrandsReq.setDeviceCategory(CartConstants.TABLETS);
		uIResponse = cxpHelper.getBrands(getBrandsReq);
		StepVerifier.create(uIResponse).assertNext(resp -> Assert.assertNotNull(resp.getBrands())).expectComplete()
				.verify();

		getBrandsReq.setDeviceCategory(CartConstants.SMARTPHONE);
		uIResponse = cxpHelper.getBrands(getBrandsReq);
		StepVerifier.create(uIResponse).assertNext(resp -> Assert.assertNotNull(resp.getBrands())).expectComplete()
				.verify();

		getBrandsReq.setDeviceCategory(StringUtils.EMPTY);
		uIResponse = cxpHelper.getBrands(getBrandsReq);
		StepVerifier.create(uIResponse).assertNext(resp -> Assert.assertNotNull(resp.getBrands())).expectComplete()
				.verify();

		uIResponse = cxpHelper.getBrands(null);
		StepVerifier.create(uIResponse).assertNext(resp -> Assert.assertNotNull(resp.getBrands())).expectComplete()
				.verify();

	}

	public void getBrandsTest2() throws JsonParseException, JsonMappingException, IOException{
		String sampleRequestString = "{\"deviceCategory\":\"Tablets\"}";
		String sampleResponseString="{ \"data\": { \"smartImeiTypeAheadDetails\": [ { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry 8703e\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry 7130e\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry Curve 9330\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry Pearl 8130\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry Storm2 9550\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry Bold 9650\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [], \"modelName\": \"SONY XPERIA 1 III\", \"euiccCapable\": false, \"makeTypeahead\": \"Sony Electronics Inc\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry 8230\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"PRIV by Blackberry\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry 8330\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry Curve 9310\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry Classic\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [], \"modelName\": \"MOTO G POWER 2021 XT2117-4\", \"euiccCapable\": false, \"makeTypeahead\": \"Motorola Mobility Inc\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry Curve 8530\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry Bold 9650 6.0\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry Bold 9930\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [], \"modelName\": \"4G Smartphone PDI\", \"euiccCapable\": false, \"makeTypeahead\": \"Provisional Device ID\" }, { \"carrier\": [], \"modelName\": \"HOT PEPPER JALAPENO UNL\", \"euiccCapable\": false, \"makeTypeahead\": \"Hot Pepper Inc\" }, { \"carrier\": [], \"modelName\": \"3G Smartphone PDI\", \"euiccCapable\": false, \"makeTypeahead\": \"Provisional Device ID\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BLACKBERRY Z10\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [], \"modelName\": \"HOT PEPPER HPP-GS1\", \"euiccCapable\": false, \"makeTypeahead\": \"Hot Pepper Inc\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry Z30\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry Curve 9370\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry Q10\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry 7250 EVDO\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry 9630\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry Storm\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry Torch 9850\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"SONY XPERIA PRO-I\", \"euiccCapable\": false, \"makeTypeahead\": \"Sony Electronics Inc\" }, { \"carrier\": [], \"modelName\": \"A_7130\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"BlackBerry 8830\", \"euiccCapable\": false, \"makeTypeahead\": \"Research in Motion\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 7\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 5S\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone XS\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone SE\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 6S\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 5\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 6\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"SPRINT\", \"TMOBILE\" ], \"modelName\": \"iPhone 13 NVZ\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"SPRINT\", \"TMOBILE\" ], \"modelName\": \"IPHONE XR NVZ\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone XS Max\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12 MINI\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 8 Plus\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"SPRINT\", \"TMOBILE\" ], \"modelName\": \"IPHONE XS MAX\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 13 SO\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 11-E\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [], \"modelName\": \"iPhone XS SimOut\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE XR PP\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 6S Plus\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12 PRO\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12 SO eSIM\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 13 Pro SO\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"modelName\": \"IPHONE X NON VERIZON\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"SPRINT\", \"TMOBILE\" ], \"modelName\": \"IPHONE XR NVZ-E\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"modelName\": \"iPhone 8 Non Verizon\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 13 mini-2\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"modelName\": \"IPHONE12 MINI GEN NVZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 13 Pro Max\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [], \"modelName\": \"iPhone XS Max SimOut\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"SPRINT\", \"TMOBILE\", \"ATT\" ], \"modelName\": \"iPhone 13 Pro NVZ\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"SPRINT\", \"TMOBILE\", \"ATT\" ], \"modelName\": \"iPhone 7 - Non VZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"ATT\" ], \"modelName\": \"IPHONE XR NON VZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12 MINI eSIM\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE SE-E 2020\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"SPRINT\" ], \"modelName\": \"IPHONE 8 NON NVZ\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12 PRO Sim Out\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12 MINI SO eSIM\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 13 Pro Max-2\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"SPRINT\", \"TMOBILE\" ], \"modelName\": \"iPhone 13 Pro Max NVZ\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [], \"modelName\": \"iPhone 8 Non VZ CDMALess\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"SPRINT\", \"TMOBILE\" ], \"modelName\": \"IPHONE XS MAX NON VZW\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"modelName\": \"IPHONE12 MINI GEN-E NVZW\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [], \"modelName\": \"iPhone 8 Plus Sim Out\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [], \"modelName\": \"IPHONE 11 PRO MAX SO\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"modelName\": \"iPhone 6S Plus Non VZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 13 Pro Max SO\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"TMOBILE\", \"SPRINT\" ], \"modelName\": \"iPhone 6 Plus - Non VZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 11 PRO MAX-E\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"TMOBILE\", \"SPRINT\" ], \"modelName\": \"IPHONE 12 GEN-E NVZW\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12 MINI Sim Out\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12 PRO SO eSIM\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [], \"modelName\": \"iPhone 6 Plus Non VZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12 PRO MAX eSIM\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"SPRINT\", \"TMOBILE\" ], \"modelName\": \"iPhone 13 Pro Max-2 NVZ\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12 PRO MAX SO eSIM\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"TMOBILE\", \"ATT\", \"SPRINT\" ], \"modelName\": \"IPHONE 11 PRO MAX NON VZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [], \"modelName\": \"IPHONE X NON VERIZON CDMA LESS\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE X\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 11\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 8\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone XR\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 5C\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 4\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 13\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 4S\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 13 mini\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE SE 2020\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [], \"modelName\": \"IPHONE 6 TRACPHONE\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 13 Pro\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 6 Plus\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 11 PRO\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"SPRINT\", \"TMOBILE\" ], \"modelName\": \"IPHONE XS NVZ\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12 eSIM\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone XR SimOut\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 11 SO\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 7 Plus\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [], \"modelName\": \"iPhone XS eSIM\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 13-2\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone XR eSIM\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"SPRINT\" ], \"modelName\": \"IPHONE 6 SPRINT\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"SPRINT\", \"TMOBILE\" ], \"modelName\": \"IPHONE 11 NON VZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 11 PRO MAX\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 13 mini SO\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"modelName\": \"iPhone 6 - Non VZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [], \"modelName\": \"IPHONE 11 PRO SO\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"SPRINT\", \"TMOBILE\" ], \"modelName\": \"iPhone 13 mini NVZ\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 11 SO-E\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12 PRO eSIM\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"SPRINT\", \"ATT\", \"TMOBILE\" ], \"modelName\": \"iPhone SE Non VZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 8 VZN PP\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"modelName\": \"IPHONE12 PROMAX GEN NVZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12 PRO MAX\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"TMOBILE\", \"ATT\", \"SPRINT\" ], \"modelName\": \"iPhone 13-2 NVZ\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [], \"modelName\": \"IPHONE XS NON VZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 11 PRO-E\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [], \"modelName\": \"iPhone 6 Non VZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [], \"modelName\": \"iPhone 8 Sim Out\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"iPhone 13 Pro-2\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12 Sim Out\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"modelName\": \"IPHONE 12 GEN NVZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"modelName\": \"iPhone 6S Non VZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"modelName\": \"IPHONE12 PRO GEN NVZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [], \"modelName\": \"IPHONE X SIM OUT\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [], \"modelName\": \"iPhone XS Max eSIM\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE SE SO 2020\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE SE SO-E 2020\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"modelName\": \"iPhone 8 Plus Non Verizon\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"SPRINT\", \"TMOBILE\" ], \"modelName\": \"iPhone 13 mini-2 NVZ\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 11 PRO SO-E\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"modelName\": \"IPHONE12 PROMAX GEN-E NVZW\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"SPRINT\", \"TMOBILE\" ], \"modelName\": \"IPHONE 11 PRO NON VZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"SPRINT\", \"ATT\", \"TMOBILE\" ], \"modelName\": \"iPHONE SE GENERIC NON VZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"SPRINT\", \"TMOBILE\" ], \"modelName\": \"IPHONE 11-E NON VZW\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"SPRINT\", \"ATT\", \"TMOBILE\" ], \"modelName\": \"iPhone 7 Plus - Non VZW\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"SPRINT\", \"TMOBILE\" ], \"modelName\": \"iPhone 13 Pro-2 NVZ\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"TMOBILE\", \"SPRINT\", \"ATT\" ], \"modelName\": \"IPHONE12 PRO GEN-E NVZW\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 11 PRO MAX SO-E\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"OTHER\", \"ATT\", \"SPRINT\", \"TMOBILE\" ], \"modelName\": \"IPHONE 11 PRO-E NON VZW\", \"euiccCapable\": true, \"makeTypeahead\": \"Apple\" }, { \"carrier\": [ \"VERIZON\" ], \"modelName\": \"IPHONE 12 PRO MAX Sim Out\", \"euiccCapable\": false, \"makeTypeahead\": \"Apple\" } ] } }";
		SmartImeiTypeAheadCXPResponse sampleUiResponse=mapper.readValue(sampleResponseString, SmartImeiTypeAheadCXPResponse.class);
		Mono<SmartImeiTypeAheadCXPResponse> sampleCXPResponseMono = Mono.just(sampleUiResponse);
		when(catalogService.smartImeiTypeAhead(Mockito.any())).thenReturn(sampleCXPResponseMono);
		GetBrandsRequest getBrandsReq=new GetBrandsRequest();
		getBrandsReq.setDeviceCategory(CartConstants.SMARTPHONES);
		Mono<Brands> UIResponse = cxpHelper.getBrands(getBrandsReq);
		StepVerifier.create(UIResponse).assertNext(resp -> Assert.assertNotNull(resp.getBrands())).expectComplete()
				.verify();

	}

	//fetchFeatureCatalogRespTest
	@Test
	public void fetchFeatureCatalogRespTest() {
		CatalogResponse response =null;
		Assert.assertNull(cxpHelper2.fetchFeatureCatalogResp(null,response));

		response = new CatalogResponse();
		Assert.assertNull(cxpHelper2.fetchFeatureCatalogResp(null,response));

		CatalogData data = new CatalogData();
		response.setData(data);
		Assert.assertNull(cxpHelper2.fetchFeatureCatalogResp(null,response));

		FeatureCatalogItem featureCatalogItem = new FeatureCatalogItem();
		data.setFeatureCatalogItems(Arrays.asList(featureCatalogItem));
		Assert.assertNull(cxpHelper2.fetchFeatureCatalogResp(null,response));

	}
	
	@Test
	@SneakyThrows
	public void bundleBuilderCartNoPromoTest() throws IOException {
		var json ="{\"data\":{\"cart\":{\"cartHeader\":{\"cartId\":\"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\"},\"lineDetails\":{\"lineSeq\":1,\"numOfLines\":1,\"numofLinesAAL\":1,\"numofLinesEUP\":0,\"allLines\":[\"AAL\",\"EUP\"],\"lineInfo\":[{\"lineActivityType\":\"EUP\",\"multiLineSeqNumber\":1,\"mobileNumber\":\"988888888\",\"itemsInfo\":[{\"cartItemType\":\"DEVICE\"}]}]}}}}";
		BundleBuilderCXPResponseData serviceResponse = mapper.readValue(json, BundleBuilderCXPResponseData.class);
		when(cxpService.bundleBuilderCart(anyString(),anyString(),Mockito.anyBoolean(),anyString(),
				Mockito.anyBoolean(),anyString(),anyString(),Mockito.anyList(),Mockito.anyBoolean(),anyString(),Mockito.anyList()))
				.thenReturn(Mono.just(serviceResponse));
		var builderRequest = getBundleBuilderRequest();
		when(featureFlagHelper.isWinbackOfferFlagEnabled()).thenReturn(Mono.just(Boolean.FALSE));
		StepVerifier.create(cxpHelper.bundleBuilderCart(builderRequest)).expectError(NullPointerException.class)
				.verify();
//		Mockito.verify(cxpService,times(1)).bundleBuilderCart(anyString(),anyString(),Mockito.anyBoolean(), argumentCaptor.capture(),
//				Mockito.anyBoolean(),anyString(),anyString(),Mockito.anyList(),Mockito.anyBoolean(),anyString(),Mockito.anyList());
//		var value = argumentCaptor.getValue();
//		Assertions.assertThat(value).isEqualTo(StringUtils.EMPTY);
		builderRequest.setSelectedOfferId(null);
		when(featureFlagHelper.isWinbackOfferFlagEnabled()).thenReturn(Mono.just(Boolean.FALSE));
		StepVerifier.create(cxpHelper.bundleBuilderCart(builderRequest))
				.expectError(NullPointerException.class)
				.verify();
	}
	
	private static BundleBuilderRequest getBundleBuilderRequest() {
		var request = new BundleBuilderRequest();
		request.setPromoChoiceOffer(true);
		request.setCartId(UUID.randomUUID().toString());
		request.setMtn("9999999");
		request.setSelectedOfferType(StringUtils.EMPTY);
		request.setAccountNumber("3883");
		request.setCachedOffer(false);
		request.setPageId("OfferInterstitial");
		request.setStrategicOfferEnabled(false);
		request.setSelectedOfferId(CartConstants.NOPROMO);
		request.setOfferFilters(List.of());
		return request;
	}

	@Test
	public void bundleBuilderPromoChoiceTest() throws IOException {
		String responseString = "{\"data\":{\"cart\":{\"cartHeader\":{\"cartId\":\"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\"},\"lineDetails\":{\"lineSeq\":1,\"numOfLines\":1,\"numofLinesAAL\":1,\"numofLinesEUP\":0,\"allLines\":[\"AAL\",\"EUP\"],\"lineInfo\":[{\"lineActivityType\":\"EUP\",\"multiLineSeqNumber\":1,\"mobileNumber\":\"988888888\",\"itemsInfo\":[{\"cartItemType\":\"DEVICE\"}]}]}}}}";
		String redisDataString = "{\"data\":{\"cart\":{\"cartHeader\":{\"cartId\":\"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\"},\"lineDetails\":{\"lineSeq\":1,\"numOfLines\":1,\"numofLinesAAL\":1,\"numofLinesEUP\":0,\"allLines\":[\"AAL\",\"EUP\"],\"lineInfo\":[{\"lineActivityType\":\"EUP\",\"multiLineSeqNumber\":1,\"mobileNumber\":\"988888888\",\"itemsInfo\":[{\"cartItemType\":\"DEVICE\"}]}]}}}}";
		BundleBuilderRequest request = getBundleBuilderRequest();
		BundleBuilderCXPResponseData serviceResponse = mapper.readValue(responseString, BundleBuilderCXPResponseData.class);
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Map<String, Object> secondAppvedData = new HashMap<>();
		secondAppvedData.put(CartConstants.APPROVED_SECONDCAPTCHA_REDIS_KEY, Boolean.TRUE.toString());
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		Mockito.when(cxpService.bundleBuilderCart(any(String.class),any(String.class),anyBoolean(),any(String.class),
				anyBoolean(),any(String.class),any(String.class),anyList(),anyBoolean(),any(String.class),anyList())).thenReturn(Mono.just(serviceResponse));
		when(featureFlagHelper.isWinbackOfferFlagEnabled()).thenReturn(Mono.just(Boolean.TRUE));
		Mono<BundleBuilderCXPResponseData> cartServiceHelperResponse = cxpHelper.bundleBuilderCart(request);
		StepVerifier.create(cartServiceHelperResponse).expectError(NullPointerException.class).verify();
		request.setStrategicOfferEnabled(Boolean.TRUE);
		cartServiceHelperResponse = cxpHelper.bundleBuilderCart(request);
		StepVerifier.create(cartServiceHelperResponse).expectErrorMatches(throwable -> throwable instanceof NullPointerException).verify();
		request.setSelectedOfferId("597967");
		cartServiceHelperResponse = cxpHelper.bundleBuilderCart(request);
		StepVerifier.create(cartServiceHelperResponse).expectError(NullPointerException.class).verify();
	}

	@Test
	public void bundleBuilderPromoChoiceWithWinBackOfferTest() throws IOException {
		String responseString = "{\"data\":{\"cart\":{\"cartHeader\":{\"cartId\":\"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\"},\"lineDetails\":{\"lineSeq\":1,\"numOfLines\":1,\"numofLinesAAL\":1,\"numofLinesEUP\":0,\"allLines\":[\"AAL\",\"EUP\"],\"lineInfo\":[{\"lineActivityType\":\"EUP\",\"multiLineSeqNumber\":1,\"mobileNumber\":\"988888888\",\"itemsInfo\":[{\"cartItemType\":\"DEVICE\"}]}]}}}}";
		String redisDataString = "{\"data\":{\"cart\":{\"cartHeader\":{\"cartId\":\"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\"},\"lineDetails\":{\"lineSeq\":1,\"numOfLines\":1,\"numofLinesAAL\":1,\"numofLinesEUP\":0,\"allLines\":[\"AAL\",\"EUP\"],\"lineInfo\":[{\"lineActivityType\":\"EUP\",\"multiLineSeqNumber\":1,\"mobileNumber\":\"988888888\",\"itemsInfo\":[{\"cartItemType\":\"DEVICE\"}]}]}}}}";
		BundleBuilderRequest request = getBundleBuilderRequest();
		BundleBuilderCXPResponseData serviceResponse = mapper.readValue(responseString, BundleBuilderCXPResponseData.class);
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Map<String, Object> secondAppvedData = new HashMap<>();
		secondAppvedData.put(CartConstants.APPROVED_SECONDCAPTCHA_REDIS_KEY, Boolean.TRUE.toString());
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		Mockito.when(cxpService.bundleBuilderCart(any(String.class),any(String.class),anyBoolean(),any(String.class),
				anyBoolean(),any(String.class),any(String.class),anyList(),anyBoolean(),any(String.class),anyList())).thenReturn(Mono.just(serviceResponse));
		when(featureFlagHelper.isWinbackOfferFlagEnabled()).thenReturn(Mono.just(Boolean.TRUE));
		Mono<BundleBuilderCXPResponseData> cartServiceHelperResponse = cxpHelper.bundleBuilderCart(request);
		Assert.assertNotNull(cartServiceHelperResponse);
		request.setWinBackOfferSelected(Boolean.TRUE);
		cartServiceHelperResponse = cxpHelper.bundleBuilderCart(request);
		Assert.assertNotNull(cartServiceHelperResponse);
		request.setSelectedOfferId("597967");
		cartServiceHelperResponse = cxpHelper.bundleBuilderCart(request);
		Assert.assertNotNull(cartServiceHelperResponse);
		request.setWinBackOfferSelected(Boolean.FALSE);
		cartServiceHelperResponse = cxpHelper.bundleBuilderCart(request);
		Assert.assertNotNull(cartServiceHelperResponse);
		request.setStrategicOfferEnabled(Boolean.TRUE);
		cartServiceHelperResponse = cxpHelper.bundleBuilderCart(request);
		Assert.assertNotNull(cartServiceHelperResponse);
		request.setSelectedOfferId("NOPROMO");
		cartServiceHelperResponse = cxpHelper.bundleBuilderCart(request);
		Assert.assertNotNull(cartServiceHelperResponse);
		request.setPromoChoiceOffer(false);
		cartServiceHelperResponse = cxpHelper.bundleBuilderCart(request);
		Assert.assertNotNull(cartServiceHelperResponse);
		when(featureFlagHelper.isWinbackOfferFlagEnabled()).thenReturn(Mono.just(Boolean.FALSE));
		cartServiceHelperResponse = cxpHelper.bundleBuilderCart(request);
		Assert.assertNotNull(cartServiceHelperResponse);
	}
	@Test
	public void maskingForBYODTest() throws IOException {
		String responseString = sourceFileReaderUtil.readFile("/data/cartServiceHelperTest/RetrieveCartUIResponseMasking.json", testFileLocation);
		RetrieveCartUIResponse response = mapper.readValue(responseString, RetrieveCartUIResponse.class);
		when(featureFlagHelper.isMaskingForBYODFFlag()).thenReturn(Boolean.TRUE);
		final HttpHeaders headers = new HttpHeaders();
		headers.set("channelId", "VZW-DOTCOM");
		RequestAccessContext.updateRequestData(new RequestAccessContext.RequestAccess(new LinkedMultiValueMap<>(), headers));

		cxpHelper.performMaskingForBYOD(response.getData().getCart());
		Assert.assertEquals("7383",response.getData().getCart().getLineDetails().getLineInfo()[0].getItemsInfo()[0].getCartItems().getCartItem()[0].getDeviceId());

		Assert.assertEquals("1234",response.getData().getCart().getLineDetails().getLineInfo()[0].getItemsInfo()[0].getCartItems().getCartItem()[1].getESIM());

		response.getData().getCart().getLineDetails().getLineInfo()[0].getItemsInfo()[0].getCartItems().getCartItem()[0].setDeviceId(null);
		cxpHelper.performMaskingForBYOD(response.getData().getCart());

		response.getData().getCart().getLineDetails().getLineInfo()[0].getItemsInfo()[0].getCartItems().getCartItem()[0].setESIM(null);
		cxpHelper.performMaskingForBYOD(response.getData().getCart());

		response.getData().getCart().getLineDetails().getLineInfo()[0].getItemsInfo()[0].getCartItems().getCartItem()[0]=null;
		cxpHelper.performMaskingForBYOD(response.getData().getCart());

		response.getData().getCart().getLineDetails().getLineInfo()[0].getItemsInfo()[0].getCartItems().setCartItem(null);
		cxpHelper.performMaskingForBYOD(response.getData().getCart());

		response.getData().getCart().getLineDetails().getLineInfo()[0].getItemsInfo()[0].setCartItems(null);
		cxpHelper.performMaskingForBYOD(response.getData().getCart());

		response.getData().getCart().getLineDetails().getLineInfo()[0].getItemsInfo()[0]=null;
		cxpHelper.performMaskingForBYOD(response.getData().getCart());

		response.getData().getCart().getLineDetails().getLineInfo()[0].setItemsInfo(null);
		cxpHelper.performMaskingForBYOD(response.getData().getCart());

		response.getData().getCart().getLineDetails().getLineInfo()[0]=null;
		cxpHelper.performMaskingForBYOD(response.getData().getCart());

		response.getData().getCart().getLineDetails().setLineInfo(null);
		cxpHelper.performMaskingForBYOD(response.getData().getCart());

		response.getData().getCart().setLineDetails(null);
		cxpHelper.performMaskingForBYOD(response.getData().getCart());
	}
}
