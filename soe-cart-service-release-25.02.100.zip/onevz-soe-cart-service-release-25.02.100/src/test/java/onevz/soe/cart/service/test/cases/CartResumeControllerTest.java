package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import onevz.soe.cart.controller.CartRedisController;
import onevz.soe.cart.controller.CartResumeController;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.helper.ResumeCartHelper;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.common.CartErrorDetail;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.ClearAndContinueUIRequest;
import onevz.soe.cart.ui.responses.ClearAndContinueUIResponse;
import onevz.soe.cart.util.CartAddDeviceUtil;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.runner.RunWith;
import org.mockito.Mockito;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(CartResumeController.class)
public class CartResumeControllerTest {

    @Autowired
    private CartResumeController controller;

    @Autowired
    private ObjectMapper mapper;

    @MockBean
    private ResumeCartHelper helper;

    @MockBean
    private RedisHelper redisHelper;
    private ServerHttpResponse mockHttpResponse;

    @Before
    public void setup ()
    {
        MockitoAnnotations.openMocks(this);
        mockHttpResponse = mock(ServerHttpResponse.class);
    }

    @Test
    public void clearAndResumeDeviceTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"mtnFlow\":\"m\",\"locationCode\":\"E319201\"}}";
        ClearAndContinueUIRequest request = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.06.09.14.32.25-934.3264619816214\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-7637447-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"TradeInHomePage\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"0488670394-00001\",\"cartCreator\":\"3194708865\",\"processingMTN\":\"\",\"registerNumber\":0,\"existingCase\":\"false\"},\"cartInfo\":{\"mtnFlow\":\"\",\"cartItemCount\":0,\"cartId\":\"eb199149-125b-4744-90d3-f3300474d8ed\",\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}\t";
        ClearAndContinueUIResponse response = mapper.readValue(responseString, ClearAndContinueUIResponse.class);
        URI url = URI.create("http://localhost");
        HttpHeaders headers = new HttpHeaders();
        headers.add("channelId", "VZW-DOTCOM");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        when(redisHelper.getDataFromRedisAsString()).thenReturn(populateRedisData());
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("device"));
        when(helper.clearAndResume(request)).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(controller,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = controller.clearAndResume(httpHeader, mockHttpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void clearAndResumeAccessoryTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"mtnFlow\":\"g\",\"locationCode\":\"E319201\"}}";
        ClearAndContinueUIRequest request = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.06.09.14.32.25-934.3264619816214\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-7637447-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"TradeInHomePage\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"0488670394-00001\",\"cartCreator\":\"3194708865\",\"processingMTN\":\"\",\"registerNumber\":0,\"existingCase\":\"false\"},\"cartInfo\":{\"mtnFlow\":\"G\",\"cartItemCount\":0,\"cartId\":\"eb199149-125b-4744-90d3-f3300474d8ed\",\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}\t";
        ClearAndContinueUIResponse response = mapper.readValue(responseString, ClearAndContinueUIResponse.class);
        URI url = URI.create("http://localhost");
        HttpHeaders headers = new HttpHeaders();
        headers.add("channelId", "VZW-DOTCOM");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        when(redisHelper.getDataFromRedisAsString()).thenReturn(populateRedisData());
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("accessory"));
        when(helper.clearAndResume(request)).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(controller,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = controller.clearAndResume(httpHeader, mockHttpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void clearAndResumeWithoutMTNFlowTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"mtnFlow\":\"m\",\"locationCode\":\"E319201\"}}";
        ClearAndContinueUIRequest request = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.06.09.14.32.25-934.3264619816214\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-7637447-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"TradeInHomePage\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"0488670394-00001\",\"cartCreator\":\"3194708865\",\"processingMTN\":\"\",\"registerNumber\":0,\"existingCase\":\"false\"},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"eb199149-125b-4744-90d3-f3300474d8ed\",\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}\t";
        ClearAndContinueUIResponse response = mapper.readValue(responseString, ClearAndContinueUIResponse.class);
        URI url = URI.create("http://localhost");
        HttpHeaders headers = new HttpHeaders();
        headers.add("channelId", "VZW-DOTCOM");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        when(redisHelper.getDataFromRedisAsString()).thenReturn(populateRedisData());
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("accessory"));
        when(helper.clearAndResume(request)).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(controller,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = controller.clearAndResume(httpHeader, mockHttpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void clearAndResumeActionTypeErrorTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"mtnFlow\":\"m\",\"locationCode\":\"E319201\"}}";
        ClearAndContinueUIRequest request = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.06.09.14.32.25-934.3264619816214\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-7637447-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"TradeInHomePage\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"0488670394-00001\",\"cartCreator\":\"3194708865\",\"processingMTN\":\"\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"eb199149-125b-4744-90d3-f3300474d8ed\",\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false}}}}}\t";
        ClearAndContinueUIResponse response = mapper.readValue(responseString, ClearAndContinueUIResponse.class);
        URI url = URI.create("http://localhost");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        when(redisHelper.getDataFromRedisAsString()).thenReturn(populateRedisData());
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("test"));
        when(helper.clearAndResume(request)).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(controller,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = controller.clearAndResume(httpHeader, mockHttpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void clearAndResumeErrorTest() throws IOException {
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"mtnFlow\":\"m\",\"locationCode\":\"E319201\"}}";
        ClearAndContinueUIRequest request = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
        ClearAndContinueUIResponse response = new ClearAndContinueUIResponse();
        response.setErrors(getCartErrorList());
        URI url = URI.create("http://localhost");
        HttpHeaders headers = new HttpHeaders();
        headers.add("channelId", "VZW-DOTCOM");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        when(redisHelper.getDataFromRedisAsString()).thenReturn(populateRedisData());
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("device"));
        when(helper.clearAndResume(request)).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(controller,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = controller.clearAndResume(httpHeader, mockHttpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    private Mono<CartRedisData> populateRedisData() {
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");

        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);
        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        return Mono.just(cartRedisData);
    }

    private static List<CartError> getCartErrorList() {
        List<CartError> errorList = new ArrayList<>();
        List<CartErrorDetail> detailList = new ArrayList<>();
        CartError cartError = new CartError();
        CartErrorDetail detail = new CartErrorDetail();
        detail.setField("CartId");
        detail.setLocation("request");
        detail.setValue("null/blank");
        detail.setIssue("Cart id is missing");
        detailList.add(detail);
        cartError.setDetailList(detailList);
        errorList.add(cartError);
        return errorList;
    }
    
    @Test
    public void clearAndResumeTest() throws JsonMappingException, JsonProcessingException {
    	String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"mtnFlow\":\"m\",\"locationCode\":\"E319201\"}}";
        ClearAndContinueUIRequest request = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
        String responseString = "{}";
        ClearAndContinueUIResponse response = mapper.readValue(responseString, ClearAndContinueUIResponse.class);
        URI url = URI.create("http://localhost");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        when(helper.clearAndResume(request)).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(controller,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = controller.clearAndResume(httpHeader, mockHttpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }
    
    @Test
    public void clearAndResumeTest2() throws JsonMappingException, JsonProcessingException {
    	String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"mtnFlow\":\"m\",\"locationCode\":\"E319201\"}}";
        ClearAndContinueUIRequest request = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
        String responseString = "{\"serviceBody\": {}}";
        ClearAndContinueUIResponse response = mapper.readValue(responseString, ClearAndContinueUIResponse.class);
        URI url = URI.create("http://localhost");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        when(helper.clearAndResume(request)).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(controller,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = controller.clearAndResume(httpHeader, mockHttpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }
    
    @Test
    public void clearAndResumeTest3() throws JsonMappingException, JsonProcessingException {
    	String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"mtnFlow\":\"m\",\"locationCode\":\"E319201\"}}";
        ClearAndContinueUIRequest request = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
        String responseString = "{\"serviceBody\": {\"serviceResponse\": {}}}";
        ClearAndContinueUIResponse response = mapper.readValue(responseString, ClearAndContinueUIResponse.class);
        URI url = URI.create("http://localhost");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        when(helper.clearAndResume(request)).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(controller,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = controller.clearAndResume(httpHeader, mockHttpResponse, request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }
    
    @Test
    public void clearAndResumeTest4() throws JsonMappingException, JsonProcessingException {
    	String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"locationCode\":\"E319201\"}}";
        ClearAndContinueUIRequest request = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
        String responseString = "{\"serviceBody\": {\"serviceResponse\": {\"context\": {\"cartInfo\": {},\"customerInfo\": {}}}}}";
        ClearAndContinueUIResponse response = mapper.readValue(responseString, ClearAndContinueUIResponse.class);
        URI url = URI.create("http://localhost");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just(""));
        when(helper.clearAndResume(request)).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(controller,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = controller.clearAndResume(httpHeader, mockHttpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp-> Assert.assertEquals(HttpStatus.OK, resp.getStatusCode())).expectComplete().verify();
    }
    
    @Test
    public void clearAndResumeTest5() throws JsonMappingException, JsonProcessingException {
    	String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"locationCode\":\"E319201\"}}";
        ClearAndContinueUIRequest request = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
        String responseString = "{\"serviceBody\": {\"serviceResponse\": {\"context\": {\"cartInfo\": {},\"customerInfo\": {}}}}}";
        ClearAndContinueUIResponse response = mapper.readValue(responseString, ClearAndContinueUIResponse.class);
        String dataString = "{}";
        CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
        URI url = URI.create("http://localhost");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(data));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("device"));
        when(helper.clearAndResume(request)).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(controller,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = controller.clearAndResume(httpHeader, mockHttpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp-> Assert.assertEquals(HttpStatus.BAD_REQUEST, resp.getStatusCode())).expectComplete().verify();
    }
    
    @Test
    public void clearAndResumeTest6() throws JsonMappingException, JsonProcessingException {
    	String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"locationCode\":\"E319201\"}}";
        ClearAndContinueUIRequest request = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
        String responseString = "{\"serviceBody\": {\"serviceResponse\": {\"context\": {\"cartInfo\": {},\"customerInfo\": {}}}}}";
        ClearAndContinueUIResponse response = mapper.readValue(responseString, ClearAndContinueUIResponse.class);
        String dataString = "{\"deviceCartInfo\": {}}";
        CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
        URI url = URI.create("http://localhost");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(data));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("device"));
        when(helper.clearAndResume(request)).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(controller,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = controller.clearAndResume(httpHeader, mockHttpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp-> Assert.assertEquals(HttpStatus.OK, resp.getStatusCode())).expectComplete().verify();
    }
    
    @Test
    public void clearAndResumeTest7() throws JsonMappingException, JsonProcessingException {
    	String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-NETACE\",\"locationCode\":\"E319201\"}}";
        ClearAndContinueUIRequest request = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
        String responseString = "{\"serviceBody\": {\"serviceResponse\": {\"context\": {\"cartInfo\": {},\"customerInfo\": {}}}}}";
        ClearAndContinueUIResponse response = mapper.readValue(responseString, ClearAndContinueUIResponse.class);
        String dataString = "{\"accessoryCartInfo\": {}}";
        CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
        URI url = URI.create("http://localhost");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        when(redisHelper.getAccessoryDataFromRedisAsString()).thenReturn(Mono.just(data));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("accessory"));
        when(helper.clearAndResume(request)).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(controller,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = controller.clearAndResume(httpHeader, mockHttpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp-> Assert.assertEquals(HttpStatus.OK, resp.getStatusCode())).expectComplete().verify();
    }
}
