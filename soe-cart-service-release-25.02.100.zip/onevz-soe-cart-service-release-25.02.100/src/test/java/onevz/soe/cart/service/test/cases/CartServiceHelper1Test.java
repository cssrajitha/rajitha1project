package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper2;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper3;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper2;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.common.CartServiceCartInfo;
import onevz.soe.cart.model.common.ConflictedSPOs;
import onevz.soe.cart.model.initiateDeviceSimActivation.InitiateDeviceSimActivationUIResponse;
import onevz.soe.cart.model.initiateDeviceSimActivation.IntiateDeviceSimActivationUIRequest;
import onevz.soe.cart.model.initiateESimActivation.InitiateESimActivationUIResponse;
import onevz.soe.cart.model.initiateESimActivation.IntiateESimActivationUIRequest;
import onevz.soe.cart.model.initiateValidateDeviceSim.InitiateValidateDeviceSimUIResponse;
import onevz.soe.cart.model.validateCart.CartValidationError;
import onevz.soe.cart.nbx.NBXFeedbackService;
import onevz.soe.cart.requests.ClearCartPEGARequest;
import onevz.soe.cart.requests.IndirectExCustRemoveLinePEGARes;
import onevz.soe.cart.requests.ValidateBYODToolCXPRequest;
import onevz.soe.cart.requests.ValidateOffersRequest;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.cart.util.CartPegaRequestUtil7;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.exception.SOEException;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.net.URI;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


import static org.mockito.Mockito.when;
import static reactor.test.StepVerifier.create;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(UpdateCartHelper.class)
public class CartServiceHelper1Test {

    @Autowired
    private UpdateCartHelper helper;
    @Autowired
    private UpdateCartHelper1 helper1;

    @MockBean
    private CartServiceCxpHelper cxpHelper;

    @MockBean
    private CartServiceCxpHelper2 cxpHelper2;

    @MockBean
    private CartServiceBpmHelper2 bpmHelper2;

    @MockBean
    private CartServiceBpmHelper3 bpmHelper3;

    @MockBean
    private CartServiceBpmHelper bpmHelper4;

    @MockBean
    private CartAccessoryHelper cartAccessoryHelper;

    @MockBean
    private RedisHelper redisHelper;

    @MockBean
    private RedisHelper2 redisHelper2;

    @MockBean
    private RedisHelper3 redisHelper3;

    @Autowired
    private ObjectMapper mapper;

    @MockBean
    private NBXFeedbackService nbxService;

    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;

    @MockBean
    CartPegaRequestUtil7 cartPegaRequest;

    @MockBean
    SOELoginSessionBean sessionBean;
    @MockBean
    FeatureFlagHelper featureFlagHelper;

    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;

    @Test
    public void splitExceededAmountHelperTest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/SplitExceededAmountUIRequest.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/SplitExceededAmountUIResponse.json", testFileLocation);
        SplitExceededAmountUIRequest sampleUIRequest = null;
        SplitExceededAmountUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, SplitExceededAmountUIRequest.class);
        sampleResponse = mapper.readValue(sampleUIResponseString, SplitExceededAmountUIResponse.class);
        when(bpmHelper3.splitExceededAmount(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        SplitExceededAmountUIResponse expectedResponse = sampleResponse;
        Mono<SplitExceededAmountUIResponse> response = helper.splitExceededAmount(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateSalesRepAndLocationHelperTest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/SalesRepAndLocationCodeUIRequest.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/SalesRepAndLocationCodeUIResponse.json", testFileLocation);
        SalesRepAndLocationCodeUIRequest sampleUIRequest = null;
        SalesRepAndLocationCodeUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, SalesRepAndLocationCodeUIRequest.class);
        sampleResponse = mapper.readValue(sampleUIResponseString, SalesRepAndLocationCodeUIResponse.class);
        when(bpmHelper3.updateSalesRepAndLocationCode(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        SalesRepAndLocationCodeUIResponse expectedResponse = sampleResponse;
        Mono<SalesRepAndLocationCodeUIResponse> response = helper.updateSalesRepAndLocationCode(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void validateCartAndCheckoutHelperTest() throws IOException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse2.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse2.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        ValidateCartUIResponse sampleValidateResponse = null;
        InitiateCheckoutUIResponse sampleResponse = null;
        InitiateCheckoutUIRequest sampleUIRequest = null;
        sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        sampleUIRequest = mapper.readValue(sampleRequestString, InitiateCheckoutUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(bpmHelper2.validateOrder(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        Mono<InitiateCheckoutUIResponse> response = helper.validateCartAndCheckout(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();


    }

    @Test
    public void validateCartAndCheckoutErrosHelperTest() throws IOException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest2.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse3.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse3.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        ValidateCartUIResponse sampleValidateResponse = null;
        InitiateCheckoutUIResponse sampleResponse = null;
        InitiateCheckoutUIRequest sampleUIRequest = null;
        sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        sampleUIRequest = mapper.readValue(sampleRequestString, InitiateCheckoutUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        List<CartValidationError> validationResponse =expectedResponse.getCartValidationErrors();
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(bpmHelper2.validateOrder(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(featureFlagHelper.earlyUpgradeBlockerFeatureFlag()).thenReturn(Mono.just(false));
        Mono<InitiateCheckoutUIResponse> response = helper.validateCartAndCheckout(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getCartValidationErrors())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(validationResponse, resp.getCartValidationErrors())).expectComplete()
                .verify();


    }

    @Test
    public void validateCartAndCheckoutBOGOErrosHelperTest() throws IOException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest3.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse5.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse5.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        ValidateCartUIResponse sampleValidateResponse = null;
        InitiateCheckoutUIResponse sampleResponse = null;
        InitiateCheckoutUIRequest sampleUIRequest = null;
        sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        sampleUIRequest = mapper.readValue(sampleRequestString, InitiateCheckoutUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        List<CartValidationError> validationResponse =expectedResponse.getCartValidationErrors();
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(bpmHelper2.validateOrder(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(featureFlagHelper.earlyUpgradeBlockerFeatureFlag()).thenReturn(Mono.just(false));
        Mono<InitiateCheckoutUIResponse> response = helper.validateCartAndCheckout(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getCartValidationErrors())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(validationResponse, resp.getCartValidationErrors())).expectComplete()
                .verify();
    }

    @Test
    public void validateCartAndCheckoutBOGOEmptyErrosHelperTest() throws IOException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIRequest3.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateCheckoutUIResponse4.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse4.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        ValidateCartUIResponse sampleValidateResponse = null;
        InitiateCheckoutUIResponse sampleResponse = null;
        InitiateCheckoutUIRequest sampleUIRequest = null;
        sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        sampleUIRequest = mapper.readValue(sampleRequestString, InitiateCheckoutUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, InitiateCheckoutUIResponse.class);
        InitiateCheckoutUIResponse expectedResponse = sampleResponse;
        List<CartValidationError> validationResponse =expectedResponse.getCartValidationErrors();
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(bpmHelper2.validateOrder(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(featureFlagHelper.earlyUpgradeBlockerFeatureFlag()).thenReturn(Mono.just(false));
        Mono<InitiateCheckoutUIResponse> response = helper.validateCartAndCheckout(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getCartValidationErrors())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(validationResponse, resp.getCartValidationErrors())).expectComplete()
                .verify();
    }
    @Test
    public void nbxFeedbackHelperTest() throws IOException {
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);

        String nbxString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackResponse.json", testFileLocation);
        String nbxRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackUIRequest.json", testFileLocation);;
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        NBXFeedbackUIRequest nbxReq = mapper.readValue(nbxRequestString, NBXFeedbackUIRequest.class);
        String bvpStr = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BVPRedisData1.json", testFileLocation);

        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        Mono<NBXFeedbackResponse> response = helper.nbxFeedbackCall(nbxReq);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();

    }


    @Test
    public void addTransferUpgradeHelperTest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateTransferUpgradeUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        UpdateTransferUpgradeUIRequest sampleUIRequest = null;
        UpdateTransferUpgradeUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateTransferUpgradeUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, UpdateTransferUpgradeUIResponse.class);
        when(bpmHelper3.addTransferUpgrade(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateTransferUpgradeUIResponse expectedResponse = sampleResponse;
        Mono<UpdateTransferUpgradeUIResponse> response = helper.addTransferUpgrade(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void addNickNameTest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddNickNameUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        AddNickNameUIRequest  sampleUIRequest = null;
        AddNickNameUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCreditAppNum("1234567890");
        sampleUIRequest = mapper.readValue(sampleUIRequestString, AddNickNameUIRequest.class);
        sampleUIRequest.setChannelId("VZW-ACSS");
        sampleResponse = mapper.readValue(sampleResponseString, AddNickNameUIResponse.class);
        when(bpmHelper3.addNickName(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<AddNickNameUIResponse> response = helper.addNickName(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
    }

    @Test
    public void customerByMtnListTest() throws IOException {
        when(cxpHelper2.customerByMtnList(Mockito.any())).thenReturn(Mono.just(new CustomerByMtnListUIResponse()));
        Mono<CustomerByMtnListUIResponse> response = helper.customerByMtnList(new CustomerByMtnListUIRequest());
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void validateBYODToolTool() throws IOException {
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(cxpHelper.validateBYODTool(Mockito.any())).thenReturn(Mono.just(new ValidateBYODToolUIResponse()));
        Mono<ValidateBYODToolUIResponse> response = helper.validateBYODTool(new ValidateBYODToolCXPRequest());
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void removeTransferUpgradeHelperTest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateTransferUpgradeUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        UpdateTransferUpgradeUIRequest sampleUIRequest = null;
        UpdateTransferUpgradeUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateTransferUpgradeUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, UpdateTransferUpgradeUIResponse.class);
        when(bpmHelper3.removeTransferUpgrade(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateTransferUpgradeUIResponse expectedResponse = sampleResponse;
        Mono<UpdateTransferUpgradeUIResponse> response = helper.removeTransferUpgrade(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void removeEdgeupTest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEdgeupUIRequest2.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEdgeupUIResponse2.json", testFileLocation);
        UpdateEdgeupUIRequest  sampleUIRequest = null;
        UpdateEdgeupUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateEdgeupUIRequest .class);
        sampleResponse = mapper.readValue(sampleResponseString, UpdateEdgeupUIResponse.class);
        when(bpmHelper2.removeEdgeUp(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateEdgeupUIResponse expectedResponse = sampleResponse;
        Mono<UpdateEdgeupUIResponse> response = helper.removeEdgeup(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void emailCartToCustomerTest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/EmailCartToCustomerUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/EmailCartToCustomerUIResponse.json", testFileLocation);
        EmailCartToCustomerUIRequest sampleUIRequest = null;
        EmailCartToCustomerUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, EmailCartToCustomerUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, EmailCartToCustomerUIResponse.class);
        when(bpmHelper3.emailCartToCustomer(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        EmailCartToCustomerUIResponse expectedResponse = sampleResponse;
        Mono<EmailCartToCustomerUIResponse> response = helper.emailCartToCustomer(sampleUIRequest);

        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateVZCCAppStatusTest() throws IOException {
        String requestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/VZCCAppStatusUIRequest.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/VZCCAppStatusUIResponse.json", testFileLocation);
        VZCCAppStatusUIRequest sampleUIRequest = null;
        VZCCAppStatusUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData11.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setIntendType("NSE");
        sampleUIRequest = mapper.readValue(requestString, VZCCAppStatusUIRequest.class);
        sampleResponse = mapper.readValue(responseString, VZCCAppStatusUIResponse.class);
        when(cxpHelper2.updateVZCCAppStatus(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        VZCCAppStatusUIResponse expectedResponse = sampleResponse;
        Mono<VZCCAppStatusUIResponse> response = helper.updateVZCCAppStatus(sampleUIRequest);

        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void getRequestDetailsTest() throws IOException, SOEHTTPException {
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData12.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, "http://localhost").cookie(new HttpCookie("RepIdCookieText","E170K")).header("Accept", "application").build();
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<AddDeviceUIRequest> response = helper.getRequestDetails("EUP", "SMSNG", "99",
                Optional.of(36), Optional.of("true"), Optional.of("30329"),
                Optional.of("L"), Optional.of("30329"), Optional.of("03/08/2020"),
                Optional.of("home"), Optional.of("true"), Optional.of("BOGOHO"),
                Optional.of("true"), Optional.of("true"), Optional.of("true"),Optional.of("Smartphones"),
                Optional.of("Smartphones"),"","","",Optional.of("true"),Optional.of("true"),
                Optional.of("true"),Optional.of("55571"),Optional.of(true),Optional.of("Y"),Optional.of(true),Optional.of(true),Optional.of(true),Optional.of("true"),Optional.of(true),Optional.of("55571"),Optional.of("55571"),httpHeader,Optional.of(true),Optional.of("36"));
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void getRequestDetailsTest2() throws IOException, SOEHTTPException {
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData13.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, "http://localhost").cookie(new HttpCookie("RepIdCookieText","E170K")).header("Accept", "application").build();
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<AddDeviceUIRequest> response = helper.getRequestDetails("AAL", "SMSNG", "0",
                Optional.of(36), Optional.of("true"), Optional.of("30329"),
                Optional.of("L"), Optional.of("30329"), Optional.of("03/08/2020"),
                Optional.of("home"), Optional.of("true"), Optional.of("BOGOHO"),
                Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of("true"),"","","",Optional.of("true"),Optional.of("true"),Optional.of("true"),Optional.of("55571"),Optional.of(true),Optional.of("Y"),Optional.of(true),Optional.of(false),Optional.of(true),Optional.of("false"),Optional.of(true),Optional.of("55571"),Optional.of("55571"),httpHeader,Optional.of(true),Optional.of("36"));
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        Mono<AddDeviceUIRequest> response2 = helper.getRequestDetails("EUP", "SMSNG", "1",
                Optional.of(36), Optional.of("true"), Optional.of("30329"),
                Optional.of("L"), Optional.of("30329"), Optional.of("03/08/2020"),
                Optional.of("home"), Optional.of("true"), Optional.of("BOGOHO"),
                Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of("true"),"","","",Optional.of("true"),Optional.of("true"),Optional.of("true"),Optional.of("55571"),Optional.of(false),Optional.of("Y"),Optional.of(false),Optional.of(true),Optional.of(true),Optional.of("false"),Optional.of(true),Optional.of("55571"),Optional.of("55571"),httpHeader,Optional.of(true),Optional.of("36"));
        StepVerifier.create(response2).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void getRequestDetailsTest6() throws IOException, SOEHTTPException {
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData13.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, "http://localhost").cookie(new HttpCookie("RepIdCookieText","E170K")).header("Accept", "application").build();
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<AddDeviceUIRequest> response = helper.getRequestDetails("AAL", "SMSNG", "0",
                Optional.of(36), Optional.of("true"), Optional.of("30329"),
                Optional.of("L"), Optional.of("30329"), Optional.of("03/08/2020"),
                Optional.of("home"), Optional.of("true"), Optional.of("BOGOHO"),
                Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of("true"),"","","",Optional.of("true"),Optional.of("true"),Optional.of("true"),Optional.of("55571"),Optional.of(true),Optional.of("Y"),Optional.of(true),Optional.of(false),Optional.of(true),Optional.of("false"),Optional.of(true),Optional.of("55571"),Optional.of("55571"),httpHeader,Optional.empty(),Optional.empty());
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        Mono<AddDeviceUIRequest> response2 = helper.getRequestDetails("EUP", "SMSNG", "1",
                Optional.of(36), Optional.of("true"), Optional.of("30329"),
                Optional.of("L"), Optional.of("30329"), Optional.of("03/08/2020"),
                Optional.of("home"), Optional.of("true"), Optional.of("BOGOHO"),
                Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of("true"), Optional.of("true"),"","","",Optional.of("true"),Optional.of("true"),Optional.of("true"),Optional.of("55571"),Optional.of(false),Optional.of("Y"),Optional.of(false),Optional.of(true),Optional.of(true),Optional.of("false"),Optional.of(true),Optional.of("55571"),Optional.of("55571"),httpHeader,Optional.empty(),Optional.empty());
        StepVerifier.create(response2).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void clearAndContinueTest() throws IOException, SOEHTTPException {
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData12.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        String requestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ClearAndContinueUIRequest.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ClearAndContinueUIResponse.json", testFileLocation);
        ClearAndContinueUIRequest request = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
        ClearAndContinueUIResponse response = mapper.readValue(responseString, ClearAndContinueUIResponse.class);
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(redisHelper.deleteCartIdAndCaseIdAndExistingCaseFromRedis()).thenReturn(Mono.just(1L));
        when(bpmHelper3.clearAndContinue(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ClearAndContinueUIResponse> cncResp = helper.clearAndContinue(request);
        StepVerifier.create(cncResp).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ClearAndContinueUIResponse1.json", testFileLocation);
        response = mapper.readValue(responseString, ClearAndContinueUIResponse.class);
        when(bpmHelper3.clearAndContinue(Mockito.any())).thenReturn(Mono.just(response));
        cncResp = helper.clearAndContinue(request);
        StepVerifier.create(cncResp).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void validateOffersTest() throws IOException, SOEHTTPException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateOffersRequest.json", testFileLocation);
        String sampleUIresponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateOffersResponse.json", testFileLocation);
        ValidateOffersRequest sampleRequest = mapper.readValue(sampleUIRequestString, ValidateOffersRequest.class);
        ValidateOffersResponse sampleResponse = mapper.readValue(sampleUIresponseString, ValidateOffersResponse.class);
        when(cxpHelper2.validateOffers(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper2.getCartIdFromRedis()).thenReturn(Mono.just("6fbae26d-666e-4dec-8af5-692faccc2bdb"));
        ValidateOffersResponse expectedResponse = sampleResponse;
        Mono<ValidateOffersResponse> cncResp = helper.validateOffers(sampleRequest);
        StepVerifier.create(cncResp).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
        StepVerifier.create(cncResp).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();

    }

    @Test
    public void activateOrSetupLaterTest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateTransferUpgradeUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        ActivateLaterUIRequest  sampleUIRequest = null;
        ActivateLaterUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, ActivateLaterUIRequest .class);
        sampleResponse = mapper.readValue(sampleResponseString, ActivateLaterUIResponse.class);
        when(bpmHelper3.activateOrSetupLater(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        ActivateLaterUIResponse expectedResponse = sampleResponse;
        Mono<ActivateLaterUIResponse> response = helper.activateOrSetupLater(sampleUIRequest);

        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateChatIdTest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateChatIdUIRequest.json", testFileLocation);
        String sampleUIRequestnotnseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateChatIdUIRequest1.json", testFileLocation);

        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateChatIdUIResponse.json", testFileLocation);
        UpdateChatIdUIRequest sampleUIRequest = null;
        UpdateChatIdUIRequest sampleUIRequest1 = null;

        UpdateChatIdUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCreditAppNum("123456");
        sampleRedisData.setAccountNumber("12345678");
        sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateChatIdUIRequest.class);
        sampleUIRequest1 = mapper.readValue(sampleUIRequestnotnseString, UpdateChatIdUIRequest.class);

        sampleResponse = mapper.readValue(sampleResponseString, UpdateChatIdUIResponse.class);
        when(bpmHelper3.updateChatId(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<UpdateChatIdUIResponse> response = helper.updateChatId(sampleUIRequest);
        Mono<UpdateChatIdUIResponse> response1 = helper.updateChatId(sampleUIRequest1);
        StepVerifier.create(response1).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
    }


    @Test
    public void clearCartHelperTest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddNickNameUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCreditAppNum("1234567");
        ClearCartUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, ClearCartUIRequest.class);
        sampleUIRequest.setChannelId("VZW-ACSS");
        ClearCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, ClearCartUIResponse.class);
        when(bpmHelper3.clearCart(Mockito.any(),Mockito.any())).thenReturn((Mono<ClearCartUIResponse>) Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        ClearCartUIResponse expectedResponse = sampleResponse;
        Mono<ClearCartUIResponse> response = helper.clearCart(sampleUIRequest);
        final Duration verify = StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        final Duration verify1 = StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateWFMInfoHelperTest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateTransferUpgradeUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        String RequestString = "{}";
        UpdateWFMInfoUIRequest request = mapper.readValue(RequestString, UpdateWFMInfoUIRequest.class);

        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);

        UpdateWFMInfoUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateWFMInfoUIRequest.class);
        UpdateWFMInfoUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateWFMInfoUIResponse.class);

        when(bpmHelper3.updateWFMInfo(Mockito.any())).thenReturn((Mono<UpdateWFMInfoUIResponse>) Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper3.updateWFMFlowDataInRedis(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));

        UpdateWFMInfoUIResponse expectedResponse = sampleResponse;
        Mono<UpdateWFMInfoUIResponse> response = helper.updateWFMInfo(sampleUIRequest);
        final Duration verify = StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        final Duration verify1 = StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();

        Mono<UpdateWFMInfoUIResponse> response1 = helper.updateWFMInfo(request);
        final Duration verify2 = StepVerifier.create(response1).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();

        when(redisHelper.getDataFromRedis()).thenThrow(new RuntimeException());
        Mono<UpdateWFMInfoUIResponse> response2 = helper.updateWFMInfo(sampleUIRequest);
        StepVerifier.create(response2).expectError();

    }

    @Test
    public void removeBvoOffersHelperTest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBvoOffersUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIResponseNew.json", testFileLocation);
        UpdateBvoOffersUIRequest sampleUIRequest = null;
        UpdateBvoOffersUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateBvoOffersUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, UpdateBvoOffersUIResponse.class);
        when(bpmHelper3.removeBvoOffers(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(new BVPRedisData()));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just(new String()));
        when(redisHelper2.deleteRemoveOfferDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        when(redisHelper2.getRemoveOfferDataIntoRedis()).thenReturn(Mono.just(new RemoveOfferRedisData()));
        UpdateBvoOffersUIResponse expectedResponse = sampleResponse;
        Mono<UpdateBvoOffersUIResponse> response = helper.removeBvoOffers(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void initiateBBPFlowHelperTest() throws IOException {
        CartRedisData data = new CartRedisData();
        DeviceSimDetailsUIResponse deviceSimDetailsUIResponse = new DeviceSimDetailsUIResponse();
        when(cxpHelper2.initiateBBPFlow(Mockito.any())).thenReturn(Mono.just(deviceSimDetailsUIResponse));
        Mono<DeviceSimDetailsUIResponse> response = helper.initiateBBPFlow(data);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void bbpGetProcessStepHelperTest() throws IOException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BBPGetProcessStepUIRequest1.json", testFileLocation);
        BBPGetProcessStepUIRequest bbpgetprocessstepUiRequest = mapper.readValue(sampleRequestString, BBPGetProcessStepUIRequest.class);

        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BbpGetProcessStepUIResponse.json", testFileLocation);
        BbpGetProcessStepUIResponse bbpgetprocessstepUiResponse = mapper.readValue(sampleResponseString, BbpGetProcessStepUIResponse.class);
        when(bpmHelper4.bbpGetProcessStep(Mockito.any())).thenReturn(Mono.just(bbpgetprocessstepUiResponse));
        Mono<BbpGetProcessStepUIResponse> response = helper.bbpGetProcessStep(bbpgetprocessstepUiRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();

    }

    @Test
    public void salesOrderAdjustmentTest() throws IOException {

        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/SalesOrderAdjustmentUIRequest.json", testFileLocation);
        SalesOrderAdjustmentUIRequest salesOrderAdjustmentUiRequest = mapper.readValue(sampleRequestString,
                SalesOrderAdjustmentUIRequest.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/SalesOrderAdjustmentUIResponse.json", testFileLocation);
        SalesOrderAdjustmentUIResponse salesOrderAdjustmentUiResponse = mapper.readValue(sampleResponseString,
                SalesOrderAdjustmentUIResponse.class);
        when(bpmHelper3.salesOrderAdjustment(Mockito.any())).thenReturn(Mono.just(salesOrderAdjustmentUiResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<SalesOrderAdjustmentUIResponse> response = helper.salesOrderAdjustment( salesOrderAdjustmentUiRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addManualDiscountHelperTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateManualDiscountUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateManualDiscountUIResponse.json", testFileLocation);
        UpdateManualDiscountUIRequest sampleRequest = null;
        UpdateManualDiscountUIResponse sampleUIResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCreditAppNum("1234567890");
        sampleRequest = mapper.readValue(sampleRequestString, UpdateManualDiscountUIRequest.class);
        sampleRequest.setChannelId("OMNI-RETAIL");
        sampleUIResponse = mapper.readValue(sampleResponseString, UpdateManualDiscountUIResponse.class);
        Mono<UpdateManualDiscountUIResponse> sampleResponseMono = Mono.just(sampleUIResponse);
        when(bpmHelper4.addManualdiscount(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateManualDiscountUIResponse expectedResponse = sampleUIResponse;
        Mono<UpdateManualDiscountUIResponse> response = helper.addManualDiscount(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateEffectiveDateHelperTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEffectiveDateUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEffectiveDateUIResponse.json", testFileLocation);
        UpdateEffectiveDateUIRequest sampleRequest = null;
        UpdateEffectiveDateUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCreditAppNum("1234567890");
        sampleRedisData.setCartCreator("nse");
        sampleRedisData.setAccountNumber("1234567890");
        sampleRedisData.setMtn("123456789");
        sampleRedisData.setProcessingMTN("12345678");
        sampleRequest = mapper.readValue(sampleRequestString, UpdateEffectiveDateUIRequest.class);
        sampleRequest.setChannelId("VZW-ACSS");
        sampleResponse = mapper.readValue(sampleResponseString, UpdateEffectiveDateUIResponse.class);
        Mono<UpdateEffectiveDateUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper4.updateEffectiveDate(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateEffectiveDateUIResponse expectedResponse = sampleResponse;
        Mono<UpdateEffectiveDateUIResponse> response = helper.updateEffectiveDate(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void formatClearCartRequestTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ClearCartUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEffectiveDateUIResponse.json", testFileLocation);
        ClearCartPEGARequest pegaRequest = new ClearCartPEGARequest();
        ClearCartUIRequest request = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        request = mapper.readValue(sampleRequestString, ClearCartUIRequest.class);
        ClearCartPEGARequest response = cartPegaRequest.formatClearCartRequest(pegaRequest, request, false);
        Assert.assertNotNull(response);
    }

    @Test
    public void clearCartDigitalHelperHelperTest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ClearCartUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ClearCartUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData14.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        ClearCartUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, ClearCartUIRequest.class);
        sampleUIRequest.setChannelId("VZW-DOTCOM");
        ClearCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, ClearCartUIResponse.class);
        when(bpmHelper3.clearCart(Mockito.any(),Mockito.any())).thenReturn((Mono<ClearCartUIResponse>) Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        ClearCartUIResponse expectedResponse = sampleResponse;
        Mono<ClearCartUIResponse> response = helper.clearCart(sampleUIRequest);
        final Duration verify = StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        final Duration verify1 = StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void populateRedirectionErrorTest() {
        StepVerifier.create(helper.populateRedirectionError()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(helper.populateRedirectionError()).assertNext(resp -> Assert.assertNotNull(resp.getErrors())).expectComplete().verify();
        StepVerifier.create(helper.populateRedirectionError()).assertNext(resp -> Assert.assertEquals("CartId or Case Id is not present in redis",
                resp.getErrors().get(0).getMessage())).expectComplete().verify();
    }

    @Test
    public void returnResponseTest() {
        StepVerifier.create(helper.returnResponse()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(helper.returnResponse()).assertNext(resp -> Assert.assertNotNull(resp.getServiceHeader())).expectComplete().verify();
        StepVerifier.create(helper.returnResponse()).assertNext(resp -> Assert.assertNotNull("00", resp.getServiceHeader().getStatusCode())).expectComplete().verify();
    }
    @Test
    public void addBuyoutAndConsentHelperTest() throws IOException {

        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddBuyoutUIResponse1.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDeviceUIRequest.json", testFileLocation);
        String consentResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateConsentCxpResponse.json", testFileLocation);
        String buyoutAndConsentResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDeviceUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);

        UpdateConsentCxpResponse sampleConsentResponse = null;
        AddDeviceUIRequest sampleUIRequest = null;
        AddBuyoutUIResponse sampleResponse = null;
        AddDeviceUIResponse sampleDeviceResponse = null;

        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, AddDeviceUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, AddBuyoutUIResponse.class);
        sampleConsentResponse = mapper.readValue(consentResponseString, UpdateConsentCxpResponse.class);
        sampleDeviceResponse = mapper.readValue(buyoutAndConsentResponseString, AddDeviceUIResponse.class);

        when(bpmHelper2.addBuyout(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(cxpHelper.updateCustomerConsent(Mockito.any())).thenReturn(Mono.just(sampleConsentResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));

        AddDeviceUIResponse expectedResponse = sampleDeviceResponse;
        Mono<AddDeviceUIResponse> response = helper.addBuyoutAndConsent(sampleUIRequest);

        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse.getIsConsentUpdated(), resp.getIsConsentUpdated())).expectComplete()
                .verify();
    }

    @Test
    public void updateBarcodeHelperTestForAssisted() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIRequest3.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData15.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        UpdateBarcodeUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateBarcodeUIRequest.class);
        UpdateBarcodeUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateBarcodeUIResponse.class);
        Mono<UpdateBarcodeUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse1.json", testFileLocation);
        ValidateCartUIResponse sampleValidateResponse = null;
        sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(bpmHelper3.updateBarcode(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.upsertValueInRedis(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        UpdateBarcodeUIResponse expectedResponse = sampleResponse;
        Mono<UpdateBarcodeUIResponse> response = helper.updateBarcode(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }


    @Test
    public void exCustremoveLinesTest() throws IOException, SOEHTTPException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/IndirectExCustRemoveLinePEGARes.json", testFileLocation);
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ExCustIndirectRemoveLinesServiceUIRequest.json", testFileLocation);
        ExCustIndirectRemoveLinesServiceUIRequest sampleRequest = null;
        IndirectExCustRemoveLinePEGARes sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRequest = mapper.readValue(sampleRequestString, ExCustIndirectRemoveLinesServiceUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, IndirectExCustRemoveLinePEGARes.class);
        Mono<IndirectExCustRemoveLinePEGARes> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper4.indirectexremoveLines(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        IndirectExCustRemoveLinePEGARes expectedResponse = sampleResponse;
        Mono<IndirectExCustRemoveLinePEGARes> response = helper.exCustremoveLines(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateGiftItemTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateGiftItemUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateGiftItemUIResponse.json", testFileLocation);
        UpdateGiftItemUIRequest sampleRequest = null;
        UpdateGiftItemUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRequest = mapper.readValue(sampleRequestString, UpdateGiftItemUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, UpdateGiftItemUIResponse.class);
        Mono<UpdateGiftItemUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper4.updateGiftItem(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateGiftItemUIResponse expectedResponse = sampleResponse;
        Mono<UpdateGiftItemUIResponse> response = helper.updateGiftItem(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }



    @Test
    public void updateSellerPriceNewHelperTestForNSE() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIRequestNew1.json", testFileLocation);
        String sampleResponseString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIResponseNew.json", testFileLocation);
        UpdateSellerPriceUIRequestNew sampleRequest = null;
        UpdateSellerPriceUIResponseNew sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData16.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRequest = mapper.readValue(sampleRequestString, UpdateSellerPriceUIRequestNew.class);
        sampleResponse = mapper.readValue(sampleResponseString, UpdateSellerPriceUIResponseNew.class);
        Mono<UpdateSellerPriceUIResponseNew> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper3.updateSellerPrice(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateSellerPriceUIResponseNew expectedResponse = sampleResponse;
        Mono<UpdateSellerPriceUIResponseNew> response = helper.updateSellerPriceNew(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void customerProfileDigital() throws IOException{
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddPlanUIResponse.json", testFileLocation);
        CustomerProfileCXPResponse request = mapper.readValue(sampleRequestString, CustomerProfileCXPResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData10.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(cxpHelper2.customerProfileDigital(sampleRequestString)).thenReturn(Mono.just(request));
        Mono<CustomerProfileCXPResponse> accountNumber=helper.customerProfileDigital(sampleRequestString);
        StepVerifier.create(accountNumber).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void populateConflictedSPOsIfPresent() throws IOException{
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDeviceUIRequest2.json", testFileLocation);
        AddDeviceUIRequest UIRequest = new AddDeviceUIRequest();
        UIRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        String responseFile = "MockAddDeviceHelperTestResponse.json";
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddDeviceUIResponse pegaResponse = new AddDeviceUIResponse();
        pegaResponse = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        Mono<AddDeviceUIResponse> sampleResponseMono = Mono.just(pegaResponse);
        String redisFile = "MockAddDeviceHelperTestRedisData.json";
        String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<ResponseEntity<GenericResponse>> response=helper.populateConflictedSPOsIfPresent(UIRequest, pegaResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }
    @Test
    public void updateBarcodeHelperpromoTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIRequest4.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData17.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setZ1OfferCode(null);
        UpdateBarcodeUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateBarcodeUIRequest.class);
        UpdateBarcodeUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateBarcodeUIResponse.class);
        Mono<UpdateBarcodeUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse1.json", testFileLocation);
        ValidateCartUIResponse sampleValidateResponse = null;
        sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(bpmHelper3.updateBarcode(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.upsertValueInRedis("promoMaxCount","1")).thenReturn(Mono.just(Boolean.FALSE));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        UpdateBarcodeUIResponse expectedResponse = sampleResponse;
        Mono<UpdateBarcodeUIResponse> response = helper.updateBarcode(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateBarcodeHelperTestpromoless() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIRequest4.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData18.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setPromoValidMaxCount("11");
        sampleRedisData.setMtn("1234567890");
        sampleRedisData.setPromoMaxCount(null);
        UpdateBarcodeUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateBarcodeUIRequest.class);
        UpdateBarcodeUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateBarcodeUIResponse.class);
        Mono<UpdateBarcodeUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse1.json", testFileLocation);
        ValidateCartUIResponse sampleValidateResponse = null;
        sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(bpmHelper3.updateBarcode(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.upsertValueInRedis(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        UpdateBarcodeUIResponse expectedResponse = sampleResponse;
        Mono<UpdateBarcodeUIResponse> response = helper.updateBarcode(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateBarcodeHelperTestpromo() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData18.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCreditAppNum("1234567890");
        sampleRedisData.setPromoMaxCount(null);
        sampleRedisData.setZ1OfferCode(null);
        sampleRedisData.setPromoValidMaxCount("11");
        UpdateBarcodeUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateBarcodeUIRequest.class);
        UpdateBarcodeUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateBarcodeUIResponse.class);
        Mono<UpdateBarcodeUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse1.json", testFileLocation);
        ValidateCartUIResponse sampleValidateResponse = null;
        sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        when(bpmHelper3.updateBarcode(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.upsertValueInRedis(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        UpdateBarcodeUIResponse expectedResponse = sampleResponse;
        Mono<UpdateBarcodeUIResponse> response = helper.updateBarcode(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();

    }

    @Test
    public void updateBarCodeSweetnerOfferTest() throws JsonProcessingException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIRequest.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData18.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIResponse.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse1.json", testFileLocation);
        UpdateBarcodeUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateBarcodeUIResponse.class);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        ValidateCartUIResponse sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        UpdateBarcodeUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateBarcodeUIRequest.class);
        Mono<UpdateBarcodeUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        sampleRequest.getCartInfo().setFwaSWOfferAccepted(true);
        when(sessionBean.isFWADigitalFlow()).thenReturn(true);
        when(bpmHelper3.updateBarcode(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.upsertValueInRedis(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        Mono<UpdateBarcodeUIResponse> updateBarcodeUIResponseMono = helper.updateBarcode(sampleRequest);
        StepVerifier.create(updateBarcodeUIResponseMono).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        when(sessionBean.isFWADigitalFlow()).thenReturn(false);
        StepVerifier.create(helper.updateBarcode(sampleRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        when(sessionBean.isFWADigitalFlow()).thenReturn(false);
        sampleRequest.getCartInfo().setFwaSWOfferAccepted(false);
        sampleRequest.getCartInfo().setSWOfferAccepted(true);
        StepVerifier.create(helper.updateBarcode(sampleRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        sampleRequest.getCartInfo().setSWOfferAccepted(false);
        StepVerifier.create(helper.updateBarcode(sampleRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void updateBarcodeHelperTestlesspromo() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBarcodeUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData18.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCreditAppNum("1234567890");
        sampleRedisData.setPromoMaxCount(null);
        sampleRedisData.setZ1OfferCode(null);
        sampleRedisData.setPromoValidMaxCount("8");
        sampleRedisData.setMtn("1234567890");
        UpdateBarcodeUIRequest sampleRequest = mapper.readValue(sampleRequestString, UpdateBarcodeUIRequest.class);
        UpdateBarcodeUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateBarcodeUIResponse.class);
        Mono<UpdateBarcodeUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateCartUIResponse1.json", testFileLocation);
        ValidateCartUIResponse sampleValidateResponse = new ValidateCartUIResponse();
        sampleValidateResponse = mapper.readValue(responseString, ValidateCartUIResponse.class);
        CartError cartError=new CartError();
        cartError.setCode("123456");
        cartError.setId("1234567");
        List<CartError> errors=new ArrayList<>();
        errors.add(cartError);
        sampleValidateResponse.setErrors(errors);
        sampleResponse.setErrors(errors);
        when(bpmHelper3.updateBarcode(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.upsertValueInRedis(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(cxpHelper.validateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleValidateResponse));
        UpdateBarcodeUIResponse expectedResponse = sampleResponse;
        Mono<UpdateBarcodeUIResponse> response = helper.updateBarcode(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void cancelCaseHelperTestnotNSE() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CancelCaseUIRequest1.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CancelCaseUIResponse.json", testFileLocation);
        CancelCaseUIRequest sampleUIRequest = null;
        CancelCaseUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        String quotePricingRedisString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/QuotePricingRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCreditAppNum("1234");
        sampleRedisData.setAccountNumber("123456");
        sampleRedisData.setMtn("1234567890");
        QuotePricingRedisData sampleQuotePricingRedisData = mapper.readValue(quotePricingRedisString, QuotePricingRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, CancelCaseUIRequest.class);
        sampleUIRequest.setChannelId("VZW-ACSS");
        sampleResponse = mapper.readValue(sampleUIResponseString, CancelCaseUIResponse.class);
        when(bpmHelper3.cancelCase(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.getQuotePricingRedisData()).thenReturn(Mono.just(sampleQuotePricingRedisData));
        CancelCaseUIResponse expectedResponse = sampleResponse;
        Mono<CancelCaseUIResponse> response = helper.cancelCase(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
                .verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }


    @Test
    public void initiateESimActivation() throws IOException{
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/IntiateESimActivationUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateESimActivationUIResponse.json", testFileLocation);
        IntiateESimActivationUIRequest request = mapper.readValue(sampleRequestString, IntiateESimActivationUIRequest.class);
        InitiateESimActivationUIResponse response = mapper.readValue(sampleResponseString, InitiateESimActivationUIResponse.class);
        when(helper.initiateESimActivation(Mockito.any())).thenReturn(Mono.just(response));
        Mono<InitiateESimActivationUIResponse> simActivationResponse = helper.initiateESimActivation(request);
        StepVerifier.create(simActivationResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void initiateDeviceSimActivationTest() throws IOException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/IntiateDeviceSimActivationUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateDeviceSimActivationUIResponse.json", testFileLocation);
        IntiateDeviceSimActivationUIRequest request = mapper.readValue(sampleRequestString, IntiateDeviceSimActivationUIRequest.class);
        InitiateDeviceSimActivationUIResponse response = mapper.readValue(sampleResponseString, InitiateDeviceSimActivationUIResponse.class);
        when(helper.initiateDeviceSimActivation(Mockito.any())).thenReturn(Mono.just(response));
        Mono<InitiateDeviceSimActivationUIResponse> activationResponse = helper.initiateDeviceSimActivation(request);
        StepVerifier.create(activationResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addAccessoryClearAndContinueTest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddAccessoriesUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateDeviceSimActivationUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);

        sampleRedisData.setIntendType("NSE");
        Lines lines1=new Lines();
        lines1.setCurrentDeviceID("123");
        List<Lines> lines=new ArrayList<>();
        lines.add(lines1);
        sampleRedisData.setLines(lines);
        sampleRedisData.setDepletionType("depl");
        sampleRedisData.setChannelId("VZW-ACSS");
        AddAccessoriesUIRequest request = new AddAccessoriesUIRequest();
        request = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
        //AddAccessoriesUIRequest request = mapper.readValue(sampleRequestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(sampleResponseString, AddAccessoriesUIResponse.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));

        when(redisHelper.updateDataIntoRedisAsString(sampleRedisData,"accessory")).thenReturn(Mono.just(Boolean.TRUE));

        when(cartAccessoryHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        Mono<AddAccessoriesUIResponse> activationResponse = helper.addAccessoryClearAndContinue(sampleRedisData,"SOP-329-E01","20ae6bcb-1150-4d16-99dd-14b7d9f128c7");
        StepVerifier.create(activationResponse).expectError().verify();
    }

    @Test
    public void customerNameByMtnTest() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateDeviceSimActivationUIResponse.json", testFileLocation);
        InitiateValidateDeviceSimUIResponse response = mapper.readValue(sampleResponseString, InitiateValidateDeviceSimUIResponse.class);
        when(cxpHelper2.customerNameByMtn(Mockito.any())).thenReturn(Mono.just(response));
        Mono<InitiateValidateDeviceSimUIResponse> activationResponse = helper.customerNameByMtn("123456");
        StepVerifier.create(activationResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void createCaseTest() throws IOException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/IntiateDeviceSimActivationUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InitiateDeviceSimActivationUIResponse.json", testFileLocation);
        CreateCaseAndGetCustomerInfoUIRequest request = mapper.readValue(sampleRequestString, CreateCaseAndGetCustomerInfoUIRequest.class);
        CreateCaseAndGetCustomerInfoUIResponse response = mapper.readValue(sampleResponseString, CreateCaseAndGetCustomerInfoUIResponse.class);
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        URI url = URI.create("http://localhost/add-accessories");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").cookies(bodyMap).build();
        when(helper.createCase(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
        Mono<CreateCaseAndGetCustomerInfoUIResponse> activationResponse = helper.createCase(request,httpRequest,"imei");
        StepVerifier.create(activationResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }



    @Test
    public void updateEffectiveDateHelpernotNSETest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEffectiveDateUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEffectiveDateUIResponse.json", testFileLocation);
        UpdateEffectiveDateUIRequest sampleRequest = null;
        UpdateEffectiveDateUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCreditAppNum("1234567890");
        sampleRedisData.setCartCreator("nse");
        sampleRedisData.setAccountNumber("1234567890");
        sampleRedisData.setMtn("123456789");
        sampleRedisData.setProcessingMTN("12345678");
        sampleRequest = mapper.readValue(sampleRequestString, UpdateEffectiveDateUIRequest.class);
        sampleRequest.setChannelId("VZW-ACSS");
        sampleResponse = mapper.readValue(sampleResponseString, UpdateEffectiveDateUIResponse.class);
        Mono<UpdateEffectiveDateUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper4.updateEffectiveDate(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateEffectiveDateUIResponse expectedResponse = sampleResponse;
        Mono<UpdateEffectiveDateUIResponse> response = helper.updateEffectiveDate(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

    }

    @Test
    public void addManualDiscountHelpernotNSETest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateManualDiscountUIRequest1.json", testFileLocation);
        String sampleResponseString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateManualDiscountUIResponse.json", testFileLocation);
        UpdateManualDiscountUIRequest sampleRequest = null;
        UpdateManualDiscountUIResponse sampleUIResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCreditAppNum("1234567890");
        sampleRedisData.setAccountNumber("1234567890");
        sampleRedisData.setMtn("1234567890");
        sampleRedisData.setProcessingMTN("1234567890");
        sampleRequest = mapper.readValue(sampleRequestString, UpdateManualDiscountUIRequest.class);
        sampleRequest.setChannelId("OMNI-RETAIL");
        sampleUIResponse = mapper.readValue(sampleResponseString, UpdateManualDiscountUIResponse.class);
        Mono<UpdateManualDiscountUIResponse> sampleResponseMono = Mono.just(sampleUIResponse);
        when(bpmHelper4.addManualdiscount(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateManualDiscountUIResponse expectedResponse = sampleUIResponse;
        Mono<UpdateManualDiscountUIResponse> response = helper.addManualDiscount(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
                .verify();
    }

    @Test
    public void populateHumWifiConflictedSFosWithCheckTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEffectiveDateUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDeviceUIResponse1.json", testFileLocation);
        AddDeviceUIRequest sampleRequest = null;
        AddDeviceUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCreditAppNum("1234567890");
        sampleRedisData.setCartCreator("nse");
        sampleRedisData.setAccountNumber("1234567890");
        sampleRedisData.setMtn("123456789");
        sampleRedisData.setProcessingMTN("12345678");
        sampleRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        sampleRequest.setChannelId("VZW-ACSS");
        sampleResponse = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        Mono<AddDeviceUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        Mono<ResponseEntity<GenericResponse>> response = helper.populateHumWifiConflictedSFosWithCheck(sampleRequest,sampleResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

    }

    @Test
    public void populateSPOsFor5GBoltTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartServiceCartInfo.json", testFileLocation);
        String sampleResponseString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/GenericResponse.json", testFileLocation);
        CartServiceCartInfo sampleRequest = null;
        GenericResponse sampleResponse = null;
        sampleRequest = mapper.readValue(sampleRequestString, CartServiceCartInfo.class);
        sampleResponse = mapper.readValue(sampleResponseString, GenericResponse.class);
        when(redisHelper.updateSPOsIntoRedis(new ConflictedSPOs())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> response = helper.populateSPOsFor5GBolt(sampleRequest,sampleResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void populateHumWifiConflictedSFosWithChecknoTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEffectiveDateUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDeviceUIResponse2.json", testFileLocation);
        AddDeviceUIRequest sampleRequest = null;
        AddDeviceUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCreditAppNum("1234567890");
        sampleRedisData.setCartCreator("nse");
        sampleRedisData.setAccountNumber("1234567890");
        sampleRedisData.setMtn("123456789");
        sampleRedisData.setProcessingMTN("12345678");
        sampleRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        sampleRequest.setChannelId("VZW-ACSS");
        sampleResponse = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        Mono<AddDeviceUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        Mono<ResponseEntity<GenericResponse>> response = helper.populateHumWifiConflictedSFosWithCheck(sampleRequest,sampleResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

    }

    @Test
    public void formatClearCartRequestScanAndGoTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ClearCartUIRequest.json", testFileLocation);
        ClearCartPEGARequest pegaRequest = new ClearCartPEGARequest();
        ClearCartUIRequest request = null;
        request = mapper.readValue(sampleRequestString, ClearCartUIRequest.class);
        request.getCartInfo().setIntent("ACCSG");
        request.getCartInfo().setIntendType("ACC");
        request.getCartInfo().setFlowType("SCAN_AND_GO");
        ClearCartPEGARequest response = cartPegaRequest.formatClearCartRequest(pegaRequest, request, false);
        Assert.assertEquals("SCAN_AND_GO", response.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getFlowType());
        Assert.assertEquals("ACCSG",response.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
    }

    @Test
    public void formatClearCartRequestScanAndGoIncorrectTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ClearCartUIRequest.json", testFileLocation);
        ClearCartPEGARequest pegaRequest = new ClearCartPEGARequest();
        ClearCartUIRequest request = null;
        request = mapper.readValue(sampleRequestString, ClearCartUIRequest.class);
        request.getCartInfo().setIntent("ACCSG");
        request.getCartInfo().setIntendType("ACC");
        request.getCartInfo().setFlowType("SCANANDGO");
        ClearCartPEGARequest response = cartPegaRequest.formatClearCartRequest(pegaRequest, request, false);
        Assert.assertNull(response.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getFlowType());
    }

    @Test
    public void formatClearCartRequestScanAndGoEmptyFlowTypeTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ClearCartUIRequest.json", testFileLocation);
        ClearCartPEGARequest pegaRequest = new ClearCartPEGARequest();
        ClearCartUIRequest request = null;
        request = mapper.readValue(sampleRequestString, ClearCartUIRequest.class);
        request.getCartInfo().setIntent("ACCSG");
        request.getCartInfo().setIntendType("ACC");
        request.getCartInfo().setFlowType(null);
        ClearCartPEGARequest response = cartPegaRequest.formatClearCartRequest(pegaRequest, request, false);
        Assert.assertNull(response.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getFlowType());
    }

    @Test
    public void formatClearCartRequestScanAndGoEmptyIntentTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ClearCartUIRequest.json", testFileLocation);
        ClearCartPEGARequest pegaRequest = new ClearCartPEGARequest();
        ClearCartUIRequest request = null;
        request = mapper.readValue(sampleRequestString, ClearCartUIRequest.class);
        request.getCartInfo().setIntent(null);
        request.getCartInfo().setIntendType("ACC");
        request.getCartInfo().setFlowType(null);
        ClearCartPEGARequest response = cartPegaRequest.formatClearCartRequest(pegaRequest, request, false);
        Assert.assertNull(response.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getFlowType());
    }

    @Test
    public void formatClearCartRequestScanAndGoIncorrectIntendTypeTest() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ClearCartUIRequest.json", testFileLocation);
        ClearCartPEGARequest pegaRequest = new ClearCartPEGARequest();
        ClearCartUIRequest request = null;
        request = mapper.readValue(sampleRequestString, ClearCartUIRequest.class);
        request.getCartInfo().setIntent(null);
        request.getCartInfo().setIntendType("ACC");
        request.getCartInfo().setFlowType(null);
        ClearCartPEGARequest response = cartPegaRequest.formatClearCartRequest(pegaRequest, request, false);
        Assert.assertNull(response.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getFlowType());
    }
}
