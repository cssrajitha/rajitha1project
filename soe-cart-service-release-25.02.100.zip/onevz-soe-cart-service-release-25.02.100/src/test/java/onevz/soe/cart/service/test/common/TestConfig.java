package onevz.soe.cart.service.test.common;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import org.springframework.util.ResourceUtils;


public class TestConfig {
	
	private String request;
	
	private String response;
	
	private String type;
	
	private String testName;
	
	public TestConfig(String type, String testName) {
		this.type = type;
		this.testName = testName;
	}
	
	public void populateReqAndRes() throws IOException {
		File requestF = ResourceUtils.getFile(getRequestFilePath());
        request = new String(Files.readAllBytes(requestF.toPath()));
        File responseF = ResourceUtils.getFile(getResponseFilePath());
        response = new String(Files.readAllBytes(responseF.toPath()));
	}
	
	public String getRequest() {
		return this.request;
	}
	
	public String getResponse() {
		return this.response;
	}
	
	private String getRequestFilePath() {
		return getFilePath(false);
	}
	
	private String getResponseFilePath() {
		String responsePath =  getFilePath(true);
		responsePath = responsePath.replace("Requests", "Responses");
		return responsePath;
	}
	
	private String getFilePath(boolean isResponse) {
		StringBuilder sb = new StringBuilder();
		sb.append(type).append(testName);
		if(isResponse) {
			sb.append("Response.json");
		}else {
			sb.append(".json");
		}
		return sb.toString();
	}

}
