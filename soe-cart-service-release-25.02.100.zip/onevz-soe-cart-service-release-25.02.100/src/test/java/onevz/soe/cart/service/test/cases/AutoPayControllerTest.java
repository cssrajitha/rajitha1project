package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.bpm.service.CartServiceBPMServices;
import onevz.soe.cart.controller.AutoPayController;
import onevz.soe.cart.responses.AutoPayPegaResponse;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.AccessoryFinancingOffersUIRequest;
import onevz.soe.cart.ui.requests.AutoPayUIRequest;
import onevz.soe.cart.ui.responses.AccessoryFinancingOffersUIResponse;
import onevz.soe.session.bean.SOELoginSessionBean;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { CartServiceTestConfig.class })
//@WebFluxTest(AutoPayController.class)
public class AutoPayControllerTest
{

    @Autowired
    private AutoPayController controller;

    @Autowired
    private ObjectMapper mapper;

    @MockBean
    CartServiceBPMServices cartBPMService;

    @MockBean
    private SOELoginSessionBean soeLoginSessionBean;


    @Test
    public void initBinderByNameTest() {
        WebDataBinder binder = new WebDataBinder(null);
        controller.initBinderByName(binder);
        assertNotNull(binder.getDisallowedFields());
    }
    @Test
    public void autoPayFlowTest() throws JsonProcessingException {
        String requestString = "{\n" +
                "    \"header\": {\n" +
                "        \"clientAppName\": \"ATG-RTL-NETACE\",\n" +
                "        \"atgCartId\": \"f44d72b8-6b49-40f1-8019-05f6f8fb1963\",\n" +
                "        \"cartId\": \"f44d72b8-6b49-40f1-8019-05f6f8fb1963\"\n" +
                "    },\n" +
                "    \"cartId\": \"f44d72b8-6b49-40f1-8019-05f6f8fb1963\",\n" +
                "    \"fullName\": \"POS TEST\",\n" +
                "    \"address\": {\n" +
                "        \"addressLine1\": \"30 INDEPENDENCE BL \",\n" +
                "        \"city\": \"WARREN\",\n" +
                "        \"state\": \"NJ\",\n" +
                "        \"zipCode\": \"07059\",\n" +
                "        \"zipCode4\": \"6747\",\n" +
                "        \"country\": \"USA\"\n" +
                "    },\n" +
                "    \"creditCardNumber\": \"411234XNK2uPqY44113 mKMg PCC\",\n" +
                "    \"encryptedCardData\":\"\",\n" +
                "    \"cardExpirationDate\": \"10/2025\",\n" +
                "    \"cardType\": \"visa\",\n" +
                "    \"contactPhoneNumber\": \"9081231211\",\n" +
                "    \"paymentAmount\":150.20\n" +
                "}";

        AutoPayUIRequest request = mapper.readValue(requestString, AutoPayUIRequest.class);
        String responseString = "{\"serviceHeader\": {\"clientId\":\"OMNI-TELESALES\",\"statusMsg\":\"SUCCESS\",\"correlationId\":\"payment-soe-bf4e5b53-7b8d-4c14-acca-07f04795a596\",\"sessionId\":\"GetSessionIdFromSessionUtils\",\"serviceName\":\"SalesOrderFlex\",\"userId\":\"asamota\",\"statusCode\":\"00\"},\"serviceBody\": {\"serviceResponse\":{\"context\":{\"cartInfo\":{\"cartId\":\"a718af6c-1551-4836-8528-790338d7a969\"},\"contextInfo\":{\"availablePaths\":[{\"path\":\"Payment-Agreement\"}],\"processAction\":\"AutoPay\",\"processStep\":\"Payment-Agreement\",\"callReason\":\"SalesOrderFlex\"},\"caseId\":\"SOF-1328145856-E01\",\"customerInfo\":{\"customerType\":\"N\",\"originalCreditApprovalNumber\":\"662784976\",\"accountNumber\":\"\",\"mtnFlow\":\"D\"},\"processMTNList\":[{\"mtn\":\"8088619270\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"InterimPage\",\"PlanSelection\",\"GridWallPDP\",\"GridWallPDP\",\"GridWallPDP\",\"ShoppingCart\",\"ShoppingCart\",\"ShoppingCart\",\"TradeIn\",\"ShoppingCart\",\"ShowHandoff\",\"OrderReview-Shipping\",\"OrderReview-Shipping\",\"OrderReview-Shipping\",\"OrderReview-Shipping\",\"Payment-Agreement\"]}]}}}}";
        AutoPayPegaResponse response = mapper.readValue(responseString, AutoPayPegaResponse.class);
        URI url = URI.create("http://localhost/cart/autoPayFlow");
        HttpHeaders headers = new HttpHeaders();
        headers.add("channelId", "OMNI-TELESALES");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        ServerHttpResponse httpResponse = null;
        try {
            Map<String, String> map = new HashMap<>();
            map.put("ORDERLOC","0026301");
            map.put("processingMTN","8284469005");
            map.put("cartCreator","804251790");
            map.put("mtn","8284469005");
            map.put("accountNumber","");
            map.put("loggedInUser","bhatni1");
            map.put("repId","ENC");
            map.put("caseId","SOF-10213030-E01");
            map.put("intendType","NSE");


            when(soeLoginSessionBean.getSessionData(Mockito.any())).thenReturn(Mono.just(map));

            when(cartBPMService.autoPayFlow(any())).thenReturn(Mono.just(response));
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        Mono<AutoPayPegaResponse> controllerResponse =  controller.autoPayFlow(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void autoPayFlowTest1() throws JsonProcessingException {
        String requestString = "{\"header\":{\"clientAppName\":\"ATG-RTL-NETACE\",\"atgCartId\":\"f3b1806f-cb66-43a5-a408-ce5f11b24990\",\"cartId\":\"f3b1806f-cb66-43a5-a408-ce5f11b24990\"},\"cartId\":\"f3b1806f-cb66-43a5-a408-ce5f11b24990\",\"fullName\":\"BEN WRIGHT\",\"address\":{\"addressLine1\":\"283 HILLSIDE AV\",\"city\":\"NEEDHAM HEIGHTS\",\"state\":\"MA\",\"zipCode\":\"02494\",\"zipCode4\":\"1315\"},\"creditCardNumber\":\"411234kfyveEID54113 8702 PCC\",\"cardExpirationDate\":\"12/2022\",\"cardType\":\"visa\",\"contactPhoneNumber\":\"7798001097\"}";
        AutoPayUIRequest request = mapper.readValue(requestString, AutoPayUIRequest.class);
        String responseString = "{\"serviceHeader\": {\"clientId\":\"OMNI-TELESALES\",\"statusMsg\":\"SUCCESS\",\"correlationId\":\"payment-soe-bf4e5b53-7b8d-4c14-acca-07f04795a596\",\"sessionId\":\"GetSessionIdFromSessionUtils\",\"serviceName\":\"SalesOrderFlex\",\"userId\":\"asamota\",\"statusCode\":\"00\"},\"serviceBody\": {\"serviceResponse\":{\"context\":{\"cartInfo\":{\"cartId\":\"a718af6c-1551-4836-8528-790338d7a969\"},\"contextInfo\":{\"availablePaths\":[{\"path\":\"Payment-Agreement\"}],\"processAction\":\"AutoPay\",\"processStep\":\"Payment-Agreement\",\"callReason\":\"SalesOrderFlex\"},\"caseId\":\"SOF-1328145856-E01\",\"customerInfo\":{\"customerType\":\"N\",\"originalCreditApprovalNumber\":\"662784976\",\"accountNumber\":\"\",\"mtnFlow\":\"D\"},\"processMTNList\":[{\"mtn\":\"8088619270\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"InterimPage\",\"PlanSelection\",\"GridWallPDP\",\"GridWallPDP\",\"GridWallPDP\",\"ShoppingCart\",\"ShoppingCart\",\"ShoppingCart\",\"TradeIn\",\"ShoppingCart\",\"ShowHandoff\",\"OrderReview-Shipping\",\"OrderReview-Shipping\",\"OrderReview-Shipping\",\"OrderReview-Shipping\",\"Payment-Agreement\"]}]}}}}";
        AutoPayPegaResponse response = mapper.readValue(responseString, AutoPayPegaResponse.class);
        URI url = URI.create("http://localhost/cart/autoPayFlow");
        HttpHeaders headers = new HttpHeaders();
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
        ServerHttpResponse httpResponse = null;
        try {
            Map<String, String> map = new HashMap<>();
            map.put("ORDERLOC","0026301");
            map.put("processingMTN","8284469005");
            map.put("cartCreator","804251790");
            map.put("mtn","8284469005");
            map.put("accountNumber","");
            map.put("loggedInUser","bhatni1");
            map.put("repId","ENC");
            map.put("caseId","SOF-10213030-E01");
            map.put("intendType","NSE");
            when(soeLoginSessionBean.getSessionData(Mockito.any())).thenReturn(Mono.just(map));
            when(cartBPMService.autoPayFlow(any())).thenReturn(Mono.just(response));
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        Mono<AutoPayPegaResponse> controllerResponse =  controller.autoPayFlow(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

}
