package onevz.soe.cart.helper;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.common.FiveG.FiveGLTEAddressRedis;
import onevz.soe.cart.model.common.FiveG.MoversRedisData;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpMethod;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

class EncryptDecryptHelperTest {

    @Mock
    private Environment env;

    @InjectMocks
    private EncryptDecryptHelper encryptDecryptHelper;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void getUnifiedNbsData() {
        String igSession = "46468716638174968";
        when(env.getProperty("encrypt.pswdIterations")).thenReturn("65536");
        when(env.getProperty("encrypt.keySize")).thenReturn("256");
        when(env.getProperty("encrypt.key", "")).thenReturn("SeL9Mt7N");
        when(env.getProperty("encrypt.secretKeyFactory.aes")).thenReturn("PBKDF2WithHmacSHA256");
        when(env.getProperty("encrypt.aesAlgo")).thenReturn("AES");
        when(env.getProperty("encrypt.cipher")).thenReturn("AES/CBC/PKCS5Padding");
        MockServerHttpRequest httpHeaders = MockServerHttpRequest.method(HttpMethod.POST, "http://localhost/5g/retrieve-cart").header("Channelid", "VZW-DOTCOM").header("User-Agent", "User-Agent").header("OriginatingClientIp", "0.0.0.0").cookie(new HttpCookie(CartConstants.DIGITAL_IG_SESSION, "121121")).build();
        FiveGLTEAddressRedis redisData = new FiveGLTEAddressRedis();
        redisData.setCartId("478775287465");
        redisData.setCompletedCartId("62468768174974696");
        Assert.assertNotNull(encryptDecryptHelper.getUnifiedNbsData(igSession, redisData));

        Assert.assertNotNull(encryptDecryptHelper.getUnifiedNbsData("", redisData));
        FiveGLTEAddressRedis redisData1 = new FiveGLTEAddressRedis(); //blank
        Assert.assertNotNull(encryptDecryptHelper.getUnifiedNbsData("", redisData1));

        when(env.getProperty("encrypt.pswdIterations")).thenThrow(new RuntimeException("Mocked exception"));
        String result = encryptDecryptHelper.getUnifiedNbsData(igSession, redisData);
        assertEquals("", result);

        MoversRedisData moversRedisedisData = new MoversRedisData();
        Assert.assertNotNull(encryptDecryptHelper.getUnifiedNbsMoversData(igSession, moversRedisedisData));
    }


}