package onevz.soe.cart.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.bpm.service.CartServiceBPMServices;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.cxp.service.CatalogService;
import onevz.soe.cart.model.common.DeviceUpgradeData;
import onevz.soe.cart.model.common.DeviceUpgradeMtn;
import onevz.soe.cart.requests.DeviceExchangeRequest;
import onevz.soe.cart.responses.*;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.wsclient.bpm.model.response.Error;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class FwaDeviceExchangeHelperTest {
    @InjectMocks
    private FwaDeviceUpgradeHelper helper;

    @Mock
    private CartServiceBPMServices bpmServices;

    @Mock
    CartServiceCXPServices cxpServices;

    @Mock
    CatalogService catalogServices;

    @InjectMocks
    private ObjectMapper mapper;

    @Mock
    RedisHelper2 redisHelper;

    @Test
    public void getExchangeDeviceDetails() throws JsonProcessingException {
        String cxpResponse = "{\"data\":{\"titanPreferredSku\":\"WNC-CR200A\",\"inStock\":true,\"isInStockMessage\":\"\"}}";
        DualSkuResponse dualSkuResponse = mapper.readValue(cxpResponse, DualSkuResponse.class);
        FWACreateCartResponse createCartResponse = mapper.readValue("{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"C-436581-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"OrderNow\"}],\"skipCheckoutCall\":false,\"unifiedNbsFlag\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"OrderNow\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"0680796839-00001\",\"cartCreator\":\"9892642781\",\"processingMTN\":\"9892642781\",\"registerNumber\":0,\"existingCase\":\"false\"},\"cartInfo\":{\"cartItemCount\":0,\"updateShippingAddress\":false,\"cartId\":\"\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"9892642781\",\"completedprocessSteps\":[]}]}}}}",FWACreateCartResponse.class);
        FWAUpdateCartResponse updateCartResponse = mapper.readValue("{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"C-461574-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShippingOptions\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"ShippingOptions\"}]},\"customerInfo\":{\"nocByod\":false,\"accountNumber\":\"0685927769-00001\",\"cartCreator\":\"2243064621\",\"processingMTN\":\"2243064621\",\"registerNumber\":0,\"noc\":false,\"myvPage\":false},\"cartInfo\":{\"financeLimitExceeded\":\"false\",\"cartItemCount\":1,\"cartId\":\"56f305be-d13c-4901-8a5e-fc4eefc452dc\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"status\":1,\"reasonCode\":\"PLAN_DEVICE_NOT_COMPATIBLE\",\"eupNoPromoFlow\":false,\"mtn\":\"2243064621\",\"device\":{\"upgradeReasonCode\":\"UN\",\"inactiveDeviceFlow\":false,\"id\":\"ASK-NCM1100\",\"installmentTerm\":\"0\",\"itemPrice\":\"0.0\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"VZ INTERNET GATEWAY ASK-NCM1100\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0,\"isNonVZDeviceSku\":false,\"skuId\":\"sku6003977\",\"skuDisplayName\":\"VZ INTERNET GATEWAY ASK-NCM1100\",\"isDfoSelected\":false},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"EUP_5G\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false,\"skipPromoChoiceOffer\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":true,\"oneBillEnrolled\":false,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false,\"instantCreditAmount\":0,\"ngdFlow\":false,\"skipResumeCase\":false},\"processMTNList\":[{\"mtn\":\"2243064621\",\"completedprocessSteps\":[]},{\"mtn\":\"2243064621\",\"completedprocessSteps\":[]}]}}}}", FWAUpdateCartResponse.class);
        DeviceExchangeRequest soeRequest = mapper.readValue("{\"intent\":\"EUP_5G\"}",DeviceExchangeRequest.class);
        DeviceExchangeResponse soeResponse = mapper.readValue("{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"C-461574-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShippingOptions\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"ShippingOptions\"}]},\"customerInfo\":{\"nocByod\":false,\"accountNumber\":\"0685927769-00001\",\"cartCreator\":\"2243064621\",\"processingMTN\":\"2243064621\",\"registerNumber\":0,\"noc\":false,\"myvPage\":false},\"cartInfo\":{\"financeLimitExceeded\":\"false\",\"cartItemCount\":1,\"cartId\":\"56f305be-d13c-4901-8a5e-fc4eefc452dc\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"status\":1,\"reasonCode\":\"PLAN_DEVICE_NOT_COMPATIBLE\",\"eupNoPromoFlow\":false,\"mtn\":\"2243064621\",\"device\":{\"upgradeReasonCode\":\"UN\",\"inactiveDeviceFlow\":false,\"id\":\"ASK-NCM1100\",\"installmentTerm\":\"0\",\"itemPrice\":\"0.0\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"VZ INTERNET GATEWAY ASK-NCM1100\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0,\"isNonVZDeviceSku\":false,\"skuId\":\"sku6003977\",\"skuDisplayName\":\"VZ INTERNET GATEWAY ASK-NCM1100\",\"isDfoSelected\":false},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"EUP_5G\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false,\"skipPromoChoiceOffer\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":true,\"oneBillEnrolled\":false,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false,\"instantCreditAmount\":0,\"ngdFlow\":false,\"skipResumeCase\":false},\"processMTNList\":[{\"mtn\":\"2243064621\",\"completedprocessSteps\":[]},{\"mtn\":\"2243064621\",\"completedprocessSteps\":[]}]}}}}", DeviceExchangeResponse.class);
        when(bpmServices.createCart(any())).thenReturn(Mono.just(createCartResponse));
        when(catalogServices.getPreferredSkuDetails(any())).thenReturn(Mono.just(dualSkuResponse));
        when(cxpServices.initiateCheckout(any())).thenReturn(Mono.just(new InitiateCheckoutResponse()));
        when(bpmServices.updateCart(any())).thenReturn(Mono.just(updateCartResponse));
        when(helper.invokeUpdateCart(dualSkuResponse,soeRequest,soeResponse,createCartResponse)).thenReturn(Mono.just(soeResponse));
        StepVerifier.create(helper.getDeviceUpgradeDetails(new DeviceExchangeRequest()))
                .assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        //null cases
        when(bpmServices.createCart(any())).thenReturn(Mono.just(createCartResponse));
        when(catalogServices.getPreferredSkuDetails(any())).thenReturn(Mono.just(new DualSkuResponse()));
        when(cxpServices.initiateCheckout(any())).thenReturn(Mono.just(new InitiateCheckoutResponse()));
        when(bpmServices.updateCart(any())).thenReturn(Mono.just(updateCartResponse));
        when(helper.invokeUpdateCart(dualSkuResponse,soeRequest,soeResponse,createCartResponse)).thenReturn(Mono.just(soeResponse));
        StepVerifier.create(helper.getDeviceUpgradeDetails(new DeviceExchangeRequest()))
                .assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        List<Error> errorList = new ArrayList<>();
        Error error = new Error();
        error.setMessage("cartCreator is Mandatory , Please send cartCreator");
        error.setId("1000");
        error.setName("VALIDATION ERROR");
        errorList.add(error);
        createCartResponse.setErrors(errorList);
        when(bpmServices.createCart(any())).thenReturn(Mono.just(createCartResponse));
        when(catalogServices.getPreferredSkuDetails(any())).thenReturn(Mono.just(dualSkuResponse));
        when(cxpServices.initiateCheckout(any())).thenReturn(Mono.just(new InitiateCheckoutResponse()));
        when(bpmServices.updateCart(any())).thenReturn(Mono.just(updateCartResponse));
        when(helper.invokeUpdateCart(dualSkuResponse,soeRequest,soeResponse,createCartResponse)).thenReturn(Mono.just(soeResponse));
        StepVerifier.create(helper.getDeviceUpgradeDetails(new DeviceExchangeRequest()))
                .assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }



    @Test
    public void formatCreateCartRequestTest() throws JsonProcessingException {
        String cxpResponse = "{\"data\":{\"titanPreferredSku\":\"WNC-CR200A\",\"inStock\":true,\"isInStockMessage\":\"\"}}";
        DualSkuResponse dualSkuResponse = mapper.readValue(cxpResponse, DualSkuResponse.class);
        FWACreateCartResponse createCartResponse = mapper.readValue("{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"C-436581-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"OrderNow\"}],\"skipCheckoutCall\":false,\"unifiedNbsFlag\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"OrderNow\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"0680796839-00001\",\"cartCreator\":\"9892642781\",\"processingMTN\":\"9892642781\",\"registerNumber\":0,\"existingCase\":\"false\"},\"cartInfo\":{\"cartItemCount\":0,\"updateShippingAddress\":false,\"cartId\":\"\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"9892642781\",\"completedprocessSteps\":[]}]}}}}",FWACreateCartResponse.class);
        FWAUpdateCartResponse updateCartResponse = mapper.readValue("{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"C-461574-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShippingOptions\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"ShippingOptions\"}]},\"customerInfo\":{\"nocByod\":false,\"accountNumber\":\"0685927769-00001\",\"cartCreator\":\"2243064621\",\"processingMTN\":\"2243064621\",\"registerNumber\":0,\"noc\":false,\"myvPage\":false},\"cartInfo\":{\"financeLimitExceeded\":\"false\",\"cartItemCount\":1,\"cartId\":\"56f305be-d13c-4901-8a5e-fc4eefc452dc\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"status\":1,\"reasonCode\":\"PLAN_DEVICE_NOT_COMPATIBLE\",\"eupNoPromoFlow\":false,\"mtn\":\"2243064621\",\"device\":{\"upgradeReasonCode\":\"UN\",\"inactiveDeviceFlow\":false,\"id\":\"ASK-NCM1100\",\"installmentTerm\":\"0\",\"itemPrice\":\"0.0\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"VZ INTERNET GATEWAY ASK-NCM1100\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0,\"isNonVZDeviceSku\":false,\"skuId\":\"sku6003977\",\"skuDisplayName\":\"VZ INTERNET GATEWAY ASK-NCM1100\",\"isDfoSelected\":false},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"EUP_5G\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false,\"skipPromoChoiceOffer\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":true,\"oneBillEnrolled\":false,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false,\"instantCreditAmount\":0,\"ngdFlow\":false,\"skipResumeCase\":false},\"processMTNList\":[{\"mtn\":\"2243064621\",\"completedprocessSteps\":[]},{\"mtn\":\"2243064621\",\"completedprocessSteps\":[]}]}}}}", FWAUpdateCartResponse.class);
        DeviceExchangeRequest soeRequest = mapper.readValue("{\"intent\":\"EUP_5G\",\"mtn\":\"2243064621\",\"accountNumber\":\"0685927769-00001\",\"networkBandWidthType\":\"CBD\"}",DeviceExchangeRequest.class);
        DeviceExchangeResponse soeResponse = mapper.readValue("{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"C-461574-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShippingOptions\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"ShippingOptions\"}]},\"customerInfo\":{\"nocByod\":false,\"accountNumber\":\"0685927769-00001\",\"cartCreator\":\"2243064621\",\"processingMTN\":\"2243064621\",\"registerNumber\":0,\"noc\":false,\"myvPage\":false},\"cartInfo\":{\"financeLimitExceeded\":\"false\",\"cartItemCount\":1,\"cartId\":\"56f305be-d13c-4901-8a5e-fc4eefc452dc\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"status\":1,\"reasonCode\":\"PLAN_DEVICE_NOT_COMPATIBLE\",\"eupNoPromoFlow\":false,\"mtn\":\"2243064621\",\"device\":{\"upgradeReasonCode\":\"UN\",\"inactiveDeviceFlow\":false,\"id\":\"ASK-NCM1100\",\"installmentTerm\":\"0\",\"itemPrice\":\"0.0\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"VZ INTERNET GATEWAY ASK-NCM1100\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0,\"isNonVZDeviceSku\":false,\"skuId\":\"sku6003977\",\"skuDisplayName\":\"VZ INTERNET GATEWAY ASK-NCM1100\",\"isDfoSelected\":false},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"EUP_5G\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false,\"skipPromoChoiceOffer\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":true,\"oneBillEnrolled\":false,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false,\"instantCreditAmount\":0,\"ngdFlow\":false,\"skipResumeCase\":false},\"processMTNList\":[{\"mtn\":\"2243064621\",\"completedprocessSteps\":[]},{\"mtn\":\"2243064621\",\"completedprocessSteps\":[]}]}}}}", DeviceExchangeResponse.class);
        when(bpmServices.createCart(any())).thenReturn(Mono.just(createCartResponse));
        when(catalogServices.getPreferredSkuDetails(any())).thenReturn(Mono.just(dualSkuResponse));
        when(cxpServices.initiateCheckout(any())).thenReturn(Mono.just(new InitiateCheckoutResponse()));
        when(bpmServices.updateCart(any())).thenReturn(Mono.just(updateCartResponse));
        when(helper.invokeUpdateCart(dualSkuResponse,soeRequest,soeResponse,createCartResponse)).thenReturn(Mono.just(soeResponse));
        StepVerifier.create(helper.getDeviceUpgradeDetails(soeRequest))
                .assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        //null case for createCase response
        createCartResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartId(null);
        when(bpmServices.createCart(any())).thenReturn(Mono.just(createCartResponse));
        StepVerifier.create(helper.getDeviceUpgradeDetails(soeRequest))
                .assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        createCartResponse.getServiceBody().getServiceResponse().getContext().setCartInfo(null);
        when(bpmServices.createCart(any())).thenReturn(Mono.just(createCartResponse));
        StepVerifier.create(helper.getDeviceUpgradeDetails(soeRequest))
                .assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        createCartResponse.getServiceBody().getServiceResponse().getContext().setCaseId(null);
        when(bpmServices.createCart(any())).thenReturn(Mono.just(createCartResponse));
        StepVerifier.create(helper.getDeviceUpgradeDetails(soeRequest))
                .assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        createCartResponse.getServiceBody().getServiceResponse().setContext(null);
        when(bpmServices.createCart(any())).thenReturn(Mono.just(createCartResponse));
        StepVerifier.create(helper.getDeviceUpgradeDetails(soeRequest))
                .assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        createCartResponse.getServiceBody().setServiceResponse(null);
        when(bpmServices.createCart(any())).thenReturn(Mono.just(createCartResponse));
        StepVerifier.create(helper.getDeviceUpgradeDetails(soeRequest))
                .assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        createCartResponse.setServiceBody(null);
        when(bpmServices.createCart(any())).thenReturn(Mono.just(createCartResponse));
        StepVerifier.create(helper.getDeviceUpgradeDetails(soeRequest))
                .assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        dualSkuResponse.getData().setTitanPreferredSku(null);
        when(helper.invokeUpdateCart(dualSkuResponse,soeRequest,soeResponse,createCartResponse)).thenReturn(Mono.just(soeResponse));
        StepVerifier.create(helper.getDeviceUpgradeDetails(soeRequest))
                .assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        dualSkuResponse.setData(null);
        when(helper.invokeUpdateCart(dualSkuResponse,null,soeResponse,createCartResponse)).thenReturn(Mono.just(soeResponse));
        StepVerifier.create(helper.getDeviceUpgradeDetails(null))
                .assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void invokeInitiateCheckoutRequestTest() throws JsonProcessingException {
        DeviceExchangeResponse soeResponse = mapper.readValue("{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"C-461574-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShippingOptions\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"ShippingOptions\"}]},\"customerInfo\":{\"nocByod\":false,\"accountNumber\":\"0685927769-00001\",\"cartCreator\":\"2243064621\",\"processingMTN\":\"2243064621\",\"registerNumber\":0,\"noc\":false,\"myvPage\":false},\"cartInfo\":{\"financeLimitExceeded\":\"false\",\"cartItemCount\":1,\"cartId\":\"56f305be-d13c-4901-8a5e-fc4eefc452dc\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"status\":1,\"reasonCode\":\"PLAN_DEVICE_NOT_COMPATIBLE\",\"eupNoPromoFlow\":false,\"mtn\":\"2243064621\",\"device\":{\"upgradeReasonCode\":\"UN\",\"inactiveDeviceFlow\":false,\"id\":\"ASK-NCM1100\",\"installmentTerm\":\"0\",\"itemPrice\":\"0.0\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"VZ INTERNET GATEWAY ASK-NCM1100\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0,\"isNonVZDeviceSku\":false,\"skuId\":\"sku6003977\",\"skuDisplayName\":\"VZ INTERNET GATEWAY ASK-NCM1100\",\"isDfoSelected\":false},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"EUP_5G\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false,\"skipPromoChoiceOffer\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":true,\"oneBillEnrolled\":false,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false,\"isPrepaidToPostpaidMigration\":false,\"instantCreditAmount\":0,\"ngdFlow\":false,\"skipResumeCase\":false},\"processMTNList\":[{\"mtn\":\"2243064621\",\"completedprocessSteps\":[]},{\"mtn\":\"2243064621\",\"completedprocessSteps\":[]}]}}}}", DeviceExchangeResponse.class);
        when(cxpServices.initiateCheckout(any())).thenReturn(Mono.just(new InitiateCheckoutResponse()));
        StepVerifier.create(helper.invokeInitiateCheckoutRequest(soeResponse))
                .assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        //null case
        soeResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartId(null);
        StepVerifier.create(helper.invokeInitiateCheckoutRequest(soeResponse))
                .assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        soeResponse.getServiceBody().getServiceResponse().getContext().setCartInfo(null);
        StepVerifier.create(helper.invokeInitiateCheckoutRequest(soeResponse))
                .assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        soeResponse.getServiceBody().getServiceResponse().setContext(null);
        StepVerifier.create(helper.invokeInitiateCheckoutRequest(soeResponse))
                .assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        soeResponse.getServiceBody().setServiceResponse(null);
        StepVerifier.create(helper.invokeInitiateCheckoutRequest(soeResponse))
                .assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        soeResponse.setServiceBody(null);
        StepVerifier.create(helper.invokeInitiateCheckoutRequest(soeResponse))
                .assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(helper.invokeInitiateCheckoutRequest(null))
                .assertNext(resp -> assertNotNull(resp)).expectComplete();
    }

}
