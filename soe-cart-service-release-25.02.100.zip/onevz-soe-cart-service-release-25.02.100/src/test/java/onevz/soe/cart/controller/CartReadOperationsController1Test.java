package onevz.soe.cart.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.jayway.jsonpath.JsonPath;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.exceptions.JsonValidator;
import onevz.soe.cart.gql.schema.bundlebuildercartlightweight.PromoHubOffer;
import onevz.soe.cart.gql.schema.bundlebuildercartlightweight.PromoHubOfferNode;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.model.bundleBuilderCart.BundleBuilderCXPCartItem;
import onevz.soe.cart.requests.BundleBuilderRequest;
import onevz.soe.cart.responses.BundleBuilderCXPResponseData;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.orderprocess.translator.BundleBuilderResponse;
import onevz.soe.orderprocess.translator.model.CartLW;
import onevz.soe.orderprocess.translator.model.LineDetailsLW;
import onevz.soe.orderprocess.translator.model.NewLineLW;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.http.server.reactive.MockServerHttpResponse;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.groups.Tuple.tuple;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static reactor.test.StepVerifier.create;

@ContextConfiguration(classes = {CartReadOperationsController1.class})
@Slf4j
@TestPropertySource("classpath:application.properties")
@DirtiesContext
public class CartReadOperationsController1Test extends BaseTest {
	
	@MockBean
	private UpdateCartHelper helper;

	@MockBean
	private  FeatureFlagHelper featureFlagHelper;
	
	@MockBean
	private CartServiceCxpHelper cartSvcCXPHelper;
	
	@MockBean
	private ReadCartHelper readCartHelper;
	
	@MockBean
	private RedisHelper redisHelper;
	@MockBean
	private RedisHelper2 redisHelper2;
	@MockBean
	private RedisHelper3 redisHelper3;
	
	@Autowired
	private CartReadOperationsController1 readOperationsController;
	
	@MockBean
	private MockServerHttpResponse serverHttpResponse;
	
	@MockBean
	private JsonValidator validator;
	
	@Before
	@SneakyThrows
	public void setUp() {
		CartRedisData cartRedisData = jsonToObject("/data/cartServiceHelperTest/CartRedisData.json", CartRedisData.class);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(cartRedisData));
		BundleBuilderCXPResponseData bundleBuilderCXPResponseData = jsonToObject("/promobuildercxpcart_response.json", BundleBuilderCXPResponseData.class);
		when(readCartHelper.bundleBuilderCart(any())).thenReturn(Mono.just(bundleBuilderCXPResponseData));
		ReflectionTestUtils.setField(readOperationsController,"promoChoiceEnabled",false);
	}
	
	
	@Test
	@SneakyThrows
	public void isPromoOfferChoiceTrueBICTest() {
		BundleBuilderRequest bundleBuilderRequest = getBundleBuilderRequest(true, "420146");
		bundleBuilderRequest.setSelectedOfferType("BIC");
		create(readOperationsController.bundleBuilderCart(getMockServerHttpRequest(), serverHttpResponse, bundleBuilderRequest))
				.assertNext(builderCartResponse -> {
					assertThat(builderCartResponse).isNotNull();
					var xpath = "$..deviceItem.promoHubOfferList";
					List<Map<String,Object>> promoHubList = JsonPath.read(convertToJson(builderCartResponse), xpath);
					PromoHubOfferNode promoHubOfferNode = convertToPojo(promoHubList.get(0), PromoHubOfferNode.class);
					assertThat(promoHubOfferNode).isNotNull();
					assertThat(promoHubOfferNode.getOfferCount())
							.isEqualTo(4);
					assertThat(promoHubOfferNode.getPromoHubOfferList()).isNotEmpty()
							.hasSize(4)
							.extracting(PromoHubOffer::getPromotionId,PromoHubOffer::getOfferName)
							.contains(
									tuple("promo4365951","Choice Get $819.99 off Iph 15 Pro ACT DPP Unl Ult"),
									tuple("promo4365915","$459.99 off iPad 10.2 9th gen Act w/Pur of 5G iPh"),
									tuple("promo4365950","$299.99 off Aple WtchSE Act W/Pur of 5G iPh Prem"),
									tuple("promo4360980","BMSM GET 259.99OFF SamBook PUR 5G SMT DPP CON DA")
							)
							.doesNotContain(
									tuple("promo4364722","Amazon TV"),
									tuple("promo4362302","Up to $1000 off iPh15 Pro/Pro Max Act Ult/Get/On")
							);
				})
				.expectComplete()
				.verify();
	}
	
	@Test
	@SneakyThrows
	public void isPromoOfferChoiceTrueTradeInPromoTest() {
		BundleBuilderRequest bundleBuilderRequest = getBundleBuilderRequest(true, "412934");
		bundleBuilderRequest.setSelectedOfferType("TRADEIN_PROMO");
		create(readOperationsController.bundleBuilderCart(getMockServerHttpRequest(), serverHttpResponse, bundleBuilderRequest))
				.assertNext(builderCartResponse -> {
					assertThat(builderCartResponse).isNotNull();
					var xpath = "$..deviceItem.promoHubOfferList";
					List<Map<String,Object>> promoHubList = JsonPath.read(convertToJson(builderCartResponse), xpath);
					PromoHubOfferNode promoHubOfferNode = convertToPojo(promoHubList.get(0), PromoHubOfferNode.class);
					assertThat(promoHubOfferNode).isNotNull();
					assertThat(promoHubOfferNode.getOfferCount())
							.isEqualTo(4);
					assertThat(promoHubOfferNode.getPromoHubOfferList()).isNotEmpty()
							.hasSize(4)
							.extracting(PromoHubOffer::getPromotionId, PromoHubOffer::getPromoType)
							.contains(
									tuple("promo4362302", "TRADEIN_PROMO"),
									tuple("promo4365915", "BICBMSM"),
									tuple("promo4365950", "BICBMSM"),
									tuple("promo4360980", "BICBMSM")
							)
							.doesNotContain(
									tuple("promo4365951", "BIC"),
									tuple("promo4364722", "FEATURED_PROMO")
							);
				})
				.expectComplete()
				.verify();
	}
	
	@Test
	@SneakyThrows
	public void promoOfferChoiceTrueFeaturedPromoScenarioTest() {
		BundleBuilderRequest bundleBuilderRequest = getBundleBuilderRequest(true, "416990");
		bundleBuilderRequest.setSelectedOfferType("FEATURED_PROMO");
		create(readOperationsController.bundleBuilderCart(getMockServerHttpRequest(), serverHttpResponse, bundleBuilderRequest))
				.assertNext(data -> {
					assertThat(data).isNotNull();
					var xpath = "$..deviceItem.promoHubOfferList";
					List<Map<String,Object>> promoHubList = JsonPath.read(convertToJson(data), xpath);
					PromoHubOfferNode promoHubOfferNode = convertToPojo(promoHubList.get(0), PromoHubOfferNode.class);
					assertThat(promoHubOfferNode).isNotNull();
					assertThat(promoHubOfferNode.getOfferCount())
							.isEqualTo(4);
					assertThat(promoHubOfferNode.getPromoHubOfferList()).isNotEmpty()
							.hasSize(4)
							.extracting(PromoHubOffer::getPromotionId)
							.contains("promo4364722", "promo4365915", "promo4365950","promo4360980")
							.doesNotContain("promo4362302", "promo4365951");
				})
				.expectComplete()
				.verify();
	}
	
	private static BundleBuilderRequest getBundleBuilderRequest(boolean isPromoChoiceOffer,String offerId) {
		BundleBuilderRequest request = new BundleBuilderRequest();
		request.setCartId(UUID.randomUUID().toString());
		request.setChannelId(CartConstants.VZW_DOTCOM);
		request.setSelectedOfferId(offerId);
		request.setPromoChoiceOffer(isPromoChoiceOffer);
		return request;
	}
	
	@Test
	@SneakyThrows
	public void isPromoOfferChoiceFalseTest() {
		BundleBuilderCXPResponseData bundleBuilderCXPResponseData = jsonToObject("/promobuildercxpcart_response.json", BundleBuilderCXPResponseData.class);
		when(readCartHelper.bundleBuilderCart(any())).thenReturn(Mono.just(bundleBuilderCXPResponseData));
		create(readOperationsController.bundleBuilderCart(getMockServerHttpRequest(), serverHttpResponse, getBundleBuilderRequest(false, "no-promo")))
				.assertNext(builderCartResponse -> {
					assertThat(builderCartResponse).isNotNull();
					String jsonPath = "$.data.cart.lineDetails.lineInfo.newLine1.deviceItem.promoHubOfferList.promoHubOfferList";
					List<Map<String, Object>> promoHubList = JsonPath.read(convertToJson(builderCartResponse), jsonPath);
					assertThat(promoHubList).isNotEmpty();
					List<PromoHubOffer> promoHubOfferList = objectToList(convertToJson(promoHubList), new TypeReference<>() {});
					assertThat(promoHubOfferList).isNotEmpty()
							.hasSize(6)
							.extracting(PromoHubOffer::getPromoType, PromoHubOffer::getOfferId)
							.contains(
									tuple("FEATURED_PROMO", "416990"), tuple("TRADEIN_PROMO", "412934"),
									tuple("BIC", "420146"), tuple("BICBMSM", "420070"),
									tuple("BICBMSM", "420124"),tuple("BICBMSM", "420124")
							);
				})
				.expectComplete()
				.verify();
	}
	
	@Test
	@SneakyThrows
	public void nullDataForPromoListTest()  {
		BundleBuilderResponse data = jsonToObject("/bundle_builder_response.json", BundleBuilderResponse.class);
		CartLW cart = data.getData().getCart();
		LineDetailsLW lineDetails = cart.getLineDetails();
		Map<String, NewLineLW> lineInfo = lineDetails.getLineInfo();
		NewLineLW newLineLW = lineInfo.get("newLine1");
		BundleBuilderCXPCartItem deviceItem = newLineLW.getDeviceItem();
		onevz.soe.cart.gql.schema.bundlebuildercartlightweight.PromoHubOfferNode promoHubOfferList = deviceItem.getPromoHubOfferList();
		promoHubOfferList.setPromoHubOfferList(null);
		Mono<BundleBuilderResponse> responseMono = Mono.just(data);
		BundleBuilderRequest bundleBuilderRequest = getBundleBuilderRequest(true, "promo4365951");
		verifier(responseMono,bundleBuilderRequest,data);
		
		deviceItem.setPromoHubOfferList(null);
		verifier(responseMono,bundleBuilderRequest,data);
		
		newLineLW.setDeviceItem(null);
		verifier(responseMono,bundleBuilderRequest,data);
		lineDetails.setLineInfo(null);
		verifier(responseMono,bundleBuilderRequest,data);
	}
	
	private void verifier(Mono<BundleBuilderResponse> responseMono,BundleBuilderRequest bundleBuilderRequest, BundleBuilderResponse response) {
		create(Objects.requireNonNull(ReflectionTestUtils.invokeMethod(readOperationsController, "filterPromoChoiceOffers", responseMono, bundleBuilderRequest)))
				.expectNext(response)
				.expectComplete()
				.verify();
	}
	
	@Test
	@SneakyThrows
	public void selectedTypeBICSMSMOfferTest() {
		BundleBuilderRequest bundleBuilderRequest = getBundleBuilderRequest(true, "420070");
		bundleBuilderRequest.setSelectedOfferType("BICBMSM");
		create(readOperationsController.bundleBuilderCart(getMockServerHttpRequest(), serverHttpResponse, bundleBuilderRequest))
				.assertNext(data -> {
					assertThat(data).isNotNull();
					var xpath = "$..deviceItem.promoHubOfferList";
					List<Map<String,Object>> promoHubList = JsonPath.read(convertToJson(data), xpath);
					PromoHubOfferNode promoHubOfferNode = convertToPojo(promoHubList.get(0), PromoHubOfferNode.class);
					assertThat(promoHubOfferNode).isNotNull();
					assertThat(promoHubOfferNode.getOfferCount())
							.isEqualTo(3);
					assertThat(promoHubOfferNode.getPromoHubOfferList()).isNotEmpty()
							.hasSize(3)
							.extracting(PromoHubOffer::getPromoType)
							.contains("BICBMSM", "BICBMSM", "BICBMSM")
							.doesNotContain("BIC");
				})
				.expectComplete()
				.verify();
	}
	
	@Test
	@SneakyThrows
	public void promoOfferChoiceTrueBMSMScenarioTest() {
		ReflectionTestUtils.setField(readOperationsController,"promoChoiceOfferTypeList",List.of("BIC","TRADEIN_PROMO","FEATURED_PROMO","BICBMSM"));
		BundleBuilderRequest bundleBuilderRequest = getBundleBuilderRequest(true, "420070");
		bundleBuilderRequest.setSelectedOfferType("BICBMSM");
		create(readOperationsController.bundleBuilderCart(getMockServerHttpRequest(), serverHttpResponse, bundleBuilderRequest))
				.assertNext(data -> {
					assertThat(data).isNotNull();
					var xpath = "$..deviceItem.promoHubOfferList";
					List<Map<String,Object>> promoHubList = JsonPath.read(convertToJson(data), xpath);
					PromoHubOfferNode promoHubOfferNode = convertToPojo(promoHubList.get(0), PromoHubOfferNode.class);
					assertThat(promoHubOfferNode).isNotNull();
					assertThat(promoHubOfferNode.getOfferCount())
							.isEqualTo(3);
					assertThat(promoHubOfferNode.getPromoHubOfferList()).isNotEmpty()
							.hasSize(3)
							.extracting(PromoHubOffer::getOfferId)
							.contains("420070", "420124", "410808")
							.doesNotContain("420146", "412934","416990");
				})
				.expectComplete()
				.verify();
		ReflectionTestUtils.setField(readOperationsController,"promoChoiceOfferTypeList",List.of("BIC","TRADEIN_PROMO","FEATURED_PROMO"));
	}
	
	@Test
	@SneakyThrows
	public void promoOfferChoiceTrueFeaturedPromoMultiLineScenarioTest() {
		BundleBuilderCXPResponseData bundleBuilderCXPResponseData = getMultiLineResponse();
		when(readCartHelper.bundleBuilderCart(any())).thenReturn(Mono.just(bundleBuilderCXPResponseData));
		BundleBuilderRequest bundleBuilderRequest = getBundleBuilderRequest(true, "595584");
		bundleBuilderRequest.setSelectedOfferType("FEATURED_PROMO");
		create(readOperationsController.bundleBuilderCart(getMockServerHttpRequest(), serverHttpResponse, bundleBuilderRequest))
				.assertNext(data -> {
					assertThat(data).isNotNull();
					Map<String, NewLineLW> lineInfo = ((BundleBuilderResponse) data).getData().getCart().getLineDetails().getLineInfo();
					assertThat(lineInfo)
							.isNotEmpty()
							.hasSize(3);
					Map<String, PromoHubOfferNode> lineMapWithPromoList = lineInfo.entrySet().stream()
							.collect(Collectors.toMap(Map.Entry::getKey, entry -> entry.getValue().getDeviceItem().getPromoHubOfferList()));
					assertThat(lineMapWithPromoList.get("newLine1")).
							isNotNull().extracting("offerCount").as("NewLine1 offerCount should be")
							.isEqualTo(4);
					assertThat(lineMapWithPromoList.get("newLine2")).isNotNull()
							.extracting("offerCount").as("NewLine2 offerCount").isEqualTo(2);
					assertThat(lineMapWithPromoList.get("newLine3")).isNotNull()
							.extracting("offerCount").as("NewLine3 offerCount").isEqualTo(4);
					assertThat(((BundleBuilderResponse) data).getData().getCart().getOrderDetails().getFlowType().equals("DVM_CONVERSION"));
				})
				.expectComplete()
				.verify();
	}
	
	@Test
	@SneakyThrows
	public void isPromoOfferChoiceFeaturedPromoKillSwitchTrueTest() {
		ReflectionTestUtils.setField(readOperationsController,"promoChoiceEnabled",true);
		BundleBuilderCXPResponseData bundleBuilderCXPResponseData = getMultiLineResponse();
		when(readCartHelper.bundleBuilderCart(any())).thenReturn(Mono.just(bundleBuilderCXPResponseData));
		BundleBuilderRequest bundleBuilderRequest = getBundleBuilderRequest(true, "595584");
		bundleBuilderRequest.setSelectedOfferType("FEATURED_PROMO");
		create(readOperationsController.bundleBuilderCart(getMockServerHttpRequest(), serverHttpResponse, bundleBuilderRequest))
				.assertNext(data -> {
					assertThat(data).isNotNull();
					Map<String, NewLineLW> lineInfo = ((BundleBuilderResponse) data).getData().getCart().getLineDetails().getLineInfo();
					assertThat(lineInfo)
							.isNotEmpty()
							.hasSize(3);
					Map<String, PromoHubOfferNode> lineMapWithPromoList = lineInfo.entrySet().stream()
							.collect(Collectors.toMap(Map.Entry::getKey, entry -> entry.getValue().getDeviceItem().getPromoHubOfferList()));
					assertThat(lineMapWithPromoList.get("newLine3").getPromoHubOfferList()).isNotEmpty().as("NewLine3")
							.hasSize(4);
					assertThat(lineMapWithPromoList.get("newLine2").getPromoHubOfferList()).isNotEmpty().as("NewLine2")
							.hasSize(2);
					assertThat(lineMapWithPromoList.get("newLine1").getPromoHubOfferList()).isNotEmpty().as("NewLine1")
							.hasSize(3);
				})
				.expectComplete()
				.verify();
	}
	
	@Test
	@SneakyThrows
	public void isPromoOfferChoiceBICKillSwitchTrueTest() {
		ReflectionTestUtils.setField(readOperationsController,"promoChoiceEnabled",true);
		BundleBuilderCXPResponseData bundleBuilderCXPResponseData = getMultiLineResponse();
		when(readCartHelper.bundleBuilderCart(any())).thenReturn(Mono.just(bundleBuilderCXPResponseData));
		BundleBuilderRequest bundleBuilderRequest = getBundleBuilderRequest(true, "420146");
		bundleBuilderRequest.setSelectedOfferType("BIC");
		create(readOperationsController.bundleBuilderCart(getMockServerHttpRequest(), serverHttpResponse, bundleBuilderRequest))
				.assertNext(data -> {
					assertThat(data).isNotNull();
					Map<String, NewLineLW> lineInfo = ((BundleBuilderResponse) data).getData().getCart().getLineDetails().getLineInfo();
					Map<String, PromoHubOfferNode> lineMapWithPromoList = lineInfo.entrySet().stream()
							.collect(Collectors.toMap(Map.Entry::getKey, entry -> entry.getValue().getDeviceItem().getPromoHubOfferList()));
					assertThat(lineMapWithPromoList.get("newLine3").getPromoHubOfferList()).isNotEmpty()
							.hasSize(4)
							.extracting("promoType")
							.contains("BIC","BICBOGO","BICBMSM")
							.doesNotContain("FEATURED_PROMO","TRADEIN_PROMO","SIMPLE");
				})
				.expectComplete()
				.verify();
	}
	
	@Test
	@SneakyThrows
	public void filterPromoOfferChoiceBICSelectedTest() {
		BundleBuilderCXPResponseData bundleBuilderCXPResponseData = getMultiLineResponse();
		when(readCartHelper.bundleBuilderCart(any())).thenReturn(Mono.just(bundleBuilderCXPResponseData));
		BundleBuilderRequest bundleBuilderRequest = getBundleBuilderRequest(true, "420146");
		bundleBuilderRequest.setSelectedOfferType("BIC");
		create(readOperationsController.bundleBuilderCart(getMockServerHttpRequest(), serverHttpResponse, bundleBuilderRequest))
				.assertNext(data -> {
					assertThat(data).isNotNull();
					Map<String, NewLineLW> lineInfo = ((BundleBuilderResponse) data).getData().getCart().getLineDetails().getLineInfo();
					assertThat(lineInfo)
							.isNotEmpty()
							.hasSize(3);
					Map<String, PromoHubOfferNode> lineMapWithPromoList = lineInfo.entrySet().stream()
							.collect(Collectors.toMap(Map.Entry::getKey, entry -> entry.getValue().getDeviceItem().getPromoHubOfferList()));
					assertThat(lineMapWithPromoList.get("newLine3").getPromoHubOfferList()).isNotEmpty()
							.as("NewLine 3")
							.hasSize(4)
							.extracting("promoType","selectedOfferId")
							.contains(tuple("BIC","420146"),tuple("BICBOGO",null),
									tuple("BICBMSM",null),tuple("BICBMSM",null));
					assertThat(lineMapWithPromoList.get("newLine2").getPromoHubOfferList()).isNotEmpty()
							.as("NewLine 2")
							.hasSize(1)
							.extracting("promoType")
							.contains("BICBOGO")
							.doesNotContain("FEATURED_PROMO","TRADEIN_PROMO","SIMPLE");
				})
				.expectComplete()
				.verify();
	}
	
	private BundleBuilderCXPResponseData getMultiLineResponse() throws IOException {
		return jsonToObject("/promobuildercxpcart_multi_line_response.json", BundleBuilderCXPResponseData.class);
	}
	
	@Test
	@SneakyThrows
	public void noPromoSelectedTest() {
		BundleBuilderResponse builderResponse = jsonToObject("/bundle_builder_response.json", BundleBuilderResponse.class);
		BundleBuilderRequest bundleBuilderRequest = getBundleBuilderRequest(true, "");
		bundleBuilderRequest.setSelectedOfferId(CartConstants.NOPROMO);
		List<Map<String,Object>> listOfHubOffer = JsonPath.read(convertToJson(builderResponse), "$..deviceItem.promoHubOfferList");
		Mono<BundleBuilderResponse> filterPromoChoiceOffers = ReflectionTestUtils.invokeMethod(readOperationsController, "filterPromoChoiceOffers", Mono.just(builderResponse), bundleBuilderRequest);
		assertThat(filterPromoChoiceOffers).isNotNull();
		create(filterPromoChoiceOffers)
				.assertNext(data -> {
					List<Map<String,Object>> responseOfferList = JsonPath.read(convertToJson(data), "$..deviceItem.promoHubOfferList");
					assertThat(responseOfferList).isNotEmpty();
					assertThat(responseOfferList).hasSize(listOfHubOffer.size());
				})
				.expectComplete()
				.verify();
		Map<String, Object> promoBadgeList = ((List<Map<String, Object>>) listOfHubOffer.get(0).get("promoHubOfferList")).get(1);
		promoBadgeList.remove("promoType");
		Map<String, Object> promoHubOfferList = ((List<Map<String, Object>>) listOfHubOffer.get(0).get("promoHubOfferList")).get(0);
		promoHubOfferList.put("promoBadges",List.of());
		bundleBuilderRequest.setSelectedOfferId("promo4365035");
		bundleBuilderRequest.setSelectedOfferType("BIC");
		Mono<BundleBuilderResponse> filterPromoCoverage = ReflectionTestUtils.invokeMethod(readOperationsController, "filterPromoChoiceOffers", Mono.just(builderResponse), bundleBuilderRequest);
		assertThat(filterPromoCoverage).isNotNull();
		create(filterPromoCoverage)
				.expectNext(builderResponse)
				.expectComplete()
				.verify();
		List<PromoHubOfferNode> offerNodes = objectToList(convertToJson(listOfHubOffer), new TypeReference<>() {});
		offerNodes.stream()
				.map(PromoHubOfferNode::getPromoHubOfferList)
				.findAny()
						.ifPresent(promoHubOffer -> {
							ReflectionTestUtils.invokeMethod(readOperationsController, "filterPdpPromoChoiceOffers", promoHubOffer, new BundleBuilderRequest());
							assertThat(promoHubOffer).isNotEmpty();
						});
		List<PromoHubOffer> offerList = offerNodes.get(0).getPromoHubOfferList();
		offerList.get(0).setPromoType(null);
		ReflectionTestUtils.invokeMethod(readOperationsController, "filterPdpPromoChoiceOffers", offerList, new BundleBuilderRequest());
	}
	
	@Test
	@SneakyThrows
	public void promoOfferChoiceWithNotSelectedTypeTest() {
		BundleBuilderRequest bundleBuilderRequest = getBundleBuilderRequest(true, "420146");
		create(readOperationsController.bundleBuilderCart(getMockServerHttpRequest(), serverHttpResponse, bundleBuilderRequest))
				.assertNext(builderCartResponse -> {
					assertThat(builderCartResponse).isNotNull();
					var xpath = "$..deviceItem.promoHubOfferList";
					List<Map<String,Object>> promoHubList = JsonPath.read(convertToJson(builderCartResponse), xpath);
					PromoHubOfferNode promoHubOfferNode = convertToPojo(promoHubList.get(0), PromoHubOfferNode.class);
					assertThat(promoHubOfferNode).isNotNull();
					assertThat(promoHubOfferNode.getOfferCount())
							.isEqualTo(3);
					assertThat(promoHubOfferNode.getPromoHubOfferList()).isNotEmpty()
							.hasSize(3)
							.extracting(PromoHubOffer::getPromotionId,PromoHubOffer::getSelectedOfferId)
							.contains(
									tuple("promo4365915",null),
									tuple("promo4365950",null),
									tuple("promo4360980",null)
							)
							.doesNotContain(tuple("promo4365951","420146"));
				})
				.expectComplete()
				.verify();
	}
	
	@Test
	@SneakyThrows
	public void promoOfferChoiceWithPromotionIDTest() {
		BundleBuilderRequest bundleBuilderRequest = getBundleBuilderRequest(true, "promo4365951");
		bundleBuilderRequest.setSelectedOfferType("BIC");
		create(readOperationsController.bundleBuilderCart(getMockServerHttpRequest(), serverHttpResponse, bundleBuilderRequest))
				.assertNext(builderCartResponse -> {
					assertThat(builderCartResponse).isNotNull();
					var xpath = "$..deviceItem.promoHubOfferList";
					List<Map<String,Object>> promoHubList = JsonPath.read(convertToJson(builderCartResponse), xpath);
					PromoHubOfferNode promoHubOfferNode = convertToPojo(promoHubList.get(0), PromoHubOfferNode.class);
					assertThat(promoHubOfferNode).isNotNull();
					assertThat(promoHubOfferNode.getOfferCount())
							.isEqualTo(4);
					assertThat(promoHubOfferNode.getPromoHubOfferList()).isNotEmpty()
							.hasSize(4)
							.extracting(PromoHubOffer::getPromotionId,PromoHubOffer::getSelectedOfferId)
							.contains(
									tuple("promo4365951","promo4365951"),
									tuple("promo4365915",null),
									tuple("promo4365950",null),
									tuple("promo4360980",null)
							);
				})
				.expectComplete()
				.verify();
	}
}
