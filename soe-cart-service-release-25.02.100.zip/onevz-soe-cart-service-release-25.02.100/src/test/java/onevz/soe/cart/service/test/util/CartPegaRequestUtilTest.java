package onevz.soe.cart.service.test.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.cxp.feature.Flag;
import onevz.cxp.feature.util.FeatureFlag;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.constants.FeatureFlagConstants;
import onevz.soe.cart.initiatecart.CpcFeatureRequest;
import onevz.soe.cart.model.AccessoryFinancingOffers.AccessoryFinancingOffersPegaRequest;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntentPEGARequest;
import onevz.soe.cart.model.addPromoIntent.AddPromoIntentUIRequest;
import onevz.soe.cart.model.addTrialContactInfoAndAddress.AddTrialContactInfoAndAddressUIRequest;
import onevz.soe.cart.model.affirmfinancing.AffirmFinancingPegaRequest;
import onevz.soe.cart.model.deviceIdValidation.SearchAttributes;
import onevz.soe.cart.model.getCase.GetCaseRequest;
import onevz.soe.cart.model.initiateValidateDeviceSim.InitiateValidateDeviceSimUIRequest;
import onevz.soe.cart.model.salesOrderAdjustment.LineDetails;
import onevz.soe.cart.model.salesOrderAdjustment.LineInfo;
import onevz.soe.cart.model.salesOrderAdjustment.SalesOrderAdjustmentOrderDetails;
import onevz.soe.cart.ui.common.CartInfo;
import onevz.soe.cart.ui.requests.AddZipCodeUIRequest;
import onevz.soe.cart.requests.*;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.smartimeisearch.DeviceIdValidationRequestFormatter;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.util.*;
import onevz.soe.spring.web.filter.RequestAccessContext;
import onevz.soe.spring.web.filter.RequestAccessContext.RequestAccess;
import onevz.soe.wsclient.bpm.model.CustomerInfo;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpHeaders;
import org.springframework.util.LinkedMultiValueMap;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
@RunWith(SpringJUnit4ClassRunner.class)
@WebFluxTest(CartPegaRequestUtil.class)
public class CartPegaRequestUtilTest {
	@Autowired
	private ObjectMapper mapper;
	@Autowired
	SourceFileReaderUtil sourceFileReaderUtil;
	@Value("${onevz.soe.cart.test.fileLocation}")
	private String testFileLocation;
	@Autowired
	private DeviceIdValidationRequestFormatter formater;
	@InjectMocks
	private CartPegaRequestUtil cartPegaRequestUtil;
	@MockBean
	FeatureFlag featureFlag;
	@Before
	public void setup() {
		RequestAccess reqAccess = new RequestAccess();
		reqAccess.getCookies().add("dvmConversion", new HttpCookie("dvmConversion", "false"));
		RequestAccessContext.updateRequestData(reqAccess);
	}
	private Flag getFFlag() {
		Flag flag = new Flag();
		flag.setName(FeatureFlagConstants.FLAG_NAME_ACTIVATION_FEE_WAIVER_FFAG);
		flag.setEnabled(true);
		flag.setFound(true);
		List<String> offerCode = new ArrayList<>();
		offerCode.add("DP2PM");
		Map<String, List<String>> fmap = new HashMap<>();
		fmap.put("offerCode", offerCode);
		flag.setAttributes(fmap);
		Mockito.when(featureFlag.getFeatureFlag(any(), any(), any())).thenReturn(Mono.just(flag));
		return flag;
	}
	@Test
	public void formatAddReplenishmentRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {},\"data\": {\"lines\": [{}]}}";
		AddReplenishmentToCartUIRequest uiRequest = mapper.readValue(requestString, AddReplenishmentToCartUIRequest.class);
		AddReplenishmentToCartPEGARequest response = CartPegaRequestUtil9.formatAddReplenishmentRequest(uiRequest, new AddReplenishmentToCartPEGARequest());
		Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
	}
	@Test
	public void formatAddReplenishmentRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"intendType\": \"EUP\"},\"data\": {\"lines\": [{}]}}";
		AddReplenishmentToCartUIRequest uiRequest = mapper.readValue(requestString, AddReplenishmentToCartUIRequest.class);
		AddReplenishmentToCartPEGARequest response = CartPegaRequestUtil9.formatAddReplenishmentRequest(uiRequest, new AddReplenishmentToCartPEGARequest());
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
	}
	@Test
	public void formatAffirmPegaRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"cartCreator\": \"cart\",\"processingMTN\": \"mtn\",\"cartId\": \"id\",\"intent\": \"NSE\",\"caseId\": \"case\"},\"data\": {\"lines\": [{}]}}";
		AffirmFinancingUIRequest uiRequest = mapper.readValue(requestString, AffirmFinancingUIRequest.class);
		AffirmFinancingPegaRequest response = CartPegaRequestUtil9.formatAffirmPegaRequest(uiRequest, new AffirmFinancingPegaRequest());
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
	}
	@Test
	public void isXboxInClearCartRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{}";
		ClearCartUIRequest uiRequest = mapper.readValue(requestString, ClearCartUIRequest.class);
		Boolean response = CartPegaRequestUtil9.isXboxInClearCartRequest(uiRequest);
		Assert.assertFalse(response);
	}
	@Test
	public void isXboxInClearCartRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"subscriptionType\": \"GAMINGCONSOLE\",\"processingStep\": \"\"}}";
		ClearCartUIRequest uiRequest = mapper.readValue(requestString, ClearCartUIRequest.class);
		Boolean response = CartPegaRequestUtil9.isXboxInClearCartRequest(uiRequest);
		Assert.assertFalse(response);
	}
	@Test
	public void formatBuyoutUIRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddBuyoutUIRequest response = CartPegaRequestUtil9.formatBuyoutUIRequest(uiRequest);
	}
	@Test
	public void formatBuyoutUIRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"customerConsent\": false},\"data\": {}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddBuyoutUIRequest response = CartPegaRequestUtil9.formatBuyoutUIRequest(uiRequest);
	}
	@Test
	public void formatBuyoutUIRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"customerConsent\": false},\"data\": {\"lines\": []}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddBuyoutUIRequest response = CartPegaRequestUtil9.formatBuyoutUIRequest(uiRequest);
	}
	@Test
	public void formatBuyoutUIRequestTest4() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"customerConsent\": false},\"data\": {\"lines\": [{}]}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddBuyoutUIRequest response = CartPegaRequestUtil9.formatBuyoutUIRequest(uiRequest);
	}
	@Test
	public void formatUpdateAddressChangePEGARequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"apartmentNo\": \"\",\"mtn\": [\"1234\"]}";
		RPSE911AddressUpdateUIRequest uiRequest = mapper.readValue(requestString, RPSE911AddressUpdateUIRequest.class);
		UpdateAddressChangePEGARequest response = CartPegaRequestUtil9.formatUpdateAddressChangePEGARequest("", "", "", uiRequest, new UpdateAddressChangePEGARequest());
		Assert.assertEquals("1234", response.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getMtn());
	}
	@Test
	public void formatAFOPegaRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"itemType\": \"device\",\"processingAction\": \"mtn\",\"cartId\": \"id\",\"intent\": \"NSE\",\"caseId\": \"case\"},\"data\": {\"lines\": [{}]}}";
		AccessoryFinancingOffersUIRequest uiRequest = mapper.readValue(requestString, AccessoryFinancingOffersUIRequest.class);
		AccessoryFinancingOffersPegaRequest response = CartPegaRequestUtil8.formatAFOPegaRequest(uiRequest, new AccessoryFinancingOffersPegaRequest());
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
	}
	@Test
	public void formatAddTrialContactInfoAndAddressPegaRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"itemType\": \"device\",\"processAction\": \"mtn\"},\"data\": {\"channelId\": \"VZW-MFA\",\"isAccountInfoUpdation\": true}}";
		AddTrialContactInfoAndAddressUIRequest uiRequest = mapper.readValue(requestString, AddTrialContactInfoAndAddressUIRequest.class);
		CartPegaRequestUtil8.formatAddTrialContactInfoAndAddressPegaRequest(uiRequest, new AddTrialContactInfoAndAddressPEGARequest(), new CartRedisData());
	}
	@Test
	public void formatAddTrialContactInfoAndAddressPegaRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {},\"data\": {\"trialContactInfo\": {},\"channelId\": \"VZW-MFA\",\"isAccountInfoUpdation\": true}}";
		AddTrialContactInfoAndAddressUIRequest uiRequest = mapper.readValue(requestString, AddTrialContactInfoAndAddressUIRequest.class);
		CartPegaRequestUtil8.formatAddTrialContactInfoAndAddressPegaRequest(uiRequest, new AddTrialContactInfoAndAddressPEGARequest(), new CartRedisData());
	}
	@Test
	public void formatAddTrialContactInfoAndAddressPegaRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {},\"data\": {\"trialContactInfo\": {},\"channelId\": \"VZW-MFA\",\"isAccountInfoUpdation\": false}}";
		AddTrialContactInfoAndAddressUIRequest uiRequest = mapper.readValue(requestString, AddTrialContactInfoAndAddressUIRequest.class);
		CartPegaRequestUtil8.formatAddTrialContactInfoAndAddressPegaRequest(uiRequest, new AddTrialContactInfoAndAddressPEGARequest(), new CartRedisData());
	}
	@Test
	public void formatAddTrialContactInfoAndAddressPegaRequestTest4() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {},\"data\": {\"trialAddress\": {},\"channelId\": \"VZW-MFA\",\"isAccountInfoUpdation\": false}}";
		AddTrialContactInfoAndAddressUIRequest uiRequest = mapper.readValue(requestString, AddTrialContactInfoAndAddressUIRequest.class);
		CartPegaRequestUtil8.formatAddTrialContactInfoAndAddressPegaRequest(uiRequest, new AddTrialContactInfoAndAddressPEGARequest(), new CartRedisData());
	}
	@Test
	public void formatUpdateGiftItemRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"itemType\": \"mobile\",\"caseId\": \"case\"},\"data\": {\"lines\": [{\"sim\": {},\"addAccessories\": []}]}}";
		UpdateGiftItemUIRequest uiRequest = mapper.readValue(requestString, UpdateGiftItemUIRequest.class);
		UpdateGiftItemPEGARequest response = CartPegaRequestUtil8.formatUpdateGiftItemRequest(new UpdateGiftItemPEGARequest(), uiRequest);
		Assert.assertEquals("mobile", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getItemType());
	}
	@Test
	public void formatUpdateGiftItemRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"processStep\": \"promo\",\"caseId\": \"SOF-case\"},\"data\": {\"lines\": [{\"sim\": {},\"addAccessories\": []}]}}";
		UpdateGiftItemUIRequest uiRequest = mapper.readValue(requestString, UpdateGiftItemUIRequest.class);
		UpdateGiftItemPEGARequest response = CartPegaRequestUtil8.formatUpdateGiftItemRequest(new UpdateGiftItemPEGARequest(), uiRequest);
		Assert.assertEquals("Upgrade", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
	}
	@Test
	public void formatCheckExistingCartPegaRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"accountNumber\": \"34567\",\"cartCreator\": \"SOF-case\",\"amRole\": \"am\",\"prospectCartId\": \"id\",\"intendType\": \"NSEACC\"},\"data\": {\"lines\": [{\"sim\": {},\"addAccessories\": []}]}}";
		CheckExistingCartUIRequest uiRequest = mapper.readValue(requestString, CheckExistingCartUIRequest.class);
		CheckExistingCartPEGARequest pegaRequest = new CheckExistingCartPEGARequest();
		CartPegaRequestUtil8.formatCheckExistingCartPegaRequest(uiRequest, pegaRequest);
		Assert.assertEquals("StandAloneAccessory", pegaRequest.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
	}
	@Test
	public void formatGuestChoiceRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"case\",\"processingMTN\": \"mtn\",\"accountNumber\": \"34567\",\"cartCreator\": \"SOF-case\",\"globalId\": \"id\",\"flowType\": \"flow\",\"cartId\": \"cart\",\"intendType\": \"\"},\"data\": {\"lines\": [{\"sim\": {},\"addAccessories\": []}]}}";
		GuestChoiceUIRequest uiRequest = mapper.readValue(requestString, GuestChoiceUIRequest.class);
		GuestChoicePEGARequest pegaRequest = new GuestChoicePEGARequest();
		CartPegaRequestUtil8.formatGuestChoiceRequest(uiRequest, pegaRequest);
		Assert.assertEquals("34567", pegaRequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getAccountNumber());
	}
	@Test
	public void formatGuestChoiceRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"case\",\"processingMTN\": \"mtn\",\"accountNumber\": \"34567\",\"cartCreator\": \"SOF-case\",\"globalId\": \"id\",\"flowType\": \"flow\",\"cartId\": \"cart\",\"intendType\": \"NSE\"},\"data\": {\"lines\": [{\"sim\": {},\"addAccessories\": []}]}}";
		GuestChoiceUIRequest uiRequest = mapper.readValue(requestString, GuestChoiceUIRequest.class);
		GuestChoicePEGARequest pegaRequest = new GuestChoicePEGARequest();
		CartPegaRequestUtil8.formatGuestChoiceRequest(uiRequest, pegaRequest);
		Assert.assertEquals("34567", pegaRequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getAccountNumber());
	}
	@Test
	public void formatGuestChoiceRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"case\",\"processingMTN\": \"mtn\",\"accountNumber\": \"34567\",\"cartCreator\": \"SOF-case\",\"globalId\": \"id\",\"flowType\": \"flow\",\"cartId\": \"cart\",\"intendType\": \"NSEACC\"},\"data\": {\"lines\": [{\"sim\": {},\"addAccessories\": []}]}}";
		GuestChoiceUIRequest uiRequest = mapper.readValue(requestString, GuestChoiceUIRequest.class);
		GuestChoicePEGARequest pegaRequest = new GuestChoicePEGARequest();
		CartPegaRequestUtil8.formatGuestChoiceRequest(uiRequest, pegaRequest);
		Assert.assertEquals("34567", pegaRequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getAccountNumber());
	}
	@Test
	public void formatGuestChoiceRequestTest4() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"intent\": \"NSE\",\"caseId\": \"case\",\"processingMTN\": \"mtn\",\"accountNumber\": \"34567\",\"cartCreator\": \"SOF-case\",\"globalId\": \"id\",\"flowType\": \"flow\",\"cartId\": \"cart\",\"intendType\": \"NSEACC\"},\"data\": {\"lines\": [{\"sim\": {},\"addAccessories\": []}]}}";
		GuestChoiceUIRequest uiRequest = mapper.readValue(requestString, GuestChoiceUIRequest.class);
		GuestChoicePEGARequest pegaRequest = new GuestChoicePEGARequest();
		CartPegaRequestUtil8.formatGuestChoiceRequest(uiRequest, pegaRequest);
		Assert.assertEquals("34567", pegaRequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getAccountNumber());
	}
	@Test
	public void formatCreateCaseRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"case\",\"processingMTN\": \"mtn\",\"accountNumber\": \"34567\",\"cartCreator\": \"SOF-case\",\"globalId\": \"id\",\"flowType\": \"flow\",\"cartId\": \"cart\",\"intendType\": \"\"},\"data\": {\"lines\": [{\"sim\": {},\"addAccessories\": []}]}}";
		CreateCaseAndGetCustomerInfoUIRequest uiRequest = mapper.readValue(requestString, CreateCaseAndGetCustomerInfoUIRequest.class);
		URI url = URI.create("localhost/");
		MockServerHttpRequest header = MockServerHttpRequest.method(HttpMethod.GET, url).header("accountNumber", "456").header("mtn", "7654").build();
		CreateCasePEGARequest response = CartPegaRequestUtil8.formatCreateCaseRequest(new CreateCasePEGARequest(), uiRequest, header);
		Assert.assertEquals("456", response.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getAccountNumber());
	}
	@Test
	public void formatInitiateValidateDeviceSimRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"case\",\"processingMTN\": \"mtn\",\"accountNumber\": \"34567\",\"cartCreator\": \"SOF-case\",\"globalId\": \"id\",\"flowType\": \"flow\",\"cartId\": \"cart\",\"intendType\": \"\"},\"data\": {\"lines\": [{\"sim\": {},\"addAccessories\": []}]}}";
		InitiateValidateDeviceSimUIRequest uiRequest = mapper.readValue(requestString, InitiateValidateDeviceSimUIRequest.class);
		URI url = URI.create("localhost/");
		MockServerHttpRequest header = MockServerHttpRequest.method(HttpMethod.GET, url).header("channelId", "VZW-MFA").header("mtn", "7654").build();
		CartRedisData data = mapper.readValue("{}", CartRedisData.class);
		InitiateValidateDeviceSimPEGARequest response = CartPegaRequestUtil8.formatInitiateValidateDeviceSimRequest(new InitiateValidateDeviceSimPEGARequest(), uiRequest, header, data);
		Assert.assertEquals("7654", response.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCartCreator());
	}
	@Test
	public void formatInitiateValidateDeviceSimRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"case\",\"processingMTN\": \"mtn\",\"accountNumber\": \"34567\",\"cartCreator\": \"SOF-case\",\"globalId\": \"id\",\"flowType\": \"flow\",\"cartId\": \"cart\",\"intendType\": \"\"},\"data\": {\"lines\": [{\"sim\": {},\"addAccessories\": []}]}}";
		InitiateValidateDeviceSimUIRequest uiRequest = mapper.readValue(requestString, InitiateValidateDeviceSimUIRequest.class);
		URI url = URI.create("localhost/");
		MockServerHttpRequest header = MockServerHttpRequest.method(HttpMethod.GET, url).header("channelId", "VZW-MFA").header("mtn", "7654").build();
		CartRedisData data = mapper.readValue("{\"imei\": \"3456\",\"iccId\": \"4567\"}", CartRedisData.class);
		InitiateValidateDeviceSimPEGARequest response = CartPegaRequestUtil8.formatInitiateValidateDeviceSimRequest(new InitiateValidateDeviceSimPEGARequest(), uiRequest, header, data);
		Assert.assertEquals("7654", response.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCartCreator());
	}
	@Test
	public void formatSaveCartWithEmailRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"case\",\"flowType\": \"flow\",\"cartId\": \"cart\",\"intendType\": \"NSE_5G\"},\"data\": {\"lines\": [{\"sim\": {},\"addAccessories\": []}]}}";
		SaveCartWithEmailUIRequest uiRequest = mapper.readValue(requestString, SaveCartWithEmailUIRequest.class);
		AddPlanAndDevicePEGARequest response = CartPegaRequestUtil8.formatSaveCartWithEmailRequest(new AddPlanAndDevicePEGARequest(), uiRequest);
		Assert.assertEquals("SAVECART", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getItemType());
	}
	@Test
	public void formatSaveCartWithEmailRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"flowType\": \"flow\",\"cartId\": \"cart\",\"intendType\": \"NSE_LTE\"},\"data\": {\"lines\": [{\"sim\": {},\"addAccessories\": []}]}}";
		SaveCartWithEmailUIRequest uiRequest = mapper.readValue(requestString, SaveCartWithEmailUIRequest.class);
		AddPlanAndDevicePEGARequest response = CartPegaRequestUtil8.formatSaveCartWithEmailRequest(new AddPlanAndDevicePEGARequest(), uiRequest);
		Assert.assertEquals("SAVECART", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getItemType());
	}
	@Test
	public void formatEffectiveDateRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"flowType\": \"flow\",\"cartId\": \"cart\",\"intendType\": \"\"},\"data\": {\"lines\": [{\"sim\": {},\"addAccessories\": []}]}}";
		UpdateEffectiveDateUIRequest uiRequest = mapper.readValue(requestString, UpdateEffectiveDateUIRequest.class);
		EffectiveDatePEGARequest response = CartPegaRequestUtil8.formatEffectiveDateRequest(new EffectiveDatePEGARequest(), uiRequest);
		Assert.assertEquals("SalesOrderFlex", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getCallReason());
	}
	@Test
	public void formatEffectiveDateRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"case\",\"flowType\": \"flow\",\"cartId\": \"cart\",\"intendType\": \"NSE\"},\"data\": {\"lines\": [{\"sim\": {},\"addAccessories\": []}]}}";
		UpdateEffectiveDateUIRequest uiRequest = mapper.readValue(requestString, UpdateEffectiveDateUIRequest.class);
		EffectiveDatePEGARequest response = CartPegaRequestUtil8.formatEffectiveDateRequest(new EffectiveDatePEGARequest(), uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatEffectiveDateRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"flowType\": \"flow\",\"cartId\": \"cart\",\"intendType\": \"NSEBYOD\"},\"data\": {\"lines\": [{\"sim\": {},\"addAccessories\": []}]}}";
		UpdateEffectiveDateUIRequest uiRequest = mapper.readValue(requestString, UpdateEffectiveDateUIRequest.class);
		EffectiveDatePEGARequest response = CartPegaRequestUtil8.formatEffectiveDateRequest(new EffectiveDatePEGARequest(), uiRequest);
		Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatManualDiscountRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"flowType\": \"flow\",\"cartId\": \"cart\",\"intendType\": \"\"},\"data\": {\"lines\": [{\"sim\": {},\"addAccessories\": []}]}}";
		UpdateManualDiscountUIRequest uiRequest = mapper.readValue(requestString, UpdateManualDiscountUIRequest.class);
		ManualDiscountPEGARequest response = CartPegaRequestUtil8.formatManualDiscountRequest(new ManualDiscountPEGARequest(), uiRequest);
		Assert.assertEquals("SalesOrderFlex", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getCallReason());
	}
	@Test
	public void formatManualDiscountRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"case\",\"flowType\": \"flow\",\"cartId\": \"cart\",\"intendType\": \"NSE\"},\"data\": {\"lines\": [{\"sim\": {},\"addAccessories\": []}]}}";
		UpdateManualDiscountUIRequest uiRequest = mapper.readValue(requestString, UpdateManualDiscountUIRequest.class);
		ManualDiscountPEGARequest response = CartPegaRequestUtil8.formatManualDiscountRequest(new ManualDiscountPEGARequest(), uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatManualDiscountRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"flowType\": \"flow\",\"cartId\": \"cart\",\"intendType\": \"NSEBYOD\"},\"data\": {\"lines\": [{\"sim\": {},\"addAccessories\": []}]}}";
		UpdateManualDiscountUIRequest uiRequest = mapper.readValue(requestString, UpdateManualDiscountUIRequest.class);
		ManualDiscountPEGARequest response = CartPegaRequestUtil8.formatManualDiscountRequest(new ManualDiscountPEGARequest(), uiRequest);
		Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatManualDiscountRequestTest4() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"flowType\": \"flow\",\"cartId\": \"cart\",\"intendType\": \"REX\"},\"data\": {\"lines\": [{\"sim\": {},\"addAccessories\": []}]}}";
		UpdateManualDiscountUIRequest uiRequest = mapper.readValue(requestString, UpdateManualDiscountUIRequest.class);
		ManualDiscountPEGARequest response = CartPegaRequestUtil8.formatManualDiscountRequest(new ManualDiscountPEGARequest(), uiRequest);
		Assert.assertEquals("REX", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatMoversPegaRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\":{\"rylEcpdUrl\":\"ryl\",\"caseId\":\"SOF-case\",\"processStep\":\"orderNow\",\"action\":\"Resume\",\"intendType\":\"EUP_5G\",\"accountNumber\":\"1234567890-00001\"},\"data\":{\"lines\":[]}}";
		AddPlanAndDeviceUIRequest uiRequest = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDevicePEGARequest response = CartPegaRequestUtil7.formatMoversPegaRequest(new AddPlanAndDevicePEGARequest(), uiRequest, false);
	}

	@Test
	public void formatMoversPegaRequest_Omni_Retail_Test() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"OMNI-RETAIL\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"callReason\":\"FiveGMovers\",\"processStep\":\"MoveNow\",\"processAction\":\"initiate\",\"intendType\":\"MOV_5G\",\"bundleInstallType\":\"\",\"enableResume\":\"true\",\"cartCreatorSalesRepId\":\"ENC13\",\"cartCreatorOrderLocationCode\":\"0026301\",\"salesRepUswin\":\"\",\"planChangeRequired\":\"true\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
		AddPlanAndDeviceUIRequest uiRequest = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDevicePEGARequest response = CartPegaRequestUtil7.formatMoversPegaRequest(new AddPlanAndDevicePEGARequest(), uiRequest, true);
		Assert.assertEquals("MoveNow", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getProcessStep());
	}

	@Test
	public void formatMoversPegaRequest_Omni_Retail_Test_false() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"OMNI-RETAIL\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"callReason\":\"FiveGMovers\",\"processStep\":\"MoveNow\",\"processAction\":\"initiate\",\"intendType\":\"MOV_5G\",\"bundleInstallType\":\"\",\"enableResume\":\"true\",\"cartCreatorSalesRepId\":\"ENC13\",\"cartCreatorOrderLocationCode\":\"0026301\",\"salesRepUswin\":\"\",\"planChangeRequired\":\"true\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
		AddPlanAndDeviceUIRequest uiRequest = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDevicePEGARequest response = CartPegaRequestUtil7.formatMoversPegaRequest(new AddPlanAndDevicePEGARequest(), uiRequest, false);
		Assert.assertEquals("MoveNow", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getProcessStep());
	}

	@Test
	public void formatMoversPegaRequest_Omni_Retail_null_cartinfo() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\":{},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
		AddPlanAndDeviceUIRequest uiRequest = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDevicePEGARequest response = CartPegaRequestUtil7.formatMoversPegaRequest(new AddPlanAndDevicePEGARequest(), uiRequest, true);
		Assert.assertNotNull(response);
	}

	@Test
	public void formatAddPlanAndDeviceRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"rylEcpdUrl\": \"ryl\",\"caseId\": \"SOF-case\",\"processStep\": \"orderNow\",\"action\": \"Resume\",\"intendType\": \"EUP_5G\"},\"data\": {\"lines\": []}}";
		AddPlanAndDeviceUIRequest uiRequest = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDevicePEGARequest response = CartPegaRequestUtil8.formatAddPlanAndDeviceRequest(new AddPlanAndDevicePEGARequest(), uiRequest);
		Assert.assertEquals("EUP_5G", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
	}
	@Test
	public void formatAddPlanAndDeviceRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"rylEcpdUrl\": \"ryl\",\"caseId\": \"SOF-case\",\"transactionType\": \"LTE_TO_CBD_UPGRADE\",\"ecpdToken\": \"ecpd\",\"intendType\": \"EUP_5G\"},\"data\": {\"lines\": [{}]},\"cBandData\": {}}";
		AddPlanAndDeviceUIRequest uiRequest = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDevicePEGARequest response = CartPegaRequestUtil8.formatAddPlanAndDeviceRequest(new AddPlanAndDevicePEGARequest(), uiRequest);
		Assert.assertEquals("EUP_5G", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
	}
	@Test
	public void formatAddPlanAndDeviceRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"rylEcpdUrl\": \"ryl\",\"caseId\": \"SOF-case\",\"transactionType\": \"cBand_Technician\",\"ecpdToken\": \"ecpd\",\"intendType\": \"EUP_5G\"},\"data\": {\"lines\": [{\"device\": {},\"e911Address\": {}}]},\"cBandData\": {}}";
		AddPlanAndDeviceUIRequest uiRequest = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDevicePEGARequest response = CartPegaRequestUtil8.formatAddPlanAndDeviceRequest(new AddPlanAndDevicePEGARequest(), uiRequest);
		Assert.assertEquals("EUP_5G", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
	}
	@Test
	public void formatAddPlanAndDeviceRequestTest4() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"fiveGMUCEligible\": \"ryl\",\"caseId\": \"SOF-case\",\"transactionType\": \"cBand_Technician\",\"ecpdToken\": \"ecpd\",\"intendType\": \"NSE_LTE\"},\"cBandData\": {},\"data\": {\"lines\": [{\"device\": {},\"e911Address\": {},\"preOrderInServiceDate\": \"date\"}]}}";
		AddPlanAndDeviceUIRequest uiRequest = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDevicePEGARequest response = CartPegaRequestUtil8.formatAddPlanAndDeviceRequest(new AddPlanAndDevicePEGARequest(), uiRequest);
		Assert.assertEquals("NSE_LTE", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
	}
	@Test
	public void formatAddPlanAndDeviceRequestTest5() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"fiveGMUCEligible\": \"ryl\",\"caseId\": \"SOF-case\",\"transactionType\": \"cBand_Technician\",\"ecpdToken\": \"ecpd\",\"intendType\": \"NSE_LTE\"},\"cBandData\": {},\"data\": {}}";
		AddPlanAndDeviceUIRequest uiRequest = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDevicePEGARequest response = CartPegaRequestUtil8.formatAddPlanAndDeviceRequest(new AddPlanAndDevicePEGARequest(), uiRequest);
		Assert.assertEquals("NSE_LTE", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
	}
	@Test
	public void formatAddPlanAndDeviceRequestTest6() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"clientAppName\": \"VZW-DOTCOM\",\"processStep\": \"OrderNow\",\"processAction\": \"DeviceAndPlan\",\"action\": \"Restart\",\"intendType\": \"NSE_5G\",\"isSequentialComboOrder\": \"true\",\"bundleInstallType\": \"Gen4-5G-Home-Internet-Self-Setup\"},\"data\": {}}";
		AddPlanAndDeviceUIRequest uiRequest = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDevicePEGARequest response = CartPegaRequestUtil8.formatAddPlanAndDeviceRequest(new AddPlanAndDevicePEGARequest(), uiRequest);
		Assert.assertEquals("NSE_5G", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
	}
	@Test
	public void formatAddPlanAndDeviceRequestTest_Redemption() throws JsonMappingException, JsonProcessingException {
		String requestString = "{ \"cartInfo\": { \"clientAppName\": \"VZW-DOTCOM\", \"cartId\": \"\", \"caseId\": \"\", \"accountNumber\": \"00001\", \"cartCreator\": \"\", \"processingMTN\": \"0123456789\", \"processStep\": \"Initiate\", \"processAction\": \"\", \"intendType\": \"ACC\", \"enableResume\": \"false\", \"flowType\": \"WHW_Redemption\" } }";
		AddPlanAndDeviceUIRequest uiRequest = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDevicePEGARequest response = CartPegaRequestUtil8.formatAddPlanAndDeviceRequest(new AddPlanAndDevicePEGARequest(), uiRequest);
		Assert.assertEquals("Initiate", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getProcessStep());
	}
	@Test
	public void formatAddPlanAndDeviceRequestTest7() throws JsonMappingException, JsonProcessingException {
		String requestString = "{ \"cartInfo\": { \"clientAppName\": \"VZW-DOTCOM\", \"cartId\": \"\", \"caseId\": \"\", \"accountNumber\": \"\", \"cartCreator\": \"\", \"processingMTN\": \"\", \"processStep\": \"OrderNow\", \"processAction\": \"DeviceAndPlan\", \"intendType\": \"NSE_5G\", \"jointCombo\": \"Y\", \"bundleInstallType\": \"Gen4-5G-Home-Internet-Self-Setup\", \"enableResume\": \"false\" }, \"data\": { \"lines\": [ { \"depletionType\": \"F\" ,  \"mtn\": \"\" } ] } }";
		AddPlanAndDeviceUIRequest uiRequest = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDevicePEGARequest response = CartPegaRequestUtil8.formatAddPlanAndDeviceRequest(new AddPlanAndDevicePEGARequest(), uiRequest);
		Assert.assertEquals("NSE_5G", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
	}
	@Test
	public void formatUpdateSellerPriceRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"processStep\": \"\",\"action\": \"Resume\",\"intendType\": \"\"},\"data\": {\"lines\": []}}";
		UpdateSellerPriceUIRequestNew uiRequest = mapper.readValue(requestString, UpdateSellerPriceUIRequestNew.class);
		UpdateSellerPricePEGARequest response = CartPegaRequestUtil7.formatUpdateSellerPriceRequest(new UpdateSellerPricePEGARequest(), uiRequest);
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatUpdateSellerPriceRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"case\",\"processStep\": \"\",\"action\": \"Resume\",\"intendType\": \"REX\"},\"data\": {\"lines\": []}}";
		UpdateSellerPriceUIRequestNew uiRequest = mapper.readValue(requestString, UpdateSellerPriceUIRequestNew.class);
		UpdateSellerPricePEGARequest response = CartPegaRequestUtil7.formatUpdateSellerPriceRequest(new UpdateSellerPricePEGARequest(), uiRequest);
		Assert.assertEquals("REX", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatUpdateSellerPriceRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"case\",\"processStep\": \"\",\"action\": \"Resume\",\"intendType\": \"NSEBYOD\"},\"data\": {\"lines\": []}}";
		UpdateSellerPriceUIRequestNew uiRequest = mapper.readValue(requestString, UpdateSellerPriceUIRequestNew.class);
		UpdateSellerPricePEGARequest response = CartPegaRequestUtil7.formatUpdateSellerPriceRequest(new UpdateSellerPricePEGARequest(), uiRequest);
		Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatUpdateSellerPriceRequestTest4() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"processStep\": \"\",\"action\": \"Resume\",\"intendType\": \"NSE\"},\"data\": {\"lines\": []}}";
		UpdateSellerPriceUIRequestNew uiRequest = mapper.readValue(requestString, UpdateSellerPriceUIRequestNew.class);
		UpdateSellerPricePEGARequest response = CartPegaRequestUtil7.formatUpdateSellerPriceRequest(new UpdateSellerPricePEGARequest(), uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatUpdateSellerPriceRequestTest5() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"OMNI-INDIRECT\",\"cartInfo\": {\"caseId\": \"case\",\"processStep\": \"\",\"action\": \"Resume\",\"intendType\": \"REX\"},\"data\": {\"lines\": []}}";
		UpdateSellerPriceUIRequestNew uiRequest = mapper.readValue(requestString, UpdateSellerPriceUIRequestNew.class);
		UpdateSellerPricePEGARequest response = CartPegaRequestUtil7.formatUpdateSellerPriceRequest(new UpdateSellerPricePEGARequest(), uiRequest);
		Assert.assertEquals("REX", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatUpdateSellerPriceRequestTest6() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"OMNI-INDIRECT-TAB\",\"cartInfo\": {\"caseId\": \"case\",\"processStep\": \"\",\"action\": \"Resume\",\"intendType\": \"REX\"},\"data\": {\"lines\": []}}";
		UpdateSellerPriceUIRequestNew uiRequest = mapper.readValue(requestString, UpdateSellerPriceUIRequestNew.class);
		UpdateSellerPricePEGARequest response = CartPegaRequestUtil7.formatUpdateSellerPriceRequest(new UpdateSellerPricePEGARequest(), uiRequest);
		Assert.assertEquals("REX", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatUpdateSellerPriceRequestTest7() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"OMNI-CARE\",\"cartInfo\": {\"caseId\": \"case\",\"processStep\": \"\",\"action\": \"Resume\",\"intendType\": \"REX\"},\"data\": {\"lines\": []}}";
		UpdateSellerPriceUIRequestNew uiRequest = mapper.readValue(requestString, UpdateSellerPriceUIRequestNew.class);
		UpdateSellerPricePEGARequest response = CartPegaRequestUtil7.formatUpdateSellerPriceRequest(new UpdateSellerPricePEGARequest(), uiRequest);
		Assert.assertEquals("REX", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatRemoveBvoOffersRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"processStep\": \"promo\",\"action\": \"Resume\",\"intendType\": \"EUP\"},\"data\": {\"lines\": []}}";
		UpdateBvoOffersUIRequest uiRequest = mapper.readValue(requestString, UpdateBvoOffersUIRequest.class);
		UpdateBvoOffersPEGARequest response = CartPegaRequestUtil7.formatRemoveBvoOffersRequest(new UpdateBvoOffersPEGARequest(), uiRequest);
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatRemoveBvoOffersRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"case\",\"processStep\": \"promo\",\"intendType\": \"NSE\"},\"data\": {\"lines\": []}}";
		UpdateBvoOffersUIRequest uiRequest = mapper.readValue(requestString, UpdateBvoOffersUIRequest.class);
		UpdateBvoOffersPEGARequest response = CartPegaRequestUtil7.formatRemoveBvoOffersRequest(new UpdateBvoOffersPEGARequest(), uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatRemoveBvoOffersRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"processStep\": \"promo\",\"intendType\": \"NSE\"},\"data\": {\"lines\": []}}";
		UpdateBvoOffersUIRequest uiRequest = mapper.readValue(requestString, UpdateBvoOffersUIRequest.class);
		UpdateBvoOffersPEGARequest response = CartPegaRequestUtil7.formatRemoveBvoOffersRequest(new UpdateBvoOffersPEGARequest(), uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatRetrieveActivationStatusRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"processStep\": \"promo\",\"sessionId\": \"session\",\"accountNumber\": \"4567\",\"mtnFlow\": \"mtn\",\"creditAppNum\": \"credit\",\"intendType\": \"NSE\"},\"data\": {\"lines\": []}}";
		RetrieveActivationStatusUIRequest uiRequest = mapper.readValue(requestString, RetrieveActivationStatusUIRequest.class);
		RetrieveActivationStatusPEGARequest response = CartPegaRequestUtil7.formatRetrieveActivationStatusRequest(new RetrieveActivationStatusPEGARequest(), uiRequest);
		Assert.assertEquals("SalesOrderFlex", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getCallReason());
	}
	@Test
	public void formatRetrieveActivationStatusRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"case\",\"globalId\": \"global\",\"cartCreator\":\"cart\",\"processStep\": \"promo\",\"sessionId\": \"session\",\"accountNumber\": \"4567\",\"mtnflow\": \"mtn\",\"creditAppNum\": \"credit\",\"intendType\": \"EUP\"},\"data\": {\"lines\": []}}";
		RetrieveActivationStatusUIRequest uiRequest = mapper.readValue(requestString, RetrieveActivationStatusUIRequest.class);
		RetrieveActivationStatusPEGARequest response = CartPegaRequestUtil7.formatRetrieveActivationStatusRequest(new RetrieveActivationStatusPEGARequest(), uiRequest);
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
	}
	@Test
	public void formatRetrieveActivationStatusRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"processStep\": \"promo\",\"sessionId\": \"session\",\"accountNumber\": \"4567\",\"mtnflow\": \"mtn\",\"creditAppNum\": \"credit\",\"intendType\": \"EUP\"},\"data\": {\"lines\": []}}";
		RetrieveActivationStatusUIRequest uiRequest = mapper.readValue(requestString, RetrieveActivationStatusUIRequest.class);
		RetrieveActivationStatusPEGARequest response = CartPegaRequestUtil7.formatRetrieveActivationStatusRequest(new RetrieveActivationStatusPEGARequest(), uiRequest);
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
	}
	@Test
	public void formatbbpGetProcessStepRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"deviceType\": \"mobile\",\"customerType\": \"regular\",\"accountNumber\": \"4567\",\"mtnFlow\": \"mtn\",\"creditAppNum\": \"credit\",\"intendType\": \"NSE\"},\"data\": {\"lines\": []}}";
		BBPGetProcessStepUIRequest uiRequest = mapper.readValue(requestString, BBPGetProcessStepUIRequest.class);
		BBPGetProcessStepPEGARequest response = CartPegaRequestUtil7.formatbbpGetProcessStepRequest(new BBPGetProcessStepPEGARequest(), uiRequest);
		Assert.assertEquals("BYOD", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
	}
	@Test
	public void formatbbpGetProcessStepRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"case\",\"deviceType\": \"mobile\",\"customerType\": \"regular\",\"accountNumber\": \"4567\",\"mtnFlow\": \"mtn\",\"creditAppNum\": \"credit\",\"intendType\": \"NSE\"},\"data\": {\"lines\": []}}";
		BBPGetProcessStepUIRequest uiRequest = mapper.readValue(requestString, BBPGetProcessStepUIRequest.class);
		BBPGetProcessStepPEGARequest response = CartPegaRequestUtil7.formatbbpGetProcessStepRequest(new BBPGetProcessStepPEGARequest(), uiRequest);
		Assert.assertEquals("BYOD", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
	}
	@Test
	public void formatbbpGetProcessStepRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"deviceType\": \"\",\"customerType\": \"N\",\"accountNumber\": \"4567\",\"mtnFlow\": \"mtn\",\"creditAppNum\": \"credit\",\"intendType\": \"NSE\"},\"data\": {\"lines\": []}}";
		BBPGetProcessStepUIRequest uiRequest = mapper.readValue(requestString, BBPGetProcessStepUIRequest.class);
		BBPGetProcessStepPEGARequest response = CartPegaRequestUtil7.formatbbpGetProcessStepRequest(new BBPGetProcessStepPEGARequest(), uiRequest);
		Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
	}
	@Test
	public void formatSalesOrderAdjustmentRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"refundOrderdetails\": {},\"cartInfo\": {\"caseId\": \"SOF-case\",\"itemType\": \"mobile\",\"checkAutoPayDiscountEligible\": \"yes\",\"accountNumber\": \"4567\",\"processAction\": \"mtn\",\"processStep\": \"credit\",\"intendType\": \"\"}}";
		SalesOrderAdjustmentUIRequest uiRequest = mapper.readValue(requestString, SalesOrderAdjustmentUIRequest.class);
		uiRequest.setRefundOrderdetails(new SalesOrderAdjustmentOrderDetails());
		setRefundOrderdetails(uiRequest);
		SalesOrderAdjustmentPEGARequest response = CartPegaRequestUtil7.formatSalesOrderAdjustmentRequest(new SalesOrderAdjustmentPEGARequest(), uiRequest);
		Assert.assertEquals("mobile", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getItemType());
	}
	@Test
	public void formatSalesOrderAdjustmentRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"refundOrderdetails\": {},\"cartInfo\": {\"caseId\": \"case\",\"itemType\": \"FMIcheck\",\"checkAutoPayDiscountEligible\": \"yes\",\"accountNumber\": \"4567\",\"processAction\": \"mtn\",\"processStep\": \"credit\",\"intendType\": \"\"}}";
		SalesOrderAdjustmentUIRequest uiRequest = mapper.readValue(requestString, SalesOrderAdjustmentUIRequest.class);
		uiRequest.setRefundOrderdetails(new SalesOrderAdjustmentOrderDetails());
		setRefundOrderdetails(uiRequest);
		SalesOrderAdjustmentPEGARequest response = CartPegaRequestUtil7.formatSalesOrderAdjustmentRequest(new SalesOrderAdjustmentPEGARequest(), uiRequest);
		Assert.assertEquals("FMICheck", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getItemType());
	}
	@Test
	public void formatSalesOrderAdjustmentRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"refundOrderdetails\": {},\"cartInfo\": {\"itemType\": \"FMI-OVERRIDE\",\"password\": \"yes\",\"comments\": \"4567\",\"processAction\": \"mtn\",\"processStep\": \"credit\",\"intendType\": \"\"}}";
		SalesOrderAdjustmentUIRequest uiRequest = mapper.readValue(requestString, SalesOrderAdjustmentUIRequest.class);
		uiRequest.setRefundOrderdetails(new SalesOrderAdjustmentOrderDetails());
		setRefundOrderdetails(uiRequest);
		SalesOrderAdjustmentPEGARequest response = CartPegaRequestUtil7.formatSalesOrderAdjustmentRequest(new SalesOrderAdjustmentPEGARequest(), uiRequest);
		Assert.assertEquals("FMI-OVERRIDE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getItemType());
	}
	@Test
	public void formatSalesOrderAdjustmentRequestTest4() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"refundOrderdetails\": {},\"cartInfo\": {\"itemType\": \"FMI-OVERRIDE\",\"parentMtn\": \"yes\",\"managerId\": \"4567\",\"processAction\": \"mtn\",\"processStep\": \"credit\",\"intendType\": \"\"}}";
		SalesOrderAdjustmentUIRequest uiRequest = mapper.readValue(requestString, SalesOrderAdjustmentUIRequest.class);
		uiRequest.setRefundOrderdetails(new SalesOrderAdjustmentOrderDetails());
		setRefundOrderdetails(uiRequest);
		SalesOrderAdjustmentPEGARequest response = CartPegaRequestUtil7.formatSalesOrderAdjustmentRequest(new SalesOrderAdjustmentPEGARequest(), uiRequest);
		Assert.assertEquals("FMI-OVERRIDE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getItemType());
	}
	@Test
	public void formatSalesOrderAdjustmentRequestTest5() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"refundOrderdetails\": {},\"cartInfo\": {\"parentMtn\": \"yes\",\"managerId\": \"4567\",\"processAction\": \"mtn\",\"processStep\": \"credit\",\"intendType\": \"NSE\",\"intent\": \"NSE\"}}";
		SalesOrderAdjustmentUIRequest uiRequest = mapper.readValue(requestString, SalesOrderAdjustmentUIRequest.class);
		uiRequest.setRefundOrderdetails(new SalesOrderAdjustmentOrderDetails());
		setRefundOrderdetails(uiRequest);
		SalesOrderAdjustmentPEGARequest response = CartPegaRequestUtil7.formatSalesOrderAdjustmentRequest(new SalesOrderAdjustmentPEGARequest(), uiRequest);
		Assert.assertEquals("RFEX", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getItemType());
	}
	@Test
	public void formatSalesOrderAdjustmentRequestTest6() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"refundOrderdetails\": {},\"cartInfo\": {\"parentMtn\": \"yes\",\"managerId\": \"4567\",\"processAction\": \"\",\"processStep\": \"\",\"intendType\": \"\"}}";
		SalesOrderAdjustmentUIRequest uiRequest = mapper.readValue(requestString, SalesOrderAdjustmentUIRequest.class);
		uiRequest.setRefundOrderdetails(new SalesOrderAdjustmentOrderDetails());
		setRefundOrderdetails(uiRequest);
		SalesOrderAdjustmentPEGARequest response = CartPegaRequestUtil7.formatSalesOrderAdjustmentRequest(new SalesOrderAdjustmentPEGARequest(), uiRequest);
		Assert.assertEquals("RFEX", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getItemType());
	}
	@Test
	public void formatAccountPinRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"sessionId\": \"session\",\"mtnFlow\": \"4567\",\"creditAppNum\": \"4567\",\"intendType\": \"\"},\"data\": {}}";
		AccountPinUIRequest uiRequest = mapper.readValue(requestString, AccountPinUIRequest.class);
		AccountPinPEGARequest response = CartPegaRequestUtil7.formatAccountPinRequest(new AccountPinPEGARequest(), uiRequest);
		Assert.assertEquals("SalesOrderFlex", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getCallReason());
	}
	@Test
	public void formatAccountPinRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"case\",\"sessionId\": \"session\",\"globalId\": \"4567\",\"cartCreator\": \"4567\",\"intendType\": \"\"},\"data\": {\"cradleFlowJourney\": \"cradle\"}}";
		AccountPinUIRequest uiRequest = mapper.readValue(requestString, AccountPinUIRequest.class);
		AccountPinPEGARequest response = CartPegaRequestUtil7.formatAccountPinRequest(new AccountPinPEGARequest(), uiRequest);
		Assert.assertEquals("SalesOrderPurchase", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getCallReason());
	}
	@Test
	public void formatAccountPinRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"mtnFlow\": \"4567\",\"customerType\": \"N\",\"intendType\": \"\"},\"data\": {\"throttleList\": \"throttle\",\"bucketAllocator\": \"flow\"}}";
		AccountPinUIRequest uiRequest = mapper.readValue(requestString, AccountPinUIRequest.class);
		AccountPinPEGARequest response = CartPegaRequestUtil7.formatAccountPinRequest(new AccountPinPEGARequest(), uiRequest);
		Assert.assertEquals("SalesOrderPurchase", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getCallReason());
	}
	@Test
	public void formatUpdateWFMInfoRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"intent\": \"EUP\",\"intendType\": \"EUP\"},\"data\": {}}";
		UpdateWFMInfoUIRequest uiRequest = mapper.readValue(requestString, UpdateWFMInfoUIRequest.class);
		UpdateWFMInfoPEGARequest response = CartPegaRequestUtil7.formatUpdateWFMInfoRequest(new UpdateWFMInfoPEGARequest(), uiRequest);
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
	}
	@Test
	public void formatClearCartRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"VZW-MFA\",\"cartInfo\": {\"caseId\": \"SOF-case\",\"processAction\": \"cart\",\"expressCheckout\": false,\"intendType\": \"NSE_LTE\"},\"data\": {}}";
		ClearCartUIRequest uiRequest = mapper.readValue(requestString, ClearCartUIRequest.class);
		ClearCartPEGARequest response = CartPegaRequestUtil7.formatClearCartRequest(new ClearCartPEGARequest(), uiRequest, true);
		Assert.assertEquals("NSE_LTE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatClearCartRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"VZW-MFA\",\"cartInfo\": {\"caseId\": \"case\",\"processAction\": \"cart\",\"expressCheckout\": true,\"intendType\": \"REX\"},\"data\": {}}";
		ClearCartUIRequest uiRequest = mapper.readValue(requestString, ClearCartUIRequest.class);
		ClearCartPEGARequest response = CartPegaRequestUtil7.formatClearCartRequest(new ClearCartPEGARequest(), uiRequest, true);
		Assert.assertEquals("REX", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatClearCartRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"VZW-MFA\",\"cartInfo\": {\"expressCheckout\": true,\"intendType\": \"\"},\"data\": {}}";
		ClearCartUIRequest uiRequest = mapper.readValue(requestString, ClearCartUIRequest.class);
		ClearCartPEGARequest response = CartPegaRequestUtil7.formatClearCartRequest(new ClearCartPEGARequest(), uiRequest, true);
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatClearCartRequestTest4() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"VZW-MFA\",\"cartInfo\": {\"expressCheckout\": true,\"intendType\": \"NSEBYOD\"},\"data\": {}}";
		ClearCartUIRequest uiRequest = mapper.readValue(requestString, ClearCartUIRequest.class);
		ClearCartPEGARequest response = CartPegaRequestUtil7.formatClearCartRequest(new ClearCartPEGARequest(), uiRequest, true);
		Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatClearCartRequestTest5() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"VZW-MFA\",\"cartInfo\": {\"expressCheckout\": true,\"intendType\": \"NSEACC\"},\"rfexExchangeShopDetails\": {}}";
		ClearCartUIRequest uiRequest = mapper.readValue(requestString, ClearCartUIRequest.class);
		ClearCartPEGARequest response = CartPegaRequestUtil7.formatClearCartRequest(new ClearCartPEGARequest(), uiRequest, true);
		Assert.assertEquals("NSEACC", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatClearCartRequestTest6() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"VZW-MFA\",\"cartInfo\": {\"expressCheckout\": true,\"intendType\": \"REX\"},\"rfexExchangeShopDetails\": {}}";
		ClearCartUIRequest uiRequest = mapper.readValue(requestString, ClearCartUIRequest.class);
		ClearCartPEGARequest response = CartPegaRequestUtil7.formatClearCartRequest(new ClearCartPEGARequest(), uiRequest, true);
		Assert.assertEquals("REX", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatClearCartRequestTest7() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"VZW-MFA\",\"cartInfo\": {\"expressCheckout\": true,\"intendType\": \"REX\"},\"rfexExchangeShopDetails\": {\"mtn\": \"mtn\"}}";
		ClearCartUIRequest uiRequest = mapper.readValue(requestString, ClearCartUIRequest.class);
		ClearCartPEGARequest response = CartPegaRequestUtil7.formatClearCartRequest(new ClearCartPEGARequest(), uiRequest, true);
		Assert.assertEquals("REX", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatClearCartRequestTest8() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"VZW-MFA\",\"data\": {},\"cartInfo\": {\"expressCheckout\": true,\"intendType\": \"REX\"},\"rfexExchangeShopDetails\": {\"mtn\": \"mtn\"}}";
		ClearCartUIRequest uiRequest = mapper.readValue(requestString, ClearCartUIRequest.class);
		ClearCartPEGARequest response = CartPegaRequestUtil7.formatClearCartRequest(new ClearCartPEGARequest(), uiRequest, true);
		Assert.assertEquals("REX", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatClearCartRequestTest9() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"VZW-MFA\",\"data\": {\"lines\": [{}]},\"cartInfo\": {\"expressCheckout\": true,\"intendType\": \"REX\"},\"rfexExchangeShopDetails\": {\"mtn\": \"mtn\"}}";
		ClearCartUIRequest uiRequest = mapper.readValue(requestString, ClearCartUIRequest.class);
		ClearCartPEGARequest response = CartPegaRequestUtil7.formatClearCartRequest(new ClearCartPEGARequest(), uiRequest, true);
		Assert.assertEquals("REX", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatClearCartRequestTest10() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"VZW-MFA\",\"data\": {\"lines\": [{}]},\"cartInfo\": {\"expressCheckout\": true,\"intendType\": \"NSE\"},\"rfexExchangeShopDetails\": {\"mtn\": \"mtn\"}}";
		ClearCartUIRequest uiRequest = mapper.readValue(requestString, ClearCartUIRequest.class);
		ClearCartPEGARequest response = CartPegaRequestUtil7.formatClearCartRequest(new ClearCartPEGARequest(), uiRequest, true);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatSaveCartForLaterRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"processAction\": \"\",\"globalId\": \"global\",\"saveCartEmailId\": \"NSE_LTE\"},\"data\": {}}";
		SaveCartForLaterUIRequest uiRequest = mapper.readValue(requestString, SaveCartForLaterUIRequest.class);
		SaveCartPEGARequest response = CartPegaRequestUtil6.formatSaveCartForLaterRequest(new SaveCartPEGARequest(), uiRequest);
		Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatSaveCartForLaterRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"case\",\"processAction\": \"saveForLater\",\"globalId\": \"global\",\"intendType\": \"NSE\"},\"data\": {\"lines\": []}}";
		SaveCartForLaterUIRequest uiRequest = mapper.readValue(requestString, SaveCartForLaterUIRequest.class);
		SaveCartPEGARequest response = CartPegaRequestUtil6.formatSaveCartForLaterRequest(new SaveCartPEGARequest(), uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatSaveCartForLaterRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"processAction\": \"removeSaveForLater\",\"processStep\": \"global\",\"intendType\": \"NSE\"},\"data\": {\"lines\": [{}]}}";
		SaveCartForLaterUIRequest uiRequest = mapper.readValue(requestString, SaveCartForLaterUIRequest.class);
		SaveCartPEGARequest response = CartPegaRequestUtil6.formatSaveCartForLaterRequest(new SaveCartPEGARequest(), uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatSaveCartForLaterRequestTest4() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"processAction\": \"remove\",\"intendType\": \"NSE\"},\"data\": {\"lines\": [{}]}}";
		SaveCartForLaterUIRequest uiRequest = mapper.readValue(requestString, SaveCartForLaterUIRequest.class);
		SaveCartPEGARequest response = CartPegaRequestUtil6.formatSaveCartForLaterRequest(new SaveCartPEGARequest(), uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatGetCaseRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"quoteId\": \"quote\",\"cartInfo\": {\"caseId\": \"SOF-case\",\"processAction\": \"\",\"globalId\": \"global\",\"saveCartEmailId\": \"NSE_LTE\"},\"data\": {}}";
		GetCaseRequest uiRequest = mapper.readValue(requestString, GetCaseRequest.class);
		GetCasePEGARequest response = CartPegaRequestUtil6.formatGetCaseRequest(new GetCasePEGARequest(), uiRequest);
		Assert.assertEquals("SalesOrderPurchase", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getCallReason());
	}
	@Test
	public void formatUpdateChatIdRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"sessionId\": \"session\",\"globalId\": \"global\",\"cartCreator\": \"cart\",\"intendType\": \"NSE\"},\"data\": {}}";
		UpdateChatIdUIRequest uiRequest = mapper.readValue(requestString, UpdateChatIdUIRequest.class);
		UpdateChatIdPEGARequest response = CartPegaRequestUtil6.formatUpdateChatIdRequest(new UpdateChatIdPEGARequest(), uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatUpdateChatIdRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"referralVendorId\": \"vendor\",\"rylEcpdUrl\": \"ryl\",\"referralSaleRepId\": \"refferal\",\"isEQPandPPLOfferApplied\": true,\"registerNumber\": 3,\"salesRepUswin\": \"sales\",\"ecpdToken\": \"ecpd\",\"throttleList\": \"throttle\",\"chatId\": \"chat\",\"standaloneBYOD\": true,\"amRole\": \"am\",\"bucketAllocator\": \"bucket\",\"caseId\": \"case\",\"editFromPage\": \"edit\",\"accountType\": \"global\",\"intendType\": \"NSE_5G\"},\"data\": {}}";
		UpdateChatIdUIRequest uiRequest = mapper.readValue(requestString, UpdateChatIdUIRequest.class);
		UpdateChatIdPEGARequest response = CartPegaRequestUtil6.formatUpdateChatIdRequest(new UpdateChatIdPEGARequest(), uiRequest);
		Assert.assertEquals("NSE_5G", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatUpdateChatIdRequestTes3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"sessionId\": \"global\",\"intendType\": \"AAL\"},\"data\": {}}";
		UpdateChatIdUIRequest uiRequest = mapper.readValue(requestString, UpdateChatIdUIRequest.class);
		UpdateChatIdPEGARequest response = CartPegaRequestUtil6.formatUpdateChatIdRequest(new UpdateChatIdPEGARequest(), uiRequest);
		Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddNickNameRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"globalId\": \"global\",\"intendType\": \"NSE\"},\"data\": {}}";
		AddNickNameUIRequest uiRequest = mapper.readValue(requestString, AddNickNameUIRequest.class);
		AddNickNamePEGARequest response = CartPegaRequestUtil6.formatAddNickNameRequest(new AddNickNamePEGARequest(), uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddNickNameRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"globalId\": \"global\",\"intendType\": \"NSEBYOD\"},\"data\": {}}";
		AddNickNameUIRequest uiRequest = mapper.readValue(requestString, AddNickNameUIRequest.class);
		AddNickNamePEGARequest response = CartPegaRequestUtil6.formatAddNickNameRequest(new AddNickNamePEGARequest(), uiRequest);
		Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatRemoveTransferUpgradeRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"globalId\": \"global\",\"intendType\": \"NSE\"},\"data\": {\"lines\": [{}]}}";
		UpdateTransferUpgradeUIRequest uiRequest = mapper.readValue(requestString, UpdateTransferUpgradeUIRequest.class);
		UpdateTransferUpgradePEGARequest response = CartPegaRequestUtil6.formatRemoveTransferUpgradeRequest(new UpdateTransferUpgradePEGARequest(), uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatRemoveTransferUpgradeRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"case\",\"globalId\": \"global\",\"intendType\": \"\"},\"data\": {\"lines\": [{}]}}";
		UpdateTransferUpgradeUIRequest uiRequest = mapper.readValue(requestString, UpdateTransferUpgradeUIRequest.class);
		UpdateTransferUpgradePEGARequest response = CartPegaRequestUtil6.formatRemoveTransferUpgradeRequest(new UpdateTransferUpgradePEGARequest(), uiRequest);
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatRemoveTransferUpgradeRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"processAction\": \"global\",\"intendType\": \"NSE\"},\"data\": {\"lines\": [{}]}}";
		UpdateTransferUpgradeUIRequest uiRequest = mapper.readValue(requestString, UpdateTransferUpgradeUIRequest.class);
		UpdateTransferUpgradePEGARequest response = CartPegaRequestUtil6.formatRemoveTransferUpgradeRequest(new UpdateTransferUpgradePEGARequest(), uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddTransferUpgradeRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"globalId\": \"global\",\"intendType\": \"NSE\"},\"data\": {\"lines\": [{}]}}";
		UpdateTransferUpgradeUIRequest uiRequest = mapper.readValue(requestString, UpdateTransferUpgradeUIRequest.class);
		UpdateTransferUpgradePEGARequest response = CartPegaRequestUtil6.formatAddTransferUpgradeRequest(new UpdateTransferUpgradePEGARequest(), uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddTransferUpgradeRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"case\",\"globalId\": \"global\",\"intendType\": \"\"},\"data\": {\"lines\": [{}]}}";
		UpdateTransferUpgradeUIRequest uiRequest = mapper.readValue(requestString, UpdateTransferUpgradeUIRequest.class);
		UpdateTransferUpgradePEGARequest response = CartPegaRequestUtil6.formatAddTransferUpgradeRequest(new UpdateTransferUpgradePEGARequest(), uiRequest);
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddTransferUpgradeRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"processAction\": \"global\",\"intendType\": \"NSE\"},\"data\": {\"lines\": [{}]}}";
		UpdateTransferUpgradeUIRequest uiRequest = mapper.readValue(requestString, UpdateTransferUpgradeUIRequest.class);
		UpdateTransferUpgradePEGARequest response = CartPegaRequestUtil6.formatAddTransferUpgradeRequest(new UpdateTransferUpgradePEGARequest(), uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formAddAccessoryRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"lines\": [{}]}";
		CartRedisData uiRequest = mapper.readValue(requestString, CartRedisData.class);
		AddAccessoriesUIRequest response = CartPegaRequestUtil6.formAddAccessoryRequest(uiRequest, "", "");
		Assert.assertNull("NSE", response.getCartInfo());
	}
	@Test
	public void formatResumeAndContinueRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"globalId\": \"global\",\"intendType\": \"NSE\"},\"data\": {\"lines\": [{}]}}";
		ResumeAndContinueUIRequest uiRequest = mapper.readValue(requestString, ResumeAndContinueUIRequest.class);
		ResumeAndContinuePegaRequest response = CartPegaRequestUtil6.formatResumeAndContinueRequest(new ResumeAndContinuePegaRequest(), uiRequest);
		Assert.assertEquals("RESUME", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getItemType());
	}
	@Test
	public void formatResumeAndContinueRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"case\",\"salesRepId\": \"global\",\"intendType\": \"NSE\"},\"data\": {\"lines\": [{}]}}";
		ResumeAndContinueUIRequest uiRequest = mapper.readValue(requestString, ResumeAndContinueUIRequest.class);
		ResumeAndContinuePegaRequest response = CartPegaRequestUtil6.formatResumeAndContinueRequest(new ResumeAndContinuePegaRequest(), uiRequest);
		Assert.assertEquals("RESUME", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getItemType());
	}
	@Test
	public void formatResumeAndContinueRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"flowType\": \"global\",\"intendType\": \"NSE\"},\"data\": {\"lines\": [{}]}}";
		ResumeAndContinueUIRequest uiRequest = mapper.readValue(requestString, ResumeAndContinueUIRequest.class);
		ResumeAndContinuePegaRequest response = CartPegaRequestUtil6.formatResumeAndContinueRequest(new ResumeAndContinuePegaRequest(), uiRequest);
		Assert.assertEquals("RESUME", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getItemType());
	}
	@Test
	public void formatClearandResumeRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"prospectCartId\": \"global\",\"intendType\": \"NSE\"},\"data\": {\"lines\": [{}]}}";
		ClearAndContinueUIRequest uiRequest = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
		ClearAndContinuePegaRequest response = CartPegaRequestUtil6.formatClearandResumeRequest(new ClearAndContinuePegaRequest(), uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatClearandResumeRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"case\",\"salesRepId\": \"global\",\"intendType\": \"AAL\"},\"data\": {\"lines\": [{}]}}";
		ClearAndContinueUIRequest uiRequest = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
		ClearAndContinuePegaRequest response = CartPegaRequestUtil6.formatClearandResumeRequest(new ClearAndContinuePegaRequest(), uiRequest);
		Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatClearandResumeRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"flowType\": \"SOF-case\",\"globalId\": \"global\",\"intendType\": \"ACC\"},\"data\": {\"lines\": [{}]}}";
		ClearAndContinueUIRequest uiRequest = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
		ClearAndContinuePegaRequest response = CartPegaRequestUtil6.formatClearandResumeRequest(new ClearAndContinuePegaRequest(), uiRequest);
		Assert.assertEquals("ACC", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatClearAndContinueRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"cartId\": \"cart\",\"prospectCartId\": \"global\",\"intendType\": \"NSEACC\"},\"data\": {\"lines\": [{}]}}";
		ClearAndContinueUIRequest uiRequest = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
		ClearAndContinuePegaRequest response = CartPegaRequestUtil6.formatClearAndContinueRequest(new ClearAndContinuePegaRequest(), uiRequest);
		Assert.assertEquals("SalesOrderFlex", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getCallReason());
	}
	@Test
	public void formatClearAndContinueRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"case\",\"cartId\": \"cart\",\"salesRepId\": \"global\",\"intendType\": \"AAL\"},\"data\": {\"lines\": [{}]}}";
		ClearAndContinueUIRequest uiRequest = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
		ClearAndContinuePegaRequest response = CartPegaRequestUtil6.formatClearAndContinueRequest(new ClearAndContinuePegaRequest(), uiRequest);
		Assert.assertEquals("SalesOrderPurchase", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getCallReason());
	}
	@Test
	public void formatClearAndContinueRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"flowType\": \"SOF-case\",\"cartId\": \"cart\",\"globalId\": \"global\",\"intendType\": \"\"},\"data\": {\"lines\": [{}]}}";
		ClearAndContinueUIRequest uiRequest = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
		ClearAndContinuePegaRequest response = CartPegaRequestUtil6.formatClearAndContinueRequest(new ClearAndContinuePegaRequest(), uiRequest);
		Assert.assertEquals("SalesOrderPurchase", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getCallReason());
	}
	@Test
	public void formatActivateLaterRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"cartId\": \"cart\",\"prospectCartId\": \"global\",\"intendType\": \"\"},\"data\": {\"lines\": [{}]}}";
		ActivateLaterUIRequest uiRequest = mapper.readValue(requestString, ActivateLaterUIRequest.class);
		ActivateLaterPEGARequest response = CartPegaRequestUtil6.formatActivateLaterRequest(new ActivateLaterPEGARequest(), uiRequest);
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatActivateLaterRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"case\",\"cartId\": \"cart\",\"prospectCartId\": \"global\",\"intendType\": \"NSEACC\"},\"data\": {\"lines\": [{}]}}";
		ActivateLaterUIRequest uiRequest = mapper.readValue(requestString, ActivateLaterUIRequest.class);
		ActivateLaterPEGARequest response = CartPegaRequestUtil6.formatActivateLaterRequest(new ActivateLaterPEGARequest(), uiRequest);
		Assert.assertEquals("SalesOrderPurchase", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getCallReason());
	}
	@Test
	public void formatActivateLaterRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"cartId\": \"cart\",\"prospectCartId\": \"global\",\"intendType\": \"NSEACC\"},\"data\": {\"lines\": [{}]}}";
		ActivateLaterUIRequest uiRequest = mapper.readValue(requestString, ActivateLaterUIRequest.class);
		ActivateLaterPEGARequest response = CartPegaRequestUtil6.formatActivateLaterRequest(new ActivateLaterPEGARequest(), uiRequest);
		Assert.assertEquals("SalesOrderPurchase", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getCallReason());
	}
	@Test
	public void formatCancelCaseRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"caseId\": \"SOF-case\",\"cartId\": \"cart\",\"processStep\": \"global\",\"intendType\": \"NSE\"},\"data\": {\"lines\": [{}]}}";
		CancelCaseUIRequest uiRequest = mapper.readValue(requestString, CancelCaseUIRequest.class);
		CancelCasePEGARequest response = CartPegaRequestUtil6.formatCancelCaseRequest(new CancelCasePEGARequest(), uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatCancelCaseRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"caseId\": \"case\",\"cartId\": \"cart\",\"processAction\": \"global\",\"intendType\": \"NSE_5G\"},\"data\": {\"lines\": [{}]}}";
		CancelCaseUIRequest uiRequest = mapper.readValue(requestString, CancelCaseUIRequest.class);
		CancelCasePEGARequest response = CartPegaRequestUtil6.formatCancelCaseRequest(new CancelCasePEGARequest(), uiRequest);
		Assert.assertEquals("NSE_5G", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatCancelCaseRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"OMNI-CARE\",\"cartInfo\": {\"cartId\": \"cart\",\"status\": \"global\",\"intendType\": \"AAL\"},\"data\": {\"lines\": [{}]}}";
		CancelCaseUIRequest uiRequest = mapper.readValue(requestString, CancelCaseUIRequest.class);
		CancelCasePEGARequest response = CartPegaRequestUtil6.formatCancelCaseRequest(new CancelCasePEGARequest(), uiRequest);
		Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatCancelCaseRequestTest4() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"caseId\": \"SOF-case\",\"cartId\": \"cart\",\"processStep\": \"global\",\"intendType\": \"NSEBYOD\"},\"data\": {\"lines\": [{}]}}";
		CancelCaseUIRequest uiRequest = mapper.readValue(requestString, CancelCaseUIRequest.class);
		CancelCasePEGARequest response = CartPegaRequestUtil6.formatCancelCaseRequest(new CancelCasePEGARequest(), uiRequest);
		Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatCancelCaseRequestTest5() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"caseId\": \"SOF-case\",\"cartId\": \"cart\",\"processStep\": \"global\",\"intendType\": \"REX\"},\"data\": {\"lines\": [{}]}}";
		CancelCaseUIRequest uiRequest = mapper.readValue(requestString, CancelCaseUIRequest.class);
		CancelCasePEGARequest response = CartPegaRequestUtil6.formatCancelCaseRequest(new CancelCasePEGARequest(), uiRequest);
		Assert.assertEquals("REX", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatCancelCaseRequestTest6() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"caseId\": \"SOF-case\",\"cartId\": \"cart\",\"processAction\": \"global\",\"intendType\": \"REX\"},\"data\": {\"lines\": [{}]}}";
		CancelCaseUIRequest uiRequest = mapper.readValue(requestString, CancelCaseUIRequest.class);
		CancelCasePEGARequest response = CartPegaRequestUtil6.formatCancelCaseRequest(new CancelCasePEGARequest(), uiRequest);
		Assert.assertEquals("REX", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatCancelCaseRequestTest7() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"OMNI-CARE\",\"cartInfo\": {\"caseId\": \"SOF-case\",\"cartId\": \"cart\",\"processStep\": \"global\",\"intendType\": \"REX\"},\"data\": {\"lines\": [{}]}}";
		CancelCaseUIRequest uiRequest = mapper.readValue(requestString, CancelCaseUIRequest.class);
		CancelCasePEGARequest response = CartPegaRequestUtil6.formatCancelCaseRequest(new CancelCasePEGARequest(), uiRequest);
		Assert.assertEquals("REX", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatCancelCaseRequestTest8() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"VZW-DOTCOM\",\"cartInfo\": {\"caseId\": \"SOF-case\",\"cartId\": \"cart\",\"processStep\": \"global\",\"intendType\": \"CLNR\"},\"data\": {\"lines\": [{}]}}";
		CancelCaseUIRequest uiRequest = mapper.readValue(requestString, CancelCaseUIRequest.class);
		CancelCasePEGARequest response = CartPegaRequestUtil6.formatCancelCaseRequest(new CancelCasePEGARequest(), uiRequest);
		Assert.assertEquals("CLNR", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatSplitExceededAmountRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"processStep\": \"global\",\"intendType\": \"\"},\"data\": {\"lines\": [{}]}}";
		SplitExceededAmountUIRequest uiRequest = mapper.readValue(requestString, SplitExceededAmountUIRequest.class);
		SplitExceededAmountPEGARequest response = CartPegaRequestUtil5.formatSplitExceededAmountRequest(new SplitExceededAmountPEGARequest(), uiRequest);
		Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatSplitExceededAmountRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"case\",\"processStep\": \"global\",\"intendType\": \"NSE\"},\"data\": {\"lines\": [{}]}}";
		SplitExceededAmountUIRequest uiRequest = mapper.readValue(requestString, SplitExceededAmountUIRequest.class);
		SplitExceededAmountPEGARequest response = CartPegaRequestUtil5.formatSplitExceededAmountRequest(new SplitExceededAmountPEGARequest(), uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatSplitExceededAmountRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"customerType\": \"N\",\"intendType\": \"EUP\"},\"data\": {\"lines\": [{}]}}";
		SplitExceededAmountUIRequest uiRequest = mapper.readValue(requestString, SplitExceededAmountUIRequest.class);
		SplitExceededAmountPEGARequest response = CartPegaRequestUtil5.formatSplitExceededAmountRequest(new SplitExceededAmountPEGARequest(), uiRequest);
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatIspuToDfillRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"processStep\": \"\",\"intendType\": \"\"},\"data\": {\"lines\": [{}]}}";
		IspuToDfillUIRequest uiRequest = mapper.readValue(requestString, IspuToDfillUIRequest.class);
		IspuToDfillPEGARequest response = CartPegaRequestUtil5.formatIspuToDfillRequest(uiRequest, new IspuToDfillPEGARequest());
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatIspuToDfillRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"accountNumber\": \"23456\",\"cartCreator\": \"cart\",\"globalId\": \"global\",\"intendType\": \"NSE\"},\"data\": {\"lines\": [{}]}}";
		IspuToDfillUIRequest uiRequest = mapper.readValue(requestString, IspuToDfillUIRequest.class);
		IspuToDfillPEGARequest response = CartPegaRequestUtil5.formatIspuToDfillRequest(uiRequest, new IspuToDfillPEGARequest());
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatIspuToDfillRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"accountType\": \"SOF-case\",\"customerType\": \"N\",\"sessionId\": \"global\",\"intendType\": \"NSE_5G\"},\"data\": {\"lines\": [{}]}}";
		IspuToDfillUIRequest uiRequest = mapper.readValue(requestString, IspuToDfillUIRequest.class);
		IspuToDfillPEGARequest response = CartPegaRequestUtil5.formatIspuToDfillRequest(uiRequest, new IspuToDfillPEGARequest());
		Assert.assertEquals("NSE_5G", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatIspuToDfillRequestTest4() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"creditAppNum\": \"SOF\",\"sessionId\": \"session\",\"globalId\": \"id\",\"cartCreator\": \"cart\",\"mtnFlow\": \"global\",\"intendType\": \"NSEBYOD\"},\"data\": {\"lines\": [{}]}}";
		IspuToDfillUIRequest uiRequest = mapper.readValue(requestString, IspuToDfillUIRequest.class);
		IspuToDfillPEGARequest response = CartPegaRequestUtil5.formatIspuToDfillRequest(uiRequest, new IspuToDfillPEGARequest());
		Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatVoidOrderRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"OMNI-CARE\",\"cartInfo\": {\"caseId\": \"SOF-case\",\"creditAppNum\": \"\",\"intendType\": \"NSE\"},\"data\": {\"lines\": [{}]}}";
		VoidOrderUIRequest uiRequest = mapper.readValue(requestString, VoidOrderUIRequest.class);
		VoidOrderPEGARequest response = CartPegaRequestUtil5.formatVoidOrderRequest(uiRequest, new VoidOrderPEGARequest());
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
	}
	@Test
	public void formatVoidOrderRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"VZW-MFA\",\"cartInfo\": {\"caseId\": \"SOF-case\",\"creditAppNum\": \"\",\"intendType\": \"NSE_5G\"},\"data\": {\"lines\": [{}]}}";
		VoidOrderUIRequest uiRequest = mapper.readValue(requestString, VoidOrderUIRequest.class);
		VoidOrderPEGARequest response = CartPegaRequestUtil5.formatVoidOrderRequest(uiRequest, new VoidOrderPEGARequest());
		Assert.assertEquals("NSE_5G", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
	}
	@Test
	public void formatVoidOrderRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"OMNI-CARE\",\"cartInfo\": {\"caseId\": \"case\",\"creditAppNum\": \"credit\",\"intendType\": \"NSEBYOD\"},\"data\": {\"lines\": [{}]}}";
		VoidOrderUIRequest uiRequest = mapper.readValue(requestString, VoidOrderUIRequest.class);
		VoidOrderPEGARequest response = CartPegaRequestUtil5.formatVoidOrderRequest(uiRequest, new VoidOrderPEGARequest());
		Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
	}
	@Test
	public void formatVoidOrderRequestTest4() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"processStep\": \"\",\"intendType\": \"REX\"},\"data\": {\"lines\": [{}]}}";
		VoidOrderUIRequest uiRequest = mapper.readValue(requestString, VoidOrderUIRequest.class);
		VoidOrderPEGARequest response = CartPegaRequestUtil5.formatVoidOrderRequest(uiRequest, new VoidOrderPEGARequest());
		Assert.assertEquals("REX", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
	}
	@Test
	public void formatUpdatePortInLaterRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"creditAppNum\": \"\",\"intendType\": \"NSE\"},\"data\": {\"lines\": [{}]}}";
		PortinLaterUIRequest uiRequest = mapper.readValue(requestString, PortinLaterUIRequest.class);
		PortinLaterPEGARequest response = CartPegaRequestUtil5.formatUpdatePortInLaterRequest(new PortinLaterPEGARequest(), uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatUpdatePortInLaterRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"case\",\"creditAppNum\": \"\",\"intendType\": \"\"},\"data\": {\"lines\": [{}]}}";
		PortinLaterUIRequest uiRequest = mapper.readValue(requestString, PortinLaterUIRequest.class);
		PortinLaterPEGARequest response = CartPegaRequestUtil5.formatUpdatePortInLaterRequest(new PortinLaterPEGARequest(), uiRequest);
		Assert.assertEquals("", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatUpdatePortInLaterRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"creditAppNum\": \"\",\"intendType\": \"NSE\"},\"data\": {}}";
		PortinLaterUIRequest uiRequest = mapper.readValue(requestString, PortinLaterUIRequest.class);
		PortinLaterPEGARequest response = CartPegaRequestUtil5.formatUpdatePortInLaterRequest(new PortinLaterPEGARequest(), uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatRevokeRebatesRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"creditAppNum\": \"\",\"intendType\": \"\"},\"data\": {\"lines\": [{}]}}";
		RevokeRebatesUIRequest uiRequest = mapper.readValue(requestString, RevokeRebatesUIRequest.class);
		RevokeRebatesPEGARequest response = CartPegaRequestUtil5.formatRevokeRebatesRequest(new RevokeRebatesPEGARequest(), uiRequest);
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatRevokeRebatesRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"creditAppNum\": \"\",\"intendType\": \"AAL\"},\"data\": {\"lines\": [{}]}}";
		RevokeRebatesUIRequest uiRequest = mapper.readValue(requestString, RevokeRebatesUIRequest.class);
		RevokeRebatesPEGARequest response = CartPegaRequestUtil5.formatRevokeRebatesRequest(new RevokeRebatesPEGARequest(), uiRequest);
		Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatManualPairingRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"creditAppNum\": \"\",\"intendType\": \"\"},\"data\": {\"lines\": [{}]}}";
		ManualPairingUIRequest uiRequest = mapper.readValue(requestString, ManualPairingUIRequest.class);
		ManualPairingPEGARequest response = CartPegaRequestUtil5.formatManualPairingRequest(new ManualPairingPEGARequest(), uiRequest);
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatManualPairingRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"case\",\"creditAppNum\": \"\",\"intendType\": \"\"},\"data\": {\"lines\": [{}]}}";
		ManualPairingUIRequest uiRequest = mapper.readValue(requestString, ManualPairingUIRequest.class);
		ManualPairingPEGARequest response = CartPegaRequestUtil5.formatManualPairingRequest(new ManualPairingPEGARequest(), uiRequest);
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatManualPairingRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"creditAppNum\": \"\",\"intendType\": \"\"},\"data\": {}}";
		ManualPairingUIRequest uiRequest = mapper.readValue(requestString, ManualPairingUIRequest.class);
		ManualPairingPEGARequest response = CartPegaRequestUtil5.formatManualPairingRequest(new ManualPairingPEGARequest(), uiRequest);
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formCreateLineReqTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"creditAppNum\": \"\",\"intendType\": \"EUP\"},\"data\": {\"lines\": [{}]}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		CreateLineUIRequest response = CartPegaRequestUtil5.formCreateLineReq(new CreateLineUIRequest(), uiRequest);
		Assert.assertEquals("EUP", response.getCartInfo().getIntendType());
	}
	@Test
	public void formatAdd5GBulkOrderRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"processStep\": \"\",\"intendType\": \"EUP\"},\"data\": {\"lines\": [{}]}}";
		Add5GBulkOrderUIRequest uiRequest = mapper.readValue(requestString, Add5GBulkOrderUIRequest.class);
		Add5GBulkOrderPEGARequest response = CartPegaRequestUtil5.formatAdd5GBulkOrderRequest(new Add5GBulkOrderPEGARequest(), uiRequest);
		Assert.assertEquals("AAL_5G", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAdd5GBulkOrderRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"processStep\": \"\",\"intendType\": \"EUP\"},\"data\": {\"lines\": [{}],\"addFeatures\": [{}]}}";
		Add5GBulkOrderUIRequest uiRequest = mapper.readValue(requestString, Add5GBulkOrderUIRequest.class);
		Add5GBulkOrderPEGARequest response = CartPegaRequestUtil5.formatAdd5GBulkOrderRequest(new Add5GBulkOrderPEGARequest(), uiRequest);
		Assert.assertEquals("AAL_5G", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAdd5GBulkOrderRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"processStep\": \"\",\"intendType\": \"EUP\"},\"data\": {\"lines\": [{}],\"removeFeatures\": [{}]}}";
		Add5GBulkOrderUIRequest uiRequest = mapper.readValue(requestString, Add5GBulkOrderUIRequest.class);
		Add5GBulkOrderPEGARequest response = CartPegaRequestUtil5.formatAdd5GBulkOrderRequest(new Add5GBulkOrderPEGARequest(), uiRequest);
		Assert.assertEquals("AAL_5G", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatDeassignMtnRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"processStep\": \"\",\"intendType\": \"NSE_5G\"},\"data\": {\"lines\": [{}]}}";
		DeassignMtnUIRequest uiRequest = mapper.readValue(requestString, DeassignMtnUIRequest.class);
		DeassignMtnPEGARequest response = CartPegaRequestUtil5.formatDeassignMtnRequest(uiRequest, new DeassignMtnPEGARequest());
		Assert.assertEquals("NSE_5G", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatDeassignMtnRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"case\",\"processStep\": \"\",\"intendType\": \"NSEBYOD\"},\"data\": {\"lines\": [{}]}}";
		DeassignMtnUIRequest uiRequest = mapper.readValue(requestString, DeassignMtnUIRequest.class);
		DeassignMtnPEGARequest response = CartPegaRequestUtil5.formatDeassignMtnRequest(uiRequest, new DeassignMtnPEGARequest());
		Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatDeassignMtnRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"processStep\": \"\",\"intendType\": \"NSE\",\"isFlexV2\": \"true\"},\"data\": {\"lines\": [{\"mtn\":\"5079937563\"}]}}";
		DeassignMtnUIRequest uiRequest = mapper.readValue(requestString, DeassignMtnUIRequest.class);
		DeassignMtnPEGARequest response = CartPegaRequestUtil5.formatDeassignMtnRequest(uiRequest, new DeassignMtnPEGARequest());
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAssignMtnRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"promoHubJourney\": false,\"intendType\": \"NSE_5G\"},\"data\": {\"lines\": [{}]}}";
		AssignMtnUIRequest uiRequest = mapper.readValue(requestString, AssignMtnUIRequest.class);
		final LinkedMultiValueMap<String, HttpCookie> cookies = new LinkedMultiValueMap<>();
		HttpCookie migrationCookie = new HttpCookie(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, "true-cookie");
		cookies.add(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, migrationCookie);
		RequestAccessContext.RequestAccess requestAccess = new RequestAccessContext.RequestAccess(cookies, new HttpHeaders());
		RequestAccessContext.updateRequestData(requestAccess);
		AssignMtnPEGARequest response = CartPegaRequestUtil5.formatAssignMtnRequest(uiRequest, new AssignMtnPEGARequest());
		Assert.assertEquals("NSE_5G", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAssignMtnRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"promoHubJourney\": true,\"intendType\": \"NSEBYOD\"},\"data\": {\"lines\": [{}]}}";
		final LinkedMultiValueMap<String, HttpCookie> cookies = new LinkedMultiValueMap<>();
		HttpCookie migrationCookie = new HttpCookie(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, "true-cookie");
		cookies.add(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, migrationCookie);
		RequestAccessContext.RequestAccess requestAccess = new RequestAccessContext.RequestAccess(cookies, new HttpHeaders());
		RequestAccessContext.updateRequestData(requestAccess);
		AssignMtnUIRequest uiRequest = mapper.readValue(requestString, AssignMtnUIRequest.class);
		AssignMtnPEGARequest response = CartPegaRequestUtil5.formatAssignMtnRequest(uiRequest, new AssignMtnPEGARequest());
		Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAssignMtnRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"rpsIntent\": \"rps\",\"processAction\": \"promo\",\"promoHubJourney\": true,\"intendType\": \"NSE\"},\"data\": {\"lines\": [{}]}}";
		final LinkedMultiValueMap<String, HttpCookie> cookies = new LinkedMultiValueMap<>();
		HttpCookie migrationCookie = new HttpCookie(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, "true-cookie");
		cookies.add(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, migrationCookie);
		RequestAccessContext.RequestAccess requestAccess = new RequestAccessContext.RequestAccess(cookies, new HttpHeaders());
		RequestAccessContext.updateRequestData(requestAccess);
		AssignMtnUIRequest uiRequest = mapper.readValue(requestString, AssignMtnUIRequest.class);
		AssignMtnPEGARequest response = CartPegaRequestUtil5.formatAssignMtnRequest(uiRequest, new AssignMtnPEGARequest());
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAssignMtnRequestTest4() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"promoHubJourney\": true,\"intendType\": \"NSE\"},\"data\": {\"lines\": [{}],\"paperLessBilling\": true}}";
		final LinkedMultiValueMap<String, HttpCookie> cookies = new LinkedMultiValueMap<>();
		HttpCookie migrationCookie = new HttpCookie(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, "true-cookie");
		cookies.add(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, migrationCookie);
		RequestAccessContext.RequestAccess requestAccess = new RequestAccessContext.RequestAccess(cookies, new HttpHeaders());
		RequestAccessContext.updateRequestData(requestAccess);
		AssignMtnUIRequest uiRequest = mapper.readValue(requestString, AssignMtnUIRequest.class);
		AssignMtnPEGARequest response = CartPegaRequestUtil5.formatAssignMtnRequest(uiRequest, new AssignMtnPEGARequest());
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAssignMtnRequestTest5() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"promoHubJourney\": true,\"intendType\": \"NSE\"},\"data\": {\"lines\": [{}],\"receiveSpecialOfferUpdates\": true}}";
		final LinkedMultiValueMap<String, HttpCookie> cookies = new LinkedMultiValueMap<>();
		HttpCookie migrationCookie = new HttpCookie(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, "true-cookie");
		cookies.add(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, migrationCookie);
		RequestAccessContext.RequestAccess requestAccess = new RequestAccessContext.RequestAccess(cookies, new HttpHeaders());
		RequestAccessContext.updateRequestData(requestAccess);
		AssignMtnUIRequest uiRequest = mapper.readValue(requestString, AssignMtnUIRequest.class);
		AssignMtnPEGARequest response = CartPegaRequestUtil5.formatAssignMtnRequest(uiRequest, new AssignMtnPEGARequest());
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAssignMtnRequestTest6() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"promoHubJourney\": true,\"intendType\": \"NSE_LTE\"},\"data\": {\"lines\": [{}]}}";
		final LinkedMultiValueMap<String, HttpCookie> cookies = new LinkedMultiValueMap<>();
		HttpCookie migrationCookie = new HttpCookie(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, "true-cookie");
		cookies.add(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, migrationCookie);
		RequestAccessContext.RequestAccess requestAccess = new RequestAccessContext.RequestAccess(cookies, new HttpHeaders());
		RequestAccessContext.updateRequestData(requestAccess);
		AssignMtnUIRequest uiRequest = mapper.readValue(requestString, AssignMtnUIRequest.class);
		AssignMtnPEGARequest response = CartPegaRequestUtil5.formatAssignMtnRequest(uiRequest, new AssignMtnPEGARequest());
		Assert.assertEquals("NSE_LTE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAssignMtnRequestTest7() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"case\",\"promoHubJourney\": true,\"intendType\": \"AAL_LTE\"},\"data\": {\"lines\": [{\"meaCode\": \"mea\"}]}}";
		final LinkedMultiValueMap<String, HttpCookie> cookies = new LinkedMultiValueMap<>();
		HttpCookie migrationCookie = new HttpCookie(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, "true-cookie");
		cookies.add(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, migrationCookie);
		RequestAccessContext.RequestAccess requestAccess = new RequestAccessContext.RequestAccess(cookies, new HttpHeaders());
		RequestAccessContext.updateRequestData(requestAccess);
		AssignMtnUIRequest uiRequest = mapper.readValue(requestString, AssignMtnUIRequest.class);
		AssignMtnPEGARequest response = CartPegaRequestUtil5.formatAssignMtnRequest(uiRequest, new AssignMtnPEGARequest());
		Assert.assertEquals("AAL_LTE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAssignMtnRequestTest8() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"promoHubJourney\": true,\"intendType\": \"AAL_5G\"},\"data\": {\"lines\": [{\"accountOwner\": \"owner\"}]}}";
		final LinkedMultiValueMap<String, HttpCookie> cookies = new LinkedMultiValueMap<>();
		HttpCookie migrationCookie = new HttpCookie(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, "true-cookie");
		cookies.add(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, migrationCookie);
		RequestAccessContext.RequestAccess requestAccess = new RequestAccessContext.RequestAccess(cookies, new HttpHeaders());
		RequestAccessContext.updateRequestData(requestAccess);
		AssignMtnUIRequest uiRequest = mapper.readValue(requestString, AssignMtnUIRequest.class);
		AssignMtnPEGARequest response = CartPegaRequestUtil5.formatAssignMtnRequest(uiRequest, new AssignMtnPEGARequest());
		Assert.assertEquals("AAL_5G", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatUpdateDeviceSimIdRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"promoHubJourney\": false,\"intendType\": \"\"},\"data\": {\"lines\": [{}]}}";
		UpdateDeviceSIMIdUIRequest uiRequest = mapper.readValue(requestString, UpdateDeviceSIMIdUIRequest.class);
		UpdateDeviceSIMIdPEGARequest response = CartPegaRequestUtil5.formatUpdateDeviceSimIdRequest(uiRequest, new UpdateDeviceSIMIdPEGARequest());
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatUpdateDeviceSimIdRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"case\",\"promoHubJourney\": false,\"intendType\": \"NSE\"},\"data\": {\"lines\": [{}]}}";
		UpdateDeviceSIMIdUIRequest uiRequest = mapper.readValue(requestString, UpdateDeviceSIMIdUIRequest.class);
		UpdateDeviceSIMIdPEGARequest response = CartPegaRequestUtil5.formatUpdateDeviceSimIdRequest(uiRequest, new UpdateDeviceSIMIdPEGARequest());
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatUpdateDeviceSimIdRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"customerType\": \"N\",\"intendType\": \"REX\"},\"data\": {\"lines\": [{}]}}";
		UpdateDeviceSIMIdUIRequest uiRequest = mapper.readValue(requestString, UpdateDeviceSIMIdUIRequest.class);
		UpdateDeviceSIMIdPEGARequest response = CartPegaRequestUtil5.formatUpdateDeviceSimIdRequest(uiRequest, new UpdateDeviceSIMIdPEGARequest());
		Assert.assertEquals("REX", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatEffectiveDateOverrideRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"processStep\": \"promo\",\"intendType\": \"NSE\"},\"data\": {\"lines\": [{}]}}";
		EffectiveDateOverrideUIRequest uiRequest = mapper.readValue(requestString, EffectiveDateOverrideUIRequest.class);
		EffectiveDateOverridePEGARequest response = CartPegaRequestUtil3.formatEffectiveDateOverrideRequest(uiRequest, new EffectiveDateOverridePEGARequest());
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatEffectiveDateOverrideRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"case\",\"processStep\": \"promo\",\"intendType\": \"NSE\"},\"data\": {\"lines\": [{}]}}";
		EffectiveDateOverrideUIRequest uiRequest = mapper.readValue(requestString, EffectiveDateOverrideUIRequest.class);
		EffectiveDateOverridePEGARequest response = CartPegaRequestUtil3.formatEffectiveDateOverrideRequest(uiRequest, new EffectiveDateOverridePEGARequest());
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatEffectiveDateOverrideRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"processStep\": \"promo\",\"intendType\": \"NSE\"},\"data\": {\"lines\": [{}]}}";
		EffectiveDateOverrideUIRequest uiRequest = mapper.readValue(requestString, EffectiveDateOverrideUIRequest.class);
		EffectiveDateOverridePEGARequest response = CartPegaRequestUtil3.formatEffectiveDateOverrideRequest(uiRequest, new EffectiveDateOverridePEGARequest());
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatInstantCreditDownPaymenRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"cradleFlowJourney\": \"promo\",\"intendType\": \"\"},\"data\": {\"lines\": [{}]}}";
		InstantCreditDownPaymentUIRequest uiRequest = mapper.readValue(requestString, InstantCreditDownPaymentUIRequest.class);
		InstantCreditDownPaymentPEGARequest response = CartPegaRequestUtil4.formatInstantCreditDownPaymenRequest(new InstantCreditDownPaymentPEGARequest(), uiRequest);
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatInstantCreditDownPaymenRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"multitrade\": true,\"intendType\": \"NSE\"},\"data\": {\"lines\": [{\"instantcredit\": {}}]}}";
		InstantCreditDownPaymentUIRequest uiRequest = mapper.readValue(requestString, InstantCreditDownPaymentUIRequest.class);
		InstantCreditDownPaymentPEGARequest response = CartPegaRequestUtil4.formatInstantCreditDownPaymenRequest(new InstantCreditDownPaymentPEGARequest(), uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatE911AddressRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"processStep\": \"promo\",\"intendType\": \"NSE\"},\"data\": {\"lines\": [{\"e911Address\": {\"address\": {}}}]}}";
		E911AddressUIRequest uiRequest = mapper.readValue(requestString, E911AddressUIRequest.class);
		E911AddressPEGARequest response = CartPegaRequestUtil4.formatE911AddressRequest(new E911AddressPEGARequest(), uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatE911AddressRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"isPrepayCart\": \"Y\",\"caseId\": \"case\",\"clientAppName\": \"client\",\"rpsIntent\": \"EUP\",\"intendType\": \"NSEBYOD\"},\"data\": {\"lines\": [{\"e911Address\": {\"address\": {}}}]}}";
		E911AddressUIRequest uiRequest = mapper.readValue(requestString, E911AddressUIRequest.class);
		E911AddressPEGARequest response = CartPegaRequestUtil4.formatE911AddressRequest(new E911AddressPEGARequest(), uiRequest);
		Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatE911AddressRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"isPrepayCart\": \"Z\",\"clientAppName\": \"client\",\"intent\": \"EUP\",\"intendType\": \"NSEBYOD\"},\"data\": {\"lines\": [{\"e911Address\": {\"e911AddressSharingOptIn\": true,\"address\": {}}}]}}";
		E911AddressUIRequest uiRequest = mapper.readValue(requestString, E911AddressUIRequest.class);
		E911AddressPEGARequest response = CartPegaRequestUtil4.formatE911AddressRequest(new E911AddressPEGARequest(), uiRequest);
		Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatE911AddressRequestTest4() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"isPrepayCart\": \"\",\"caseId\": \"SOF-case\",\"clientAppName\": \"VZW-NUMBERLINK\",\"intent\": \"EUP\",\"intendType\": \"NSEBYOD\"},\"data\": {\"lines\": [{\"e911Address\": {\"e911AddressSharingOptIn\": true,\"address\": {}}}]}}";
		E911AddressUIRequest uiRequest = mapper.readValue(requestString, E911AddressUIRequest.class);
		E911AddressPEGARequest response = CartPegaRequestUtil4.formatE911AddressRequest(new E911AddressPEGARequest(), uiRequest);
		Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatBillingAddressRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"deviceType\": \"promo\",\"intendType\": \"\"},\"data\": {\"lines\": []}}";
		BillingAddressUIRequest uiRequest = mapper.readValue(requestString, BillingAddressUIRequest.class);
		BillingAddressPEGARequest response = CartPegaRequestUtil4.formatBillingAddressRequest(new BillingAddressPEGARequest(), uiRequest);
		Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatBillingAddressRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"case\",\"clientAppName\": \"VZW-DOTCOM-BBP\",\"intendType\": \"NSE\"},\"data\": {\"lines\": []}}";
		BillingAddressUIRequest uiRequest = mapper.readValue(requestString, BillingAddressUIRequest.class);
		BillingAddressPEGARequest response = CartPegaRequestUtil4.formatBillingAddressRequest(new BillingAddressPEGARequest(), uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatBillingAddressRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"expressCheckout\": true,\"deviceType\": \"promo\",\"intendType\": \"NSEACC\"},\"data\": {\"lines\": []}}";
		BillingAddressUIRequest uiRequest = mapper.readValue(requestString, BillingAddressUIRequest.class);
		BillingAddressPEGARequest response = CartPegaRequestUtil4.formatBillingAddressRequest(new BillingAddressPEGARequest(), uiRequest);
		Assert.assertEquals("NSEACC", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatBillingAddressRequestTest4() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"expressCheckout\": false,\"deviceType\": \"promo\",\"intendType\": \"NSEACC\"},\"data\": {\"lines\": []}}";
		BillingAddressUIRequest uiRequest = mapper.readValue(requestString, BillingAddressUIRequest.class);
		BillingAddressPEGARequest response = CartPegaRequestUtil4.formatBillingAddressRequest(new BillingAddressPEGARequest(), uiRequest);
		Assert.assertEquals("NSEACC", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatServiceAddressRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"deviceType\": \"promo\",\"intendType\": \"NSE\"},\"data\": {\"lines\": []}}";
		ServiceAddressUIRequest uiRequest = mapper.readValue(requestString, ServiceAddressUIRequest.class);
		ServiceAddressPEGARequest response = CartPegaRequestUtil3.formatServiceAddressRequest(new ServiceAddressPEGARequest(), uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatServiceAddressRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"expressCheckout\": false,\"caseId\": \"case\",\"clientAppName\": \"VZW-DOTCOM-BBP\",\"intendType\": \"NSEBYOD\"},\"data\": {\"lines\": []}}";
		ServiceAddressUIRequest uiRequest = mapper.readValue(requestString, ServiceAddressUIRequest.class);
		ServiceAddressPEGARequest response = CartPegaRequestUtil3.formatServiceAddressRequest(new ServiceAddressPEGARequest(), uiRequest);
		Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatServiceAddressRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"expressCheckout\": true,\"processStep\": \"promo\",\"intendType\": \"NSE\"},\"data\": {\"lines\": []}}";
		ServiceAddressUIRequest uiRequest = mapper.readValue(requestString, ServiceAddressUIRequest.class);
		ServiceAddressPEGARequest response = CartPegaRequestUtil3.formatServiceAddressRequest(new ServiceAddressPEGARequest(), uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatNumberShareRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"deviceType\": \"promo\",\"intendType\": \"NSE\"},\"data\": {\"lines\": []}}";
		NumberShareUIRequest uiRequest = mapper.readValue(requestString, NumberShareUIRequest.class);
		NumberSharePEGARequest response = CartPegaRequestUtil3.formatNumberShareRequest(new NumberSharePEGARequest(), uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatNumberShareRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"promoHubJourney\": false,\"caseId\": \"case\",\"deviceType\": \"promo\",\"intendType\": \"NSE\"},\"data\": {\"lines\": []}}";
		NumberShareUIRequest uiRequest = mapper.readValue(requestString, NumberShareUIRequest.class);
		NumberSharePEGARequest response = CartPegaRequestUtil3.formatNumberShareRequest(new NumberSharePEGARequest(), uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatNumberShareRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"promoHubJourney\": true,\"intendType\": \"NSE\"},\"data\": {\"lines\": []}}";
		NumberShareUIRequest uiRequest = mapper.readValue(requestString, NumberShareUIRequest.class);
		NumberSharePEGARequest response = CartPegaRequestUtil3.formatNumberShareRequest(new NumberSharePEGARequest(), uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatNumberShareRequestTest4() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"promoHubJourney\": true,\"intendType\": \"NSEBYOD\"},\"data\": {\"lines\": []}}";
		NumberShareUIRequest uiRequest = mapper.readValue(requestString, NumberShareUIRequest.class);
		NumberSharePEGARequest response = CartPegaRequestUtil3.formatNumberShareRequest(new NumberSharePEGARequest(), uiRequest);
		Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatNumberShareRequestTest5() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"promoHubJourney\": true,\"intendType\": \"EUP\"},\"data\": {\"lines\": []}}";
		NumberShareUIRequest uiRequest = mapper.readValue(requestString, NumberShareUIRequest.class);
		NumberSharePEGARequest response = CartPegaRequestUtil3.formatNumberShareRequest(new NumberSharePEGARequest(), uiRequest);
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatCreateLineRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"isPrepayCart\": \"Y\",\"intendType\": \"NSE\"},\"data\": {\"lines\": []}}";
		CreateLineUIRequest uiRequest = mapper.readValue(requestString, CreateLineUIRequest.class);
		CreateLinePEGARequest response = CartPegaRequestUtil3.formatCreateLineRequest(new CreateLinePEGARequest(), uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatCreateLineRequestAddressTest() throws JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"isPrepayCart\": \"Y\",\"intendType\": \"NSE\",\"city\": \"BATON ROUGE\",\"addressLine1\": \"1 ONE AMERICAN PL\",\"state\": \"LA\",\"zipCode\": \"87001\"},\"data\": {\"enableFcc\": true,\"zipCode\": \"70825\",\"lines\": []}}";
		CreateLineUIRequest uiRequest = mapper.readValue(requestString, CreateLineUIRequest.class);
		CreateLinePEGARequest response = CartPegaRequestUtil3.formatCreateLineRequest(new CreateLinePEGARequest(), uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
		uiRequest.getCartInfo().setIntendType("NSEBYOD");
		CreateLinePEGARequest response1 = CartPegaRequestUtil3.formatCreateLineRequest(new CreateLinePEGARequest(), uiRequest);
		Assert.assertEquals("NSEBYOD", response1.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatCreateLineRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"quoteWithSkipMDN\": true,\"redemptionCode\": \"SOF-case\",\"isPrepayCart\": \"Z\",\"intendType\": \"NSE_5G\",\"cradleFlowJourney\": \"cradle\"},\"externalId\": \"external\",\"vzId\": \"vz\",\"data\": {\"lines\": []}}";
		CreateLineUIRequest uiRequest = mapper.readValue(requestString, CreateLineUIRequest.class);
		CreateLinePEGARequest response = CartPegaRequestUtil3.formatCreateLineRequest(new CreateLinePEGARequest(), uiRequest);
		Assert.assertEquals("NSE_5G", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatCreateLineRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"isPrepayCart\": \"Y\",\"intendType\": \"EUP\"},\"data\": {\"lines\": []}}";
		CreateLineUIRequest uiRequest = mapper.readValue(requestString, CreateLineUIRequest.class);
		CreateLinePEGARequest response = CartPegaRequestUtil3.formatCreateLineRequest(new CreateLinePEGARequest(), uiRequest);
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatCreateLineRequestTest4() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"isPrepayCart\": \"Y\",\"intendType\": \"NSEBYOD\"},\"data\": {\"lines\": []}}";
		CreateLineUIRequest uiRequest = mapper.readValue(requestString, CreateLineUIRequest.class);
		CreateLinePEGARequest response = CartPegaRequestUtil3.formatCreateLineRequest(new CreateLinePEGARequest(), uiRequest);
		Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatCreateLineRequestTest_PurchasePath1() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\":{\"cartId\":\"0e0be712-a8e2-472a-8adb-2221847553c4\",\"caseId\":\"SOP-14498729-E01\",\"clientAppName\":\"OMNI-RETAIL\",\"creditAppNum\":\"247006973\",\"processingMTN\":\"\",\"processStep\":\"MTNSelectionPage\",\"intendType\":\"NSE\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"deviceTypeSelected\":\"Smartphones\"},{\"mtn\":\"\",\"deviceTypeSelected\":\"5GInternet\"}]}}";
		CreateLineUIRequest uiRequest = mapper.readValue(requestString, CreateLineUIRequest.class);
		CreateLinePEGARequest response = CartPegaRequestUtil3.formatCreateLineRequest(new CreateLinePEGARequest(), uiRequest);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatCreateLineRequestTest_PurchasePath2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\":{\"processStep\":\"MTNSelectionPage\",\"intendType\":\"AAL_5G\",\"cartId\":\"23e44824-807e-4d10-ba40-bcbe91cba7eb\",\"caseId\":\"SOP-14460922-E01\",\"cartCreator\":\"SOP-14460922-E01\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"deviceTypeSelected\":\"5G Internet\"}]}}";
		CreateLineUIRequest uiRequest = mapper.readValue(requestString, CreateLineUIRequest.class);
		CreateLinePEGARequest response = CartPegaRequestUtil3.formatCreateLineRequest(new CreateLinePEGARequest(), uiRequest);
		Assert.assertEquals("AAL_5G", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatCreateLineRequestTest_PurchasePath3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\":{\"processStep\":\"MTNSelectionPage\",\"intendType\":\"AAL_5G\",\"cartId\":\"23e44824-807e-4d10-ba40-bcbe91cba7eb\",\"caseId\":\"SOP-14460922-E01\",\"cartCreator\":\"SOP-14460922-E01\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"deviceTypeSelected\":\"SmartPhone\"}]}}";
		CreateLineUIRequest uiRequest = mapper.readValue(requestString, CreateLineUIRequest.class);
		CreateLinePEGARequest response = CartPegaRequestUtil3.formatCreateLineRequest(new CreateLinePEGARequest(), uiRequest);
		Assert.assertEquals("AAL_5G", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatCreateLineRequestTest_PurchasePath4() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\":{\"processStep\":\"MTNSelectionPage\",\"intendType\":\"AAL\",\"cartId\":\"23e44824-807e-4d10-ba40-bcbe91cba7eb\",\"caseId\":\"SOP-14460922-E01\",\"cartCreator\":\"SOP-14460922-E01\"},\"data\":{\"lines\":[{\"mtn\":\"\"}]}}";
		CreateLineUIRequest uiRequest = mapper.readValue(requestString, CreateLineUIRequest.class);
		CreateLinePEGARequest response = CartPegaRequestUtil3.formatCreateLineRequest(new CreateLinePEGARequest(), uiRequest);
		Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatCreateLineRequestTest5() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"isPrepayCart\": \"Y\",\"intendType\": \"AAL\",\"customerType\": \"U\"},\"data\": {\"lines\": []}}";
		CreateLineUIRequest uiRequest = mapper.readValue(requestString, CreateLineUIRequest.class);
		CreateLinePEGARequest response = CartPegaRequestUtil3.formatCreateLineRequest(new CreateLinePEGARequest(), uiRequest);
		Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}

	@Test
	public void formatCreateLineRequestTest6() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"isPrepayCart\": \"Y\",\"intendType\": \"NSEBYOD\",\"existingCradleFlowJourney\": \"NextGen\"},\"data\": {\"lines\": []}}";
		CreateLineUIRequest uiRequest = mapper.readValue(requestString, CreateLineUIRequest.class);
		CreateLinePEGARequest response = CartPegaRequestUtil3.formatCreateLineRequest(new CreateLinePEGARequest(), uiRequest);
		Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestIsLineLevelPlanTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"VZW-MFA\",\"cartInfo\": {\"deviceId\": \"SOF-case\",\"clientAppName\": \"VZW-DOTCOM-BBP\",\"intendType\": \"EUP\"},\"data\": {\"lines\": [{}]}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		uiRequest.getCartInfo().setIsLineLevelPlanAccount(null);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,true,true, getFFlag());
		uiRequest.getCartInfo().setIsLineLevelPlanAccount(false);
		response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,true,true, getFFlag());
		uiRequest.getCartInfo().setIsLineLevelPlanAccount(true);
		response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,false,false, getFFlag());
		uiRequest.getCartInfo().setAmRole("accountHolder");
		response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,true,true, getFFlag());
		uiRequest.getCartInfo().setAmRole("mobileSecure");
		response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,false,false, getFFlag());
	}
	@Test
	public void formatAddDeviceRequestTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"isFlexV2\": true,\"caseId\": \"SOF-case\",\"byodESim\": \"byod\",\"universalId\": \"Y\",\"intendType\": \"PAD\"},\"data\": {\"lines\": [{}]}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		uiRequest.setFlexV2ValidationFLag(true);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,false, false, getFFlag());
		Assert.assertEquals("PAD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());

		uiRequest.setData(null);
		response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,false, false, getFFlag());
		Assert.assertEquals("PAD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());

		uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		uiRequest.setFlexV2ValidationFLag(false);
		uiRequest.getCartInfo().setFlexV2(false);
		Assert.assertEquals("PAD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());

		uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		uiRequest.getCartInfo().setFlexV2(false);
		Assert.assertEquals("PAD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());


	}
	@Test
	public void formatAddDeviceRequestTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"byodESim\": \"byod\",\"universalId\": \"Y\",\"intendType\": \"DEO\"},\"data\": {\"lines\": [{\"device\": {\"connectedCarDetails\": {}}}]}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,true,true, getFFlag());
		Assert.assertEquals("DEO", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"byodESim\": \"byod\",\"clientAppName\": \"Y\",\"intendType\": \"NSE_5G\"},\"data\": {\"lines\": [{\"device\": {\"connectedCarDetails\": {\"brandName\": \"KIA\"}},\"selectedOffers\": [{}]}]}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,true,true, getFFlag());
		Assert.assertEquals("NSE_5G", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestTest4() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"OMNI-INDIRECT\",\"cartInfo\": {\"caseId\": \"SOF-case\",\"byodESim\": \"byod\",\"clientAppName\": \"VZW-DOTCOM-BBP\",\"intendType\": \"NSE_5G\"},\"data\": {\"lines\": [{\"device\": {\"connectedCarDetails\": {\"brandName\": \"KIA\"}},\"selectedOffers\": [{}]}]}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,true,true, getFFlag());
		Assert.assertEquals("NSE_5G", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestTest5() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"OMNI-INDIRECT\",\"cartInfo\": {\"deviceId\": \"SOF-case\",\"byodESim\": \"byod\",\"clientAppName\": \"VZW-DOTCOM-BBP\",\"intendType\": \"NSE_5G\"},\"data\": {\"lines\": [{\"device\": {\"connectedCarDetails\": {\"brandName\": \"KIA\"}},\"selectedOffers\": [{}]}]}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "PromoHub",true,true,true, getFFlag());
		Assert.assertEquals("NSE_5G", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestTest6() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"VZW-MFA\",\"cartInfo\": {\"deviceId\": \"SOF-case\",\"clientAppName\": \"VZW-DOTCOM-BBP\",\"intendType\": \"EUP\"},\"data\": {\"lines\": [{}]}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,false,true, getFFlag());
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestTest7() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"VZW-MFA\",\"cartInfo\": {\"deviceId\": \"SOF-case\",\"clientAppName\": \"VZW-DOTCOM-BBP\",\"intendType\": \"NSE\"},\"data\": {\"lines\": [{}]}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,true,true, getFFlag());
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestTest8() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"VZW-MFA\",\"cartInfo\": {\"triggerPricingValidation\": true,\"deviceId\": \"SOF-case\",\"clientAppName\": \"VZW-DOTCOM-BBP\",\"intendType\": \"NSE\"},\"data\": {\"lines\": [{}]}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "throttle",true,false,true, getFFlag());
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestTest9() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"VZW-MFA\",\"cartInfo\": {\"deviceId\": \"SOF-case\",\"clientAppName\": \"VZW-DOTCOM-BBP\",\"intendType\": \"NSE\"},\"data\": {\"lines\": [{\"addfeatures\": []},{\"removeFeatures\": []}]}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "AccessoryInterestialProspect",true,true,true, getFFlag());
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestTest10() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"universalId\": \"id\",\"channelId\": \"VZW-MFA\",\"cartInfo\": {\"deviceId\": \"SOF-case\",\"clientAppName\": \"VZW-DOTCOM-BBP\",\"intendType\": \"NSE\"},\"data\": {\"lines\": [{\"isNewLine\": true,\"numbersharePairingMode\": \"number\"}]}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "AccessoryInterestialProspect",true,false,true, getFFlag());
		Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestTest11() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"OMNI-RETAIL-TAB\",\"cartInfo\": {\"editFromPage\": \"SOF-case\",\"clientAppName\": \"VZW-DOTCOM-BBP\",\"intendType\": \"NSE\"},\"data\": {\"lines\": [{\"isNewLine\": false,\"fiveG\": {}},{\"isNewLine\": true}]}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "AccessoryInterestialProspect",true,true,true, getFFlag());
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestTest12() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"OMNI-RETAIL-TAB\",\"cartInfo\": {\"editFromPage\": \"BundleRecommendationsPage\",\"clientAppName\": \"VZW-DOTCOM-BBP\",\"intendType\": \"NSE\"},\"data\": {\"lines\": [{\"eupNoPromoFlow\": true,\"lineWithSkipMDN\": true,\"preBackOrderDate\": \"date\"}]}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "AccessoryInterestialProspect",true,false,true, getFFlag());
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestTest13() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"OMNI-RETAIL-TAB\",\"cartInfo\": {\"editFromPage\": \"BundleRecommendationsPage\",\"mtnFlow\": \"VZW-DOTCOM-BBP\",\"intendType\": \"NSE\"},\"data\": {\"lines\": [{\"plan\": {},\"isNewLine\": true}]}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "AccessoryInterestialProspect",true,false,true, getFFlag());
		Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestTest14() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"OMNI-RETAIL-TAB\",\"cartInfo\": {\"mtnFlow\": \"PromoBundle\",\"intendType\": \"BYOD\"},\"data\": {\"lines\": [{\"plan\":{},\"buyGetInd\": \"B\",\"customerProvidedMtn\": \"\",\"isNewLine\": true,\"qaIconicTesting\": false}]}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "AccessoryInterestialProspect",true,true,true, getFFlag());
		Assert.assertEquals("BYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestTest15() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"OMNI-RETAIL-TAB\",\"cartInfo\": {\"editDevice\": false,\"intendType\": \"CLNR\"},\"data\": {\"lines\": [{\"buyGetInd\": \"B\",\"customerProvidedMtnType\": \"\",\"isNewLine\": false,\"qaIconicTesting\": true}]}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "AccessoryInterestialProspect",true,false,false, getFFlag());
		Assert.assertEquals("CLNR", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestTest16() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"editDevice\": true,\"intendType\": \"CLNR\"},\"data\": {\"lines\": [{\"clnrInfo\": {},\"isNewLine\": false,\"qaIconicTesting\": true}]}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "AccessoryInterestialProspect",true,false, false, getFFlag());
		Assert.assertEquals("CLNR", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestTest17() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"clientAppName\": \"VZW-DOTCOM-BBP\",\"intendType\": \"AAL\"},\"data\": {\"lines\": [{}]}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "PromoHub",true,true,true, getFFlag());
		Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestTest18() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"clientAppName\": \"VZW-DOTCOM-BBP\",\"intendType\": \"\"},\"data\": {\"lines\": [{}]},\"preConfigured\": true}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "PromoHub",true,true,true, getFFlag());
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestTest19() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"editDevice\": true,\"expressCheckout\": true,\"intendType\": \"EUPBYOD\",\"clientAppName\": \"name\",\"processAction\": \"add\"},\"data\": {\"lines\": [{\"clnrInfo\": {},\"isNewLine\": false,\"qaIconicTesting\": true}]}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "AccessoryInterestialProspect",true,false, false, getFFlag());
		Assert.assertEquals("EUPBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestTest20() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"editDevice\": true,\"expressCheckout\": false,\"intendType\": \"AccountGrowth\"},\"data\": {\"lines\": [{\"clnrInfo\": {},\"isNewLine\": false,\"qaIconicTesting\": true}]}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "AccessoryInterestialProspect",true,false,true, getFFlag());
		Assert.assertEquals("AccountGrowth", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestTest21() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"editDevice\": true,\"expressCheckout\": true,\"intendType\": \"EUPBYOD\",\"clientAppName\": \"name\",\"processAction\": \"add\"},\"data\": {\"lines\": [{\"clnrInfo\": {},\"isNewLine\": false,\"qaIconicTesting\": true}]}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "AccessoryInterestialProspect",true,false, false, getFFlag());
		Assert.assertEquals("EUPBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestTest22() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"OMNI-RETAIl-TAB\",\"cartInfo\": {\"editDevice\": true,\"expressCheckout\": true,\"intendType\": \"EUPBYOD\",\"clientAppName\": \"VZW-ECOM\",\"processAction\": \"addSim\"},\"data\": {\"lines\": [{\"clnrInfo\": {},\"isNewLine\": false,\"qaIconicTesting\": true}]}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "AccessoryInterestialProspect",true,true,true, getFFlag());
		Assert.assertEquals("EUPBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestTest23() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"OMNI-RETAIL-TAB\",\"cartInfo\": {\"editDevice\": true,\"expressCheckout\": true,\"intendType\": \"EUPBYOD\",\"clientAppName\": \"name\",\"processAction\": \"addSim\"},\"data\": {\"lines\": [{\"clnrInfo\": {},\"isNewLine\": false,\"qaIconicTesting\": true}]}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "AccessoryInterestialProspect",true,true,true, getFFlag());
		Assert.assertEquals("EUPBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestTest24() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"OMNI-RETAIL\",\"cartInfo\": {\"editDevice\": true,\"expressCheckout\": true,\"intendType\": \"\",\"clientAppName\": \"name\",\"processAction\": \"addSim\"},\"data\": {\"lines\": [{\"clnrInfo\": {},\"isNewLine\": false,\"qaIconicTesting\": true}]}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "AccessoryInterestialProspect",true,true,true, getFFlag());
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestTest25() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"OMNI-RETAIL\",\"cartInfo\": {\"editDevice\": true,\"expressCheckout\": true,\"intendType\": \"AAL\",\"clientAppName\": \"name\",\"processAction\": \"addSim\"},\"data\": {\"lines\": [{\"clnrInfo\": {},\"isNewLine\": false,\"qaIconicTesting\": true}]}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "AccessoryInterestialProspect",true,false,true, getFFlag());
		Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestTest26() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\", \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-DOTCOM-BBP\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": { \"esimFlowType\":\"LostICCIDProfile\", \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\",\"tradeInPromoSelected\": \"promo283838\"  }] }}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "PromoHub",true,true,true, getFFlag());
		Assert.assertEquals("EUPBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestTest27() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\", \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-DOTCOM-BBP\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": { \"esimFlowType\":\"PendingOrder\", \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\" ,\"tradeInPromoSelected\": \"promo283838\" }] }}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "PromoHub",true,false,true, getFFlag());
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestTest28() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\", \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-DOTCOM-BBP\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": { \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "PromoHub",true,true,true, getFFlag());
		Assert.assertEquals("EUP", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
    @Test
	public void formatAddDeviceRequestTestOneClick() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"processStep\":\"GridWallPDP\",\"processingMTN\":\"8042128259\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"number_share_capable\":\"Y\",\"creditAppNum\":\"264155557\",\"isQuoteCart\":false,\"oneClick\":true},\"data\":{\"lines\":[{\"mtn\":\"8042128259\",\"lineDeviceDollar\":0,\"upgradeReasonCode\":\"\",\"device\":{\"category\":\"\",\"deviceId\":\"356172094636930\",\"id\":\"MTAV2LL/A\",\"contractTerm\":\"MONTH_TO_MONTH\",\"dppMonths\":\"\",\"isCustomerProvidedEquipment\":false,\"amount\":1349.99},\"sim\":{\"id\":\"DFILLSIM5G-SA-A\",\"iccid\":\"89148000004739209396\",\"isCustomerProvidedSIM\":false},\"isKeepingExistingEqProtection\":true,\"ispuFlow\":false,\"newLineOrAAL\":true,\"isNewLine\":true,\"depletionLocationCode\":\"\",\"depletionType\":\"L\",\"sddZipCode\":\"\",\"preBackOrderDate\":\"\",\"triggerPricingValidation\":true,\"customerType\":\"N\"}],\"selectedMtn\":\"\",\"totalDeviceDollar\":null}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,true,true, getFFlag());
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestPrepayExistingCust() throws JsonMappingException, JsonProcessingException {
		String requestString ="{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"processStep\":\"GridWallPDP\",\"processingMTN\":\"9012084401\",\"processAction\":\"addDevice\",\"intendType\":\"AAL\",\"number_share_capable\":\"Y\",\"creditAppNum\":\"428012111\",\"isQuoteCart\":false,\"isPrepayCart\":\"Y\",\"customerType\":\"U\"},\"data\":{\"lines\":[{\"mtn\":\"9012084401\",\"lineDeviceDollar\":0,\"upgradeReasonCode\":\"\",\"device\":{\"category\":\"Smartphones\",\"deviceId\":\"\",\"id\":\"SMF721ULVEV\",\"contractTerm\":\"MONTH_TO_MONTH\",\"dppMonths\":\"\",\"isCustomerProvidedEquipment\":false,\"amount\":1059.99},\"sim\":{\"id\":\"EMBDSIM5GSA\",\"iccid\":\"\",\"isCustomerProvidedSIM\":false},\"isKeepingExistingEqProtection\":true,\"ispuFlow\":false,\"newLineOrAAL\":true,\"isNewLine\":true,\"depletionLocationCode\":\"\",\"depletionType\":\"L\",\"sddZipCode\":\"\",\"preBackOrderDate\":\"\",\"triggerPricingValidation\":true,\"customerType\":\"N\"}],\"selectedMtn\":\"\",\"totalDeviceDollar\":null}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,true,true, getFFlag());
		Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddFeaturesRequestoneClickTestPrepay() throws IOException {
		String sampleUIRequestString="{\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"\",\"intendType\":\"NSEBYOD\",\"cartId\":\"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\":\"SOF-123445\",\"accountNumber\":\"account\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-DOTCOM-BBP\",\"intent\":\"Inline\",\"rpsIntent\":\"rpsIntent\",\"oneClick\":true,\"isPrepayCart\":\"Y\"},\"data\":{\"checkAutoPayDiscountEligible\":\"checkAutoPayDiscountEligible\",\"lines\":[{\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\"}}";
		AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
		AddFeaturesPEGARequest pegaRequest = new AddFeaturesPEGARequest();
		AddFeaturesPEGARequest response = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
		Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddFeaturesRequestOneClickTestPrepayAAL() throws IOException {
		String sampleUIRequestString="{\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"\",\"intendType\":\"AAL\",\"cartId\":\"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\":\"SOF-123445\",\"accountNumber\":\"account\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-DOTCOM-BBP\",\"intent\":\"Inline\",\"rpsIntent\":\"rpsIntent\",\"oneClick\":true,\"isPrepayCart\":\"Y\"},\"data\":{\"checkAutoPayDiscountEligible\":\"checkAutoPayDiscountEligible\",\"lines\":[{\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\"}}";
		AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
		AddFeaturesPEGARequest pegaRequest = new AddFeaturesPEGARequest();
		AddFeaturesPEGARequest response = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
		Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestMvaProspectTest() throws JsonMappingException, JsonProcessingException {
		//String requestString = "{\"appUniversalId\": \"abcd\",\"channelId\": \"VZW-MFA-ANDROID\",\"cartInfo\": {\"deviceId\": \"SOF-case\",\"clientAppName\": \"VZW-MFA-ANDROID\",\"intendType\": \"NSE\"},\"data\": {\"lines\": [{\"isNewLine\": true,\"numbersharePairingMode\": \"number\"}]}}";
		String requestString = "{\"appUniversalId\": \"abcd\",\"channelId\": \"VZW-MFA\",\"cartInfo\": {\"deviceId\": \"SOF-case\",\"clientAppName\": \"VZW-DOTCOM-BBP\",\"intendType\": \"NSE\"},\"data\": {\"lines\": [{}]}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,true,true, getFFlag());
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddFeaturesRequestOneClickTestPrepayBYOD() throws IOException {
		String sampleUIRequestString="{\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"\",\"intendType\":\"BYOD\",\"cartId\":\"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\":\"SOF-123445\",\"accountNumber\":\"account\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-DOTCOM-BBP\",\"intent\":\"Inline\",\"rpsIntent\":\"rpsIntent\",\"oneClick\":true,\"isPrepayCart\":\"Y\"},\"data\":{\"checkAutoPayDiscountEligible\":\"checkAutoPayDiscountEligible\",\"lines\":[{\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\"}}";
		AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
		AddFeaturesPEGARequest pegaRequest = new AddFeaturesPEGARequest();
		AddFeaturesPEGARequest response = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
		Assert.assertEquals("BYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void addPlanPEGARequestoneClickTestPrepay() throws IOException {
		String sampleUIRequestString="{\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"\",\"intendType\":\"NSEBYOD\",\"cartId\":\"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\":\"SOF-123445\",\"accountNumber\":\"account\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-DOTCOM-BBP\",\"intent\":\"Inline\",\"rpsIntent\":\"rpsIntent\",\"oneClick\":true,\"isPrepayCart\":\"Y\"},\"data\":{\"checkAutoPayDiscountEligible\":\"checkAutoPayDiscountEligible\",\"lines\":[{\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\"}}";
		AddPlanUIRequest uiRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
		AddPlanPEGARequest pegaRequest = new AddPlanPEGARequest();
		AddPlanPEGARequest response = CartPegaRequestUtil2.formatAddPlanRequest(pegaRequest, uiRequest, true, false, getFFlag(), true);
		Assert.assertEquals("FEA", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void addPlanPEGARequestwithFeatures() throws IOException {
		String sampleUIRequestString="{\"cartInfo\":{\"cartCreator\":\"5182653463\",\"processingMTN\":\"5182653463\",\"processStep\":\"PlanSelection\",\"intendType\":\"CPC\"},\"data\":{\"lines\":[{\"mtn\":\"5182653463\",\"addFeatures\":[{\"id\":\"2621\",\"quantity\":\"1\",\"actionIndicator\":\"A\",\"type\":\"SPO\"},{\"id\":\"2641\",\"quantity\":\"1\",\"actionIndicator\":\"A\",\"type\":\"SPO\"}],\"removeFeatures\":[]}],\"parentMtn\":\"\"}}";
		AddPlanUIRequest uiRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
		AddPlanPEGARequest pegaRequest = new AddPlanPEGARequest();
		AddPlanPEGARequest response = CartPegaRequestUtil2.formatAddPlanRequest(pegaRequest, uiRequest, true, false, getFFlag(), true);
		Assert.assertEquals("FEA", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());

		//addPlanPEGARequestPlanwithFeatures
		sampleUIRequestString="{\"cartInfo\":{\"cartCreator\":\"5182653463\",\"processingMTN\":\"5182653463\",\"processStep\":\"PlanSelection\",\"intendType\":\"CPC\"},\"data\":{\"lines\":[{\"mtn\":\"5182653463\",\"plan\":{\"id\":\"50432\",\"isRecommendedPlan\":false,\"recommender\":\"\"},\"addFeatures\":[{\"id\":\"2621\",\"quantity\":\"1\",\"actionIndicator\":\"A\",\"type\":\"SPO\"},{\"id\":\"2641\",\"quantity\":\"1\",\"actionIndicator\":\"A\",\"type\":\"SPO\"}],\"removeFeatures\":[]}],\"parentMtn\":\"\"}}";
		uiRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
		response = CartPegaRequestUtil2.formatAddPlanRequest(pegaRequest, uiRequest, true, false, getFFlag(), true);
		Assert.assertEquals("CPC", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());

		//addPlanPEGARequestPlanwithFeatures1
		sampleUIRequestString="{\"cartInfo\":{\"cartCreator\":\"5182653463\",\"processingMTN\":\"5182653463\",\"processStep\":\"NEXTGENConfiguratorPage\",\"intendType\":\"CPC\"},\"data\":{\"lines\":[{\"mtn\":\"5182653463\",\"plan\":{\"id\":\"50432\",\"isRecommendedPlan\":false,\"recommender\":\"\"},\"addFeatures\":[{\"id\":\"2621\",\"quantity\":\"1\",\"actionIndicator\":\"A\",\"type\":\"SPO\"},{\"id\":\"2641\",\"quantity\":\"1\",\"actionIndicator\":\"A\",\"type\":\"SPO\"}],\"removeFeatures\":[]}],\"parentMtn\":\"\"}}";
		uiRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
		response = CartPegaRequestUtil2.formatAddPlanRequest(pegaRequest, uiRequest, true, false, getFFlag(), true);
		Assert.assertEquals("CPC", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());

		//addPlanPEGARequestPlanwithFeatures2
		sampleUIRequestString = "{\"cartInfo\":{\"cartCreator\":\"5182653463\",\"processingMTN\":\"5182653463\",\"processStep\":\"NEXTGENConfiguratorPage\",\"intendType\":\"CPC\"},\"data\":{\"lines\":[{\"mtn\":\"5182653463\",\"plan\":{\"id\":\"50432\",\"isRecommendedPlan\":false,\"recommender\":\"\"},\"addFeatures\":[{\"id\":\"2621\",\"quantity\":\"1\",\"actionIndicator\":\"A\",\"type\":\"SPO\"},{\"id\":\"2641\",\"quantity\":\"1\",\"actionIndicator\":\"A\",\"type\":\"SPO\"}],\"removeFeatures\":[]}],\"parentMtn\":\"\"}}";
		uiRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
		response = CartPegaRequestUtil2.formatAddPlanRequest(pegaRequest, uiRequest, true, false, getFFlag(), true);
		Assert.assertEquals("CPC", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}

	@Test
	public void addPlanPEGARequestPlanAddressTest() throws IOException {
		String sampleUIRequestString="{\"cartInfo\":{\"cartCreator\":\"5182653463\",\"processingMTN\":\"5182653463\",\"processStep\":\"PlanSelection\",\"intendType\":\"NSE\",\"city\": \"BATON ROUGE\",\"addressLine1\": \"1 ONE AMERICAN PL\",\"state\": \"LA\",\"zipCode\": \"87001\"},\"data\":{\"enableFcc\": true,\"lines\":[{\"mtn\":\"5182653463\",\"plan\":{\"id\":\"50432\",\"isRecommendedPlan\":false,\"recommender\":\"\"},\"addFeatures\":[{\"id\":\"2621\",\"quantity\":\"1\",\"actionIndicator\":\"A\",\"type\":\"SPO\"},{\"id\":\"2641\",\"quantity\":\"1\",\"actionIndicator\":\"A\",\"type\":\"SPO\"}],\"removeFeatures\":[]}],\"parentMtn\":\"\"}}";
		AddPlanUIRequest uiRequest = mapper.readValue(sampleUIRequestString, AddPlanUIRequest.class);
		AddPlanPEGARequest pegaRequest = new AddPlanPEGARequest();
		AddPlanPEGARequest response = CartPegaRequestUtil2.formatAddPlanRequest(pegaRequest, uiRequest, true, false, getFFlag(), true);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
		uiRequest.getCartInfo().setIntendType("NSEBYOD");
		AddPlanPEGARequest response1 = CartPegaRequestUtil2.formatAddPlanRequest(pegaRequest, uiRequest, true, false, getFFlag(), true);
		Assert.assertEquals("NSEBYOD", response1.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddAccessoriesRequestoneClickTestPrepayTest() throws IOException {
		String sampleUIRequestString="{\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"\",\"intendType\":\"NSEBYOD\",\"cartId\":\"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\":\"SOF-123445\",\"accountNumber\":\"account\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-DOTCOM-BBP\",\"intent\":\"Inline\",\"rpsIntent\":\"rpsIntent\",\"oneClick\":true,\"isPrepayCart\":\"Y\"},\"data\":{\"checkAutoPayDiscountEligible\":\"checkAutoPayDiscountEligible\",\"lines\":[{\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\"}}";
		AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
		AddAccessoryPEGARequest pegaRequest = new AddAccessoryPEGARequest();
		AddAccessoryPEGARequest response = CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, UIRequest, "oneClickCheckoutForAccessory",true);
		Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddAccessoriesRequestOneClickTestPrepayAAL() throws IOException {
		String sampleUIRequestString="{\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"\",\"intendType\":\"AAL\",\"cartId\":\"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\":\"SOF-123445\",\"accountNumber\":\"account\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-DOTCOM-BBP\",\"intent\":\"Inline\",\"rpsIntent\":\"rpsIntent\",\"oneClick\":true,\"isPrepayCart\":\"Y\"},\"data\":{\"checkAutoPayDiscountEligible\":\"checkAutoPayDiscountEligible\",\"lines\":[{\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\"}}";
		AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
		AddAccessoryPEGARequest pegaRequest = new AddAccessoryPEGARequest();
		AddAccessoryPEGARequest response = CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, UIRequest, "oneClickCheckoutForAccessory",true);
		Assert.assertEquals("AAL", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddAccessoriesRequestOneClickTestPrepayBYOD() throws IOException {
		String sampleUIRequestString="{\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"\",\"intendType\":\"BYOD\",\"cartId\":\"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\":\"SOF-123445\",\"accountNumber\":\"account\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-DOTCOM-BBP\",\"intent\":\"Inline\",\"rpsIntent\":\"rpsIntent\",\"oneClick\":true,\"isPrepayCart\":\"Y\"},\"data\":{\"checkAutoPayDiscountEligible\":\"checkAutoPayDiscountEligible\",\"lines\":[{\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\"}}";
		AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
		AddAccessoryPEGARequest pegaRequest = new AddAccessoryPEGARequest();
		AddAccessoryPEGARequest response = CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, UIRequest,"oneClickCheckoutForAccessory",true);
		Assert.assertEquals("BYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddAccessoriesRequestOneClickTestPrepayDepletionLocation() throws IOException {
		String sampleUIRequestString="{\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"\",\"intendType\":\"BYOD\",\"depletionLocationCode\":\"1000040\",\"cartId\":\"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\":\"SOF-123445\",\"accountNumber\":\"account\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-DOTCOM-BBP\",\"intent\":\"Inline\",\"rpsIntent\":\"rpsIntent\",\"oneClick\":true,\"isPrepayCart\":\"Y\"},\"data\":{\"checkAutoPayDiscountEligible\":\"checkAutoPayDiscountEligible\",\"lines\":[{\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\"}}";
		AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
		AddAccessoryPEGARequest pegaRequest = new AddAccessoryPEGARequest();
		AddAccessoryPEGARequest response = CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, UIRequest,"oneClickCheckoutForAccessory",true);
		Assert.assertEquals("BYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestTelesales() throws JsonMappingException, JsonProcessingException {
		String requestString ="{\"channelId\":\"OMNI-TELESALES\",\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"processStep\":\"GridWallPDP\",\"processingMTN\":\"8042128259\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"number_share_capable\":\"Y\",\"creditAppNum\":\"264155557\",\"isQuoteCart\":false,\"oneClick\":true,\"caseId\":\"SOF-123445\"},\"data\":{\"lines\":[{\"mtn\":\"8042128259\",\"lineDeviceDollar\":0,\"upgradeReasonCode\":\"\",\"device\":{\"category\":\"\",\"deviceId\":\"356172094636930\",\"id\":\"MTAV2LL/A\",\"contractTerm\":\"MONTH_TO_MONTH\",\"dppMonths\":\"\",\"isCustomerProvidedEquipment\":true,\"amount\":1349.99},\"sim\":{\"id\":\"DFILLSIM5G-SA-A\",\"iccid\":\"89148000004739209396\",\"isCustomerProvidedSIM\":true},\"isKeepingExistingEqProtection\":true,\"ispuFlow\":false,\"newLineOrAAL\":true,\"isNewLine\":true,\"depletionLocationCode\":\"\",\"depletionType\":\"L\",\"sddZipCode\":\"\",\"preBackOrderDate\":\"\",\"triggerPricingValidation\":true,\"customerType\":\"N\"}],\"selectedMtn\":\"\",\"totalDeviceDollar\":null}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,true,true, getFFlag());
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatInitiateValidateDeviceSimRequestTest_BYOD() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\":{\"cartId\":\"17983bf1-995f-482e-baa3-a45f4e3a8285\",\"caseId\":\"SOF-14805422-E01\",\"creditAppNum\":\"4048447474\",\"accountNumber\":\"\",\"intent\":\"BYOD\",\"intendType\":\"BYOD\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":\"validateDeviceSim\",\"action\":\"\",\"oneClick\":true,\"locationCode\":\"411057\",\"cartCreator\":\"Creator\",\"sessionId\":\"sessionId\",\"mtnFlow\":\"MTNFlow\"},\"data\":{\"lines\":[{\"mtn\":\"7132494511\",\"mtnType\":\"\",\"eskuId\":\"\",\"device\":{\"id\":\"356704081223650\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":true,\"sim\":{\"id\":\"\",\"sku\":\"\",\"isCustomerProvidedSIM\":false,\"CurrentSimid\":\"\"}}}]},\"disableEsimAtLocalInventory\":false,\"channelId\":\"OMNI_CARE\"}";
        DeviceIdValidationUIRequest UIRequest = new DeviceIdValidationUIRequest();
	        DeviceIdValidationPEGARequest pegaRequest = new DeviceIdValidationPEGARequest();
	        UIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIRequest.class);
	        formater.formatDeviceIdValidationRequest(UIRequest, pegaRequest, new SearchAttributes());
	        StepVerifier.create(Mono.just(pegaRequest))
	                .assertNext(req -> Assert.assertNotNull(pegaRequest))
	                .expectComplete().verify();
	}
	@Test
	public void formatInitiateValidateDeviceSimRequestTest_AAL() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\":{\"cartId\":\"17983bf1-995f-482e-baa3-a45f4e3a8285\",\"caseId\":\"SOF-14805422-E01\",\"creditAppNum\":\"4048447474\",\"processingMTN\":\"7132494511\",\"accountNumber\":\"\",\"intent\":\"AAL\",\"intendType\":\"BYOD\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":\"validateDeviceSim\",\"action\":\"\"},\"data\":{\"lines\":[{\"mtn\":\"7132494511\",\"mtnType\":\"\",\"eskuId\":\"\",\"device\":{\"id\":\"356704081223650\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":false,\"sim\":{\"id\":\"\",\"sku\":\"\",\"isCustomerProvidedSIM\":false,\"CurrentSimid\":\"\"}}}]},\"disableEsimAtLocalInventory\":false}";
		 DeviceIdValidationUIRequest UIRequest = new DeviceIdValidationUIRequest();
	        DeviceIdValidationPEGARequest pegaRequest = new DeviceIdValidationPEGARequest();
	        UIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIRequest.class);
	        formater.formatDeviceIdValidationRequest(UIRequest, pegaRequest, new SearchAttributes());
	        StepVerifier.create(Mono.just(pegaRequest))
	                .assertNext(req -> Assert.assertNotNull(pegaRequest))
	                .expectComplete().verify();
	}
	@Test
	public void formatInitiateValidateDeviceSimRequestTest_SOF() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\":{\"cartId\":\"17983bf1-995f-482e-baa3-a45f4e3a8285\",\"caseId\":\"SOP-14805422-E01\",\"creditAppNum\":\"4048447474\",\"processingMTN\":\"7132494511\",\"accountNumber\":\"\",\"intent\":\"AAL\",\"intendType\":\"BYOD\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":\"validateDeviceSim\",\"action\":\"\"},\"data\":{\"lines\":[{\"mtn\":\"7132494511\",\"mtnType\":\"\",\"eskuId\":\"\",\"device\":{\"id\":\"356704081223650\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":false,\"sim\":{\"id\":\"\",\"sku\":\"\",\"isCustomerProvidedSIM\":false,\"CurrentSimid\":\"\"}}}]},\"disableEsimAtLocalInventory\":false}";
		 DeviceIdValidationUIRequest UIRequest = new DeviceIdValidationUIRequest();
	        DeviceIdValidationPEGARequest pegaRequest = new DeviceIdValidationPEGARequest();
	        UIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIRequest.class);
	        formater.formatDeviceIdValidationRequest(UIRequest, pegaRequest, new SearchAttributes());
	        StepVerifier.create(Mono.just(pegaRequest))
	                .assertNext(req -> Assert.assertNotNull(pegaRequest))
	                .expectComplete().verify();
	}

	@Test
	public void formatInitiateValidateDeviceSimRequestTest_FWA_Exchange() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\":{\"accountNumber\":\"\",\"action\":\"\",\"cartCreator\":\"Creator\",\"cartId\":\"17983bf1-995f-482e-baa3-a45f4e3a8285\",\"creditAppNum\":\"4048447474\",\"intendType\":\"5GHomeRetailRFEX\",\"intent\":\"5GHomeRetailRFEX\",\"locationCode\":\"D593801\",\"processAction\":\"validateDeviceSim\",\"processStep\":\"GridWallPDP\"},\"channelId\":\"OMNI-RETAIL\",\"data\":{\"lines\":[{\"device\":{\"CurrentId\":\"\",\"Flowtype\":\"DEVICE\",\"id\":\"356704081223650\",\"isCustomerProvidedEquipment\":true,\"sim\":{\"CurrentSimid\":\"\",\"id\":\"\",\"isCustomerProvidedSIM\":false,\"sku\":\"\"},\"sku\":\"\",\"smartIMEI\":false},\"eskuId\":\"\",\"mtn\":\"7132494511\",\"mtnType\":\"\"}]},\"disableEsimAtLocalInventory\":false}";
		DeviceIdValidationUIRequest UIRequest = new DeviceIdValidationUIRequest();
		DeviceIdValidationPEGARequest pegaRequest = new DeviceIdValidationPEGARequest();
		UIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIRequest.class);
		formater.formatDeviceIdValidationRequest(UIRequest, pegaRequest, new SearchAttributes());
		StepVerifier.create(Mono.just(pegaRequest))
				.assertNext(req -> Assert.assertNotNull(pegaRequest))
				.expectComplete().verify();
	}

	@Test
	public void formatAddFeaturesRequestAddAccesories() throws IOException {
		String sampleUIRequestString = "{\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"\",\"intendType\":\"AAL\",\"cartId\":\"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\":\"SOF-123445\",\"accountNumber\":\"account\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-DOTCOM-BBP\",\"intent\":\"Inline\",\"rpsIntent\":\"rpsIntent\",\"oneClick\":true,\"isPrepayCart\":\"Y\"},\"data\":{\"checkAutoPayDiscountEligible\":\"checkAutoPayDiscountEligible\",\"lines\":[{\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null,\"accessories\":{\"add\":[{\"sorId\":\"xxx\"}],\"remove\":[{\"sorId\":\"xxx\"}]}}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\"}}";
		AddFeaturesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
		UIRequest.getCartInfo().setDepletionType("F");
		UIRequest.getCartInfo().setIspuFlow(Boolean.TRUE);
		AddFeaturesPEGARequest pegaRequest = new AddFeaturesPEGARequest();
		AddFeaturesPEGARequest response = CartPegaRequestUtil3.formatAddFeaturesRequest(pegaRequest, UIRequest, getFFlag());
		Assert.assertEquals("AAL",
				response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddAccessoriesRequestForRemoveAccessories() throws IOException {
		String sampleUIRequestString="{\"channelId\":\"VZW-DOTCOM\",\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"3043743984\",\"processAction\":\"addAccessoryRecommendations\",\"processStep\":\"PromoHub\",\"intendType\":\"ACC\",\"pageId\":\"PROMOHUB\",\"intent\":\"Accessory\",\"cradleFlowJourney\":\"PromoHub\"},\"data\":{\"validateCart\":true,\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"3043743984\",\"mdnFilterValue\":\"3043743984\",\"removeAccessories\":[{\"id\":\"MGYJ3AM/A\",\"qty\":1,\"isSoftSku\":false,\"accessoryBundle\":false,\"accessorySkuID\":\"MGYJ3AM/A\"}],\"ispuFlow\":false,\"depletionLocationCode\":null}]},\"expressCheckout\":\"true\",\"skipSVC\":true}";
		AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
		AddAccessoryPEGARequest pegaRequest = new AddAccessoryPEGARequest();
		AddAccessoryPEGARequest response1 = CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, UIRequest, "oneClickCheckoutForAccessory",true);
		Assert.assertEquals(CartConstants.PROMO_HUB,
				response1.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCradleFlowJourney());
		AddAccessoryPEGARequest response2 = CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, UIRequest, "oneClickCheckoutForAccessory",false);
		Assert.assertNotEquals(CartConstants.PROMO_HUB,
				response2.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCradleFlowJourney());
	}
	@Test
	public void formatAddAccessoriesRequestForNonDigitalAddAccessories() throws IOException {
		String sampleUIRequestString="{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"3043743984\",\"processAction\":\"addAccessoryRecommendations\",\"processStep\":\"PromoHub\",\"intendType\":\"ACC\",\"pageId\":\"PROMOHUB\",\"intent\":\"Accessory\",\"cradleFlowJourney\":\"PromoHub\"},\"data\":{\"validateCart\":true,\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"3043743984\",\"mdnFilterValue\":\"3043743984\",\"addAccessories\":[{\"id\":\"MGYJ3AM/A\",\"qty\":1,\"isSoftSku\":false,\"accessoryBundle\":false,\"accessorySkuID\":\"MGYJ3AM/A\"}],\"ispuFlow\":false,\"depletionLocationCode\":null}]},\"expressCheckout\":\"true\",\"skipSVC\":true}";
		AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
		AddAccessoryPEGARequest pegaRequest = new AddAccessoryPEGARequest();
		AddAccessoryPEGARequest response = CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, UIRequest, "oneClickCheckoutForAccessory",true);
		Assert.assertNotEquals(CartConstants.PROMO_HUB,
				response.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCradleFlowJourney());
	}
	@Test
	public void formatAddAccessoriesRequestoneClickTestPrepayTestWFW() throws IOException {
		String sampleUIRequestString="{\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"\",\"processAction\":\"xxx\",\"intendType\":\"NSEBYOD\",\"cartId\":\"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\":\"SOF-123445\",\"accountNumber\":\"account\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-DOTCOM-BBP\",\"intent\":\"Inline\",\"rpsIntent\":\"rpsIntent\",\"oneClick\":true,\"isPrepayCart\":\"Y\"},\"data\":{\"checkAutoPayDiscountEligible\":\"checkAutoPayDiscountEligible\",\"lines\":[{\"addAccessories\":[{\"id\":\"CR1000A\",\"qty\":2,\"isSoftSku\":false,\"accountLevelAccessory\":false,\"macId\":\"\",\"macIds\":[\"1CD6BE386883\",\"1CD6BE3868AD\"]}],\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\"}}";
		AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
		AddAccessoryPEGARequest pegaRequest = new AddAccessoryPEGARequest();
		AddAccessoryPEGARequest response = CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, UIRequest, "oneClickCheckoutForAccessory",true);
		Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestIsPromoPDPAndNoPendingOfferExists() throws JsonMappingException, JsonProcessingException {
		String requestString ="{\"channelId\":\"OMNI-TELESALES\",\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"processStep\":\"GridWallPDP\",\"processingMTN\":\"8042128259\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"number_share_capable\":\"Y\",\"creditAppNum\":\"264155557\",\"isQuoteCart\":false,\"oneClick\":true,\"caseId\":\"SOF-123445\",\"isPromoPDP\" : true, \"noPendingOfferExists\" : true},\"data\":{\"lines\":[{\"mtn\":\"8042128259\",\"lineDeviceDollar\":0,\"upgradeReasonCode\":\"\",\"device\":{\"category\":\"\",\"deviceId\":\"356172094636930\",\"id\":\"MTAV2LL/A\",\"contractTerm\":\"MONTH_TO_MONTH\",\"dppMonths\":\"\",\"isCustomerProvidedEquipment\":true,\"amount\":1349.99},\"sim\":{\"id\":\"DFILLSIM5G-SA-A\",\"iccid\":\"89148000004739209396\",\"isCustomerProvidedSIM\":true},\"isKeepingExistingEqProtection\":true,\"ispuFlow\":false,\"newLineOrAAL\":true,\"isNewLine\":true,\"depletionLocationCode\":\"\",\"depletionType\":\"L\",\"sddZipCode\":\"\",\"preBackOrderDate\":\"\",\"triggerPricingValidation\":true,\"customerType\":\"N\"}],\"selectedMtn\":\"\",\"totalDeviceDollar\":null}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,true,true, getFFlag());
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestIsPromoPDPAndNoPendingOfferExistsFalseScenario() throws JsonMappingException, JsonProcessingException {
		String requestString ="{\"channelId\":\"OMNI-TELESALES\",\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"processStep\":\"GridWallPDP\",\"processingMTN\":\"8042128259\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"number_share_capable\":\"Y\",\"creditAppNum\":\"264155557\",\"isQuoteCart\":false,\"oneClick\":true,\"caseId\":\"SOF-123445\",\"isPromoPDP\" : false, \"noPendingOfferExists\" : false},\"data\":{\"lines\":[{\"mtn\":\"8042128259\",\"lineDeviceDollar\":0,\"upgradeReasonCode\":\"\",\"device\":{\"category\":\"\",\"deviceId\":\"356172094636930\",\"id\":\"MTAV2LL/A\",\"contractTerm\":\"MONTH_TO_MONTH\",\"dppMonths\":\"\",\"isCustomerProvidedEquipment\":true,\"amount\":1349.99},\"sim\":{\"id\":\"DFILLSIM5G-SA-A\",\"iccid\":\"89148000004739209396\",\"isCustomerProvidedSIM\":true},\"isKeepingExistingEqProtection\":true,\"ispuFlow\":false,\"newLineOrAAL\":true,\"isNewLine\":true,\"depletionLocationCode\":\"\",\"depletionType\":\"L\",\"sddZipCode\":\"\",\"preBackOrderDate\":\"\",\"triggerPricingValidation\":true,\"customerType\":\"N\"}],\"selectedMtn\":\"\",\"totalDeviceDollar\":null}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,true,true, getFFlag());
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestIsPromoPDPWithEUPScenario() throws JsonMappingException, JsonProcessingException {
		String requestString ="{\"channelId\":\"OMNI-TELESALES\",\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"processStep\":\"GridWallPDP\",\"processingMTN\":\"8042128259\",\"processAction\":\"addDevice\",\"intendType\":\"EUP\",\"number_share_capable\":\"Y\",\"creditAppNum\":\"264155557\",\"isQuoteCart\":false,\"oneClick\":true,\"caseId\":\"SOF-123445\",\"isPromoPDP\" : true, \"noPendingOfferExists\" : false},\"data\":{\"lines\":[{\"mtn\":\"8042128259\",\"lineDeviceDollar\":0,\"upgradeReasonCode\":\"\",\"device\":{\"category\":\"\",\"deviceId\":\"356172094636930\",\"id\":\"MTAV2LL/A\",\"contractTerm\":\"MONTH_TO_MONTH\",\"dppMonths\":\"\",\"isCustomerProvidedEquipment\":true,\"amount\":1349.99},\"sim\":{\"id\":\"DFILLSIM5G-SA-A\",\"iccid\":\"89148000004739209396\",\"isCustomerProvidedSIM\":true},\"isKeepingExistingEqProtection\":true,\"ispuFlow\":false,\"newLineOrAAL\":true,\"isNewLine\":true,\"depletionLocationCode\":\"\",\"depletionType\":\"L\",\"sddZipCode\":\"\",\"preBackOrderDate\":\"\",\"triggerPricingValidation\":true,\"customerType\":\"N\"}],\"selectedMtn\":\"\",\"totalDeviceDollar\":null}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,true,true, getFFlag());
		Assert.assertEquals("Upgrade", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getIntent());
	}
	@Test
	public void formatAddZipcodeRequest() throws JsonMappingException, JsonProcessingException {
		String requestString ="{\"channelId\":\"VZW-DOTCOM-BBP\",\"enableFcc\": true,\"cartInfo\":{\"cartId\":\"f0679741-4223-472b-a025-98824801ec24\",\"action\":\"UPDATE\",\"zipCode\":\"07920\",\"city\": \"BATON ROUGE\",\"addressLine1\": \"1 ONE AMERICAN PL\",\"state\": \"LA\",\"intendType\":\"NSEBYOD\",\"itemType\":\"USERCONTACTINFO\"},\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"LocationDetails\",\"processAction\":\"addZipCode\"}}";
		AddZipCodeUIRequest uiRequest = mapper.readValue(requestString, AddZipCodeUIRequest.class);
		AddZipcodePEGARequest response = CartPegaRequestUtil4.formatAddZipcodeRequest(new AddZipcodePEGARequest(), uiRequest);
		Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddAccessoriesRequestoneClickTestPrepayDepletionLocation() throws IOException {
		String sampleUIRequestString="{\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"\",\"processAction\":\"xxx\",\"intendType\":\"BYOD\",\"cartId\":\"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\":\"SOF-123445\",\"accountNumber\":\"account\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-DOTCOM-BBP\",\"intent\":\"Inline\",\"rpsIntent\":\"rpsIntent\",\"oneClick\":true,\"isPrepayCart\":\"Y\"},\"data\":{\"checkAutoPayDiscountEligible\":\"checkAutoPayDiscountEligible\",\"depletionLocationCode\":\"1000040\",\"lines\":[{\"addAccessories\":[{\"id\":\"CR1000A\",\"qty\":2,\"isSoftSku\":false,\"accountLevelAccessory\":false,\"macId\":\"\",\"macIds\":[\"1CD6BE386883\",\"1CD6BE3868AD\"]}],\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\"}}";
		AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
		AddAccessoryPEGARequest pegaRequest = new AddAccessoryPEGARequest();
		AddAccessoryPEGARequest response = CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, UIRequest, "oneClickCheckoutForAccessory",true);
		Assert.assertEquals("BYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddAccessoriesRequestoneClickTestPrepayDepletionLocation2() throws IOException {
		String sampleUIRequestString="{\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"\",\"processAction\":\"xxx\",\"intendType\":\"BYOD\",\"cartId\":\"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\":\"SOP-123445\",\"accountNumber\":\"account\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-DOTCOM-BBP\",\"intent\":\"Inline\",\"rpsIntent\":\"rpsIntent\",\"oneClick\":true,\"isPrepayCart\":\"Y\"},\"data\":{\"checkAutoPayDiscountEligible\":\"checkAutoPayDiscountEligible\",\"depletionLocationCode\":\"1000040\",\"lines\":[{\"addAccessories\":[{\"id\":\"CR1000A\",\"qty\":2,\"isSoftSku\":false,\"accountLevelAccessory\":false,\"macId\":\"\",\"macIds\":[\"1CD6BE386883\",\"1CD6BE3868AD\"]}],\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\"}}";
		AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
		AddAccessoryPEGARequest pegaRequest = new AddAccessoryPEGARequest();
		AddAccessoryPEGARequest response = CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, UIRequest, "oneClickCheckoutForAccessory",true);
		Assert.assertEquals("BYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddAccessoriesRequestoneClickTestPrepayDepletionLocation3() throws IOException {
		String sampleUIRequestString="{\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"\",\"processAction\":\"xxx\",\"intendType\":\"BYOD\",\"cartId\":\"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\":\"SOF-123445\",\"accountNumber\":\"account\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-DOTCOM-BBP\",\"intent\":\"Inline\",\"rpsIntent\":\"rpsIntent\",\"oneClick\":true,\"isPrepayCart\":\"Y\"},\"data\":{\"checkAutoPayDiscountEligible\":\"checkAutoPayDiscountEligible\",\"depletionLocationCode\":\"\",\"lines\":[{\"addAccessories\":[{\"id\":\"CR1000A\",\"qty\":2,\"isSoftSku\":false,\"accountLevelAccessory\":false,\"macId\":\"\",\"macIds\":[\"1CD6BE386883\",\"1CD6BE3868AD\"]}],\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\"}}";
		AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
		AddAccessoryPEGARequest pegaRequest = new AddAccessoryPEGARequest();
		AddAccessoryPEGARequest response = CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, UIRequest, "oneClickCheckoutForAccessory",true);
		Assert.assertEquals("BYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddAccessoriesRequestoneClickTestPrepayDepletionLocation4() throws IOException {
		String sampleUIRequestString="{\"channelId\":\"VZW-DOTCOM-BBP\",\"cartInfo\":{\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"\",\"processAction\":\"xxx\",\"intendType\":\"BYOD\",\"cartId\":\"7326249e-f93a-462b-9f9c-299d18f370b2\",\"caseId\":\"SOF-123445\",\"accountNumber\":\"account\",\"editPlanClick\":true,\"deviceType\":\"deviceType\",\"accountLevelPlan\":true,\"isSmartLocator\":true,\"expressCheckout\":true,\"promoHubJourney\":true,\"mtnFlow\":\"mtn\",\"clientAppName\":\"VZW-DOTCOM-BBP\",\"intent\":\"Inline\",\"rpsIntent\":\"rpsIntent\",\"oneClick\":true,\"isPrepayCart\":\"Y\"},\"data\":{\"checkAutoPayDiscountEligible\":\"checkAutoPayDiscountEligible\",\"lines\":[{\"addAccessories\":[{\"id\":\"CR1000A\",\"qty\":2,\"isSoftSku\":false,\"accountLevelAccessory\":false,\"macId\":\"\",\"macIds\":[\"1CD6BE386883\",\"1CD6BE3868AD\"]}],\"nickName\":\"name\",\"promoRejectionIndicator\":true,\"numbersharePairingMode\":\"numbersharePairingMode\",\"addFeatures\":[{}],\"deviceTypeSelected\":\"\",\"selectedOffers\":[{}],\"device\":{},\"mtn\":null,\"contractTerm\":\"contractTerm\",\"trialSelected\":\"true\",\"subscriptionSelected\":\"true\",\"trialAllowance\":\"abcd\",\"trialValidityPeriod\":\"abcd\",\"plan\":null}],\"parentMtn\":null,\"retrieveFeatureLossReferenceData\":\"retrieveFeatureLossReferenceData\",\"effectiveDate\":\"effectiveDate\"}}";
		AddAccessoriesUIRequest UIRequest = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
		AddAccessoryPEGARequest pegaRequest = new AddAccessoryPEGARequest();
		AddAccessoryPEGARequest response = CartPegaRequestUtil3.formatAddAccessoriesRequest(pegaRequest, UIRequest, "oneClickCheckoutForAccessory",true);
		Assert.assertEquals("BYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatRetrieveActivationStatusRequestTest4() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"processStep\": \"promo\",\"sessionId\": \"session\",\"accountNumber\": \"4567\",\"mtnFlow\": \"mtn\",\"creditAppNum\": \"credit\",\"intendType\": \"NSE\"},\"data\": {\"lines\": []},\"lastRetry\":true}";
		RetrieveActivationStatusUIRequest uiRequest = mapper.readValue(requestString, RetrieveActivationStatusUIRequest.class);
		RetrieveActivationStatusPEGARequest response = CartPegaRequestUtil7.formatRetrieveActivationStatusRequest(new RetrieveActivationStatusPEGARequest(), uiRequest);
		Assert.assertEquals(true, response.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getLastRetry());
	}
	@Test
	public void formatAddDeviceRequest2Test() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\":{\"caseId\":\"SOF-case\",\"byodESim\":\"byod\",\"universalId\":\"Y\",\"intendType\":\"DEO\"},\"data\":{\"couponCode\":\"testCoupon\",\"lines\":[{\"portInNumber\":\"9905629442\",\"device\":{\"connectedCarDetails\":{}}}]}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,true,true, getFFlag());
		Assert.assertEquals("DEO", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestUnverifiedExceptionTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\": {\"caseId\": \"SOF-case\",\"byodESim\": \"byod\",\"universalId\": \"Y\",\"intendType\": \"DEO\"},\"data\": {\"lines\": [{\"device\": {\"connectedCarDetails\": {}},\"idVerifyStatus\":\"FAIL\",\"highRiskSimswapDelayActivation\":\"true\"}]}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,true,true, getFFlag());
		Assert.assertEquals("DEO", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestPositiveCustomerConsentTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\":{\"caseId\":\"SOF-case\",\"byodESim\":\"byod\",\"universalId\":\"Y\",\"intendType\":\"DEO\"},\"data\":{\"couponCode\":\"testCoupon\",\"lines\":[{\"portInNumber\":\"9905629442\",\"idVerifyStatus\":\"pass\",\"isCustConsentAcceptedSMSBlast\":true,\"device\":{\"connectedCarDetails\":{}}}]}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,true,true, getFFlag());
		Assert.assertEquals("DEO", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequest_withPastDue() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"8644919045\",\"processStep\":\"DPPSummary\",\"intendType\":\"EUP\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"Y\",\"edgeUpSelected\":\"N\",\"processAction\":\"addBuyoutAmtAndDevice\",\"mtnFlow\":\"G\",\"pastDueAccepted\":\"Y\",\"pastdue\":{\"amount\":\"163.04\"}},\"data\":{\"lines\":[{\"mtn\":\"8644919045\",\"isEdgeBuyOut\":true}],\"effectiveDate\":\"\"}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,true,true, getFFlag());
		Assert.assertEquals("Y", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getPastDueAccepted());
		Assert.assertNotNull(response.getServiceBody().getServiceRequest().getContext().getCartInfo().getPastdue());
	}
	public static void setRefundOrderdetails(SalesOrderAdjustmentUIRequest uiRequest){
		uiRequest.setRefundOrderdetails(new SalesOrderAdjustmentOrderDetails());
		uiRequest.getRefundOrderdetails().setAddressValidationRequired(true);
		uiRequest.getRefundOrderdetails().setCreditValidationRequired(true);
		uiRequest.getRefundOrderdetails().setLines(new LineDetails());
		LineInfo[] lineInfos=new LineInfo[]{};
		uiRequest.getRefundOrderdetails().getLines().setLineInfo(lineInfos);
	}
	@Test
	public void formatClearAndContinueRequestProcessStepTest(){
		ClearAndContinuePegaRequest pegaRequest = new ClearAndContinuePegaRequest();
		ClearAndContinueUIRequest uiRequest = new ClearAndContinueUIRequest();
		uiRequest.setCartInfo(new CartInfo());
		uiRequest.getCartInfo().setProcessStep("SecondNumberPage");
		ClearAndContinuePegaRequest response = CartPegaRequestUtil6.formatClearAndContinueRequest(pegaRequest, uiRequest);
		Assert.assertEquals("SecondNumberPage", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getProcessStep());
		uiRequest.getCartInfo().setProcessStep("MTNSelectionPage");
		response = CartPegaRequestUtil6.formatClearAndContinueRequest(pegaRequest, uiRequest);
		Assert.assertEquals("MTNSelectionPage", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getProcessStep());
		uiRequest.getCartInfo().setProcessStep("");
		response = CartPegaRequestUtil6.formatClearAndContinueRequest(pegaRequest, uiRequest);
		Assert.assertEquals("", response.getServiceBody().getServiceRequest().getContext().getContextInfo().getProcessStep());
	}
	@Test
	public void formatCpcCartRequestTest(){
		CpcFeatureRequest pegaRequest = new CpcFeatureRequest();
		CustomerInfo customerInfo=new CustomerInfo();
		customerInfo.setAccountNumber("abc123");
		customerInfo.setCartCreator("mtn");
		CartPegaRequestUtil9.formatCpcCartRequest(pegaRequest, customerInfo,new AddPlanAndDeviceUIRequest());
		assertTrue(true);
	}
	@Test
	public void formatInitiateValidateDeviceSimRequestTest_DVMFlow() throws JsonMappingException, JsonProcessingException {
		RequestAccess reqAccess = new RequestAccess();
		reqAccess.getCookies().add("dvmConversion", new HttpCookie("dvmConversion", "true"));
		RequestAccessContext.updateRequestData(reqAccess);
		String sampleUIRequestString = "{\"cartInfo\":{\"cartId\":\"17983bf1-995f-482e-baa3-a45f4e3a8285\",\"caseId\":\"SOF-14805422-E01\",\"creditAppNum\":\"4048447474\",\"processingMTN\":\"7132494511\",\"accountNumber\":\"\",\"intent\":\"BYOD\",\"intendType\":\"BYOD\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":\"validateDeviceSim\",\"action\":\"\"},\"data\":{\"lines\":[{\"mtn\":\"7132494511\",\"mtnType\":\"\",\"eskuId\":\"\",\"device\":{\"id\":\"356704081223650\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":false,\"sim\":{\"id\":\"\",\"sku\":\"\",\"isCustomerProvidedSIM\":false,\"CurrentSimid\":\"\"}}}]},\"disableEsimAtLocalInventory\":false}";
		 DeviceIdValidationUIRequest UIRequest = new DeviceIdValidationUIRequest();
	        DeviceIdValidationPEGARequest pegaRequest = new DeviceIdValidationPEGARequest();
	        UIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIRequest.class);
	        formater.formatDeviceIdValidationRequest(UIRequest, pegaRequest, new SearchAttributes());
	        Assert.assertEquals(CartConstants.NEW_CUSTOMER, pegaRequest.getServiceBody().getServiceRequest().getContext().getCustomerInfo().getCustomerType());
	}
	@Test
	public void checkIfUpgradeSkipTradeinTest() throws JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/addPromoIntentOfferInterstialRequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		AddPromoIntentUIRequest uiRequest = mapper.readValue(requestString, AddPromoIntentUIRequest.class);
		uiRequest.getCartInfo().setIntendType(CartConstants.EUP);
		CartPegaRequestUtil5.checkIfUpgradeSkipTradein(uiRequest);
	}
	@Test
	public void formatAddPromoIntentRequestTest() throws JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/addPromoIntentOfferInterstialRequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		AddPromoIntentUIRequest uiRequest = mapper.readValue(requestString, AddPromoIntentUIRequest.class);
		uiRequest.getCartInfo().setIntendType(CartConstants.EUP);
		CartPegaRequestUtil5.formatAddPromoIntentRequest(uiRequest , new AddPromoIntentPEGARequest(),true);
	}
	@Test
	public void ngdDeleteCartTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\": \"VZW-DOTCOM\",\"ngdFlow\": true,\"data\": {\"lines\": [{}]},\"cartInfo\": {\"expressCheckout\": true,\"intendType\": \"NSE\"},\"rfexExchangeShopDetails\": {\"mtn\": \"mtn\"}}";
		DeleteCartUIRequest uiRequest = mapper.readValue(requestString, DeleteCartUIRequest.class);
		DeleteCartPegaRequest response = CartPegaRequestUtil7.ngdCreateDeleteCartPegaRequest(new DeleteCartPegaRequest(), uiRequest, false);
		Assert.assertEquals("NSE", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatAddDeviceRequestLgpo_Test() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":\"addDeviceSim\",\"intendType\":\"NSEBYOD\",\"zipCode\":\"\",\"addressLine1\":\"\",\"city\":\"\",\"state\":\"\"},\"data\":{\"subFlow\":\"\",\"lines\":[{\"mtn\":\"newLine1\",\"device\":{\"id\":\"3H725LL/A\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"\",\"contractTerm\":\"MONTH_TO_MONTH\",\"deviceId\":\"\",\"smartIMEI\":true,\"category\":\"Smartphone\",\"rawCategory\":\"4G Smartphone\",\"prodType\":\"4GSmartphone-IN\",\"byodESimPhone\":false},\"sim\":{\"id\":\"DFILLSIM5G-SA-A\",\"isCustomerProvidedSIM\":false,\"iccid\":\"\",\"eSIM\":\"\"},\"isNewLine\":true,\"ispuFlow\":false,\"depletionType\":\"F\",\"depletionLocationCode\":\"\",\"isKeepingExistingEqProtection\":true}],\"enableFcc\":true,\"isLGPOEligible\":true}}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "",true,true,true, getFFlag());
		Assert.assertEquals("NSEBYOD", response.getServiceBody().getServiceRequest().getContext().getCartInfo().getIntendType());
	}
	@Test
	public void formatCpcCartRequestChannelIdTest() throws JsonMappingException,JsonProcessingException {
		String requestString ="{\"cartInfo\":{\"rylEcpdUrl\":\"ryl\",\"caseId\":\"SOF-case\",\"processStep\":\"orderNow\",\"action\":\"Resume\",\"intendType\":\"EUP_5G\"},\"data\":{\"lines\":[]},\"channelId\":\"VZW-DOTCOM-MOB\"}";
		AddPlanAndDeviceUIRequest uiRequest = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		CpcFeatureRequest pegaRequest = new CpcFeatureRequest();
		CustomerInfo customerInfo=new CustomerInfo();
		customerInfo.setAccountNumber("abc123");
		customerInfo.setCartCreator("mtn");
		CartPegaRequestUtil9.formatCpcCartRequest(pegaRequest, customerInfo, uiRequest);
		assertTrue(true);
	}
	@Test
	public void formatInitiateValidateDeviceSimRequestTest_RFEX() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\":{\"cartId\":\"17983bf1-995f-482e-baa3-a45f4e3a8285\",\"caseId\":\"SOF-14805422-E01\",\"creditAppNum\":\"4048447474\",\"processingMTN\":\"7132494511\",\"accountNumber\":\"\",\"intent\":\"AAL\",\"intendType\":\"AAL\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":\"validateDeviceSim\",\"action\":\"\"},\"data\":{\"lines\":[{\"mtn\":\"7132494511\",\"mtnType\":\"\",\"eskuId\":\"\",\"device\":{\"id\":\"356704081223650\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":false,\"sim\":{\"id\":\"\",\"sku\":\"\",\"isCustomerProvidedSIM\":false,\"CurrentSimid\":\"\"}}}]},\"disableEsimAtLocalInventory\":false}";
		DeviceIdValidationUIRequest UIRequest = new DeviceIdValidationUIRequest();
		DeviceIdValidationPEGARequest pegaRequest = new DeviceIdValidationPEGARequest();
		UIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIRequest.class);
		UIRequest.getCartInfo().setIntent("");
		UIRequest.getCartInfo().setIntendType("");
		formater.formatDeviceIdValidationRequest(UIRequest, pegaRequest, new SearchAttributes());
		StepVerifier.create(Mono.just(pegaRequest)).assertNext(req -> Assert.assertNotNull(pegaRequest)).expectComplete().verify();
		UIRequest.getCartInfo().setIntent(null);
		UIRequest.getCartInfo().setIntendType(null);
		formater.formatDeviceIdValidationRequest(UIRequest, pegaRequest, new SearchAttributes());
		StepVerifier.create(Mono.just(pegaRequest)).assertNext(req -> Assert.assertNotNull(pegaRequest)).expectComplete().verify();
		UIRequest.getCartInfo().setIntent("REX");
		UIRequest.getCartInfo().setIntendType("REX");
		formater.formatDeviceIdValidationRequest(UIRequest, pegaRequest, new SearchAttributes());
		StepVerifier.create(Mono.just(pegaRequest)).assertNext(req -> Assert.assertNotNull(pegaRequest)).expectComplete().verify();
	}
	@Test
	public void formatAddDeviceRequestTest31() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"channelId\":\"VZW-DOTCOM-BBP\", \"cartInfo\": {  \"cartCreator\": \"7169849755\",  \"clientAppName\": \"VZW-DOTCOM-BBP\", \"editDevice\":false ,\"cartId\": \"0663dce6-2103-49e4-ba25-28e55fb94d70\",  \"caseId\": \"SOP-741350-E01\",  \"processingMTN\": \"\",  \"accountNumber\": \"0280106868-00001\",  \"intendType\": \"EUP\" }, \"data\": { \"newLineOrAAL\": false,  \"lines\": [{   \"ispuFlow\": false,   \"mtn\": \"7169849755\",   \"sim\": {    \"id\": \"EMBDSIMTRI\"   },   \"isKeepingExistingEqProtection\": true,   \"device\": {    \"id\": \"GA01221-US\",    \"contractTerm\": \"VERIZON_EDGE\",    \"dppMonths\": \"24\"   },   \"depletionType\": \"F\"  }] }}";
		AddDeviceUIRequest uiRequest = mapper.readValue(requestString, AddDeviceUIRequest.class);
		uiRequest.getCartInfo().setCaseId("");
		uiRequest.getCartInfo().setCartId("");
		uiRequest.getCartInfo().setSkipResumeCase(true);
		AddDevicePEGARequest response = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "PromoHub",true,true,true, getFFlag());
		Assert.assertNotNull(response);
		uiRequest.getCartInfo().setCaseId("");
		uiRequest.getCartInfo().setCartId("cartId");
		uiRequest.getCartInfo().setSkipResumeCase(true);
		AddDevicePEGARequest response1 = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "PromoHub",true,true,true, getFFlag());
		Assert.assertNotNull(response1);
		uiRequest.getCartInfo().setCaseId("caseId");
		uiRequest.getCartInfo().setCartId("");
		uiRequest.getCartInfo().setSkipResumeCase(true);
		AddDevicePEGARequest response2 = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "PromoHub",true,true,true, getFFlag());
		Assert.assertNotNull(response2);
		uiRequest.getCartInfo().setCaseId("");
		uiRequest.getCartInfo().setCartId("");
		uiRequest.getCartInfo().setSkipResumeCase(false);
		AddDevicePEGARequest response3 = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "PromoHub",true,true,true, getFFlag());
		Assert.assertNotNull(response3);
		uiRequest.getCartInfo().setCaseId("");
		uiRequest.getCartInfo().setCartId("");
		uiRequest.getCartInfo().setSkipResumeCase(true);
		AddDevicePEGARequest response4 = CartPegaRequestUtil4.formatAddDeviceRequest(new AddDevicePEGARequest(), uiRequest, "PromoHub",true,true,false, getFFlag());
		Assert.assertNotNull(response4);
	}

	@Test
	public void formatInitiateValidateDeviceSimRequestTest_caseIdNull() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\":{\"cartId\":\"17983bf1-995f-482e-baa3-a45f4e3a8285\",\"caseId\":null,\"creditAppNum\":\"4048447474\",\"accountNumber\":\"\",\"intent\":\"BYOD\",\"intendType\":\"BYOD\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":\"validateDeviceSim\",\"action\":\"\",\"OneClick\":true,\"LocationCode\":\"411057\",\"cartCreator\":\"Creator\",\"sessionId\":\"sessionId\",\"mtnFlow\":\"MTNFlow\"},\"data\":{\"lines\":[{\"mtn\":\"7132494511\",\"mtnType\":\"\",\"eskuId\":\"\",\"device\":{\"id\":\"356704081223650\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":true,\"sim\":{\"id\":\"\",\"sku\":\"\",\"isCustomerProvidedSIM\":false,\"CurrentSimid\":\"\"}}}]},\"disableEsimAtLocalInventory\":false,\"channelId\":\"OMNI_CARE\"}";
		DeviceIdValidationUIRequest UIRequest = new DeviceIdValidationUIRequest();
		DeviceIdValidationPEGARequest pegaRequest = new DeviceIdValidationPEGARequest();
		UIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIRequest.class);
		formater.formatDeviceIdValidationRequest(UIRequest, pegaRequest, new SearchAttributes());
		StepVerifier.create(Mono.just(pegaRequest))
				.assertNext(req -> Assert.assertNotNull(pegaRequest))
				.expectComplete().verify();
	}

	@Test
	public void formatInitiateValidateDeviceSimRequestTest_notOneclick() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\":{\"cartId\":\"17983bf1-995f-482e-baa3-a45f4e3a8285\",\"caseId\":\"SOF-14805422-E01\",\"creditAppNum\":\"4048447474\",\"accountNumber\":\"\",\"intent\":\"BYOD\",\"intendType\":\"BYOD\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":\"validateDeviceSim\",\"action\":\"\",\"oneClick\":false,\"LocationCode\":\"411057\",\"cartCreator\":\"Creator\",\"sessionId\":\"sessionId\",\"mtnFlow\":\"MTNFlow\"},\"data\":{\"lines\":[{\"mtn\":\"7132494511\",\"mtnType\":\"\",\"eskuId\":\"\",\"device\":{\"id\":\"356704081223650\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":true,\"sim\":{\"id\":\"\",\"sku\":\"\",\"isCustomerProvidedSIM\":false,\"CurrentSimid\":\"\"}}}]},\"disableEsimAtLocalInventory\":false,\"channelId\":\"OMNI_CARE\"}";
		DeviceIdValidationUIRequest UIRequest = new DeviceIdValidationUIRequest();
		DeviceIdValidationPEGARequest pegaRequest = new DeviceIdValidationPEGARequest();
		UIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIRequest.class);
		formater.formatDeviceIdValidationRequest(UIRequest, pegaRequest, new SearchAttributes());
		StepVerifier.create(Mono.just(pegaRequest))
				.assertNext(req -> Assert.assertNotNull(pegaRequest))
				.expectComplete().verify();
	}

	@Test
	public void formatInitiateValidateDeviceSimRequestTest_processStepEmpty() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\":{\"cartId\":\"17983bf1-995f-482e-baa3-a45f4e3a8285\",\"caseId\":\"SOF-14805422-E01\",\"creditAppNum\":\"4048447474\",\"accountNumber\":\"\",\"intent\":\"BYOD\",\"intendType\":\"BYOD\",\"processStep\":null,\"processAction\":\"validateDeviceSim\",\"action\":\"\",\"OneClick\":false,\"LocationCode\":\"411057\",\"cartCreator\":\"Creator\",\"sessionId\":\"sessionId\",\"mtnFlow\":\"MTNFlow\"},\"data\":{\"lines\":[{\"mtn\":\"7132494511\",\"mtnType\":\"\",\"eskuId\":\"\",\"device\":{\"id\":\"356704081223650\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":true,\"sim\":{\"id\":\"\",\"sku\":\"\",\"isCustomerProvidedSIM\":false,\"CurrentSimid\":\"\"}}}]},\"disableEsimAtLocalInventory\":false,\"channelId\":\"OMNI_CARE\"}";
		DeviceIdValidationUIRequest UIRequest = new DeviceIdValidationUIRequest();
		DeviceIdValidationPEGARequest pegaRequest = new DeviceIdValidationPEGARequest();
		UIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIRequest.class);
		formater.formatDeviceIdValidationRequest(UIRequest, pegaRequest, new SearchAttributes());
		StepVerifier.create(Mono.just(pegaRequest))
				.assertNext(req -> Assert.assertNotNull(pegaRequest))
				.expectComplete().verify();
	}

	@Test
	public void formatInitiateValidateDeviceSimRequestTest_processActionEmpty() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\":{\"cartId\":\"17983bf1-995f-482e-baa3-a45f4e3a8285\",\"caseId\":\"SOF-14805422-E01\",\"creditAppNum\":\"4048447474\",\"accountNumber\":\"\",\"intent\":\"BYOD\",\"intendType\":\"BYOD\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":null,\"action\":\"\",\"OneClick\":false,\"LocationCode\":\"411057\",\"cartCreator\":\"Creator\",\"sessionId\":\"sessionId\",\"mtnFlow\":\"MTNFlow\"},\"data\":{\"lines\":[{\"mtn\":\"7132494511\",\"mtnType\":\"\",\"eskuId\":\"\",\"device\":{\"id\":\"356704081223650\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":true,\"sim\":{\"id\":\"\",\"sku\":\"\",\"isCustomerProvidedSIM\":false,\"CurrentSimid\":\"\"}}}]},\"disableEsimAtLocalInventory\":false,\"channelId\":\"OMNI_CARE\"}";
		DeviceIdValidationUIRequest UIRequest = new DeviceIdValidationUIRequest();
		DeviceIdValidationPEGARequest pegaRequest = new DeviceIdValidationPEGARequest();
		UIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIRequest.class);
		formater.formatDeviceIdValidationRequest(UIRequest, pegaRequest, new SearchAttributes());
		StepVerifier.create(Mono.just(pegaRequest))
				.assertNext(req -> Assert.assertNotNull(pegaRequest))
				.expectComplete().verify();
	}

	@Test
	public void formatInitiateValidateDeviceSimRequestTest_locationCodeEmpty() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\":{\"cartId\":\"17983bf1-995f-482e-baa3-a45f4e3a8285\",\"caseId\":\"SOF-14805422-E01\",\"creditAppNum\":\"4048447474\",\"accountNumber\":\"\",\"intent\":\"BYOD\",\"intendType\":\"BYOD\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":null,\"action\":\"\",\"oneClick\":false,\"locationCode\":null,\"cartCreator\":\"Creator\",\"sessionId\":\"sessionId\",\"mtnFlow\":\"MTNFlow\"},\"data\":{\"lines\":[{\"mtn\":\"7132494511\",\"mtnType\":\"\",\"eskuId\":\"\",\"device\":{\"id\":\"356704081223650\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":true,\"sim\":{\"id\":\"\",\"sku\":\"\",\"isCustomerProvidedSIM\":false,\"CurrentSimid\":\"\"}}}]},\"disableEsimAtLocalInventory\":false,\"channelId\":\"OMNI_CARE\"}";
		DeviceIdValidationUIRequest UIRequest = new DeviceIdValidationUIRequest();
		DeviceIdValidationPEGARequest pegaRequest = new DeviceIdValidationPEGARequest();
		UIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIRequest.class);
		formater.formatDeviceIdValidationRequest(UIRequest, pegaRequest, new SearchAttributes());
		StepVerifier.create(Mono.just(pegaRequest))
				.assertNext(req -> Assert.assertNotNull(pegaRequest))
				.expectComplete().verify();
	}

	@Test
	public void formatInitiateValidateDeviceSimRequestTest_intentTypeEmpty() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\":{\"cartId\":\"17983bf1-995f-482e-baa3-a45f4e3a8285\",\"caseId\":\"SOF-14805422-E01\",\"creditAppNum\":\"4048447474\",\"accountNumber\":\"\",\"intent\":\"BYOD\",\"intendType\":null,\"processStep\":\"BYODDeviceIDPage\",\"processAction\":null,\"action\":\"\",\"oneClick\":false,\"locationCode\":null,\"cartCreator\":\"Creator\",\"sessionId\":\"sessionId\",\"mtnFlow\":\"MTNFlow\"},\"data\":{\"lines\":[{\"mtn\":\"7132494511\",\"mtnType\":\"\",\"eskuId\":\"\",\"device\":{\"id\":\"356704081223650\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":true,\"sim\":{\"id\":\"\",\"sku\":\"\",\"isCustomerProvidedSIM\":false,\"CurrentSimid\":\"\"}}}]},\"disableEsimAtLocalInventory\":false,\"channelId\":\"OMNI_CARE\"}";
		DeviceIdValidationUIRequest UIRequest = new DeviceIdValidationUIRequest();
		DeviceIdValidationPEGARequest pegaRequest = new DeviceIdValidationPEGARequest();
		UIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIRequest.class);
		formater.formatDeviceIdValidationRequest(UIRequest, pegaRequest, new SearchAttributes());
		StepVerifier.create(Mono.just(pegaRequest))
				.assertNext(req -> Assert.assertNotNull(pegaRequest))
				.expectComplete().verify();
	}

	@Test
	public void formatInitiateValidateDeviceSimRequestTest_intentEmpty() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\":{\"cartId\":\"17983bf1-995f-482e-baa3-a45f4e3a8285\",\"caseId\":\"SOF-14805422-E01\",\"creditAppNum\":\"4048447474\",\"accountNumber\":\"\",\"intent\":null,\"intendType\":\"BYOD\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":null,\"action\":\"\",\"oneClick\":false,\"locationCode\":null,\"cartCreator\":\"Creator\",\"sessionId\":\"sessionId\",\"mtnFlow\":\"MTNFlow\"},\"data\":{\"lines\":[{\"mtn\":\"7132494511\",\"mtnType\":\"\",\"eskuId\":\"\",\"device\":{\"id\":\"356704081223650\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":true,\"sim\":{\"id\":\"\",\"sku\":\"\",\"isCustomerProvidedSIM\":false,\"CurrentSimid\":\"\"}}}]},\"disableEsimAtLocalInventory\":false,\"channelId\":\"OMNI_CARE\"}";
		DeviceIdValidationUIRequest UIRequest = new DeviceIdValidationUIRequest();
		DeviceIdValidationPEGARequest pegaRequest = new DeviceIdValidationPEGARequest();
		UIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIRequest.class);
		formater.formatDeviceIdValidationRequest(UIRequest, pegaRequest, new SearchAttributes());
		StepVerifier.create(Mono.just(pegaRequest))
				.assertNext(req -> Assert.assertNotNull(pegaRequest))
				.expectComplete().verify();
	}

	@Test
	public void formatInitiateValidateDeviceSimRequestTest_nse() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\":{\"cartId\":\"17983bf1-995f-482e-baa3-a45f4e3a8285\",\"caseId\":\"SOF-14805422-E01\",\"creditAppNum\":\"4048447474\",\"accountNumber\":\"\",\"intent\":\"NSE\",\"intendType\":\"NSE\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":null,\"action\":\"\",\"oneClick\":false,\"locationCode\":null,\"cartCreator\":\"Creator\",\"sessionId\":\"sessionId\",\"mtnFlow\":\"MTNFlow\"},\"data\":{\"lines\":[{\"mtn\":\"7132494511\",\"mtnType\":\"\",\"eskuId\":\"\",\"device\":{\"id\":\"356704081223650\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":true,\"sim\":{\"id\":\"\",\"sku\":\"\",\"isCustomerProvidedSIM\":false,\"CurrentSimid\":\"\"}}}]},\"disableEsimAtLocalInventory\":false,\"channelId\":\"OMNI_CARE\"}";
		DeviceIdValidationUIRequest UIRequest = new DeviceIdValidationUIRequest();
		DeviceIdValidationPEGARequest pegaRequest = new DeviceIdValidationPEGARequest();
		UIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIRequest.class);
		formater.formatDeviceIdValidationRequest(UIRequest, pegaRequest, new SearchAttributes());
		StepVerifier.create(Mono.just(pegaRequest))
				.assertNext(req -> Assert.assertNotNull(pegaRequest))
				.expectComplete().verify();
	}

	@Test
	public void formatInitiateValidateDeviceSimRequestTest_nse_byod() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\":{\"cartId\":\"17983bf1-995f-482e-baa3-a45f4e3a8285\",\"caseId\":\"SOF-14805422-E01\",\"creditAppNum\":\"4048447474\",\"accountNumber\":\"12345\",\"intent\":\"NSEBYOD\",\"intendType\":\"NSEBYOD\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":null,\"action\":\"\",\"oneClick\":false,\"locationCode\":null,\"cartCreator\":\"Creator\",\"sessionId\":\"sessionId\",\"mtnFlow\":\"MTNFlow\"},\"data\":{\"lines\":[{\"mtn\":\"7132494511\",\"mtnType\":\"\",\"eskuId\":\"\",\"device\":{\"id\":\"356704081223650\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"\",\"isCustomerProvidedEquipment\":true,\"sku\":\"XUYZW\",\"smartIMEI\":true,\"sim\":{\"id\":\"\",\"sku\":\"XUYZW\",\"isCustomerProvidedSIM\":false,\"CurrentSimid\":\"\"}}}]},\"disableEsimAtLocalInventory\":false,\"channelId\":\"OMNI_CARE\"}";
		DeviceIdValidationUIRequest UIRequest = new DeviceIdValidationUIRequest();
		DeviceIdValidationPEGARequest pegaRequest = new DeviceIdValidationPEGARequest();
		UIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIRequest.class);
		formater.formatDeviceIdValidationRequest(UIRequest, pegaRequest, new SearchAttributes());
		StepVerifier.create(Mono.just(pegaRequest))
				.assertNext(req -> Assert.assertNotNull(pegaRequest))
				.expectComplete().verify();
	}

	@Test
	public void formatInitiateValidateDeviceSimRequestTest_SOP() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\":{\"cartId\":\"17983bf1-995f-482e-baa3-a45f4e3a8285\",\"caseId\":\"SOP-14805422-E01\",\"creditAppNum\":\"4048447474\",\"accountNumber\":\"\",\"customerType\":\"AAL\",\"intent\":\"REX\",\"intendType\":\"NSE\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":null,\"action\":\"\",\"oneClick\":false,\"locationCode\":null,\"cartCreator\":\"\",\"sessionId\":\"sessionId\",\"globalId\":\"globalId\",\"mtnFlow\":\"MTNFlow\"},\"data\":{\"lines\":[{\"mtn\":\"7132494511\",\"mtnType\":\"\",\"eskuId\":\"\",\"device\":{\"id\":\"356704081223650\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"\",\"isCustomerProvidedEquipment\":true,\"sku\":\"ZANBXDE\",\"sorDisplayName\":\"iphone 16\",\"smartIMEI\":true,\"sim\":{\"id\":\"\",\"sku\":\"\",\"isCustomerProvidedSIM\":false,\"CurrentSimid\":\"\"}}}]},\"disableEsimAtLocalInventory\":false,\"channelId\":\"DIGITAL\"}";
		DeviceIdValidationUIRequest UIRequest = new DeviceIdValidationUIRequest();
		DeviceIdValidationPEGARequest pegaRequest = new DeviceIdValidationPEGARequest();
		UIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIRequest.class);
		formater.formatDeviceIdValidationRequest(UIRequest, pegaRequest, new SearchAttributes());
		StepVerifier.create(Mono.just(pegaRequest))
				.assertNext(req -> Assert.assertNotNull(pegaRequest))
				.expectComplete().verify();
	}

	@Test
	public void formatInitiateValidateDeviceSimRequestTest_emptyCredit() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\":{\"cartId\":\"17983bf1-995f-482e-baa3-a45f4e3a8285\",\"caseId\":\"SOP-14805422-E01\",\"creditAppNum\":\"\",\"accountNumber\":\"\",\"customerType\":\"AAL\",\"intent\":\"REX\",\"intendType\":\"NSE\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":null,\"action\":\"\",\"oneClick\":false,\"locationCode\":null,\"cartCreator\":\"\",\"sessionId\":\"sessionId\",\"mtnFlow\":\"MTNFlow\"},\"data\":{\"lines\":[{\"mtn\":\"7132494511\",\"mtnType\":\"\",\"eskuId\":\"\",\"device\":{\"id\":\"356704081223650\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":true,\"sim\":{\"id\":\"\",\"sku\":\"\",\"isCustomerProvidedSIM\":false,\"CurrentSimid\":\"\"}}}]},\"disableEsimAtLocalInventory\":false,\"channelId\":\"OMNI_CARE\"}";
		DeviceIdValidationUIRequest UIRequest = new DeviceIdValidationUIRequest();
		DeviceIdValidationPEGARequest pegaRequest = new DeviceIdValidationPEGARequest();
		UIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIRequest.class);
		formater.formatDeviceIdValidationRequest(UIRequest, pegaRequest, new SearchAttributes());
		StepVerifier.create(Mono.just(pegaRequest))
				.assertNext(req -> Assert.assertNotNull(pegaRequest))
				.expectComplete().verify();
	}

	@Test
	public void formatInitiateValidateDeviceSimRequestTest_lineEmpty() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\":{\"cartId\":\"17983bf1-995f-482e-baa3-a45f4e3a8285\",\"caseId\":\"SOP-14805422-E01\",\"creditAppNum\":\"\",\"accountNumber\":\"\",\"customerType\":\"AAL\",\"intent\":\"REX\",\"intendType\":\"NSE\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":null,\"action\":\"\",\"oneClick\":false,\"locationCode\":null,\"cartCreator\":\"\",\"sessionId\":\"sessionId\",\"mtnFlow\":\"MTNFlow\"},\"data\":{\"lines\":null},\"disableEsimAtLocalInventory\":false,\"channelId\":\"OMNI_CARE\"}";
		DeviceIdValidationUIRequest UIRequest = new DeviceIdValidationUIRequest();
		DeviceIdValidationPEGARequest pegaRequest = new DeviceIdValidationPEGARequest();
		UIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIRequest.class);
		formater.formatDeviceIdValidationRequest(UIRequest, pegaRequest, new SearchAttributes());
		StepVerifier.create(Mono.just(pegaRequest))
				.assertNext(req -> Assert.assertNotNull(pegaRequest))
				.expectComplete().verify();
	}

	@Test
	public void formatInitiateValidateDeviceSimRequestTest_lineMtnEmpty() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\":{\"cartId\":\"17983bf1-995f-482e-baa3-a45f4e3a8285\",\"caseId\":\"SOP-14805422-E01\",\"creditAppNum\":\"\",\"accountNumber\":\"\",\"customerType\":\"AAL\",\"intent\":\"REX\",\"intendType\":\"NSE\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":null,\"action\":\"\",\"oneClick\":false,\"locationCode\":null,\"cartCreator\":\"\",\"sessionId\":\"sessionId\",\"mtnFlow\":\"MTNFlow\"},\"data\":{\"lines\":[{\"mtn\":null,\"mtnType\":\"\",\"eskuId\":\"\",\"device\":{\"id\":\"356704081223650\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":true,\"sim\":{\"id\":\"\",\"sku\":\"\",\"isCustomerProvidedSIM\":false,\"CurrentSimid\":\"\"}}}]},\"disableEsimAtLocalInventory\":false,\"channelId\":\"OMNI_CARE\"}";
		DeviceIdValidationUIRequest UIRequest = new DeviceIdValidationUIRequest();
		DeviceIdValidationPEGARequest pegaRequest = new DeviceIdValidationPEGARequest();
		UIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIRequest.class);
		formater.formatDeviceIdValidationRequest(UIRequest, pegaRequest, new SearchAttributes());
		StepVerifier.create(Mono.just(pegaRequest))
				.assertNext(req -> Assert.assertNotNull(pegaRequest))
				.expectComplete().verify();
	}

	@Test
	public void formatInitiateValidateDeviceSimRequestTest_deviceEmpty() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\":{\"cartId\":\"17983bf1-995f-482e-baa3-a45f4e3a8285\",\"caseId\":\"SOP-14805422-E01\",\"creditAppNum\":\"\",\"accountNumber\":\"\",\"customerType\":\"AAL\",\"intent\":\"REX\",\"intendType\":\"NSE\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":null,\"action\":\"\",\"oneClick\":false,\"locationCode\":null,\"cartCreator\":\"\",\"sessionId\":\"sessionId\",\"mtnFlow\":\"MTNFlow\"},\"data\":{\"lines\":[{\"mtn\":null,\"mtnType\":\"\",\"eskuId\":\"\",\"device\":null}]},\"disableEsimAtLocalInventory\":false,\"channelId\":\"OMNI_CARE\"}";
		DeviceIdValidationUIRequest UIRequest = new DeviceIdValidationUIRequest();
		DeviceIdValidationPEGARequest pegaRequest = new DeviceIdValidationPEGARequest();
		UIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIRequest.class);
		formater.formatDeviceIdValidationRequest(UIRequest, pegaRequest, new SearchAttributes());
		StepVerifier.create(Mono.just(pegaRequest))
				.assertNext(req -> Assert.assertNotNull(pegaRequest))
				.expectComplete().verify();
	}

	@Test
	public void formatInitiateValidateDeviceSimRequestTest_deviceAttrEmpty() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString =  "{\"cartInfo\":{\"cartId\":\"17983bf1-995f-482e-baa3-a45f4e3a8285\",\"caseId\":\"SOP-14805422-E01\",\"creditAppNum\":\"\",\"accountNumber\":\"\",\"customerType\":\"AAL\",\"intent\":\"REX\",\"intendType\":\"NSE\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":null,\"action\":\"\",\"oneClick\":false,\"locationCode\":null,\"cartCreator\":\"\",\"sessionId\":\"sessionId\",\"mtnFlow\":\"MTNFlow\"},\"data\":{\"lines\":[{\"mtn\":\"7132494511\",\"mtnType\":\"\",\"eskuId\":\"\",\"device\":{\"id\":\"356704081223650\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"\",\"isCustomerProvidedEquipment\":true,\"sku\":\"ZABCX\",\"smartIMEI\":false,\"sim\":null}}]},\"disableEsimAtLocalInventory\":false,\"channelId\":\"OMNI_CARE\"}";
		DeviceIdValidationUIRequest UIRequest = new DeviceIdValidationUIRequest();
		DeviceIdValidationPEGARequest pegaRequest = new DeviceIdValidationPEGARequest();
		UIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIRequest.class);
		formater.formatDeviceIdValidationRequest(UIRequest, pegaRequest, new SearchAttributes());
		StepVerifier.create(Mono.just(pegaRequest))
				.assertNext(req -> Assert.assertNotNull(pegaRequest))
				.expectComplete().verify();
	}


}

