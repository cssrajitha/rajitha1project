package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.helper.OmniDLHelperForAIQuote;
import onevz.soe.cart.model.addAccessory.AddAccContext;
import onevz.soe.cart.model.addAccessory.AddAccServiceBody;
import onevz.soe.cart.model.addAccessory.AddAccServiceResponse;
import onevz.soe.cart.model.addBuyout.AddBuyoutContext;
import onevz.soe.cart.model.addBuyout.AddBuyoutServiceBody;
import onevz.soe.cart.model.addBuyout.AddBuyoutServiceResponse;
import onevz.soe.cart.model.addDevice.AddDeviceContext;
import onevz.soe.cart.model.addDevice.AddDeviceServiceBody;
import onevz.soe.cart.model.addDevice.AddDeviceServiceResponse;

import onevz.soe.cart.model.addFeature.AddFeaturesContext;
import onevz.soe.cart.model.addFeature.AddFeaturesServiceBody;
import onevz.soe.cart.model.addFeature.AddFeaturesServiceResponse;
import onevz.soe.cart.model.addPlan.AddPlanContext;
import onevz.soe.cart.model.addPlan.AddPlanServiceBody;
import onevz.soe.cart.model.addPlan.AddPlanServiceResponse;
import onevz.soe.cart.model.catalog.CatalogData;
import onevz.soe.cart.model.catalog.ContractInfo;
import onevz.soe.cart.model.catalog.SoftSkuCatalogItem;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.retrieveCart.*;
import onevz.soe.cart.model.retrieveCart.ServiceInfo;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.CatalogResponse;
import onevz.soe.cart.ui.common.*;
import onevz.soe.cart.ui.common.AddDeviceData;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.requests.AddDeviceUIRequest;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.cart.ui.responses.AddDeviceUIResponse;
import onevz.soe.customerprofile.model.gql.assisted.Address;
import onevz.soe.customerprofile.model.gql.assisted.*;
import onevz.soe.customerprofile.model.gql.assisted.BillAccount;
import onevz.soe.customerprofile.model.gql.assisted.PricePlanInfo;
import onevz.soe.customerprofile.response.CustomerProfileResponse;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.math.BigDecimal;
import java.util.*;

@RunWith(SpringJUnit4ClassRunner.class)
@WebFluxTest(OmniDLHelperForAIQuote.class)
public class OmniDLHelperForAIQuoteTest {

    @InjectMocks
    OmniDLHelperForAIQuote omniDLHelper;

    @Autowired
    ObjectMapper mapper;

    @Test
    public void getVzdlDataForAddDeviceTest() {
        AddDeviceUIRequest request = null;
        AddDeviceUIResponse response = null;
        Assert.assertNull(omniDLHelper.getVzdlDataForAddDevice(request, response, new CartRedisData()));

        request = new AddDeviceUIRequest();
        response = new AddDeviceUIResponse();
        Assert.assertNull(omniDLHelper.getVzdlDataForAddDevice(request, response, new CartRedisData()));

        request.setData(new AddDeviceData());
        omniDLHelper.getVzdlDataForAddDevice(request, response, new CartRedisData());

        response.setServiceBody(new AddDeviceServiceBody());
        omniDLHelper.getVzdlDataForAddDevice(request, response, new CartRedisData());

        request = new AddDeviceUIRequest();
        omniDLHelper.getVzdlDataForAddDevice(request, response, new CartRedisData());

    }

    @Test
    public void populateVzdlDataForAddDeviceTest() {
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        AddDeviceUIResponse response = new AddDeviceUIResponse();
        CartRedisData cartRedisData = new CartRedisData();
        Assert.assertNull(omniDLHelper.populateVzdlDataForAddDevice(request, response, cartRedisData));

        AddDeviceServiceBody serviceBody = new AddDeviceServiceBody();
        AddDeviceServiceResponse AddDeviceServiceResponse = new AddDeviceServiceResponse();
        AddDeviceContext context = new AddDeviceContext();
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        context.setCartInfo(cartInfo);
        AddDeviceServiceResponse.setContext(context);
        serviceBody.setServiceResponse(AddDeviceServiceResponse);
        response.setServiceBody(serviceBody);

        AddDeviceData data = new AddDeviceData();
        request.setData(data);
        Assert.assertNull(omniDLHelper.populateVzdlDataForAddDevice(request, response, cartRedisData));

        Line[] lines = new Line[2];
        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(lines);
        Assert.assertNull(omniDLHelper.populateVzdlDataForAddDevice(request, response, cartRedisData));

        Lines[] reqLine = new Lines[2];
        request.getData().setLines(Arrays.asList(reqLine));
        Assert.assertNull(omniDLHelper.populateVzdlDataForAddDevice(request, response, cartRedisData));

        lines[0] = new Line();
        Line line1 = new Line();
        lines[1] = line1;
        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(lines);
        Assert.assertNull(omniDLHelper.populateVzdlDataForAddDevice(request, response, cartRedisData));

        Lines[] reqLine2 = new Lines[1];
        Lines lines1 = new Lines();
        lines1.setMtn("8323149457");
        Device device = new Device();
        device.setId("1");
        device.setSkuId("skuId");
        device.setSkuDisplayName("Iphone 16 Pro");
        device.setDiscountAmount("50");
        device.setProductId("SorId");
        device.setDescription("test");
        device.setItemPrice("$1100");
        lines1.setDevice(device);
        List<Feature> featureList = new ArrayList<>();
        Feature feature = new Feature();
        feature.setId("spo1");
        featureList.add(feature);
        lines1.setAddFeatures(featureList);
        reqLine2[0] = lines1;
        CartRedisData rr = null;
        rr = new CartRedisData();
        CustomerProfileResponse customerProfileResponse = new CustomerProfileResponse();
        List<BillAccount> billAccountList = new ArrayList<>();
        BillAccount billAccount = new BillAccount();
        Mtn mtn = new Mtn();
        mtn.setMtn("8323149457");
        mtn.setMtnHashCode("werewewfsddsdsfdsfdf");
        List<Mtn> mtnList = new ArrayList<>();
        mtnList.add(mtn);
        billAccount.setMtns(mtnList);
        billAccountList.add(billAccount);
        Data data1 = new Data();
        Customer customer = new Customer();
        customer.setBillAccounts(billAccountList);
        data1.setCustomer(customer);
        customerProfileResponse.setData(data1);
        rr.setCustomerProfile(customerProfileResponse);
        Address address = new Address();
        rr.getCustomerProfile().getData().getCustomer().setAddress(address);
        Line[] lines2 = new Line[1];
        Line line2 = new Line();
        line2.setMtn("8323149457");
        line2.setMonthlyInstallment(36.80);
        line2.setDevice(device);
        ConflictedSPO[] conflictedSPOS =  new ConflictedSPO[1];
        ConflictedSPO conflictedSPO = new ConflictedSPO();
        conflictedSPO.setId("spo1");
        conflictedSPOS[0] = conflictedSPO;
        line2.setSpos(conflictedSPOS);
        lines2[0] = line2;
        DeviceCartInfo deviceCartInfo = new DeviceCartInfo();
        deviceCartInfo.setSessionId("Session-1");
        request.setCartInfo(deviceCartInfo);
        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(lines2);
        request.getData().setLines(Arrays.asList(reqLine2));
        Assert.assertNotNull(omniDLHelper.populateVzdlDataForAddDevice(request, response, rr));

        Assert.assertNotNull(request);
    }

    @Test
    public void populateVzdlDataForAddDeviceTest1() {
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        AddDeviceUIResponse response = new AddDeviceUIResponse();
        CartRedisData cartRedisData = new CartRedisData();
        Assert.assertNull(omniDLHelper.populateVzdlDataForAddDevice(request, response, cartRedisData));

        AddDeviceServiceBody serviceBody = new AddDeviceServiceBody();
        AddDeviceServiceResponse AddDeviceServiceResponse = new AddDeviceServiceResponse();
        AddDeviceContext context = new AddDeviceContext();
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        context.setCartInfo(cartInfo);
        AddDeviceServiceResponse.setContext(context);
        serviceBody.setServiceResponse(AddDeviceServiceResponse);
        response.setServiceBody(serviceBody);

        AddDeviceData data = new AddDeviceData();
        request.setData(data);
        Assert.assertNull(omniDLHelper.populateVzdlDataForAddDevice(request, response, cartRedisData));

        Line[] lines = new Line[2];
        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(lines);
        Assert.assertNull(omniDLHelper.populateVzdlDataForAddDevice(request, response, cartRedisData));

        Lines[] reqLine = new Lines[2];
        request.getData().setLines(Arrays.asList(reqLine));
        Assert.assertNull(omniDLHelper.populateVzdlDataForAddDevice(request, response, cartRedisData));

        lines[0] = new Line();
        Line line1 = new Line();
        lines[1] = line1;
        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(lines);
        Assert.assertNull(omniDLHelper.populateVzdlDataForAddDevice(request, response, cartRedisData));

        Lines[] reqLine2 = new Lines[1];
        Lines lines1 = new Lines();
        lines1.setMtn("9988776655");
        Device device = new Device();
        device.setId("1");
        device.setDiscountAmount("");
        lines1.setDevice(device);
        reqLine2[0] = lines1;
        CartRedisData rr = null;
        rr = new CartRedisData();
        CustomerProfileResponse customerProfileResponse = new CustomerProfileResponse();
        List<BillAccount> billAccountList = new ArrayList<>();
        BillAccount billAccount = new BillAccount();
        Mtn mtn = new Mtn();
        mtn.setMtn("9988776655");
        mtn.setMtnHashCode("123456789887542");
        List<Mtn> mtnList = new ArrayList<>();
        mtnList.add(mtn);
        billAccount.setMtns(mtnList);
        billAccountList.add(billAccount);
        Data data1 = new Data();
        Customer customer = new Customer();
        customer.setBillAccounts(billAccountList);
        data1.setCustomer(customer);
        customerProfileResponse.setData(data1);
        rr.setCustomerProfile(customerProfileResponse);
        Address address = new Address();
        rr.getCustomerProfile().getData().getCustomer().setAddress(address);
        Line[] lines2 = new Line[1];
        Line line2 = new Line();
        line2.setMtn("9988776655");
        line2.setMonthlyInstallment(0.00);
        line2.setDevice(device);
        ConflictedSPO[] conflictedSPOS =  new ConflictedSPO[1];
        ConflictedSPO conflictedSPO = new ConflictedSPO();
        conflictedSPO.setId("spo1");
        conflictedSPOS[0] = conflictedSPO;
        line2.setSpos(conflictedSPOS);
        lines2[0] = line2;
        DeviceCartInfo deviceCartInfo = new DeviceCartInfo();
        deviceCartInfo.setSessionId("Session-1");
        request.setCartInfo(deviceCartInfo);
        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(lines2);
        request.getData().setLines(Arrays.asList(reqLine2));
        Assert.assertNotNull(omniDLHelper.populateVzdlDataForAddDevice(request, response, rr));

        Assert.assertNotNull(request);
    }

    @Test
    public void updateUserDataTest() {
        Vzdl vzdl = new Vzdl();
        CartRedisData rr = null;
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        omniDLHelper.updateUserData(vzdl, rr, request);

        DeviceCartInfo cartInfo = new DeviceCartInfo();
        cartInfo.setSessionId("12345");
        request.setCartInfo(cartInfo);
        rr = new CartRedisData();
        omniDLHelper.updateUserData(vzdl, rr, request);

        rr.setCustomerProfile(new CustomerProfileResponse());
        rr.getCustomerProfile().setData(null);
        omniDLHelper.updateUserData(vzdl, rr, request);

        rr.getCustomerProfile().setData(new Data());
        rr.getCustomerProfile().getData().setCustomer(null);
        omniDLHelper.updateUserData(vzdl, rr, request);

        rr.getCustomerProfile().getData().setCustomer(new Customer());
        omniDLHelper.updateUserData(vzdl, rr, request);

        rr.getCustomerProfile().getData().getCustomer().setCustomerHash("");
        rr.getCustomerProfile().getData().getCustomer().setAccountNo("");
        rr.getCustomerProfile().getData().getCustomer().setBillAccounts(null);
        omniDLHelper.updateUserData(vzdl, rr, request);

        rr.getCustomerProfile().getData().getCustomer().setCustomerHash("");
        rr.getCustomerProfile().getData().getCustomer().setAccountNo("");
        rr.getCustomerProfile().getData().getCustomer().setBillAccounts(new ArrayList<>());
        omniDLHelper.updateUserData(vzdl, rr, request);

        rr.getCustomerProfile().getData().getCustomer().setCustomerHash("123");
        rr.getCustomerProfile().getData().getCustomer().setAccountNo("1234-000");
        rr.getCustomerProfile().getData().getCustomer().setLookupMtn("678");
        Address address = new Address();
        rr.getCustomerProfile().getData().getCustomer().setAddress(address);
        omniDLHelper.updateUserData(vzdl, rr, request);

        address.setZipCode("1234");
        rr.getCustomerProfile().getData().getCustomer().setAddress(address);
        BillAccount billAccount = new BillAccount();
        billAccount.setMtns(null);
        List<BillAccount> accounts = new ArrayList<>();
        accounts.add(billAccount);
        accounts.add(null);
        omniDLHelper.updateUserData(vzdl, rr, request);

        BillAccount billAccount1 = new BillAccount();
        Mtn mtn = new Mtn();
        List<Mtn> mtns = new ArrayList<>();
        mtns.add(new Mtn());
        mtns.add(mtn);

        mtn.setMtn("678");
        mtn.setPricePlanInfo(new PricePlanInfo());
        mtns.add(mtn);
        Mtn mtn1 = new Mtn();
        PricePlanInfo pricePlanInfo = new PricePlanInfo();
        pricePlanInfo.setDescription("Test");
        mtn1.setMtn("123");
        mtn1.setPricePlanInfo(pricePlanInfo);
        mtns.add(mtn1);
        billAccount1.setMtns(mtns);
        accounts.add(billAccount1);
        rr.getCustomerProfile().getData().getCustomer().setBillAccounts(accounts);
        omniDLHelper.updateUserData(vzdl, rr, request);
        Assert.assertNotNull(vzdl.getUser());
    }

    @Test
    public void updatePageDataTest() {
        Vzdl vzdl = new Vzdl();
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        omniDLHelper.updatePageData(vzdl, request);

        DeviceCartInfo cartInfo = new DeviceCartInfo();
        request.setCartInfo(cartInfo);
        omniDLHelper.updatePageData(vzdl, request);

        request.getCartInfo().setSessionId("");
        request.setChannelId(null);
        request.getCartInfo().setIntendType("");
        request.getCartInfo().setCaseId("");
        request.getCartInfo().setCartId("");
        omniDLHelper.updatePageData(vzdl, request);
        Assert.assertNotNull(vzdl.getPage());

        request.getCartInfo().setSessionId("12345");
        request.getCartInfo().setIntendType("NSE");
        request.getCartInfo().setCaseId("1234");
        request.getCartInfo().setCartId("567888");
        request.setChannelId("");
        omniDLHelper.updatePageData(vzdl, request);
        Assert.assertNotNull(vzdl.getPage());

        request.setChannelId(CartConstants.RETAIL);
        omniDLHelper.updatePageData(vzdl, request);

        request.setChannelId(CartConstants.RETAIL_IPAD);
        omniDLHelper.updatePageData(vzdl, request);

        request.setChannelId("Test");
        omniDLHelper.updatePageData(vzdl, request);
    }

    @Test
    public void updateTxnDataTest() {
        Vzdl vzdl = new Vzdl();
        CartRedisData rr = null;
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        Optional<CartServiceCartInfo> cartInfo = Optional.empty();
        omniDLHelper.updateTxnData(vzdl, rr, request, cartInfo);
        Assert.assertTrue(vzdl.getTxn().isEmpty());


        rr = new CartRedisData();
        omniDLHelper.updateTxnData(vzdl, rr, request, cartInfo);

        CartServiceCartInfo cartServiceCartInfo = new CartServiceCartInfo();
        cartInfo = Optional.of(cartServiceCartInfo);
        request.setCartInfo(new DeviceCartInfo());
        request.getCartInfo().setIntendType(null);
        omniDLHelper.updateTxnData(vzdl, rr, request, cartInfo);

        cartServiceCartInfo.setCartId("");
        cartInfo = Optional.of(cartServiceCartInfo);
        request.getCartInfo().setIntendType("");
        omniDLHelper.updateTxnData(vzdl, rr, request, cartInfo);

        rr.setAutoPayEnrolled("");
        rr.setRepId("");
        rr.setLocationCode("");
        rr.setAgentRole("");
        omniDLHelper.updateTxnData(vzdl, rr, request, cartInfo);

        cartServiceCartInfo.setCartId("5362537");
        cartInfo = Optional.of(cartServiceCartInfo);
        rr.setAutoPayEnrolled("123");
        rr.setAgentRole("ENC-123");
        rr.setRepId("ENC");
        rr.setLocationCode("1234");
        request.getCartInfo().setIntendType("NSE");
        omniDLHelper.updateTxnData(vzdl, rr, request, cartInfo);

    }

    @Test
    public void updateProductDataForDeviceTest() {
        Vzdl vzdl = new Vzdl();
        CartRedisData rr = null;
        AddDeviceUIRequest request = new AddDeviceUIRequest();
        request.setData(new AddDeviceData());
        Optional<Lines> requestLines = Optional.empty();
        rr = new CartRedisData();
        Lines[] reqLine = new Lines[1];
        Lines lines = new Lines();
        reqLine[0] = lines;
        request.getData().setLines(Arrays.asList(reqLine));

        CartServiceCartInfo cartInfo = new CartServiceCartInfo();

        omniDLHelper.updateProductDataForDevice(vzdl, rr, request, requestLines, Optional.empty());
        Assert.assertNotNull(vzdl.getProduct());

        rr.setCustomerProfile(new CustomerProfileResponse());
        reqLine[0] = null;
        request.getData().setLines(Arrays.asList(reqLine));
        omniDLHelper.updateProductDataForDevice(vzdl, rr, request, requestLines, Optional.empty());

        Data data = new Data();
        data.setCustomer(new Customer());
        List<BillAccount> billAccounts = new ArrayList<>();
        Mtn mtn = new Mtn();
        mtn.setMtn("123");
        mtn.setPricePlanInfo(new PricePlanInfo());
        Mtn mtn1 = new Mtn();
        mtn1.setMtn("123");
        PricePlanInfo pricePlanInfo = new PricePlanInfo();
        pricePlanInfo.setDescription("");
        mtn1.setPricePlanInfo(pricePlanInfo);
        mtn1.setMtnHashCode("");
        Mtn mtn2 = new Mtn();
        mtn2.setMtn("123");
        pricePlanInfo.setDescription("123457");
        pricePlanInfo.setPlanId("097");
        mtn2.setPricePlanInfo(pricePlanInfo);
        mtn2.setMtnHashCode("aec");
        List<Mtn> mtns = new ArrayList<>();
        Mtn mtn3 = new Mtn();
        mtn3.setMtn("");
        Mtn mtn4 = new Mtn();
        mtns.add(new Mtn());
        Mtn mtn5 = new Mtn();
        mtn5.setMtn("123");
        mtn5.setMtnHashCode("");
        mtns.add(mtn);
        mtns.add(mtn1);
        mtns.add(mtn2);
        mtns.add(mtn3);
        mtns.add(mtn4);
        mtns.add(mtn5);
        BillAccount billAccount = new BillAccount();
        billAccount.setMtns(mtns);
        billAccounts.add(billAccount);
        billAccounts.add(null);
        data.getCustomer().setBillAccounts(billAccounts);
        rr.getCustomerProfile().setData(data);
        reqLine = new Lines[3];
        Lines line = new Lines();
        line.setMtn("123");
        reqLine[0] = line;
        line.setPlan(new Plan());
        line.setAddFeatures(new ArrayList<>());
        line.setLinechanged(true);
        reqLine[1] = line;
        line.getPlan().setId("abc");
        line.getPlan().setPath(null);
        Feature feature = new Feature();
        List<Feature> features = new ArrayList<>();
        features.add(null);
        features.add(feature);
        feature.setId("spo1");
        features.add(feature);
        line.setAddFeatures(features);
        reqLine[2] = line;
        request.getData().setLines(Arrays.asList(reqLine));
        request.getData().getLines().get(0).setPlan(new Plan());
        request.getData().getLines().get(0).getPlan().setPath("path for the plan");
        requestLines = Optional.of(reqLine[0]);
        omniDLHelper.updateProductDataForDevice(vzdl, rr, request, requestLines, Optional.empty());

        line.setPlan(new Plan());
        line.setAddFeatures(new ArrayList<>());
        reqLine = new Lines[1];
        line.setLinechanged(false);
        reqLine[0] = line;
        request.getData().setLines(Arrays.asList(reqLine));
        omniDLHelper.updateProductDataForDevice(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        line.setLinechanged(true);
        line.getPlan().setId("");
        line.getPlan().setPath("");
        reqLine[0] = line;
        request.getData().setLines(Arrays.asList(reqLine));
        Line[] respLine = new Line[2];
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductDataForDevice(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        line.getPlan().setId("abc");
        line.getPlan().setPath(null);
        reqLine[0] = line;
        request.getData().setLines(Arrays.asList(reqLine));
        Line[] lines1 = new Line[2];
        lines1[0] = null;
        Line line1 = new Line();
        lines1[1] = line1;
        respLine[0] = null;
        respLine[1] = new Line();
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductDataForDevice(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        line.getPlan().setPath("plans page");
        reqLine[0] = line;
        request.getData().setLines(Arrays.asList(reqLine));
        omniDLHelper.updateProductDataForDevice(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        Line respLine1 = new Line();
        respLine1.setMtn("");
        respLine[0] = respLine1;
        respLine1.setMtn("123");
        respLine[1] = respLine1;
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductDataForDevice(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        respLine1.setPlan(new Plan());
        respLine = new Line[1];
        respLine[0] = respLine1;
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductDataForDevice(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        respLine1.getPlan().setId("");
        respLine[0] = respLine1;
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductDataForDevice(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        respLine1.getPlan().setId(null);
        respLine[0] = respLine1;
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductDataForDevice(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        respLine1.getPlan().setId("abc");
        respLine1.getPlan().setDiscountedPrice(null);
        respLine[0] = respLine1;
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductDataForDevice(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        respLine1.getPlan().setDiscountedPrice("");
        respLine[0] = respLine1;
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductDataForDevice(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        respLine1.getPlan().setDiscountedPrice("20.00");
        respLine[0] = respLine1;
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductDataForDevice(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        respLine1.setSpos(new ConflictedSPO[1]);
        respLine[0] = respLine1;
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductDataForDevice(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        ConflictedSPO spo = new ConflictedSPO();
        spo.setId("spo1");
        ConflictedSPO[] spos = new ConflictedSPO[4];
        spos[0] = spo;
        spo.setId("");
        spos[1] = spo;
        spo.setId(null);
        spos[2] = spo;
        spos[3] = null;
        respLine1.setSpos(spos);
        respLine[0] = respLine1;
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductDataForDevice(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        request.getData().getLines().get(0).setDevice(null);
        omniDLHelper.updateProductDataForDevice(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        request.getData().getLines().get(0).getPlan().setPath("Plans page");
        omniDLHelper.updateProductDataForDevice(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        request.getData().getLines().get(0).setPlan(new Plan());
        request.getData().getLines().get(0).getPlan().setPath(null);
        omniDLHelper.updateProductDataForDevice(vzdl, rr, request, requestLines, Optional.of(cartInfo));

        request.getData().getLines().get(0).getPlan().setPath("");
        omniDLHelper.updateProductDataForDevice(vzdl, rr, request, requestLines, Optional.of(cartInfo));

    }

    @Test
    public void updateEventTest() throws Exception {
        Vzdl vzdl = new Vzdl();
        CartRedisData rr = null;
        omniDLHelper.updateEvent(vzdl);

        rr = new CartRedisData();
        omniDLHelper.updateEvent(vzdl);

        rr.setRetrieveCart(new CXPRetrieveCartDataVO());
        omniDLHelper.updateEvent(vzdl);

        rr.getRetrieveCart().setCart(new CXPCartVO());
        omniDLHelper.updateEvent(vzdl);

        rr.getRetrieveCart().getCart().setLineDetails(new CXPLineDetailsVO());
        omniDLHelper.updateEvent(vzdl);

        rr.getRetrieveCart().getCart().getLineDetails().setLineInfo(null);
        rr.getRetrieveCart().getCart().getLineDetails().setNumOfAccessoryAndDeviceItemsInCart(null);
        omniDLHelper.updateEvent(vzdl);

        rr.getRetrieveCart().getCart().getLineDetails().setLineInfo(new CXPLineInfo[0]);
        rr.getRetrieveCart().getCart().getLineDetails().setNumOfAccessoryAndDeviceItemsInCart(0);
        omniDLHelper.updateEvent(vzdl);

        rr.getRetrieveCart().getCart().getLineDetails().setLineInfo(new CXPLineInfo[2]);
        rr.getRetrieveCart().getCart().getLineDetails().setNumOfAccessoryAndDeviceItemsInCart(2);
        omniDLHelper.updateEvent(vzdl);
        Assert.assertNotNull(vzdl.getEvent().getValue());

        rr.getRetrieveCart().getCart().getLineDetails().setNumOfAccessoryAndDeviceItemsInCart(0);
        CXPLineInfo lineArray[] = new CXPLineInfo[2];
        lineArray[0] = null;
        lineArray[1] = new CXPLineInfo();
        lineArray[1].setLineActivityType(null);
        lineArray[1].setServiceInfo(null);
        rr.getRetrieveCart().getCart().getLineDetails().setLineInfo(lineArray);
        omniDLHelper.updateEvent(vzdl);

        lineArray = new CXPLineInfo[1];
        lineArray[0] = new CXPLineInfo();
        lineArray[0].setLineActivityType("");
        lineArray[0].setServiceInfo(new ServiceInfo());
        rr.getRetrieveCart().getCart().getLineDetails().setLineInfo(lineArray);
        omniDLHelper.updateEvent(vzdl);

        lineArray[0].setLineActivityType("ABC");
        lineArray[0].getServiceInfo().setSelectedFeaturesList(new SelectedFeaturesList());
        rr.getRetrieveCart().getCart().getLineDetails().setLineInfo(lineArray);
        omniDLHelper.updateEvent(vzdl);

        lineArray[0].setLineActivityType("CPC");
        lineArray[0].getServiceInfo().getSelectedFeaturesList().setVisFeature(null);
        rr.getRetrieveCart().getCart().getLineDetails().setLineInfo(lineArray);
        omniDLHelper.updateEvent(vzdl);

        lineArray[0].setLineActivityType("ABC");
        lineArray[0].getServiceInfo().getSelectedFeaturesList().setVisFeature(new ArrayList<>());
        rr.getRetrieveCart().getCart().getLineDetails().setLineInfo(lineArray);
        omniDLHelper.updateEvent(vzdl);

        List<VisFeature> featureList = new ArrayList<>();
        VisFeature feature = new VisFeature();
        featureList.add(null);
        feature.setAddDeleteInd("");
        featureList.add(feature);
        lineArray[0].getServiceInfo().getSelectedFeaturesList().setVisFeature(featureList);
        rr.getRetrieveCart().getCart().getLineDetails().setLineInfo(lineArray);
        omniDLHelper.updateEvent(vzdl);

        featureList = new ArrayList<>();
        feature.setAddDeleteInd(null);
        featureList.add(feature);
        lineArray[0].getServiceInfo().getSelectedFeaturesList().setVisFeature(featureList);
        rr.getRetrieveCart().getCart().getLineDetails().setLineInfo(lineArray);
        omniDLHelper.updateEvent(vzdl);

        featureList = new ArrayList<>();
        feature.setAddDeleteInd("z");
        featureList.add(feature);
        lineArray[0].getServiceInfo().getSelectedFeaturesList().setVisFeature(featureList);
        rr.getRetrieveCart().getCart().getLineDetails().setLineInfo(lineArray);
        omniDLHelper.updateEvent(vzdl);

        featureList = new ArrayList<>();
        feature.setAddDeleteInd("A");
        featureList.add(feature);
        lineArray[0].getServiceInfo().getSelectedFeaturesList().setVisFeature(featureList);
        rr.getRetrieveCart().getCart().getLineDetails().setLineInfo(lineArray);
        omniDLHelper.updateEvent(vzdl);
        Assert.assertNotNull(vzdl.getEvent().getValue());
    }
    @Test
    public void getVzdlDataForAddPlanTest() {
        AddPlanUIRequest request = null;
        AddPlanUIResponse response = null;
        Assert.assertNull(omniDLHelper.getVzdlDataForAddPlanAndPerks(request, response, false));

        request = new AddPlanUIRequest();
        response = new AddPlanUIResponse();
        Assert.assertNull(omniDLHelper.getVzdlDataForAddPlanAndPerks(request, response, false));

        request.setData(new AddPlanData());
        omniDLHelper.getVzdlDataForAddPlanAndPerks(request, response, false);

        response.setServiceBody(new AddPlanServiceBody());
        omniDLHelper.getVzdlDataForAddPlanAndPerks(request, response, false);

        request = new AddPlanUIRequest();
        omniDLHelper.getVzdlDataForAddPlanAndPerks(request, response, false);
    }
    @Test
    public void getVzdlDataForAddAccessoriesTest() {
        AddAccessoriesUIRequest request = null;
        AddAccessoriesUIResponse response = null;
        Assert.assertNull(omniDLHelper.getVzdlDataForAddAccessories(request, response, null));

        request = new AddAccessoriesUIRequest();
        response = new AddAccessoriesUIResponse();
        Assert.assertNull(omniDLHelper.getVzdlDataForAddAccessories(request, response, null));

        request.setData(new AddAccessoriesData());
        omniDLHelper.getVzdlDataForAddAccessories(request, response, null);

        response.setServiceBody(new AddAccServiceBody());
        omniDLHelper.getVzdlDataForAddAccessories(request, response, null);

        request = new AddAccessoriesUIRequest();
        omniDLHelper.getVzdlDataForAddAccessories(request, response, null);
    }
    @Test
    public void getVzdlDataForAddFeaturesTest() {
        AddFeaturesUIRequest request = null;
        AddFeaturesUIResponse response = null;
        Assert.assertNull(omniDLHelper.getVzdlDataForAddFeatures(request, response));

        request = new AddFeaturesUIRequest();
        response = new AddFeaturesUIResponse();
        Assert.assertNull(omniDLHelper.getVzdlDataForAddFeatures(request, response));

        request.setData(new AddFeaturesData());
        omniDLHelper.getVzdlDataForAddFeatures(request, response);

        response.setServiceBody(new AddFeaturesServiceBody());
        omniDLHelper.getVzdlDataForAddFeatures(request, response);

        request = new AddFeaturesUIRequest();
        omniDLHelper.getVzdlDataForAddFeatures(request, response);
    }
    @Test
    public void getVzdlDataForAddBuyoutTest() {
        AddBuyoutUIRequest request = null;
        AddBuyoutUIResponse response = null;
        Assert.assertNull(omniDLHelper.getVzdlDataForAddBuyout(request, response));

        request = new AddBuyoutUIRequest();
        response = new AddBuyoutUIResponse();
        Assert.assertNull(omniDLHelper.getVzdlDataForAddBuyout(request, response));

        request.setData(new AddBuyoutData());
        omniDLHelper.getVzdlDataForAddBuyout(request, response);

        response.setServiceBody(new AddBuyoutServiceBody());
        omniDLHelper.getVzdlDataForAddBuyout(request, response);

        request = new AddBuyoutUIRequest();
        omniDLHelper.getVzdlDataForAddBuyout(request, response);
    }
    @Test
    public void populateVzdlDataForAddPlanTest() {
        AddPlanData data = new AddPlanData();
        AddPlanUIRequest request = new AddPlanUIRequest();
        AddPlanUIResponse addPlanUIResponse = new AddPlanUIResponse();
        addPlanUIResponse.setServiceBody(new AddPlanServiceBody());
        addPlanUIResponse.getServiceBody().setServiceResponse(new AddPlanServiceResponse());
        addPlanUIResponse.getServiceBody().getServiceResponse().setContext(new AddPlanContext());
        addPlanUIResponse.getServiceBody().getServiceResponse().getContext().setCartInfo(new CartServiceCartInfo());
        Line[] lineArr = new Line[2];
        Line line = new Line();
        line.setCurrentPlanType(null);
        lineArr[0] = line;
        lineArr[1] = null;
        Lines[] reqLine = new Lines[1];
        Lines lines = new Lines();
        Plan plan = new Plan();
        plan.setId("23424");
        plan.setPath("testLoc");
        lines.setPlan(plan);
        reqLine[0] = lines;
        data.setLines(reqLine);
        request.setData(data);
        addPlanUIResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(lineArr);
        omniDLHelper.populateVzdlDataForAddPlanAndPerks(request,addPlanUIResponse, false);

        addPlanUIResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(new Line[0]);
        request.getData().setLines(new Lines[1]);
        omniDLHelper.populateVzdlDataForAddPlanAndPerks(request,addPlanUIResponse, false);

        addPlanUIResponse.getServiceBody().getServiceResponse().setContext(null);
        request.getData().setLines(new Lines[0]);
        omniDLHelper.populateVzdlDataForAddPlanAndPerks(request,addPlanUIResponse, false);
    }

    @Test
    public void populateVzdlDataForAddPlanTest1() {
        Vzdl vzdl = new Vzdl();
        AddPlanUIRequest request = new AddPlanUIRequest();
        request.setData(new AddPlanData());
        Optional<Lines> requestLines= Optional.empty();
        Lines[] reqLine = new Lines[1];
        Lines lines= new Lines();
        reqLine[0]=lines;
        request.getData().setLines(reqLine);

        CartServiceCartInfo cartInfo = new CartServiceCartInfo();

        omniDLHelper.updateProductDataForPlan(vzdl, request, requestLines, Optional.empty());
        Assert.assertNotNull(vzdl.getProduct());

        reqLine[0]= null;
        request.getData().setLines(reqLine);
        omniDLHelper.updateProductDataForPlan(vzdl, request, requestLines, Optional.empty());

        reqLine = new Lines[3];
        Lines line= new Lines();
        line.setMtn("123");
        reqLine[0]= line;
        line.setPlan(new Plan());
        line.setLinechanged(true);
        reqLine[1]= line;
        line.getPlan().setId("abc");
        line.getPlan().setPath(null);

        line.setPlan(null);
        reqLine[2] = line;
        request.getData().setLines(reqLine);
        requestLines= Optional.of(reqLine[0]);
        omniDLHelper.updateProductDataForPlan(vzdl, request, requestLines, Optional.empty());

        reqLine= new Lines[1];
        line.setMtn(null);
        reqLine[0]= line;
        request.getData().setLines(reqLine);
        omniDLHelper.updateProductDataForPlan(vzdl, request, requestLines, Optional.of(cartInfo));

        reqLine= new Lines[1];
        line.setMtn("");
        reqLine[0]= line;
        request.getData().setLines(reqLine);
        omniDLHelper.updateProductDataForPlan(vzdl, request, requestLines, Optional.of(cartInfo));

        line.setPlan(new Plan());
        line.setAddFeatures(new ArrayList<>());
        reqLine= new Lines[1];
        line.setLinechanged(false);
        line.setMtn("123");
        reqLine[0]= line;
        request.getData().setLines(reqLine);
        omniDLHelper.updateProductDataForPlan(vzdl, request, requestLines, Optional.of(cartInfo));

        line.setLinechanged(true);
        line.getPlan().setId("");
        line.getPlan().setPath("");
        reqLine[0]= line;
        request.getData().setLines(reqLine);
        Line[] respLine= new Line[2];
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductDataForPlan(vzdl, request, requestLines, Optional.of(cartInfo));

        line.getPlan().setId("abc");
        line.getPlan().setPath(null);
        reqLine[0]= line;
        request.getData().setLines(reqLine);
        respLine[0]= null;
        respLine[1]= new Line();
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductDataForPlan(vzdl, request, requestLines, Optional.of(cartInfo));

        line.getPlan().setPath("path for the plan");
        line.setMultiLineSeqNumber(null);
        line.getPlan().setPropId("");
        reqLine[0]= line;
        request.getData().setLines(reqLine);
        omniDLHelper.updateProductDataForPlan(vzdl, request, requestLines, Optional.of(cartInfo));

        line.getPlan().setPropId("123");
        reqLine[0]= line;
        request.getData().setLines(reqLine);
        omniDLHelper.updateProductDataForPlan(vzdl, request, requestLines, Optional.of(cartInfo));

        Line respLine1= new Line();
        respLine1.setMtn("");
        respLine[0] = respLine1;
        respLine1.setMtn("123");
        respLine[1]= respLine1;
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductDataForPlan(vzdl, request, requestLines, Optional.of(cartInfo));

        respLine1.setPlan(new Plan());
        respLine= new Line[1];
        respLine[0]= respLine1;
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductDataForPlan(vzdl, request, requestLines, Optional.of(cartInfo));

        respLine1.getPlan().setId("");
        respLine[0]= respLine1;
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductDataForPlan(vzdl, request, requestLines, Optional.of(cartInfo));

        respLine1.getPlan().setId(null);
        respLine[0]= respLine1;
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductDataForPlan(vzdl, request, requestLines, Optional.of(cartInfo));

        respLine1.getPlan().setId("abc");
        respLine1.getPlan().setDiscountedPrice(null);
        respLine[0]= respLine1;
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductDataForPlan(vzdl, request, requestLines, Optional.of(cartInfo));

        respLine1.getPlan().setDiscountedPrice("");
        respLine1.setCurrentPlanType("");
        respLine[0]= respLine1;
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductDataForPlan(vzdl, request, requestLines, Optional.of(cartInfo));

        respLine1.getPlan().setDiscountedPrice("50.00");
        respLine1.setCurrentPlanType(null);
        respLine[0]= respLine1;
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductDataForPlan(vzdl, request, requestLines, Optional.of(cartInfo));

        respLine1.getPlan().setDiscountedPrice("");
        respLine1.getPlan().setProductId("1");
        respLine1.getPlan().setName("test");
        respLine1.getPlan().setPrice("123");
        respLine1.setCurrentPlanType(null);
        respLine[0]= respLine1;
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductDataForPlan(vzdl, request, requestLines, Optional.of(cartInfo));

        respLine1.setCurrentPlanType("123");
        respLine[0]= respLine1;
        cartInfo.setLines(respLine);
        omniDLHelper.updateProductDataForPlan(vzdl, request, requestLines, Optional.of(cartInfo));

        Assert.assertNotNull(request);
    }

    @Test
    public void populateVzdlDataForAddBuyoutTest() {
        AddBuyoutData data = new AddBuyoutData();
        AddBuyoutUIRequest request = new AddBuyoutUIRequest();
        AddBuyoutUIResponse addBuyoutUIResponse = new AddBuyoutUIResponse();
        addBuyoutUIResponse.setServiceBody(new AddBuyoutServiceBody());
        addBuyoutUIResponse.getServiceBody().setServiceResponse(new AddBuyoutServiceResponse());
        addBuyoutUIResponse.getServiceBody().getServiceResponse().setContext(new AddBuyoutContext());
        addBuyoutUIResponse.getServiceBody().getServiceResponse().getContext().setCartInfo(new CartServiceCartInfo());
        Line[] lineArr = new Line[2];
        Line line = new Line();
        line.setCurrentPlanType(null);
        lineArr[0] = line;
        lineArr[1] = null;
        Lines[] reqLine = new Lines[1];
        Lines lines = new Lines();
        lines.setMtn("8323149457");
        reqLine[0] = lines;
        data.setLines(reqLine);
        request.setData(data);
        addBuyoutUIResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(lineArr);
        omniDLHelper.populateVzdlDataForAddBuyout(request,addBuyoutUIResponse);

        addBuyoutUIResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(new Line[0]);
        request.getData().setLines(new Lines[1]);
        omniDLHelper.populateVzdlDataForAddBuyout(request,addBuyoutUIResponse);

        addBuyoutUIResponse.getServiceBody().getServiceResponse().setContext(null);
        request.getData().setLines(new Lines[0]);
        omniDLHelper.populateVzdlDataForAddBuyout(request,addBuyoutUIResponse);
    }
    @Test
    public void populateVzdlDataForAddFeaturesTest() {
        AddFeaturesData data = new AddFeaturesData();
        AddFeaturesUIRequest request = new AddFeaturesUIRequest();
        AddFeaturesUIResponse addFeaturesUIResponse = new AddFeaturesUIResponse();
        addFeaturesUIResponse.setServiceBody(new AddFeaturesServiceBody());
        addFeaturesUIResponse.getServiceBody().setServiceResponse(new AddFeaturesServiceResponse());
        addFeaturesUIResponse.getServiceBody().getServiceResponse().setContext(new AddFeaturesContext());
        addFeaturesUIResponse.getServiceBody().getServiceResponse().getContext().setCartInfo(new CartServiceCartInfo());
        Line[] lineArr = new Line[2];
        Line line = new Line();
        line.setCurrentPlanType(null);
        lineArr[0] = line;
        lineArr[1] = null;
        LineFeature[] reqLine = new LineFeature[1];
        LineFeature lines = new LineFeature();
        lines.setMtn("8323149457");
        reqLine[0] = lines;
        data.setLines(reqLine);
        request.setData(data);
        List<Feature> featureList =  new ArrayList<>();
        Feature feature = new Feature();
        feature.setId("1");
        feature.setQuantity(1);
        feature.setActionIndicator("A");
        featureList.add(feature);
        FeatureAction featureAction = new FeatureAction();
        featureAction.setAdd(featureList);
        featureAction.setRemove(featureList);
        addFeaturesUIResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(lineArr);
        request.getData().getLines()[0].setFeatures(featureAction);
        omniDLHelper.populateVzdlDataForAddFeatures(request,addFeaturesUIResponse);

        addFeaturesUIResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(new Line[0]);
        omniDLHelper.populateVzdlDataForAddFeatures(request,addFeaturesUIResponse);

        addFeaturesUIResponse.getServiceBody().getServiceResponse().setContext(null);
        omniDLHelper.populateVzdlDataForAddFeatures(request,addFeaturesUIResponse);

        request.getData().setLines(new LineFeature[0]);
        omniDLHelper.populateVzdlDataForAddFeatures(request,addFeaturesUIResponse);
    }

    @Test
    public void updateProductDataForFeaturesTest() {
        Vzdl vzdl = new Vzdl();
        Optional<LineFeature> requestLines= Optional.empty();
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        AddFeaturesData data = new AddFeaturesData();
        AddFeaturesUIRequest request = new AddFeaturesUIRequest();
        AddFeaturesUIResponse addFeaturesUIResponse = new AddFeaturesUIResponse();
        addFeaturesUIResponse.setServiceBody(new AddFeaturesServiceBody());
        addFeaturesUIResponse.getServiceBody().setServiceResponse(new AddFeaturesServiceResponse());
        addFeaturesUIResponse.getServiceBody().getServiceResponse().setContext(new AddFeaturesContext());
        addFeaturesUIResponse.getServiceBody().getServiceResponse().getContext().setCartInfo(new CartServiceCartInfo());

        LineFeature[] reqLine = new LineFeature[1];
        LineFeature lines = new LineFeature();
        lines.setMtn("8585858585");
        reqLine[0] = lines;
        data.setLines(reqLine);
        request.setData(data);

        List<Feature> featureList =  new ArrayList<>();
        Feature feature = new Feature();
        feature.setId("1");
        feature.setQuantity(1);
        feature.setActionIndicator("A");
        Feature feature1 = new Feature();
        feature1.setId("1");
        feature1.setQuantity(1);
        feature1.setActionIndicator(null);
        featureList.add(feature);
        FeatureAction featureAction = new FeatureAction();
        featureAction.setAdd(featureList);
        featureAction.setRemove(featureList);

        ConflictedSPO spo= new ConflictedSPO();
        spo.setId("Id");
        spo.setSkuId("skuId");
        spo.setPrice("20");
        spo.setDescription("desc");
        ConflictedSPO[] spos= new ConflictedSPO[4];
        spos[0]=spo;
        spos[1]=spo;
        spos[2]= spo;
        spos[3]=null;

        Line[] respLine = new Line[2];
        Line line = new Line();
        line.setMtn("8585858585");
        line.setSpos(spos);
        line.setCurrentPlanType(null);
        respLine[0] = line;
        respLine[1] = null;

        cartInfo.setLines(respLine);
        requestLines = Optional.of(reqLine[0]);
        request.getData().getLines()[0].setFeatures(featureAction);
        addFeaturesUIResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(respLine);
        request.getData().getLines()[0].setFeatures(featureAction);
        omniDLHelper.updateProductDataForFeatures(vzdl, request, requestLines, Optional.of(cartInfo));

        feature.setId("842");
        spo.setId("842");
        spos[1]=spo;
        omniDLHelper.updateProductDataForFeatures(vzdl, request, requestLines, Optional.of(cartInfo));

        spo.setId("842");
        spos[1]=spo;
        spo.setSkuId("");
        spo.setDescription("");
        spo.setPrice("");
        omniDLHelper.updateProductDataForFeatures(vzdl, request, requestLines, Optional.of(cartInfo));

        feature.setId("842");
        spo.setId("842");
        spos[1]=spo;
        spo.setSkuId("sku");
        omniDLHelper.updateProductDataForFeatures(vzdl, request, requestLines, Optional.of(cartInfo));

        spo.setSkuId("");
        spo.setPrice("");
        spo.setDescription("");
        spos[0] = null;
        omniDLHelper.updateProductDataForFeatures(vzdl, request, requestLines, Optional.empty());

        request.getData().getLines()[0].getFeatures().setAdd(Collections.emptyList());
        omniDLHelper.updateProductDataForFeatures(vzdl, request, requestLines, Optional.of(cartInfo));

        request.getData().getLines()[0].getFeatures().setAdd(null);
        omniDLHelper.updateProductDataForFeatures(vzdl, request, requestLines, Optional.of(cartInfo));

        request.getData().getLines()[0].setFeatures(null);
        omniDLHelper.updateProductDataForFeatures(vzdl, request, requestLines, Optional.of(cartInfo));

        omniDLHelper.updateProductDataForFeatures(vzdl, request, Optional.empty(), Optional.of(cartInfo));

        Assert.assertNotNull(request);
    }

    @Test
    public void populateVzdlDataForAddAccessoriesTest() {
        AddAccessoriesData data = new AddAccessoriesData();
        AddAccessoriesUIRequest request = new AddAccessoriesUIRequest();
        AddAccessoriesUIResponse addAccessoriesUIResponse = new AddAccessoriesUIResponse();
        addAccessoriesUIResponse.setServiceBody(new AddAccServiceBody());
        addAccessoriesUIResponse.getServiceBody().setServiceResponse(new AddAccServiceResponse());
        addAccessoriesUIResponse.getServiceBody().getServiceResponse().setContext(new AddAccContext());
        addAccessoriesUIResponse.getServiceBody().getServiceResponse().getContext().setCartInfo(new CartServiceCartInfo());
        Line[] lineArr = new Line[2];
        Line line = new Line();
        line.setCurrentPlanType(null);
        lineArr[0] = line;
        lineArr[1] = null;
        Lines[] reqLine = new Lines[1];
        Lines lines = new Lines();
        lines.setMtn("8323149457");
        Accessory[] addAccessories =  new Accessory[1];
        Accessory accessory = new Accessory();
        accessory.setId("1");
        addAccessories[0] = accessory;
        lines.setAddAccessories(addAccessories);
        reqLine[0] = lines;
        data.setLines(reqLine);
        request.setData(data);
        addAccessoriesUIResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(lineArr);
        omniDLHelper.populateVzdlDataForAddAccessories(request,addAccessoriesUIResponse, null);

        addAccessoriesUIResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(new Line[0]);
        request.getData().setLines(new Lines[1]);
        omniDLHelper.populateVzdlDataForAddAccessories(request,addAccessoriesUIResponse, null);

        addAccessoriesUIResponse.getServiceBody().getServiceResponse().setContext(null);
        request.getData().setLines(new Lines[0]);
        omniDLHelper.populateVzdlDataForAddAccessories(request,addAccessoriesUIResponse, null);
    }

    @Test
    public void updateProductDataForAccessoriesTest() {
        Vzdl vzdl = new Vzdl();
        Optional<Lines> requestLines= Optional.empty();
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        AddAccessoriesData data = new AddAccessoriesData();
        AddAccessoriesUIRequest request = new AddAccessoriesUIRequest();
        AddAccessoriesUIResponse addAccessoriesUIResponse = new AddAccessoriesUIResponse();
        addAccessoriesUIResponse.setServiceBody(new AddAccServiceBody());
        addAccessoriesUIResponse.getServiceBody().setServiceResponse(new AddAccServiceResponse());
        addAccessoriesUIResponse.getServiceBody().getServiceResponse().setContext(new AddAccContext());
        addAccessoriesUIResponse.getServiceBody().getServiceResponse().getContext().setCartInfo(new CartServiceCartInfo());

        ConflictedSPO spo= new ConflictedSPO();
        spo.setId("1");
        spo.setSkuId("sku");
        spo.setPrice("50");
        spo.setDescription("description");
        ConflictedSPO[] spos= new ConflictedSPO[4];
        spos[0]=spo;
        spos[1]=spo;
        spo.setId(null);
        spos[2]= spo;
        spos[3]=null;

        Line[] respLine = new Line[2];
        Line line = new Line();
        line.setMtn("8323149457");
        line.setSpos(spos);
        line.setCurrentPlanType(null);
        respLine[0] = line;
        respLine[1] = null;

        Lines[] reqLine = new Lines[1];
        Lines lines = new Lines();
        lines.setMtn("8323149457");
        Accessory[] addAccessories =  new Accessory[2];
        Accessory accessory = new Accessory();
        accessory.setId("1");
        Accessory accessory1 = new Accessory();
        accessory.setId(CartConstants.SETUPANDGO);
        addAccessories[0] = accessory;
        addAccessories[1] = accessory1;
        lines.setAddAccessories(addAccessories);
        reqLine[0] = lines;
        data.setLines(reqLine);
        request.setData(data);

        cartInfo.setLines(respLine);
        requestLines = Optional.of(reqLine[0]);
        addAccessoriesUIResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(respLine);
        omniDLHelper.updateProductDataForAccessories(vzdl, request, requestLines, Optional.of(cartInfo), null);
        cartInfo.setLines(respLine);

        CatalogResponse catalogResponse= new CatalogResponse();
        omniDLHelper.updateProductDataForAccessories(vzdl, request, requestLines, Optional.of(cartInfo),catalogResponse);

        CatalogData catalogData= new CatalogData();
        catalogResponse.setData(catalogData);
        omniDLHelper.updateProductDataForAccessories(vzdl, request, requestLines, Optional.of(cartInfo), catalogResponse);

        SoftSkuCatalogItem softSkuCatalogItem= new SoftSkuCatalogItem();
        catalogData.setSoftSkuCatalogItems(Collections.singletonList(softSkuCatalogItem));
        omniDLHelper.updateProductDataForAccessories(vzdl, request, requestLines, Optional.of(cartInfo), catalogResponse);

        softSkuCatalogItem.setSkuDisplayName("Setup and Go");
        softSkuCatalogItem.setSorId("SETUPANDGO");
        onevz.soe.cart.model.catalog.Price price = new onevz.soe.cart.model.catalog.Price();
        ContractInfo contractInfo= new ContractInfo();
        contractInfo.setOriginalPrice(BigDecimal.ONE);
        price.setFullRetailPrice(contractInfo);
        softSkuCatalogItem.setPrice(price);
        catalogData.setSoftSkuCatalogItems(Collections.singletonList(softSkuCatalogItem));
        omniDLHelper.updateProductDataForAccessories(vzdl, request, requestLines, Optional.of(cartInfo), catalogResponse);

        softSkuCatalogItem.setSkuDisplayName("");
        softSkuCatalogItem.setSorId("SETUPANDGO");


        price.setFullRetailPrice(null);
        softSkuCatalogItem.setPrice(price);
        catalogData.setSoftSkuCatalogItems(Collections.singletonList(softSkuCatalogItem));
        omniDLHelper.updateProductDataForAccessories(vzdl, request, requestLines, Optional.of(cartInfo), catalogResponse);


        accessory.setId("1234");
        spo.setId("1234");
        spos[1]=spo;
        omniDLHelper.updateProductDataForAccessories(vzdl, request, requestLines, Optional.of(cartInfo), null);

        accessory.setId("1234");
        spo.setId("1234");
        spos[1]=spo;
        spo.setSkuId("skuId");
        omniDLHelper.updateProductDataForAccessories(vzdl, request, requestLines, Optional.of(cartInfo), null);

        accessory.setId("1234");
        spo.setId("1234");
        spos[1]=spo;
        spo.setSkuId("");
        spo.setDescription("");
        spo.setPrice("");
        omniDLHelper.updateProductDataForAccessories(vzdl, request, requestLines, Optional.of(cartInfo), null);

        accessory.setId("1234");
        spo.setId("1234");
        spos[1]=spo;
        spo.setSkuId("skuId");
        request.getData().getLines()[0].setAddAccessories(null);
        omniDLHelper.updateProductDataForAccessories(vzdl, request, requestLines, Optional.of(cartInfo), null);
        accessory.setId("1234");

        spo.setId("1234");
        spos[1]=spo;
        spo.setSkuId("skuId");
        request.getData().getLines()[0].setAddAccessories(new Accessory[0]);
        omniDLHelper.updateProductDataForAccessories(vzdl, request, requestLines, Optional.of(cartInfo), null);

        accessory.setId("1234");
        spo.setId("1234");
        spos[1]=spo;
        spo.setSkuId("skuId");
        omniDLHelper.updateProductDataForAccessories(vzdl, request, Optional.empty(), Optional.of(cartInfo), null);

        Assert.assertNotNull(request);
    }

    @Test
    public void updateProductDataForFeaturesTest_addPlanAndPerks() {
        Vzdl vzdl = new Vzdl();
        Optional<Lines> requestLines= Optional.empty();
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        AddPlanData data = new AddPlanData();
        AddPlanUIRequest request = new AddPlanUIRequest();
        AddPlanUIResponse addPlanUIResponse = new AddPlanUIResponse();
        addPlanUIResponse.setServiceBody(new AddPlanServiceBody());
        addPlanUIResponse.getServiceBody().setServiceResponse(new AddPlanServiceResponse());
        addPlanUIResponse.getServiceBody().getServiceResponse().setContext(new AddPlanContext());
        addPlanUIResponse.getServiceBody().getServiceResponse().getContext().setCartInfo(new CartServiceCartInfo());

        Lines[] reqLine = new Lines[1];
        Lines lines = new Lines();
        lines.setMtn("8585858585");
        reqLine[0] = lines;
        data.setLines(reqLine);
        request.setData(data);

        List<Feature> featureList =  new ArrayList<>();
        Feature feature = new Feature();
        feature.setId("1");
        feature.setQuantity(1);
        feature.setActionIndicator("A");
        featureList.add(feature);
        List<Feature> featureListRemove =  new ArrayList<>();
        Feature feature1 = new Feature();
        feature1.setId("1");
        feature1.setQuantity(1);
        feature1.setActionIndicator(null);
        featureListRemove.add(feature1);

        ConflictedSPO spo= new ConflictedSPO();
        spo.setId("Id");
        spo.setSkuId("skuId");
        spo.setPrice("20");
        spo.setDescription("desc");
        ConflictedSPO[] spos= new ConflictedSPO[4];
        spos[0]=spo;
        spos[1]=spo;
        spos[2]= spo;
        spos[3]=null;

        Line[] respLine = new Line[2];
        Line line = new Line();
        line.setMtn("8585858585");
        line.setSpos(spos);
        line.setCurrentPlanType(null);
        respLine[0] = line;
        respLine[1] = null;

        cartInfo.setLines(respLine);
        requestLines = Optional.of(reqLine[0]);
        request.getData().getLines()[0].setAddFeatures(featureList);
        request.getData().getLines()[0].setRemoveFeatures(featureListRemove);
        addPlanUIResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(respLine);
        omniDLHelper.getVzdlDataForAddPlanAndPerks(request,addPlanUIResponse, true);
        omniDLHelper.populateVzdlDataForAddPlanAndPerks(request, addPlanUIResponse, true);

        omniDLHelper.updateProductDataForFeatures(vzdl, request, requestLines, Optional.of(cartInfo));

        feature.setId("842");
        spo.setId("842");
        spos[1]=spo;
        omniDLHelper.updateProductDataForFeatures(vzdl, request, requestLines, Optional.of(cartInfo));

        spo.setId("842");
        spos[1]=spo;
        spo.setPrice("");
        spo.setSkuId("");
        spo.setDescription("");
        omniDLHelper.updateProductDataForFeatures(vzdl, request, requestLines, Optional.of(cartInfo));

        feature.setId("842");
        spo.setId("842");
        spos[1]=spo;
        spo.setSkuId("sku");
        omniDLHelper.updateProductDataForFeatures(vzdl, request, requestLines, Optional.of(cartInfo));

        spo.setSkuId("");
        spo.setPrice("");
        spo.setDescription("");
        spos[0] = null;
        omniDLHelper.updateProductDataForFeatures(vzdl, request, requestLines, Optional.empty());

        request.getData().getLines()[0].setAddFeatures(null);
        request.getData().getLines()[0].setRemoveFeatures(null);
        omniDLHelper.updateProductDataForFeatures(vzdl, request, requestLines, Optional.of(cartInfo));

        request.getData().getLines()[0].setAddFeatures(Collections.emptyList());
        request.getData().getLines()[0].setRemoveFeatures(Collections.emptyList());
        omniDLHelper.updateProductDataForFeatures(vzdl, request, requestLines, Optional.of(cartInfo));

        omniDLHelper.updateProductDataForFeatures(vzdl, request, Optional.empty(), Optional.empty());

        Assert.assertNotNull(request);
    }



}
