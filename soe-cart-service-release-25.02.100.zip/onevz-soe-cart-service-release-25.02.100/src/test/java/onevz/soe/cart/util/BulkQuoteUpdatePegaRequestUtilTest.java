package onevz.soe.cart.util;

import junit.framework.Assert;
import onevz.soe.cart.model.bulkcartupdate.BulkQuoteUIRequest;
import onevz.soe.cart.model.bulkcartupdate.CartData;
import onevz.soe.cart.model.bulkcartupdate.CartServiceBulkCartInfo;
import onevz.soe.cart.model.bulkcartupdate.Lines;
import onevz.soe.cart.model.tradeIn.appraiseDevice.DeviceOutInfo;
import onevz.soe.cart.model.tradeIn.appraiseDevice.RecycleDeviceOffer;
import onevz.soe.cart.model.tradeIn.appraiseDevice.TriageInfo;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BulkQuoteUpdatePegaRequestUtilTest {

    @Test
    public void testpopulateTradeInInfoForLines() throws Exception{
        CartServiceBulkCartInfo cartInfo = new CartServiceBulkCartInfo();
        List<DeviceOutInfo> tradeInItems = new ArrayList<>();
        BulkQuoteUIRequest request = new BulkQuoteUIRequest();
        CartData data = new CartData();
        request.setData(data);
        BulkQuoteUpdatePegaRequestUtil.populateTradeInInfoForLines( cartInfo, tradeInItems,  request);
        org.junit.Assert.assertNotNull(request);

        //data null
        request.setData(null);
        BulkQuoteUpdatePegaRequestUtil.populateTradeInInfoForLines( cartInfo, tradeInItems,  request);
        org.junit.Assert.assertNotNull(request);

        //tradeIndata
        Lines line = new Lines();
        DeviceOutInfo deviceOutInfo= new DeviceOutInfo();
        deviceOutInfo.setTriageInfo(new TriageInfo());
        deviceOutInfo.setRecycleDeviceOffer(new RecycleDeviceOffer());
        line.setTradeInItems(Collections.singletonList(deviceOutInfo));
        data.setLines(Collections.singletonList(line));
        request.setData(data);
        BulkQuoteUpdatePegaRequestUtil.populateTradeInInfoForLines( cartInfo, tradeInItems,  request);
        org.junit.Assert.assertNotNull(tradeInItems);
        Assert.assertEquals(1,tradeInItems.size());
        Assert.assertNotNull(tradeInItems.get(0).getTriageInfo());
        Assert.assertNotNull(tradeInItems.get(0).getRecycleDeviceOffer());
    }
}
