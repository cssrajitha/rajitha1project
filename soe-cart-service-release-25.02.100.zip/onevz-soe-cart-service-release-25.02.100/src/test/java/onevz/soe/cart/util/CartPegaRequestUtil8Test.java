package onevz.soe.cart.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.requests.AddPlanAndDevicePEGARequest;
import onevz.soe.cart.ui.requests.AddPlanAndDeviceUIRequest;
import org.junit.Test;
import org.mockito.Mock;

import static org.junit.Assert.assertNotNull;

public class CartPegaRequestUtil8Test {

    @Mock
    AddPlanAndDeviceUIRequest addPlanUIRequest;

    @Mock
    ObjectMapper mapper;

    @Test
    public void formatAddPlanAndDeviceRequest() throws JsonProcessingException {
        AddPlanAndDevicePEGARequest addPlanAndDevicePEGARequest = new AddPlanAndDevicePEGARequest();
        String sampleUIReq = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"Restart\",\"intendType\":\"NSE_5G\",\"bundleInstallType\":\"5GHomeCBandSelfSetup\",\"transactionType\":\"WIFIBACKUP\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]},\"midnight\":\"Y\"}";
        mapper = new ObjectMapper();

        addPlanUIRequest = mapper.readValue(sampleUIReq, AddPlanAndDeviceUIRequest.class);
        AddPlanAndDevicePEGARequest result = CartPegaRequestUtil8.formatAddPlanAndDeviceRequest(addPlanAndDevicePEGARequest,addPlanUIRequest);
        assertNotNull(result);

    }
    @Test
    public void formatAddPlanAndDeviceRequestNoTransactionType() throws JsonProcessingException {
        AddPlanAndDevicePEGARequest addPlanAndDevicePEGARequest = new AddPlanAndDevicePEGARequest();
        String sampleUIReq = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"Restart\",\"intendType\":\"NSE_5G\",\"bundleInstallType\":\"5GHomeCBandSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]},\"midnight\":\"Y\"}";
        mapper = new ObjectMapper();

        addPlanUIRequest = mapper.readValue(sampleUIReq, AddPlanAndDeviceUIRequest.class);
        AddPlanAndDevicePEGARequest result = CartPegaRequestUtil8.formatAddPlanAndDeviceRequest(addPlanAndDevicePEGARequest,addPlanUIRequest);
        assertNotNull(result);

    }
}
