package onevz.soe.cart.controller;

import onevz.cxp.feature.util.FeatureFlag;
import onevz.soe.cart.helper.FwaDeviceUpgradeHelper;
import onevz.soe.cart.helper.RedisHelper2;
import onevz.soe.cart.requests.DeviceExchangeRequest;
import onevz.soe.cart.responses.DeviceExchangeResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.util.MultiValueMap;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.net.URI;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class FwaDeviceExchangeControllerTest {
    @InjectMocks
    private FwaDeviceUpgradeCreateCartController controller;

    @Mock
    private FwaDeviceUpgradeHelper helper;

    @Mock
    private FeatureFlag featureFlag;

    @Mock
    private RedisHelper2 redisHelper;

    @Test
    public void fwaDeviceExchangeTest(){
        DeviceExchangeRequest request = new DeviceExchangeRequest();
        URI url = URI.create("http://localhost:8080/fwaDeviceUpgradeCreateCart");
        MultiValueMap<String, String> headersMap = new HttpHeaders();
        headersMap.add("channelId","VZW-DOTCOM");
        headersMap.add("sso_jwt","eydrgrg.rgrgr.reergh");
        headersMap.add("E2erequestid","8a202548-094c-4802-9d60-cb9209f03c75");
        headersMap.add("accountNumber","0685927769-00001" );
        headersMap.add("digital_ig_session","POE-D-07d2aa08-ac97-41ee-91fc-d90575efe692");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headersMap).build();
        request.setIntent("EUP_5G");
        request.setNetworkBandWidthType("CBD");
        request.setAccountNumber("0685927769-00001");
        request.setMtn("2243064621");
        when(featureFlag.isFeatureEnabled(anyString(), anyString(), anyString(),any(Boolean.class))).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.fetchRedisData(any())).thenReturn(Mono.just(request));
        when(helper.getDeviceUpgradeDetails(any())).thenReturn(Mono.just(new DeviceExchangeResponse()));
        StepVerifier.create(controller.fwaDeviceExchange(httpHeader,request))
                .assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        request.setNetworkBandWidthType(null);
        when(redisHelper.fetchRedisData(any())).thenReturn(Mono.just(request));
        StepVerifier.create(controller.fwaDeviceExchange(httpHeader,request))
                .assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        request.setNetworkBandWidthType("CBD");
        request.setMtn(null);
        when(redisHelper.fetchRedisData(any())).thenReturn(Mono.just(request));
        StepVerifier.create(controller.fwaDeviceExchange(httpHeader,request))
                .assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        when(redisHelper.fetchRedisData(any())).thenReturn(Mono.just(new DeviceExchangeRequest()));
        when(helper.getDeviceUpgradeDetails(any())).thenReturn(Mono.just(new DeviceExchangeResponse()));
        StepVerifier.create(controller.fwaDeviceExchange(httpHeader,new DeviceExchangeRequest()))
                .assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        when(featureFlag.isFeatureEnabled(anyString(), anyString(), anyString(),any(Boolean.class))).thenReturn(Mono.just(Boolean.FALSE));
        when(redisHelper.fetchRedisData(any())).thenReturn(Mono.just(new DeviceExchangeRequest()));
        when(helper.getDeviceUpgradeDetails(any())).thenReturn(Mono.just(new DeviceExchangeResponse()));
        StepVerifier.create(controller.fwaDeviceExchange(httpHeader,new DeviceExchangeRequest()))
                .assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }
}
