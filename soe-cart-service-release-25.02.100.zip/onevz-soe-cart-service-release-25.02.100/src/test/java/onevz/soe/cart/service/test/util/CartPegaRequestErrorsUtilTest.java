package onevz.soe.cart.service.test.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.deviceIdValidation.DeviceIdValidationData;
import onevz.soe.cart.model.deviceIdValidation.DeviceIdValidationLine;
import onevz.soe.cart.model.edgeup.EdgeUp;
import onevz.soe.cart.ui.common.*;
import onevz.soe.cart.ui.requests.*;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import onevz.soe.cart.model.addDevice.AddPlanDeviceCartInfo;
import onevz.soe.cart.model.addTrialContactInfoAndAddress.AddTrialContactInfoAndAddressUIRequest;
import onevz.soe.cart.model.salesOrderAdjustment.SalesOrderAdjustmentOrderDetails;
import onevz.soe.cart.requests.ESimDetailsETNIRequest;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.responses.MyOfferETRRedisData;
import onevz.soe.cart.responses.RemoveOfferRedisData;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.util.CartPegaRequestErrorsUtil;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(CartPegaRequestErrorsUtil.class)
public class CartPegaRequestErrorsUtilTest {

	@Autowired
	private ObjectMapper mapper;
	
	@MockBean
	CartPegaRequestErrorsUtil util;
	
	@Test
	public void handleDeviceIdValidationRequestLineErrorTest() throws IOException {
		String sampleUIRequestString = "{}";
		DeviceIdValidationUIRequest UIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIRequest.class);
		CartPegaRequestErrorsUtil.handleDeviceIdValidationRequestErrors(UIRequest);
		StepVerifier.create(Mono.just(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleDeviceIdValidationRequestLineErrorTest2() throws IOException {
		String sampleUIRequestString = "{\"data\": {\"lines\": [{}]},\"cartInfo\": {}}";
		DeviceIdValidationUIRequest UIRequest = mapper.readValue(sampleUIRequestString, DeviceIdValidationUIRequest.class);
		CartPegaRequestErrorsUtil.handleDeviceIdValidationRequestErrors(UIRequest);
		StepVerifier.create(Mono.just(UIRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleUpdateWFMInfoRequestErrorsTest() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\": {}}";
		UpdateWFMInfoUIRequest request = mapper.readValue(sampleUIRequestString, UpdateWFMInfoUIRequest.class);
		CartPegaRequestErrorsUtil.handleUpdateWFMInfoRequestErrors(request);
		StepVerifier.create(Mono.just(request)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleAddDeviceRequestErrorsTest() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"channelId\": \"OMNI-TELESALES\",\"data\": {\"lines\": [{\"depletionType\": \"L\",\"ispuFlow\": true},{\"depletionType\": \"L\",\"ispuFlow\": false},{\"depletionType\": \"D\"}]},\"cartInfo\": {\"processStep\": \"E911\",\"intendType\": \"BYOD\"}}";
		AddDeviceUIRequest request = mapper.readValue(sampleUIRequestString, AddDeviceUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDeviceRequestErrorsPrepayTest() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"channelId\": \"OMNI-TELESALES\",\"data\": {\"lines\": [{\"depletionType\": \"L\",\"ispuFlow\": true},{\"depletionType\": \"L\",\"ispuFlow\": false},{\"depletionType\": \"D\"}]},\"cartInfo\": {\"processStep\": \"E911\",\"intendType\": \"BYOD\"}}";
		AddDeviceUIRequest request = mapper.readValue(sampleUIRequestString, AddDeviceUIRequest.class);
		request.getCartInfo().setIsPrepayCart("Y");
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDeviceRequestErrorsPrepayFalseTest() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"channelId\": \"OMNI-TELESALES\",\"data\": {\"lines\": [{\"depletionType\": \"L\",\"ispuFlow\": true},{\"depletionType\": \"L\",\"ispuFlow\": false},{\"depletionType\": \"D\"}]},\"cartInfo\": {\"processStep\": \"E911\",\"intendType\": \"BYOD\"}}";
		AddDeviceUIRequest request = mapper.readValue(sampleUIRequestString, AddDeviceUIRequest.class);
		request.getCartInfo().setIsPrepayCart("N");
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDeviceRequestErrorsTest2() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"channelId\": \"OMNI-TELESALES\",\"data\": {\"lines\": [{\"depletionType\": \"L\",\"ispuFlow\": true},{\"depletionType\": \"L\",\"ispuFlow\": false},{\"depletionType\": \"D\"}]},\"cartInfo\": {\"processStep\": \"step\",\"intendType\": \"\"}}";
		AddDeviceUIRequest request = mapper.readValue(sampleUIRequestString, AddDeviceUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleAddDeviceRequestErrorsTest3() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"channelId\": \"OMNI-TELESALES\",\"data\": {\"lines\": [{\"depletionType\": \"L\",\"ispuFlow\": true},{\"depletionType\": \"L\",\"ispuFlow\": false},{\"depletionType\": \"D\"}]},\"cartInfo\": {\"caseId\": \"case\",\"processStep\": \"step\",\"intendType\": \"\"}}";
		AddDeviceUIRequest request = mapper.readValue(sampleUIRequestString, AddDeviceUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleAddDeviceRequestErrorsTest4() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"channelId\": \"OMNI-TELESALES\",\"data\": {\"lines\": [{\"depletionType\": \"L\",\"ispuFlow\": true},{\"depletionType\": \"L\",\"ispuFlow\": false},{\"depletionType\": \"D\"}]},\"cartInfo\": {\"cartId\": \"cart\",\"processStep\": \"step\",\"intendType\": \"\"}}";
		AddDeviceUIRequest request = mapper.readValue(sampleUIRequestString, AddDeviceUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleAddDeviceRequestErrorsTest5() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"channelId\": \"OMNI-TELESALES\",\"data\": {\"lines\": [{\"depletionType\": \"L\",\"ispuFlow\": true},{\"depletionType\": \"L\",\"ispuFlow\": false},{\"depletionType\": \"L\"},{\"depletionType\": \"D\"}]},\"cartInfo\": {\"caseId\": \"case\",\"cartId\": \"cart\",\"processStep\": \"step\",\"intendType\": \"AAL\"}}";
		AddDeviceUIRequest request = mapper.readValue(sampleUIRequestString, AddDeviceUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleClearAndContinueRequestErrorsTest() {
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleClearAndContinueRequestErrors("itemType");
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleClearAndContinueRequestErrorsTest2() {
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleClearAndContinueRequestErrors("device");
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleAddDeviceMtnFlowTest() {
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDeviceMtnFlow("G");
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleRemoveEdgeUpRequestErrorsTest() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"data\": {}}";
		UpdateEdgeupUIRequest request = mapper.readValue(sampleUIRequestString, UpdateEdgeupUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleRemoveEdgeUpRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleRemoveBvoOffersRequestErrorsTest() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"data\": {}}";
		UpdateBvoOffersUIRequest request = mapper.readValue(sampleUIRequestString, UpdateBvoOffersUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleRemoveBvoOffersRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleRemoveBvoOffersRequestErrorsTest2() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"data\": {\"lines\": [{},{\"removeOffers\": [{}]}]}}";
		UpdateBvoOffersUIRequest request = mapper.readValue(sampleUIRequestString, UpdateBvoOffersUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleRemoveBvoOffersRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleAddEdgeUpRequestErrorsTest() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"data\": {\"lines\": [{}]},\"cartInfo\":{}}";
		UpdateEdgeupUIRequest request = mapper.readValue(sampleUIRequestString, UpdateEdgeupUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddEdgeUpRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleUpsertRemoveOfferDataRequestErrorsTest() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"data\": {}}";
		RemoveOfferRedisData request = mapper.readValue(sampleUIRequestString, RemoveOfferRedisData.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleUpsertRemoveOfferDataRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleUpsertRemoveOfferDataRequestErrorsTest2() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"data\": {\"lines\": [{},{\"removeOffers\": [{}]}]}}";
		RemoveOfferRedisData request = mapper.readValue(sampleUIRequestString, RemoveOfferRedisData.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleUpsertRemoveOfferDataRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleUpdateSellerPriceRequestErrorsTest() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"data\": {\"lines\": [{}]}}";
		UpdateSellerPriceUIRequestNew request = mapper.readValue(sampleUIRequestString, UpdateSellerPriceUIRequestNew.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleUpdateSellerPriceRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleAddDownPaymentRequestErrorsTest() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"data\": {},\"cartInfo\": {\"intendType\": \"NSE\"}}";
		DownPaymentUIRequest request = mapper.readValue(sampleUIRequestString, DownPaymentUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDownPaymentRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleAddDownPaymentRequestErrorsTest2() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"data\": {},\"cartInfo\": {\"intendType\": \"NSEBYOD\"}}";
		DownPaymentUIRequest request = mapper.readValue(sampleUIRequestString, DownPaymentUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDownPaymentRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleBillingAddressRequestErrorsTest() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"data\": {\"lines\": [{\"billingAddress\": {}}]}}";
		BillingAddressUIRequest request = mapper.readValue(sampleUIRequestString, BillingAddressUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleBillingAddressRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleUpdatePurchaseOrderRequestErrorsTest() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{}";
		UpdatePurchaseOrderUIRequest request = mapper.readValue(sampleUIRequestString, UpdatePurchaseOrderUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleUpdatePurchaseOrderRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleUpdatePurchaseOrderRequestErrorsTest2() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartId\": \"cartId\",\"purchaseOrderNumber\": \"765\",\"intendType\": \"NSE\"}";
		UpdatePurchaseOrderUIRequest request = mapper.readValue(sampleUIRequestString, UpdatePurchaseOrderUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleUpdatePurchaseOrderRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleApplyMyOfferRequestErrorsTest() throws JsonMappingException, JsonProcessingException {
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleApplyMyOfferRequestErrors(new ApplyOfferRequest(), new MyOfferETRRedisData());
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleApplyMyOfferRequestErrorsTest2() throws JsonMappingException, JsonProcessingException {
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleApplyMyOfferRequestErrors(new ApplyOfferRequest(), new MyOfferETRRedisData());
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleApplyMyOfferRequestErrorsTest3() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"lines\": [{}]}";
		MyOfferETRRedisData data = mapper.readValue(sampleUIRequestString, MyOfferETRRedisData.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleApplyMyOfferRequestErrors(new ApplyOfferRequest(), data);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		data.setLines(null);
		CartPegaRequestErrorsUtil.handleApplyMyOfferRequestErrors(new ApplyOfferRequest(), data);

		CartPegaRequestErrorsUtil.handleApplyMyOfferRequestErrors(new ApplyOfferRequest(), null);
	}
	
	@Test
	public void handleAddTransferUpgradeRequestErrorsTest() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"data\": {\"lines\": [{}]}}";
		UpdateTransferUpgradeUIRequest request = mapper.readValue(sampleUIRequestString, UpdateTransferUpgradeUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddTransferUpgradeRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleRPSE911AddressUpdateRequestErrorsTest() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"lines\": [{}]}";
		RPSE911AddressUpdateUIRequest request = mapper.readValue(sampleUIRequestString, RPSE911AddressUpdateUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleRPSE911AddressUpdateRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleSalesOrderAdjustmentRequestErrorsTest() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\": {}}";
		SalesOrderAdjustmentUIRequest request = mapper.readValue(sampleUIRequestString, SalesOrderAdjustmentUIRequest.class);
		request.setRefundOrderdetails(new SalesOrderAdjustmentOrderDetails());
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleSalesOrderAdjustmentRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleSalesOrderAdjustmentRequestErrorsTest2() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\": {}}";
		SalesOrderAdjustmentUIRequest request = mapper.readValue(sampleUIRequestString, SalesOrderAdjustmentUIRequest.class);
		SalesOrderAdjustmentOrderDetails orderDetails = mapper.readValue("{\"lines\": {}}", SalesOrderAdjustmentOrderDetails.class);
		request.setRefundOrderdetails(orderDetails);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleSalesOrderAdjustmentRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleSalesOrderAdjustmentRequestErrorsTest3() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\": {}}";
		SalesOrderAdjustmentUIRequest request = mapper.readValue(sampleUIRequestString, SalesOrderAdjustmentUIRequest.class);
		SalesOrderAdjustmentOrderDetails orderDetails = mapper.readValue("{\"lines\": {\"lineInfo\": [{},{\"items\": [{}]}]}}", SalesOrderAdjustmentOrderDetails.class);
		request.setRefundOrderdetails(orderDetails);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleSalesOrderAdjustmentRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void validateCartIdAndCaseIdTest() throws JsonMappingException, JsonProcessingException {
		String cartInfoString = "{\"cartId\": \"cart\",\"caseId\": \"case\"}";
		DeviceCartInfo cartInfo = mapper.readValue(cartInfoString, DeviceCartInfo.class);
		List<CartError> errors = CartPegaRequestErrorsUtil.validateCartIdAndCaseId(cartInfo);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		cartInfo.setCartId("random");
		cartInfo.setCaseId("random");
		CartPegaRequestErrorsUtil.validateCartIdAndCaseId(cartInfo);

		cartInfo.setCartId(null);
		cartInfo.setCaseId(null);
		CartPegaRequestErrorsUtil.validateCartIdAndCaseId(cartInfo);
	}
	
	@Test
	public void handleAddReplenishmenttoCartRequestErrorsTest() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"data\": {}}";
		AddReplenishmentToCartUIRequest request = mapper.readValue(sampleUIRequestString, AddReplenishmentToCartUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddReplenishmenttoCartRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleAddReplenishmenttoCartRequestErrorsTest2() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"data\": {\"lines\": [{}]}}";
		AddReplenishmentToCartUIRequest request = mapper.readValue(sampleUIRequestString, AddReplenishmentToCartUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddReplenishmenttoCartRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleEsimDetailsRequestValidationTest() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"data\": {}}";
		ESimDetailsETNIRequest request = mapper.readValue(sampleUIRequestString, ESimDetailsETNIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleEsimDetailsRequestValidation(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		request.setEid("null");
		CartPegaRequestErrorsUtil.handleEsimDetailsRequestValidation(request);
	}

	@Test
	public void handleEsimDetailsRequestValidationTest2() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"eid\": \"12345678901234567890123456789012\"}";
		ESimDetailsETNIRequest request = mapper.readValue(sampleUIRequestString, ESimDetailsETNIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleEsimDetailsRequestValidation(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void indirectCustRequestErrorsTest() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"context\": {\"customerInfo\": {\"processingMTN\": \"mtn\"},\"cartInfo\": {},\"contextInfo\": {}}}";
		ExCustIndirectRemoveLinesServiceUIRequest request = mapper.readValue(sampleUIRequestString, ExCustIndirectRemoveLinesServiceUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.indirectCustRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		request.getContext().getCustomerInfo().setProcessingMTN("random");
		request.getContext().getCartInfo().setIntendType("random");
		CartPegaRequestErrorsUtil.indirectCustRequestErrors(request);

		request.getContext().getCustomerInfo().setProcessingMTN("");
		request.getContext().getCartInfo().setIntendType(CartConstants.NSE);
		CartPegaRequestErrorsUtil.indirectCustRequestErrors(request);
	}
	
	@Test
	public void handleCheckExistingCartRequestErrorsTest() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\": {}}";
		AccessoryFinancingOffersUIRequest request = mapper.readValue(sampleUIRequestString, AccessoryFinancingOffersUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleCheckExistingCartRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleAddTrialContactInfoAndAddressRequestErrorsTest() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"data\": {}}";
		AddTrialContactInfoAndAddressUIRequest request = mapper.readValue(sampleUIRequestString, AddTrialContactInfoAndAddressUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddTrialContactInfoAndAddressRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleCheckExistingCartRequestErrorsTest2() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\": {}}";
		CheckExistingCartUIRequest request = mapper.readValue(sampleUIRequestString, CheckExistingCartUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleCheckExistingCartRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleGuestChoiceRequestErrorsTest() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\": {}}";
		GuestChoiceUIRequest request = mapper.readValue(sampleUIRequestString, GuestChoiceUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleGuestChoiceRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleManualDiscountRequestErrorsTest() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"data\": {},\"cartInfo\": {}}";
		UpdateManualDiscountUIRequest request = mapper.readValue(sampleUIRequestString, UpdateManualDiscountUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleManualDiscountRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleManualDiscountRequestErrorsTest2() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"data\": {\"lines\": [{},{\"manualDiscount\": [{}]}]},\"cartInfo\": {\"action\": \"ADD\"}}";
		UpdateManualDiscountUIRequest request = mapper.readValue(sampleUIRequestString, UpdateManualDiscountUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleManualDiscountRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void validateIntentType5GTest() throws JsonMappingException, JsonProcessingException {
		String cartInfoString = "{\"cartId\": \"cart\",\"caseId\": \"case\"}";
		AddPlanDeviceCartInfo cartInfo = mapper.readValue(cartInfoString, AddPlanDeviceCartInfo.class);
		List<CartError> errors = CartPegaRequestErrorsUtil.validateIntentType5G(cartInfo);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void validateIntentType5GTest2() throws JsonMappingException, JsonProcessingException {
		String cartInfoString = "{\"intendType\": \"NSE\",\"caseId\": \"case\"}";
		AddPlanDeviceCartInfo cartInfo = mapper.readValue(cartInfoString, AddPlanDeviceCartInfo.class);
		List<CartError> errors = CartPegaRequestErrorsUtil.validateIntentType5G(cartInfo);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void validateProcessMtnCartCreator5GTest() throws JsonMappingException, JsonProcessingException {
		String cartInfoString = "{\"cartCreator\": \"cart\",\"caseId\": \"case\"}";
		AddPlanDeviceCartInfo cartInfo = mapper.readValue(cartInfoString, AddPlanDeviceCartInfo.class);
		List<CartError> errors = CartPegaRequestErrorsUtil.validateProcessMtnCartCreator5G(cartInfo);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		cartInfo.setCartCreator("random");
		cartInfo.setProcessingMTN("random");
		CartPegaRequestErrorsUtil.validateProcessMtnCartCreator5G(cartInfo);
	}
	
	@Test
	public void validateCartIdAndCaseId5GTest() throws JsonMappingException, JsonProcessingException {
		String cartInfoString = "{\"cartId\": \"cart\",\"caseId\": \"case\"}";
		AddPlanDeviceCartInfo cartInfo = mapper.readValue(cartInfoString, AddPlanDeviceCartInfo.class);
		List<CartError> errors = CartPegaRequestErrorsUtil.validateCartIdAndCaseId5G(cartInfo);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleRPSApplePayloadUIRequestErrorsTest() throws JsonMappingException, JsonProcessingException {
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleRPSApplePayloadUIRequestErrors(null, "");
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

//		RPSApplePayloadUIRequest RPSApplePayloadUIRequestObj = new RPSApplePayloadUIRequest();
//		RPSApplePayloadUIRequestObj.setSecondaryDeviceActive(null);
//		CartPegaRequestErrorsUtil.handleRPSApplePayloadUIRequestErrors(RPSApplePayloadUIRequestObj, "");
	}
	
	@Test
	public void handleRPSApplePayloadUIRequestErrorsTest2() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"secondaryDeviceActive\": {}}";
		RPSApplePayloadUIRequest request = mapper.readValue(sampleUIRequestString, RPSApplePayloadUIRequest.class);
		request.setSecondaryDeviceActive(new SecondaryDeviceActive());
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleRPSApplePayloadUIRequestErrors(request, "");
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleRPSReleasePendingOrderRequestErrorsTest() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"secondaryDeviceActive\": {}}";
		RPSReleasePendingOrderUIRequest request = mapper.readValue(sampleUIRequestString, RPSReleasePendingOrderUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleRPSReleasePendingOrderRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleRPSReleasePendingOrderRequestErrorsTest2() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"lineItemInfoList\": [{\"orderNumber\": \"567\"}]}";
		RPSReleasePendingOrderUIRequest request = mapper.readValue(sampleUIRequestString, RPSReleasePendingOrderUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleRPSReleasePendingOrderRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleAddFeaturesRequestErrorsTest() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\": {},\"data\": {\"account\": {}}}";
		AddFeaturesUIRequest request = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddFeaturesRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleAddFeaturesRequestErrorsTest2() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\": {},\"data\": {\"lines\": [{},{\"mcsSubscription\": {\"remove\": [{}]}},{\"feature\": {}}],\"account\": {\"mcsSubscription\": {\"remove\": [{}]}}}}";
		AddFeaturesUIRequest request = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddFeaturesRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void handleAddFeaturesRequestErrorsTest3() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\": {},\"data\": {\"lines\": [{},{\"mcsSubscription\": {\"remove\": [{}]}},{\"features\": {}}],\"account\": {\"features\": {}}}}";
		AddFeaturesUIRequest request = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddFeaturesRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

//		Arrays.stream(request.getData().getLines()).forEach(line -> {
//			line.getMcsSubscription().setAdd(Arrays.asList(new McsSubscription()));
//			line.getMcsSubscription().getAdd().forEach(sub -> sub = null);
//		});
//		CartPegaRequestErrorsUtil.handleAddFeaturesRequestErrors(request);

		request.getData().getLines()[0].setFeatures(new FeatureAction());
		request.getData().getLines()[0].getFeatures().setAdd(Arrays.asList(new Feature()));
		request.getData().getLines()[0].getFeatures().getAdd().get(0).setId("");
		CartPegaRequestErrorsUtil.handleAddFeaturesRequestErrors(request);

		request.getData().getLines()[0].getFeatures().getAdd().stream().forEach(add -> add = null);
		CartPegaRequestErrorsUtil.handleAddFeaturesRequestErrors(request);
	}

    //test both itemId and catId are missing
	@Test
	public void handleAddFeaturesRequestErrorsTest4() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\":{\"cartCreator\":\"5135320416\",\"intendType\":\"EUP\",\"creditAppNum\":\"5135320416\",\"processStep\":\"FeaturesPDP\"},\"data\":{\"isSubscription\":true,\"lines\":[{\"mtn\":\"5135320416\",\"mcsSubscription\":{\"add\":[{\"name\":\"Identity Secure - Line\",\"actionIndicator\":\"A\",\"description\":\"INSTALLATION SERVICES\",\"pricePlanId\":\"35550962\",\"price\":5}]}}]}}";
		AddFeaturesUIRequest request = mapper.readValue(sampleUIRequestString, AddFeaturesUIRequest.class);
        ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddFeaturesRequestErrors(request);
        StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }
	
	@Test
	public void handleAddAccessoriesRequestErrorsTest() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\": {\"subscriptionType\": \"GAMINGCONSOLE\"},\"data\": {\"depletionType\": \"L\",\"lines\": [{\"addAccessories\": [{}]},{\"ispuFlow\": true,\"addAccessories\": [{}]},{},{\"ispuFlow\": false,\"addAccessories\": [{},{\"serialNumber\": \"456\"}]},{\"ispuFlow\": true,\"removeAccessories\": [{}]},{\"ispuFlow\": true,\"depletionLocationCode\": \"loc\"}]},\"channelId\": \"OMNI-TELESALES\"}";
		AddAccessoriesUIRequest request = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddAccessoriesRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		request.getData().setZipCode("#we23^&*#");
		errors = CartPegaRequestErrorsUtil.handleAddAccessoriesRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
    @Test
	public void handleAddAccessoriesRequestErrorsTestPrepay() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\": {\"caseId\": \"case\",\"subscriptionType\": \"GAMINGCONSOLE\"},\"data\": {\"depletionType\": \"L\",\"lines\": [{\"addAccessories\": [{}]},{\"ispuFlow\": true,\"addAccessories\": [{}]},{},{\"ispuFlow\": false,\"addAccessories\": [{},{\"serialNumber\": \"456\"}]},{\"ispuFlow\": true,\"removeAccessories\": [{}]},{\"ispuFlow\": true,\"depletionLocationCode\": \"loc\"}]},\"channelId\": \"OMNI-TELESALES\"}";
		AddAccessoriesUIRequest request = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddAccessoriesRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}


	@Test
	public void handleAddAccessoriesRequestErrorsTestPrepayWithCaseID() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\": {\"caseId\": \"SOF-12333\",\"subscriptionType\": \"GAMINGCONSOLE\"},\"data\": {\"depletionType\": \"L\",\"lines\": [{\"addAccessories\": [{}]},{\"ispuFlow\": true,\"addAccessories\": [{}]},{},{\"ispuFlow\": false,\"addAccessories\": [{},{\"serialNumber\": \"456\"}]},{\"ispuFlow\": true,\"removeAccessories\": [{}]},{\"ispuFlow\": true,\"depletionLocationCode\": \"loc\"}]},\"channelId\": \"OMNI-TELESALES\"}";
		AddAccessoriesUIRequest request = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddAccessoriesRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	@Test
	public void handleAddAccessoriesRequestErrorsTest2() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\": {\"subscriptionType\": \"GAMINGCONSOLE\"},\"data\": {\"depletionType\": \"D\",\"lines\": [{},{\"ispuFlow\": false,\"addAccessories\": [{}]},{\"ispuFlow\": true,\"removeAccessories\": [{}]},{\"ispuFlow\": true,\"depletionLocationCode\": \"loc\"}]},\"channelId\": \"OMNI-TELESALES\"}";
		AddAccessoriesUIRequest request = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddAccessoriesRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		Arrays.stream(request.getData().getLines()).forEach(line -> {
			line.setAddAccessories(new Accessory[]{new Accessory()});
			Arrays.stream(line.getAddAccessories()).forEach(accessory -> {
				accessory.setId(CartConstants.TAX_SOFT_SKU);
				accessory.setQty("4");
			});
		});
		CartPegaRequestErrorsUtil.handleAddAccessoriesRequestErrors(request);
		Arrays.stream(request.getData().getLines()).forEach(line -> {
			line.setAddAccessories(new Accessory[]{new Accessory()});
			line.getAddAccessories()[0] = null;
		});
		CartPegaRequestErrorsUtil.handleAddAccessoriesRequestErrors(request);
	}
	
	@Test
	public void handleAddAccessoriesRequestErrorsTest3() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "";
		sampleUIRequestString = "{\"cartInfo\": {\"subscriptionType\": \"GAMINGCONSOLE\",\"intendType\": \"REX\"},\"data\": {\"depletionType\": \"L\",\"lines\": [{\"addAccessories\": [{}]},{\"ispuFlow\": true,\"addAccessories\": [{}]},{},{\"ispuFlow\": false,\"addAccessories\": [{},{\"serialNumber\": \"456\"}]},{\"ispuFlow\": true,\"removeAccessories\": [{}]},{\"ispuFlow\": true,\"depletionLocationCode\": \"loc\"}]},\"channelId\": \"OMNI-TELESALES\"}";
		AddAccessoriesUIRequest request = mapper.readValue(sampleUIRequestString, AddAccessoriesUIRequest.class);
		request.setChannelId("OMNI-RETAIL");
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddAccessoriesRequestErrors(request);
		
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	

	@Test
	public void handleUpsertRemoveOfferDataRequestErrorsTest3() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"lines\": [{},{\"removeOffers\": [{}]}]}";
		RemoveOfferRedisData request = mapper.readValue(sampleUIRequestString, RemoveOfferRedisData.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleUpsertRemoveOfferDataRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void emptyCaptchaErrorresponseTest() {
		Assert.assertNotNull( CartPegaRequestErrorsUtil.emptyCaptchaErrorresponse());
	}

	@Test
	public void validateProcessStepProcessAction5GTest() {
		AddPlanDeviceCartInfo cartInfo = new AddPlanDeviceCartInfo();
		cartInfo.setProcessAction(null);
		CartPegaRequestErrorsUtil.validateProcessStepProcessAction5G(cartInfo);

		cartInfo.setProcessStep("random");
		cartInfo.setProcessAction("random");
		CartPegaRequestErrorsUtil.validateProcessStepProcessAction5G(cartInfo);

	}

	@Test
	public void handleDeviceIdValidationRequestErrorsTest() {
		DeviceIdValidationUIRequest DeviceIdValidationUIRequestObj = new DeviceIdValidationUIRequest();
		DeviceIdValidationUIRequestObj.setCartInfo(new CartInfo());
		DeviceIdValidationUIRequestObj.getCartInfo().setIntendType(CartConstants.BYOD);
		DeviceIdValidationUIRequestObj.getCartInfo().setProcessStep("NSEBYODLanding");
		DeviceIdValidationUIRequestObj.setData(new DeviceIdValidationData());
		DeviceIdValidationLine DeviceIdValidationLineObj = new DeviceIdValidationLine();
		DeviceIdValidationLineObj.setDevice(new Device());
		DeviceIdValidationLineObj.getDevice().setIsCustomerProvidedEquipment(null);
		DeviceIdValidationLineObj.getDevice().setSmartIMEI(false);
		DeviceIdValidationLineObj.getDevice().setFlowtype(CartConstants.DEVICE);
		DeviceIdValidationLineObj.getDevice().setId("");
		DeviceIdValidationLineObj.getDevice().setToken("");
		DeviceIdValidationUIRequestObj.getData().setLines(Arrays.asList(DeviceIdValidationLineObj));
		CartPegaRequestErrorsUtil.handleDeviceIdValidationRequestErrors(DeviceIdValidationUIRequestObj);

		DeviceIdValidationUIRequestObj.getCartInfo().setProcessStep("random");
		DeviceIdValidationUIRequestObj.getData().setLines(Arrays.asList(DeviceIdValidationLineObj));
		CartPegaRequestErrorsUtil.handleDeviceIdValidationRequestErrors(DeviceIdValidationUIRequestObj);

		DeviceIdValidationLineObj.getDevice().setSmartIMEI(null);
		DeviceIdValidationLineObj.getDevice().setFlowtype(CartConstants.SIM);
		DeviceIdValidationLineObj.getDevice().setSim(new SoftSKUItem());
		DeviceIdValidationLineObj.getDevice().getSim().setId("");
		DeviceIdValidationUIRequestObj.getData().setLines(Arrays.asList(DeviceIdValidationLineObj));
		CartPegaRequestErrorsUtil.handleDeviceIdValidationRequestErrors(DeviceIdValidationUIRequestObj);

		DeviceIdValidationLineObj.getDevice().getSim().setId("random");
		DeviceIdValidationUIRequestObj.getData().setLines(Arrays.asList(DeviceIdValidationLineObj));
		CartPegaRequestErrorsUtil.handleDeviceIdValidationRequestErrors(DeviceIdValidationUIRequestObj);

		DeviceIdValidationLineObj.getDevice().setFlowtype(null);
		DeviceIdValidationLineObj.getDevice().getSim().setIsCustomerProvidedSIM(null);
		CartPegaRequestErrorsUtil.handleDeviceIdValidationRequestErrors(DeviceIdValidationUIRequestObj);
		DeviceIdValidationLineObj.getDevice().getSim().setIsCustomerProvidedSIM(true);
		DeviceIdValidationLineObj.getDevice().setIsCustomerProvidedEquipment(true);
		CartPegaRequestErrorsUtil.handleDeviceIdValidationRequestErrors(DeviceIdValidationUIRequestObj);
	}

	@Test
	public void handleAdd5GBulkOrderRequestErrorsTest() {
		Add5GBulkOrderUIRequest Add5GBulkOrderUIRequestObj = new Add5GBulkOrderUIRequest();
		Add5GBulkOrderUIRequestObj.setCartInfo(new CartInfo());
		Add5GBulkOrderUIRequestObj.getCartInfo().setProcessStep("random");
		Add5GBulkOrderUIRequestObj.getCartInfo().setIntendType(CartConstants.EUPBYOD);
		Add5GBulkOrderUIRequestObj.setData(new Add5GBulkOrderData());
		Add5GBulkOrderUIRequestObj.getData().setLines(Arrays.asList(new Lines()));
		Add5GBulkOrderUIRequestObj.getData().getLines().get(0).setIsEdgeBuyOut(null);
		Add5GBulkOrderUIRequestObj.getData().getLines().get(0).setEdgeup(null);
		Add5GBulkOrderUIRequestObj.getData().getLines().get(0).setDevice(null);
		Add5GBulkOrderUIRequestObj.getData().getLines().get(0).setSim(new SoftSKUItem());
		Add5GBulkOrderUIRequestObj.getData().getLines().get(0).getSim().setId("");
		CartPegaRequestErrorsUtil.handleAdd5GBulkOrderRequestErrors(Add5GBulkOrderUIRequestObj);

		Add5GBulkOrderUIRequestObj.getData().getLines().get(0).setDevice(new Device());
		Add5GBulkOrderUIRequestObj.getData().getLines().get(0).getDevice().setId("");
		Add5GBulkOrderUIRequestObj.getData().getLines().get(0).getDevice().setDeviceId("");
		CartPegaRequestErrorsUtil.handleAdd5GBulkOrderRequestErrors(Add5GBulkOrderUIRequestObj);

		//Add5GBulkOrderUIRequestObj.getCartInfo().setIntendType("");
		Add5GBulkOrderUIRequestObj.getData().getLines().get(0).getSim().setId("");
		CartPegaRequestErrorsUtil.handleAdd5GBulkOrderRequestErrors(Add5GBulkOrderUIRequestObj);

		Add5GBulkOrderUIRequestObj.getData().getLines().get(0).setEdgeup(new EdgeUp());
		Add5GBulkOrderUIRequestObj.getData().getLines().get(0).getEdgeup().setDeviceId("");
		CartPegaRequestErrorsUtil.handleAdd5GBulkOrderRequestErrors(Add5GBulkOrderUIRequestObj);
	}

	@Test
	public void handleAccountPinRequestErrorsTest() {
		AccountPinUIRequest AccountPinUIRequestObj = new AccountPinUIRequest();
		AccountPinUIRequestObj.setCartInfo(new CartInfo());
		AccountPinUIRequestObj.getCartInfo().setAccountPin("random");
		CartPegaRequestErrorsUtil.handleAccountPinRequestErrors(AccountPinUIRequestObj);

		AccountPinUIRequestObj.getCartInfo().setAccountPin("");
		CartPegaRequestErrorsUtil.handleAccountPinRequestErrors(AccountPinUIRequestObj);

		AccountPinUIRequestObj.setCartInfo(null);
		CartPegaRequestErrorsUtil.handleAccountPinRequestErrors(AccountPinUIRequestObj);
	}

	@Test
	public void handleDeviceSimIdErrorsTest() {
		CartPegaRequestErrorsUtil.handleDeviceSimIdErrors();

		UpdateTransferUpgradeUIRequest UpdateTransferUpgradeUIRequestObj = new UpdateTransferUpgradeUIRequest();
		UpdateTransferUpgradeUIRequestObj.setData(new UpdateTransferUpgradeData());
		UpdateTransferUpgradeUIRequestObj.getData().setLines(Arrays.asList(new Lines()));
		UpdateTransferUpgradeUIRequestObj.getData().getLines().get(0).setMtn("@#$%%!)");
		CartPegaRequestErrorsUtil.handleRemoveTransferUpgradeRequestErrors(UpdateTransferUpgradeUIRequestObj);
	}
	
	//	xbox exchange
	@Test
	public void xboxExchangeNotAllowedForRetailErrorTest() {
		CartErrorDetail errors = CartPegaRequestErrorsUtil.xboxExchangeNotAllowedForRetailError("GAMINGCONSOLE");
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void handleAddDeviceRequestErrorsProductIdTest() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"channelId\":\"VZW-DOTCOM\",\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"noPendingOfferExists\":false,\"isPromoPDP\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"30004\"},\"data\":{\"lines\":[{\"isCommonPDP\":false,\"mtn\":\"\",\"purchasePath\":\"NSE\",\"eupNoPromoFlow\":false,\"device\":{\"id\":\"MWGF2LL/A\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":36,\"productId\":\"jhh*@jkg56\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBDSIMTRI\"},\"ispuFlow\":false,\"estimatedReadyByDate\":\"\",\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false,\"selectedSedOfferId\":\"\"}],\"rtm\":{\"url\":\"https://vzwqa2.verizonwireless.com/smartphones/apple-iphone-11-pro-max/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/iphone-11-pro-max-space-gray?fmt=webp\",\"name\":\"iPhone 11 Pro Max\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://vzwqa2.verizonwireless.com/smartphones/apple-iphone-11-pro-max/\"}}}";
		AddDeviceUIRequest request = mapper.readValue(sampleUIRequestString, AddDeviceUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(request);
		Assert.assertFalse(errors.getErrors().isEmpty());
	}

	@Test
	public void handleAssignMtnRequestErrorsTest() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\":{\"intendType\":\"NSE\",\"processingMTN\":\"newLine1\",\"processStep\":\"AssignNumbers\",\"processAction\":\"AssignNumbers\",\"customerType\":\"N\"},\"data\":{\"lines\":[{\"mtn\":\"newLine1\",\"npaNxx\":\"123(*&496\",\"accountOwner\":\"Y\"}]}}";
		AssignMtnUIRequest request = mapper.readValue(sampleUIRequestString, AssignMtnUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAssignMtnRequestErrors(request);
		Assert.assertFalse(errors.getErrors().isEmpty());
	}

	@Test
	public void handleAddDeviceRequestErrorsProductId2Test() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"channelId\":\"VZW-DOTCOM\",\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"noPendingOfferExists\":false,\"isPromoPDP\":false,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"30004\"},\"data\":{\"lines\":[{\"isCommonPDP\":false,\"mtn\":\"\",\"purchasePath\":\"NSE\",\"eupNoPromoFlow\":false,\"device\":{\"id\":\"MWGF2LL/A\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":false,\"dppMonths\":36,\"productId\":\"jhhjkg56\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBDSIMTRI\"},\"ispuFlow\":false,\"estimatedReadyByDate\":\"\",\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":false,\"selectedSedOfferId\":\"\"}],\"rtm\":{\"url\":\"https://vzwqa2.verizonwireless.com/smartphones/apple-iphone-11-pro-max/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/iphone-11-pro-max-space-gray?fmt=webp\",\"name\":\"iPhone 11 Pro Max\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://vzwqa2.verizonwireless.com/smartphones/apple-iphone-11-pro-max/\"}}}";
		AddDeviceUIRequest request = mapper.readValue(sampleUIRequestString, AddDeviceUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(request);
		Assert.assertNull(errors.getErrors());
	}

	@Test
	public void handleAssignMtnRequestError2Test() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\":{\"intendType\":\"NSE\",\"processingMTN\":\"newLine1\",\"processStep\":\"AssignNumbers\",\"processAction\":\"AssignNumbers\",\"customerType\":\"N\"},\"data\":{\"lines\":[{\"mtn\":\"newLine1\",\"npaNxx\":\"123496\",\"accountOwner\":\"Y\"}]}}";
		AssignMtnUIRequest request = mapper.readValue(sampleUIRequestString, AssignMtnUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAssignMtnRequestErrors(request);
		Assert.assertNull(errors.getErrors());
	}

	@Test
	public void handleAddDeviceRequestErrorsDigitalTest() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"SecondNumberPage\",\"processAction\":\"addDeviceSim\",\"intendType\":\"BYOD\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"isNewLine\":true,\"ispuFlow\":false,\"depletionType\":\"F\",\"depletionLocationCode\":\"\",\"isKeepingExistingEqProtection\":true,\"secondNumber\":{\"isSecondNumber\":true,\"primaryMtn\":\"2677887898\",\"secondMtn\":\"\"}}]}}";
		AddDeviceUIRequest request = mapper.readValue(sampleUIRequestString, AddDeviceUIRequest.class);
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(request);
		Assert.assertNull(errors.getErrors());
		request.getData().getLines().get(0).getSecondNumber().setIsSecondNumber(false);
		errors = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(request);
		Assert.assertNotNull(errors.getErrors());
		request.getData().getLines().get(0).getSecondNumber().setIsSecondNumber(null);
		errors = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(request);
		Assert.assertNotNull(errors.getErrors());
		request.getData().getLines().get(0).setSecondNumber(null);
		errors = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(request);
		Assert.assertNotNull(errors.getErrors());
	}

	@Test
	public void handleAddDeviceProcessMtnErrorsTest() throws JsonMappingException, JsonProcessingException {
		String sampleUIRequestString = "{\"channelId\": \"OMNI-TELESALES\",\"data\": {\"lines\": [{\"depletionType\": \"L\",\"ispuFlow\": true},{\"depletionType\": \"L\",\"ispuFlow\": false},{\"depletionType\": \"D\"}]},\"cartInfo\": {\"processStep\": \"E911\",\"intendType\": \"BYOD\"}}";
		AddDeviceUIRequest request = mapper.readValue(sampleUIRequestString, AddDeviceUIRequest.class);
		request.getCartInfo().setProcessingMTN("#$#$#%$#^#$@@");
		ErrorResponse errors = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		request.getCartInfo().setProcessingMTN("");
		errors = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		request.getCartInfo().setProcessingMTN(null);
		errors = CartPegaRequestErrorsUtil.handleAddDeviceRequestErrors(request);
		StepVerifier.create(Mono.just(errors)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

	}
}
