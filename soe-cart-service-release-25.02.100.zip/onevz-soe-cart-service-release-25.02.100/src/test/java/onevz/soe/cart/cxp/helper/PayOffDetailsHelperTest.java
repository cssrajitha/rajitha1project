package onevz.soe.cart.cxp.helper;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.bpm.service.CartServiceBPMServices;
import onevz.soe.cart.cxp.helper.PayOffDetailsHelper;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.responses.AddPayOffDetailsPEGAResponse;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.AddPayOffDetailsUIRequest;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.io.IOException;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { CartServiceTestConfig.class })
public class PayOffDetailsHelperTest {

    @MockBean
    private RedisHelper redisHelper;
    @Autowired
    private ObjectMapper mapper;
    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;
    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;

    @Autowired
    private PayOffDetailsHelper payOffDetailsHelper;

    @MockBean
    private CartServiceBPMServices services;
    @Test
    public void getAddPayOffDetailsTest()  throws IOException, SOEHTTPException {

        HttpHeaders headers = new HttpHeaders();
        headers.add("channelId", "VZW-DOTCOM");
        String requestFile = "data/addPayOffDetails/SOE-addPayOffDetails-Request.json";
        String pegaRes = "data/addPayOffDetails/addPayDetailsPegaRes.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String pegaResString = sourceFileReaderUtil.readFile(pegaRes, testFileLocation);
        AddPayOffDetailsUIRequest request = mapper.readValue(requestString, AddPayOffDetailsUIRequest.class);
        AddPayOffDetailsPEGAResponse pegaResponse = mapper.readValue(pegaResString, AddPayOffDetailsPEGAResponse.class);


        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(services.addPayOffDetails(any())).thenReturn(Mono.just(pegaResponse));
        StepVerifier.create(payOffDetailsHelper.getAddPayOffDetails(headers, request)).assertNext(res -> Assert.assertNotNull(res)).verifyComplete();

        // pega call error
        when(services.addPayOffDetails(any())).thenThrow(new SOEHTTPException(100, "ERROR"));
        StepVerifier.create(payOffDetailsHelper.getAddPayOffDetails(headers, request)).assertNext(res -> Assert.assertNotNull(res)).verifyComplete();
    }

    @Test
    public void getAddPayOffDetailsTest1()  throws IOException, SOEHTTPException {

        HttpHeaders headers = new HttpHeaders();
        headers.add("channelId", "VZW-DOTCOM");
        String requestFile = "data/addPayOffDetails/SOE-addPayOffDetails-Request.json";
        String pegaRes = "data/addPayOffDetails/addPayDetailsPegaRes.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String pegaResString = sourceFileReaderUtil.readFile(pegaRes, testFileLocation);
        AddPayOffDetailsUIRequest request = mapper.readValue(requestString, AddPayOffDetailsUIRequest.class);
        AddPayOffDetailsPEGAResponse pegaResponse = mapper.readValue(pegaResString, AddPayOffDetailsPEGAResponse.class);


        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";

        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        // channel id null, with intendType in redis, no mtn in lines from input request
        headers.remove("");
        sampleRedisData.setIntendType("TST");
        sampleRedisData.setCustomerType("D");
        sampleRedisData.setAccountNumber("");
        sampleRedisData.setCreditAppNum("TST");
        sampleRedisData.setMtnFlow("F");
        request.getCartInfo().setIntendType("TST");
        for(Lines line : request.getData().getLines()) {
            line.setMtn("");
        }

        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(services.addPayOffDetails(any())).thenReturn(Mono.just(pegaResponse));
        StepVerifier.create(payOffDetailsHelper.getAddPayOffDetails(headers, request)).assertNext(res -> Assert.assertNotNull(res)).verifyComplete();

    }

    @Test
    public void getAddPayOffDetailsTest2()  throws IOException, SOEHTTPException {

        HttpHeaders headers = new HttpHeaders();
        headers.add("channelId", "VZW-DOTCOM");
        String requestFile = "data/addPayOffDetails/SOE-addPayOffDetails-Request.json";
        String pegaRes = "data/addPayOffDetails/addPayDetailsPegaRes.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String pegaResString = sourceFileReaderUtil.readFile(pegaRes, testFileLocation);
        AddPayOffDetailsUIRequest request = mapper.readValue(requestString, AddPayOffDetailsUIRequest.class);
        AddPayOffDetailsPEGAResponse pegaResponse = mapper.readValue(pegaResString, AddPayOffDetailsPEGAResponse.class);


        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";

        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        // channel id null, with intendType in redis, no mtn in lines from input request
        headers.remove("");
        sampleRedisData.setIntendType("AAL");
        sampleRedisData.setCustomerType("D");
        sampleRedisData.setAccountNumber("");
        sampleRedisData.setCreditAppNum("TST");
        sampleRedisData.setMtnFlow("F");
        request.getCartInfo().setIntendType("TST");
        for(Lines line : request.getData().getLines()) {
            line.setMtn("");
        }

        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(services.addPayOffDetails(any())).thenReturn(Mono.just(pegaResponse));
        StepVerifier.create(payOffDetailsHelper.getAddPayOffDetails(headers, request)).assertNext(res -> Assert.assertNotNull(res)).verifyComplete();

    }

    @Test
    public void getAddPayOffDetailsTestNullLines()  throws IOException, SOEHTTPException {

        HttpHeaders headers = new HttpHeaders();
        String requestFile = "data/addPayOffDetails/SOE-addPayOffDetails-Request.json";
        String pegaRes = "data/addPayOffDetails/addPayDetailsPegaRes.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String pegaResString = sourceFileReaderUtil.readFile(pegaRes, testFileLocation);
        AddPayOffDetailsUIRequest request = mapper.readValue(requestString, AddPayOffDetailsUIRequest.class);
        AddPayOffDetailsPEGAResponse pegaResponse = mapper.readValue(pegaResString, AddPayOffDetailsPEGAResponse.class);


        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";

        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        // channel id null, with intendType in redis, no mtn in lines from input request
        sampleRedisData.setIntendType("TST");
        sampleRedisData.setCustomerType("D");
        sampleRedisData.setAccountNumber("");
        sampleRedisData.setCreditAppNum("TST");
        sampleRedisData.setMtnFlow("F");
        sampleRedisData.setCartCreator(null);
        request.getCartInfo().setIntendType("TST");
        request.getData().setLines(null);
        request.getCartInfo().setProcessStep(null);
        request.getCartInfo().setProcessAction(null);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(services.addPayOffDetails(any())).thenReturn(Mono.just(pegaResponse));
        StepVerifier.create(payOffDetailsHelper.getAddPayOffDetails(headers, request)).assertNext(res -> Assert.assertNotNull(res)).verifyComplete();

    }

}
