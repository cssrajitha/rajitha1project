//package onevz.soe.cart.service.test.cases;
//
//import com.fasterxml.jackson.databind.ObjectMapper;
//import junit.framework.Assert;
//import onevz.soe.cart.controller.FiveGCartDetailsController;
//import onevz.soe.cart.helper.FiveGHomeHelper;
//import onevz.soe.cart.helper.RedisHelper;
//import onevz.soe.cart.helper.UpdateCartHelper;
//import onevz.soe.cart.requests.GetCartDetailsRequest;
//import onevz.soe.cart.responses.GenericResponse;
//import onevz.soe.cart.responses.GetCartDetailsUIResponse;
//import onevz.soe.cart.service.test.config.CartServiceTestConfig;
//import onevz.soe.omnidl.util.DLUtilityService;
//import onevz.soe.security.TokenProcessor;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.mockito.Mockito;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.http.HttpMethod;
//import org.springframework.http.ResponseEntity;
//import org.springframework.http.server.reactive.ServerHttpResponse;
//import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//import reactor.core.publisher.Mono;
//import reactor.test.StepVerifier;
//
//import java.io.IOException;
//import java.net.URI;
//
//import static org.mockito.Mockito.when;
//
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(classes = { CartServiceTestConfig.class })
//@WebFluxTest(FiveGCartDetailsController.class)
//public class FiveGCartDetailsControllerTest {
//
//	@MockBean
//	private FiveGHomeHelper readCartHelper;
//
//	@Autowired
//	private FiveGCartDetailsController cartController;
//

//
//	@Autowired
//	private ObjectMapper mapper;
//
//	@MockBean
//	private RedisHelper redisHelper;
//
//	@Test
//	public void retrieveCartTest() throws IOException {
//		String requestString = "{\"meta\":{\"user\":\"spandsu\",\"client\":\"VZW-DOTCOM\"},\"data\":{\"cartId\":\"55d59c3e-26aa-4b1f-9996-525737615858\"}}";
//		String responseString = "{\"data\":{\"cart\":{\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"cartHeader\":{\"sourceSystem\":\"CXP\",\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"fullAccountNumber\":\"0225597159-1\",\"userId\":\"kumasa1\",\"customFit\":false,\"status\":\"A\",\"lastAccessSystem\":\"CXP\",\"createTimestamp\":\"2019-11-20T11:09:41.549Z\",\"lastUpdateTimestamp\":\"2019-11-20T11:09:41.549Z\",\"cartCreator\":\"4434541510\",\"cartCreatorOrderLocationCode\":\"E248201\",\"cartCreatorSalesRepId\":\"ENC\",\"creditApplicationNum\":\"388936130\",\"secondaryCreditApplicationNum\":0},\"orderDetails\":{\"orderType\":\"PS\",\"locationCode\":\"E248201\",\"customerType\":\"U\",\"billingSystem\":\"CXP\",\"linkApplicationNum\":0,\"prepayApplicationNum\":0,\"totalTaxAmount\":\"38.75\",\"spocs\":{\"notificationOptions\":{\"contactPhoneNumber\":\"1196120299\",\"primaryEmailId\":\"YFOOWLTH659034@VZW.COM\"}},\"totalDueToday\":538.74,\"totalDueMonthly\":0.0,\"subTotalDueMonthly\":0.0,\"subTotalMonthlyTaxes\":0.0,\"subTotalOtherLines\":0.0,\"subTotalOtherLinesTaxes\":0.0,\"instantDRCCredit\":false,\"managerApprovalRequired\":false,\"isAttachmentCompleted\":false,\"nextMonthBillTotal\":0.0,\"barCodes\":[],\"instantCreditAmount\":0.0,\"instantCreditAmountRemaining\":0.0,\"instantCreditEligible\":false,\"orderList\":[{\"creditApplication\":{\"creditApplicationNum\":388936130,\"creditApprovalStatus\":\"AP\",\"creditStatusReason\":\"CACVASAUTOMATICAPPROVAL\",\"internationalEligibility\":\"true\",\"creditAdvisory\":\"APP388936130APPROVED-WITHNODEPOSITREQUIRED'B'\",\"securityDepositAmount\":\"0\",\"serviceClass\":\"B\",\"lineCreditClass\":\"\"},\"orderActivityType\":\"EUP\",\"orderNumber\":\"1112\"}],\"orderNumber\":0,\"outletId\":\"124632\",\"registerNumber\":0,\"saleType\":\"P\",\"salesRepId\":\"ENC\",\"totalInstantCreditAmount\":0.0,\"totalInstantCreditAmountUsed\":0.0},\"lineDetails\":{\"lineInfo\":[{\"multiLineSeqNumber\":1,\"lineActivityType\":\"EUP\",\"totalDueToday\":538.74,\"totalDueTodayWithoutTax\":499.99,\"totalDueMonthly\":0.0,\"mobileNumber\":\"4434541510\",\"serviceInfo\":{\"mldTrunkMTN\":0,\"primaryUserInfo\":{\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\",\"zipCode4\":\"7848\"},\"isValidAddress\":true},\"mtn\":\"4434541510\",\"min\":\"4439349260\",\"oldPricePlanId\":\"17991\",\"currentDevice\":{\"oldLteVoraEquipInfo\":{\"iccid\":\"89148000004671963398\",\"lteVoraDeviceInfo\":{\"deviceId\":\"352530085081859\",\"deviceType\":\"4GE\"}}},\"isSharePlanAdded\":false,\"edgeLine\":false,\"vlcLine\":false,\"isE911AddressValidated\":false,\"oldPlanFlag\":\"L\",\"orderDevice\":{\"lteVoraEquipInfo\":{\"lteEqpt\":{},\"lteVoraDeviceInfo\":{}}}},\"itemsInfo\":[{\"depletionType\":\"L\",\"attention\":\"KENNYBONDS\",\"shipping\":{\"address\":{\"streetNum\":\"719CHESSIECROSSINGWAY\",\"streetName\":\"\",\"city\":\"WOODBINE\",\"state\":\"MD\",\"zipCode\":\"21797\"},\"shippingCost\":\"0.0\",\"firstName\":\"KENNY\",\"lastName\":\"BONDS\",\"isUseUnVerifiedAddress\":false,\"isValidAddress\":false},\"itemCount\":1,\"itemTabSeqNum\":0,\"cartItems\":{\"cartItem\":[{\"itemCode\":\"MTUJ2LL/A\",\"sorId\":\"MTUJ2LL/A\",\"cartItemType\":\"DEVICE\",\"mobileNumber\":\"4434541510\",\"description\":\"APPLEWATCHS440GALPSSP\",\"qty\":1,\"bundleSeqNum\":0,\"itemPrice\":\"499.99\",\"taxAmount\":38.75,\"groupDiscInd\":0,\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/Apple_Watch_Series_4_GPS_Plus_Cellular_40mm_Aluminum_Case_with_Sport_Band_MTUJ2LLA?$device-thumb$\"},\"prodCode1\":\"LTE\",\"prodCode2\":\"SMW\",\"prodCode3\":\"EUC\",\"prodCode4\":\"000\",\"priceType\":\"MONTH_TO_MONTH\",\"btaEligible\":\"true\",\"catalogPrice\":499.99,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"color\":{\"color\":\"#cfbea9\",\"colorDisplayName\":\"GOLD/PINKSAND\"},\"itemNrpPrice\":499.99,\"itemCost\":499.99,\"upgradeReasonCode\":\"EA\",\"itemPriceType\":\"R\",\"discounts\":[],\"availableReasonCode\":[],\"inventory\":{\"isAvailable\":true,\"isBackorder\":false,\"isPreOrder\":false,\"qtyAvailable\":39437.0},\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"numberShareEligible\":\"true\",\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"EMBD4GSIM-N\",\"sorId\":\"EMBD4GSIM-N\",\"cartItemType\":\"SIM\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0},{\"itemCode\":\"WAR6002\",\"sorId\":\"WAR6002\",\"cartItemType\":\"WARRANTY\",\"qty\":1,\"bundleSeqNum\":0,\"taxAmount\":0.0,\"groupDiscInd\":0,\"instantCreditAmountUsed\":0.0,\"instantCreditAmountUsedForTaxes\":0.0,\"discounts\":[],\"availableReasonCode\":[],\"isCustomerProvidedSIM\":false,\"isNetworkExtender\":false,\"ispuEligible\":false,\"itemSeqNum\":0,\"sddEligible\":false,\"smartIMEI\":false,\"year\":0}]},\"isPromoSelected\":false,\"isTradeInSelected\":false}],\"lineIdentifier\":0,\"itemSeqNum5GL\":0,\"itemSeqNum4GR\":0,\"lineExchangeTotal\":0.0,\"lineRefundTotal\":0.0,\"isCpe\":false,\"isDevicePlanCompatible\":false,\"portinMtnAssignment\":false,\"impactedLine\":false,\"preOrBackOrder\":false,\"ispuItem\":true,\"ispuItemBYOD\":false}],\"cartId\":\"3efad59a-f94e-45fa-9ed9-fd72aeae9bd5\",\"numOfLines\":1,\"numofLinesAAL\":0,\"numofLinesEUP\":0,\"validationMessages\":[],\"payments\":[],\"lineSeq\":0,\"vlcactivePhoneCount\":0,\"fivegOrderind\":false,\"aceOrderCreated\":false,\"serviceLinesCreated\":false,\"aceItemsModified\":false,\"clnrOrderFlag\":false,\"broadbandInd\":false,\"isPaperLessBilling\":\"false\"}}},\"meta\":{\"timestamp\":\"1576761387264\",\"cxpCorrelationId\":\"2019-12-19T13:16:27.+0000:7c505485-018b-4aa3-bb35-9c80e2e39f7a:cxp-cart-domain-qa-ev6v-qa-nsq2cxp-66f6d4765b-ngk7j\"}}";
//		GetCartDetailsRequest request = mapper.readValue(requestString, GetCartDetailsRequest.class);
//		GetCartDetailsUIResponse response = mapper.readValue(responseString, GetCartDetailsUIResponse.class);
//		URI url = URI.create("http://localhost/retrieve-cart");
//		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
//		ServerHttpResponse httpResponse = null;
//		when(readCartHelper.get5GCart(Mockito.any())).thenReturn(Mono.just(response));
//		when(redisHelper.upsertRetrieveCartDataIntoRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
//
//		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.retrieveFiveGCart(httpHeader, httpResponse,
//				request);
//		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
//				.verify();
//	}
//
//
//}
