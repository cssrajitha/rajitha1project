package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper3;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper2;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.model.addDevice.AddDeviceContext;
import onevz.soe.cart.model.addDevice.AddDeviceServiceBody;
import onevz.soe.cart.model.addDevice.AddDeviceServiceResponse;
import onevz.soe.cart.model.addDevice.ShowAALPromoIntercept;
import onevz.soe.cart.model.common.CartServiceCartInfo;
import onevz.soe.cart.model.common.CartServiceContextInfo;
import onevz.soe.cart.model.common.CartServiceCustomerInfo;
import onevz.soe.cart.model.common.Line;
import onevz.soe.cart.nbx.NBXFeedbackService;
import onevz.soe.cart.requests.MyOffersCXPRequest;
import onevz.soe.cart.requests.ValidateOffersRequest;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.common.DeviceCartInfo;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(UpdateCartHelper.class)
public class CartServiceHelper5Test {

    @Autowired
    private UpdateCartHelper helper;

    @MockBean
    private CartServiceCxpHelper cxpHelper;

    @MockBean
    private CartServiceCxpHelper2 cxpHelper2;

    @MockBean
    private CartServiceBpmHelper3 bpmHelper3;

    @MockBean
    private CartServiceBpmHelper bpmHelper4;

    @MockBean
    private RedisHelper redisHelper;

    @MockBean
    private RedisHelper2 redisHelper2;

    @MockBean
    private RedisHelper3 redisHelper3;

    @Autowired
    private ObjectMapper mapper;

    @MockBean
    private NBXFeedbackService nbxService;

    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;

    @MockBean
    CartAddDeviceHelper deviceHelper;

    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;

    @Test
    public void cancelCaseHelperTest1() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CancelCaseUIRequest3.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CancelCaseUIResponse.json", testFileLocation);
        CancelCaseUIRequest sampleUIRequest =  mapper.readValue(sampleUIRequestString, CancelCaseUIRequest.class);
        CancelCaseUIResponse sampleResponse = mapper.readValue(sampleUIResponseString, CancelCaseUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData101.json", testFileLocation);
        String quotePricingRedisString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/QuotePricingRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        QuotePricingRedisData sampleQuotePricingRedisData = mapper.readValue(quotePricingRedisString, QuotePricingRedisData.class);
        when(bpmHelper3.cancelCase(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.getQuotePricingRedisData()).thenReturn(Mono.just(sampleQuotePricingRedisData));
        CancelCaseUIResponse expectedResponse = sampleResponse;
        Mono<CancelCaseUIResponse> response = helper.cancelCase(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void cancelCaseHelperTest2() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CancelCaseUIRequest3.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CancelCaseUIResponse.json", testFileLocation);
        CancelCaseUIRequest sampleUIRequest =  mapper.readValue(sampleUIRequestString, CancelCaseUIRequest.class);
        CancelCaseUIResponse sampleResponse = mapper.readValue(sampleUIResponseString, CancelCaseUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData101.json", testFileLocation);
        String quotePricingRedisString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/QuotePricingRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        QuotePricingRedisData sampleQuotePricingRedisData = mapper.readValue(quotePricingRedisString, QuotePricingRedisData.class);
        when(bpmHelper3.cancelCase(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.getQuotePricingRedisData()).thenReturn(Mono.just(sampleQuotePricingRedisData));
        CancelCaseUIResponse expectedResponse = sampleResponse;
        Mono<CancelCaseUIResponse> response = helper.cancelCase(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void cancelCaseHelperTest3() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CancelCaseUIRequest4.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CancelCaseUIResponse.json", testFileLocation);
        CancelCaseUIRequest sampleUIRequest =  mapper.readValue(sampleUIRequestString, CancelCaseUIRequest.class);
        CancelCaseUIResponse sampleResponse = mapper.readValue(sampleUIResponseString, CancelCaseUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData101.json", testFileLocation);
        String quotePricingRedisString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/QuotePricingRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        QuotePricingRedisData sampleQuotePricingRedisData = mapper.readValue(quotePricingRedisString, QuotePricingRedisData.class);
        when(bpmHelper3.cancelCase(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.getQuotePricingRedisData()).thenReturn(Mono.just(sampleQuotePricingRedisData));
        CancelCaseUIResponse expectedResponse = sampleResponse;
        Mono<CancelCaseUIResponse> response = helper.cancelCase(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void cancelCaseHelperTest4() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CancelCaseUIRequest5.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CancelCaseUIResponse.json", testFileLocation);
        CancelCaseUIRequest sampleUIRequest =  mapper.readValue(sampleUIRequestString, CancelCaseUIRequest.class);
        CancelCaseUIResponse sampleResponse = mapper.readValue(sampleUIResponseString, CancelCaseUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData102.json", testFileLocation);
        String quotePricingRedisString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/QuotePricingRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        QuotePricingRedisData sampleQuotePricingRedisData = mapper.readValue(quotePricingRedisString, QuotePricingRedisData.class);
        when(bpmHelper3.cancelCase(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.getQuotePricingRedisData()).thenReturn(Mono.just(sampleQuotePricingRedisData));
        CancelCaseUIResponse expectedResponse = sampleResponse;
        Mono<CancelCaseUIResponse> response = helper.cancelCase(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void cancelCaseHelperTest5() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CancelCaseUIRequest6.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CancelCaseUIResponse.json", testFileLocation);
        CancelCaseUIRequest sampleUIRequest =  mapper.readValue(sampleUIRequestString, CancelCaseUIRequest.class);
        CancelCaseUIResponse sampleResponse = mapper.readValue(sampleUIResponseString, CancelCaseUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData103.json", testFileLocation);
        String quotePricingRedisString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/QuotePricingRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        QuotePricingRedisData sampleQuotePricingRedisData = mapper.readValue(quotePricingRedisString, QuotePricingRedisData.class);
        when(bpmHelper3.cancelCase(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.getQuotePricingRedisData()).thenReturn(Mono.just(sampleQuotePricingRedisData));
        CancelCaseUIResponse expectedResponse = sampleResponse;
        Mono<CancelCaseUIResponse> response = helper.cancelCase(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void cancelCaseHelperTest6() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CancelCaseUIRequest6.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CancelCaseUIResponse7.json", testFileLocation);
        CancelCaseUIRequest sampleUIRequest =  mapper.readValue(sampleUIRequestString, CancelCaseUIRequest.class);
        CancelCaseUIResponse sampleResponse = mapper.readValue(sampleUIResponseString, CancelCaseUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData103.json", testFileLocation);
        String quotePricingRedisString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/QuotePricingRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        QuotePricingRedisData sampleQuotePricingRedisData = mapper.readValue(quotePricingRedisString, QuotePricingRedisData.class);
        when(bpmHelper3.cancelCase(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.getQuotePricingRedisData()).thenReturn(Mono.just(sampleQuotePricingRedisData));
        CancelCaseUIResponse expectedResponse = sampleResponse;
        Mono<CancelCaseUIResponse> response = helper.cancelCase(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void cancelCaseHelperTest7() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CancelCaseUIRequest.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CancelCaseUIResponse.json", testFileLocation);
        CancelCaseUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, CancelCaseUIRequest.class);
        CancelCaseUIResponse sampleResponse = mapper.readValue(sampleUIResponseString, CancelCaseUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        String quotePricingRedisString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/QuotePricingRedisData1.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCreditAppNum("1234");
        QuotePricingRedisData sampleQuotePricingRedisData = mapper.readValue(quotePricingRedisString, QuotePricingRedisData.class);
        sampleUIRequest.setChannelId("VZW-ACSS");
        when(bpmHelper3.cancelCase(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper2.getQuotePricingRedisData()).thenReturn(Mono.just(sampleQuotePricingRedisData));
        CancelCaseUIResponse expectedResponse = sampleResponse;
        Mono<CancelCaseUIResponse> response = helper.cancelCase(sampleUIRequest);
        StepVerifier.create(response).expectError().verify();
    }

    @Test
    public void calculateMultiLineTaxForCartHelperTest1() throws IOException, SOEHTTPException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CalculateMultilineTaxUIRequest.json", testFileLocation);
        String sampleUIresponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CalculateMultilineTaxUIResponse.json", testFileLocation);
        CalculateMultilineTaxUIRequest sampleRequest = mapper.readValue(sampleUIRequestString, CalculateMultilineTaxUIRequest.class);
        CalculateMultilineTaxUIResponse sampleResponse = mapper.readValue(sampleUIresponseString, CalculateMultilineTaxUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData104.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        String rcResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveCartUIResponse1.json", testFileLocation);
        RetrieveCartUIResponse rcResponse = mapper.readValue(rcResponseString, RetrieveCartUIResponse.class);
        when(cxpHelper.retrieveCart(Mockito.any())).thenReturn(Mono.just(rcResponse));
        Mono<CalculateMultilineTaxUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(cxpHelper.calculateMultiLineTaxForCart(Mockito.any())).thenReturn(sampleResponseMono);
        Mono<CalculateMultilineTaxUIResponse> respMono = helper.calculateMultiLineTaxForCart(sampleRequest);
        StepVerifier.create(respMono).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void activateOrSetupLaterTest1() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ActivateLaterUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        ActivateLaterUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, ActivateLaterUIRequest .class);
        ActivateLaterUIResponse sampleResponse = mapper.readValue(sampleResponseString, ActivateLaterUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData90.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper3.activateOrSetupLater(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        ActivateLaterUIResponse expectedResponse = sampleResponse;
        Mono<ActivateLaterUIResponse> response = helper.activateOrSetupLater(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void activateOrSetupLaterTest2() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ActivateLaterUIRequest2.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        ActivateLaterUIRequest  sampleUIRequest = mapper.readValue(sampleUIRequestString, ActivateLaterUIRequest .class);
        ActivateLaterUIResponse sampleResponse = mapper.readValue(sampleResponseString, ActivateLaterUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData90.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper3.activateOrSetupLater(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        ActivateLaterUIResponse expectedResponse = sampleResponse;
        Mono<ActivateLaterUIResponse> response = helper.activateOrSetupLater(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void activateOrSetupLaterTest3() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ActivateLaterUIRequest3.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        ActivateLaterUIRequest  sampleUIRequest = mapper.readValue(sampleUIRequestString, ActivateLaterUIRequest .class);
        ActivateLaterUIResponse sampleResponse = mapper.readValue(sampleResponseString, ActivateLaterUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData90.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper3.activateOrSetupLater(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        ActivateLaterUIResponse expectedResponse = sampleResponse;
        Mono<ActivateLaterUIResponse> response = helper.activateOrSetupLater(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void activateOrSetupLaterTest4() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ActivateLaterUIRequest3.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        ActivateLaterUIRequest  sampleUIRequest = mapper.readValue(sampleUIRequestString, ActivateLaterUIRequest .class);
        ActivateLaterUIResponse sampleResponse = mapper.readValue(sampleResponseString, ActivateLaterUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData91.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper3.activateOrSetupLater(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        ActivateLaterUIResponse expectedResponse = sampleResponse;
        Mono<ActivateLaterUIResponse> response = helper.activateOrSetupLater(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void getRequestDetailsTest1() throws IOException, SOEHTTPException {
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData105.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, "http://localhost").cookie(new HttpCookie("RepIdCookieText","E170K")).header("Accept", "application").build();
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<AddDeviceUIRequest> response = helper.getRequestDetails("EUP", "SMSNG", "99",
                Optional.of(36), Optional.of("true"), Optional.of("30329"),
                Optional.of("L"), Optional.of("30329"), Optional.of("03/08/2020"),
                Optional.of("home"), Optional.of("BOGOHO"), Optional.of("BOGOHO"),
                Optional.of("true"), Optional.of("true"), Optional.of("true"),Optional.of("Smartphones"),Optional.of("Smartphones"),"","","",Optional.of("true"),Optional.of("true"),Optional.of("true"),Optional.of("55571"),Optional.of(true),Optional.of("Y"),Optional.of(true),Optional.of(true),Optional.of(true),Optional.of("false"),Optional.of(true),Optional.of("1792"),Optional.of("123456"),httpHeader,Optional.of(true),Optional.of("36"));
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        Mono<AddDeviceUIRequest> response1 = helper.getRequestDetails("EUP", "SMSNG", "99",
                Optional.of(36), Optional.of("true"), Optional.of("30329"),
                Optional.of("L"), Optional.of("30329"), Optional.of("03/08/2020"),
                Optional.of("home"), Optional.of("BMSM"), Optional.of("BOGOHO"),
                Optional.of("true"), Optional.of("true"), Optional.of("true"),Optional.of("Smartphones"),Optional.of("Smartphones"),"","","",Optional.of("true"),Optional.of("true"),Optional.of("true"),Optional.of("55571"),Optional.of(true),Optional.of("Y"),Optional.of(true),Optional.of(true),Optional.of(true),Optional.of("false"),Optional.of(true),Optional.of("1792"),Optional.of("123456"),httpHeader,Optional.of(true),Optional.of("36"));
        StepVerifier.create(response1).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void getRequestDetailsTest3() throws IOException, SOEHTTPException {
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData105.json", testFileLocation);
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, "http://localhost").cookie(new HttpCookie("RepIdCookieText","E170K")).header("Accept", "application").build();
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);

        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<AddDeviceUIRequest> response = helper.getRequestDetails("NSE", "SMSNG", "99",
                Optional.of(36), Optional.of("true"), Optional.of("30329"),
                Optional.of("L"), Optional.of("30329"), Optional.of("03/08/2020"),
                Optional.of("home"), Optional.of("BOGO"), Optional.of("BOGOHO"),
                Optional.of("true"), Optional.of("true"), Optional.of("true"),Optional.of("Smartphones"),Optional.of("Smartphones"),"dev567397","","",Optional.of("true"),Optional.of("true"),Optional.of("true"),Optional.of("55571"),Optional.of(true),Optional.of("Y"),Optional.of(true),Optional.of(false),Optional.of(true),Optional.of("false"),Optional.of(true),Optional.of("1792"),Optional.of("123456"),httpHeader,Optional.of(true),Optional.of("36"));
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        Mono<AddDeviceUIRequest> response2 = helper.getRequestDetails("NSE", "SMSNG", "99",
                Optional.of(36), Optional.of("true"), Optional.of("30329"),
                Optional.empty(), Optional.of("30329"), Optional.of("03/08/2020"),
                Optional.of("home"), Optional.of("TRADEIN"), Optional.of("BOGOHO"),
                Optional.of("true"), Optional.of("true"), Optional.of("true"),Optional.of("Smartphones"),Optional.of("Smartphones"),"dev567397","","",Optional.of("true"),Optional.of("true"),Optional.of("true"),Optional.of("55571"),Optional.of(false),Optional.of("Y"),Optional.of(false),Optional.of(true),Optional.of(true),Optional.of("false"),Optional.of(true),Optional.of("1792"),Optional.of("123456"),httpHeader,Optional.of(true),Optional.of("36"));
        StepVerifier.create(response2).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        Mono<AddDeviceUIRequest> response1 = helper.getRequestDetails("NSE", "SMSNG", "99",
                Optional.empty(), Optional.of("true"),  Optional.empty(),
                Optional.of("M"), Optional.of("30329"), Optional.of("03/08/2020"),
                Optional.of("home"),  Optional.empty(), Optional.empty(),
                Optional.of("true"), Optional.of("false"), Optional.of("false"),
                Optional.of("Smartphones"),Optional.of("Smartphones"),"dev567397","","",Optional.of("true"),Optional.of("true"),Optional.of("true"),Optional.of("55571"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(true),Optional.of("false"),Optional.of(true),Optional.of("1792"),Optional.of("123456"),httpHeader,Optional.of(true),Optional.of("36"));
        StepVerifier.create(response1).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        Mono<AddDeviceUIRequest> response3 = helper.getRequestDetails("NSE", "SMSNG", "99",
                Optional.empty(), Optional.of("true"),  Optional.empty(),
                Optional.of("M"), Optional.empty(), Optional.empty(),
                Optional.empty(),  Optional.empty(), Optional.empty(),
                Optional.of("true"), Optional.of("false"), Optional.of("false"),
                Optional.of("Smartphones"),Optional.of("Smartphones"),"dev567397","","",Optional.of("true"),Optional.of("true"),Optional.empty(),Optional.of("55571"),Optional.of(true),Optional.of("Y"),Optional.of(true),Optional.of(true),Optional.of(true),Optional.of("false"),Optional.of(true),Optional.of("1792"),Optional.of("123456"),httpHeader,Optional.of(true),Optional.of("36"));
        StepVerifier.create(response3).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        Mono<AddDeviceUIRequest> response4 = helper.getRequestDetails("NSE", "SMSNG", "99",
                Optional.empty(), Optional.of("true"),  Optional.empty(),
                Optional.of("M"), Optional.empty(), Optional.empty(),
                Optional.empty(),  Optional.empty(), Optional.empty(),
                Optional.of("true"), Optional.empty(), Optional.empty(),
                Optional.of("smartphones"),Optional.empty(),"dev567397","","",Optional.of("true"),Optional.empty(),Optional.of("true"),Optional.of("55571"),Optional.of(true),Optional.of("Y"),Optional.of(true),Optional.of(true),Optional.of(true),Optional.of("false"),Optional.of(true),Optional.of("1792"),Optional.of("123456"),httpHeader,Optional.of(true),Optional.of("36"));
        StepVerifier.create(response4).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        Mono<AddDeviceUIRequest> response5 = helper.getRequestDetails("NSE", "SMSNG", "99",
                Optional.empty(), Optional.of("true"),  Optional.empty(),
                Optional.of("M"), Optional.empty(), Optional.empty(),
                Optional.empty(),  Optional.empty(), Optional.empty(),
                Optional.of("true"), Optional.empty(), Optional.empty(),
                Optional.empty(),Optional.empty(),"dev567397","","",Optional.empty(),Optional.empty(),Optional.empty(),Optional.of("55571"),Optional.of(true),Optional.of("Y"),Optional.of(true),Optional.of(true),Optional.of(true),Optional.of("false"),Optional.of(true),Optional.of("1792"),Optional.of("123456"),httpHeader,Optional.of(true),Optional.of("36"));
        StepVerifier.create(response5).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        Mono<AddDeviceUIRequest> response22 = helper.getRequestDetails("NSE", "SMSNG", "99",
                Optional.of(36), Optional.of("true"), Optional.of("30329"),
                Optional.empty(), Optional.of("30329"), Optional.of("03/08/2020"),
                Optional.of("home"), Optional.of("BIC"), Optional.of("BIC"),
                Optional.of("true"), Optional.of("true"), Optional.of("true"),Optional.of("Smartphones"),Optional.of("Smartphones"),"dev567397","","",Optional.of("true"),Optional.of("true"),Optional.of("true"),Optional.of("55571"),Optional.of(false),Optional.of("Y"),Optional.of(true),Optional.of(true),Optional.of(true),Optional.of("false"),Optional.of(true),Optional.of("1792"),Optional.of("123456"),httpHeader,Optional.of(true),Optional.of("36"));
        StepVerifier.create(response22).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        Mono<AddDeviceUIRequest> response6 = helper.getRequestDetails("NSE", "SMSNG", "99",
                Optional.of(36), Optional.of("true"), Optional.of("30329"),
                Optional.empty(), Optional.of("30329"), Optional.of("03/08/2020"),
                Optional.of("home"), Optional.of("BIC"), Optional.of("BIC"),
                Optional.of("true"), Optional.of("true"), Optional.of("true"),Optional.of("Smartphones"),Optional.of("Smartphones"),"dev567397","","",Optional.of("true"),Optional.of("true"),Optional.of("true"),Optional.of("55571"),Optional.of(true),Optional.of("Y"),Optional.of(true),Optional.of(true),Optional.of(true),Optional.of("false"),Optional.of(true),Optional.of("1792"),Optional.of("123456"),httpHeader,Optional.of(true),Optional.of("36"));
        StepVerifier.create(response6).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

        Mono<AddDeviceUIRequest> response7 = helper.getRequestDetails("NSE", "SMSNG", "99",
                Optional.of(36), Optional.of("true"), Optional.of("30329"),
                Optional.empty(), Optional.of("30329"), Optional.of("03/08/2020"),
                Optional.of("home"), Optional.of("PROMO_BUNDLE"), Optional.of("PROMO_BUNDLE"),
                Optional.of("true"), Optional.of("true"), Optional.of("true"),Optional.of("Smartphones"),Optional.of("Smartphones"),"dev567397","","",Optional.of("true"),Optional.of("true"),Optional.of("true"),Optional.of("55571"),Optional.of(true),Optional.of("Y"),Optional.of(true),Optional.of(true),Optional.of(true),Optional.of("false"),Optional.of(true),Optional.of("1792"),Optional.of("123456"),httpHeader,Optional.of(true),Optional.of("36"));
        StepVerifier.create(response7).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

    }

    @Test
    public void addStepFlowNameUpdateTest() throws IOException {
        helper.addStepFlowNameUpdate("NSEBYOD");
        helper.addStepFlowNameUpdate("BYOD");
        helper.addStepFlowNameUpdate("aal");
        helper.addStepFlowNameUpdate("eup");
    }

    @Test
    public void clearAndContinueTest1() throws IOException, SOEHTTPException {
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData106.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        String requestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ClearAndContinueUIRequest1.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ClearAndContinueUIResponse2.json", testFileLocation);
        ClearAndContinueUIRequest request = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
        ClearAndContinueUIResponse response = mapper.readValue(responseString, ClearAndContinueUIResponse.class);
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(redisHelper.deleteCartIdAndCaseIdAndExistingCaseFromRedis()).thenReturn(Mono.just(1L));
        when(bpmHelper3.clearAndContinue(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ClearAndContinueUIResponse> cncResp = helper.clearAndContinue(request);
        StepVerifier.create(cncResp).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ClearAndContinueUIResponse1.json", testFileLocation);
        response = mapper.readValue(responseString, ClearAndContinueUIResponse.class);
        when(bpmHelper3.clearAndContinue(Mockito.any())).thenReturn(Mono.just(response));
        cncResp = helper.clearAndContinue(request);
        StepVerifier.create(cncResp).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void clearAndContinueTest2() throws IOException, SOEHTTPException {
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData106.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        String requestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ClearAndContinueUIRequest3.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ClearAndContinueUIResponse2.json", testFileLocation);
        ClearAndContinueUIRequest request = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
        ClearAndContinueUIResponse response = mapper.readValue(responseString, ClearAndContinueUIResponse.class);
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(redisHelper.deleteCartIdAndCaseIdAndExistingCaseFromRedis()).thenReturn(Mono.just(1L));
        when(bpmHelper3.clearAndContinue(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ClearAndContinueUIResponse> cncResp = helper.clearAndContinue(request);
        StepVerifier.create(cncResp).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ClearAndContinueUIResponse3.json", testFileLocation);
        response = mapper.readValue(responseString, ClearAndContinueUIResponse.class);
        when(bpmHelper3.clearAndContinue(Mockito.any())).thenReturn(Mono.just(response));
        cncResp = helper.clearAndContinue(request);
        StepVerifier.create(cncResp).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void clearAndContinueTest3() throws IOException, SOEHTTPException {
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData107.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        String requestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ClearAndContinueUIRequest4.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ClearAndContinueUIResponse2.json", testFileLocation);
        ClearAndContinueUIRequest request = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
        ClearAndContinueUIResponse response = mapper.readValue(responseString, ClearAndContinueUIResponse.class);
        when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
        when(redisHelper.deleteCartIdAndCaseIdAndExistingCaseFromRedis()).thenReturn(Mono.just(1L));
        when(bpmHelper3.clearAndContinue(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ClearAndContinueUIResponse> cncResp = helper.clearAndContinue(request);
        StepVerifier.create(cncResp).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ClearAndContinueUIResponse4.json", testFileLocation);
        response = mapper.readValue(responseString, ClearAndContinueUIResponse.class);
        when(bpmHelper3.clearAndContinue(Mockito.any())).thenReturn(Mono.just(response));
        cncResp = helper.clearAndContinue(request);
        StepVerifier.create(cncResp).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addDeviceClearAndContinueTest1() throws JsonParseException, JsonMappingException, IOException {
        String sampleUIresponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CalculateMultilineTaxUIResponse.json", testFileLocation);
        ServerHttpResponse httpResponse = Mockito.mock(ServerHttpResponse.class);
        CartRedisData sampleRedisData =new CartRedisData();
        sampleRedisData.setIntendType("NSE");
        Lines lines1=new Lines();
        lines1.setCurrentDeviceID("123");
        List<Lines> lines=new ArrayList<>();
        lines.add(lines1);
        sampleRedisData.setLines(lines);
        sampleRedisData.setDepletionType("depl");sampleRedisData.setChannelId("VZW-ACSS");sampleRedisData.setCreditAppNum("1234567890");sampleRedisData.setCartCreator("nse");
        sampleRedisData.setAccountNumber("1234567890");
        sampleRedisData.setMtn("123456789");
        sampleRedisData.setProcessingMTN("12345678");
        sampleRedisData.setExistingCase("123456789");
        DeviceCartInfo deviceCartInfo=new DeviceCartInfo();
        deviceCartInfo.setCartId("1234567890");
        deviceCartInfo.setCaseId("12345");
        sampleRedisData.setDeviceCartInfo(deviceCartInfo);
        UpdateTradeInOfferUIRequest sampleRequest = null;
        AddDeviceUIResponse sampleResponse = new AddDeviceUIResponse();
        AddDeviceServiceBody serviceBody=new AddDeviceServiceBody();
        AddDeviceServiceResponse serviceResponse=new AddDeviceServiceResponse();
        AddDeviceContext context=new AddDeviceContext();
        CartServiceCartInfo cartInfo=new CartServiceCartInfo();
        cartInfo.setCartId("1234");
        context.setCartInfo(cartInfo);
        context.setCaseId("12345");
        Line line1=new Line();
        line1.setMtn("123456");
        Line line2=new Line();
        line2.setMtn("123456");
        Line[] linesc= {line1,line2};
        context.setLines(linesc);
        CartServiceContextInfo contextInfo=new CartServiceContextInfo();
        contextInfo.setProcessStep("step");
        context.setContextInfo(contextInfo);
        CartServiceCustomerInfo customerInfo=new CartServiceCustomerInfo();
        context.setCustomerInfo(customerInfo);
        ShowAALPromoIntercept showAALPromoIntercept=new ShowAALPromoIntercept();
        showAALPromoIntercept.setMyOfferEligibile(true);
        context.setShowAALPromoIntercept(showAALPromoIntercept);
        serviceResponse.setContext(context);
        serviceBody.setServiceResponse(serviceResponse);
        sampleResponse.setServiceBody(serviceBody);
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
        StepVerifier.create(helper.addDeviceClearAndContinue(sampleRedisData,"SOP-329-E01","20ae6bcb-1150-4d16-99dd-14b7d9f128c7","VZW-ACSS",httpResponse,null)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void validateOffersTest1() throws IOException, SOEHTTPException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateOffersRequest.json", testFileLocation);
        String sampleUIresponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ValidateOffersResponse.json", testFileLocation);
        ValidateOffersRequest sampleRequest = mapper.readValue(sampleUIRequestString, ValidateOffersRequest.class);
        ValidateOffersResponse sampleResponse = mapper.readValue(sampleUIresponseString, ValidateOffersResponse.class);
        when(cxpHelper2.validateOffers(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper2.getCartIdFromRedis()).thenReturn(Mono.just(""));
        ValidateOffersResponse expectedResponse = sampleResponse;
        Mono<ValidateOffersResponse> cncResp = helper.validateOffers(sampleRequest);
        StepVerifier.create(cncResp).assertNext(resp -> Assert.assertNotNull(resp.getData())).expectComplete().verify();
        StepVerifier.create(cncResp).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void nbxFeedbackHelperTest1() throws IOException {
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String nbxString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackResponse.json", testFileLocation);
        String nbxRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackUIRequest.json", testFileLocation);;
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        NBXFeedbackUIRequest nbxReq = mapper.readValue(nbxRequestString, NBXFeedbackUIRequest.class);
        String bvpStr = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BVPRedisData2.json", testFileLocation);
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        Mono<NBXFeedbackResponse> response = helper.nbxFeedbackCall(nbxReq);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void nbxFeedbackHelperTest2() throws IOException {
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String nbxString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackResponse.json", testFileLocation);
        String nbxRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackUIRequest.json", testFileLocation);;
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        NBXFeedbackUIRequest nbxReq = mapper.readValue(nbxRequestString, NBXFeedbackUIRequest.class);
        String bvpStr = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BVPRedisData3.json", testFileLocation);
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        Mono<NBXFeedbackResponse> response = helper.nbxFeedbackCall(nbxReq);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void nbxFeedbackHelperTest3() throws IOException {
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String nbxString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackResponse.json", testFileLocation);
        String nbxRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackUIRequest1.json", testFileLocation);
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        NBXFeedbackUIRequest nbxReq = mapper.readValue(nbxRequestString, NBXFeedbackUIRequest.class);
        String bvpStr = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BVPRedisData3.json", testFileLocation);
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        Mono<NBXFeedbackResponse> response = helper.nbxFeedbackCall(nbxReq);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void nbxFeedbackHelperTest4() throws IOException {
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String nbxString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackResponse.json", testFileLocation);
        String nbxRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackUIRequest2.json", testFileLocation);
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        NBXFeedbackUIRequest nbxReq = mapper.readValue(nbxRequestString, NBXFeedbackUIRequest.class);
        String bvpStr = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BVPRedisData3.json", testFileLocation);
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        Mono<NBXFeedbackResponse> response = helper.nbxFeedbackCall(nbxReq);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void nbxFeedbackHelperTest5() throws IOException {
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String nbxString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackResponse.json", testFileLocation);
        String nbxRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackUIRequest2.json", testFileLocation);
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        NBXFeedbackUIRequest nbxReq = mapper.readValue(nbxRequestString, NBXFeedbackUIRequest.class);
        String bvpStr = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BVPRedisData4.json", testFileLocation);
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        Mono<NBXFeedbackResponse> response = helper.nbxFeedbackCall(nbxReq);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void nbxFeedbackHelperTest6() throws IOException {
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String nbxString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackResponse.json", testFileLocation);
        String nbxRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackUIRequest3.json", testFileLocation);
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        NBXFeedbackUIRequest nbxReq = mapper.readValue(nbxRequestString, NBXFeedbackUIRequest.class);
        String bvpStr = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BVPRedisData4.json", testFileLocation);
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        Mono<NBXFeedbackResponse> response = helper.nbxFeedbackCall(nbxReq);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void nbxFeedbackHelperTest7() throws IOException {
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String nbxString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackResponse.json", testFileLocation);
        String nbxRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackUIRequest4.json", testFileLocation);
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        NBXFeedbackUIRequest nbxReq = mapper.readValue(nbxRequestString, NBXFeedbackUIRequest.class);
        String bvpStr = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BVPRedisData4.json", testFileLocation);
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        Mono<NBXFeedbackResponse> response = helper.nbxFeedbackCall(nbxReq);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void nbxFeedbackHelperTest8() throws IOException {
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String nbxString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackResponse.json", testFileLocation);
        String nbxRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackUIRequest5.json", testFileLocation);
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        NBXFeedbackUIRequest nbxReq = mapper.readValue(nbxRequestString, NBXFeedbackUIRequest.class);
        String bvpStr = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BVPRedisData4.json", testFileLocation);
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        Mono<NBXFeedbackResponse> response = helper.nbxFeedbackCall(nbxReq);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void nbxFeedbackHelperTest9() throws IOException {
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String nbxString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackResponse.json", testFileLocation);
        String nbxRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NBXFeedbackUIRequest5.json", testFileLocation);
        NBXFeedbackResponse nbxRes = mapper.readValue(nbxString, NBXFeedbackResponse.class);
        NBXFeedbackUIRequest nbxReq = mapper.readValue(nbxRequestString, NBXFeedbackUIRequest.class);
        String bvpStr = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BVPRedisData5.json", testFileLocation);
        BVPRedisData bvpData = mapper.readValue(bvpStr, BVPRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(bvpData));
        when(nbxService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(nbxRes));
        Mono<NBXFeedbackResponse> response = helper.nbxFeedbackCall(nbxReq);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addTransferUpgradeHelperTest2() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateTransferUpgradeUIRequest2.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        UpdateTransferUpgradeUIRequest sampleUIRequest = null;
        UpdateTransferUpgradeUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateTransferUpgradeUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, UpdateTransferUpgradeUIResponse.class);
        when(bpmHelper3.addTransferUpgrade(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateTransferUpgradeUIResponse expectedResponse = sampleResponse;
        Mono<UpdateTransferUpgradeUIResponse> response = helper.addTransferUpgrade(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addTransferUpgradeHelperTest3() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateTransferUpgradeUIRequest3.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        UpdateTransferUpgradeUIRequest sampleUIRequest = null;
        UpdateTransferUpgradeUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateTransferUpgradeUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, UpdateTransferUpgradeUIResponse.class);
        when(bpmHelper3.addTransferUpgrade(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateTransferUpgradeUIResponse expectedResponse = sampleResponse;
        Mono<UpdateTransferUpgradeUIResponse> response = helper.addTransferUpgrade(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addTransferUpgradeHelperTest4() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ActivateLaterUIRequest3.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        UpdateTransferUpgradeUIRequest sampleUIRequest = null;
        UpdateTransferUpgradeUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateTransferUpgradeUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, UpdateTransferUpgradeUIResponse.class);
        when(bpmHelper3.addTransferUpgrade(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateTransferUpgradeUIResponse expectedResponse = sampleResponse;
        Mono<UpdateTransferUpgradeUIResponse> response = helper.addTransferUpgrade(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addTransferUpgradeHelperTest5() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateTransferUpgradeUIRequest2.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        UpdateTransferUpgradeUIRequest sampleUIRequest = null;
        UpdateTransferUpgradeUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData108.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateTransferUpgradeUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, UpdateTransferUpgradeUIResponse.class);
        when(bpmHelper3.addTransferUpgrade(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateTransferUpgradeUIResponse expectedResponse = sampleResponse;
        Mono<UpdateTransferUpgradeUIResponse> response = helper.addTransferUpgrade(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void removeTransferUpgradeHelperTest2() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateTransferUpgradeUIRequest2.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        UpdateTransferUpgradeUIRequest sampleUIRequest = null;
        UpdateTransferUpgradeUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateTransferUpgradeUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, UpdateTransferUpgradeUIResponse.class);
        when(bpmHelper3.removeTransferUpgrade(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateTransferUpgradeUIResponse expectedResponse = sampleResponse;
        Mono<UpdateTransferUpgradeUIResponse> response = helper.removeTransferUpgrade(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void removeTransferUpgradeHelperTest3() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ActivateLaterUIRequest3.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        UpdateTransferUpgradeUIRequest sampleUIRequest = null;
        UpdateTransferUpgradeUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateTransferUpgradeUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, UpdateTransferUpgradeUIResponse.class);
        when(bpmHelper3.removeTransferUpgrade(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateTransferUpgradeUIResponse expectedResponse = sampleResponse;
        Mono<UpdateTransferUpgradeUIResponse> response = helper.removeTransferUpgrade(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void removeTransferUpgradeHelperTest4() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ActivateLaterUIRequest3.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        UpdateTransferUpgradeUIRequest sampleUIRequest = null;
        UpdateTransferUpgradeUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData109.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateTransferUpgradeUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, UpdateTransferUpgradeUIResponse.class);
        when(bpmHelper3.removeTransferUpgrade(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateTransferUpgradeUIResponse expectedResponse = sampleResponse;
        Mono<UpdateTransferUpgradeUIResponse> response = helper.removeTransferUpgrade(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void removeTransferUpgradeHelperTest5() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ActivateLaterUIRequest2.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        UpdateTransferUpgradeUIRequest sampleUIRequest = null;
        UpdateTransferUpgradeUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateTransferUpgradeUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, UpdateTransferUpgradeUIResponse.class);
        when(bpmHelper3.removeTransferUpgrade(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateTransferUpgradeUIResponse expectedResponse = sampleResponse;
        Mono<UpdateTransferUpgradeUIResponse> response = helper.removeTransferUpgrade(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void removeBvoOffersHelperTest1() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBvoOffersUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIResponseNew.json", testFileLocation);
        UpdateBvoOffersUIRequest sampleUIRequest = null;
        UpdateBvoOffersUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData35.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateBvoOffersUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, UpdateBvoOffersUIResponse.class);
        when(bpmHelper3.removeBvoOffers(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(new BVPRedisData()));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just(new String()));
        when(redisHelper2.deleteRemoveOfferDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        when(redisHelper2.getRemoveOfferDataIntoRedis()).thenReturn(Mono.just(new RemoveOfferRedisData()));
        UpdateBvoOffersUIResponse expectedResponse = sampleResponse;
        Mono<UpdateBvoOffersUIResponse> response = helper.removeBvoOffers(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }


    @Test
    public void removeBvoOffersHelperTest2() throws IOException {
        String sampleUIRequestString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateBvoOffersUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIResponseNew.json", testFileLocation);
        UpdateBvoOffersUIRequest sampleUIRequest = null;
        UpdateBvoOffersUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData36.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateBvoOffersUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, UpdateBvoOffersUIResponse.class);
        when(bpmHelper3.removeBvoOffers(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getBVPDataFromRedis()).thenReturn(Mono.just(new BVPRedisData()));
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just(new String()));
        when(redisHelper2.deleteRemoveOfferDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        when(redisHelper2.getRemoveOfferDataIntoRedis()).thenReturn(Mono.just(new RemoveOfferRedisData()));
        UpdateBvoOffersUIResponse expectedResponse = sampleResponse;
        Mono<UpdateBvoOffersUIResponse> response = helper.removeBvoOffers(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addNickNameTest2() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddNickNameUIRequest2.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        AddNickNameUIRequest  sampleUIRequest = null;
        AddNickNameUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData110.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, AddNickNameUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, AddNickNameUIResponse.class);
        when(bpmHelper3.addNickName(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<AddNickNameUIResponse> response = helper.addNickName(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
    }

    @Test
    public void addNickNameTest3() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddNickNameUIRequest3.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        AddNickNameUIRequest  sampleUIRequest = null;
        AddNickNameUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData42.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, AddNickNameUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, AddNickNameUIResponse.class);
        when(bpmHelper3.addNickName(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<AddNickNameUIResponse> response = helper.addNickName(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
    }

    @Test
    public void addNickNameTest4() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddNickNameUIRequest5.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        AddNickNameUIRequest  sampleUIRequest = null;
        AddNickNameUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData42.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, AddNickNameUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, AddNickNameUIResponse.class);
        when(bpmHelper3.addNickName(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<AddNickNameUIResponse> response = helper.addNickName(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
    }

    @Test
    public void addNickNameTest5() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddNickNameUIRequest4.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        AddNickNameUIRequest  sampleUIRequest = null;
        AddNickNameUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData42.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, AddNickNameUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, AddNickNameUIResponse.class);
        when(bpmHelper3.addNickName(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<AddNickNameUIResponse> response = helper.addNickName(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
    }


    @Test
    public void addNickNameTest6() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddNickNameUIRequest6.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        AddNickNameUIRequest  sampleUIRequest = null;
        AddNickNameUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData42.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, AddNickNameUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, AddNickNameUIResponse.class);
        when(bpmHelper3.addNickName(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<AddNickNameUIResponse> response = helper.addNickName(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
    }

    @Test
    public void addNickNameTest7() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddNickNameUIRequest7.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        AddNickNameUIRequest  sampleUIRequest = null;
        AddNickNameUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData42.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, AddNickNameUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, AddNickNameUIResponse.class);
        when(bpmHelper3.addNickName(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<AddNickNameUIResponse> response = helper.addNickName(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
    }

    @Test
    public void emailCartToCustomerTest2() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/EmailCartToCustomerUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/EmailCartToCustomerUIResponse.json", testFileLocation);
        EmailCartToCustomerUIRequest sampleUIRequest = null;
        EmailCartToCustomerUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleUIRequest = mapper.readValue(sampleUIRequestString, EmailCartToCustomerUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, EmailCartToCustomerUIResponse.class);
        when(bpmHelper3.emailCartToCustomer(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        EmailCartToCustomerUIResponse expectedResponse = sampleResponse;
        Mono<EmailCartToCustomerUIResponse> response = helper.emailCartToCustomer(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateVZCCAppStatusTest2() throws IOException {
        String requestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/VZCCAppStatusUIRequest.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/VZCCAppStatusUIResponse.json", testFileLocation);
        VZCCAppStatusUIRequest sampleUIRequest = null;
        VZCCAppStatusUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData11.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setIntendType("EUP");
        sampleUIRequest = mapper.readValue(requestString, VZCCAppStatusUIRequest.class);
        sampleResponse = mapper.readValue(responseString, VZCCAppStatusUIResponse.class);
        when(cxpHelper2.updateVZCCAppStatus(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        VZCCAppStatusUIResponse expectedResponse = sampleResponse;
        Mono<VZCCAppStatusUIResponse> response = helper.updateVZCCAppStatus(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateVZCCAppStatusTest3() throws IOException {
        String requestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/VZCCAppStatusUIRequest.json", testFileLocation);
        String responseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/VZCCAppStatusUIResponse.json", testFileLocation);
        VZCCAppStatusUIRequest sampleUIRequest = null;
        VZCCAppStatusUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData11.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setIntendType("");
        sampleUIRequest = mapper.readValue(requestString, VZCCAppStatusUIRequest.class);
        sampleResponse = mapper.readValue(responseString, VZCCAppStatusUIResponse.class);
        when(cxpHelper2.updateVZCCAppStatus(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        VZCCAppStatusUIResponse expectedResponse = sampleResponse;
        Mono<VZCCAppStatusUIResponse> response = helper.updateVZCCAppStatus(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateChatIdTest2() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateChatIdUIRequest3.json", testFileLocation);
        String sampleUIRequestnotnseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateChatIdUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateChatIdUIResponse.json", testFileLocation);
        UpdateChatIdUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateChatIdUIRequest.class);
        UpdateChatIdUIRequest sampleUIRequest1 = mapper.readValue(sampleUIRequestnotnseString, UpdateChatIdUIRequest.class);
        UpdateChatIdUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateChatIdUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setAccountNumber("12345678");
        when(bpmHelper3.updateChatId(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<UpdateChatIdUIResponse> response = helper.updateChatId(sampleUIRequest);
        Mono<UpdateChatIdUIResponse> response1 = helper.updateChatId(sampleUIRequest1);
        StepVerifier.create(response1).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
    }

    @Test
    public void clearCartHelperTest3() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ClearCartUIRequest3.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData42.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        ClearCartUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, ClearCartUIRequest.class);
        ClearCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, ClearCartUIResponse.class);
        when(bpmHelper3.clearCart(Mockito.any(),Mockito.any())).thenReturn((Mono<ClearCartUIResponse>) Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        ClearCartUIResponse expectedResponse = sampleResponse;
        Mono<ClearCartUIResponse> response = helper.clearCart(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void clearCartHelperTest4() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ClearCartUIRequest4.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData42.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        ClearCartUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, ClearCartUIRequest.class);
        ClearCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, ClearCartUIResponse.class);
        when(bpmHelper3.clearCart(Mockito.any(),Mockito.any())).thenReturn((Mono<ClearCartUIResponse>) Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        ClearCartUIResponse expectedResponse = sampleResponse;
        Mono<ClearCartUIResponse> response = helper.clearCart(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void clearCartHelperTest5() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddNickNameUIRequest5.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData42.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        ClearCartUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, ClearCartUIRequest.class);
        ClearCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, ClearCartUIResponse.class);
        when(bpmHelper3.clearCart(Mockito.any(),Mockito.any())).thenReturn((Mono<ClearCartUIResponse>) Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        ClearCartUIResponse expectedResponse = sampleResponse;
        Mono<ClearCartUIResponse> response = helper.clearCart(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void clearCartHelperTest6() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ClearCartUIRequest5.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData111.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        ClearCartUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, ClearCartUIRequest.class);
        ClearCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, ClearCartUIResponse.class);
        when(bpmHelper3.clearCart(Mockito.any(),Mockito.any())).thenReturn((Mono<ClearCartUIResponse>) Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        ClearCartUIResponse expectedResponse = sampleResponse;
        Mono<ClearCartUIResponse> response = helper.clearCart(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void clearCartHelperTest7() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ClearCartUIRequest6.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData111.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        ClearCartUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, ClearCartUIRequest.class);
        ClearCartUIResponse sampleResponse = mapper.readValue(sampleResponseString, ClearCartUIResponse.class);
        when(bpmHelper3.clearCart(Mockito.any(),Mockito.any())).thenReturn((Mono<ClearCartUIResponse>) Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
        ClearCartUIResponse expectedResponse = sampleResponse;
        Mono<ClearCartUIResponse> response = helper.clearCart(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateWFMInfoHelperTest2() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateTransferUpgradeUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData36.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        UpdateWFMInfoUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateWFMInfoUIRequest.class);
        UpdateWFMInfoUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateWFMInfoUIResponse.class);
        when(bpmHelper3.updateWFMInfo(Mockito.any())).thenReturn((Mono<UpdateWFMInfoUIResponse>) Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper3.updateWFMFlowDataInRedis(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        UpdateWFMInfoUIResponse expectedResponse = sampleResponse;
        Mono<UpdateWFMInfoUIResponse> response = helper.updateWFMInfo(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateWFMInfoHelperTest3() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateWFMInfoUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData112.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        UpdateWFMInfoUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateWFMInfoUIRequest.class);
        UpdateWFMInfoUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateWFMInfoUIResponse.class);
        when(bpmHelper3.updateWFMInfo(Mockito.any())).thenReturn((Mono<UpdateWFMInfoUIResponse>) Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper3.updateWFMFlowDataInRedis(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        UpdateWFMInfoUIResponse expectedResponse = sampleResponse;
        Mono<UpdateWFMInfoUIResponse> response = helper.updateWFMInfo(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateWFMInfoHelperTest4() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateWFMInfoUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData113.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        UpdateWFMInfoUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateWFMInfoUIRequest.class);
        UpdateWFMInfoUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateWFMInfoUIResponse.class);
        when(bpmHelper3.updateWFMInfo(Mockito.any())).thenReturn((Mono<UpdateWFMInfoUIResponse>) Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper3.updateWFMFlowDataInRedis(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        UpdateWFMInfoUIResponse expectedResponse = sampleResponse;
        Mono<UpdateWFMInfoUIResponse> response = helper.updateWFMInfo(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateWFMInfoHelperTest5() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateWFMInfoUIRequest2.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData113.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        UpdateWFMInfoUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateWFMInfoUIRequest.class);
        UpdateWFMInfoUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateWFMInfoUIResponse.class);
        when(bpmHelper3.updateWFMInfo(Mockito.any())).thenReturn((Mono<UpdateWFMInfoUIResponse>) Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper3.updateWFMFlowDataInRedis(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        UpdateWFMInfoUIResponse expectedResponse = sampleResponse;
        Mono<UpdateWFMInfoUIResponse> response = helper.updateWFMInfo(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateWFMInfoHelperTest6() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateWFMInfoUIRequest3.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RemoveLinesUIResponse1.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData113.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        UpdateWFMInfoUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateWFMInfoUIRequest.class);
        UpdateWFMInfoUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateWFMInfoUIResponse.class);
        when(bpmHelper3.updateWFMInfo(Mockito.any())).thenReturn((Mono<UpdateWFMInfoUIResponse>) Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper3.updateWFMFlowDataInRedis(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        UpdateWFMInfoUIResponse expectedResponse = sampleResponse;
        Mono<UpdateWFMInfoUIResponse> response = helper.updateWFMInfo(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateMyOffersHelperTest1() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/MyOffersCXPRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/MyOffersCXPResponse.json", testFileLocation);
        MyOffersCXPRequest sampleRequest = mapper.readValue(sampleRequestString, MyOffersCXPRequest.class);
        MyOffersCXPResponse sampleResponse = mapper.readValue(sampleResponseString, MyOffersCXPResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RTDRedisData.json", testFileLocation);
        RTDRedisData sampleRedisData = mapper.readValue(redisDataString, RTDRedisData.class);
        Mono<MyOffersCXPResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(cxpHelper2.updateMyOffers(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper2.getRTDOfferDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        String cartId = "bea202a6-42cb-40d4-ac87-d3f1db2b3f13";
        when(redisHelper2.getCartIdFromRedis()).thenReturn(Mono.just(cartId));
        MyOffersCXPResponse expectedResponse = sampleResponse;
        Mono<MyOffersCXPResponse> response = helper.updateMyOffers("assisted");
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateAccountPinHelperTest1() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AccountPinUIRequest1.json", testFileLocation);
        String sampleResponseString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIResponseNew.json", testFileLocation);
        AccountPinUIRequest sampleRequest = mapper.readValue(sampleRequestString, AccountPinUIRequest.class);
        AccountPinUIResponse sampleResponse = mapper.readValue(sampleResponseString, AccountPinUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData114.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<AccountPinUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper3.updateAccountPin(sampleRequest)).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        AccountPinUIResponse expectedResponse = sampleResponse;
        Mono<AccountPinUIResponse> response = helper.updateAccountPin(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateAccountPinHelperTest2() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AccountPinUIRequest1.json", testFileLocation);
        String sampleResponseString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIResponseNew.json", testFileLocation);
        AccountPinUIRequest sampleRequest = mapper.readValue(sampleRequestString, AccountPinUIRequest.class);
        AccountPinUIResponse sampleResponse = mapper.readValue(sampleResponseString, AccountPinUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData115.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<AccountPinUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper3.updateAccountPin(sampleRequest)).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        AccountPinUIResponse expectedResponse = sampleResponse;
        Mono<AccountPinUIResponse> response = helper.updateAccountPin(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateAccountPinHelperTest3() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AccountPinUIRequest2.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIResponseNew.json", testFileLocation);
        AccountPinUIRequest sampleRequest = mapper.readValue(sampleRequestString, AccountPinUIRequest.class);
        AccountPinUIResponse sampleResponse = mapper.readValue(sampleResponseString, AccountPinUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData115.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<AccountPinUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper3.updateAccountPin(sampleRequest)).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        AccountPinUIResponse expectedResponse = sampleResponse;
        Mono<AccountPinUIResponse> response = helper.updateAccountPin(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }
    @Test
    public void updateAccountPinHelperTest4() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AccountPinUIRequest3.json", testFileLocation);
        String sampleResponseString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIResponseNew.json", testFileLocation);
        AccountPinUIRequest sampleRequest = mapper.readValue(sampleRequestString, AccountPinUIRequest.class);
        AccountPinUIResponse sampleResponse = mapper.readValue(sampleResponseString, AccountPinUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData116.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<AccountPinUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper3.updateAccountPin(sampleRequest)).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        AccountPinUIResponse expectedResponse = sampleResponse;
        Mono<AccountPinUIResponse> response = helper.updateAccountPin(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateAccountPinHelperTest5() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AccountPinUIRequest4.json", testFileLocation);
        String sampleResponseString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIResponseNew.json", testFileLocation);
        AccountPinUIRequest sampleRequest = null;
        AccountPinUIResponse sampleResponse = null;
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData117.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRequest = mapper.readValue(sampleRequestString, AccountPinUIRequest.class);
        sampleResponse = mapper.readValue(sampleResponseString, AccountPinUIResponse.class);
        Mono<AccountPinUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper3.updateAccountPin(sampleRequest)).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        AccountPinUIResponse expectedResponse = sampleResponse;
        Mono<AccountPinUIResponse> response = helper.updateAccountPin(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void salesOrderAdjustmentTest1() throws IOException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/SalesOrderAdjustmentUIRequest1.json", testFileLocation);
        SalesOrderAdjustmentUIRequest salesOrderAdjustmentUiRequest = mapper.readValue(sampleRequestString,SalesOrderAdjustmentUIRequest.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData118.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/SalesOrderAdjustmentUIResponse.json", testFileLocation);
        SalesOrderAdjustmentUIResponse salesOrderAdjustmentUiResponse = mapper.readValue(sampleResponseString,SalesOrderAdjustmentUIResponse.class);
        when(bpmHelper3.salesOrderAdjustment(Mockito.any())).thenReturn(Mono.just(salesOrderAdjustmentUiResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<SalesOrderAdjustmentUIResponse> response = helper.salesOrderAdjustment( salesOrderAdjustmentUiRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void salesOrderAdjustmentTest2() throws IOException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/SalesOrderAdjustmentUIRequest1.json", testFileLocation);
        SalesOrderAdjustmentUIRequest salesOrderAdjustmentUiRequest = mapper.readValue(sampleRequestString,SalesOrderAdjustmentUIRequest.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData119.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/SalesOrderAdjustmentUIResponse.json", testFileLocation);
        SalesOrderAdjustmentUIResponse salesOrderAdjustmentUiResponse = mapper.readValue(sampleResponseString,SalesOrderAdjustmentUIResponse.class);
        when(bpmHelper3.salesOrderAdjustment(Mockito.any())).thenReturn(Mono.just(salesOrderAdjustmentUiResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<SalesOrderAdjustmentUIResponse> response = helper.salesOrderAdjustment( salesOrderAdjustmentUiRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void bbpGetProcessStepHelperTest1() throws IOException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BBPGetProcessStepUIRequest.json", testFileLocation);
        BBPGetProcessStepUIRequest bbpgetprocessstepUiRequest = mapper.readValue(sampleRequestString, BBPGetProcessStepUIRequest.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData120.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BbpGetProcessStepUIResponse1.json", testFileLocation);
        BbpGetProcessStepUIResponse bbpgetprocessstepUiResponse = mapper.readValue(sampleResponseString, BbpGetProcessStepUIResponse.class);
        when(bpmHelper4.bbpGetProcessStep(Mockito.any())).thenReturn(Mono.just(bbpgetprocessstepUiResponse));
        Mono<BbpGetProcessStepUIResponse> response = helper.bbpGetProcessStep(bbpgetprocessstepUiRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addZipcodeHelperTest1() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/MyOffersCXPRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddZipcodeRedisData.json", testFileLocation);
        AddZipCodeUIRequest sampleRequest = mapper.readValue(sampleRequestString, AddZipCodeUIRequest.class);
        AddZipcodeRedisData sampleResponse =  mapper.readValue(sampleResponseString, AddZipcodeRedisData.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData121.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<AddZipcodeRedisData> sampleResponseMono = Mono.just(sampleResponse);
        when(cxpHelper2.addZipcode(sampleRequest)).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        AddZipcodeRedisData expectedResponse = sampleResponse;
        Mono<AddZipcodeRedisData> response = helper.addZipcode(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void populateHumWifiConflictedSFosWithCheckTest1() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEffectiveDateUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDeviceUIResponse6.json", testFileLocation);
        AddDeviceUIRequest sampleRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCreditAppNum("1234567890");
        sampleRedisData.setCartCreator("nse");
        sampleRedisData.setAccountNumber("1234567890");
        sampleRedisData.setMtn("123456789");
        sampleRedisData.setProcessingMTN("12345678");
        sampleRequest.setChannelId("VZW-ACSS");
        Mono<AddDeviceUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        Mono<ResponseEntity<GenericResponse>> response = helper.populateHumWifiConflictedSFosWithCheck(sampleRequest,sampleResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void populateHumWifiConflictedSFosWithCheckTest2() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEffectiveDateUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDeviceUIResponse3.json", testFileLocation);
        AddDeviceUIRequest sampleRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCreditAppNum("1234567890");
        sampleRedisData.setCartCreator("nse");
        sampleRedisData.setAccountNumber("1234567890");
        sampleRedisData.setMtn("123456789");
        sampleRedisData.setProcessingMTN("12345678");
        sampleRequest.setChannelId("VZW-ACSS");
        Mono<AddDeviceUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        Mono<ResponseEntity<GenericResponse>> response = helper.populateHumWifiConflictedSFosWithCheck(sampleRequest,sampleResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void populateHumWifiConflictedSFosWithCheckTest3() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEffectiveDateUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDeviceUIResponse4.json", testFileLocation);
        AddDeviceUIRequest sampleRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCreditAppNum("1234567890");
        sampleRedisData.setCartCreator("nse");
        sampleRedisData.setAccountNumber("1234567890");
        sampleRedisData.setMtn("123456789");
        sampleRedisData.setProcessingMTN("12345678");
        sampleRequest.setChannelId("VZW-ACSS");
        Mono<AddDeviceUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        Mono<ResponseEntity<GenericResponse>> response = helper.populateHumWifiConflictedSFosWithCheck(sampleRequest,sampleResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Ignore
    @Test
    public void populateHumWifiConflictedSFosWithCheckTest4() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEffectiveDateUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDeviceUIResponse5.json", testFileLocation);
        AddDeviceUIRequest sampleRequest = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setCreditAppNum("1234567890");
        sampleRedisData.setCartCreator("nse");
        sampleRedisData.setAccountNumber("1234567890");
        sampleRedisData.setMtn("123456789");
        sampleRedisData.setProcessingMTN("12345678");
        sampleRequest.setChannelId("VZW-ACSS");
        Mono<AddDeviceUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        Mono<ResponseEntity<GenericResponse>> response = helper.populateHumWifiConflictedSFosWithCheck(sampleRequest,sampleResponse);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void getRequestDetailsIsCommonPDPAndIsTradeInIntentSelected() throws IOException, SOEHTTPException {
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData105.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.GET, "http://localhost").cookie(new HttpCookie("RepIdCookieText","E170K")).header("Accept", "application").build();
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<AddDeviceUIRequest> response = helper.getRequestDetails("EUP", "SMSNG", "99",
                Optional.of(36), Optional.of("true"), Optional.of("30329"),
                Optional.of("L"), Optional.of("30329"), Optional.of("03/08/2020"),
                Optional.of("home"), Optional.of("BOGOHO"), Optional.of("BOGOHO"),
                Optional.of("true"), Optional.of("true"), Optional.of("true"),Optional.of("Smartphones"),Optional.of("Smartphones"),"","","",Optional.of("true"),Optional.of("true"),Optional.of("true"),Optional.of("55571"),Optional.of(true),Optional.of("Y"),Optional.of(true),Optional.of(true),Optional.of(true),Optional.of("false"),Optional.of(true),Optional.of("1792"),Optional.of("123456"),httpHeader,Optional.of(true),Optional.of("36"));
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        Mono<AddDeviceUIRequest> response1 = helper.getRequestDetails("EUP", "SMSNG", "99",
                Optional.of(36), Optional.of("true"), Optional.of("30329"),
                Optional.of("L"), Optional.of("30329"), Optional.of("03/08/2020"),
                Optional.of("home"), Optional.of("BMSM"), Optional.of("BOGOHO"),
                Optional.of("true"), Optional.of("true"), Optional.of("true"),Optional.of("Smartphones"),Optional.of("Smartphones"),"","","",Optional.of("true"),Optional.of("true"),Optional.of("true"),Optional.of("55571"),Optional.of(true),Optional.of("Y"),Optional.of(true),Optional.of(false),Optional.of(true),Optional.of("false"),Optional.of(true),Optional.of("1792"),Optional.of("123456"),httpHeader,Optional.of(true),Optional.of("36"));
        StepVerifier.create(response1).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        Mono<AddDeviceUIRequest> response2 = helper.getRequestDetails("EUP", "SMSNG", "99",
                Optional.of(36), Optional.of("true"), Optional.of("30329"),
                Optional.of("L"), Optional.of("30329"), Optional.of("03/08/2020"),
                Optional.of("home"), Optional.of("BMSM"), Optional.of("BOGOHO"),
                Optional.of("true"), Optional.of("true"), Optional.of("true"),Optional.of("Smartphones"),Optional.of("Smartphones"),"","","",Optional.of("true"),Optional.of("true"),Optional.of("true"),Optional.of("55571"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(true),Optional.of(true),Optional.of("false"),Optional.of(true),Optional.of("1792"),Optional.of("123456"),httpHeader,Optional.of(true),Optional.of("36"));
        StepVerifier.create(response2).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        Mono<AddDeviceUIRequest> response3 = helper.getRequestDetails("EUP", "SMSNG", "99",
                Optional.of(36), Optional.of("true"), Optional.of("30329"),
                Optional.of("L"), Optional.of("30329"), Optional.of("03/08/2020"),
                Optional.of("home"), Optional.of("BMSM"), Optional.of("BOGOHO"),
                Optional.of("true"), Optional.of("true"), Optional.of("true"),Optional.of("Smartphones"),Optional.of("Smartphones"),"","","",Optional.of("true"),Optional.of("true"),Optional.of("true"),Optional.of("55571"),Optional.of(true),Optional.of("Y"),Optional.of(false),Optional.of(false),Optional.of(true),Optional.of("false"),Optional.of(true),Optional.of("1792"),Optional.of("123456"),httpHeader,Optional.of(true),Optional.of("36"));
        StepVerifier.create(response3).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void test_clearAndContinue_addDevice_withPastDue() throws JsonParseException, JsonMappingException, IOException {
        String sampleUIresponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CalculateMultilineTaxUIResponse.json", testFileLocation);
        ServerHttpResponse httpResponse = Mockito.mock(ServerHttpResponse.class);
        CartRedisData sampleRedisData =new CartRedisData();
        sampleRedisData.setIntendType("NSE");
        Lines lines1=new Lines();
        lines1.setCurrentDeviceID("123");
        List<Lines> lines=new ArrayList<>();
        lines.add(lines1);
        sampleRedisData.setLines(lines);
        sampleRedisData.setDepletionType("depl");sampleRedisData.setChannelId("VZW-ACSS");sampleRedisData.setCreditAppNum("1234567890");sampleRedisData.setCartCreator("nse");
        sampleRedisData.setAccountNumber("1234567890");
        sampleRedisData.setMtn("123456789");
        sampleRedisData.setProcessingMTN("12345678");
        sampleRedisData.setExistingCase("123456789");
        DeviceCartInfo deviceCartInfo=new DeviceCartInfo();
        deviceCartInfo.setCartId("1234567890");
        deviceCartInfo.setCaseId("12345");
        sampleRedisData.setDeviceCartInfo(deviceCartInfo);
        UpdateTradeInOfferUIRequest sampleRequest = null;
        AddDeviceUIResponse sampleResponse = new AddDeviceUIResponse();
        AddDeviceServiceBody serviceBody=new AddDeviceServiceBody();
        AddDeviceServiceResponse serviceResponse=new AddDeviceServiceResponse();
        AddDeviceContext context=new AddDeviceContext();
        CartServiceCartInfo cartInfo=new CartServiceCartInfo();
        cartInfo.setCartId("1234");
        context.setCartInfo(cartInfo);
        context.setCaseId("12345");
        Line line1=new Line();
        line1.setMtn("123456");
        Line line2=new Line();
        line2.setMtn("123456");
        Line[] linesc= {line1,line2};
        context.setLines(linesc);
        CartServiceContextInfo contextInfo=new CartServiceContextInfo();
        contextInfo.setProcessStep("step");
        context.setContextInfo(contextInfo);
        CartServiceCustomerInfo customerInfo=new CartServiceCustomerInfo();
        context.setCustomerInfo(customerInfo);
        ShowAALPromoIntercept showAALPromoIntercept=new ShowAALPromoIntercept();
        showAALPromoIntercept.setMyOfferEligibile(true);
        context.setShowAALPromoIntercept(showAALPromoIntercept);
        serviceResponse.setContext(context);
        serviceBody.setServiceResponse(serviceResponse);
        sampleResponse.setServiceBody(serviceBody);
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
        when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(sampleResponse));
        StepVerifier.create(helper.addDeviceClearAndContinue(sampleRedisData,"SOP-329-E01","20ae6bcb-1150-4d16-99dd-14b7d9f128c7","VZW-DOTCOM",httpResponse,null)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }
}
