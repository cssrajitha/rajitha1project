package onevz.soe.cart.bpm.helper;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.helper.SetupAndGoHelper;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.OrderConfirmationCXPResponse;
import onevz.soe.cart.responses.SUAGSelectionDetailsUIResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.util.SourceFileReaderUtil;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.util.ArrayList;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {CartServiceTestConfig.class})
public class SetupAndGoHelperTest {

    @InjectMocks
    private SetupAndGoHelper helper;

    @Mock
    private CartServiceCXPServices cxpServices;

    @Mock
    private RedisHelper redisHelper;

    @Mock
    private ObjectMapper mockMapper;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private SourceFileReaderUtil sourceFileReaderUtil;

    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;

    @Test
    public void test_setupAndGo_success() throws IOException {
        String fileName = "suag-linedetail-response.json";
        ReflectionTestUtils.setField(helper, "mceExcludedSkus", new ArrayList<>());
        OrderConfirmationCXPResponse cxpResponse = createOrderConfirmationCXPResponseObject(fileName);
        CartRedisData cartRedisData = new CartRedisData();
        cartRedisData.setCartId("abcdefghijklmmnopqrstuvwxyz-1234");
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(cartRedisData));
        Mockito.when(cxpServices.getOrderConfirmationData(Mockito.anyString())).thenReturn(Mono.just(cxpResponse));
        Mono<SUAGSelectionDetailsUIResponse> response = helper.getSUAGSelectionDetails();
        StepVerifier.create(response).assertNext(res ->{
            Assert.assertNotNull(res.getData());
            Assert.assertNotNull(res.getData().getSuagDetails());
        }).expectComplete().verify();
    }

    @Test
    public void test_setupAndGo_noCartInCache() throws IOException {
        String fileName = "suag-linedetail-response.json";
        ReflectionTestUtils.setField(helper, "mceExcludedSkus", new ArrayList<>());
        OrderConfirmationCXPResponse cxpResponse = createOrderConfirmationCXPResponseObject(fileName);
        CartRedisData cartRedisData = new CartRedisData();
        cartRedisData.setCartId(null);
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(cartRedisData));
        Mockito.when(cxpServices.getOrderConfirmationData(Mockito.anyString())).thenReturn(Mono.just(cxpResponse));
        Mono<SUAGSelectionDetailsUIResponse> response = helper.getSUAGSelectionDetails();
        StepVerifier.create(response).assertNext(res ->{
            Assert.assertNotNull(res.getErrors());
        }).expectComplete().verify();
    }

    @Test
    public void test_setupAndGo_errorResponse() throws JsonProcessingException {
        String fileName = "ErrorResponse.json";
        OrderConfirmationCXPResponse cxpResponse = createOrderConfirmationCXPResponseObject(fileName);
        CartRedisData cartRedisData = new CartRedisData();
        cartRedisData.setCartId("abcdefghijklmmnopqrstuvwxyz-1234");
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(cartRedisData));
        Mockito.when(cxpServices.getOrderConfirmationData(Mockito.anyString())).thenReturn(Mono.just(cxpResponse));
        Mono<SUAGSelectionDetailsUIResponse> response = helper.getSUAGSelectionDetails();
        StepVerifier.create(response).assertNext(Assert::assertNotNull).verifyComplete();
    }

    @Test
    public void test_setupAndGo_No_cartItems() throws JsonProcessingException {
        String fileName = "shopping-graphql-line-no-cart-item.json";
        OrderConfirmationCXPResponse cxpResponse = createOrderConfirmationCXPResponseObject(fileName);
        CartRedisData cartRedisData = new CartRedisData();
        cartRedisData.setCartId("abcdefghijklmmnopqrstuvwxyz-1234");
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(cartRedisData));
        Mockito.when(cxpServices.getOrderConfirmationData(Mockito.anyString())).thenReturn(Mono.just(cxpResponse));
        Mono<SUAGSelectionDetailsUIResponse> response = helper.getSUAGSelectionDetails();
        StepVerifier.create(response).assertNext(Assert::assertNotNull).verifyComplete();
    }

    @Test
    public void test_setupAndGo_comboOrder_cartItems() throws JsonProcessingException {
        ReflectionTestUtils.setField(helper, "mceExcludedSkus", new ArrayList<>());
        String fileName = "shopping-graphql-line-combo-order.json";
        OrderConfirmationCXPResponse cxpResponse = createOrderConfirmationCXPResponseObject(fileName);
        CartRedisData cartRedisData = new CartRedisData();
        cartRedisData.setCartId("abcdefghijklmmnopqrstuvwxyz-1234");
        Mockito.when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(cartRedisData));
        Mockito.when(cxpServices.getOrderConfirmationData(Mockito.anyString())).thenReturn(Mono.just(cxpResponse));
        Mono<SUAGSelectionDetailsUIResponse> response = helper.getSUAGSelectionDetails();
        StepVerifier.create(response).assertNext(Assert::assertNotNull).verifyComplete();
    }

    private OrderConfirmationCXPResponse createOrderConfirmationCXPResponseObject(String fileName) throws JsonProcessingException {
        String file = sourceFileReaderUtil.readFile(fileName, testFileLocation);
        return objectMapper.readValue(file, OrderConfirmationCXPResponse.class);

    }

}
