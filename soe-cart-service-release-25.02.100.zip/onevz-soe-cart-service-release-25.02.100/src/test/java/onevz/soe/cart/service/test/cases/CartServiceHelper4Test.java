package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.cxp.feature.ConfigurationProfile;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper2;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper3;
import onevz.soe.cart.bpm.service.CartServiceBPMServices;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.cxp.helper.CartServiceCxpHelper2;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.model.assignMtn.AssignMtnData;
import onevz.soe.cart.model.assignMtn.AssignMtnServiceBody;
import onevz.soe.cart.model.common.CartServiceServiceHeader;
import onevz.soe.cart.requests.AssignMtnPEGARequest;
import onevz.soe.cart.responses.AssignMtnPEGAResponse;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.FiveGAddressRedisData;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.common.CartInfo;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(UpdateCartHelper.class)
public class CartServiceHelper4Test {


    @Autowired
    private UpdateCartHelper helper;

    @MockBean
    private CartServiceCxpHelper2 cxpHelper2;

    @MockBean
    private CartServiceBpmHelper2 bpmHelper2;

    @MockBean
    private CartServiceBpmHelper3 bpmHelper3;

    @MockBean
    private RedisHelper redisHelper;

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;

    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;

    @MockBean
    CartServiceBPMServices bpmServices;
    @MockBean
    FeatureFlagHelper featureFlagHelper;

    @Test
    public void addE911AddressHelperTest1() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/E911AddressUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/E911AddressUIRequest1.json", testFileLocation);
        E911AddressUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, E911AddressUIRequest.class);
        E911AddressUIResponse sampleResponse = mapper.readValue(sampleResponseString, E911AddressUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData64.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addE911Address(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        E911AddressUIResponse expectedResponse = sampleResponse;
        Mono<E911AddressUIResponse> response = helper.addE911Address(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addE911AddressHelperTest2() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/E911AddressUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/E911AddressUIRequest1.json", testFileLocation);
        E911AddressUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, E911AddressUIRequest.class);
        E911AddressUIResponse sampleResponse = mapper.readValue(sampleResponseString, E911AddressUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData65.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addE911Address(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        E911AddressUIResponse expectedResponse = sampleResponse;
        Mono<E911AddressUIResponse> response = helper.addE911Address(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addE911AddressHelperTest3() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/E911AddressUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/E911AddressUIRequest2.json", testFileLocation);
        E911AddressUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, E911AddressUIRequest.class);
        E911AddressUIResponse sampleResponse = mapper.readValue(sampleResponseString, E911AddressUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData66.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addE911Address(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        E911AddressUIResponse expectedResponse = sampleResponse;
        Mono<E911AddressUIResponse> response = helper.addE911Address(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addE911AddressHelperTest4() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/E911AddressUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/E911AddressUIRequest2.json", testFileLocation);
        E911AddressUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, E911AddressUIRequest.class);
        E911AddressUIResponse sampleResponse = mapper.readValue(sampleResponseString, E911AddressUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData67.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleResponse = mapper.readValue(sampleResponseString, E911AddressUIResponse.class);
        when(bpmHelper2.addE911Address(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        E911AddressUIResponse expectedResponse = sampleResponse;
        Mono<E911AddressUIResponse> response = helper.addE911Address(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addE911AddressHelperTest5() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/E911AddressUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/E911AddressUIRequest3.json", testFileLocation);
        E911AddressUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, E911AddressUIRequest.class);
        E911AddressUIResponse sampleResponse = mapper.readValue(sampleResponseString, E911AddressUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData67.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addE911Address(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        E911AddressUIResponse expectedResponse = sampleResponse;
        Mono<E911AddressUIResponse> response = helper.addE911Address(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addE911AddressHelperTest6() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/E911AddressUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/E911AddressUIRequest4.json", testFileLocation);
        E911AddressUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, E911AddressUIRequest.class);
        E911AddressUIResponse sampleResponse = mapper.readValue(sampleResponseString, E911AddressUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData67.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addE911Address(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        E911AddressUIResponse expectedResponse = sampleResponse;
        Mono<E911AddressUIResponse> response = helper.addE911Address(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addE911AddressHelperTest7() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/E911AddressUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/E911AddressUIRequest5.json", testFileLocation);
        E911AddressUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, E911AddressUIRequest.class);
        E911AddressUIResponse sampleResponse = mapper.readValue(sampleResponseString, E911AddressUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData68.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addE911Address(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        E911AddressUIResponse expectedResponse = sampleResponse;
        Mono<E911AddressUIResponse> response = helper.addE911Address(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addE911AddressHelperTest8() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/E911AddressUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/E911AddressUIRequest6.json", testFileLocation);
        E911AddressUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, E911AddressUIRequest.class);
        E911AddressUIResponse sampleResponse = mapper.readValue(sampleResponseString, E911AddressUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData69.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addE911Address(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        E911AddressUIResponse expectedResponse = sampleResponse;
        Mono<E911AddressUIResponse> response = helper.addE911Address(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addE911AddressHelperTest9() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/E911AddressUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/E911AddressUIRequest7.json", testFileLocation);
        E911AddressUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, E911AddressUIRequest.class);
        E911AddressUIResponse sampleResponse = mapper.readValue(sampleResponseString, E911AddressUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData70.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addE911Address(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        E911AddressUIResponse expectedResponse = sampleResponse;
        Mono<E911AddressUIResponse> response = helper.addE911Address(sampleUIRequest);
        StepVerifier.create(response).expectError().verify();
    }

    @Test
    public void addE911AddressHelperTest10() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/E911AddressUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/E911AddressUIRequest8.json", testFileLocation);
        E911AddressUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, E911AddressUIRequest.class);
        E911AddressUIResponse sampleResponse = mapper.readValue(sampleResponseString, E911AddressUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData71.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addE911Address(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        E911AddressUIResponse expectedResponse = sampleResponse;
        Mono<E911AddressUIResponse> response = helper.addE911Address(sampleUIRequest);
        StepVerifier.create(response).expectError().verify();
    }

    @Test
    public void instantCreditDownPaymentTest1() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InstantCreditDownPaymentUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InstantCreditDownPaymentUIResponse.json", testFileLocation);
        InstantCreditDownPaymentUIResponse sampleResponse =  mapper.readValue(sampleResponseString, InstantCreditDownPaymentUIResponse.class);
        InstantCreditDownPaymentUIRequest sampleUIRequest =  mapper.readValue(sampleUIRequestString, InstantCreditDownPaymentUIRequest.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData72.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addInstantCreditDownPayment(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        InstantCreditDownPaymentUIResponse expectedResponse = sampleResponse;
        Mono<InstantCreditDownPaymentUIResponse> response = helper.addInstantCreditDownPayment(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void instantCreditDownPaymentTest2() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InstantCreditDownPaymentUIRequest2.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InstantCreditDownPaymentUIResponse.json", testFileLocation);
        InstantCreditDownPaymentUIResponse sampleResponse =  mapper.readValue(sampleResponseString, InstantCreditDownPaymentUIResponse.class);
        InstantCreditDownPaymentUIRequest sampleUIRequest =  mapper.readValue(sampleUIRequestString, InstantCreditDownPaymentUIRequest.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData72.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addInstantCreditDownPayment(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        InstantCreditDownPaymentUIResponse expectedResponse = sampleResponse;
        Mono<InstantCreditDownPaymentUIResponse> response = helper.addInstantCreditDownPayment(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void instantCreditDownPaymentTest3() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InstantCreditDownPaymentUIRequest3.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InstantCreditDownPaymentUIResponse.json", testFileLocation);
        InstantCreditDownPaymentUIResponse sampleResponse =  mapper.readValue(sampleResponseString, InstantCreditDownPaymentUIResponse.class);
        InstantCreditDownPaymentUIRequest sampleUIRequest =  mapper.readValue(sampleUIRequestString, InstantCreditDownPaymentUIRequest.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData72.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addInstantCreditDownPayment(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        InstantCreditDownPaymentUIResponse expectedResponse = sampleResponse;
        Mono<InstantCreditDownPaymentUIResponse> response = helper.addInstantCreditDownPayment(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void instantCreditDownPaymentTest4() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InstantCreditDownPaymentUIRequest3.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/InstantCreditDownPaymentUIResponse.json", testFileLocation);
        InstantCreditDownPaymentUIResponse sampleResponse =  mapper.readValue(sampleResponseString, InstantCreditDownPaymentUIResponse.class);
        InstantCreditDownPaymentUIRequest sampleUIRequest =  mapper.readValue(sampleUIRequestString, InstantCreditDownPaymentUIRequest.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData36.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addInstantCreditDownPayment(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        InstantCreditDownPaymentUIResponse expectedResponse = sampleResponse;
        Mono<InstantCreditDownPaymentUIResponse> response = helper.addInstantCreditDownPayment(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateSalesRepAndLocationHelperTest1() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/SalesRepAndLocationCodeUIRequest1.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/SalesRepAndLocationCodeUIResponse.json", testFileLocation);
        SalesRepAndLocationCodeUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, SalesRepAndLocationCodeUIRequest.class);
        SalesRepAndLocationCodeUIResponse sampleResponse =  mapper.readValue(sampleUIResponseString, SalesRepAndLocationCodeUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData73.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper3.updateSalesRepAndLocationCode(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        SalesRepAndLocationCodeUIResponse expectedResponse = sampleResponse;
        Mono<SalesRepAndLocationCodeUIResponse> response = helper.updateSalesRepAndLocationCode(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateSalesRepAndLocationHelperTest2() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/SalesRepAndLocationCodeUIRequest3.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/SalesRepAndLocationCodeUIResponse.json", testFileLocation);
        SalesRepAndLocationCodeUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, SalesRepAndLocationCodeUIRequest.class);
        SalesRepAndLocationCodeUIResponse sampleResponse =  mapper.readValue(sampleUIResponseString, SalesRepAndLocationCodeUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData74.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper3.updateSalesRepAndLocationCode(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        SalesRepAndLocationCodeUIResponse expectedResponse = sampleResponse;
        Mono<SalesRepAndLocationCodeUIResponse> response = helper.updateSalesRepAndLocationCode(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateSalesRepAndLocationHelperTest3() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/SalesRepAndLocationCodeUIRequest2.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/SalesRepAndLocationCodeUIResponse.json", testFileLocation);
        SalesRepAndLocationCodeUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, SalesRepAndLocationCodeUIRequest.class);
        SalesRepAndLocationCodeUIResponse sampleResponse =  mapper.readValue(sampleUIResponseString, SalesRepAndLocationCodeUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData75.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper3.updateSalesRepAndLocationCode(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        SalesRepAndLocationCodeUIResponse expectedResponse = sampleResponse;
        Mono<SalesRepAndLocationCodeUIResponse> response = helper.updateSalesRepAndLocationCode(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateSalesRepAndLocationHelperTest4() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/SalesRepAndLocationCodeUIRequest4.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/SalesRepAndLocationCodeUIResponse.json", testFileLocation);
        SalesRepAndLocationCodeUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, SalesRepAndLocationCodeUIRequest.class);
        SalesRepAndLocationCodeUIResponse sampleResponse =  mapper.readValue(sampleUIResponseString, SalesRepAndLocationCodeUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData75.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper3.updateSalesRepAndLocationCode(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        SalesRepAndLocationCodeUIResponse expectedResponse = sampleResponse;
        Mono<SalesRepAndLocationCodeUIResponse> response = helper.updateSalesRepAndLocationCode(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateSalesRepAndLocationHelperTest5() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/SalesRepAndLocationCodeUIRequest5.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/SalesRepAndLocationCodeUIResponse.json", testFileLocation);
        SalesRepAndLocationCodeUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, SalesRepAndLocationCodeUIRequest.class);
        SalesRepAndLocationCodeUIResponse sampleResponse =  mapper.readValue(sampleUIResponseString, SalesRepAndLocationCodeUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData75.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper3.updateSalesRepAndLocationCode(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        SalesRepAndLocationCodeUIResponse expectedResponse = sampleResponse;
        Mono<SalesRepAndLocationCodeUIResponse> response = helper.updateSalesRepAndLocationCode(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void macAddressHelperTest1() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/MyOffersCXPRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/MyOffersCXPResponse.json", testFileLocation);
        MacAddressUIRequest sampleRequest = mapper.readValue(sampleRequestString, MacAddressUIRequest.class);
        MacAddressUIResponse sampleResponse = mapper.readValue(sampleResponseString, MacAddressUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData76.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<MacAddressUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(cxpHelper2.updateMacAddress(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        MacAddressUIResponse expectedResponse = sampleResponse;
        Mono<MacAddressUIResponse> response = helper.updateMacAddress(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void effectiveDateOverrideHelperTest1() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/EffectiveDateOverrideUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/EffectiveDateOverrideUIRequest1.json", testFileLocation);
        EffectiveDateOverrideUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, EffectiveDateOverrideUIRequest.class);
        EffectiveDateOverrideUIResponse sampleResponse =  mapper.readValue(sampleResponseString, EffectiveDateOverrideUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData77.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.effectiveDateOverride(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        EffectiveDateOverrideUIResponse expectedResponse = sampleResponse;
        Mono<EffectiveDateOverrideUIResponse> response = helper.effectiveDateOverride(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void effectiveDateOverrideHelperTest2() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/EffectiveDateOverrideUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/EffectiveDateOverrideUIRequest2.json", testFileLocation);
        EffectiveDateOverrideUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, EffectiveDateOverrideUIRequest.class);
        EffectiveDateOverrideUIResponse sampleResponse =  mapper.readValue(sampleResponseString, EffectiveDateOverrideUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData77.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.effectiveDateOverride(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        EffectiveDateOverrideUIResponse expectedResponse = sampleResponse;
        Mono<EffectiveDateOverrideUIResponse> response = helper.effectiveDateOverride(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void effectiveDateOverrideHelperTest3() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/EffectiveDateOverrideUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/EffectiveDateOverrideUIRequest3.json", testFileLocation);
        EffectiveDateOverrideUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, EffectiveDateOverrideUIRequest.class);
        EffectiveDateOverrideUIResponse sampleResponse =  mapper.readValue(sampleResponseString, EffectiveDateOverrideUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData77.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.effectiveDateOverride(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        EffectiveDateOverrideUIResponse expectedResponse = sampleResponse;
        Mono<EffectiveDateOverrideUIResponse> response = helper.effectiveDateOverride(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void effectiveDateOverrideHelperTest4() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/EffectiveDateOverrideUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/EffectiveDateOverrideUIRequest3.json", testFileLocation);
        EffectiveDateOverrideUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, EffectiveDateOverrideUIRequest.class);
        EffectiveDateOverrideUIResponse sampleResponse =  mapper.readValue(sampleResponseString, EffectiveDateOverrideUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData78.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.effectiveDateOverride(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        EffectiveDateOverrideUIResponse expectedResponse = sampleResponse;
        Mono<EffectiveDateOverrideUIResponse> response = helper.effectiveDateOverride(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void assignMTNHelperTest1() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIRequest2.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIResponse.json", testFileLocation);
        AssignMtnUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, AssignMtnUIRequest.class);
        AssignMtnUIResponse sampleResponse = mapper.readValue(sampleResponseString, AssignMtnUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData2.json", testFileLocation);;
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<AssignMtnUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.assignMtn(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CartRedisData()));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(new FiveGAddressRedisData()));
        AssignMtnUIResponse expectedResponse = sampleResponse;
        Mono<AssignMtnUIResponse> response = helper.assignMtn(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void assignMTNHelperTestUITampering() throws IOException, SOEHTTPException {
        ReflectionTestUtils.setField(helper, "storeNpaNxxInCache", true);
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIRequest2.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIResponse.json", testFileLocation);
        AssignMtnUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, AssignMtnUIRequest.class);
        sampleUIRequest.setPath(CartConstants.NSE_ASSIGN_MTN_URL);
        AssignMtnUIResponse sampleResponse = mapper.readValue(sampleResponseString, AssignMtnUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData2.json", testFileLocation);;
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        sampleRedisData.setNpanxxlist(List.of("1234"));
        sampleRedisData.setCartId("123");
        Mono<AssignMtnUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.assignMtn(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(new FiveGAddressRedisData()));
        when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CartRedisData()));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        AssignMtnUIResponse expectedResponse = sampleResponse;
        Mono<AssignMtnUIResponse> response = helper.assignMtn(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void assignMTNHelperTest2() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIResponse.json", testFileLocation);
        AssignMtnUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, AssignMtnUIRequest.class);
        AssignMtnUIResponse sampleResponse = mapper.readValue(sampleResponseString, AssignMtnUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData79.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<AssignMtnUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.assignMtn(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CartRedisData()));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("true"));
        when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(new FiveGAddressRedisData()));
        AssignMtnUIResponse expectedResponse = sampleResponse;
        Mono<AssignMtnUIResponse> response = helper.assignMtn(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void assignMTNHelperTest3() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIResponse.json", testFileLocation);
        AssignMtnUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, AssignMtnUIRequest.class);
        AssignMtnUIResponse sampleResponse = mapper.readValue(sampleResponseString, AssignMtnUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData80.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<AssignMtnUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.assignMtn(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CartRedisData()));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just(""));
        when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(new FiveGAddressRedisData()));
        AssignMtnUIResponse expectedResponse = sampleResponse;
        Mono<AssignMtnUIResponse> response = helper.assignMtn(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void assignMTNHelperTest4() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIRequest3.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIResponse.json", testFileLocation);
        AssignMtnUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, AssignMtnUIRequest.class);
        AssignMtnUIResponse sampleResponse = mapper.readValue(sampleResponseString, AssignMtnUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData80.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<AssignMtnUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.assignMtn(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CartRedisData()));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just(""));
        when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(new FiveGAddressRedisData()));
        AssignMtnUIResponse expectedResponse = sampleResponse;
        Mono<AssignMtnUIResponse> response = helper.assignMtn(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void assignMTNHelperTest5() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIRequest4.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIResponse.json", testFileLocation);
        AssignMtnUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, AssignMtnUIRequest.class);
        AssignMtnUIResponse sampleResponse = mapper.readValue(sampleResponseString, AssignMtnUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData81.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<AssignMtnUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.assignMtn(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CartRedisData()));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just(""));
        when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(new FiveGAddressRedisData()));
        AssignMtnUIResponse expectedResponse = sampleResponse;
        Mono<AssignMtnUIResponse> response = helper.assignMtn(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void assignMTNHelperTest6() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIRequest5.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIResponse.json", testFileLocation);
        AssignMtnUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, AssignMtnUIRequest.class);
        AssignMtnUIResponse sampleResponse = mapper.readValue(sampleResponseString, AssignMtnUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData82.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<AssignMtnUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.assignMtn(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CartRedisData()));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just(""));
        when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(new FiveGAddressRedisData()));
        AssignMtnUIResponse expectedResponse = sampleResponse;
        Mono<AssignMtnUIResponse> response = helper.assignMtn(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void assignMTNHelperTest7() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIRequest6.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIResponse.json", testFileLocation);
        AssignMtnUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, AssignMtnUIRequest.class);
        AssignMtnUIResponse sampleResponse = mapper.readValue(sampleResponseString, AssignMtnUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData82.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<AssignMtnUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.assignMtn(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CartRedisData()));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just(""));
        when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(new FiveGAddressRedisData()));
        AssignMtnUIResponse expectedResponse = sampleResponse;
        Mono<AssignMtnUIResponse> response = helper.assignMtn(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void assignMTNHelperTest8() throws IOException, SOEHTTPException {
        ReflectionTestUtils.setField(helper, "enableSecurityForCart", true);
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIRequest7.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIResponse.json", testFileLocation);
        AssignMtnUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, AssignMtnUIRequest.class);
        AssignMtnUIResponse sampleResponse = mapper.readValue(sampleResponseString, AssignMtnUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData83.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<AssignMtnUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(new FiveGAddressRedisData()));
        when(bpmHelper2.assignMtn(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CartRedisData()));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        AssignMtnUIResponse expectedResponse = sampleResponse;
        Mono<AssignMtnUIResponse> response = helper.assignMtn(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void assignMTNHelperTest9() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIRequest8.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIResponse.json", testFileLocation);
        AssignMtnUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, AssignMtnUIRequest.class);
        AssignMtnUIResponse sampleResponse = mapper.readValue(sampleResponseString, AssignMtnUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData83.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(new FiveGAddressRedisData()));
        Mono<AssignMtnUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.assignMtn(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CartRedisData()));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        AssignMtnUIResponse expectedResponse = sampleResponse;
        Mono<AssignMtnUIResponse> response = helper.assignMtn(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void assignMTNHelperTest10() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIRequest9.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIResponse.json", testFileLocation);
        AssignMtnUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, AssignMtnUIRequest.class);
        AssignMtnUIResponse sampleResponse = mapper.readValue(sampleResponseString, AssignMtnUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData83.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<AssignMtnUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.assignMtn(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CartRedisData()));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        AssignMtnUIResponse expectedResponse = sampleResponse;
        Mono<AssignMtnUIResponse> response = helper.assignMtn(sampleUIRequest);
        StepVerifier.create(response).expectError().verify();
    }

    @Test
    public void assignMTNHelperTest11() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIRequest9.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIResponse.json", testFileLocation);
        AssignMtnUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, AssignMtnUIRequest.class);
        AssignMtnUIResponse sampleResponse = mapper.readValue(sampleResponseString, AssignMtnUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData84.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<AssignMtnUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.assignMtn(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CartRedisData()));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(new FiveGAddressRedisData()));
        AssignMtnUIResponse expectedResponse = sampleResponse;
        Mono<AssignMtnUIResponse> response = helper.assignMtn(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void assignMTNHelperTest12() throws IOException, SOEHTTPException {
        ReflectionTestUtils.setField(helper, "enableSecurityForCart", false);
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIRequest7.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIResponse.json", testFileLocation);
        AssignMtnUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, AssignMtnUIRequest.class);
        AssignMtnUIResponse sampleResponse = mapper.readValue(sampleResponseString, AssignMtnUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData83.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<AssignMtnUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.assignMtn(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CartRedisData()));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(new FiveGAddressRedisData()));
        AssignMtnUIResponse expectedResponse = sampleResponse;
        Mono<AssignMtnUIResponse> response = helper.assignMtn(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void assignMTNHelperTest13() throws IOException, SOEHTTPException {
        ReflectionTestUtils.setField(helper, "enableSecurityForCart", false);
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIRequest7.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIResponse1.json", testFileLocation);
        AssignMtnUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, AssignMtnUIRequest.class);
        AssignMtnUIResponse sampleResponse = mapper.readValue(sampleResponseString, AssignMtnUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData83.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<AssignMtnUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.assignMtn(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CartRedisData()));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(new FiveGAddressRedisData()));
        AssignMtnUIResponse expectedResponse = sampleResponse;
        Mono<AssignMtnUIResponse> response = helper.assignMtn(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void assignMTNHelperTest14() throws IOException, SOEHTTPException {
        ReflectionTestUtils.setField(helper, "enableSecurityForCart", false);
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIRequest7.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIResponse2.json", testFileLocation);
        AssignMtnUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, AssignMtnUIRequest.class);
        AssignMtnUIResponse sampleResponse = mapper.readValue(sampleResponseString, AssignMtnUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData83.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<AssignMtnUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.assignMtn(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CartRedisData()));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(new FiveGAddressRedisData()));
        AssignMtnUIResponse expectedResponse = sampleResponse;
        Mono<AssignMtnUIResponse> response = helper.assignMtn(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void assignMTNHelperTest15() throws IOException, SOEHTTPException {
        ReflectionTestUtils.setField(helper, "enableSecurityForCart", false);
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIRequest7.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AssignMtnUIResponse.json", testFileLocation);
        AssignMtnUIRequest sampleUIRequest = mapper.readValue(sampleRequestString, AssignMtnUIRequest.class);
        AssignMtnUIResponse sampleResponse = mapper.readValue(sampleResponseString, AssignMtnUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData85.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<AssignMtnUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.assignMtn(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.upsertDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CartRedisData()));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        when(redisHelper.getFiveGAddressFromRedis()).thenReturn(Mono.just(new FiveGAddressRedisData()));
        AssignMtnUIResponse expectedResponse = sampleResponse;
        Mono<AssignMtnUIResponse> response = helper.assignMtn(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void assignMtnTestCoverage() throws SOEHTTPException {
        AssignMtnUIRequest uiRequest = new AssignMtnUIRequest();
        uiRequest.setCartInfo(new CartInfo());
        uiRequest.setData(new AssignMtnData());
        uiRequest.getData().setLines(new ArrayList<>());
        uiRequest.setPredictivePrefetchEnabled(true);
        AssignMtnPEGAResponse addPromoIntentPEGAResponse = new AssignMtnPEGAResponse();
        addPromoIntentPEGAResponse.setServiceBody(new AssignMtnServiceBody());
        addPromoIntentPEGAResponse.setServiceHeader(new CartServiceServiceHeader());
        Mockito.when(featureFlagHelper.fetchDigitalPegaPredictivePrefetchFFlag()).thenReturn(Mono.just(false));
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(new ConfigurationProfile()));
        when(bpmServices.assignMtn(new AssignMtnPEGARequest())).thenReturn(Mono.just(new AssignMtnPEGAResponse()));
        StepVerifier.create(bpmHelper2.assignMtn(uiRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete();

        uiRequest.setPredictivePrefetchEnabled(true);
        Mockito.when(featureFlagHelper.fetchDigitalPegaPredictivePrefetchFFlag()).thenReturn(Mono.just(true));
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(new ConfigurationProfile()));
        when(bpmServices.assignMtn(new AssignMtnPEGARequest())).thenReturn(Mono.just(addPromoIntentPEGAResponse));
        StepVerifier.create(bpmHelper2.assignMtn(uiRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete();

        uiRequest.setPredictivePrefetchEnabled(false);
        Mockito.when(featureFlagHelper.fetchDigitalPegaPredictivePrefetchFFlag()).thenReturn(Mono.just(true));
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(new ConfigurationProfile()));
        when(bpmServices.assignMtn(new AssignMtnPEGARequest())).thenReturn(Mono.just(addPromoIntentPEGAResponse));
        StepVerifier.create(bpmHelper2.assignMtn(uiRequest)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete();
    }

    @Test
    public void deassignMTNHelperTest1() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DeassignMtnUIRequest2.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DeassignMtnUIResponse.json", testFileLocation);
        DeassignMtnUIRequest sampleRequest =  mapper.readValue(sampleRequestString, DeassignMtnUIRequest.class);
        DeassignMtnUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeassignMtnUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData86.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<DeassignMtnUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.deassignMtn(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        DeassignMtnUIResponse expectedResponse = sampleResponse;
        Mono<DeassignMtnUIResponse> response = helper.deassignMtn(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void deassignMTNHelperTest2() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DeassignMtnUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DeassignMtnUIResponse.json", testFileLocation);
        DeassignMtnUIRequest sampleRequest =  mapper.readValue(sampleRequestString, DeassignMtnUIRequest.class);
        DeassignMtnUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeassignMtnUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData86.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<DeassignMtnUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.deassignMtn(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        DeassignMtnUIResponse expectedResponse = sampleResponse;
        Mono<DeassignMtnUIResponse> response = helper.deassignMtn(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void deassignMTNHelperTest3() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DeassignMtnUIRequest3.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DeassignMtnUIResponse.json", testFileLocation);
        DeassignMtnUIRequest sampleRequest =  mapper.readValue(sampleRequestString, DeassignMtnUIRequest.class);
        DeassignMtnUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeassignMtnUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData86.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<DeassignMtnUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.deassignMtn(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        DeassignMtnUIResponse expectedResponse = sampleResponse;
        Mono<DeassignMtnUIResponse> response = helper.deassignMtn(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void deassignMTNHelperTest4() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DeassignMtnUIRequest4.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DeassignMtnUIResponse.json", testFileLocation);
        DeassignMtnUIRequest sampleRequest =  mapper.readValue(sampleRequestString, DeassignMtnUIRequest.class);
        DeassignMtnUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeassignMtnUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData87.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<DeassignMtnUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.deassignMtn(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        DeassignMtnUIResponse expectedResponse = sampleResponse;
        Mono<DeassignMtnUIResponse> response = helper.deassignMtn(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void deassignMTNHelperTest5() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DeassignMtnUIRequest5.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DeassignMtnUIResponse.json", testFileLocation);
        DeassignMtnUIRequest sampleRequest =  mapper.readValue(sampleRequestString, DeassignMtnUIRequest.class);
        DeassignMtnUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeassignMtnUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData88.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<DeassignMtnUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.deassignMtn(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        DeassignMtnUIResponse expectedResponse = sampleResponse;
        Mono<DeassignMtnUIResponse> response = helper.deassignMtn(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void deassignMTNHelperTes6() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DeassignMtnUIRequest6.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DeassignMtnUIResponse.json", testFileLocation);
        DeassignMtnUIRequest sampleRequest =  mapper.readValue(sampleRequestString, DeassignMtnUIRequest.class);
        DeassignMtnUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeassignMtnUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData88.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<DeassignMtnUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.deassignMtn(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        DeassignMtnUIResponse expectedResponse = sampleResponse;
        Mono<DeassignMtnUIResponse> response = helper.deassignMtn(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void deassignMTNHelperTes7() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DeassignMtnUIRequest7.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DeassignMtnUIResponse.json", testFileLocation);
        DeassignMtnUIRequest sampleRequest =  mapper.readValue(sampleRequestString, DeassignMtnUIRequest.class);
        DeassignMtnUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeassignMtnUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData88.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<DeassignMtnUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.deassignMtn(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        DeassignMtnUIResponse expectedResponse = sampleResponse;
        Mono<DeassignMtnUIResponse> response = helper.deassignMtn(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void deassignMTNHelperTes8() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DeassignMtnUIRequest7.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DeassignMtnUIResponse.json", testFileLocation);
        DeassignMtnUIRequest sampleRequest =  mapper.readValue(sampleRequestString, DeassignMtnUIRequest.class);
        DeassignMtnUIResponse sampleResponse = mapper.readValue(sampleResponseString, DeassignMtnUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData89.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<DeassignMtnUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.deassignMtn(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        DeassignMtnUIResponse expectedResponse = sampleResponse;
        Mono<DeassignMtnUIResponse> response = helper.deassignMtn(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void add5GBulkOrderHelperTest1() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/Add5GBulkOrderUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/Add5GBulkOrderUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData35.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Add5GBulkOrderUIResponse responseServiceMono = mapper.readValue(sampleResponseString, Add5GBulkOrderUIResponse.class);
        Add5GBulkOrderUIRequest UIRequest = mapper.readValue(sampleRequestString, Add5GBulkOrderUIRequest.class);
        Mono<Add5GBulkOrderUIResponse> sampleResponseMono = Mono.just(responseServiceMono);
        when(bpmHelper2.add5GBulkOrder(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Add5GBulkOrderUIResponse expectedResponse = responseServiceMono;
        Mono<Add5GBulkOrderUIResponse> response = helper.add5GBulkOrder(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void add5GBulkOrderHelperTest2() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/Add5GBulkOrderUIRequest2.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/Add5GBulkOrderUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData35.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Add5GBulkOrderUIResponse responseServiceMono = mapper.readValue(sampleResponseString, Add5GBulkOrderUIResponse.class);
        Add5GBulkOrderUIRequest UIRequest = mapper.readValue(sampleRequestString, Add5GBulkOrderUIRequest.class);
        Mono<Add5GBulkOrderUIResponse> sampleResponseMono = Mono.just(responseServiceMono);
        when(bpmHelper2.add5GBulkOrder(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Add5GBulkOrderUIResponse expectedResponse = responseServiceMono;
        Mono<Add5GBulkOrderUIResponse> response = helper.add5GBulkOrder(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void add5GBulkOrderHelperTest3() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/Add5GBulkOrderUIRequest3.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/Add5GBulkOrderUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData35.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Add5GBulkOrderUIResponse responseServiceMono = mapper.readValue(sampleResponseString, Add5GBulkOrderUIResponse.class);
        Add5GBulkOrderUIRequest UIRequest = mapper.readValue(sampleRequestString, Add5GBulkOrderUIRequest.class);
        Mono<Add5GBulkOrderUIResponse> sampleResponseMono = Mono.just(responseServiceMono);
        when(bpmHelper2.add5GBulkOrder(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Add5GBulkOrderUIResponse expectedResponse = responseServiceMono;
        Mono<Add5GBulkOrderUIResponse> response = helper.add5GBulkOrder(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void add5GBulkOrderHelperTest4() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/Add5GBulkOrderUIRequest2.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/Add5GBulkOrderUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData36.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Add5GBulkOrderUIResponse responseServiceMono = mapper.readValue(sampleResponseString, Add5GBulkOrderUIResponse.class);
        Add5GBulkOrderUIRequest UIRequest = mapper.readValue(sampleRequestString, Add5GBulkOrderUIRequest.class);
        Mono<Add5GBulkOrderUIResponse> sampleResponseMono = Mono.just(responseServiceMono);
        when(bpmHelper2.add5GBulkOrder(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Add5GBulkOrderUIResponse expectedResponse = responseServiceMono;
        Mono<Add5GBulkOrderUIResponse> response = helper.add5GBulkOrder(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void giftPurchaseHelperTest1() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/GiftPurchaseUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/GiftPurchaseUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        GiftPurchaseUIRequest UIRequest = mapper.readValue(sampleRequestString, GiftPurchaseUIRequest.class);
        GiftPurchaseUIResponse soeResponse = mapper.readValue(sampleResponseString, GiftPurchaseUIResponse.class);
        Mono<GiftPurchaseUIResponse> sampleResponseMono = Mono.just(soeResponse);
        when(cxpHelper2.giftPurchase(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<GiftPurchaseUIResponse> response = helper.giftPurchase(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void manualPairingHelperTest1() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ManualPairingUIRequest1.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveURCForCartUIResponse.json", testFileLocation);
        ManualPairingUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, ManualPairingUIRequest.class);
        ManualPairingUIResponse sampleResponse = mapper.readValue(sampleUIResponseString, ManualPairingUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData90.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper3.manualPairing(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        ManualPairingUIResponse expectedResponse = sampleResponse;
        Mono<ManualPairingUIResponse> response = helper.manualPairing(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void manualPairingHelperTest2() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ManualPairingUIRequest2.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveURCForCartUIResponse.json", testFileLocation);
        ManualPairingUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, ManualPairingUIRequest.class);
        ManualPairingUIResponse sampleResponse = mapper.readValue(sampleUIResponseString, ManualPairingUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData90.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper3.manualPairing(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        ManualPairingUIResponse expectedResponse = sampleResponse;
        Mono<ManualPairingUIResponse> response = helper.manualPairing(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void manualPairingHelperTest3() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ManualPairingUIRequest3.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveURCForCartUIResponse.json", testFileLocation);
        ManualPairingUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, ManualPairingUIRequest.class);
        ManualPairingUIResponse sampleResponse = mapper.readValue(sampleUIResponseString, ManualPairingUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData90.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper3.manualPairing(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        ManualPairingUIResponse expectedResponse = sampleResponse;
        Mono<ManualPairingUIResponse> response = helper.manualPairing(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void manualPairingHelperTest4() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ManualPairingUIRequest3.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveURCForCartUIResponse.json", testFileLocation);
        ManualPairingUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, ManualPairingUIRequest.class);
        ManualPairingUIResponse sampleResponse = mapper.readValue(sampleUIResponseString, ManualPairingUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData91.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper3.manualPairing(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        ManualPairingUIResponse expectedResponse = sampleResponse;
        Mono<ManualPairingUIResponse> response = helper.manualPairing(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void revokeRebatesHelperTest1() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RevokeRebatesUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RevokeRebatesUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData35.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        RevokeRebatesUIRequest UIRequest = mapper.readValue(sampleRequestString, RevokeRebatesUIRequest.class);
        RevokeRebatesUIResponse soeResponse = mapper.readValue(sampleResponseString, RevokeRebatesUIResponse.class);
        Mono<RevokeRebatesUIResponse> sampleResponseMono = Mono.just(soeResponse);
        when(bpmHelper2.revokeRebates(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<RevokeRebatesUIResponse> response = helper.revokeRebates(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void revokeRebatesHelperTest2() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RevokeRebatesUIRequest2.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RevokeRebatesUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData35.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        RevokeRebatesUIRequest UIRequest = mapper.readValue(sampleRequestString, RevokeRebatesUIRequest.class);
        RevokeRebatesUIResponse soeResponse = mapper.readValue(sampleResponseString, RevokeRebatesUIResponse.class);
        Mono<RevokeRebatesUIResponse> sampleResponseMono = Mono.just(soeResponse);
        when(bpmHelper2.revokeRebates(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<RevokeRebatesUIResponse> response = helper.revokeRebates(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void revokeRebatesHelperTest3() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RevokeRebatesUIRequest3.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RevokeRebatesUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData35.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        RevokeRebatesUIRequest UIRequest = mapper.readValue(sampleRequestString, RevokeRebatesUIRequest.class);
        RevokeRebatesUIResponse soeResponse = mapper.readValue(sampleResponseString, RevokeRebatesUIResponse.class);
        Mono<RevokeRebatesUIResponse> sampleResponseMono = Mono.just(soeResponse);
        when(bpmHelper2.revokeRebates(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<RevokeRebatesUIResponse> response = helper.revokeRebates(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void revokeRebatesHelperTest4() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RevokeRebatesUIRequest3.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RevokeRebatesUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData36.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        RevokeRebatesUIRequest UIRequest = mapper.readValue(sampleRequestString, RevokeRebatesUIRequest.class);
        RevokeRebatesUIResponse soeResponse = mapper.readValue(sampleResponseString, RevokeRebatesUIResponse.class);
        Mono<RevokeRebatesUIResponse> sampleResponseMono = Mono.just(soeResponse);
        when(bpmHelper2.revokeRebates(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<RevokeRebatesUIResponse> response = helper.revokeRebates(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updatePortInLaterHelperTest1() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/PortinLaterUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/PortinLaterUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData35.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        PortinLaterUIRequest UIRequest = mapper.readValue(sampleRequestString, PortinLaterUIRequest.class);
        PortinLaterUIResponse soeResponse = mapper.readValue(sampleResponseString, PortinLaterUIResponse.class);
        Mono<PortinLaterUIResponse> sampleResponseMono = Mono.just(soeResponse);
        when(bpmHelper2.updatePortInLater(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<PortinLaterUIResponse> response = helper.updatePortInLater(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updatePortInLaterHelperTest2() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/PortinLaterUIRequest2.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/PortinLaterUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData35.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        PortinLaterUIRequest UIRequest = mapper.readValue(sampleRequestString, PortinLaterUIRequest.class);
        PortinLaterUIResponse soeResponse = mapper.readValue(sampleResponseString, PortinLaterUIResponse.class);
        Mono<PortinLaterUIResponse> sampleResponseMono = Mono.just(soeResponse);
        when(bpmHelper2.updatePortInLater(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<PortinLaterUIResponse> response = helper.updatePortInLater(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updatePortInLaterHelperTest3() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/PortinLaterUIRequest3.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/PortinLaterUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData35.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        PortinLaterUIRequest UIRequest = mapper.readValue(sampleRequestString, PortinLaterUIRequest.class);
        PortinLaterUIResponse soeResponse = mapper.readValue(sampleResponseString, PortinLaterUIResponse.class);
        Mono<PortinLaterUIResponse> sampleResponseMono = Mono.just(soeResponse);
        when(bpmHelper2.updatePortInLater(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<PortinLaterUIResponse> response = helper.updatePortInLater(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void updatePortInLaterHelperTest4() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/PortinLaterUIRequest2.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/PortinLaterUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData36.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        PortinLaterUIRequest UIRequest = mapper.readValue(sampleRequestString, PortinLaterUIRequest.class);
        PortinLaterUIResponse soeResponse = mapper.readValue(sampleResponseString, PortinLaterUIResponse.class);
        Mono<PortinLaterUIResponse> sampleResponseMono = Mono.just(soeResponse);
        when(bpmHelper2.updatePortInLater(Mockito.any())).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<PortinLaterUIResponse> response = helper.updatePortInLater(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void voidOrderHelperTest1() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/VoidOrderUIRequest1.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/VoidOrderUIResponse.json", testFileLocation);
        VoidOrderUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, VoidOrderUIRequest.class);
        VoidOrderUIResponse sampleResponse = mapper.readValue(sampleUIResponseString, VoidOrderUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData92.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.voidOrder(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        VoidOrderUIResponse expectedResponse = sampleResponse;
        Mono<VoidOrderUIResponse> response = helper.voidOrder(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();

    }

    @Test
    public void voidOrderHelperTest2() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/VoidOrderUIRequest2.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/VoidOrderUIResponse.json", testFileLocation);
        VoidOrderUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, VoidOrderUIRequest.class);
        VoidOrderUIResponse sampleResponse = mapper.readValue(sampleUIResponseString, VoidOrderUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData92.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.voidOrder(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        VoidOrderUIResponse expectedResponse = sampleResponse;
        Mono<VoidOrderUIResponse> response = helper.voidOrder(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void voidOrderHelperTest3() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/VoidOrderUIRequest1.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/VoidOrderUIResponse.json", testFileLocation);
        VoidOrderUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, VoidOrderUIRequest.class);
        VoidOrderUIResponse sampleResponse = mapper.readValue(sampleUIResponseString, VoidOrderUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData93.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.voidOrder(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        VoidOrderUIResponse expectedResponse = sampleResponse;
        Mono<VoidOrderUIResponse> response = helper.voidOrder(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void voidOrderHelperTest4() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/VoidOrderUIRequest3.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/VoidOrderUIResponse.json", testFileLocation);
        VoidOrderUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, VoidOrderUIRequest.class);
        VoidOrderUIResponse sampleResponse = mapper.readValue(sampleUIResponseString, VoidOrderUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData94.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.voidOrder(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        VoidOrderUIResponse expectedResponse = sampleResponse;
        Mono<VoidOrderUIResponse> response = helper.voidOrder(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void voidOrderHelperTest5() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/VoidOrderUIRequest4.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/VoidOrderUIResponse.json", testFileLocation);
        VoidOrderUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, VoidOrderUIRequest.class);
        VoidOrderUIResponse sampleResponse = mapper.readValue(sampleUIResponseString, VoidOrderUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData94.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.voidOrder(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        VoidOrderUIResponse expectedResponse = sampleResponse;
        Mono<VoidOrderUIResponse> response = helper.voidOrder(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void ispuToDfillHelperTest1() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/IspuToDfillUIRequest1.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveURCForCartUIResponse.json", testFileLocation);
        IspuToDfillUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, IspuToDfillUIRequest.class);
        IspuToDfillUIResponse sampleResponse = mapper.readValue(sampleUIResponseString, IspuToDfillUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData95.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.ispuToDfill(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        IspuToDfillUIResponse expectedResponse = sampleResponse;
        Mono<IspuToDfillUIResponse> response = helper.ispuToDfill(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void ispuToDfillHelperTest2() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/IspuToDfillUIRequest2.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveURCForCartUIResponse.json", testFileLocation);
        IspuToDfillUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, IspuToDfillUIRequest.class);
        IspuToDfillUIResponse sampleResponse = mapper.readValue(sampleUIResponseString, IspuToDfillUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData96.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.ispuToDfill(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        IspuToDfillUIResponse expectedResponse = sampleResponse;
        Mono<IspuToDfillUIResponse> response = helper.ispuToDfill(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void ispuToDfillHelperTest3() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/IspuToDfillUIRequest3.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveURCForCartUIResponse.json", testFileLocation);
        IspuToDfillUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, IspuToDfillUIRequest.class);
        IspuToDfillUIResponse sampleResponse = mapper.readValue(sampleUIResponseString, IspuToDfillUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData96.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.ispuToDfill(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        IspuToDfillUIResponse expectedResponse = sampleResponse;
        Mono<IspuToDfillUIResponse> response = helper.ispuToDfill(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void ispuToDfillHelperTest4() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/IspuToDfillUIRequest4.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveURCForCartUIResponse.json", testFileLocation);
        IspuToDfillUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, IspuToDfillUIRequest.class);
        IspuToDfillUIResponse sampleResponse = mapper.readValue(sampleUIResponseString, IspuToDfillUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData96.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.ispuToDfill(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        IspuToDfillUIResponse expectedResponse = sampleResponse;
        Mono<IspuToDfillUIResponse> response = helper.ispuToDfill(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void ispuToDfillHelperTest5() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/IspuToDfillUIRequest5.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveURCForCartUIResponse.json", testFileLocation);
        IspuToDfillUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, IspuToDfillUIRequest.class);
        IspuToDfillUIResponse sampleResponse = mapper.readValue(sampleUIResponseString, IspuToDfillUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData96.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.ispuToDfill(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        IspuToDfillUIResponse expectedResponse = sampleResponse;
        Mono<IspuToDfillUIResponse> response = helper.ispuToDfill(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void ispuToDfillHelperTest6() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/IspuToDfillUIRequest5.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/RetrieveURCForCartUIResponse.json", testFileLocation);
        IspuToDfillUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, IspuToDfillUIRequest.class);
        IspuToDfillUIResponse sampleResponse = mapper.readValue(sampleUIResponseString, IspuToDfillUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData97.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.ispuToDfill(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        IspuToDfillUIResponse expectedResponse = sampleResponse;
        Mono<IspuToDfillUIResponse> response = helper.ispuToDfill(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }
    @Test
    public void splitExceededAmountHelperTest1() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/SplitExceededAmountUIRequest1.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/SplitExceededAmountUIResponse.json", testFileLocation);
        SplitExceededAmountUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, SplitExceededAmountUIRequest.class);
        SplitExceededAmountUIResponse sampleResponse = mapper.readValue(sampleUIResponseString, SplitExceededAmountUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData98.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper3.splitExceededAmount(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        SplitExceededAmountUIResponse expectedResponse = sampleResponse;
        Mono<SplitExceededAmountUIResponse> response = helper.splitExceededAmount(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void splitExceededAmountHelperTest2() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/SplitExceededAmountUIRequest2.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/SplitExceededAmountUIResponse.json", testFileLocation);
        SplitExceededAmountUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, SplitExceededAmountUIRequest.class);
        SplitExceededAmountUIResponse sampleResponse = mapper.readValue(sampleUIResponseString, SplitExceededAmountUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData50.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper3.splitExceededAmount(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        SplitExceededAmountUIResponse expectedResponse = sampleResponse;
        Mono<SplitExceededAmountUIResponse> response = helper.splitExceededAmount(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void splitExceededAmountHelperTest3() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/SplitExceededAmountUIRequest3.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/SplitExceededAmountUIResponse.json", testFileLocation);
        SplitExceededAmountUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, SplitExceededAmountUIRequest.class);
        SplitExceededAmountUIResponse sampleResponse = mapper.readValue(sampleUIResponseString, SplitExceededAmountUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData99.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper3.splitExceededAmount(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        SplitExceededAmountUIResponse expectedResponse = sampleResponse;
        Mono<SplitExceededAmountUIResponse> response = helper.splitExceededAmount(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void splitExceededAmountHelperTest4() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/SplitExceededAmountUIRequest4.json", testFileLocation);
        String sampleUIResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/SplitExceededAmountUIResponse.json", testFileLocation);
        SplitExceededAmountUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, SplitExceededAmountUIRequest.class);
        SplitExceededAmountUIResponse sampleResponse = mapper.readValue(sampleUIResponseString, SplitExceededAmountUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData100.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper3.splitExceededAmount(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        SplitExceededAmountUIResponse expectedResponse = sampleResponse;
        Mono<SplitExceededAmountUIResponse> response = helper.splitExceededAmount(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

}
