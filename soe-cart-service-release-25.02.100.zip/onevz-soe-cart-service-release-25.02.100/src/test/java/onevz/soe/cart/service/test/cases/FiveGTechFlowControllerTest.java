package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import net.jcip.annotations.NotThreadSafe;
import onevz.soe.cart.controller.FiveGTechFlowController;
import onevz.soe.cart.helper.FiveGTechFlowHelper;
import onevz.soe.cart.helper.RedisHelper3;
import onevz.soe.cart.initiatecart.InitiateCartUIResponse;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.reviewOrderInsipico.InspicioResponseOrderInfo;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.AddPlanAndDeviceUIRequest;
import onevz.soe.cart.ui.responses.AddPlanAndDeviceUIResponse;
import onevz.soe.exception.SOEError;
import onevz.soe.exception.SOEErrorHolder;
import onevz.soe.wsclient.bpm.model.CustomerInfo;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpResponse;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(FiveGTechFlowController.class)
//@NotThreadSafe
public class FiveGTechFlowControllerTest {

	@Mock
	private FiveGTechFlowHelper readCartHelper;

	@InjectMocks
	private FiveGTechFlowController cartController;

	@Mock
	private RedisHelper3 redisHelper3;

	@Autowired
	private ObjectMapper mapper;

	@Test
	public void cpcUpdateCartTest() throws JsonProcessingException {
		URI url = URI.create("http://localhost/cart/5g/cpcUpdateCart");
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("GLOBALID", "VZW-DOTCOM");
		httpHeaders.add("channelId", "Digital");
		httpHeaders.add("digital_ig_session", "digital_ig_session_12345");
		HttpCookie cookie = new HttpCookie("GLOBALID", "VZW-DOTCOM");


		MockServerHttpRequest httpHeader = MockServerHttpRequest.post(url.toString()).headers(httpHeaders).cookie(cookie).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		String respString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-478074622-W01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Accessories\"},{\"path\":\"PlanSelection\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\",\"pastDueBalance\":\"false\",\"pastDueBalanceAmount\":\"0.0\"},\"customerInfo\":{\"accountNumber\":\"0824904910-00001\",\"cartCreator\":\"7708238475\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"existingCase\":\"true\"},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"be872fcc-8e69-4557-afee-2a1cfe1b43d6\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"PlanSelection\",\"Accessories\",\"Accessories\",\"Accessories\",\"ShoppingCart\",\"ShippingOptions\",\"OrderNow\"]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"PlanSelection\",\"Accessories\",\"Accessories\",\"Accessories\",\"ShoppingCart\",\"ShippingOptions\",\"OrderNow\"]}]}}}}";
		AddPlanAndDeviceUIResponse addPlanAndDeviceUIResponse =mapper.readValue(respString,AddPlanAndDeviceUIResponse.class);
		when(readCartHelper.cpcUpdateCart(Mockito.any())).thenReturn(Mono.just(addPlanAndDeviceUIResponse));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.cpcUpdateCart(httpHeader, httpResponse,null);
		StepVerifier.create(controllerResponse).assertNext(resp -> org.junit.Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void cpcUpdateCartErrorTest() {
		URI url = URI.create("http://localhost/cart/5g/cpcUpdateCart");
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("GLOBALID", "VZW-DOTCOM");
		httpHeaders.add("channelId", "Digital");
		httpHeaders.add("digital_ig_session", "digital_ig_session_12345");
		HttpCookie cookie = new HttpCookie("GLOBALID", "VZW-DOTCOM");


		MockServerHttpRequest httpHeader = MockServerHttpRequest.post(url.toString()).headers(httpHeaders).cookie(cookie).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		InspicioResponseOrderInfo inspicioResponseOrderInfo=new InspicioResponseOrderInfo();
		AddPlanAndDeviceUIResponse addPlanAndDeviceUIResponse =new AddPlanAndDeviceUIResponse();
		List<CartError> cartErros = new ArrayList<>();
		CartError cartError = new CartError();
		cartError.setName("Test Name");
		cartError.setDebug_id("test_debugId");
		cartError.setMessage("Error Message");
		cartErros.add(cartError);
		addPlanAndDeviceUIResponse.setErrors(cartErros);
		when(readCartHelper.cpcUpdateCart(Mockito.any())).thenReturn(Mono.just(addPlanAndDeviceUIResponse));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.cpcUpdateCart(httpHeader, httpResponse,null);
		StepVerifier.create(controllerResponse).assertNext(resp -> org.junit.Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}
	@Test
	public void cpcProvisionPlantTest() {
		URI url = URI.create("http://localhost/cart/5g/cpcUpdateCart");
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("GLOBALID", "VZW-DOTCOM");
		httpHeaders.add("channelId", "Digital");
		httpHeaders.add("digital_ig_session", "digital_ig_session_12345");
		HttpCookie cookie = new HttpCookie("GLOBALID", "VZW-DOTCOM");


		MockServerHttpRequest httpHeader = MockServerHttpRequest.post(url.toString()).headers(httpHeaders).cookie(cookie).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		InspicioResponseOrderInfo inspicioResponseOrderInfo=new InspicioResponseOrderInfo();
		AddPlanAndDeviceUIResponse addPlanAndDeviceUIResponse =new AddPlanAndDeviceUIResponse();
		when(readCartHelper.cpcSubmitPlan(Mockito.any())).thenReturn(Mono.just(addPlanAndDeviceUIResponse));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		//when(inspicioResponseOrderInfo.zipWith(Mockito.any())).thenReturn(Mono.just(reviewOrderData));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.cpcProvisionPlan(httpHeader, httpResponse,null);
		StepVerifier.create(controllerResponse).assertNext(resp -> org.junit.Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void cpcProvisionPlanErrorTest() {
		URI url = URI.create("http://localhost/cart/5g/cpcUpdateCart");
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("GLOBALID", "VZW-DOTCOM");
		httpHeaders.add("channelId", "Digital");
		httpHeaders.add("digital_ig_session", "digital_ig_session_12345");
		HttpCookie cookie = new HttpCookie("GLOBALID", "VZW-DOTCOM");


		MockServerHttpRequest httpHeader = MockServerHttpRequest.post(url.toString()).headers(httpHeaders).cookie(cookie).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		InspicioResponseOrderInfo inspicioResponseOrderInfo=new InspicioResponseOrderInfo();
		AddPlanAndDeviceUIResponse addPlanAndDeviceUIResponse =new AddPlanAndDeviceUIResponse();
		List<CartError> cartErros = new ArrayList<>();
		CartError cartError = new CartError();
		cartError.setName("Test Name");
		cartError.setDebug_id("test_debugId");
		cartError.setMessage("Error Message");
		cartErros.add(cartError);
		addPlanAndDeviceUIResponse.setErrors(cartErros);
		when(readCartHelper.cpcSubmitPlan(Mockito.any())).thenReturn(Mono.just(addPlanAndDeviceUIResponse));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.cpcProvisionPlan(httpHeader, httpResponse,null);
		StepVerifier.create(controllerResponse).assertNext(resp -> org.junit.Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}
	
	@Test
	public void cpcUpdateCartTest1() throws JsonProcessingException {
		URI url = URI.create("http://localhost/cart/5g/cpcUpdateCart");
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("GLOBALID", "VZW-DOTCOM");
		httpHeaders.add("channelId", "Digital");
		httpHeaders.add("digital_ig_session", "digital_ig_session_12345");
		HttpCookie cookie = new HttpCookie("GLOBALID", "VZW-DOTCOM");


		MockServerHttpRequest httpHeader = MockServerHttpRequest.post(url.toString()).headers(httpHeaders).cookie(cookie).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		String respString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-478074622-W01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Accessories\"},{\"path\":\"PlanSelection\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\",\"pastDueBalance\":\"false\",\"pastDueBalanceAmount\":\"0.0\"},\"customerInfo\":{\"accountNumber\":\"0824904910-00001\",\"cartCreator\":\"7708238475\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"existingCase\":\"true\"},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"PlanSelection\",\"Accessories\",\"Accessories\",\"Accessories\",\"ShoppingCart\",\"ShippingOptions\",\"OrderNow\"]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"PlanSelection\",\"Accessories\",\"Accessories\",\"Accessories\",\"ShoppingCart\",\"ShippingOptions\",\"OrderNow\"]}]}}}}";
		AddPlanAndDeviceUIResponse addPlanAndDeviceUIResponse =mapper.readValue(respString,AddPlanAndDeviceUIResponse.class);
		when(readCartHelper.cpcUpdateCart(Mockito.any())).thenReturn(Mono.just(addPlanAndDeviceUIResponse));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.cpcUpdateCart(httpHeader, httpResponse,null);
		StepVerifier.create(controllerResponse).assertNext(resp -> org.junit.Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void cpcUpdateCartTest2() throws JsonProcessingException {
		URI url = URI.create("http://localhost/cart/5g/cpcUpdateCart");
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("GLOBALID", "VZW-DOTCOM");
		httpHeaders.add("channelId", "Digital");
		httpHeaders.add("digital_ig_session", "digital_ig_session_12345");
		HttpCookie cookie = new HttpCookie("GLOBALID", "VZW-DOTCOM");


		MockServerHttpRequest httpHeader = MockServerHttpRequest.post(url.toString()).headers(httpHeaders).cookie(cookie).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		String respString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{}}}";
		AddPlanAndDeviceUIResponse addPlanAndDeviceUIResponse =mapper.readValue(respString,AddPlanAndDeviceUIResponse.class);
		when(readCartHelper.cpcUpdateCart(Mockito.any())).thenReturn(Mono.just(addPlanAndDeviceUIResponse));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.cpcUpdateCart(httpHeader, httpResponse,null);
		StepVerifier.create(controllerResponse).assertNext(resp -> org.junit.Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void cpcUpdateCartTest3() throws JsonProcessingException {
		URI url = URI.create("http://localhost/cart/5g/cpcUpdateCart");
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("GLOBALID", "VZW-DOTCOM");
		httpHeaders.add("channelId", "Digital");
		httpHeaders.add("digital_ig_session", "digital_ig_session_12345");
		HttpCookie cookie = new HttpCookie("GLOBALID", "VZW-DOTCOM");


		MockServerHttpRequest httpHeader = MockServerHttpRequest.post(url.toString()).headers(httpHeaders).cookie(cookie).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		String respString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{}}";
		AddPlanAndDeviceUIResponse addPlanAndDeviceUIResponse =mapper.readValue(respString,AddPlanAndDeviceUIResponse.class);
		when(readCartHelper.cpcUpdateCart(Mockito.any())).thenReturn(Mono.just(addPlanAndDeviceUIResponse));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.cpcUpdateCart(httpHeader, httpResponse,null);
		StepVerifier.create(controllerResponse).assertNext(resp -> org.junit.Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void cpcUpdateCartTest4() throws JsonProcessingException {
		URI url = URI.create("http://localhost/cart/5g/cpcUpdateCart");
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("GLOBALID", "VZW-DOTCOM");
		httpHeaders.add("channelId", "Digital");
		httpHeaders.add("digital_ig_session", "digital_ig_session_12345");
		HttpCookie cookie = new HttpCookie("GLOBALID", "VZW-DOTCOM");


		MockServerHttpRequest httpHeader = MockServerHttpRequest.post(url.toString()).headers(httpHeaders).cookie(cookie).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		String respString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"}}";
		AddPlanAndDeviceUIResponse addPlanAndDeviceUIResponse =mapper.readValue(respString,AddPlanAndDeviceUIResponse.class);
		when(readCartHelper.cpcUpdateCart(Mockito.any())).thenReturn(Mono.just(addPlanAndDeviceUIResponse));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.cpcUpdateCart(httpHeader, httpResponse,null);
		StepVerifier.create(controllerResponse).assertNext(resp -> org.junit.Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void cpcinitateCartTest() throws JsonProcessingException {
		URI url = URI.create("http://localhost/cart/5g/cpcUpdateCart");
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("GLOBALID", "VZW-DOTCOM");
		httpHeaders.add("channelId", "Digital");
		httpHeaders.add("digital_ig_session", "digital_ig_session_12345");
		HttpCookie cookie = new HttpCookie("GLOBALID", "VZW-DOTCOM");
		AddPlanAndDeviceUIRequest request=new AddPlanAndDeviceUIRequest();
		request.setChannelId("VZW-DOTCOM");
		String resp="{ \"serviceHeader\": { \"clientId\": \"VZW-DOTCOM\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"CPC\", \"statusCode\": \"00\" }, \"serviceBody\":" +
				" { \"serviceResponse\": { \"context\": { \"caseId\": \"CPC-12401688-E01\", \"contextInfo\": { \"callReason\": \"CPC\", \"processStep\": \"planSelection\", \"availablePaths\": [ { \"path\": \"planSelection\" }, { \"path\": \"featureSelection\" } ], \"pastDueBalance\": \"false\", \"pendingOrderAccountLevel\": \"false\" }, \"customerInfo\": { \"accountNumber\": \"0326564274-00001\", \"cartCreator\": \"5619384700\", \"registerNumber\": 0 }, \"cartInfo\": { \"cartId\": \"5bad495f-b32f-4bc3-8293-c0064cb7750f\" } } } } }";
		InitiateCartUIResponse initiateCartUIResponse =mapper.readValue(resp,InitiateCartUIResponse.class);
		MockServerHttpRequest httpHeader = MockServerHttpRequest.post(url.toString()).headers(httpHeaders).cookie(cookie).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();

		when(readCartHelper.cpcInititateCart(Mockito.any())).thenReturn(Mono.just(initiateCartUIResponse));
		Mono<ResponseEntity<InitiateCartUIResponse>> controllerResponse = cartController.cpcCreateCart(httpHeader, httpResponse,request);
		StepVerifier.create(controllerResponse).assertNext(Assert::assertNotNull).expectComplete()
				.verify();
	}
	@Test
	public void cpcInitateCartChannelIdNullTest() throws JsonProcessingException {
		AddPlanAndDeviceUIRequest request=new AddPlanAndDeviceUIRequest();
		request.setChannelId("VZW-DOTCOM");
		URI url = URI.create("http://localhost/cart/5g/cpcUpdateCart");
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("GLOBALID", "VZW-DOTCOM");
		httpHeaders.add("digital_ig_session", "digital_ig_session_12345");
		HttpCookie cookie = new HttpCookie("GLOBALID", "VZW-DOTCOM");

		String resp="{ \"serviceHeader\": { \"clientId\": \"VZW-DOTCOM\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"CPC\", \"statusCode\": \"00\" }, \"serviceBody\":" +
				" { \"serviceResponse\": { \"context\": { \"caseId\": \"CPC-12401688-E01\", \"contextInfo\": { \"callReason\": \"CPC\", \"processStep\": \"planSelection\", \"availablePaths\": [ { \"path\": \"planSelection\" }, { \"path\": \"featureSelection\" } ], \"pastDueBalance\": \"false\", \"pendingOrderAccountLevel\": \"false\" }, \"customerInfo\": { \"accountNumber\": \"0326564274-00001\", \"cartCreator\": \"5619384700\", \"registerNumber\": 0 }, \"cartInfo\": { \"cartId\": \"5bad495f-b32f-4bc3-8293-c0064cb7750f\" } } } } }";
		InitiateCartUIResponse initiateCartUIResponse =mapper.readValue(resp,InitiateCartUIResponse.class);
		MockServerHttpRequest httpHeader = MockServerHttpRequest.post(url.toString()).headers(httpHeaders).cookie(cookie).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(readCartHelper.cpcInititateCart(Mockito.any())).thenReturn(Mono.just(initiateCartUIResponse));
		Mono<ResponseEntity<InitiateCartUIResponse>> controllerResponse = cartController.cpcCreateCart(httpHeader, httpResponse,request);
		StepVerifier.create(controllerResponse).assertNext(Assert::assertNotNull).expectComplete()
				.verify();
	}
	@Test
	public void cpcInitiateCartErrorTest() throws IOException, SOEHTTPException {
		AddPlanAndDeviceUIRequest req=new AddPlanAndDeviceUIRequest();
		String reqString  ="{}";
		String respString="{ \"serviceHeader\": { \"clientId\": \"VZW-DOTCOM\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"CPC\", \"statusCode\": \"00\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \"CPC-12401688-E01\", \"contextInfo\": { \"callReason\": \"CPC\", \"processStep\": \"planSelection\", \"availablePaths\": [ { \"path\": \"planSelection\" }, { \"path\": \"featureSelection\" } ], \"pastDueBalance\": \"false\", \"pendingOrderAccountLevel\": \"false\" }, \"customerInfo\": { \"accountNumber\": \"0326564274-00001\", \"cartCreator\": \"5619384700\", \"registerNumber\": 0 }, \"cartInfo\": { \"cartId\": \"5bad495f-b32f-4bc3-8293-c0064cb7750f\" } } } } }";
		URI url = URI.create("http://localhost/cart/5g/cpcInitiateCart");
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("GLOBALID", "VZW-DOTCOM");
		httpHeaders.add("channelId", "Digital");
		httpHeaders.add("digital_ig_session", "digital_ig_session_12345");
		HttpCookie cookie = new HttpCookie("GLOBALID", "VZW-DOTCOM");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.post(url.toString()).headers(httpHeaders).cookie(cookie).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		CustomerInfo customerInfo =new CustomerInfo();
		customerInfo.setCartCreator("5619384700");
		customerInfo.setAccountNumber("0326564274-00001");
		SOEErrorHolder soeErrorHolder = new SOEErrorHolder();
		List<SOEError> errors = new ArrayList<>();
		SOEError soeError = new SOEError();
		soeError.setDebug_id("test");
		soeError.setCategory("BPM");
		soeError.setMessage("BAD GATEWAY");
		errors.add(soeError);
		soeErrorHolder.setErrors(errors);
		SOEHTTPException soehttpException = new SOEHTTPException(500, soeErrorHolder);
		Mono<InitiateCartUIResponse> dummyResponse1 = Mono.error(soehttpException);
		when(readCartHelper.cpcInititateCart(Mockito.any())).thenReturn(dummyResponse1);
		Mono<ResponseEntity<InitiateCartUIResponse>> cartUIResponse1 = cartController.cpcCreateCart(httpHeader, httpResponse, req);
		StepVerifier.create(cartUIResponse1).assertNext(Assert::assertNotNull).expectComplete().verify();
	}
}