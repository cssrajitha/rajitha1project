package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vzw.cradle.vo.CradleResponse;
import onevz.cxp.feature.util.FeatureFlag;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper2;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper3;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.constants.RedisConstants;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.helper.RedisHelper3;
import onevz.soe.cart.helper.UpdateCartHelper;
import onevz.soe.cart.model.createLine.HomeSalesAddress;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.cradle.CradleAllocator;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(UpdateCartHelper.class)
public class CartServiceHelper3Test {

    @Autowired
    private UpdateCartHelper helper;

    @MockBean
    private CartServiceBpmHelper2 bpmHelper2;

    @MockBean
    private CartServiceBpmHelper3 bpmHelper3;

    @MockBean
    private RedisHelper redisHelper;

    @MockBean
    private RedisHelper3 redisHelper3;

    @Autowired
    private ObjectMapper mapper;

    @MockBean
    FeatureFlag featureFlag;

    @MockBean
    private CradleAllocator cradleAllocator;

    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;

    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;

    @Test
    public void addBuyoutHelperTest1() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddBuyoutUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddBuyoutUIRequest7.json", testFileLocation);
        AddBuyoutUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, AddBuyoutUIRequest.class);
        AddBuyoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddBuyoutUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData33.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addBuyout(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        AddBuyoutUIResponse expectedResponse = sampleResponse;
        Mono<AddBuyoutUIResponse> response = helper.addBuyout(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addBuyoutHelperTest2() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddBuyoutUIResponse.json", testFileLocation);
        String sampleUIRequestString = 	sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddBuyoutUIRequest2.json", testFileLocation);
        AddBuyoutUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, AddBuyoutUIRequest.class);
        AddBuyoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddBuyoutUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData33.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addBuyout(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        AddBuyoutUIResponse expectedResponse = sampleResponse;
        Mono<AddBuyoutUIResponse> response = helper.addBuyout(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addBuyoutHelperTest3() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddBuyoutUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddBuyoutUIRequest3.json", testFileLocation);
        AddBuyoutUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, AddBuyoutUIRequest.class);
        AddBuyoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddBuyoutUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData33.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addBuyout(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        AddBuyoutUIResponse expectedResponse = sampleResponse;
        Mono<AddBuyoutUIResponse> response = helper.addBuyout(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addBuyoutHelperTest4() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddBuyoutUIResponse.json", testFileLocation);
        String sampleUIRequestString = 	sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddBuyoutUIRequest3.json", testFileLocation);
        AddBuyoutUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, AddBuyoutUIRequest.class);
        AddBuyoutUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddBuyoutUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData34.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addBuyout(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        AddBuyoutUIResponse expectedResponse = sampleResponse;
        Mono<AddBuyoutUIResponse> response = helper.addBuyout(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addEdgeUpHelperTest1() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEdgeupUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEdgeupUIRequest1.json", testFileLocation);
        UpdateEdgeupUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateEdgeupUIRequest.class);
        UpdateEdgeupUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateEdgeupUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData35.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addEdgeup(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateEdgeupUIResponse expectedResponse = sampleResponse;
        Mono<UpdateEdgeupUIResponse> response = helper.addEdgeup(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addEdgeUpHelperTest2() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEdgeupUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEdgeupUIRequest3.json", testFileLocation);
        UpdateEdgeupUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateEdgeupUIRequest.class);
        UpdateEdgeupUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateEdgeupUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData35.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addEdgeup(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateEdgeupUIResponse expectedResponse = sampleResponse;
        Mono<UpdateEdgeupUIResponse> response = helper.addEdgeup(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addEdgeUpHelperTest3() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEdgeupUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEdgeupUIRequest4.json", testFileLocation);
        UpdateEdgeupUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateEdgeupUIRequest.class);
        UpdateEdgeupUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateEdgeupUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData35.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addEdgeup(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateEdgeupUIResponse expectedResponse = sampleResponse;
        Mono<UpdateEdgeupUIResponse> response = helper.addEdgeup(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addEdgeUpHelperTest4() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEdgeupUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEdgeupUIRequest4.json", testFileLocation);
        UpdateEdgeupUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateEdgeupUIRequest.class);
        UpdateEdgeupUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateEdgeupUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData36.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addEdgeup(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateEdgeupUIResponse expectedResponse = sampleResponse;
        Mono<UpdateEdgeupUIResponse> response = helper.addEdgeup(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void removeEdgeupTest1() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEdgeupUIRequest5.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEdgeupUIResponse2.json", testFileLocation);
        UpdateEdgeupUIRequest  sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateEdgeupUIRequest .class);
        UpdateEdgeupUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateEdgeupUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData35.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.removeEdgeUp(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateEdgeupUIResponse expectedResponse = sampleResponse;
        Mono<UpdateEdgeupUIResponse> response = helper.removeEdgeup(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void removeEdgeupTest2() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEdgeupUIRequest6.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEdgeupUIResponse2.json", testFileLocation);
        UpdateEdgeupUIRequest  sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateEdgeupUIRequest .class);
        UpdateEdgeupUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateEdgeupUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData35.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.removeEdgeUp(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateEdgeupUIResponse expectedResponse = sampleResponse;
        Mono<UpdateEdgeupUIResponse> response = helper.removeEdgeup(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void removeEdgeupTest3() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEdgeupUIRequest7.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEdgeupUIResponse2.json", testFileLocation);
        UpdateEdgeupUIRequest  sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateEdgeupUIRequest .class);
        UpdateEdgeupUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateEdgeupUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData35.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.removeEdgeUp(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateEdgeupUIResponse expectedResponse = sampleResponse;
        Mono<UpdateEdgeupUIResponse> response = helper.removeEdgeup(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void removeEdgeupTest4() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEdgeupUIRequest7.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEdgeupUIResponse2.json", testFileLocation);
        UpdateEdgeupUIRequest  sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateEdgeupUIRequest .class);
        UpdateEdgeupUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateEdgeupUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData34.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.removeEdgeUp(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateEdgeupUIResponse expectedResponse = sampleResponse;
        Mono<UpdateEdgeupUIResponse> response = helper.removeEdgeup(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void pastDuesHelperTest1() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/PastDuesUIResponse.json", testFileLocation);
        String sampleUIRequestString =  sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEdgeupUIRequest5.json", testFileLocation);
        PastDuesUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, PastDuesUIRequest.class);
        PastDuesUIResponse sampleResponse = mapper.readValue(sampleResponseString, PastDuesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData35.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        PastDuesUIResponse expectedResponse = sampleResponse;
        when(bpmHelper2.pastDues(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<PastDuesUIResponse> response = helper.pastDues(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void pastDuesHelperTest2() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/PastDuesUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEdgeupUIRequest6.json", testFileLocation);
        PastDuesUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, PastDuesUIRequest.class);
        PastDuesUIResponse sampleResponse = mapper.readValue(sampleResponseString, PastDuesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData35.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        PastDuesUIResponse expectedResponse = sampleResponse;
        when(bpmHelper2.pastDues(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<PastDuesUIResponse> response = helper.pastDues(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void pastDuesHelperTest3() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/PastDuesUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEdgeupUIRequest7.json", testFileLocation);
        PastDuesUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, PastDuesUIRequest.class);
        PastDuesUIResponse sampleResponse = mapper.readValue(sampleResponseString, PastDuesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData35.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        PastDuesUIResponse expectedResponse = sampleResponse;
        when(bpmHelper2.pastDues(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<PastDuesUIResponse> response = helper.pastDues(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void pastDuesHelperTest4() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/PastDuesUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateEdgeupUIRequest7.json", testFileLocation);
        PastDuesUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, PastDuesUIRequest.class);
        PastDuesUIResponse sampleResponse = mapper.readValue(sampleResponseString, PastDuesUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData34.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        PastDuesUIResponse expectedResponse = sampleResponse;
        when(bpmHelper2.pastDues(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        Mono<PastDuesUIResponse> response = helper.pastDues(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addDownPaymentHelperTest1() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDownPaymentUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DownPaymentUIRequest1.json", testFileLocation);
        DownPaymentUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, DownPaymentUIRequest.class);
        AddDownPaymentUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddDownPaymentUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData37.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addDownPayment(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        AddDownPaymentUIResponse expectedResponse = sampleResponse;
        Mono<AddDownPaymentUIResponse> response = helper.addDownPayment(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addDownPaymentHelperTest2() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDownPaymentUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DownPaymentUIRequest1.json", testFileLocation);
        DownPaymentUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, DownPaymentUIRequest.class);
        AddDownPaymentUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddDownPaymentUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData38.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addDownPayment(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        AddDownPaymentUIResponse expectedResponse = sampleResponse;
        Mono<AddDownPaymentUIResponse> response = helper.addDownPayment(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addDownPaymentHelperTest3() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDownPaymentUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DownPaymentUIRequest2.json", testFileLocation);
        DownPaymentUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, DownPaymentUIRequest.class);
        AddDownPaymentUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddDownPaymentUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData38.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addDownPayment(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        AddDownPaymentUIResponse expectedResponse = sampleResponse;
        Mono<AddDownPaymentUIResponse> response = helper.addDownPayment(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addDownPaymentHelperTest4() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDownPaymentUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DownPaymentUIRequest3.json", testFileLocation);
        DownPaymentUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, DownPaymentUIRequest.class);
        AddDownPaymentUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddDownPaymentUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData38.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addDownPayment(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        AddDownPaymentUIResponse expectedResponse = sampleResponse;
        Mono<AddDownPaymentUIResponse> response = helper.addDownPayment(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addDownPaymentHelperTest5() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDownPaymentUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DownPaymentUIRequest4.json", testFileLocation);
        DownPaymentUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, DownPaymentUIRequest.class);
        AddDownPaymentUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddDownPaymentUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData38.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addDownPayment(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(featureFlag.isFeatureEnabled(anyString(), anyString(), anyString(), anyBoolean())).thenReturn(Mono.just(Boolean.TRUE));
        AddDownPaymentUIResponse expectedResponse = sampleResponse;
        Mono<AddDownPaymentUIResponse> response = helper.addDownPayment(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addDownPaymentHelperTest6() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDownPaymentUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DownPaymentUIRequest5.json", testFileLocation);
        DownPaymentUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, DownPaymentUIRequest.class);
        AddDownPaymentUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddDownPaymentUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData39.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addDownPayment(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        AddDownPaymentUIResponse expectedResponse = sampleResponse;
        Mono<AddDownPaymentUIResponse> response = helper.addDownPayment(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addDownPaymentHelperTest7() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDownPaymentUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DownPaymentUIRequest6.json", testFileLocation);
        DownPaymentUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, DownPaymentUIRequest.class);
        AddDownPaymentUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddDownPaymentUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData39.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addDownPayment(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        AddDownPaymentUIResponse expectedResponse = sampleResponse;
        Mono<AddDownPaymentUIResponse> response = helper.addDownPayment(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addDownPaymentHelperTest8() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDownPaymentUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DownPaymentUIRequest7.json", testFileLocation);
        DownPaymentUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, DownPaymentUIRequest.class);
        AddDownPaymentUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddDownPaymentUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData39.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addDownPayment(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        AddDownPaymentUIResponse expectedResponse = sampleResponse;
        Mono<AddDownPaymentUIResponse> response = helper.addDownPayment(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addDownPaymentHelperTest9() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDownPaymentUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DownPaymentUIRequest6.json", testFileLocation);
        DownPaymentUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, DownPaymentUIRequest.class);
        AddDownPaymentUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddDownPaymentUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData40.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addDownPayment(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        AddDownPaymentUIResponse expectedResponse = sampleResponse;
        Mono<AddDownPaymentUIResponse> response = helper.addDownPayment(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addDownPaymentHelperDigitalElvisTest1() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDownPaymentUIDigitalResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DownPaymentUIDigitalRequest.json", testFileLocation);
        DownPaymentUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, DownPaymentUIRequest.class);
        AddDownPaymentUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddDownPaymentUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData38.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addDownPayment(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(featureFlag.isFeatureEnabled(anyString(), anyString(), anyString(), anyBoolean())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<AddDownPaymentUIResponse> response = helper.addDownPayment(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
    }

    @Test
    public void addDownPaymentHelperDigitalElvisTest2() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDownPaymentUIDigitalResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DownPaymentUIDigitalRequest.json", testFileLocation);
        DownPaymentUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, DownPaymentUIRequest.class);
        AddDownPaymentUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddDownPaymentUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData13.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addDownPayment(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(featureFlag.isFeatureEnabled(anyString(), anyString(), anyString(), anyBoolean())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<AddDownPaymentUIResponse> response = helper.addDownPayment(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
    }

    @Test
    public void addDownPaymentHelperDigitalElvisTest3() throws IOException{
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDownPaymentUIDigitalResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DownPaymentUIDigital2Request.json", testFileLocation);
        DownPaymentUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, DownPaymentUIRequest.class);
        AddDownPaymentUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddDownPaymentUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData13.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addDownPayment(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(featureFlag.isFeatureEnabled(anyString(), anyString(), anyString(), anyBoolean())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<AddDownPaymentUIResponse> response = helper.addDownPayment(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
    }

    @Test
    public void addDownPaymentHelperDigitalElvisTest4() throws IOException{
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDownPaymentUIDigitalResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DownPaymentUIDigital3Request.json", testFileLocation);
        DownPaymentUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, DownPaymentUIRequest.class);
        AddDownPaymentUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddDownPaymentUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData38.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addDownPayment(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(featureFlag.isFeatureEnabled(anyString(), anyString(), anyString(), anyBoolean())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<AddDownPaymentUIResponse> response = helper.addDownPayment(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
    }

    @Test
    public void addDownPaymentHelperDigitalElvisTest5() throws IOException{
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDownPaymentUIDigitalResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DownPaymentUIDigital4Request.json", testFileLocation);
        DownPaymentUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, DownPaymentUIRequest.class);
        AddDownPaymentUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddDownPaymentUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData38.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addDownPayment(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(featureFlag.isFeatureEnabled(anyString(), anyString(), anyString(), anyBoolean())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<AddDownPaymentUIResponse> response = helper.addDownPayment(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
    }

    @Test
    public void addDownPaymentHelperDigitalElvisTest6() throws IOException{
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/AddDownPaymentUIDigitalResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DownPaymentUIDigital5Request.json", testFileLocation);
        DownPaymentUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, DownPaymentUIRequest.class);
        AddDownPaymentUIResponse sampleResponse = mapper.readValue(sampleResponseString, AddDownPaymentUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData38.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addDownPayment(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(featureFlag.isFeatureEnabled(anyString(), anyString(), anyString(), anyBoolean())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<AddDownPaymentUIResponse> response = helper.addDownPayment(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
    }

    @Test
    public void addDownPaymentHelperDigitalNonElvisTest() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/DownPaymentUIDigitalRequest.json", testFileLocation);
        DownPaymentUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, DownPaymentUIRequest.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData38.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(featureFlag.isFeatureEnabled(anyString(), anyString(), anyString(), anyBoolean())).thenReturn(Mono.just(Boolean.FALSE));
        Mono<AddDownPaymentUIResponse> response = helper.addDownPayment(sampleUIRequest);
        StepVerifier.create(response).assertNext(Assert::assertNotNull).expectComplete().verify();
    }

    @Test
    public void createLineHelperTest1() throws IOException {

        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreateLineUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreateLineUIResponse.json", testFileLocation);
        CreateLineUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, CreateLineUIRequest.class);
        CreateLineUIResponse sampleResponse = mapper.readValue(sampleResponseString, CreateLineUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData41.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(featureFlag.isFeatureEnabled(anyString(), anyString(), anyString(), anyBoolean())).thenReturn(Mono.just(Boolean.TRUE));
        when(bpmHelper2.createLine(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper3.getHomeSalesAddressFromRedis()).thenReturn(Mono.just(new HomeSalesAddress()));
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CradleResponse()));
        CreateLineUIResponse expectedResponse = sampleResponse;
        sampleUIRequest.getCartInfo().setIntendType(CartConstants.NSE_BYOD);
        when(cradleAllocator.getDataMap()).thenReturn(Mono.just(new HashMap<>()));
        when(redisHelper3.getDataFromSession(Mockito.any())).thenReturn(Mono.just(new HashMap<>()));
        Mono<CreateLineUIResponse> response = helper.createLine(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();

        Map<String,String> cradleDatmap=new HashMap<>();
        cradleDatmap.put(CartConstants.ACCOUNT_NUMBER,"1234567890");
        when(cradleAllocator.getDataMap()).thenReturn(Mono.just(cradleDatmap));
        when(redisHelper3.getDataFromSession(Mockito.any())).thenReturn(Mono.just(new HashMap<>()));
        response = helper.createLine(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void createLineHelperTest2() throws IOException {

        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreateLineUIRequest.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreateLineUIResponse.json", testFileLocation);
        CreateLineUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, CreateLineUIRequest.class);
        CreateLineUIResponse sampleResponse = mapper.readValue(sampleResponseString, CreateLineUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData42.json", testFileLocation);
        when(featureFlag.isFeatureEnabled(anyString(), anyString(), anyString(), anyBoolean())).thenReturn(Mono.just(Boolean.TRUE));
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.createLine(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper3.getHomeSalesAddressFromRedis()).thenReturn(Mono.just(new HomeSalesAddress()));
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CradleResponse()));
        sampleUIRequest.getCartInfo().setIntendType(CartConstants.NSE_BYOD);
        CreateLineUIResponse expectedResponse = sampleResponse;
        Map<String,String> cradleDatmap=new HashMap<>();
        cradleDatmap.put(CartConstants.THROTTLE_LIST,CartConstants.NEXTGEN_C_BYOD_CDL_VALUE);
        when(cradleAllocator.getDataMap()).thenReturn(Mono.just(cradleDatmap));
        when(redisHelper3.getDataFromSession(Mockito.any())).thenReturn(Mono.just(new HashMap<>()));
        Mono<CreateLineUIResponse> response = helper.createLine(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void createLineHelperTest3() throws IOException {

        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreateLineUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreateLineUIResponse.json", testFileLocation);
        CreateLineUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, CreateLineUIRequest.class);
        CreateLineUIResponse sampleResponse = mapper.readValue(sampleResponseString, CreateLineUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData42.json", testFileLocation);
        when(featureFlag.isFeatureEnabled(anyString(), anyString(), anyString(), anyBoolean())).thenReturn(Mono.just(Boolean.TRUE));
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.createLine(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper3.getHomeSalesAddressFromRedis()).thenReturn(Mono.just(new HomeSalesAddress()));
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CradleResponse()));
        Map<String,String> cradleDatmap=new HashMap<>();
        CreateLineUIResponse expectedResponse = sampleResponse;
        when(redisHelper3.getDataFromSession(Mockito.any())).thenReturn(Mono.just(new HashMap<>()));
        cradleDatmap.put(CartConstants.THROTTLE_LIST,"");
        sampleUIRequest.getCartInfo().setIntendType(CartConstants.NSE_BYOD);
        when(cradleAllocator.getDataMap()).thenReturn(Mono.just(cradleDatmap));
        Mono<CreateLineUIResponse> response = helper.createLine(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
        cradleDatmap.put(CartConstants.THROTTLE_LIST,CartConstants.NEXT_GEN);
        when(cradleAllocator.getDataMap()).thenReturn(Mono.just(cradleDatmap));
        response = helper.createLine(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
    }

    @Test
    public void createLineHelperTest4() throws IOException {

        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreateLineUIRequest2.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreateLineUIResponse.json", testFileLocation);
        CreateLineUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, CreateLineUIRequest.class);
        CreateLineUIResponse sampleResponse = mapper.readValue(sampleResponseString, CreateLineUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData42.json", testFileLocation);
        when(featureFlag.isFeatureEnabled(anyString(), anyString(), anyString(), anyBoolean())).thenReturn(Mono.just(Boolean.TRUE));
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.createLine(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper3.getHomeSalesAddressFromRedis()).thenReturn(Mono.just(new HomeSalesAddress()));
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CradleResponse()));
        Map<String,String> cradleDatmap=new HashMap<>();
        cradleDatmap.put(CartConstants.THROTTLE_LIST,CartConstants.NEXT_GEN);
        when(cradleAllocator.getDataMap()).thenReturn(Mono.just(cradleDatmap));
        CreateLineUIResponse expectedResponse = sampleResponse;
        sampleUIRequest.getCartInfo().setIntendType("NSEBYOD");
        when(redisHelper3.getDataFromSession(Mockito.any())).thenReturn(Mono.just(new HashMap<>()));
        Mono<CreateLineUIResponse> response = helper.createLine(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void createLineHelperTest5() throws IOException {
        ReflectionTestUtils.setField(helper, "enableMHOffers", true);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreateLineUIRequest3.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CreateLineUIResponse1.json", testFileLocation);
        CreateLineUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, CreateLineUIRequest.class);
        CreateLineUIResponse sampleResponse = mapper.readValue(sampleResponseString, CreateLineUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData43.json", testFileLocation);
        when(featureFlag.isFeatureEnabled(anyString(), anyString(), anyString(), anyBoolean())).thenReturn(Mono.just(Boolean.TRUE));
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.createLine(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper3.getHomeSalesAddressFromRedis()).thenReturn(Mono.just(new HomeSalesAddress()));
        when(cradleAllocator.invokeReactiveCradle(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(new CradleResponse()));
        Map<String,String> cradleDatmap=new HashMap<>();
        when(cradleAllocator.getDataMap()).thenReturn(Mono.just(cradleDatmap));
        sampleUIRequest.setChannelId("VZW-MFA-ANDROID");
        sampleUIRequest.getCartInfo().setIntendType(CartConstants.NSE_BYOD);
        CreateLineUIResponse expectedResponse = sampleResponse;
        when(redisHelper3.getDataFromSession(Mockito.any())).thenReturn(Mono.just(new HashMap<>()));
        cradleDatmap.put(CartConstants.THROTTLE_LIST,"");
        when(cradleAllocator.getDataMap()).thenReturn(Mono.just(cradleDatmap));
        Mono<CreateLineUIResponse> response = helper.createLine(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void numbershareHelperTest1() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NumberShareUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NumberShareUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData46.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        NumberShareUIRequest UIRequest = mapper.readValue(sampleUIRequestString, NumberShareUIRequest.class);
        NumberShareUIResponse sampleResponse = mapper.readValue(sampleResponseString, NumberShareUIResponse.class);
        when(bpmHelper2.numberShare(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        NumberShareUIResponse expectedResponse = sampleResponse;
        Mono<NumberShareUIResponse> response = helper.numberShare(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void numbershareHelperTest2() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NumberShareUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NumberShareUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData42.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        NumberShareUIRequest UIRequest = mapper.readValue(sampleUIRequestString, NumberShareUIRequest.class);
        NumberShareUIResponse sampleResponse = mapper.readValue(sampleResponseString, NumberShareUIResponse.class);
        when(bpmHelper2.numberShare(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        NumberShareUIResponse expectedResponse = sampleResponse;
        Mono<NumberShareUIResponse> response = helper.numberShare(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void numbershareHelperTest3() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NumberShareUIRequest2.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NumberShareUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData42.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        NumberShareUIRequest UIRequest = mapper.readValue(sampleUIRequestString, NumberShareUIRequest.class);
        NumberShareUIResponse sampleResponse = mapper.readValue(sampleResponseString, NumberShareUIResponse.class);
        when(bpmHelper2.numberShare(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        NumberShareUIResponse expectedResponse = sampleResponse;
        Mono<NumberShareUIResponse> response = helper.numberShare(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void numbershareHelperTest4() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NumberShareUIRequest3.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NumberShareUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData42.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        NumberShareUIRequest UIRequest = mapper.readValue(sampleUIRequestString, NumberShareUIRequest.class);
        NumberShareUIResponse sampleResponse = mapper.readValue(sampleResponseString, NumberShareUIResponse.class);
        when(bpmHelper2.numberShare(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("false"));
        NumberShareUIResponse expectedResponse = sampleResponse;
        Mono<NumberShareUIResponse> response = helper.numberShare(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void numbershareHelperTest5() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NumberShareUIRequest4.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NumberShareUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData42.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        NumberShareUIRequest UIRequest = mapper.readValue(sampleUIRequestString, NumberShareUIRequest.class);
        NumberShareUIResponse sampleResponse = mapper.readValue(sampleResponseString, NumberShareUIResponse.class);
        when(bpmHelper2.numberShare(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just("true"));
        NumberShareUIResponse expectedResponse = sampleResponse;
        Mono<NumberShareUIResponse> response = helper.numberShare(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void numbershareHelperTest6() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NumberShareUIRequest4.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NumberShareUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData42.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        NumberShareUIRequest UIRequest = mapper.readValue(sampleUIRequestString, NumberShareUIRequest.class);
        NumberShareUIResponse sampleResponse = mapper.readValue(sampleResponseString, NumberShareUIResponse.class);
        when(bpmHelper2.numberShare(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just(""));
        NumberShareUIResponse expectedResponse = sampleResponse;
        Mono<NumberShareUIResponse> response = helper.numberShare(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void numbershareHelperTest7() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NumberShareUIRequest4.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NumberShareUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData47.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        NumberShareUIRequest UIRequest = mapper.readValue(sampleUIRequestString, NumberShareUIRequest.class);
        NumberShareUIResponse sampleResponse = mapper.readValue(sampleResponseString, NumberShareUIResponse.class);
        when(bpmHelper2.numberShare(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just(""));
        NumberShareUIResponse expectedResponse = sampleResponse;
        Mono<NumberShareUIResponse> response = helper.numberShare(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void numbershareHelperTest8() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NumberShareUIRequest5.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NumberShareUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData48.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        NumberShareUIRequest UIRequest = mapper.readValue(sampleUIRequestString, NumberShareUIRequest.class);
        NumberShareUIResponse sampleResponse = mapper.readValue(sampleResponseString, NumberShareUIResponse.class);
        when(bpmHelper2.numberShare(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just(""));
        NumberShareUIResponse expectedResponse = sampleResponse;
        Mono<NumberShareUIResponse> response = helper.numberShare(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void numbershareHelperTest9() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NumberShareUIRequest6.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NumberShareUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData48.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        NumberShareUIRequest UIRequest = mapper.readValue(sampleUIRequestString, NumberShareUIRequest.class);
        NumberShareUIResponse sampleResponse = mapper.readValue(sampleResponseString, NumberShareUIResponse.class);
        when(bpmHelper2.numberShare(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just(""));
        NumberShareUIResponse expectedResponse = sampleResponse;
        Mono<NumberShareUIResponse> response = helper.numberShare(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void numbershareHelperTest10() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NumberShareUIRequest7.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/NumberShareUIResponse.json", testFileLocation);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData48.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        NumberShareUIRequest UIRequest = mapper.readValue(sampleUIRequestString, NumberShareUIRequest.class);
        NumberShareUIResponse sampleResponse = mapper.readValue(sampleResponseString, NumberShareUIResponse.class);
        when(bpmHelper2.numberShare(Mockito.any())).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        when(redisHelper.getPromoHubSpokeJourney()).thenReturn(Mono.just(""));
        NumberShareUIResponse expectedResponse = sampleResponse;
        Mono<NumberShareUIResponse> response = helper.numberShare(UIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateDeviceSimIdHelperTest1() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateDeviceSIMIdUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateDeviceSIMIdUIResponse.json", testFileLocation);
        UpdateDeviceSIMIdUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateDeviceSIMIdUIRequest.class);
        UpdateDeviceSIMIdUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateDeviceSIMIdUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData49.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper3.updateDeviceSimId(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateDeviceSIMIdUIResponse expectedResponse = sampleResponse;
        Mono<UpdateDeviceSIMIdUIResponse> response = helper.updateDeviceSIMId(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateDeviceSimIdHelperTest2() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateDeviceSIMIdUIRequest1.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateDeviceSIMIdUIResponse.json", testFileLocation);
        UpdateDeviceSIMIdUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateDeviceSIMIdUIRequest.class);
        UpdateDeviceSIMIdUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateDeviceSIMIdUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData50.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper3.updateDeviceSimId(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateDeviceSIMIdUIResponse expectedResponse = sampleResponse;
        Mono<UpdateDeviceSIMIdUIResponse> response = helper.updateDeviceSIMId(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateDeviceSimIdHelperTest3() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateDeviceSIMIdUIRequest2.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateDeviceSIMIdUIResponse.json", testFileLocation);
        UpdateDeviceSIMIdUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateDeviceSIMIdUIRequest.class);
        UpdateDeviceSIMIdUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateDeviceSIMIdUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData50.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper3.updateDeviceSimId(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateDeviceSIMIdUIResponse expectedResponse = sampleResponse;
        Mono<UpdateDeviceSIMIdUIResponse> response = helper.updateDeviceSIMId(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateDeviceSimIdHelperTest4() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateDeviceSIMIdUIRequest3.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateDeviceSIMIdUIResponse.json", testFileLocation);
        UpdateDeviceSIMIdUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateDeviceSIMIdUIRequest.class);
        UpdateDeviceSIMIdUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateDeviceSIMIdUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData51.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper3.updateDeviceSimId(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateDeviceSIMIdUIResponse expectedResponse = sampleResponse;
        Mono<UpdateDeviceSIMIdUIResponse> response = helper.updateDeviceSIMId(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateDeviceSimIdHelperTest5() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateDeviceSIMIdUIRequest4.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateDeviceSIMIdUIResponse.json", testFileLocation);
        UpdateDeviceSIMIdUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateDeviceSIMIdUIRequest.class);
        UpdateDeviceSIMIdUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateDeviceSIMIdUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData52.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper3.updateDeviceSimId(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateDeviceSIMIdUIResponse expectedResponse = sampleResponse;
        Mono<UpdateDeviceSIMIdUIResponse> response = helper.updateDeviceSIMId(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateDeviceSimIdHelperTest6() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateDeviceSIMIdUIRequest5.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateDeviceSIMIdUIResponse.json", testFileLocation);
        UpdateDeviceSIMIdUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateDeviceSIMIdUIRequest.class);
        UpdateDeviceSIMIdUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateDeviceSIMIdUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData52.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper3.updateDeviceSimId(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateDeviceSIMIdUIResponse expectedResponse = sampleResponse;
        Mono<UpdateDeviceSIMIdUIResponse> response = helper.updateDeviceSIMId(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void updateDeviceSimIdHelperTest7() throws IOException {
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateDeviceSIMIdUIRequest6.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateDeviceSIMIdUIResponse.json", testFileLocation);
        UpdateDeviceSIMIdUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, UpdateDeviceSIMIdUIRequest.class);
        UpdateDeviceSIMIdUIResponse sampleResponse = mapper.readValue(sampleResponseString, UpdateDeviceSIMIdUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData52.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper3.updateDeviceSimId(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        UpdateDeviceSIMIdUIResponse expectedResponse = sampleResponse;
        Mono<UpdateDeviceSIMIdUIResponse> response = helper.updateDeviceSIMId(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addServiceAddressHelperTest1() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/E911AddressUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ServiceAddressUIRequest1.json", testFileLocation);
        ServiceAddressUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, ServiceAddressUIRequest.class);
        ServiceAddressUIResponse sampleResponse = mapper.readValue(sampleResponseString, ServiceAddressUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData53.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addServiceAddress(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        ServiceAddressUIResponse expectedResponse = sampleResponse;
        Mono<ServiceAddressUIResponse> response = helper.addServiceAddress(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addServiceAddressHelperTest2() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/E911AddressUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ServiceAddressUIRequest1.json", testFileLocation);
        ServiceAddressUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, ServiceAddressUIRequest.class);
        ServiceAddressUIResponse sampleResponse = mapper.readValue(sampleResponseString, ServiceAddressUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData54.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addServiceAddress(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        ServiceAddressUIResponse expectedResponse = sampleResponse;
        Mono<ServiceAddressUIResponse> response = helper.addServiceAddress(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addServiceAddressHelperTest3() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/E911AddressUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ServiceAddressUIRequest6.json", testFileLocation);
        ServiceAddressUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, ServiceAddressUIRequest.class);
        ServiceAddressUIResponse sampleResponse = mapper.readValue(sampleResponseString, ServiceAddressUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData55.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addServiceAddress(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        ServiceAddressUIResponse expectedResponse = sampleResponse;
        Mono<ServiceAddressUIResponse> response = helper.addServiceAddress(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addServiceAddressHelperTest4() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/E911AddressUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ServiceAddressUIRequest7.json", testFileLocation);
        ServiceAddressUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, ServiceAddressUIRequest.class);
        ServiceAddressUIResponse sampleResponse = mapper.readValue(sampleResponseString, ServiceAddressUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData55.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addServiceAddress(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        ServiceAddressUIResponse expectedResponse = sampleResponse;
        Mono<ServiceAddressUIResponse> response = helper.addServiceAddress(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addServiceAddressHelperTest5() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/E911AddressUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ServiceAddressUIRequest8.json", testFileLocation);
        ServiceAddressUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, ServiceAddressUIRequest.class);
        ServiceAddressUIResponse sampleResponse = mapper.readValue(sampleResponseString, ServiceAddressUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData55.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addServiceAddress(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        ServiceAddressUIResponse expectedResponse = sampleResponse;
        Mono<ServiceAddressUIResponse> response = helper.addServiceAddress(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addServiceAddressHelperTest6() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/E911AddressUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ServiceAddressUIRequest9.json", testFileLocation);
        ServiceAddressUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, ServiceAddressUIRequest.class);
        ServiceAddressUIResponse sampleResponse = mapper.readValue(sampleResponseString, ServiceAddressUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData56.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addServiceAddress(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        ServiceAddressUIResponse expectedResponse = sampleResponse;
        Mono<ServiceAddressUIResponse> response = helper.addServiceAddress(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addServiceAddressHelperTest7() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/E911AddressUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ServiceAddressUIRequest10.json", testFileLocation);
        ServiceAddressUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, ServiceAddressUIRequest.class);
        ServiceAddressUIResponse sampleResponse = mapper.readValue(sampleResponseString, ServiceAddressUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData57.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addServiceAddress(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        ServiceAddressUIResponse expectedResponse = sampleResponse;
        Mono<ServiceAddressUIResponse> response = helper.addServiceAddress(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addServiceAddressHelperTest8() throws IOException {
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/E911AddressUIResponse.json", testFileLocation);
        String sampleUIRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/ServiceAddressUIRequest11.json", testFileLocation);
        ServiceAddressUIRequest sampleUIRequest = mapper.readValue(sampleUIRequestString, ServiceAddressUIRequest.class);
        ServiceAddressUIResponse sampleResponse = mapper.readValue(sampleResponseString, ServiceAddressUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData58.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        when(bpmHelper2.addServiceAddress(sampleUIRequest)).thenReturn(Mono.just(sampleResponse));
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        ServiceAddressUIResponse expectedResponse = sampleResponse;
        Mono<ServiceAddressUIResponse> response = helper.addServiceAddress(sampleUIRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addBillingAddressHelperTest1() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BillingAddressUIRequest1.json", testFileLocation);
        String sampleResponseString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIResponseNew.json", testFileLocation);
        BillingAddressUIRequest sampleRequest = mapper.readValue(sampleRequestString, BillingAddressUIRequest.class);
        BillingAddressUIResponse sampleResponse = mapper.readValue(sampleResponseString, BillingAddressUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData59.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<BillingAddressUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.addBillingAddress(sampleRequest)).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        BillingAddressUIResponse expectedResponse = sampleResponse;
        Mono<BillingAddressUIResponse> response = helper.addBillingAddress(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addBillingAddressHelperTest2() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BillingAddressUIRequest1.json", testFileLocation);
        String sampleResponseString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIResponseNew.json", testFileLocation);
        BillingAddressUIRequest sampleRequest = mapper.readValue(sampleRequestString, BillingAddressUIRequest.class);
        BillingAddressUIResponse sampleResponse = mapper.readValue(sampleResponseString, BillingAddressUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData60.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<BillingAddressUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.addBillingAddress(sampleRequest)).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        BillingAddressUIResponse expectedResponse = sampleResponse;
        Mono<BillingAddressUIResponse> response = helper.addBillingAddress(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addBillingAddressHelperTest3() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BillingAddressUIRequest2.json", testFileLocation);
        String sampleResponseString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIResponseNew.json", testFileLocation);
        BillingAddressUIRequest sampleRequest = mapper.readValue(sampleRequestString, BillingAddressUIRequest.class);
        BillingAddressUIResponse sampleResponse = mapper.readValue(sampleResponseString, BillingAddressUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData60.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<BillingAddressUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.addBillingAddress(sampleRequest)).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        BillingAddressUIResponse expectedResponse = sampleResponse;
        Mono<BillingAddressUIResponse> response = helper.addBillingAddress(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addBillingAddressHelperTest4() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BillingAddressUIRequest3.json", testFileLocation);
        String sampleResponseString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIResponseNew.json", testFileLocation);
        BillingAddressUIRequest sampleRequest = mapper.readValue(sampleRequestString, BillingAddressUIRequest.class);
        BillingAddressUIResponse sampleResponse = mapper.readValue(sampleResponseString, BillingAddressUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData60.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<BillingAddressUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.addBillingAddress(sampleRequest)).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        BillingAddressUIResponse expectedResponse = sampleResponse;
        Mono<BillingAddressUIResponse> response = helper.addBillingAddress(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addBillingAddressHelperTest5() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BillingAddressUIRequest4.json", testFileLocation);
        String sampleResponseString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIResponseNew.json", testFileLocation);
        BillingAddressUIRequest sampleRequest = mapper.readValue(sampleRequestString, BillingAddressUIRequest.class);
        BillingAddressUIResponse sampleResponse = mapper.readValue(sampleResponseString, BillingAddressUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData60.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<BillingAddressUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.addBillingAddress(sampleRequest)).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        BillingAddressUIResponse expectedResponse = sampleResponse;
        Mono<BillingAddressUIResponse> response = helper.addBillingAddress(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addBillingAddressHelperTest6() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BillingAddressUIRequest5.json", testFileLocation);
        String sampleResponseString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIResponseNew.json", testFileLocation);
        BillingAddressUIRequest sampleRequest = mapper.readValue(sampleRequestString, BillingAddressUIRequest.class);
        BillingAddressUIResponse sampleResponse = mapper.readValue(sampleResponseString, BillingAddressUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData61.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<BillingAddressUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.addBillingAddress(sampleRequest)).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        BillingAddressUIResponse expectedResponse = sampleResponse;
        Mono<BillingAddressUIResponse> response = helper.addBillingAddress(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addBillingAddressHelperTest7() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BillingAddressUIRequest5.json", testFileLocation);
        String sampleResponseString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIResponseNew.json", testFileLocation);
        BillingAddressUIRequest sampleRequest = mapper.readValue(sampleRequestString, BillingAddressUIRequest.class);
        BillingAddressUIResponse sampleResponse = mapper.readValue(sampleResponseString, BillingAddressUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData62.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<BillingAddressUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.addBillingAddress(sampleRequest)).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        BillingAddressUIResponse expectedResponse = sampleResponse;
        Mono<BillingAddressUIResponse> response = helper.addBillingAddress(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addBillingAddressHelperTest8() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BillingAddressUIRequest5.json", testFileLocation);
        String sampleResponseString =sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIResponseNew.json", testFileLocation);
        BillingAddressUIRequest sampleRequest = mapper.readValue(sampleRequestString, BillingAddressUIRequest.class);
        BillingAddressUIResponse sampleResponse = mapper.readValue(sampleResponseString, BillingAddressUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData63.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<BillingAddressUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.addBillingAddress(sampleRequest)).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        BillingAddressUIResponse expectedResponse = sampleResponse;
        Mono<BillingAddressUIResponse> response = helper.addBillingAddress(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    @Test
    public void addBillingAddressHelperTest9() throws IOException, SOEHTTPException {
        String sampleRequestString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/BillingAddressUIRequest6.json", testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/UpdateSellerPriceUIResponseNew.json", testFileLocation);
        BillingAddressUIRequest sampleRequest = mapper.readValue(sampleRequestString, BillingAddressUIRequest.class);
        BillingAddressUIResponse sampleResponse = mapper.readValue(sampleResponseString, BillingAddressUIResponse.class);
        String redisDataString = sourceFileReaderUtil.readFile("data/cartServiceHelperTest/CartRedisData63.json", testFileLocation);
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        Mono<BillingAddressUIResponse> sampleResponseMono = Mono.just(sampleResponse);
        when(bpmHelper2.addBillingAddress(sampleRequest)).thenReturn(sampleResponseMono);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
        BillingAddressUIResponse expectedResponse = sampleResponse;
        Mono<BillingAddressUIResponse> response = helper.addBillingAddress(sampleRequest);
        StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
        StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete().verify();
    }

    private String getHomeSalesAddressList() {
        return "[{\"addressType\":\"BillAccount\",\"addressValid\":\"false\",\"cBandQualified\":\"false\",\"eventCorrelationId\":\"76244_1691515510232_737\",\"fiosqualified\":\"false\",\"firstName\":\"###\",\"fiveGHomeQualified\":\"false\",\"gigqualified\":\"false\",\"hsiqualified\":\"false\",\"lastName\":\"###\",\"LTEQualified\":\"false\",\"recordIdentifier\":\"4025\",\"addressInfo\":{\"addressLine1\":\"###\",\"baselocationId\":\"300074229125\",\"city\":\"###\",\"latitude\":\"0.0\",\"locationId\":\"300074229125\",\"longitude\":\"0.0\",\"state\":\"###\",\"zipCode\":\"###\"},\"eligibilities\":{\"fiveGHomebundle\":[],\"moversSoftSkus\":null,\"cbandBundle\":[],\"LTEHomeSku\":null,\"CBandSku\":\"ASK-NCQ1338FA\"},\"priorQualification\":{\"cbandQualified\":\"false\",\"fiveGHomeQualified\":\"false\",\"LTEQualified\":\"false\"}}]";
    }

}
