package onevz.soe.cart.service.test.cases;

import onevz.soe.cart.cxp.helper.CatalogServiceHelper;
import onevz.soe.cart.exceptions.CommonCartServiceException;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.IOException;

import static org.springframework.http.HttpStatus.CONTINUE;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(CommonCartServiceException.class)
public class CommonCartServiceExceptionTest {
    @Test
    public void ExceptionTest() throws Exception  {
        Assert.assertNotNull( new CommonCartServiceException(CONTINUE,"message"));
    }
}
