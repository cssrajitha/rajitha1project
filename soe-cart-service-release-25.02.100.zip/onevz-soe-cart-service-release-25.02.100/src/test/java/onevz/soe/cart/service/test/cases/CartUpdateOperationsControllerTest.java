package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper3;
import onevz.soe.cart.controller.CartUpdateOperationsController;
import onevz.soe.cart.controller.CartUpdateOperationsController2;
import onevz.soe.cart.controller.CartUpdateOperationsController3;
import onevz.soe.cart.exceptions.JsonValidator;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.cradle.CradleAllocator;
import onevz.soe.omnidl.util.DLUtilityService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.*;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpResponse;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(CartUpdateOperationsController.class)
public class CartUpdateOperationsControllerTest {

	@Autowired
	private ObjectMapper mapper;

	@Autowired
	private CartUpdateOperationsController cartController;

	@Autowired
	private CartUpdateOperationsController2 cartController2;

	@Autowired
	private CartUpdateOperationsController3 cartController3;

	@MockBean
	private RedisHelper redisHelper;

	@MockBean
	private RedisHelper2 redisHelper2;

	@MockBean
	private UpdateCartHelper helper;

	@Value("${onevz.soe.cart.test.fileLocation}")
	private String testFileLocation;

	@Autowired
	SourceFileReaderUtil sourceFileReaderUtil;

	@MockBean
	private DLUtilityService dlUtilityService;

	@MockBean
	private CartAddDeviceHelper deviceHelper;

	@MockBean
	private CartServiceBpmHelper3 bpmHelper;

	@MockBean
	private JsonValidator validator;

	@Test
	public void clearXboxFromCartOnDppSummaryTest() throws IOException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/clearXboxFromCartOnDppSummaryRequest.json";
		String responseFile = "data/CartUpdateOperationsControllerTestJson/clearXboxFromCartOnDppSummaryResponse.json";
		String redisDataFile = "data/CartUpdateOperationsControllerTestJson/clearXboxFromCartOnDppSummaryRedisData.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
		String redisDataString = sourceFileReaderUtil.readFile(redisDataFile, testFileLocation);
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		sampleRedisData.setCreditAppNum("");
		ClearCartUIRequest request = mapper.readValue(requestString, ClearCartUIRequest.class);
		ClearCartUIResponse response = mapper.readValue(responseString, ClearCartUIResponse.class);
		URI url = URI.create("http://localhost/clearCart");
		ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("digital_ig_session", "VZW-DOTCOM-1").header("mtn", "8437299178").cookie(new HttpCookie("digital_ig_session", "digital_1")).cookie(new HttpCookie("ecpdcookie", "1234")).cookie(new HttpCookie("domainCookie", "ecpd")).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(bpmHelper.clearCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(helper.clearCart(Mockito.any())).thenReturn(Mono.just(response));
		when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
		when(redisHelper2.updateDeviceCartCount(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
		when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(1L));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.clearCart(httpRequest, httpResponse,
				request);
		cartController.addCartCountCookie(httpResponse,"gnCartCount", Optional.empty(),httpRequest);
		StepVerifier.create(controllerResponse).assertNext(res -> {
			Assert.assertEquals(200, res.getStatusCodeValue());
		}).expectComplete().verify();
	}

	@Test
	public void applyMyOfferTest() throws IOException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/applyMyOfferRequest.json";
		String responseFile = "data/CartUpdateOperationsControllerTestJson/applyMyOfferResponse.json";
		String validateOfferResponse1File = "data/CartUpdateOperationsControllerTestJson/applyMyOfferValidationResponse.json";
		String redisDataFile = "data/CartUpdateOperationsControllerTestJson/applyMyOfferRedisData.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
		String validateOfferResponse1 = sourceFileReaderUtil.readFile(validateOfferResponse1File, testFileLocation);
		String redisDataString = sourceFileReaderUtil.readFile(redisDataFile, testFileLocation);
		MyOfferETRRedisData sampleRedisData = mapper.readValue(redisDataString, MyOfferETRRedisData.class);
		ApplyOfferRequest request = mapper.readValue(requestString, ApplyOfferRequest.class);
		ValidateOffersResponse response = mapper.readValue(responseString, ValidateOffersResponse.class);
		ValidateOffersResponse cxpResponse = mapper.readValue(validateOfferResponse1, ValidateOffersResponse.class);
		URI url = URI.create("http://localhost/applyMyOffers");
		ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-RETAIL").header("digital_ig_session", "VZW-DOTCOM-1").header("mtn", "8437299178").cookie(new HttpCookie("digital_ig_session", "digital_1")).cookie(new HttpCookie("ecpdcookie", "1234")).cookie(new HttpCookie("domainCookie", "ecpd")).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(helper.validateOffers(Mockito.any())).thenReturn(Mono.just(cxpResponse));
		Mono<ResponseEntity<ValidateOffersResponse>> controllerResponse = cartController.applyMyOffers(httpRequest, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(res -> {
			Assert.assertEquals(200, res.getStatusCodeValue());
		}).expectComplete().verify();
		// offers - my
		redisDataString = "{\"lines\":[{\"mtn\":\"4132072093\",\"offers\":[{\"complianceType\":\"EQP\",\"description\":\"\",\"compatibleIndicator\":\"N\",\"propId\":\"OBT_135\",\"offerCompliance\":\"N\"}]}]}";
		sampleRedisData = mapper.readValue(redisDataString, MyOfferETRRedisData.class);
		when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		controllerResponse = cartController.applyMyOffers(httpRequest, httpResponse, request);
		StepVerifier.create(controllerResponse).assertNext(res -> {
			Assert.assertTrue(res.getBody().getStatusMessage().contains("My"));
		}).expectComplete().verify();

		// offers aal - no msg
		redisDataString = " {\"lines\":[{\"mtn\":\"NewLine1\",\"offers\":[{\"complianceType\":\"SFO\",\"sku\":\"80873\",\"description\":\"BYOD AAL and Get 30% Off SP Access\",\"compatibleIndicator\":\"Y\",\"propId\":\"UAT_135\",\"aal\":\"Y\",\"offerCompliance\":\"Y\"}]}]}";
		sampleRedisData = mapper.readValue(redisDataString, MyOfferETRRedisData.class);
		when(redisHelper.getMyOfferETRDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		controllerResponse = cartController.applyMyOffers(httpRequest, httpResponse, request);
		StepVerifier.create(controllerResponse).assertNext(res -> {
			Assert.assertEquals("", res.getBody().getStatusMessage());
		}).expectComplete().verify();
	}

	@Test
	public void effectiveDateOverrideTest() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/AALrequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		//	String requestString = "{\"data\": {},\"cartInfo\": {\"intendType\": \"AAL\"}}";
		String responseString = "{}";
		EffectiveDateOverrideUIRequest request = mapper.readValue(requestString, EffectiveDateOverrideUIRequest.class);
		EffectiveDateOverrideUIResponse uiResponse = mapper.readValue(responseString, EffectiveDateOverrideUIResponse.class);
		URI url = URI.create("http://localhost/effectiveDateOverride");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.effectiveDateOverride(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.effectiveDateOverride(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void effectiveDateOverrideTest2() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/effectiveDateOverrideRequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{}";
		EffectiveDateOverrideUIRequest request = mapper.readValue(requestString, EffectiveDateOverrideUIRequest.class);
		EffectiveDateOverrideUIResponse uiResponse = mapper.readValue(responseString, EffectiveDateOverrideUIResponse.class);
		URI url = URI.create("http://localhost/effectiveDateOverride");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.effectiveDateOverride(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.effectiveDateOverride(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void effectiveDateOverrideTest3() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/effectiveDateOverrideRequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		EffectiveDateOverrideUIRequest request = mapper.readValue(requestString, EffectiveDateOverrideUIRequest.class);
		EffectiveDateOverrideUIResponse uiResponse = mapper.readValue(responseString, EffectiveDateOverrideUIResponse.class);
		URI url = URI.create("http://localhost/effectiveDateOverride");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM-MOB").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.effectiveDateOverride(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.effectiveDateOverride(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateMacAddressTest() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/AALrequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{}";
		MacAddressUIRequest request = mapper.readValue(requestString, MacAddressUIRequest.class);
		MacAddressUIResponse uiResponse = mapper.readValue(responseString, MacAddressUIResponse.class);
		URI url = URI.create("http://localhost/mac-address");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.updateMacAddress(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController.updateMacAddress(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateMacAddressTest2() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/updateMacAddressRequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{}";
		MacAddressUIRequest request = mapper.readValue(requestString, MacAddressUIRequest.class);
		MacAddressUIResponse uiResponse = mapper.readValue(responseString, MacAddressUIResponse.class);
		URI url = URI.create("http://localhost/mac-address");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.updateMacAddress(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController.updateMacAddress(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateMacAddressTest3() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/updateMacAddressRequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		MacAddressUIRequest request = mapper.readValue(requestString, MacAddressUIRequest.class);
		MacAddressUIResponse uiResponse = mapper.readValue(responseString, MacAddressUIResponse.class);
		URI url = URI.create("http://localhost/mac-address");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM-MOB").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.updateMacAddress(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController.updateMacAddress(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateSalesRepAndLocationCodeTest() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/AALrequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{}";
		SalesRepAndLocationCodeUIRequest request = mapper.readValue(requestString, SalesRepAndLocationCodeUIRequest.class);
		SalesRepAndLocationCodeUIResponse uiResponse = mapper.readValue(responseString, SalesRepAndLocationCodeUIResponse.class);
		URI url = URI.create("http://localhost/salesRep");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.updateSalesRepAndLocationCode(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController.updateSalesRepAndLocationCode(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateSalesRepAndLocationCodeTest2() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/updateSalesRepAndLocationCodeRequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		//String requestString = "{\"data\": {\"salesRepId\": \"id\",\"lines\": [{\"mtn\": \"mtn\",\"e911Address\": {\"address\": {}}}]},\"cartInfo\": {\"cartId\": \"id\"}}";
		String responseString = "{}";
		SalesRepAndLocationCodeUIRequest request = mapper.readValue(requestString, SalesRepAndLocationCodeUIRequest.class);
		SalesRepAndLocationCodeUIResponse uiResponse = mapper.readValue(responseString, SalesRepAndLocationCodeUIResponse.class);
		URI url = URI.create("http://localhost/salesRep");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.updateSalesRepAndLocationCode(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController.updateSalesRepAndLocationCode(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateSalesRepAndLocationCodeTest3() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/updateSalesRepAndLocationCodeRequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		SalesRepAndLocationCodeUIRequest request = mapper.readValue(requestString, SalesRepAndLocationCodeUIRequest.class);
		SalesRepAndLocationCodeUIResponse uiResponse = mapper.readValue(responseString, SalesRepAndLocationCodeUIResponse.class);
		URI url = URI.create("http://localhost/salesRep");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM-MOB").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.updateSalesRepAndLocationCode(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController.updateSalesRepAndLocationCode(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updatePortInLaterTest() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/AALrequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{}";
		PortinLaterUIRequest request = mapper.readValue(requestString, PortinLaterUIRequest.class);
		PortinLaterUIResponse uiResponse = mapper.readValue(responseString, PortinLaterUIResponse.class);
		URI url = URI.create("http://localhost/portInLater");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.updatePortInLater(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.updatePortInLater(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updatePortInLaterTest2() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/effectiveDateOverrideRequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		PortinLaterUIRequest request = mapper.readValue(requestString, PortinLaterUIRequest.class);
		PortinLaterUIResponse uiResponse = mapper.readValue(responseString, PortinLaterUIResponse.class);
		URI url = URI.create("http://localhost/portInLater");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.updatePortInLater(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.updatePortInLater(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void revokeRebatesTest() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/AALrequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{}";
		RevokeRebatesUIRequest request = mapper.readValue(requestString, RevokeRebatesUIRequest.class);
		RevokeRebatesUIResponse uiResponse = mapper.readValue(responseString, RevokeRebatesUIResponse.class);
		URI url = URI.create("http://localhost/revokeRebates");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.revokeRebates(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.revokeRebates(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void revokeRebatesTest2() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/effectiveDateOverrideRequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		RevokeRebatesUIRequest request = mapper.readValue(requestString, RevokeRebatesUIRequest.class);
		RevokeRebatesUIResponse uiResponse = mapper.readValue(responseString, RevokeRebatesUIResponse.class);
		URI url = URI.create("http://localhost/revokeRebates");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.revokeRebates(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.revokeRebates(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void giftPurchaseTest() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/AALrequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{}";
		GiftPurchaseUIRequest request = mapper.readValue(requestString, GiftPurchaseUIRequest.class);
		GiftPurchaseUIResponse uiResponse = mapper.readValue(responseString, GiftPurchaseUIResponse.class);
		URI url = URI.create("http://localhost/enroll-giftPurchase");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.giftPurchase(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.giftPurchase(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void giftPurchaseTest2() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/effectiveDateOverrideRequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		GiftPurchaseUIRequest request = mapper.readValue(requestString, GiftPurchaseUIRequest.class);
		GiftPurchaseUIResponse uiResponse = mapper.readValue(responseString, GiftPurchaseUIResponse.class);
		URI url = URI.create("http://localhost/enroll-giftPurchase");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.giftPurchase(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.giftPurchase(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void add5GBulkOrderTest() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/AALrequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{}";
		Add5GBulkOrderUIRequest request = mapper.readValue(requestString, Add5GBulkOrderUIRequest.class);
		Add5GBulkOrderUIResponse uiResponse = mapper.readValue(responseString, Add5GBulkOrderUIResponse.class);
		URI url = URI.create("http://localhost/add-fiveGBulkOrder");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.add5GBulkOrder(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.add5GBulkOrder(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void add5GBulkOrderTest2() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/add5GBulkOrderRequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		Add5GBulkOrderUIRequest request = mapper.readValue(requestString, Add5GBulkOrderUIRequest.class);
		Add5GBulkOrderUIResponse uiResponse = mapper.readValue(responseString, Add5GBulkOrderUIResponse.class);
		URI url = URI.create("http://localhost/add-fiveGBulkOrder");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.add5GBulkOrder(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.add5GBulkOrder(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void add5GBulkOrderTest3() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/add5GBulkOrderRequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{}";
		Add5GBulkOrderUIRequest request = mapper.readValue(requestString, Add5GBulkOrderUIRequest.class);
		Add5GBulkOrderUIResponse uiResponse = mapper.readValue(responseString, Add5GBulkOrderUIResponse.class);
		URI url = URI.create("http://localhost/add-fiveGBulkOrder");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.add5GBulkOrder(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.add5GBulkOrder(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updatePurchaseOrderTest() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/AALrequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{}";
		UpdatePurchaseOrderUIRequest request = mapper.readValue(requestString, UpdatePurchaseOrderUIRequest.class);
		UpdatePurchaseOrderUIResponse uiResponse = mapper.readValue(responseString, UpdatePurchaseOrderUIResponse.class);
		URI url = URI.create("http://localhost/updatePurchaseOrder");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.updatePurchaseOrder(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.updatePurchaseOrder(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updatePurchaseOrderTest2() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/add5GBulkOrderRequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		UpdatePurchaseOrderUIRequest request = mapper.readValue(requestString, UpdatePurchaseOrderUIRequest.class);
		UpdatePurchaseOrderUIResponse uiResponse = mapper.readValue(responseString, UpdatePurchaseOrderUIResponse.class);
		URI url = URI.create("http://localhost/updatePurchaseOrder");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.updatePurchaseOrder(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.updatePurchaseOrder(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void assignMtnTest() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/AALrequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{}";
		AssignMtnUIRequest request = mapper.readValue(requestString, AssignMtnUIRequest.class);
		AssignMtnUIResponse uiResponse = mapper.readValue(responseString, AssignMtnUIResponse.class);
		URI url = URI.create("http://localhost/assign-mtn");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.assignMtn(Mockito.any())).thenReturn(Mono.just(uiResponse));
		when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(new ErrorResponse());
		Mono<ResponseEntity<GenericResponse>> response = cartController.assignMtn(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void initiateAddReplenishmentTest() throws IOException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/initiateAddReplenishmentRequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{}";
		String redisDataFile = "data/CartUpdateOperationsControllerTestJson/initiateAddReplenishmentRedisData.json";
		String redisDataString = sourceFileReaderUtil.readFile(redisDataFile, testFileLocation);
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		AddReplenishmentToCartUIRequest request = mapper.readValue(requestString, AddReplenishmentToCartUIRequest.class);
		AddReplenishmentToCartUIResponse response = mapper.readValue(responseString, AddReplenishmentToCartUIResponse.class);
		URI url = URI.create("http://localhost/addReplenishmentOnlyToCart");
		//ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "OMNI-CARE").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		//when(redisHelper.upsertValueInRedis(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
		//when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(helper.addReplenishmentToCart(Mockito.any())).thenReturn(Mono.just(response));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addReplenishmenttoCart(httpHeader, httpResponse, request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void assignMtnTest2() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/assignMtnE911Request.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		AssignMtnUIRequest request = mapper.readValue(requestString, AssignMtnUIRequest.class);
		AssignMtnUIResponse uiResponse = mapper.readValue(responseString, AssignMtnUIResponse.class);
		URI url = URI.create("http://localhost/assign-mtn");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "OMNI-CARE").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.assignMtn(Mockito.any())).thenReturn(Mono.just(uiResponse));
		when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
		Mono<ResponseEntity<GenericResponse>> response = cartController.assignMtn(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void assignMtnFlexV2Test() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/assignMtnE911Request.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		AssignMtnUIRequest request = mapper.readValue(requestString, AssignMtnUIRequest.class);
		AssignMtnUIResponse uiResponse = mapper.readValue(responseString, AssignMtnUIResponse.class);
		URI url = URI.create("http://localhost/flexV2/assign-mtn");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "OMNI-CARE").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.assignMtn(Mockito.any())).thenReturn(Mono.just(uiResponse));
		when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
		Mono<ResponseEntity<GenericResponse>> response = cartController.assignMtn(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void assignMtnTest3() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/mtnNpaNxxE911Request.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{}";
		AssignMtnUIRequest request = mapper.readValue(requestString, AssignMtnUIRequest.class);
		AssignMtnUIResponse uiResponse = mapper.readValue(responseString, AssignMtnUIResponse.class);
		URI url = URI.create("http://localhost/assign-mtn");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.assignMtn(Mockito.any())).thenReturn(Mono.just(uiResponse));
		when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
		Mono<ResponseEntity<GenericResponse>> response = cartController.assignMtn(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void assignMtnTest4() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/mtnNpaNxxE911Request.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		AssignMtnUIRequest request = mapper.readValue(requestString, AssignMtnUIRequest.class);
		AssignMtnUIResponse uiResponse = mapper.readValue(responseString, AssignMtnUIResponse.class);
		URI url = URI.create("http://localhost/assign-mtn");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.assignMtn(Mockito.any())).thenReturn(Mono.just(uiResponse));
		when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
		Mono<ResponseEntity<GenericResponse>> response = cartController.assignMtn(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void assignMtnTest5() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/mtnNpaNxxE911Request.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		AssignMtnUIRequest request = mapper.readValue(requestString, AssignMtnUIRequest.class);
		AssignMtnUIResponse uiResponse = mapper.readValue(responseString, AssignMtnUIResponse.class);
		URI url = URI.create("http://localhost/assign-mtn");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.assignMtn(Mockito.any())).thenReturn(Mono.just(uiResponse));
		when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
		Mono<ResponseEntity<GenericResponse>> response = cartController.assignMtn(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deassignMtnTest() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/AALrequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{}";
		DeassignMtnUIRequest request = mapper.readValue(requestString, DeassignMtnUIRequest.class);
		DeassignMtnUIResponse uiResponse = mapper.readValue(responseString, DeassignMtnUIResponse.class);
		URI url = URI.create("http://localhost/deassign-mtn");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.deassignMtn(Mockito.any())).thenReturn(Mono.just(uiResponse));
		when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(new ErrorResponse());
		Mono<ResponseEntity<GenericResponse>> response = cartController2.deassignMtn(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deassignMtnTest2() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/assignMtnE911Request.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		DeassignMtnUIRequest request = mapper.readValue(requestString, DeassignMtnUIRequest.class);
		DeassignMtnUIResponse uiResponse = mapper.readValue(responseString, DeassignMtnUIResponse.class);
		URI url = URI.create("http://localhost/deassign-mtn");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "OMNI-CARE").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.deassignMtn(Mockito.any())).thenReturn(Mono.just(uiResponse));
		when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
		Mono<ResponseEntity<GenericResponse>> response = cartController2.deassignMtn(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deassignMtnTest3() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/mtnNpaNxxE911Request.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{}";
		DeassignMtnUIRequest request = mapper.readValue(requestString, DeassignMtnUIRequest.class);
		DeassignMtnUIResponse uiResponse = mapper.readValue(responseString, DeassignMtnUIResponse.class);
		URI url = URI.create("http://localhost/deassign-mtn");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.deassignMtn(Mockito.any())).thenReturn(Mono.just(uiResponse));
		when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
		Mono<ResponseEntity<GenericResponse>> response = cartController2.deassignMtn(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deassignMtnTest4() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/mtnNpaNxxE911Request.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		DeassignMtnUIRequest request = mapper.readValue(requestString, DeassignMtnUIRequest.class);
		DeassignMtnUIResponse uiResponse = mapper.readValue(responseString, DeassignMtnUIResponse.class);
		URI url = URI.create("http://localhost/deassign-mtn");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.deassignMtn(Mockito.any())).thenReturn(Mono.just(uiResponse));
		when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
		Mono<ResponseEntity<GenericResponse>> response = cartController2.deassignMtn(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void deassignMtnTest5() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/mtnNpaNxxE911Request.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		DeassignMtnUIRequest request = mapper.readValue(requestString, DeassignMtnUIRequest.class);
		DeassignMtnUIResponse uiResponse = mapper.readValue(responseString, DeassignMtnUIResponse.class);
		URI url = URI.create("http://localhost/deassign-mtn");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.deassignMtn(Mockito.any())).thenReturn(Mono.just(uiResponse));
		when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
		Mono<ResponseEntity<GenericResponse>> response = cartController2.deassignMtn(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void voidOrderTest() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/AALrequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{}";
		VoidOrderUIRequest request = mapper.readValue(requestString, VoidOrderUIRequest.class);
		VoidOrderUIResponse uiResponse = mapper.readValue(responseString, VoidOrderUIResponse.class);
		URI url = URI.create("http://localhost/voidOrder");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.voidOrder(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.voidOrder(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void voidOrderTest2() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/assignMtnE911Request.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		VoidOrderUIRequest request = mapper.readValue(requestString, VoidOrderUIRequest.class);
		VoidOrderUIResponse uiResponse = mapper.readValue(responseString, VoidOrderUIResponse.class);
		URI url = URI.create("http://localhost/voidOrder");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "OMNI-CARE").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.voidOrder(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.voidOrder(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void manualPairingTest() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/AALrequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{}";
		ManualPairingUIRequest request = mapper.readValue(requestString, ManualPairingUIRequest.class);
		ManualPairingUIResponse uiResponse = mapper.readValue(responseString, ManualPairingUIResponse.class);
		URI url = URI.create("http://localhost/manual-pairing");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.manualPairing(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.manualPairing(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void manualPairingTest2() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/assignMtnE911Request.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		ManualPairingUIRequest request = mapper.readValue(requestString, ManualPairingUIRequest.class);
		ManualPairingUIResponse uiResponse = mapper.readValue(responseString, ManualPairingUIResponse.class);
		URI url = URI.create("http://localhost/manual-pairing");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "OMNI-CARE").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.manualPairing(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.manualPairing(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void splitExceededAmountTest() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/AALrequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{}";
		SplitExceededAmountUIRequest request = mapper.readValue(requestString, SplitExceededAmountUIRequest.class);
		SplitExceededAmountUIResponse uiResponse = mapper.readValue(responseString, SplitExceededAmountUIResponse.class);
		URI url = URI.create("http://localhost/splitExceededAmount");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.splitExceededAmount(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.splitExceededAmount(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void splitExceededAmountTest2() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/assignMtnE911Request.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		SplitExceededAmountUIRequest request = mapper.readValue(requestString, SplitExceededAmountUIRequest.class);
		SplitExceededAmountUIResponse uiResponse = mapper.readValue(responseString, SplitExceededAmountUIResponse.class);
		URI url = URI.create("http://localhost/splitExceededAmount");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "OMNI-CARE").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.splitExceededAmount(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.splitExceededAmount(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void ispuToDfillTest() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/AALrequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{}";
		IspuToDfillUIRequest request = mapper.readValue(requestString, IspuToDfillUIRequest.class);
		IspuToDfillUIResponse uiResponse = mapper.readValue(responseString, IspuToDfillUIResponse.class);
		URI url = URI.create("http://localhost/ispuToDfill");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.ispuToDfill(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.ispuToDfill(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void ispuToDfillTest2() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/assignMtnE911Request.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		IspuToDfillUIRequest request = mapper.readValue(requestString, IspuToDfillUIRequest.class);
		IspuToDfillUIResponse uiResponse = mapper.readValue(responseString, IspuToDfillUIResponse.class);
		URI url = URI.create("http://localhost/ispuToDfill");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.ispuToDfill(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.ispuToDfill(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void ispuToDfillTest3() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/assignMtnE911Request.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		IspuToDfillUIRequest request = mapper.readValue(requestString, IspuToDfillUIRequest.class);
		IspuToDfillUIResponse uiResponse = mapper.readValue(responseString, IspuToDfillUIResponse.class);
		URI url = URI.create("http://localhost/ispuToDfill");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.ispuToDfill(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.ispuToDfill(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void cancelCaseTest() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/AALrequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{}";
		CancelCaseUIRequest request = mapper.readValue(requestString, CancelCaseUIRequest.class);
		CancelCaseUIResponse uiResponse = mapper.readValue(responseString, CancelCaseUIResponse.class);
		URI url = URI.create("http://localhost/cancelCase");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		String redisData = "{\"cartId\":\"871ebc69-5440-47a6-803e-832f814fdf42\",\"caseId\":\"SOP-15426433-C01\",\"intendType\":\"NSE\",\"cartCreator\":\"410164408\",\"cartCount\":\"1\",\"locationCode\":\"0026301\",\"storeLocationState\":\"NJ\",\"isSmartphone\":false,\"isAppleDevice\":false,\"creditAppNum\":\"410164408\",\"safeTechSessionId\":\"4ccad69dfbdf4d6d8d65d986\",\"verifiedName\":\"sravya test\",\"creditCheckFailedCount\":0,\"repId\":\"ENC\",\"storeName\":\"Atlantic City\",\"loggedInUser\":\"buthasr\",\"repRole\":\"POSSYSTST\",\"customerType\":\"N\",\"mobilityCreditApplicationNum\":\"410164408\",\"isfiveGUpSellSelected\":false,\"isDirectApply\":true}";
		CartRedisData sampleRedisData1 = mapper.readValue(redisData, CartRedisData.class);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData1));
		when(helper.cancelCase(Mockito.any())).thenReturn(Mono.just(uiResponse));
		when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.cancelCase(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void cancelCaseTest2() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/assignMtnE911Request.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		CancelCaseUIRequest request = mapper.readValue(requestString, CancelCaseUIRequest.class);
		CancelCaseUIResponse uiResponse = mapper.readValue(responseString, CancelCaseUIResponse.class);
		URI url = URI.create("http://localhost/cancelCase");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		String redisData = "{\"cartId\":\"871ebc69-5440-47a6-803e-832f814fdf42\",\"caseId\":\"SOP-15426433-C01\",\"intendType\":\"NSE\",\"cartCreator\":\"410164408\",\"cartCount\":\"1\",\"locationCode\":\"0026301\",\"storeLocationState\":\"NJ\",\"isSmartphone\":false,\"isAppleDevice\":false,\"creditAppNum\":\"410164408\",\"safeTechSessionId\":\"4ccad69dfbdf4d6d8d65d986\",\"verifiedName\":\"sravya test\",\"creditCheckFailedCount\":0,\"repId\":\"ENC\",\"storeName\":\"Atlantic City\",\"loggedInUser\":\"buthasr\",\"repRole\":\"POSSYSTST\",\"customerType\":\"N\",\"mobilityCreditApplicationNum\":\"410164408\",\"isfiveGUpSellSelected\":false,\"isDirectApply\":true}";
		CartRedisData sampleRedisData1 = mapper.readValue(redisData, CartRedisData.class);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData1));
		when(helper.cancelCase(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.cancelCase(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void cancelCaseTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"data\": {},\"cartInfo\": {\"intendType\": \"NSE\"}}";
		String responseString = "{}";
		CancelCaseUIRequest request = mapper.readValue(requestString, CancelCaseUIRequest.class);
		CancelCaseUIResponse uiResponse = mapper.readValue(responseString, CancelCaseUIResponse.class);
		URI url = URI.create("http://localhost/cancelCase");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		String redisData = "{\"cartId\":\"871ebc69-5440-47a6-803e-832f814fdf42\",\"caseId\":\"SOP-15426433-C01\",\"intendType\":\"NSE\",\"cartCreator\":\"410164408\",\"cartCount\":\"1\",\"locationCode\":\"0026301\",\"storeLocationState\":\"NJ\",\"isSmartphone\":false,\"isAppleDevice\":false,\"creditAppNum\":\"410164408\",\"safeTechSessionId\":\"4ccad69dfbdf4d6d8d65d986\",\"verifiedName\":\"sravya test\",\"creditCheckFailedCount\":0,\"repId\":\"ENC\",\"storeName\":\"Atlantic City\",\"loggedInUser\":\"buthasr\",\"repRole\":\"POSSYSTST\",\"customerType\":\"N\",\"mobilityCreditApplicationNum\":\"410164408\",\"isfiveGUpSellSelected\":false,\"isDirectApply\":true}";
		CartRedisData sampleRedisData1 = mapper.readValue(redisData, CartRedisData.class);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData1));
		when(helper.cancelCase(Mockito.any())).thenReturn(Mono.just(uiResponse));
		when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.cancelCase(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void cancelCaseflexV2Test() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"data\": {},\"cartInfo\": {\"processStep\": \"OrderReview-Shipping\"}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-RETAIL\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2024.09.13.16.06.27-523.8383235378662\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-15429021-C01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Close\",\"availablePaths\":[{\"path\":\"OrderReview-Shipping\"}]},\"cartInfo\":{\"cartId\":\"\",\"statusMsg\":\"\"},\"customerInfo\":{\"customerType\":\"N\",\"originalCreditApprovalNumber\":\"416164410\",\"nocByod\":false,\"accountNumber\":\"\",\"cartCreator\":\"416164410\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"noc\":false,\"myvPage\":false}}}}}";
		CancelCaseUIRequest request = mapper.readValue(requestString, CancelCaseUIRequest.class);
		CancelCaseUIResponse uiResponse = mapper.readValue(responseString, CancelCaseUIResponse.class);
		URI url = URI.create("http://localhost/flexV2/cancelCase");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		String redisData = "{\"cartId\":\"871ebc69-5440-47a6-803e-832f814fdf42\",\"caseId\":\"SOP-15426433-C01\",\"intendType\":\"NSE\",\"cartCreator\":\"410164408\",\"cartCount\":\"1\",\"locationCode\":\"0026301\",\"storeLocationState\":\"NJ\",\"isSmartphone\":false,\"isAppleDevice\":false,\"creditAppNum\":\"410164408\",\"safeTechSessionId\":\"4ccad69dfbdf4d6d8d65d986\",\"verifiedName\":\"sravya test\",\"creditCheckFailedCount\":0,\"repId\":\"ENC\",\"storeName\":\"Atlantic City\",\"loggedInUser\":\"buthasr\",\"repRole\":\"POSSYSTST\",\"customerType\":\"N\",\"mobilityCreditApplicationNum\":\"410164408\",\"isfiveGUpSellSelected\":false,\"isDirectApply\":true}";
		CartRedisData sampleRedisData1 = mapper.readValue(redisData, CartRedisData.class);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData1));
		when(helper.cancelCase(Mockito.any())).thenReturn(Mono.just(uiResponse));
		when(redisHelper.deleteCartIdAndCaseIdFromRedis()).thenReturn(Mono.just(1L));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.cancelCase(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		//NSE
		redisData="{\"cartId\":\"871ebc69-5440-47a6-803e-832f814fdf42\",\"caseId\":\"SOP-15426433-C01\",\"intendType\":\"NSE\",\"cartCreator\":\"410164408\",\"cartCount\":\"1\",\"locationCode\":\"0026301\",\"storeLocationState\":\"NJ\",\"isSmartphone\":false,\"isAppleDevice\":false,\"creditAppNum\":\"410164408\",\"safeTechSessionId\":\"4ccad69dfbdf4d6d8d65d986\",\"verifiedName\":\"test\",\"creditCheckFailedCount\":0,\"repId\":\"ENC\",\"storeName\":\"Atlantic City\",\"loggedInUser\":\"buthasr\",\"repRole\":\"POSSYSTST\",\"customerType\":\"N\",\"mobilityCreditApplicationNum\":\"410164408\",\"isfiveGUpSellSelected\":false,\"isDirectApply\":true}";
		sampleRedisData1 = mapper.readValue(redisData, CartRedisData.class);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData1));
		response = cartController2.cancelCase(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		//intentType
		redisData="{\"cartId\":\"871ebc69-5440-47a6-803e-832f814fdf42\",\"caseId\":\"SOP-15426433-C01\",\"intendType\":\"EUP\",\"cartCreator\":\"410164408\",\"cartCount\":\"1\",\"locationCode\":\"0026301\",\"storeLocationState\":\"NJ\",\"isSmartphone\":false,\"isAppleDevice\":false,\"creditAppNum\":\"410164408\",\"safeTechSessionId\":\"4ccad69dfbdf4d6d8d65d986\",\"verifiedName\":\"test\",\"creditCheckFailedCount\":0,\"repId\":\"ENC\",\"storeName\":\"Atlantic City\",\"loggedInUser\":\"buthasr\",\"repRole\":\"POSSYSTST\",\"customerType\":\"Y\",\"mobilityCreditApplicationNum\":\"410164408\",\"isfiveGUpSellSelected\":false,\"isDirectApply\":true}";
		sampleRedisData1 = mapper.readValue(redisData, CartRedisData.class);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData1));
		response = cartController2.cancelCase(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		//intentType null
		redisData="{\"cartId\":\"871ebc69-5440-47a6-803e-832f814fdf42\",\"caseId\":\"SOP-15426433-C01\",\"cartCreator\":\"410164408\",\"cartCount\":\"1\",\"locationCode\":\"0026301\",\"storeLocationState\":\"NJ\",\"isSmartphone\":false,\"isAppleDevice\":false,\"creditAppNum\":\"410164408\",\"safeTechSessionId\":\"4ccad69dfbdf4d6d8d65d986\",\"verifiedName\":\"test\",\"creditCheckFailedCount\":0,\"repId\":\"ENC\",\"storeName\":\"Atlantic City\",\"loggedInUser\":\"buthasr\",\"repRole\":\"POSSYSTST\",\"mobilityCreditApplicationNum\":\"410164408\",\"isfiveGUpSellSelected\":false,\"isDirectApply\":true}";
		sampleRedisData1 = mapper.readValue(redisData, CartRedisData.class);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData1));
		response = cartController2.cancelCase(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		request.getCartInfo().setFlexV2(false);
		url = URI.create("http://localhost/cancelCase");
		httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").build();
		response = cartController2.cancelCase(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "DIGITAL").build();
		response = cartController2.cancelCase(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

		//header
		url=URI.create("http://localhost");
		httpHeader=MockServerHttpRequest.method(HttpMethod.POST,url ).build();
		response = cartController2.cancelCase(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void activateOrSetupLaterTest() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/AALrequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{}";
		ActivateLaterUIRequest request = mapper.readValue(requestString, ActivateLaterUIRequest.class);
		ActivateLaterUIResponse uiResponse = mapper.readValue(responseString, ActivateLaterUIResponse.class);
		URI url = URI.create("http://localhost/activateOrSetupLater");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.activateOrSetupLater(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.activateOrSetupLater(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void activateOrSetupLaterTest2() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/assignMtnE911Request.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		ActivateLaterUIRequest request = mapper.readValue(requestString, ActivateLaterUIRequest.class);
		ActivateLaterUIResponse uiResponse = mapper.readValue(responseString, ActivateLaterUIResponse.class);
		URI url = URI.create("http://localhost/activateOrSetupLater");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.activateOrSetupLater(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.activateOrSetupLater(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void addTransferUpgradeTest() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/AALrequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{}";
		UpdateTransferUpgradeUIRequest request = mapper.readValue(requestString, UpdateTransferUpgradeUIRequest.class);
		UpdateTransferUpgradeUIResponse uiResponse = mapper.readValue(responseString, UpdateTransferUpgradeUIResponse.class);
		URI url = URI.create("http://localhost/addTransferUpgrade");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.addTransferUpgrade(Mockito.any())).thenReturn(Mono.just(uiResponse));
		when(redisHelper.upsertAlternateUpgradeDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.addTransferUpgrade(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void addTransferUpgradeTest2() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/addTransferUpgradeE911Request.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		UpdateTransferUpgradeUIRequest request = mapper.readValue(requestString, UpdateTransferUpgradeUIRequest.class);
		UpdateTransferUpgradeUIResponse uiResponse = mapper.readValue(responseString, UpdateTransferUpgradeUIResponse.class);
		URI url = URI.create("http://localhost/addTransferUpgrade");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.addTransferUpgrade(Mockito.any())).thenReturn(Mono.just(uiResponse));
		when(redisHelper.upsertAlternateUpgradeDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.addTransferUpgrade(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void addTransferUpgradeTest3() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/addTransferUpgradeE911Request.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{}";
		UpdateTransferUpgradeUIRequest request = mapper.readValue(requestString, UpdateTransferUpgradeUIRequest.class);
		UpdateTransferUpgradeUIResponse uiResponse = mapper.readValue(responseString, UpdateTransferUpgradeUIResponse.class);
		URI url = URI.create("http://localhost/addTransferUpgrade");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.addTransferUpgrade(Mockito.any())).thenReturn(Mono.just(uiResponse));
		when(redisHelper.upsertAlternateUpgradeDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.addTransferUpgrade(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void removeTransferUpgradeTest() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/AALrequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{}";
		UpdateTransferUpgradeUIRequest request = mapper.readValue(requestString, UpdateTransferUpgradeUIRequest.class);
		UpdateTransferUpgradeUIResponse uiResponse = mapper.readValue(responseString, UpdateTransferUpgradeUIResponse.class);
		URI url = URI.create("http://localhost/removeTransferUpgrade");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.removeTransferUpgrade(Mockito.any())).thenReturn(Mono.just(uiResponse));
		when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(new ErrorResponse());
		when(redisHelper.deleteAlternateUpgradeDataIntoRedis(Mockito.any())).thenReturn(Mono.just(1L));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.removeTransferUpgrade(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void removeTransferUpgradeTest2() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/assignMtnE911Request.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		UpdateTransferUpgradeUIRequest request = mapper.readValue(requestString, UpdateTransferUpgradeUIRequest.class);
		UpdateTransferUpgradeUIResponse uiResponse = mapper.readValue(responseString, UpdateTransferUpgradeUIResponse.class);
		URI url = URI.create("http://localhost/removeTransferUpgrade");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "OMNI-CARE").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.removeTransferUpgrade(Mockito.any())).thenReturn(Mono.just(uiResponse));
		when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
		when(redisHelper.deleteAlternateUpgradeDataIntoRedis(Mockito.any())).thenReturn(Mono.just(1L));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.removeTransferUpgrade(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void removeTransferUpgradeTest3() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/mtnNpaNxxE911Request.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{}";
		UpdateTransferUpgradeUIRequest request = mapper.readValue(requestString, UpdateTransferUpgradeUIRequest.class);
		UpdateTransferUpgradeUIResponse uiResponse = mapper.readValue(responseString, UpdateTransferUpgradeUIResponse.class);
		URI url = URI.create("http://localhost/removeTransferUpgrade");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.removeTransferUpgrade(Mockito.any())).thenReturn(Mono.just(uiResponse));
		when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
		when(redisHelper.deleteAlternateUpgradeDataIntoRedis(Mockito.any())).thenReturn(Mono.just(1L));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.removeTransferUpgrade(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void removeTransferUpgradeTest4() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/mtnNpaNxxE911Request.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		UpdateTransferUpgradeUIRequest request = mapper.readValue(requestString, UpdateTransferUpgradeUIRequest.class);
		UpdateTransferUpgradeUIResponse uiResponse = mapper.readValue(responseString, UpdateTransferUpgradeUIResponse.class);
		URI url = URI.create("http://localhost/removeTransferUpgrade");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.removeTransferUpgrade(Mockito.any())).thenReturn(Mono.just(uiResponse));
		when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
		when(redisHelper.deleteAlternateUpgradeDataIntoRedis(Mockito.any())).thenReturn(Mono.just(1L));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.removeTransferUpgrade(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void addNickNameTest() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/AALrequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{}";
		AddNickNameUIRequest request = mapper.readValue(requestString, AddNickNameUIRequest.class);
		AddNickNameUIResponse uiResponse = mapper.readValue(responseString, AddNickNameUIResponse.class);
		URI url = URI.create("http://localhost/addNickName");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.addNickName(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.addNickName(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void addNickNameTest2() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/assignMtnE911Request.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		AddNickNameUIRequest request = mapper.readValue(requestString, AddNickNameUIRequest.class);
		AddNickNameUIResponse uiResponse = mapper.readValue(responseString, AddNickNameUIResponse.class);
		URI url = URI.create("http://localhost/addNickName");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.addNickName(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.addNickName(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void addNickNameTest3() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/assignMtnE911Request.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		AddNickNameUIRequest request = mapper.readValue(requestString, AddNickNameUIRequest.class);
		AddNickNameUIResponse uiResponse = mapper.readValue(responseString, AddNickNameUIResponse.class);
		URI url = URI.create("http://localhost/addNickName");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.addNickName(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.addNickName(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void bbpAddZipCodeTest() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/AALrequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		AddZipCodeUIRequest request = mapper.readValue(requestString, AddZipCodeUIRequest.class);
		URI url = URI.create("http://localhost");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(redisHelper2.upsertBBPFlowZipCodeDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
		when(validator.convertObjectToString(Mockito.<AddZipcodeRedisData>any())).thenReturn(new AddZipcodeRedisData());
		Mono<ResponseEntity<AddZipcodeRedisData>> response = cartController2.bbpAddZipCode(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void bbpAddZipCodeTest2() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/bbpAddZipCodeRequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		//String requestString = "{\"zipCode\": \"zip\",\"data\": {\"lines\": [{\"npaNxx\": \"\",\"mtn\": \"mtn\"}]},\"cartInfo\": {\"processStep\": \"E911\"}}";
		AddZipCodeUIRequest request = mapper.readValue(requestString, AddZipCodeUIRequest.class);
		URI url = URI.create("http://localhost/addZipcode");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(redisHelper2.upsertBBPFlowZipCodeDataIntoRedis(Mockito.any())).thenReturn(Mono.just(false));
		Mono<ResponseEntity<AddZipcodeRedisData>> response = cartController2.bbpAddZipCode(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void bbpAddZipCodeTest3() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/assignMtnE911Request.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		AddZipCodeUIRequest request = mapper.readValue(requestString, AddZipCodeUIRequest.class);
		URI url = URI.create("http://localhost/nse/addZipcode");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.addZipcode(Mockito.any())).thenReturn(Mono.just(new AddZipcodeRedisData()));
		when(redisHelper2.upsertBBPFlowZipCodeDataIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
		Mono<ResponseEntity<AddZipcodeRedisData>> response = cartController2.bbpAddZipCode(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateVZCCAppStatusTest() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/updateVZCCAppStatusRequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{}";
		VZCCAppStatusUIRequest request = mapper.readValue(requestString, VZCCAppStatusUIRequest.class);
		VZCCAppStatusUIResponse uiResponse = mapper.readValue(responseString, VZCCAppStatusUIResponse.class);
		URI url = URI.create("http://localhost/vzccFeedbackStatus");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.updateVZCCAppStatus(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.updateVZCCAppStatus(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateVZCCAppStatus2() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/assignMtnE911Request.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{}";
		VZCCAppStatusUIRequest request = mapper.readValue(requestString, VZCCAppStatusUIRequest.class);
		VZCCAppStatusUIResponse uiResponse = mapper.readValue(responseString, VZCCAppStatusUIResponse.class);
		URI url = URI.create("http://localhost/vzccFeedbackStatus");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.updateVZCCAppStatus(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.updateVZCCAppStatus(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateVZCCAppStatusTest3() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/assignMtnE911Request.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		VZCCAppStatusUIRequest request = mapper.readValue(requestString, VZCCAppStatusUIRequest.class);
		VZCCAppStatusUIResponse uiResponse = mapper.readValue(responseString, VZCCAppStatusUIResponse.class);
		URI url = URI.create("http://localhost/nse/vzccFeedbackStatus");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.updateVZCCAppStatus(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.updateVZCCAppStatus(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}


	@Test
	public void removeBvoOffersTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"chatId\": \"\"}";
		String responseString = "{}";
		UpdateBvoOffersUIRequest request = mapper.readValue(requestString, UpdateBvoOffersUIRequest.class);
		UpdateBvoOffersUIResponse uiResponse = mapper.readValue(responseString, UpdateBvoOffersUIResponse.class);
		URI url = URI.create("http://localhost/removeOffers");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.removeBvoOffers(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.removeBvoOffers(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void removeBvoOffersTest2() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"chatId\": \"AAL\"}";
		String responseString = "{\"errors\": [{}]}";
		UpdateBvoOffersUIRequest request = mapper.readValue(requestString, UpdateBvoOffersUIRequest.class);
		UpdateBvoOffersUIResponse uiResponse = mapper.readValue(responseString, UpdateBvoOffersUIResponse.class);
		URI url = URI.create("http://localhost/removeOffers");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.removeBvoOffers(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.removeBvoOffers(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateWFMInfoTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"data\": {},\"cartInfo\": {\"intent\": \"AAL\"}}";
		String responseString = "{}";
		UpdateWFMInfoUIRequest request = mapper.readValue(requestString, UpdateWFMInfoUIRequest.class);
		UpdateWFMInfoUIResponse uiResponse = mapper.readValue(responseString, UpdateWFMInfoUIResponse.class);
		URI url = URI.create("http://localhost/updateWFMInfo");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.updateWFMInfo(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.updateWFMInfo(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateWFMInfoTest2() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/updateWFMInfoAALRequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{}";
		UpdateWFMInfoUIRequest request = mapper.readValue(requestString, UpdateWFMInfoUIRequest.class);
		UpdateWFMInfoUIResponse uiResponse = mapper.readValue(responseString, UpdateWFMInfoUIResponse.class);
		URI url = URI.create("http://localhost/updateWFMInfo");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.updateWFMInfo(Mockito.any())).thenReturn(Mono.just(uiResponse));
		when(redisHelper2.updateChatId(Mockito.any())).thenReturn(Mono.just(true));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.updateWFMInfo(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateWFMInfoTest3() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/updateWFMInfoAALRequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		UpdateWFMInfoUIRequest request = mapper.readValue(requestString, UpdateWFMInfoUIRequest.class);
		UpdateWFMInfoUIResponse uiResponse = mapper.readValue(responseString, UpdateWFMInfoUIResponse.class);
		URI url = URI.create("http://localhost/updateWFMInfo");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.updateWFMInfo(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.updateWFMInfo(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateMyOffersTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"data\": {}}";
		String responseString = "{}";
		ApplyOfferRequest request = mapper.readValue(requestString, ApplyOfferRequest.class);
		MyOffersCXPResponse uiResponse = mapper.readValue(responseString, MyOffersCXPResponse.class);
		URI url = URI.create("http://localhost/applyEquipmentOffers");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.updateMyOffers(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<MyOffersCXPResponse>> response = cartController.updateMyOffers(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateMyOffersTest2() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/updateMyOffersTrueRequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{}";
		ApplyOfferRequest request = mapper.readValue(requestString, ApplyOfferRequest.class);
		MyOffersCXPResponse uiResponse = mapper.readValue(responseString, MyOffersCXPResponse.class);
		URI url = URI.create("http://localhost/applyEquipmentOffers");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.updateMyOffers(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<MyOffersCXPResponse>> response = cartController.updateMyOffers(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateMyOffersTest3() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"data\": {\"wfmOrderInfo\": {}},\"cartInfo\": {\"isEquipmentOffer\": false}}";
		String responseString = "{\"errors\": [{}]}";
		ApplyOfferRequest request = mapper.readValue(requestString, ApplyOfferRequest.class);
		MyOffersCXPResponse uiResponse = mapper.readValue(responseString, MyOffersCXPResponse.class);
		URI url = URI.create("http://localhost/applyEquipmentOffers");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.updateMyOffers(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<MyOffersCXPResponse>> response = cartController.updateMyOffers(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateMyOffersTest4() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"data\": {\"wfmOrderInfo\": {}},\"cartInfo\": {}}";
		String responseString = "{\"errors\": [{}]}";
		ApplyOfferRequest request = mapper.readValue(requestString, ApplyOfferRequest.class);
		MyOffersCXPResponse uiResponse = mapper.readValue(responseString, MyOffersCXPResponse.class);
		URI url = URI.create("http://localhost/applyEquipmentOffers");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.updateMyOffers(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<MyOffersCXPResponse>> response = cartController.updateMyOffers(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateMyOffersTest5() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/updateMyOffersTrueRequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		ApplyOfferRequest request = mapper.readValue(requestString, ApplyOfferRequest.class);
		MyOffersCXPResponse uiResponse = mapper.readValue(responseString, MyOffersCXPResponse.class);
		URI url = URI.create("http://localhost/applyEquipmentOffers");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.updateMyOffers(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<MyOffersCXPResponse>> response = cartController.updateMyOffers(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateTradeInOfferTest() throws JsonMappingException, JsonProcessingException {
		String requestString = "{\"data\": {}}";
		String responseString = "{}";
		UpdateTradeInOfferUIRequest request = mapper.readValue(requestString, UpdateTradeInOfferUIRequest.class);
		UpdateTradeInOfferUIResponse uiResponse = mapper.readValue(responseString, UpdateTradeInOfferUIResponse.class);
		URI url = URI.create("http://localhost/updateTradeInOffer");
		MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
		map.put("channelId", null);
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).headers(map).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.updateTradeInOffer(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.updateTradeInOffer(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateTradeInOfferTest2() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/updateMyOffersTrueRequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		UpdateTradeInOfferUIRequest request = mapper.readValue(requestString, UpdateTradeInOfferUIRequest.class);
		UpdateTradeInOfferUIResponse uiResponse = mapper.readValue(responseString, UpdateTradeInOfferUIResponse.class);
		URI url = URI.create("http://localhost/updateTradeInOffer");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.updateTradeInOffer(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.updateTradeInOffer(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void updateTradeInOfferTest3() throws JsonMappingException, JsonProcessingException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/updateMyOffersTrueRequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseString = "{\"errors\": [{}]}";
		UpdateTradeInOfferUIRequest request = mapper.readValue(requestString, UpdateTradeInOfferUIRequest.class);
		UpdateTradeInOfferUIResponse uiResponse = mapper.readValue(responseString, UpdateTradeInOfferUIResponse.class);
		URI url = URI.create("http://localhost/updateTradeInOffer");
		MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
		map.put("channelId", new ArrayList<String>());
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).headers(map).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.updateTradeInOffer(Mockito.any())).thenReturn(Mono.just(uiResponse));
		Mono<ResponseEntity<GenericResponse>> response = cartController2.updateTradeInOffer(httpHeader, httpResponse, request);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void initiateAddReplenishmentRequestErrorsTest() throws IOException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/initiateAddReplenishmentRequestErrorsRequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseFile = "data/CartUpdateOperationsControllerTestJson/initiateAddReplenishmentRequestErrorsResponse.json";
		String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
		String redisDataFile = "data/CartUpdateOperationsControllerTestJson/initiateAddReplenishmentRedisData.json";
		String redisDataString = sourceFileReaderUtil.readFile(redisDataFile, testFileLocation);
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		AddReplenishmentToCartUIRequest request = mapper.readValue(requestString, AddReplenishmentToCartUIRequest.class);
		AddReplenishmentToCartUIResponse response = mapper.readValue(responseString, AddReplenishmentToCartUIResponse.class);
		URI url = URI.create("http://localhost/addReplenishmentOnlyToCart");
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "OMNI-CARE").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
		when(helper.addReplenishmentToCart(Mockito.any())).thenReturn(Mono.just(response));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addReplenishmenttoCart(httpHeader, httpResponse, request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void initiateAddReplenishmentErrorsTest() throws IOException {
		String requestFile = "data/CartUpdateOperationsControllerTestJson/initiateAddReplenishmentErrorsRequest.json";
		String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String responseFile = "data/CartUpdateOperationsControllerTestJson/initiateAddReplenishmentErrorsResponse.json";
		String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
		String redisDataFile = "data/CartUpdateOperationsControllerTestJson/initiateAddReplenishmentRedisData.json";
		String redisDataString = sourceFileReaderUtil.readFile(redisDataFile, testFileLocation);
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		AddReplenishmentToCartUIRequest request = mapper.readValue(requestString, AddReplenishmentToCartUIRequest.class);
		AddReplenishmentToCartUIResponse response = mapper.readValue(responseString, AddReplenishmentToCartUIResponse.class);
		URI url = URI.create("http://localhost/addReplenishmentOnlyToCart");
		//ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.OK);
		when(helper.addReplenishmentToCart(Mockito.any())).thenReturn(Mono.just(response));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addReplenishmenttoCart(httpHeader, httpResponse, request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void addDeviceRedisUpdateTest() throws IOException{
		String requestFile = "AddDeviceRequestTestSubflow.json";
		String responseFile = "AddDeviceResponseTest.json";
		String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
		AddDeviceUIRequest request = mapper.readValue(sampleRequestString, AddDeviceUIRequest.class);
		AddDeviceUIResponse response = mapper.readValue(sampleResponseString, AddDeviceUIResponse.class);
		when(deviceHelper.addDevice(Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
		when(dlUtilityService.getFlowDLData()).thenReturn(Mono.just(new HashMap<>()));
		when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("subFlow"));
		when(dlUtilityService.upsertVZPageSubFLow(anyString(),anyBoolean(),anyString())).thenReturn(Mono.just(Boolean.TRUE));
		//when(dlUtilityService.upsertVZPageSubFLow("pSim",true,CartConstants.SUB_FLOW).thenReturn(true));
		when(helper.populateConflictedSPOsIfPresent(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
		when(helper.populateHumWifiConflictedSFosWithCheck(Mockito.any(), Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(HttpStatus.OK).body(response)));
		ReflectionTestUtils.setField(cartController3,"domains", List.of(".verizon.com",".verizonwireless.com"));
		request.getCartInfo().setIntendType("NSEBYOD");
		URI url = URI.create("http://localhost/add-device");
		ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
		httpResponse.setStatusCode(HttpStatus.OK);
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
		StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();

		request.getCartInfo().setIntendType("BYOD");
		request.getData().setSubFlow("instant");
		controllerResponse = cartController3.addDevice(httpRequest,httpResponse, request);
		StepVerifier.create(controllerResponse).assertNext(resp -> {Assert.assertNotNull(resp);}).expectComplete().verify();

	}

}
