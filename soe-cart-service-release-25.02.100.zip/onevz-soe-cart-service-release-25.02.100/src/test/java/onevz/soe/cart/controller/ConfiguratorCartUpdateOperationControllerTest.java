package onevz.soe.cart.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.exceptions.JsonValidator;
import onevz.soe.cart.helper.CartConfiguratorHelper;
import onevz.soe.cart.helper.FeatureFlagHelper;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.model.retrieveCart.CXPCartVO;
import onevz.soe.cart.model.retrieveCart.RetrieveCartHeader;
import onevz.soe.cart.model.validateCart.CXPValidateCartDataVO;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.ui.requests.AddAllConfiguratorUIRequest;
import onevz.soe.cart.ui.responses.AddAllConfiguratorUIResponse;
import onevz.soe.cart.ui.responses.ValidateCartUIResponse;
import onevz.soe.cart.util.CartConfiguratorPegaRequestErrorsUtil;
import onevz.soe.cart.util.SourceFileReaderUtil;
import org.junit.Assert;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.*;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpResponse;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.ResourceUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@RunWith(SpringJUnit4ClassRunner.class)
@WebFluxTest(ConfiguratorCartUpdateOperationController.class)
public class ConfiguratorCartUpdateOperationControllerTest {
    @MockBean
    private FeatureFlagHelper featureFlagHelper;
    private static final String DOT_COM_CHANNEL_ID = "VZW-DOTCOM";
    private static final String RETAIL_CHANNEL_ID = "OMNI-RETAIL";
    private final String apiPathValue = "/cart/nse/addToCartForConfigurator";
    @MockBean
    CartConfiguratorHelper cartConfiguratorHelper;
    @MockBean
    JsonValidator validator;
    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;
    @Autowired
    private ConfiguratorCartUpdateOperationController configuratorCartUpdateOperationController;
    @Autowired
    private ObjectMapper mapper;
    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;
    @MockBean
    private RedisHelper redisHelper;


    @Test
    public void addCartConfiguratorTest() throws IOException {
        CartRedisData cartRedisData = new CartRedisData();
        cartRedisData.setCartId("5560eeed-2ad2-4634-866b-c4986502594b");
        cartRedisData.setCaseId("SOP-123--E01");

        String requestFile = "data/addAllToCartConfigurator/request/successRequestFormatted.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        AddAllConfiguratorUIRequest request = mapper.readValue(requestString, AddAllConfiguratorUIRequest.class);
        request.setChannelId("VZ-DOTCOM");
        String responseFile = "data/addAllToCartConfigurator/response/successResponse.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAllConfiguratorUIResponse response = mapper.readValue(responseString, AddAllConfiguratorUIResponse.class);

        URI url = URI.create("http://localhost/cart/nse/addToCartForConfigurator");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("channelId", new HttpCookie(DOT_COM_CHANNEL_ID, "true"));
        HttpCookie digitalIgSession = new HttpCookie(CartConstants.DIGITAL_IG_SESSION, "session1");
        bodyMap.add(CartConstants.DIGITAL_IG_SESSION, digitalIgSession);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("channelId", DOT_COM_CHANNEL_ID);
        httpHeaders.add("digital_ig_session", "session1");
        httpHeaders.add(CartConstants.COM_VZ_ID, "vzId");
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).headers(httpHeaders).contextPath(apiPathValue).cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartConfiguratorHelper.addToCartForConfigurator(any())).thenReturn(Mono.just(response));
        when(featureFlagHelper.isNgdAbandonCartFFlag()).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.updateCartIdAndCaseIdIntoRedisForNGD(any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.getCartAndCaseIdFromRedis()).thenReturn(Mono.just(cartRedisData));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = configuratorCartUpdateOperationController.addToCartForConfigurator(serverHttpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(Assertions::assertNotNull).expectComplete().verify();

        httpHeaders = new HttpHeaders();
        httpHeaders.add("digital_ig_session", "session1");
        httpHeaders.add(CartConstants.COM_VZ_ID, "vzId");
        serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST,"").headers(httpHeaders).contextPath("").cookies(bodyMap).build();
        controllerResponse = configuratorCartUpdateOperationController.addToCartForConfigurator(serverHttpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(Assertions::assertNotNull).expectComplete().verify();


        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartId("ABCD");
        request.getCartInfo().setCartId("ABCDE");
        serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST,url).headers(httpHeaders).contextPath(apiPathValue).cookies(bodyMap).build();
        controllerResponse = configuratorCartUpdateOperationController.addToCartForConfigurator(serverHttpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(Assertions::assertNotNull).expectComplete().verify();

        cartRedisData.setCartId(null);
        request.getCartInfo().setCartId(null);
        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartId(null);
        controllerResponse = configuratorCartUpdateOperationController.addToCartForConfigurator(serverHttpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(Assertions::assertNotNull).expectComplete().verify();

        request.getCartInfo().setIntendType("ABC");
        controllerResponse = configuratorCartUpdateOperationController.addToCartForConfigurator(serverHttpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(Assertions::assertNotNull).expectComplete().verify();

        request.setChannelId("ABC");
        controllerResponse = configuratorCartUpdateOperationController.addToCartForConfigurator(serverHttpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(Assertions::assertNotNull).expectComplete().verify();

        when(featureFlagHelper.isNgdAbandonCartFFlag()).thenReturn(Mono.just(Boolean.FALSE));
        controllerResponse = configuratorCartUpdateOperationController.addToCartForConfigurator(serverHttpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(Assertions::assertNotNull).expectComplete().verify();

        when(redisHelper.getCartAndCaseIdFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        controllerResponse = configuratorCartUpdateOperationController.addToCartForConfigurator(serverHttpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(Assertions::assertNotNull).expectComplete().verify();

        response.getServiceBody().getServiceResponse().getContext().setCartInfo(null);
        configuratorCartUpdateOperationController.addDeviceCountCookie(response,httpResponse);
        StepVerifier.create(controllerResponse).assertNext(Assertions::assertNotNull).expectComplete().verify();

    }

    @Test
    public void addCartConfiguratorTestBadRequest() throws IOException {
        String requestFile = "data/addAllToCartConfigurator/request/cartCreatorMissingUIRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        AddAllConfiguratorUIRequest request = mapper.readValue(requestString, AddAllConfiguratorUIRequest.class);
        request.setChannelId("VZ-DOTCOM");
        String responseFile = "data/addAllToCartConfigurator/response/channelBadRequestUIResponse.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAllConfiguratorUIResponse response = mapper.readValue(responseString, AddAllConfiguratorUIResponse.class);

        URI url = URI.create("http://localhost/cart/nse/addToCartForConfigurator");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("channelId", new HttpCookie(RETAIL_CHANNEL_ID, "true"));
        HttpCookie digitalIgSession = new HttpCookie(CartConstants.DIGITAL_IG_SESSION, "session1");
        bodyMap.add(CartConstants.DIGITAL_IG_SESSION, digitalIgSession);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("channelId", RETAIL_CHANNEL_ID);
        httpHeaders.add("digital_ig_session", "session1");
        httpHeaders.add(CartConstants.COM_VZ_ID, "vzId");
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).contextPath(apiPathValue).headers(httpHeaders).cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(cartConfiguratorHelper.addToCartForConfigurator(any())).thenReturn(Mono.just(response));
        when(featureFlagHelper.isNgdAbandonCartFFlag()).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.updateCartIdAndCaseIdIntoRedisForNGD(any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.getCartAndCaseIdFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = configuratorCartUpdateOperationController.addToCartForConfigurator(serverHttpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(Assertions::assertNotNull).expectComplete().verify();
    }

    @Test
    public void addAllPEGAResponseErrorTest() throws IOException {
        File file = ResourceUtils.getFile("classpath:data/addAllToCartConfigurator/request/cartCreatorMissingUIRequest.json");
        String requestString = new String(Files.readAllBytes(file.toPath()));

        file = ResourceUtils.getFile("classpath:data/addAllToCartConfigurator/response/cartCreatorMissingPEGAError.json");
        String responseString = new String(Files.readAllBytes(file.toPath()));

        AddAllConfiguratorUIRequest request = mapper.readValue(requestString, AddAllConfiguratorUIRequest.class);
        request.setChannelId(DOT_COM_CHANNEL_ID);
        AddAllConfiguratorUIResponse response = mapper.readValue(responseString, AddAllConfiguratorUIResponse.class);
        URI url = URI.create("http://localhost/cart/nse/addToCartForConfigurator");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("channelId", new HttpCookie(DOT_COM_CHANNEL_ID, "true"));
        HttpCookie digitalIgSession = new HttpCookie(CartConstants.DIGITAL_IG_SESSION, "session1");
        bodyMap.add(CartConstants.DIGITAL_IG_SESSION, digitalIgSession);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("channelId", DOT_COM_CHANNEL_ID);
        httpHeaders.add("digital_ig_session", "session1");
        httpHeaders.add(CartConstants.COM_VZ_ID, "vzId");
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).contextPath(apiPathValue).headers(httpHeaders).cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(featureFlagHelper.isNgdAbandonCartFFlag()).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.updateCartIdAndCaseIdIntoRedisForNGD(any())).thenReturn(Mono.just(Boolean.TRUE));
        when(redisHelper.getCartAndCaseIdFromRedis()).thenReturn(Mono.just(new CartRedisData()));
        when(cartConfiguratorHelper.addToCartForConfigurator(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = configuratorCartUpdateOperationController.addToCartForConfigurator(serverHttpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(Assertions::assertNotNull).expectComplete().verify();


    }

    @Test
    public void removeSensitiveInfoForAssignMTNTest() throws IOException {

        String requestFile = "data/addAllToCartConfigurator/request/successRequestFormatted.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        AddAllConfiguratorUIRequest request = mapper.readValue(requestString, AddAllConfiguratorUIRequest.class);
        request.setChannelId("VZW-DOTCOM");
        String responseFile = "data/addAllToCartConfigurator/response/successResponse.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAllConfiguratorUIResponse response = mapper.readValue(responseString, AddAllConfiguratorUIResponse.class);
        configuratorCartUpdateOperationController.removeSensitiveInfo(request, response);
        Assert.assertNotNull(request.getChannelId());
        Assert.assertNotNull(response.getServiceBody().getServiceResponse());
        response.getServiceBody().getServiceResponse().getContext().setCartInfo(null);
        configuratorCartUpdateOperationController.removeSensitiveInfo(request, response);
        Assert.assertNotNull(request.getChannelId());
        Assert.assertNotNull(response.getServiceBody().getServiceResponse());

        response.setValidateCartResponse(new ValidateCartUIResponse());
        response.getValidateCartResponse().setData(new CXPValidateCartDataVO());
        response.getValidateCartResponse().getData().setValidateCartAndUpdate(new CXPCartVO());
        response.getValidateCartResponse().getData().getValidateCartAndUpdate().setCartHeader(new RetrieveCartHeader());
        configuratorCartUpdateOperationController.removeSensitiveInfo(request, response);
        Assert.assertNotNull(request.getChannelId());
        Assert.assertNotNull(response.getServiceBody());

        response.getServiceBody().getServiceResponse().setContext(null);
        configuratorCartUpdateOperationController.removeSensitiveInfo(request, response);

        response.getServiceBody().setServiceResponse(null);
        configuratorCartUpdateOperationController.removeSensitiveInfo(request, response);

        request.setChannelId("abc");
        configuratorCartUpdateOperationController.removeSensitiveInfo(request, response);
        Assert.assertNotNull(request.getChannelId());

        response.setServiceBody(null);
        configuratorCartUpdateOperationController.removeSensitiveInfo(request, response);

        response=null;
        configuratorCartUpdateOperationController.removeSensitiveInfo(request, response);

    }

    @Test
    public void testAddCartCountCookie_ServiceBodyNull() {
        AddAllConfiguratorUIResponse pegaResponse = mock(AddAllConfiguratorUIResponse.class);
        ServerHttpResponse httpResponse = mock(ServerHttpResponse.class);

        when(pegaResponse.getServiceBody()).thenReturn(null);
        configuratorCartUpdateOperationController.addCartCountCookie(pegaResponse,httpResponse);
        verify(httpResponse,never()).addCookie(any());
    }

    @Test
    public void testDeviceCountCookie_ServiceBodyNull() {
        AddAllConfiguratorUIResponse pegaResponse = mock(AddAllConfiguratorUIResponse.class);
        ServerHttpResponse httpResponse = mock(ServerHttpResponse.class);

        when(pegaResponse.getServiceBody()).thenReturn(null);
        configuratorCartUpdateOperationController.addDeviceCountCookie(pegaResponse,httpResponse);
        verify(httpResponse,never()).addCookie(any());
    }

    @Test
    public void addDeviceCountCookieTest() throws JsonProcessingException {

        String responseFile = "data/addAllToCartConfigurator/response/successResponse.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddAllConfiguratorUIResponse response = mapper.readValue(responseString, AddAllConfiguratorUIResponse.class);

        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);

        configuratorCartUpdateOperationController.addDeviceCountCookie(response,httpResponse);
        Assert.assertNotNull(response.getServiceBody());
        Assert.assertNotNull(httpResponse);

        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setLineDevices(null);
        configuratorCartUpdateOperationController.addDeviceCountCookie(response,httpResponse);
        Assert.assertNotNull(response.getServiceBody());
        Assert.assertNotNull(httpResponse);

        response.getServiceBody().getServiceResponse().getContext().setCartInfo(null);
        configuratorCartUpdateOperationController.addDeviceCountCookie(response,httpResponse);

        response.getServiceBody().getServiceResponse().setContext(null);
        configuratorCartUpdateOperationController.addDeviceCountCookie(response,httpResponse);

        response.getServiceBody().setServiceResponse(null);
        configuratorCartUpdateOperationController.addDeviceCountCookie(response,httpResponse);
        Assert.assertNotNull(response.getServiceBody());
        Assert.assertNotNull(httpResponse);

        response.setServiceBody(null);
        configuratorCartUpdateOperationController.addDeviceCountCookie(response,httpResponse);
        Assert.assertNull(response.getServiceBody());
        response=null;
        configuratorCartUpdateOperationController.addDeviceCountCookie(response,httpResponse);
        Assert.assertNull(response);
    }

    @Test
    public void populateAddAllConfiguratorUIRequestTest() throws JsonProcessingException {
        String requestFile = "data/addAllToCartConfigurator/request/successRequestFormatted.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        AddAllConfiguratorUIRequest request = mapper.readValue(requestString, AddAllConfiguratorUIRequest.class);
        request.setChannelId("VZW-DOTCOM");
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        URI url = URI.create("http://localhost/cart/nse/addToCartForConfigurator");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("channelId", new HttpCookie(DOT_COM_CHANNEL_ID, "true"));
        HttpCookie digitalIgSession = new HttpCookie(CartConstants.DIGITAL_IG_SESSION, "session1");
        bodyMap.add(CartConstants.DIGITAL_IG_SESSION, digitalIgSession);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("channelId", DOT_COM_CHANNEL_ID);
        httpHeaders.add("digital_ig_session", "session1");
        httpHeaders.add(CartConstants.COM_VZ_ID, "vzId");
        MockServerHttpRequest serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).headers(httpHeaders).contextPath(apiPathValue).cookies(bodyMap).build();

        configuratorCartUpdateOperationController.populateAddAllConfiguratorUIRequest(serverHttpRequest,request,httpResponse);
        Assert.assertNotNull(serverHttpRequest);
        Assert.assertNotNull(request);
        Assert.assertNotNull(httpResponse);

        request.getCartInfo().setIntendType("ABC");
        configuratorCartUpdateOperationController.populateAddAllConfiguratorUIRequest(serverHttpRequest,request,httpResponse);
        bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("channelId", new HttpCookie(DOT_COM_CHANNEL_ID, "true"));
        serverHttpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).headers(httpHeaders).contextPath(apiPathValue).cookies(bodyMap).build();
        configuratorCartUpdateOperationController.populateAddAllConfiguratorUIRequest(serverHttpRequest,request,httpResponse);
        Assert.assertNotNull(serverHttpRequest);
        Assert.assertNotNull(request);
        Assert.assertNotNull(httpResponse);
        request.setChannelId("ABC");
        configuratorCartUpdateOperationController.populateAddAllConfiguratorUIRequest(serverHttpRequest,request,httpResponse);

    }
 }
