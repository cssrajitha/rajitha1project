package onevz.soe.cart.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.helper.DeviceSimValidationService;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.DeviceIdValidationUIRequest;
import onevz.soe.cart.ui.requests.ProductInquiryUIRequest;
import onevz.soe.cart.ui.responses.DeviceIdValidationUIResponse;
import onevz.soe.cart.ui.responses.ProductInquiryUIResponse;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpResponse;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.net.URI;

import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { CartServiceTestConfig.class })

public class DeviceSimValidationControllerTest {

    @Autowired
    private DeviceSimValidationController controller;
    @MockBean
    CartReadOperationsController pegaController;
    @Autowired
    private ObjectMapper mapper;
    @MockBean
    DeviceSimValidationService service;

    @Test
    public void deviceIdValidation() {
        ProductInquiryUIRequest sampleUIRequest= new ProductInquiryUIRequest();
        ProductInquiryUIResponse expectedResponse = new ProductInquiryUIResponse();
        sampleUIRequest.setDeviceId("357067262838780");
        sampleUIRequest.setIccId("89148000009224838443");
        expectedResponse.setReturnMessage("success");
        expectedResponse.setReturnCode("000");
        Assert.assertNotNull(sampleUIRequest);
        URI url = URI.create("http://localhost/product-inquiry");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header(CartConstants.CHANNEL_ID, "OMNI-TELESALES").build();
        String channel = "OMNI-TELESALES";
        ReflectionTestUtils.setField(controller,"deviceSimValidationService", service);
        when(service.processDeviceProductInquiry(sampleUIRequest,channel)).thenReturn(Mono.just(expectedResponse));
        Mono<ProductInquiryUIResponse> uiResponseMono = controller.deviceIdValidation(httpHeader , sampleUIRequest);
        StepVerifier.create(uiResponseMono).assertNext(r -> Assert.assertNotNull(r)).expectComplete().verify();
    }

    @Test
    public void combinedValidation() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"cartCreator\":\"\",\"cartId\":\"c7158b23-0d50-4334-81c0-0782a84be873\",\"caseId\":\"SOF-138001-E01\",\"creditAppNum\":\"417048672\",\"processingMTN\":\"9363292629\",\"accountNumber\":\"\",\"intent\":\"NSEBYOD\",\"intendType\":\"NSEBYOD\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":\"validateDeviceSim\",\"action\":\"NSE\"},\"data\":{\"lines\":[{\"mtn\":\"9363292629\",\"mtnType\":\"\",\"eskuId\":\"\",\"device\":{\"id\":\"357067262838780\",\"Flowtype\":\"SIM\",\"CurrentId\":\"\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":false,\"sim\":{\"id\":\"89148000009224838443\",\"sku\":\"\",\"isCustomerProvidedSIM\":true,\"CurrentSimid\":\"\"}}}]},\"disableEsimAtLocalInventory\":false}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-RETAIL\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderFlex\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.09.27.04.51.15-519.4059404273995\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOF-138001-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderFlex\",\"processStep\":\"GridWallPDP\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"GridWallPDP\"}]},\"customerInfo\":{\"customerType\":\"N\",\"originalCreditApprovalNumber\":\"417048672\",\"accountNumber\":\"\",\"cartCreator\":\"417048672\",\"processingMTN\":\"\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"c7158b23-0d50-4334-81c0-0782a84be873\",\"couponCode\":\"\",\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false},\"deviceInfo\":{\"simInfo\":{\"iccid\":\"89148000009224838443\",\"mfgCode\":\"GTO\",\"launchPackageSku\":\"DFILLSIM5G-SA-A\",\"prodName\":\"GTO 4G 5G Interim DFILL SIM\",\"preferredSoftSim\":\"DFILLSIM5G-SA-A\",\"launchPackageSkuType\":\"SMA135UZKV\",\"pairedIccid\":\"\",\"type\":\"5GS\",\"mtn\":\"\",\"mobileNumber\":\"\",\"active\":false,\"aging\":false,\"available\":true,\"retired\":false,\"grandFathered\":false,\"status\":\"00000\",\"euimid\":\"A00000FFD61BD0\",\"imsiv\":\"311480867119419\",\"imsivf\":\"\",\"iccIdStat\":\"AA\",\"min\":\"\",\"ispuCompatibleSIM\":\"BULKSIM5G-SA-A\",\"makeEtniPersApi\":false,\"deviceId\":\"357067262838780\",\"dfillCompatibleSim\":\"DFILLSIM5G-SA-A\",\"esimid\":\"\",\"eID\":\"\"},\"invokeIdScan\":\"\",\"deviceSimCompatible\":\"Y\",\"deviceSimM2MPair\":\"N\",\"deviceESimCompatible\":\"N\",\"deviceESimM2MPair\":\"N\",\"deviceId\":\"357067262838780\",\"color\":{\"colorId\":\"clr40003\",\"displayName\":\"Black\",\"description\":\"Black\",\"colorCssStyle\":\"#000000\"},\"imageName\":\"samsung-galaxy-a13-black-sma135uzkv\",\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/samsung-galaxy-a13-black-sma135uzkv\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/samsung-galaxy-a13-black-sma135uzkv?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/samsung-galaxy-a13-black-sma135uzkv?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/samsung-galaxy-a13-black-sma135uzkv?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/samsung-galaxy-a13-black-sma135uzkv?$device-thumb$\"},\"skuDisplayName\":\"Samsung Galaxy A13 in Black\",\"deviceSku\":\"SMA135UZKV\",\"isRestrictedDevice\":\"\",\"deviceAttributes\":{\"mfgCode\":\"\",\"mfgName\":\"\",\"prodName\":\"\",\"prodType\":\"\",\"equipModeCode\":\"\",\"equipMode\":\"\",\"gpsIndicator\":\"\",\"daccCode\":\"\",\"deviceType\":\"\",\"deviceCategory\":\"\",\"productId\":\"\",\"postpaidRestrictStartDate\":\"\",\"prepayRestrictStartDate\":\"\",\"wholesaleRestrictStartDate\":\"\"},\"lostAndStolen\":{\"lostStolen\":\"N\",\"nonPay\":\"N\"},\"numbershareCapability\":\"\",\"price\":{\"fullRetailPrice\":{\"originalPrice\":\"189.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"Full Retail Price\"},\"oneYearPrice\":{\"originalPrice\":\"189.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"One Year Price\"},\"devicePaymentPrice\":[]},\"skipSimIdFlag\":false,\"appleWatchFlag\":false,\"fmipLocked\":false,\"appleCarrieLock\":false,\"e911AddrInd\":\"\",\"simClass4G\":\"PI\",\"makeEtniPersApi\":false,\"softMessages\":[],\"standalonePairingEligible\":true,\"deviceFamilyType\":\"Phone\",\"osType\":\"Android\",\"euiccCapable\":\"\",\"imei1\":\"\",\"imei2\":\"\",\"productFamily\":\"SAMSUNG GALAXY A13\",\"productDisplayName\":\"Galaxy A13\",\"pairedImeiData\":{\"pairedImei\":\"\",\"eid\":\"\",\"sku\":\"\",\"preferredSim\":\"\",\"devicePreferredSoftSim\":\"\",\"simClass4G\":\"\",\"euiccCapable\":false},\"eSIMOnly\":false}}}}}";
        DeviceIdValidationUIRequest request = mapper.readValue(requestString, DeviceIdValidationUIRequest.class);
        DeviceIdValidationUIResponse response = mapper.readValue(responseString, DeviceIdValidationUIResponse.class);
        URI url = URI.create("http://localhost/validateDeviceSimTransfer");
        ProductInquiryUIRequest uiRequest= new ProductInquiryUIRequest();
        uiRequest.setDeviceId("357067262838780");
        uiRequest.setIccId("89148000009224838443");
        ProductInquiryUIResponse uiResponse = new ProductInquiryUIResponse();
        uiResponse.setReturnMessage("success");
        uiResponse.setReturnCode("000");
        Mono<ProductInquiryUIResponse> uiResponseProdcutMono = Mono.just(uiResponse);
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        ResponseEntity<GenericResponse> genericResponseResponseEntity = new ResponseEntity<>(response, HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> pegaResponse =  Mono.just(genericResponseResponseEntity);
        Mockito.when(pegaController.deviceIdValidation(httpHeader,httpResponse,request)).thenReturn(pegaResponse);
        Mockito.when(controller.deviceIdValidation(httpHeader,uiRequest)).thenReturn(uiResponseProdcutMono);
        Mono<ResponseEntity<GenericResponse>> uiResponseMono = controller.combinedValidation(httpHeader,httpResponse,request);
        StepVerifier.create(uiResponseMono).assertNext(a-> Assert.assertNotNull(a)).expectComplete().verify();
    }
    @Test
    public void combinedValidation_Negative() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"cartCreator\":\"\",\"cartId\":\"c7158b23-0d50-4334-81c0-0782a84be873\",\"caseId\":\"SOF-138001-E01\",\"creditAppNum\":\"417048672\",\"processingMTN\":\"9363292629\",\"accountNumber\":\"\",\"intent\":\"NSEBYOD\",\"intendType\":\"NSEBYOD\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":\"validateDeviceSim\",\"action\":\"NSE\"},\"data\":{\"lines\":[{\"mtn\":\"9363292629\",\"mtnType\":\"\",\"eskuId\":\"\",\"device\":{\"id\":\"357067262838780\",\"Flowtype\":\"SIM\",\"CurrentId\":\"\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":false,\"sim\":{\"id\":\"89148000009224838443\",\"sku\":\"\",\"isCustomerProvidedSIM\":true,\"CurrentSimid\":\"\"}}}]},\"disableEsimAtLocalInventory\":false}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-RETAIL\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderFlex\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.09.27.04.51.15-519.4059404273995\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOF-138001-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderFlex\",\"processStep\":\"GridWallPDP\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"GridWallPDP\"}]},\"customerInfo\":{\"customerType\":\"N\",\"originalCreditApprovalNumber\":\"417048672\",\"accountNumber\":\"\",\"cartCreator\":\"417048672\",\"processingMTN\":\"\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"c7158b23-0d50-4334-81c0-0782a84be873\",\"couponCode\":\"\",\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false,\"isFlexV2\":false},\"deviceInfo\":{\"simInfo\":{\"iccid\":\"89148000009224838443\",\"mfgCode\":\"GTO\",\"launchPackageSku\":\"DFILLSIM5G-SA-A\",\"prodName\":\"GTO 4G 5G Interim DFILL SIM\",\"preferredSoftSim\":\"DFILLSIM5G-SA-A\",\"launchPackageSkuType\":\"SMA135UZKV\",\"pairedIccid\":\"\",\"type\":\"5GS\",\"mtn\":\"\",\"mobileNumber\":\"\",\"active\":false,\"aging\":false,\"available\":true,\"retired\":false,\"grandFathered\":false,\"status\":\"00000\",\"euimid\":\"A00000FFD61BD0\",\"imsiv\":\"311480867119419\",\"imsivf\":\"\",\"iccIdStat\":\"AA\",\"min\":\"\",\"ispuCompatibleSIM\":\"BULKSIM5G-SA-A\",\"makeEtniPersApi\":false,\"deviceId\":\"357067262838780\",\"dfillCompatibleSim\":\"DFILLSIM5G-SA-A\",\"esimid\":\"\",\"eID\":\"\"},\"invokeIdScan\":\"\",\"deviceSimCompatible\":\"Y\",\"deviceSimM2MPair\":\"N\",\"deviceESimCompatible\":\"N\",\"deviceESimM2MPair\":\"N\",\"deviceId\":\"357067262838780\",\"color\":{\"colorId\":\"clr40003\",\"displayName\":\"Black\",\"description\":\"Black\",\"colorCssStyle\":\"#000000\"},\"imageName\":\"samsung-galaxy-a13-black-sma135uzkv\",\"imageUrlMap\":{\"defaultImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/samsung-galaxy-a13-black-sma135uzkv\",\"largeImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/samsung-galaxy-a13-black-sma135uzkv?$device-lg$\",\"mediumImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/samsung-galaxy-a13-black-sma135uzkv?$device-med$\",\"miniImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/samsung-galaxy-a13-black-sma135uzkv?$device-mini$\",\"thumbImage\":\"https://ss7.vzw.com/is/image/VerizonWireless/samsung-galaxy-a13-black-sma135uzkv?$device-thumb$\"},\"skuDisplayName\":\"Samsung Galaxy A13 in Black\",\"deviceSku\":\"SMA135UZKV\",\"isRestrictedDevice\":\"\",\"deviceAttributes\":{\"mfgCode\":\"\",\"mfgName\":\"\",\"prodName\":\"\",\"prodType\":\"\",\"equipModeCode\":\"\",\"equipMode\":\"\",\"gpsIndicator\":\"\",\"daccCode\":\"\",\"deviceType\":\"\",\"deviceCategory\":\"\",\"productId\":\"\",\"postpaidRestrictStartDate\":\"\",\"prepayRestrictStartDate\":\"\",\"wholesaleRestrictStartDate\":\"\"},\"lostAndStolen\":{\"lostStolen\":\"N\",\"nonPay\":\"N\"},\"numbershareCapability\":\"\",\"price\":{\"fullRetailPrice\":{\"originalPrice\":\"189.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"Full Retail Price\"},\"oneYearPrice\":{\"originalPrice\":\"189.99\",\"discountedPrice\":\"0.0\",\"contractDuration\":\"0.0\",\"contractText\":\"One Year Price\"},\"devicePaymentPrice\":[]},\"skipSimIdFlag\":false,\"appleWatchFlag\":false,\"fmipLocked\":false,\"appleCarrieLock\":false,\"e911AddrInd\":\"\",\"simClass4G\":\"PI\",\"makeEtniPersApi\":false,\"softMessages\":[],\"standalonePairingEligible\":true,\"deviceFamilyType\":\"Phone\",\"osType\":\"Android\",\"euiccCapable\":\"\",\"imei1\":\"\",\"imei2\":\"\",\"productFamily\":\"SAMSUNG GALAXY A13\",\"productDisplayName\":\"Galaxy A13\",\"pairedImeiData\":{\"pairedImei\":\"\",\"eid\":\"\",\"sku\":\"\",\"preferredSim\":\"\",\"devicePreferredSoftSim\":\"\",\"simClass4G\":\"\",\"euiccCapable\":false},\"eSIMOnly\":false}}}}}";
        DeviceIdValidationUIRequest request = mapper.readValue(requestString, DeviceIdValidationUIRequest.class);
        DeviceIdValidationUIResponse response = mapper.readValue(responseString, DeviceIdValidationUIResponse.class);
        URI url = URI.create("http://localhost/validateDeviceSimTransfer");
        ProductInquiryUIRequest uiRequest= new ProductInquiryUIRequest();
        uiRequest.setDeviceId("357067262838780");
        uiRequest.setIccId("89148000009224838443");
        ProductInquiryUIResponse uiResponse = new ProductInquiryUIResponse();
        uiResponse.setReturnMessage("success");
        uiResponse.setReturnCode("111");
        Mono<ProductInquiryUIResponse> uiResponseProdcutMono = Mono.just(uiResponse);
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        ResponseEntity<GenericResponse> genericResponseResponseEntity = new ResponseEntity<>(response, HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> pegaResponse =  Mono.just(genericResponseResponseEntity);
        Mockito.when(pegaController.deviceIdValidation(httpHeader,httpResponse,request)).thenReturn(pegaResponse);
        Mockito.when(controller.deviceIdValidation(httpHeader,uiRequest)).thenReturn(uiResponseProdcutMono);
        Mono<ResponseEntity<GenericResponse>> uiResponseMono = controller.combinedValidation(httpHeader,httpResponse,request);
        StepVerifier.create(uiResponseMono).assertNext(a-> Assert.assertNotNull(a)).expectComplete().verify();
    }
    @Test
    public void combinedValidation_Negative1() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"cartCreator\":\"\",\"cartId\":\"c7158b23-0d50-4334-81c0-0782a84be873\",\"caseId\":\"SOF-138001-E01\",\"creditAppNum\":\"417048672\",\"processingMTN\":\"9363292629\",\"accountNumber\":\"\",\"intent\":\"NSEBYOD\",\"intendType\":\"NSEBYOD\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":\"validateDeviceSim\",\"action\":\"NSE\"},\"data\":{\"lines\":[{\"mtn\":\"9363292629\",\"mtnType\":\"\",\"eskuId\":\"\",\"device\":{\"id\":\"357067262838780\",\"Flowtype\":\"SIM\",\"CurrentId\":\"\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":false,\"sim\":{\"id\":\"89148000009224838443\",\"sku\":\"\",\"isCustomerProvidedSIM\":true,\"CurrentSimid\":\"\"}}}]},\"disableEsimAtLocalInventory\":false}";
        String responseString = "{\"errors\":[{\"namespace\":\"cxp-customerprofile-services\",\"name\":\"SIM_NOT_FOUND_IN_DMD_ASSISTED\",\"id\":\"3521\",\"debug_id\":\"2023-09-28T11:37:07.+0000:c3df20e9d8521f2d:cxp-customerprofile-services-75c9ffcd49-nwlfw:kubernetes\",\"message\":\"Sim is not compatible with the selected Device\",\"severity\":\"High\",\"errorCategory\":\"BUSINESSERR\",\"category\":\"BUSINESS_ERR\",\"serviceErrMsg\":\"Sim is not compatible with the selected Device\",\"msgType\":\"R\",\"cfeMsg\":true}]}";
        DeviceIdValidationUIRequest request = mapper.readValue(requestString, DeviceIdValidationUIRequest.class);
        DeviceIdValidationUIResponse response = mapper.readValue(responseString, DeviceIdValidationUIResponse.class);
        URI url = URI.create("http://localhost/validateDeviceSimTransfer");
        ProductInquiryUIRequest uiRequest= new ProductInquiryUIRequest();
        uiRequest.setDeviceId("357067262838780");
        uiRequest.setIccId("89148000009224838443");
        ProductInquiryUIResponse uiResponse = new ProductInquiryUIResponse();
        uiResponse.setReturnMessage("success");
        uiResponse.setReturnCode("000");
        Mono<ProductInquiryUIResponse> uiResponseProdcutMono = Mono.just(uiResponse);
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        ResponseEntity<GenericResponse> genericResponseResponseEntity = new ResponseEntity<>(response, HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> pegaResponse =  Mono.just(genericResponseResponseEntity);
        Mockito.when(pegaController.deviceIdValidation(httpHeader,httpResponse,request)).thenReturn(pegaResponse);
        Mockito.when(controller.deviceIdValidation(httpHeader,uiRequest)).thenReturn(uiResponseProdcutMono);
        Mono<ResponseEntity<GenericResponse>> uiResponseMono = controller.combinedValidation(httpHeader,httpResponse,request);
        StepVerifier.create(uiResponseMono).assertNext(a-> Assert.assertNotNull(a)).expectComplete().verify();
    }
    @Test
    public void combinedValidation_Negative2() throws JsonProcessingException {
        String requestString = "{\"cartInfo\":{\"cartCreator\":\"\",\"cartId\":\"c7158b23-0d50-4334-81c0-0782a84be873\",\"caseId\":\"SOF-138001-E01\",\"creditAppNum\":\"417048672\",\"processingMTN\":\"9363292629\",\"accountNumber\":\"\",\"intent\":\"NSEBYOD\",\"intendType\":\"NSEBYOD\",\"processStep\":\"BYODDeviceIDPage\",\"processAction\":\"validateDeviceSim\",\"action\":\"NSE\"},\"data\":{\"lines\":[{\"mtn\":\"9363292629\",\"mtnType\":\"\",\"eskuId\":\"\",\"device\":{\"id\":\"357067262838780\",\"Flowtype\":\"SIM\",\"CurrentId\":\"\",\"isCustomerProvidedEquipment\":true,\"sku\":\"\",\"smartIMEI\":false,\"sim\":{\"id\":\"89148000009224838443\",\"sku\":\"\",\"isCustomerProvidedSIM\":true,\"CurrentSimid\":\"\"}}}]},\"disableEsimAtLocalInventory\":false}";
        GenericResponse genericResponse = new GenericResponse();
        ResponseEntity<GenericResponse> gRes = new ResponseEntity<>(null, HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> monoGRes = Mono.just(gRes);
        DeviceIdValidationUIRequest request = mapper.readValue(requestString, DeviceIdValidationUIRequest.class);
        URI url = URI.create("http://localhost/validateDeviceSimTransfer");
        ProductInquiryUIRequest uiRequest= new ProductInquiryUIRequest();
        uiRequest.setDeviceId("357067262838780");
        uiRequest.setIccId("89148000009224838443");
        ProductInquiryUIResponse uiResponse = new ProductInquiryUIResponse();
        uiResponse.setReturnMessage("success");
        uiResponse.setReturnCode("000");
        Mono<ProductInquiryUIResponse> uiResponseProdcutMono = Mono.just(uiResponse);
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        Mockito.when(pegaController.deviceIdValidation(httpHeader,httpResponse,request)).thenReturn(monoGRes);
        Mockito.when(controller.deviceIdValidation(httpHeader,uiRequest)).thenReturn(uiResponseProdcutMono);
        Mono<ResponseEntity<GenericResponse>> uiResponseMono = controller.combinedValidation(httpHeader,httpResponse,request);
        StepVerifier.create(uiResponseMono).assertNext(a-> Assert.assertNotNull(a)).expectComplete().verify();
    }
}
