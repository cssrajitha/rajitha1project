package onevz.soe.cart.bpm.helper;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.bpm.service.CartServiceBPMServices;
import onevz.soe.cart.helper.FeatureFlagHelper;
import onevz.soe.cart.helper.RedisHelper2;
import onevz.soe.cart.requests.AddAllConfiguratorPEGARequest;
import onevz.soe.cart.responses.AddAllConfiguratorPEGAResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.AddAllConfiguratorUIRequest;
import onevz.soe.cart.ui.responses.AddAllConfiguratorUIResponse;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;

import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {CartServiceTestConfig.class})
public class CartServiceConfiguratorBpmHelperTest {

    @Autowired
    private ObjectMapper mapper;

    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;

    @Mock
    private CartServiceBPMServices bpmServices;

    @Mock
    private RedisHelper2 redisHelper2;

    @Mock
    private FeatureFlagHelper featureFlagHelper;

    @InjectMocks
    private CartServiceConfiguratorBpmHelper bpmHelper;

    @Autowired
    private SourceFileReaderUtil sourceFileReaderUtil;

    @Test
    public void testAddAllCartConfiguratorSuccess() throws IOException, SOEHTTPException {
        String addAllRequestFile = "data/addAllToCartConfigurator/request/successRequestFormatted.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(addAllRequestFile, testFileLocation);
        AddAllConfiguratorUIRequest request = mapper.readValue(sampleRequestString, AddAllConfiguratorUIRequest.class);

        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just("sampleUser"));
        when(featureFlagHelper.isNgdTradeInBulkUpdateEnabled()).thenReturn(true);
        when(bpmServices.addAllConfigurator(Mockito.any(AddAllConfiguratorPEGARequest.class))).thenReturn(Mono.just(new AddAllConfiguratorPEGAResponse()));

        Mono<AddAllConfiguratorUIResponse> responseMono = bpmHelper.addAllCartConfigurator(request);

        StepVerifier.create(responseMono).assertNext(response -> Assert.assertNotNull(response)).expectComplete().verify();
    }

    @Test
    public void testAddAllCartConfiguratorException() throws IOException, SOEHTTPException {
        String addAllRequestFile = "data/addAllToCartConfigurator/request/successRequestFormatted.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(addAllRequestFile, testFileLocation);
        AddAllConfiguratorUIRequest request = mapper.readValue(sampleRequestString, AddAllConfiguratorUIRequest.class);
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just("sampleUser"));
        when(featureFlagHelper.isNgdTradeInBulkUpdateEnabled()).thenReturn(true);
        when(bpmServices.addAllConfigurator(Mockito.any(AddAllConfiguratorPEGARequest.class))).thenReturn(Mono.error(new SOEHTTPException(500, "Internal Server Error")));
        Mono<AddAllConfiguratorUIResponse> responseMono = bpmHelper.addAllCartConfigurator(request);
        StepVerifier.create(responseMono).expectError(SOEHTTPException.class).verify();
    }

    @Test
    public void testAddAllCartConfiguratorForException() throws IOException, SOEHTTPException {
        String addAllRequestFile = "data/addAllToCartConfigurator/request/successRequestFormatted.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(addAllRequestFile, testFileLocation);
        AddAllConfiguratorUIRequest request = mapper.readValue(sampleRequestString, AddAllConfiguratorUIRequest.class);
        when(redisHelper2.getLoggedInUser()).thenReturn(Mono.just("sampleUser"));
        when(featureFlagHelper.isNgdTradeInBulkUpdateEnabled()).thenReturn(true);
        when(bpmServices.addAllConfigurator(Mockito.any(AddAllConfiguratorPEGARequest.class))).thenThrow(SOEHTTPException.class);
        Mono<AddAllConfiguratorUIResponse> responseMono = bpmHelper.addAllCartConfigurator(request);
        StepVerifier.create(responseMono).assertNext(response -> Assert.assertNotNull(response)).expectComplete().verify();
    }

    @Test
    public void testAddAllCartConfiguratorEmptyUser() throws IOException, SOEHTTPException {
        String addAllRequestFile = "data/addAllToCartConfigurator/request/successRequestFormatted.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(addAllRequestFile, testFileLocation);
        AddAllConfiguratorUIRequest request = mapper.readValue(sampleRequestString, AddAllConfiguratorUIRequest.class);
        String userData = "";
        Mono<String> loggedInResponse = Mono.just(userData);
        when(redisHelper2.getLoggedInUser()).thenReturn(loggedInResponse);
        when(featureFlagHelper.isNgdTradeInBulkUpdateEnabled()).thenReturn(true);
        when(bpmServices.addAllConfigurator(Mockito.any(AddAllConfiguratorPEGARequest.class))).thenReturn(Mono.just(new AddAllConfiguratorPEGAResponse()));
        Mono<AddAllConfiguratorUIResponse> responseMono = bpmHelper.addAllCartConfigurator(request);

        StepVerifier.create(responseMono).assertNext(response -> Assert.assertNotNull(response)).expectComplete().verify();
    }
}