package onevz.soe.cart.service.test.cases;

import onevz.soe.cart.bpm.service.CartServiceBPMServices;
import onevz.soe.cart.requests.NBXFeedbackRequest;
import onevz.soe.cart.responses.AddDevicePEGAResponse;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.NBXFeedbackResponse;
import onevz.soe.cart.ui.requests.NBXFeedbackUIRequest;
import onevz.soe.cart.ui.requests.SaveCartUIRequest;
import onevz.soe.cart.ui.responses.SaveCartUIResponse;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import onevz.soe.cart.model.bvp.BVPLine;
import onevz.soe.cart.nbx.NBXFeedbackService;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;

import static org.mockito.Mockito.RETURNS_SMART_NULLS;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { CartServiceTestConfig.class })
//@WebFluxTest(NBXFeedbackService.class)
public class NBXFeedbackServiceTest {

	@Autowired
	private NBXFeedbackService nbxService;
	
	@Autowired
	private ObjectMapper mapper;

	@MockBean
	private CartServiceBPMServices bpmService;

	@Autowired
	SourceFileReaderUtil sourceFileReaderUtil;

	@Value("${onevz.soe.cart.test.fileLocation}")
	private String testFileLocation;

	@Test
	public void formatNbxFeedbackRequestTest() throws JsonMappingException, JsonProcessingException {
		String bvpLineStr = "{\"mtn\": \"5079937563\",\"getBestValuePromotions\": {  \"clientId\": \"NETACE\",  \"sessionId\": \"4352144075584082252\",  \"rtdSessionId\": \"NBA-85771580-SQA1\",  \"clientSessionId\": \"0\",  \"clientTransactionId\": \"\",  \"bestValueOffers\": [{  \"id\": \"203040\",  \"rank\": \"1\",  \"dispositionOptionId\": null,  \"myOffer\": true,  \"verizonUp\": false,  \"barcode\": null,  \"myOfferAccepted\": false,  \"verizonUpAccepted\": false,  \"name\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"description\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"redemptionIds\": null,  \"contractTypes\": [\"2YR\",\"FR\",\"DPP\"  ],  \"compatiblePlanIds\": [\"36571\",\"36569\",\"36565\",\"36496\",\"36310\",\"36184\"  ],  \"deviceSku\": \"SMN976VZWV\"}  ],  \"totalDeviceDollarsBalance\": \"0.0\",  \"deviceDollarDisplayName\": \"\",  \"isVerizonUpAvailable\": false,  \"isDeviceDollarManuallyAccepted\": false,  \"rank\": \"1\",  \"propositionId\": \"RO_01\",  \"dispositionId\": \"10\",  \"soiEngagementId\": \"501002648\"}}";
		BVPLine nbxRes = mapper.readValue(bvpLineStr, BVPLine.class);

		StepVerifier.create(Mono.just(nbxService.formatNbxFeedbackRequest(nbxRes, "", "pandsi9"))).assertNext(resp -> Assert.assertNotNull(resp))
				.expectComplete().verify();
	}

	@Test
	public void formatNbxPromoFeedbackRequestTest() throws JsonMappingException, JsonProcessingException {

		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);

		String nbxFeedBack = "{ \"service\": { \"serviceHeader\": { \"clientId\": \"NETACE\", \"clientTransactionId\": \"f448eae3-04d0-4e80-812c-de4d152bc699-4052233\", \"clientSessionId\": \"02cf4756-651c-4431-ab3f-85038b010005\", \"timestamp\": \"2022-05-16 12:53:12 GMT\", \"serviceName\": \"NBX\" }, \"serviceBody\": { \"serviceRequest\": { \"contextInfo\": { \"callReason\": \"Recommendation\", \"category\": \"PromoBundle\", \"subServiceName\": \"CaptureResponse\", \"sessionId\": \"8706320352278362076\", \"rtdSessionID\": \"NBA-8706320352278362071-WDC\", \"agentID\": \"castsh7\" }, \"customerInfo\": { \"mtn\": \"8089871368\", \"accountNo\": \"0870985200-00001\", \"mtnFlow\": \"PromoBundle\" }, \"customerResponse\": { \"responseList\": [{ \"rank\": \"1\", \"propositionId\": \"RO_01\", \"dispositionOptionId\": \"81\", \"soiEngagementId\": \"501003108\", \"timeStamp\": \"2022-05-16 12:53:12 GMT\", \"dynamicAttrList\": [{ \"attrId\": \"Offer\", \"value\": \"PR_1584\" }] }, { \"rank\": \"2\", \"propositionId\": \"RO_02\", \"dispositionOptionId\": \"81\", \"soiEngagementId\": \"501003108\", \"timeStamp\": \"2022-05-16 12:53:12 GMT\", \"dynamicAttrList\": [{ \"attrId\": \"Offer\", \"value\": \"375160\" }] }, { \"rank\": \"3\", \"propositionId\": \"RO_02\", \"dispositionOptionId\": \"81\", \"soiEngagementId\": \"501003108\", \"timeStamp\": \"2022-05-16 12:53:12 GMT\", \"dynamicAttrList\": [{ \"attrId\": \"Offer\", \"value\": \"375160\" }] }], \"externalResponseList\": [{ \"rank\": \"1\", \"propositionId\": \"PR_1584\", \"dispositionOptionId\": \"81\", \"soiEngagementId\": \"501003108\", \"timeStamp\": \"2022-05-16 12:53:12 GMT\", \"dynamicAttrList\": [{ \"attrId\": \"isRtdOffer\", \"value\": \"Y\" }] }, { \"rank\": \"2\", \"propositionId\": \"PR_1584\", \"dispositionOptionId\": \"81\", \"soiEngagementId\": \"501003108\", \"timeStamp\": \"2022-05-16 12:53:12 GMT\", \"dynamicAttrList\": [{ \"attrId\": \"isRtdOffer\", \"value\": \"Y\" }] }] } } } } }";
		NBXFeedbackUIRequest nbxRes = mapper.readValue(nbxFeedBack, NBXFeedbackUIRequest.class);

		StepVerifier.create(Mono.just(nbxService.formatNbxPromoFeedbackRequest(nbxRes, sampleRedisData))).assertNext(resp -> Assert.assertNotNull(resp))
				.expectComplete().verify();
	}
	@Test
	public void nbxFeedbackCallTest() throws JsonMappingException, JsonProcessingException, SOEHTTPException {
		String requestFile = "MockNBXServiceRequest.json";
		String responseFile = "MockNBXServiceResponse.json";
		String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
		NBXFeedbackRequest request = null;
		NBXFeedbackResponse response = null;
		request = mapper.readValue(sampleRequestString, NBXFeedbackRequest.class);
		response = mapper.readValue(sampleResponseString, NBXFeedbackResponse.class);


		when(bpmService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(response));
		Mono<NBXFeedbackResponse> serviceResponse = nbxService.nbxFeedbackCall(request);
		StepVerifier.create(serviceResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
		}

	@Test
	public void nbxFeedbackCallErrorTest() throws JsonMappingException, JsonProcessingException, SOEHTTPException {
		String requestFile = "MockNBXServiceRequest.json";
		String responseFile = "MockNBXServiceErrorResponse.json";
		String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
		NBXFeedbackRequest request = null;
		NBXFeedbackResponse response = null;
		request = mapper.readValue(sampleRequestString, NBXFeedbackRequest.class);
		response = mapper.readValue(sampleResponseString, NBXFeedbackResponse.class);


		when(bpmService.nbxFeedbackCall(Mockito.any())).thenReturn(Mono.just(response));
		Mono<NBXFeedbackResponse> serviceResponse = nbxService.nbxFeedbackCall(request);
		StepVerifier.create(serviceResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

	}

	@Test
	public void nbxFeedbackCallHTTPExceptionTest() throws IOException, SOEHTTPException {
		String requestFile = "MockNBXServiceRequest.json";

		String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);

		NBXFeedbackRequest request = mapper.readValue(sampleRequestString, NBXFeedbackRequest.class);

		Mono<NBXFeedbackResponse> dummyResponse = Mono.just(Mockito.mock(NBXFeedbackResponse.class, RETURNS_SMART_NULLS));
		when(bpmService.nbxFeedbackCall(Mockito.any())).thenThrow(new SOEHTTPException("nbx", null, dummyResponse.toString()));
		StepVerifier.create(Mono.just(nbxService.nbxFeedbackCall(request))).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void formatNbxPromoFeedbackRequestTest1() throws JsonMappingException, JsonProcessingException {
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\":null, \"mtn\":null }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		String nbxFeedBack = "{ \"service\": { \"serviceHeader\": null, \"serviceBody\": { \"serviceRequest\": { \"contextInfo\": { \"callReason\": \"Recommendation\", \"category\": \"PromoBundle\", \"subServiceName\": \"CaptureResponse\", \"sessionId\": \"8706320352278362076\", \"rtdSessionID\": \"NBA-8706320352278362071-WDC\", \"agentID\": \"castsh7\" }, \"customerInfo\": { \"mtn\": \"8089871368\", \"accountNo\": \"0870985200-00001\", \"mtnFlow\": \"PromoBundle\" }, \"customerResponse\": { \"responseList\": [{ \"rank\": \"1\", \"propositionId\": \"RO_01\", \"dispositionOptionId\": \"81\", \"soiEngagementId\": \"501003108\", \"timeStamp\": \"2022-05-16 12:53:12 GMT\", \"dynamicAttrList\": [{ \"attrId\": \"Offer\", \"value\": \"PR_1584\" }] }, { \"rank\": \"2\", \"propositionId\": \"RO_02\", \"dispositionOptionId\": \"81\", \"soiEngagementId\": \"501003108\", \"timeStamp\": \"2022-05-16 12:53:12 GMT\", \"dynamicAttrList\": [{ \"attrId\": \"Offer\", \"value\": \"375160\" }] }, { \"rank\": \"3\", \"propositionId\": \"RO_02\", \"dispositionOptionId\": \"81\", \"soiEngagementId\": \"501003108\", \"timeStamp\": \"2022-05-16 12:53:12 GMT\", \"dynamicAttrList\": [{ \"attrId\": \"Offer\", \"value\": \"375160\" }] }], \"externalResponseList\": [] } } } } }";
		NBXFeedbackUIRequest nbxRes = mapper.readValue(nbxFeedBack, NBXFeedbackUIRequest.class);
		StepVerifier.create(Mono.just(nbxService.formatNbxPromoFeedbackRequest(nbxRes, sampleRedisData))).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void formatNbxPromoFeedbackRequestTest2() throws JsonMappingException, JsonProcessingException {
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\":null, \"mtn\":null }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		String nbxFeedBack = "{ \"service\": { \"serviceHeader\": null, \"serviceBody\": { \"serviceRequest\": { \"contextInfo\": { \"callReason\": \"Recommendation\", \"category\": \"PromoBundle\", \"subServiceName\": \"CaptureResponse\", \"sessionId\": \"8706320352278362076\", \"rtdSessionID\": \"NBA-8706320352278362071-WDC\", \"agentID\": \"castsh7\" }, \"customerInfo\": { \"mtn\": \"8089871368\", \"accountNo\": \"0870985200-00001\", \"mtnFlow\": \"PromoBundle\" }, \"customerResponse\": { \"responseList\": [{ \"rank\": \"1\", \"propositionId\": \"RO_01\", \"dispositionOptionId\": \"81\", \"soiEngagementId\": \"501003108\", \"timeStamp\": \"2022-05-16 12:53:12 GMT\", \"dynamicAttrList\": [{ \"attrId\": \"Offer\", \"value\": \"PR_1584\" }] }, { \"rank\": \"2\", \"propositionId\": \"RO_02\", \"dispositionOptionId\": \"81\", \"soiEngagementId\": \"501003108\", \"timeStamp\": \"2022-05-16 12:53:12 GMT\", \"dynamicAttrList\": [{ \"attrId\": \"Offer\", \"value\": \"375160\" }] }, { \"rank\": \"3\", \"propositionId\": \"RO_02\", \"dispositionOptionId\": \"81\", \"soiEngagementId\": \"501003108\", \"timeStamp\": \"2022-05-16 12:53:12 GMT\", \"dynamicAttrList\": [{ \"attrId\": \"Offer\", \"value\": \"375160\" }] }], \"externalResponseList\": null } } } } }";
		NBXFeedbackUIRequest nbxRes = mapper.readValue(nbxFeedBack, NBXFeedbackUIRequest.class);
		StepVerifier.create(Mono.just(nbxService.formatNbxPromoFeedbackRequest(nbxRes, sampleRedisData))).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void formatNbxPromoFeedbackRequestTest3() throws JsonMappingException, JsonProcessingException {
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		String nbxFeedBack = "{ \"service\": { \"serviceHeader\": { \"clientId\": \"NETACE\", \"clientTransactionId\": \"f448eae3-04d0-4e80-812c-de4d152bc699-4052233\", \"clientSessionId\": \"02cf4756-651c-4431-ab3f-85038b010005\", \"timestamp\": \"2022-05-16 12:53:12 GMT\", \"serviceName\": \"NBX\" }, \"serviceBody\": { \"serviceRequest\": { \"contextInfo\": { \"callReason\": \"Recommendation\", \"category\": \"PromoBundle\", \"subServiceName\": \"CaptureResponse\", \"sessionId\": \"8706320352278362076\", \"rtdSessionID\": \"NBA-8706320352278362071-WDC\", \"agentID\": \"castsh7\" }, \"customerInfo\": { \"mtn\": \"8089871368\", \"accountNo\": \"0870985200-00001\", \"mtnFlow\": \"PromoBundle\" }, \"customerResponse\": { \"responseList\": [], \"externalResponseList\": [{ \"rank\": \"1\", \"propositionId\": \"PR_1584\", \"dispositionOptionId\": \"81\", \"soiEngagementId\": \"501003108\", \"timeStamp\": \"2022-05-16 12:53:12 GMT\", \"dynamicAttrList\": [{ \"attrId\": \"isRtdOffer\", \"value\": \"Y\" }] }, { \"rank\": \"2\", \"propositionId\": \"PR_1584\", \"dispositionOptionId\": \"81\", \"soiEngagementId\": \"501003108\", \"timeStamp\": \"2022-05-16 12:53:12 GMT\", \"dynamicAttrList\": [{ \"attrId\": \"isRtdOffer\", \"value\": \"Y\" }] }] } } } } }";
		NBXFeedbackUIRequest nbxRes = mapper.readValue(nbxFeedBack, NBXFeedbackUIRequest.class);
		StepVerifier.create(Mono.just(nbxService.formatNbxPromoFeedbackRequest(nbxRes, sampleRedisData))).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void formatNbxPromoFeedbackRequestTest4() throws JsonMappingException, JsonProcessingException {
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		String nbxFeedBack = "{ \"service\": { \"serviceHeader\": { \"clientId\": \"NETACE\", \"clientTransactionId\": \"f448eae3-04d0-4e80-812c-de4d152bc699-4052233\", \"clientSessionId\": \"02cf4756-651c-4431-ab3f-85038b010005\", \"timestamp\": \"2022-05-16 12:53:12 GMT\", \"serviceName\": \"NBX\" }, \"serviceBody\": { \"serviceRequest\": { \"contextInfo\": { \"callReason\": \"Recommendation\", \"category\": \"PromoBundle\", \"subServiceName\": \"CaptureResponse\", \"sessionId\": \"8706320352278362076\", \"rtdSessionID\": \"NBA-8706320352278362071-WDC\", \"agentID\": \"castsh7\" }, \"customerInfo\": { \"mtn\": \"8089871368\", \"accountNo\": \"0870985200-00001\", \"mtnFlow\": \"PromoBundle\" }, \"customerResponse\": { \"responseList\": null, \"externalResponseList\": [{ \"rank\": \"1\", \"propositionId\": \"PR_1584\", \"dispositionOptionId\": \"81\", \"soiEngagementId\": \"501003108\", \"timeStamp\": \"2022-05-16 12:53:12 GMT\", \"dynamicAttrList\": [{ \"attrId\": \"isRtdOffer\", \"value\": \"Y\" }] }, { \"rank\": \"2\", \"propositionId\": \"PR_1584\", \"dispositionOptionId\": \"81\", \"soiEngagementId\": \"501003108\", \"timeStamp\": \"2022-05-16 12:53:12 GMT\", \"dynamicAttrList\": [{ \"attrId\": \"isRtdOffer\", \"value\": \"Y\" }] }] } } } } }";
		NBXFeedbackUIRequest nbxRes = mapper.readValue(nbxFeedBack, NBXFeedbackUIRequest.class);
		StepVerifier.create(Mono.just(nbxService.formatNbxPromoFeedbackRequest(nbxRes, sampleRedisData))).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void formatNbxPromoFeedbackRequestTest5() throws JsonMappingException, JsonProcessingException {
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		String nbxFeedBack = "{ \"service\": { \"serviceHeader\": { \"clientId\": \"NETACE\", \"clientTransactionId\": \"f448eae3-04d0-4e80-812c-de4d152bc699-4052233\", \"clientSessionId\": \"02cf4756-651c-4431-ab3f-85038b010005\", \"timestamp\": \"2022-05-16 12:53:12 GMT\", \"serviceName\": \"NBX\" }, \"serviceBody\": { \"serviceRequest\": { \"contextInfo\": { \"callReason\": \"Recommendation\", \"category\": \"PromoBundle\", \"subServiceName\": \"CaptureResponse\", \"sessionId\": \"8706320352278362076\", \"rtdSessionID\": \"NBA-8706320352278362071-WDC\", \"agentID\": \"castsh7\" }, \"customerInfo\": { \"mtn\": \"8089871368\", \"accountNo\": \"0870985200-00001\", \"mtnFlow\": \"PromoBundle\" }, \"customerResponse\":null }}}}}";
		NBXFeedbackUIRequest nbxRes = mapper.readValue(nbxFeedBack, NBXFeedbackUIRequest.class);
		StepVerifier.create(Mono.just(nbxService.formatNbxPromoFeedbackRequest(nbxRes, sampleRedisData))).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void formatNbxFeedbackRequestTest1() throws JsonMappingException, JsonProcessingException {
		String bvpLineStr = "{\"mtn\": \"5079937563\",\"getBestValuePromotions\": { \"rtdRank\":\"2\", \"clientId\": \"NETACE\",  \"sessionId\": \"4352144075584082252\",  \"rtdSessionId\": \"NBA-85771580-SQA1\",  \"clientSessionId\": \"0\",  \"clientTransactionId\": \"\",  \"bestValueOffers\": [{  \"id\": \"203040\",  \"rtdRank\":\"1\",\"rank\": \"1\",  \"dispositionOptionId\": null,  \"myOffer\": true,  \"verizonUp\": false,  \"barcode\": null,  \"myOfferAccepted\": false,  \"verizonUpAccepted\": false,  \"name\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"description\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"redemptionIds\": null,  \"contractTypes\": [\"2YR\",\"FR\",\"DPP\"  ],  \"compatiblePlanIds\": [\"36571\",\"36569\",\"36565\",\"36496\",\"36310\",\"36184\"  ],  \"deviceSku\": \"SMN976VZWV\"}  ],  \"totalDeviceDollarsBalance\": \"0.0\",  \"deviceDollarDisplayName\": \"\",  \"isVerizonUpAvailable\": false,  \"isDeviceDollarManuallyAccepted\": false,  \"rank\": \"1\",  \"propositionId\": \"RO_01\",  \"dispositionId\": \"10\",  \"soiEngagementId\": \"501002648\"}}";
		BVPLine nbxRes = mapper.readValue(bvpLineStr, BVPLine.class);
		StepVerifier.create(Mono.just(nbxService.formatNbxFeedbackRequest(nbxRes, "", "pandsi9"))).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void formatNbxFeedbackRequestTest2() throws JsonMappingException, JsonProcessingException {
		String bvpLineStr = "{\"mtn\": \"5079937563\",\"getBestValuePromotions\": { \"rtdRank\":\"2\", \"clientId\": \"NETACE\",  \"sessionId\": \"4352144075584082252\",  \"rtdSessionId\": \"NBA-85771580-SQA1\",  \"clientSessionId\": \"0\",  \"clientTransactionId\": \"\",  \"bestValueOffers\": [{  \"dispositionOptionId\":\"876\",\"id\": \"203040\",  \"rtdRank\":\"1\",\"rank\": \"1\",  \"dispositionOptionId\": null,  \"myOffer\": false,  \"verizonUp\": false,  \"barcode\": null,  \"myOfferAccepted\": false,  \"verizonUpAccepted\": false,  \"name\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"description\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"redemptionIds\": null,  \"contractTypes\": [\"2YR\",\"FR\",\"DPP\"  ],  \"compatiblePlanIds\": [\"36571\",\"36569\",\"36565\",\"36496\",\"36310\",\"36184\"  ],  \"deviceSku\": \"SMN976VZWV\"}  ],  \"totalDeviceDollarsBalance\": \"0.0\",  \"deviceDollarDisplayName\": \"\",  \"isVerizonUpAvailable\": false,  \"isDeviceDollarManuallyAccepted\": false,  \"rank\": \"1\",  \"propositionId\": \"RO_01\",  \"dispositionId\": \"10\",  \"soiEngagementId\": \"501002648\"}}";
		BVPLine nbxRes = mapper.readValue(bvpLineStr, BVPLine.class);
		System.setProperty("endPoint", "add-device");
		StepVerifier.create(Mono.just(nbxService.formatNbxFeedbackRequest(nbxRes, "", "pandsi9"))).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void formatNbxFeedbackRequestTest3() throws JsonMappingException, JsonProcessingException {
		String bvpLineStr = "{\"mtn\": \"5079937563\",\"getBestValuePromotions\": { \"rtdRank\":\"2\", \"clientId\": \"NETACE\",  \"sessionId\": \"4352144075584082252\",  \"rtdSessionId\": \"NBA-85771580-SQA1\",  \"clientSessionId\": \"0\",  \"clientTransactionId\": \"\",  \"bestValueOffers\": [{  \"dispositionOptionId\":\"876\",\"id\": \"203040\",  \"rtdRank\":\"1\",\"rank\": \"1\",  \"dispositionOptionId\": null,  \"myOffer\": false,  \"verizonUp\": false,  \"barcode\": null,  \"myOfferAccepted\": false,  \"verizonUpAccepted\": false,  \"name\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"description\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"redemptionIds\": null,  \"contractTypes\": [\"2YR\",\"FR\",\"DPP\"  ],  \"compatiblePlanIds\": [\"36571\",\"36569\",\"36565\",\"36496\",\"36310\",\"36184\"  ],  \"deviceSku\": \"SMN976VZWV\"}  ],  \"totalDeviceDollarsBalance\": \"0.0\",  \"deviceDollarDisplayName\": \"\",  \"isVerizonUpAvailable\": false,  \"isDeviceDollarManuallyAccepted\": false,  \"rank\": \"1\",  \"propositionId\": \"RO_01\",  \"dispositionId\": \"10\",  \"soiEngagementId\": \"501002648\"}}";
		BVPLine nbxRes = mapper.readValue(bvpLineStr, BVPLine.class);
		System.setProperty("endPoint", "remove-lines");
		StepVerifier.create(Mono.just(nbxService.formatNbxFeedbackRequest(nbxRes, "", "pandsi9"))).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}
	
	@Test
	public void formatNbxFeedbackRequestTest4() throws JsonMappingException, JsonProcessingException {
		String bvpLineStr = "{\"mtn\": \"5079937563\",\"getBestValuePromotions\": { \"rtdRank\":\"2\", \"clientId\": \"NETACE\",  \"sessionId\": \"4352144075584082252\",  \"rtdSessionId\": \"NBA-85771580-SQA1\",  \"clientSessionId\": \"0\",  \"clientTransactionId\": \"\",  \"bestValueOffers\": [{  \"dispositionOptionId\":\"876\",\"id\": null,  \"rtdRank\":\"1\",\"rank\": \"1\",    \"myOffer\": false,  \"verizonUp\": false,  \"barcode\": null,  \"myOfferAccepted\": false,  \"verizonUpAccepted\": false,  \"name\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"description\": \"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",  \"redemptionIds\": null,  \"contractTypes\": [\"2YR\",\"FR\",\"DPP\"  ],  \"compatiblePlanIds\": [\"36571\",\"36569\",\"36565\",\"36496\",\"36310\",\"36184\"  ],  \"deviceSku\": null}  ],  \"totalDeviceDollarsBalance\": \"0.0\",  \"deviceDollarDisplayName\": \"\",  \"isVerizonUpAvailable\": false,  \"isDeviceDollarManuallyAccepted\": false,  \"rank\": \"1\",  \"propositionId\": \"RO_01\",  \"dispositionId\": \"10\",  \"soiEngagementId\": \"501002648\"}}";
		BVPLine nbxRes = mapper.readValue(bvpLineStr, BVPLine.class);
		System.setProperty("endPoint", "removeOffers");
		StepVerifier.create(Mono.just(nbxService.formatNbxFeedbackRequest(nbxRes, "", "pandsi9"))).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void formatNbxFeedbackRequestTestM1() throws JsonMappingException, JsonProcessingException {
		String bvpLineStr = "{\"mtn\":\"5079937563\",\"getBestValuePromotions\":{\"clientId\":\"NETACE\",\"sessionId\":\"4352144075584082252\",\"rtdSessionId\":\"NBA-85771580-SQA1\",\"clientSessionId\":\"0\",\"clientTransactionId\":\"\",\"bestValueOffers\":[{\"id\":\"203040\",\"rank\":\"1\",\"dispositionOptionId\":\"213\",\"myOffer\":false,\"verizonUp\":false,\"barcode\":null,\"myOfferAccepted\":false,\"verizonUpAccepted\":false,\"name\":\"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",\"description\":\"Step Up to Unlimited and get $300 Off SELECT Samsung Smartphones Upgrade via Monthly Recurring BIC - Restricted\",\"redemptionIds\":null,\"contractTypes\":[\"2YR\",\"FR\",\"DPP\"],\"compatiblePlanIds\":[\"36571\",\"36569\",\"36565\",\"36496\",\"36310\",\"36184\"],\"deviceSku\":\"SMN976VZWV\"}],\"totalDeviceDollarsBalance\":\"0.0\",\"deviceDollarDisplayName\":\"\",\"isVerizonUpAvailable\":false,\"isDeviceDollarManuallyAccepted\":false,\"rank\":\"1\",\"propositionId\":\"RO_01\",\"dispositionId\":\"10\",\"soiEngagementId\":\"501002648\",\"rtdRank\":\"2343\"}}";
		BVPLine nbxRes = mapper.readValue(bvpLineStr, BVPLine.class);

		StepVerifier.create(Mono.just(nbxService.formatNbxFeedbackRequest(nbxRes, "", "pandsi9"))).assertNext(resp -> Assert.assertNotNull(resp))
				.expectComplete().verify();
	}
}
