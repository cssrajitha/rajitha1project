package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.cxp.feature.ConfigurationProfile;
import onevz.cxp.feature.Flag;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.controller.CartUpdateOperationsController;
import onevz.soe.cart.controller.CartUpdateOperationsController2;
import onevz.soe.cart.controller.CartUpdateOperationsController3;
import onevz.soe.cart.exceptions.JsonValidator;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.*;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.omnidl.service.OmniDLService;
import onevz.soe.omnidl.util.DLUtilityService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.*;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpResponse;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(CartUpdateOperationsController2.class)
public class CartUpdateOperationsController2Test {

    @Autowired
    private ObjectMapper mapper;

    @MockBean
    private CartAddDeviceHelper devHelper;

    @Autowired
    private CartUpdateOperationsController cartController;

    @Autowired
    private CartUpdateOperationsController2 cartController2;

    @Autowired
    private CartUpdateOperationsController3 cartController3;

    @MockBean
    private RedisHelper redisHelper;
    @MockBean
    private OmniDLHelper omniDLHelper;
    @MockBean
    FeatureFlagHelper featureFlagHelper;
    @MockBean
    private RedisHelper2 redisHelper2;

    @MockBean
    private OmniDLService dlService;

    @MockBean
    private RedisHelper3 redisHelper3;
    @MockBean
    private UpdateCartHelper helper;

    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;

    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;
    @MockBean
    private JsonValidator validator;

    @MockBean
    private DLUtilityService dlUtilityService;

    @Test
    public void removeLinesTest() throws IOException {
        String requestFile = "RemoveLinesRequestTest.json";
        String responseFile = "RemoveLinesResponseTest.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        RemoveLinesUIRequest request = mapper.readValue(sampleRequestString, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse response = mapper.readValue(sampleResponseString, RemoveLinesUIResponse.class);
        when(helper.removeLines(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(14423)));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.deleteEdgeBuyoutDataFromRedis()).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.updateDeviceCartCount(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just(""));
        URI url = URI.create("http://localhost/flexV2/remove-lines");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.removeLines(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {
            assertNotNull(resp);}).expectComplete().verify();
    }

    @Test
    public void removeLinesWithoutCartInfoTest() throws IOException {
        String requestFile = "RemoveLinesRequestWithoutCartInfoTest.json";
        String responseFile = "RemoveLinesResponseTest.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        RemoveLinesUIRequest request = mapper.readValue(sampleRequestString, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse response = mapper.readValue(sampleResponseString, RemoveLinesUIResponse.class);
        when(helper.removeLines(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(14423)));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.deleteEdgeBuyoutDataFromRedis()).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.updateDeviceCartCount(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just(""));
        URI url = URI.create("http://localhost/flexV2/remove-lines");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.removeLines(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {
            assertNotNull(resp);}).expectComplete().verify();

        response.getServiceBody().getServiceResponse().getContext().setCartInfo(null);
        controllerResponse = cartController.removeLines(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {
            assertNotNull(resp);}).expectComplete().verify();

        response.getServiceBody().getServiceResponse().setContext(null);
        controllerResponse = cartController.removeLines(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {
            assertNotNull(resp);}).expectComplete().verify();

        response.getServiceBody().setServiceResponse(null);
        controllerResponse = cartController.removeLines(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {
            assertNotNull(resp);}).expectComplete().verify();

        response.setServiceBody(null);
        controllerResponse = cartController.removeLines(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {
            assertNotNull(resp);}).expectComplete().verify();
    }

    @Test
    public void removeLinesTest2() throws IOException{
        String requestFile = "RemoveLinesRequestTest1.json";
        String responseFile = "RemoveLinesResponseTest1.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        RemoveLinesUIRequest request = mapper.readValue(sampleRequestString, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse response = mapper.readValue(sampleResponseString, RemoveLinesUIResponse.class);
        when(helper.removeLines(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(14423)));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.deleteEdgeBuyoutDataFromRedis()).thenReturn(Mono.just(Long.valueOf(144323)));
        URI url = URI.create("http://localhost/remove-lines");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.removeLines(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {
            assertNotNull(resp);}).expectComplete().verify();
    }

    @Test
    public void removeLinesTest3() throws IOException{
        String requestFile = "RemoveLinesRequestTest2.json";
        String responseFile = "RemoveLinesResponseTest2.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        RemoveLinesUIRequest request = mapper.readValue(sampleRequestString, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse response = mapper.readValue(sampleResponseString, RemoveLinesUIResponse.class);
        when(helper.removeLines(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(14423)));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.deleteEdgeBuyoutDataFromRedis()).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.updateDeviceCartCount(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just("upgrade"));
        URI url = URI.create("http://localhost/remove-lines");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.removeLines(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {
            assertNotNull(resp);}).expectComplete().verify();
    }

    @Test
    public void removeLinesTest4() throws IOException{
        String requestFile = "RemoveLinesRequestTest3.json";
        String responseFile = "RemoveLinesResponseTest2.json";
        String redisDataFile = "data/CartUpdateOperationsControllerTestJson/removeLines4RedisData.json";
        String getDataFromRedisAsString = sourceFileReaderUtil.readFile(redisDataFile, testFileLocation);
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        RemoveLinesUIRequest request = mapper.readValue(sampleRequestString, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse response = mapper.readValue(sampleResponseString, RemoveLinesUIResponse.class);
        CartRedisData sampleRedisData = mapper.readValue(getDataFromRedisAsString, CartRedisData.class);
        when(helper.removeLines(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(14423)));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.deleteEdgeBuyoutDataFromRedis()).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.updateDeviceCartCount(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just("upgrade"));
        when(redisHelper2.getRole()).thenReturn(Mono.just("accountMember"));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("accessory"));
        when(redisHelper.getAccessoryDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(helper.addAccessoryClearAndContinue(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(new AddAccessoriesUIResponse()));
        URI url = URI.create("http://localhost/remove-lines");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.removeLines(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {
            assertNotNull(resp);}).expectComplete().verify();
    }

    @Test
    public void removeLinesTest5() throws IOException{
        String requestFile = "RemoveLinesRequestTest3.json";
        String responseFile = "RemoveLinesResponseTest2.json";
        String redisDataFile = "data/CartUpdateOperationsControllerTestJson/removeLines5RedisData.json";
        String getDataFromRedisAsString = sourceFileReaderUtil.readFile(redisDataFile, testFileLocation);
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        RemoveLinesUIRequest request = mapper.readValue(sampleRequestString, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse response = mapper.readValue(sampleResponseString, RemoveLinesUIResponse.class);
        CartRedisData sampleRedisData = mapper.readValue(getDataFromRedisAsString, CartRedisData.class);
        when(helper.removeLines(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(14423)));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.deleteEdgeBuyoutDataFromRedis()).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.updateDeviceCartCount(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just("upgrade"));
        when(redisHelper2.getRole()).thenReturn(Mono.just("accountMember"));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("device"));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(helper.addDeviceClearAndContinue(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(new AddDeviceUIResponse()));
        URI url = URI.create("http://localhost/remove-lines");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.removeLines(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {
            assertNotNull(resp);}).expectComplete().verify();
    }

    @Test
    public void removeLinesTest6() throws IOException{
        String requestJson = "data/CartUpdateOperationsControllerTestJson/removeLines6Request.json";
        String requestFile = sourceFileReaderUtil.readFile(requestJson, testFileLocation);
        String responseJson = "data/CartUpdateOperationsControllerTestJson/removeLines6Response.json";
        String responseFile = sourceFileReaderUtil.readFile(responseJson, testFileLocation);
        RemoveLinesUIRequest request = mapper.readValue(requestFile, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse response = mapper.readValue(responseFile, RemoveLinesUIResponse.class);
        when(helper.removeLines(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(14423)));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.deleteEdgeBuyoutDataFromRedis()).thenReturn(Mono.just(Long.valueOf(144323)));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        when(redisHelper2.updateDeviceCartCount(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just(""));
        URI url = URI.create("http://localhost/remove-lines");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.removeLines(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {
            assertNotNull(resp);}).expectComplete().verify();
    }

    @Test
    public void removeLinesTest7() throws IOException{
        String requestJson = "data/CartUpdateOperationsControllerTestJson/removeLines6Request.json";
        String requestFile = sourceFileReaderUtil.readFile(requestJson, testFileLocation);
        String responseJson = "data/CartUpdateOperationsControllerTestJson/removeLines6Response.json";
        String responseFile = sourceFileReaderUtil.readFile(responseJson, testFileLocation);
        RemoveLinesUIRequest request = mapper.readValue(requestFile, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse response = mapper.readValue(responseFile, RemoveLinesUIResponse.class);
        when(helper.removeLines(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(14423)));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.deleteEdgeBuyoutDataFromRedis()).thenReturn(Mono.just(Long.valueOf(144323)));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(new ErrorResponse());
        URI url = URI.create("http://localhost/remove-lines");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-CARE").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.removeLines(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void removeLinesTest8() throws IOException{
        String requestJson = "data/CartUpdateOperationsControllerTestJson/removeLines8Request.json";
        String requestFile = sourceFileReaderUtil.readFile(requestJson, testFileLocation);
        String responseJson = "data/CartUpdateOperationsControllerTestJson/removeLines8Response.json";
        String responseFile = sourceFileReaderUtil.readFile(responseJson, testFileLocation);
        RemoveLinesUIRequest request = mapper.readValue(requestFile, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse response = mapper.readValue(responseFile, RemoveLinesUIResponse.class);
        when(helper.removeLines(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(14423)));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.deleteEdgeBuyoutDataFromRedis()).thenReturn(Mono.just(Long.valueOf(144323)));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        when(redisHelper2.updateDeviceCartCount(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just(""));
        URI url = URI.create("http://localhost/remove-lines");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "session")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.removeLines(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void removeLinesTest9() throws IOException{
        String requestJson = "data/CartUpdateOperationsControllerTestJson/removeLines8Request.json";
        String requestFile = sourceFileReaderUtil.readFile(requestJson, testFileLocation);
        String responseJson = "data/CartUpdateOperationsControllerTestJson/removeLines9Response.json";
        String responseFile = sourceFileReaderUtil.readFile(responseJson, testFileLocation);
        RemoveLinesUIRequest request = mapper.readValue(requestFile, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse response = mapper.readValue(responseFile, RemoveLinesUIResponse.class);
        when(helper.removeLines(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(14423)));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.deleteEdgeBuyoutDataFromRedis()).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.updateDeviceCartCount(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just(""));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        URI url = URI.create("http://localhost/remove-lines");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "session")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.removeLines(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void removeLinesTest10() throws IOException{
        String requestJson = "data/CartUpdateOperationsControllerTestJson/removeLines8Request.json";
        String requestFile = sourceFileReaderUtil.readFile(requestJson, testFileLocation);
        String responseJson = "data/CartUpdateOperationsControllerTestJson/removeLines10Response.json";
        String responseFile = sourceFileReaderUtil.readFile(responseJson, testFileLocation);
        RemoveLinesUIRequest request = mapper.readValue(requestFile, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse response = mapper.readValue(responseFile, RemoveLinesUIResponse.class);
        when(helper.removeLines(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(14423)));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.deleteEdgeBuyoutDataFromRedis()).thenReturn(Mono.just(Long.valueOf(144323)));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        when(redisHelper2.updateDeviceCartCount(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just(""));
        URI url = URI.create("http://localhost/remove-lines");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "session")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.removeLines(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void removeLinesTestForNseNgd() throws IOException{
        when(featureFlagHelper.isNgdProspectClearCartCookiesEnabled()).thenReturn(Boolean.TRUE);
        String requestJson = "data/CartUpdateOperationsControllerTestJson/removeLines8Request.json";
        String requestFile = sourceFileReaderUtil.readFile(requestJson, testFileLocation);
        String responseJson = "data/CartUpdateOperationsControllerTestJson/removeLines10Response.json";
        String responseFile = sourceFileReaderUtil.readFile(responseJson, testFileLocation);
        RemoveLinesUIRequest request = mapper.readValue(requestFile, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse response = mapper.readValue(responseFile, RemoveLinesUIResponse.class);
        request.setChannelId("VZW-DOTCOM");
        request.getCartInfo().setIntendType(CartConstants.NSE);
        when(helper.removeLines(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(14423)));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.deleteEdgeBuyoutDataFromRedis()).thenReturn(Mono.just(Long.valueOf(144323)));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        when(redisHelper2.updateDeviceCartCount(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just(""));
        URI url = URI.create("http://localhost/remove-lines");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "session")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.removeLines(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        assertNotNull(controllerResponse);
        request.getCartInfo().setIntendType(CartConstants.EUP);
        controllerResponse = cartController.removeLines(httpRequest,httpResponse, request);
        assertNotNull(controllerResponse);
    }

    @Test
    public void removeLinesTestForNseNgdCartItemCount() throws IOException{
        when(featureFlagHelper.isNgdProspectClearCartCookiesEnabled()).thenReturn(Boolean.TRUE);
        String requestJson = "data/CartUpdateOperationsControllerTestJson/removeLines8Request.json";
        String requestFile = sourceFileReaderUtil.readFile(requestJson, testFileLocation);
        String responseJson = "data/CartUpdateOperationsControllerTestJson/removeLines10Response.json";
        String responseFile = sourceFileReaderUtil.readFile(responseJson, testFileLocation);
        RemoveLinesUIRequest request = mapper.readValue(requestFile, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse response = mapper.readValue(responseFile, RemoveLinesUIResponse.class);
        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setCartItemCount(3);
        request.setChannelId("VZW-DOTCOM");
        request.getCartInfo().setIntendType(CartConstants.NSE);
        when(helper.removeLines(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(14423)));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.deleteEdgeBuyoutDataFromRedis()).thenReturn(Mono.just(Long.valueOf(144323)));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        when(redisHelper2.updateDeviceCartCount(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just(""));
        URI url = URI.create("http://localhost/remove-lines");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "session")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.removeLines(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        when(helper.removeLines(Mockito.any())).thenReturn(Mono.just(response));
        controllerResponse = cartController.removeLines(httpRequest,httpResponse, request);
        assertNotNull(controllerResponse);
    }

    @Test
    public void removeLinesTest11() throws IOException{
        String requestJson = "data/CartUpdateOperationsControllerTestJson/removeLines8Request.json";
        String requestFile = sourceFileReaderUtil.readFile(requestJson, testFileLocation);
        String responseJson = "data/CartUpdateOperationsControllerTestJson/removeLines11Response.json";
        String responseFile = sourceFileReaderUtil.readFile(responseJson, testFileLocation);
        RemoveLinesUIRequest request = mapper.readValue(requestFile, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse response = mapper.readValue(responseFile, RemoveLinesUIResponse.class);
        when(helper.removeLines(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(14423)));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.deleteEdgeBuyoutDataFromRedis()).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.updateDeviceCartCount(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just(""));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        URI url = URI.create("http://localhost/remove-lines");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "session")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.removeLines(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void removeLinesTest12() throws IOException{
        String requestJson = "data/CartUpdateOperationsControllerTestJson/removeLines12Request.json";
        String requestFile = sourceFileReaderUtil.readFile(requestJson, testFileLocation);
        String responseJson = "data/CartUpdateOperationsControllerTestJson/removeLines12Response.json";
        String responseFile = sourceFileReaderUtil.readFile(responseJson, testFileLocation);
        RemoveLinesUIRequest request = mapper.readValue(requestFile, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse response = mapper.readValue(responseFile, RemoveLinesUIResponse.class);
        when(helper.removeLines(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(14423)));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.deleteEdgeBuyoutDataFromRedis()).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.updateDeviceCartCount(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just(""));
        when(redisHelper2.getRole()).thenReturn(Mono.just(""));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        URI url = URI.create("http://localhost/remove-lines");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "session")).header("channelId", "").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.removeLines(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void removeLinesTest13() throws IOException{
        String requestJson = "data/CartUpdateOperationsControllerTestJson/removeLines12Request.json";
        String requestFile = sourceFileReaderUtil.readFile(requestJson, testFileLocation);
        String responseJson = "data/CartUpdateOperationsControllerTestJson/removeLines12Response.json";
        String responseFile = sourceFileReaderUtil.readFile(responseJson, testFileLocation);
        RemoveLinesUIRequest request = mapper.readValue(requestFile, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse response = mapper.readValue(responseFile, RemoveLinesUIResponse.class);
        when(helper.removeLines(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(14423)));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.deleteEdgeBuyoutDataFromRedis()).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.updateDeviceCartCount(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just(""));
        when(redisHelper2.getRole()).thenReturn(Mono.just("mobileSecure"));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just(""));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        URI url = URI.create("http://localhost/remove-lines");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "session")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.removeLines(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void removeLinesTest14() throws IOException{
        String requestJson = "data/CartUpdateOperationsControllerTestJson/removeLines12Request.json";
        String requestFile = sourceFileReaderUtil.readFile(requestJson, testFileLocation);
        String responseJson = "data/CartUpdateOperationsControllerTestJson/removeLines12Response.json";
        String responseFile = sourceFileReaderUtil.readFile(responseJson, testFileLocation);
        RemoveLinesUIRequest request = mapper.readValue(requestFile, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse response = mapper.readValue(responseFile, RemoveLinesUIResponse.class);
        when(helper.removeLines(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(14423)));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.deleteEdgeBuyoutDataFromRedis()).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.updateDeviceCartCount(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just(""));
        when(redisHelper2.getRole()).thenReturn(Mono.just("mobile"));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just(""));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        URI url = URI.create("http://localhost/remove-lines");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "session")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.removeLines(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void removeLinesTest15() throws IOException{
        String requestJson = "data/CartUpdateOperationsControllerTestJson/removeLines12Request.json";
        String requestFile = sourceFileReaderUtil.readFile(requestJson, testFileLocation);
        String responseJson = "data/CartUpdateOperationsControllerTestJson/removeLines12Response.json";
        String responseFile = sourceFileReaderUtil.readFile(responseJson, testFileLocation);
        RemoveLinesUIRequest request = mapper.readValue(requestFile, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse response = mapper.readValue(responseFile, RemoveLinesUIResponse.class);
        when(helper.removeLines(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(14423)));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.deleteEdgeBuyoutDataFromRedis()).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.updateDeviceCartCount(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just(""));
        when(redisHelper2.getRole()).thenReturn(Mono.just("mobileSecure"));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("accessory"));
        when(redisHelper.getAccessoryDataFromRedisAsString()).thenReturn(Mono.just(new CartRedisData()));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        URI url = URI.create("http://localhost/remove-lines");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "session")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.removeLines(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void removeLinesTest16() throws IOException{
        String requestJson = "data/CartUpdateOperationsControllerTestJson/removeLines12Request.json";
        String requestFile = sourceFileReaderUtil.readFile(requestJson, testFileLocation);
        String responseJson = "data/CartUpdateOperationsControllerTestJson/removeLines12Response.json";
        String responseFile = sourceFileReaderUtil.readFile(responseJson, testFileLocation);
        String dataString = "{\"accessoryCartInfo\": {\"intendType\": \"NSE\"}}";
        CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
        RemoveLinesUIRequest request = mapper.readValue(requestFile, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse response = mapper.readValue(responseFile, RemoveLinesUIResponse.class);
        when(helper.removeLines(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(14423)));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.deleteEdgeBuyoutDataFromRedis()).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.updateDeviceCartCount(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just(""));
        when(redisHelper2.getRole()).thenReturn(Mono.just("mobileSecure"));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("accessory"));
        when(redisHelper.getAccessoryDataFromRedisAsString()).thenReturn(Mono.just(data));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        URI url = URI.create("http://localhost/remove-lines");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "session")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.removeLines(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void removeLinesTest17() throws IOException{
        String requestJson = "data/CartUpdateOperationsControllerTestJson/removeLines12Request.json";
        String requestFile = sourceFileReaderUtil.readFile(requestJson, testFileLocation);
        String responseJson = "data/CartUpdateOperationsControllerTestJson/removeLines12Response.json";
        String responseFile = sourceFileReaderUtil.readFile(responseJson, testFileLocation);
        String dataString = "{\"accessoryCartInfo\": {\"intendType\": \"ACC\"}}";
        CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
        RemoveLinesUIRequest request = mapper.readValue(requestFile, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse response = mapper.readValue(responseFile, RemoveLinesUIResponse.class);
        AddAccessoriesUIResponse uiResponse = mapper.readValue("{\"errors\": [{}]}", AddAccessoriesUIResponse.class);
        when(helper.removeLines(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(14423)));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.deleteEdgeBuyoutDataFromRedis()).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.updateDeviceCartCount(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just(""));
        when(redisHelper2.getRole()).thenReturn(Mono.just("mobileSecure"));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("accessory"));
        when(redisHelper.getAccessoryDataFromRedisAsString()).thenReturn(Mono.just(data));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        when(helper.addAccessoryClearAndContinue(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(uiResponse));
        URI url = URI.create("http://localhost/remove-lines");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "session")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.removeLines(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void removeLinesTest18() throws IOException{
        String requestJson = "data/CartUpdateOperationsControllerTestJson/removeLines12Request.json";
        String requestFile = sourceFileReaderUtil.readFile(requestJson, testFileLocation);
        String responseJson = "data/CartUpdateOperationsControllerTestJson/removeLines12Response.json";
        String responseFile = sourceFileReaderUtil.readFile(responseJson, testFileLocation);
        String dataString = "{\"accessoryCartInfo\": {\"intendType\": \"ACC\"}}";
        CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
        RemoveLinesUIRequest request = mapper.readValue(requestFile, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse response = mapper.readValue(responseFile, RemoveLinesUIResponse.class);
        AddAccessoriesUIResponse uiResponse = mapper.readValue("{\"errors\": [{}]}", AddAccessoriesUIResponse.class);
        when(helper.removeLines(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(14423)));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.deleteEdgeBuyoutDataFromRedis()).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.updateDeviceCartCount(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just(""));
        when(redisHelper2.getRole()).thenReturn(Mono.just("mobileSecure"));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("accessory"));
        when(redisHelper.getAccessoryDataFromRedisAsString()).thenReturn(Mono.just(data));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        when(helper.addAccessoryClearAndContinue(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(uiResponse));
        URI url = URI.create("http://localhost/remove-lines");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "session")).header("channelId", "OMNI-CARE").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.removeLines(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void removeLinesTest19() throws IOException{
        String requestJson = "data/CartUpdateOperationsControllerTestJson/removeLines12Request.json";
        String requestFile = sourceFileReaderUtil.readFile(requestJson, testFileLocation);
        String responseJson = "data/CartUpdateOperationsControllerTestJson/removeLines12Response.json";
        String responseFile = sourceFileReaderUtil.readFile(responseJson, testFileLocation);
        String dataString = "{\"accessoryCartInfo\": {\"intendType\": \"ACC\"}}";
        CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
        RemoveLinesUIRequest request = mapper.readValue(requestFile, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse response = mapper.readValue(responseFile, RemoveLinesUIResponse.class);
        AddAccessoriesUIResponse uiResponse = mapper.readValue("{\"errors\": [{}]}", AddAccessoriesUIResponse.class);
        when(helper.removeLines(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(14423)));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.deleteEdgeBuyoutDataFromRedis()).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.updateDeviceCartCount(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just(""));
        when(redisHelper2.getRole()).thenReturn(Mono.just("mobileSecure"));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("mobile"));
        when(redisHelper.getAccessoryDataFromRedisAsString()).thenReturn(Mono.just(data));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        when(helper.addAccessoryClearAndContinue(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(uiResponse));
        URI url = URI.create("http://localhost/remove-lines");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "session")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.removeLines(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void removeLinesTest20() throws IOException{
        String requestJson = "data/CartUpdateOperationsControllerTestJson/removeLines12Request.json";
        String requestFile = sourceFileReaderUtil.readFile(requestJson, testFileLocation);
        String responseJson = "data/CartUpdateOperationsControllerTestJson/removeLines12Response.json";
        String responseFile = sourceFileReaderUtil.readFile(responseJson, testFileLocation);
        String dataString = "{}";
        CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
        RemoveLinesUIRequest request = mapper.readValue(requestFile, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse response = mapper.readValue(responseFile, RemoveLinesUIResponse.class);
        AddAccessoriesUIResponse uiResponse = mapper.readValue("{\"errors\": [{}]}", AddAccessoriesUIResponse.class);
        when(helper.removeLines(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(14423)));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.deleteEdgeBuyoutDataFromRedis()).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.updateDeviceCartCount(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just(""));
        when(redisHelper2.getRole()).thenReturn(Mono.just("mobileSecure"));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("device"));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(data));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        when(helper.addAccessoryClearAndContinue(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(uiResponse));
        URI url = URI.create("http://localhost/remove-lines");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "session")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.removeLines(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void removeLinesTest21() throws IOException{
        String requestJson = "data/CartUpdateOperationsControllerTestJson/removeLines12Request.json";
        String requestFile = sourceFileReaderUtil.readFile(requestJson, testFileLocation);
        String responseJson = "data/CartUpdateOperationsControllerTestJson/removeLines12Response.json";
        String responseFile = sourceFileReaderUtil.readFile(responseJson, testFileLocation);
        String dataString = "{\"deviceCartInfo\": {\"intendType\": \"AAl\"}}";
        CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
        RemoveLinesUIRequest request = mapper.readValue(requestFile, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse response = mapper.readValue(responseFile, RemoveLinesUIResponse.class);
        AddDeviceUIResponse uiResponse = mapper.readValue("{\"errors\": [{}]}", AddDeviceUIResponse.class);
        when(helper.removeLines(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(14423)));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.deleteEdgeBuyoutDataFromRedis()).thenReturn(Mono.just(Long.valueOf(144323)));
        when(redisHelper2.updateDeviceCartCount(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just(""));
        when(redisHelper2.getRole()).thenReturn(Mono.just("mobileSecure"));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("device"));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(data));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        when(helper.addDeviceClearAndContinue(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(uiResponse));
        URI url = URI.create("http://localhost/remove-lines");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "session")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.removeLines(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void removeLinesTest22() throws IOException{
        String requestJson = "data/CartUpdateOperationsControllerTestJson/removeLines12Request.json";
        String requestFile = sourceFileReaderUtil.readFile(requestJson, testFileLocation);
        String responseJson = "data/CartUpdateOperationsControllerTestJson/removeLines12Response.json";
        String responseFile = sourceFileReaderUtil.readFile(responseJson, testFileLocation);
        String dataString = "{\"deviceCartInfo\": {\"intendType\": \"NSE\"}}";
        CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
        RemoveLinesUIRequest request = mapper.readValue(requestFile, RemoveLinesUIRequest.class);
        RemoveLinesUIResponse response = mapper.readValue(responseFile, RemoveLinesUIResponse.class);
        AddDeviceUIResponse uiResponse = mapper.readValue("{\"errors\": [{}]}", AddDeviceUIResponse.class);
        when(helper.removeLines(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.deleteAddDeviceDataFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(14423)));
        when(redisHelper.deleteProcessingMtnFromRedis(Mockito.any())).thenReturn(Mono.just(Long.valueOf(14423)));
        when(redisHelper2.deleteEdgeBuyoutDataFromRedis()).thenReturn(Mono.just(Long.valueOf(14423)));
        when(redisHelper2.updateDeviceCartCount(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper2.getCartOrderFlowType()).thenReturn(Mono.just(""));
        when(redisHelper2.getRole()).thenReturn(Mono.just("mobileSecure"));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("device"));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(data));
        when(validator.convertObjectToString(Mockito.<ErrorResponse>any())).thenReturn(null);
        when(helper.addDeviceClearAndContinue(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(uiResponse));
        URI url = URI.create("http://localhost/remove-lines");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "session")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.removeLines(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void createLineTest1() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/createLine1Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/createLine1Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLineUIResponse response = mapper.readValue(responseString, CreateLineUIResponse.class);
        URI url = URI.create("http://localhost/new-line");
        HttpCookie RepIdCookieText = new HttpCookie("RepIdCookieText","TestSalesRep");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(RepIdCookieText).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        when(helper.createLine(any())).thenReturn(Mono.just(response));
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.createLine(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void createLineTest2() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/createLine1Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/createLine1Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLineUIResponse response = mapper.readValue(responseString, CreateLineUIResponse.class);
        URI url = URI.create("");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        when(helper.createLine(any())).thenReturn(Mono.just(response));
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.createLine(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void createLineTest3() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/createLine1Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/createLine1Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLineUIResponse response = mapper.readValue(responseString, CreateLineUIResponse.class);
        URI url = URI.create("http://localhost/new-line");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookie(new HttpCookie("digital_ig_session", "digital_ig_session")).build();
        ServerHttpResponse httpResponse = null;
        when(helper.createLine(any())).thenReturn(Mono.just(response));
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.createLine(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void createLineTest5() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/createLine5Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/createLine1Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLineUIResponse response = mapper.readValue(responseString, CreateLineUIResponse.class);
        URI url = URI.create("http://localhost/new-line");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookie(new HttpCookie("digital_ig_session", "digital_ig_session")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(helper.createLine(any())).thenReturn(Mono.just(response));
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.createLine(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void createLineTest6() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/createLine6Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/createLine1Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLineUIResponse response = mapper.readValue(responseString, CreateLineUIResponse.class);
        URI url = URI.create("http://localhost/new-line");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-TELESALES").cookie(new HttpCookie("digital_ig_session", "digital_ig_session")).build();
        ServerHttpResponse httpResponse = null;
        when(helper.createLine(any())).thenReturn(Mono.just(response));
         when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.createLine(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        when(redisHelper.addFlowNameToRedis(Mockito.any())).thenReturn(Mono.just(true));
         when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        controllerResponse = cartController3.createLine(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

    }


    @Test
    public void createLineTest7() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/createLine5Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/createLine7Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLineUIResponse response = mapper.readValue(responseString, CreateLineUIResponse.class);
        URI url = URI.create("http://localhost/new-line");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookie(new HttpCookie("digital_ig_session", "digital_ig_session")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(helper.createLine(any())).thenReturn(Mono.just(response));
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.createLine(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

    }

    @Test
    public void createLineTest8() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/createLine5Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/createLine8Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLineUIResponse response = mapper.readValue(responseString, CreateLineUIResponse.class);
        URI url = URI.create("http://localhost/new-line");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookie(new HttpCookie("digital_ig_session", "digital_ig_session")).build();
        ServerHttpResponse httpResponse = null;
        when(helper.createLine(any())).thenReturn(Mono.just(response));
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.createLine(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void createLineTest9() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/createLine5Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/createLine9Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLineUIResponse response = mapper.readValue(responseString, CreateLineUIResponse.class);
        URI url = URI.create("http://localhost/new-line");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookie(new HttpCookie("digital_ig_session", "digital_ig_session")).build();
        ServerHttpResponse httpResponse = null;
        when(helper.createLine(any())).thenReturn(Mono.just(response));
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.createLine(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void createLineTest10() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/createLine5Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/createLine10Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLineUIResponse response = mapper.readValue(responseString, CreateLineUIResponse.class);
        URI url = URI.create("http://localhost/cart/nse/new-line");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookie(new HttpCookie("digital_ig_session", "digital_ig_session")).cookie(new HttpCookie("GLOBALID", "GLOBALID1")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(helper.createLine(any())).thenReturn(Mono.just(response));
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.createLine(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void createLineTest11() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/createLine5Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/createLine11Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLineUIResponse response = mapper.readValue(responseString, CreateLineUIResponse.class);
        URI url = URI.create("http://localhost/cart/nse/new-line");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookie(new HttpCookie("digital_ig_session", "digital_ig_session")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(helper.createLine(any())).thenReturn(Mono.just(response));
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.createLine(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void createLineTest12() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/createLine5Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/createLine12Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLineUIResponse response = mapper.readValue(responseString, CreateLineUIResponse.class);
        URI url = URI.create("http://localhost/cart/nse/new-line");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookie(new HttpCookie("digital_ig_session", "digital_ig_session")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(helper.createLine(any())).thenReturn(Mono.just(response));
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.createLine(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        final MockServerHttpRequest mockServerHttpRequest = MockServerHttpRequest.post("http://localhost/")
                .header("channelId", "VZW-DOTCOM")
                .header(CartConstants.ORIGINATING_CLIENT_IP,"162.115.236")
                .build();
        controllerResponse = cartController3.createLine(mockServerHttpRequest, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void createLineTest13() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/createLine5Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/createLine13Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLineUIResponse response = mapper.readValue(responseString, CreateLineUIResponse.class);
        URI url = URI.create("http://localhost/cart/nse/new-line");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookie(new HttpCookie("digital_ig_session", "digital_ig_session")).build();
        ServerHttpResponse httpResponse = null;
        when(helper.createLine(any())).thenReturn(Mono.just(response));
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.createLine(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void createLineTest14() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/createLine5Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/createLine14Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLineUIResponse response = mapper.readValue(responseString, CreateLineUIResponse.class);
        URI url = URI.create("http://localhost/cart/nse/new-line");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookie(new HttpCookie("digital_ig_session", "digital_ig_session")).build();
        ServerHttpResponse httpResponse = null;
        when(helper.createLine(any())).thenReturn(Mono.just(response));
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));
        when(featureFlagHelper.isTradeInPromoCheckFflagEnabled()).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.createLine(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void createLineTest15() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/createLine5Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/createLine15Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLineUIResponse response = mapper.readValue(responseString, CreateLineUIResponse.class);
        URI url = URI.create("http://localhost/cart/nse/new-line");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookie(new HttpCookie("digital_ig_session", "digital_ig_session")).build();
        ServerHttpResponse httpResponse = null;
        when(helper.createLine(any())).thenReturn(Mono.just(response));
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.createLine(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }


    @Test
    public void createLineTest16() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/createLine5Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/createLine16Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLineUIResponse response = mapper.readValue(responseString, CreateLineUIResponse.class);
        URI url = URI.create("http://localhost/cart/nse/new-line");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookie(new HttpCookie("digital_ig_session", "digital_ig_session")).build();
        ServerHttpResponse httpResponse = null;
        when(helper.createLine(any())).thenReturn(Mono.just(response));
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.createLine(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void createLineTest17() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/createLine5Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/createLine17Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLineUIResponse response = mapper.readValue(responseString, CreateLineUIResponse.class);
        URI url = URI.create("http://localhost/cart/nse/new-line");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookie(new HttpCookie("digital_ig_session", "digital_ig_session")).build();
        ServerHttpResponse httpResponse = null;
        when(helper.createLine(any())).thenReturn(Mono.just(response));
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.createLine(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).expectError().verify();
    }

    @Test
    public void createLineErrorTest1() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/createLine1Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/createLineError1Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLineUIResponse response = mapper.readValue(responseString, CreateLineUIResponse.class);
        URI url = URI.create("http://localhost/new-line");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.NOT_FOUND);
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(helper.createLine(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.createLine(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void createLineTest18() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/createLine5Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/createLine12Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLineUIResponse response = mapper.readValue(responseString, CreateLineUIResponse.class);
        URI url = URI.create("http://localhost/cart/nse/new-line");
        request.getCartInfo().setIntendType("NSEBYOD");
        final MockServerHttpRequest mockServerHttpRequest = MockServerHttpRequest.post("http://localhost/")
                .header("channelId", "VZW-DOTCOM")
                .header(CartConstants.ORIGINATING_CLIENT_IP,"162.115.236")
                .build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(helper.createLine(any())).thenReturn(Mono.just(response));
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> controllerResponse=cartController3.createLine(mockServerHttpRequest, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        request.getCartInfo().setIntendType("NSE");
        controllerResponse=cartController3.createLine(mockServerHttpRequest, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addFeaturesTest() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"cartInfo\": {}}";
        AddFeaturesUIRequest request = mapper.readValue(requestString, AddFeaturesUIRequest.class);
        URI url = URI.create("http://localhost/add-features");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.addFeatures(Mockito.any())).thenReturn(Mono.just(mapper.readValue("{\"errors\": [{}]}", AddFeaturesUIResponse.class)));
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        when(featureFlagHelper.isTradeInPromoCheckFflagEnabled()).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> response = cartController.addFeatures(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addFeaturesTest2() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"cartInfo\": {}}";
        String responseString = "{}";
        AddFeaturesUIRequest request = mapper.readValue(requestString, AddFeaturesUIRequest.class);
        AddFeaturesUIResponse uiResponse = mapper.readValue(responseString, AddFeaturesUIResponse.class);
        URI url = URI.create("http://localhost/add-features");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-CARE").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.addFeatures(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(helper.populateProtectionVersion(Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(uiResponse)));
        when(helper.updateFlowNameForAssisted(Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(uiResponse)));

        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        Mono<ResponseEntity<GenericResponse>> response = cartController.addFeatures(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addFeaturesTest3() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"cartInfo\": {}}";
        String responseString = "{\"serviceBody\": {}}";
        AddFeaturesUIRequest request = mapper.readValue(requestString, AddFeaturesUIRequest.class);
        AddFeaturesUIResponse uiResponse = mapper.readValue(responseString, AddFeaturesUIResponse.class);
        URI url = URI.create("http://localhost/add-features");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookie(new HttpCookie("digital_ig_session", "")).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.addFeatures(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(helper.populateProtectionVersion(Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(uiResponse)));
        when(helper.updateFlowNameForAssisted(Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(uiResponse)));
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        Mono<ResponseEntity<GenericResponse>> response = cartController.addFeatures(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addFeaturesTest4() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"cartInfo\": {}}";
        String responseString = "{\"serviceBody\": {\"serviceResponse\": {}}}";
        AddFeaturesUIRequest request = mapper.readValue(requestString, AddFeaturesUIRequest.class);
        AddFeaturesUIResponse uiResponse = mapper.readValue(responseString, AddFeaturesUIResponse.class);
        URI url = URI.create("http://localhost/add-features");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.addFeatures(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(helper.populateProtectionVersion(Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(uiResponse)));
        when(helper.updateFlowNameForAssisted(Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(uiResponse)));
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        Mono<ResponseEntity<GenericResponse>> response = cartController.addFeatures(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addFeaturesTest5() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"cartInfo\": {}}";
        String responseString = "{\"serviceHeader\": {},\"serviceBody\": {\"serviceResponse\": {\"context\": {}}}}";
        AddFeaturesUIRequest request = mapper.readValue(requestString, AddFeaturesUIRequest.class);
        AddFeaturesUIResponse uiResponse = mapper.readValue(responseString, AddFeaturesUIResponse.class);
        URI url = URI.create("http://localhost/add-features");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.addFeatures(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(helper.populateProtectionVersion(Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(uiResponse)));
        when(helper.updateFlowNameForAssisted(Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(uiResponse)));
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        Mono<ResponseEntity<GenericResponse>> response = cartController.addFeatures(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addFeaturesTest6() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"cartInfo\": {}}";
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addFeatures6Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        AddFeaturesUIRequest request = mapper.readValue(requestString, AddFeaturesUIRequest.class);
        AddFeaturesUIResponse uiResponse = mapper.readValue(responseString, AddFeaturesUIResponse.class);
        URI url = URI.create("http://localhost/add-features");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-MFA-ANDROID").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.addFeatures(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(helper.populateProtectionVersion(Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(uiResponse)));
        when(helper.populateSPOsFor5GBolt(Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(uiResponse)));
        when(helper.populateHumWifiConflictedSFos(Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(uiResponse)));
        when(helper.updateFlowNameForAssisted(Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(uiResponse)));

        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        Mono<ResponseEntity<GenericResponse>> response = cartController.addFeatures(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addFeaturesTest7() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"cartInfo\": {}}";
        String responseString = "{\"serviceBody\": {\"serviceResponse\": {\"context\": {\"cartInfo\": {\"lines\": [{}]}}}}}";
        AddFeaturesUIRequest request = mapper.readValue(requestString, AddFeaturesUIRequest.class);
        AddFeaturesUIResponse uiResponse = mapper.readValue(responseString, AddFeaturesUIResponse.class);
        URI url = URI.create("http://localhost/add-features");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-MFA-ANDROID").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.addFeatures(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(helper.populateProtectionVersion(Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(uiResponse)));
        when(helper.populateSPOsFor5GBolt(Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(uiResponse)));
        when(helper.populateHumWifiConflictedSFos(Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(uiResponse)));
        when(redisHelper3.resetConflictReviewStatus()).thenReturn((Mono.empty()));
        when(redisHelper.addFlowNameToRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(helper.updateFlowNameForAssisted(Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(uiResponse)));
        when(featureFlagHelper.isTradeInPromoCheckFflagEnabled()).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> response = cartController.addFeatures(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

        ServerHttpRequest httpHeader1 = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").build();
        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        Mono<ResponseEntity<GenericResponse>> response1 = cartController.addFeatures(httpHeader1, httpResponse, request);
        StepVerifier.create(response1).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

    }


    @Test
    public void addFeaturesTest8() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"cartInfo\": {}}";
        String responseString = "{\"serviceBody\": {\"serviceResponse\": {\"context\": {\"cartInfo\": {\"lines\": []}}}}}";
        AddFeaturesUIRequest request = mapper.readValue(requestString, AddFeaturesUIRequest.class);
        AddFeaturesUIResponse uiResponse = mapper.readValue(responseString, AddFeaturesUIResponse.class);
        URI url = URI.create("http://localhost/add-features");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-CARE").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.addFeatures(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(helper.populateProtectionVersion(Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(uiResponse)));
        when(helper.populateSPOsFor5GBolt(Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(uiResponse)));
        when(helper.populateHumWifiConflictedSFos(Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(uiResponse)));
        when(helper.updateFlowNameForAssisted(Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(httpResponse.getStatusCode()).body(uiResponse)));

        List<Flag> flags = new ArrayList<>();
        ConfigurationProfile configurationProfile = new ConfigurationProfile();
        configurationProfile.setFlags(flags);
        when(featureFlagHelper.fetchDigitalPerformanceCfgProfile()).thenReturn(Mono.just(configurationProfile));
        Mono<ResponseEntity<GenericResponse>> response = cartController.addFeatures(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void resumeAndContinueTest() throws JsonProcessingException {
        String requestString = "{}";
        String responseString = "{\"errors\": [{}]}";
        ResumeAndContinueUIRequest request = mapper.readValue(requestString, ResumeAndContinueUIRequest.class);
        ResumeAndContinueUIResponse uiResponse = mapper.readValue(responseString, ResumeAndContinueUIResponse.class);
        URI url = URI.create("http://localhost/resumeAndContinue");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.ACCEPTED);
        when(helper.resumeAndContinue(Mockito.any())).thenReturn(Mono.just(uiResponse));
        Mono<ResponseEntity<GenericResponse>> response = cartController.resumeAndContinue(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void resumeAndContinueTest2() throws JsonProcessingException {
        String requestString = "{\"cartInfo\": {\"mtnFlow\": \"A\"}}";
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addFeatures6Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        ResumeAndContinueUIRequest request = mapper.readValue(requestString, ResumeAndContinueUIRequest.class);
        ResumeAndContinueUIResponse uiResponse = mapper.readValue(responseString, ResumeAndContinueUIResponse.class);
        URI url = URI.create("http://localhost/resumeAndContinue");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.ACCEPTED);
        when(helper.resumeAndContinue(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just(""));
        Mono<ResponseEntity<GenericResponse>> response = cartController.resumeAndContinue(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void resumeAndContinueTest3() throws JsonMappingException, JsonProcessingException {
        String requestString = "{\"cartInfo\": {}}";
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addFeatures6Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        ResumeAndContinueUIRequest request = mapper.readValue(requestString, ResumeAndContinueUIRequest.class);
        ResumeAndContinueUIResponse uiResponse = mapper.readValue(responseString, ResumeAndContinueUIResponse.class);
        URI url = URI.create("http://localhost/resumeAndContinue");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.ACCEPTED);
        when(helper.resumeAndContinue(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just(""));
        Mono<ResponseEntity<GenericResponse>> response = cartController.resumeAndContinue(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void resumeAndContinueTest4() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/resumeAndContinue4Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addFeatures6Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        String dataString = "{}";
        ResumeAndContinueUIRequest request = mapper.readValue(requestString, ResumeAndContinueUIRequest.class);
        ResumeAndContinueUIResponse uiResponse = mapper.readValue(responseString, ResumeAndContinueUIResponse.class);
        CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
        URI url = URI.create("http://localhost/resumeAndContinue");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.ACCEPTED);
        when(helper.resumeAndContinue(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("device"));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(data));
        Mono<ResponseEntity<GenericResponse>> response = cartController.resumeAndContinue(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void resumeAndContinueTest5() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/resumeAndContinue4Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addFeatures6Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        String dataString = "{\"deviceCartInfo\":{}}";
        ResumeAndContinueUIRequest request = mapper.readValue(requestString, ResumeAndContinueUIRequest.class);
        ResumeAndContinueUIResponse uiResponse = mapper.readValue(responseString, ResumeAndContinueUIResponse.class);
        CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
        URI url = URI.create("http://localhost/resumeAndContinue");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.ACCEPTED);
        when(helper.resumeAndContinue(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("device"));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(data));
        Mono<ResponseEntity<GenericResponse>> response = cartController.resumeAndContinue(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void resumeAndContinueTest6() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/resumeAndContinue4Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addFeatures6Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        String dataString = "{\"deviceCartInfo\":{\"intendType\": \"AAL\"}}";
        ResumeAndContinueUIRequest request = mapper.readValue(requestString, ResumeAndContinueUIRequest.class);
        ResumeAndContinueUIResponse uiResponse = mapper.readValue(responseString, ResumeAndContinueUIResponse.class);
        CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
        URI url = URI.create("http://localhost/resumeAndContinue");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.ACCEPTED);
        when(helper.resumeAndContinue(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("device"));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(data));
        when(helper.addDeviceClearAndContinue(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(new AddDeviceUIResponse()));
        Mono<ResponseEntity<GenericResponse>> response = cartController.resumeAndContinue(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void resumeAndContinueTest7() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/resumeAndContinue4Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addFeatures6Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        String dataString = "{\"deviceCartInfo\":{\"intendType\": \"ACC\"}}";
        ResumeAndContinueUIRequest request = mapper.readValue(requestString, ResumeAndContinueUIRequest.class);
        ResumeAndContinueUIResponse uiResponse = mapper.readValue(responseString, ResumeAndContinueUIResponse.class);
        CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
        URI url = URI.create("http://localhost/resumeAndContinue");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.ACCEPTED);
        when(helper.resumeAndContinue(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("device"));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(data));
        when(helper.addDeviceClearAndContinue(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(mapper.readValue("{\"errors\": [{}]}", AddDeviceUIResponse.class)));
        Mono<ResponseEntity<GenericResponse>> response = cartController.resumeAndContinue(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void resumeAndContinueTest8() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/resumeAndContinue4Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addFeatures6Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        String dataString = "{\"deviceCartInfo\":{\"intendType\": \"ACC\"}}";
        ResumeAndContinueUIRequest request = mapper.readValue(requestString, ResumeAndContinueUIRequest.class);
        ResumeAndContinueUIResponse uiResponse = mapper.readValue(responseString, ResumeAndContinueUIResponse.class);
        CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
        URI url = URI.create("http://localhost/resumeAndContinue");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.resumeAndContinue(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("device"));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(data));
        when(helper.addDeviceClearAndContinue(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(mapper.readValue("{\"errors\": [{}]}", AddDeviceUIResponse.class)));
        Mono<ResponseEntity<GenericResponse>> response = cartController.resumeAndContinue(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void resumeAndContinueTest9() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/resumeAndContinue4Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addFeatures6Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        String dataString = "{\"accessoryCartInfo\":{\"intendType\": \"AAL\"}}";
        ResumeAndContinueUIRequest request = mapper.readValue(requestString, ResumeAndContinueUIRequest.class);
        ResumeAndContinueUIResponse uiResponse = mapper.readValue(responseString, ResumeAndContinueUIResponse.class);
        CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
        URI url = URI.create("http://localhost/resumeAndContinue");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.ACCEPTED);
        when(helper.resumeAndContinue(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("accessory"));
        when(redisHelper.getAccessoryDataFromRedisAsString()).thenReturn(Mono.just(data));
        when(helper.addAccessoryClearAndContinue(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(new AddAccessoriesUIResponse()));
        Mono<ResponseEntity<GenericResponse>> response = cartController.resumeAndContinue(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void resumeAndContinueTest10() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/resumeAndContinue4Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addFeatures6Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        String dataString = "{\"accessoryCartInfo\":{\"intendType\": \"ACC\"}}";
        ResumeAndContinueUIRequest request = mapper.readValue(requestString, ResumeAndContinueUIRequest.class);
        ResumeAndContinueUIResponse uiResponse = mapper.readValue(responseString, ResumeAndContinueUIResponse.class);
        CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
        URI url = URI.create("http://localhost/resumeAndContinue");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.ACCEPTED);
        when(helper.resumeAndContinue(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("accessory"));
        when(redisHelper.getAccessoryDataFromRedisAsString()).thenReturn(Mono.just(data));
        when(helper.addAccessoryClearAndContinue(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(mapper.readValue("{\"errors\": [{}]}", AddAccessoriesUIResponse.class)));
        Mono<ResponseEntity<GenericResponse>> response = cartController.resumeAndContinue(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void resumeAndContinueTest11() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/resumeAndContinue4Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addFeatures6Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        String dataString = "{\"accessoryCartInfo\":{\"intendType\": \"NSE\"}}";
        ResumeAndContinueUIRequest request = mapper.readValue(requestString, ResumeAndContinueUIRequest.class);
        ResumeAndContinueUIResponse uiResponse = mapper.readValue(responseString, ResumeAndContinueUIResponse.class);
        CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
        URI url = URI.create("http://localhost/resumeAndContinue");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.resumeAndContinue(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("accessory"));
        when(redisHelper.getAccessoryDataFromRedisAsString()).thenReturn(Mono.just(data));
        when(helper.addAccessoryClearAndContinue(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(mapper.readValue("{\"errors\": [{}]}", AddAccessoriesUIResponse.class)));
        Mono<ResponseEntity<GenericResponse>> response = cartController.resumeAndContinue(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void resumeAndContinueTest12() throws JsonMappingException, JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/resumeAndContinue4Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/addFeatures6Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        String dataString = "{\"accessoryCartInfo\":{\"intendType\": \"ACC\"}}";
        ResumeAndContinueUIRequest request = mapper.readValue(requestString, ResumeAndContinueUIRequest.class);
        ResumeAndContinueUIResponse uiResponse = mapper.readValue(responseString, ResumeAndContinueUIResponse.class);
        CartRedisData data = mapper.readValue(dataString, CartRedisData.class);
        URI url = URI.create("http://localhost/resumeAndContinue");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.BAD_REQUEST);
        when(helper.resumeAndContinue(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("accessory"));
        when(redisHelper.getAccessoryDataFromRedisAsString()).thenReturn(Mono.just(data));
        when(helper.addAccessoryClearAndContinue(Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(mapper.readValue("{\"errors\": [{}]}", AddAccessoriesUIResponse.class)));
        Mono<ResponseEntity<GenericResponse>> response = cartController.resumeAndContinue(httpHeader, httpResponse, request);
        StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void resumeAndContinueTest13() throws  JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/resumeAndContinue4Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"serviceBody\": {\"serviceResponse\": {}}}";
        ResumeAndContinueUIRequest request = mapper.readValue(requestString, ResumeAndContinueUIRequest.class);
        ResumeAndContinueUIResponse uiResponse = mapper.readValue(responseString, ResumeAndContinueUIResponse.class);
        URI url = URI.create("http://localhost/resumeAndContinue");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.ACCEPTED);
        when(helper.resumeAndContinue(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("devi"));
        Mono<ResponseEntity<GenericResponse>> response = cartController.resumeAndContinue(httpHeader, httpResponse, request);
        StepVerifier.create(response).expectError().verify();
    }

    @Test
    public void resumeAndContinueTest14() throws  JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/resumeAndContinue4Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"serviceBody\": {}}";
        ResumeAndContinueUIRequest request = mapper.readValue(requestString, ResumeAndContinueUIRequest.class);
        ResumeAndContinueUIResponse uiResponse = mapper.readValue(responseString, ResumeAndContinueUIResponse.class);
        URI url = URI.create("http://localhost/resumeAndContinue");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.ACCEPTED);
        when(helper.resumeAndContinue(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("devi"));
        Mono<ResponseEntity<GenericResponse>> response = cartController.resumeAndContinue(httpHeader, httpResponse, request);
        StepVerifier.create(response).expectError().verify();
    }

    @Test
    public void resumeAndContinueTest15() throws  JsonProcessingException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/resumeAndContinue4Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseString = "{\"serviceHeader\": {}}";
        ResumeAndContinueUIRequest request = mapper.readValue(requestString, ResumeAndContinueUIRequest.class);
        ResumeAndContinueUIResponse uiResponse = mapper.readValue(responseString, ResumeAndContinueUIResponse.class);
        URI url = URI.create("http://localhost/resumeAndContinue");
        ServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.ACCEPTED);
        when(helper.resumeAndContinue(Mockito.any())).thenReturn(Mono.just(uiResponse));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(Mockito.any())).thenReturn(Mono.just(true));
        when(redisHelper.getItemTypeFromRedis()).thenReturn(Mono.just("devi"));
        Mono<ResponseEntity<GenericResponse>> response = cartController.resumeAndContinue(httpHeader, httpResponse, request);
        StepVerifier.create(response).expectError().verify();
    }

    @Test
    public void calculateMultiLineTaxForCartTest() throws IOException{
        String requestFile = "CalculateMultiLinetaxForCartRequestTest.json";
        String responseFile = "CalculateMultiLinetaxForCartResponseTest.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        CalculateMultilineTaxUIRequest request = mapper.readValue(sampleRequestString, CalculateMultilineTaxUIRequest.class);
        CalculateMultilineTaxUIResponse response = mapper.readValue(sampleResponseString, CalculateMultilineTaxUIResponse.class);
        when(helper.calculateMultiLineTaxForCart(Mockito.any())).thenReturn(Mono.just(response));
        URI url = URI.create("http://localhost/calculateMultiLineTaxForCart");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.calculateMultiLineTaxForCart(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {
            assertNotNull(resp);}).expectComplete().verify();
    }

    @Test
    public void calculateMultiLineTaxForCartTest1() throws IOException{
        String requestFile = "data/CartUpdateOperationsControllerTestJson/calculateMultiLineTaxForCartRequestTest.json";
        String responseFile = "data/CartUpdateOperationsControllerTestJson/calculateMultiLineTaxForCartResponseTest.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        CalculateMultilineTaxUIRequest request = mapper.readValue(sampleRequestString, CalculateMultilineTaxUIRequest.class);
        CalculateMultilineTaxUIResponse response = mapper.readValue(sampleResponseString, CalculateMultilineTaxUIResponse.class);
        when(helper.calculateMultiLineTaxForCart(Mockito.any())).thenReturn(Mono.just(response));
        AddZipcodeRedisData addZipcodeRedisData = new AddZipcodeRedisData();
        addZipcodeRedisData.setZipCode("1234");
        when(helper.updateZipcodeToCart(Mockito.any(), Mockito.any())).thenReturn(Mono.just(addZipcodeRedisData));
        URI url = URI.create("http://localhost/nse/calculateMultiLineTaxForCart");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("mtn", "8437299178").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.addCookie(ResponseCookie.from("cdlThrottleList","abandonCart").build());
        httpResponse.setStatusCode(HttpStatus.OK);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.calculateMultiLineTaxForCart(httpRequest,httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> {
            assertNotNull(resp);}).expectComplete().verify();
    }

    @Test
    public void calculateMultiLineTaxForCartTest3() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/calculateMultiLine3Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/calculateMultiLine3Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        CalculateMultilineTaxUIRequest request = mapper.readValue(requestString, CalculateMultilineTaxUIRequest.class);
        CalculateMultilineTaxUIResponse response = mapper.readValue(responseString,CalculateMultilineTaxUIResponse.class);
        URI url = URI.create("http://localhost/nse/calculateMultiLineTaxForCart");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        when(helper.calculateMultiLineTaxForCart(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.calculateMultiLineTaxForCart(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void calculateMultiLineTaxForCartTest4() throws IOException {
        String responseFile = "data/CartUpdateOperationsControllerTestJson/calculateMultiLine3Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        CalculateMultilineTaxUIRequest request = null;
        CalculateMultilineTaxUIResponse response = mapper.readValue(responseString,CalculateMultilineTaxUIResponse.class);
        URI url = URI.create("http://localhost/nse/calculateMultiLineTaxForCart");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        when(helper.calculateMultiLineTaxForCart(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.calculateMultiLineTaxForCart(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void calculateMultiLineTaxForCartTest5() throws IOException {
        String responseFile = "data/CartUpdateOperationsControllerTestJson/calculateMultiLine3Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        CalculateMultilineTaxUIRequest request = null;
        CalculateMultilineTaxUIResponse response = mapper.readValue(responseString,CalculateMultilineTaxUIResponse.class);
        URI url = URI.create("");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = null;
        when(helper.calculateMultiLineTaxForCart(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.calculateMultiLineTaxForCart(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void calculateMultiLineTaxForCartTest6() throws IOException {
        String requestFile = "data/CartUpdateOperationsControllerTestJson/calculateMultiLine6Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/createLineError1Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        CalculateMultilineTaxUIRequest request = mapper.readValue(requestString, CalculateMultilineTaxUIRequest.class);
        CalculateMultilineTaxUIResponse response = mapper.readValue(responseString,CalculateMultilineTaxUIResponse.class);
        URI url = URI.create("http://localhost/nse/calculateMultiLineTaxForCart");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.NOT_FOUND);
        when(helper.calculateMultiLineTaxForCart(any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.calculateMultiLineTaxForCart(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void newLineFlexV2Test() throws Exception{
            String requestFile = "data/CartUpdateOperationsControllerTestJson/createLineFlexV2Req.json";
            String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
            String responseFile = "data/CartUpdateOperationsControllerTestJson/createLineFlexV2Resp.json";
            String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
            CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
            CreateLineUIResponse response = mapper.readValue(responseString, CreateLineUIResponse.class);
            URI url = URI.create("http://localhost/flexV2/new-line");
            MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookie(new HttpCookie("digital_ig_session", "digital_ig_session")).build();
            ServerHttpResponse httpResponse = new MockServerHttpResponse();
            when(helper.createLine(any())).thenReturn(Mono.just(response));
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
            when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));
            Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.createLine(httpHeader, httpResponse,request);
            StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }
    @Test
    public void newLineTest() throws Exception{
        String requestFile = "data/CartUpdateOperationsControllerTestJson/newLineRequest.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/newLineResponse.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLineUIResponse response = mapper.readValue(responseString, CreateLineUIResponse.class);
        URI url = URI.create("http://localhost/nse/new-line");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookie(new HttpCookie("digital_ig_session", "digital_ig_session")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(helper.createLine(any())).thenReturn(Mono.just(response));
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.createLine(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
        when(featureFlagHelper.isHubProspectCartCookieDomainIssueFFlagEnabled()).thenReturn(Boolean.TRUE);
        controllerResponse = cartController3.createLine(httpHeader, httpResponse,request);
        response.getServiceBody().getServiceResponse().getContext().getContextInfo().setProcessStep("test");
        response.getServiceBody().getServiceResponse().getContext().getContextInfo().setCradleFlowJourney("test");
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }
    @Test
    public void newLineTest2() throws Exception{
        String requestFile = "data/CartUpdateOperationsControllerTestJson/newLine2Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/CartUpdateOperationsControllerTestJson/newLine2Response.json";
        String responseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLineUIResponse response = mapper.readValue(responseString, CreateLineUIResponse.class);
        URI url = URI.create("http://localhost/nse/new-line");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookie(new HttpCookie("digital_ig_session", "digital_ig_session")).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(helper.createLine(any())).thenReturn(Mono.just(response));
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));
        doNothing().when(dlService).buildDLData(any());
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.createLine(httpHeader, httpResponse,request);
        StepVerifier.create(controllerResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
    }
    @Test
    public void addDeviceWithBuyoutTestMVO() throws IOException {
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/addDeviceWithBuyout");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        when(featureFlagHelper.isTradeInPromoCheckFflagEnabled()).thenReturn(Mono.just(Boolean.TRUE));
        ReflectionTestUtils.setField(cartController2,"domains", List.of(".verizon.com",".verizonwireless.com"));
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\",\"caseId\":\"SOP-329-E01\",\"accountNumber\":\"0820215913-00001\",\"cartCreator\":\"8149348075\",\"processingMTN\":\"8149348075\",\"processStep\":\"DPPSummary\",\"intendType\":\"EUP\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"Y\",\"edgeUpSelected\":\"N\",\"processAction\":\"addBuyoutAmtAndDevice\",\"mtnFlow\":\"M\",\"myvPage\":true},\"data\":{\"lines\":[{\"mtn\":\"8149348075\",\"isEdgeBuyOut\":true}],\"effectiveDate\":\"\"}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addDeviceWithBuyout(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> junit.framework.Assert.assertNotNull(resp)).expectComplete()
                .verify();
        String requestString1 = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\",\"caseId\":\"SOP-329-E01\",\"accountNumber\":\"0820215913-00001\",\"cartCreator\":\"8149348075\",\"processingMTN\":\"8149348075\",\"processStep\":\"DPPSummary\",\"intendType\":\"EUP\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"Y\",\"edgeUpSelected\":\"N\",\"processAction\":\"addBuyoutAmtAndDevice\",\"mtnFlow\":\"M\",\"myvPage\":false},\"data\":{\"lines\":[{\"mtn\":\"8149348075\",\"isEdgeBuyOut\":true}],\"effectiveDate\":\"\"}}";
        AddDeviceUIRequest request1 = mapper.readValue(requestString1, AddDeviceUIRequest.class);
        Mono<ResponseEntity<GenericResponse>> controllerResponse1 = cartController2.addDeviceWithBuyout(httpHeader,
                httpResponse, request1);
        StepVerifier.create(controllerResponse1).assertNext(resp -> junit.framework.Assert.assertNotNull(resp)).expectComplete()
                .verify();
        String requestString2 = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"f395ce3f-0a26-49ff-85a1-fe6c56cfa8ed\",\"caseId\":\"SOP-329-E01\",\"accountNumber\":\"0820215913-00001\",\"cartCreator\":\"8149348075\",\"processingMTN\":\"8149348075\",\"processStep\":\"DPPSummary\",\"intendType\":\"EUP\",\"buyOutFlag\":\"Y\",\"buyOutSelected\":\"Y\",\"edgeUpSelected\":\"N\",\"processAction\":\"addBuyoutAmtAndDevice\",\"mtnFlow\":\"E\",\"myvPage\":true},\"data\":{\"lines\":[{\"mtn\":\"8149348075\",\"isEdgeBuyOut\":true}],\"effectiveDate\":\"\"}}";
        AddDeviceUIRequest request2 = mapper.readValue(requestString2, AddDeviceUIRequest.class);
        Mono<ResponseEntity<GenericResponse>> controllerResponse2 = cartController2.addDeviceWithBuyout(httpHeader,
                httpResponse, request2);
        StepVerifier.create(controllerResponse2).assertNext(resp -> junit.framework.Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceWithEdgeupTest() throws IOException {
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"Cases\":[],\"caseId\":\"SOP-329-E01\",\"contextInfo\":{\"pendingOrderAccountLevel\":\" \",\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"MTNSelectionPage/ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"lookupMTN\":\" \",\"accountNumber\":\"0820215913-00001\"}}}}}";
        String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"accountNumber\": \"0222965595-00001\", \"mtn\": \"8436667390\" }";
        CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/addDeviceWithEdgeup");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(sampleRedisData));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        when(featureFlagHelper.isTradeInPromoCheckFflagEnabled()).thenReturn(Mono.just(Boolean.TRUE));
        ReflectionTestUtils.setField(cartController2,"domains",List.of(".verizon.com",".verizonwireless.com"));
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"7702864195\",\"processStep\":\"DPPSummary\",\"buyOutFlag\":\"Y\",\"intendType\":\"EUP\",\"buyOutSelected\":\"N\",\"edgeUpSelected\":\"Y\",\"FMITurnedoff\":\"Y\",\"deviceMisMatched\":\"N\",\"processAction\":\"addEdgeUpAmtAndDevice\",\"mtnFlow\":\"M\",\"myvPage\":false},\"data\":{\"lines\":[{\"mtn\":\"7702864195\",\"isEdgeBuyOut\":true,\"edgeup\":{\"deviceId\":\"353547798635648\",\"edgeupAmount\":\"$227.29\"}}],\"effectiveDate\":\"\"}}";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController2.addDeviceWithEdgeup(httpHeader,
                httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> junit.framework.Assert.assertNotNull(resp)).expectComplete()
                .verify();
        String requestString1 = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"7702864195\",\"processStep\":\"DPPSummary\",\"buyOutFlag\":\"Y\",\"intendType\":\"EUP\",\"buyOutSelected\":\"N\",\"edgeUpSelected\":\"Y\",\"FMITurnedoff\":\"Y\",\"deviceMisMatched\":\"N\",\"processAction\":\"addEdgeUpAmtAndDevice\",\"mtnFlow\":\"M\",\"myvPage\":true},\"data\":{\"lines\":[{\"mtn\":\"7702864195\",\"isEdgeBuyOut\":true,\"edgeup\":{\"deviceId\":\"353547798635648\",\"edgeupAmount\":\"$227.29\"}}],\"effectiveDate\":\"\"}}";
        AddDeviceUIRequest request1 = mapper.readValue(requestString1, AddDeviceUIRequest.class);
        Mono<ResponseEntity<GenericResponse>> controllerResponse1 = cartController2.addDeviceWithEdgeup(httpHeader,
                httpResponse, request1);
        StepVerifier.create(controllerResponse1).assertNext(resp -> junit.framework.Assert.assertNotNull(resp)).expectComplete()
                .verify();
        String requestString2 = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"7702864195\",\"processStep\":\"DPPSummary\",\"buyOutFlag\":\"Y\",\"intendType\":\"EUP\",\"buyOutSelected\":\"N\",\"edgeUpSelected\":\"Y\",\"FMITurnedoff\":\"Y\",\"deviceMisMatched\":\"N\",\"processAction\":\"addEdgeUpAmtAndDevice\",\"mtnFlow\":\"E\",\"myvPage\":true},\"data\":{\"lines\":[{\"mtn\":\"7702864195\",\"isEdgeBuyOut\":true,\"edgeup\":{\"deviceId\":\"353547798635648\",\"edgeupAmount\":\"$227.29\"}}],\"effectiveDate\":\"\"}}";
        AddDeviceUIRequest request2 = mapper.readValue(requestString2, AddDeviceUIRequest.class);
        Mono<ResponseEntity<GenericResponse>> controllerResponse2 = cartController2.addDeviceWithEdgeup(httpHeader,
                httpResponse, request2);
        StepVerifier.create(controllerResponse2).assertNext(resp -> junit.framework.Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }
}
