package onevz.soe.cart.service.test.cases;

import static org.mockito.Mockito.when;

import java.io.IOException;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.fasterxml.jackson.databind.ObjectMapper;

import onevz.soe.cart.bpm.helper.CartServiceBpmHelper3;
import onevz.soe.cart.helper.RedisHelper;
import onevz.soe.cart.helper.ResumeCartHelper;
import onevz.soe.cart.model.clearAndContinue.ClearAndContinueContext;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.ClearAndContinueUIRequest;
import onevz.soe.cart.ui.responses.ClearAndContinueUIResponse;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(ResumeCartHelper.class)
//@SpringBootTest
public class ResumeCartHelperTest {
	
	@Autowired
	private ResumeCartHelper resumeCartHelper;

	@MockBean
	private CartServiceBpmHelper3 bpmHelper;

	@MockBean
	private RedisHelper redisHelper;

	@Autowired
	private ObjectMapper mapper;

	@Autowired
	SourceFileReaderUtil sourceFileReaderUtil;
	
	@Value("${onevz.soe.cart.test.fileLocation}")
	private String testFileLocation;

	@Test
	public void clearAndResumeTest() throws IOException, SOEHTTPException {
		String requestString = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"prospectCartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processAction\":\"addAccessoryAndCheckout\",\"processStep\":\"AccessoryPDP\",\"intendType\":\"NSEACC\",\"pageId\":\"CART\",\"intent\":\"StandAloneAccessory\",\"cradleFlowJourney\":\"PromoHub\",\"action\":\"UPDATE\",\"itemType\":\"ACCESSORY\"}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGAgeneratedmessage\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\"]},{\"mtn\": \"2515813861\",\"completedprocessSteps\": []}],\"cartInfo\":{\"cartId\":\"a705f835-c61a-4e20-b616-0c9839202a15\"},\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"PromoHub\",\"availablePaths\":[{\"path\":\"PromoHub\"},{\"path\":\"MTNSelectionPage\"}],\"callReason\":\"SalesOrderPurchase\"}}}}}";
		ClearAndContinueUIRequest sampleRequest = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
		ClearAndContinueUIResponse sampleResponse = mapper.readValue(responseString, ClearAndContinueUIResponse.class);
		
		String redisDataString = "{ \"cartId\": \"20ae6bcb-1150-4d16-99dd-14b7d9f128c7\", \"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"accountNumber\": \"0222965595-00001\", \"prospectCartId\": \"8436667390\" , \"locationCode\":\"8436667390\", \"intendType\":\"123\", \"mtn\":\"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		
		Mono<ClearAndContinueUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper.clearAndResume(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		Mono<ClearAndContinueUIResponse> response = resumeCartHelper.clearAndResume(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete()
				.verify();
	}

	@Test
	public void clearAndResumeCaseIdTest() throws IOException, SOEHTTPException {
		String requestFile = "MockResumeCartRequest.json";
		String responseFile = "MockResumeCartResponse.json";
		String redisFile = "MockRedisData.json";
		String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
		String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
		ClearAndContinueUIRequest sampleRequest = mapper.readValue(sampleRequestString, ClearAndContinueUIRequest.class);
		ClearAndContinueUIResponse sampleResponse = mapper.readValue(sampleResponseString, ClearAndContinueUIResponse.class);
		sampleResponse.getServiceBody().getServiceResponse().setContext(new ClearAndContinueContext());
		sampleResponse.getServiceBody().getServiceResponse().getContext().setCaseId("");
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<ClearAndContinueUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper.clearAndResume(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper.deleteCartIdAndCaseIdAndExistingCaseFromRedis()).thenReturn(Mono.just(Long.valueOf(123)));
		ClearAndContinueUIResponse expectedResponse = sampleResponse;
		Mono<ClearAndContinueUIResponse> response = resumeCartHelper.clearAndResume(sampleRequest);
		StepVerifier.create(response).expectError();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}

	@Test
	public void clearAndResumeCartIdTest() throws IOException, SOEHTTPException {
		String requestFile = "MockResumeCartRequest.json";
		String responseFile = "MockResumeCartResponse.json";
		String redisFile = "MockRedisData.json";
		String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
		String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
		ClearAndContinueUIRequest sampleRequest = mapper.readValue(sampleRequestString, ClearAndContinueUIRequest.class);
		ClearAndContinueUIResponse sampleResponse = mapper.readValue(sampleResponseString, ClearAndContinueUIResponse.class);
		sampleResponse.getServiceBody().getServiceResponse().setContext(new ClearAndContinueContext());
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<ClearAndContinueUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper.clearAndResume(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		when(redisHelper.deleteCartIdAndCaseIdAndExistingCaseFromRedis()).thenReturn(Mono.just(1L));
		ClearAndContinueUIResponse expectedResponse = sampleResponse;
		Mono<ClearAndContinueUIResponse> response = resumeCartHelper.clearAndResume(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}

	@Test
	public void clearAndResumeErrorTest() throws IOException, SOEHTTPException {
		String requestFile = "MockResumeCartRequest.json";
		String responseFile = "MockResumeCartErrorResponse.json";
		String redisFile = "MockRedisData.json";
		String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		String sampleResponseString = sourceFileReaderUtil.readFile(responseFile, testFileLocation);
		String redisDataString = sourceFileReaderUtil.readFile(redisFile, testFileLocation);
		ClearAndContinueUIRequest sampleRequest = mapper.readValue(sampleRequestString, ClearAndContinueUIRequest.class);
		ClearAndContinueUIResponse sampleResponse = mapper.readValue(sampleResponseString, ClearAndContinueUIResponse.class);
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		Mono<ClearAndContinueUIResponse> sampleResponseMono = Mono.just(sampleResponse);
		when(bpmHelper.clearAndResume(Mockito.any())).thenReturn(sampleResponseMono);
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		ClearAndContinueUIResponse expectedResponse = sampleResponse;
		Mono<ClearAndContinueUIResponse> response = resumeCartHelper.clearAndResume(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
		StepVerifier.create(response).assertNext(resp -> Assert.assertEquals(expectedResponse, resp)).expectComplete()
				.verify();
	}
	
	@Test
	public void clearAndResumeTest2() throws IOException, SOEHTTPException {
		String requestString = "{\"cartInfo\":{\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"cartId\":\"\",\"prospectCartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processAction\":\"addAccessoryAndCheckout\",\"processStep\":\"AccessoryPDP\",\"intendType\":\"NSEACC\",\"pageId\":\"CART\",\"intent\":\"StandAloneAccessory\",\"cradleFlowJourney\":\"PromoHub\",\"action\":\"UPDATE\",\"itemType\":\"ACCESSORY\"}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-ECOM\",\"statusMsg\":\"PEGAgeneratedmessage\",\"correlationId\":\"69a66ef4d7e344dfb2db299209ea8333\",\"sessionId\":\"\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1583186-DEV3\",\"customerInfo\":{\"accountNumber\":\"07893451230-00001\",\"cartCreator\":\"2515813861\",\"processingMTN\":\"2515813860\"},\"processMTNList\":[{\"mtn\":\"2515813860\",\"completedprocessSteps\":[\"MTNSelectionPage\",\"GridWallPDP\"]},{\"mtn\": \"2515813861\",\"completedprocessSteps\": []}],\"cartInfo\":{\"cartId\":\"a705f835-c61a-4e20-b616-0c9839202a15\"},\"contextInfo\":{\"processAction\":\"\",\"processStep\":\"PromoHub\",\"availablePaths\":[{\"path\":\"PromoHub\"},{\"path\":\"MTNSelectionPage\"}],\"callReason\":\"SalesOrderPurchase\"}}}}}";
		ClearAndContinueUIRequest sampleRequest = mapper.readValue(requestString, ClearAndContinueUIRequest.class);
		ClearAndContinueUIResponse sampleResponse = mapper.readValue(responseString, ClearAndContinueUIResponse.class);
		String redisDataString = "{\"caseId\": \"SOP-538499-E01\", \"processingMTN\": \"1234567890\", \"cartCreator\": \"1234567890\", \"prospectCartId\": \"8436667390\" , \"locationCode\":\"8436667390\", \"mtn\":\"8436667390\" }";
		CartRedisData sampleRedisData = mapper.readValue(redisDataString, CartRedisData.class);
		when(bpmHelper.clearAndResume(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(sampleRedisData));
		Mono<ClearAndContinueUIResponse> response = resumeCartHelper.clearAndResume(sampleRequest);
		StepVerifier.create(response).assertNext(resp -> Assert.assertNotNull(resp.getServiceBody())).expectComplete().verify();
	}
}
