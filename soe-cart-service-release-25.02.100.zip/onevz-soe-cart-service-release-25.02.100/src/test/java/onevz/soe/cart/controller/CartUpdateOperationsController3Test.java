package onevz.soe.cart.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.micrometer.core.instrument.util.IOUtils;
import junit.framework.Assert;
import onevz.cxp.feature.util.FeatureFlag;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.constants.FeatureFlagConstants;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.model.addDevice.AddDeviceServiceBody;
import onevz.soe.cart.model.addDevice.AddDeviceServiceResponse;
import onevz.soe.cart.model.addPlan.AddPlanLineDevice;
import onevz.soe.cart.model.common.CartServiceCartInfo;
import onevz.soe.cart.model.common.DeviceImeiSimDetails;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.responses.CustomerProfileCXPResponse;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.AddAccessoriesUIRequest;
import onevz.soe.cart.ui.requests.AddDeviceUIRequest;
import onevz.soe.cart.ui.requests.CreateLineUIRequest;
import onevz.soe.cart.ui.responses.AddAccessoriesUIResponse;
import onevz.soe.cart.ui.responses.AddDeviceUIResponse;
import onevz.soe.cart.ui.responses.CreateLineUIResponse;
import onevz.soe.cart.util.CartPegaRequestUtil;
import onevz.soe.cart.util.CartUtil;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.omnidl.service.OmniDLService;
import onevz.soe.omnidl.util.DLUtilityService;
import onevz.soe.session.bean.SOELoginSessionBean;
import onevz.soe.wsclient.bpm.model.CartInfo;
import onevz.soe.wsclient.bpm.model.Context;
import onevz.soe.wsclient.bpm.model.ServiceBody;
import onevz.soe.wsclient.bpm.model.response.ServiceResponse;
import onevz.soe.wsclient.http.exceptions.SOEHTTPException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.*;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpResponse;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import onevz.soe.spring.web.filter.RequestAccessContext;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.ResourceUtils;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;


@RunWith(SpringJUnit4ClassRunner.class)
@WebFluxTest(CartUpdateOperationsController3.class)
public class CartUpdateOperationsController3Test {

    @MockBean
    private RedisHelper redisHelper;
    @MockBean
    private OmniDLHelper omniDLHelper;
    @MockBean
    private FeatureFlagHelper featureFlagHelper;

    @MockBean
    private RedisHelper2 redisHelper2;

    @MockBean
    private RedisHelper3 redisHelper3;
    @MockBean
    private DLUtilityService dlUtilityService;

    @Autowired
    private ObjectMapper mapper;

    @MockBean
    private CartAddDeviceHelper devHelper;

    @MockBean
    private UpdateCartHelper cartHelper;
    @MockBean
    private FeatureFlag featureFlag;

    @Autowired
    private CartUpdateOperationsController3 cartController3;
    @MockBean
    private CartAccessoryLoggingHelper cartAccessoryLoggingHelper;

    @MockBean
    private FiveGhomeCommonHelper fiveGhomeCommonHelper;

    @MockBean
    private CartAccessoryHelper accHelper;

    @MockBean
    private SOELoginSessionBean soeLoginSessionBean;

    @Mock
    private CartPegaRequestUtil cartPegaRequestUtil;

    @MockBean
    private OmniDLService dlService;
    @Mock
    private ServerHttpResponse httpResponse;
    @Mock
    private AddDeviceUIRequest request;
    @Mock
    private AddDeviceUIResponse pegaResponse;

    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;

    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;

    @Before
    public void setUp() {
//        ReflectionTestUtils.setField(cartPegaRequestUtil,"enableDvmConversionFlag",true);
        final LinkedMultiValueMap<String, HttpCookie> cookies = new LinkedMultiValueMap<>();
        HttpCookie migrationCookie = new HttpCookie(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, "true-cookie");
        HttpCookie dvmCookie = new HttpCookie(CartConstants.DVM_CONVERSION_COOKIE, "true-cookie");
        cookies.add(CartConstants.PREPAID_TO_POSTPAID_MIGRATION, migrationCookie);
        cookies.add(CartConstants.DVM_CONVERSION_COOKIE, dvmCookie);
        RequestAccessContext.RequestAccess requestAccess = new RequestAccessContext.RequestAccess(cookies, new HttpHeaders());
        RequestAccessContext.updateRequestData(requestAccess);
        Mockito.when(featureFlagHelper.isRouterFlagEnabled()).thenReturn(Mono.just(Boolean.TRUE));
    }

    @Test
    public void addDeviceTest() throws IOException {
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);

        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper2.getDeviceId()).thenReturn(Mono.just("1234"));
        when(redisHelper2.getSimId()).thenReturn(Mono.just("1234"));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC"));
         when(dlUtilityService.upsertVZPageSubFLow(anyString(), anyBoolean(), anyString())).thenReturn(Mono.just(Boolean.TRUE));
        doNothing().when(dlUtilityService).updateDlData("eup");
         String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"30004\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"eupNoPromoFlow\":false,\"device\":{\"id\":\"MLA23LL/A\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":true,\"dppMonths\":36,\"productId\":\"dev16720001\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBDSIM5G\"},\"ispuFlow\":false,\"estimatedReadyByDate\":\"\",\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":true,\"selectedSedOfferId\":\"\"}],\"rtm\":{\"url\":\"https://www.verizon.com/smartphones/apple-iphone-13/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-midnight-09142021?fmt=pjpg\",\"name\":\"iPhone 13\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://www.verizon.com/smartphones/apple-iphone-13/\"}}}\t";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1858878952-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryInterestial\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryInterestial\",\"processAction\":\"\",\"cradleFlowJourney\":\"AccessoryInterestialProspectPG\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\"},\"cartInfo\":{\"financeLimitExceeded\":\"true\",\"cartItemCount\":1,\"totalDueToday\":54.25,\"totalDueMonthly\":0.0,\"cartId\":\"a144d317-de87-468e-88ee-a5e223fdf152\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":19.59,\"monthlyInstallment\":19.44,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MLA23LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"699.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 13\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}\n" +
                "\n";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        request.setChannelId("VZ-DOTCOM");
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/add-device");
        HttpCookie targetPricingOffer = new HttpCookie("targetPricingOffer", "true");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("targetPricingOffer", targetPricingOffer);
        bodyMap.add("channelId", new HttpCookie("VZW-DOTCOM", "true"));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.customerProfileDigital(Mockito.anyString()))
                .thenReturn(Mono.just(new CustomerProfileCXPResponse()));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mockito.when(featureFlag.isFeatureEnabled(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyBoolean())).thenReturn(Mono.just(false));
        Mockito.when( featureFlagHelper.fetchD2DFeatureFlag()).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    //Story: ACT180-1011
    @Test
    public void addDeviceTest_isShipToHome() throws IOException {
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);

        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper2.getDeviceId()).thenReturn(Mono.just("1234"));
        when(redisHelper2.getSimId()).thenReturn(Mono.just("1234"));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(), anyBoolean(), anyString())).thenReturn(Mono.just(Boolean.TRUE));
        doNothing().when(dlUtilityService).updateDlData("eup");
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"enableDefaultedShipToHome\":true,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"30004\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"eupNoPromoFlow\":false,\"device\":{\"id\":\"MLA23LL/A\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":true,\"dppMonths\":36,\"productId\":\"dev16720001\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBDSIM5G\"},\"ispuFlow\":false,\"estimatedReadyByDate\":\"\",\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":true,\"selectedSedOfferId\":\"\"}],\"rtm\":{\"url\":\"https://www.verizon.com/smartphones/apple-iphone-13/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-midnight-09142021?fmt=pjpg\",\"name\":\"iPhone 13\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://www.verizon.com/smartphones/apple-iphone-13/\"}}}\t";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1858878952-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryInterestial\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryInterestial\",\"processAction\":\"\",\"cradleFlowJourney\":\"AccessoryInterestialProspectPG\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\"},\"cartInfo\":{\"financeLimitExceeded\":\"true\",\"cartItemCount\":1,\"totalDueToday\":54.25,\"totalDueMonthly\":0.0,\"cartId\":\"a144d317-de87-468e-88ee-a5e223fdf152\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":19.59,\"monthlyInstallment\":19.44,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MLA23LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"699.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 13\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}\n" +
                "\n";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        request.setChannelId("VZ-DOTCOM");
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/add-device");
        HttpCookie targetPricingOffer = new HttpCookie("targetPricingOffer", "true");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("targetPricingOffer", targetPricingOffer);
        bodyMap.add("channelId", new HttpCookie("VZW-DOTCOM", "true"));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.customerProfileDigital(Mockito.anyString()))
                .thenReturn(Mono.just(new CustomerProfileCXPResponse()));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mockito.when(featureFlag.isFeatureEnabled(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyBoolean())).thenReturn(Mono.just(false));
        Mockito.when( featureFlagHelper.fetchD2DFeatureFlag()).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceTest_deleteCacheData() throws IOException {
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);

        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper2.getDeviceId()).thenReturn(Mono.just("1234"));
        when(redisHelper2.getSimId()).thenReturn(Mono.just("1234"));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(), anyBoolean(), anyString())).thenReturn(Mono.just(Boolean.TRUE));
        doNothing().when(dlUtilityService).updateDlData("eup");
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"30004\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"eupNoPromoFlow\":false,\"device\":{\"id\":\"MLA23LL/A\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":true,\"dppMonths\":36,\"productId\":\"dev16720001\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBDSIM5G\"},\"ispuFlow\":false,\"estimatedReadyByDate\":\"\",\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":true,\"selectedSedOfferId\":\"\"}],\"rtm\":{\"url\":\"https://www.verizon.com/smartphones/apple-iphone-13/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-midnight-09142021?fmt=pjpg\",\"name\":\"iPhone 13\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://www.verizon.com/smartphones/apple-iphone-13/\"}}}\t";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1858878952-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryInterestial\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryInterestial\",\"processAction\":\"\",\"cradleFlowJourney\":\"AccessoryInterestialProspectPG\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\"},\"cartInfo\":{\"financeLimitExceeded\":\"true\",\"cartItemCount\":1,\"totalDueToday\":54.25,\"totalDueMonthly\":0.0,\"cartId\":\"a144d317-de87-468e-88ee-a5e223fdf152\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":19.59,\"monthlyInstallment\":19.44,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MLA23LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"699.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 13\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}\n" +
                "\n";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        request.setChannelId("VZ-DOTCOM");
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/add-device");
        HttpCookie targetPricingOffer = new HttpCookie("targetPricingOffer", "true");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("targetPricingOffer", targetPricingOffer);
        bodyMap.add("channelId", new HttpCookie("VZW-DOTCOM", "true"));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.customerProfileDigital(Mockito.anyString()))
                .thenReturn(Mono.just(new CustomerProfileCXPResponse()));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        when(soeLoginSessionBean.deleteSessionData(Mockito.any())).thenReturn(Mono.just(1L));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mockito.when(featureFlag.isFeatureEnabled(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyBoolean())).thenReturn(Mono.just(false));
        Mockito.when( featureFlagHelper.fetchD2DFeatureFlag()).thenReturn(Mono.just(true));
        request.getCartInfo().setMyvPage(true);
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceTestOne() throws IOException {
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);

        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper2.getDeviceId()).thenReturn(Mono.just("1234"));
        when(redisHelper2.getSimId()).thenReturn(Mono.just("1234"));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(), anyBoolean(), anyString())).thenReturn(Mono.just(Boolean.TRUE));
        doNothing().when(dlUtilityService).updateDlData("eup");
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"30004\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"eupNoPromoFlow\":false,\"device\":{\"id\":\"MLA23LL/A\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":true,\"dppMonths\":36,\"productId\":\"dev16720001\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBDSIM5G\"},\"ispuFlow\":false,\"estimatedReadyByDate\":\"\",\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":true,\"selectedSedOfferId\":\"\"}],\"rtm\":{\"url\":\"https://www.verizon.com/smartphones/apple-iphone-13/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-midnight-09142021?fmt=pjpg\",\"name\":\"iPhone 13\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://www.verizon.com/smartphones/apple-iphone-13/\"}}}\t";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1858878952-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryInterestial\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryInterestial\",\"processAction\":\"\",\"cradleFlowJourney\":\"AccessoryInterestialProspectPG\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\"},\"cartInfo\":{\"financeLimitExceeded\":\"true\",\"cartItemCount\":1,\"totalDueToday\":54.25,\"totalDueMonthly\":0.0,\"cartId\":\"a144d317-de87-468e-88ee-a5e223fdf152\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":19.59,\"monthlyInstallment\":19.44,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MLA23LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"699.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 13\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}\n" +
                "\n";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        request.setChannelId("VZ-DOTCOM");
        request.getData().getLines().get(0).setBuyDevSorId("123");
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/add-device");
        HttpCookie targetPricingOffer = new HttpCookie("targetPricingOffer", "true");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("targetPricingOffer", targetPricingOffer);
        bodyMap.add("channelId", new HttpCookie("VZW-DOTCOM", "true"));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.customerProfileDigital(Mockito.anyString()))
                .thenReturn(Mono.just(new CustomerProfileCXPResponse()));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mockito.when(featureFlag.isFeatureEnabled(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyBoolean())).thenReturn(Mono.just(false));
        Mockito.when( featureFlagHelper.fetchD2DFeatureFlag()).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }


    @Test
    public void addDevice_NEXTGEN_Test() throws IOException {
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);

        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper2.getDeviceId()).thenReturn(Mono.just("1234"));
        when(redisHelper2.getSimId()).thenReturn(Mono.just("1234"));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        when(redisHelper2.getEdgeBuyoutDetails()).thenReturn(Mono.just(new HashMap()));
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(), anyBoolean(), anyString())).thenReturn(Mono.just(Boolean.TRUE));
        doNothing().when(dlUtilityService).updateDlData("eup");
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"30004\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"eupNoPromoFlow\":false,\"device\":{\"id\":\"MLA23LL/A\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":true,\"dppMonths\":36,\"productId\":\"dev16720001\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBDSIM5G\"},\"ispuFlow\":false,\"estimatedReadyByDate\":\"\",\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":true,\"selectedSedOfferId\":\"\"}],\"rtm\":{\"url\":\"https://www.verizon.com/smartphones/apple-iphone-13/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-midnight-09142021?fmt=pjpg\",\"name\":\"iPhone 13\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://www.verizon.com/smartphones/apple-iphone-13/\"}}}\t";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1858878952-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryInterestial\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryInterestial\",\"processAction\":\"\",\"cradleFlowJourney\":\"NEXTGEN\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\"},\"cartInfo\":{\"financeLimitExceeded\":\"true\",\"cartItemCount\":1,\"totalDueToday\":54.25,\"totalDueMonthly\":0.0,\"cartId\":\"a144d317-de87-468e-88ee-a5e223fdf152\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":19.59,\"monthlyInstallment\":19.44,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MLA23LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"699.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 13\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}\n" +
                "\n";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        request.setChannelId("VZ-DOTCOM");
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/add-device");
        HttpCookie targetPricingOffer = new HttpCookie("targetPricingOffer", "true");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("targetPricingOffer", targetPricingOffer);
        bodyMap.add("channelId", new HttpCookie("VZW-DOTCOM", "true"));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.customerProfileDigital(Mockito.anyString()))
                .thenReturn(Mono.just(new CustomerProfileCXPResponse()));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mockito.when(featureFlag.isFeatureEnabled(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyBoolean())).thenReturn(Mono.just(false));
        Mockito.when( featureFlagHelper.fetchD2DFeatureFlag()).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(
                        resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addAccessoryNSETest() throws IOException {
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"editAccessory\":false,\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"9999999999\",\"processStep\":\"AccessoryPDP\",\"processAction\":\"addAccessory\",\"intendType\":\"NSEACC\",\"intent\":\"StandAloneAccessory\",\"expressflowForAcc\":false,\"expressCheckout\":false,\"disableMyLink\":false,\"mtnFlow\":\"D\",\"globalId\":\"\",\"customerType\":\"N\",\"zipCode\":\"30004\"},\"data\":{\"depletionType\":\"F\",\"lines\":[{\"mtn\":\"9999999999\",\"mdnFilterValue\":\"9999999999\",\"ispuFlow\":false,\"estimatedReadyByDate\":\"\",\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"preBackOrderDate\":\"\",\"preBackOrderDisplayType\":\"\",\"addAccessories\":[{\"giftCard\":false,\"id\":\"77-88673\",\"qty\":1,\"isSoftSku\":false,\"accessoryBundle\":false,\"productId\":\"acc19040401\",\"category\":\"Bundle Eligible Cases\",\"isEcpdDiscountEligilble\":false}]}],\"rtm\":{\"url\":\"https://vzwqa1.verizonwireless.com/products/otterbox-defender-series-pro-case-for-iphone-14-plus/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/otterbox-defender-series-pro-case-for-skye-black-77-88673-iset\",\"name\":\"Defender Series Pro Case for iPhone 14 Plus\",\"make\":\"OtterBox\",\"categoryId\":\"Bundle Eligible Cases\",\"pageURL\":\"https://vzwqa1.verizonwireless.com/products/otterbox-defender-series-pro-case-for-iphone-14-plus/\",\"acc_url\":\"https://vzwqa1.verizonwireless.com/products/otterbox-defender-series-pro-case-for-iphone-14-plus/\",\"acc_img\":\"https://ss7.vzw.com/is/image/VerizonWireless/otterbox-defender-series-pro-case-for-skye-black-77-88673-iset\",\"acc_categoryId\":\"Bundle Eligible Cases\"}}}\n" +
                "\t\n";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM-MOB\",\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"0\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.11.06.04.09-330.03973370036346\"},\"serviceBody\":{\"serviceRequest\":{\"context\":{\"caseId\":\"SOP-149172347805-E01\",\"contextInfo\":{\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Accessories\",\"processAction\":\"addAccessory\",\"intent\":\"NSE_5G\"},\"customerInfo\":{\"throttleName\":\"|\",\"bucketAllocator\":\"BAU\",\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-M-37118f14-86cd-41c6-912e-2493dfbe5e97\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"pageId\":\"PROTECTION\",\"deviceId\":\"\",\"globalId\":\"POE-M-37118f14-86cd-41c6-912e-2493dfbe5e97\"},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"74558388-63d2-4838-a6ec-f9299263f590\",\"itemType\":\"ACCESSORY\",\"intendType\":\"NSE_5G\",\"action\":\"UPDATE\",\"lines\":[{\"accessories\":{\"add\":[{\"qty\":\"1\",\"isSoftSku\":false,\"accountLevelAccessory\":false,\"scannedItem\":false,\"cashOptionEnabled\":false,\"id\":\"ASK-STI6220\"}]},\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"ispuFlow\":false,\"depletionType\":\"F\",\"depletionLocationCode\":\"\",\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false,\"fmiCheck\":false}}}}}\t";
        AddAccessoriesUIRequest request = mapper.readValue(requestString, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(responseString, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/cart/nse/5g/add-accessories");
        HttpCookie digital_ig_session = new HttpCookie("digital_ig_session", "11b5e062-c453");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("digital_ig_session", digital_ig_session);
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("digital_ig_session", "digital_1").header("flowName", "NSE_5G").header("channelId", "VZW-DOTCOM").cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        Map<String, Object> redisMtnMap = new HashMap<>();
        when(cartAccessoryLoggingHelper.logAccessoryInkibana(Mockito.any())).thenReturn(Mono.just(new Object()));
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(fiveGhomeCommonHelper.isFWAFlow(Mockito.any())).thenReturn(true);
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(true);
        Mockito.when(featureFlag.isFeatureEnabled(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyBoolean())).thenReturn(Mono.just(false));
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        Mockito.when( featureFlagHelper.fetchD2DFeatureFlag()).thenReturn(Mono.just(true));
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put("cartCount","1");
        redisData.put("cartOrderFlowType","eup");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> org.junit.Assert.assertNotNull(resp)).expectComplete().verify();

        response.getServiceBody().getServiceRequest().getContext().getContextInfo().setProcessStep("AccessoryInterestial");
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        StepVerifier.create(cartController3.addAccessory(httpRequest, httpResponse, request)).assertNext(resp -> org.junit.Assert.assertNotNull(resp)).expectComplete().verify();
    }

    @Test
    public void addDevicePreToPostMigrationFlowTest() throws IOException {
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);
        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper2.getDeviceId()).thenReturn(Mono.just("1234"));
        when(redisHelper2.getSimId()).thenReturn(Mono.just("1234"));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(), anyBoolean(), anyString())).thenReturn(Mono.just(Boolean.TRUE));
        doNothing().when(dlUtilityService).updateDlData("eup");
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"30004\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"eupNoPromoFlow\":false,\"device\":{\"id\":\"MLA23LL/A\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":true,\"dppMonths\":36,\"productId\":\"dev16720001\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBDSIM5G\"},\"ispuFlow\":false,\"estimatedReadyByDate\":\"\",\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":true,\"selectedSedOfferId\":\"\"}],\"prepaidMtn\":\"4098989898\",\"rtm\":{\"url\":\"https://www.verizon.com/smartphones/apple-iphone-13/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-midnight-09142021?fmt=pjpg\",\"name\":\"iPhone 13\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://www.verizon.com/smartphones/apple-iphone-13/\"}}}\t";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1858878952-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryInterestial\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryInterestial\",\"processAction\":\"\",\"cradleFlowJourney\":\"AccessoryInterestialProspectPG\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\"},\"cartInfo\":{\"financeLimitExceeded\":\"true\",\"cartItemCount\":1,\"totalDueToday\":54.25,\"totalDueMonthly\":0.0,\"cartId\":\"a144d317-de87-468e-88ee-a5e223fdf152\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":19.59,\"monthlyInstallment\":19.44,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MLA23LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"699.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 13\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}\n" +
                "\n";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        request.setChannelId("VZ-DOTCOM");
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/nse/add-device");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("channelId", new HttpCookie("VZW-DOTCOM", "true"));
        bodyMap.add("preToPostMigrationFlow", new HttpCookie("preToPostMigrationFlow", "true"));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.customerProfileDigital(Mockito.anyString()))
                .thenReturn(Mono.just(new CustomerProfileCXPResponse()));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mockito.when(featureFlag.isFeatureEnabled(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyBoolean())).thenReturn(Mono.just(false));
        Mockito.when( featureFlagHelper.fetchD2DFeatureFlag()).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDeviceTestAIQuote() throws IOException {
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);

        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper2.getDeviceId()).thenReturn(Mono.just("1234"));
        when(redisHelper2.getSimId()).thenReturn(Mono.just("1234"));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(), anyBoolean(), anyString())).thenReturn(Mono.just(Boolean.TRUE));
        doNothing().when(dlUtilityService).updateDlData("eup");

        File file = null;
        file = ResourceUtils.getFile("classpath:data/mockedPegaRequest.json");
        String requestString = null;
        requestString = new String(Files.readAllBytes(file.toPath()));

        file = ResourceUtils.getFile("classpath:data/mockedPegaResponse.json");
        String responseString = null;
        responseString = new String(Files.readAllBytes(file.toPath()));


        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        request.setChannelId("OMNI-RETAIL");
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/add-device");
        HttpCookie targetPricingOffer = new HttpCookie("targetPricingOffer", "true");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("targetPricingOffer", targetPricingOffer);
        bodyMap.add("channelId", new HttpCookie("OMNI-RETAIL", "true"));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.customerProfileDigital(Mockito.anyString()))
                .thenReturn(Mono.just(new CustomerProfileCXPResponse()));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mockito.when(featureFlag.isFeatureEnabled(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyBoolean())).thenReturn(Mono.just(false));
        Mockito.when( featureFlagHelper.fetchD2DFeatureFlag()).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDevice_BYOD_Test() throws IOException {
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);

        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        DeviceImeiSimDetails deviceImeiSimDetails = new DeviceImeiSimDetails();
        deviceImeiSimDetails.setIccid("00000");
        deviceImeiSimDetails.setImei2("1234");
        deviceImeiSimDetails.setImei1("5678");
        deviceImeiSimDetails.setEID("9087645");
        cartRedisData.setDeviceImeiSimDetails(deviceImeiSimDetails);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        when(redisHelper2.getEdgeBuyoutDetails()).thenReturn(Mono.just(new HashMap()));
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(), anyBoolean(), anyString())).thenReturn(Mono.just(Boolean.TRUE));
        doNothing().when(dlUtilityService).updateDlData("eup");
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"BYODSimIDPage\",\"processAction\":\"addDeviceSim\",\"intendType\":\"NSEBYOD\",\"zipCode\":\"\",\"addressLine1\":\"\",\"city\":\"\",\"state\":\"\"},\"data\":{\"subFlow\":\"\",\"imeiFromSession\":true,\"lines\":[{\"mtn\":\"newLine1\",\"device\":{\"id\":\"MLAE3LL/A-2\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"\",\"contractTerm\":\"MONTH_TO_MONTH\",\"deviceId\":\"\",\"smartIMEI\":false,\"category\":\"Smartphone\",\"rawCategory\":\"5G Smartphone\",\"prodType\":\"5GSmartphone\",\"byodESimPhone\":true},\"sim\":{\"id\":\"SOFTSIM5G-SA-D\",\"isCustomerProvidedSIM\":false,\"iccid\":\"\",\"eSIM\":\"\"},\"isNewLine\":true,\"ispuFlow\":false,\"depletionType\":\"F\",\"depletionLocationCode\":\"\",\"isKeepingExistingEqProtection\":true}],\"enableFcc\":true}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1858878952-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryInterestial\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryInterestial\",\"processAction\":\"\",\"cradleFlowJourney\":\"NEXTGEN\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\"},\"cartInfo\":{\"financeLimitExceeded\":\"true\",\"cartItemCount\":1,\"totalDueToday\":54.25,\"totalDueMonthly\":0.0,\"cartId\":\"a144d317-de87-468e-88ee-a5e223fdf152\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":19.59,\"monthlyInstallment\":19.44,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MLA23LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"699.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 13\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}\n" +
                "\n";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        request.setChannelId("VZW-DOTCOM");
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/add-device");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("channelId", new HttpCookie("VZW-DOTCOM", "true"));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.customerProfileDigital(Mockito.anyString()))
                .thenReturn(Mono.just(new CustomerProfileCXPResponse()));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mockito.when(featureFlag.isFeatureEnabled(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyBoolean())).thenReturn(Mono.just(false));
        Mockito.when( featureFlagHelper.fetchD2DFeatureFlag()).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(
                        resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        request.getCartInfo().setIntendType(null);
        controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(
                        resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }

    @Test
    public void addDevice_DVM_Test() throws IOException {
        RequestAccessContext.RequestAccess requestAccess = new RequestAccessContext.RequestAccess();
        requestAccess.getCookies().add(CartConstants.DVM_CONVERSION_FLAG, new HttpCookie("dvmConversion", "true"));
        requestAccess.getHeaders().add("comvzid", "true");
        RequestAccessContext.updateRequestData(requestAccess);
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);

        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        DeviceImeiSimDetails deviceImeiSimDetails = new DeviceImeiSimDetails();
        deviceImeiSimDetails.setIccid("00000");
        deviceImeiSimDetails.setImei2("1234");
        deviceImeiSimDetails.setImei1("5678");
        deviceImeiSimDetails.setEID("9087645");
        cartRedisData.setDeviceImeiSimDetails(deviceImeiSimDetails);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        when(redisHelper2.getEdgeBuyoutDetails()).thenReturn(Mono.just(new HashMap()));
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC"));
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("dvmConversion", new HttpCookie("dvmConversion", "true"));
        bodyMap.add("channelId", new HttpCookie("VZW-DOTCOM", "true"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(), anyBoolean(), anyString())).thenReturn(Mono.just(Boolean.TRUE));
        doNothing().when(dlUtilityService).updateDlData("DVM");
        String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-ECOM\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"BYODSimIDPage\",\"processAction\":\"addDeviceSim\",\"intendType\":\"NSEBYOD\",\"zipCode\":\"\",\"addressLine1\":\"\",\"city\":\"\",\"state\":\"\"},\"data\":{\"subFlow\":\"\",\"imeiFromSession\":true,\"lines\":[{\"mtn\":\"newLine1\",\"device\":{\"id\":\"MLAE3LL/A-2\",\"Flowtype\":\"DEVICE\",\"CurrentId\":\"\",\"contractTerm\":\"MONTH_TO_MONTH\",\"deviceId\":\"\",\"smartIMEI\":false,\"category\":\"Smartphone\",\"rawCategory\":\"5G Smartphone\",\"prodType\":\"5GSmartphone\",\"byodESimPhone\":true},\"sim\":{\"id\":\"SOFTSIM5G-SA-D\",\"isCustomerProvidedSIM\":false,\"iccid\":\"\",\"eSIM\":\"\"},\"isNewLine\":true,\"ispuFlow\":false,\"depletionType\":\"F\",\"depletionLocationCode\":\"\",\"isKeepingExistingEqProtection\":true}],\"enableFcc\":true}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1858878952-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryInterestial\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryInterestial\",\"processAction\":\"\",\"cradleFlowJourney\":\"NEXTGEN\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\"},\"cartInfo\":{\"financeLimitExceeded\":\"true\",\"cartItemCount\":1,\"totalDueToday\":54.25,\"totalDueMonthly\":0.0,\"cartId\":\"a144d317-de87-468e-88ee-a5e223fdf152\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":19.59,\"monthlyInstallment\":19.44,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MLA23LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"699.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 13\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}\n" +
                "\n";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        request.setChannelId("VZW-DOTCOM");
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/add-device");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("comvzid", "123456").cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.customerProfileDigital(Mockito.anyString()))
                .thenReturn(Mono.just(new CustomerProfileCXPResponse()));
        when(devHelper.addDevice(any(),any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mockito.when(featureFlag.isFeatureEnabled(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyBoolean())).thenReturn(Mono.just(false));
        Mockito.when( featureFlagHelper.fetchD2DFeatureFlag()).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(
                        resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
//        MockServerHttpRequest httpHeader1 = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-DOTCOM").cookies(bodyMap).build();
//        Mono<ResponseEntity<GenericResponse>> controllerResponse1 = cartController3.addDevice(httpHeader1, httpResponse,
//                request);
//        StepVerifier.create(controllerResponse1).assertNext(
//                resp -> Assert.assertNotNull(resp)).expectComplete()
//                .verify();
//        MockServerHttpRequest httpHeader2 = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-DOTCOM").header("comvzid", "").cookies(bodyMap).build();
//        Mono<ResponseEntity<GenericResponse>> controllerResponse2 = cartController3.addDevice(httpHeader2, httpResponse,
//                request);
//        StepVerifier.create(controllerResponse2).assertNext(
//                resp -> Assert.assertNotNull(resp)).expectComplete()
//                .verify();
    }

    @Test
    public void createLine_DVM_Test() throws IOException {
        RequestAccessContext.RequestAccess requestAccess = new RequestAccessContext.RequestAccess();
        requestAccess.getCookies().add(CartConstants.DVM_CONVERSION_FLAG, new HttpCookie("dvmConversion", "true"));
        requestAccess.getHeaders().add("comvzid", "true");
        RequestAccessContext.updateRequestData(requestAccess);
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        line.setTanglewoodSelected("Y");
        line.setLine("New Line 1");
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);

        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        DeviceImeiSimDetails deviceImeiSimDetails = new DeviceImeiSimDetails();
        deviceImeiSimDetails.setIccid("00000");
        deviceImeiSimDetails.setImei2("1234");
        deviceImeiSimDetails.setImei1("5678");
        deviceImeiSimDetails.setEID("9087645");
        cartRedisData.setDeviceImeiSimDetails(deviceImeiSimDetails);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        when(redisHelper2.getEdgeBuyoutDetails()).thenReturn(Mono.just(new HashMap()));
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC"));
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("dvmConversion", new HttpCookie("dvmConversion", "true"));
        bodyMap.add("channelId", new HttpCookie("VZW-DOTCOM", "true"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(), anyBoolean(), anyString())).thenReturn(Mono.just(Boolean.TRUE));
        doNothing().when(dlUtilityService).updateDlData("DVM");
        String requestString = "{\"cartInfo\":{\"processStep\":\"LineSelection\",\"intendType\":\"NSE\",\"mtnFlow\":\"P\",\"customerType\":\"N\",\"cartCreatorSalesRepId\":\"ENC\",\"cartCreatorOrderLocationCode\":\"D463801\"},\"data\":{\"zipCode\":\"07920\",\"numOfLines\":1,\"lines\":[{\"mtn\":\"\",\"line\":\"New Line 1\",\"tanglewoodSelected\":\"Y\",\"deviceTypeSelected\":\"\"}]}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.05.13.14.11.06-127.06731644231873\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-7242794-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"PlanSelection\"}]},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-2f3f50b1-3c2f-46ab-9e22-88d793741519\",\"processingMTN\":\"\",\"registerNumber\":0,\"mtnFlow\":\"D\",\"globalId\":\"POE-D-2f3f50b1-3c2f-46ab-9e22-88d793741519\"},\"cartInfo\":{\"financeLimitExceeded\":\"false\",\"lineNumbers\":[\"newLine1\"],\"cartItemCount\":0,\"cartId\":\"bcbfe931-c214-42e1-b240-70bb8961593a\",\"statusMsg\":\"Lines created successfully\",\"userId\":\"\",\"mtn\":\"newLine1\",\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"zipCode\":\"\",\"ecpdProfileId\":\"\",\"protectionNotRequired\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}],\"homeSalesAddress\":{}}}}}";
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLineUIResponse response = mapper.readValue(responseString, CreateLineUIResponse.class);
        request.setChannelId("VZW-DOTCOM");
        URI url = URI.create("http://localhost/add-device");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("comvzid", "123456").cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.createLine(any())).thenReturn(Mono.just(response));
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));
        Mockito.when(featureFlag.isFeatureEnabled(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyBoolean())).thenReturn(Mono.just(false));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.createLine(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(
                        resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
//        MockServerHttpRequest httpHeader1 = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-DOTCOM").cookies(bodyMap).build();
//        Mono<ResponseEntity<GenericResponse>> controllerResponse1 = cartController3.addDevice(httpHeader1, httpResponse,
//                request);
//        StepVerifier.create(controllerResponse1).assertNext(
//                resp -> Assert.assertNotNull(resp)).expectComplete()
//                .verify();
//        MockServerHttpRequest httpHeader2 = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-DOTCOM").header("comvzid", "").cookies(bodyMap).build();
//        Mono<ResponseEntity<GenericResponse>> controllerResponse2 = cartController3.addDevice(httpHeader2, httpResponse,
//                request);
//        StepVerifier.create(controllerResponse2).assertNext(
//                resp -> Assert.assertNotNull(resp)).expectComplete()
//                .verify();
    }
    @Test
    public void createLine_acNextGenCookie() throws IOException {
        RequestAccessContext.RequestAccess requestAccess = new RequestAccessContext.RequestAccess();
        requestAccess.getCookies().add(CartConstants.DVM_CONVERSION_FLAG, new HttpCookie("dvmConversion", "true"));
        requestAccess.getHeaders().add("comvzid", "true");
        RequestAccessContext.updateRequestData(requestAccess);
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        line.setTanglewoodSelected("Y");
        line.setLine("New Line 1");
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);

        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        DeviceImeiSimDetails deviceImeiSimDetails = new DeviceImeiSimDetails();
        deviceImeiSimDetails.setIccid("00000");
        deviceImeiSimDetails.setImei2("1234");
        deviceImeiSimDetails.setImei1("5678");
        deviceImeiSimDetails.setEID("9087645");
        cartRedisData.setDeviceImeiSimDetails(deviceImeiSimDetails);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        when(redisHelper2.getEdgeBuyoutDetails()).thenReturn(Mono.just(new HashMap()));
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC"));
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("dvmConversion", new HttpCookie("dvmConversion", "true"));
        bodyMap.add("channelId", new HttpCookie("VZW-DOTCOM", "true"));
        bodyMap.add("uuid", new HttpCookie("UUID", "123"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(), anyBoolean(), anyString())).thenReturn(Mono.just(Boolean.TRUE));
        doNothing().when(dlUtilityService).updateDlData("DVM");
        String requestString = "{\"cartInfo\":{\"processStep\":\"LineSelection\",\"intendType\":\"NSE\",\"mtnFlow\":\"P\",\"customerType\":\"N\",\"cartCreatorSalesRepId\":\"ENC\",\"cartCreatorOrderLocationCode\":\"D463801\"},\"data\":{\"zipCode\":\"07920\",\"numOfLines\":1,\"lines\":[{\"mtn\":\"\",\"line\":\"New Line 1\",\"tanglewoodSelected\":\"Y\",\"deviceTypeSelected\":\"\"}]}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.05.13.14.11.06-127.06731644231873\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-7242794-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"PlanSelection\"}]},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-2f3f50b1-3c2f-46ab-9e22-88d793741519\",\"processingMTN\":\"\",\"registerNumber\":0,\"mtnFlow\":\"D\",\"globalId\":\"POE-D-2f3f50b1-3c2f-46ab-9e22-88d793741519\"},\"cartInfo\":{\"financeLimitExceeded\":\"false\",\"lineNumbers\":[\"newLine1\"],\"cartItemCount\":0,\"cartId\":\"bcbfe931-c214-42e1-b240-70bb8961593a\",\"statusMsg\":\"Lines created successfully\",\"userId\":\"\",\"mtn\":\"newLine1\",\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"zipCode\":\"\",\"ecpdProfileId\":\"\",\"protectionNotRequired\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}],\"homeSalesAddress\":{}}}}}";
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLineUIResponse response = mapper.readValue(responseString, CreateLineUIResponse.class);
        request.setChannelId("VZW-DOTCOM");
        URI url = URI.create("http://localhost/add-device");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-MFA").header("comvzid", "123456").cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.createLine(any())).thenReturn(Mono.just(response));
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(false));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));
        Mockito.when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART, FeatureFlagConstants.FLAG_NAME_CART_OPERATION_WITH_UUID, true)).thenReturn(Mono.just(true));
        Mockito.when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART, FeatureFlagConstants.FLAG_NAME_SET_ACNEXTGEN_FOR_MVA, false)).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.createLine(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(
                        resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();

        request = mapper.readValue(requestString, CreateLineUIRequest.class);
        response = mapper.readValue(responseString, CreateLineUIResponse.class);
        when(cartHelper.createLine(any())).thenReturn(Mono.just(response));
        Mockito.when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART, FeatureFlagConstants.FLAG_NAME_CART_OPERATION_WITH_UUID, true)).thenReturn(Mono.just(false));
        controllerResponse = cartController3.createLine(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();

        request = mapper.readValue(requestString, CreateLineUIRequest.class);
        response = mapper.readValue(responseString, CreateLineUIResponse.class);
        when(cartHelper.createLine(any())).thenReturn(Mono.just(response));
        Mockito.when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART, FeatureFlagConstants.FLAG_NAME_CART_OPERATION_WITH_UUID, true)).thenReturn(Mono.just(true));
        Mockito.when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART, FeatureFlagConstants.FLAG_NAME_SET_ACNEXTGEN_FOR_MVA, false)).thenReturn(Mono.just(false));
        controllerResponse = cartController3.createLine(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();

        request = mapper.readValue(requestString, CreateLineUIRequest.class);
        response = mapper.readValue(responseString, CreateLineUIResponse.class);
        when(cartHelper.createLine(any())).thenReturn(Mono.just(response));
        Mockito.when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART, FeatureFlagConstants.FLAG_NAME_SET_ACNEXTGEN_FOR_MVA, false)).thenReturn(Mono.just(true));
        httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").header("comvzid", "123456").cookies(bodyMap).build();
        controllerResponse = cartController3.createLine(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();

        request = mapper.readValue(requestString, CreateLineUIRequest.class);
        response = mapper.readValue(responseString, CreateLineUIResponse.class);
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(true));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(cartHelper.createLine(any())).thenReturn(Mono.just(response));
       // when(CartUtil.generateExpireDate("MM/dd/yyyyTHH:mm",3000)).thenReturn(null);
        httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-MFA").header("comvzid", "123456").build();
        controllerResponse = cartController3.createLine(httpHeader, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }
    @Test
    public void createLine_acNextGenCookie1() throws IOException {
        RequestAccessContext.RequestAccess requestAccess = new RequestAccessContext.RequestAccess();
        requestAccess.getCookies().add(CartConstants.DVM_CONVERSION_FLAG, new HttpCookie("dvmConversion", "true"));
        requestAccess.getHeaders().add("comvzid", "true");
        RequestAccessContext.updateRequestData(requestAccess);
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        line.setTanglewoodSelected("Y");
        line.setLine("New Line 1");
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);

        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        DeviceImeiSimDetails deviceImeiSimDetails = new DeviceImeiSimDetails();
        deviceImeiSimDetails.setIccid("00000");
        deviceImeiSimDetails.setImei2("1234");
        deviceImeiSimDetails.setImei1("5678");
        deviceImeiSimDetails.setEID("9087645");
        cartRedisData.setDeviceImeiSimDetails(deviceImeiSimDetails);
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        when(redisHelper2.getEdgeBuyoutDetails()).thenReturn(Mono.just(new HashMap()));
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC"));
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("dvmConversion", new HttpCookie("dvmConversion", "true"));
        bodyMap.add("channelId", new HttpCookie("VZW-DOTCOM", "true"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(), anyBoolean(), anyString())).thenReturn(Mono.just(Boolean.TRUE));
        doNothing().when(dlUtilityService).updateDlData("DVM");
        String requestString = "{\"cartInfo\":{\"processStep\":\"LineSelection\",\"intendType\":\"NSE\",\"mtnFlow\":\"P\",\"customerType\":\"N\",\"cartCreatorSalesRepId\":\"ENC\",\"cartCreatorOrderLocationCode\":\"D463801\"},\"data\":{\"zipCode\":\"07920\",\"numOfLines\":1,\"lines\":[{\"mtn\":\"\",\"line\":\"New Line 1\",\"tanglewoodSelected\":\"Y\",\"deviceTypeSelected\":\"\"}]}}";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.05.13.14.11.06-127.06731644231873\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-7242794-E01\",\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"PlanSelection\",\"processAction\":\"\",\"availablePaths\":[{\"path\":\"PlanSelection\"}]},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-2f3f50b1-3c2f-46ab-9e22-88d793741519\",\"processingMTN\":\"\",\"registerNumber\":0,\"mtnFlow\":\"D\",\"globalId\":\"POE-D-2f3f50b1-3c2f-46ab-9e22-88d793741519\"},\"cartInfo\":{\"financeLimitExceeded\":\"false\",\"lineNumbers\":[\"newLine1\"],\"cartItemCount\":0,\"cartId\":\"bcbfe931-c214-42e1-b240-70bb8961593a\",\"statusMsg\":\"Lines created successfully\",\"userId\":\"\",\"mtn\":\"newLine1\",\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"zipCode\":\"\",\"ecpdProfileId\":\"\",\"protectionNotRequired\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}],\"homeSalesAddress\":{}}}}}";
        CreateLineUIRequest request = mapper.readValue(requestString, CreateLineUIRequest.class);
        CreateLineUIResponse response = mapper.readValue(responseString, CreateLineUIResponse.class);
        request.setChannelId("VZW-DOTCOM");
        URI url = URI.create("http://localhost/add-device");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-MFA").header("comvzid", "123456").cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.createLine(any())).thenReturn(Mono.just(response));
        when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(false));
        when(omniDLHelper.setFlow(Mockito.any(),Mockito.any())).thenReturn(Mono.just("AAL"));
        when(redisHelper.updateCartIdAndCaseIdIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));
        Mockito.when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART, FeatureFlagConstants.FLAG_NAME_CART_OPERATION_WITH_UUID, true)).thenReturn(Mono.just(true));
        Mockito.when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART, FeatureFlagConstants.FLAG_NAME_SET_ACNEXTGEN_FOR_MVA, false)).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.createLine(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(
                        resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
    }
    @Test
    public void addDeviceTestCookie() throws IOException {
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);

        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper2.getDeviceId()).thenReturn(Mono.just("1234"));
        when(redisHelper2.getSimId()).thenReturn(Mono.just("1234"));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(), anyBoolean(), anyString())).thenReturn(Mono.just(Boolean.TRUE));
        doNothing().when(dlUtilityService).updateDlData("eup");
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"30004\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"eupNoPromoFlow\":false,\"device\":{\"id\":\"MLA23LL/A\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":true,\"dppMonths\":36,\"productId\":\"dev16720001\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBDSIM5G\"},\"ispuFlow\":false,\"estimatedReadyByDate\":\"\",\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":true,\"selectedSedOfferId\":\"\"}],\"rtm\":{\"url\":\"https://www.verizon.com/smartphones/apple-iphone-13/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-midnight-09142021?fmt=pjpg\",\"name\":\"iPhone 13\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://www.verizon.com/smartphones/apple-iphone-13/\"}}}\t";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1858878952-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryInterestial\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryInterestial\",\"processAction\":\"\",\"cradleFlowJourney\":\"AccessoryInterestialProspectPG\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\"},\"cartInfo\":{\"financeLimitExceeded\":\"true\",\"cartItemCount\":1,\"totalDueToday\":54.25,\"totalDueMonthly\":0.0,\"cartId\":\"a144d317-de87-468e-88ee-a5e223fdf152\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":19.59,\"monthlyInstallment\":19.44,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MLA23LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"699.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 13\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}\n" +
                "\n";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        request.setChannelId("VZ-DOTCOM");
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/add-device");
        HttpCookie targetPricingOffer = new HttpCookie("targetPricingOffer", "true");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("targetPricingOffer", targetPricingOffer);
        bodyMap.add("channelId", new HttpCookie("VZW-DOTCOM", "true"));
        bodyMap.add("uuid", new HttpCookie("UUID", "123"));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-MFA").cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.customerProfileDigital(Mockito.anyString()))
                .thenReturn(Mono.just(new CustomerProfileCXPResponse()));
        when(devHelper.addDevice(any(), any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mockito.when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART, FeatureFlagConstants.FLAG_NAME_CART_OPERATION_WITH_UUID, true)).thenReturn(Mono.just(true));
        Mockito.when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART, FeatureFlagConstants.FLAG_NAME_SET_ACNEXTGEN_FOR_MVA, false)).thenReturn(Mono.just(true));
        Mockito.when( featureFlagHelper.fetchD2DFeatureFlag()).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();

        request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        when(devHelper.addDevice(any(), any())).thenReturn(Mono.just(response));
        Mockito.when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART, FeatureFlagConstants.FLAG_NAME_CART_OPERATION_WITH_UUID, true)).thenReturn(Mono.just(false));
        controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();

        request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        when(devHelper.addDevice(any(), any())).thenReturn(Mono.just(response));
        httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-MFA").cookies(bodyMap).build();
        Mockito.when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART, FeatureFlagConstants.FLAG_NAME_CART_OPERATION_WITH_UUID, true)).thenReturn(Mono.just(true));
        Mockito.when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART, FeatureFlagConstants.FLAG_NAME_SET_ACNEXTGEN_FOR_MVA, false)).thenReturn(Mono.just(false));
        controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();


        request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        when(devHelper.addDevice(any(), any())).thenReturn(Mono.just(response));
        Mockito.when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART, FeatureFlagConstants.FLAG_NAME_SET_ACNEXTGEN_FOR_MVA, false)).thenReturn(Mono.just(true));
        httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookies(bodyMap).build();
        controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();


        request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        when(devHelper.addDevice(any(), any())).thenReturn(Mono.just(response));
        httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-MFA").build();
        controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();

    }

//        request = mapper.readValue(requestString, AddDeviceUIRequest.class);
//        response = mapper.readValue(responseString, AddDeviceUIResponse.class);
//        when(devHelper.addDevice(any(), any())).thenReturn(Mono.just(response));
//        httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-MFA").cookies(bodyMap).build();
//        controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
//                request);
//        request.setHttpRequest(null);
//        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
//

    @Test
    public void addDeviceTestCookie1() throws IOException {
        CartRedisData cartRedisData = new CartRedisData();
        Lines line = new Lines();
        line.setMtn("");
        line.setIsEdgeBuyOut(false);
        List<Lines> linesList = new ArrayList<>();
        linesList.add(line);

        cartRedisData.setCartId("");
        cartRedisData.setCaseId("");
        cartRedisData.setLines(linesList);
        cartRedisData.setLocationCode("abcd1234");
        when(redisHelper.getDataFromRedisAsString()).thenReturn(Mono.just(cartRedisData));
        when(redisHelper2.getDeviceId()).thenReturn(Mono.just("1234"));
        when(redisHelper2.getSimId()).thenReturn(Mono.just("1234"));
        when(redisHelper.updateDataIntoRedisAsString(any(), any())).thenReturn(Mono.just(true));
        when(dlUtilityService.getSubFlowVal()).thenReturn(Mono.just("NOVA|USC"));
        when(dlUtilityService.upsertVZPageSubFLow(anyString(), anyBoolean(), anyString())).thenReturn(Mono.just(Boolean.TRUE));
        doNothing().when(dlUtilityService).updateDlData("eup");
        String requestString = "{\"cartInfo\":{\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"GridWallPDP\",\"processAction\":\"addDevice\",\"intendType\":\"NSE\",\"isTradeInSelected\":false,\"disableMyLink\":false,\"editDevice\":false,\"expressCheckout\":null,\"mtnFlow\":\"D\",\"customerType\":\"N\",\"zipCode\":\"30004\"},\"data\":{\"lines\":[{\"mtn\":\"\",\"purchasePath\":\"NSE\",\"eupNoPromoFlow\":false,\"device\":{\"id\":\"MLA23LL/A\",\"contractTerm\":\"VERIZON_EDGE\",\"iconicPhone\":true,\"dppMonths\":36,\"productId\":\"dev16720001\",\"category\":\"Smartphones\",\"preconfigure\":false},\"sim\":{\"id\":\"EMBDSIM5G\"},\"ispuFlow\":false,\"estimatedReadyByDate\":\"\",\"depletionLocationCode\":\"\",\"depletionType\":\"F\",\"isKeepingExistingEqProtection\":true,\"isNewLine\":false,\"selectedPromoId\":\"\",\"selectedPromoType\":\"NOPROMO\",\"promoRejectionIndicator\":true,\"isIconicPhone\":true,\"selectedSedOfferId\":\"\"}],\"rtm\":{\"url\":\"https://www.verizon.com/smartphones/apple-iphone-13/\",\"img\":\"https://ss7.vzw.com/is/image/VerizonWireless/apple-iphone-13-midnight-09142021?fmt=pjpg\",\"name\":\"iPhone 13\",\"make\":\"Apple\",\"categoryId\":\"Smartphones\",\"pageURL\":\"https://www.verizon.com/smartphones/apple-iphone-13/\"}}}\t";
        String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2023.02.03.07.48.51-596.1844856406657\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-1858878952-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"AccessoryInterestial\"}],\"skipCheckoutCall\":false,\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"AccessoryInterestial\",\"processAction\":\"\",\"cradleFlowJourney\":\"AccessoryInterestialProspectPG\"},\"customerInfo\":{\"customerType\":\"N\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\",\"processingMTN\":\"\",\"registerNumber\":0,\"globalId\":\"POE-D-cc2cd1e7-8cbd-49cc-a896-b9a38cceed7f\"},\"cartInfo\":{\"financeLimitExceeded\":\"true\",\"cartItemCount\":1,\"totalDueToday\":54.25,\"totalDueMonthly\":0.0,\"cartId\":\"a144d317-de87-468e-88ee-a5e223fdf152\",\"statusMsg\":\"Success\",\"statusCode\":\"1\",\"lines\":[{\"plan\":{\"isRecommendedPlan\":false,\"isGCPromoAvailable\":false},\"status\":1,\"firstMonthInstallment\":19.59,\"monthlyInstallment\":19.44,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"selectedPromoType\":\"NOPROMO\",\"eupNoPromoFlow\":false,\"mtn\":\"newLine1\",\"device\":{\"upgradeReasonCode\":\"\",\"id\":\"MLA23LL/A\",\"installmentTerm\":\"0\",\"itemPrice\":\"699.99\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"iPhone 13\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false,\"skipImei1Call\":false,\"amount\":0.0},\"sim\":{\"id\":\"EMBDSIM5G\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":false,\"planValidationFailed\":false,\"lineActivityType\":\"NSE\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"fiveGPlanAdded\":false,\"editSim\":false,\"lineWithSkipMDN\":false,\"inWithVerizonOpted\":false,\"protectionNotRequired\":false}],\"expressCheckout\":false,\"effectiveDateDetails\":{\"isOnDemandAllowed\":false,\"isBackDateAllowed\":false,\"isFutureDateAllowed\":false,\"selectedDate\":\"\"},\"preAuthSuccess\":false,\"promoLossIndicator\":false,\"monthlyCreditAmount\":\"0.0\",\"agreementNumber\":\"0\",\"vztDiscountGain\":false,\"vztDiscountLoss\":false,\"discountPromoTotal\":0.0,\"registerNumber\":0,\"hasMixAndMatchPlan\":false,\"oneBillEnrolled\":false,\"isPlanChangeRequiredOnMultiLines\":false,\"ecpdProfileId\":\"\",\"protectionNotRequired\":false,\"fmiCheck\":false},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[]}]}}}}\n" +
                "\n";
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        request.setChannelId("VZ-DOTCOM");
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/add-device");
        HttpCookie targetPricingOffer = new HttpCookie("targetPricingOffer", "true");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("targetPricingOffer", targetPricingOffer);
        bodyMap.add("channelId", new HttpCookie("VZW-DOTCOM", "true"));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-MFA").cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);
        when(cartHelper.customerProfileDigital(Mockito.anyString()))
                .thenReturn(Mono.just(new CustomerProfileCXPResponse()));
        when(devHelper.addDevice(any(), any())).thenReturn(Mono.just(response));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mockito.when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART, FeatureFlagConstants.FLAG_NAME_CART_OPERATION_WITH_UUID, true)).thenReturn(Mono.just(true));
        Mockito.when(featureFlag.isFeatureEnabled(FeatureFlagConstants.APPLICATION_NAME_DIGITAL, FeatureFlagConstants.CONFIG_PROFILE_MVA_PROSPECT_CART, FeatureFlagConstants.FLAG_NAME_SET_ACNEXTGEN_FOR_MVA, false)).thenReturn(Mono.just(true));
        Mockito.when( featureFlagHelper.fetchD2DFeatureFlag()).thenReturn(Mono.just(true));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addDevice(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();

    }

    public void testCreateCookieDeviceCount() {
        when(request.getChannelId()).thenReturn("VZW-DOTCOM");
        when(pegaResponse.getServiceBody()).thenReturn((AddDeviceServiceBody) mock(ServiceBody.class));
        ServiceResponse serviceResponse = mock(ServiceResponse.class);
        when(pegaResponse.getServiceBody().getServiceResponse()).thenReturn((AddDeviceServiceResponse) serviceResponse);
        Context context = mock(Context.class);
        CartServiceCartInfo cartInfo = mock(CartServiceCartInfo.class);
        AddPlanLineDevice[] lineDevices = new AddPlanLineDevice[3];
        when(serviceResponse.getContext()).thenReturn(context);
        when(context.getCartInfo()).thenReturn(cartInfo);
        when(cartInfo.getLineDevices()).thenReturn(lineDevices);
        cartController3.createCookieDeviceCount(httpResponse,request,pegaResponse,"cartCount");

        verify(httpResponse).addCookie(argThat(cookie ->
                cookie.getName().equals("cartCount") &&
                        cookie.getValue().equals("3") &&
                        cookie.getPath().equals("/") &&
                        !cookie.isHttpOnly()
        ));

    }

    @Test
    public void dfoToDppCartTest() throws JsonProcessingException, SOEHTTPException {

        String requestString = readFromFile("dfoToDppCart_UIRequest.json");
        String responseString = readFromFile("dfoToDppCart_UIResponse.json");
        AddDeviceUIRequest request = mapper.readValue(requestString, AddDeviceUIRequest.class);
        AddDeviceUIResponse response = mapper.readValue(responseString, AddDeviceUIResponse.class);
        URI url = URI.create("http://localhost/dfoToDppCart");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("channelId", new HttpCookie("VZW-DOTCOM", "true"));
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        httpResponse.setStatusCode(HttpStatus.OK);

        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.dfoToDppCart(httpHeader, httpResponse,
                request);
    }



    public static String readFromFile(String fileName) {

        ClassLoader classLoader = CartUpdateOperationsController3Test.class.getClassLoader();

        try (InputStream inputStream = classLoader.getResourceAsStream(fileName)) {
            String result = IOUtils.toString(inputStream, StandardCharsets.UTF_8);
            return result;
        } catch (IOException e) {
            e.printStackTrace();
        }


        return "{}";
    }

    @Test
    public void addAccessoryFlexv2() throws IOException {
        String requestString = "AddAccessory_flexv2.json";
        String responseString = "AddAccessory_response_flexv2.json";

        String readRequest = sourceFileReaderUtil.readFile(requestString, testFileLocation);
        String readResponse = sourceFileReaderUtil.readFile(responseString, testFileLocation);
        AddAccessoriesUIRequest request = mapper.readValue(readRequest, AddAccessoriesUIRequest.class);
        AddAccessoriesUIResponse response = mapper.readValue(readResponse, AddAccessoriesUIResponse.class);
        URI url = URI.create("http://localhost/cart/flexV2/add-accessories");
        HttpCookie digital_ig_session = new HttpCookie("digital_ig_session", "11b5e062-c453");
        MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
        bodyMap.add("digital_ig_session", digital_ig_session);
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).header("digital_ig_session", "digital_1").header("flowName", "NSE_5G").header("channelId", "VZW-DOTCOM").cookies(bodyMap).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        Map<String, Object> redisMtnMap = new HashMap<>();
        when(cartAccessoryLoggingHelper.logAccessoryInkibana(Mockito.any())).thenReturn(Mono.just(new Object()));
        when(accHelper.addAccessory(Mockito.any())).thenReturn(Mono.just(response));
        when(redisHelper.updateDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(true));
        when(fiveGhomeCommonHelper.isFWAFlow(Mockito.any())).thenReturn(true);
        when(soeLoginSessionBean.isFWADigitalFlow()).thenReturn(true);
        Mockito.when(featureFlag.isFeatureEnabled(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyBoolean())).thenReturn(Mono.just(false));
        Mockito.when(featureFlagHelper.fetchAssistedTaggingFeatureFlag()).thenReturn(Mono.just(Boolean.TRUE));
        Mockito.when( featureFlagHelper.fetchD2DFeatureFlag()).thenReturn(Mono.just(true));
        List<String> requiredDataKeys = Arrays.asList(CartConstants.CART_COUNT, CartConstants.CART_ORDER_FLOW_TYPE);
        Map<String,String> redisData = new HashMap<>();
        redisData.put("cartCount","1");
        redisData.put("cartOrderFlowType","eup");
        when(redisHelper.getRequiredDataFromRedis(requiredDataKeys)).thenReturn(Mono.just(redisData));
        ReflectionTestUtils.setField(cartController3,"domains",List.of(".verizon.com",".verizonwireless.com"));
        Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController3.addAccessory(httpRequest, httpResponse, request);
        StepVerifier.create(controllerResponse).assertNext(resp -> org.junit.Assert.assertNotNull(resp)).expectComplete().verify();
    }
}