package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.controller.RefundExchangeController;
import onevz.soe.cart.controller.RemoveLockController;
import onevz.soe.cart.helper.RemoveLockHelper;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.responses.RemoveLockUIResponse;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.bind.WebDataBinder;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.net.URI;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = {CartServiceTestConfig.class})
@WebFluxTest(RefundExchangeController.class)
public class RemoveLockControllerTest {

    @Autowired
    RemoveLockController removeLockController;
    @MockBean
    RemoveLockHelper removeLockerHelper;
    @Autowired
    private ObjectMapper mapper;

    @Test
    public void saveCartTest() throws JsonProcessingException {
        String sampleResponse = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"sessionId\":\"\",\"correlationId\":\"soe-cart-2022.06.03.08.45.02-579.9162554637929\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"contextInfo\":{\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"ShoppingCart\",\"availablePaths\":[{\"path\":\"ShoppingCart\"},{\"path\":\"showFeatures\"},{\"path\":\"showDevice\"}]},\"customerInfo\":{\"accountNumber\":\"0389652918-00001\",\"cartCreator\":\"9375641370\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"statusMsg\":\"Save cart data updated successfully\",\"statusCode\":\"1\",\"discountPromoTotal\":0.0,\"registerNumber\":0,\"protectionNotRequired\":false},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"BYODDeviceIDPage\",\"BYODDeviceIDPage\",\"ShoppingCart\",\"DeviceConfigurator\",\"ShoppingCart\",\"PlanSelection\",\"ShoppingCart\",\"ShoppingCart\"]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"BYODDeviceIDPage\",\"BYODDeviceIDPage\",\"ShoppingCart\",\"DeviceConfigurator\",\"ShoppingCart\",\"PlanSelection\",\"ShoppingCart\",\"ShoppingCart\"]}]}}}}\n" +
                "\t\n";
        RemoveLockUIResponse response = mapper.readValue(sampleResponse, RemoveLockUIResponse.class);
        URI url = URI.create("http://localhost/removeLock");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        when(removeLockerHelper.updateRemoveLock(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> saveCartResponse = removeLockController.saveCart(httpHeader, httpResponse);
        StepVerifier.create(saveCartResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
                .verify();
        StepVerifier.create(saveCartResponse).assertNext(resp -> Assert.assertEquals(HttpStatus.OK, resp.getStatusCode())).expectComplete()
                .verify();
    }

    @Test
    public void saveCartErrorTest() throws JsonProcessingException {
        String sampleResponse = "{\"errors\":[{\"name\":\"VALIDATION_ERROR\",\"id\":\"1000\",\"message\":\"Validation error with journ mapping\",\"severity\":\"High\"}]}";
        RemoveLockUIResponse response = mapper.readValue(sampleResponse, RemoveLockUIResponse.class);
        URI url = URI.create("http://localhost/removeLock");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZ-DOTCOM").build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        when(removeLockerHelper.updateRemoveLock(Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> saveCartResponse = removeLockController.saveCart(httpHeader, httpResponse);
        StepVerifier.create(saveCartResponse).expectError().verify();
    }

    @Test
    public void initBinderByNameTest() {
        WebDataBinder binder = new WebDataBinder(null);
        removeLockController.initBinderByName(binder);
        assertNotNull(binder.getDisallowedFields());
    }

}
