package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import junit.framework.Assert;
import onevz.soe.cart.bpm.helper.CartServiceBpmHelper;
import onevz.soe.cart.constants.CartConstants;
import onevz.soe.cart.controller.FiveGHomeController;
import onevz.soe.cart.gql.schema.LineInfo;
import onevz.soe.cart.gql.schema.ServiceInfo;
import onevz.soe.cart.helper.*;
import onevz.soe.cart.model.common.CartError;
import onevz.soe.cart.model.common.FieldValidationException;
import onevz.soe.cart.model.retrieveCart.Cart5GAppointment;
import onevz.soe.cart.model.reviewOrderInsipico.InspicioResponseOrderInfo;
import onevz.soe.cart.model.reviewOrderInsipico.InspicioTermsAndConditions;
import onevz.soe.cart.model.reviewOrderInsipico.ReviewOrderData;
import onevz.soe.cart.requests.GetCartDetailsRequest;
import onevz.soe.cart.responses.*;
import onevz.soe.cart.ui.requests.*;
import onevz.soe.cart.ui.responses.AddPlanAndDeviceUIResponse;
import onevz.soe.cart.ui.responses.CrmRetrieveCartUIResponse;
import onevz.soe.session.bean.SOELoginSessionBean;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.*;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpResponse;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.WebDataBinder;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.*;

@RunWith(SpringJUnit4ClassRunner.class)
@WebFluxTest(FiveGHomeController.class)
public class FiveGHomeControllerTest {

	@MockBean
	private FiveGhomeCommonHelper readCartHelper;
	@MockBean
	private FiveGhomeAALHelper fiveGhomeAALHelper;
	@MockBean
	private FiveGhomeNSEHelper fiveGhomeNSEHelper;
	@Autowired
	private FiveGHomeController cartController;
	@Autowired
	private ObjectMapper mapper;
	@MockBean
	private RedisHelper redisHelper;
	@MockBean
	private RedisHelper2 redisHelper2;
	@MockBean
	private RedisHelper3 redisHelper3;
	@MockBean
	private RemoveHomePhoneHelper removeHomePhoneHelper;
	@MockBean
	private UpdateCartWithDatesHelper updateCartWithDatesHelper;
	@MockBean
	private SOELoginSessionBean sessionBean;
	@MockBean
	CartServiceBpmHelper bpmHelper;
	@MockBean
	private FiveGhomeTechHelper fiveGhomeTechHelper;

	@Test
	public void retrieveFiveGCartTest() throws IOException {
		String requestString = "{\"meta\":{},\"data\":{\"cartId\":\"b58e3b4d-f13c-440d-8ca8-465f4856a16b\"}}";
		String responseString = "{\"cartHeader\":{\"vendorId\":\"VZWCOM\",\"sourceSystem\":\"VZW-DOTCOM\",\"cartId\":\"b58e3b4d-f13c-440d-8ca8-465f4856a16b\",\"fullAccountNumber\":\"0282354804-1\",\"status\":\"A\",\"createTimestamp\":\"2021-10-11T05:50:50.450965-04:00[US/Eastern]\",\"lastUpdateTimestamp\":\"2021-10-11T05:51:45.828807-04:00[US/Eastern]\",\"cartCreator\":\"7326726656\",\"cartCreatorChannelId\":\"VZW-DOTCOM\",\"cartCreatorOrderLocationCode\":\"D463801\",\"cartCreatorSalesRepId\":\"EZ706\",\"caseId\":\"SOP-4604006-E01\",\"visionCustomerType\":\"PE\",\"maverickLocation\":false,\"preConfiguredCartType\":\"BAU\",\"preConfiguredCartTypeDuringAddDevice\":\"BAU\",\"isCoreRep\":false},\"orderDetailsView\":{\"dueTodayAmount\":\"0.0\",\"dueMonthlyAmount\":\"60.0\",\"orderActivityType\":\"AAL\",\"totalShippingCost\":\"null\",\"totalDiscountedShippingCost\":\"null\",\"installType\":\"Professional SetUp\",\"orderNumber\":\"3117431\",\"locationCode\":\"D463801\",\"orderType\":\"PS\",\"numOfLines\":\"1\",\"hiddenPromos\":[\"wireless-offer\"]},\"dueTodayList\":[{\"name\":\"5G Internet Gateway\",\"installationType\":\"Professional SetUp\",\"discountApplied\":\"0.0\",\"actualAmount\":\"0.0\",\"totalAmountWithDiscount\":\"0.0\",\"productId\":\"16900002\",\"sorId\":\"LVSKIHP\",\"itemType\":\"DEVICE\",\"quantity\":\"1\",\"taxAmount\":\"0.0\",\"lineNumber\":\"newLine1\",\"multiLineSeqNumber\":1,\"isBackorder\":\"false\",\"preBackDate\":\"\"}],\"dueMonthlyList\":[{\"name\":\"5G HOME INTERNET\",\"actualAmount\":\"80.0\",\"totalAmountWithDiscount\":\"60.0\",\"productId\":\"39425\",\"itemType\":\"PLAN\"}],\"dueMonthlyTaxes\":[{\"dueAmount\":\"0.0\"}],\"dueTodayTaxes\":[{\"dueAmount\":\"0.0\"}],\"shippingDetails\":[{\"address\":{\"apartmentNo\":\"\",\"type\":\"R\",\"streetNumber\":\"125\",\"streetName\":\"SAINT NICHOLAS\",\"addressLine2\":\"\",\"addressLine1\":\"125 SAINT NICHOLAS AVE\",\"city\":\"SOUTH PLAINFIELD\",\"state\":\"NJ\",\"zipCode\":\"07080\",\"zipCode4\":\"1807\",\"county\":\"\",\"countryCode\":\"\",\"fipsCode\":\"3402369390\",\"firstName\":\"JACK\",\"lastName\":\"MANUEL\",\"emailId\":\"QVOOLN64Z7@VZW.COM\",\"phoneNumber\":\"3453350350\",\"streetType\":\"AVE\",\"streetDirection\":\"\"},\"cbrPhone\":\"3453350350\",\"firstName\":\"JACK\",\"lastName\":\"MANUEL\",\"midInitials\":\"J\",\"isUseUnVerifiedAddress\":false,\"isValidAddress\":false,\"email\":\"QVOOLN64Z7@VZW.COM\"}],\"payments\":[],\"primaryUserInfo\":{\"firstName\":\"JACK\",\"lastName\":\"MANUEL\",\"address\":{\"firmName\":\"\",\"apartmentNo\":\"\",\"type\":\"AVE\",\"streetNumber\":\"125\",\"streetName\":\"SAINT NICHOLAS\",\"addressLine2\":\"\",\"addressLine1\":\"125 SAINT NICHOLAS AVE\",\"poBoxNo\":\"\",\"ruralRouteNo\":\"\",\"ruralDelNo\":\"\",\"city\":\"SOUTH PLAINFIELD\",\"state\":\"NJ\",\"zipCode\":\"07080\",\"zipCode4\":\"1807\",\"county\":\"\",\"countryCode\":\"US\",\"fipsCode\":\"3402369390\",\"firstName\":\"JACK\",\"lastName\":\"MANUEL\",\"emailId\":\"QVOOLN64Z7@VZW.COM\",\"phoneNumber\":\"3453350350\",\"streetType\":\"AVE\",\"streetDirection\":\"\"},\"isValidAddress\":true,\"bsnsName\":\"\",\"emailId\":\"QVOOLN64Z7@VZW.COM\"},\"cart5GAddress\":{\"addressLine1\":\"800 S OGDEN ST\",\"city\":\"DENVER\",\"state\":\"CO\",\"zipCode\":\"80209\",\"zipCode4\":\"\",\"countryCode\":\"\",\"fipsCode\":\"0803120000\",\"floor\":0},\"registrationDetails\":{}}";
		GetCartDetailsRequest request = mapper.readValue(requestString, GetCartDetailsRequest.class);
		GetCartDetailsUIResponse response = mapper.readValue(responseString, GetCartDetailsUIResponse.class);
		URI url = URI.create("http://localhost/5g/retrieve-cart");
		MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
		HttpCookie httpCookieCjevent  = new HttpCookie(CartConstants.CJEVENT, CartConstants.CJEVENT);
		HttpCookie httpCookieAffiliate  = new HttpCookie(CartConstants.AFFILIATE, CartConstants.AFFILIATE);
		HttpCookie httpCookieigSession  = new HttpCookie(CartConstants.DIGITAL_IG_SESSION, CartConstants.DIGITAL_IG_SESSION);
		bodyMap.add(CartConstants.CJEVENT, httpCookieCjevent);
		bodyMap.add(CartConstants.AFFILIATE, httpCookieAffiliate);
		bodyMap.add(CartConstants.DIGITAL_IG_SESSION,httpCookieigSession);
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookies(bodyMap).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(fiveGhomeNSEHelper.get5GCart(request)).thenReturn(Mono.just(ResponseEntity.status(200).body(response)));
		when(redisHelper.upsertRetrieveCartDataIntoRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));

		Mono<ResponseEntity<GetCartDetailsUIResponse>> controllerResponse = cartController.retrieveFiveGCart(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
		//for covring 2nd branch of "sessionId" assignment in controller
		MockServerHttpRequest httpHeaderNullCheck = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookies(bodyMap).build();
		Mono<ResponseEntity<GetCartDetailsUIResponse>> controllerResponseNullCheck = cartController.retrieveFiveGCart(httpHeaderNullCheck, httpResponse,
				request);
		StepVerifier.create(controllerResponseNullCheck).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
		MultiValueMap<String, HttpCookie> bodyMap1 = new LinkedMultiValueMap<String, HttpCookie>();
		HttpCookie httpCookieCjevent1  = new HttpCookie(CartConstants.CJEVENT, null);
		HttpCookie httpCookieAffiliate1  = new HttpCookie(CartConstants.AFFILIATE, null);
		bodyMap1.add(CartConstants.CJEVENT, httpCookieCjevent1);
		bodyMap1.add(CartConstants.AFFILIATE, httpCookieAffiliate1);
		MockServerHttpRequest httpHeader1 = MockServerHttpRequest.method(HttpMethod.POST, url).cookies(bodyMap1).build();
		Mono<ResponseEntity<GetCartDetailsUIResponse>> controllerResponse1 = cartController.retrieveFiveGCart(httpHeader1, httpResponse,
				request);
		StepVerifier.create(controllerResponse1).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();


		HttpCookie httpCookieCjevent2  = new HttpCookie("visitId", "null");
		HttpCookie httpCookieAffiliate2  = new HttpCookie("visitorId", "null");
		bodyMap.add("visitId", httpCookieCjevent2);
		bodyMap.add("visitorId", httpCookieAffiliate2);
		bodyMap.remove(CartConstants.CJEVENT);
		bodyMap.remove(CartConstants.AFFILIATE);
		MockServerHttpRequest httpHeader2 = MockServerHttpRequest.method(HttpMethod.POST, url).cookies(bodyMap).build();
		Mono<ResponseEntity<GetCartDetailsUIResponse>> controllerResponse2 = cartController.retrieveFiveGCart(httpHeader2, httpResponse,
				request);
		StepVerifier.create(controllerResponse2).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void saveCartWithEmailTest() throws IOException {
		String requestString = "{\"emaild\":\"usha.kammara@veriozn.com\",\"intendType\":\"NSE_LTE\"}";
		String responseString = "{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"correlationId\":\"POE-D-e81378f9-d693-4234-802a-41019e24e4c3\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4346627-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\"},\"customerInfo\":{\"customerType\":\"N\",\"originalCreditApprovalNumber\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-e81378f9-d693-4234-802a-41019e24e4c3\",\"processingMTN\":\"\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"4221df0b-f63d-46f4-b59a-43edb32c8675\",\"statusMsg\":\"Save cart data updated successfully\",\"statusCode\":\"1\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"ShoppingCart\"]},{\"mtn\":\"\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"ShoppingCart\"]}]}}}}";
		SaveCartWithEmailUIRequest request = mapper.readValue(requestString, SaveCartWithEmailUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);// AddPlanAndDeviceUIResponse
		URI url = URI.create("http://localhost/5g/saveCartWithEmail");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.saveCartWithEmail(request)).thenReturn(Mono.just(response));

		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.saveCartWithEmail(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test  // updateProcessStep
	public void updateProcessStepTest() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"newLine1\",\"processStep\":\"InstallType\",\"processAction\":\"Complete\",\"intendType\":\"AAL_5G\",\"bundleInstallType\":\"\"},\"data\":{}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4387896-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"0280000250-00001\",\"cartCreator\":\"3166127651\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"existingCase\":\"\"},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"9978549b-aa29-4d8e-b09e-e4c7256da6da\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"InstallType\"]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"InstallType\"]}]}}}}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);// AddPlanAndDeviceUIResponse
		URI url = URI.create("http://localhost/5g/updateProcessStep");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(request)).thenReturn(Mono.just(response));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
		when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));

		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.updateProcessStep(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void updateProcessStepWithCookiesTest() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"newLine1\",\"processStep\":\"InstallType\",\"processAction\":\"Complete\",\"intendType\":\"AAL_5G\",\"bundleInstallType\":\"\"},\"data\":{}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4387896-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"0280000250-00001\",\"cartCreator\":\"3166127651\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"existingCase\":\"\"},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"9978549b-aa29-4d8e-b09e-e4c7256da6da\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"InstallType\"]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"InstallType\"]}]}}}}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);// AddPlanAndDeviceUIResponse
		URI url = URI.create("http://localhost/5g/updateProcessStep");
		HttpCookie digital_ig_session = new HttpCookie("digital_ig_session", "digital_ig_session");
		HttpCookie domainCookie = new HttpCookie("domainCookie", "domainCookie");
		HttpCookie ecpdcookie = new HttpCookie("ecpdcookie", "ecpdcookie");
		MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
		bodyMap.add("digital_ig_session", digital_ig_session);
		bodyMap.add("domainCookie", domainCookie);
		bodyMap.add("ecpdcookie", ecpdcookie);
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookies(bodyMap).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(request)).thenReturn(Mono.just(response));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
		when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));

		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.updateProcessStep(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test  // Gen2-Gen3 updateCart
	public void swapUpdateCartTest() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"8135199979\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"intendType\":\"EUP_5G_REPAIR\",\"bundleInstallType\":\"5GHomeGeminiProfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"O\"}]}}";
		String responseString="{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4629485-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"0430568040-00001\",\"cartCreator\":\"8135199979\",\"processingMTN\":\"8135199979\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":1,\"cartId\":\"2a74d680-a043-4d53-8836-802edb5c7e49\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"lines\":[{\"status\":1,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"mtn\":\"8135199979\",\"isDeviceSelected\":false,\"userSelectedPlan\":false,\"lineId\":\"8135199979\",\"sortingNumber\":\"0\",\"device\":{\"upgradeReasonCode\":\"UN\",\"id\":\"16900002\",\"itemPrice\":\"0.0\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"EUP_5G_REPAIR\",\"currentPlanType\":\"LLP\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"isAppendedLine\":false,\"fiveGPlanAdded\":false}],\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"8135199979\",\"completedprocessSteps\":[]},{\"mtn\":\"8135199979\",\"completedprocessSteps\":[]}]}}}}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);
		URI url = URI.create("http://localhost/5g/swap/updateCart");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.upgradePlanAndDevice(request)).thenReturn(Mono.just(response));
		when(redisHelper3.fetchCustomerAddressFromRedis()).thenReturn(Mono.just(new CustomerProfileAddressResponse()));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(any(),eq("device"))).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.upgradePlanAndDevice(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test  // Gen2-Gen3 updateCart
	public void swapUpdateCartWithCookiesTest() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"8135199979\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"intendType\":\"EUP_5G_REPAIR\",\"bundleInstallType\":\"5GHomeGeminiProfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"O\"}]}}";
		String responseString="{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4629485-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"0430568040-00001\",\"cartCreator\":\"8135199979\",\"processingMTN\":\"8135199979\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":1,\"cartId\":\"2a74d680-a043-4d53-8836-802edb5c7e49\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"lines\":[{\"status\":1,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"mtn\":\"8135199979\",\"isDeviceSelected\":false,\"userSelectedPlan\":false,\"lineId\":\"8135199979\",\"sortingNumber\":\"0\",\"device\":{\"upgradeReasonCode\":\"UN\",\"id\":\"16900002\",\"itemPrice\":\"0.0\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"EUP_5G_REPAIR\",\"currentPlanType\":\"LLP\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"isAppendedLine\":false,\"fiveGPlanAdded\":false}],\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"8135199979\",\"completedprocessSteps\":[]},{\"mtn\":\"8135199979\",\"completedprocessSteps\":[]}]}}}}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);
		URI url = URI.create("http://localhost/5g/swap/updateCart");
		HttpCookie digital_ig_session = new HttpCookie("digital_ig_session", "digital_ig_session");
		HttpCookie domainCookie = new HttpCookie("domainCookie", "domainCookie");
		HttpCookie ecpdcookie = new HttpCookie("ecpdcookie", "ecpdcookie");
		MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
		bodyMap.add("digital_ig_session", digital_ig_session);
		bodyMap.add("domainCookie", domainCookie);
		bodyMap.add("ecpdcookie", ecpdcookie);
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookies(bodyMap).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.upgradePlanAndDevice(request)).thenReturn(Mono.just(response));
		when(redisHelper3.fetchCustomerAddressFromRedis()).thenReturn(Mono.just(new CustomerProfileAddressResponse()));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(any(),eq("device"))).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.upgradePlanAndDevice(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test  // Gen2-Gen3 retrieve-cart
	public void swapFiveGRetrieveCartTest() throws IOException {
		String requestString = "{\"meta\":{},\"data\":{\"cartId\":\"2a74d680-a043-4d53-8836-802edb5c7e49\"}}";
		String responseString = "{\"cartHeader\":{\"vendorId\":\"VZWCOM\",\"sourceSystem\":\"VZW-DOTCOM\",\"cartId\":\"2a74d680-a043-4d53-8836-802edb5c7e49\",\"fullAccountNumber\":\"0430568040-1\",\"status\":\"A\",\"createTimestamp\":\"2021-10-19T09:56:24.043067-04:00[US/Eastern]\",\"lastUpdateTimestamp\":\"2021-10-19T09:56:25.288929-04:00[US/Eastern]\",\"cartCreator\":\"8135199979\",\"cartCreatorChannelId\":\"VZW-DOTCOM\",\"cartCreatorOrderLocationCode\":\"1456801\",\"cartCreatorSalesRepId\":\"NPB2C\",\"caseId\":\"SOP-4629485-E01\",\"visionCustomerType\":\"PE\",\"maverickLocation\":false,\"preConfiguredCartType\":\"BAU\",\"preConfiguredCartTypeDuringAddDevice\":\"BAU\",\"isCoreRep\":false},\"orderDetailsView\":{\"dueTodayAmount\":\"0.0\",\"dueMonthlyAmount\":\"0.0\",\"totalShippingCost\":\"null\",\"totalDiscountedShippingCost\":\"null\",\"locationCode\":\"1456801\",\"orderType\":\"PS\",\"numOfLines\":\"1\"},\"dueTodayList\":[],\"dueTodayTaxes\":[{\"dueAmount\":\"0.0\"}]}";
		GetCartDetailsRequest request = mapper.readValue(requestString, GetCartDetailsRequest.class);
		GetCartDetailsUIResponse response = mapper.readValue(responseString, GetCartDetailsUIResponse.class);// AddPlanAndDeviceUIResponse
		URI url = URI.create("http://localhost/5g/swap/retrieve-cart");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(fiveGhomeTechHelper.getSwap5GCart(request, httpResponse)).thenReturn(Mono.just(ResponseEntity.status(200).body(response)));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
		when(redisHelper.upsertRetrieveCartDataIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));

		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.swapFiveGRetrieveCart(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test  // Gen2-Gen3 order-confirmation
	public void swapOrderConfirmationTest() throws IOException {
		String requestString = "{\"meta\":{},\"data\":{\"cartId\":\"b58e3b4d-f13c-440d-8ca8-465f4856a16b\"}}";
		String responseString = "{\"cartHeader\":{\"vendorId\":\"VZWCOM\",\"sourceSystem\":\"VZW-DOTCOM\",\"cartId\":\"964f96a1-f9bd-4901-aa10-44fe057f085c\",\"fullAccountNumber\":\"0289201945-1\",\"status\":\"A\",\"createTimestamp\":\"2021-09-08T08:13:37.375359-04:00[US/Eastern]\",\"lastUpdateTimestamp\":\"2021-09-08T08:13:43.248388-04:00[US/Eastern]\",\"cartCreator\":\"4024188003\",\"cartCreatorChannelId\":\"VZW-DOTCOM\",\"cartCreatorOrderLocationCode\":\"N832201\",\"cartCreatorSalesRepId\":\"NPB2C\",\"caseId\":\"SOP-3464709-E01\",\"visionCustomerType\":\"PE\",\"maverickLocation\":false,\"preConfiguredCartType\":\"BAU\",\"preConfiguredCartTypeDuringAddDevice\":\"BAU\",\"isCoreRep\":false},\"orderDetailsView\":{\"orderNumber\":\"2060048\",\"locationCode\":\"N832201\",\"orderType\":\"PS\",\"numOfLines\":\"1\"},\"primaryUserInfo\":{\"emailId\":\"SVZGSVIOVZ927@VZW.COM\"}}";
		GetCartDetailsRequest request = mapper.readValue(requestString, GetCartDetailsRequest.class);
		GetCartDetailsUIResponse response = mapper.readValue(responseString, GetCartDetailsUIResponse.class);// AddPlanAndDeviceUIResponse
		URI url = URI.create("http://localhost/5g/swap/order-confirmation");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.swapOrderConfirmation(request, httpResponse)).thenReturn(Mono.just(ResponseEntity.status(200).body(response)));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.swapOrderConfirmation(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void removeHomePhoneTest() throws Exception {
		String requestString = "{\n \"cartInfo\": {\n \"clientAppName\": \"VZW-DOTCOM\",\n \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\n \"cartId\": \"\",\n \"caseId\": \"\",\n  \"accountNumber\": \"0213143123-00001\", \n \"cartCreator\": \"8136958775\",\n\"processingMTN\": \"8136958775\",\n \"homePhoneMTN\":\"xxxxxx\",\n  \"processStep\": \"ShoppingCart\",\n  \"processAction\": \"removeDevice\",\n \"intendType\": \"MOVER\",\n \"action\" : \"REMOVE\"\n \n  }\n}";
		String responseString = "{\n \"serviceHeader\" : {\n   \"clientId\" : \"OMNI-RETAIL\",\n   \"statusMsg\" : \"SUCCESS\",\n \"correlationId\" : \"soe-cart-2021.08.06.17.50.24-125.72236596853669\",\n  \"sessionId\" : \"\",\n   \"serviceName\" : \"SalesOrderPurchase\",\n  \"userId\" : \"\",\n\"statusCode\" : \"00\"\n },\n \"serviceBody\" : {\n\"serviceResponse\" : {\n \"context\" : {\n    \"cartInfo\" : {\n   \"statusMsg\" : \"Success\",\n\"cartId\" : \"aa3a61e9-5410-4243-9efe-598c3ec2ac08\",\n \"statusCode\" : \"1\"\n },\n      \"contextInfo\" : {\n     \"availablePaths\" : [{\n   \"path\" : \"ShoppingCart\"\n }, {\n    \"path\" : \"addDevice\"\n }\n   ],\n \"processStep\" : \"ShoppingCart\",\n  \"callReason\" : \"SalesOrderPurchase\"\n },\n\"caseId\" : \"SOP-3647723-E01\",\n    \"customerInfo\" : {\n    \"cartCreator\" : \"4102411705\",\n\"processingMTN\" : \"4014436878\",\n   \"accountNumber\" : \"0001445545-00001\"\n },\n   \"processMTNList\" : [{\n   \"mtn\" : \"2404951496\",\n  \"completedprocessSteps\" : [\"ShoppingCart\",\"addDevice\"]\n}\n    ]\n}\n}\n}\n}\n";
		RemoveHomePhoneUIRequest request = mapper.readValue(requestString, RemoveHomePhoneUIRequest.class);
		RemoveHomePhonePegaResponse response = mapper.readValue(responseString, RemoveHomePhonePegaResponse.class);
		URI url = URI.create("http://localhost/removeHomePhone");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
		when(removeHomePhoneHelper.removeHomePhone(Mockito.any())).thenReturn(Mono.just(response));
		Mono<Object> controllerResponse = cartController.removeHomePhone(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
		StepVerifier.create(controllerResponse).assertNext(resp -> org.junit.Assert.assertEquals(response, resp)).expectComplete()
				.verify();
	}

	@Test
	public void removeHomePhoneWithRedisDataTest() throws Exception {
		String requestString = "{\n \"cartInfo\": {\n \"clientAppName\": \"VZW-DOTCOM\",\n \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\n \"cartId\": \"\",\n \"caseId\": \"\",\n  \"accountNumber\": \"0213143123-00001\", \n \"cartCreator\": \"8136958775\",\n\"processingMTN\": \"8136958775\",\n \"homePhoneMTN\":\"xxxxxx\",\n  \"processStep\": \"ShoppingCart\",\n  \"processAction\": \"removeDevice\",\n \"intendType\": \"MOVER\",\n \"action\" : \"REMOVE\"\n \n  }\n}";
		String responseString = "{\n \"serviceHeader\" : {\n   \"clientId\" : \"OMNI-RETAIL\",\n   \"statusMsg\" : \"SUCCESS\",\n \"correlationId\" : \"soe-cart-2021.08.06.17.50.24-125.72236596853669\",\n  \"sessionId\" : \"\",\n   \"serviceName\" : \"SalesOrderPurchase\",\n  \"userId\" : \"\",\n\"statusCode\" : \"00\"\n },\n \"serviceBody\" : {\n\"serviceResponse\" : {\n \"context\" : {\n    \"cartInfo\" : {\n   \"statusMsg\" : \"Success\",\n\"cartId\" : \"aa3a61e9-5410-4243-9efe-598c3ec2ac08\",\n \"statusCode\" : \"1\"\n },\n      \"contextInfo\" : {\n     \"availablePaths\" : [{\n   \"path\" : \"ShoppingCart\"\n }, {\n    \"path\" : \"addDevice\"\n }\n   ],\n \"processStep\" : \"ShoppingCart\",\n  \"callReason\" : \"SalesOrderPurchase\"\n },\n\"caseId\" : \"SOP-3647723-E01\",\n    \"customerInfo\" : {\n    \"cartCreator\" : \"4102411705\",\n\"processingMTN\" : \"4014436878\",\n   \"accountNumber\" : \"0001445545-00001\"\n },\n   \"processMTNList\" : [{\n   \"mtn\" : \"2404951496\",\n  \"completedprocessSteps\" : [\"ShoppingCart\",\"addDevice\"]\n}\n    ]\n}\n}\n}\n}\n";
		RemoveHomePhoneUIRequest request = mapper.readValue(requestString, RemoveHomePhoneUIRequest.class);
		RemoveHomePhonePegaResponse response = mapper.readValue(responseString, RemoveHomePhonePegaResponse.class);
		URI url = URI.create("http://localhost/removeHomePhone");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		CartRedisData redisData=new CartRedisData();
		redisData.setCartId("69a66ef4d7e344dfb2db299209ea8333");
		redisData.setCaseId("123");
		redisData.setAccountNumber("0213143123-00001");
		redisData.setProcessingMTN("8136958775");
		redisData.setCartCreator("8136958775");
		redisData.setProcessStep("ShoppingCart");
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(redisData));
		when(removeHomePhoneHelper.removeHomePhone(Mockito.any())).thenReturn(Mono.just(response));
		Mono<Object> controllerResponse = cartController.removeHomePhone(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void updateCartWithDateTest() throws IOException {
		String requestString = "{\n \"context\": {\n \"caseId\": \"SOP-3597615-E01\",\n\"contextInfo\": {\n \"callReason\": \"SalesOrderPurchase\",\n \"processStep\": \"OrderReview\",\n\"processAction\": \"UpdateScheduleAppointment\",\n \"intent\": \"MOVER\"\n},\n\"customerInfo\": {\n\"accountNumber\": \"0389467727-00001\",\n\"cartCreator\": \"6072376627\",\n\"processingMTN\": \"8136958775\",\n \"registerNumber\": 0\n},\n\"cartInfo\": {\n\"cartId\": \"cfe0a112-c547-41a6-bfde-7e0688d7a774\",\n  \"itemType\": \"SCHEDULE5GAPPT\",\n\"intendType\": \"MOVER\",\n\"moversInfo\": {\n\"moveInDate\": \"07/20/2021\",\n  \"moveOutDate\": \"07/30/2021\"\n }\n }\n }\n}";
		String responseString = "{\n \"serviceHeader\" : {\n \"statusMsg\" : \"SUCCESS\",\n \"sessionId\" : \"\",\n \"serviceName\" : \"SalesOrderPurchase\",\n \"userId\" : \"\",\n\"statusCode\" : \"00\"\n },\n \"serviceBody\" : {\n \"serviceResponse\" : {\n\"context\" : {\n\"cartInfo\" : {\n  \"statusMsg\" : \"Success\",\n\"cartId\" : \"1f69c02f-c68f-4445-b5ff-8814fbd3412d\",\n \"preAuthSuccess\" : false,\n \"statusCode\" : \"1\"\n },\n \"contextInfo\" : {\n \"availablePaths\" : [{\n \"path\" : \"OrderReview-Shipping-Payment-Agreement\"\n  }\n   ],\n  \"processAction\" : \"\",\n \"processStep\" : \"OrderReview-Shipping-Payment-Agreement\",\n  \"callReason\" : \"SalesOrderPurchase\"\n    },\n \"caseId\" : \"SOP-3335332-E01\",\n\"customerInfo\" : {\n \"cartCreator\" : \"4029847575\",\n  \"processingMTN\" : \"newLine1\",\n \"accountNumber\" : \"0283134872-00001\"\n },\n   \"processMTNList\" : [{\n   \"mtn\" : \"newLine1\",\n\"completedprocessSteps\" : [\"NumberSelection\", \"Accessories\", \"NumberSelection\", \"NumberSelection\", \"ShoppingCart\", \"ContactInfo\", \"ShippingOptions\", \"ShippingOptions\", \"AppointmentSchedule\"]\n }\n]\n }\n  }\n }\n}\n";
		CartWithDateUIRequest request = mapper.readValue(requestString, CartWithDateUIRequest.class);
		CartWithDatePegaResponse response = mapper.readValue(responseString, CartWithDatePegaResponse.class);
		URI url = URI.create("http://localhost/5g/updateCartWithDates");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
		when(updateCartWithDatesHelper.saveCartWithDate(Mockito.any())).thenReturn(Mono.just(response));
		Mono<CartWithDatePegaResponse> controllerResponse = cartController.updateCartWithDateAppointment(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
		StepVerifier.create(controllerResponse).assertNext(resp -> org.junit.Assert.assertEquals(response, resp)).expectComplete()
				.verify();
	}

	@Test
	public void updateCartWithDateWithRedisDataTest() throws IOException {
		String requestString = "{\n \"context\": {\n \"caseId\": \"SOP-3597615-E01\",\n\"contextInfo\": {\n \"callReason\": \"SalesOrderPurchase\",\n \"processStep\": \"OrderReview\",\n\"processAction\": \"UpdateScheduleAppointment\",\n \"intent\": \"MOVER\"\n},\n\"customerInfo\": {\n\"accountNumber\": \"0389467727-00001\",\n\"cartCreator\": \"6072376627\",\n\"processingMTN\": \"8136958775\",\n \"registerNumber\": 0\n},\n\"cartInfo\": {\n\"cartId\": \"cfe0a112-c547-41a6-bfde-7e0688d7a774\",\n  \"itemType\": \"SCHEDULE5GAPPT\",\n\"intendType\": \"MOVER\",\n\"moversInfo\": {\n\"moveInDate\": \"07/20/2021\",\n  \"moveOutDate\": \"07/30/2021\"\n }\n }\n }\n}";
		String responseString = "{\n \"serviceHeader\" : {\n \"statusMsg\" : \"SUCCESS\",\n \"sessionId\" : \"\",\n \"serviceName\" : \"SalesOrderPurchase\",\n \"userId\" : \"\",\n\"statusCode\" : \"00\"\n },\n \"serviceBody\" : {\n \"serviceResponse\" : {\n\"context\" : {\n\"cartInfo\" : {\n  \"statusMsg\" : \"Success\",\n\"cartId\" : \"1f69c02f-c68f-4445-b5ff-8814fbd3412d\",\n \"preAuthSuccess\" : false,\n \"statusCode\" : \"1\"\n },\n \"contextInfo\" : {\n \"availablePaths\" : [{\n \"path\" : \"OrderReview-Shipping-Payment-Agreement\"\n  }\n   ],\n  \"processAction\" : \"\",\n \"processStep\" : \"OrderReview-Shipping-Payment-Agreement\",\n  \"callReason\" : \"SalesOrderPurchase\"\n    },\n \"caseId\" : \"SOP-3335332-E01\",\n\"customerInfo\" : {\n \"cartCreator\" : \"4029847575\",\n  \"processingMTN\" : \"newLine1\",\n \"accountNumber\" : \"0283134872-00001\"\n },\n   \"processMTNList\" : [{\n   \"mtn\" : \"newLine1\",\n\"completedprocessSteps\" : [\"NumberSelection\", \"Accessories\", \"NumberSelection\", \"NumberSelection\", \"ShoppingCart\", \"ContactInfo\", \"ShippingOptions\", \"ShippingOptions\", \"AppointmentSchedule\"]\n }\n]\n }\n  }\n }\n}\n";
		CartWithDateUIRequest request = mapper.readValue(requestString, CartWithDateUIRequest.class);
		CartWithDatePegaResponse response = mapper.readValue(responseString, CartWithDatePegaResponse.class);
		URI url = URI.create("http://localhost/5g/updateCartWithDates");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		CartRedisData redisData=new CartRedisData();
		redisData.setCartId("69a66ef4d7e344dfb2db299209ea8333");
		redisData.setCaseId("123");
		redisData.setAccountNumber("0213143123-00001");
		redisData.setProcessingMTN("8136958775");
		redisData.setCartCreator("8136958775");
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(redisData));
		when(updateCartWithDatesHelper.saveCartWithDate(Mockito.any())).thenReturn(Mono.just(response));
		Mono<CartWithDatePegaResponse> controllerResponse = cartController.updateCartWithDateAppointment(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}



	@Test
	public void addPlanAndDeviceTest() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"intendType\":\"AAL_5G\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-5188491-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Accessories\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Accessories\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-D-410f65a0-8535-471c-b1b3-0d14cbfcbd26\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":1,\"cartId\":\"6af05322-815c-423c-9bb2-9b0fce190075\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"onDemandAllowed\":false,\"backDateAllowed\":false,\"futureDateAllowed\":false,\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"lines\":[{\"status\":1,\"spos\":[{\"id\":\"732\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false},{\"id\":\"1508\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false}],\"sfos\":[{\"id\":\"48526\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"48553\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"54307\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68872\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"70421\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78003\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"83856\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"85503\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86112\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86926\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86927\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86928\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86952\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86953\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false}],\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"mtn\":\"newLine1\",\"isDeviceSelected\":true,\"userSelectedPlan\":false,\"lineId\":\"newLine1\",\"sortingNumber\":\"0\",\"device\":{\"id\":\"LVSKIHP\",\"itemPrice\":\"0.0\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"5G Internet Gateway\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false},\"sim\":{\"id\":\"NI-DPSIM\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"NSE_5G\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"isAppendedLine\":false,\"fiveGPlanAdded\":false}],\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]}]}}}}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);
		URI url = URI.create("http://localhost/5g/updateCart");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response));

		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addPlanAndDevice(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}



	@Test
	public void addPlanAndDevice_Error1Test() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"intendType\":\"AAL_5G\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
		String responseString = "{\"errors\":[]}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);
		System.out.println(request.getChannelId());
		URI url = URI.create("http://localhost/5g/updateCart");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addPlanAndDevice(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse.log()).expectError()
				.verify();
	}





	@Test
	public void addPlanAndDeviceWithCookiesTest() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"intendType\":\"AAL_5G\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-5188491-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Accessories\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Accessories\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-D-410f65a0-8535-471c-b1b3-0d14cbfcbd26\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":1,\"cartId\":\"6af05322-815c-423c-9bb2-9b0fce190075\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"onDemandAllowed\":false,\"backDateAllowed\":false,\"futureDateAllowed\":false,\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"lines\":[{\"status\":1,\"spos\":[{\"id\":\"732\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false},{\"id\":\"1508\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false}],\"sfos\":[{\"id\":\"48526\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"48553\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"54307\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68872\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"70421\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78003\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"83856\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"85503\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86112\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86926\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86927\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86928\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86952\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86953\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false}],\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"mtn\":\"newLine1\",\"isDeviceSelected\":true,\"userSelectedPlan\":false,\"lineId\":\"newLine1\",\"sortingNumber\":\"0\",\"device\":{\"id\":\"LVSKIHP\",\"itemPrice\":\"0.0\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"5G Internet Gateway\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false},\"sim\":{\"id\":\"NI-DPSIM\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"NSE_5G\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"isAppendedLine\":false,\"fiveGPlanAdded\":false}],\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]}]}}}}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);
		System.out.println(request.getChannelId());
		URI url = URI.create("http://localhost/5g/updateCart");
		HttpCookie digital_ig_session = new HttpCookie("digital_ig_session", "digital_ig_session");
		HttpCookie domainCookie = new HttpCookie("domainCookie", "domainCookie");
		HttpCookie ecpdcookie = new HttpCookie("ecpdcookie", "ecpdcookie");
		HttpCookie MUCFlow = new HttpCookie("MUCFlow", "MUCFlow");
		MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
		bodyMap.add("digital_ig_session", digital_ig_session);
		bodyMap.add("domainCookie", domainCookie);
		bodyMap.add("ecpdcookie", ecpdcookie);
		bodyMap.add("MUCFlow", MUCFlow);
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookies(bodyMap).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addPlanAndDevice(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void getReviewOrderDataTest() throws IOException {
		String requestString = "{\"meta\":{},\"data\":{\"cartId\":\"dfd05c21-532a-4ab4-a05e-a9aebb7c7036\"}}";
		String responseString = "{\"flowType\":\"FCL\",\"orderInfo\":{\"totalDueToday\":\"0.0\",\"totalDueMonthly\":\"50.00\",\"showMonthlyPricing\":true,\"taxesSurchargesGovtFees\":{\"showTodayAmount\":true,\"dueToday\":\"0.0\",\"dueMonthlyAmount\":\"Included for 5G Home Internet.*\"},\"items\":[{\"name\":\"Verizon Internet Gateway\",\"dueToday\":\"0.0\",\"dueMonthly\":\"0.0\",\"showMonthlyPricing\":true,\"productId\":\"dev15280028\",\"showTodayPricing\":true,\"installationType\":\"Professional SetUp\",\"showBroadBandInfo\":false,\"thumbnailImageURL\":\"#THUMBNAIL_IMAGE_URL#\",\"displayDueTodaySection\":true,\"displayDueMonthlySection\":false,\"itemType\":\"DEVICE\",\"sorId\":\"ASK-NCQ1338\"},{\"name\":\"5G HOME\",\"dueToday\":\"0.0\",\"dueMonthly\":\"50.00\",\"showMonthlyPricing\":true,\"productId\":\"50127\",\"showTodayPricing\":true,\"showBroadBandInfo\":true,\"displayDueTodaySection\":false,\"displayDueMonthlySection\":true,\"modalContent\":\"#MODAL_CONTENT#\",\"itemType\":\"PLAN\"}]},\"termsAndConditions\":{\"agreementText\":\"<h2>Customer Agreement</h2>\\r\\r\\r<p><em>(Para una copia de este documento en espanol, visite nuestro website: <a target='_blank' href='https://www.verizon.com/espanol' class='link'>verizon.com/espanol)</a></em></p>\\r\\r<p><strong>Thanks for choosing Verizon. In this Customer Agreement (\\\"Agreement\\\"), you'll find important information about your wireless Service, including:</strong></p>\\r\\r<ul>\\r<li><strong>our ability to make changes to your Service or this Agreement's terms,</strong></li>\\r<li><strong>our liability if things don't work as planned and how any disputes between us must be resolved in arbitration or small claims court.</strong></li></ul>\\r\\r\\r<h3>My Service</h3>\\r\\r<p><strong>Your Service terms and conditions are part of this Agreement.</strong> Your Plan includes your monthly allowances and features, where you can use them (your \\\"Coverage Area\\\"), and their monthly and pay&ndash;per&ndash;use charges. You can also subscribe to several Optional Services, like international service plans or equipment protection services. Together, your Plan, features you use, and any Optional Services you select are your Service. Your billing and shipping addresses, and your primary place of use, must be within the areas served by the network Verizon owns and operates. The current version of this Agreement and the terms and conditions for your Service are available online at <a target='_blank' href='https://www.verizon.com' class='link'>verizon.com.</a> A description of permitted and prohibited uses for calling and Data Services is available online at\\r<a target='_blank' href='https://www.verizon.com/support/important-plan-information/' class='link'>verizon.com/support/important-plan-information</a>; prepaid customers should visit <a target='_blank' href='https://www.verizon.com/support/prepaid-customer-info-legal/' class='link'>http://verizon.com/support/prepaid-customer-info-legal.</a></p>\\r\\r\\r<p>By using the Service you are agreeing to every provision of this Agreement whether or not you have read it. This agreement also applies to all lines on your account and anyone who uses your Service.</p> \\r\\r\\r<h3>Cancellation</h3>\\r\\r<p><strong>You can cancel a line of Service within 30 days of accepting this Agreement without having to pay an early termination fee as long as you return, within the applicable return period, any equipment you purchased from us or one of our authorized retailers at a discount in connection with your acceptance of this Agreement, but you'll still have to pay for your Service through that date. If you signed up for Prepaid Service, no refunds will be granted after 30 days or if your account has been activated. See \\r<a target='_blank' href='https://www.vzw.com/support/return-policy' class='link'>http://verizon.com/support/return-policy</a> for complete details and information on returning your equipment.</strong></p>\\r\\r\\r<h3>My Privacy</h3>\\r\\r<p>Accepting this Agreement means that you also agree to our Privacy Policy, available at <a target='_blank' href='https://www.verizon.com/privacy' class='link'>verizon.com/privacy</a>, which may be updated from time to time and describes the information we collect, how we use and share it, and the choices you have about how certain information is used and shared. We will notify you or ask for your permission, as appropriate, if we plan to use your information for additional purposes. It is your responsibility to let the people who connect devices through your mobile hotspot, Jetpack or wireless router know that we will collect, use and share information about their device and use of the Service as described in our Privacy Policy.</p>\\r\\r<p>If you subscribe to Service for which usage charges are billed at the end of the billing period (\\\"Postpay Service\\\"), or have a device payment installment agreement, we may investigate your credit history at any time in connection with the service subscription or device payment installment agreement. If you'd like the name and address of any credit agency that gives us a credit report about you, just ask.</p>\\r\\r<p>Many services and applications offered through your device may be provided by third parties. You should review the applicable terms and privacy policy before you use, link to or download a service or application provided by a third party.</p>\\r\\r<p>You agree that Verizon and collections agencies that work on our behalf may contact you about your account status, including past due or current charges, using prerecorded calls, email and calls or messages delivered by an automatic telephone dialing system to any wireless phone number, other contact number or email address you provide. Verizon will treat any email address you provide as your private email that is only accessible by you; you acknowledge that we may send you receipts, notices and other documents regarding your service to this email address. Unless you notify us that your wireless service is based in a different time zone, calls will be made to your cellular device during permitted calling hours based upon the time zone affiliated with the mobile telephone number you provide.</p>\\r\\r\\r<h3>What happens if my Postpay Service is canceled before the end of my contract term?</h3>\\r\\r<p>If you're signing up for Postpay Service, you're agreeing to subscribe to a line of Service either on a month&ndash;to&ndash;month basis or for a minimum contract term, as shown on your receipt or order confirmation. (If your Service is suspended without billing or at a reduced billing rate, that time doesn't count toward completing your contract term.) Once you've completed your contract term, you'll automatically become a customer on a month&ndash;to&ndash;month basis for that line of Service. <strong>If your line of service has a contract term and you cancel that line, or if we cancel it for good cause, during that contract term, you'll have to pay an early termination fee.  If your contract term results from your purchase of an advanced device, your early termination fee will be &#36;350, which will decline by &#36;10 per month upon completion of months 7&ndash;17, &#36;20 per month upon completion of months 18&ndash;22, &#36;60 upon completion of month 23 and will be &#36;0 upon completion of the contract term. For other contract terms, your early termination fee will be &#36;175, which will decline by &#36;5 per month upon completion of months 7&ndash;17, &#36;10 per month upon completion of months 18&ndash;22, &#36;30 upon completion of month 23 and will be &#36;0 upon completion of your contract term. Cancellations will become effective on the last day of that month's billing cycle,</strong> and you are responsible for all charges incurred until then. Also, if you bought your wireless device from an authorized agent or third&ndash;party vendor, you should check whether it charges a separate termination fee.</p> \\r\\r<p><strong>If you purchased a device on a monthly installment agreement and cancel service, you should check that agreement to determine if you may have to immediately pay off the balance.</strong></p>\\r\\r\\r<h3>Your Mobile Number and Porting.</h3>\\r\\r<p>You may be able to transfer, or \\\"port\\\", your wireless phone number to another carrier. If you port a number from us, we'll treat it as though you asked us to cancel your Service for that number. After the porting is completed, you won't be able to use our service for that number, but you'll remain responsible for all fees and charges through the end of that billing cycle, just like any other cancellation. If you're a Prepaid customer, you won't be entitled to a refund of any balance on your account. If you port a number to us, please be aware that we may not be able to provide some services right away, such as 911 location services. You don't have any rights to your wireless phone number, except for any right you may have to port it. After a line of service is disconnected, for any reason, the disconnected Mobile Telephone Number (MTN) may not be suspended or otherwise reserved and may not be able to be recovered.</p>\\r\\r\\r<h3>Can I have someone else manage my Postpay account?</h3>\\r\\r<p>No problem &ndash; just tell us by phone, in person, or in writing. You can appoint someone to manage your Postpay account. The person you appoint (the Account Manager) will be able to make changes to your account, including adding new lines of Service, buying a new wireless device(s) on a device payment agreement based upon your credit history, billing certain services and accessories to your account, and extending your contract term. Any changes that person makes will be treated as modifications to this Agreement.</p>\\r\\r\\r<h3>Can Verizon change this Agreement or my Service?</h3>\\r\\r<p>We may change prices or any other term of your Service or this Agreement at any time, but we'll provide notice first, including written notice if you have Postpay Service. If you use your Service after the change takes effect that means you're accepting the change. If you're a Postpay customer and a change to your Plan or this Agreement has a material adverse effect on you, you can cancel the line of Service that has been affected within 60 days of receiving the notice with no early termination fee if we fail to negate the change after you notify us of your objection to it. Notwithstanding this provision, if we make any changes to the dispute resolution provision of this Agreement, such changes will not affect the resolution of any disputes that arose before such change.</p>\\r\\r\\r<h3>My wireless device</h3>\\r\\r<p>Your wireless device must comply with Federal Communications Commission regulations, be certified for use on our network, and be compatible with your Service. Please be aware that we may change your wireless device's software, applications or programming remotely, without notice. This could affect your stored data, or how you've programmed or use your wireless device. By activating Service that uses a SIM (Subscriber Identity Module) card, you agree we own the intellectual property and software in the SIM card that we may change the software or other data in the SIM card remotely and without notice, and we may utilize any capacity in the SIM card for administrative, network, business and/or commercial purposes. In order to mitigate theft and other fraudulent activity, newly purchased devices may be locked to work exclusively on the Verizon Network for 60 days. For more information, visit <a target='_blank' href='https://www.verizon.com/support/device-unlocking-policy/' class='link'>verizon.com/support/device-unlocking-policy</a>.</p>\\r\\r\\r<h3>Internet Access</h3>\\r\\r<p><strong>If you download or use applications, services or software provided by third parties (including voice applications), 911 or E911, or other calling functionality, may work differently than services offered by us, or may not work at all. Please review all terms and conditions of such third&ndash;party products. Verizon Wireless is not responsible for any third&ndash;party information, content, applications or services you access, download or use on your device. You are responsible for maintaining virus and other Internet security protections when accessing these third&ndash;party products or services. For additional information, visit the Verizon Content Policy at <a target='_blank' href='https://www.verizon.com/about/our-company/company-policies/' class='link'>verizon.com/about/our-company/company-policies</a>. To learn about content filtering and how you may block materials harmful to minors, visit <a target='_blank' href='https://www.verizon.com/solutions-and-services/content-filters/' class='link'>verizon.com/solutions-and-services/content-filters/</a>. For information about our network management practices for our broadband internet access services visit <a target='_blank' href='https://www.verizon.com/about/our-company/open-internet' class='link'>verizon.com/about/our-company/open-internet</a></strong></p>\\r\\r\\r<h3>Where and how does Verizon wireless Service work?</h3>\\r\\r<p>Wireless devices use radio transmissions, so unfortunately you can't get Service if your device isn't in range of a transmission signal. And please be aware that even within your Coverage Area, many things can affect the availability and quality of your Service, including network capacity, your device, terrain, buildings, foliage and weather.</p>\\r\\r\\r<h3>How does Verizon calculate my charges?</h3>\\r\\r<p>You agree to pay all access, usage and other charges that you or any other user of your wireless device incurred. If multiple wireless devices are associated with your account, you agree to pay all charges incurred by users of those wireless devices. For charges based on the amount of time used or data sent or received, we'll round up any fraction to the next full minute or, depending on how you're billed for data usage, the next full megabyte or gigabyte. For outgoing calls, usage time starts when you first press <strong>Send</strong> or the call connects to a network, and for incoming calls, it starts when the call connects to a network (which may be before it rings). Usage time may end several seconds after you press <strong>End</strong> or after the call disconnects. For calls made on our network, we charge only for calls that are answered, including by machines. For Postpay Service, usage cannot always be processed right away and may be included in a later bill, but the usage will still count towards your allowance for the month when the Service was used.</p>\\r\\r\\r<h3>What Charges are set by Verizon?</h3>\\r\\r<p>Our charges may also include Federal Universal Service, Regulatory\\rand Administrative Charges, and we may also include other charges related to our governmental costs. We set these charges; they aren't taxes, they aren't required by law, they are not necessarily related to anything the government does, they are kept by us in whole or in part, and the amounts and what they pay for may change. For more information, visit: <a target='_blank' href='https://www.verizon.com/support/surcharges/' class='link'>verizon.com/support/surcharges/</a>.</p>\\r\\r\\r<h3>Government Taxes, Fees and Surcharges</h3>\\r\\r<p>You must pay all taxes, fees and surcharges set by federal, state and local governments. Please note that we may not always be able to notify you in advance of changes to these charges.</p>\\r\\r\\r<h3>What is roaming?</h3>\\r\\r<p>You're \\\"roaming\\\" whenever your wireless device connects to a network outside your Coverage Area or connects to another carrier's network, which could happen even within your Coverage Area. There may be higher rates or extra charges (including charges for long distance, tolls or calls that don't connect), and your data service may be limited or slowed, when roaming.</p>\\r\\r\\r<h3>How can I prevent unintended charges on my bill or block spam calls?</h3>\\r\\r<p>Many services and applications are accessible on or through wireless devices, including purchases of games, movies, music and other content. Some of these services are provided by Verizon. Others are provided by third parties that may offer the option to bill the charges to your Verizon bill or other methods of payment. Charges may be one&ndash;time or recurring. The amount and frequency of the charges will be disclosed to you or the person using your device or a device associated with your account at the time a purchase is made. If the purchaser chooses to have the charges billed to your account, such charges will become part of the amount due for that billing cycle. <strong>Verizon offers tools to block or restrict these services, and to block all billing for third&ndash;party services on your Verizon wireless bill, at <a target='_blank' href='https://www.verizonwireless.com/myverizon' class='link'>verizonwireless.com/myverizon</a>. We do not support calls to 900, 976 and certain other international premium rate numbers.</strong></p>\\r\\r<p>Verizon automatically blocks in the network many calls that are highly likely to be illegal, such as calls from telephone numbers that are not authorized to make outbound calls. Additionally, your Service includes access to optional blocking tools for unwanted robocalls through our Call Filter service to which you may be auto&ndash;enrolled.  This service sends to voicemail many calls we determine to be high&ndash;risk spam, but you can adjust your spam filter preferences to block more or less calls. Visit <a target='_blank' href='https://www.verizon.com/about/responsibility/robocalls' class='link'>https://www.verizon.com/about/responsibility/robocalls</a> for more info.</p>\\r\\r<h3>How and when can I dispute charges?</h3>\\r\\r<p>If you're a Postpay customer, you can dispute your bill within 180 days of receiving it, but unless otherwise provided by law or unless you're disputing charges because your wireless device was lost or stolen, you still have to pay all charges until the dispute is resolved. If you're a Prepaid customer, you can dispute a charge within 180 days of the date the disputed charge was incurred. <strong>YOU MAY CALL US TO DISPUTE CHARGES ON YOUR BILL OR ANY SERVICE(S) FOR WHICH YOU WERE BILLED, BUT IF YOU WISH TO PRESERVE YOUR RIGHT TO BRING AN ARBITRATION OR SMALL CLAIMS CASE REGARDING SUCH DISPUTE, YOU MUST WRITE TO US AT THE CUSTOMER SERVICE ADDRESS ON YOUR BILL, OR SEND US A COMPLETED NOTICE OF DISPUTE FORM (AVAILABLE AT VERIZON.COM), WITHIN THE 180&ndash;DAY PERIOD MENTIONED ABOVE. IF YOU DO NOT NOTIFY US IN WRITING OF SUCH DISPUTE WITHIN THE 180&ndash;DAY PERIOD, YOU WILL HAVE WAIVED YOUR RIGHT TO DISPUTE THE BILL OR SUCH SERVICE(S) AND TO BRING AN ARBITRATION OR SMALL CLAIMS CASE REGARDING ANY SUCH DISPUTE.</strong></p>\\r\\r\\r<h3>What are my rights for dropped calls or interrupted Service?</h3>\\r\\r<p>If you drop a call in your Coverage Area, redial. If it's answered within 5 minutes, call us within 90 days if you're a Postpay customer, or within 45 days if you're a Prepaid customer, and we'll give you a 1&ndash;minute airtime credit. If you're a Postpay customer and you lose Service in your Coverage Area for more than 24 hours in a row and we're at fault, call us within 180 days and we'll give you a credit for the time lost. Please be aware that these are your only rights for dropped calls or interrupted Service.</p>\\r\\r\\r\\r<h3>Billing and Payments</h3>\\r\\r<p>If you're a Postpay customer and we don't get your payment on time, we will charge you a late fee of up to 1.5 percent per month (18 percent per year) on the unpaid balance, or a flat &#36;5 per month, whichever is greater, if allowed by law in the state of your billing address. (If you choose to have your Service billed by another company (pursuant to a Verizon&ndash;approved program), late fees are set by that company and may be higher than our late fees.) Late fees are part of the rates and charges you agree to pay. If you fail to pay on time and we refer your account(s) to a third party for collection, a collection fee will be assessed and will be due at the time of the referral to the third party. The fee will be calculated at the maximum percentage permitted by applicable law, not to exceed 18 percent. We may require a deposit at the time of activation or afterward, or an increased deposit. We'll pay simple interest on any deposit at the rate the law requires. We may apply deposits or payments in any order to any amounts you owe us on any account. If your final credit balance is less than &#36;1, we will refund it only if you ask. If your service is suspended or terminated, you may have to pay a fee to have service reactivated.</p>\\r\\r<p>If you're a Prepaid customer, you may replenish your balance at any time before the expiration date by providing us with another payment. If you maintain a Prepaid account balance, it may not exceed &#36;1,000 and you may be prevented from replenishing if your balance reaches &#36;1,000. We may apply your payments to any amounts you may owe us if your earlier account replenishment payments had been reversed. If you do not have sufficient funds in your account to cover your Service, and sufficient funds are not added within 60 days, your account will be cancelled and any unused balance will be forfeited.</p>\\r\\r<p>We may charge you up to &#36;25 for any returned check. The substantive laws of Pennsylvania shall be applied to disputes related to checks tendered as payment in full for less than the full balance due, without regard to the conflicts of laws and rules of that state. If you make a payment, or make a payment arrangement, through a call center representative, we may charge you an Agent Assistance Fee.</p>\\r\\r\\r<h3>What if my wireless device gets lost or stolen?</h3>\\r\\r<p>We're here to help. It's important that you notify us right away, so we can suspend your Service to keep someone else from using it. If you're a Postpay customer and your wireless device is used after the loss or theft but before you report it, and you want a credit for any charges for that usage, we're happy to review your account activity and any other information you'd like us to consider. Keep in mind that you may be held responsible for the charges if you delayed reporting the loss or theft without good reason, but you don't have to pay any charges you dispute while they are being investigated. If you are a California customer and we haven't given you a courtesy suspension of recurring monthly charges during the past year, we'll give you one for 30 days or until you replace or recover your wireless device, whichever comes first.</p>\\r\\r\\r<h3>What are Verizon's rights to limit or end Service or end this Agreement?</h3>\\r\\r<p>We can, without notice, limit, suspend or end your Service or any agreement with you for\\r any good cause, including, but not limited to: (1) if you: (a) breach this agreement or violate our prohibited usage policies; (b) resell your Service; (c) use your Service for any illegal purpose, including use that violates trade and economic sanctions and prohibitions promulgated by any US governmental agency;\\r(d) install, deploy or use any regeneration equipment or similar mechanism (for example, a repeater) to originate, amplify, enhance, retransmit or regenerate an RF signal without our permission; (e) steal from or lie to us; or, if you're a Postpay customer; (f) do not pay your bill on time; (g) incur charges larger than a required deposit or billing limit, or materially in excess of your monthly access charges (even if we haven't yet billed the charges); (h) provide credit information we can't verify;  (i) are unable to pay us or go bankrupt; or (j) default under any device financing agreement with Verizon; or (2) if you, any user of your device or any line of service on your account, or any account manager on your account: (a) threaten, harass, or use vulgar and/or inappropriate language toward our representatives; (b) interfere with our operations; (c) \\\"spam,\\\" or engage in other abusive messaging or calling; (d) modify your device from its manufacturer's specifications; or (e) use your Service in a way that negatively affects our network or other customers. We can also temporarily limit your Service for any operational or governmental reason.</p>\\r\\r\\r<h3>Am I eligible for special discounts?</h3>\\r\\r<p>If you're a Postpay customer, you may be eligible for a discount if you are and remain affiliated with an organization that has an agreement with us. Unless your discount is through a government employee discount program, we may share certain information about your Service (including your name, your wireless telephone number and your total monthly charges) with your organization from time to time to make sure you're still eligible. We may adjust or remove your discount according to your organization's agreement with us, and remove your discount if your eligibility ends or your contract term expires. In any case, this won't be considered to have a material adverse effect on you.</p>\\r\\r\\r<h3>DISCLAIMER OF WARRANTIES</h3>\\r\\r<p><strong>We make no representations or warranties, express or implied, including, to the extent permitted by applicable law, any implied warranty of merchantability or fitness for a particular purpose, about your Service, your wireless device, or any applications you access through your wireless device. We do not warrant that your wireless device will work perfectly or will not need occasional upgrades or modifications, or that it will not be negatively affected by network&ndash;related modifications, upgrades or similar activity.</strong></p>\\r\\r\\r<h3>WAIVERS AND LIMITATIONS OF LIABILITY</h3>\\r\\r<p><strong>You and Verizon both agree to limit claims against each other solely to direct damages. That means neither of us will claim any damages that are indirect, special, consequential, incidental, treble, or punitive. For example, disallowed damages include those arising out of a Service or device failure, unauthorized access or changes to your account or device, or the use of your account or device by others to authenticate, access or make changes to a third&ndash;party account, such as a financial or cryptocurrency account, including changing passwords or transferring or withdrawing funds. This limitation and waiver will apply regardless of the theory of liability. It also applies if you bring a claim against one of our suppliers, to the extent we would be required to indemnify the supplier for the claim. </strong> You agree we aren't responsible for problems caused by you or others, or by any act of God. You also agree we aren't liable for missed or deleted voice mails or other messages, or for any information (like pictures) that gets lost or deleted if we work on your device. If another wireless carrier is involved in any problem (for example, while you're roaming), you also agree to any limitations of liability that it imposes.</p>\\r\\r\\r<div style=\\\"width:auto;height:auto;border:2px solid black; padding: 5px;\\\">\\r\\r<h3>HOW DO I RESOLVE DISPUTES WITH VERIZON?</h3>\\r\\r\\r<p><strong>WE HOPE TO MAKE YOU A HAPPY CUSTOMER, BUT IF THERE'S AN ISSUE THAT NEEDS TO BE RESOLVED, THIS SECTION OUTLINES WHAT'S EXPECTED OF BOTH OF US.</strong></p>\\r\\r<p><strong>YOU AND VERIZON BOTH AGREE TO RESOLVE DISPUTES ONLY BY ARBITRATION OR IN SMALL CLAIMS COURT AS DISCUSSED BELOW. YOU UNDERSTAND THAT BY THIS AGREEMENT YOU ARE GIVING UP THE RIGHT TO BRING A CLAIM IN COURT OR IN FRONT OF A JURY. WHILE THE PROCEDURES IN ARBITRATION MAY BE DIFFERENT, AN ARBITRATOR CAN AWARD YOU THE SAME DAMAGES AND RELIEF, AND MUST HONOR THE SAME TERMS IN THIS AGREEMENT, AS A COURT WOULD. IF THE LAW ALLOWS FOR AN AWARD OF ATTORNEYS' FEES, AN ARBITRATOR CAN AWARD THEM TOO. THE SAME DEFENSES ARE ALSO AVAILABLE TO BOTH PARTIES AS WOULD BE AVAILABLE IN COURT INCLUDING ANY APPLICABLE STATUTE OF LIMITATIONS. WE ALSO BOTH AGREE THAT:</strong></p>\\r\\r<ol>\\r<li>THE FEDERAL ARBITRATION ACT APPLIES TO THIS AGREEMENT. EXCEPT FOR SMALL CLAIMS COURT CASES, ANY DISPUTE THAT IN ANY WAY RELATES TO OR ARISES OUT OF THIS AGREEMENT, OR FROM ANY EQUIPMENT, PRODUCTS AND SERVICES YOU RECEIVE FROM US, OR FROM ANY ADVERTISING FOR ANY SUCH PRODUCTS OR SERVICES, OR FROM OUR EFFORTS TO COLLECT AMOUNTS YOU MAY OWE US FOR SUCH PRODUCTS OR SERVICES, INCLUDING ANY DISPUTES YOU HAVE WITH OUR EMPLOYEES OR AGENTS, WILL BE RESOLVED BY ONE OR MORE NEUTRAL ARBITRATORS BEFORE THE AMERICAN ARBITRATION ASSOCIATION (\\\"AAA\\\") OR BETTER BUSINESS BUREAU (\\\"BBB\\\"). YOU CAN ALSO BRING ANY ISSUES YOU MAY HAVE TO THE ATTENTION OF FEDERAL, STATE, OR LOCAL GOVERNMENT AGENCIES, AND IF THE LAW ALLOWS, THEY CAN SEEK RELIEF AGAINST US FOR YOU. THIS AGREEMENT TO ARBITRATE CONTINUES TO APPLY EVEN AFTER YOU HAVE STOPPED RECEIVING SERVICE FROM US.</li>\\r\\r<li>UNLESS YOU AND VERIZON AGREE OTHERWISE, THE ARBITRATION WILL TAKE PLACE IN THE COUNTY OF YOUR BILLING ADDRESS. FOR CLAIMS OVER &#36;10,000, THE AAA'S CONSUMER ARBITRATION RULES WILL APPLY. FOR CLAIMS OF &#36;10,000 OR LESS, THE PARTY BRINGING THE CLAIM CAN CHOOSE EITHER THE AAA'S CONSUMER ARBITRATION RULES OR THE BBB'S RULES FOR BINDING ARBITRATION. YOU CAN GET PROCEDURES, RULES AND FEE INFORMATION FROM THE AAA (WWW.ADR.ORG), THE BBB (WWW.BBB.ORG) OR FROM US. FOR CLAIMS OF &#36;10,000 OR LESS, YOU CAN CHOOSE WHETHER YOU'D LIKE THE ARBITRATION CARRIED OUT BASED ONLY ON DOCUMENTS SUBMITTED TO THE ARBITRATOR, OR BY A HEARING IN PERSON OR BY PHONE. ALTERNATIVELY, FOR CLAIMS WITHIN THE JURISDICTIONAL LIMIT OF THE SMALL CLAIMS COURT IN THE STATE ENCOMPASSING YOUR BILLING ADDRESS, EITHER YOU OR VERIZON CAN CHOOSE TO BRING AN INDIVIDUAL ACTION IN SMALL CLAIMS COURT INSTEAD OF PROCEEDING IN ARBITRATION; FURTHERMORE, IF THE CLAIMS IN ANY REQUEST OR DEMAND FOR ARBITRATION COULD HAVE BEEN BROUGHT IN SMALL CLAIMS COURT, THEN EITHER YOU OR VERIZON MAY CHOOSE TO HAVE THE CLAIMS HEARD IN SMALL CLAIMS COURT, RATHER THAN IN ARBITRATION, AT ANY TIME BEFORE THE ARBITRATOR IS APPOINTED, BY NOTIFYING THE OTHER PARTY OF THAT CHOICE IN WRITING.  IF THIS PROVISION OR THE LIMITATION ON BRINGING ACTIONS TO SMALL CLAIMS COURT IS FOUND TO BE INVALID, THEN THIS PROVISION SHALL BE SEVERABLE AND THE MATTER WILL PROCEED IN ARBITRATION; IN NO WAY WILL THIS PROVISION ALLOW FOR AN ACTION TO BE BROUGHT ON A CLASS OR COLLECTIVE BASIS.</li>\\r\\r<li><strong>THIS AGREEMENT DOESN'T ALLOW CLASS OR COLLECTIVE ARBITRATIONS EVEN IF THE AAA OR BBB PROCEDURES OR RULES WOULD. NOTWITHSTANDING ANY OTHER PROVISION OF THIS AGREEMENT, THE ARBITRATOR MAY AWARD MONEY OR INJUNCTIVE RELIEF ONLY IN FAVOR OF THE INDIVIDUAL PARTY SEEKING RELIEF AND ONLY TO THE EXTENT NECESSARY TO PROVIDE RELIEF WARRANTED BY THAT PARTY'S INDIVIDUAL CLAIM. NO CLASS, REPRESENTATIVE OR PRIVATE ATTORNEY GENERAL OR GENERAL INJUNCTIVE RELIEF THEORIES OF LIABILITY OR PRAYERS FOR RELIEF MAY BE MAINTAINED IN ANY ARBITRATION HELD UNDER THIS AGREEMENT. ANY QUESTION REGARDING THE ENFORCEABILITY OR INTERPRETATION OF THIS PARAGRAPH SHALL BE DECIDED BY A COURT AND NOT THE ARBITRATOR.</strong></li>\\r\\r<li>IF EITHER OF US INTENDS TO SEEK ARBITRATION UNDER THIS AGREEMENT, THE PARTY SEEKING ARBITRATION MUST FIRST NOTIFY THE OTHER PARTY OF THE DISPUTE IN WRITING AT LEAST 60 DAYS IN ADVANCE OF INITIATING THE ARBITRATION. NOTICE TO VERIZON SHOULD BE SENT TO VERIZON WIRELESS DISPUTE RESOLUTION MANAGER, ONE VERIZON WAY, BASKING RIDGE, NJ 07920. THE NOTICE MUST INCLUDE ENOUGH INFORMATION TO ALLOW US TO IDENTIFY YOUR ACCOUNT AS WELL AS TO ASSESS AND ATTEMPT TO RESOLVE YOUR CLAIM, INCLUDING THE NAME OF THE VERIZON WIRELESS ACCOUNT HOLDER, THE MOBILE TELEPHONE NUMBER AT ISSUE, A DESCRIPTION OF THE CLAIM, THE SPECIFIC FACTS SUPPORTING THE CLAIM, THE DAMAGES YOU CLAIM TO HAVE SUFFERED AND THE RELIEF YOU ARE SEEKING. THE NOTICE REQUIREMENT IS DESIGNED TO ALLOW VERIZON TO MAKE A FAIR, FACT&ndash;BASED OFFER OF SETTLEMENT IF IT CHOOSES TO DO SO. YOU CANNOT PROCEED TO ARBITRATION UNLESS YOU PROVIDE THIS INFORMATION. YOU MAY CHOOSE TO BE REPRESENTED BY AN ATTORNEY OR OTHER PERSON AS PART OF THIS PROCESS, BUT IF YOU DO YOU MUST SUBMIT A LETTER OR THE FORM AVAILABLE AT THIS LINK AUTHORIZING US TO DISCUSS YOUR ACCOUNT INFORMATION WITH THIS ATTORNEY OR OTHER PERSON. THE SUFFICIENCY OF THIS NOTICE IS AN ISSUE TO BE DECIDED BY A COURT PRIOR TO THE FILING OF ANY DEMAND FOR ARBITRATION. IF YOU HAVE PROVIDED THIS INFORMATION AND WE ARE UNABLE TO RESOLVE OUR DISPUTE WITHIN 60 DAYS, EITHER PARTY MAY THEN PROCEED TO FILE A CLAIM FOR ARBITRATION. WE'LL REIMBURSE ANY FILING FEE THAT THE AAA OR BBB CHARGES YOU FOR ARBITRATION OF THE DISPUTE AT THE CONLCUSION OF THE ARBITRATION IF YOU FULLY PARTICIPATE IN THE PROCEEDING. WE'LL ALSO PAY ANY ADMINISTRATIVE AND ARBITRATOR FEES CHARGED BY THE ARBITRATION TRIBUNAL. IF THE ARBITRATOR DETERMINES THAT YOUR CLAIM WAS FILED FOR PURPOSES OF HARASSMENT OR IS PATENTLY FRIVOLOUS, THE ARBITRATOR WILL REQUIRE YOU TO REIMBURSE VERIZON FOR ANY FILING, ADMINISTRATIVE OR ARBITRATOR FEES ASSOCIATED WITH THE ARBITRATION.</li>\\r\\r<li>WE MAY, BUT ARE NOT OBLIGATED TO, MAKE A WRITTEN SETTLEMENT OFFER ANYTIME BEFORE THE ARBITRATION HEARING. THE AMOUNT OR TERMS OF ANY SETTLEMENT OFFER MAY NOT BE DISCLOSED TO THE ARBITRATOR UNTIL AFTER THE ARBITRATOR ISSUES AN AWARD ON THE CLAIM. IF YOU DON'T ACCEPT THE OFFER AND THE ARBITRATOR AWARDS YOU AN AMOUNT OF MONEY THAT'S MORE THAN OUR OFFER BUT LESS THAN &#36;5,000, OR IF WE DON'T MAKE YOU AN OFFER, AND THE ARBITRATOR AWARDS YOU ANY AMOUNT OF MONEY BUT LESS THAN &#36;5,000, THEN WE AGREE TO PAY YOU &#36;5,000 INSTEAD OF THE AMOUNT AWARDED. IN THAT CASE WE ALSO AGREE TO PAY ANY REASONABLE ATTORNEYS' FEES AND EXPENSES, REGARDLESS OF WHETHER THE LAW REQUIRES IT FOR YOUR CASE. IF THE ARBITRATOR AWARDS YOU MORE THAN &#36;5,000, THEN WE WILL PAY YOU ONLY THAT AMOUNT.</li>\\r\\r<li>IF 25 OR MORE CUSTOMERS INITIATE NOTICES OF DISPUTE WITH VERIZON WIRELESS RAISING SIMILAR CLAIMS, AND COUNSEL FOR THE VERIZON WIRELESS CUSTOMERS BRINGING THE CLAIMS ARE THE SAME OR COORDINATED FOR THESE CUSTOMERS, THE CLAIMS SHALL PROCEED IN ARBITRATION IN A COORDINATED PROCEEDING.  COUNSEL FOR THE VERIZON WIRELESS CUSTOMERS AND COUNSEL FOR VERIZON WIRELESS SHALL EACH SELECT FIVE CASES TO PROCEED FIRST IN ARBITRATION IN A BELLWETHER PROCEEDING.  THE REMAINING CASES SHALL NOT BE FILED IN ARBITRATION UNTIL THE FIRST TEN HAVE BEEN RESOLVED.  IF THE PARTIES ARE UNABLE TO RESOLVE THE REMAINING CASES AFTER THE CONCLUSION OF THE BELLWETHER PROCEEDING, EACH SIDE MAY SELECT ANOTHER FIVE CASES TO PROCEED TO ARBITRATION FOR A SECOND BELLWETHER PROCEEDING.  THIS PROCESS MAY CONTINUE UNTIL THE PARTIES ARE ABLE TO RESOLVE ALL OF THE CLAIMS, EITHER THROUGH SETTLEMENT OR ARBITRATION. A COURT WILL HAVE AUTHORITY TO ENFORCE THIS CLAUSE AND, IF NECESSARY, TO ENJOIN THE MASS FILING OF ARBITRATION DEMANDS AGAINST VERIZON.</li>\\r\\r<li>AN ARBITRATION AWARD AND ANY JUDGMENT CONFIRMING IT APPLY ONLY TO THAT SPECIFIC CASE; IT CAN'T BE USED IN ANY OTHER CASE EXCEPT TO ENFORCE THE AWARD ITSELF.</li>\\r\\r<li><strong>IF FOR SOME REASON THE PROHIBITION ON CLASS ARBITRATIONS SET FORTH IN SUBSECTION (3) CANNOT BE ENFORCED AS TO ALL OR PART OF A DISPUTE, THEN THE AGREEMENT TO ARBITRATE WILL NOT APPLY TO THAT DISPUTE OR PART OF THE DISPUTE.</strong></li>\\r\\r<li><strong>IF FOR ANY REASON A CLAIM PROCEEDS IN COURT RATHER THAN THROUGH ARBITRATION, YOU AND VERIZON AGREE THAT THERE WILL NOT BE A JURY TRIAL. YOU AND VERIZON UNCONDITIONALLY WAIVE ANY RIGHT TO TRIAL BY JURY IN ANY ACTION, PROCEEDING OR COUNTERCLAIM ARISING OUT OF OR RELATING TO THIS AGREEMENT IN ANY WAY. IN THE EVENT OF LITIGATION, THIS PARAGRAPH MAY BE FILED TO SHOW A WRITTEN CONSENT TO A TRIAL BY THE COURT.</strong></li></ol></div>\\r\\r\\r<h3>About this Agreement</h3>\\r\\r<p>If either you or we don't enforce our rights under this agreement in one instance, that doesn't mean you or we won't or can't enforce those rights in any other instance. You cannot assign this Agreement or any of your rights or duties under it without our permission. However, we may assign this Agreement or any debt you owe us without notifying you. <strong>If you're a Postpay customer, please note that many notices we send to you will show up as messages on your monthly bill. If you have online billing, those notices will be deemed received by you when your online bill is available for viewing. If you get a paper bill, those notices will be deemed received by you three days after we mail the bill to you. If we send other notices to you, they will be considered received immediately if we send them to your wireless device, or to any email or fax number you've given us, or after three days if we mail them to your billing address. If you need to send notices to us, please send them to the customer service address on your latest bill.</strong></p>\\r\\r<p><strong>If you're a Prepaid customer and we send notices to you, they will be considered received immediately if we send them to your wireless device or to any email you've given us, or if we post them as a precall notification on your Service, or after three days if we mail them to the most current address we have for you. If you need to send notices to us, please send them to the Customer Service Prepaid address at <a target='_blank' href='https://www.verizon.com/contactus' class='link'>verizon.com/contactus</a></strong></p>\\r\\r<p><strong>If any part of this agreement, including anything regarding the arbitration process (except for the prohibition on class arbitrations as explained in part 8 of the dispute resolution section above), is ruled invalid, that part may be removed from this agreement.</strong></p>\\r\\r<p><strong>This agreement and the documents it incorporates form the entire agreement between us. You can't rely on any other documents, or on what's said by any Sales or Customer Service Representatives, and you have no other rights regarding Service or this agreement.</strong> This Agreement isn't for the benefit of any third party except our parent companies, affiliates, subsidiaries, agents, and predecessors and successors in interest. Except where we've agreed otherwise elsewhere in this agreement, this agreement and any disputes covered by it are governed by federal law and the laws of the state encompassing the area code of your wireless phone number when you accepted this agreement, without regard to the conflicts of laws and rules of that state.</p>\\r\\r\\r<p>Updated: October 20, 2021.</p>\",\"agreementTextHeader\":\"Customer Agreement\",\"deviceName\":\"#DEVICE_NAME#\",\"termsAndConditions5G\":\"<h2>Verizon LTE Home Internet Terms of Service</h2>\\r\\r<p>These Terms of Service (\\\"TOS\\\") are between you and Verizon Wireless (\\\"VZW\\\", \\\"We\\\", \\\"Us\\\") and they set forth the terms and conditions under which you agree to use and we agree to provide the Verizon LTE Home Internet service (\\\"Service\\\"). By using the Service, you are agreeing to every provision of these TOS, whether or not you have read them.</p>\\r\\r<ol type=\\\"1\\\">\\r<li><strong>Customer Agreement.</strong> Your use of the Service also is subject to all of the terms in your Verizon Wireless Customer Agreement. The current version of the Customer Agreement can be found at: <u>www.verizonwireless.com/b2c/support/customer-agreement.</u></li>\\r\\r<li><strong>Service Availability and Use.</strong> Unfortunately, we can't guarantee that our LTE Home Internet service will be available at your address, even if we accept your order and you attempt to install it. The service is to be used only for typical residential purposes in a single residential unit.  If you use the Service for purposes that are not typically residential, if you make the Service available to others to use outside of your residential unit, or if you relocate the equipment used to provide you Service without notifying us and receiving our consent as described herein, we may suspend or terminate the Service without notice.  The Service does not support static IP addresses and may not be compatible with some live TV streaming services (you should verify compatibility with your streaming provider).</li>\\r\\r<li><strong>Equipment.</strong> You must use equipment that is certified by VZW, which will include an LTE Home Router and also may include a separate LTE Home Antenna (if necessary), in order to use the Service. Please note that the LTE Home Router can only be used with the LTE Home Internet service. It will not function on any other carriers' networks. The LTE Home Router also contains a Subscriber Identity Module (SIM) card that is only authorized for use in the LTE Home Router. You may not remove the SIM and insert it into another device, and if you do so, it will be considered a violation of these TOS, which will give us the right to suspend or terminate your Service without notice. </li>\\r\\r<li><strong>Permitted Uses.</strong> You can use the Service for accessing the Internet and for such uses as: (i) Internet browsing; (ii) email; (iii) intranet access (including accessing corporate intranets, email and individual productivity applications made available by your company); (iv) uploading, downloading and streaming of audio, video and games; and (v) Voice over Internet Protocol (VoIP).</li>\\r\\r<li><strong>Prohibited Uses. You may not use the Service for illegal purposes or purposes that infringe upon others' intellectual property rights, or in a manner that interferes with other users' service; that violates trade and economic sanctions and prohibitions as promulgated by the departments of Commerce, Treasury or any other U.S. government agency; that interferes with the network's ability to fairly allocate capacity among users. Examples of prohibited usage include: (i) server devices or host computer applications that are broadcast to multiple servers or recipients such that they could enable \\\"bots\\\" or similar routines (as set forth in more detail in (ii) below) or otherwise degrade network capacity or functionality; (ii) \\\"auto&ndash;responders,\\\" \\\"cancel&ndash;bots,\\\" or similar automated or manual routines that generate amounts of net traffic that could disrupt net user groups or e&ndash;mail use by others; (iii) generating \\\"spam\\\" or unsolicited commercial or bulk e&ndash;mail (or activities that facilitate the dissemination of such e&ndash;mail); (iv) any activity that adversely affects the ability of other users or systems to use either Verizon Wireless' services or the Internet&ndash;based resources of others, including the generation or dissemination of viruses, malware, or \\\"denial of service\\\" attacks; (v) accessing, or attempting to access without authority, the information, accounts or devices of others, or to penetrate, or attempt to penetrate, Verizon Wireless' or another entity's network or systems; or (vi) running software or other devices that maintain continuous active Internet connections when a computer's connection would otherwise be idle, or \\\"keep alive\\\" functions, unless they adhere to Verizon Wireless' requirements for such usage, which may be changed from time to time.\\r<br />\\r\\rWe further reserve the right to take measures to protect our network and other users from harm, compromised capacity or degradation in performance. These measures may impact your service, and we reserve the right to deny, modify or terminate service, with or without notice, to anyone we believe is using the Service in a manner that adversely impacts our network. We may monitor your compliance, or the compliance of other subscribers, with these terms and conditions, but we will not monitor the content of your communications, except as otherwise expressly permitted or required by law. See <u>Verizon's Privacy Policy.</u></strong>\\r</li>\\r\\r<li><strong>Installation/Setup.</strong> You are responsible for setting up the equipment needed to provide the Service to your residence. You should carefully follow the installation/setup instructions provided in the box(es) and on the My Verizon app. The Service includes 30 days of free telephone setup support to assist with installation and setup, should you need it.</li>\\r\\r<li><strong>Changing Service Location.</strong> You may not move the equipment or use the Service at another address without our authorization. If you are moving to a new address and wish to continue using Service, please contact us to confirm coverage and whether you can install/set up the Service at your new address. If you move without notifying us, we may not be able to provide the Service to you, and may suspend or terminate your Service without notice.</li>\\r\\r<li><strong>Additional Cancellation and Equipment Return Information.</strong> You may cancel Service for any reason within 30 days of accepting these TOS, and if you purchased an LTE Home Router under VZW’s Device Payment Plan (DPP), you also must return that equipment, within the applicable return period, but you'll still have to pay for your Service through that date. See <u>vzw.com/returnpolicy</u></li>\\r</ol>\\r\\r\\r<p>Last updated: 06/09/21.</p>\",\"termsAndConditions5GHeader\":\"Verizon 5G Home Internet Terms of Service\"}}";
		String cartId="dfd05c21-532a-4ab4-a05e-a9aebb7c7036";
		URI url = URI.create("http://localhost/cart/5g/cbd/getReviewOrderDatay");
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("GLOBALID", "VZW-DOTCOM");
		httpHeaders.add("channelId", "Digital");
		httpHeaders.add("digital_ig_session", "digital_ig_session_12345");
		HttpCookie cookie = new HttpCookie("GLOBALID", "VZW-DOTCOM");

		GetCartDetailsRequest getCartDetailsRequest = mapper.readValue(requestString, GetCartDetailsRequest.class);
		ReviewOrderData reviewOrderData = mapper.readValue(responseString, ReviewOrderData.class);

		MockServerHttpRequest httpHeader = MockServerHttpRequest.post(url.toString()).headers(httpHeaders).cookie(cookie).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		InspicioResponseOrderInfo inspicioResponseOrderInfo=new InspicioResponseOrderInfo();
		InspicioTermsAndConditions inspicioTermsAndConditions =new InspicioTermsAndConditions();
		when(redisHelper2.getCartIdFromRedis()).thenReturn(Mono.just(cartId));
		when(fiveGhomeTechHelper.getTechCbandCart5GCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(inspicioResponseOrderInfo));
		when(readCartHelper.getAgreementDetails(Mockito.any())).thenReturn(Mono.just(inspicioTermsAndConditions));
		//when(inspicioResponseOrderInfo.zipWith(Mockito.any())).thenReturn(Mono.just(reviewOrderData));
		Mono<ReviewOrderData> controllerResponse = cartController.retrieveReviewOrderTechCbandData(httpHeader, httpResponse,getCartDetailsRequest);
		//StepVerifier.create(controllerResponse).assertNext(resp -> org.junit.Assert.assertEquals(controllerResponse, resp)).expectComplete().verify();
		StepVerifier.create(controllerResponse).assertNext(resp -> org.junit.Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void crmRetriveCart1Test() throws IOException {
		String requestString =  "{\"cartId\":\"852a8e01-a83a-4c38-b082-bf90edd6e838\",\"customerType\":\"N\",\"accountNumber\":\"\",\"lqData\":{\"networkBandwidthType\":\"MMW\",\"lineActivityType\":\"NSE_5G\",\"eligible5GHomeBundle\":[{\"bundleName\":\"5GHomeGeminiSelfSetup\",\"id\":\"16900001\"},{\"bundleName\":\"5GHomeGeminiProfSetup\",\"id\":\"16900002\"}],\"cart5GAddress\":{\"addressLine1\":\"800 S OGDEN ST\",\"city\":\"DENVER\",\"state\":\"CO\",\"zipCode\":\"80209\",\"zipCode4\":\"\",\"county\":\"\",\"countryCode\":\"\",\"fipsCode\":\"0803120000\",\"emailId\":\"\"}}}";
		String responseString = "{\"serviceHeader\":{\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"GetCases\",\"userId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"customerInfo\":{\"customerType\":\"N\",\"cartId\":\"89859655-b722-4199-955a-6160389d03f2\",\"accountNumber\":\"\",\"cartCreator\":\"SIT1-NSA-29-10-12-13-PM-D\",\"emailId\":\"\",\"registerNumber\":0},\"cases\":[{\"processStep\":\"ShoppingCart\",\"preConfiguredCartTypeDuringAddDevice\":\"BAU\",\"cartCreator\":\"SIT1-NSA-29-10-12-12-PM-D\",\"pxUpdateDateTime\":\"20211029T064236.293 GMT\",\"cartId\":\"89859655-b722-4199-955a-6160389d03f2\",\"caseID\":\"SOP-5113066-E01\",\"emailId\":\"\",\"channelId\":\"VZW-DOTCOM\",\"intent\":\"NSE_5G\",\"quoteId\":\"\",\"amRole\":\"\",\"callReason\":\"Sales Order Purchase\",\"pxCreateDateTime\":\"20211029T064227.933 GMT\",\"lineCreator\":\"\",\"lastActiveChannelID\":\"VZW-DOTCOM\",\"explicit_lock\":\"\"}]}}}}";
		CrmResumeCartUIRequest request = mapper.readValue(requestString, CrmResumeCartUIRequest.class);
		request.setEmailId("abc@gmail.com");
		CrmRetrieveCartUIResponse response = mapper.readValue(responseString, CrmRetrieveCartUIResponse.class);
		URI url = URI.create("/5g/crmResumeCart");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(redisHelper3.getAccountNumberFromRedis(Mockito.any())).thenReturn(Mono.just(""));
		when(sessionBean.getSessionData(Mockito.any(),Mockito.any())).thenReturn(Mono.just(""));
		when(readCartHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(bpmHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(redisHelper3.updateCrmResumeDataIntoRedisAsString(Mockito.any())).thenReturn(Mono.just(true));

		when(readCartHelper.crmRetrieveCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(response));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.crmRetrieveCart(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void crmRetriveCart_CXPErrorTest() throws IOException {
		String requestString =  "{\"cartId\":\"852a8e01-a83a-4c38-b082-bf90edd6e838\",\"customerType\":\"N\",\"accountNumber\":\"\",\"lqData\":{\"networkBandwidthType\":\"MMW\",\"lineActivityType\":\"NSE_5G\",\"eligible5GHomeBundle\":[{\"bundleName\":\"5GHomeGeminiSelfSetup\",\"id\":\"16900001\"},{\"bundleName\":\"5GHomeGeminiProfSetup\",\"id\":\"16900002\"}],\"cart5GAddress\":{\"addressLine1\":\"800 S OGDEN ST\",\"city\":\"DENVER\",\"state\":\"CO\",\"zipCode\":\"80209\",\"zipCode4\":\"\",\"county\":\"\",\"countryCode\":\"\",\"fipsCode\":\"0803120000\",\"emailId\":\"\"}}}";
		String responseString = "{\"serviceHeader\":{\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"GetCases\",\"userId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"customerInfo\":{\"customerType\":\"N\",\"cartId\":\"89859655-b722-4199-955a-6160389d03f2\",\"accountNumber\":\"\",\"cartCreator\":\"SIT1-NSA-29-10-12-13-PM-D\",\"emailId\":\"\",\"registerNumber\":0},\"cases\":[{\"processStep\":\"ShoppingCart\",\"preConfiguredCartTypeDuringAddDevice\":\"BAU\",\"cartCreator\":\"SIT1-NSA-29-10-12-12-PM-D\",\"pxUpdateDateTime\":\"20211029T064236.293 GMT\",\"cartId\":\"89859655-b722-4199-955a-6160389d03f2\",\"caseID\":\"SOP-5113066-E01\",\"emailId\":\"\",\"channelId\":\"VZW-DOTCOM\",\"intent\":\"NSE_5G\",\"quoteId\":\"\",\"amRole\":\"\",\"callReason\":\"Sales Order Purchase\",\"pxCreateDateTime\":\"20211029T064227.933 GMT\",\"lineCreator\":\"\",\"lastActiveChannelID\":\"VZW-DOTCOM\",\"explicit_lock\":\"\"}]}}}}";
		CrmResumeCartUIRequest request = mapper.readValue(requestString, CrmResumeCartUIRequest.class);
		request.setEmailId("abc@gmail.com");
		CrmRetrieveCartUIResponse response = new CrmRetrieveCartUIResponse();
		List<CartError> erros=new ArrayList<CartError>();
		response.setErrors(erros);
		URI url = URI.create("/5g/crmResumeCart");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(redisHelper3.getAccountNumberFromRedis(Mockito.any())).thenReturn(Mono.just(""));
		when(sessionBean.getSessionData(Mockito.any(),Mockito.any())).thenReturn(Mono.just(""));
		when(readCartHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(bpmHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(redisHelper3.updateCrmResumeDataIntoRedisAsString(Mockito.any())).thenReturn(Mono.just(true));

		when(readCartHelper.crmRetrieveCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(response));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.crmRetrieveCart(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test  // updateProcessStep
	public void updateProcessStep1Test() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"newLine1\",\"processStep\":\"InstallType\",\"processAction\":\"Complete\",\"intendType\":\"AAL_5G\",\"bundleInstallType\":\"\"},\"data\":{}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4387896-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"0280000250-00001\",\"cartCreator\":\"3166127651\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"existingCase\":\"\"},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"9978549b-aa29-4d8e-b09e-e4c7256da6da\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"InstallType\"]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"InstallType\"]}]}}}}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);// AddPlanAndDeviceUIResponse

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("channelId","digital");
		MockServerHttpRequest request1 = MockServerHttpRequest.post("foo/bar")
				.headers(httpHeaders).build();

		URI url = URI.create("http://localhost/5g/updateProcessStep");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(request)).thenReturn(Mono.just(response));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
		when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));

		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.updateProcessStep(request1, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test  // updateProcessStep
	public void updateProcessStepConditionCheckTest() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"newLine1\",\"processStep\":\"InstallType\",\"processAction\":\"Complete\",\"intendType\":\"AAL_5G\",\"bundleInstallType\":\"\"},\"data\":{}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4387896-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"0280000250-00001\",\"cartCreator\":\"3166127651\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"existingCase\":\"\"},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"InstallType\"]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"InstallType\"]}]}}}}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);// AddPlanAndDeviceUIResponse

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("channelId","digital");
		MockServerHttpRequest request1 = MockServerHttpRequest.post("foo/bar")
				.headers(httpHeaders).build();

		URI url = URI.create("http://localhost/5g/updateProcessStep");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(request)).thenReturn(Mono.just(response));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
		when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));

		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.updateProcessStep(request1, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void saveCartWithEmail1Test() throws IOException {
		String requestString = "{\"emaild\":\"usha.kammara@veriozn.com\",\"intendType\":\"NSE_LTE\"}";
		String responseString = "{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"correlationId\":\"POE-D-e81378f9-d693-4234-802a-41019e24e4c3\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4346627-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\"},\"customerInfo\":{\"customerType\":\"N\",\"originalCreditApprovalNumber\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-e81378f9-d693-4234-802a-41019e24e4c3\",\"processingMTN\":\"\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"4221df0b-f63d-46f4-b59a-43edb32c8675\",\"statusMsg\":\"Save cart data updated successfully\",\"statusCode\":\"1\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"ShoppingCart\"]},{\"mtn\":\"\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"ShoppingCart\"]}]}}}}";
		SaveCartWithEmailUIRequest request = mapper.readValue(requestString, SaveCartWithEmailUIRequest.class);
		AddPlanAndDeviceUIResponse response = new AddPlanAndDeviceUIResponse();
		List<CartError> erros=new ArrayList<CartError>();
		response.setErrors(erros);
		URI url = URI.create("http://localhost/5g/saveCartWithEmail");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.saveCartWithEmail(request)).thenReturn(Mono.just(response));

		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.saveCartWithEmail(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void retrieveFiveGCart1Test() throws IOException {
		String requestString = "{\"meta\":{},\"data\":{\"cartId\":\"b58e3b4d-f13c-440d-8ca8-465f4856a16b\"}}";
		String responseString = "{\"cartHeader\":{\"vendorId\":\"VZWCOM\",\"sourceSystem\":\"VZW-DOTCOM\",\"cartId\":\"b58e3b4d-f13c-440d-8ca8-465f4856a16b\",\"fullAccountNumber\":\"0282354804-1\",\"status\":\"A\",\"createTimestamp\":\"2021-10-11T05:50:50.450965-04:00[US/Eastern]\",\"lastUpdateTimestamp\":\"2021-10-11T05:51:45.828807-04:00[US/Eastern]\",\"cartCreator\":\"7326726656\",\"cartCreatorChannelId\":\"VZW-DOTCOM\",\"cartCreatorOrderLocationCode\":\"D463801\",\"cartCreatorSalesRepId\":\"EZ706\",\"caseId\":\"SOP-4604006-E01\",\"visionCustomerType\":\"PE\",\"maverickLocation\":false,\"preConfiguredCartType\":\"BAU\",\"preConfiguredCartTypeDuringAddDevice\":\"BAU\",\"isCoreRep\":false},\"orderDetailsView\":{\"dueTodayAmount\":\"0.0\",\"dueMonthlyAmount\":\"60.0\",\"orderActivityType\":\"AAL\",\"totalShippingCost\":\"null\",\"totalDiscountedShippingCost\":\"null\",\"installType\":\"Professional SetUp\",\"orderNumber\":\"3117431\",\"locationCode\":\"D463801\",\"orderType\":\"PS\",\"numOfLines\":\"1\",\"hiddenPromos\":[\"wireless-offer\"]},\"dueTodayList\":[{\"name\":\"5G Internet Gateway\",\"installationType\":\"Professional SetUp\",\"discountApplied\":\"0.0\",\"actualAmount\":\"0.0\",\"totalAmountWithDiscount\":\"0.0\",\"productId\":\"16900002\",\"sorId\":\"LVSKIHP\",\"itemType\":\"DEVICE\",\"quantity\":\"1\",\"taxAmount\":\"0.0\",\"lineNumber\":\"newLine1\",\"multiLineSeqNumber\":1,\"isBackorder\":\"false\",\"preBackDate\":\"\"}],\"dueMonthlyList\":[{\"name\":\"5G HOME INTERNET\",\"actualAmount\":\"80.0\",\"totalAmountWithDiscount\":\"60.0\",\"productId\":\"39425\",\"itemType\":\"PLAN\"}],\"dueMonthlyTaxes\":[{\"dueAmount\":\"0.0\"}],\"dueTodayTaxes\":[{\"dueAmount\":\"0.0\"}],\"shippingDetails\":[{\"address\":{\"apartmentNo\":\"\",\"type\":\"R\",\"streetNumber\":\"125\",\"streetName\":\"SAINT NICHOLAS\",\"addressLine2\":\"\",\"addressLine1\":\"125 SAINT NICHOLAS AVE\",\"city\":\"SOUTH PLAINFIELD\",\"state\":\"NJ\",\"zipCode\":\"07080\",\"zipCode4\":\"1807\",\"county\":\"\",\"countryCode\":\"\",\"fipsCode\":\"3402369390\",\"firstName\":\"JACK\",\"lastName\":\"MANUEL\",\"emailId\":\"QVOOLN64Z7@VZW.COM\",\"phoneNumber\":\"3453350350\",\"streetType\":\"AVE\",\"streetDirection\":\"\"},\"cbrPhone\":\"3453350350\",\"firstName\":\"JACK\",\"lastName\":\"MANUEL\",\"midInitials\":\"J\",\"isUseUnVerifiedAddress\":false,\"isValidAddress\":false,\"email\":\"QVOOLN64Z7@VZW.COM\"}],\"payments\":[],\"primaryUserInfo\":{\"firstName\":\"JACK\",\"lastName\":\"MANUEL\",\"address\":{\"firmName\":\"\",\"apartmentNo\":\"\",\"type\":\"AVE\",\"streetNumber\":\"125\",\"streetName\":\"SAINT NICHOLAS\",\"addressLine2\":\"\",\"addressLine1\":\"125 SAINT NICHOLAS AVE\",\"poBoxNo\":\"\",\"ruralRouteNo\":\"\",\"ruralDelNo\":\"\",\"city\":\"SOUTH PLAINFIELD\",\"state\":\"NJ\",\"zipCode\":\"07080\",\"zipCode4\":\"1807\",\"county\":\"\",\"countryCode\":\"US\",\"fipsCode\":\"3402369390\",\"firstName\":\"JACK\",\"lastName\":\"MANUEL\",\"emailId\":\"QVOOLN64Z7@VZW.COM\",\"phoneNumber\":\"3453350350\",\"streetType\":\"AVE\",\"streetDirection\":\"\"},\"isValidAddress\":true,\"bsnsName\":\"\",\"emailId\":\"QVOOLN64Z7@VZW.COM\"},\"cart5GAddress\":{\"addressLine1\":\"800 S OGDEN ST\",\"city\":\"DENVER\",\"state\":\"CO\",\"zipCode\":\"80209\",\"zipCode4\":\"\",\"countryCode\":\"\",\"fipsCode\":\"0803120000\",\"floor\":0},\"registrationDetails\":{}}";
		GetCartDetailsRequest request = mapper.readValue(requestString, GetCartDetailsRequest.class);
		GetCartDetailsUIResponse response = mapper.readValue(responseString, GetCartDetailsUIResponse.class);
		URI url = URI.create("http://localhost/5g/retrieve-cart");
		MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
		HttpCookie httpCookieAffiliate  = new HttpCookie(CartConstants.AFFILIATE, null );
		HttpCookie httpCookieCjevent  = new HttpCookie(CartConstants.CJEVENT, null);
		bodyMap.add(CartConstants.CJEVENT, httpCookieCjevent);
		bodyMap.add(CartConstants.AFFILIATE, httpCookieAffiliate);
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		request.getData().setValidateCart(true);
		when(fiveGhomeNSEHelper.get5GCart(request)).thenReturn(Mono.just(ResponseEntity.status(200).body(response)));
		when(redisHelper.upsertRetrieveCartDataIntoRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		when(fiveGhomeAALHelper.get5GValidateCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(ResponseEntity.status(200).body(response)));

		Mono<ResponseEntity<GetCartDetailsUIResponse>> controllerResponse = cartController.retrieveFiveGCart(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()	.verify();
	}

	@Test  // Gen2-Gen3 retrieve-cart
	public void swapFiveGRetrieveCartChannelIdTest() throws IOException {
		String requestString = "{\"meta\":{},\"data\":{\"cartId\":\"2a74d680-a043-4d53-8836-802edb5c7e49\"}}";
		String responseString = "{\"cartHeader\":{\"vendorId\":\"VZWCOM\",\"sourceSystem\":\"VZW-DOTCOM\",\"cartId\":\"2a74d680-a043-4d53-8836-802edb5c7e49\",\"fullAccountNumber\":\"0430568040-1\",\"status\":\"A\",\"createTimestamp\":\"2021-10-19T09:56:24.043067-04:00[US/Eastern]\",\"lastUpdateTimestamp\":\"2021-10-19T09:56:25.288929-04:00[US/Eastern]\",\"cartCreator\":\"8135199979\",\"cartCreatorChannelId\":\"VZW-DOTCOM\",\"cartCreatorOrderLocationCode\":\"1456801\",\"cartCreatorSalesRepId\":\"NPB2C\",\"caseId\":\"SOP-4629485-E01\",\"visionCustomerType\":\"PE\",\"maverickLocation\":false,\"preConfiguredCartType\":\"BAU\",\"preConfiguredCartTypeDuringAddDevice\":\"BAU\",\"isCoreRep\":false},\"orderDetailsView\":{\"dueTodayAmount\":\"0.0\",\"dueMonthlyAmount\":\"0.0\",\"totalShippingCost\":\"null\",\"totalDiscountedShippingCost\":\"null\",\"locationCode\":\"1456801\",\"orderType\":\"PS\",\"numOfLines\":\"1\"},\"dueTodayList\":[],\"dueTodayTaxes\":[{\"dueAmount\":\"0.0\"}]}";
		GetCartDetailsRequest request = mapper.readValue(requestString, GetCartDetailsRequest.class);
		GetCartDetailsUIResponse response = mapper.readValue(responseString, GetCartDetailsUIResponse.class);// AddPlanAndDeviceUIResponse
		URI url = URI.create("http://localhost/5g/swap/retrieve-cart");
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("GLOBALID", "VZW-DOTCOM");
		httpHeaders.add("channelId", "Digital");
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(httpHeaders).build();
		when(fiveGhomeTechHelper.getSwap5GCart(request, httpResponse)).thenReturn(Mono.just(ResponseEntity.status(200).body(response)));
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
		when(redisHelper.upsertRetrieveCartDataIntoRedis(any())).thenReturn(Mono.just(Boolean.TRUE));

		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.swapFiveGRetrieveCart(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test  // Gen2-Gen3 order-confirmation
	public void swapOrderConfirmationChannelIdTest() throws IOException {
		String requestString = "{\"meta\":{},\"data\":{\"cartId\":\"b58e3b4d-f13c-440d-8ca8-465f4856a16b\"}}";
		String responseString = "{\"cartHeader\":{\"vendorId\":\"VZWCOM\",\"sourceSystem\":\"VZW-DOTCOM\",\"cartId\":\"964f96a1-f9bd-4901-aa10-44fe057f085c\",\"fullAccountNumber\":\"0289201945-1\",\"status\":\"A\",\"createTimestamp\":\"2021-09-08T08:13:37.375359-04:00[US/Eastern]\",\"lastUpdateTimestamp\":\"2021-09-08T08:13:43.248388-04:00[US/Eastern]\",\"cartCreator\":\"4024188003\",\"cartCreatorChannelId\":\"VZW-DOTCOM\",\"cartCreatorOrderLocationCode\":\"N832201\",\"cartCreatorSalesRepId\":\"NPB2C\",\"caseId\":\"SOP-3464709-E01\",\"visionCustomerType\":\"PE\",\"maverickLocation\":false,\"preConfiguredCartType\":\"BAU\",\"preConfiguredCartTypeDuringAddDevice\":\"BAU\",\"isCoreRep\":false},\"orderDetailsView\":{\"orderNumber\":\"2060048\",\"locationCode\":\"N832201\",\"orderType\":\"PS\",\"numOfLines\":\"1\"},\"primaryUserInfo\":{\"emailId\":\"SVZGSVIOVZ927@VZW.COM\"}}";
		GetCartDetailsRequest request = mapper.readValue(requestString, GetCartDetailsRequest.class);
		GetCartDetailsUIResponse response = mapper.readValue(responseString, GetCartDetailsUIResponse.class);// AddPlanAndDeviceUIResponse
		URI url = URI.create("http://localhost/5g/swap/order-confirmation");
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("GLOBALID", "VZW-DOTCOM");
		httpHeaders.add("channelId", "Digital");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(httpHeaders).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.swapOrderConfirmation(request, httpResponse)).thenReturn(Mono.just(ResponseEntity.status(200).body(response)));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.swapOrderConfirmation(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void removeHomePhoneValidationErrorTest() throws Exception {
		String requestString = "{\n \"cartInfo\": {\n \"clientAppName\": \"VZW-DOTCOM\",\n \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\n \"cartId\": \"\",\n \"caseId\": \"\",\n  \"accountNumber\": \"0213143123-00001\", \n \"cartCreator\": \"8136958775\",\n\"processingMTN\": \"8136958775\",\n \"homePhoneMTN\":\"xxxxxx\",\n  \"processStep\": \"ShoppingCart\",\n  \"processAction\": \"removeDevice\",\n \"intendType\": \"MOVER\",\n \"action\" : \"REMOVE\"\n \n  }\n}";
		RemoveHomePhoneUIRequest request = mapper.readValue(requestString, RemoveHomePhoneUIRequest.class);
		FieldValidationException fieldValidationException=new FieldValidationException();
		fieldValidationException.setCode("401");
		fieldValidationException.setMessage("Error Code");
		fieldValidationException.setName("FieldValidationException");
		URI url = URI.create("http://localhost/removeHomePhone");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = null;
		when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(new CartRedisData()));
		when(removeHomePhoneHelper.validateUiRequest(Mockito.any())).thenReturn(fieldValidationException);
		Mono<Object> controllerResponse = cartController.removeHomePhone(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void retrieveReviewOrderTechCbandDataTest() throws JsonProcessingException {
		String requestString = "{\"meta\":{},\"data\":{\"cartId\":\"b58e3b4d-f13c-440d-8ca8-465f4856a16b\"}}";
		String cartId="";
		GetCartDetailsRequest request = mapper.readValue(requestString, GetCartDetailsRequest.class);
		URI url = URI.create("http://localhost/cart/5g/cbd/getReviewOrderData");
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("GLOBALID", "VZW-DOTCOM");
		//httpHeaders.add("channelId", "Digital");
		httpHeaders.add("digital_ig_session", "digital_ig_session_12345");
		HttpCookie cookie = new HttpCookie("GLOBALID", "VZW-DOTCOM");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.post(url.toString()).headers(httpHeaders).cookie(cookie).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		InspicioResponseOrderInfo inspicioResponseOrderInfo=new InspicioResponseOrderInfo();
		InspicioTermsAndConditions inspicioTermsAndConditions =new InspicioTermsAndConditions();
		when(redisHelper2.getCartIdFromRedis()).thenReturn(Mono.just(cartId));
		when(fiveGhomeTechHelper.getTechCbandCart5GCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(inspicioResponseOrderInfo));
		when(readCartHelper.getAgreementDetails(Mockito.any())).thenReturn(Mono.just(inspicioTermsAndConditions));
		Mono<ReviewOrderData> retrieveReviewOrder=cartController.retrieveReviewOrderTechCbandData(httpHeader,httpResponse,request);
		StepVerifier.create(retrieveReviewOrder).assertNext(resp -> org.junit.Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

    @Test
    public void removeHomePhoneExceptionTest() throws Exception {
        String requestString = "{\n \"cartInfo\": {\n \"clientAppName\": \"VZW-DOTCOM\",\n \"correlationId\": \"69a66ef4d7e344dfb2db299209ea8333\",\n \"cartId\": \"\",\n \"caseId\": \"\",\n  \"accountNumber\": \"0213143123-00001\", \n \"cartCreator\": \"8136958775\",\n\"processingMTN\": \"8136958775\",\n \"homePhoneMTN\":\"xxxxxx\",\n  \"processStep\": \"ShoppingCart\",\n  \"processAction\": \"removeDevice\",\n \"intendType\": \"MOVER\",\n \"action\" : \"REMOVE\"\n \n  }\n}";
        String responseString = "{\n \"serviceHeader\" : {\n   \"clientId\" : \"OMNI-RETAIL\",\n   \"statusMsg\" : \"SUCCESS\",\n \"correlationId\" : \"soe-cart-2021.08.06.17.50.24-125.72236596853669\",\n  \"sessionId\" : \"\",\n   \"serviceName\" : \"SalesOrderPurchase\",\n  \"userId\" : \"\",\n\"statusCode\" : \"00\"\n },\n \"serviceBody\" : {\n\"serviceResponse\" : {\n \"context\" : {\n    \"cartInfo\" : {\n   \"statusMsg\" : \"Success\",\n\"cartId\" : \"aa3a61e9-5410-4243-9efe-598c3ec2ac08\",\n \"statusCode\" : \"1\"\n },\n      \"contextInfo\" : {\n     \"availablePaths\" : [{\n   \"path\" : \"ShoppingCart\"\n }, {\n    \"path\" : \"addDevice\"\n }\n   ],\n \"processStep\" : \"ShoppingCart\",\n  \"callReason\" : \"SalesOrderPurchase\"\n },\n\"caseId\" : \"SOP-3647723-E01\",\n    \"customerInfo\" : {\n    \"cartCreator\" : \"4102411705\",\n\"processingMTN\" : \"4014436878\",\n   \"accountNumber\" : \"0001445545-00001\"\n },\n   \"processMTNList\" : [{\n   \"mtn\" : \"2404951496\",\n  \"completedprocessSteps\" : [\"ShoppingCart\",\"addDevice\"]\n}\n    ]\n}\n}\n}\n}\n";
        RemoveHomePhoneUIRequest request = mapper.readValue(requestString, RemoveHomePhoneUIRequest.class);
        RemoveHomePhonePegaResponse response = mapper.readValue(responseString, RemoveHomePhonePegaResponse.class);
        URI url = URI.create("http://localhost/removeHomePhone");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        CartRedisData redisData=new CartRedisData();
        redisData.setCartId("69a66ef4d7e344dfb2db299209ea8333");
        redisData.setCaseId("123");
        redisData.setAccountNumber("0213143123-00001");
        redisData.setProcessingMTN("8136958775");
        redisData.setCartCreator("8136958775");
        redisData.setProcessStep("ShoppingCart");
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(redisData));
        when(removeHomePhoneHelper.removeHomePhone(Mockito.any())).thenReturn(Mono.just(response));
        when(removeHomePhoneHelper.removeHomePhone(Mockito.any())).thenThrow((new IllegalStateException()));
        Mono<Object> controllerResponse = cartController.removeHomePhone(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).expectComplete().verify();
    }

    @Test
    public void updateCartWithDateWithRedisData1Test() throws IOException {
        String requestString = "{\n \"context\": {\n \"caseId\": \"SOP-3597615-E01\",\n\"contextInfo\": {\n \"callReason\": \"SalesOrderPurchase\",\n \"processStep\": \"OrderReview\",\n\"processAction\": \"UpdateScheduleAppointment\",\n \"intent\": \"MOVER\"\n},\n\"customerInfo\": {\n\"accountNumber\": \"0389467727-00001\",\n\"cartCreator\": \"6072376627\",\n\"processingMTN\": \"8136958775\",\n \"registerNumber\": 0\n},\n\"cartInfo\": {\n\"cartId\": \"cfe0a112-c547-41a6-bfde-7e0688d7a774\",\n  \"itemType\": \"SCHEDULE5GAPPT\",\n\"intendType\": \"MOVER\",\n\"moversInfo\": {\n\"moveInDate\": \"07/20/2021\",\n  \"moveOutDate\": \"07/30/2021\"\n }\n }\n }\n}";
        String responseString = "{\n \"serviceHeader\" : {\n \"statusMsg\" : \"SUCCESS\",\n \"sessionId\" : \"\",\n \"serviceName\" : \"SalesOrderPurchase\",\n \"userId\" : \"\",\n\"statusCode\" : \"00\"\n },\n \"serviceBody\" : {\n \"serviceResponse\" : {\n\"context\" : {\n\"cartInfo\" : {\n  \"statusMsg\" : \"Success\",\n\"cartId\" : \"1f69c02f-c68f-4445-b5ff-8814fbd3412d\",\n \"preAuthSuccess\" : false,\n \"statusCode\" : \"1\"\n },\n \"contextInfo\" : {\n \"availablePaths\" : [{\n \"path\" : \"OrderReview-Shipping-Payment-Agreement\"\n  }\n   ],\n  \"processAction\" : \"\",\n \"processStep\" : \"OrderReview-Shipping-Payment-Agreement\",\n  \"callReason\" : \"SalesOrderPurchase\"\n    },\n \"caseId\" : \"SOP-3335332-E01\",\n\"customerInfo\" : {\n \"cartCreator\" : \"4029847575\",\n  \"processingMTN\" : \"newLine1\",\n \"accountNumber\" : \"0283134872-00001\"\n },\n   \"processMTNList\" : [{\n   \"mtn\" : \"newLine1\",\n\"completedprocessSteps\" : [\"NumberSelection\", \"Accessories\", \"NumberSelection\", \"NumberSelection\", \"ShoppingCart\", \"ContactInfo\", \"ShippingOptions\", \"ShippingOptions\", \"AppointmentSchedule\"]\n }\n]\n }\n  }\n }\n}\n";
        CartWithDateUIRequest request = mapper.readValue(requestString, CartWithDateUIRequest.class);
        CartWithDatePegaResponse response = mapper.readValue(responseString, CartWithDatePegaResponse.class);
        URI url = URI.create("http://localhost/5g/updateCartWithDates");
        MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = null;
        CartRedisData redisData=new CartRedisData();
        redisData.setCartId("69a66ef4d7e344dfb2db299209ea8333");
        redisData.setCaseId("123");
        redisData.setAccountNumber("0213143123-00001");
        redisData.setProcessingMTN("8136958775");
        redisData.setCartCreator("8136958775");
        when(redisHelper.getDataFromRedis()).thenReturn(Mono.just(redisData));
        when(updateCartWithDatesHelper.saveCartWithDate(Mockito.any())).thenThrow((new IllegalStateException()));
        Mono<CartWithDatePegaResponse> controllerResponse = cartController.updateCartWithDateAppointment(httpHeader, httpResponse,
                request);
        StepVerifier.create(controllerResponse).expectComplete().verify();
    }

	@Test
	public void retrieveFiveGCartTest1() throws IOException {
		String requestString = "{\"meta\":{},\"data\":{\"cartId\":\"b58e3b4d-f13c-440d-8ca8-465f4856a16b\"}}";
		String responseString = "{\"cartHeader\":{\"vendorId\":\"VZWCOM\",\"sourceSystem\":\"VZW-DOTCOM\",\"cartId\":\"b58e3b4d-f13c-440d-8ca8-465f4856a16b\",\"fullAccountNumber\":\"0282354804-1\",\"status\":\"A\",\"createTimestamp\":\"2021-10-11T05:50:50.450965-04:00[US/Eastern]\",\"lastUpdateTimestamp\":\"2021-10-11T05:51:45.828807-04:00[US/Eastern]\",\"cartCreator\":\"7326726656\",\"cartCreatorChannelId\":\"VZW-DOTCOM\",\"cartCreatorOrderLocationCode\":\"D463801\",\"cartCreatorSalesRepId\":\"EZ706\",\"caseId\":\"SOP-4604006-E01\",\"visionCustomerType\":\"PE\",\"maverickLocation\":false,\"preConfiguredCartType\":\"BAU\",\"preConfiguredCartTypeDuringAddDevice\":\"BAU\",\"isCoreRep\":false},\"orderDetailsView\":{\"dueTodayAmount\":\"0.0\",\"dueMonthlyAmount\":\"60.0\",\"orderActivityType\":\"AAL\",\"totalShippingCost\":\"null\",\"totalDiscountedShippingCost\":\"null\",\"installType\":\"Professional SetUp\",\"orderNumber\":\"3117431\",\"locationCode\":\"D463801\",\"orderType\":\"PS\",\"numOfLines\":\"1\",\"hiddenPromos\":[\"wireless-offer\"]},\"dueTodayList\":[{\"name\":\"5G Internet Gateway\",\"installationType\":\"Professional SetUp\",\"discountApplied\":\"0.0\",\"actualAmount\":\"0.0\",\"totalAmountWithDiscount\":\"0.0\",\"productId\":\"16900002\",\"sorId\":\"LVSKIHP\",\"itemType\":\"DEVICE\",\"quantity\":\"1\",\"taxAmount\":\"0.0\",\"lineNumber\":\"newLine1\",\"multiLineSeqNumber\":1,\"isBackorder\":\"false\",\"preBackDate\":\"\"}],\"dueMonthlyList\":[{\"name\":\"5G HOME INTERNET\",\"actualAmount\":\"80.0\",\"totalAmountWithDiscount\":\"60.0\",\"productId\":\"39425\",\"itemType\":\"PLAN\"}],\"dueMonthlyTaxes\":[{\"dueAmount\":\"0.0\"}],\"dueTodayTaxes\":[{\"dueAmount\":\"0.0\"}],\"shippingDetails\":[{\"address\":{\"apartmentNo\":\"\",\"type\":\"R\",\"streetNumber\":\"125\",\"streetName\":\"SAINT NICHOLAS\",\"addressLine2\":\"\",\"addressLine1\":\"125 SAINT NICHOLAS AVE\",\"city\":\"SOUTH PLAINFIELD\",\"state\":\"NJ\",\"zipCode\":\"07080\",\"zipCode4\":\"1807\",\"county\":\"\",\"countryCode\":\"\",\"fipsCode\":\"3402369390\",\"firstName\":\"JACK\",\"lastName\":\"MANUEL\",\"emailId\":\"QVOOLN64Z7@VZW.COM\",\"phoneNumber\":\"3453350350\",\"streetType\":\"AVE\",\"streetDirection\":\"\"},\"cbrPhone\":\"3453350350\",\"firstName\":\"JACK\",\"lastName\":\"MANUEL\",\"midInitials\":\"J\",\"isUseUnVerifiedAddress\":false,\"isValidAddress\":false,\"email\":\"QVOOLN64Z7@VZW.COM\"}],\"payments\":[],\"primaryUserInfo\":{\"firstName\":\"JACK\",\"lastName\":\"MANUEL\",\"address\":{\"firmName\":\"\",\"apartmentNo\":\"\",\"type\":\"AVE\",\"streetNumber\":\"125\",\"streetName\":\"SAINT NICHOLAS\",\"addressLine2\":\"\",\"addressLine1\":\"125 SAINT NICHOLAS AVE\",\"poBoxNo\":\"\",\"ruralRouteNo\":\"\",\"ruralDelNo\":\"\",\"city\":\"SOUTH PLAINFIELD\",\"state\":\"NJ\",\"zipCode\":\"07080\",\"zipCode4\":\"1807\",\"county\":\"\",\"countryCode\":\"US\",\"fipsCode\":\"3402369390\",\"firstName\":\"JACK\",\"lastName\":\"MANUEL\",\"emailId\":\"QVOOLN64Z7@VZW.COM\",\"phoneNumber\":\"3453350350\",\"streetType\":\"AVE\",\"streetDirection\":\"\"},\"isValidAddress\":true,\"bsnsName\":\"\",\"emailId\":\"QVOOLN64Z7@VZW.COM\"},\"cart5GAddress\":{\"addressLine1\":\"800 S OGDEN ST\",\"city\":\"DENVER\",\"state\":\"CO\",\"zipCode\":\"80209\",\"zipCode4\":\"\",\"countryCode\":\"\",\"fipsCode\":\"0803120000\",\"floor\":0},\"registrationDetails\":{}}";
		GetCartDetailsRequest request = mapper.readValue(requestString, GetCartDetailsRequest.class);
		GetCartDetailsUIResponse response = mapper.readValue(responseString, GetCartDetailsUIResponse.class);
		URI url = URI.create("http://localhost/5g/retrieve-cart");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(fiveGhomeNSEHelper.get5GCart(request)).thenReturn(Mono.just(ResponseEntity.status(200).body(response)));
		when(redisHelper.upsertRetrieveCartDataIntoRedis(Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));

		Mono<ResponseEntity<GetCartDetailsUIResponse>> controllerResponse = cartController.retrieveFiveGCart(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void addPlanAndDeviceTest1() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"EXPRESS_STORE\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"intendType\":\"AAL_5G\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"EXPRESS_STORE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-5188491-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Accessories\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Accessories\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-D-410f65a0-8535-471c-b1b3-0d14cbfcbd26\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":1,\"cartId\":\"6af05322-815c-423c-9bb2-9b0fce190075\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"onDemandAllowed\":false,\"backDateAllowed\":false,\"futureDateAllowed\":false,\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"lines\":[{\"status\":1,\"spos\":[{\"id\":\"732\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false},{\"id\":\"1508\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false}],\"sfos\":[{\"id\":\"48526\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"48553\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"54307\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68872\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"70421\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78003\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"83856\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"85503\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86112\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86926\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86927\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86928\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86952\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86953\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false}],\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"mtn\":\"newLine1\",\"isDeviceSelected\":true,\"userSelectedPlan\":false,\"lineId\":\"newLine1\",\"sortingNumber\":\"0\",\"device\":{\"id\":\"LVSKIHP\",\"itemPrice\":\"0.0\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"5G Internet Gateway\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false},\"sim\":{\"id\":\"NI-DPSIM\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"NSE_5G\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"isAppendedLine\":false,\"fiveGPlanAdded\":false}],\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]}]}}}}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);
		URI url = URI.create("http://localhost/5g/updateCart");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "EXPRESS_STORE").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response));

		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addPlanAndDevice(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void addPlanAndDeviceWithCookiesTest1() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"intendType\":\"AAL_5G\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]},\"midnight\":\"Y\"}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-5188491-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Accessories\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Accessories\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-D-410f65a0-8535-471c-b1b3-0d14cbfcbd26\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":1,\"cartId\":\"6af05322-815c-423c-9bb2-9b0fce190075\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"onDemandAllowed\":false,\"backDateAllowed\":false,\"futureDateAllowed\":false,\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"lines\":[{\"status\":1,\"spos\":[{\"id\":\"732\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false},{\"id\":\"1508\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false}],\"sfos\":[{\"id\":\"48526\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"48553\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"54307\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68872\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"70421\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78003\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"83856\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"85503\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86112\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86926\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86927\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86928\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86952\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86953\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false}],\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"mtn\":\"newLine1\",\"isDeviceSelected\":true,\"userSelectedPlan\":false,\"lineId\":\"newLine1\",\"sortingNumber\":\"0\",\"device\":{\"id\":\"LVSKIHP\",\"itemPrice\":\"0.0\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"5G Internet Gateway\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false},\"sim\":{\"id\":\"NI-DPSIM\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"NSE_5G\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"isAppendedLine\":false,\"fiveGPlanAdded\":false}],\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]}]}}}}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);
		System.out.println(request.getChannelId());
		URI url = URI.create("http://localhost/5g/updateCart");
		HttpCookie digital_ig_session = new HttpCookie("digital_ig_session", "digital_ig_session");
		HttpCookie domainCookie = new HttpCookie("domainCookie", "domainCookie");
		HttpCookie ecpdcookie = new HttpCookie("ecpdcookie", "ecpdcookie:token1:token2:token3");
		HttpCookie MUCFlow = new HttpCookie("MUCFlow", "Y");
		MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
		bodyMap.add("digital_ig_session", digital_ig_session);
		bodyMap.add("domainCookie", domainCookie);
		bodyMap.add("ecpdcookie", ecpdcookie);
		bodyMap.add("MUCFlow", MUCFlow);
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookies(bodyMap).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addPlanAndDevice(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}




	@Test
	public void addPlanAndDevice_DigitalChannelIdTest4() throws IOException {
		String requestString = "{\"cartInfo\":{\"disableMyLink\":false,\"intendType\":\"BYOD\",\"covidQuestionareAnswered\":false,\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"320089\",\"processingMTN\":\"newline1\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"showAALPromoIntercept\":{\"myOfferEligibile\":true},\"caseId\":\"SOP-5188491-E01\",\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-D-410f65a0-8535-471c-b1b3-0d14cbfcbd26\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"cartInfo\":{\"processStep\":\"OrderNow\",\"intendType\":\"EUP_LTE\",\"ecpdProfileId\":\"ecpdId\",\"cartItemCount\":1,\"cartId\":\"6af05322-815c-423c-9bb2-9b0fce190075\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"onDemandAllowed\":false,\"backDateAllowed\":false,\"futureDateAllowed\":false,\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]}]}}}}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);
		System.out.println(request.getChannelId());
		URI url = URI.create("http://localhost/5g/updateCart");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.PARTIAL_CONTENT);
		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addPlanAndDevice(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse.log()).expectError().verify();
	}


	@Test
	public void addPlanAndDevice_Error6Test() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"intendType\":\"AAL_5G\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
		String responseString = "{\"errors\":[{\"namespace\":\"CartService\",\"id\":\"712\",\"message\":\"Invalid Address:Street name/PO Box/Rural Delivery Route not found in Zipcode\",\"name\":\"REQUEST_VALIDATION_ERROR\"}]}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);
		System.out.println(request.getChannelId());
		URI url = URI.create("http://localhost/5g/updateCart");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addPlanAndDevice(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void updateProcessStepTest2() throws IOException {
		String requestString = "{\"cartInfo\":{\"covidQuestionareAnswered\":true,\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"processStep\":\"InstallType\",\"processAction\":\"Complete\",\"bundleInstallType\":\"\"},\"data\":{}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"showAALPromoIntercept\":{\"myOfferEligibile\":true},\"caseId\":\"SOP-4387896-E01\",\"customerInfo\":{\"accountNumber\":\"0280000250-00001\",\"cartCreator\":\"3166127651\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"existingCase\":\"\"},\"cartInfo\":{\"ecpdProfileId\":\"ecpd\",\"cartItemCount\":0,\"cartId\":\"9978549b-aa29-4d8e-b09e-e4c7256da6da\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"InstallType\"]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"InstallType\"]}]}}}}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);// AddPlanAndDeviceUIResponse

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("channelId","digital");
		httpHeaders.add("path","/cart/nse/add-device" );

		URI url = URI.create("http://localhost/5g/updateProcessStep");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(httpHeaders).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.PARTIAL_CONTENT);
		when(readCartHelper.addPlanAndDevice(request)).thenReturn(Mono.just(response));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
		when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));

		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.updateProcessStep(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).expectError().verify();

		String requestString3 = "{\"cartInfo\":{\"intendType\":\"EUP_LTE\",\"covidQuestionareAnswered\":false,\"clientAppName\":\"OMNI-TELESALES\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"processingMTN\":\"newLine1\",\"processStep\":\"OrderNow\",\"processAction\":\"Complete\",\"bundleInstallType\":\"\"},\"data\":{}}";
		String responseString3 = "{\"serviceHeader\":{\"clientId\":\"OMNI-TELESALES\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4387896-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"0280000250-00001\",\"cartCreator\":\"3166127651\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"existingCase\":\"\"},\"cartInfo\":{\"ecpdProfileId\":\"ecpd\",\"cartItemCount\":0,\"cartId\":\"9978549b-aa29-4d8e-b09e-e4c7256da6da\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"InstallType\"]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"InstallType\"]}]}}}}";
		AddPlanAndDeviceUIRequest request3 = mapper.readValue(requestString3, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response3 = mapper.readValue(responseString3, AddPlanAndDeviceUIResponse.class);// AddPlanAndDeviceUIResponse

		HttpHeaders httpHeaders3 = new HttpHeaders();
		httpHeaders3.add("channelId","assisted");

		URI url3 = URI.create("http://localhost/5g/updateProcessStep");
		MockServerHttpRequest httpHeader3 = MockServerHttpRequest.method(HttpMethod.POST, url3).headers(httpHeaders3).build();
		ServerHttpResponse httpResponse3 = new MockServerHttpResponse();
		httpResponse3.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(request3)).thenReturn(Mono.just(response3));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
		when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));

		Mono<ResponseEntity<GenericResponse>> controllerResponse3 = cartController.updateProcessStep(httpHeader3, httpResponse3,
				request3);
		StepVerifier.create(controllerResponse3).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		String requestString4 = "{\"cartInfo\":{\"covidQuestionareAnswered\":true,\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"processStep\":\"InstallType\",\"processAction\":\"Complete\",\"bundleInstallType\":\"\"},\"data\":{}}";
		String responseString4 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"showAALPromoIntercept\":{\"myOfferEligibile\":true},\"caseId\":\"SOP-4387896-E01\",\"customerInfo\":{\"accountNumber\":\"0280000250-00001\",\"cartCreator\":\"3166127651\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"existingCase\":\"\"},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"InstallType\"]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"InstallType\"]}]}}}}";
		AddPlanAndDeviceUIRequest request4 = mapper.readValue(requestString4, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response4 = mapper.readValue(responseString4, AddPlanAndDeviceUIResponse.class);// AddPlanAndDeviceUIResponse

		HttpHeaders httpHeaders4 = new HttpHeaders();
		httpHeaders4.add("channelId","digital");
		httpHeaders4.add("path","/cart/nse/add-device" );

		URI url4 = URI.create("http://localhost/5g/updateProcessStep");
		MockServerHttpRequest httpHeader4 = MockServerHttpRequest.method(HttpMethod.POST, url4).headers(httpHeaders4).build();
		ServerHttpResponse httpResponse4 = new MockServerHttpResponse();
		httpResponse4.setStatusCode(HttpStatus.PARTIAL_CONTENT);
		when(readCartHelper.addPlanAndDevice(request4)).thenReturn(Mono.just(response4));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
		when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));

		Mono<ResponseEntity<GenericResponse>> controllerResponse4 = cartController.updateProcessStep(httpHeader4, httpResponse4,
				request4);
		StepVerifier.create(controllerResponse4).expectError().verify();

		String requestString5 = "{\"cartInfo\":{\"covidQuestionareAnswered\":true,\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"processStep\":\"InstallType\",\"processAction\":\"Complete\",\"bundleInstallType\":\"\"},\"data\":{}}";
		String responseString5 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{}}}";
		AddPlanAndDeviceUIRequest request5 = mapper.readValue(requestString5, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response5 = mapper.readValue(responseString5, AddPlanAndDeviceUIResponse.class);// AddPlanAndDeviceUIResponse

		HttpHeaders httpHeaders5 = new HttpHeaders();
		httpHeaders5.add("channelId","digital");
		httpHeaders5.add("path","/cart/nse/add-device" );

		URI url5 = URI.create("http://localhost/5g/updateProcessStep");
		MockServerHttpRequest httpHeader5 = MockServerHttpRequest.method(HttpMethod.POST, url5).headers(httpHeaders5).build();
		ServerHttpResponse httpResponse5 = new MockServerHttpResponse();
		httpResponse5.setStatusCode(HttpStatus.PARTIAL_CONTENT);
		when(readCartHelper.addPlanAndDevice(request5)).thenReturn(Mono.just(response5));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
		when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));

		Mono<ResponseEntity<GenericResponse>> controllerResponse5 = cartController.updateProcessStep(httpHeader5, httpResponse5,
				request5);
		StepVerifier.create(controllerResponse5).expectError().verify();
	}

//	@Test
//	public void updateProcessStepTest3() throws IOException {
//		String requestString3 = "{\"cartInfo\":{\"intendType\":\"EUP_LTE\",\"covidQuestionareAnswered\":false,\"clientAppName\":\"OMNI-TELESALES\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"processingMTN\":\"newLine1\",\"processStep\":\"OrderNow\",\"processAction\":\"Complete\",\"bundleInstallType\":\"\"},\"data\":{}}";
//		String responseString3 = "{\"serviceHeader\":{\"clientId\":\"OMNI-TELESALES\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4387896-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"0280000250-00001\",\"cartCreator\":\"3166127651\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"existingCase\":\"\"},\"cartInfo\":{\"ecpdProfileId\":\"ecpd\",\"cartItemCount\":0,\"cartId\":\"9978549b-aa29-4d8e-b09e-e4c7256da6da\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"InstallType\"]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"InstallType\"]}]}}}}";
//		AddPlanAndDeviceUIRequest request3 = mapper.readValue(requestString3, AddPlanAndDeviceUIRequest.class);
//		AddPlanAndDeviceUIResponse response3 = mapper.readValue(responseString3, AddPlanAndDeviceUIResponse.class);// AddPlanAndDeviceUIResponse
//
//		HttpHeaders httpHeaders3 = new HttpHeaders();
//		httpHeaders3.add("channelId","assisted");
//
//		URI url3 = URI.create("http://localhost/5g/updateProcessStep");
//		MockServerHttpRequest httpHeader3 = MockServerHttpRequest.method(HttpMethod.POST, url3).headers(httpHeaders3).build();
//		ServerHttpResponse httpResponse3 = new MockServerHttpResponse();
//		httpResponse3.setStatusCode(HttpStatus.CONTINUE);
//		when(readCartHelper.addPlanAndDevice(request3)).thenReturn(Mono.just(response3));
//		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
//		when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
//
//		Mono<ResponseEntity<GenericResponse>> controllerResponse3 = cartController.updateProcessStep(httpHeader3, httpResponse3,
//				request3);
//		StepVerifier.create(controllerResponse3).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
//				.verify();
//	}

//	@Test
//	public void updateProcessStepTest4() throws IOException {
//		String requestString4 = "{\"cartInfo\":{\"covidQuestionareAnswered\":true,\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"processStep\":\"InstallType\",\"processAction\":\"Complete\",\"bundleInstallType\":\"\"},\"data\":{}}";
//		String responseString4 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"showAALPromoIntercept\":{\"myOfferEligibile\":true},\"caseId\":\"SOP-4387896-E01\",\"customerInfo\":{\"accountNumber\":\"0280000250-00001\",\"cartCreator\":\"3166127651\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"existingCase\":\"\"},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"InstallType\"]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"InstallType\"]}]}}}}";
//		AddPlanAndDeviceUIRequest request4 = mapper.readValue(requestString4, AddPlanAndDeviceUIRequest.class);
//		AddPlanAndDeviceUIResponse response4 = mapper.readValue(responseString4, AddPlanAndDeviceUIResponse.class);// AddPlanAndDeviceUIResponse
//
//		HttpHeaders httpHeaders4 = new HttpHeaders();
//		httpHeaders4.add("channelId","digital");
//		httpHeaders4.add("path","/cart/nse/add-device" );
//
//		URI url4 = URI.create("http://localhost/5g/updateProcessStep");
//		MockServerHttpRequest httpHeader4 = MockServerHttpRequest.method(HttpMethod.POST, url4).headers(httpHeaders4).build();
//		ServerHttpResponse httpResponse4 = new MockServerHttpResponse();
//		httpResponse4.setStatusCode(HttpStatus.PARTIAL_CONTENT);
//		when(readCartHelper.addPlanAndDevice(request4)).thenReturn(Mono.just(response4));
//		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
//		when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
//
//		Mono<ResponseEntity<GenericResponse>> controllerResponse4 = cartController.updateProcessStep(httpHeader4, httpResponse4,
//				request4);
//		StepVerifier.create(controllerResponse4).expectError().verify();
//	}

//	@Test
//	public void updateProcessStepTest5() throws IOException {
//		String requestString5 = "{\"cartInfo\":{\"covidQuestionareAnswered\":true,\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"processStep\":\"InstallType\",\"processAction\":\"Complete\",\"bundleInstallType\":\"\"},\"data\":{}}";
//		String responseString5 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{}}}";
//		AddPlanAndDeviceUIRequest request5 = mapper.readValue(requestString5, AddPlanAndDeviceUIRequest.class);
//		AddPlanAndDeviceUIResponse response5 = mapper.readValue(responseString5, AddPlanAndDeviceUIResponse.class);// AddPlanAndDeviceUIResponse
//
//		HttpHeaders httpHeaders5 = new HttpHeaders();
//		httpHeaders5.add("channelId","digital");
//		httpHeaders5.add("path","/cart/nse/add-device" );
//
//		URI url5 = URI.create("http://localhost/5g/updateProcessStep");
//		MockServerHttpRequest httpHeader5 = MockServerHttpRequest.method(HttpMethod.POST, url5).headers(httpHeaders5).build();
//		ServerHttpResponse httpResponse5 = new MockServerHttpResponse();
//		httpResponse5.setStatusCode(HttpStatus.PARTIAL_CONTENT);
//		when(readCartHelper.addPlanAndDevice(request5)).thenReturn(Mono.just(response5));
//		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
//		when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
//
//		Mono<ResponseEntity<GenericResponse>> controllerResponse5 = cartController.updateProcessStep(httpHeader5, httpResponse5,
//				request5);
//		StepVerifier.create(controllerResponse5).expectError().verify();
//	}

	@Test
	public void updateProcessStepErrorsTest() throws IOException {
		String requestString = "{\"cartInfo\":{\"covidQuestionareAnswered\":true,\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"processStep\":\"InstallType\",\"processAction\":\"Complete\",\"bundleInstallType\":\"\"},\"data\":{}}";
		String responseString = "{\"errors\":[{\"namespace\":\"CartService\",\"id\":\"3226\"}]}";		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);// AddPlanAndDeviceUIResponse
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("channelId","VZW-DOTCOM");
		URI url = URI.create("http://localhost/5g/updateProcessStep");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(httpHeaders).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.PARTIAL_CONTENT);
		when(readCartHelper.addPlanAndDevice(request)).thenReturn(Mono.just(response));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
		when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));

		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.updateProcessStep(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void saveCartWithEmailTest1() throws IOException {
		String requestString = "{\"emaild\":\"usha.kammara@veriozn.com\",\"intendType\":\"NSE_LTE\"}";
		String responseString = "{\"serviceHeader\":{\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\",\"correlationId\":\"POE-D-e81378f9-d693-4234-802a-41019e24e4c3\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4346627-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\"},\"customerInfo\":{\"customerType\":\"N\",\"originalCreditApprovalNumber\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"POE-D-e81378f9-d693-4234-802a-41019e24e4c3\",\"processingMTN\":\"\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":0,\"cartId\":\"4221df0b-f63d-46f4-b59a-43edb32c8675\",\"statusMsg\":\"Save cart data updated successfully\",\"statusCode\":\"1\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"ShoppingCart\"]},{\"mtn\":\"\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"ShoppingCart\"]}]}}}}";
		SaveCartWithEmailUIRequest request = mapper.readValue(requestString, SaveCartWithEmailUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);// AddPlanAndDeviceUIResponse
		URI url = URI.create("http://localhost/5g/saveCartWithEmail");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.saveCartWithEmail(request)).thenReturn(Mono.just(response));

		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.saveCartWithEmail(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}


	@Test  // Gen2-Gen3 updateCart
	public void swapUpdateCartWithCookiesTest1() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"bundleInstallType\":\"5GHomeGeminiProfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"O\"}]}}";
		String responseString="{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4629485-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"0430568040-00001\",\"cartCreator\":\"8135199979\",\"processingMTN\":\"8135199979\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":1,\"cartId\":\"2a74d680-a043-4d53-8836-802edb5c7e49\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"lines\":[{\"status\":1,\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"isDeviceSelected\":false,\"userSelectedPlan\":false,\"lineId\":\"8135199979\",\"sortingNumber\":\"0\",\"device\":{\"upgradeReasonCode\":\"UN\",\"id\":\"16900002\",\"itemPrice\":\"0.0\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"EUP_5G_REPAIR\",\"currentPlanType\":\"LLP\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"isAppendedLine\":false,\"fiveGPlanAdded\":false}],\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"8135199979\",\"completedprocessSteps\":[]},{\"mtn\":\"8135199979\",\"completedprocessSteps\":[]}]}}}}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);
		URI url = URI.create("http://localhost/5g/swap/updateCart");
		HttpCookie digital_ig_session = new HttpCookie("digital_ig_session", null);
		HttpCookie domainCookie = new HttpCookie("domainCookie", null);
		HttpCookie ecpdcookie = new HttpCookie("ecpdcookie", null);
		MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
		bodyMap.add("digital_ig_session", digital_ig_session);
		bodyMap.add("domainCookie", domainCookie);
		bodyMap.add("ecpdcookie", ecpdcookie);
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookies(bodyMap).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.upgradePlanAndDevice(request)).thenReturn(Mono.just(response));
		when(redisHelper3.fetchCustomerAddressFromRedis()).thenReturn(Mono.just(new CustomerProfileAddressResponse()));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(any(),eq("device"))).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.upgradePlanAndDevice(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test  // Gen2-Gen3 updateCart
	public void swapUpdateCartTest1() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"8135199979\",\"processingMTN\":\"newline1\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"intendType\":\"EUP_5G_REPAIR\",\"bundleInstallType\":\"5GHomeGeminiProfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"O\"}]}}";
		String responseString="{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4629485-E01\",\"customerInfo\":{\"accountNumber\":\"0430568040-00001\",\"cartCreator\":\"8135199979\",\"processingMTN\":\"8135199979\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":1,\"cartId\":\"2a74d680-a043-4d53-8836-802edb5c7e49\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"8135199979\",\"completedprocessSteps\":[]},{\"mtn\":\"8135199979\",\"completedprocessSteps\":[]}]}}}}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);
		URI url = URI.create("http://localhost/5g/swap/updateCart");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.PARTIAL_CONTENT);
		when(readCartHelper.upgradePlanAndDevice(request)).thenReturn(Mono.just(response));
		when(redisHelper3.fetchCustomerAddressFromRedis()).thenReturn(Mono.just(new CustomerProfileAddressResponse()));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(any(),eq("device"))).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.upgradePlanAndDevice(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).expectError().verify();

		String requestString2 = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"8135199979\",\"processingMTN\":\"newline1\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"intendType\":\"EUP_5G_REPAIR\",\"bundleInstallType\":\"5GHomeGeminiProfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"O\"}]}}";
		String responseString2="{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4629485-E01\",\"customerInfo\":{\"accountNumber\":\"0430568040-00001\",\"cartCreator\":\"8135199979\",\"processingMTN\":\"8135199979\",\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"8135199979\",\"completedprocessSteps\":[]},{\"mtn\":\"8135199979\",\"completedprocessSteps\":[]}]}}}}";
		AddPlanAndDeviceUIRequest request2 = mapper.readValue(requestString2, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response2 = mapper.readValue(responseString2, AddPlanAndDeviceUIResponse.class);
		URI url2 = URI.create("http://localhost/5g/swap/updateCart");
		MockServerHttpRequest httpHeader2 = MockServerHttpRequest.method(HttpMethod.POST, url2).build();
		ServerHttpResponse httpResponse2 = new MockServerHttpResponse();
		httpResponse2.setStatusCode(HttpStatus.PARTIAL_CONTENT);
		when(readCartHelper.upgradePlanAndDevice(request2)).thenReturn(Mono.just(response2));
		when(redisHelper3.fetchCustomerAddressFromRedis()).thenReturn(Mono.just(new CustomerProfileAddressResponse()));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(any(),eq("device"))).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse2 = cartController.upgradePlanAndDevice(httpHeader2, httpResponse2,
				request2);
		StepVerifier.create(controllerResponse2).expectError().verify();

		String requestString3 = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"8135199979\",\"processingMTN\":\"newline1\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"intendType\":\"EUP_5G_REPAIR\",\"bundleInstallType\":\"5GHomeGeminiProfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"O\"}]}}";
		String responseString3="{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{}}}";
		AddPlanAndDeviceUIRequest request3 = mapper.readValue(requestString3, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response3 = mapper.readValue(responseString3, AddPlanAndDeviceUIResponse.class);
		URI url3 = URI.create("http://localhost/5g/swap/updateCart");
		MockServerHttpRequest httpHeader3 = MockServerHttpRequest.method(HttpMethod.POST, url3).build();
		ServerHttpResponse httpResponse3 = new MockServerHttpResponse();
		httpResponse3.setStatusCode(HttpStatus.PARTIAL_CONTENT);
		when(readCartHelper.upgradePlanAndDevice(request3)).thenReturn(Mono.just(response3));
		when(redisHelper3.fetchCustomerAddressFromRedis()).thenReturn(Mono.just(new CustomerProfileAddressResponse()));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(any(),eq("device"))).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse3 = cartController.upgradePlanAndDevice(httpHeader3, httpResponse3,
				request3);
		StepVerifier.create(controllerResponse3).expectError().verify();

		String requestString4 = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"8135199979\",\"processingMTN\":\"newline1\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"intendType\":\"EUP_5G_REPAIR\",\"bundleInstallType\":\"5GHomeGeminiProfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"O\"}]}}";
		String responseString4="{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"}}";
		AddPlanAndDeviceUIRequest request4 = mapper.readValue(requestString4, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response4 = mapper.readValue(responseString4, AddPlanAndDeviceUIResponse.class);
		URI url4 = URI.create("http://localhost/5g/swap/updateCart");
		MockServerHttpRequest httpHeader4 = MockServerHttpRequest.method(HttpMethod.POST, url4).build();
		ServerHttpResponse httpResponse4 = new MockServerHttpResponse();
		httpResponse4.setStatusCode(HttpStatus.PARTIAL_CONTENT);
		when(readCartHelper.upgradePlanAndDevice(request4)).thenReturn(Mono.just(response4));
		when(redisHelper3.fetchCustomerAddressFromRedis()).thenReturn(Mono.just(new CustomerProfileAddressResponse()));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(any(),eq("device"))).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse4 = cartController.upgradePlanAndDevice(httpHeader4, httpResponse4,
				request4);
		StepVerifier.create(controllerResponse4).expectError().verify();

		String requestString5 = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"8135199979\",\"processingMTN\":\"newline1\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"intendType\":\"EUP_5G_REPAIR\",\"bundleInstallType\":\"5GHomeGeminiProfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"O\"}]}}";
		String responseString5="{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4629485-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"0430568040-00001\",\"cartCreator\":\"8135199979\",\"processingMTN\":\"8135199979\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":1,\"cartId\":\"2a74d680-a043-4d53-8836-802edb5c7e49\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"lines\":[{}],\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"8135199979\",\"completedprocessSteps\":[]},{\"mtn\":\"8135199979\",\"completedprocessSteps\":[]}]}}}}";
		AddPlanAndDeviceUIRequest request5 = mapper.readValue(requestString5, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response5 = mapper.readValue(responseString5, AddPlanAndDeviceUIResponse.class);
		URI url5 = URI.create("http://localhost/5g/swap/updateCart");
		MockServerHttpRequest httpHeader5 = MockServerHttpRequest.method(HttpMethod.POST, url5).build();
		ServerHttpResponse httpResponse5 = new MockServerHttpResponse();
		httpResponse5.setStatusCode(HttpStatus.PARTIAL_CONTENT);
		when(readCartHelper.upgradePlanAndDevice(request5)).thenReturn(Mono.just(response5));
		when(redisHelper3.fetchCustomerAddressFromRedis()).thenReturn(Mono.just(new CustomerProfileAddressResponse()));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(any(),eq("device"))).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse5 = cartController.upgradePlanAndDevice(httpHeader5, httpResponse5,
				request5);
		StepVerifier.create(controllerResponse5).expectError().verify();
	}

//	@Test  // Gen2-Gen3 updateCart
//	public void swapUpdateCartTest2() throws IOException {
//		String requestString2 = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"8135199979\",\"processingMTN\":\"newline1\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"intendType\":\"EUP_5G_REPAIR\",\"bundleInstallType\":\"5GHomeGeminiProfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"O\"}]}}";
//		String responseString2="{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4629485-E01\",\"customerInfo\":{\"accountNumber\":\"0430568040-00001\",\"cartCreator\":\"8135199979\",\"processingMTN\":\"8135199979\",\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"8135199979\",\"completedprocessSteps\":[]},{\"mtn\":\"8135199979\",\"completedprocessSteps\":[]}]}}}}";
//		AddPlanAndDeviceUIRequest request2 = mapper.readValue(requestString2, AddPlanAndDeviceUIRequest.class);
//		AddPlanAndDeviceUIResponse response2 = mapper.readValue(responseString2, AddPlanAndDeviceUIResponse.class);
//		URI url2 = URI.create("http://localhost/5g/swap/updateCart");
//		MockServerHttpRequest httpHeader2 = MockServerHttpRequest.method(HttpMethod.POST, url2).build();
//		ServerHttpResponse httpResponse2 = new MockServerHttpResponse();
//		httpResponse2.setStatusCode(HttpStatus.PARTIAL_CONTENT);
//		when(readCartHelper.upgradePlanAndDevice(request2)).thenReturn(Mono.just(response2));
//		when(redisHelper3.fetchCustomerAddressFromRedis()).thenReturn(Mono.just(new CustomerProfileAddressResponse()));
//		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(any(),eq("device"))).thenReturn(Mono.just(Boolean.TRUE));
//		Mono<ResponseEntity<GenericResponse>> controllerResponse2 = cartController.upgradePlanAndDevice(httpHeader2, httpResponse2,
//				request2);
//		StepVerifier.create(controllerResponse2).expectError().verify();
//	}

//	@Test  // Gen2-Gen3 updateCart
//	public void swapUpdateCartTest3() throws IOException {
//		String requestString3 = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"8135199979\",\"processingMTN\":\"newline1\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"intendType\":\"EUP_5G_REPAIR\",\"bundleInstallType\":\"5GHomeGeminiProfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"O\"}]}}";
//		String responseString3="{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{}}}";
//		AddPlanAndDeviceUIRequest request3 = mapper.readValue(requestString3, AddPlanAndDeviceUIRequest.class);
//		AddPlanAndDeviceUIResponse response3 = mapper.readValue(responseString3, AddPlanAndDeviceUIResponse.class);
//		URI url3 = URI.create("http://localhost/5g/swap/updateCart");
//		MockServerHttpRequest httpHeader3 = MockServerHttpRequest.method(HttpMethod.POST, url3).build();
//		ServerHttpResponse httpResponse3 = new MockServerHttpResponse();
//		httpResponse3.setStatusCode(HttpStatus.PARTIAL_CONTENT);
//		when(readCartHelper.upgradePlanAndDevice(request3)).thenReturn(Mono.just(response3));
//		when(redisHelper3.fetchCustomerAddressFromRedis()).thenReturn(Mono.just(new CustomerProfileAddressResponse()));
//		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(any(),eq("device"))).thenReturn(Mono.just(Boolean.TRUE));
//		Mono<ResponseEntity<GenericResponse>> controllerResponse3 = cartController.upgradePlanAndDevice(httpHeader3, httpResponse3,
//				request3);
//		StepVerifier.create(controllerResponse3).expectError().verify();
//	}

//	@Test  // Gen2-Gen3 updateCart
//	public void swapUpdateCartTest4() throws IOException {
//		String requestString4 = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"8135199979\",\"processingMTN\":\"newline1\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"intendType\":\"EUP_5G_REPAIR\",\"bundleInstallType\":\"5GHomeGeminiProfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"O\"}]}}";
//		String responseString4="{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"}}";
//		AddPlanAndDeviceUIRequest request4 = mapper.readValue(requestString4, AddPlanAndDeviceUIRequest.class);
//		AddPlanAndDeviceUIResponse response4 = mapper.readValue(responseString4, AddPlanAndDeviceUIResponse.class);
//		URI url4 = URI.create("http://localhost/5g/swap/updateCart");
//		MockServerHttpRequest httpHeader4 = MockServerHttpRequest.method(HttpMethod.POST, url4).build();
//		ServerHttpResponse httpResponse4 = new MockServerHttpResponse();
//		httpResponse4.setStatusCode(HttpStatus.PARTIAL_CONTENT);
//		when(readCartHelper.upgradePlanAndDevice(request4)).thenReturn(Mono.just(response4));
//		when(redisHelper3.fetchCustomerAddressFromRedis()).thenReturn(Mono.just(new CustomerProfileAddressResponse()));
//		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(any(),eq("device"))).thenReturn(Mono.just(Boolean.TRUE));
//		Mono<ResponseEntity<GenericResponse>> controllerResponse4 = cartController.upgradePlanAndDevice(httpHeader4, httpResponse4,
//				request4);
//		StepVerifier.create(controllerResponse4).expectError().verify();
//	}

	@Test
	public void addPlanAndDeviceTest2() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"EXPRESS_STORE\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"intendType\":\"AAL_5G\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"EXPRESS_STORE\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-5188491-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Accessories\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Accessories\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-D-410f65a0-8535-471c-b1b3-0d14cbfcbd26\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":1,\"cartId\":\"6af05322-815c-423c-9bb2-9b0fce190075\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"onDemandAllowed\":false,\"backDateAllowed\":false,\"futureDateAllowed\":false,\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"lines\":[{\"status\":1,\"spos\":[{\"id\":\"732\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false},{\"id\":\"1508\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false}],\"sfos\":[{\"id\":\"48526\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"48553\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"54307\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68872\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"70421\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78003\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"83856\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"85503\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86112\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86926\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86927\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86928\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86952\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86953\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false}],\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"mtn\":\"newLine1\",\"isDeviceSelected\":true,\"userSelectedPlan\":false,\"lineId\":\"newLine1\",\"sortingNumber\":\"0\",\"device\":{\"id\":\"LVSKIHP\",\"itemPrice\":\"0.0\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"5G Internet Gateway\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false},\"sim\":{\"id\":\"NI-DPSIM\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"NSE_5G\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"isAppendedLine\":false,\"fiveGPlanAdded\":false}],\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]}]}}}}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);
		URI url = URI.create("http://localhost/cart/nse/add-device");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "EXPRESS_STORE").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response));

		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addPlanAndDevice(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void addPlanAndDeviceTest3() throws IOException {
		String requestString = "{\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-5188491-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Accessories\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Accessories\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-D-410f65a0-8535-471c-b1b3-0d14cbfcbd26\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":1,\"cartId\":\"6af05322-815c-423c-9bb2-9b0fce190075\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"onDemandAllowed\":false,\"backDateAllowed\":false,\"futureDateAllowed\":false,\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"lines\":[{\"status\":1,\"spos\":[{\"id\":\"732\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false},{\"id\":\"1508\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false}],\"sfos\":[{\"id\":\"48526\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"48553\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"54307\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68872\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"70421\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78003\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"83856\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"85503\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86112\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86926\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86927\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86928\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86952\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86953\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false}],\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"mtn\":\"newLine1\",\"isDeviceSelected\":true,\"userSelectedPlan\":false,\"lineId\":\"newLine1\",\"sortingNumber\":\"0\",\"device\":{\"id\":\"LVSKIHP\",\"itemPrice\":\"0.0\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"5G Internet Gateway\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false},\"sim\":{\"id\":\"NI-DPSIM\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"NSE_5G\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"isAppendedLine\":false,\"fiveGPlanAdded\":false}],\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]}]}}}}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);
		URI url = URI.create("http://localhost/5g/updateCart");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response));

		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addPlanAndDevice(httpHeader, httpResponse,
				request);
		Assert.assertNotNull(controllerResponse);
	}

	@Test
	public void addPlanAndDeviceTest4() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"intendType\":\"AAL_5G\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{}}}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);
		URI url = URI.create("http://localhost/cart/nse/add-device");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response));

		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addPlanAndDevice(httpHeader, httpResponse,
				request);
		Assert.assertNotNull(controllerResponse);
	}


	@Test  // Gen2-Gen3 updateCart
	public void swapUpdateCartErrorTest() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"8135199979\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"intendType\":\"EUP_5G_REPAIR\",\"bundleInstallType\":\"5GHomeGeminiProfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"O\"}]}}";
		String responseString="{\"errors\":[{\"id\":\"001\",\"namespace\":\"CartService\"}]}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);
		URI url = URI.create("http://localhost/5g/swap/updateCart");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.upgradePlanAndDevice(request)).thenReturn(Mono.just(response));
		when(redisHelper3.fetchCustomerAddressFromRedis()).thenReturn(Mono.just(new CustomerProfileAddressResponse()));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(any(),eq("device"))).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.upgradePlanAndDevice(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

//	@Test  // Gen2-Gen3 updateCart
//	public void swapUpdateCartTest5() throws IOException {
//		String requestString5 = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"8135199979\",\"processingMTN\":\"newline1\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"intendType\":\"EUP_5G_REPAIR\",\"bundleInstallType\":\"5GHomeGeminiProfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"O\"}]}}";
//		String responseString5="{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4629485-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"0430568040-00001\",\"cartCreator\":\"8135199979\",\"processingMTN\":\"8135199979\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":1,\"cartId\":\"2a74d680-a043-4d53-8836-802edb5c7e49\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"lines\":[{}],\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"8135199979\",\"completedprocessSteps\":[]},{\"mtn\":\"8135199979\",\"completedprocessSteps\":[]}]}}}}";
//		AddPlanAndDeviceUIRequest request5 = mapper.readValue(requestString5, AddPlanAndDeviceUIRequest.class);
//		AddPlanAndDeviceUIResponse response5 = mapper.readValue(responseString5, AddPlanAndDeviceUIResponse.class);
//		URI url5 = URI.create("http://localhost/5g/swap/updateCart");
//		MockServerHttpRequest httpHeader5 = MockServerHttpRequest.method(HttpMethod.POST, url5).build();
//		ServerHttpResponse httpResponse5 = new MockServerHttpResponse();
//		httpResponse5.setStatusCode(HttpStatus.PARTIAL_CONTENT);
//		when(readCartHelper.upgradePlanAndDevice(request5)).thenReturn(Mono.just(response5));
//		when(redisHelper3.fetchCustomerAddressFromRedis()).thenReturn(Mono.just(new CustomerProfileAddressResponse()));
//		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(any(),eq("device"))).thenReturn(Mono.just(Boolean.TRUE));
//		Mono<ResponseEntity<GenericResponse>> controllerResponse5 = cartController.upgradePlanAndDevice(httpHeader5, httpResponse5,
//				request5);
//		StepVerifier.create(controllerResponse5).expectError().verify();
//	}

	@Test
	public void validateAndApplyCouponTest() throws JsonProcessingException {
		URI url = URI.create("http://localhost/5g/validate-apply-coupon");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.PARTIAL_CONTENT);
		String responseString="{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4629485-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"0430568040-00001\",\"cartCreator\":\"8135199979\",\"processingMTN\":\"8135199979\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":1,\"cartId\":\"2a74d680-a043-4d53-8836-802edb5c7e49\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"lines\":[{}],\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"8135199979\",\"completedprocessSteps\":[]},{\"mtn\":\"8135199979\",\"completedprocessSteps\":[]}]}}}}";
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);
		when(readCartHelper.validateAndUpdateCouponToCart(Mockito.any())).thenReturn(Mono.just(response));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.validateAndApplyCoupon(httpHeader, httpResponse,
				new FWAUpdateCouponUIRequest());
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void validateAndApplyCoupon2Test() throws JsonProcessingException {
		URI url = URI.create("http://localhost/5g/validate-apply-coupon");

		HttpCookie topkey = new HttpCookie("visibleTest", "s1");
		MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
		bodyMap.add("visibleTest", topkey);
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).cookies(bodyMap).build();

		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.PARTIAL_CONTENT);
		String responseString="{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4629485-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"0430568040-00001\",\"cartCreator\":\"8135199979\",\"processingMTN\":\"8135199979\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":1,\"cartId\":\"2a74d680-a043-4d53-8836-802edb5c7e49\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"lines\":[{}],\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"8135199979\",\"completedprocessSteps\":[]},{\"mtn\":\"8135199979\",\"completedprocessSteps\":[]}]}}}}";
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);
		when(readCartHelper.validateAndUpdateCouponToCart(Mockito.any())).thenReturn(Mono.just(response));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.validateAndApplyCoupon(httpHeader, httpResponse,
				new FWAUpdateCouponUIRequest());
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		URI url1 = URI.create("http://localhost/5g/validate-apply-coupon");

		HttpCookie topkey1 = new HttpCookie("visibleTest", null);
		MultiValueMap<String, HttpCookie> bodyMap1 = new LinkedMultiValueMap<String, HttpCookie>();
		bodyMap.add("visibleTest", topkey1);
		MockServerHttpRequest httpHeader1 = MockServerHttpRequest.method(HttpMethod.POST, url1).cookies(bodyMap1).build();

		Mono<ResponseEntity<GenericResponse>> controllerResponse1 = cartController.validateAndApplyCoupon(httpHeader1, httpResponse,
				new FWAUpdateCouponUIRequest());
		StepVerifier.create(controllerResponse1).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test  // updateProcessStep
	public void updateProcessStepTest6() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"newLine1\",\"processStep\":\"OrderNow\",\"processAction\":\"Complete\",\"intendType\":\"EUP_LTE\",\"bundleInstallType\":\"\"},\"data\":{}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4387896-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"0280000250-00001\",\"cartCreator\":\"3166127651\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"existingCase\":\"\"},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"InstallType\"]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"InstallType\"]}]}}}}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);// AddPlanAndDeviceUIResponse
		HttpHeaders headers = new HttpHeaders();
		headers.add("path","/cart/nse/add-device");
		URI url = URI.create("http://localhost/5g/updateProcessStep");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(headers).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(request)).thenReturn(Mono.just(response));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
		when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));

		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.updateProcessStep(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test  // updateProcessStep
	public void updateProcessStepTest7() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"newLine1\",\"processStep\":\"Complete\",\"processAction\":\"Complete\",\"intendType\":\"EUP_LTE\",\"bundleInstallType\":\"\"},\"data\":{}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4387896-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"0280000250-00001\",\"cartCreator\":\"3166127651\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"existingCase\":\"\"},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"InstallType\"]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"InstallType\"]}]}}}}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);// AddPlanAndDeviceUIResponse
		URI url = URI.create("http://localhost/5g/updateProcessStep");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(request)).thenReturn(Mono.just(response));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
		when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));

		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.updateProcessStep(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		String requestString8 = "{\"cartInfo\":{\"clientAppName\":\"OMNI-RETAIL\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"newLine1\",\"processStep\":\"Complete\",\"processAction\":\"Complete\",\"intendType\":\"EUP_LTE\",\"bundleInstallType\":\"\"},\"data\":{}}";
		String responseString8 = "{\"serviceHeader\":{\"clientId\":\"OMNI-RETAIL\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4387896-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"0280000250-00001\",\"cartCreator\":\"3166127651\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"existingCase\":\"\"},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"InstallType\"]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"InstallType\"]}]}}}}";
		AddPlanAndDeviceUIRequest request8 = mapper.readValue(requestString8, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response8 = mapper.readValue(responseString8, AddPlanAndDeviceUIResponse.class);// AddPlanAndDeviceUIResponse
		URI url8 = URI.create("http://localhost/5g/updateProcessStep");
		MockServerHttpRequest httpHeader8 = MockServerHttpRequest.method(HttpMethod.POST, url8).header("channelId","OMNI-RETAIL").build();
		ServerHttpResponse httpResponse8 = new MockServerHttpResponse();
		httpResponse8.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(request8)).thenReturn(Mono.just(response8));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
		when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));

		Mono<ResponseEntity<GenericResponse>> controllerResponse8 = cartController.updateProcessStep(httpHeader8, httpResponse8,
				request8);
		StepVerifier.create(controllerResponse8).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		String requestString9 = "{\"cartInfo\":{\"clientAppName\":\"OMNI-RETAIL\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"newLine1\",\"processStep\":\"Complete\",\"processAction\":\"Complete\",\"intendType\":\"EUP_LTE\",\"bundleInstallType\":\"\"},\"data\":{}}";
		String responseString9 = "{\"serviceHeader\":{\"clientId\":\"OMNI-RETAIL\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"}}";
		AddPlanAndDeviceUIRequest request9 = mapper.readValue(requestString9, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response9 = mapper.readValue(responseString9, AddPlanAndDeviceUIResponse.class);// AddPlanAndDeviceUIResponse
		URI url9 = URI.create("http://localhost/5g/updateProcessStep");
		MockServerHttpRequest httpHeader9 = MockServerHttpRequest.method(HttpMethod.POST, url9).header("channelId","OMNI-RETAIL").build();
		ServerHttpResponse httpResponse9 = new MockServerHttpResponse();
		httpResponse9.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(request9)).thenReturn(Mono.just(response9));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
		when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));

		Mono<ResponseEntity<GenericResponse>> controllerResponse9 = cartController.updateProcessStep(httpHeader9, httpResponse9,
				request9);
		StepVerifier.create(controllerResponse9).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

//	@Test  // updateProcessStep
//	public void updateProcessStepTest8() throws IOException {
//		String requestString8 = "{\"cartInfo\":{\"clientAppName\":\"OMNI-RETAIL\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"newLine1\",\"processStep\":\"Complete\",\"processAction\":\"Complete\",\"intendType\":\"EUP_LTE\",\"bundleInstallType\":\"\"},\"data\":{}}";
//		String responseString8 = "{\"serviceHeader\":{\"clientId\":\"OMNI-RETAIL\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4387896-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"0280000250-00001\",\"cartCreator\":\"3166127651\",\"processingMTN\":\"newLine1\",\"registerNumber\":0,\"existingCase\":\"\"},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"InstallType\"]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[\"Accessories\",\"ShoppingCart\",\"InstallType\"]}]}}}}";
//		AddPlanAndDeviceUIRequest request8 = mapper.readValue(requestString8, AddPlanAndDeviceUIRequest.class);
//		AddPlanAndDeviceUIResponse response8 = mapper.readValue(responseString8, AddPlanAndDeviceUIResponse.class);// AddPlanAndDeviceUIResponse
//		URI url8 = URI.create("http://localhost/5g/updateProcessStep");
//		MockServerHttpRequest httpHeader8 = MockServerHttpRequest.method(HttpMethod.POST, url8).header("channelId","OMNI-RETAIL").build();
//		ServerHttpResponse httpResponse8 = new MockServerHttpResponse();
//		httpResponse8.setStatusCode(HttpStatus.CONTINUE);
//		when(readCartHelper.addPlanAndDevice(request8)).thenReturn(Mono.just(response8));
//		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
//		when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
//
//		Mono<ResponseEntity<GenericResponse>> controllerResponse8 = cartController.updateProcessStep(httpHeader8, httpResponse8,
//				request8);
//		StepVerifier.create(controllerResponse8).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
//				.verify();
//	}

//	@Test  // updateProcessStep
//	public void updateProcessStepTest9() throws IOException {
//		String requestString9 = "{\"cartInfo\":{\"clientAppName\":\"OMNI-RETAIL\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"newLine1\",\"processStep\":\"Complete\",\"processAction\":\"Complete\",\"intendType\":\"EUP_LTE\",\"bundleInstallType\":\"\"},\"data\":{}}";
//		String responseString9 = "{\"serviceHeader\":{\"clientId\":\"OMNI-RETAIL\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"}}";
//		AddPlanAndDeviceUIRequest request9 = mapper.readValue(requestString9, AddPlanAndDeviceUIRequest.class);
//		AddPlanAndDeviceUIResponse response9 = mapper.readValue(responseString9, AddPlanAndDeviceUIResponse.class);// AddPlanAndDeviceUIResponse
//		URI url9 = URI.create("http://localhost/5g/updateProcessStep");
//		MockServerHttpRequest httpHeader9 = MockServerHttpRequest.method(HttpMethod.POST, url9).header("channelId","OMNI-RETAIL").build();
//		ServerHttpResponse httpResponse9 = new MockServerHttpResponse();
//		httpResponse9.setStatusCode(HttpStatus.CONTINUE);
//		when(readCartHelper.addPlanAndDevice(request9)).thenReturn(Mono.just(response9));
//		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
//		when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));
//
//		Mono<ResponseEntity<GenericResponse>> controllerResponse9 = cartController.updateProcessStep(httpHeader9, httpResponse9,
//				request9);
//		StepVerifier.create(controllerResponse9).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
//				.verify();
//	}

	@Test
	public void updateProcessStepErrorsTest1() throws IOException {
		String requestString = "{\"cartInfo\":{\"covidQuestionareAnswered\":true,\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"processStep\":\"InstallType\",\"processAction\":\"Complete\",\"bundleInstallType\":\"\"},\"data\":{}}";
		String responseString = "{\"errors\":[{\"namespace\":\"CartService\",\"id\":\"3226\"}]}";		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);// AddPlanAndDeviceUIResponse
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("channelId","OMNI-RETAIL");
		URI url = URI.create("http://localhost/5g/updateProcessStep");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).headers(httpHeaders).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.PARTIAL_CONTENT);
		when(readCartHelper.addPlanAndDevice(request)).thenReturn(Mono.just(response));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
		when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));

		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.updateProcessStep(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void updateProcessStepErrorsTest2() throws IOException {
		String requestString = "{\"cartInfo\":{\"covidQuestionareAnswered\":true,\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"processStep\":\"InstallType\",\"processAction\":\"Complete\",\"bundleInstallType\":\"\"},\"data\":{}}";
		String responseString = "{\"errors\":[{\"namespace\":\"CartService\",\"id\":\"3226\"}]}";		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);// AddPlanAndDeviceUIResponse
		URI url = URI.create("http://localhost/5g/updateProcessStep");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.PARTIAL_CONTENT);
		when(readCartHelper.addPlanAndDevice(request)).thenReturn(Mono.just(response));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(),Mockito.any())).thenReturn(Mono.just(true));
		when(sessionBean.setSessionData(Mockito.any())).thenReturn(Mono.just(true));

		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.updateProcessStep(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test  // Gen2-Gen3 updateCart
	public void swapUpdateCartTest6() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"8135199979\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"intendType\":\"EUP_5G_REPAIR\",\"bundleInstallType\":\"5GHomeGeminiProfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"O\"}]}}";
		String responseString="{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4629485-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"0430568040-00001\",\"cartCreator\":\"8135199979\",\"processingMTN\":\"8135199979\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":1,\"cartId\":\"2a74d680-a043-4d53-8836-802edb5c7e49\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"8135199979\",\"completedprocessSteps\":[]},{\"mtn\":\"8135199979\",\"completedprocessSteps\":[]}]}}}}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);
		URI url = URI.create("http://localhost/5g/swap/updateCart");

		HttpCookie ecpd = new HttpCookie("ecpd", "token");
		MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
		bodyMap.add("ecpd", ecpd);
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-DOTCOM").cookies(bodyMap).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.upgradePlanAndDevice(request)).thenReturn(Mono.just(response));
		when(redisHelper3.fetchCustomerAddressFromRedis()).thenReturn(Mono.just(new CustomerProfileAddressResponse()));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(any(),eq("device"))).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.upgradePlanAndDevice(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test  // Gen2-Gen3 updateCart
	public void swapUpdateCartTest7() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"8135199979\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"intendType\":\"EUP_5G_REPAIR\",\"bundleInstallType\":\"5GHomeGeminiProfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"O\"}]}}";
		String responseString="{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-4629485-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"ShoppingCart\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"ShoppingCart\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"0430568040-00001\",\"cartCreator\":\"8135199979\",\"processingMTN\":\"8135199979\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":1,\"cartId\":\"2a74d680-a043-4d53-8836-802edb5c7e49\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"lines\":[],\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"8135199979\",\"completedprocessSteps\":[]},{\"mtn\":\"8135199979\",\"completedprocessSteps\":[]}]}}}}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);
		URI url = URI.create("http://localhost/5g/swap/updateCart");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId","VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.upgradePlanAndDevice(request)).thenReturn(Mono.just(response));
		when(redisHelper3.fetchCustomerAddressFromRedis()).thenReturn(Mono.just(new CustomerProfileAddressResponse()));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(any(),eq("device"))).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.upgradePlanAndDevice(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void retrieveReviewOrderTechCbandDataTest1() throws JsonProcessingException {
		String requestString = "{\"meta\":{}}";
		String cartId="";
		GetCartDetailsRequest request = mapper.readValue(requestString, GetCartDetailsRequest.class);
		URI url = URI.create("http://localhost/cart/5g/cbd/getReviewOrderData");
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("GLOBALID", "VZW-DOTCOM");
		//httpHeaders.add("channelId", "Digital");
		httpHeaders.add("digital_ig_session", "digital_ig_session_12345");
		HttpCookie cookie = new HttpCookie("GLOBALID", "VZW-DOTCOM");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.post(url.toString()).headers(httpHeaders).cookie(cookie).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		InspicioResponseOrderInfo inspicioResponseOrderInfo=new InspicioResponseOrderInfo();
		InspicioTermsAndConditions inspicioTermsAndConditions =new InspicioTermsAndConditions();
		when(redisHelper2.getCartIdFromRedis()).thenReturn(Mono.just(cartId));
		when(fiveGhomeTechHelper.getTechCbandCart5GCart(Mockito.any(),Mockito.any())).thenReturn(Mono.just(inspicioResponseOrderInfo));
		when(readCartHelper.getAgreementDetails(Mockito.any())).thenReturn(Mono.just(inspicioTermsAndConditions));
		Mono<ReviewOrderData> retrieveReviewOrder=cartController.retrieveReviewOrderTechCbandData(httpHeader,httpResponse,request);
		StepVerifier.create(retrieveReviewOrder).assertNext(resp -> org.junit.Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void addPlanAndDeviceWithCookiesTest2() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"intendType\":\"EUP_LTE\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-5188491-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Accessories\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Accessories\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-D-410f65a0-8535-471c-b1b3-0d14cbfcbd26\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":1,\"cartId\":\"6af05322-815c-423c-9bb2-9b0fce190075\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"onDemandAllowed\":false,\"backDateAllowed\":false,\"futureDateAllowed\":false,\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"lines\":[{\"status\":1,\"spos\":[{\"id\":\"732\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false},{\"id\":\"1508\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false}],\"sfos\":[{\"id\":\"48526\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"48553\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"54307\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68872\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"70421\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78003\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"83856\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"85503\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86112\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86926\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86927\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86928\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86952\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86953\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false}],\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"isDeviceSelected\":true,\"userSelectedPlan\":false,\"lineId\":\"newLine1\",\"sortingNumber\":\"0\",\"device\":{\"id\":\"LVSKIHP\",\"itemPrice\":\"0.0\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"5G Internet Gateway\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false},\"sim\":{\"id\":\"NI-DPSIM\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"NSE_5G\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"isAppendedLine\":false,\"fiveGPlanAdded\":false}],\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]}]}}}}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);
		System.out.println(request.getChannelId());
		URI url = URI.create("http://localhost/5g/updateCart");
		HttpCookie digital_ig_session = new HttpCookie("digital_ig_session", "digital_ig_session");
		HttpCookie domainCookie = new HttpCookie("domainCookie", "domainCookie");
		HttpCookie ecpdcookie = new HttpCookie("ecpdcookie", "ecpd");
		MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
		bodyMap.add("digital_ig_session", digital_ig_session);
		bodyMap.add("domainCookie", domainCookie);
		bodyMap.add("ecpdcookie", ecpdcookie);
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookies(bodyMap).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addPlanAndDevice(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

	@Test
	public void addPlanAndDeviceWithCookiesTest3() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"0245678-001\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"ORDER\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"intendType\":\"EUP_LTE\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-5188491-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Accessories\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Accessories\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-D-410f65a0-8535-471c-b1b3-0d14cbfcbd26\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]}]}}}}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);
		System.out.println(request.getChannelId());
		URI url = URI.create("http://localhost/5g/updateCart");
		HttpCookie digital_ig_session = new HttpCookie("digital_ig_session", "digital_ig_session");
		HttpCookie domainCookie = new HttpCookie("domainCookie", "domainCookie");
		HttpCookie ecpdcookie = new HttpCookie("ecpdcookie", "ecpd");
		MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
		bodyMap.add("digital_ig_session", digital_ig_session);
		bodyMap.add("domainCookie", domainCookie);
		bodyMap.add("ecpdcookie", ecpdcookie);
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookies(bodyMap).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addPlanAndDevice(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse.log()).expectError().verify();
	}

	public void addPlanAndDeviceTest5() throws IOException {
		String requestString = "{\"cartInfo\":{\"disableMyLink\":false,\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"0245678-001\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"Order\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"intendType\":\"EUP_LTE\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-5188491-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Accessories\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Accessories\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-D-410f65a0-8535-471c-b1b3-0d14cbfcbd26\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]}]}}}}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);
		System.out.println(request.getChannelId());
		URI url = URI.create("http://localhost/5g/updateCart");
		HttpCookie digital_ig_session = new HttpCookie("digital_ig_session", "digital_ig_session");
		HttpCookie domainCookie = new HttpCookie("domainCookie", "domainCookie");
		HttpCookie ecpdcookie = new HttpCookie("ecpdcookie", "ecpd");
		MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
		bodyMap.add("digital_ig_session", digital_ig_session);
		bodyMap.add("domainCookie", domainCookie);
		bodyMap.add("ecpdcookie", ecpdcookie);
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookies(bodyMap).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addPlanAndDevice(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse.log()).expectError().verify();
	}

	public void addPlanAndDeviceTest6() throws IOException {
		String requestString = "{\"cartInfo\":{\"disableMyLink\":true,\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"0245678-001\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"Order\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"intendType\":\"BYOD\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-5188491-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Accessories\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Accessories\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-D-410f65a0-8535-471c-b1b3-0d14cbfcbd26\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]}]}}}}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);
		System.out.println(request.getChannelId());
		URI url = URI.create("http://localhost/5g/updateCart");
		HttpCookie digital_ig_session = new HttpCookie("digital_ig_session", "digital_ig_session");
		HttpCookie domainCookie = new HttpCookie("domainCookie", "domainCookie");
		HttpCookie ecpdcookie = new HttpCookie("ecpdcookie", "ecpd");
		MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
		bodyMap.add("digital_ig_session", digital_ig_session);
		bodyMap.add("domainCookie", domainCookie);
		bodyMap.add("ecpdcookie", ecpdcookie);
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookies(bodyMap).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addPlanAndDevice(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse.log()).expectError().verify();
	}

	public void addPlanAndDeviceTest7() throws IOException {
		String requestString = "{\"cartInfo\":{\"disableMyLink\":true,\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"0245678-001\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"Order\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"intendType\":\"BYOD\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{}}}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);
		System.out.println(request.getChannelId());
		URI url = URI.create("http://localhost/5g/updateCart");
		HttpCookie digital_ig_session = new HttpCookie("digital_ig_session", "digital_ig_session");
		HttpCookie domainCookie = new HttpCookie("domainCookie", "domainCookie");
		HttpCookie ecpdcookie = new HttpCookie("ecpdcookie", "ecpd");
		MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
		bodyMap.add("digital_ig_session", digital_ig_session);
		bodyMap.add("domainCookie", domainCookie);
		bodyMap.add("ecpdcookie", ecpdcookie);
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").cookies(bodyMap).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addPlanAndDevice(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse.log()).expectError().verify();
	}

	public void addPlanAndDeviceTest8() throws IOException {
		String requestString = "{\"cartInfo\":{\"disableMyLink\":true,\"clientAppName\":\"OMNI-RETAIL\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"0245678-001\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"Order\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"intendType\":\"BYOD\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
		String responseString = "{\"serviceHeader\":{\"clientId\":\"OMNI-RETAIL\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{}}}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);
		System.out.println(request.getChannelId());
		URI url = URI.create("http://localhost/5g/updateCart");
		HttpCookie digital_ig_session = new HttpCookie("digital_ig_session", "digital_ig_session");
		HttpCookie domainCookie = new HttpCookie("domainCookie", "domainCookie");
		HttpCookie ecpdcookie = new HttpCookie("ecpdcookie", "ecpd");
		MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
		bodyMap.add("digital_ig_session", digital_ig_session);
		bodyMap.add("domainCookie", domainCookie);
		bodyMap.add("ecpdcookie", ecpdcookie);
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").cookies(bodyMap).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addPlanAndDevice(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse.log()).expectError().verify();
	}

	private String getData(String jsonFilePath) throws IOException {
		File file = ResourceUtils.getFile(jsonFilePath);
		String data = new String(Files.readAllBytes(file.toPath()));
		return new String(data.getBytes(StandardCharsets.UTF_8));
	}

	@Test
	public void addTruckRollCartTest() throws IOException {
		URI url = URI.create("http://localhost/");
		HttpCookie digital_ig_session = new HttpCookie("digital_ig_session", "digital_ig_session");
		HttpCookie domainCookie = new HttpCookie("domainCookie", "domainCookie");
		HttpCookie ecpdcookie = new HttpCookie("ecpdcookie", "ecpd");
		MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
		bodyMap.add("digital_ig_session", digital_ig_session);
		bodyMap.add("domainCookie", domainCookie);
		bodyMap.add("ecpdcookie", ecpdcookie);
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").cookies(bodyMap).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);

		String requestString = getData("classpath:AddTruckRollCartUIRequest.json");
		AddTruckRollCartUIRequest addTruckRollCartUIRequest = mapper.readValue(requestString, AddTruckRollCartUIRequest.class);
		String responseString = getData("classpath:AddTruckRollCartBPMResponse.json");
		AddTruckRollCartUIResponse addTruckRollCartUIResponse = mapper.readValue(responseString, AddTruckRollCartUIResponse.class);
		OrderReviewDetailsResponse orderReviewDetailsResponse = new OrderReviewDetailsResponse();
		OrderReviewDetails data = new OrderReviewDetails();
		LineDetails lineDetails = new LineDetails();
		LineInfo lineInfo = new LineInfo();
		ServiceInfo serviceInfo = new ServiceInfo();
		Cart5GAppointment cart5GAppointment = new Cart5GAppointment();
		serviceInfo.setCart5GAppointment(cart5GAppointment);
		lineInfo.setAssignMTNIndicator("assignmtn");
		lineInfo.setServiceInfo(serviceInfo);
		List<LineInfo> lines = new ArrayList<>();
		lines.add(lineInfo);
		Cart cart = new Cart();
		cart.setCartId("123");
		cart.setLineDetails(lineDetails);
		lineDetails.setLineInfo(lines);
		data.setCart(cart);
		orderReviewDetailsResponse.setData(data);
		when(readCartHelper.addTruckRollCart(addTruckRollCartUIRequest, httpHeader)).thenReturn(Mono.just(addTruckRollCartUIResponse));
		when(readCartHelper.orderReviewDetails(addTruckRollCartUIResponse)).thenReturn(Mono.just(orderReviewDetailsResponse));
		Mono<AddTruckRollCartUIResponse> addTruckRollCartResponse = cartController.addTruckRollCart(httpHeader, httpResponse, addTruckRollCartUIRequest);
		StepVerifier.create(addTruckRollCartResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void addPlanAndDeviceTestForExpressCheckout() throws IOException {
		String requestString = "{\"cartInfo\": {\"clientAppName\": \"VZW-DOTCOM\",\"accountNumber\": \"\",\"cartCreator\": \"\",\"processingMTN\": \"\",\"processStep\": \"OrderNow\",\"processAction\": \"DeviceAndPlan\",\"intendType\": \"NSE_5G\",\"bundleInstallType\": \"Gen4-5G-Home-Internet-Self-Setup\"},\"data\": {\"lines\": [{\"depletionType\": \"F\"}]},\"midnight\": \"Y\"}";
		String responseString = "{\"serviceHeader\": {\"clientId\": \"VZW-DOTCOM\",\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"contextInfo\": {\"availablePaths\": [{\"path\": \"Accessories\"},{\"path\": \"PlanSelection\"}],\"pendingOrderAccountLevel\": \"false\",\"callReason\": \"SalesOrderPurchase\",\"processStep\": \"ShoppingCart\",\"processAction\": \"\",\"pastDueBalanceAmount\": \"\"},\"customerInfo\": {\"accountNumber\": \"\",\"cartCreator\": \"POW-D-11c98874-352b-4471-84cf-8a080e13e37b\",\"processingMTN\": \"newLine1\",\"registerNumber\": 0,\"existingCase\": \"true\",\"vfExistInCart\": false,\"fwaExpressCheckout\":true},\"cartInfo\": {\"cartItemCount\": 0,\"updateShippingAddress\": false,\"discountPromoTotal\": 0.0,\"registerNumber\": 0,\"cartExist\": \"Y\"},\"processMTNList\": [{\"mtn\": \"newLine1\",\"completedprocessSteps\": [\"PlanSelection\",\"Accessories\",\"Accessories\",\"InstallType\",\"OrderNow\"]},{\"mtn\": \"newLine1\",\"completedprocessSteps\": [\"PlanSelection\",\"Accessories\",\"Accessories\",\"InstallType\",\"OrderNow\"]}]}}}}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);
		System.out.println(request.getChannelId());
		URI url = URI.create("http://localhost/cart/nse/5g/updateCart");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addPlanAndDevice(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		String requestString2 = "{\"cartInfo\": {\"clientAppName\": \"VZW-DOTCOM\",\"accountNumber\": \"\",\"cartCreator\": \"\",\"processingMTN\": \"\",\"processStep\": \"OrderNow\",\"processAction\": \"DeviceAndPlan\",\"intendType\": \"NSE_5G\",\"bundleInstallType\": \"Gen4-5G-Home-Internet-Self-Setup\"},\"data\": {\"lines\": [{\"depletionType\": \"F\"}]},\"midnight\": \"Y\"}";
		String responseString2 = "{\"serviceHeader\": {\"clientId\": \"VZW-DOTCOM\",\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"contextInfo\": {\"availablePaths\": [{\"path\": \"Accessories\"},{\"path\": \"PlanSelection\"}],\"pendingOrderAccountLevel\": \"false\",\"callReason\": \"SalesOrderPurchase\",\"processStep\": \"ShoppingCart\",\"processAction\": \"\",\"pastDueBalanceAmount\": \"\"},\"customerInfo\": {\"accountNumber\": \"\",\"cartCreator\": \"POW-D-11c98874-352b-4471-84cf-8a080e13e37b\",\"processingMTN\": \"newLine1\",\"registerNumber\": 0,\"existingCase\": \"true\",\"vfExistInCart\": false},\"cartInfo\": {\"cartItemCount\": 0,\"updateShippingAddress\": false,\"discountPromoTotal\": 0.0,\"registerNumber\": 0,\"cartExist\": \"Y\"},\"processMTNList\": [{\"mtn\": \"newLine1\",\"completedprocessSteps\": [\"PlanSelection\",\"Accessories\",\"Accessories\",\"InstallType\",\"OrderNow\"]},{\"mtn\": \"newLine1\",\"completedprocessSteps\": [\"PlanSelection\",\"Accessories\",\"Accessories\",\"InstallType\",\"OrderNow\"]}]}}}}";
		AddPlanAndDeviceUIRequest request2 = mapper.readValue(requestString2, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response2 = mapper.readValue(responseString2, AddPlanAndDeviceUIResponse.class);
		System.out.println(request2.getChannelId());
		URI url2 = URI.create("http://localhost/cart/nse/5g/updateCart");
		MockServerHttpRequest httpHeader2 = MockServerHttpRequest.method(HttpMethod.POST, url2).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse2 = new MockServerHttpResponse();
		httpResponse2.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response2));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse2 = cartController.addPlanAndDevice(httpHeader2, httpResponse2,
				request2);
		StepVerifier.create(controllerResponse2).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		String requestString3 = "{\"cartInfo\": {\"clientAppName\": \"VZW-DOTCOM\",\"accountNumber\": \"\",\"cartCreator\": \"\",\"processingMTN\": \"\",\"processStep\": \"Accessories\",\"processAction\": \"DeviceAndPlan\",\"intendType\": \"NSE_5G\",\"bundleInstallType\": \"Gen4-5G-Home-Internet-Self-Setup\"},\"data\": {\"lines\": [{\"depletionType\": \"F\"}]},\"midnight\": \"Y\"}";
		String responseString3 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-5188491-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Accessories\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Accessories\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-D-410f65a0-8535-471c-b1b3-0d14cbfcbd26\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]}]}}}}";
		AddPlanAndDeviceUIRequest request3 = mapper.readValue(requestString3, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response3 = mapper.readValue(responseString3, AddPlanAndDeviceUIResponse.class);
		System.out.println(request3.getChannelId());
		URI url3 = URI.create("http://localhost/cart/nse/5g/updateCart");
		MockServerHttpRequest httpHeader3 = MockServerHttpRequest.method(HttpMethod.POST, url3).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse3 = new MockServerHttpResponse();
		httpResponse3.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response3));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse3 = cartController.addPlanAndDevice(httpHeader3, httpResponse3,
				request3);
		StepVerifier.create(controllerResponse3).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		String requestString4 = "{\"cartInfo\": {\"clientAppName\": \"VZW-DOTCOM\",\"accountNumber\": \"\",\"cartCreator\": \"\",\"processingMTN\": \"\",\"processStep\": \"OrderNow\",\"processAction\": \"DeviceAndPlan\",\"action\": \"Resume\",\"intendType\": \"NSE_5G\",\"bundleInstallType\": \"Gen4-5G-Home-Internet-Self-Setup\"},\"data\": {\"lines\": [{\"depletionType\": \"F\"}]},\"midnight\": \"Y\"}";
		String responseString4 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-5188491-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Accessories\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Accessories\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-D-410f65a0-8535-471c-b1b3-0d14cbfcbd26\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]}]}}}}";
		AddPlanAndDeviceUIRequest request4 = mapper.readValue(requestString4, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response4 = mapper.readValue(responseString4, AddPlanAndDeviceUIResponse.class);
		System.out.println(request4.getChannelId());
		URI url4 = URI.create("http://localhost/cart/nse/5g/updateCart");
		MockServerHttpRequest httpHeader4 = MockServerHttpRequest.method(HttpMethod.POST, url4).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse4 = new MockServerHttpResponse();
		httpResponse4.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response4));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse4 = cartController.addPlanAndDevice(httpHeader4, httpResponse4,
				request4);
		StepVerifier.create(controllerResponse4).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}
//	@Test
//	public void addPlanAndDeviceTestForExpressCheckoutNegative() throws IOException {
//		String requestString2 = "{\"cartInfo\": {\"clientAppName\": \"VZW-DOTCOM\",\"accountNumber\": \"\",\"cartCreator\": \"\",\"processingMTN\": \"\",\"processStep\": \"OrderNow\",\"processAction\": \"DeviceAndPlan\",\"intendType\": \"NSE_5G\",\"bundleInstallType\": \"Gen4-5G-Home-Internet-Self-Setup\"},\"data\": {\"lines\": [{\"depletionType\": \"F\"}]},\"midnight\": \"Y\"}";
//		String responseString2 = "{\"serviceHeader\": {\"clientId\": \"VZW-DOTCOM\",\"statusMsg\": \"SUCCESS\",\"serviceName\": \"SalesOrderPurchase\",\"userId\": \"\",\"statusCode\": \"00\"},\"serviceBody\": {\"serviceResponse\": {\"context\": {\"contextInfo\": {\"availablePaths\": [{\"path\": \"Accessories\"},{\"path\": \"PlanSelection\"}],\"pendingOrderAccountLevel\": \"false\",\"callReason\": \"SalesOrderPurchase\",\"processStep\": \"ShoppingCart\",\"processAction\": \"\",\"pastDueBalanceAmount\": \"\"},\"customerInfo\": {\"accountNumber\": \"\",\"cartCreator\": \"POW-D-11c98874-352b-4471-84cf-8a080e13e37b\",\"processingMTN\": \"newLine1\",\"registerNumber\": 0,\"existingCase\": \"true\",\"vfExistInCart\": false},\"cartInfo\": {\"cartItemCount\": 0,\"updateShippingAddress\": false,\"discountPromoTotal\": 0.0,\"registerNumber\": 0,\"cartExist\": \"Y\"},\"processMTNList\": [{\"mtn\": \"newLine1\",\"completedprocessSteps\": [\"PlanSelection\",\"Accessories\",\"Accessories\",\"InstallType\",\"OrderNow\"]},{\"mtn\": \"newLine1\",\"completedprocessSteps\": [\"PlanSelection\",\"Accessories\",\"Accessories\",\"InstallType\",\"OrderNow\"]}]}}}}";
//		AddPlanAndDeviceUIRequest request2 = mapper.readValue(requestString2, AddPlanAndDeviceUIRequest.class);
//		AddPlanAndDeviceUIResponse response2 = mapper.readValue(responseString2, AddPlanAndDeviceUIResponse.class);
//		System.out.println(request2.getChannelId());
//		URI url2 = URI.create("http://localhost/cart/nse/5g/updateCart");
//		MockServerHttpRequest httpHeader2 = MockServerHttpRequest.method(HttpMethod.POST, url2).header("channelId", "VZW-DOTCOM").build();
//		ServerHttpResponse httpResponse2 = new MockServerHttpResponse();
//		httpResponse2.setStatusCode(HttpStatus.CONTINUE);
//		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response2));
//		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
//		Mono<ResponseEntity<GenericResponse>> controllerResponse2 = cartController.addPlanAndDevice(httpHeader2, httpResponse2,
//				request2);
//		StepVerifier.create(controllerResponse2).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
//				.verify();
//	}

//	@Test
//	public void addPlanAndDeviceTestForExpressCheckoutNegativeCase1() throws IOException {
//		String requestString3 = "{\"cartInfo\": {\"clientAppName\": \"VZW-DOTCOM\",\"accountNumber\": \"\",\"cartCreator\": \"\",\"processingMTN\": \"\",\"processStep\": \"Accessories\",\"processAction\": \"DeviceAndPlan\",\"intendType\": \"NSE_5G\",\"bundleInstallType\": \"Gen4-5G-Home-Internet-Self-Setup\"},\"data\": {\"lines\": [{\"depletionType\": \"F\"}]},\"midnight\": \"Y\"}";
//		String responseString3 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-5188491-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Accessories\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Accessories\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-D-410f65a0-8535-471c-b1b3-0d14cbfcbd26\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]}]}}}}";
//		AddPlanAndDeviceUIRequest request3 = mapper.readValue(requestString3, AddPlanAndDeviceUIRequest.class);
//		AddPlanAndDeviceUIResponse response3 = mapper.readValue(responseString3, AddPlanAndDeviceUIResponse.class);
//		System.out.println(request3.getChannelId());
//		URI url3 = URI.create("http://localhost/cart/nse/5g/updateCart");
//		MockServerHttpRequest httpHeader3 = MockServerHttpRequest.method(HttpMethod.POST, url3).header("channelId", "VZW-DOTCOM").build();
//		ServerHttpResponse httpResponse3 = new MockServerHttpResponse();
//		httpResponse3.setStatusCode(HttpStatus.CONTINUE);
//		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response3));
//		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
//		Mono<ResponseEntity<GenericResponse>> controllerResponse3 = cartController.addPlanAndDevice(httpHeader3, httpResponse3,
//				request3);
//		StepVerifier.create(controllerResponse3).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
//				.verify();
//	}

//	@Test
//	public void addPlanAndDeviceTestForExpressCheckoutNegativeCase2() throws IOException {
//		String requestString4 = "{\"cartInfo\": {\"clientAppName\": \"VZW-DOTCOM\",\"accountNumber\": \"\",\"cartCreator\": \"\",\"processingMTN\": \"\",\"processStep\": \"OrderNow\",\"processAction\": \"DeviceAndPlan\",\"action\": \"Resume\",\"intendType\": \"NSE_5G\",\"bundleInstallType\": \"Gen4-5G-Home-Internet-Self-Setup\"},\"data\": {\"lines\": [{\"depletionType\": \"F\"}]},\"midnight\": \"Y\"}";
//		String responseString4 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-5188491-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Accessories\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Accessories\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-D-410f65a0-8535-471c-b1b3-0d14cbfcbd26\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]}]}}}}";
//		AddPlanAndDeviceUIRequest request4 = mapper.readValue(requestString4, AddPlanAndDeviceUIRequest.class);
//		AddPlanAndDeviceUIResponse response4 = mapper.readValue(responseString4, AddPlanAndDeviceUIResponse.class);
//		System.out.println(request4.getChannelId());
//		URI url4 = URI.create("http://localhost/cart/nse/5g/updateCart");
//		MockServerHttpRequest httpHeader4 = MockServerHttpRequest.method(HttpMethod.POST, url4).header("channelId", "VZW-DOTCOM").build();
//		ServerHttpResponse httpResponse4 = new MockServerHttpResponse();
//		httpResponse4.setStatusCode(HttpStatus.CONTINUE);
//		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response4));
//		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
//		Mono<ResponseEntity<GenericResponse>> controllerResponse4 = cartController.addPlanAndDevice(httpHeader4, httpResponse4,
//				request4);
//		StepVerifier.create(controllerResponse4).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
//				.verify();
//	}

	@Test
	public void updateTruckRollCartTest() throws IOException {
		URI url = URI.create("http://localhost/");
		HttpCookie digital_ig_session = new HttpCookie("digital_ig_session", "digital_ig_session");
		HttpCookie domainCookie = new HttpCookie("domainCookie", "domainCookie");
		HttpCookie ecpdcookie = new HttpCookie("ecpdcookie", "ecpd");
		MultiValueMap<String, HttpCookie> bodyMap = new LinkedMultiValueMap<String, HttpCookie>();
		bodyMap.add("digital_ig_session", digital_ig_session);
		bodyMap.add("domainCookie", domainCookie);
		bodyMap.add("ecpdcookie", ecpdcookie);
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "OMNI-RETAIL").cookies(bodyMap).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);

		String requestString = getData("classpath:AddTruckRollCartUIRequest.json");
		AddTruckRollCartUIRequest addTruckRollCartUIRequest = mapper.readValue(requestString, AddTruckRollCartUIRequest.class);
		String responseString = getData("classpath:AddTruckRollCartBPMResponse.json");
		AddTruckRollCartUIResponse addTruckRollCartUIResponse = mapper.readValue(responseString, AddTruckRollCartUIResponse.class);

		when(readCartHelper.updateTruckRollCart(addTruckRollCartUIRequest, httpHeader)).thenReturn(Mono.just(addTruckRollCartUIResponse));
		Mono<AddTruckRollCartUIResponse> addTruckRollCartResponse = cartController.updateTruckRollCart(httpHeader, httpResponse, addTruckRollCartUIRequest);
		StepVerifier.create(addTruckRollCartResponse).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void getDueMonthlyAndDueTodayTest() throws JsonProcessingException {
		String requestString = "{\"meta\":{},\"data\":{\"cartId\":\"b58e3b4d-f13c-440d-8ca8-465f4856a16b\"}}";
		String responseString = "{\"cartHeader\":{\"vendorId\":\"VZWCOM\",\"sourceSystem\":\"VZW-DOTCOM\",\"cartId\":\"b58e3b4d-f13c-440d-8ca8-465f4856a16b\",\"fullAccountNumber\":\"0282354804-1\",\"status\":\"A\",\"createTimestamp\":\"2021-10-11T05:50:50.450965-04:00[US/Eastern]\",\"lastUpdateTimestamp\":\"2021-10-11T05:51:45.828807-04:00[US/Eastern]\",\"cartCreator\":\"7326726656\",\"cartCreatorChannelId\":\"VZW-DOTCOM\",\"cartCreatorOrderLocationCode\":\"D463801\",\"cartCreatorSalesRepId\":\"EZ706\",\"caseId\":\"SOP-4604006-E01\",\"visionCustomerType\":\"PE\",\"maverickLocation\":false,\"preConfiguredCartType\":\"BAU\",\"preConfiguredCartTypeDuringAddDevice\":\"BAU\",\"isCoreRep\":false},\"orderDetailsView\":{\"dueTodayAmount\":\"0.0\",\"dueMonthlyAmount\":\"60.0\",\"orderActivityType\":\"AAL\",\"totalShippingCost\":\"null\",\"totalDiscountedShippingCost\":\"null\",\"installType\":\"Professional SetUp\",\"orderNumber\":\"3117431\",\"locationCode\":\"D463801\",\"orderType\":\"PS\",\"numOfLines\":\"1\",\"hiddenPromos\":[\"wireless-offer\"]},\"dueTodayList\":[{\"name\":\"5G Internet Gateway\",\"installationType\":\"Professional SetUp\",\"discountApplied\":\"0.0\",\"actualAmount\":\"0.0\",\"totalAmountWithDiscount\":\"0.0\",\"productId\":\"16900002\",\"sorId\":\"LVSKIHP\",\"itemType\":\"DEVICE\",\"quantity\":\"1\",\"taxAmount\":\"0.0\",\"lineNumber\":\"newLine1\",\"multiLineSeqNumber\":1,\"isBackorder\":\"false\",\"preBackDate\":\"\"}],\"dueMonthlyList\":[{\"name\":\"5G HOME INTERNET\",\"actualAmount\":\"80.0\",\"totalAmountWithDiscount\":\"60.0\",\"productId\":\"39425\",\"itemType\":\"PLAN\"}],\"dueMonthlyTaxes\":[{\"dueAmount\":\"0.0\"}],\"dueTodayTaxes\":[{\"dueAmount\":\"0.0\"}],\"shippingDetails\":[{\"address\":{\"apartmentNo\":\"\",\"type\":\"R\",\"streetNumber\":\"125\",\"streetName\":\"SAINT NICHOLAS\",\"addressLine2\":\"\",\"addressLine1\":\"125 SAINT NICHOLAS AVE\",\"city\":\"SOUTH PLAINFIELD\",\"state\":\"NJ\",\"zipCode\":\"07080\",\"zipCode4\":\"1807\",\"county\":\"\",\"countryCode\":\"\",\"fipsCode\":\"3402369390\",\"firstName\":\"JACK\",\"lastName\":\"MANUEL\",\"emailId\":\"QVOOLN64Z7@VZW.COM\",\"phoneNumber\":\"3453350350\",\"streetType\":\"AVE\",\"streetDirection\":\"\"},\"cbrPhone\":\"3453350350\",\"firstName\":\"JACK\",\"lastName\":\"MANUEL\",\"midInitials\":\"J\",\"isUseUnVerifiedAddress\":false,\"isValidAddress\":false,\"email\":\"QVOOLN64Z7@VZW.COM\"}],\"payments\":[],\"primaryUserInfo\":{\"firstName\":\"JACK\",\"lastName\":\"MANUEL\",\"address\":{\"firmName\":\"\",\"apartmentNo\":\"\",\"type\":\"AVE\",\"streetNumber\":\"125\",\"streetName\":\"SAINT NICHOLAS\",\"addressLine2\":\"\",\"addressLine1\":\"125 SAINT NICHOLAS AVE\",\"poBoxNo\":\"\",\"ruralRouteNo\":\"\",\"ruralDelNo\":\"\",\"city\":\"SOUTH PLAINFIELD\",\"state\":\"NJ\",\"zipCode\":\"07080\",\"zipCode4\":\"1807\",\"county\":\"\",\"countryCode\":\"US\",\"fipsCode\":\"3402369390\",\"firstName\":\"JACK\",\"lastName\":\"MANUEL\",\"emailId\":\"QVOOLN64Z7@VZW.COM\",\"phoneNumber\":\"3453350350\",\"streetType\":\"AVE\",\"streetDirection\":\"\"},\"isValidAddress\":true,\"bsnsName\":\"\",\"emailId\":\"QVOOLN64Z7@VZW.COM\"},\"cart5GAddress\":{\"addressLine1\":\"800 S OGDEN ST\",\"city\":\"DENVER\",\"state\":\"CO\",\"zipCode\":\"80209\",\"zipCode4\":\"\",\"countryCode\":\"\",\"fipsCode\":\"0803120000\",\"floor\":0},\"registrationDetails\":{}}";
		GetCartDetailsRequest request = mapper.readValue(requestString, GetCartDetailsRequest.class);
		GetCartDetailsUIResponse response = mapper.readValue(responseString, GetCartDetailsUIResponse.class);
		when(fiveGhomeNSEHelper.get5GCart(request)).thenReturn(Mono.just(ResponseEntity.status(200).body(response)));
		Mono<GetCartDetailsUIResponse> responseMono = cartController.getDueMonthlyAndDueToday(request);
		StepVerifier.create(responseMono).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
	}

	@Test
	public void populateAndReturnDummyResponseTest() throws JsonProcessingException {
		Mono<ResponseEntity<GenericResponse>> response = cartController.populateAndReturnDummyResponse("e1");
		StepVerifier.create(response).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();
		Mono<ResponseEntity<GenericResponse>> response1 = cartController.populateAndReturnDummyResponse("e2");
		StepVerifier.create(response1).assertNext(resp -> assertNotNull(resp)).expectComplete().verify();

	}

	@Test
	public void crmRetriveCartTest() throws IOException {
		String requestString =  "{\"cartId\":\"852a8e01-a83a-4c38-b082-bf90edd6e838\",\"customerType\":\"N\",\"accountNumber\":\"\",\"lqData\":{\"networkBandwidthType\":\"MMW\",\"lineActivityType\":\"NSE_5G\",\"eligible5GHomeBundle\":[{\"bundleName\":\"5GHomeGeminiSelfSetup\",\"id\":\"16900001\"},{\"bundleName\":\"5GHomeGeminiProfSetup\",\"id\":\"16900002\"}],\"cart5GAddress\":{\"addressLine1\":\"800 S OGDEN ST\",\"city\":\"DENVER\",\"state\":\"CO\",\"zipCode\":\"80209\",\"zipCode4\":\"\",\"county\":\"\",\"countryCode\":\"\",\"fipsCode\":\"0803120000\",\"emailId\":\"\"}}}";
		String responseString = "{\"serviceHeader\":{\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"GetCases\",\"userId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"customerInfo\":{\"customerType\":\"N\",\"cartId\":\"89859655-b722-4199-955a-6160389d03f2\",\"accountNumber\":\"\",\"cartCreator\":\"SIT1-NSA-29-10-12-13-PM-D\",\"emailId\":\"\",\"registerNumber\":0},\"cases\":[{\"processStep\":\"ShoppingCart\",\"preConfiguredCartTypeDuringAddDevice\":\"BAU\",\"cartCreator\":\"SIT1-NSA-29-10-12-12-PM-D\",\"pxUpdateDateTime\":\"20211029T064236.293 GMT\",\"cartId\":\"89859655-b722-4199-955a-6160389d03f2\",\"caseID\":\"SOP-5113066-E01\",\"emailId\":\"\",\"channelId\":\"VZW-DOTCOM\",\"intent\":\"NSE_5G\",\"quoteId\":\"\",\"amRole\":\"\",\"callReason\":\"Sales Order Purchase\",\"pxCreateDateTime\":\"20211029T064227.933 GMT\",\"lineCreator\":\"\",\"lastActiveChannelID\":\"VZW-DOTCOM\",\"explicit_lock\":\"\"}]}}}}";
		CrmResumeCartUIRequest request = mapper.readValue(requestString, CrmResumeCartUIRequest.class);
		CrmRetrieveCartUIResponse response = mapper.readValue(responseString, CrmRetrieveCartUIResponse.class);
		URI url = URI.create("/5g/crmResumeCart");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(redisHelper3.getAccountNumberFromRedis(Mockito.any())).thenReturn(Mono.just(""));
		when(sessionBean.getSessionData(Mockito.any(),Mockito.any())).thenReturn(Mono.just(""));
		when(readCartHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(bpmHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response));
		when(redisHelper3.updateCrmResumeDataIntoRedisAsString(Mockito.any())).thenReturn(Mono.just(true));

		when(readCartHelper.crmRetrieveCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(response));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.crmRetrieveCart(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		String requestString2 =  "{\"accountNumber\":\"\",\"lqData\":{\"networkBandwidthType\":\"MMW\",\"lineActivityType\":\"NSE_5G\",\"eligible5GHomeBundle\":[{\"bundleName\":\"5GHomeGeminiSelfSetup\",\"id\":\"16900001\"},{\"bundleName\":\"5GHomeGeminiProfSetup\",\"id\":\"16900002\"}],\"cart5GAddress\":{\"addressLine1\":\"800 S OGDEN ST\",\"city\":\"DENVER\",\"state\":\"CO\",\"zipCode\":\"80209\",\"zipCode4\":\"\",\"county\":\"\",\"countryCode\":\"\",\"fipsCode\":\"0803120000\",\"emailId\":\"\"}}}";
		String responseString2 = "{\"serviceHeader\":{\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"GetCases\",\"userId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"customerInfo\":{\"customerType\":\"N\",\"cartId\":\"89859655-b722-4199-955a-6160389d03f2\",\"accountNumber\":\"\",\"cartCreator\":\"SIT1-NSA-29-10-12-13-PM-D\",\"emailId\":\"\",\"registerNumber\":0},\"cases\":[{\"processStep\":\"ShoppingCart\",\"preConfiguredCartTypeDuringAddDevice\":\"BAU\",\"pxUpdateDateTime\":\"20211029T064236.293 GMT\",\"emailId\":\"\",\"channelId\":\"VZW-DOTCOM\",\"quoteId\":\"\",\"amRole\":\"\",\"callReason\":\"Sales Order Purchase\",\"pxCreateDateTime\":\"20211029T064227.933 GMT\",\"lineCreator\":\"\",\"lastActiveChannelID\":\"VZW-DOTCOM\",\"explicit_lock\":\"\"}]}}}}";
		CrmResumeCartUIRequest request2 = mapper.readValue(requestString2, CrmResumeCartUIRequest.class);
		CrmRetrieveCartUIResponse response2 = mapper.readValue(responseString2, CrmRetrieveCartUIResponse.class);
		URI url2 = URI.create("/5g/crmResumeCart");
		MockServerHttpRequest httpHeader2 = MockServerHttpRequest.method(HttpMethod.POST, url2).build();
		ServerHttpResponse httpResponse2 = new MockServerHttpResponse();
		httpResponse2.setStatusCode(HttpStatus.CONTINUE);
		when(redisHelper3.getAccountNumberFromRedis(Mockito.any())).thenReturn(Mono.just(""));
		when(sessionBean.getSessionData(Mockito.any(),Mockito.any())).thenReturn(Mono.just(""));
		when(readCartHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response2));
		when(bpmHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response2));
		when(redisHelper3.updateCrmResumeDataIntoRedisAsString(Mockito.any())).thenReturn(Mono.just(true));

		when(readCartHelper.crmRetrieveCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(response2));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse2 = cartController.crmRetrieveCart(httpHeader2, httpResponse2,
				request2);
		StepVerifier.create(controllerResponse2.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		String requestString3 =  "{\"accountNumber\":\"\",\"lqData\":{\"networkBandwidthType\":\"MMW\",\"lineActivityType\":\"NSE_5G\",\"eligible5GHomeBundle\":[{\"bundleName\":\"5GHomeGeminiSelfSetup\",\"id\":\"16900001\"},{\"bundleName\":\"5GHomeGeminiProfSetup\",\"id\":\"16900002\"}],\"cart5GAddress\":{\"addressLine1\":\"800 S OGDEN ST\",\"city\":\"DENVER\",\"state\":\"CO\",\"zipCode\":\"80209\",\"zipCode4\":\"\",\"county\":\"\",\"countryCode\":\"\",\"fipsCode\":\"0803120000\",\"emailId\":\"\"}}}";
		String responseString3 = "{\"serviceHeader\":{\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"GetCases\",\"userId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"customerInfo\":{\"customerType\":\"N\",\"cartId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"SIT1-NSA-29-10-12-13-PM-D\",\"emailId\":\"\",\"registerNumber\":0},\"cases\":[{\"processStep\":\"ShoppingCart\",\"preConfiguredCartTypeDuringAddDevice\":\"BAU\",\"pxUpdateDateTime\":\"20211029T064236.293 GMT\",\"emailId\":\"\",\"channelId\":\"VZW-DOTCOM\",\"quoteId\":\"\",\"amRole\":\"\",\"callReason\":\"Sales Order Purchase\",\"pxCreateDateTime\":\"20211029T064227.933 GMT\",\"lineCreator\":\"\",\"lastActiveChannelID\":\"VZW-DOTCOM\",\"explicit_lock\":\"\"}]}}}}";
		CrmResumeCartUIRequest request3 = mapper.readValue(requestString3, CrmResumeCartUIRequest.class);
		CrmRetrieveCartUIResponse response3 = mapper.readValue(responseString3, CrmRetrieveCartUIResponse.class);
		URI url3 = URI.create("/5g/crmResumeCart");
		MockServerHttpRequest httpHeader3 = MockServerHttpRequest.method(HttpMethod.POST, url3).build();
		ServerHttpResponse httpResponse3 = new MockServerHttpResponse();
		httpResponse3.setStatusCode(HttpStatus.CONTINUE);
		when(redisHelper3.getAccountNumberFromRedis(Mockito.any())).thenReturn(Mono.just(""));
		when(sessionBean.getSessionData(Mockito.any(),Mockito.any())).thenReturn(Mono.just(""));
		when(readCartHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response3));
		when(bpmHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response3));
		when(redisHelper3.updateCrmResumeDataIntoRedisAsString(Mockito.any())).thenReturn(Mono.just(true));

		when(readCartHelper.crmRetrieveCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(response3));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse3 = cartController.crmRetrieveCart(httpHeader3, httpResponse3,
				request3);
		StepVerifier.create(controllerResponse3.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		String requestString4 =  "{\"accountNumber\":\"\",\"lqData\":{\"networkBandwidthType\":\"MMW\",\"lineActivityType\":\"NSE_5G\",\"eligible5GHomeBundle\":[{\"bundleName\":\"5GHomeGeminiSelfSetup\",\"id\":\"16900001\"},{\"bundleName\":\"5GHomeGeminiProfSetup\",\"id\":\"16900002\"}],\"cart5GAddress\":{\"addressLine1\":\"800 S OGDEN ST\",\"city\":\"DENVER\",\"state\":\"CO\",\"zipCode\":\"80209\",\"zipCode4\":\"\",\"county\":\"\",\"countryCode\":\"\",\"fipsCode\":\"0803120000\",\"emailId\":\"\"}}}";
		String responseString4 = "{\"serviceHeader\":{\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"GetCases\",\"userId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"customerInfo\":{\"customerType\":\"N\",\"cartId\":\"89859655-b722-4199-955a-6160389d03f2\",\"accountNumber\":\"\",\"cartCreator\":\"SIT1-NSA-29-10-12-13-PM-D\",\"emailId\":\"\",\"registerNumber\":0}}}}}";
		CrmResumeCartUIRequest request4 = mapper.readValue(requestString4, CrmResumeCartUIRequest.class);
		CrmRetrieveCartUIResponse response4 = mapper.readValue(responseString4, CrmRetrieveCartUIResponse.class);
		URI url4 = URI.create("/5g/crmResumeCart");
		MockServerHttpRequest httpHeader4 = MockServerHttpRequest.method(HttpMethod.POST, url4).build();
		ServerHttpResponse httpResponse4 = new MockServerHttpResponse();
		httpResponse4.setStatusCode(HttpStatus.CONTINUE);
		when(redisHelper3.getAccountNumberFromRedis(Mockito.any())).thenReturn(Mono.just(""));
		when(sessionBean.getSessionData(Mockito.any(),Mockito.any())).thenReturn(Mono.just(""));
		when(readCartHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response4));
		when(bpmHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response4));
		when(redisHelper3.updateCrmResumeDataIntoRedisAsString(Mockito.any())).thenReturn(Mono.just(true));

		when(readCartHelper.crmRetrieveCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(response4));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse4 = cartController.crmRetrieveCart(httpHeader4, httpResponse4,
				request4);
		StepVerifier.create(controllerResponse4.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		String requestString5 =  "{\"cartId\":\"\",\"accountNumber\":\"\",\"lqData\":{\"networkBandwidthType\":\"MMW\",\"lineActivityType\":\"NSE_5G\",\"eligible5GHomeBundle\":[{\"bundleName\":\"5GHomeGeminiSelfSetup\",\"id\":\"16900001\"},{\"bundleName\":\"5GHomeGeminiProfSetup\",\"id\":\"16900002\"}],\"cart5GAddress\":{\"addressLine1\":\"800 S OGDEN ST\",\"city\":\"DENVER\",\"state\":\"CO\",\"zipCode\":\"80209\",\"zipCode4\":\"\",\"county\":\"\",\"countryCode\":\"\",\"fipsCode\":\"0803120000\",\"emailId\":\"\"}}}";
		String responseString5 = "{\"serviceHeader\":{\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"GetCases\",\"userId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"cases\":[],\"customerInfo\":{\"customerType\":\"N\",\"cartId\":\"89859655-b722-4199-955a-6160389d03f2\",\"accountNumber\":\"\",\"cartCreator\":\"SIT1-NSA-29-10-12-13-PM-D\",\"emailId\":\"\",\"registerNumber\":0}}}}}";
		CrmResumeCartUIRequest request5 = mapper.readValue(requestString5, CrmResumeCartUIRequest.class);
		CrmRetrieveCartUIResponse response5 = mapper.readValue(responseString5, CrmRetrieveCartUIResponse.class);
		URI url5 = URI.create("/5g/crmResumeCart");
		MockServerHttpRequest httpHeader5 = MockServerHttpRequest.method(HttpMethod.POST, url5).build();
		ServerHttpResponse httpResponse5 = new MockServerHttpResponse();
		httpResponse5.setStatusCode(HttpStatus.CONTINUE);
		when(redisHelper3.getAccountNumberFromRedis(Mockito.any())).thenReturn(Mono.just(""));
		when(sessionBean.getSessionData(Mockito.any(),Mockito.any())).thenReturn(Mono.just(""));
		when(readCartHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response5));
		when(bpmHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response5));
		when(redisHelper3.updateCrmResumeDataIntoRedisAsString(Mockito.any())).thenReturn(Mono.just(true));

		when(readCartHelper.crmRetrieveCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(response5));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse5 = cartController.crmRetrieveCart(httpHeader5, httpResponse5,
				request5);
		StepVerifier.create(controllerResponse5.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		String requestString6 =  "{\"cartId\":\"\",\"accountNumber\":\"\",\"lqData\":{\"networkBandwidthType\":\"MMW\",\"lineActivityType\":\"NSE_5G\",\"eligible5GHomeBundle\":[{\"bundleName\":\"5GHomeGeminiSelfSetup\",\"id\":\"16900001\"},{\"bundleName\":\"5GHomeGeminiProfSetup\",\"id\":\"16900002\"}],\"cart5GAddress\":{\"addressLine1\":\"800 S OGDEN ST\",\"city\":\"DENVER\",\"state\":\"CO\",\"zipCode\":\"80209\",\"zipCode4\":\"\",\"county\":\"\",\"countryCode\":\"\",\"fipsCode\":\"0803120000\",\"emailId\":\"\"}}}";
		String responseString6 = "{\"serviceHeader\":{\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"GetCases\",\"userId\":\"\"},\"serviceBody\":{\"serviceResponse\":{}}}";
		CrmResumeCartUIRequest request6 = mapper.readValue(requestString6, CrmResumeCartUIRequest.class);
		CrmRetrieveCartUIResponse response6 = mapper.readValue(responseString6, CrmRetrieveCartUIResponse.class);
		URI url6 = URI.create("/5g/crmResumeCart");
		MockServerHttpRequest httpHeader6 = MockServerHttpRequest.method(HttpMethod.POST, url6).build();
		ServerHttpResponse httpResponse6 = new MockServerHttpResponse();
		httpResponse6.setStatusCode(HttpStatus.CONTINUE);
		when(redisHelper3.getAccountNumberFromRedis(Mockito.any())).thenReturn(Mono.just(""));
		when(sessionBean.getSessionData(Mockito.any(),Mockito.any())).thenReturn(Mono.just(""));
		when(readCartHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response6));
		when(bpmHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response6));
		when(redisHelper3.updateCrmResumeDataIntoRedisAsString(Mockito.any())).thenReturn(Mono.just(true));

		when(readCartHelper.crmRetrieveCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(response6));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse6 = cartController.crmRetrieveCart(httpHeader6, httpResponse6,
				request6);
		StepVerifier.create(controllerResponse6.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		String requestString7 =  "{\"cartId\":\"\",\"accountNumber\":\"\",\"lqData\":{\"networkBandwidthType\":\"MMW\",\"lineActivityType\":\"NSE_5G\",\"eligible5GHomeBundle\":[{\"bundleName\":\"5GHomeGeminiSelfSetup\",\"id\":\"16900001\"},{\"bundleName\":\"5GHomeGeminiProfSetup\",\"id\":\"16900002\"}],\"cart5GAddress\":{\"addressLine1\":\"800 S OGDEN ST\",\"city\":\"DENVER\",\"state\":\"CO\",\"zipCode\":\"80209\",\"zipCode4\":\"\",\"county\":\"\",\"countryCode\":\"\",\"fipsCode\":\"0803120000\",\"emailId\":\"\"}}}";
		String responseString7 = "{\"serviceHeader\":{\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"GetCases\",\"userId\":\"\"},\"serviceBody\":{}}";
		CrmResumeCartUIRequest request7 = mapper.readValue(requestString7, CrmResumeCartUIRequest.class);
		CrmRetrieveCartUIResponse response7 = mapper.readValue(responseString7, CrmRetrieveCartUIResponse.class);
		URI url7 = URI.create("/5g/crmResumeCart");
		MockServerHttpRequest httpHeader7 = MockServerHttpRequest.method(HttpMethod.POST, url7).build();
		ServerHttpResponse httpResponse7 = new MockServerHttpResponse();
		httpResponse7.setStatusCode(HttpStatus.CONTINUE);
		when(redisHelper3.getAccountNumberFromRedis(Mockito.any())).thenReturn(Mono.just(""));
		when(sessionBean.getSessionData(Mockito.any(),Mockito.any())).thenReturn(Mono.just(""));
		when(readCartHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response7));
		when(bpmHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response7));
		when(redisHelper3.updateCrmResumeDataIntoRedisAsString(Mockito.any())).thenReturn(Mono.just(true));

		when(readCartHelper.crmRetrieveCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(response7));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse7 = cartController.crmRetrieveCart(httpHeader7, httpResponse7,
				request7);
		StepVerifier.create(controllerResponse7.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		String requestString8 =  "{\"cartId\":\"\",\"accountNumber\":\"\",\"lqData\":{\"networkBandwidthType\":\"MMW\",\"lineActivityType\":\"NSE_5G\",\"eligible5GHomeBundle\":[{\"bundleName\":\"5GHomeGeminiSelfSetup\",\"id\":\"16900001\"},{\"bundleName\":\"5GHomeGeminiProfSetup\",\"id\":\"16900002\"}],\"cart5GAddress\":{\"addressLine1\":\"800 S OGDEN ST\",\"city\":\"DENVER\",\"state\":\"CO\",\"zipCode\":\"80209\",\"zipCode4\":\"\",\"county\":\"\",\"countryCode\":\"\",\"fipsCode\":\"0803120000\",\"emailId\":\"\"}}}";
		String responseString8 = "{\"errors\":[{\"id\":\"001\",\"namespace\":\"CartService\"}]}";
		CrmResumeCartUIRequest request8 = mapper.readValue(requestString8, CrmResumeCartUIRequest.class);
		CrmRetrieveCartUIResponse response8 = mapper.readValue(responseString8, CrmRetrieveCartUIResponse.class);
		URI url8 = URI.create("/5g/crmResumeCart");
		MockServerHttpRequest httpHeader8 = MockServerHttpRequest.method(HttpMethod.POST, url8).build();
		ServerHttpResponse httpResponse8 = new MockServerHttpResponse();
		httpResponse8.setStatusCode(HttpStatus.CONTINUE);
		when(redisHelper3.getAccountNumberFromRedis(Mockito.any())).thenReturn(Mono.just(""));
		when(sessionBean.getSessionData(Mockito.any(),Mockito.any())).thenReturn(Mono.just(""));
		when(readCartHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response8));
		when(bpmHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response8));
		when(redisHelper3.updateCrmResumeDataIntoRedisAsString(Mockito.any())).thenReturn(Mono.just(true));

		when(readCartHelper.crmRetrieveCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(response8));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse8 = cartController.crmRetrieveCart(httpHeader8, httpResponse8,
				request8);
		StepVerifier.create(controllerResponse8.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}

//	@Test
//	public void crmRetrieveCartTest1() throws IOException {
//		String requestString2 =  "{\"accountNumber\":\"\",\"lqData\":{\"networkBandwidthType\":\"MMW\",\"lineActivityType\":\"NSE_5G\",\"eligible5GHomeBundle\":[{\"bundleName\":\"5GHomeGeminiSelfSetup\",\"id\":\"16900001\"},{\"bundleName\":\"5GHomeGeminiProfSetup\",\"id\":\"16900002\"}],\"cart5GAddress\":{\"addressLine1\":\"800 S OGDEN ST\",\"city\":\"DENVER\",\"state\":\"CO\",\"zipCode\":\"80209\",\"zipCode4\":\"\",\"county\":\"\",\"countryCode\":\"\",\"fipsCode\":\"0803120000\",\"emailId\":\"\"}}}";
//		String responseString2 = "{\"serviceHeader\":{\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"GetCases\",\"userId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"customerInfo\":{\"customerType\":\"N\",\"cartId\":\"89859655-b722-4199-955a-6160389d03f2\",\"accountNumber\":\"\",\"cartCreator\":\"SIT1-NSA-29-10-12-13-PM-D\",\"emailId\":\"\",\"registerNumber\":0},\"cases\":[{\"processStep\":\"ShoppingCart\",\"preConfiguredCartTypeDuringAddDevice\":\"BAU\",\"pxUpdateDateTime\":\"20211029T064236.293 GMT\",\"emailId\":\"\",\"channelId\":\"VZW-DOTCOM\",\"quoteId\":\"\",\"amRole\":\"\",\"callReason\":\"Sales Order Purchase\",\"pxCreateDateTime\":\"20211029T064227.933 GMT\",\"lineCreator\":\"\",\"lastActiveChannelID\":\"VZW-DOTCOM\",\"explicit_lock\":\"\"}]}}}}";
//		CrmResumeCartUIRequest request2 = mapper.readValue(requestString2, CrmResumeCartUIRequest.class);
//		CrmRetrieveCartUIResponse response2 = mapper.readValue(responseString2, CrmRetrieveCartUIResponse.class);
//		URI url2 = URI.create("/5g/crmResumeCart");
//		MockServerHttpRequest httpHeader2 = MockServerHttpRequest.method(HttpMethod.POST, url2).build();
//		ServerHttpResponse httpResponse2 = new MockServerHttpResponse();
//		httpResponse2.setStatusCode(HttpStatus.CONTINUE);
//		when(redisHelper3.getAccountNumberFromRedis(Mockito.any())).thenReturn(Mono.just(""));
//		when(sessionBean.getSessionData(Mockito.any(),Mockito.any())).thenReturn(Mono.just(""));
//		when(readCartHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response2));
//		when(bpmHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response2));
//		when(redisHelper3.updateCrmResumeDataIntoRedisAsString(Mockito.any())).thenReturn(Mono.just(true));
//
//		when(readCartHelper.crmRetrieveCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(response2));
//		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
//		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.crmRetrieveCart(httpHeader2, httpResponse2,
//				request2);
//		StepVerifier.create(controllerResponse.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
//				.verify();
//	}

//	@Test
//	public void crmRetrieveCartConditionCheckTest() throws IOException {
//		String requestString3 =  "{\"accountNumber\":\"\",\"lqData\":{\"networkBandwidthType\":\"MMW\",\"lineActivityType\":\"NSE_5G\",\"eligible5GHomeBundle\":[{\"bundleName\":\"5GHomeGeminiSelfSetup\",\"id\":\"16900001\"},{\"bundleName\":\"5GHomeGeminiProfSetup\",\"id\":\"16900002\"}],\"cart5GAddress\":{\"addressLine1\":\"800 S OGDEN ST\",\"city\":\"DENVER\",\"state\":\"CO\",\"zipCode\":\"80209\",\"zipCode4\":\"\",\"county\":\"\",\"countryCode\":\"\",\"fipsCode\":\"0803120000\",\"emailId\":\"\"}}}";
//		String responseString3 = "{\"serviceHeader\":{\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"GetCases\",\"userId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"customerInfo\":{\"customerType\":\"N\",\"cartId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"SIT1-NSA-29-10-12-13-PM-D\",\"emailId\":\"\",\"registerNumber\":0},\"cases\":[{\"processStep\":\"ShoppingCart\",\"preConfiguredCartTypeDuringAddDevice\":\"BAU\",\"pxUpdateDateTime\":\"20211029T064236.293 GMT\",\"emailId\":\"\",\"channelId\":\"VZW-DOTCOM\",\"quoteId\":\"\",\"amRole\":\"\",\"callReason\":\"Sales Order Purchase\",\"pxCreateDateTime\":\"20211029T064227.933 GMT\",\"lineCreator\":\"\",\"lastActiveChannelID\":\"VZW-DOTCOM\",\"explicit_lock\":\"\"}]}}}}";
//		CrmResumeCartUIRequest request3 = mapper.readValue(requestString3, CrmResumeCartUIRequest.class);
//		CrmRetrieveCartUIResponse response3 = mapper.readValue(responseString3, CrmRetrieveCartUIResponse.class);
//		URI url3 = URI.create("/5g/crmResumeCart");
//		MockServerHttpRequest httpHeader3 = MockServerHttpRequest.method(HttpMethod.POST, url3).build();
//		ServerHttpResponse httpResponse3 = new MockServerHttpResponse();
//		httpResponse3.setStatusCode(HttpStatus.CONTINUE);
//		when(redisHelper3.getAccountNumberFromRedis(Mockito.any())).thenReturn(Mono.just(""));
//		when(sessionBean.getSessionData(Mockito.any(),Mockito.any())).thenReturn(Mono.just(""));
//		when(readCartHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response3));
//		when(bpmHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response3));
//		when(redisHelper3.updateCrmResumeDataIntoRedisAsString(Mockito.any())).thenReturn(Mono.just(true));
//
//		when(readCartHelper.crmRetrieveCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(response3));
//		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
//		Mono<ResponseEntity<GenericResponse>> controllerResponse3 = cartController.crmRetrieveCart(httpHeader3, httpResponse3,
//				request3);
//		StepVerifier.create(controllerResponse3.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
//				.verify();
//	}

//	@Test
//	public void crmRetrieveCartTest2() throws IOException {
//		String requestString4 =  "{\"accountNumber\":\"\",\"lqData\":{\"networkBandwidthType\":\"MMW\",\"lineActivityType\":\"NSE_5G\",\"eligible5GHomeBundle\":[{\"bundleName\":\"5GHomeGeminiSelfSetup\",\"id\":\"16900001\"},{\"bundleName\":\"5GHomeGeminiProfSetup\",\"id\":\"16900002\"}],\"cart5GAddress\":{\"addressLine1\":\"800 S OGDEN ST\",\"city\":\"DENVER\",\"state\":\"CO\",\"zipCode\":\"80209\",\"zipCode4\":\"\",\"county\":\"\",\"countryCode\":\"\",\"fipsCode\":\"0803120000\",\"emailId\":\"\"}}}";
//		String responseString4 = "{\"serviceHeader\":{\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"GetCases\",\"userId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"customerInfo\":{\"customerType\":\"N\",\"cartId\":\"89859655-b722-4199-955a-6160389d03f2\",\"accountNumber\":\"\",\"cartCreator\":\"SIT1-NSA-29-10-12-13-PM-D\",\"emailId\":\"\",\"registerNumber\":0}}}}}";
//		CrmResumeCartUIRequest request4 = mapper.readValue(requestString4, CrmResumeCartUIRequest.class);
//		CrmRetrieveCartUIResponse response4 = mapper.readValue(responseString4, CrmRetrieveCartUIResponse.class);
//		URI url4 = URI.create("/5g/crmResumeCart");
//		MockServerHttpRequest httpHeader4 = MockServerHttpRequest.method(HttpMethod.POST, url4).build();
//		ServerHttpResponse httpResponse4 = new MockServerHttpResponse();
//		httpResponse4.setStatusCode(HttpStatus.CONTINUE);
//		when(redisHelper3.getAccountNumberFromRedis(Mockito.any())).thenReturn(Mono.just(""));
//		when(sessionBean.getSessionData(Mockito.any(),Mockito.any())).thenReturn(Mono.just(""));
//		when(readCartHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response4));
//		when(bpmHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response4));
//		when(redisHelper3.updateCrmResumeDataIntoRedisAsString(Mockito.any())).thenReturn(Mono.just(true));
//
//		when(readCartHelper.crmRetrieveCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(response4));
//		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
//		Mono<ResponseEntity<GenericResponse>> controllerResponse4 = cartController.crmRetrieveCart(httpHeader4, httpResponse4,
//				request4);
//		StepVerifier.create(controllerResponse4.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
//				.verify();
//	}

//	@Test
//	public void crmRetrieveCartTest3() throws IOException {
//		String requestString5 =  "{\"cartId\":\"\",\"accountNumber\":\"\",\"lqData\":{\"networkBandwidthType\":\"MMW\",\"lineActivityType\":\"NSE_5G\",\"eligible5GHomeBundle\":[{\"bundleName\":\"5GHomeGeminiSelfSetup\",\"id\":\"16900001\"},{\"bundleName\":\"5GHomeGeminiProfSetup\",\"id\":\"16900002\"}],\"cart5GAddress\":{\"addressLine1\":\"800 S OGDEN ST\",\"city\":\"DENVER\",\"state\":\"CO\",\"zipCode\":\"80209\",\"zipCode4\":\"\",\"county\":\"\",\"countryCode\":\"\",\"fipsCode\":\"0803120000\",\"emailId\":\"\"}}}";
//		String responseString5 = "{\"serviceHeader\":{\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"GetCases\",\"userId\":\"\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"cases\":[],\"customerInfo\":{\"customerType\":\"N\",\"cartId\":\"89859655-b722-4199-955a-6160389d03f2\",\"accountNumber\":\"\",\"cartCreator\":\"SIT1-NSA-29-10-12-13-PM-D\",\"emailId\":\"\",\"registerNumber\":0}}}}}";
//		CrmResumeCartUIRequest request5 = mapper.readValue(requestString5, CrmResumeCartUIRequest.class);
//		CrmRetrieveCartUIResponse response5 = mapper.readValue(responseString5, CrmRetrieveCartUIResponse.class);
//		URI url5 = URI.create("/5g/crmResumeCart");
//		MockServerHttpRequest httpHeader5 = MockServerHttpRequest.method(HttpMethod.POST, url5).build();
//		ServerHttpResponse httpResponse5 = new MockServerHttpResponse();
//		httpResponse5.setStatusCode(HttpStatus.CONTINUE);
//		when(redisHelper3.getAccountNumberFromRedis(Mockito.any())).thenReturn(Mono.just(""));
//		when(sessionBean.getSessionData(Mockito.any(),Mockito.any())).thenReturn(Mono.just(""));
//		when(readCartHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response5));
//		when(bpmHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response5));
//		when(redisHelper3.updateCrmResumeDataIntoRedisAsString(Mockito.any())).thenReturn(Mono.just(true));
//
//		when(readCartHelper.crmRetrieveCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(response5));
//		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
//		Mono<ResponseEntity<GenericResponse>> controllerResponse5 = cartController.crmRetrieveCart(httpHeader5, httpResponse5,
//				request5);
//		StepVerifier.create(controllerResponse5.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
//				.verify();
//	}

//	@Test
//	public void crmRetrieveCartTest4() throws IOException {
//		String requestString6 =  "{\"cartId\":\"\",\"accountNumber\":\"\",\"lqData\":{\"networkBandwidthType\":\"MMW\",\"lineActivityType\":\"NSE_5G\",\"eligible5GHomeBundle\":[{\"bundleName\":\"5GHomeGeminiSelfSetup\",\"id\":\"16900001\"},{\"bundleName\":\"5GHomeGeminiProfSetup\",\"id\":\"16900002\"}],\"cart5GAddress\":{\"addressLine1\":\"800 S OGDEN ST\",\"city\":\"DENVER\",\"state\":\"CO\",\"zipCode\":\"80209\",\"zipCode4\":\"\",\"county\":\"\",\"countryCode\":\"\",\"fipsCode\":\"0803120000\",\"emailId\":\"\"}}}";
//		String responseString6 = "{\"serviceHeader\":{\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"GetCases\",\"userId\":\"\"},\"serviceBody\":{\"serviceResponse\":{}}}";
//		CrmResumeCartUIRequest request6 = mapper.readValue(requestString6, CrmResumeCartUIRequest.class);
//		CrmRetrieveCartUIResponse response6 = mapper.readValue(responseString6, CrmRetrieveCartUIResponse.class);
//		URI url6 = URI.create("/5g/crmResumeCart");
//		MockServerHttpRequest httpHeader6 = MockServerHttpRequest.method(HttpMethod.POST, url6).build();
//		ServerHttpResponse httpResponse6 = new MockServerHttpResponse();
//		httpResponse6.setStatusCode(HttpStatus.CONTINUE);
//		when(redisHelper3.getAccountNumberFromRedis(Mockito.any())).thenReturn(Mono.just(""));
//		when(sessionBean.getSessionData(Mockito.any(),Mockito.any())).thenReturn(Mono.just(""));
//		when(readCartHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response6));
//		when(bpmHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response6));
//		when(redisHelper3.updateCrmResumeDataIntoRedisAsString(Mockito.any())).thenReturn(Mono.just(true));
//
//		when(readCartHelper.crmRetrieveCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(response6));
//		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
//		Mono<ResponseEntity<GenericResponse>> controllerResponse6 = cartController.crmRetrieveCart(httpHeader6, httpResponse6,
//				request6);
//		StepVerifier.create(controllerResponse6.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
//				.verify();
//	}

//	@Test
//	public void crmRetrieveCartTest5() throws IOException {
//		String requestString7 =  "{\"cartId\":\"\",\"accountNumber\":\"\",\"lqData\":{\"networkBandwidthType\":\"MMW\",\"lineActivityType\":\"NSE_5G\",\"eligible5GHomeBundle\":[{\"bundleName\":\"5GHomeGeminiSelfSetup\",\"id\":\"16900001\"},{\"bundleName\":\"5GHomeGeminiProfSetup\",\"id\":\"16900002\"}],\"cart5GAddress\":{\"addressLine1\":\"800 S OGDEN ST\",\"city\":\"DENVER\",\"state\":\"CO\",\"zipCode\":\"80209\",\"zipCode4\":\"\",\"county\":\"\",\"countryCode\":\"\",\"fipsCode\":\"0803120000\",\"emailId\":\"\"}}}";
//		String responseString7 = "{\"serviceHeader\":{\"statusMsg\":\"PEGA generated message\",\"serviceName\":\"GetCases\",\"userId\":\"\"},\"serviceBody\":{}}";
//		CrmResumeCartUIRequest request7 = mapper.readValue(requestString7, CrmResumeCartUIRequest.class);
//		CrmRetrieveCartUIResponse response7 = mapper.readValue(responseString7, CrmRetrieveCartUIResponse.class);
//		URI url7 = URI.create("/5g/crmResumeCart");
//		MockServerHttpRequest httpHeader7 = MockServerHttpRequest.method(HttpMethod.POST, url7).build();
//		ServerHttpResponse httpResponse7 = new MockServerHttpResponse();
//		httpResponse7.setStatusCode(HttpStatus.CONTINUE);
//		when(redisHelper3.getAccountNumberFromRedis(Mockito.any())).thenReturn(Mono.just(""));
//		when(sessionBean.getSessionData(Mockito.any(),Mockito.any())).thenReturn(Mono.just(""));
//		when(readCartHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response7));
//		when(bpmHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response7));
//		when(redisHelper3.updateCrmResumeDataIntoRedisAsString(Mockito.any())).thenReturn(Mono.just(true));
//
//		when(readCartHelper.crmRetrieveCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(response7));
//		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
//		Mono<ResponseEntity<GenericResponse>> controllerResponse7 = cartController.crmRetrieveCart(httpHeader7, httpResponse7,
//				request7);
//		StepVerifier.create(controllerResponse7.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
//				.verify();
//	}

//	@Test
//	public void crmRetrieveCartErrorTest() throws IOException {
//		String requestString8 =  "{\"cartId\":\"\",\"accountNumber\":\"\",\"lqData\":{\"networkBandwidthType\":\"MMW\",\"lineActivityType\":\"NSE_5G\",\"eligible5GHomeBundle\":[{\"bundleName\":\"5GHomeGeminiSelfSetup\",\"id\":\"16900001\"},{\"bundleName\":\"5GHomeGeminiProfSetup\",\"id\":\"16900002\"}],\"cart5GAddress\":{\"addressLine1\":\"800 S OGDEN ST\",\"city\":\"DENVER\",\"state\":\"CO\",\"zipCode\":\"80209\",\"zipCode4\":\"\",\"county\":\"\",\"countryCode\":\"\",\"fipsCode\":\"0803120000\",\"emailId\":\"\"}}}";
//		String responseString8 = "{\"errors\":[{\"id\":\"001\",\"namespace\":\"CartService\"}]}";
//		CrmResumeCartUIRequest request8 = mapper.readValue(requestString8, CrmResumeCartUIRequest.class);
//		CrmRetrieveCartUIResponse response8 = mapper.readValue(responseString8, CrmRetrieveCartUIResponse.class);
//		URI url8 = URI.create("/5g/crmResumeCart");
//		MockServerHttpRequest httpHeader8 = MockServerHttpRequest.method(HttpMethod.POST, url8).build();
//		ServerHttpResponse httpResponse8 = new MockServerHttpResponse();
//		httpResponse8.setStatusCode(HttpStatus.CONTINUE);
//		when(redisHelper3.getAccountNumberFromRedis(Mockito.any())).thenReturn(Mono.just(""));
//		when(sessionBean.getSessionData(Mockito.any(),Mockito.any())).thenReturn(Mono.just(""));
//		when(readCartHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response8));
//		when(bpmHelper.crmRetrieveCart(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(Mono.just(response8));
//		when(redisHelper3.updateCrmResumeDataIntoRedisAsString(Mockito.any())).thenReturn(Mono.just(true));
//
//		when(readCartHelper.crmRetrieveCart(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(Mono.just(response8));
//		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
//		Mono<ResponseEntity<GenericResponse>> controllerResponse8 = cartController.crmRetrieveCart(httpHeader8, httpResponse8,
//				request8);
//		StepVerifier.create(controllerResponse8.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
//				.verify();
//	}

	@Test
	public void addPlanAndDevice_ErrorTest() throws IOException {
		String requestString = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"intendType\":\"AAL_5G\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
		String responseString = "{\"errors\":[{\"namespace\":\"CartService\",\"id\":\"712\",\"message\":\"Invalid Address:Street name/PO Box/Rural Delivery Route not found in Zipcode\",\"name\":\"REQUEST_VALIDATION_ERROR\"}]}";
		AddPlanAndDeviceUIRequest request = mapper.readValue(requestString, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response = mapper.readValue(responseString, AddPlanAndDeviceUIResponse.class);
		System.out.println(request.getChannelId());
		URI url = URI.create("http://localhost/5g/updateCart");
		MockServerHttpRequest httpHeader = MockServerHttpRequest.method(HttpMethod.POST, url).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse = new MockServerHttpResponse();
		httpResponse.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse = cartController.addPlanAndDevice(httpHeader, httpResponse,
				request);
		StepVerifier.create(controllerResponse.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		String requestString2 = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"intendType\":\"AAL_5G\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
		String responseString2 = "{}";
		AddPlanAndDeviceUIRequest request2 = mapper.readValue(requestString2, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response2 = mapper.readValue(responseString2, AddPlanAndDeviceUIResponse.class);
		System.out.println(request2.getChannelId());
		URI url2 = URI.create("http://localhost/5g/updateCart");
		MockServerHttpRequest httpHeader2 = MockServerHttpRequest.method(HttpMethod.POST, url2).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse2 = new MockServerHttpResponse();
		httpResponse2.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response2));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse2 = cartController.addPlanAndDevice(httpHeader2, httpResponse2,
				request2);
		StepVerifier.create(controllerResponse2.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		String requestString3 = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"intendType\":\"AAL_5G\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
		String responseString3 = "{\"errors\":[{\"namespace\":\"CartService\",\"id\":\"712\",\"message\":\"FiveG qualified address is not available. Please select one.\",\"name\":\"REQUEST_VALIDATION_ERROR\"}]}";
		AddPlanAndDeviceUIRequest request3 = mapper.readValue(requestString3, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response3 = mapper.readValue(responseString3, AddPlanAndDeviceUIResponse.class);
		System.out.println(request3.getChannelId());
		URI url3 = URI.create("http://localhost/5g/updateCart");
		MockServerHttpRequest httpHeader3 = MockServerHttpRequest.method(HttpMethod.POST, url3).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse3 = new MockServerHttpResponse();
		httpResponse3.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response3));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse3 = cartController.addPlanAndDevice(httpHeader3, httpResponse3,
				request3);
		StepVerifier.create(controllerResponse3.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		String requestString4 = "{\"cartInfo\":{\"flowType\":\"WHW_Redemptio\",\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"intendType\":\"AAL_5G\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
		String responseString4 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-5188491-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Accessories\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Accessories\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-D-410f65a0-8535-471c-b1b3-0d14cbfcbd26\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":1,\"cartId\":\"6af05322-815c-423c-9bb2-9b0fce190075\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"onDemandAllowed\":false,\"backDateAllowed\":false,\"futureDateAllowed\":false,\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"lines\":[{\"status\":1,\"spos\":[{\"id\":\"732\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false},{\"id\":\"1508\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false}],\"sfos\":[{\"id\":\"48526\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"48553\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"54307\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68872\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"70421\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78003\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"83856\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"85503\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86112\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86926\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86927\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86928\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86952\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86953\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false}],\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"mtn\":\"newLine1\",\"isDeviceSelected\":true,\"userSelectedPlan\":false,\"lineId\":\"newLine1\",\"sortingNumber\":\"0\",\"device\":{\"id\":\"LVSKIHP\",\"itemPrice\":\"0.0\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"5G Internet Gateway\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false},\"sim\":{\"id\":\"NI-DPSIM\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"NSE_5G\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"isAppendedLine\":false,\"fiveGPlanAdded\":false}],\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]}]}}}}";
		AddPlanAndDeviceUIRequest request4 = mapper.readValue(requestString4, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response4 = mapper.readValue(responseString4, AddPlanAndDeviceUIResponse.class);
		System.out.println(request4.getChannelId());
		URI url4 = URI.create("http://localhost/5g/updateCart");
		MockServerHttpRequest httpHeader4 = MockServerHttpRequest.method(HttpMethod.POST, url4).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse4 = new MockServerHttpResponse();
		httpResponse4.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response4));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse4 = cartController.addPlanAndDevice(httpHeader4, httpResponse4,
				request4);
		StepVerifier.create(controllerResponse4.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		String requestString5 = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"intendType\":\"AAL_5G\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
		String responseString5 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-5188491-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Accessories\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Accessories\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-D-410f65a0-8535-471c-b1b3-0d14cbfcbd26\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":1,\"cartId\":\"\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"onDemandAllowed\":false,\"backDateAllowed\":false,\"futureDateAllowed\":false,\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"lines\":[{\"status\":1,\"spos\":[{\"id\":\"732\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false},{\"id\":\"1508\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false}],\"sfos\":[{\"id\":\"48526\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"48553\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"54307\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68872\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"70421\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78003\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"83856\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"85503\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86112\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86926\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86927\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86928\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86952\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86953\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false}],\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"mtn\":\"newLine1\",\"isDeviceSelected\":true,\"userSelectedPlan\":false,\"lineId\":\"newLine1\",\"sortingNumber\":\"0\",\"device\":{\"id\":\"LVSKIHP\",\"itemPrice\":\"0.0\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"5G Internet Gateway\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false},\"sim\":{\"id\":\"NI-DPSIM\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"NSE_5G\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"isAppendedLine\":false,\"fiveGPlanAdded\":false}],\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]}]}}}}";
		AddPlanAndDeviceUIRequest request5 = mapper.readValue(requestString5, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response5 = mapper.readValue(responseString5, AddPlanAndDeviceUIResponse.class);
		System.out.println(request5.getChannelId());
		URI url5 = URI.create("http://localhost/5g/updateCart");
		MockServerHttpRequest httpHeader5 = MockServerHttpRequest.method(HttpMethod.POST, url5).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse5 = new MockServerHttpResponse();
		httpResponse5.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response5));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse5 = cartController.addPlanAndDevice(httpHeader5, httpResponse5,
				request5);
		StepVerifier.create(controllerResponse5.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		String requestString6 = "{\"cartInfo\":{\"covidQuestionareAnswered\":true,\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
		String responseString6 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-5188491-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Accessories\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Accessories\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-D-410f65a0-8535-471c-b1b3-0d14cbfcbd26\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"cartInfo\":{\"ecpdProfileId\":\"ecpdId\",\"cartItemCount\":1,\"cartId\":\"6af05322-815c-423c-9bb2-9b0fce190075\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"onDemandAllowed\":false,\"backDateAllowed\":false,\"futureDateAllowed\":false,\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]}]}}}}";
		AddPlanAndDeviceUIRequest request6 = mapper.readValue(requestString6, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response6 = mapper.readValue(responseString6, AddPlanAndDeviceUIResponse.class);
		System.out.println(request6.getChannelId());
		URI url6 = URI.create("http://localhost/5g/updateCart");
		MockServerHttpRequest httpHeader6 = MockServerHttpRequest.method(HttpMethod.POST, url6).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse6 = new MockServerHttpResponse();
		httpResponse6.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response6));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse6 = cartController.addPlanAndDevice(httpHeader6, httpResponse6,
				request6);
		StepVerifier.create(controllerResponse6.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		String requestString7 = "{\"cartInfo\":{\"intendType\":\"EUP_LTE\",\"covidQuestionareAnswered\":false,\"clientAppName\":\"OMNI-TELESALES\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
		String responseString7 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-5188491-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Accessories\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Accessories\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-D-410f65a0-8535-471c-b1b3-0d14cbfcbd26\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"cartInfo\":{\"processStep\":\"OrderNow\",\"intendType\":\"EUP_LTE\",\"ecpdProfileId\":\"ecpdId\",\"cartItemCount\":1,\"cartId\":\"6af05322-815c-423c-9bb2-9b0fce190075\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"onDemandAllowed\":false,\"backDateAllowed\":false,\"futureDateAllowed\":false,\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]}]}}}}";
		AddPlanAndDeviceUIRequest request7 = mapper.readValue(requestString7, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response7 = mapper.readValue(responseString7, AddPlanAndDeviceUIResponse.class);
		System.out.println(request7.getChannelId());
		URI url7 = URI.create("http://localhost/5g/updateCart");
		MockServerHttpRequest httpHeader7 = MockServerHttpRequest.method(HttpMethod.POST, url7).header("channelId", "OMNI-TELESALES").build();
		ServerHttpResponse httpResponse7 = new MockServerHttpResponse();
		httpResponse7.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response7));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse7 = cartController.addPlanAndDevice(httpHeader7, httpResponse7,
				request7);
		StepVerifier.create(controllerResponse7.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		String requestString8 = "{\"cartInfo\":{\"intendType\":\"EUP_LTE\",\"covidQuestionareAnswered\":false,\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"processingMTN\":\"newline1\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
		String responseString8 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"showAALPromoIntercept\":{\"myOfferEligibile\":true},\"caseId\":\"SOP-5188491-E01\",\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-D-410f65a0-8535-471c-b1b3-0d14cbfcbd26\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"cartInfo\":{\"processStep\":\"OrderNow\",\"intendType\":\"EUP_LTE\",\"ecpdProfileId\":\"ecpdId\",\"cartItemCount\":1,\"cartId\":\"6af05322-815c-423c-9bb2-9b0fce190075\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"onDemandAllowed\":false,\"backDateAllowed\":false,\"futureDateAllowed\":false,\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]}]}}}}";
		AddPlanAndDeviceUIRequest request8 = mapper.readValue(requestString8, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response8 = mapper.readValue(responseString8, AddPlanAndDeviceUIResponse.class);
		System.out.println(request8.getChannelId());
		URI url8 = URI.create("http://localhost/5g/updateCart");
		MockServerHttpRequest httpHeader8 = MockServerHttpRequest.method(HttpMethod.POST, url8).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse8 = new MockServerHttpResponse();
		httpResponse8.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response8));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse8 = cartController.addPlanAndDevice(httpHeader8, httpResponse8,
				request8);
		StepVerifier.create(controllerResponse8.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		String requestString9 = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"intendType\":\"AAL_5G\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
		String responseString9 = "{\"errors\":[{}]}";
		AddPlanAndDeviceUIRequest request9 = mapper.readValue(requestString9, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response9 = mapper.readValue(responseString9, AddPlanAndDeviceUIResponse.class);
		System.out.println(request9.getChannelId());
		URI url9 = URI.create("http://localhost/5g/updateCart");
		MockServerHttpRequest httpHeader9 = MockServerHttpRequest.method(HttpMethod.POST, url9).header("channelId", "VZW-DOTCOM").build();
		ServerHttpResponse httpResponse9 = new MockServerHttpResponse();
		httpResponse9.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response9));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse9 = cartController.addPlanAndDevice(httpHeader9, httpResponse9,
				request9);
		StepVerifier.create(controllerResponse9.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();

		String requestString10 = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"intendType\":\"AAL_5G\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
		String responseString10 = "{\"errors\":[{\"namespace\":\"CartService\",\"id\":\"712\",\"message\":\"Invalid Address:Street name/PO Box/Rural Delivery Route not found in Zipcode\",\"name\":\"REQUEST_VALIDATION_ERROR\"}]}";
		AddPlanAndDeviceUIRequest request10 = mapper.readValue(requestString10, AddPlanAndDeviceUIRequest.class);
		AddPlanAndDeviceUIResponse response10 = mapper.readValue(responseString10, AddPlanAndDeviceUIResponse.class);
		System.out.println(request10.getChannelId());
		URI url10 = URI.create("http://localhost/5g/updateCart");
		MockServerHttpRequest httpHeader10 = MockServerHttpRequest.method(HttpMethod.POST, url10).header("channelId", "OMNI-TELESALES").build();
		ServerHttpResponse httpResponse10 = new MockServerHttpResponse();
		httpResponse10.setStatusCode(HttpStatus.CONTINUE);
		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response10));
		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
		Mono<ResponseEntity<GenericResponse>> controllerResponse10 = cartController.addPlanAndDevice(httpHeader10, httpResponse10,
				request10);
		StepVerifier.create(controllerResponse10.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
				.verify();
	}
//	@Test
//	public void addPlanAndDevice_Error2Test() throws IOException {
//		String requestString2 = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"intendType\":\"AAL_5G\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
//		String responseString2 = "{}";
//		AddPlanAndDeviceUIRequest request2 = mapper.readValue(requestString2, AddPlanAndDeviceUIRequest.class);
//		AddPlanAndDeviceUIResponse response2 = mapper.readValue(responseString2, AddPlanAndDeviceUIResponse.class);
//		System.out.println(request2.getChannelId());
//		URI url2 = URI.create("http://localhost/5g/updateCart");
//		MockServerHttpRequest httpHeader2 = MockServerHttpRequest.method(HttpMethod.POST, url2).header("channelId", "VZW-DOTCOM").build();
//		ServerHttpResponse httpResponse2 = new MockServerHttpResponse();
//		httpResponse2.setStatusCode(HttpStatus.CONTINUE);
//		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response2));
//		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
//		Mono<ResponseEntity<GenericResponse>> controllerResponse2 = cartController.addPlanAndDevice(httpHeader2, httpResponse2,
//				request2);
//		StepVerifier.create(controllerResponse2.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
//				.verify();
//	}

//	@Test
//	public void addPlanAndDevice_Error3Test() throws IOException {
//		String requestString3 = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"intendType\":\"AAL_5G\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
//		String responseString3 = "{\"errors\":[{\"namespace\":\"CartService\",\"id\":\"712\",\"message\":\"FiveG qualified address is not available. Please select one.\",\"name\":\"REQUEST_VALIDATION_ERROR\"}]}";
//		AddPlanAndDeviceUIRequest request3 = mapper.readValue(requestString3, AddPlanAndDeviceUIRequest.class);
//		AddPlanAndDeviceUIResponse response3 = mapper.readValue(responseString3, AddPlanAndDeviceUIResponse.class);
//		System.out.println(request3.getChannelId());
//		URI url3 = URI.create("http://localhost/5g/updateCart");
//		MockServerHttpRequest httpHeader3 = MockServerHttpRequest.method(HttpMethod.POST, url3).header("channelId", "VZW-DOTCOM").build();
//		ServerHttpResponse httpResponse3 = new MockServerHttpResponse();
//		httpResponse3.setStatusCode(HttpStatus.CONTINUE);
//		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response3));
//		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
//		Mono<ResponseEntity<GenericResponse>> controllerResponse3 = cartController.addPlanAndDevice(httpHeader3, httpResponse3,
//				request3);
//		StepVerifier.create(controllerResponse3.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
//				.verify();
//	}

//	@Test
//	public void addPlanAndDevice_DigitalChannelIdTest() throws IOException {
//		String requestString4 = "{\"cartInfo\":{\"flowType\":\"WHW_Redemptio\",\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"intendType\":\"AAL_5G\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
//		String responseString4 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-5188491-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Accessories\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Accessories\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-D-410f65a0-8535-471c-b1b3-0d14cbfcbd26\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":1,\"cartId\":\"6af05322-815c-423c-9bb2-9b0fce190075\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"onDemandAllowed\":false,\"backDateAllowed\":false,\"futureDateAllowed\":false,\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"lines\":[{\"status\":1,\"spos\":[{\"id\":\"732\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false},{\"id\":\"1508\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false}],\"sfos\":[{\"id\":\"48526\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"48553\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"54307\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68872\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"70421\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78003\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"83856\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"85503\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86112\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86926\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86927\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86928\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86952\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86953\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false}],\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"mtn\":\"newLine1\",\"isDeviceSelected\":true,\"userSelectedPlan\":false,\"lineId\":\"newLine1\",\"sortingNumber\":\"0\",\"device\":{\"id\":\"LVSKIHP\",\"itemPrice\":\"0.0\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"5G Internet Gateway\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false},\"sim\":{\"id\":\"NI-DPSIM\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"NSE_5G\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"isAppendedLine\":false,\"fiveGPlanAdded\":false}],\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]}]}}}}";
//		AddPlanAndDeviceUIRequest request4 = mapper.readValue(requestString4, AddPlanAndDeviceUIRequest.class);
//		AddPlanAndDeviceUIResponse response4 = mapper.readValue(responseString4, AddPlanAndDeviceUIResponse.class);
//		System.out.println(request4.getChannelId());
//		URI url4 = URI.create("http://localhost/5g/updateCart");
//		MockServerHttpRequest httpHeader4 = MockServerHttpRequest.method(HttpMethod.POST, url4).header("channelId", "VZW-DOTCOM").build();
//		ServerHttpResponse httpResponse4 = new MockServerHttpResponse();
//		httpResponse4.setStatusCode(HttpStatus.CONTINUE);
//		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response4));
//		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
//		Mono<ResponseEntity<GenericResponse>> controllerResponse4 = cartController.addPlanAndDevice(httpHeader4, httpResponse4,
//				request4);
//		StepVerifier.create(controllerResponse4.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
//				.verify();
//	}

//	@Test
//	public void addPlanAndDevice_ConditionCheckTest() throws IOException {
//		String requestString5 = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"intendType\":\"AAL_5G\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
//		String responseString5 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-5188491-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Accessories\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Accessories\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-D-410f65a0-8535-471c-b1b3-0d14cbfcbd26\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"cartInfo\":{\"cartItemCount\":1,\"cartId\":\"\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"onDemandAllowed\":false,\"backDateAllowed\":false,\"futureDateAllowed\":false,\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"lines\":[{\"status\":1,\"spos\":[{\"id\":\"732\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false},{\"id\":\"1508\",\"actionIndicator\":\"A\",\"success\":true,\"is5GBolt\":false}],\"sfos\":[{\"id\":\"48526\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"48553\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"54307\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"68872\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"70421\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"78003\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"83856\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"85503\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86112\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86926\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86927\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86928\",\"conflict\":\"Add SFO due to missing DACC SFO Sequence\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86952\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false},{\"id\":\"86953\",\"actionIndicator\":\"A\",\"displayHumWiFi\":false}],\"reasonCode\":\"PLAN_DEVICE_COMPATIBLE\",\"mtn\":\"newLine1\",\"isDeviceSelected\":true,\"userSelectedPlan\":false,\"lineId\":\"newLine1\",\"sortingNumber\":\"0\",\"device\":{\"id\":\"LVSKIHP\",\"itemPrice\":\"0.0\",\"finalPrice\":\"0.0\",\"discountAmount\":\"0.0\",\"qty\":1,\"edgeUpEnabled\":false,\"numberShareEnabled\":false,\"existingDeviceName\":\"5G Internet Gateway\",\"fiveGToFourGDownGrade\":false,\"byodESimPhone\":false},\"sim\":{\"id\":\"NI-DPSIM\"},\"warranty\":{\"itemPrice\":\"0.0\"},\"devicePlanCompatible\":true,\"planValidationFailed\":false,\"lineActivityType\":\"NSE_5G\",\"planQualifiedForPromotion\":false,\"fiveGUpSell\":false,\"is5GBoltEligible\":false,\"isAppendedLine\":false,\"fiveGPlanAdded\":false}],\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]}]}}}}";
//		AddPlanAndDeviceUIRequest request5 = mapper.readValue(requestString5, AddPlanAndDeviceUIRequest.class);
//		AddPlanAndDeviceUIResponse response5 = mapper.readValue(responseString5, AddPlanAndDeviceUIResponse.class);
//		System.out.println(request5.getChannelId());
//		URI url5 = URI.create("http://localhost/5g/updateCart");
//		MockServerHttpRequest httpHeader5 = MockServerHttpRequest.method(HttpMethod.POST, url5).header("channelId", "VZW-DOTCOM").build();
//		ServerHttpResponse httpResponse5 = new MockServerHttpResponse();
//		httpResponse5.setStatusCode(HttpStatus.CONTINUE);
//		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response5));
//		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
//		Mono<ResponseEntity<GenericResponse>> controllerResponse5 = cartController.addPlanAndDevice(httpHeader5, httpResponse5,
//				request5);
//		StepVerifier.create(controllerResponse5.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
//				.verify();
//	}

//	@Test
//	public void addPlanAndDevice_DigitalChannelIdTest1() throws IOException {
//		String requestString6 = "{\"cartInfo\":{\"covidQuestionareAnswered\":true,\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
//		String responseString6 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-5188491-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Accessories\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Accessories\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-D-410f65a0-8535-471c-b1b3-0d14cbfcbd26\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"cartInfo\":{\"ecpdProfileId\":\"ecpdId\",\"cartItemCount\":1,\"cartId\":\"6af05322-815c-423c-9bb2-9b0fce190075\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"onDemandAllowed\":false,\"backDateAllowed\":false,\"futureDateAllowed\":false,\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]}]}}}}";
//		AddPlanAndDeviceUIRequest request6 = mapper.readValue(requestString6, AddPlanAndDeviceUIRequest.class);
//		AddPlanAndDeviceUIResponse response6 = mapper.readValue(responseString6, AddPlanAndDeviceUIResponse.class);
//		System.out.println(request6.getChannelId());
//		URI url6 = URI.create("http://localhost/5g/updateCart");
//		MockServerHttpRequest httpHeader6 = MockServerHttpRequest.method(HttpMethod.POST, url6).header("channelId", "VZW-DOTCOM").build();
//		ServerHttpResponse httpResponse6 = new MockServerHttpResponse();
//		httpResponse6.setStatusCode(HttpStatus.CONTINUE);
//		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response6));
//		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
//		Mono<ResponseEntity<GenericResponse>> controllerResponse6 = cartController.addPlanAndDevice(httpHeader6, httpResponse6,
//				request6);
//		StepVerifier.create(controllerResponse6.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
//				.verify();
//	}

//	@Test
//	public void addPlanAndDevice_AssistedChannelIdTest() throws IOException {
//		String requestString7 = "{\"cartInfo\":{\"intendType\":\"EUP_LTE\",\"covidQuestionareAnswered\":false,\"clientAppName\":\"OMNI-TELESALES\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
//		String responseString7 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"caseId\":\"SOP-5188491-E01\",\"contextInfo\":{\"availablePaths\":[{\"path\":\"Accessories\"}],\"callReason\":\"SalesOrderPurchase\",\"processStep\":\"Accessories\",\"processAction\":\"\"},\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-D-410f65a0-8535-471c-b1b3-0d14cbfcbd26\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"cartInfo\":{\"processStep\":\"OrderNow\",\"intendType\":\"EUP_LTE\",\"ecpdProfileId\":\"ecpdId\",\"cartItemCount\":1,\"cartId\":\"6af05322-815c-423c-9bb2-9b0fce190075\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"onDemandAllowed\":false,\"backDateAllowed\":false,\"futureDateAllowed\":false,\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]}]}}}}";
//		AddPlanAndDeviceUIRequest request7 = mapper.readValue(requestString7, AddPlanAndDeviceUIRequest.class);
//		AddPlanAndDeviceUIResponse response7 = mapper.readValue(responseString7, AddPlanAndDeviceUIResponse.class);
//		System.out.println(request7.getChannelId());
//		URI url7 = URI.create("http://localhost/5g/updateCart");
//		MockServerHttpRequest httpHeader7 = MockServerHttpRequest.method(HttpMethod.POST, url7).header("channelId", "OMNI-TELESALES").build();
//		ServerHttpResponse httpResponse7 = new MockServerHttpResponse();
//		httpResponse7.setStatusCode(HttpStatus.CONTINUE);
//		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response7));
//		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
//		Mono<ResponseEntity<GenericResponse>> controllerResponse7 = cartController.addPlanAndDevice(httpHeader7, httpResponse7,
//				request7);
//		StepVerifier.create(controllerResponse7.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
//				.verify();
//	}

//	@Test
//	public void addPlanAndDevice_DigitalChannelIdTest3() throws IOException {
//		String requestString8 = "{\"cartInfo\":{\"intendType\":\"EUP_LTE\",\"covidQuestionareAnswered\":false,\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"processingMTN\":\"newline1\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
//		String responseString8 = "{\"serviceHeader\":{\"clientId\":\"VZW-DOTCOM\",\"statusMsg\":\"SUCCESS\",\"serviceName\":\"SalesOrderPurchase\",\"userId\":\"\",\"statusCode\":\"00\"},\"serviceBody\":{\"serviceResponse\":{\"context\":{\"showAALPromoIntercept\":{\"myOfferEligibile\":true},\"caseId\":\"SOP-5188491-E01\",\"customerInfo\":{\"accountNumber\":\"\",\"cartCreator\":\"POE-D-410f65a0-8535-471c-b1b3-0d14cbfcbd26\",\"processingMTN\":\"newLine1\",\"registerNumber\":0},\"cartInfo\":{\"processStep\":\"OrderNow\",\"intendType\":\"EUP_LTE\",\"ecpdProfileId\":\"ecpdId\",\"cartItemCount\":1,\"cartId\":\"6af05322-815c-423c-9bb2-9b0fce190075\",\"statusMsg\":\"Success\",\"devicePlanCompatible\":\"\",\"monthlyCreditAmount\":\"0.0\",\"vztDiscountLoss\":false,\"vztDiscountGain\":false,\"promoLossIndicator\":false,\"effectiveDateDetails\":{\"onDemandAllowed\":false,\"backDateAllowed\":false,\"futureDateAllowed\":false,\"suggestedBackDate\":\"\",\"suggestedFutureDate\":\"\",\"currentBillCycleBeginDate\":\"\",\"nextBillCycleBeginDate\":\"\",\"onDemandDate\":\"\",\"onDemandRangeInDays\":\"\",\"selectedDate\":\"\"},\"agreementNumber\":\"0\",\"financeLimitExceeded\":\"false\",\"expressCheckout\":false,\"oneBillEnrolled\":false,\"hasMixAndMatchPlan\":false,\"preAuthSuccess\":false,\"statusCode\":\"1\",\"showIntercept\":\"false\",\"discountPromoTotal\":0.0,\"registerNumber\":0},\"processMTNList\":[{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]},{\"mtn\":\"newLine1\",\"completedprocessSteps\":[]}]}}}}";
//		AddPlanAndDeviceUIRequest request8 = mapper.readValue(requestString8, AddPlanAndDeviceUIRequest.class);
//		AddPlanAndDeviceUIResponse response8 = mapper.readValue(responseString8, AddPlanAndDeviceUIResponse.class);
//		System.out.println(request8.getChannelId());
//		URI url8 = URI.create("http://localhost/5g/updateCart");
//		MockServerHttpRequest httpHeader8 = MockServerHttpRequest.method(HttpMethod.POST, url8).header("channelId", "VZW-DOTCOM").build();
//		ServerHttpResponse httpResponse8 = new MockServerHttpResponse();
//		httpResponse8.setStatusCode(HttpStatus.CONTINUE);
//		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response8));
//		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
//		Mono<ResponseEntity<GenericResponse>> controllerResponse8 = cartController.addPlanAndDevice(httpHeader8, httpResponse8,
//				request8);
//		StepVerifier.create(controllerResponse8.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
//				.verify();
//	}

//	@Test
//	public void addPlanAndDevice_Error4Test() throws IOException {
//		String requestString9 = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"intendType\":\"AAL_5G\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
//		String responseString9 = "{\"errors\":[{}]}";
//		AddPlanAndDeviceUIRequest request9 = mapper.readValue(requestString9, AddPlanAndDeviceUIRequest.class);
//		AddPlanAndDeviceUIResponse response9 = mapper.readValue(responseString9, AddPlanAndDeviceUIResponse.class);
//		System.out.println(request9.getChannelId());
//		URI url9 = URI.create("http://localhost/5g/updateCart");
//		MockServerHttpRequest httpHeader9 = MockServerHttpRequest.method(HttpMethod.POST, url9).header("channelId", "VZW-DOTCOM").build();
//		ServerHttpResponse httpResponse9 = new MockServerHttpResponse();
//		httpResponse9.setStatusCode(HttpStatus.CONTINUE);
//		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response9));
//		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
//		Mono<ResponseEntity<GenericResponse>> controllerResponse9 = cartController.addPlanAndDevice(httpHeader9, httpResponse9,
//				request9);
//		StepVerifier.create(controllerResponse9.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
//				.verify();
//	}

//	@Test
//	public void addPlanAndDevice_Error5Test() throws IOException {
//		String requestString10 = "{\"cartInfo\":{\"clientAppName\":\"VZW-DOTCOM\",\"cartId\":\"\",\"caseId\":\"\",\"accountNumber\":\"\",\"cartCreator\":\"\",\"processingMTN\":\"\",\"processStep\":\"OrderNow\",\"processAction\":\"DeviceAndPlan\",\"action\":\"\",\"intendType\":\"AAL_5G\",\"bundleInstallType\":\"5GHomeGeminiSelfSetup\"},\"data\":{\"lines\":[{\"depletionType\":\"F\"}]}}";
//		String responseString10 = "{\"errors\":[{\"namespace\":\"CartService\",\"id\":\"712\",\"message\":\"Invalid Address:Street name/PO Box/Rural Delivery Route not found in Zipcode\",\"name\":\"REQUEST_VALIDATION_ERROR\"}]}";
//		AddPlanAndDeviceUIRequest request10 = mapper.readValue(requestString10, AddPlanAndDeviceUIRequest.class);
//		AddPlanAndDeviceUIResponse response10 = mapper.readValue(responseString10, AddPlanAndDeviceUIResponse.class);
//		System.out.println(request10.getChannelId());
//		URI url10 = URI.create("http://localhost/5g/updateCart");
//		MockServerHttpRequest httpHeader10 = MockServerHttpRequest.method(HttpMethod.POST, url10).header("channelId", "OMNI-TELESALES").build();
//		ServerHttpResponse httpResponse10 = new MockServerHttpResponse();
//		httpResponse10.setStatusCode(HttpStatus.CONTINUE);
//		when(readCartHelper.addPlanAndDevice(Mockito.any())).thenReturn(Mono.just(response10));
//		when(redisHelper3.updateFiveGOrderNowDataIntoRedisAsString(Mockito.any(), Mockito.any())).thenReturn(Mono.just(Boolean.TRUE));
//		Mono<ResponseEntity<GenericResponse>> controllerResponse10 = cartController.addPlanAndDevice(httpHeader10, httpResponse10,
//				request10);
//		StepVerifier.create(controllerResponse10.log()).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete()
//				.verify();
//	}

	@Test
	public void initBinderByNameTest()
	{
		WebDataBinder binder = new WebDataBinder(cartController);
		cartController.initBinderByName(binder); // void
		Assert.assertEquals("cart","cart");
	}



}