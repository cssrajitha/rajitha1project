package onevz.soe.cart.service.test.cases;

import static org.mockito.Mockito.when;

import java.io.IOException;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.jackson.databind.ObjectMapper;

import onevz.soe.cart.cxp.helper.CartServiceCxpHelper2;
import onevz.soe.cart.cxp.service.CartServiceCXPServices;
import onevz.soe.cart.model.deviceIdValidation.SearchAttributes;
import onevz.soe.cart.responses.DeviceIdValidationCXPResponse;
import onevz.soe.cart.ui.requests.DeviceIdValidationUIRequest;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;


@RunWith(SpringRunner.class)
public class CartServiceCxpHelper2Test2 {

	private static final Logger logger = LoggerFactory.getLogger(CartServiceCxpHelper2Test2.class);

	@InjectMocks
	private CartServiceCxpHelper2 cxpHelper2;

	@Mock
	private ObjectMapper mapper;
	
	@Mock
	private CartServiceCXPServices cxpService;

	@Test
	public void deviceIdValidationTest1() throws IOException {
		String sampleRequestString = "{\n" +
				"   \"channelId\":\"OMNI-CARE\",\n" +
				"   \"cartInfo\":{\n" +
				"      \"clientAppName\":\"VZW-NETACE\",\n" +
				"      \"action\":\"BYOD\",\n" +
				"      \"cartId\":\"845001b6-5524-4424-ae61-ba9f4099c18d\",\n" +
				"      \"caseId\":\"SOP-1103-E01\",\n" +
				"      \"accountNumber\":\"0207688462-00001\",\n" +
				"      \"cartCreator\":\"6159691822\",\n" +
				"      \"processingMTN\":\"\",\n" +
				"      \"intent\":\"5GHome\",\n" +
				"      \"processStep\":\"GridWallPDP\",\n" +
				"      \"processAction\":\"validateGiftBoxId\"\n" +
				"   },\n" +
				"   \"data\":{\n" +
				"   \"flowName\" : \"DVM\"\n" +
				"      \"lines\":[\n" +
				"         {\n" +
				"\t\t \"wireLineAccountInformation\":{\"vztAccountNo\":\"\"},\n" +
				"            \"mtn\":\"6159691822\",\n" +
				"            \"device\":{\n" +
				"               \"Flowtype\":\"GIFTBOX\",\n" +
				"               \"isCustomerProvidedEquipment\":true,\n" +
				"               \"giftBox\":{\n" +
				"                  \"id\":\"LVSKPGB\"\n" +
				"               }\n" +
				"            }\n" +
				"         }\n" +
				"      ]\n" +
				"   }\n" +
				"}";
		String sampleResponseString = "{\"client\": \"CXP\", \"data\": {  \"lines\": [{  \"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		StepVerifier.create(cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

	}

	@Test
	public void deviceIdValidationTestN2() throws IOException {
		String sampleRequestString = "{\n" +
				"   \"channelId\":\"OMNI-CARE\",\n" +
				"   \"cartInfo\":{\n" +
				"      \"clientAppName\":\"VZW-NETACE\",\n" +
				"      \"action\":\"BYOD\",\n" +
				"      \"cartId\":\"845001b6-5524-4424-ae61-ba9f4099c18d\",\n" +
				"      \"caseId\":\"SOP-1103-E01\",\n" +
				"      \"accountNumber\":\"0207688462-00001\",\n" +
				"      \"cartCreator\":\"6159691822\",\n" +
				"      \"processingMTN\":\"\",\n" +
				"      \"intent\":\"5GHome\",\n" +
				"      \"processStep\":\"GridWallPDP\",\n" +
				"      \"processAction\":\"validateGiftBoxId\"\n" +
				"   },\n" +
				"   \"data\":{\n" +
				"   \"flowName\" : \"DVM\"\n" +
				"      \"lines\":[\n" +
				"         {\n" +
				"\t\t \"wireLineAccountInformation\":{\"vztAccountNo\":\"1234\"},\n" +
				"            \"mtn\":\"6159691822\",\n" +
				"            \"device\":{\n" +
				"               \"Flowtype\":\"GIFTBOX\",\n" +
				"               \"isCustomerProvidedEquipment\":true,\n" +
				"               \"giftBox\":{\n" +
				"                  \"id\":\"LVSKPGB\"\n" +
				"               }\n" +
				"            }\n" +
				"         }\n" +
				"      ]\n" +
				"   }\n" +
				"}";
		String sampleResponseString = "{\"client\": \"CXP\", \"data\": {  \"lines\": [{  \"mtn\": \"2158806687\",\"device\": {\"id\": \"353818087864458\",\"isCustomerProvidedSIM\": false,\"isCPE\": \"YES\",\"Flowtype\": \"DEVICE\",\"CurrentId\": 1232242424242},\"sim\": {\"id\": \"\",\"isCustomerProvidedSIM\": false,\"CurrentSimid\": 1232242424242}}]}}";
		DeviceIdValidationUIRequest sampleRequest = mapper.readValue(sampleRequestString, DeviceIdValidationUIRequest.class);
		DeviceIdValidationCXPResponse sampleResponse = mapper.readValue(sampleResponseString, DeviceIdValidationCXPResponse.class);
		when(cxpService.deviceValidation(Mockito.any())).thenReturn(Mono.just(sampleResponse));
		StepVerifier.create(cxpHelper2.deviceIdValidation(sampleRequest, new SearchAttributes())).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();

	}


}
