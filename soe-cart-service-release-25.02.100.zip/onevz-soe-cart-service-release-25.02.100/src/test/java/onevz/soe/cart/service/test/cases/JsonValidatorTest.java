package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.json.JsonSanitizer;
//import jdk.nashorn.internal.runtime.JSONFunctions;
import onevz.soe.cart.exceptions.JsonValidator;
import onevz.soe.cart.responses.AddZipcodeRedisData;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.requests.RPSApplePayloadUIRequest;
import onevz.soe.cart.ui.requests.SaveCartUIRequest;
import onevz.soe.cart.util.SourceFileReaderUtil;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.IOException;

import static org.mockito.Mockito.*;


@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = { CartServiceTestConfig.class })
@WebFluxTest(JsonValidator.class)
public class JsonValidatorTest {

	@Autowired
	private JsonValidator jsonValidator;
	@Autowired
	private ObjectMapper mapper;
	@Autowired
	SourceFileReaderUtil sourceFileReaderUtil;

	@Value("${onevz.soe.cart.test.fileLocation}")
	private String testFileLocation;

	@Test
	public void convertObjectToStringTest() throws IOException {
		String requestFile = "MockSaveCartRequest.json";
		String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		SaveCartUIRequest sampleRequest = null;
		sampleRequest = mapper.readValue(sampleRequestString, SaveCartUIRequest.class);
		String validatorResponse = jsonValidator.convertObjectToString(sampleRequest);
		StepVerifier.create(Mono.just(validatorResponse)).assertNext(resp -> Assert.assertNotNull(resp)).expectComplete().verify();
		Assert.assertNull(jsonValidator.convertObjectToString((Object) null));
		jsonValidator.convertObjectToString((Object) "{$$'");
	}

	@Test
	public void convertObjectToStringErrorRespTest() throws IOException {
		String requestFile = "ErrorResponse.json";
		String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		ErrorResponse sampleRequest = null;
		sampleRequest = mapper.readValue(sampleRequestString, ErrorResponse.class);
		ErrorResponse validatorResponse = jsonValidator.convertObjectToString(sampleRequest);
		StepVerifier.create(Mono.just(validatorResponse)).assertNext(resp -> Assert.assertNotNull(resp))
				.expectComplete().verify();
//		Assert.assertNull(jsonValidator.convertObjectToString((ErrorResponse) null));
	}

	@Test
	public void convertObjectToStringAddZipCodeDataTest() throws IOException {
		String requestFile = "MockAddZipCodeData.json";
		String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		AddZipcodeRedisData sampleRequest = null;
		sampleRequest = mapper.readValue(sampleRequestString, AddZipcodeRedisData.class);
		AddZipcodeRedisData validatorResponse = jsonValidator.convertObjectToString(sampleRequest);
		StepVerifier.create(Mono.just(validatorResponse)).assertNext(resp -> Assert.assertNotNull(resp))
				.expectComplete().verify();
//		Assert.assertNull(jsonValidator.convertObjectToString((AddZipcodeRedisData) null));
	}

	@Test
	public void convertRPSStringToObjectTest() throws IOException {
		String requestFile = "MockRPSApplePayloadUIRequest.json";
		String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		RPSApplePayloadUIRequest sampleRequest = null;
		sampleRequest = mapper.readValue(sampleRequestString, RPSApplePayloadUIRequest.class);
		RPSApplePayloadUIRequest validatorResponse = jsonValidator.convertRPSStringToObject(sampleRequestString);
		StepVerifier.create(Mono.just(validatorResponse)).assertNext(resp -> Assert.assertNotNull(resp))
				.expectComplete().verify();
	}

	@Test
	public void sanitizeRPSApplePayloadUIRequestTest() throws IOException {
		String requestFile = "MockRPSApplePayloadUIRequest.json";
		String sampleRequestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
		RPSApplePayloadUIRequest sampleRequest = null;
		sampleRequest = mapper.readValue(sampleRequestString, RPSApplePayloadUIRequest.class);
		RPSApplePayloadUIRequest validatorResponse = jsonValidator.sanitizeRPSApplePayloadUIRequest(sampleRequest);
		StepVerifier.create(Mono.just(validatorResponse)).assertNext(resp -> Assert.assertNotNull(resp))
				.expectComplete().verify();
//		Assert.assertNull(jsonValidator.sanitizeRPSApplePayloadUIRequest(null));
	}
}
