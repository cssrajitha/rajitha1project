package onevz.soe.cart.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.cxp.helper.PayOffDetailsHelper;
import onevz.soe.cart.exceptions.JsonValidator;
import onevz.soe.cart.responses.ErrorResponse;
import onevz.soe.cart.responses.GenericResponse;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.AddPayOffDetailsUIRequest;
import onevz.soe.cart.ui.responses.AddPayOffDetailsUIResponse;
import onevz.soe.cart.util.SourceFileReaderUtil;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.http.server.reactive.MockServerHttpResponse;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.net.URI;

import static org.junit.Assert.assertNotNull;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {CartServiceTestConfig.class})
public class PayOffControllerControllerTest {

    @Mock
    private PayOffDetailsHelper payOffDetailsHelper;

    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;
    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;

    @InjectMocks
    private PayOffController controller;

    @Autowired
    private ObjectMapper mapper;

    @Mock
    JsonValidator validator;

    @Test
    public void test_addPayOffDetails_success() throws Exception {
        URI url = URI.create("http://localhost/cart/addPayOffDetails");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        String requestFile = "data/addPayOffDetails/SOE-addPayOffDetails-Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/addPayOffDetails/SOE-addPayOffDetails-Response.json";
        AddPayOffDetailsUIRequest request = mapper.readValue(requestString, AddPayOffDetailsUIRequest.class);
        String resString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);

        AddPayOffDetailsUIResponse response = mapper.readValue(resString, AddPayOffDetailsUIResponse.class);
        Mockito.when(payOffDetailsHelper.getAddPayOffDetails(Mockito.any(), Mockito.any())).thenReturn(Mono.just(response));
        Mono<ResponseEntity<GenericResponse>> responseUI = controller.addPayOffDetails(httpRequest, httpResponse, request);
        StepVerifier.create(responseUI).assertNext(Assert::assertNotNull).verifyComplete();
    }

    @Test
    public void test_addPayOffDetails_validations1() throws Exception {
        URI url = URI.create("http://localhost/cart/addPayOffDetails");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        String requestFile = "data/addPayOffDetails/SOE-addPayOffDetails-Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/addPayOffDetails/SOE-addPayOffDetails-Response.json";
        AddPayOffDetailsUIRequest request = mapper.readValue(requestString, AddPayOffDetailsUIRequest.class);
        String resString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);

        /*AddPayOffDetailsUIResponse response = mapper.readValue(resString, AddPayOffDetailsUIResponse.class);
        Mockito.when(payOffDetailsHelper.getAddPayOffDetails(Mockito.any(), Mockito.any())).thenReturn(Mono.just(response));*/
        request.getCartInfo().setProcessStep(null);
        request.getCartInfo().setProcessAction(null);
        request.getData().setLines(null);
        Mockito.when(validator.convertObjectToString(Mockito.any(ErrorResponse.class))).thenReturn(new ErrorResponse());
        Mono<ResponseEntity<GenericResponse>> responseUI = controller.addPayOffDetails(httpRequest, httpResponse, request);
        StepVerifier.create(responseUI).assertNext(Assert::assertNotNull).verifyComplete();
    }

    @Test
    public void test_addPayOffDetails_validations2() throws Exception {
        URI url = URI.create("http://localhost/cart/addPayOffDetails");
        ServerHttpRequest httpRequest = MockServerHttpRequest.method(HttpMethod.POST, url).build();
        ServerHttpResponse httpResponse = new MockServerHttpResponse();
        String requestFile = "data/addPayOffDetails/SOE-addPayOffDetails-Request.json";
        String requestString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);
        String responseFile = "data/addPayOffDetails/SOE-addPayOffDetails-Response.json";
        AddPayOffDetailsUIRequest request = mapper.readValue(requestString, AddPayOffDetailsUIRequest.class);
        String resString = sourceFileReaderUtil.readFile(requestFile, testFileLocation);

        /*AddPayOffDetailsUIResponse response = mapper.readValue(resString, AddPayOffDetailsUIResponse.class);
        Mockito.when(payOffDetailsHelper.getAddPayOffDetails(Mockito.any(), Mockito.any())).thenReturn(Mono.just(response));*/
        for(Lines line : request.getData().getLines()) {
            request.getData().getLines()[0].setPayOffDeviceInfo(null);
        }

        Mockito.when(validator.convertObjectToString(Mockito.any(ErrorResponse.class))).thenReturn(new ErrorResponse());

        Mono<ResponseEntity<GenericResponse>> responseUI = controller.addPayOffDetails(httpRequest, httpResponse, request);
        StepVerifier.create(responseUI).assertNext(Assert::assertNotNull).verifyComplete();
    }


}
