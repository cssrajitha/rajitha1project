package onevz.soe.cart.service.test.cases;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import onevz.soe.cart.helper.OmniDLHelper;
import onevz.soe.cart.model.addAccessory.AccessoryAction;
import onevz.soe.cart.model.addAccessory.AddAccContext;
import onevz.soe.cart.model.addAccessory.AddAccServiceBody;
import onevz.soe.cart.model.addAccessory.AddAccServiceResponse;
import onevz.soe.cart.model.common.*;
import onevz.soe.cart.model.retrieveCart.CXPRetrieveCartDataVO;
import onevz.soe.cart.responses.CartRedisData;
import onevz.soe.cart.service.test.config.CartServiceTestConfig;
import onevz.soe.cart.ui.common.AddAccessoriesData;
import onevz.soe.cart.ui.common.CartInfo;
import onevz.soe.cart.ui.common.Lines;
import onevz.soe.cart.ui.requests.AddAccessoriesUIRequest;
import onevz.soe.cart.ui.requests.RemoveLinesUIRequest;
import onevz.soe.cart.ui.responses.AddAccessoriesUIResponse;
import onevz.soe.cart.ui.responses.RemoveLinesUIResponse;
import onevz.soe.cart.ui.responses.RetrieveCartUIResponse;
import onevz.soe.cart.util.SourceFileReaderUtil;
import onevz.soe.customerprofile.response.CustomerProfileResponse;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {CartServiceTestConfig.class})
public class OmniDLHelper2Test {
    @Autowired
    OmniDLHelper omniDLHelper;

    @Autowired
    ObjectMapper mapper;

    @Autowired
    SourceFileReaderUtil sourceFileReaderUtil;
    @Value("${onevz.soe.cart.test.fileLocation}")
    private String testFileLocation;
    private RetrieveCartUIResponse cxpResponse;
    private Vzdl vzdl;


    @Before
    public void setUp() {
        cxpResponse = new RetrieveCartUIResponse();
        vzdl = new Vzdl();
    }

    @Test
    public void getVzdlTxnDataForRemoveDeviceCartTest() throws JsonProcessingException {
        String requestString = "{ \"cartInfo\": { \"processingMTN\": \"9194377114\", \"processAction\": \"removeDevice\" }, \"data\": { \"lines\": [ { \"mtn\": \"9194377114\" } ], \"enableAssistedTagging\": true } }";
        RemoveLinesUIRequest request = mapper.readValue(requestString, RemoveLinesUIRequest.class);

        String responseString = "{ \"serviceHeader\": { \"clientId\": \"OMNI-RETAIL\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\", \"correlationId\": \"soe-cart-2024.04.23.09.35.04-178.37801937771425\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \"SOP-18707596-E01\", \"contextInfo\": { \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"ShoppingCart\", \"availablePaths\": [ { \"path\": \"TradeIn\" } ] }, \"customerInfo\": { \"nocByod\": false, \"accountNumber\": \"0513778948-00001\", \"cartCreator\": \"2519798197\", \"processingMTN\": \"9083318304\" }, \"cartInfo\": { \"cartId\": \"029a944d-9e52-42c0-888d-2b978cb239b5\", \"statusMsg\": \"Success\", \"statusCode\": \"1\" }, \"processMTNList\": [ { \"mtn\": \"9083318304\", \"completedprocessSteps\": [ \"ShoppingCart\" ] } ] } } }, \"cartCount\": \"0\" }";
        RemoveLinesUIResponse response = mapper.readValue(responseString, RemoveLinesUIResponse.class);

        CartRedisData cartSession = new CartRedisData();

        String customerProfileJson = "CustomerProfileResponseRD.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(customerProfileJson, testFileLocation);
        CustomerProfileResponse profileResponse = mapper.readValue(sampleRequestString, CustomerProfileResponse.class);

        String sampleCartString = "{ \"cart\": { \"cartHasOnlyAccessories\": false, \"cartHasConflicts\": true, \"conflictsAccepted\": false, \"cartHeader\": { \"vendorId\": \"NETACE\", \"ani\": 9194377114, \"repRole\": \"POSSYSTST\", \"locationType\": \"S\", \"sourceSystem\": \"OMNI-RETAIL\", \"cartId\": \"f9f76751-1bed-4d8f-ae9e-dfe7896117a8\", \"fullAccountNumber\": \"0319507991-1\", \"status\": \"A\", \"cartCreator\": \"9194377114\", \"cartCreatorChannelId\": \"OMNI-RETAIL\", \"cartCreatorOrderLocationCode\": \"P332201\", \"cartCreatorSalesRepId\": \"ENC\", \"caseId\": \"SOP-14196606-C01\", \"visionCustomerType\": \"PE\", \"isERTRep\": false }, \"orderDetails\": { \"totalTaxAmount\": \"0.0\", \"totalPerksSavings\": \"0.0\" }, \"lineDetails\": { \"lineInfo\": [ { \"isCommonPDP\": false, \"isTradeInIntentSelected\": false, \"multiLineSeqNumber\": 2, \"lineActivityType\": \"AAL\", \"totalDueToday\": 1299.99, \"totalDueTodayWithoutTax\": 1299.99, \"totalDueTodayWithoutTaxWithoutDiscount\": 1299.99, \"totalDueMonthly\": 0.0, \"mobileNumber\": \"9194377114\", \"showGlobalChoiceOffer\": false, \"itemsInfo\": [ { \"depletionType\": \"F\", \"attention\": \"RAVI WRIGHT\", \"shipping\": { \"address\": { \"firmName\": \"\", \"apartmentNo\": \"\", \"streetDirection\": \"\" }, \"bsnsName\": \"\", \"shipToCustomerAddress\": false }, \"fipsCode\": \"3403503340\", \"itemCount\": 1, \"itemTabSeqNum\": 0, \"cartItems\": { \"cartItem\": [ { \"discountAmount\": 0.0, \"deviceDollarApplied\": 0.0, \"qrScanNeededForEsimActivation\": false, \"isPreconfigureDuringAddDevice\": false, \"deviceDisplayName\": \"GALAXY S24U 256 VL\", \"accessoryGiftCardAmount\": 0.0, \"tradeInAmountTowardsUserDPUsed\": 0.0, \"sorDeviceCategory\": \"5G Smartphone\", \"sorDeviceType\": \"5GE\", \"operatingSystem\": \"Android\", \"vendingKioskItem\": \"false\", \"canonicalUrl\": \"smartphones/samsung-galaxy-s24-ultra/\", \"bogoItem\": false, \"refxItemSeqNum\": 0, \"sorProductFamily\": \"GALAXY S24 ULTRA\", \"giftCard\": false, \"itemCode\": \"SMS928UZVV\", \"totalPriceWithDiscount\": 1299.99, \"sorId\": \"SMS928UZVV\", \"skuId\": \"sku6010133\", \"cartItemType\": \"DEVICEE\", \"mobileNumber\": \"6413528577\", \"minNumber\": \"6417505600\", \"description\": \"Galaxy S24 Ultra\", \"capacity\": \"256 GB\", \"qty\": 1, \"bundleSeqNum\": 0, \"itemPrice\": \"1299.99\", \"deviceId\": \"\", \"discountedPercentage\": 0.0, \"discountedPrice\": 1299.99, \"buyOutTaxAmountUnbilled\": 0.0, \"buyOutAmountWithoutTax\": 0.0, \"taxAmount\": 0.0, \"imageUrlMap\": { \"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet\", \"largeImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet?$device-lg$\", \"mediumImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet?$device-med$\", \"miniImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet?$device-mini$\", \"thumbImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet?$device-thumb$\" }, \"prodCode1\": \"5GD\", \"prodCode2\": \"SMT\", \"prodCode3\": \"DIG\", \"prodCode4\": \"VDS\", \"prodCode5\": \"ISL\", \"priceType\": \"VERIZON_EDGE\", \"deviceDueMonthly\": 36.11, \"btaEligible\": \"true\", \"depletionType\": \"F\", \"catalogPrice\": 1299.99, \"instantCreditAmountUsed\": 0.0, \"instantCreditAmountUsedForTaxes\": 0.0, \"color\": { \"color\": \"#746f86\", \"colorDisplayName\": \"TITANIUM VIOLET\" }, \"unitTaxBasedPrice\": 1299.99, \"itemNrpPrice\": 1299.99, \"itemCost\": 1299.99, \"upgradeReasonCode\": \"\", \"upgradeReasonDesc\": \"Invalid Reason Code - 0yr\", \"itemPriceType\": \"R\", \"discounts\": [], \"availableReasonCode\": [], \"itemSeqNum\": 1, \"sddEligible\": true, \"smartIMEI\": false, \"year\": 0, \"sellerPrice\": \"0.0\", \"edgeDeviceCap\": \"1299.99\", \"productId\": \"dev21411188\", \"numberShareCapabilityInfo\": { \"sorHdVoiceInd\": true, \"isNumberShareCapable\": false, \"isNumberShareMandatory\": false }, \"taxDetailsList\": [], \"hasDeviceUnlockPolicy\": true, \"manufacturer\": \"Samsung\", \"iconicPhone\": false, \"ringBell\": false, \"quantityAllowed\": false } ] }, \"depletionLocation\": \"\", \"isPromoSelected\": false, \"isTradeInSelected\": false, \"taxExemptionTypes\": \"\" } ], \"assignMTNIndicator\": \"Y\", \"mtnDetails\": { \"dummyMTNForDomain\": \"9437711401\", \"lineNumber\": \"newLine1\", \"minNumber\": \"6417505600\", \"mobileNumber\": \"6413528577\", \"assignMTNTimestamp\": \"2024-04-23T16:35:51.313473-04:00[US/Eastern]\", \"npaNXX\": \"641352\" }, \"lineNumber\": \"newLine1\", \"fiveGToFourGDownGrade\": false, \"deviceTypeSelected\": \"Smartphones\", \"deviceCategoryName\": \"Smartphones\", \"reasonCode\": \"PLAN_DEVICE_COMPATIBLE\", \"disqualifiedPropositions\": [], \"qualifiedPropositions\": [], \"lineCreator\": \"9194377114\", \"lineRefundTotal\": 0.0, \"lineExchangeTotal\": 1299.99, \"totalDueMonthlyBeforeCredit\": 0.0, \"sugAllowed\": false, \"totalDueAddOnMonthly\": 0.0, \"totalPriceOfPlanAndPerks\": \"0.0\", \"isCpe\": false, \"isLTEHomeLine\": false, \"isDevicePlanCompatible\": false, \"portinMtnAssignment\": false, \"impactedLine\": false, \"preOrBackOrder\": false, \"ispuItem\": false, \"ispuItemBYOD\": false, \"isModConnected\": false, \"modDevice\": false, \"byodCapable\": false, \"isCarLine\": false, \"buySimOnly\": false, \"broadBandInd\": false, \"ispuDownPaymentAdjstRequired\": false, \"ispuDownPaymentAmount\": 0.0, \"lineWithSkipMDN\": false, \"protectionNotRequired\": false } ], \"numOfAccessoryAndDeviceItemsInCart\": 1, \"totalEdgeUpAmount\": 0.0, \"totalEdgeBuyOutAmount\": 0.0, \"tradeInDetail\": {}, \"totalDownPaymentAmt\": 0.0, \"numOfLinesWithDevices\": 1, \"subscriptionInfos\": [], \"numofApprovedLines\": 0, \"rfexPayments\": [], \"cartId\": \"f9f76751-1bed-4d8f-ae9e-dfe7896117a8\", \"numOfLines\": 2, \"numofLinesAAL\": 1, \"numofLinesEUP\": 1, \"payments\": [], \"lineSeq\": 0, \"acctMcsSubscription\": [], \"spendingLimitAmountExceededBy\": \"1299.99\", \"numofAccessories\": 0, \"subAccountNBSInfo\": [], \"bagTax\": false, \"couponDetails\": [ {} ] }, \"displayCartValidationErrors\": true }, \"warningMessages\": [], \"redesignFlow\": false, \"isLocalStoreOfferEnabled\": false }";
        CXPRetrieveCartDataVO cart = mapper.readValue(sampleCartString, CXPRetrieveCartDataVO.class);
        cartSession.setRetrieveCart(cart);
        cartSession.setCustomerProfile(profileResponse);

        sampleCartString = "{ \"cart\": { \"cartHasOnlyAccessories\": false, \"cartHasConflicts\": true, \"conflictsAccepted\": false, \"cartHeader\": { \"vendorId\": \"NETACE\", \"ani\": 9194377114, \"repRole\": \"POSSYSTST\", \"locationType\": \"S\", \"sourceSystem\": \"OMNI-RETAIL\", \"cartId\": \"f9f76751-1bed-4d8f-ae9e-dfe7896117a8\", \"fullAccountNumber\": \"0319507991-1\", \"status\": \"A\", \"cartCreator\": \"9194377114\", \"cartCreatorChannelId\": \"OMNI-RETAIL\", \"cartCreatorOrderLocationCode\": \"P332201\", \"cartCreatorSalesRepId\": \"ENC\", \"caseId\": \"SOP-14196606-C01\", \"visionCustomerType\": \"PE\", \"isERTRep\": false }, \"orderDetails\": { \"totalTaxAmount\": \"0.0\", \"totalPerksSavings\": \"0.0\" }, \"lineDetails\": { \"lineInfo\": [ { \"isCommonPDP\": false, \"isTradeInIntentSelected\": false, \"multiLineSeqNumber\": 2, \"lineActivityType\": \"AAL\", \"totalDueToday\": 1299.99, \"totalDueTodayWithoutTax\": 1299.99, \"totalDueTodayWithoutTaxWithoutDiscount\": 1299.99, \"totalDueMonthly\": 0.0, \"mobileNumber\": \"9194377114\", \"showGlobalChoiceOffer\": false, \"itemsInfo\": [ { \"depletionType\": \"F\", \"attention\": \"RAVI WRIGHT\", \"shipping\": { \"address\": { \"firmName\": \"\", \"apartmentNo\": \"\", \"streetDirection\": \"\" }, \"bsnsName\": \"\", \"shipToCustomerAddress\": false }, \"fipsCode\": \"3403503340\", \"itemCount\": 1, \"itemTabSeqNum\": 0, \"cartItems\": { \"cartItem\": [ { \"discountAmount\": 0.0, \"deviceDollarApplied\": 0.0, \"qrScanNeededForEsimActivation\": false, \"isPreconfigureDuringAddDevice\": false, \"deviceDisplayName\": \"GALAXY S24U 256 VL\", \"accessoryGiftCardAmount\": 0.0, \"tradeInAmountTowardsUserDPUsed\": 0.0, \"sorDeviceCategory\": \"5G Smartphone\", \"sorDeviceType\": \"5GE\", \"operatingSystem\": \"Android\", \"vendingKioskItem\": \"false\", \"canonicalUrl\": \"smartphones/samsung-galaxy-s24-ultra/\", \"bogoItem\": false, \"refxItemSeqNum\": 0, \"sorProductFamily\": \"GALAXY S24 ULTRA\", \"giftCard\": false, \"itemCode\": \"SMS928UZVV\", \"totalPriceWithDiscount\": 1299.99, \"sorId\": \"SMS928UZVV\", \"skuId\": \"sku6010133\", \"cartItemType\": \"ACCESSORY\", \"mobileNumber\": \"6413528577\", \"minNumber\": \"6417505600\", \"description\": \"Galaxy S24 Ultra\", \"capacity\": \"256 GB\", \"qty\": 1, \"bundleSeqNum\": 0, \"itemPrice\": \"1299.99\", \"deviceId\": \"\", \"discountedPercentage\": 0.0, \"discountedPrice\": 1299.99, \"buyOutTaxAmountUnbilled\": 0.0, \"buyOutAmountWithoutTax\": 0.0, \"taxAmount\": 0.0, \"imageUrlMap\": { \"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet\", \"largeImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet?$device-lg$\", \"mediumImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet?$device-med$\", \"miniImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet?$device-mini$\", \"thumbImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet?$device-thumb$\" }, \"prodCode1\": \"5GD\", \"prodCode2\": \"SMT\", \"prodCode3\": \"DIG\", \"prodCode4\": \"VDS\", \"prodCode5\": \"ISL\", \"priceType\": \"VERIZON_EDGE\", \"deviceDueMonthly\": 36.11, \"btaEligible\": \"true\", \"depletionType\": \"F\", \"catalogPrice\": 1299.99, \"instantCreditAmountUsed\": 0.0, \"instantCreditAmountUsedForTaxes\": 0.0, \"color\": { \"color\": \"#746f86\", \"colorDisplayName\": \"TITANIUM VIOLET\" }, \"unitTaxBasedPrice\": 1299.99, \"itemNrpPrice\": 1299.99, \"itemCost\": 1299.99, \"upgradeReasonCode\": \"\", \"upgradeReasonDesc\": \"Invalid Reason Code - 0yr\", \"itemPriceType\": \"R\", \"discounts\": [], \"availableReasonCode\": [], \"itemSeqNum\": 1, \"sddEligible\": true, \"smartIMEI\": false, \"year\": 0, \"sellerPrice\": \"0.0\", \"edgeDeviceCap\": \"1299.99\", \"productId\": \"dev21411188\", \"numberShareCapabilityInfo\": { \"sorHdVoiceInd\": true, \"isNumberShareCapable\": false, \"isNumberShareMandatory\": false }, \"taxDetailsList\": [], \"hasDeviceUnlockPolicy\": true, \"manufacturer\": \"Samsung\", \"iconicPhone\": false, \"ringBell\": false, \"quantityAllowed\": false } ] }, \"depletionLocation\": \"\", \"isPromoSelected\": false, \"isTradeInSelected\": false, \"taxExemptionTypes\": \"\" } ], \"assignMTNIndicator\": \"Y\", \"mtnDetails\": { \"dummyMTNForDomain\": \"9437711401\", \"lineNumber\": \"newLine1\", \"minNumber\": \"6417505600\", \"mobileNumber\": \"6413528577\", \"assignMTNTimestamp\": \"2024-04-23T16:35:51.313473-04:00[US/Eastern]\", \"npaNXX\": \"641352\" }, \"lineNumber\": \"newLine1\", \"fiveGToFourGDownGrade\": false, \"deviceTypeSelected\": \"Smartphones\", \"deviceCategoryName\": \"Smartphones\", \"reasonCode\": \"PLAN_DEVICE_COMPATIBLE\", \"disqualifiedPropositions\": [], \"qualifiedPropositions\": [], \"lineCreator\": \"9194377114\", \"lineRefundTotal\": 0.0, \"lineExchangeTotal\": 1299.99, \"totalDueMonthlyBeforeCredit\": 0.0, \"sugAllowed\": false, \"totalDueAddOnMonthly\": 0.0, \"totalPriceOfPlanAndPerks\": \"0.0\", \"isCpe\": false, \"isLTEHomeLine\": false, \"isDevicePlanCompatible\": false, \"portinMtnAssignment\": false, \"impactedLine\": false, \"preOrBackOrder\": false, \"ispuItem\": false, \"ispuItemBYOD\": false, \"isModConnected\": false, \"modDevice\": false, \"byodCapable\": false, \"isCarLine\": false, \"buySimOnly\": false, \"broadBandInd\": false, \"ispuDownPaymentAdjstRequired\": false, \"ispuDownPaymentAmount\": 0.0, \"lineWithSkipMDN\": false, \"protectionNotRequired\": false } ], \"numOfAccessoryAndDeviceItemsInCart\": 1, \"totalEdgeUpAmount\": 0.0, \"totalEdgeBuyOutAmount\": 0.0, \"tradeInDetail\": {}, \"totalDownPaymentAmt\": 0.0, \"numOfLinesWithDevices\": 1, \"subscriptionInfos\": [], \"numofApprovedLines\": 0, \"rfexPayments\": [], \"cartId\": \"f9f76751-1bed-4d8f-ae9e-dfe7896117a8\", \"numOfLines\": 2, \"numofLinesAAL\": 1, \"numofLinesEUP\": 1, \"payments\": [], \"lineSeq\": 0, \"acctMcsSubscription\": [], \"spendingLimitAmountExceededBy\": \"1299.99\", \"numofAccessories\": 0, \"subAccountNBSInfo\": [], \"bagTax\": false, \"couponDetails\": [ {} ] }, \"displayCartValidationErrors\": true }, \"warningMessages\": [], \"redesignFlow\": false, \"isLocalStoreOfferEnabled\": false }";
        cart = mapper.readValue(sampleCartString, CXPRetrieveCartDataVO.class);
        cartSession.setRetrieveCart(cart);
        cartSession.setCustomerProfile(profileResponse);

        sampleCartString = "{ \"cart\": { \"cartHasOnlyAccessories\": false, \"cartHasConflicts\": true, \"conflictsAccepted\": false, \"cartHeader\": { \"vendorId\": \"NETACE\", \"ani\": 9194377114, \"repRole\": \"POSSYSTST\", \"locationType\": \"S\", \"sourceSystem\": \"OMNI-RETAIL\", \"cartId\": \"f9f76751-1bed-4d8f-ae9e-dfe7896117a8\", \"fullAccountNumber\": \"0319507991-1\", \"status\": \"A\", \"cartCreator\": \"9194377114\", \"cartCreatorChannelId\": \"OMNI-RETAIL\", \"cartCreatorOrderLocationCode\": \"P332201\", \"cartCreatorSalesRepId\": \"ENC\", \"caseId\": \"SOP-14196606-C01\", \"visionCustomerType\": \"PE\", \"isERTRep\": false }, \"orderDetails\": { \"totalTaxAmount\": \"0.0\", \"totalPerksSavings\": \"0.0\" }, \"lineDetails\": { \"lineInfo\": [ { \"isCommonPDP\": false, \"isTradeInIntentSelected\": false, \"multiLineSeqNumber\": 2, \"lineActivityType\": \"AAL\", \"totalDueToday\": 1299.99, \"totalDueTodayWithoutTax\": 1299.99, \"totalDueTodayWithoutTaxWithoutDiscount\": 1299.99, \"totalDueMonthly\": 0.0, \"mobileNumber\": \"9194377114\", \"showGlobalChoiceOffer\": false, \"itemsInfo\": [ { \"depletionType\": \"F\", \"attention\": \"RAVI WRIGHT\", \"shipping\": { \"address\": { \"firmName\": \"\", \"apartmentNo\": \"\", \"streetDirection\": \"\" }, \"bsnsName\": \"\", \"shipToCustomerAddress\": false }, \"fipsCode\": \"3403503340\", \"itemCount\": 1, \"itemTabSeqNum\": 0, \"cartItems\": { \"cartItem\": [ { \"discountAmount\": 0.0, \"deviceDollarApplied\": 0.0, \"qrScanNeededForEsimActivation\": false, \"isPreconfigureDuringAddDevice\": false, \"deviceDisplayName\": \"GALAXY S24U 256 VL\", \"accessoryGiftCardAmount\": 0.0, \"tradeInAmountTowardsUserDPUsed\": 0.0, \"sorDeviceCategory\": \"5G Smartphone\", \"sorDeviceType\": \"5GE\", \"operatingSystem\": \"Android\", \"vendingKioskItem\": \"false\", \"canonicalUrl\": \"smartphones/samsung-galaxy-s24-ultra/\", \"bogoItem\": false, \"refxItemSeqNum\": 0, \"sorProductFamily\": \"GALAXY S24 ULTRA\", \"giftCard\": false, \"itemCode\": \"SMS928UZVV\", \"totalPriceWithDiscount\": 1299.99, \"sorId\": \"SMS928UZVV\", \"skuId\": \"sku6010133\", \"cartItemType\": \"\", \"mobileNumber\": \"6413528577\", \"minNumber\": \"6417505600\", \"description\": \"Galaxy S24 Ultra\", \"capacity\": \"256 GB\", \"qty\": 1, \"bundleSeqNum\": 0, \"itemPrice\": \"1299.99\", \"deviceId\": \"\", \"discountedPercentage\": 0.0, \"discountedPrice\": 1299.99, \"buyOutTaxAmountUnbilled\": 0.0, \"buyOutAmountWithoutTax\": 0.0, \"taxAmount\": 0.0, \"imageUrlMap\": { \"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet\", \"largeImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet?$device-lg$\", \"mediumImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet?$device-med$\", \"miniImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet?$device-mini$\", \"thumbImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet?$device-thumb$\" }, \"prodCode1\": \"5GD\", \"prodCode2\": \"SMT\", \"prodCode3\": \"DIG\", \"prodCode4\": \"VDS\", \"prodCode5\": \"ISL\", \"priceType\": \"VERIZON_EDGE\", \"deviceDueMonthly\": 36.11, \"btaEligible\": \"true\", \"depletionType\": \"F\", \"catalogPrice\": 1299.99, \"instantCreditAmountUsed\": 0.0, \"instantCreditAmountUsedForTaxes\": 0.0, \"color\": { \"color\": \"#746f86\", \"colorDisplayName\": \"TITANIUM VIOLET\" }, \"unitTaxBasedPrice\": 1299.99, \"itemNrpPrice\": 1299.99, \"itemCost\": 1299.99, \"upgradeReasonCode\": \"\", \"upgradeReasonDesc\": \"Invalid Reason Code - 0yr\", \"itemPriceType\": \"R\", \"discounts\": [], \"availableReasonCode\": [], \"itemSeqNum\": 1, \"sddEligible\": true, \"smartIMEI\": false, \"year\": 0, \"sellerPrice\": \"0.0\", \"edgeDeviceCap\": \"1299.99\", \"productId\": \"dev21411188\", \"numberShareCapabilityInfo\": { \"sorHdVoiceInd\": true, \"isNumberShareCapable\": false, \"isNumberShareMandatory\": false }, \"taxDetailsList\": [], \"hasDeviceUnlockPolicy\": true, \"manufacturer\": \"Samsung\", \"iconicPhone\": false, \"ringBell\": false, \"quantityAllowed\": false } ] }, \"depletionLocation\": \"\", \"isPromoSelected\": false, \"isTradeInSelected\": false, \"taxExemptionTypes\": \"\" } ], \"assignMTNIndicator\": \"Y\", \"mtnDetails\": { \"dummyMTNForDomain\": \"9437711401\", \"lineNumber\": \"newLine1\", \"minNumber\": \"6417505600\", \"mobileNumber\": \"6413528577\", \"assignMTNTimestamp\": \"2024-04-23T16:35:51.313473-04:00[US/Eastern]\", \"npaNXX\": \"641352\" }, \"lineNumber\": \"newLine1\", \"fiveGToFourGDownGrade\": false, \"deviceTypeSelected\": \"Smartphones\", \"deviceCategoryName\": \"Smartphones\", \"reasonCode\": \"PLAN_DEVICE_COMPATIBLE\", \"disqualifiedPropositions\": [], \"qualifiedPropositions\": [], \"lineCreator\": \"9194377114\", \"lineRefundTotal\": 0.0, \"lineExchangeTotal\": 1299.99, \"totalDueMonthlyBeforeCredit\": 0.0, \"sugAllowed\": false, \"totalDueAddOnMonthly\": 0.0, \"totalPriceOfPlanAndPerks\": \"0.0\", \"isCpe\": false, \"isLTEHomeLine\": false, \"isDevicePlanCompatible\": false, \"portinMtnAssignment\": false, \"impactedLine\": false, \"preOrBackOrder\": false, \"ispuItem\": false, \"ispuItemBYOD\": false, \"isModConnected\": false, \"modDevice\": false, \"byodCapable\": false, \"isCarLine\": false, \"buySimOnly\": false, \"broadBandInd\": false, \"ispuDownPaymentAdjstRequired\": false, \"ispuDownPaymentAmount\": 0.0, \"lineWithSkipMDN\": false, \"protectionNotRequired\": false } ], \"numOfAccessoryAndDeviceItemsInCart\": 1, \"totalEdgeUpAmount\": 0.0, \"totalEdgeBuyOutAmount\": 0.0, \"tradeInDetail\": {}, \"totalDownPaymentAmt\": 0.0, \"numOfLinesWithDevices\": 1, \"subscriptionInfos\": [], \"numofApprovedLines\": 0, \"rfexPayments\": [], \"cartId\": \"f9f76751-1bed-4d8f-ae9e-dfe7896117a8\", \"numOfLines\": 2, \"numofLinesAAL\": 1, \"numofLinesEUP\": 1, \"payments\": [], \"lineSeq\": 0, \"acctMcsSubscription\": [], \"spendingLimitAmountExceededBy\": \"1299.99\", \"numofAccessories\": 0, \"subAccountNBSInfo\": [], \"bagTax\": false, \"couponDetails\": [ {} ] }, \"displayCartValidationErrors\": true }, \"warningMessages\": [], \"redesignFlow\": false, \"isLocalStoreOfferEnabled\": false }";
        cart = mapper.readValue(sampleCartString, CXPRetrieveCartDataVO.class);
        cartSession.setRetrieveCart(cart);
        cartSession.setCustomerProfile(profileResponse);

        Assert.assertNotNull(omniDLHelper.getVzdlTxnDataForRemoveDeviceCart(request, cartSession));
        sampleCartString = "{ \"cart\": { \"cartHasOnlyAccessories\": false, \"cartHasConflicts\": true, \"conflictsAccepted\": false, \"cartHeader\": { \"vendorId\": \"NETACE\", \"ani\": 9194377114, \"repRole\": \"POSSYSTST\", \"locationType\": \"S\", \"sourceSystem\": \"OMNI-RETAIL\", \"cartId\": \"f9f76751-1bed-4d8f-ae9e-dfe7896117a8\", \"fullAccountNumber\": \"0319507991-1\", \"status\": \"A\", \"cartCreator\": \"9194377114\", \"cartCreatorChannelId\": \"OMNI-RETAIL\", \"cartCreatorOrderLocationCode\": \"P332201\", \"cartCreatorSalesRepId\": \"ENC\", \"caseId\": \"SOP-14196606-C01\", \"visionCustomerType\": \"PE\", \"isERTRep\": false }, \"orderDetails\": { \"totalTaxAmount\": \"0.0\", \"totalPerksSavings\": \"0.0\" }, \"lineDetails\": { \"lineInfo\": [ { \"isCommonPDP\": false, \"isTradeInIntentSelected\": false, \"multiLineSeqNumber\": 2, \"lineActivityType\": \"AAL\", \"totalDueToday\": 1299.99, \"totalDueTodayWithoutTax\": 1299.99, \"totalDueTodayWithoutTaxWithoutDiscount\": 1299.99, \"totalDueMonthly\": 0.0, \"mobileNumber\": \"9194377114\", \"showGlobalChoiceOffer\": false, \"itemsInfo\": [ { \"depletionType\": \"F\", \"attention\": \"RAVI WRIGHT\", \"shipping\": { \"address\": { \"firmName\": \"\", \"apartmentNo\": \"\", \"streetDirection\": \"\" }, \"bsnsName\": \"\", \"shipToCustomerAddress\": false }, \"fipsCode\": \"3403503340\", \"itemCount\": 1, \"itemTabSeqNum\": 0, \"cartItems\": { \"cartItem\": [ { \"discountAmount\": 0.0, \"deviceDollarApplied\": 0.0, \"qrScanNeededForEsimActivation\": false, \"isPreconfigureDuringAddDevice\": false, \"deviceDisplayName\": \"GALAXY S24U 256 VL\", \"accessoryGiftCardAmount\": 0.0, \"tradeInAmountTowardsUserDPUsed\": 0.0, \"sorDeviceCategory\": \"5G Smartphone\", \"sorDeviceType\": \"5GE\", \"operatingSystem\": \"Android\", \"vendingKioskItem\": \"false\", \"canonicalUrl\": \"smartphones/samsung-galaxy-s24-ultra/\", \"bogoItem\": false, \"refxItemSeqNum\": 0, \"sorProductFamily\": \"GALAXY S24 ULTRA\", \"giftCard\": false, \"itemCode\": \"SMS928UZVV\", \"totalPriceWithDiscount\": 1299.99, \"sorId\": \"SMS928UZVV\", \"skuId\": \"sku6010133\", \"mobileNumber\": \"6413528577\", \"minNumber\": \"6417505600\", \"description\": \"Galaxy S24 Ultra\", \"capacity\": \"256 GB\", \"qty\": 1, \"bundleSeqNum\": 0, \"itemPrice\": \"1299.99\", \"deviceId\": \"\", \"discountedPercentage\": 0.0, \"discountedPrice\": 1299.99, \"buyOutTaxAmountUnbilled\": 0.0, \"buyOutAmountWithoutTax\": 0.0, \"taxAmount\": 0.0, \"imageUrlMap\": { \"defaultImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet\", \"largeImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet?$device-lg$\", \"mediumImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet?$device-med$\", \"miniImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet?$device-mini$\", \"thumbImage\": \"https://ss7.vzw.com/is/image/VerizonWireless/samsung-eureka-e3-titaniumviolet?$device-thumb$\" }, \"prodCode1\": \"5GD\", \"prodCode2\": \"SMT\", \"prodCode3\": \"DIG\", \"prodCode4\": \"VDS\", \"prodCode5\": \"ISL\", \"priceType\": \"VERIZON_EDGE\", \"deviceDueMonthly\": 36.11, \"btaEligible\": \"true\", \"depletionType\": \"F\", \"catalogPrice\": 1299.99, \"instantCreditAmountUsed\": 0.0, \"instantCreditAmountUsedForTaxes\": 0.0, \"color\": { \"color\": \"#746f86\", \"colorDisplayName\": \"TITANIUM VIOLET\" }, \"unitTaxBasedPrice\": 1299.99, \"itemNrpPrice\": 1299.99, \"itemCost\": 1299.99, \"upgradeReasonCode\": \"\", \"upgradeReasonDesc\": \"Invalid Reason Code - 0yr\", \"itemPriceType\": \"R\", \"discounts\": [], \"availableReasonCode\": [], \"itemSeqNum\": 1, \"sddEligible\": true, \"smartIMEI\": false, \"year\": 0, \"sellerPrice\": \"0.0\", \"edgeDeviceCap\": \"1299.99\", \"productId\": \"dev21411188\", \"numberShareCapabilityInfo\": { \"sorHdVoiceInd\": true, \"isNumberShareCapable\": false, \"isNumberShareMandatory\": false }, \"taxDetailsList\": [], \"hasDeviceUnlockPolicy\": true, \"manufacturer\": \"Samsung\", \"iconicPhone\": false, \"ringBell\": false, \"quantityAllowed\": false } ] }, \"depletionLocation\": \"\", \"isPromoSelected\": false, \"isTradeInSelected\": false, \"taxExemptionTypes\": \"\" } ], \"assignMTNIndicator\": \"Y\", \"mtnDetails\": { \"dummyMTNForDomain\": \"9437711401\", \"lineNumber\": \"newLine1\", \"minNumber\": \"6417505600\", \"mobileNumber\": \"6413528577\", \"assignMTNTimestamp\": \"2024-04-23T16:35:51.313473-04:00[US/Eastern]\", \"npaNXX\": \"641352\" }, \"lineNumber\": \"newLine1\", \"fiveGToFourGDownGrade\": false, \"deviceTypeSelected\": \"Smartphones\", \"deviceCategoryName\": \"Smartphones\", \"reasonCode\": \"PLAN_DEVICE_COMPATIBLE\", \"disqualifiedPropositions\": [], \"qualifiedPropositions\": [], \"lineCreator\": \"9194377114\", \"lineRefundTotal\": 0.0, \"lineExchangeTotal\": 1299.99, \"totalDueMonthlyBeforeCredit\": 0.0, \"sugAllowed\": false, \"totalDueAddOnMonthly\": 0.0, \"totalPriceOfPlanAndPerks\": \"0.0\", \"isCpe\": false, \"isLTEHomeLine\": false, \"isDevicePlanCompatible\": false, \"portinMtnAssignment\": false, \"impactedLine\": false, \"preOrBackOrder\": false, \"ispuItem\": false, \"ispuItemBYOD\": false, \"isModConnected\": false, \"modDevice\": false, \"byodCapable\": false, \"isCarLine\": false, \"buySimOnly\": false, \"broadBandInd\": false, \"ispuDownPaymentAdjstRequired\": false, \"ispuDownPaymentAmount\": 0.0, \"lineWithSkipMDN\": false, \"protectionNotRequired\": false } ], \"numOfAccessoryAndDeviceItemsInCart\": 1, \"totalEdgeUpAmount\": 0.0, \"totalEdgeBuyOutAmount\": 0.0, \"tradeInDetail\": {}, \"totalDownPaymentAmt\": 0.0, \"numOfLinesWithDevices\": 1, \"subscriptionInfos\": [], \"numofApprovedLines\": 0, \"rfexPayments\": [], \"cartId\": \"f9f76751-1bed-4d8f-ae9e-dfe7896117a8\", \"numOfLines\": 2, \"numofLinesAAL\": 1, \"numofLinesEUP\": 1, \"payments\": [], \"lineSeq\": 0, \"acctMcsSubscription\": [], \"spendingLimitAmountExceededBy\": \"1299.99\", \"numofAccessories\": 0, \"subAccountNBSInfo\": [], \"bagTax\": false, \"couponDetails\": [ {} ] }, \"displayCartValidationErrors\": true }, \"warningMessages\": [], \"redesignFlow\": false, \"isLocalStoreOfferEnabled\": false }";
        cart = mapper.readValue(sampleCartString, CXPRetrieveCartDataVO.class);
        cartSession.setRetrieveCart(cart);
        Assert.assertNotNull(omniDLHelper.getVzdlTxnDataForRemoveDeviceCart(request, cartSession));

        Assert.assertNotNull(omniDLHelper.getVzdlTxnDataForRemoveDeviceCart(request, cartSession));
        sampleCartString = "{ \"cart\": { \"cartHasOnlyAccessories\": false, \"cartHasConflicts\": true, \"conflictsAccepted\": false, \"cartHeader\": { \"vendorId\": \"NETACE\", \"ani\": 9194377114, \"repRole\": \"POSSYSTST\", \"locationType\": \"S\", \"sourceSystem\": \"OMNI-RETAIL\", \"cartId\": \"f9f76751-1bed-4d8f-ae9e-dfe7896117a8\", \"fullAccountNumber\": \"0319507991-1\", \"status\": \"A\", \"cartCreator\": \"9194377114\", \"cartCreatorChannelId\": \"OMNI-RETAIL\", \"cartCreatorOrderLocationCode\": \"P332201\", \"cartCreatorSalesRepId\": \"ENC\", \"caseId\": \"SOP-14196606-C01\", \"visionCustomerType\": \"PE\", \"isERTRep\": false }, \"orderDetails\": { \"totalTaxAmount\": \"0.0\", \"totalPerksSavings\": \"0.0\" }, \"lineDetails\": { \"lineInfo\": [ { \"isCommonPDP\": false, \"isTradeInIntentSelected\": false, \"multiLineSeqNumber\": 2, \"lineActivityType\": \"AAL\", \"totalDueToday\": 1299.99, \"totalDueTodayWithoutTax\": 1299.99, \"totalDueTodayWithoutTaxWithoutDiscount\": 1299.99, \"totalDueMonthly\": 0.0, \"mobileNumber\": \"9194377114\", \"showGlobalChoiceOffer\": false, \"itemsInfo\": [ { \"depletionType\": \"F\", \"attention\": \"RAVI WRIGHT\", \"shipping\": { \"address\": { \"firmName\": \"\", \"apartmentNo\": \"\", \"streetDirection\": \"\" }, \"bsnsName\": \"\", \"shipToCustomerAddress\": false }, \"fipsCode\": \"3403503340\", \"itemCount\": 1, \"itemTabSeqNum\": 0, \"cartItems\": {}, \"depletionLocation\": \"\", \"isPromoSelected\": false, \"isTradeInSelected\": false, \"taxExemptionTypes\": \"\" } ], \"assignMTNIndicator\": \"Y\", \"mtnDetails\": { \"dummyMTNForDomain\": \"9437711401\", \"lineNumber\": \"newLine1\", \"minNumber\": \"6417505600\", \"mobileNumber\": \"6413528577\", \"assignMTNTimestamp\": \"2024-04-23T16:35:51.313473-04:00[US/Eastern]\", \"npaNXX\": \"641352\" }, \"lineNumber\": \"newLine1\", \"fiveGToFourGDownGrade\": false, \"deviceTypeSelected\": \"Smartphones\", \"deviceCategoryName\": \"Smartphones\", \"reasonCode\": \"PLAN_DEVICE_COMPATIBLE\", \"disqualifiedPropositions\": [], \"qualifiedPropositions\": [], \"lineCreator\": \"9194377114\", \"lineRefundTotal\": 0.0, \"lineExchangeTotal\": 1299.99, \"totalDueMonthlyBeforeCredit\": 0.0, \"sugAllowed\": false, \"totalDueAddOnMonthly\": 0.0, \"totalPriceOfPlanAndPerks\": \"0.0\", \"isCpe\": false, \"isLTEHomeLine\": false, \"isDevicePlanCompatible\": false, \"portinMtnAssignment\": false, \"impactedLine\": false, \"preOrBackOrder\": false, \"ispuItem\": false, \"ispuItemBYOD\": false, \"isModConnected\": false, \"modDevice\": false, \"byodCapable\": false, \"isCarLine\": false, \"buySimOnly\": false, \"broadBandInd\": false, \"ispuDownPaymentAdjstRequired\": false, \"ispuDownPaymentAmount\": 0.0, \"lineWithSkipMDN\": false, \"protectionNotRequired\": false } ], \"numOfAccessoryAndDeviceItemsInCart\": 1, \"totalEdgeUpAmount\": 0.0, \"totalEdgeBuyOutAmount\": 0.0, \"tradeInDetail\": {}, \"totalDownPaymentAmt\": 0.0, \"numOfLinesWithDevices\": 1, \"subscriptionInfos\": [], \"numofApprovedLines\": 0, \"rfexPayments\": [], \"cartId\": \"f9f76751-1bed-4d8f-ae9e-dfe7896117a8\", \"numOfLines\": 2, \"numofLinesAAL\": 1, \"numofLinesEUP\": 1, \"payments\": [], \"lineSeq\": 0, \"acctMcsSubscription\": [], \"spendingLimitAmountExceededBy\": \"1299.99\", \"numofAccessories\": 0, \"subAccountNBSInfo\": [], \"bagTax\": false, \"couponDetails\": [ {} ] }, \"displayCartValidationErrors\": true }, \"warningMessages\": [], \"redesignFlow\": false, \"isLocalStoreOfferEnabled\": false }";
        cart = mapper.readValue(sampleCartString, CXPRetrieveCartDataVO.class);
        cartSession.setRetrieveCart(cart);
        Assert.assertNotNull(omniDLHelper.getVzdlTxnDataForRemoveDeviceCart(request, cartSession));

        Assert.assertNotNull(omniDLHelper.getVzdlTxnDataForRemoveDeviceCart(request, cartSession));
        sampleCartString = "{ \"cart\": { \"cartHasOnlyAccessories\": false, \"cartHasConflicts\": true, \"conflictsAccepted\": false, \"cartHeader\": { \"vendorId\": \"NETACE\", \"ani\": 9194377114, \"repRole\": \"POSSYSTST\", \"locationType\": \"S\", \"sourceSystem\": \"OMNI-RETAIL\", \"cartId\": \"f9f76751-1bed-4d8f-ae9e-dfe7896117a8\", \"fullAccountNumber\": \"0319507991-1\", \"status\": \"A\", \"cartCreator\": \"9194377114\", \"cartCreatorChannelId\": \"OMNI-RETAIL\", \"cartCreatorOrderLocationCode\": \"P332201\", \"cartCreatorSalesRepId\": \"ENC\", \"caseId\": \"SOP-14196606-C01\", \"visionCustomerType\": \"PE\", \"isERTRep\": false }, \"orderDetails\": { \"totalTaxAmount\": \"0.0\", \"totalPerksSavings\": \"0.0\" }, \"lineDetails\": { \"lineInfo\": [ { \"isCommonPDP\": false, \"isTradeInIntentSelected\": false, \"multiLineSeqNumber\": 2, \"lineActivityType\": \"AAL\", \"totalDueToday\": 1299.99, \"totalDueTodayWithoutTax\": 1299.99, \"totalDueTodayWithoutTaxWithoutDiscount\": 1299.99, \"totalDueMonthly\": 0.0, \"mobileNumber\": \"9194377114\", \"showGlobalChoiceOffer\": false, \"itemsInfo\": [ { \"depletionType\": \"F\", \"attention\": \"RAVI WRIGHT\", \"shipping\": { \"address\": { \"firmName\": \"\", \"apartmentNo\": \"\", \"streetDirection\": \"\" }, \"bsnsName\": \"\", \"shipToCustomerAddress\": false }, \"fipsCode\": \"3403503340\", \"itemCount\": 1, \"itemTabSeqNum\": 0, \"depletionLocation\": \"\", \"isPromoSelected\": false, \"isTradeInSelected\": false, \"taxExemptionTypes\": \"\" } ], \"assignMTNIndicator\": \"Y\", \"mtnDetails\": { \"dummyMTNForDomain\": \"9437711401\", \"lineNumber\": \"newLine1\", \"minNumber\": \"6417505600\", \"mobileNumber\": \"6413528577\", \"assignMTNTimestamp\": \"2024-04-23T16:35:51.313473-04:00[US/Eastern]\", \"npaNXX\": \"641352\" }, \"lineNumber\": \"newLine1\", \"fiveGToFourGDownGrade\": false, \"deviceTypeSelected\": \"Smartphones\", \"deviceCategoryName\": \"Smartphones\", \"reasonCode\": \"PLAN_DEVICE_COMPATIBLE\", \"disqualifiedPropositions\": [], \"qualifiedPropositions\": [], \"lineCreator\": \"9194377114\", \"lineRefundTotal\": 0.0, \"lineExchangeTotal\": 1299.99, \"totalDueMonthlyBeforeCredit\": 0.0, \"sugAllowed\": false, \"totalDueAddOnMonthly\": 0.0, \"totalPriceOfPlanAndPerks\": \"0.0\", \"isCpe\": false, \"isLTEHomeLine\": false, \"isDevicePlanCompatible\": false, \"portinMtnAssignment\": false, \"impactedLine\": false, \"preOrBackOrder\": false, \"ispuItem\": false, \"ispuItemBYOD\": false, \"isModConnected\": false, \"modDevice\": false, \"byodCapable\": false, \"isCarLine\": false, \"buySimOnly\": false, \"broadBandInd\": false, \"ispuDownPaymentAdjstRequired\": false, \"ispuDownPaymentAmount\": 0.0, \"lineWithSkipMDN\": false, \"protectionNotRequired\": false } ], \"numOfAccessoryAndDeviceItemsInCart\": 1, \"totalEdgeUpAmount\": 0.0, \"totalEdgeBuyOutAmount\": 0.0, \"tradeInDetail\": {}, \"totalDownPaymentAmt\": 0.0, \"numOfLinesWithDevices\": 1, \"subscriptionInfos\": [], \"numofApprovedLines\": 0, \"rfexPayments\": [], \"cartId\": \"f9f76751-1bed-4d8f-ae9e-dfe7896117a8\", \"numOfLines\": 2, \"numofLinesAAL\": 1, \"numofLinesEUP\": 1, \"payments\": [], \"lineSeq\": 0, \"acctMcsSubscription\": [], \"spendingLimitAmountExceededBy\": \"1299.99\", \"numofAccessories\": 0, \"subAccountNBSInfo\": [], \"bagTax\": false, \"couponDetails\": [ {} ] }, \"displayCartValidationErrors\": true }, \"warningMessages\": [], \"redesignFlow\": false, \"isLocalStoreOfferEnabled\": false }";
        cart = mapper.readValue(sampleCartString, CXPRetrieveCartDataVO.class);
        cartSession.setRetrieveCart(cart);
        Assert.assertNotNull(omniDLHelper.getVzdlTxnDataForRemoveDeviceCart(request, cartSession));


        Assert.assertNotNull(omniDLHelper.getVzdlTxnDataForRemoveDeviceCart(request, cartSession));
    }
    @Test
    public void getVzdlTxnDataForRemoveDeviceCartEdgeTest() throws JsonProcessingException {
        String requestString = "{ \"cartInfo\": { \"processingMTN\": \"9194377114\", \"processAction\": \"removeDevice\" }, \"data\": { \"lines\": [ { \"mtn\": \"9194377114\" } ], \"enableAssistedTagging\": true } }";
        RemoveLinesUIRequest request = mapper.readValue(requestString, RemoveLinesUIRequest.class);

        String responseString = "{ \"serviceHeader\": { \"clientId\": \"OMNI-RETAIL\", \"statusMsg\": \"SUCCESS\", \"serviceName\": \"SalesOrderPurchase\", \"userId\": \"\", \"statusCode\": \"00\", \"sessionId\": \"\", \"correlationId\": \"soe-cart-2024.04.23.09.35.04-178.37801937771425\" }, \"serviceBody\": { \"serviceResponse\": { \"context\": { \"caseId\": \"SOP-18707596-E01\", \"contextInfo\": { \"callReason\": \"SalesOrderPurchase\", \"processStep\": \"ShoppingCart\", \"availablePaths\": [ { \"path\": \"TradeIn\" } ] }, \"customerInfo\": { \"nocByod\": false, \"accountNumber\": \"0513778948-00001\", \"cartCreator\": \"2519798197\", \"processingMTN\": \"9083318304\" }, \"cartInfo\": { \"cartId\": \"029a944d-9e52-42c0-888d-2b978cb239b5\", \"statusMsg\": \"Success\", \"statusCode\": \"1\" }, \"processMTNList\": [ { \"mtn\": \"9083318304\", \"completedprocessSteps\": [ \"ShoppingCart\" ] } ] } } }, \"cartCount\": \"0\" }";
        RemoveLinesUIResponse response = mapper.readValue(responseString, RemoveLinesUIResponse.class);

        CartRedisData cartSession = new CartRedisData();

        String customerProfileJson = "CustomerProfileResponseRD.json";
        String sampleRequestString = sourceFileReaderUtil.readFile(customerProfileJson, testFileLocation);
        CustomerProfileResponse profileResponse = mapper.readValue(sampleRequestString, CustomerProfileResponse.class);
        String sampleCartString = "{ \"cart\": { \"cartHasOnlyAccessories\": false, \"cartHasConflicts\": true, \"conflictsAccepted\": false, \"cartHeader\": { \"vendorId\": \"NETACE\", \"ani\": 9194377114, \"repRole\": \"POSSYSTST\", \"locationType\": \"S\", \"sourceSystem\": \"OMNI-RETAIL\", \"cartId\": \"f9f76751-1bed-4d8f-ae9e-dfe7896117a8\", \"fullAccountNumber\": \"0319507991-1\", \"status\": \"A\", \"cartCreator\": \"9194377114\", \"cartCreatorChannelId\": \"OMNI-RETAIL\", \"cartCreatorOrderLocationCode\": \"P332201\", \"cartCreatorSalesRepId\": \"ENC\", \"caseId\": \"SOP-14196606-C01\", \"visionCustomerType\": \"PE\", \"isERTRep\": false }, \"orderDetails\": { \"totalTaxAmount\": \"0.0\", \"totalPerksSavings\": \"0.0\" }, \"lineDetails\": { \"lineInfo\": [ { \"isCommonPDP\": false, \"isTradeInIntentSelected\": false, \"multiLineSeqNumber\": 2, \"lineActivityType\": \"AAL\", \"totalDueToday\": 1299.99, \"totalDueTodayWithoutTax\": 1299.99, \"totalDueTodayWithoutTaxWithoutDiscount\": 1299.99, \"totalDueMonthly\": 0.0, \"mobileNumber\": \"9194377114\", \"showGlobalChoiceOffer\": false, \"assignMTNIndicator\": \"Y\", \"mtnDetails\": { \"dummyMTNForDomain\": \"9437711401\", \"lineNumber\": \"newLine1\", \"minNumber\": \"6417505600\", \"mobileNumber\": \"6413528577\", \"assignMTNTimestamp\": \"2024-04-23T16:35:51.313473-04:00[US/Eastern]\", \"npaNXX\": \"641352\" }, \"lineNumber\": \"newLine1\", \"fiveGToFourGDownGrade\": false, \"deviceTypeSelected\": \"Smartphones\", \"deviceCategoryName\": \"Smartphones\", \"reasonCode\": \"PLAN_DEVICE_COMPATIBLE\", \"disqualifiedPropositions\": [], \"qualifiedPropositions\": [], \"lineCreator\": \"9194377114\", \"lineRefundTotal\": 0.0, \"lineExchangeTotal\": 1299.99, \"totalDueMonthlyBeforeCredit\": 0.0, \"sugAllowed\": false, \"totalDueAddOnMonthly\": 0.0, \"totalPriceOfPlanAndPerks\": \"0.0\", \"isCpe\": false, \"isLTEHomeLine\": false, \"isDevicePlanCompatible\": false, \"portinMtnAssignment\": false, \"impactedLine\": false, \"preOrBackOrder\": false, \"ispuItem\": false, \"ispuItemBYOD\": false, \"isModConnected\": false, \"modDevice\": false, \"byodCapable\": false, \"isCarLine\": false, \"buySimOnly\": false, \"broadBandInd\": false, \"ispuDownPaymentAdjstRequired\": false, \"ispuDownPaymentAmount\": 0.0, \"lineWithSkipMDN\": false, \"protectionNotRequired\": false } ], \"numOfAccessoryAndDeviceItemsInCart\": 1, \"totalEdgeUpAmount\": 0.0, \"totalEdgeBuyOutAmount\": 0.0, \"tradeInDetail\": {}, \"totalDownPaymentAmt\": 0.0, \"numOfLinesWithDevices\": 1, \"subscriptionInfos\": [], \"numofApprovedLines\": 0, \"rfexPayments\": [], \"cartId\": \"f9f76751-1bed-4d8f-ae9e-dfe7896117a8\", \"numOfLines\": 2, \"numofLinesAAL\": 1, \"numofLinesEUP\": 1, \"payments\": [], \"lineSeq\": 0, \"acctMcsSubscription\": [], \"spendingLimitAmountExceededBy\": \"1299.99\", \"numofAccessories\": 0, \"subAccountNBSInfo\": [], \"bagTax\": false, \"couponDetails\": [ {} ] }, \"displayCartValidationErrors\": true }, \"warningMessages\": [], \"redesignFlow\": false, \"isLocalStoreOfferEnabled\": false }";
        CXPRetrieveCartDataVO cart = mapper.readValue(sampleCartString, CXPRetrieveCartDataVO.class);
        cartSession.setRetrieveCart(cart);
        request.getData().getLines()[0].setMtn("12345");
        Assert.assertNotNull(omniDLHelper.getVzdlTxnDataForRemoveDeviceCart(request, cartSession));

        request.getData().getLines()[0].setMtn(null);
        Assert.assertNotNull(omniDLHelper.getVzdlTxnDataForRemoveDeviceCart(request, cartSession));


        cartSession.getRetrieveCart().getCart().getLineDetails().getLineInfo()[0].setMobileNumber(null);
        Assert.assertNotNull(omniDLHelper.getVzdlTxnDataForRemoveDeviceCart(request, cartSession));

        cartSession.getRetrieveCart().getCart().setLineDetails(null);
        Assert.assertNull(omniDLHelper.getVzdlTxnDataForRemoveDeviceCart(request, cartSession));

        cartSession.setRetrieveCart(null);
        Assert.assertNull(omniDLHelper.getVzdlTxnDataForRemoveDeviceCart(request, cartSession));

        request.getData().setLines(null);
        Assert.assertNull(omniDLHelper.getVzdlTxnDataForRemoveDeviceCart(request, cartSession));

        request.getData().setLines(new Lines[0]);
        Assert.assertNull(omniDLHelper.getVzdlTxnDataForRemoveDeviceCart(request, cartSession));

    }

    @Test
    public void getVzdlDataForAddAccessoriesTest() {
        AddAccessoriesUIRequest request = null;
        AddAccessoriesUIResponse response = null;
        String sessionId = "";
        Assert.assertNull(omniDLHelper.getVzdlDataForAddAccessories(request, response));

        request = new AddAccessoriesUIRequest();
        response = new AddAccessoriesUIResponse();
        Assert.assertNull(omniDLHelper.getVzdlDataForAddAccessories(request, response));

        request.setData(new AddAccessoriesData());
        omniDLHelper.getVzdlDataForAddAccessories(request, response);
        Assert.assertNotNull(vzdl);

        response.setServiceBody(new AddAccServiceBody());
        omniDLHelper.getVzdlDataForAddAccessories(request, response);
        Assert.assertNotNull(vzdl);

        request = new AddAccessoriesUIRequest();
        omniDLHelper.getVzdlDataForAddAccessories(request, response);
        Assert.assertNotNull(vzdl);
    }
    @Test
    public void populateVzdlDataForAddAccessoriesTest1() {
        AddAccessoriesData data = new AddAccessoriesData();
        AddAccessoriesUIRequest request = new AddAccessoriesUIRequest();
        AddAccessoriesUIResponse addAccessoriesUIResponse = new AddAccessoriesUIResponse();
        addAccessoriesUIResponse.setServiceBody(new AddAccServiceBody());
        addAccessoriesUIResponse.getServiceBody().setServiceResponse(new AddAccServiceResponse());
        addAccessoriesUIResponse.getServiceBody().getServiceResponse().setContext(new AddAccContext());
        addAccessoriesUIResponse.getServiceBody().getServiceResponse().getContext().setCartInfo(new CartServiceCartInfo());
        Line[] lineArr = new Line[2];
        Line line = new Line();
        line.setCurrentPlanType(null);

        AccessoryAction accessoryAction = new AccessoryAction();
        List<ItemDetails> itemDetails = new ArrayList<>();
        ItemDetails items = new ItemDetails();

        items.setCategory("accessories");
        items.setQty(1);
        items.setName("AirPods 4 with Active Noise Cancellation");
        items.setItemPrice("179.00");
        items.setId("MXP93LL/A");
        items.setSkuId("acc562736");
        itemDetails.add(items);
        accessoryAction.setItems(itemDetails);
        line.setAccessories(accessoryAction);
        lineArr[0] = line;
        lineArr[1] = null;
        Lines[] reqLine = new Lines[1];
        Lines lines = new Lines();

        lines.setMtn("8323149457");
        lines.setAccountOwner("Account Owner");
        Accessory[] addAccessories =  new Accessory[1];
        Accessory accessory = new Accessory();
        accessory.setId("1");
        addAccessories[0] = accessory;
        lines.setAddAccessories(addAccessories);
        reqLine[0] = lines;
        data.setLines(reqLine);
        CartInfo cartInfo = new CartInfo();
        cartInfo.setCaseId("SOP-21855585-E01");
        request.setCartInfo(cartInfo);
        addAccessoriesUIResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(lineArr);


        request.setData(data);
        request.setChannelId("OMNI-RETAIL");
        vzdl = omniDLHelper.populateVzdlDataForAddAccessories(request,addAccessoriesUIResponse);
        Assert.assertNotNull(vzdl);

        Arrays.stream(addAccessoriesUIResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getLines()).forEach(x->
        {
            if(x!=null)
                x.getAccessories().getItems().stream().forEach(y -> y.setSkuId(null));
        });
        vzdl = omniDLHelper.populateVzdlDataForAddAccessories(request,addAccessoriesUIResponse);
        Assert.assertNotNull(vzdl);

        Arrays.stream(addAccessoriesUIResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getLines()).forEach(x->
        {
            if(x!=null)
                x.getAccessories().getItems().stream().forEach(y -> y.setItemPrice(null));
        });
        vzdl = omniDLHelper.populateVzdlDataForAddAccessories(request,addAccessoriesUIResponse);
        Assert.assertNotNull(vzdl);

        Arrays.stream(addAccessoriesUIResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getLines()).forEach(x->
        {
            if (x != null)
                x.getAccessories().getItems().stream().forEach(y -> y.setName(null));
        });
        vzdl = omniDLHelper.populateVzdlDataForAddAccessories(request,addAccessoriesUIResponse);
        Assert.assertNotNull(vzdl);

        Arrays.stream(addAccessoriesUIResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getLines()).forEach(x->
        {
            if (x != null)
                x.getAccessories().getItems().stream().forEach(y -> y.setId(null));
        });
        vzdl = omniDLHelper.populateVzdlDataForAddAccessories(request,addAccessoriesUIResponse);
        Assert.assertNotNull(vzdl);

        Arrays.stream(addAccessoriesUIResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getLines()).forEach(x->
        {
            if (x != null)
                x.getAccessories().setItems(null);
        });
        vzdl = omniDLHelper.populateVzdlDataForAddAccessories(request,addAccessoriesUIResponse);
        Assert.assertNotNull(vzdl);

        Arrays.stream(addAccessoriesUIResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().getLines()).forEach(x->
        {
            if (x != null)
                x.setAccessories(null);
        });
        vzdl = omniDLHelper.populateVzdlDataForAddAccessories(request,addAccessoriesUIResponse);
        Assert.assertNotNull(vzdl);

        addAccessoriesUIResponse.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(null);
        vzdl = omniDLHelper.populateVzdlDataForAddAccessories(request,addAccessoriesUIResponse);
        Assert.assertNull(vzdl);

        addAccessoriesUIResponse.getServiceBody().getServiceResponse().getContext().setCartInfo(null);
        vzdl = omniDLHelper.populateVzdlDataForAddAccessories(request,addAccessoriesUIResponse);
        Assert.assertNull(vzdl);

        addAccessoriesUIResponse.getServiceBody().getServiceResponse().setContext(null);
        vzdl = omniDLHelper.populateVzdlDataForAddAccessories(request,addAccessoriesUIResponse);
        Assert.assertNull(vzdl);

        addAccessoriesUIResponse.getServiceBody().setServiceResponse(null);
        vzdl = omniDLHelper.populateVzdlDataForAddAccessories(request,addAccessoriesUIResponse);
        Assert.assertNull(vzdl);

        addAccessoriesUIResponse.setServiceBody(null);
        vzdl = omniDLHelper.populateVzdlDataForAddAccessories(request,addAccessoriesUIResponse);
        Assert.assertNull(vzdl);


        request.getData().setLines(null);
        vzdl = omniDLHelper.populateVzdlDataForAddAccessories(request,addAccessoriesUIResponse);
        Assert.assertNull(vzdl);

        request.setData(null);
        vzdl = omniDLHelper.populateVzdlDataForAddAccessories(request,addAccessoriesUIResponse);
        Assert.assertNull(vzdl);

    }

    @Test
    public void populateVzdlDataForAddAccessoryTest() {
        AddAccessoriesUIRequest request = new AddAccessoriesUIRequest();
        AddAccessoriesUIResponse response = new AddAccessoriesUIResponse();
        Assert.assertNull(omniDLHelper.populateVzdlDataForAddAccessories(request, response));

        AddAccServiceBody serviceBody = new AddAccServiceBody();
        AddAccServiceResponse addAccServiceResponse = new AddAccServiceResponse();
        AddAccContext context = new AddAccContext();
        CartServiceCartInfo cartInfo = new CartServiceCartInfo();
        context.setCartInfo(cartInfo);
        addAccServiceResponse.setContext(context);
        serviceBody.setServiceResponse(addAccServiceResponse);
        response.setServiceBody(serviceBody);

        AddAccessoriesData data = new AddAccessoriesData();
        request.setData(data);
        Assert.assertNull(omniDLHelper.populateVzdlDataForAddAccessories(request, response));

        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(null);
        Assert.assertNull(omniDLHelper.populateVzdlDataForAddAccessories(request, response));

        List<Line> lineList= new ArrayList<>();
        Line[] lineArr= new Line[lineList.size()];
        lineList.toArray(lineArr);
        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(lineArr);
        Assert.assertNull(omniDLHelper.populateVzdlDataForAddAccessories(request, response));

        lineList= new ArrayList<>();
        lineList.add(new Line());
        lineArr= new Line[lineList.size()];
        lineList.toArray(lineArr);
        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(lineArr);
        Assert.assertNull(omniDLHelper.populateVzdlDataForAddAccessories(request, response));

        Line[] lines = new Line[2];
        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(lines);
        Assert.assertNull(omniDLHelper.populateVzdlDataForAddAccessories(request, response));

        Lines[] linesArr= new Lines[0];
        request.getData().setLines(linesArr);
        Assert.assertNull(omniDLHelper.populateVzdlDataForAddAccessories(request, response));

        List<Lines> linesList= new ArrayList<>();
        linesList.add(null);
        linesList.add(new Lines());
        linesArr= new Lines[linesList.size()];
        linesList.toArray(linesArr);
        request.getData().setLines(linesArr);
        Assert.assertNull(omniDLHelper.populateVzdlDataForAddAccessories(request, response));

        Lines[] reqLine = new Lines[2];
        request.getData().setLines(reqLine);
        Assert.assertNull(omniDLHelper.populateVzdlDataForAddAccessories(request, response));

        lines[0] = new Line();
        Line line1= new Line();
        lines[1]= line1;
        response.getServiceBody().getServiceResponse().getContext().getCartInfo().setLines(lines);
        Assert.assertNull(omniDLHelper.populateVzdlDataForAddAccessories(request, response));

        reqLine[0] = new Lines();
        Lines lines1= new Lines();
        reqLine[1]= lines1;
        request.getData().setLines(reqLine);
        Assert.assertNotNull(omniDLHelper.populateVzdlDataForAddAccessories(request, response));

    }
}
